//
// (c) Copyright: IBM Services Company Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// Name: cs_NPW_emptyCarrier_Pickup.cpp
//
#include "cs_pptmgr.hpp"
//
#include "pcas.hh"
//
// Class: CS_PPTManager
//
// Service: cs_NPW_emptyCarrier_Pickup()
//
// Change history:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/10/23 INN-R170016 JJ.Zhang       Initial Release
//
//[Function Description]
//  Get empty carrier with required carrier category
//
//[Input Parameters]
//  const pptObjCommonIn&             strObjCommonIn
//  const csObjNPW_emptyCarrier_Pickup_in&  strNPW_emptyCarrier_Pickup_in
//
//  typedef struct csObjNPW_emptyCarrier_Pickup_in_struct
//  {
//      string           cassetteCategory;
//      any              siInfo;
//  }csObjNPW_emptyCarrier_Pickup_in;
//
//[Output Parameters]
//  csObjNPW_emptyCarrier_Pickup_out&   strNPW_emptyCarrier_Pickup_out
//
//  typedef struct csObjNPW_emptyCarrier_Pickup_out_struct
//  {
//      pptRetCode           strResult;
//      objectIdentifier     carrierID;
//      any                  siInfo;
//  }csObjNPW_emptyCarrier_Pickup_out;
//
//
//[Return Value]:
//
//  Return Code                        Messsage ID
//  ---------------------------------- -----------------------------------------
//  RC_OK                              MSG_OK
//  RC_SYSTEM_ERROR                    MSG_SYSTEM_ERROR
//
CORBA::Long CS_PPTManager_i::cs_NPW_emptyCarrier_Pickup (
    csObjNPW_emptyCarrier_Pickup_out&  strNPW_emptyCarrier_Pickup_out,
    const pptObjCommonIn&             strObjCommon,
    const csObjNPW_emptyCarrier_Pickup_in&  strNPW_emptyCarrier_Pickup_in )
{
    char* methodName = NULL;

    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cs_NPW_emptyCarrier_Pickup");

        //-----------------------------------------
        //  Get all empty carriers
        //-----------------------------------------
        objCassette_ListGetDR_in__170  strCassette_ListGetDR_in;
        strCassette_ListGetDR_in.emptyFlag                  = TRUE;
        strCassette_ListGetDR_in.cassetteCategory           = strNPW_emptyCarrier_Pickup_in.cassetteCategory;
        strCassette_ListGetDR_in.cassetteStatus             = CIMFWStrDup(CIMFW_Durable_Available);
        strCassette_ListGetDR_in.maxRetrieveCount           = -1;
        strCassette_ListGetDR_in.sorterJobCreationCheckFlag = TRUE;
        objectIdentifier dummyID;
        dummyID.identifier = CIMFWStrDup("");
        strCassette_ListGetDR_in.bankID                     = dummyID;
        strCassette_ListGetDR_in.durableSubStatus           = dummyID;
        strCassette_ListGetDR_in.flowStatus                 = CIMFWStrDup("");
        objCassette_ListGetDR_out__170 strCassette_ListGetDR_out;
        rc = cassette_ListGetDR__170(strCassette_ListGetDR_out, strObjCommonIn, strCassette_ListGetDR_in);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cassette_ListGetDR__170() rc != RC_OK");
            strBWSWaferOutAndSTBReqResult.strResult = strCassette_ListGetDR_out.strResult ;
            return( rc );
        }

        pptFoundCassetteSequence__170 strFoundCassette = strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette;
        CORBA::Long nFoundCasLen = strFoundCassette.length();

        CORBA::Long i=0;
        CORBA::Boolean bEmptyCasFoundFlg = FALSE;

        for( i=0; i<nFoundCasLen; i++ )
        {
            PPT_METHODTRACE_V3("", "i/cassetteID", i, strFoundCassette[i].cassetteID.identifier);

            //----------------------------------------------
            //   Data Condition Check
            //----------------------------------------------
            if( !strFoundCassette[i].emptyFlag )
            {
                PPT_METHODTRACE_V1("", "Input cassette is not empty.") ;
                continue;
            }
            if( CIMFWStrCmp(strFoundCassette[i].cassetteStatus, CIMFW_Durable_Available) &&
                CIMFWStrCmp(strFoundCassette[i].cassetteStatus, CIMFW_Durable_InUse    ) )
            {
                PPT_METHODTRACE_V1("", "Input cassette is not 'Available' and not InUse.") ;
                continue;
            }

            if( CIMFWStrCmp(strFoundCassette[i].transferStatus, SP_TransState_StationIn) &&
                CIMFWStrCmp(strFoundCassette[i].transferStatus, SP_TransState_BayIn)     &&
                CIMFWStrCmp(strFoundCassette[i].transferStatus, SP_TransState_ManualIn)  )
            {
                    PPT_METHODTRACE_V1("", "Input cassette is not [SI] [BI] [MI]") ;
                continue;
            }

            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;
            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                            strObjCommonIn,
                                            strFoundCassette[i].cassetteID );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "<cassette_controlJobID_Get> failed.") ;
                strNPW_emptyCarrier_Pickup_out.strResult  = strCassette_controlJobID_Get_out.strResult ;
                return rc ;
            }

            if( CIMFWStrLen( strCassette_controlJobID_Get_out.controlJobID.identifier ) != 0 )
            {
                PPT_METHODTRACE_V1("", "Input cassette is not 'controlJobID is nil'") ;
                continue;
            }

            PosCassette_var aCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette, strFoundCassette[i].cassetteID,
                                                   strNPW_emptyCarrier_Pickup_out,
                                                   cs_NPW_emptyCarrier_Pickup );

            // Check XferReserve
            CORBA::Boolean transferReserved;
            try
            {
                transferReserved = aCassette->isReserved();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isReserved)

            if ( transferReserved != FALSE )
            {
                PPT_METHODTRACE_V1("", "Cassette has XferReservation");
                continue;
            }

            // Check NPWReserve
            CORBA::Boolean dispatchReserveFlag;
            try
            {
                dispatchReserveFlag = aCassette->isDispatchReserved();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isDispatchtReserved)

            if ( dispatchReserveFlag != FALSE )
            {
                PPT_METHODTRACE_V1("", "Cassette has DispatchReservation");
                continue;
            }

            // Check SLM Reserve
            PosMachine_var aSLMReservedMachine;
            try
            {
                aSLMReservedMachine = aCassette->getSLMReservedMachine();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getSLMReservedMachine);

            if ( !CORBA::is_nil(aSLMReservedMachine) )
            {
                PPT_METHODTRACE_V1("", "Cassette has SLM Reservation");
                continue;
            }

            //check Carrier Usage type
            CORBA::String_var strCarrierUsageType;
            SI_PPT_USERDATA_GET_STRING( aPosCassette, CS_M_CAST_UsageType, strCarrierUsageType );
            PPT_METHODTRACE_V2("", "strCarrierUsageType", strCarrierUsageType );

            if ( 0 == CIMFWStrCmp(strCarrierUsageType, CS_CarrierUsageType_Production ) )
            {
                PPT_METHODTRACE_V2("", "Usage Type", strReqUsageType);
                continue;
            }
            PPT_METHODTRACE_V1("", "Assign carrier as available empty carrier." ) ;

            strNPW_emptyCarrier_Pickup_out.carrierID = strFoundCassette[i].cassetteID;

            bEmptyCasFoundFlg = TRUE;
            break;
        }
        if( !bEmptyCasFoundFlg )
        {
            PPT_METHODTRACE_V1("", "Empty cassette was not found from input cassette sequence.") ;
            SET_MSG_RC(strNPW_emptyCarrier_Pickup_out, MSG_NOT_FOUND_EMPTYCAST, RC_NOT_FOUND_EMPTYCAST) ;
            return RC_NOT_FOUND_EMPTYCAST ;
        }

        //----------------------------------------
        //  Return to caller
        //----------------------------------------		
        PPT_METHODTRACE_EXIT( "CS_PPTManager_i::cs_NPW_emptyCarrier_Pickup");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS( strNPW_emptyCarrier_Pickup_out, cs_NPW_emptyCarrier_Pickup, methodName );
}

