//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txDowngradeItemListInq.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: cs_txDowngradeItemListInq()
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/24 INN-R170016  JJ.Zhang       Equipment Monitor customization
//
// Description:
//
// Return:
//     long
//
// Parameter:
//     csDowngradeItemListInqResult& strDowngradeItemListInqResult
//     const pptObjCommonIn& strObjCommonIn
//
//  typedef  struct csDowngradeItemListInqResult_struct{
//    pptRetCode            strResult;
//    objectIdentifier      dcDefID;
//    stringSequence        selectedDCItems;
//    stringSequence        candidateDCItems;
//    any                   siInfo;
//  }csDowngradeItemListInqResult;
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_txDowngradeItemListInq (csDowngradeItemListInqResult& strDowngradeItemListInqResult,
                                                        const pptObjCommonIn& strObjCommonIn,
                                                        const csDowngradeItemListInqInParm& strDowngradeItemListInqInParm
                                                        CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txDowngradeItemListInq")
    CORBA::Long rc = RC_OK ;

    //---------------------------------------------
    // Get downgrade items from CSFSNPWDCDEF_ITEM
    //---------------------------------------------
    csObjDowngradeItemList_GetDR_in strDowngradeItemList_GetDR_in;
    strDowngradeItemList_GetDR_in.dcDefID = strDowngradeItemListInqInParm.dcDefID;
    strDowngradeItemList_GetDR_in.candidateFlag = TRUE;

    csObjDowngradeItemList_GetDR_out strDowngradeItemList_GetDR_out;
    rc = cs_downgradeItemList_GetDR( strDowngradeItemList_GetDR_out,
                               strObjCommonIn,
                               strDowngradeItemList_GetDR_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_downgradeItemList_GetDR() != RC_OK", rc);
        strDowngradeItemListInqResult.strResult = strDowngradeItemList_GetDR_out.strResult;
        return rc;
    }
    strDowngradeItemListInqResult.dcDefID = strDowngradeItemList_GetDR_out.dcDefID;
    strDowngradeItemListInqResult.selectedDCItems  = strDowngradeItemList_GetDR_out.selectedDCItems;
    strDowngradeItemListInqResult.candidateDCItems = strDowngradeItemList_GetDR_out.candidateDCItems;
 
    /*-----------------------*/
    /*   Set out structure   */
    /*-----------------------*/
    SET_MSG_RC(strDowngradeItemListInqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: cs_txDowngradeItemListInq")
    return( RC_OK );
}
