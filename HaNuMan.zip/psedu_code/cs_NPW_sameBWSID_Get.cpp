//
// (c) Copyright: IBM Services Company Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// Name: cs_NPW_sameBWSID_Get.cpp
//
// Class: CS_PPTManager
//
// Service: cs_NPW_sameBWSID_Get()
//
// Change history:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/10/20 INN-R170016 JJ.Zhang       Initial Release
//
//[Function Description]
//  Get same BWS IDs from all used BWSID by monitor product
//
//[Input Parameters]
//  const pptObjCommonIn&             strObjCommonIn
//  const csObjNPW_sameBWSID_Get_in&  strNPW_sameBWSID_Get_in
//
//  typedef struct csObjNPW_sameBWSID_Get_in_struct
//  {
//      stringSequence   strOrgBWSIDSeq;
//      any              siInfo;
//  }csObjNPW_sameBWSID_Get_in;
//
//[Output Parameters]
//  csObjNPW_sameBWSID_Get_out&   strNPW_sameBWSID_Get_out
//
//  typedef struct csObjNPW_sameBWSID_Get_out_struct
//  {
//      pptRetCode           strResult;
//      stringSequence       BWSIDs;
//      any                  siInfo;
//  }csObjNPW_sameBWSID_Get_out;
//
//
//[Return Value]:
//
//  Return Code                        Messsage ID
//  ---------------------------------- -----------------------------------------
//  RC_OK                              MSG_OK
//  RC_SYSTEM_ERROR                    MSG_SYSTEM_ERROR
//
CORBA::Long CS_PPTManager_i::cs_NPW_sameBWSID_Get (
    csObjNPW_sameBWSID_Get_out&  strNPW_sameBWSID_Get_out,
    const pptObjCommonIn&             strObjCommon,
    const csObjNPW_sameBWSID_Get_in&  strNPW_sameBWSID_Get_in )
{
    char* methodName = NULL;

    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cs_NPW_sameBWSID_Get");

        //-----------------------------------------
        //  Initialize
        //-----------------------------------------
        strNPW_sameBWSID_Get_out.BWSIDs.length(0);

        CORBA::Long i=0, j=0;
        CORBA::Long nLen = strEqpMonitorInventoryInfoSeq.length();
        for( i=0; i<nLen; i++ )
        {
            //strOrgBWSIDSeq[i] contains BWS IDs used for a bank
            //format may be: 'BWS1', or 'BWS1;BWS2' or 'BWS1;BWS2;BWS3;'
            //screen out the same BWS IDs used by start bank of every monitor product
            //Ex: orgBWSIDSeq[0]: BWS1
            //    orgBWSIDSeq[1]: BWS1;BWS2;
            //return BWSIDS contains BWS1 only
        }

        //----------------------------------------
        //  Return to caller
        //----------------------------------------		
        PPT_METHODTRACE_EXIT( "CS_PPTManager_i::cs_NPW_sameBWSID_Get");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS( strNPW_sameBWSID_Get_out, cs_NPW_sameBWSID_Get, methodName );
}

