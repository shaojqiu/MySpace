//
// (c) Copyright: IBM Services Company Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// Name: cs_NPW_CheckCoditionForBWSOut.cpp
//
#include "cs_pptmgr.hpp"

#include "pcas.hh"
//
// Class: CS_PPTManager
//
// Service: cs_NPW_CheckCoditionForBWSOut()
//
// Change history:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/10/23 INN-R170016 JJ.Zhang       Initial Release
//
//[Function Description]
//  Check BWS /Carrier condition for BWSOut operation
//
//[Input Parameters]
//  const pptObjCommonIn&             strObjCommonIn
//  const csObjNPW_CheckCoditionForBWSOut_in&  strNPW_CheckCoditionForBWSOut_in
//
//  typedef struct csbjNPW_CheckCoditionForBWSOut_in_struct
//  {
//      objectIdentifier   BWSID;
//      objectIdentifier   emptyCarrierID;
//      pptEqpPortStatus   strEqpPortStatus
//      any                siInfo;
//  }csbjNPW_CheckCoditionForBWSOut_in;
//
//[Output Parameters]
//  csbjNPW_CheckCoditionForBWSOut_out&   strNPW_CheckCoditionForBWSOut_out
//
// typedef objBase_out strNPW_CheckCoditionForBWSOut_out;
//
//
//[Return Value]:
//
//  Return Code                        Messsage ID
//  ---------------------------------- -----------------------------------------
//  RC_OK                              MSG_OK
//  RC_SYSTEM_ERROR                    MSG_SYSTEM_ERROR
//
CORBA::Long CS_PPTManager_i::cs_NPW_CheckCoditionForBWSOut (
    csbjNPW_CheckCoditionForBWSOut_out&       strNPW_CheckCoditionForBWSOut_out,
    const pptObjCommonIn&                     strObjCommon,
    const csbjNPW_CheckCoditionForBWSOut_in&  strNPW_CheckCoditionForBWSOut_in )
{
    char* methodName = NULL;

    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cs_NPW_CheckCoditionForBWSOut");


        //Check BWS /Carrier condition for BWSOut operation
        //----------------------------------------------
        // Check BWS Usage type
        //----------------------------------------------
        PosMachine_var aPosMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aPosMachine,
                                         strNPW_CheckCoditionForBWSOut_in.BWSID,
                                         strNPW_CheckCoditionForBWSOut_out,
                                         cs_NPW_CheckCoditionForBWSOut );

        CORBA::String_var bwsUsageType;
        SI_PPT_USERDATA_GET_STRING( aPosMachine, CS_S_EQP_BWSUsageType, bwsUsageType );
        PPT_METHODTRACE_V2("", "CS_S_EQP_BWSUsageType", bwsUsageType);
        if( 0 != CIMFWStrCmp(bwsUsageType, CS_ProductCategory_NonProduction) )
        {
            PPT_METHODTRACE_V1("", "bwsUsageType != NonProduction");
            CS_PPT_SET_MSG_RC_KEY1( strNPW_CheckCoditionForBWSOut_out,
                                    CS_MSG_INVALID_BWS_USAGETYPE,
                                    CS_RC_INVALID_BWS_USAGETYPE,
                                    bwsUsageType );
            return CS_RC_INVALID_BWS_USAGETYPE;
        }

        /*--------------------------------------*/
        /*   Check Cassette Category   */
        /*--------------------------------------*/
        PosCassette_var aPosCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aPosCassette, strNPW_CheckCoditionForBWSOut_in.emptyCarrierID,
                                               strNPW_CheckCoditionForBWSOut_out,
                                               cs_NPW_CheckCoditionForBWSOut );

        CORBA::String_var castUsageType;
        SI_PPT_USERDATA_GET_STRING( aPosCassette, CS_M_CAST_UsageType, castUsageType );

        if( 0 != CIMFWStrCmp(CS_CarrierUsageType_NonProduction, castUsageType) )
        {
            PPT_METHODTRACE_V1("", "castUsageType != NonProduction");
            PPT_SET_MSG_RC_KEY1( strNPW_CheckCoditionForBWSOut_out,
                                 CS_MSG_INVALID_CARRIER_USAGETYPE,
                                 CS_RC_INVALID_CARRIER_USAGETYPE,
                                 castUsageType );
            return CS_RC_INVALID_CARRIER_USAGETYPE;
        }

        /*--------------------------------------*/
        /*   Check Cassette's Transfer Status   */
        /*--------------------------------------*/

        /*-----------------------*/
        /*   Get TransferState   */
        /*-----------------------*/
        PPT_METHODTRACE_V1("", "Get TransferState");

        CORBA::String_var transferState;
        try
        {
            transferState = aPosCassette->getTransportState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTransportState)

        if ( (0 == CIMFWStrCmp(strEqpPortStatus.accessMode, SP_Eqp_AccessMode_Auto))
          && (0 != CIMFWStrCmp(transferState, SP_TransState_StationIn))
          && (0 != CIMFWStrCmp(transferState, SP_TransState_BayIn))
          && (0 != CIMFWStrCmp(transferState, SP_TransState_ManualIn)) )
        {
            PPT_METHODTRACE_V1("", "The Carrier is not transfering. Return error...");
            PPT_SET_MSG_RC_KEY2( strNPW_CheckCoditionForBWSOut_out,
                                 MSG_INVALID_CAST_XFERSTAT,
                                 RC_INVALID_CAST_XFERSTAT,
                                 transferState,
                                 strNPW_CheckCoditionForBWSOut_in.emptyCarrierID.identifier );
            return RC_INVALID_CAST_XFERSTAT;
        }

        /*--------------------------------------*/
        /*   Check loadedCassetteID             */
        /*--------------------------------------*/
        if( CIMFWStrLen(strNPW_CheckCoditionForBWSOut_in.strEqpPortStatus.loadedCassetteID.identifier) > 0 )
        {
            PPT_METHODTRACE_V1("", "The Carrier is already loaded on the equipment. Return error...");
            PPT_SET_MSG_RC_KEY1( strNPW_CheckCoditionForBWSOut_out,
                                 MSG_CST_ALREADY_LOADED,
                                 RC_CST_ALREADY_LOADED,
                                 strNPW_CheckCoditionForBWSOut_in.strEqpPortStatus.loadedCassetteID.identifier );
            return RC_CST_ALREADY_LOADED;
        }

        /*--------------------------------------*/
        /*   Check loadResrvedCassetteID        */
        /*--------------------------------------*/
        if( CIMFWStrLen(strNPW_CheckCoditionForBWSOut_in.strEqpPortStatus.loadResrvedCassetteID.identifier) > 0 )
        {
            PPT_METHODTRACE_V1("", "LoadPort already been reserved for carrier. Return error...");
            PPT_SET_MSG_RC_KEY1( strNPW_CheckCoditionForBWSOut_out,
                                 MSG_ALREADY_RESERVED_LOADPORT,
                                 RC_ALREADY_RESERVED_LOADPORT,
                                 strNPW_CheckCoditionForBWSOut_in.strEqpPortStatus.portID.identifier,
                                 strNPW_CheckCoditionForBWSOut_in.strEqpPortStatus.loadedCassetteID.identifier );
            return MSG_ALREADY_RESERVED_LOADPORT;
        }

        /*--------------------------------------*/
        /*   Check portState                    */
        /*--------------------------------------*/
        if ( 0 != CIMFWStrCmp(strNPW_CheckCoditionForBWSOut_in.strEqpPortStatus.portState, SP_PortRsc_PortState_LoadReq) )
        {
            PPT_METHODTRACE_V1("", "The Equipment portState is not LoadReq. Return error...");
            PPT_SET_MSG_RC_KEY( strNPW_CheckCoditionForBWSOut_out,
                                MSG_NOT_FOUND_LOADREQ,
                                RC_NOT_FOUND_LOADREQ,
                                "" );
            return RC_NOT_FOUND_LOADREQ;
        }

        //----------------------------------------
        //  Return to caller
        //----------------------------------------
        PPT_METHODTRACE_EXIT( "CS_PPTManager_i::cs_NPW_CheckCoditionForBWSOut");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS( strNPW_CheckCoditionForBWSOut_out, cs_NPW_CheckCoditionForBWSOut, methodName );
}
