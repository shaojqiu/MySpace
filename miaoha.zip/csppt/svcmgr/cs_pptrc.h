// @(#) 1.2 superpos/src/csppt/source/posppt/svcmgr/cs_pptrc.h, mm_srv_5_0_cspp, mm_srv_5_0_cspp 5/27/03 10:34:10 [ 5/27/03 10:34:11 ]
//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 2003. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2003. All rights reserved.
//
// SiView
// File : cs_pptrc.h
// Description : CS PPT Return codes
//
// ** Notice **
//   This is a sample code for customizing a PPT ServiceManager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT ServiceManager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
// Change History:
//
//   Date       Defect#  Author        Description
//   ---------- -------- ------------- ------------------------------------------
//   2003/03/06 D5000000 C.Tsuchiya    Initial Release
//
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
// 2017/09/07 INN-R170002 JJ.Zhang       Contamination Control
// 2017/09/19 INN-A170008 Menghua Yin    TA Certify Support
// 2017/09/20 INN-R170014 shenql         Batch Sizing by Step
// 2017/09/23 INN-R170001 Vera Chen      Lot ID Naming Rule(10100,11201)
// 2017/09/25 INN-R170003 XL.Cong        Add new transfer state PI/PO to control FOUP location(add 10302)
// 2017/10/17 INN-A170017 Cheng Li       INN-R170017:Bare Wafer Stocker (10200,10201,10202,10203,10204,10205)
// 2017/10/20 INN-R170016 JJ.Zhang       Equipment Monitor Customization
// 2017/10/20 INN-R170017 LiHejing       Add Bare Wafer Stocker (10206,10207,10208,10209,10210)
// 2017/10/24 INN-R170017 LiHejing       Add Bare Wafer Stocker (10211)
// 2017/10/25 INN-R170016 JQ.Shao        Equipment Monitor Customization (10101,10906)
// 2017/10/25 INN-R170017 WangFang       Add for BWS (10212 to 10225)
// 2017/10/27 INN-R170016 Yangxiaojun    Add for BWS (10905)
// 2017/10/27 INN-R170017 Cheng Li       Add for Bare Wafer Stocker (10226,10227)
// 2017/10/31 INN-R170009 Nick Tsai      Add 10102
// 2017/11/02 INN-R170017-01 Evie Su     Add 10208~10236
//====================================================================================

#ifndef CSPptRC_h
#define CSPptRC_h

#include "pptrc.h"

// ******* IMPORTANT *********
// Please follow the alphabetical sequence.

//AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
//        CS_RC_Axxxx :  10100 -  10199
//------------------------------------------
#define CS_RC_ALREADY_EXIST_LOTIDCTRL                   10100   //INN-R170001
#define CS_RC_ALREADY_EXIST_EQPINVENTORYINFO            10101   //INN-R170016
#define CS_RC_APC_NEED_PILOT                            10102   //INN-R170009
//BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB
//        CS_RC_Bxxxx :  10200 -  10299
//------------------------------------------
#define CS_RC_BWS_CONFIG_DUPLICATE_BWSID               10200   //INN-R170017
#define CS_RC_BWS_CONFIG_DUPLICATE_ZONEID              10201   //INN-R170017
#define CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY      10202   //INN-R170017
#define CS_RC_BWS_CONFIG_INVALID_ZONE_MAX_CAPACITY     10203   //INN-R170017
#define CS_RC_BWS_CONFIG_NOT_ALLOWED_DELETE_ZONE       10204   //INN-R170017
#define CS_RC_BWS_CONFIG_NOT_ALLOWED_UPDATE_ZONE       10205   //INN-R170017
#define CS_RC_BWS_WAFERLIST_NOT_FOUND_BWS              10206   //INN-R170017
#define CS_RC_BWS_WAFERLIST_NOT_FOUND_ZONE             10207   //INN-R170017
#define CS_RC_BWS_WAFERLIST_NOT_FOUND_WAFER            10208   //INN-R170017
#define CS_RC_BWS_WAFERLIST_NOT_FOUND_ZONE_FOR_DELETE  10209   //INN-R170017
#define CS_RC_BWS_NOT_FOUND_ZONE_FOR_DELETE            10210   //INN-R170017
#define CS_RC_BWS_WAFERLIST_SEARCHKEY_BLANK            10211   //INN-R170017
#define CS_RC_BWS_INVENTORY_ERROR                      10212   //INN-R170017
#define CS_RC_BWS_INVENTORY_INVALID_BWS_CAPACITY       10213   //INN-R170017
#define CS_RC_BWS_INVENTORY_MISMATCH_BWSID             10214   //INN-R170017
#define CS_RC_BWS_INVENTORY_MISMATCH_WAFER_CAPACITY    10215   //INN-R170017
#define CS_RC_BWS_INVENTORY_MISMATCH_ZONEID            10216   //INN-R170017
#define CS_RC_BWS_INVENTORY_UPLOAD_NOT_ALLOWED         10217   //INN-R170017
#define CS_RC_BWS_JOB_DUPLICATE_WAFERID                10218   //INN-R170017
#define CS_RC_BWS_JOB_INVALID_BWS_AVILABLE_CAPACITY    10219   //INN-R170017
#define CS_RC_BWS_JOB_INVALID_BWS_MAX_CAPACITY         10220   //INN-R170017
#define CS_RC_BWS_JOB_INVALID_ZONE_AVILABLE_CAPACITY   10221   //INN-R170017
#define CS_RC_BWS_JOB_INVALID_ZONE_MAX_CAPACITY        10222   //INN-R170017
#define CS_RC_BWS_SM_DATA_NOT_EXIST_BWSID              10223   //INN-R170017
#define CS_RC_BWS_SM_DATA_NOT_EXIST_ZONEID             10224   //INN-R170017
#define CS_RC_BWS_NOT_BARE_WAFER_STOCKER               10225   //INN-R170017
#define CS_RC_BWS_CONFIG_NOT_FOUND_BWS                 10226   //INN-R170017
#define CS_RC_BWS_CONFIG_NOT_FOUND_ZONE                10227   //INN-R170017
#define CS_RC_BWS_INVENTORY_INVALID_ZONE_CAPACITY            10228  //INN-R170017-01
#define CS_RC_BWS_NOT_ALLOWED_MOVEBANK                       10229  //INN-R170017-01
#define CS_RC_BWS_NOT_ALLOWED_SCRAPWAFER                     10230  //INN-R170017-01
#define CS_RC_BWS_NOT_ALLOWED_OPERATION_FOR_SORTERJOB        10231  //INN-R170017-01
#define CS_RC_BWS_NOT_ALLOWED_OPERATION_FOR_SPECIALCONTROL   10232  //INN-R170017-01
#define CS_RC_BWS_NOT_ALLOWED_OPERATION_FOR_BWSCONFIG        10233  //INN-R170017-01
#define CS_RC_BWS_NOT_ALLOWED_OPERATION_FOR_BWSINFO          10234  //INN-R170017-01                                                            
#define CS_RC_BWS_NOT_ALLOWED_SORTER_ACTION                  10235  //INN-R170017-01
#define CS_RC_BWS_NOT_ALLOWED_SORTER_ACTION_INCONSISTENCY    10236  //INN-R170017-01                                                           
//CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
//        CS_RC_Cxxxx :  10300 -  10399
//------------------------------------------
#define CS_RC_CARRIER_CONTAMINATION_MISMATCH             		10300   //INN-A170002
#define CS_RC_CANNOT_HOLDRELEASE_CCMH                    		10301   //INN-A170002
#define CS_RC_CAST_XFERSTATE_BE_CHANGED_BY_OTHER_OPERATION		10302   //INN-R170003
#define CS_RC_CARRIER_USAGE_TYPE_MISMATCH                               10303   //INN-A170002

//DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD
//        CS_RC_Dxxxx :  10400 -  10499
//------------------------------------------
#define CS_RC_DIFFERENT_CONTAMINATION_FOR_MERGE                         10400   //INN-A170002
#define CS_RC_DIFFERENT_PRFLAG_FOR_MERGE                                10401   //INN-A170002
#define CS_RC_DUPLICATED_EQPMON_DEFINITION                              10402   //INN-A170016

//EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
//        CS_RC_Exxxx :  10500 -  10599
//------------------------------------------

//FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
//        CS_RC_Fxxxx :  10600 -  10699
//------------------------------------------

//GGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG
//        CS_RC_Gxxxx :  10700 -  10799
//------------------------------------------

//HHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH
//        CS_RC_Hxxxx :  10800 -  10899
//------------------------------------------

//IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII
//        CS_RC_Ixxxx :  10900 -  10999
//------------------------------------------
#define CS_RC_INVALID_FORMAT                            10900   //INN-A170008
#define CS_RC_INVALID_CARRIER_USAGETYPE                 10901   //INN-A170002
#define CS_RC_INVAILD_WET_BATCH_SIZE                    10902   //INN-R170014
#define CS_RC_INVAILD_WET_WAFER_COUNT                   10903   //INN-R170014
#define CS_RC_INVALID_NPW_MONITOR_TYPE                  10904   //INN-R170016
#define CS_RC_INVALID_DWNGITEMVALUE                     10905   //INN-R170016
#define CS_RC_INVALID_BWS_USAGETYPE                     10906   //INN-R170016
//JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ
//        CS_RC_Jxxxx :  11000 -  11099
//------------------------------------------

//KKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKKK
//        CS_RC_Kxxxx :  11100 -  11199
//------------------------------------------

//LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
//        CS_RC_Lxxxx :  11200 -  11299
//------------------------------------------
#define CS_RC_LOT_CONTAMINATION_MISMATCH               11200    //INN-A170002
#define CS_RC_LOTIDCTRL_NOT_FOUND                      11201    //INN-R170001

//MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
//        CS_RC_Mxxxx :  11300 -  11399
//------------------------------------------

//NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
//        CS_RC_Nxxxx :  11400 -  11599
//------------------------------------------
#define CS_RC_NO_RESPONSE_RMS                          11400    //INN-A170001
#define CS_RC_NOT_SAME_CONTAMINATION                   11401    //INN-R170002
#define CS_RC_NOT_FOUND_EQPMONITOR_INVENTORY_INFO      11402    //INN-R170016
#define CS_RC_NPW_TOO_MANY_WAFER                       11403    //INN-R170016
#define CS_RC_NOT_FOUND_ENOUGH_SOURCE_WAFER            11404    //INN-R170016
#define CS_RC_NOT_SAME_CARRIER_CATEGOPRY               11405    //INN-R170016
#define CS_RC_NOT_EXIST_BWSOUTSTB_INFO                 11406    //INN-R170016
//OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
//        CS_RC_Oxxxx :  11600 -  11699
//------------------------------------------

//PPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPPP
//        CS_RC_Pxxxx :  11700 -  11799
//------------------------------------------

//QQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQQ
//        CS_RC_Qxxxx :  11800 -  11899
//------------------------------------------

//RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
//        CS_RC_Rxxxx :  11900 -  11999
//------------------------------------------
#define CS_RC_RMS_SERVER_BIND_FAIL                     11900    //INN-A170001
#define CS_RC_REQUIRED_CAST_CATEGORY_MISMATCH          11901    //INN-A170002

//SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS
//        CS_RC_Sxxxx :  12000 -  12099
//------------------------------------------
#define CS_RC_SAMPLE_RETURN_CODE                       12000

//TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
//        CS_RC_Txxxx :  12100 -  12199
//------------------------------------------

//UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU
//        CS_RC_Uxxxx :  12200 -  12299
//------------------------------------------
#define CS_RC_USER_RMS_FUNCTION_CHECK_FAIL             12200  //INN-A170001
#define CS_RC_USER_SKILL_EXPIRED_DATE                  12201  //INN-A170008
#define CS_RC_USAGE_TYPE_MISMATCH                      12202  //INN-R170002

//VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV
//        CS_RC_Vxxxx :  12300 -  12399
//------------------------------------------

//WWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWW
//        CS_RC_Wxxxx :  12400 -  12499
//------------------------------------------
#define CS_RC_WAFER_SLOTMAP_UNMATCH                     12400  //INN-R170016
#define CS_RC_WAFER_NO_USE_BY_EQPMON                    12401  //INN-R170016

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
//        CS_RC_Xxxxx :  12500 -  12599
//------------------------------------------

//YYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYYY
//        CS_RC_Yxxxx :  12600 -  12699
//------------------------------------------

//ZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZZ
//        CS_RC_Zxxxx :  12700 -  12799
//------------------------------------------


#endif

