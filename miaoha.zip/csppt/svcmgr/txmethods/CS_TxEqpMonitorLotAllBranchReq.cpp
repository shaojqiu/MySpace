#ifndef lint
static char *sccsid =  "@(#) 1.1 /superpos/src/csppt/source/posppt/svcmgr/txmethods/CS_TxEqpMonitorLotAllBranchReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:51:36 [ 7/13/07 21:51:36 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: CS_TxEqpMonitorLotAllBranchReq.cpp
//
//
#include "cs_pptsm.hpp"
#include "pptenv.hpp"
#include "spfunc.hpp"
#include "ppteventlog.hpp"
//
// Class: CS_PPTServiceManager
//
// Service: CS_TxEqpMonitorLotAllBranchReq()
//
// Change history:
// Date       Defect#       Person         Comments
// ---------- ------------- -------------- -------------------------------------------
// 2017-10-17 INN-R170016   JQ.Shao        NPW Management Initial Release

// Description:
//<Method Summary>

//</Method Summary>

//<MRM>

//</MRM>
//
// Return:
//     csEqpMonitorLotAllBranchReqResult
//
// Parameter:
//
//     const pptUser&                              requestUserID
//     const csEqpMonitorLotAllBranchReqInParm&    strEqpMonitorLotAllBranchReqInParm
//     const char *                                claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//Sample code:
//<Sample Code>

//</Sample Code>
//
//<Method Start>

#define  TRANSACTION_ID "CSTRC004"
csEqpMonitorLotAllBranchReqResult* CS_PPTServiceManager_i:: CS_TxEqpMonitorLotAllBranchReq (
    const pptUser&                              requestUserID,
    const csEqpMonitorLotAllBranchReqInParm&    strEqpMonitorInventoryListInqInParm,
    const char *                                claimMemo
    CORBAENV_LAST_CPP)
{
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);    
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i:: CS_TxEqpMonitorLotAllBranchReq ")
    CS_PPT_PARMTRACE_VERBOSE2(requestUserID,strEqpMonitorInventoryListInqInParm);  

    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
    csEqpMonitorLotAllBranchReqResult* retVal = new csEqpMonitorLotAllBranchReqResult;
    pptEventParameterSequence strEventParameter ;
    objCalendar_GetCurrentTimeDR_out strCalendar_GetCurrentTimeDR_out ;
    pptObjCommonIn strObjCommonIn ;
    CORBA::Long rc = 0 ;

    // Initialising strObjCommonIn's first two parameters
    strObjCommonIn.transactionID = CIMFWStrDup(TRANSACTION_ID) ;
    strObjCommonIn.strUser = requestUserID ;
    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

    // Incoming Log Put
    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp =
                       strObjCommonIn.strTimeStamp.reportTimeStamp;

    CORBA::ULong nLen = strEventParameter.length();
    strEventParameter.length( nLen + 2 );
    strEventParameter[nLen].parameterName    = CIMFWStrDup( "EqpMonitorID");
    strEventParameter[nLen++].parameterValue = strEqpMonitorInventoryListInqInParm.eqpMonitorID.identifier;
    strEventParameter[nLen].parameterName    = CIMFWStrDup( "CAR_ID");
    strEventParameter[nLen++].parameterValue = strEqpMonitorInventoryListInqInParm.carrierID.identifier;

    PPTEVENTLOG( retVal, &strObjCommonIn, &strEventParameter );

    CREATE_TX_OBJ;

    TX_BEGIN(calendar_GetCurrentTimeDR)
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn) ;
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp ;
        if ( CIMFWStrLen(strObjCommonIn.strUser.functionID)==0 )
        {
            strObjCommonIn.strUser.functionID = CIMFWStrDup(TRANSACTION_ID) ;
        }
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "calendar_GetCurrentTimeDR() != RC_OK", rc);
        TX_ROLLBACK(calendar_GetCurrentTimeDR)
        retVal->strResult = strCalendar_GetCurrentTimeDR_out.strResult ;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;
        return retVal ;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR)

    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummy ;

    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

    TX_BEGIN(txPrivilegeCheckReq)
    try
    {
        rc = theCS_PPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult,strObjCommonIn,dummy,dummy,dummyIDs,dummyIDs,
                                                   strEqpMonitorInventoryListInqInParm.lotIDs,
                                                   dummyIDs);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "txPrivilegeCheckReq() != RC_OK", rc);
        TX_ROLLBACK(txPrivilegeCheckReq)
        retVal->strResult = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;
        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq)

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    TX_BEGIN(cs_txEqpMonitorLotAllBranchReq)

    try
    {
        rc = theCS_PPTManager->cs_txEqpMonitorLotAllBranchReq( *retVal, strObjCommonIn, strEqpMonitorInventoryListInqInParm, claimMemo );
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(cs_txEqpMonitorLotAllBranchReq)

    /*-----------------------------------------------------------------------*/
    /*   Post Process                                                        */
    /*-----------------------------------------------------------------------*/
    pptPostProcessActionRegistReqResult__100 strPostProcessActionRegistReqResult;

    if ( rc == RC_OK )
    {
        PPT_METHODTRACE_V1("", "cs_txEqpMonitorLotAllBranchReq :rc == RC_OK");

        pptPostProcessRegistrationParm strPostProcessRegistrationParm;
        strPostProcessRegistrationParm.lotIDs = retVal->lotIDs;

        //Post-Processing Registration for Cassette
        try
        {
            rc = thePPTManager->txPostProcessActionRegistReq__100( strPostProcessActionRegistReqResult,
                                                              strObjCommonIn,
                                                              strObjCommonIn.transactionID,    //TXID
                                                              NULL,                            //patternID
                                                              NULL,                            //dkey
                                                              -1,                              //seqNo
                                                              strPostProcessRegistrationParm,  //target objects
                                                              "" );
        }
        CATCH_TX_TIMEOUT_EXCEPTIONS(txPostProcessActionRegistReq__100);

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "Registration of Post Process:rc != RC_OK");
            retVal->strResult = strPostProcessActionRegistReqResult.strResult;
        }
    }

    //----------------------------------
    // Post-Processing Execution Section
    //----------------------------------
    if (rc == RC_OK)
    {
        PPT_METHODTRACE_V1("", "cs_txEqpMonitorLotAllBranchReq and txPostProcessActionRegistReq__100 :rc == RC_OK");
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(cs_txEqpMonitorLotAllBranchReq);

        //Post Process Execution for Lot
        pptPostProcessExecReqResult__100_var result  = TxPostProcessExecReq__100( requestUserID, strPostProcessActionRegistReqResult.dKey, 1, 0, NULL, "" );

        rc = atoi( result->strResult.returnCode );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "TxPostProcessExecReq__100 :rc != RC_OK");
            retVal->strResult = result->strResult;
        }
        else
        {
            PPT_METHODTRACE_V1("", "TxPostProcessExecReq__100 :rc == RC_OK");
        }
    }
    else
    {
        PPT_METHODTRACE_V1("","cs_txEqpMonitorLotAllBranchReq or txPostProcessActionRegistReq__100 :rc != RC_OK");
        TX_ROLLBACK(cs_txEqpMonitorLotAllBranchReq) ;
    }

    /*------------------------------------------------------------------------*/
    /*   Make Event Log                                                       */
    /*------------------------------------------------------------------------*/
    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i:: CS_TxEqpMonitorLotAllBranchReq ")
    PPT_PARMTRACE_VERBOSE1(*retVal);
    return retVal ;
}
