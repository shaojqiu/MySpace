//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// SiView
// Name: TxEqpMonitorUpdateReq.cpp
//

#include "cs_pptsm.hpp"
#include "pptenv.hpp"
#include "spfunc.hpp"
#include "ppteventlog.hpp"

// Class: PPTServiceManager
//
// Service: TxEqpMonitorUpdateReq()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- ---------------------------------------------------
// 2013/07/18 DSN000081739 Sa Guo         Equipment Monitor Automation Support
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/23 INN-R170016  JJ.Zhang       Equipment Monitor customization
//
// Description:
//<Method Summary>
// This function registers a equipment monitor definition for specified equipment.
// This function also update and delete a registered equipment monitor definition.
//
//</Method Summary>
//<MRM>
// EQP12-1. Automated Equipment Monitor Operation
//</MRM>
//
// Return:
//     pptEqpMonitorUpdateReqResult
//
// Parameter:
//     const pptUser&                                    requestUserID
//     const pptEqpMonitorUpdateReqInParm&               strEqpMonitorUpdateReqInParm
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
// Sample code:
//<Sample Code>
//    //m_pSvcMgr is PPTServiceManager class
//    //m_User is pptUser struct
//
//    pptEqpMonitorUpdateReqInParm strEqpMonitorUpdateReqInParm;
//    strEqpMonitorUpdateReqInParm.equipmentID.identifier      = CORBA::string_dup("EQP01");
//    strEqpMonitorUpdateReqInParm.eqpMonitorID.identifier     = CORBA::string_dup("EQPMon01");
//    strEqpMonitorUpdateReqInParm.actionType                  = CORBA::string_dup("Create");
//    strEqpMonitorUpdateReqInParm.monitorType                 = CORBA::string_dup("Manual");
//    pptEqpMonitorProductInfoSequence strEqpMonitorProductInfoSeq;
//    strEqpMonitorProductInfoSeq.length(1);
//    strEqpMonitorProductInfoSeq[0].productID.identifier      = CORBA::string_dup("PROD01");
//    strEqpMonitorProductInfoSeq[0].waferCount                = 3;
//    strEqpMonitorProductInfoSeq[0].startSeqNo                = 1;
//    strEqpMonitorUpdateReqInParm.strEqpMonitorProductInfoSeq = strEqpMonitorProductInfoSeq;
//
//    CORBA::String_var claimMemo = CORBA::string_dup("TEST");
//
//    pptEqpMonitorUpdateReqResult* pRet  = NULL;
//    pRet = m_pSvcMgr->TxEqpMonitorUpdateReq(
//        m_User,
//        strEqpMonitorUpdateReqInParm,
//        claimMemo
//        );
//
//</Sample Code>
//
//<Method Start>

//INN-R170016 pptEqpMonitorUpdateReqResult* PPTServiceManager_i::TxEqpMonitorUpdateReq(
pptEqpMonitorUpdateReqResult* CS_PPTServiceManager_i::CS_TxEqpMonitorUpdateReq( //INN-R170016
    const pptUser&                                       requestUserID,                              //<i>R/Request User ID
//INN-R170016    const pptEqpMonitorUpdateReqInParm&     strEqpMonitorUpdateReqInParm,               //<i>R/In Parameters
    const csEqpMonitorUpdateReqInParm&                   strEqpMonitorUpdateReqInParm,               //<i>R/In Parameters //INN-R170016
    const char*                                          claimMemo                                   //<i>R/Claim Memo
    CORBAENV_LAST_CPP )                                                                              //<i>O/IT Environment
{
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);
    PPT_METHODTRACE_ENTRY("PPTServiceManager_i::TxEqpMonitorUpdateReq");
    CS_PPT_PARMTRACE_VERBOSE3(requestUserID, strEqpMonitorUpdateReqInParm, claimMemo);

    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
    pptEqpMonitorUpdateReqResult* retVal = new pptEqpMonitorUpdateReqResult;

    pptEventParameterSequence         strEventParameter;
    objCalendar_GetCurrentTimeDR_out  strCalendar_GetCurrentTimeDR_out;
    pptObjCommonIn                    strObjCommonIn;
    CORBA::Long                       rc = 0;

    const objectIdentifier& equipmentID  = strEqpMonitorUpdateReqInParm.equipmentID;
    const objectIdentifier& eqpMonitorID = strEqpMonitorUpdateReqInParm.eqpMonitorID;

    // Initialising strObjCommonIn's first two parameters
    strObjCommonIn.transactionID    = CIMFWStrDup("TXEQC022");
    strObjCommonIn.strUser          = requestUserID;

    retVal->strResult.transactionID = CIMFWStrDup("TXEQC022");

    //---------------------------------------------
    // Set time stamp.
    //---------------------------------------------
    strObjCommonIn.strTimeStamp.reportTimeStamp                   = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;

    //---------------------------------------------
    // Put Incoming Log.
    //---------------------------------------------
    CORBA::ULong nLen = strEventParameter.length();
    strEventParameter.length(nLen + 2);
    strEventParameter[nLen].parameterName    = CIMFWStrDup("EQP_ID");
    strEventParameter[nLen++].parameterValue = CIMFWStrDup( equipmentID.identifier );
    strEventParameter[nLen].parameterName    = CIMFWStrDup("EQP_MONITOR_ID");
    strEventParameter[nLen++].parameterValue = CIMFWStrDup( eqpMonitorID.identifier );
    PPTEVENTLOG(retVal, &strObjCommonIn, &strEventParameter);

    CREATE_TX_OBJ;

    //---------------------------------------------
    // Get calendar
    //---------------------------------------------
    TX_BEGIN(calendar_GetCurrentTimeDR);
    try
    {
        rc = thePPTManager->calendar_GetCurrentTimeDR( strCalendar_GetCurrentTimeDR_out, strObjCommonIn );
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp;
        strObjCommonIn.strUser.functionID = CIMFWStrDup( "TXEQC022" );
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "calendar_GetCurrentTimeDR() != RC_OK", rc);
        TX_ROLLBACK(calendar_GetCurrentTimeDR);
        retVal->strResult               = strCalendar_GetCurrentTimeDR_out.strResult;
        retVal->strResult.transactionID = CIMFWStrDup("TXEQC022");
        return retVal;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR);

    //---------------------------------------------
    // Check privilege
    //---------------------------------------------
    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummyID;
    dummyID.identifier = CIMFWStrDup("");
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

    TX_BEGIN(txPrivilegeCheckReq);
    try
    {
        rc = thePPTManager->txPrivilegeCheckReq(
                            strPrivilegeCheckReqResult,
                            strObjCommonIn,
                            equipmentID,                                                    //equipmentID
                            dummyID,                                                        //stockerID
                            dummyIDs,                                                       //productIDs
                            dummyIDs,                                                       //routeIDs
                            dummyIDs,                                                       //lotIDs
                            dummyIDs );                                                     //machineRecipeIDs
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "txPrivilegeCheckReq() != RC_OK", rc);
        TX_ROLLBACK(txPrivilegeCheckReq)
        retVal->strResult               = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup("TXEQC022");
        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq);

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    TX_BEGIN(txEqpMonitorUpdateReq);
    try
    {
//INN-R170016        rc = thePPTManager->txEqpMonitorUpdateReq( *retVal,
        rc = theCS_PPTManager->cs_txEqpMonitorUpdateReq( *retVal, //INN-R170016
                                                   strObjCommonIn,
                                                   strEqpMonitorUpdateReqInParm,
                                                   claimMemo );
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txEqpMonitorUpdateReq);

    if ( rc == RC_OK )
    {
        PPT_METHODTRACE_V1("", "txEqpMonitorUpdateReq() == RC_OK");
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(txEqpMonitorUpdateReq);
    }
    else
    {
        PPT_METHODTRACE_V2("", "txEqpMonitorUpdateReq() != RC_OK", rc);
        TX_ROLLBACK(txEqpMonitorUpdateReq);
    }

    //-----------------------------------------------------------------------
    //   Post Process
    //-----------------------------------------------------------------------
    retVal->strResult.transactionID = CIMFWStrDup("TXEQC022");

    PPT_METHODTRACE_EXIT("PPTServiceManager_i::TxEqpMonitorUpdateReq");
    PPT_PARMTRACE_VERBOSE1(*retVal);
    return retVal;
}