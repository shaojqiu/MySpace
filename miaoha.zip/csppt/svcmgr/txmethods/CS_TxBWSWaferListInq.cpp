// (c) Copyright: IBM  Company Ltd, 2017, 2027. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017, 2027. All rights reserved.
//
// SiView
// Name: CS_TxUserCertifyCheckInq.cpp
//
// Modeficaiton History:
// Date       Defect        Name      Description
// ---------- ------------- --------- ----------------------------------------------
// 2017/10/19 INN-R170017   LiHejing  BWS Wafer List Inquery

// Class: PPTServiceManager
//
// Service: CS_TxBWSWaferListInq()

// Description:
//<Method Summary>

//</Method Summary>

// Return:
//     csBWSWaferListInqResult*
//
// Parameter:
//
//     const pptUser& requestUserID
//     const csBWSWaferListInqInParm& strBWSWaferListInqInParm

//<Method Start>
#include "cs_pptsm.hpp"
#include "ppteventlog.hpp"

csBWSWaferListInqResult* CS_PPTServiceManager_i::CS_TxBWSWaferListInq(
    const pptUser&                  requestUserID,
    const csBWSWaferListInqInParm&  strBWSWaferListInqInParm
    CORBAENV_LAST_CPP)
{
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);

    PPT_METHODTRACE_ENTRY("PPTServiceManager_i:: CS_TxBWSWaferListInq");

    CS_PPT_PARMTRACE_VERBOSE2(requestUserID, strBWSWaferListInqInParm)

    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
    csBWSWaferListInqResult* retVal = new csBWSWaferListInqResult;
    pptObjCommonIn    strObjCommonIn;

    // Initializing strObjCommonIn's first two parameters
    strObjCommonIn.transactionID = CIMFWStrDup("CSEQQ007");
    strObjCommonIn.strUser = requestUserID;

    // Incoming Log Put
    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();

    retVal->strResult.transactionID = CIMFWStrDup("CSEQQ007");
    retVal->strResult.returnCode = CIMFWStrDup("Incoming");

    // set Event Parameter
    CORBA::ULong nLen = 0;
    pptEventParameterSequence strEventParameter;
    strEventParameter.length( 7 );
    strEventParameter[nLen].parameterName  = CIMFWStrDup( "BWSID" );
    strEventParameter[nLen].parameterValue = CIMFWStrDup( strBWSWaferListInqInParm.BWSID.identifier );
    nLen++;
    strEventParameter[nLen].parameterName  = CIMFWStrDup( "SEARCH_TYPE" );
    strEventParameter[nLen].parameterValue = ConvertLongtoString( strBWSWaferListInqInParm.lSearchType );
    nLen++;
    strEventParameter[nLen].parameterName  = CIMFWStrDup( "ZONE_ID" );
    strEventParameter[nLen].parameterValue = CIMFWStrDup( strBWSWaferListInqInParm.zoneID );
    nLen++;
    strEventParameter[nLen].parameterName  = CIMFWStrDup( "WAFER_ID" );
    strEventParameter[nLen].parameterValue = CIMFWStrDup( strBWSWaferListInqInParm.strBWSWaferData.waferID.identifier );
    nLen++;
    strEventParameter[nLen].parameterName  = CIMFWStrDup( "WAFER_GRADE_ID" );
    strEventParameter[nLen].parameterValue = CIMFWStrDup( strBWSWaferListInqInParm.strBWSWaferData.waferGradeID );
    nLen++;
    strEventParameter[nLen].parameterName  = CIMFWStrDup( "LOT_ID" );
    strEventParameter[nLen].parameterValue = CIMFWStrDup( strBWSWaferListInqInParm.strBWSWaferData.lotID.identifier );
    nLen++;
    strEventParameter[nLen].parameterName  = CIMFWStrDup( "BANK_ID" );
    strEventParameter[nLen].parameterValue = CIMFWStrDup( strBWSWaferListInqInParm.strBWSWaferData.bankID.identifier );
    nLen++;

    PPTEVENTLOG( retVal, &strObjCommonIn, &strEventParameter );

    CORBA::Long rc = RC_OK;
    //------------------------------
    // calendar_GetCurrentTimeDR
    //------------------------------
    objCalendar_GetCurrentTimeDR_out strCalendar_GetCurrentTimeDR_out;
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
    TX_BEGIN(calendar_GetCurrentTimeDR);
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out, strObjCommonIn);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR);

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "calendar_GetCurrentTimeDR() != RC_OK", rc);
        TX_ROLLBACK(calendar_GetCurrentTimeDR);
        retVal->strResult = strCalendar_GetCurrentTimeDR_out.strResult;
        retVal->strResult.transactionID = CIMFWStrDup("CSEQQ007");

        return retVal;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR);

    //------------------------------
    // txPrivilegeCheckReq
    //------------------------------
    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    // Dummy Object
    objectIdentifier dummy;
    objectIdentifier eqpID = strBWSWaferListInqInParm.BWSID;
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

    TX_BEGIN(txPrivilegeCheckReq);
    try
    {
        rc = theCS_PPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult, strObjCommonIn,
                                                   eqpID,          // Equipment
                                                   dummy,          // Stocker
                                                   dummyIDs,       // ProductIDs
                                                   dummyIDs,       // RouteIDs
                                                   dummyIDs,       // LotIDs
                                                   dummyIDs);      // MachineRecipeIDs
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "rc != RC_OK");
        TX_ROLLBACK(txPrivilegeCheckReq);
        retVal->strResult = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup("CSEQQ007");

        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq)

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    TX_BEGIN(cs_txBWSWaferListInq);
    try
    {
        rc = theCS_PPTManager->cs_txBWSWaferListInq(*retVal, strObjCommonIn, strBWSWaferListInqInParm);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(cs_txBWSWaferListInq);

    /*-----------------------------------------------------------------------*/
    /*   Post Process                                                        */
    /*-----------------------------------------------------------------------*/
    if (rc == RC_OK)
    {
        PPT_METHODTRACE_V1("", "cs_txBWSWaferListInq() == RC_OK");
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(cs_txBWSWaferListInq);
    }
    else
    {
        PPT_METHODTRACE_V2("", "cs_txBWSWaferListInq() != RC_OK", rc);
        TX_ROLLBACK(cs_txBWSWaferListInq);
        retVal->strResult.transactionID = CIMFWStrDup("CSEQQ007");
        return retVal;
    }

    retVal->strResult.transactionID = CIMFWStrDup("CSEQQ007");

    PPT_METHODTRACE_EXIT("PPTServiceManager_i:: cs_txBWSWaferListInq");
    CS_PPT_PARMTRACE_VERBOSE1(*retVal);

    return retVal;
}