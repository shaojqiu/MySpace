// @(#) 1.3 superpos/src/csppt/source/posppt/svcmgr/txmethods/cs_pubmethd.hpp, mm_srv_5_0_cspp, mm_srv_5_0_cspp 6/9/03 14:07:17 [ 6/9/03 14:07:18 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView         : MMS
// File Name      : cs_pubmethd.hpp
// Description    : Definition of Customized TX Method
//
// ** Notice **
//   This is a sample code for customizing a PPT ServiceManager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT ServiceManager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//
// Modification History :
//
// Date       Defect   Name             Description
// ---------- -------- ---------------- ----------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya      Initial Release for R5.0
// 2004/10/26 D6000025 K.Murakami      eBrokerMigration.
//
// Date       version           Person         Comments
// ---------- ---------------   -------------- -------------------------------------------
// 2017/08/02 INN-A170001       Mike Chang     INN-A170001:RMS enabling
// 2017/08/28 INN-R170003       Helios Zhen    INN-R170003:Durable Management Enhancement
// 2017/07/25 INN_R170084       Jacky Yeh      170084: Automatic Vendor Lot Receive and Prepare
// 2017/09/08 INN-R170002       JJ.Zhang       Contamination Control
// 2017/09/12 INN-R170008       Menghua Yin    TA Certify Support
//                                             Add CS_TxUserCertifiedSkillDeleteReq
//                                                 CS_TxUserCertifiedSkillUpdateReq
//                                                 CS_TxUserCertifyCheckInq
//                                                 CS_TxUserCertifiedEqpTypeSkillInq
// 2017/09/11 INN-R170006       YangXigang     For fixture
// 2017/09/18 INN_R170014       shenql         170014: Automatic Vendor Lot Receive and Prepare
// 2017/10/16 INN-R170009       Nick Tsai      Add CS_TxLotComplicatedHoldReq
// 2017/10/18 INN-R170016       JQ.Shao        NPW Management Initial Release
//                                             Add CS_TxEqpMonitorInventoryListInq
//                                                 CS_TxDowngradeItemListInq
//                                                 CS_TxDowngradeSettingListInq
//                                                 CS_TxEqpMonitorInventoryUpdateReq
//                                                 CS_TxBWSWaferOutAndSTBReq
//                                                 CS_TxEqpMonitorLotSTBReq
//                                                 CS_TxEqpMonitorLotAllBranchReq
//                                                 CS_TxEqpMonitorLotPrepareIDResetReq
//                                                 CS_TxDowngradeItemUpdateReq
//                                                 CS_TxDowngradeSettingUpdateReq
//                                                 CS_TxEqpMonitorSourceCandidateInfoInq
// 2017/10/19 INN-R170027       Vera Chen      Add CS_TxNPWProductChangeReq
// 2017/10/22 INN-R170017       LiHejing       Add CS_TxBWSWaferListInq
// 2017/10/24 INN-R170017       Cheng Li       Add CS_TxBWSConfigInfoInq
//                                                 CS_TxBWSConfigChangeReq
// 2017/10/27 INN-R170017       Wang Fang      Add CS_TxBWSInventoryReq
// 2017/11/01 INN-R170003-01    Evie Su        Add CS_TxDurableDeliveryReq
// 2017/11/02 INN-R170003-02    Nick Tsai      Add TxDurableStatusMultiChangeReq
//



#ifndef CS_PubMethods_hpp
#define CS_PubMethods_hpp

// Define Customized TX Method here.
//D02.0057 Add Start
virtual csEqpInAuditListInqResult* CS_TxEqpInAuditListInq(
    const pptUser&                   requestUserID,
    CORBA::Boolean                   bodyFlag,
    CORBA::Boolean                   constFlag
    CORBAENV_LAST_HPP
);

virtual csEqpListByOwnerInqResult* CS_TxEqpListByOwnerInq(
    const pptUser&                   requestUserID,
    const objectIdentifier&          equipmentOwnerID
    CORBAENV_LAST_HPP
);

virtual csEqpRMSFlgInqResult* CS_TxEqpRMSFlgInq(
    const pptUser&                   requestUserID,
    const objectIdentifier&          equipmentID
    CORBAENV_LAST_HPP
);

virtual csPrivilegeCheckForRMSReqResult* CS_TxPrivilegeCheckForRMSReq
(
    const pptUser&                   requestUserID,
    const objectIdentifier&          equipmentID
    CORBAENV_LAST_HPP
);

// Transaction Id : CSEQQ014
virtual csEqpInfoListByOwnerInqResult* CS_TxEqpInfoListByOwnerInq(
    const pptUser&                     requestUserID,
    const objectIdentifier&            equipmentOwnerID
    CORBAENV_LAST_HPP
);

virtual csEqpRelatedRecipeIDAuditFlagListInqResult* CS_TxEqpRelatedRecipeIDAuditFlagListInq
(
    const pptUser& requestUserID,
    const objectIdentifier& equipmentID,
    CORBA::Boolean getAuditFlag
    CORBAENV_LAST_HPP
) ;
//D02.0057 Add End

//D6000025virtual csTestFunctionResult* TxTestFunction( const pptUser& requestUserID,const char *FunctionID, const objectIdentifier& lotID, const objectIdentifier& equipmentID, const char *claimMemo, CORBA::Environment &IT_env = CORBA::default_environment) ;
virtual csTestFunctionResult* TxTestFunction( const pptUser& requestUserID,const char *FunctionID, const objectIdentifier& lotID, const objectIdentifier& equipmentID, const objectIdentifier& routeID, const char *operationNumber, const char *claimMemo CORBAENV_LAST_HPP) ;  //D6000025
//INN-R170003 Add Start
virtual csCassetteInspectionTimeResetReqResult* CS_TxCassetteInspectionTimeResetReq
(
    const pptUser& 						requestUserID,
    const objectIdentifier& 			cassetteID,
    const char*              			claimMemo
    CORBAENV_LAST_HPP
) ;
virtual csCassettePMTimeResetReqResult* CS_TxCassettePMTimeResetReq
(
    const pptUser& 						requestUserID,
    const objectIdentifier& 			cassetteID,
    const char*              			claimMemo
    CORBAENV_LAST_HPP
) ;
virtual csReticleWaferCountResetReqResult* CS_TxReticleWaferCountResetReq
(
    const pptUser& 						requestUserID,
    const objectIdentifier& 			reticleID,
    const char*              			claimMemo
    CORBAENV_LAST_HPP
) ;
virtual csReticleUsedDurationResetReqResult* CS_TxReticleUsedDurationResetReq
(
    const pptUser& 						requestUserID,
    const objectIdentifier& 			reticleID,
    const char*              			claimMemo
    CORBAENV_LAST_HPP
) ;

//INN-R170084 add start
// TxID: CSTRC001
virtual csVendorLotReserveReqResult* CS_TxVendorLotReserveReq
(
    const pptUser&                          requestUserID,
    const objectIdentifier&                 bankID,
    const char *                            lotType,
    const char *                            subLotType,
    const char *                            sourceProduct,
    const char *                            partNo,
    const pptNewLotAttributes&              strNewLotAttributes
    CORBAENV_LAST_HPP
) ;

// TxID: CSTRC002
virtual csVendorLotReserveCancelReqResult* CS_TxVendorLotReserveCancelReq
(
    const pptUser&                          requestUserID,
    const objectIdentifier&                 cassetteID
    CORBAENV_LAST_HPP
) ;

// TxID: CSTRQ001
virtual csVendorLotReserveListInqResult* CS_TxVendorLotReserveListInq
(
    const pptUser&                          requestUserID,
    const objectIdentifier&                 cassetteID
    CORBAENV_LAST_HPP
) ;
//INN-R170084 add end
//INN-R170002 add start
virtual pptCassetteDeliveryReqResult* TxCassetteDeliveryReq(
    const pptUser&              requestUserID,
    const objectIdentifier&     equipmentID
    CORBAENV_LAST_HPP);

virtual pptCassetteDeliveryForInternalBufferReqResult* TxCassetteDeliveryForInternalBufferReq(
    const pptUser&              requestUserID,
    const objectIdentifier&     equipmentID
    CORBAENV_LAST_HPP);

virtual csCarrierUsageTypeChangeReqResult* CS_TxCarrierUsageTypeChangeReq (
    const pptUser&                           requestUserID,
    const csCarrierUsageTypeChangeReqInParm& strCarrierUsageTypeChangeReqInParm,
    const char*                              claimMemo
    CORBAENV_LAST_HPP);
//INN-R170002 add end

//INN-R170008 Add Start

virtual csUserCertifiedSkillDeleteReqResult* CS_TxUserCertifiedSkillDeleteReq(
    const pptUser&                              requestUserID,
    const csUserCertifiedSkillDeleteReqInParm&  strUserCertifiedSkillDeleteReqInParm
    CORBAENV_LAST_HPP);

virtual csUserCertifiedSkillUpdateReqResult* CS_TxUserCertifiedSkillUpdateReq(
    const pptUser&                              requestUserID,
    const csUserCertifiedSkillUpdateReqInParm&  strUserCertifiedSkillUpdateReqInParm
    CORBAENV_LAST_HPP);

virtual csUserCertifyCheckInqResult* CS_TxUserCertifyCheckInq(
    const pptUser&                              requestUserID,
    const csUserCertifyCheckInqInParm&          strUserCertifyCheckInqInParm
    CORBAENV_LAST_HPP);

virtual csUserCertifiedEqpTypeSkillInqResult* CS_TxUserCertifiedEqpTypeSkillInq(
    const pptUser&                              requestUserID,
    const csUserCertifiedEqpTypeSkillInqInParm& strUserCertifiedEqpTypeSkillInqInParm
    CORBAENV_LAST_HPP);

//INN-R170008 Add End
//INN-R170006 add Start
virtual csFixtureTouchCountRptResult* CS_TxFixtureTouchCountRpt (
    const pptUser&                          requestUserID,
    const csFixtureTouchCountRptInParm&     strFixtureTouchCountRptInParm
    CORBAENV_LAST_HPP);
//INN-R170006 add End
//INN-R170014 add Start
virtual pptStartLotsReservationForInternalBufferReqResult* CS_TxStartLotsReservationForInternalBufferReq(
			const pptUser&                   requestUserID,
            const objectIdentifier&          equipmentID,
            const objectIdentifier&          controlJobID,
            const pptStartCassetteSequence&  strStartCassette,
			CORBA::Boolean                   skipBatchSizeFlag,
            CORBA::Boolean                   skipWaferCountFlag,
            const char *                     claimMemo
    CORBAENV_LAST_HPP);
//INN-R170014 add End
//INN-R170009 add start
virtual csLotComplicatedHoldReqResult* CS_TxLotComplicatedHoldReq
(
    const pptUser&                          requestUserID,
    const csLotComplicatedHoldReqInParam&   strLotComplicatedHoldReqInParam
    CORBAENV_LAST_HPP
);
//INN-R170009 add end
//INN-R170016 add start
virtual csEqpMonitorInventoryListInqResult* CS_TxEqpMonitorInventoryListInq
(
    const pptUser&                              requestUserID,
    const csEqpMonitorInventoryListInqInParm&   strEqpMonitorInventoryListInqInParm
    CORBAENV_LAST_HPP
);
virtual csDowngradeItemListInqResult* CS_TxDowngradeItemListInq
(
    const pptUser&                          requestUserID,
    const csDowngradeItemListInqInParm&     strDowngradeItemListInqInParm
    CORBAENV_LAST_HPP
);
virtual csDowngradeSettingListInqResult* CS_TxDowngradeSettingListInq
(
    const pptUser&                           requestUserID,
    const csDowngradeSettingListInqInParm&   strDowngradeSettingListInqInParm
    CORBAENV_LAST_HPP
);
virtual csEqpMonitorInventoryUpdateReqResult* CS_TxEqpMonitorInventoryUpdateReq
(
    const pptUser&                                requestUserID,
    const csEqpMonitorInventoryUpdateReqInParm&   strEqpMonitorInventoryUpdateReqInParm,
    const char *                                  claimMemo
    CORBAENV_LAST_HPP
);
virtual csBWSWaferOutAndSTBReqResult* CS_TxBWSWaferOutAndSTBReq
(
    const pptUser&                        requestUserID,
    const csBWSWaferOutAndSTBReqInParm&   strBWSWaferOutAndSTBReqInParm,
    const char *                          claimMemo
    CORBAENV_LAST_HPP
);
virtual csEqpMonitorLotSTBReqResult* CS_TxEqpMonitorLotSTBReq
(
    const pptUser&                       requestUserID,
    const csEqpMonitorLotSTBReqInParm&   strEqpMonitorLotSTBReqInParm,
    const char *                         claimMemo
    CORBAENV_LAST_HPP
);
virtual csEqpMonitorLotAllBranchReqResult* CS_TxEqpMonitorLotAllBranchReq
(
    const pptUser&                             requestUserID,
    const csEqpMonitorLotAllBranchReqInParm&   strEqpMonitorLotAllBranchReqInParm,
    const char *                               claimMemo
    CORBAENV_LAST_HPP
);
virtual csEqpMonitorLotPrepareIDResetReqResult* CS_TxEqpMonitorLotPrepareIDResetReq
(
    const pptUser&                                  requestUserID,
    const csEqpMonitorLotPrepareIDResetReqInParm&   strEqpMonitorLotPrepareIDResetReqInParm,
    const char *                                    claimMemo
    CORBAENV_LAST_HPP
);
virtual csDowngradeItemUpdateReqResult* CS_TxDowngradeItemUpdateReq
(
    const pptUser&                          requestUserID,
    const csDowngradeItemUpdateReqInParm&   strDowngradeItemUpdateReqInParm,
    const char *                            claimMemo
    CORBAENV_LAST_HPP
);
virtual csDowngradeItemUpdateReqResult* CS_TxDowngradeSettingUpdateReq
(
    const pptUser&                             requestUserID,
    const csDowngradeSettingUpdateReqInParm&   strDowngradeSettingUpdateReqInParm,
    const char *                               claimMemo
    CORBAENV_LAST_HPP
);

virtual pptEqpMonitorUpdateReqResult* CS_TxEqpMonitorUpdateReq (
    const pptUser&                              requestUserID,
    const csEqpMonitorUpdateReqInParm&          strEqpMonitorUpdateReqInParm,
    const char*                                 claimMemo
    CORBAENV_LAST_HPP );

virtual csEqpMonitorListInqResult* CS_TxEqpMonitorListInq (
    const pptUser&                              requestUserID,
    const pptEqpMonitorListInqInParm&           strEqpMonitorListInqInParm
    CORBAENV_LAST_HPP );

virtual csEqpMonitorSourceCandidateInfoInqResult* CS_TxEqpMonitorSourceCandidateInfoInq (
    const pptUser&                                   requestUserID,
    const csEqpMonitorSourceCandidateInfoInqInParm&  strEqpMonitorSourceCandidateInfoInqInParm
    CORBAENV_LAST_HPP );
//INN-R170016 add end

//INN-R170027 Add start
virtual csNPWProductChangeReqResult* CS_TxNPWProductChangeReq
(
    const pptUser&                              requestUserID,
    const csNPWProductChangeReqInParm&          strNPWProductChangeReqInParm,
    const char *                                claimMemo
    CORBAENV_LAST_HPP
);
//INN-R170027 Add end
//INN-R170017 Add start
virtual csBWSWaferListInqResult* CS_TxBWSWaferListInq(
    const pptUser&                  requestUserID,
    const csBWSWaferListInqInParm&  strBWSWaferListInqInParm
    CORBAENV_LAST_HPP
);

virtual csBWSConfigInfoInqResult* CS_TxBWSConfigInfoInq(
        const pptUser&                     requestUserID,
        const csBWSConfigInfoInqInParm&    strBWSConfigInfoInqInParm
        CORBAENV_LAST_HPP
);

virtual csBWSConfigChangeReqResult* CS_TxBWSConfigChangeReq(
        const pptUser&                      requestUserID,
        const csBWSConfigChangeReqInParm&   strBWSConfigChangeReqInParm,
        const char *                        claimMemo
        CORBAENV_LAST_HPP
);
//INN-R170017 Add end
//INN-R170017 add start
virtual csBWSInventoryReqResult* CS_TxBWSInventoryReq
(
    const pptUser&                   requestUserID,
    const csBWSInventoryReqInParm&   strBWSInventoryReqInParm,
    const char *                     claimMemo
    CORBAENV_LAST_HPP
);
//INN-R170017 add end

//INN-R170003-01 add start
virtual csDurableDeliveryReqResult* CS_TxDurableDeliveryReq
(
    const pptUser&                   requestUserID,
    const objectIdentifier&          equipmentID
    CORBAENV_LAST_HPP
);
//INN-R170003-01 add end

//INN-R170003-02 add start
virtual pptDurableStatusMultiChangeReqResult* TxDurableStatusMultiChangeReq
(
    const pptUser&                                requestUserID,
    const pptDurableStatusMultiChangeReqInParm&   strDurableStatusMultiChangeReqInParm,
    const char*                                   claimMemo
    CORBAENV_LAST_HPP
);
//INN-R170003-02 add end

#endif
