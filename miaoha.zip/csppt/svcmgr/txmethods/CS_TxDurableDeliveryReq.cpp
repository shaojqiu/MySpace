#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/svcmgr/txmethods/CS_TxDurableDeliveryReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:52:55 [ 7/13/07 21:52:56 ]";
#endif

//
//
// SiView
// Name: CS_TxDurableDeliveryReq.cpp
//

#include "cs_pptsm.hpp"

//#include "pptdefs.h"
//#include "pptenv.hpp"
//#include "spfunc.hpp"
//#include "ppteventlog.hpp"

//=============================================================================
// For TXDSC008 : CS_TxDurableDeliveryReq
//=============================================================================
// Class: PPTServiceManager
//
// Service: CS_TxDurableDeliveryReq()
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/28 INN-R170003  Evie Su        Initial Release, copy from TxCassetteDeliveryReq.cpp
//
// Description:
//<Method Summary>
//This function selects the best Lot and sends requests for Carrier transfer to Equipment or Stocker.
//
//This function has the following purposes.
//-Select the best Lot from WIPLots and send a request to transfer the Carrier to Equipment.
//-Send a request to transfer the Carrier, which has been finished processing on Equipment, to Stocker.
//-Send a request to transfer the Carrier, which has been finished processing on Equipment, to Equipment for the next operation.
//
//When RTD (Real Time Dispatcher) is Available, the priority is given to WIPLot information or Stocker information that are returned from RTD.
//If Equipment needs Empty Carrier, the best EmptyCarrier will also be selected.
//</Method Summary>
//
//<MRM>
//DIS4-2. : Carrier Delivery Request for Auto Dispatch Mode
//</MRM>
//
// Return:
//     pptStartLotsReservationReqResult
//
// Parameter:
//
//     const pptUser&                      requestUserID,
//     const objectIdentifier&             equipmentID,
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//<Method Start>

#define TRANSACTION_ID "xxxxx"

csDurableDeliveryReqResult* CS_PPTServiceManager_i:: CS_TxDurableDeliveryReq (
    const pptUser&                      requestUserID,  //<i>R/Request User ID
    const objectIdentifier&             equipmentID     //<i>R/Equipment ID
    CORBAENV_LAST_CPP)                                  //<i>O/IT Environment
{
    PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i:: CS_TxDurableDeliveryReq ");
    PPT_PARMTRACE_VERBOSE2(requestUserID,equipmentID);
    
    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/

    csDurableDeliveryReqResult*         retVal = new csDurableDeliveryReqResult;
//    pptEventParameterSequence           strEventParameter;
//    objCalendar_GetCurrentTimeDR_out    strCalendar_GetCurrentTimeDR_out ;
//    pptObjCommonIn                      strObjCommonIn ;
//    CORBA::Long                         rc = 0 ;

//    // Initialising strObjCommonIn's first two parameters
//
//    strObjCommonIn.transactionID = CIMFWStrDup(TRANSACTION_ID) ;
//    strObjCommonIn.strUser = requestUserID ;
//
//    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;
//
//    // Incoming Log Put
//    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();
//    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp =
//                                           strObjCommonIn.strTimeStamp.reportTimeStamp;
//
//    CORBA::Long     nLen = strEventParameter.length() ;
//    strEventParameter.length( nLen + 1 ) ;
//    strEventParameter[nLen].parameterName = CIMFWStrDup("EQP_ID") ;
//    strEventParameter[nLen].parameterValue =  CIMFWStrDup( equipmentID.identifier ) ;
//    PPTEVENTLOG( retVal, &strObjCommonIn, &strEventParameter );
//
//    CREATE_TX_OBJ;
//
//    TX_BEGIN(calendar_GetCurrentTimeDR);
//    try
//    {
//        rc = thePPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn) ;
//        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp ;
//        strObjCommonIn.strUser.functionID = CIMFWStrDup( TRANSACTION_ID ) ;
//    }
//    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR);
//
//    if (rc != RC_OK)
//    {
//        PPT_METHODTRACE_V1("CS_PPTServiceManager_i:: CS_TxDurableDeliveryReq", "rc != RC_OK");
//        TX_ROLLBACK(calendar_GetCurrentTimeDR);
//        retVal->strResult = strCalendar_GetCurrentTimeDR_out.strResult ;
//        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;
//        return retVal ;
//    }
//    TX_COMMIT(calendar_GetCurrentTimeDR);
//
//    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
//    objectIdentifier dummy;
//    objectIdentifierSequence dummyIDs;
//    dummyIDs.length(0);
//
//    TX_BEGIN(txPrivilegeCheckReq);
//    try
//    {
//        rc = thePPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult,strObjCommonIn,equipmentID,dummy,dummyIDs,dummyIDs,dummyIDs,dummyIDs);
//    }
//    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq);
//
//    if (rc != RC_OK)
//    {
//        PPT_METHODTRACE_V1("CS_PPTServiceManager_i:: CS_TxDurableDeliveryReq", "rc != RC_OK");
//        TX_ROLLBACK(txPrivilegeCheckReq);
//        retVal->strResult = strPrivilegeCheckReqResult.strResult;
//        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;
//        return retVal;
//    }
//    TX_COMMIT(txPrivilegeCheckReq);
//
//    /*-----------------------------------------------------------------------*/
//    /*   Main Process                                                        */
//    /*-----------------------------------------------------------------------*/
//    TX_BEGIN(cs_txDurableDeliveryReq);
//    try
//    {
//        rc = thePPTManager->cs_txDurableDeliveryReq( *retVal, strObjCommonIn, equipmentID );
//        PPT_METHODTRACE_V2( "", "cs_txDurableDeliveryReq() rc", rc );
//
//    }
//    CATCH_TX_TIMEOUT_EXCEPTIONS(cs_txDurableDeliveryReq);
//    if (rc == RC_OK)
//    {
//        PPT_METHODTRACE_V1("CS_PPTServiceManager_i:: CS_TxDurableDeliveryReq", "rc == RC_OK");
//        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
//        TX_COMMIT(cs_txDurableDeliveryReq);
//    }
//
//    else if(rc == RC_NO_PROCESSJOBEXECFLAG || rc == RC_INVALID_SMPL_SETTING)
//    {
//        PPT_METHODTRACE_V1("CS_PPTServiceManager_i:: CS_TxDurableDeliveryReq", "rc == RC_NO_PROCESSJOBEXECFLAG || rc == RC_INVALID_SMPL_SETTING");
//        TX_COMMIT(cs_txDurableDeliveryReq);
//    }
//    else
//    {
//        TX_ROLLBACK(cs_txDurableDeliveryReq)
//        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;
//    }
//
//    // Call System Message
//    CORBA::Long lenSysMsg = retVal->strSysMstDurableInfoSeq.length();
//    PPT_METHODTRACE_V2("", "retVal->strSysMstDurableInfoSeq.length", lenSysMsg);
//    if (0 < lenSysMsg)
//    {
//        TX_BEGIN(txSystemMsgRpt)
//        CORBA::Long saveRc = rc; 
//
//        pptSystemMsgRptResult strSystemMsgRptResult;
//        for (CORBA::Long i=0; i < lenSysMsg; i++ )
//        {
//            PPT_METHODTRACE_V2("", "---------------------------------------SendMsg[i]", i);
//            PPT_METHODTRACE_V2("", "subSystemID.........", retVal->strSysMstDurableInfoSeq[i].subSystemID);
//            PPT_METHODTRACE_V2("", "systemMessageCode...", retVal->strSysMstDurableInfoSeq[i].systemMessageCode);
//            PPT_METHODTRACE_V2("", "systemMessageText...", retVal->strSysMstDurableInfoSeq[i].systemMessageText);
//
//            char sysMsg[1024];
//            memset(sysMsg, '\0', sizeof(sysMsg));
//            if ( 1020 < CIMFWStrLen(retVal->strSysMstDurableInfoSeq[i].systemMessageText) )
//            {
//                PPT_METHODTRACE_V1("", "Cut SystemMessageText");
//                strncpy( sysMsg, retVal->strSysMstDurableInfoSeq[i].systemMessageText, 1020 );
//                strcat(sysMsg, "...");
//                retVal->strSysMstDurableInfoSeq[i].systemMessageText = CIMFWStrDup(sysMsg);
//            }
//
//            try
//            {
//                rc = thePPTManager->txSystemMsgRpt( strSystemMsgRptResult,
//                                                    strObjCommonIn,
//                                                    retVal->strSysMstDurableInfoSeq[i].subSystemID,
//                                                    retVal->strSysMstDurableInfoSeq[i].systemMessageCode,
//                                                    retVal->strSysMstDurableInfoSeq[i].systemMessageText,
//                                                    retVal->strSysMstDurableInfoSeq[i].notifyFlag,
//                                                    retVal->strSysMstDurableInfoSeq[i].equipmentID,
//                                                    retVal->strSysMstDurableInfoSeq[i].equipmentStatus,
//                                                    retVal->strSysMstDurableInfoSeq[i].stockerID,
//                                                    retVal->strSysMstDurableInfoSeq[i].stockerStatus,
//                                                    retVal->strSysMstDurableInfoSeq[i].AGVID,
//                                                    retVal->strSysMstDurableInfoSeq[i].AGVStatus,
//                                                    retVal->strSysMstDurableInfoSeq[i].lotID,
//                                                    retVal->strSysMstDurableInfoSeq[i].lotStatus,
//                                                    retVal->strSysMstDurableInfoSeq[i].routeID,
//                                                    retVal->strSysMstDurableInfoSeq[i].operationID,
//                                                    retVal->strSysMstDurableInfoSeq[i].operationNumber,
//                                                    retVal->strSysMstDurableInfoSeq[i].systemMessageTimeStamp,
//                                                    "" );
//            }
//            CATCH_TX_TIMEOUT_EXCEPTIONS(txSystemMsgRpt)
//
//            if (rc != RC_OK)
//            {
//                PPT_METHODTRACE_V1("", "txSystemMsgRpt failed.")
//                TX_ROLLBACK(txSystemMsgRpt)
//                retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;
//                return retVal;
//            }
//        }
//
//        PPT_METHODTRACE_V1("", "txSystemMsgRpt succeed")
//        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
//        TX_COMMIT(txSystemMsgRpt)
//
//        //------------------------------------------
//        //  Entity Inhibit enable check.            
//        //  SP_INHIBIT_WHEN_APC_RPARMADJUST_NG      
//        //       0 --> Inhibit disable              
//        //       1 --> Inhibit enable               
//        //------------------------------------------
//        CORBA::Long envInhibitWhenAPC = atoi(getenv(SP_INHIBIT_WHEN_APC_RPARMADJUST_NG));
//        if( envInhibitWhenAPC == 1 )
//        {
//            PPT_METHODTRACE_V2("", "small Tx return error. saveRc:", saveRc);
//
//            if( saveRc == RC_NO_RESPONSE_APC      ||
//                saveRc == RC_APC_SERVER_BIND_FAIL ||
//                saveRc == RC_APC_RUNTIMECAPABILITY_ERROR  ||
//                saveRc == RC_APC_RECIPEPARAMETERREQ_ERROR ||
//                saveRc == RC_APC_RETURN_DUPLICATE_PARAMETERNAME )
//            {
//
//                CORBA::String_var strClaimMemo = CIMFWStrDup("APC IF Error.");
//
//                //------------------------------------------- 
//                // Inhibit Equipment for APC I/F Errors       
//                //------------------------------------------- 
//                TX_BEGIN(txEntityInhibitReq__101);
//                try
//                {
//                    pptEntityInhibitDetailAttributes strEntityInhibitions;
//
//                    PPT_METHODTRACE_V2("", "equipment ID to inhibit req", equipmentID.identifier);
//
//                    strEntityInhibitions.entities.length(1);
//                    strEntityInhibitions.entities[0].className           = CIMFWStrDup(SP_InhibitClassID_Equipment);
//                    strEntityInhibitions.entities[0].objectID            = equipmentID;
//                    strEntityInhibitions.entities[0].attrib              = CIMFWStrDup("");
//                    strEntityInhibitions.subLotTypes.length(0);
//                    strEntityInhibitions.startTimeStamp                  = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);
//                    
//                    if( saveRc == RC_NO_RESPONSE_APC ||
//                        saveRc == RC_APC_SERVER_BIND_FAIL )
//                    {
//                        strEntityInhibitions.reasonCode = CIMFWStrDup(SP_Reason_EntityInhibit_For_APCNoResponse);
//                    }
//                    else if( saveRc == RC_APC_RUNTIMECAPABILITY_ERROR ||
//                             saveRc == RC_APC_RECIPEPARAMETERREQ_ERROR)
//                    {
//                        strEntityInhibitions.reasonCode = CIMFWStrDup(SP_Reason_EntityInhibit_For_APCReturnCodeNG);
//                    }
//                    else if( saveRc == RC_APC_RETURN_DUPLICATE_PARAMETERNAME )
//                    {
//                        strEntityInhibitions.reasonCode = CIMFWStrDup(SP_Reason_EntityInhibit_For_APCReturnValueError);
//                    }
//                    
//                    strEntityInhibitions.ownerID          = strObjCommonIn.strUser.userID;
//                    strEntityInhibitions.claimedTimeStamp = CIMFWStrDup("");
//
//                    pptEntityInhibitReqResult__101 strEntityInhibitReqResult;
//                    rc = thePPTManager->txEntityInhibitReq__101(strEntityInhibitReqResult,
//                                                                strObjCommonIn, 
//                                                                strEntityInhibitions, 
//                                                                strClaimMemo);
//                }
//                CATCH_TX_TIMEOUT_EXCEPTIONS(txEntityInhibitReq__101);
//                if (rc == RC_OK)
//                {
//                    PPT_METHODTRACE_V1("", "txEntityInhibitReq__101 returns RC_OK");
//                    TX_COMMIT(txEntityInhibitReq__101);
//                }
//                else
//                {
//                    PPT_METHODTRACE_V2("", "txEntityInhibitReq__101 returns Error.", rc);
//                    TX_ROLLBACK(txEntityInhibitReq__101);
//                }
//            }
//        }
//    }

    /*-----------------------------------------------------------------------*/
    /*   Post Process                                                        */
    /*-----------------------------------------------------------------------*/
    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i:: CS_TxDurableDeliveryReq ");
    //CS_PPT_PARMTRACE_VERBOSE1(*retVal);
    return retVal ;
}
