// (c) Copyright: IBM  Company Ltd, 2017, 2027. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017, 2027. All rights reserved.
//
// SiView
// Name: CS_TxUserCertifiedSkillUpdateReq.cpp
//
// Modeficaiton History:
// Date       Defect           Name             Description
// ---------- -------- ---------------- ----------------------------------------------
// 2017/09/04 INN-R170008      Menghua Yin      TA Certify Update

// Class: PPTServiceManager
//
// Service: CS_TxUserCertifiedSkillUpdateReq()

// Description:
//<Method Summary>
// Update the TA Certify Skill
//</Method Summary>

// Return:
//     csUserCertifiedSkillUpdateReqResult*
//
// Parameter:
//
//     const pptUser& requestUserID
//     const csUserCertifiedSkillUpdateReqInParm& strUserCertifiedSkillUpdateReqInParm

//<Method Start>

#include "cs_pptsm.hpp"
#include "ppteventlog.hpp"

csUserCertifiedSkillUpdateReqResult* CS_PPTServiceManager_i::CS_TxUserCertifiedSkillUpdateReq (
    const pptUser& requestUserID,
    const csUserCertifiedSkillUpdateReqInParm& strUserCertifiedSkillUpdateReqInParm
    CORBAENV_LAST_CPP)
{
    CS_PPT_METHODPARMTRACELOG_FILTER( requestUserID.clientNode, requestUserID.userID.identifier );

    PPT_METHODTRACE_ENTRY ( "PPTServiceManager_i:: CS_TxUserCertifiedSkillUpdateReq" );

    // CS_PPT_PARMTRACE_VERBOSE2( requestUserID, strUserCertifiedSkillUpdateReqInParm );

    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
    csUserCertifiedSkillUpdateReqResult* retVal = new csUserCertifiedSkillUpdateReqResult;
    pptObjCommonIn    strObjCommonIn;

    // Initializing strObjCommonIn's first two parameters
    strObjCommonIn.transactionID = CIMFWStrDup( "CSOTC003" );
    strObjCommonIn.strUser = requestUserID;

    // Incoming Log Put
    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();

    retVal->strResult.transactionID = CIMFWStrDup("CSOTC003");
    retVal->strResult.returnCode    = CIMFWStrDup("Incoming");

    // set Event Parameter
    pptEventParameterSequence strEventParameter;
    CORBA::Long nlen = strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq.length();
    strEventParameter.length(nlen + 1);
    for (CORBA::Long i = 0; i < nlen; i++)
    {
        strEventParameter[i].parameterName = CIMFWStrDup("USER_ID");
        strEventParameter[i].parameterValue = strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].userID.identifier;
    }
    PPTEVENTLOG(retVal, &strObjCommonIn, &strEventParameter);

    CREATE_TX_OBJ;
    CORBA::Long rc = 0;
    
    //------------------------------
    // calendar_GetCurrentTimeDR
    //------------------------------
    objCalendar_GetCurrentTimeDR_out strCalendar_GetCurrentTimeDR_out;
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
    TX_BEGIN( calendar_GetCurrentTimeDR );
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out, strObjCommonIn);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "calendar_GetCurrentTimeDR() != RC_OK", rc);
        TX_ROLLBACK(calendar_GetCurrentTimeDR);
        retVal->strResult = strCalendar_GetCurrentTimeDR_out.strResult;
        retVal->strResult.transactionID = CIMFWStrDup("CSOTC003");

        return retVal;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR);

    //------------------------------
    // txPrivilegeCheckReq
    //------------------------------
    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    // Dummy Object
    objectIdentifier dummy;
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

    TX_BEGIN(txPrivilegeCheckReq);
    try
    {
        rc = theCS_PPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult, strObjCommonIn,
                                                   dummy,          // Equipment
                                                   dummy,          // Stocker
                                                   dummyIDs,       // ProductIDs
                                                   dummyIDs,       // RouteIDs
                                                   dummyIDs,       // LotIDs
                                                   dummyIDs);      // MachineRecipeIDs
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq)
    
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "rc != RC_OK");
        TX_ROLLBACK(txPrivilegeCheckReq);
        retVal->strResult = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup("CSOTC003");
    
        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq)

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    TX_BEGIN( cs_txUserCertifiedSkillUpdateReq );
    try
    {
        rc = theCS_PPTManager->cs_txUserCertifiedSkillUpdateReq(*retVal, strObjCommonIn, strUserCertifiedSkillUpdateReqInParm);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS( cs_txUserCertifiedSkillUpdateReq );

    /*-----------------------------------------------------------------------*/
    /*   Post Process                                                        */
    /*-----------------------------------------------------------------------*/
    if (rc == RC_OK)
    {
        PPT_METHODTRACE_V1( "", "cs_txUserCertifiedSkillUpdateReq() == RC_OK" );
        PPT_SET_TX_MSG( (*retVal), MSG_OK, RC_OK );
        TX_COMMIT( cs_txUserCertifiedSkillUpdateReq );
    }
    else
    {
        PPT_METHODTRACE_V2( "", "cs_txUserCertifiedSkillUpdateReq() != RC_OK", rc );
        TX_ROLLBACK( cs_txUserCertifiedSkillUpdateReq );
    }

    retVal->strResult.transactionID = CIMFWStrDup( "CSOTC003" );

    PPT_METHODTRACE_EXIT( "PPTServiceManager_i:: CS_TxUserCertifiedSkillUpdateReq" );
    CS_PPT_PARMTRACE_VERBOSE1( *retVal );
    return retVal;
}