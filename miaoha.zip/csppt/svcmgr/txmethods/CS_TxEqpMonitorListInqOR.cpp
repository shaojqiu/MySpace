//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// SiView
// Name: TxEqpMonitorListInq.cpp
//

#include "cs_pptsm.hpp"
#include "pptenv.hpp"
#include "spfunc.hpp"
#include "ppteventlog.hpp"

// Class: PPTServiceManager
//
// Service: TxEqpMonitorListInq()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- ---------------------------------------------------
// 2013/07/10 DSN000081739 Sa Guo         Equipment Monitor Automation Support
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/23 INN-R170016  JJ.Zhang       Equipment Monitor customization
//
//
// Description:
//<Method Summary>
// This function returns equipment monitor information for specified equipment or a specified equipment monitor.
//
//</Method Summary>
//<MRM>
// EQP12-1. Automated Equipment Monitor Operation
//</MRM>
//
// Return:
//     pptEqpMonitorListInqResult
//
// Parameter:
//     const pptUser&                                    requestUserID
//     const pptEqpMonitorListInqInParm&                 strEqpMonitorListInqInParm
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
// Sample code:
//<Sample Code>
//    //m_pSvcMgr is PPTServiceManager class
//    //m_User is pptUser struct
//
//    pptEqpMonitorListInqInParm strEqpMonitorListInqInParm;
//    strEqpMonitorListInqInParm.equipmentID.identifier = CORBA::string_dup("EQP01");
//    strEqpMonitorListInqInParm.eqpMonitorID.identifier = CORBA::string_dup("EQP01");
//
//    pptEqpMonitorListInqResult* pRet  = NULL;
//    pRet = m_pSvcMgr->TxEqpMonitorListInq(
//        m_User,
//        strEqpMonitorListInqInParm
//        );
//
//</Sample Code>
//
//<Method Start>

//INN-R170016 pptEqpMonitorListInqResult* PPTServiceManager_i::TxEqpMonitorListInq(
csEqpMonitorListInqResult* CS_PPTServiceManager_i::CS_TxEqpMonitorListInq( //INN-R170016
    const pptUser&                                       requestUserID,                              //<i>R/Request User ID
    const pptEqpMonitorListInqInParm&                    strEqpMonitorListInqInParm                  //<i>R/In Parameters
    CORBAENV_LAST_CPP )                                                                              //<i>O/IT Environment
{
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i::CS_TxEqpMonitorListInq");
    PPT_PARMTRACE_VERBOSE2(requestUserID, strEqpMonitorListInqInParm);

    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
//INN-R170016    pptEqpMonitorListInqResult* retVal = new pptEqpMonitorListInqResult;
    csEqpMonitorListInqResult* retVal = new csEqpMonitorListInqResult; //INN-R170016

    pptEventParameterSequence strEventParameter;
    objCalendar_GetCurrentTimeDR_out strCalendar_GetCurrentTimeDR_out;
    pptObjCommonIn strObjCommonIn;

    CORBA::Long rc = 0;

    const objectIdentifier& equipmentID  = strEqpMonitorListInqInParm.equipmentID;
    const objectIdentifier& eqpMonitorID = strEqpMonitorListInqInParm.eqpMonitorID;

    // Initialising strObjCommonIn's first two parameters
    strObjCommonIn.transactionID = CIMFWStrDup("TXEQQ024");
    strObjCommonIn.strUser = requestUserID;

    retVal->strResult.transactionID = CIMFWStrDup("TXEQQ024");

    //---------------------------------------------
    // Set time stamp.
    //---------------------------------------------
    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;

    //---------------------------------------------
    // Put Incoming Log.
    //---------------------------------------------
    CORBA::ULong nLen = strEventParameter.length();
    strEventParameter.length(nLen + 2);
    strEventParameter[nLen].parameterName    = CIMFWStrDup("EQP_ID");
    strEventParameter[nLen++].parameterValue = CIMFWStrDup( equipmentID.identifier );
    strEventParameter[nLen].parameterName    = CIMFWStrDup("EQP_MONITOR_ID");
    strEventParameter[nLen++].parameterValue = CIMFWStrDup( eqpMonitorID.identifier );
    PPTEVENTLOG(retVal, &strObjCommonIn, &strEventParameter);

    CREATE_TX_OBJ;

    //---------------------------------------------
    // Get calendar
    //---------------------------------------------
    TX_BEGIN(calendar_GetCurrentTimeDR);
    try
    {
        rc = thePPTManager->calendar_GetCurrentTimeDR( strCalendar_GetCurrentTimeDR_out, strObjCommonIn );
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp;
        if ( CIMFWStrLen(strObjCommonIn.strUser.functionID)==0 )
        {
            strObjCommonIn.strUser.functionID = CIMFWStrDup( "TXEQQ024" );
        }
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "calendar_GetCurrentTimeDR() != RC_OK", rc);
        TX_ROLLBACK(calendar_GetCurrentTimeDR);
        retVal->strResult               = strCalendar_GetCurrentTimeDR_out.strResult;
        retVal->strResult.transactionID = CIMFWStrDup("TXEQQ024");
        return retVal;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR);

    //---------------------------------------------
    // Check privilege
    //---------------------------------------------
    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummyID;
    dummyID.identifier = CIMFWStrDup("");
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

    TX_BEGIN(txPrivilegeCheckReq);
    try
    {
        rc = thePPTManager->txPrivilegeCheckReq(
                            strPrivilegeCheckReqResult,
                            strObjCommonIn,
                            equipmentID,    //equipmentID
                            dummyID,        //stockerID
                            dummyIDs,       //productIDs
                            dummyIDs,       //routeIDs
                            dummyIDs,       //lotIDs
                            dummyIDs );     //machineRecipeIDs
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "txPrivilegeCheckReq() != RC_OK", rc);
        TX_ROLLBACK(txPrivilegeCheckReq)
        retVal->strResult               = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup("TXEQQ024");
        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq);

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    TX_BEGIN(txEqpMonitorListInq);
    try
    {
//INN-R170016        rc = thePPTManager->txEqpMonitorListInq( *retVal,
        rc = theCS_PPTManager->cs_txEqpMonitorListInq( *retVal, //INN-R170016
                                                 strObjCommonIn,
                                                 strEqpMonitorListInqInParm );
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txEqpMonitorListInq);

    if ( rc == RC_OK )
    {
        PPT_METHODTRACE_V1("", "txEqpMonitorListInq() == RC_OK");
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(txEqpMonitorListInq);
    }
    else
    {
        PPT_METHODTRACE_V2("", "txEqpMonitorListInq() != RC_OK", rc);
        TX_ROLLBACK(txEqpMonitorListInq);
    }

    //-----------------------------------------------------------------------
    //   Post Process
    //-----------------------------------------------------------------------
    retVal->strResult.transactionID = CIMFWStrDup("TXEQQ024");

    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i::CS_TxEqpMonitorListInq");
    CS_PPT_PARMTRACE_VERBOSE1(*retVal);
    return retVal;
}