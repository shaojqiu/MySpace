//
// (c) Copyright: IBM Taiwan Industrial Solution Co., Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// File : CS_TxVendorLotReserveListInq.cpp
//
// Description :
//
// Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/07/25 INN-R170084  Jacky Yeh      170084: Automatic Vendor Lot Receive and Prepare
//

#include "cs_pptsm.hpp"

#include "pptenv.hpp"
#include "ppteventlog.hpp"
#include "spfunc.hpp"

#define TRANSACTION_ID "CSTRQ001"
csVendorLotReserveListInqResult* CS_PPTServiceManager_i::CS_TxVendorLotReserveListInq (
    const pptUser&                                    requestUserID,
    const objectIdentifier&                           cassetteID
    CORBAENV_LAST_CPP )
{
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i::CS_TxVendorLotReserveListInq");
    CS_PPT_PARMTRACE_VERBOSE2( requestUserID,cassetteID );
    
    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
    csVendorLotReserveListInqResult* retVal = new csVendorLotReserveListInqResult;
    pptEventParameterSequence strEventParameter ;
    objCalendar_GetCurrentTimeDR_out strCalendar_GetCurrentTimeDR_out ;
    pptObjCommonIn strObjCommonIn ;
    
    CORBA::Long rc = 0 ;
    
    // Initialising strObjCommonIn's first two parameters
    strObjCommonIn.transactionID = CIMFWStrDup(TRANSACTION_ID) ;
    strObjCommonIn.strUser = requestUserID ;

    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

    // Incoming Log Put
    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp =
                       strObjCommonIn.strTimeStamp.reportTimeStamp;

    // Set data for EventParameter
    CORBA::Long nLen = strEventParameter.length() ;
    
    //ToDo Add eventlog parameters here
    strEventParameter.length( nLen + 1 ) ;  
    strEventParameter[nLen].parameterName = CIMFWStrDup("CAST_ID") ;
    strEventParameter[nLen].parameterValue =  CIMFWStrDup( cassetteID.identifier ) ;
    
    PPTEVENTLOG(retVal, &strObjCommonIn, &strEventParameter);
    
    CREATE_TX_OBJ

    TX_BEGIN(calendar_GetCurrentTimeDR)
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn) ;
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp ;
        if ( CIMFWStrLen(strObjCommonIn.strUser.functionID) == 0 )
        {
            strObjCommonIn.strUser.functionID = CIMFWStrDup( TRANSACTION_ID ) ;
        }
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2( "", "rc != RC_OK",rc )
        TX_ROLLBACK(calendar_GetCurrentTimeDR)
        retVal->strResult = strCalendar_GetCurrentTimeDR_out.strResult ;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

        return retVal ;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR)

    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult ;
    objectIdentifier dummy;
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

    TX_BEGIN(txPrivilegeCheckReq)
    try
    {
        rc = theCS_PPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult,strObjCommonIn,dummy,dummy,dummyIDs,dummyIDs,dummyIDs,dummyIDs);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2( "", "rc != RC_OK",rc )
        TX_ROLLBACK(txPrivilegeCheckReq)
        retVal->strResult = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq)
    
    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    TX_BEGIN(cs_txVendorLotReserveListInq)
    try
    {
        rc = theCS_PPTManager->cs_txVendorLotReserveListInq( *retVal,strObjCommonIn,cassetteID );
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(cs_txVendorLotReserveListInq)
    
    if (rc == RC_OK)
    {
        PPT_METHODTRACE_V1( "", "rc == RC_OK" )
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(cs_txVendorLotReserveListInq)
    }
    else
    {
        PPT_METHODTRACE_V2( "", "rc != RC_OK",rc )
        TX_ROLLBACK(cs_txVendorLotReserveListInq)
    }
    
    /*-----------------------------------------------------------------------*/
    /*   Post Process                                                        */
    /*-----------------------------------------------------------------------*/

    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

    PPT_METHODTRACE_EXIT( "CS_PPTServiceManager_i::CS_TxVendorLotReserveListInq" );
    CS_PPT_PARMTRACE_VERBOSE1(*retVal);
    return retVal;
}
