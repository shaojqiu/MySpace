//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2003. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2003. All rights reserved.
//
// SiView
// Name: CS_TxPrivilegeCheckForRMSReq.cpp
//

#include "cs_pptsm.hpp"
#include "pptenv.hpp"          
#include "spfunc.hpp"  
#include "ppteventlog.hpp"     

// Class: CS_PPTServiceManager
//
// Service: CS_TxPrivilegeCheckForRMSReq()
//
// Change history:
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
// 2017/09/15 INN-A170001 Helios Zhen    Change TRANSCTION_ID to CSOTC001
//
// Description:
//
// Return:
//     csWorkAreaListByDeptInqResult
//
// Parameter:
//        const pptUser&                   requestUserID,
//        const objectIdentifier&          equipmentID,
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
#define TRANSACTION_ID "CSOTC001"
csPrivilegeCheckForRMSReqResult* CS_PPTServiceManager_i::CS_TxPrivilegeCheckForRMSReq(
    const pptUser&                   requestUserID,
    const objectIdentifier&          equipmentID,
    CORBA::Environment&              IT_env)
{
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);    
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i:: CS_TxPrivilegeCheckForRMSReq ")
    CS_PPT_PARMTRACE_VERBOSE2(requestUserID,equipmentID);  
    
    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/

    csPrivilegeCheckForRMSReqResult* retVal = new csPrivilegeCheckForRMSReqResult;
    pptEventParameterSequence strEventParameter ;
    objCalendar_GetCurrentTimeDR_out strCalendar_GetCurrentTimeDR_out ;
    pptObjCommonIn strObjCommonIn ;
    CORBA::Long rc = 0 ;
    
    // Initialising strObjCommonIn's first two parameters

    strObjCommonIn.transactionID = CIMFWStrDup(TRANSACTION_ID) ;
    strObjCommonIn.strUser = requestUserID ;
    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;
    
    // Incoming Log Put                                                
    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();      
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp =
                       strObjCommonIn.strTimeStamp.reportTimeStamp;    

    CORBA::Long nLen = strEventParameter.length() ;
    strEventParameter.length( nLen + 1 ) ;
    strEventParameter[nLen].parameterName = CIMFWStrDup("equipmentID") ;
    strEventParameter[nLen].parameterValue =  CIMFWStrDup( equipmentID.identifier ) ;
    PPTEVENTLOG( retVal, &strObjCommonIn, &strEventParameter );

    CREATE_TX_OBJ 
    
    TX_BEGIN(calendar_GetCurrentTimeDR)
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn) ;
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp ;
        
        strObjCommonIn.strUser.functionID = CIMFWStrDup(TRANSACTION_ID) ;  
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "rc != RC_OK")
        TX_ROLLBACK(calendar_GetCurrentTimeDR)
        retVal->strResult = strCalendar_GetCurrentTimeDR_out.strResult ;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;
        return retVal ;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR)
    
    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummy;

    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);
    
    TX_BEGIN(txPrivilegeCheckReq)
    try
    {
        rc = theCS_PPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult,strObjCommonIn,equipmentID,dummy, dummyIDs,dummyIDs,dummyIDs,dummyIDs); 
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq);
    
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "rc != RC_OK")
        TX_ROLLBACK(txPrivilegeCheckReq)
        retVal->strResult = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;


        return retVal ;
    }
    TX_COMMIT(txPrivilegeCheckReq)
    
    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/

    TX_BEGIN(cs_txPrivilegeCheckForRMSReq)
    try
    {
        rc = theCS_PPTManager->cs_txPrivilegeCheckForRMSReq( *retVal, strObjCommonIn, equipmentID );
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(cs_txPrivilegeCheckForRMSReq);
    if (rc == RC_OK)
    {
        PPT_METHODTRACE_V1("", "rc == RC_OK");
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(cs_txPrivilegeCheckForRMSReq);         
    }
    else
    {
        PPT_METHODTRACE_V1("", "rc != RC_OK");
        TX_ROLLBACK(cs_txPrivilegeCheckForRMSReq);

        return retVal;
    }
    
    /*-----------------------------------------------------------------------*/
    /*   Post Process                                                        */
    /*-----------------------------------------------------------------------*/
    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID);
  
    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i::CS_TxPrivilegeCheckForRMSReq");
    CS_PPT_PARMTRACE_VERBOSE1(*retVal);
    return retVal ;
}
     
