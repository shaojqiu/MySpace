// (c) Copyright: IBM  Company Ltd, 2017, 2027. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017, 2027. All rights reserved.
//
// SiView
// Name: CS_TxUserCertifiedEqpTypeSkillInq.cpp
//
// Modeficaiton History:
// Date       Defect           Name             Description
// ---------- -------- ---------------- ----------------------------------------------
// 2017/09/04 INN-R170008      Menghua Yin      TA Certify

// Class: PPTServiceManager
//
// Service: CS_TxUserCertifiedEqpTypeSkillInq()

// Description:
//<Method Summary>

//</Method Summary>

// Return:
//     csUserCertifiedEqpTypeSkillInqResult*
//
// Parameter:
//
//     const pptUser& requestUserID
//     const csUserCertifiedEqpTypeSkillInqInParm& strUserCertifiedEqpTypeSkillInqInParm

//<Method Start>
#include "cs_pptsm.hpp"
#include "ppteventlog.hpp"

csUserCertifiedEqpTypeSkillInqResult* CS_PPTServiceManager_i::CS_TxUserCertifiedEqpTypeSkillInq(
    const pptUser& requestUserID,
    const csUserCertifiedEqpTypeSkillInqInParm& strUserCertifiedEqpTypeSkillInqInParm
    CORBAENV_LAST_CPP)
{
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);

    PPT_METHODTRACE_ENTRY("PPTServiceManager_i:: CS_TxUserCertifiedEqpTypeSkillInq");

    CS_PPT_PARMTRACE_VERBOSE2(requestUserID, strUserCertifiedEqpTypeSkillInqInParm);

    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
    csUserCertifiedEqpTypeSkillInqResult* retVal = new csUserCertifiedEqpTypeSkillInqResult;
    pptObjCommonIn    strObjCommonIn;

    // Initializing strObjCommonIn's first two parameters
    strObjCommonIn.transactionID = CIMFWStrDup("CSOTQ002");
    strObjCommonIn.strUser = requestUserID;

    // Incoming Log Put
    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();

    retVal->strResult.transactionID = CIMFWStrDup("CSOTQ002");
    retVal->strResult.returnCode = CIMFWStrDup("Incoming");

    // set Event Parameter
    pptEventParameterSequence strEventParameter;
    CORBA::Long nLen = strEventParameter.length();
    strEventParameter.length(nLen + 1);
    strEventParameter[nLen].parameterName = CIMFWStrDup("USER_ID");
    strEventParameter[nLen++].parameterValue = strUserCertifiedEqpTypeSkillInqInParm.userID.identifier;
    PPTEVENTLOG(retVal, &strObjCommonIn, &strEventParameter);

    CREATE_TX_OBJ;
    CORBA::Long rc = 0;

    //------------------------------
    // calendar_GetCurrentTimeDR
    //------------------------------
    objCalendar_GetCurrentTimeDR_out strCalendar_GetCurrentTimeDR_out;
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
    TX_BEGIN(calendar_GetCurrentTimeDR);
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out, strObjCommonIn);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR);

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "calendar_GetCurrentTimeDR() != RC_OK", rc);
        TX_ROLLBACK(calendar_GetCurrentTimeDR);
        retVal->strResult = strCalendar_GetCurrentTimeDR_out.strResult;
        retVal->strResult.transactionID = CIMFWStrDup("CSOTQ002");

        return retVal;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR);

    //------------------------------
    // txPrivilegeCheckReq
    //------------------------------
    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    // Dummy Object
    objectIdentifier dummy;
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

    /*
    TX_BEGIN(txPrivilegeCheckReq);
    try
    {
        rc = theCS_PPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult, strObjCommonIn,
                                                   dummy,          // Equipment
                                                   dummy,          // Stocker
                                                   dummyIDs,       // ProductIDs
                                                   dummyIDs,       // RouteIDs
                                                   dummyIDs,       // LotIDs
                                                   dummyIDs);      // MachineRecipeIDs
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "rc != RC_OK");
        TX_ROLLBACK(txPrivilegeCheckReq);
        retVal->strResult = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup("CSOTQ002");

        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq)
    */

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    TX_BEGIN(cs_txUserCertifiedEqpTypeSkillInq);
    try
    {
        rc = theCS_PPTManager->cs_txUserCertifiedEqpTypeSkillInq(*retVal, strObjCommonIn, strUserCertifiedEqpTypeSkillInqInParm);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(cs_txUserCertifiedEqpTypeSkillInq);

    /*-----------------------------------------------------------------------*/
    /*   Post Process                                                        */
    /*-----------------------------------------------------------------------*/
    if (rc == RC_OK)
    {
        PPT_METHODTRACE_V1("", "cs_txUserCertifiedEqpTypeSkillInq() == RC_OK");
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(cs_txUserCertifiedEqpTypeSkillInq);
    }
    else
    {
        PPT_METHODTRACE_V2("", "cs_txUserCertifiedEqpTypeSkillInq() != RC_OK", rc);
        TX_ROLLBACK(cs_txUserCertifiedEqpTypeSkillInq);
    }

    retVal->strResult.transactionID = CIMFWStrDup("CSOTQ002");

    PPT_METHODTRACE_EXIT("PPTServiceManager_i:: cs_txUserCertifiedEqpTypeSkillInq");
    CS_PPT_PARMTRACE_VERBOSE1(*retVal);
    
    return retVal;
}