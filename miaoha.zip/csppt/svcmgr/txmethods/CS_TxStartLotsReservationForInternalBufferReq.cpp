#ifndef lint
static char *sccsid =  "@(#) 1.6 superpos/src/spppt/source/posppt/svcmgr/txmethods/CS_TxStartLotsReservationForInternalBufferReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 12/3/07 16:30:37 [ 12/3/07 16:30:38 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: CS_TxStartLotsReservationForInternalBufferReq.cpp
//

#include "cs_pptsm.hpp"

#include "pptdefs.h"
//D4000012 #include "pptenv.hpp"
#include "pptenv.hpp"          //D4100134 restore
#include "spfunc.hpp"
#include "ppteventlog.hpp"  //D9000007

//=============================================================================
// For TXTRC056 : CS_TxStartLotsReservationForInternalBufferReq
//=============================================================================
// Class: PPTServiceManager
//
// Service: CS_TxStartLotsReservationForInternalBufferReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2001/06/27 D4000012 K.Tamura       add environment variable control(PPTEnv::logIncoming change)
// 2001/08/08 D4000013 K.Kido         Unified Security Control.
// 2002/02/15 D4100014 H.Adachi       Add Parameter Log and Trace Log Filter
// 2002-02-25 D4100134 C.Tsuchiya     Delete thePPT_TRACE_INCOMING
// 2002/07/26 P4200078 K.Kido         Fix unnecessary length.
// 2004/08/11 D51M0000 K.Tachibana    APC I/F Enhance for Interface Spec-B
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2005-03-04 D6000101 A.Tomari       Add the following document infomation
//                                    -<Method Summary>
//                                    -<MRM>
//                                    -<Sample Code>
//                                    -<IN-parm's description>
// 2005/04/11 D6000215 K.Kido         Delete timeStamp_DoCalculation. (Migrated into txEntityInhibitReq)
// 2005-08-17 P6000489 A.Tomari       Large-Tx Method Document keywords correction
// 2006-01-20 D7000182 H.Mutoh        Enhancement of re-sending APCControlJobInformation.
// 2006/08/17 D7000228 M.Murata       Fix some logic because of memory leak.
// 2007/04/20 D9000001 H.Murakami     64bit support.
// 2007/05/25 D9000007 D.Tamura       EventLog improvement
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009/10/02 DSIV00001365 R.Okano        Entity Inhibit Improvement. (R101)
// 2017/09/18 INN-R170014  shenql         Batch Sizing by Step.
//
// Description:
//<Method Summary>
//This function supports to reserve in advance the Lot for processing to Equipment that Category ID defined in SM is Internal Buffer.
//This function performs process start reservation for the specified WIP Lots and Carriers to the Equipment.
//At the time of process start reservation; various Checks by Operation Mode of the Equipment are performed.
//By this process start reservation, System creates Control Job and its Control Job is assigned to the specified Equipment, the Lot, and Carrier.
//When this process start reservation is performed, the Equipment permits only the process start of the reserved Lots and Carriers; the process start of the reserved Lots and Carriers can perform only by the reserved Equipment.
//</Method Summary>
//
//<MRM>
// EQP11-1. : Internal Buffer Equipment (Furnace Type) Management
// EQP11-2. : Internal Buffer Equipment (Wet Bench) Management
// DIS4-1. : Start Lots Reservation
// DIS6-1. : Start Lots Reservation with Automated Reticle Transferring system
// EQP9-1. : Recipe Body Management
// DIS4-2. : Carrier Delivery Request for Auto Dispatch Mode
// EWR1-2. : Flexible Process Condition Change (Dynamic Recipe Change)
//</MRM>
//
// Return:
//     pptStartLotsReservationForInternalBufferReqResult
//
// Parameter:
//
//    const pptUser&                   requestUserID,
//    const objectIdentifier&          equipmentID,
//    const objectIdentifier&          controlJobID,
//    const pptStartCassetteSequence&  strStartCassette,
//    const char *                     claimMemo,
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//Sample code:
//<Sample Code>
//    //m_pSvcMgr is PPTServiceManager class
//    //m_User is pptUser struct
//
//    objectIdentifier EquipmentID;
//    EquipmentID.identifier           = CORBA::string_dup("CL001");
//    CORBA::String_var SelectCriteria = CORBA::string_dup(SP_DP_SelectCriteria_All);
//
//    pptWhatNextLotListInqResult* pWhatNextLotListInqResult = NULL;
//    pWhatNextLotListInqResult = m_pSvcMgr->TxWhatNextLotListInq (
//        m_User,
//        EquipmentID,
//        SelectCriteria
//        );
//
//    pptLotListInCassetteInqResult* pLotListInCassetteInqResult = NULL;
//    pLotListInCassetteInqResult = m_pSvcMgr->TxLotListInCassetteInq(
//        m_User,
//        pWhatNextLotListInqResult->strWhatNextAttributes[n1].cassetteID
//        );
//
//    pptLotInfoInqResult* pLotInfoInqResult = NULL;
//    pLotInfoInqResult = m_pSvcMgr->TxLotInfoInq(
//        m_User,
//        pLotListInCassetteInqResult->strLotListInCassetteInfo[n2].lotID,
//        TRUE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, FALSE, TRUE, TRUE, TRUE, FALSE
//        );
//
//    pptStartCassetteSequence strTmpStartCassetteSeq;
//    CORBA::Long nLotLen = pLotInfoInqResult->strLotListInCassetteInfo.lotID.length();
//    strTmpStartCassetteSeq.length(n3);
//    strTmpStartCassetteSeq[n3].strLotInCassette.length(nLotLen);
//    strTmpStartCassetteSeq[n3].strLotInCassette[n4].lotID
//                                                    = pLotInfoInqResult->strLotListInCassetteInfo.lotID[n4];
//    strTmpStartCassetteSeq[n3].strLotInCassette[n4].monitorLotFlag     = FALSE;
//    strTmpStartCassetteSeq[n3].strLotInCassette[n4].operationStartFlag = TRUE;
//    strTmpStartCassetteSeq[n3].strLotInCassette[n4].strLotWafer[n5].waferID
//                                                    = pLotInfoInqResult->strLotInfo[n6].strLotWaferAttributes[n7].waferID;
//    strTmpStartCassetteSeq[n3].strLotInCassette[n4].strLotWafer[n5].slotNumber
//                                                    = pLotInfoInqResult->strLotInfo[n6].strLotWaferAttributes[n7].slotNumber;
//    strTmpStartCassetteSeq[n3].strLotInCassette[n4].strLotWafer[n5].controlWaferFlag
//                                                    = pLotInfoInqResult->strLotInfo[n6].strLotWaferAttributes[n7].controlWaferFlag;
//
//    pptLotsInfoForStartReservationForInternalBufferInqResult*
//                                                 pLotsInfoForStartReservationForInternalBufferInqResult = NULL;
//    pLotsInfoForStartReservationForInternalBufferInqResult =
//                                                 m_pSvcMgr->TxLotsInfoForStartReservationForInternalBufferInq ( 
//        m_User,
//        EquipmentID,
//        strTmpStartCassetteSeq
//        );
//
//    CORBA::String_var ClaimMemo = CORBA::string_dup("Claim Memo");
//
//    pptStartLotsReservationForInternalBufferReqResult* pRet = NULL;
//    pRet = m_pSvcMgr->CS_TxStartLotsReservationForInternalBufferReq (
//        m_User,
//        EquipmentID,
//        ptWhatNextLotListInqResult->strWhatNextAttributes[n1].controlJob,
//        pLotsInfoForStartReservationForInternalBufferInqResult->strStartCassette,
//        ClaimMemo
//        );
//</Sample Code>
//
//<Method Start>
pptStartLotsReservationForInternalBufferReqResult* CS_PPTServiceManager_i:: CS_TxStartLotsReservationForInternalBufferReq (
            const pptUser&                   requestUserID,    //<i>R/Request User ID
            const objectIdentifier&          equipmentID,      //<i>R/Equipment ID
            const objectIdentifier&          controlJobID,     //<i>R/Control Job ID
            const pptStartCassetteSequence&  strStartCassette, //<i>R/Sequence of Start Carrier Information
            CORBA::Boolean                   skipBatchSizeFlag,  //INN-R170014
            CORBA::Boolean                   skipWaferCountFlag, //INN-R170014
//D6000025             const char *                     claimMemo,
//D6000025             CORBA::Environment&              IT_env )
            const char *                     claimMemo         //<i>O/Claim Memo      //D6000025
            CORBAENV_LAST_CPP )                                //<i>O/IT Environment  //D6000025 INN-R170014
{
    PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);    //D4100014
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i:: CS_TxStartLotsReservationForInternalBufferReq "); //INN-R170014
    PPT_PARMTRACE_VERBOSE5(requestUserID,equipmentID,controlJobID,strStartCassette,claimMemo );    //D4100014
    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/

    pptStartLotsReservationForInternalBufferReqResult*  retVal = new pptStartLotsReservationForInternalBufferReqResult;
    pptEventParameterSequence                           strEventParameter;
    objCalendar_GetCurrentTimeDR_out                    strCalendar_GetCurrentTimeDR_out ;
    pptObjCommonIn                                      strObjCommonIn ;
    CORBA::Long                                         rc = 0 ;

    // Initialising strObjCommonIn's first two parameters

    strObjCommonIn.transactionID = CIMFWStrDup("TXTRC056") ;
    strObjCommonIn.strUser = requestUserID ;

    retVal->strResult.transactionID = CIMFWStrDup("TXTRC056") ;

    // Incoming Log Put
    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp =
                                           strObjCommonIn.strTimeStamp.reportTimeStamp;
//D4000012    if (PPTEnv::logIncoming)
//D4100134    if (thePPT_TRACE_INCOMING)    //D4000012
//D9000007    if(PPTEnv::logIncoming)    //D4100134
//D9000007    {
//D9000007        retVal->strResult.transactionID = CIMFWStrDup("TXTRC056") ;
//D9000007        retVal->strResult.returnCode = CIMFWStrDup("Incoming") ;

    CORBA::Long     nLen = strEventParameter.length() ;
    strEventParameter.length( nLen + 1 ) ;
    strEventParameter[nLen].parameterName = CIMFWStrDup("EQP_ID") ;
    strEventParameter[nLen].parameterValue =  CIMFWStrDup( equipmentID.identifier ) ;

//D9000007        if ( strStartCassette.length() > 0 )
//D9000007        {
//D9000007            CORBA::Long                     strCassetteIDLen = 0 ;
//D9000007            CORBA::Long                     nLen = strEventParameter.length() ;
//D9000007//P4200078  strEventParameter.length( nLen + 2 ) ;
//D9000007            strEventParameter.length( nLen + 1 ) ;    //P4200078
//D9000007            // Calculate the length of the string
//D9000007            for( CORBA::Long j=0; j<strStartCassette.length(); j++ )
//D9000007            {
//D9000007                strCassetteIDLen += CIMFWStrLen( strStartCassette[j].cassetteID.identifier ) + 1 ;
//D9000007            }

//D9000007//D9000001            char*   strCassetteID = CORBA::string_alloc( strCassetteIDLen + 1 ) ;
//D9000007            char*   strCassetteID = CORBA::string_alloc( (CORBA::ULong) strCassetteIDLen + 1 ) ;       //D9000001
//D9000007            strCassetteID[0] = NULL ;
//D9000007            for( j=0; j<strStartCassette.length(); j++ )
//D9000007            {
//D9000007                CIMFWStrCat( strCassetteID, (const char *)strStartCassette[j].cassetteID.identifier ) ;
//D9000007                CIMFWStrCat( strCassetteID, "," ) ;
//D9000007            }
//D9000007            strEventParameter[nLen].parameterName = CIMFWStrDup("CAST_ID") ;
//D9000007            strEventParameter[nLen].parameterValue =  strCassetteID ;
//D9000007        }
//D9000007        eventLog_Put(strEventParameter, strObjCommonIn, retVal->strResult);
//D9000007        strEventParameter.length( 0 ) ;
//D9000007        nLen = 0 ;
//D9000007    }
//D9000007 add start
    CORBA::ULong castLen = strStartCassette.length();
    PPT_METHODTRACE_V2("","Start Cassette Record", castLen );

    if( castLen > 0 )
    {
        //------------------------------//
        // Collecting Start Cassette ID //
        //------------------------------//
        CORBA::ULong i_Cas ;
        for( i_Cas = 0; i_Cas < castLen; i_Cas++ )
        {
            PPT_METHODTRACE_V2("","Collected Cassette ID", strStartCassette[i_Cas].cassetteID.identifier) ;

            CORBA::ULong nLen = strEventParameter.length() ;
            strEventParameter.length( nLen + 3 ) ;
            strEventParameter[nLen].parameterName    = CIMFWStrDup("LOAD_PORT_ID");
            strEventParameter[nLen++].parameterValue = CIMFWStrDup(strStartCassette[i_Cas].loadPortID.identifier);
            strEventParameter[nLen].parameterName    = CIMFWStrDup("UNLOAD_PORT_ID") ;
            strEventParameter[nLen++].parameterValue = CIMFWStrDup(strStartCassette[i_Cas].unloadPortID.identifier);
            strEventParameter[nLen].parameterName    = CIMFWStrDup("CAST_ID") ;
            strEventParameter[nLen].parameterValue   = CIMFWStrDup(strStartCassette[i_Cas].cassetteID.identifier) ;

            //------------------------------//
            // Collecting LotID in Cassette //
            //------------------------------//
            CORBA::ULong lotsInCastLen = strStartCassette[i_Cas].strLotInCassette.length() ;
            PPT_METHODTRACE_V2("","Lot In Cassette Record", lotsInCastLen ) ;

            if ( lotsInCastLen > 0 )
            {
                CORBA::ULong strLotIDInCasLen = 0 ;
                CORBA::ULong m ;

                //---------------------------------------//
                // Calculate length of lotID in cassette //
                //---------------------------------------//
                for ( m = 0; m < lotsInCastLen; m++ )
                {
                    strLotIDInCasLen += CIMFWStrLen( strStartCassette[i_Cas].strLotInCassette[m].lotID.identifier ) + 1 ;
                }
                PPT_METHODTRACE_V2("","strLotIDInCasLen", strLotIDInCasLen) ;

                char*   strLotIDInCas = CORBA::string_alloc( strLotIDInCasLen + 1 ) ;
                strLotIDInCas[0] = '\0';

                for ( m = 0; m < lotsInCastLen; m++ )
                {
                    CIMFWStrCat( strLotIDInCas, (const char *)strStartCassette[i_Cas].strLotInCassette[m].lotID.identifier ) ;
                    CIMFWStrCat( strLotIDInCas, "," ) ;
                }
                strLotIDInCas[--strLotIDInCasLen] = '\0';
                PPT_METHODTRACE_V2("","Collected Lot ID", strLotIDInCas) ;

                nLen = strEventParameter.length() ;
                strEventParameter.length( nLen + 1 ) ;
                strEventParameter[nLen].parameterName  = CIMFWStrDup("LOT_ID") ;
                strEventParameter[nLen].parameterValue = strLotIDInCas ;
            }
        }
    }

    PPTEVENTLOG( retVal, &strObjCommonIn, &strEventParameter );
//D9000007 add end


    CREATE_TX_OBJ;

    TX_BEGIN(calendar_GetCurrentTimeDR);
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn) ;
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp ;
        strObjCommonIn.strUser.functionID = CIMFWStrDup( "TXTRC056" ) ;
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR);

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTServiceManager_i:: CS_TxStartLotsReservationForInternalBufferReq", "rc != RC_OK");//INN-R170014
        TX_ROLLBACK(calendar_GetCurrentTimeDR);
        retVal->strResult = strCalendar_GetCurrentTimeDR_out.strResult ;
        retVal->strResult.transactionID = CIMFWStrDup("TXTRC056") ;

//D9000007        CORBA::Long     nLen = strEventParameter.length() ;
//D9000007        strEventParameter.length( nLen + 1 ) ;
//D9000007        strEventParameter[nLen].parameterName = CIMFWStrDup("EQP_ID") ;
//D9000007        strEventParameter[nLen].parameterValue =  CIMFWStrDup( equipmentID.identifier ) ;
//D9000007        if ( strStartCassette.length() > 0 )
//D9000007        {
//D9000007            CORBA::Long                     strCassetteIDLen = 0 ;
//D9000007            CORBA::Long                     nLen = strEventParameter.length() ;
//P4200078  strEventParameter.length( nLen + 2 ) ;
//D9000007            strEventParameter.length( nLen + 1 ) ;    //P4200078
//D9000007            // Calculate the length of the string
//D9000007            for( CORBA::Long j=0; j<strStartCassette.length(); j++ )
//D9000007            {
//D9000007                strCassetteIDLen += CIMFWStrLen( strStartCassette[j].cassetteID.identifier ) + 1 ;
//D9000007            }

//D9000001            char*   strCassetteID = CORBA::string_alloc( strCassetteIDLen + 1 ) ;
//D9000007            char*   strCassetteID = CORBA::string_alloc( (CORBA::ULong) strCassetteIDLen + 1 ) ;       //D9000001
//D9000007            strCassetteID[0] = NULL ;
//D9000007            for( j=0; j<strStartCassette.length(); j++ )
//D9000007            {
//D9000007                CIMFWStrCat( strCassetteID, (const char *)strStartCassette[j].cassetteID.identifier ) ;
//D9000007                CIMFWStrCat( strCassetteID, "," ) ;
//D9000007            }
//D9000007            strEventParameter[nLen].parameterName = CIMFWStrDup("CAST_ID") ;
//D9000007            strEventParameter[nLen].parameterValue =  strCassetteID ;
//D9000007        }
//D9000007        eventLog_Put(strEventParameter,strObjCommonIn,retVal->strResult);
        return retVal ;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR);

    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummy;
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

//D4000013 add start
    /*-----------------------------------------------------------------------*/
    /*   abstract LotIDs for PrivilegeCheck                                  */
    /*-----------------------------------------------------------------------*/
    PPT_METHODTRACE_V1("","abstract lotIDs for PrivilegeCheck!!");

    objectIdentifierSequence lotIDs;
    CORBA::Long lotCounter = 0;
    CORBA::Long allLotLen = 500;
    lotIDs.length(allLotLen);

    CORBA::Long lenStartCassette = strStartCassette.length();
    PPT_METHODTRACE_V2("","StartCassette length ",lenStartCassette);

    for ( CORBA::Long i = 0 ; i < lenStartCassette ; i++ )
    {
        CORBA::Long lenLotInCassette = strStartCassette[i].strLotInCassette.length();
        PPT_METHODTRACE_V3("","StartCassette[i].lotInCassette length ", i , lenLotInCassette);

        for (CORBA::Long j = 0; j < lenLotInCassette ; j++ )
        {
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == TRUE)
            {
                if ( lotCounter >= allLotLen )
                {
                    allLotLen = allLotLen + 500;
                    lotIDs.length(allLotLen);
                }

                lotIDs[lotCounter] = strStartCassette[i].strLotInCassette[j].lotID;
                lotCounter++;
            }
        }
    }

    lotIDs.length(lotCounter);

    //LotIDs TRACE
    PPT_METHODTRACE_V1("","#### abstracted lotIDs Trace... ####");
    for (CORBA::Long k = 0; k < lotCounter ; k++ )
    {
        PPT_METHODTRACE_V3("","lot sequence ",k + 1,lotIDs[k].identifier);
    }
    PPT_METHODTRACE_V1("","####################################");

//D4000013 add end

    TX_BEGIN(txPrivilegeCheckReq);
    try
    {
//D4000013        rc = theCS_PPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult,strObjCommonIn,equipmentID,dummy,dummyIDs,dummyIDs,dummyIDs,dummyIDs);
        rc = theCS_PPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult,strObjCommonIn,equipmentID,dummy,dummyIDs,dummyIDs,lotIDs,dummyIDs);             //D4000013
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq);

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTServiceManager_i:: CS_TxStartLotsReservationForInternalBufferReq", "rc != RC_OK");//INN-R170014
        TX_ROLLBACK(txPrivilegeCheckReq);
        retVal->strResult = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup("TXTRC056") ;

//D9000007        CORBA::Long     nLen = strEventParameter.length() ;
//D9000007        strEventParameter.length( nLen + 1 ) ;
//D9000007        strEventParameter[nLen].parameterName = CIMFWStrDup("EQP_ID") ;
//D9000007        strEventParameter[nLen].parameterValue =  CIMFWStrDup( equipmentID.identifier ) ;
//D9000007        if ( strStartCassette.length() > 0 )
//D9000007        {
//D9000007            CORBA::Long                     strCassetteIDLen = 0 ;
//D9000007            CORBA::Long                     nLen = strEventParameter.length() ;
//P4200078  strEventParameter.length( nLen + 2 ) ;
//D9000007            strEventParameter.length( nLen + 1 ) ;    //P4200078
//D9000007            // Calculate the length of the string
//D9000007            for( CORBA::Long j=0; j<strStartCassette.length(); j++ )
//D9000007            {
//D9000007                strCassetteIDLen += CIMFWStrLen( strStartCassette[j].cassetteID.identifier ) + 1 ;
//D9000007            }

//D9000001            char*   strCassetteID = CORBA::string_alloc( strCassetteIDLen + 1 ) ;
//D9000007            char*   strCassetteID = CORBA::string_alloc( (CORBA::ULong) strCassetteIDLen + 1 ) ;       //D9000001
//D9000007            strCassetteID[0] = NULL ;
//D9000007            for( j=0; j<strStartCassette.length(); j++ )
//D9000007            {
//D9000007                CIMFWStrCat( strCassetteID, (const char *)strStartCassette[j].cassetteID.identifier ) ;
//D9000007                CIMFWStrCat( strCassetteID, "," ) ;
//D9000007            }
//D9000007            strEventParameter[nLen].parameterName = CIMFWStrDup("CAST_ID") ;
//D9000007            strEventParameter[nLen].parameterValue =  strCassetteID ;
//D9000007        }
//D9000007        eventLog_Put(strEventParameter,strObjCommonIn,retVal->strResult);
        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq);

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
//D7000228    char *APCIFControlStatus = NULL;            //D7000182
//D7000228    CORBA::String_var tmpAPCIFControlStatus;    //D7000182
    CORBA::String_var APCIFControlStatus;    //D7000228
    TX_BEGIN(cs_txStartLotsReservationForInternalBufferReq);//INN-R170014
    try
    {
        rc = theCS_PPTManager->cs_txStartLotsReservationForInternalBufferReq(*retVal, strObjCommonIn, equipmentID, 
                                                       controlJobID, strStartCassette, skipBatchSizeFlag,skipWaferCountFlag,//INN-R170014
//D7000182                                                       claimMemo);
//D7000228                                                       claimMemo, APCIFControlStatus);    //D7000182
                                                       claimMemo, (char*&)APCIFControlStatus);    //D7000228 //INN-R170014
//D7000228        tmpAPCIFControlStatus = APCIFControlStatus;    //D7000182
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(cs_txStartLotsReservationForInternalBufferReq); //INN-R170014
    if (rc == RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTServiceManager_i:: CS_TxStartLotsReservationForInternalBufferReq", "rc == RC_OK");//INN-R170014
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(cs_txStartLotsReservationForInternalBufferReq);//INN-R170014
    }
    else
    {
        PPT_METHODTRACE_V1("CS_PPTServiceManager_i:: CS_TxStartLotsReservationForInternalBufferReq", "rc != RC_OK");//INN-R170014
        TX_ROLLBACK(cs_txStartLotsReservationForInternalBufferReq);//INN-R170014
//D7000182 add start
        if( CIMFWStrLen(APCIFControlStatus) != 0 && CIMFWStrCmp(getenv(SP_Rollback_Notify_To_APC), "1") == 0 )
        {
            PPT_METHODTRACE_V2("", "Re-send ControlJobInformation to APC. notify status ->", APCIFControlStatus);
            CORBA::Long iRc = RC_OK;
            pptAPCControlJobInfoRptResult strAPCControlJobInfoRptResult;
            TX_BEGIN(txAPCControlJobInfoRpt);
            try
            {
                iRc = theCS_PPTManager->txAPCControlJobInfoRpt(strAPCControlJobInfoRptResult,
                                                            strObjCommonIn,
                                                            equipmentID,
                                                            controlJobID,
                                                            strStartCassette,
                                                            APCIFControlStatus);
            }
            CATCH_TX_TIMEOUT_EXCEPTIONS(txAPCControlJobInfoRpt);
            if( iRc == RC_OK || iRc == RC_OK_NO_IF )
            {
                PPT_METHODTRACE_V2("", "txAPCControlJobInfoRpt() == RC_OK or RC_OK_NO_IF", iRc);
                TX_COMMIT(txAPCControlJobInfoRpt);
            }
            else
            {
                PPT_METHODTRACE_V2("", "txAPCControlJobInfoRpt() != RC_OK", iRc);
                TX_ROLLBACK(txAPCControlJobInfoRpt);
            }
        }
//D7000182 add end
    }

//D51M0000 add start 
    //--------------------------------
    // Entity Inhibit                
    //--------------------------------
    PPT_METHODTRACE_V2("", "small Tx return error. rc:", rc);
    //-------------------------------------------
    //  Entity Inhibit enable check.            
    //  SP_INHIBIT_WHEN_APC_RPARMADJUST_NG      
    //       0 --> Inhibit disable              
    //       1 --> Inhibit enable               
    //-------------------------------------------
//D9000001    CORBA::Long envInhibitWhenAPC = atol(getenv(SP_INHIBIT_WHEN_APC_RPARMADJUST_NG));
    CORBA::Long envInhibitWhenAPC = atoi(getenv(SP_INHIBIT_WHEN_APC_RPARMADJUST_NG));    //D9000001
    if( envInhibitWhenAPC == 1 )
    {
        PPT_METHODTRACE_V1("", "SP_INHIBIT_WHEN_APC_RPARMADJUST_NG == 1 ");
        if( rc == RC_NO_RESPONSE_APC      ||
            rc == RC_APC_SERVER_BIND_FAIL ||
            rc == RC_APC_RUNTIMECAPABILITY_ERROR  ||
            rc == RC_APC_RECIPEPARAMETERREQ_ERROR ||
            rc == RC_APC_RETURN_DUPLICATE_PARAMETERNAME )
        {

            CORBA::String_var strClaimMemo = CIMFWStrDup("APC IF Error.");
            CORBA::Long saveRc = rc;

//D6000215  //--------------------------------
//D6000215  // Calculate EndTime for Inhibit  
//D6000215  //--------------------------------
//D6000215  objTimeStamp_DoCalculation_out      strTimeStamp_DoCalculation_out;
//D6000215  CORBA::String_var targetTimeStamp;
//D6000215
//D6000215  TX_BEGIN(timeStamp_DoCalculation);
//D6000215  try
//D6000215  {
//D6000215      CORBA::Long inhibitDuration          = atol(getenv(SP_INHIBIT_DURATION));
//D6000215      CORBA::String_var tmpReportTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);
//D6000215      rc = theCS_PPTManager->timeStamp_DoCalculation( strTimeStamp_DoCalculation_out,
//D6000215                                                   strObjCommonIn,
//D6000215                                                   tmpReportTimeStamp,
//D6000215                                                   inhibitDuration,
//D6000215                                                   0,0,0,0);
//D6000215  }
//D6000215  CATCH_TX_TIMEOUT_EXCEPTIONS(timeStamp_DoCalculation);
//D6000215
//D6000215  if ( rc == RC_OK )
//D6000215  {
//D6000215      PPT_METHODTRACE_V1("", "timeStamp_DoCalculation rc == RC_OK");
//D6000215      TX_COMMIT(timeStamp_DoCalculation);
//D6000215      targetTimeStamp = CIMFWStrDup(strTimeStamp_DoCalculation_out.targetTimeStamp);
//D6000215  }
//D6000215  else if ( rc != RC_OK )
//D6000215  {
//D6000215      PPT_METHODTRACE_V1("", "timeStamp_DoCalculation rc != RC_OK");
//D6000215      TX_ROLLBACK(timeStamp_DoCalculation);
//D6000215      targetTimeStamp = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
//D6000215  }

            //------------------------------------------- 
            // Inhibit Equipment for APC I/F Errors       
            //------------------------------------------- 
//DSIV00001365            TX_BEGIN(txEntityInhibitReq);
            TX_BEGIN(txEntityInhibitReq__101);    //DSIV00001365
            try
            {
//DSIV00001365                pptEntityInhibitAttributes strEntityInhibitions;
                pptEntityInhibitDetailAttributes strEntityInhibitions;    //DSIV00001365

                PPT_METHODTRACE_V2("CS_PPTServiceManager_i:: CS_TxStartLotsReservationForInternalBufferReq","equipment ID to inhibit req", equipmentID.identifier);//INN-R170014

                strEntityInhibitions.entities.length(1);
                strEntityInhibitions.entities[0].className           = CIMFWStrDup(SP_InhibitClassID_Equipment);
                strEntityInhibitions.entities[0].objectID            = equipmentID;
                strEntityInhibitions.entities[0].attrib              = CIMFWStrDup("");
                strEntityInhibitions.subLotTypes.length(0);
                strEntityInhibitions.startTimeStamp                  = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);
//D6000215      strEntityInhibitions.endTimeStamp                    = CIMFWStrDup(targetTimeStamp);

                if( saveRc == RC_NO_RESPONSE_APC ||
                    saveRc == RC_APC_SERVER_BIND_FAIL )
                {
                    strEntityInhibitions.reasonCode = CIMFWStrDup(SP_Reason_EntityInhibit_For_APCNoResponse);
                }
                else if( saveRc == RC_APC_RUNTIMECAPABILITY_ERROR ||
                         saveRc == RC_APC_RECIPEPARAMETERREQ_ERROR)
                {
                    strEntityInhibitions.reasonCode = CIMFWStrDup(SP_Reason_EntityInhibit_For_APCReturnCodeNG);
                }
                else if( saveRc == RC_APC_RETURN_DUPLICATE_PARAMETERNAME )
                {
                    strEntityInhibitions.reasonCode = CIMFWStrDup(SP_Reason_EntityInhibit_For_APCReturnValueError);
                }

                strEntityInhibitions.ownerID          = strObjCommonIn.strUser.userID;
                strEntityInhibitions.claimedTimeStamp = CIMFWStrDup("");

//DSIV00001365                pptEntityInhibitReqResult strEntityInhibitReqResult;
//DSIV00001365                rc = theCS_PPTManager->txEntityInhibitReq(strEntityInhibitReqResult,
//DSIV00001365                                                       strObjCommonIn, 
//DSIV00001365                                                       strEntityInhibitions, 
//DSIV00001365                                                       strClaimMemo);
//DSIV00001365            }
//DSIV00001365            CATCH_TX_TIMEOUT_EXCEPTIONS(txEntityInhibitReq);
//DSIV00001365            if (rc == RC_OK)
//DSIV00001365            {
//DSIV00001365                PPT_METHODTRACE_V1("", "txEntityInhibitReq returns RC_OK");
//DSIV00001365                TX_COMMIT(txEntityInhibitReq);
//DSIV00001365                rc = saveRc;
//DSIV00001365            }
//DSIV00001365            else
//DSIV00001365            {
//DSIV00001365                PPT_METHODTRACE_V2("", "txEntityInhibitReq returns Error.", rc);
//DSIV00001365                TX_ROLLBACK(txEntityInhibitReq);
//DSIV00001365            }
//DSIV00001365 add start
                pptEntityInhibitReqResult__101 strEntityInhibitReqResult;
                rc = theCS_PPTManager->txEntityInhibitReq__101(strEntityInhibitReqResult,
                                                            strObjCommonIn, 
                                                            strEntityInhibitions, 
                                                            strClaimMemo);
            }
            CATCH_TX_TIMEOUT_EXCEPTIONS(txEntityInhibitReq__101);
            if (rc == RC_OK)
            {
                PPT_METHODTRACE_V1("", "txEntityInhibitReq__101 returns RC_OK");
                TX_COMMIT(txEntityInhibitReq__101);
                rc = saveRc;
            }
            else
            {
                PPT_METHODTRACE_V2("", "txEntityInhibitReq__101 returns Error.", rc);
                TX_ROLLBACK(txEntityInhibitReq__101);
            }
//DSIV00001365 add end
        }
    }
//D51M0000 add end

    /*-----------------------------------------------------------------------*/
    /*   Post Process                                                        */
    /*-----------------------------------------------------------------------*/
    retVal->strResult.transactionID = CIMFWStrDup("TXTRC056") ;

//D9000007    CORBA::Long     nLen = strEventParameter.length() ;
//D9000007    strEventParameter.length( nLen + 1 ) ;
//D9000007    strEventParameter[nLen].parameterName = CIMFWStrDup("EQP_ID") ;
//D9000007    strEventParameter[nLen].parameterValue =  CIMFWStrDup( equipmentID.identifier ) ;
//D9000007    if ( strStartCassette.length() > 0 )
//D9000007    {
//D9000007        CORBA::Long                     strCassetteIDLen = 0 ;
//D9000007        CORBA::Long                     nLen = strEventParameter.length() ;
//P4200078        strEventParameter.length( nLen + 2 ) ;
//D9000007        strEventParameter.length( nLen + 1 ) ;    //P4200078
//D9000007        // Calculate the length of the string
//D9000007        for( CORBA::Long j=0; j<strStartCassette.length(); j++ )
//D9000007        {
//D9000007            strCassetteIDLen += CIMFWStrLen( strStartCassette[j].cassetteID.identifier ) + 1 ;
//D9000007        }

//D9000001        char*   strCassetteID = CORBA::string_alloc( strCassetteIDLen + 1 ) ;
//D9000007        char*   strCassetteID = CORBA::string_alloc( (CORBA::ULong) strCassetteIDLen + 1 ) ;       //D9000001
//D9000007        strCassetteID[0] = NULL ;
//D9000007        for( j=0; j<strStartCassette.length(); j++ )
//D9000007        {
//D9000007            CIMFWStrCat( strCassetteID, (const char *)strStartCassette[j].cassetteID.identifier ) ;
//D9000007            CIMFWStrCat( strCassetteID, "," ) ;
//D9000007        }
//D9000007        strEventParameter[nLen].parameterName = CIMFWStrDup("CAST_ID") ;
//D9000007        strEventParameter[nLen].parameterValue =  strCassetteID ;
//D9000007    }
//D9000007    eventLog_Put(strEventParameter,strObjCommonIn,retVal->strResult);

//D9000007 add start
    nLen = strEventParameter.length() ;
    strEventParameter.length( nLen + 1 ) ;
    strEventParameter[nLen].parameterName  = CIMFWStrDup("CONTROL_JOB_ID") ;
    strEventParameter[nLen].parameterValue = CIMFWStrDup( retVal->controlJobID.identifier ) ;
//D9000007 add end

    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i:: CS_TxStartLotsReservationForInternalBufferReq ");//INN-R170014
    PPT_PARMTRACE_VERBOSE1(*retVal);    //D4100014
    return retVal ;
}
