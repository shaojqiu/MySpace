// @(#) 1.3 superpos/src/csppt/source/posppt/svcmgr/cs_pptsm.hpp, mm_srv_5_0_cspp, mm_srv_5_0_cspp 6/9/03 14:05:15 [ 6/9/03 14:05:16 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView - PPT Service Manager
// Name: PPTSm.hpp
//
// ** Notice **
//   This is a sample code for customizing a PPT Manager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT Manager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//
// Change history:
//
// Date       Defect#   Person         Comments
// ---------- --------- -------------- -------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya      Initial Release for R5.0
// 09/15/04   D6000025 K.Murakami     BOAImpl was added in order to make it TIE to BOA. 
// 10/26/04   D6000025 K.Murakami     eBrokerMigration.
//      
//

#ifndef cs_pptsm_ih
#define cs_pptsm_ih

//#define CS_PPTSM_DECLSPEC CIMFW_DELLEXPORT

#include "pptsm.hpp"
#include "cs_pptsm.hh"
#include "cs_pptmgr.hh"
#include "cs_pptrc.h"
#include "cs_pptmsg.h"
#include "cs_posconst.hpp"
#include "cs_pptparmlog.hpp"
#include "cs_pptmacros.hpp"

#ifdef MO_BOA   //D6000025
class CS_PPTServiceManager_i : virtual public PPTServiceManager_i, virtual public CS_PPTServiceManagerBOAImpl  //D6000025
#else    //D6000025
class CS_PPTServiceManager_i : public PPTServiceManager_i
#endif   //D6000025
{
public:
                CS_PPTServiceManager_i();
                ~CS_PPTServiceManager_i();
//D6000025                void CS_PPTServiceManager_init (CORBA::Environment &IT_env = CORBA::default_environment) ;
                void CS_PPTServiceManager_init (CORBAENV_ONLY_HPP) ;  //D6000025
//D6000025                void CS_PPTServiceManager_uninit (CORBA::Environment &IT_env = CORBA::default_environment) ;
                void CS_PPTServiceManager_uninit (CORBAENV_ONLY_HPP) ;   //D6000025

protected:
                CS_PPTManager_var theCS_PPTManager;
public:
                #include "cs_pubmethd.hpp"
    };

#ifndef MO_BOA  //D6000025
DEF_TIE_CS_PPTServiceManager(CS_PPTServiceManager_i);
#endif   //D6000025

#endif
