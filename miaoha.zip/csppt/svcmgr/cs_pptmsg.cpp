// SCCS ID: %Z% %I% %W% %G% %U% [ %H% %T% ]
//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SuperPOSEIDON - CS_PPTServiceManager
// Name: CS_PPTMsg.cpp
//
// Change history:
//
// Date       Defect#        Person           Comments
// ---------- -----------    --------------   -------------------------------------------
// 2017/09/04 INN-R170003    JJ.Zhang         Initial release for innotron
//

#include <strstream.h>
#include <iostream.h>
#include <nl_types.h>
#include <string.h>
#include <stdio.h>
#include "cs_pptstr.hh"
#include "cs_pptmsg.h"
#include "cs_pptmsg.hpp"

#include "cs_pptmgr.hpp"

#define CS_SP_CATALOG_OPENERROR_MESSAGE     "The message catelog file could not be opened."
#define CS_SP_CATALOG_NOTSPECIFY_MESSAGE    "The message catalog file name is not specified. Set it as MM_CS_CATALOG_FILE."
#define CS_SP_CATALOG_NOTFOUND_MESSAGE      "The appropriate message could not be found."
#define CS_SP_CATALOG_MANYPARAMETER_MESSAGE "message truncated (many parameters specified) : "
#define CS_SP_CATALOG_LESSPARAMETER_MESSAGE "message truncated (less parameters specified) : "
#define CS_SP_CATALOG_OVERFLLOW_MESSAGE     "message truncated (length over fllow) : "
#define CS_SP_CATALOG_NULL_VALUE            "(NULL)"
#define CS_SP_CATALOG_NOPARAMETER_VALUE     "??"
#define CS_SP_CATALOG_NOMESSAGE_TEXT        ""
#define CS_SP_CATALOG_NOMESSAGE_ID          ""

#define CS_REASON_TEXT_LEN             3000

//---------------------------------------------------------------

char* cs_get_message_from_catalog(long msgid)
{
    //-------------------------------------------
    // getting message text from message catalog
    //-------------------------------------------
    char* pmsg = NULL;

    //-----------------------
    // openning catalog file
    //-----------------------
    nl_catd catd ;
    char* catfile = getenv("MM_CS_CATALOG_FILE");

    if ( catfile == NULL )
    {
        pmsg = strdup(CS_SP_CATALOG_NOTSPECIFY_MESSAGE);
        return pmsg;
    }
    
    catd = catopen(catfile, 0);
    
    if (catd == CATD_ERR)
    {
        //----------------
        // failed to open
        //----------------
        pmsg = strdup(CS_SP_CATALOG_OPENERROR_MESSAGE);
    }
    else
    {
        //-----------------------------------------------
        // openned catalog file and getting message text
        //-----------------------------------------------
        char* tmpmsg = NULL;
        tmpmsg = catgets(catd,MS_SET2,msgid,"CS_SP_CATALOG_NOTFOUND_MESSAGE");
        if ( tmpmsg != NULL )
        {
            pmsg = strdup(tmpmsg);
        }
        else
        {
            pmsg = strdup("");
        }
        //----------------------
        // closing catalog file
        //----------------------
        catclose(catd);
    }

    return pmsg;

}

//--------------------------------------------------------------

unsigned int cs_get_token_count(const char* msg, const char* token)
{
    char* p=NULL;
    unsigned int count=0;

    p = strstr(msg,token);
    while ( p != NULL )
    {
        ++count;
        p = strstr( p + CIMFWStrLen(token), token);
    }

    return count;
}

//--------------------------------------------------------------

void cs_set_message_and_returncode(pptRetCode* strResult, long msgid, long rc)
{
    //-------------------------------------------
    // setting return code into result structure
    //-------------------------------------------
    ostrstream strrc;
    strrc << rc << ends;
    strResult->returnCode  = strrc.str();

    //======================================================
    // do not freeze strstreambuf pointer
    // because it is passed to returnCode due to performance
    //======================================================

    //-------------------------------------------
    // getting message text from message catalog
    //-------------------------------------------
    char* pmsg = cs_get_message_from_catalog(msgid);

    //--------------------------------------------
    // setting message text into result structure
    //--------------------------------------------
    if ( pmsg != NULL )
    {
        //--------------------------
        // checking parameter count
        //--------------------------
        unsigned int pcount = cs_get_token_count(pmsg,"%s");

        ostrstream pmsgkey;

        if ( pcount == 0 )
        {
            pmsgkey << pmsg << ends;
        }
        else
        {
             pmsgkey << CS_SP_CATALOG_LESSPARAMETER_MESSAGE;
        }

        //--------------
        // checking key
        //--------------
        char *startpointer = NULL;
        char **savepointer = &startpointer;

        //----------------------------------
        // getting message to 1st parameter
        //----------------------------------
        char *token = strtok_r(pmsg,"%",savepointer);
        char *tokenBack = token;

        if (( token != NULL ) && ( pcount > 0 ))
        {
            pmsgkey << token;
            pmsgkey << CS_SP_CATALOG_NOPARAMETER_VALUE;

            //--------------------------
            // Fill ?? to remainning %x
            //--------------------------
            unsigned int i;
            for ( i = 1; i < pcount; i++ )
            {
                token = strtok_r(NULL,"%",savepointer);

                //---------------------------
                // %x is remainning
                //---------------------------
                if ( token != NULL )
                {
                    pmsgkey << token + 1;
                    pmsgkey << CS_SP_CATALOG_NOPARAMETER_VALUE;
                }
                else
                {
                    // Need not Logic. Because Looping %x counts.
                }
            }
            if ( token != NULL )
            {
                pmsgkey << token + CIMFWStrLen(token) + 2 << ends;
            }
            else
            {
                pmsgkey << ends;
            }
        }
        else
        {
             //-------------------------------------
             // %x is not exist on original message.
             //-------------------------------------
             pmsgkey << pmsg << ends;
        }

        //----------------------------
        // Judgement of Message Length
        //----------------------------
        unsigned int messageLen = CIMFWStrLen(pmsgkey.str());

        if ( messageLen > CS_REASON_TEXT_LEN - 1 )
        {
            char  tempMsg[CS_REASON_TEXT_LEN];
            memset( tempMsg, '\0', CS_REASON_TEXT_LEN );

            strncpy( tempMsg, pmsgkey.str() , CS_REASON_TEXT_LEN - 1 );

            strResult->messageText = strdup(tempMsg);
        }
        else
        {
            strResult->messageText = pmsgkey.str();
        }
    }
    else
    {
        strResult->messageText = strdup(CS_SP_CATALOG_NOMESSAGE_TEXT);
    }

    //--------------------------------------
    // getting message ID from message text
    //--------------------------------------
    char* pmsgid = NULL;

    //----------------------------------
    // getting message to 1st parameter
    //----------------------------------
    char* startpointer = NULL;
    char** savepointer = &startpointer;
    char* token = strtok_r(pmsg,":",savepointer);

    if ( token != NULL )
    { 
         pmsgid = strdup(token);
    }
    else
    {
         pmsgid = strdup(CS_SP_CATALOG_NOMESSAGE_ID);
    }

    //----------------------------------------
    // setting message ID in result structure
    //----------------------------------------
    strResult->messageID = pmsgid;

    //-----------
    // delete it
    //-----------
    delete pmsg;

}

//-------------------------------------------------------------------------------------------

void cs_set_message_and_returncode(pptRetCode *strResult, long msgid, long rc, const char* key1)
{
    //-------------------------------------------
    // setting return code into result structure
    //-------------------------------------------
    ostrstream strrc;
    strrc << rc << ends;
    strResult->returnCode  = strrc.str();

    //=======================================================
    // do not freeze strstreambuf pointer
    // because it is passed to returnCode due to performance
    //=======================================================

    //-------------------------------------------
    // getting message text from message catalog
    //-------------------------------------------
    char* pmsg = cs_get_message_from_catalog(msgid);

    //-------------------------------------
    // setting message with keys specified
    //-------------------------------------
    ostrstream pmsgkey;

    if ( pmsg != NULL )
    {
        //----------------------------------------------
        // checking parameter count in Original Message
        //----------------------------------------------
        unsigned int pcount = cs_get_token_count(pmsg,"%s");

        if ( pcount == 1 )
        {
            //----------------------------------------------
            // Key Information Null Check For Message Length
            //----------------------------------------------
            unsigned int key1Len = 0;
            if ( key1 != NULL )
            {
                key1Len = CIMFWStrLen(key1);
            } 

            if ( CIMFWStrLen(pmsg) + key1Len > CS_REASON_TEXT_LEN - 1 )
            {
                pmsgkey << CS_SP_CATALOG_OVERFLLOW_MESSAGE;
            }
        }

        if ( pcount < 1 )
        {
            pmsgkey << CS_SP_CATALOG_MANYPARAMETER_MESSAGE;
        }
        else if ( pcount > 1 )
        {
            pmsgkey << CS_SP_CATALOG_LESSPARAMETER_MESSAGE;
        }

        //--------------
        // checking key
        //--------------
        char *startpointer = NULL;
        char **savepointer = &startpointer;

        //----------------------------------
        // getting message to 1st parameter
        //----------------------------------
        char *token = strtok_r(pmsg,"%",savepointer);
        char *tokenBack = token;

        if (( token != NULL ) && ( pcount >= 1 ))
        {
            //-----------------------
            // setting 1st parameter
            //-----------------------
            pmsgkey << token;

            if ( key1 != NULL )
            {
                pmsgkey << key1;
            }
            else if ( key1 == NULL )
            {
                pmsgkey << CS_SP_CATALOG_NULL_VALUE;
            }

            //--------------------------
            // Fill ?? to remainning %x
            //--------------------------
            unsigned int i;
            for ( i = 1; i < pcount; i++ )
            {
                token = strtok_r(NULL,"%",savepointer);

                //---------------------------
                // %x is remainning
                //---------------------------
                if ( token != NULL )
                {
                    pmsgkey << token + 1;
                    pmsgkey << CS_SP_CATALOG_NOPARAMETER_VALUE;
                }
                else
                {
                    // Need not Logic. Because Looping %x counts. 
                }
            }

            // putting following message ( '.' represents NULL )
            //
            //   token            token+CIMFWStrLen(token)
            //   |                |
            //   V                V
            //  "001000E: The lot %s is not found." // before strtok 
            //  "001000E: The lot .s is not found." // after strtok
            //

            if ( token != NULL )
            {
                pmsgkey << token + CIMFWStrLen(token) + 2 << ends;
            }
            else
            {
                pmsgkey << ends;
            }
        }
        else
        {
             //-------------------------------------
             // %x is not exist on original message.
             //-------------------------------------
             pmsgkey << pmsg << ends;
        }

        //----------------------------
        // Judgement of Message Length
        //----------------------------
        unsigned int messageLen = CIMFWStrLen(pmsgkey.str());

        if ( messageLen > CS_REASON_TEXT_LEN - 1 )
        {
            char  tempMsg[CS_REASON_TEXT_LEN];
            memset( tempMsg, '\0', CS_REASON_TEXT_LEN );
 
            strncpy( tempMsg, pmsgkey.str() , CS_REASON_TEXT_LEN - 1 );

            //--------------------------------------------
            // setting message text into result structure
            //--------------------------------------------
            strResult->messageText = strdup(tempMsg);
        }
        else
        {
            //--------------------------------------------
            // setting message text into result structure
            //--------------------------------------------
            strResult->messageText = pmsgkey.str();
        }

        //=======================================================
        // do not freeze strstreambuf pointer
        // because it is passed to returnCode due to performance
        //=======================================================
    }
    else
    {
        strResult->messageText = strdup(CS_SP_CATALOG_NOMESSAGE_TEXT);
    }

    //--------------------------------------
    // getting message ID from message text
    //--------------------------------------
    char* pmsgid = NULL;

    //----------------------------------
    // getting message to 1st parameter
    //----------------------------------
    char *startpointer = NULL;
    char **savepointer = &startpointer;
    char *token = strtok_r(pmsg,":",savepointer);

    if ( token != NULL )
    {
         pmsgid = strdup(token);
    }
    else
    {
         pmsgid = strdup(CS_SP_CATALOG_NOMESSAGE_ID);
    }

    //----------------------------------------
    // setting message ID in result structure
    //----------------------------------------
    strResult->messageID = pmsgid;

    // delete it
    delete pmsg;

}

//-------------------------------------------------------------------------------------------------------------

void cs_set_message_and_returncode(pptRetCode *strResult, long msgid, long rc, const char* key1, const char *key2)
{
    //-------------------------------------------
    // setting return code into result structure
    //-------------------------------------------
    ostrstream strrc;
    strrc << rc << ends;
    strResult->returnCode  = strrc.str();

    //=======================================================
    // do not freeze strstreambuf pointer
    // because it is passed to returnCode due to performance
    //=======================================================

    //-------------------------------------------
    // getting message text from message catalog
    //-------------------------------------------
    char* pmsg = cs_get_message_from_catalog(msgid);

    //-------------------------------------
    // setting message with keys specified
    //-------------------------------------
    ostrstream pmsgkey;

    if ( pmsg != NULL )
    {
        //----------------------------------------------
        // checking parameter count in Original Message
        //----------------------------------------------
        unsigned int pcount = cs_get_token_count(pmsg,"%s");

        if ( pcount == 2 )
        {
            //----------------------------------------------
            // Key Information Null Check For Message Length
            //----------------------------------------------
            unsigned int key1Len = 0;
            if ( key1 != NULL )
            {
                key1Len = CIMFWStrLen(key1);
            }

            unsigned int key2Len = 0;
            if ( key2 != NULL )
            {
                key2Len = CIMFWStrLen(key2);
            }

            if ( CIMFWStrLen(pmsg) + key1Len + key2Len > CS_REASON_TEXT_LEN - 1 )
            {
                pmsgkey << CS_SP_CATALOG_OVERFLLOW_MESSAGE;
            }
        }

        if ( pcount < 2 )
        {
            pmsgkey << CS_SP_CATALOG_MANYPARAMETER_MESSAGE;
        }
        else if ( pcount > 2 )
        {
            pmsgkey << CS_SP_CATALOG_LESSPARAMETER_MESSAGE;
        }

        //--------------
        // checking key
        //--------------
        char *startpointer = NULL;
        char **savepointer = &startpointer;

        //----------------------------------
        // getting message to 1st parameter
        //----------------------------------
        char *token = strtok_r(pmsg,"%",savepointer);
        char *tokenBack = token;

        if (( token != NULL ) && ( pcount >= 1 ))
        {
             //-----------------------
             // setting 1st parameter
             //-----------------------
             pmsgkey << token;

             if ( key1 != NULL )
             {
                 pmsgkey << key1; 
             }
             else if ( key1 == NULL )
             {
                 pmsgkey << CS_SP_CATALOG_NULL_VALUE;
             }

             //----------------------------------
             // getting message to 2nd parameter
             //----------------------------------
             tokenBack = token;
             token = strtok_r(NULL,"%",savepointer);

             if (( token != NULL ) && ( pcount >= 2 ))
             {
                 pmsgkey << token + 1;

                 if ( key2 != NULL ) 
                 {
                     pmsgkey << key2;
                 }
                 else if ( key2 == NULL )
                 {
                     pmsgkey << CS_SP_CATALOG_NULL_VALUE;
                 }

                 // putting following message ( '.' represents NULL )
                 //
                 //                     token     token+CIMFWStrLen(token)
                 //                     |         |
                 //                     V         V
                 //  "001000E: The lot %s in foup %s is not found." // before strtok
                 //  "001000E: The lot .s in foup .s is not found." // after strtok
                 //

                 //--------------------------
                 // Fill ?? to remainning %x
                 //--------------------------
                 unsigned int i;
                 for ( i = 2; i < pcount; i++ )
                 {
                     tokenBack = token;
                     token = strtok_r(NULL,"%",savepointer);

                     //---------------------------
                     // %x is remainning
                     //---------------------------
                     if ( token != NULL )
                     {
                         pmsgkey << token + 1;
                         pmsgkey << CS_SP_CATALOG_NOPARAMETER_VALUE;
                     }
                     else
                     {
                         // Need not Logic. Because Looping %x counts. 
                     }
                 }
                 if ( token != NULL )
                 {
                     pmsgkey << token + CIMFWStrLen(token) + 2 << ends;
                 }
                 else
                 {
                     pmsgkey << ends;
                 }
             }
             else
             {
                 pmsgkey << tokenBack + CIMFWStrLen(tokenBack) + 2 << ends;
             }
        }
        else
        {
             pmsgkey << pmsg << ends;
        }

        //----------------------------
        // Judgement of Message Length
        //----------------------------
        unsigned int messageLen = CIMFWStrLen(pmsgkey.str());

        if ( messageLen > CS_REASON_TEXT_LEN - 1 )
        {
            char  tempMsg[CS_REASON_TEXT_LEN];
            memset( tempMsg, '\0', CS_REASON_TEXT_LEN );

            strncpy( tempMsg, pmsgkey.str() , CS_REASON_TEXT_LEN - 1 );

            //--------------------------------------------
            // setting message text into result structure
            //--------------------------------------------
            strResult->messageText = strdup(tempMsg);
        }
        else
        {
            //--------------------------------------------
            // setting message text into result structure
            //--------------------------------------------
            strResult->messageText = pmsgkey.str();
        }

        //=======================================================
        // do not freeze strstreambuf pointer
        // because it is passed to returnCode due to performance
        //=======================================================
    }
    else
    {
        strResult->messageText = strdup(CS_SP_CATALOG_NOMESSAGE_TEXT);
    }

    //--------------------------------------
    // getting message ID from message text
    //--------------------------------------
    char* pmsgid = NULL;

    //----------------------------------
    // getting message to 1st parameter
    //----------------------------------
    char *startpointer = NULL;
    char **savepointer = &startpointer;
    char *token = strtok_r(pmsg,":",savepointer);

    if ( token != NULL )
    {
         pmsgid = strdup(token);
    }
    else
    {
         pmsgid = strdup(CS_SP_CATALOG_NOMESSAGE_ID);
    }

//  char* tokenpointer = strchr(pmsgkey.str(),':');
//  if ( tokenpointer != NULL )
//  {
//       //   pmsg   tokenpointer                  pmsgid
//       //   |      |                             |
//       //   V      V                     copy    V
//       //  "001002E:Lot is not found."  ------> "001002E"
//       //
//       unsigned int tokensize = (unsigned int)tokenpointer-(unsigned int)pmsgkey.str();
//       pmsgid = new char[tokensize+1];
//       strncpy(pmsgid, pmsgkey.str(), tokensize);
//       pmsgid[tokensize] = NULL;
//  }
//  else
//  {
//       pmsgid = strdup(CS_SP_CATALOG_NOMESSAGE_ID);
//  }

    //----------------------------------------
    // setting message ID in result structure
    //----------------------------------------
    strResult->messageID = pmsgid;

    //-----------
    // delete it
    //-----------
    delete pmsg;

}

//------------------------------------------------------------------------------------------------

void cs_set_message_and_returncode(pptRetCode *strResult, long msgid, long rc, const char* key1, const char* key2, const char* key3)
{
    //-------------------------------------------
    // setting return code into result structure
    //-------------------------------------------
    ostrstream strrc;
    strrc << rc << ends;
    strResult->returnCode  = strrc.str();

    //========================================================
    // do not freeze strstreambuf pointer
    // because it is passed to returnCode due to performance
    //========================================================

    //-------------------------------------------
    // getting message text from message catalog
    //-------------------------------------------
    char* pmsg = cs_get_message_from_catalog(msgid);

    //-------------------------------------
    // setting message with keys specified
    //-------------------------------------
    ostrstream pmsgkey;

    if ( pmsg != NULL )
    {
        //--------------------------
        // checking parameter count
        //--------------------------
        unsigned int pcount = cs_get_token_count(pmsg,"%s");

        if ( pcount == 3 )
        {
            //----------------------------------------------
            // Key Information Null Check For Message Length
            //----------------------------------------------
            unsigned int key1Len = 0;
            if ( key1 != NULL )
            {
                key1Len = CIMFWStrLen(key1);
            }

            unsigned int key2Len = 0;
            if ( key2 != NULL )
            {
                key2Len = CIMFWStrLen(key2);
            }

            unsigned int key3Len = 0;
            if ( key3 != NULL )
            {
                key3Len = CIMFWStrLen(key3);
            }

            if ( CIMFWStrLen(pmsg) + key1Len + key2Len + key3Len > CS_REASON_TEXT_LEN - 1 )
            {
                pmsgkey << CS_SP_CATALOG_OVERFLLOW_MESSAGE;
            }
        }

        if ( pcount < 3 )
        {
            pmsgkey << CS_SP_CATALOG_MANYPARAMETER_MESSAGE;
        }
        else if ( pcount > 3 )
        {
            pmsgkey << CS_SP_CATALOG_LESSPARAMETER_MESSAGE;
        }

        //--------------
        // checking key
        //--------------
        char *startpointer = NULL;
        char **savepointer = &startpointer;

        // getting message to 1st parameter
        char *token = strtok_r(pmsg,"%",savepointer);
        char *tokenBack = token;

        if (( token != NULL ) && ( pcount >= 1 ))
        {
            //-----------------------
            // setting 1st parameter
            //-----------------------
            pmsgkey << token;
            if ( key1 != NULL )
            {
                 pmsgkey << key1;
            }
            else if ( key1 == NULL )
            {
                 pmsgkey << CS_SP_CATALOG_NULL_VALUE ;
            }

            //----------------------------------
            // getting message to 2nd parameter
            //-----------------------------------
            tokenBack = token;
            token = strtok_r(NULL,"%",savepointer);

            //-----------------------
            // setting 2nd parameter
            //-----------------------
            if (( token != NULL ) && ( pcount >= 2 ))
            {
                pmsgkey << token+1;

                if ( key2 != NULL )
                {
                    pmsgkey << key2;
                }
                else if ( key2 == NULL )
                {
                    pmsgkey << CS_SP_CATALOG_NULL_VALUE ;
                }

                //----------------------------------
                // getting message to 3rd parameter
                //----------------------------------
                tokenBack = token;
                token = strtok_r(NULL,"%",savepointer);

                //-----------------------
                // setting 3rd parameter
                //-----------------------
                if (( token != NULL )  && ( pcount >= 3 ))
                {
                    pmsgkey << token+1;
                    if ( key3 != NULL )
                    {
                        pmsgkey << key3;
                    }
                    else if ( key3 == NULL )
                    {
                        pmsgkey << CS_SP_CATALOG_NULL_VALUE ;
                    }
                     
                    // putting following message ( '.' represents NULL )
                    //                                token             token+CIMFWStrLen(token)
                    //                                |                 |
                    //                                V                 V
                    //  "001000E: The lot %s in foup %s is not found in %s." // before strtok
                    //  "001000E: The lot .s in foup .s is not found in .s." // after strtok
                    //

                    //--------------------------
                    // Fill ?? to remainning %x
                    //--------------------------
                    unsigned int i;
                    for ( i = 3; i < pcount; i++ )
                    {
                        token = strtok_r(NULL,"%",savepointer);

                        //---------------------------
                        // %x is remainning
                        //---------------------------
                        if ( token != NULL )
                        {
                            pmsgkey << token + 1;
                            pmsgkey << CS_SP_CATALOG_NOPARAMETER_VALUE;
                        }
                        else
                        {
                            // Need not Logic. Because Looping %x counts. 
                        }
                    }

                    if ( token != NULL )
                    {
                        pmsgkey << token + CIMFWStrLen(token) + 2 << ends;
                    }
                    else
                    {
                        pmsgkey << ends;
                    }
                }
                else
                {
                    pmsgkey << tokenBack + CIMFWStrLen(tokenBack) + 2 << ends;
                }
            }
            else
            {
                pmsgkey << tokenBack + CIMFWStrLen(tokenBack) + 2 << ends;
            }
        }
        else
        {
             pmsgkey << pmsg << ends;
        }

        //----------------------------
        // Judgement of Message Length
        //----------------------------
        unsigned int messageLen = CIMFWStrLen(pmsgkey.str());

        if ( messageLen > CS_REASON_TEXT_LEN - 1 )
        {
            char  tempMsg[CS_REASON_TEXT_LEN];
            memset( tempMsg, '\0', CS_REASON_TEXT_LEN );
 
            strncpy( tempMsg, pmsgkey.str() , CS_REASON_TEXT_LEN - 1 );

            //--------------------------------------------
            // setting message text into result structure
            //--------------------------------------------
            strResult->messageText = strdup(tempMsg);
        }
        else
        {
            //--------------------------------------------
            // setting message text into result structure
            //--------------------------------------------
            strResult->messageText = pmsgkey.str();
        }

        // do not freeze strstreambuf pointer because it is passed to returnCode due to performance

    }
    else
    {
        strResult->messageText = strdup(CS_SP_CATALOG_NOMESSAGE_TEXT);
    }

    //--------------------------------------
    // getting message ID from message text
    //--------------------------------------
    char* pmsgid = NULL;

    // getting message to 1st parameter
    char *startpointer = NULL;
    char **savepointer = &startpointer;
    char *token = strtok_r(pmsg,":",savepointer);

    if ( token != NULL )
    {
         pmsgid = strdup(token);
    }
    else
    {
         pmsgid = strdup(CS_SP_CATALOG_NOMESSAGE_ID);
    }

    //----------------------------------------
    // setting message ID in result structure
    //----------------------------------------
    strResult->messageID = pmsgid;

    //-----------
    // delete it
    //-----------
    delete pmsg;

}

//----------------------------------------------------------------------------------------------------

void cs_set_message_and_returncode(pptRetCode *strResult, long msgid, long rc, const char* key1, const char* key2, const char* key3, const char* key4)
{
    //-------------------------------------------
    // setting return code into result structure
    //-------------------------------------------
    ostrstream strrc;
    strrc << rc << ends;
    strResult->returnCode  = strrc.str();

    //========================================================
    // do not freeze strstreambuf pointer
    // because it is passed to returnCode due to performance
    //========================================================

    //-------------------------------------------
    // getting message text from message catalog
    //-------------------------------------------
    char* pmsg = cs_get_message_from_catalog(msgid);

    //-------------------------------------
    // setting message with keys specified
    //-------------------------------------
    ostrstream pmsgkey;

    if ( pmsg != NULL )
    {
        //--------------------------
        // checking parameter count
        //--------------------------
        unsigned int pcount = cs_get_token_count(pmsg,"%s");

        if ( pcount == 4 )
        {
            //----------------------------------------------
            // Key Information Null Check For Message Length
            //----------------------------------------------
            unsigned int key1Len = 0;
            if ( key1 != NULL )
            {
                key1Len = CIMFWStrLen(key1);
            }

            unsigned int key2Len = 0;
            if ( key2 != NULL )
            {
                key2Len = CIMFWStrLen(key2);
            }
            
            unsigned int key3Len = 0;
            if ( key3 != NULL )
            {
                key3Len = CIMFWStrLen(key3);
            }
            
            unsigned int key4Len = 0;
            if ( key4 != NULL )
            {
                key4Len = CIMFWStrLen(key4);
            }

            if ( CIMFWStrLen(pmsg) + key1Len + key2Len + key3Len + key4Len > CS_REASON_TEXT_LEN - 1 )
            {
                pmsgkey << CS_SP_CATALOG_OVERFLLOW_MESSAGE;
            }
        }

        if ( pcount < 4 )
        {
            pmsgkey << CS_SP_CATALOG_MANYPARAMETER_MESSAGE;
        }
        else if ( pcount > 4 )
        {
            pmsgkey << CS_SP_CATALOG_LESSPARAMETER_MESSAGE;
        }

        //--------------
        // checking key
        //--------------
        char *startpointer = NULL;
        char **savepointer = &startpointer;

        // getting message to 1st parameter
        char *token = strtok_r(pmsg,"%",savepointer);
        char *tokenBack = token;

        if (( token != NULL ) && ( pcount >= 1 ))
        {
            //-----------------------
            // setting 1st parameter
            //-----------------------
            pmsgkey << token;
            if ( key1 != NULL )
            {
                 pmsgkey << key1;
            }
            else if ( key1 == NULL )
            {
                 pmsgkey << CS_SP_CATALOG_NULL_VALUE ;
            }

            //----------------------------------
            // getting message to 2nd parameter
            //-----------------------------------
            tokenBack = token;
            token = strtok_r(NULL,"%",savepointer);

            //-----------------------
            // setting 2nd parameter
            //-----------------------
            if (( token != NULL ) && ( pcount >= 2 ))
            {
                pmsgkey << token+1;

                if ( key2 != NULL )
                {
                    pmsgkey << key2;
                }
                else if ( key2 == NULL )
                {
                    pmsgkey << CS_SP_CATALOG_NULL_VALUE ;
                }

                //----------------------------------
                // getting message to 3rd parameter
                //----------------------------------
                tokenBack = token;
                token = strtok_r(NULL,"%",savepointer);

                //-----------------------
                // setting 3rd parameter
                //-----------------------
                if (( token != NULL )  && ( pcount >= 3 ))
                {
                     pmsgkey << token+1;
                    if ( key3 != NULL )
                    {
                        pmsgkey << key3;
                    }
                    else if ( key3 == NULL )
                    {
                        pmsgkey << CS_SP_CATALOG_NULL_VALUE ;
                    }
                     
                    //----------------------------------
                    // getting message to 4th parameter
                    //----------------------------------
                    tokenBack = token;
                    token = strtok_r(NULL,"%",savepointer);

                    //-----------------------
                    // setting 4th parameter
                    //-----------------------
                    if (( token != NULL )  && ( pcount >= 4 ))
                    {
                        pmsgkey << token+1;
                        if ( key4 != NULL )
                        {
                            pmsgkey << key4;
                        }
                        else if ( key4 == NULL )
                        {
                            pmsgkey << CS_SP_CATALOG_NULL_VALUE ;
                        }

                        // putting following message ( '.' represents NULL )
                        //                                token             token+CIMFWStrLen(token)
                        //                                |                 |
                        //                                V                 V
                        //  "001000E: The lot %s in foup %s is not found in %s." // before strtok
                        //  "001000E: The lot .s in foup .s is not found in .s." // after strtok
                        //

                        //--------------------------
                        // Fill ?? to remainning %x
                        //--------------------------
                        unsigned int i;
                        for ( i = 4; i < pcount; i++ )
                        {
                            tokenBack = token;
                            token = strtok_r(NULL,"%",savepointer);

                            //---------------------------
                            // %x is remainning
                            //---------------------------
                            if ( token != NULL )
                            {
                                pmsgkey << token + 1;
                                pmsgkey << CS_SP_CATALOG_NOPARAMETER_VALUE;
                            }
                            else
                            {
                                // Need not Logic. Because Looping %x counts. 
                            }
                        }

                        if ( token != NULL )
                        {
                            pmsgkey << token + CIMFWStrLen(token) + 2 << ends;
                        }
                        else
                        {
                             pmsgkey << ends;
                        }
                    }
                    else
                    {
                        pmsgkey << tokenBack + CIMFWStrLen(tokenBack) + 2 << ends;
                    }
                }
                else
                {
                    pmsgkey << tokenBack + CIMFWStrLen(tokenBack) + 2 << ends;
                }
            }
            else
            {
                pmsgkey << tokenBack + CIMFWStrLen(tokenBack) + 2 << ends;
            }
        }
        else
        {
             pmsgkey << pmsg << ends;
        }

        //----------------------------
        // Judgement of Message Length
        //----------------------------
        unsigned int messageLen = CIMFWStrLen(pmsgkey.str());

        if ( messageLen > CS_REASON_TEXT_LEN - 1 )
        {
            char  tempMsg[CS_REASON_TEXT_LEN];
            memset( tempMsg, '\0', CS_REASON_TEXT_LEN );
 
            strncpy( tempMsg, pmsgkey.str() , CS_REASON_TEXT_LEN - 1 );

            //--------------------------------------------
            // setting message text into result structure
            //--------------------------------------------
            strResult->messageText = strdup(tempMsg);
        }
        else
        {
            //--------------------------------------------
            // setting message text into result structure
            //--------------------------------------------
            strResult->messageText = pmsgkey.str();
        }

        // do not freeze strstreambuf pointer because it is passed to returnCode due to performance

    }
    else
    {
        strResult->messageText = strdup(CS_SP_CATALOG_NOMESSAGE_TEXT);
    }

    //--------------------------------------
    // getting message ID from message text
    //--------------------------------------
    char* pmsgid = NULL;

    // getting message to 1st parameter
    char *startpointer = NULL;
    char **savepointer = &startpointer;
    char *token = strtok_r(pmsg,":",savepointer);

    if ( token != NULL )
    {
         pmsgid = strdup(token);
    }
    else
    {
         pmsgid = strdup(CS_SP_CATALOG_NOMESSAGE_ID);
    }

    //----------------------------------------
    // setting message ID in result structure
    //----------------------------------------
    strResult->messageID = pmsgid;

    //-----------
    // delete it
    //-----------
    delete pmsg;

}
