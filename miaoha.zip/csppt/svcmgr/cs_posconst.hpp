//  @(#) 1.3 superpos/src/csppt/source/posppt/svcmgr/cs_posconst.hpp, mm_srv_5_0_cspp, mm_srv_5_0_cspp 6/9/03 14:02:06 [ 6/9/03 14:02:07 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
//
// SiView         : MMS
// File Name      : cs_posconst.hpp
// Description    : Constant values declaration for CSCLASS
//
// ** Notice **
// This is a sample code for customizing a PPT ServiceManager.
// IBM desn't ensure  the behaviour in all cases and all situations.
// If you customize PPT ServiceManager using this examples from this code,
// you have to ensure the behavior of your code through your test process.
//
// Modification History :
//
// Date       Defect      Name             Description
// ---------- --------    ---------------- ----------------------------------------------
// 2003/06/09 D5000014    C.Tsuchiya       Initial Release for R5.0
//
// Innotron Modification history :
// Date       Defect#     Person           Comments
// ---------- --------    --------------   -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang       INN-A170001:RMS enabling
// 2017/08/31 INN-R170002 YangXigang       Add for contamination customization for innotron
// 2017/09/14 INN-R170003 Nick Tsai        Add for Durable Management Enhancement
// 2017/09/12 INN-R170008 Menghua Yin      Add TA Certify info
// 2017/09/12 INN-R170006 YangXigang       For fixture
// 2017/09/18 INN-R170009 Gary Ke          Add for APC Litho
// 2017/09/18 INN-R170014 shenql           Add for Durable Management Enhancement
// 2017/09/25 INN-R170009 LiuXinxin        Add for Litho APC
// 2017/09/29 INN-R170003 Joan Zhou        INN-R170003: Add for new cassette user data
// 2017/10/17 INN-R170017 Cheng Li         Add for Bare Wafer Stocker
// 2017/10/17 INN-R170009 Gary Ke          Add for APC Litho
// 2017/10/18 INN-R170003 Joan Zhou        Durable Management Enhancement
// 2017/10/19 INN-R170027 Vera Chen        NPW Product Change
// 2017/10/20 INN-R170016 JQ.Shao          NPW Management Initial Release
// 2017/10/23 INN-R17000901 Gary Ke        Add for Lot Photo Layer Get
// 2017/10/24 INN_R170009 Qufd             Add APC Queue
// 2017/10/25 INN-R170017 Wang Fang        Add for BWS
// 2017/10/30 INN-R170085 Jun Zhang        Equipment status for PM
// 2017/10/31 INN-R170020 liu Xinxin       Add for new SPC actioncode
// 2017/11/03 INN-R170017 Wang Fang        Add CS_Reason_BWS_Hold,CS_Reason_BWS_HoldRelease

#ifndef _CS_POSCONST_HPP_
#define _CS_POSCONST_HPP_

#include <posconst.hpp>

//INN-A170001 Add Start
#define CS_UDATA_TYPE_STRING                        (const char*)"String"
#define CS_SP_BindEverytime_RMS                     (const char *) "CS_SP_BindEverytime_RMS"
#define CS_SP_RMS_SERVER_NAME                       (const char *) "RMS_SERVER_NAME"
#define CS_SP_RMS_MARKER_NAME                       (const char *) "RMS_MARKER_NAME"
#define CS_SP_RMS_HOST_NAME                         (const char *) "RMS_HOST_NAME"
#define CS_SP_BIND_SLEEP_TIME_RMS                   (const char *) "CS_SP_BIND_SLEEP_TIME_RMS"
#define CS_SP_BIND_RETRY_COUNT_RMS                  (const char *) "CS_SP_BIND_RETRY_COUNT_RMS"
#define CS_SP_TX_TIMEOUT_RMS                        (const char *) "CS_SP_TX_TIMEOUT_RMS"
#define CS_SP_RMS_CHECK_ONLINE_FLAG                 (const char *) "CS_SP_RMS_CHECK_ONLINE_FLAG"
#define CS_SP_DEFAULT_RETRY_COUNT_RMS               5
#define CS_SP_DEFAULT_SLEEP_TIME_RMS                1
#define CS_M_RMS_BODY_FLAG                          (const char *) "M_EQP_BodyAuditFlag"
#define CS_M_RECIPEBODYCONFIRM_FLAG                 (const char *) "M_MRCP_AuditFlag"
#define CS_M_RMS_CONST_FLAG                         (const char *) "M_EQP_ConstantAuditFlag"
#define CS_RMS_IGNOREAUDIT_EQPLIST                  (const char *) "CS_RMS_IGNOREAUDIT_EQPLIST"
//INN-A170001 Add End

//INN-R170003 Add Start
#define CS_SP_DRBL_STATE_NOTAVAILABLE               (const char *) "NOTAVAILABLE"
#define CS_SP_DRBL_STATE_INUSE                      (const char *) "INUSE"
//INN-R170003 Add End

//INN-R170002 Add Start
#define CS_S_MAINPD_OpeContamiInLevel               (const char*)"S_MAINPD_OpeContamiInLevel"
#define CS_S_MAINPD_OpeContamiOutLevel              (const char*)"S_MAINPD_OpeContamiOutLevel"
#define CS_S_MAINPD_OpePRControl                    (const char*)"S_MAINPD_OpePRControl"
#define CS_S_PROD_CarrierUsageType                  (const char*)"S_PROD_CarrierUsageType"
#define CS_S_EQP_PRControl                          (const char*)"S_EQP_PRControl"
#define CS_M_LOT_Contamination_Flag                 (const char*)"M_LOT_Contamination_Flag"
#define CS_M_LOT_PR_Flag                            (const char*)"M_LOT_PR_Flag"
#define CS_M_LOT_PR_Flag_Yes                        (const char*)"Yes"
#define CS_M_LOT_PR_Flag_No                         (const char*)"No"
#define CS_M_CAST_UsageType                         (const char*)"M_CAST_UsageType"
#define CS_PRControl_Action_IgnorePR                (const char*)"IgnorePR"
#define CS_PRControl_Action_AvoidPR                 (const char*)"AvoidPR"
#define CS_PRControl_Action_SetPR                   (const char*)"SetPR"
#define CS_PRControl_Action_RemovePR                (const char*)"RemovePR"
#define CS_ContaminationLevel_NoCheck               (const char*)"NoCheck"
#define CS_CarrierCategory_NoCheck                  (const char*)"NoCheck"
#define CS_CarrierUsageType_Production              (const char*)"Production"
#define CS_CarrierUsageType_NonProduction           (const char*)"Non-Production"
#define CS_SP_Reason_ContaminationMismatchHold      (const char*)"CCMH"
//INN-R170002 Add End

//INN-R170003 Add Start
#define CS_S_MAINPD_OPE_FOUP_CLEAN_FLAG                 (const char *)"S_MAINPD_OpeFOUPCleanFlag"
#define CS_S_MAINPD_DURABLE_FLOW_TYPE                   (const char *)"S_MAINPD_DurableFlowType"

#define CS_M_CAST_LAST_INSPECTION_TIME                  (const char *)"M_CAST_LastInspTime"
#define CS_M_CAST_LAST_PM_TIME                          (const char *)"M_CAST_LastPMTime"

#define CS_M_RTCL_LAST_REPAIR_TIME                      (const char *)"M_RTCL_LastRepairTime"
#define CS_M_RTCL_LAST_INSPECTION_TIME                  (const char *)"M_RTCL_LastInspTime"
#define CS_M_RTCL_USED_WAFER_COUNT                      (const char *)"M_RTCL_UsedWaferCount"
#define CS_M_RTCL_EQUIPMENTIN_TIME                      (const char *)"M_RTCL_EquipmentInTime"
#define CS_M_RTCL_EQUIPMENTOUT_TIME                      (const char *)"M_RTCL_EquipmentOutTime"

#define CS_FOUP_DURABLE_SUB_STATE_FRESH                 (const char *)"FOUP_Fresh"
#define CS_FOUP_DURABLE_SUB_STATE_WAITINSP              (const char *)"FOUP_WaitInsp"
#define CS_FOUP_DURABLE_SUB_STATE_WAITVISCHK            (const char *)"FOUP_WaitVisChk"
#define CS_FOUP_DURABLE_SUB_STATE_WAITCLEAN             (const char *)"FOUP_WaitClean"
#define CS_FOUP_DURABLE_SUB_STATE_WAITUSE               (const char *)"FOUP_WaitUse"
#define CS_FOUP_DURABLE_SUB_STATE_SCRAP                 (const char *)"FOUP_Scrap"
#define CS_FOUP_DURABLE_SUB_STATE_HOLD                  (const char *)"FOUP_Hold"
#define CS_FOUP_DURABLE_SUB_STATE_FULLINUSE             (const char *)"FOUP_FullInUse"
#define CS_FOUP_DURABLE_SUB_STATE_PARTIALINUSE          (const char *)"FOUP_PartialInUse"

#define CS_RETICLE_DURABLE_SUB_STATE_IDLE               (const char *)"RTCL_Idle"
#define CS_RETICLE_DURABLE_SUB_STATE_EQIN               (const char *)"RTCL_EqIn"
#define CS_RETICLE_DURABLE_SUB_STATE_BUFFERI            (const char *)"RTCL_BufferIn"
#define CS_RETICLE_DURABLE_SUB_STATE_RUN                (const char *)"RTCL_Run"
#define CS_RETICLE_DURABLE_SUB_STATE_HOLD               (const char *)"RTCL_Hold"
#define CS_RETICLE_DURABLE_SUB_STATE_INSPDIE            (const char *)"RTCL_InspDie"
#define CS_RETICLE_DURABLE_SUB_STATE_WAITREPAIR         (const char *)"RTCL_WaitRepair"
#define CS_RETICLE_DURABLE_SUB_STATE_SCRAP              (const char *)"RTCL_Scrap"
#define CS_RETICLE_DURABLE_SUB_STATE_SCRAPOUT           (const char *)"RTCL_ScrapOut"

#define CS_RETICLEPOD_DURABLE_SUB_STATE_INUSE           (const char *)"RPOD_InUse"
#define CS_RETICLEPOD_DURABLE_SUB_STATE_WAITUSE         (const char *)"RPOD_WaitUse"
#define CS_RETICLEPOD_DURABLE_SUB_STATE_WAITCLEAN       (const char *)"RPOD_WaitClean"
#define CS_RETICLEPOD_DURABLE_SUB_STATE_HOLD            (const char *)"RPOD_Hold"
#define CS_RETICLEPOD_DURABLE_SUB_STATE_WAITINSP        (const char *)"RPOD_WaitInsp"
#define CS_RETICLEPOD_DURABLE_SUB_STATE_CLEAN           (const char *)"RPOD_Clean"
#define CS_RETICLEPOD_DURABLE_SUB_STATE_SCRAP           (const char *)"RPOD_Scrap"

#define CS_DURABLE_EVENT_ACTION_USED_DURATION_RESET     (const char *)"USEDDURATIONRESET"
#define CS_DURABLE_EVENT_ACTION_WAFER_COUNT_RESET       (const char *)"WAFERCOUNTRESET"
#define CS_DURABLE_EVENT_ACTION_INSPECTION_RESET        (const char *)"INSPECTIONRESET"
#define CS_DURABLE_EVENT_ACTION_PM_RESET                (const char *)"PMRESET"

#define CS_DURABLE_FLOW_TYPE_FOUP_CLEAN                 (const char *)"FOUP_Clean"
#define CS_DURABLE_FLOW_TYPE_FOUP_INSPECTION            (const char *)"FOUP_Inspection"

#define CS_TRANS_STATE_PORT_IN                          (const char *)"PI"
#define CS_TRANS_STATE_PORT_OUT                         (const char *)"PO"

#define CS_SP_DURABLE_FLOW_TYPE_FOUP_INSPECTION         (const char*)"FOUP_Inspection"
#define CS_SP_DURABLE_FLOW_TYPE_FOUP_CLEAN              (const char*)"FOUP_Clean"
//INN-R170003 Add End

//INN-R170008 Add Start
#define CS_TACERTIFY_SKILL_EXP_DURATION             (const char*)"CS_TACERTIFY_SKILL_EXP_DURATION"
#define CS_TACERTIFY_PRE_ALARM_DURATION             (const char*)"CS_TACERTIFY_PRE_ALARM_DURATION"
#define CS_S_USER_CERTIFICATION_REQURIED            (const char*)"S_USER_CertificationRequried"
#define CS_S_EQPTYPE_REQUIREDSKILL_1                (const char*)"S_EQPTYPE_RequiredSkill_1"
#define CS_S_EQPTYPE_REQUIREDSKILL_2                (const char*)"S_EQPTYPE_RequiredSkill_2"
#define CS_S_EQPTYPE_REQUIREDSKILL_3                (const char*)"S_EQPTYPE_RequiredSkill_3"
#define CS_S_EQPTYPE_REQUIREDSKILL_4                (const char*)"S_EQPTYPE_RequiredSkill_4"
#define CS_S_EQPTYPE_REQUIREDSKILL_5                (const char*)"S_EQPTYPE_RequiredSkill_5"
#define CS_COMMON_YES                               (const char*)"Yes"
#define CS_COMMON_NO                                (const char*)"No"
#define CS_ACTION_CODE_INSERT_UPDATE                (const char*)"Insert_Update"
#define CS_ACTION_CODE_DELETE                       (const char*)"Delete"
#define CS_USER_DEFINED_CATEGORY_SKILL              (const char*)"Skill"
//INN-R170008 Add End

//INN-R170006 Add Start
#define CS_M_Fixture_CumulativeTouchCount           (const char*)"M_DRBL_CumulativeTouchCount"
#define CS_M_WAFER_FixtureTouchCount                (const char*)"M_WFR_FixtureTouchCount"
//INN-R170006 Add End

//INN-R170009 Add Start
#define CS_S_MAINPD_OPE_APC_COMBINE_FLAG       (const char*)"S_MAINPD_OpeAPCLithoCombineFlag"
#define CS_M_EQP_LITHO_ITM_FLAG                (const char*)"M_EQP_LithoITMFlag"
#define CS_M_EQP_LITHO_ITM_LAYER_FLAG          (const char*)"M_EQP_LithoITMLayerFlag"
#define CS_M_WAFER_FIRST_LITHO_USED_CHUCK      (const char*)"M_WAFER_FirstLithoUsedChuck"

#define CS_APC_COMBINE_FLAG_ACTION_RESV_RECOMMEND   (const char *)"Reservation_Recommend"
#define CS_APC_COMBINE_FLAG_ACTION_OPST_RECOMMEND   (const char *)"OpeStart_Recommend"
#define CS_APC_COMBINE_FLAG_ACTION_USED             (const char *)"Used"
#define CS_APC_COMBINE_FLAG_ACTION_METROLOGY        (const char *)"Metrology"
#define CS_APC_CONTROLJOB_TYPE_LITHO_RECOMMEND      (const char *)"LITHORECOMMEND"
#define CS_APC_CONTROLJOB_TYPE_OL_METROLOGY         (const char *)"OLMET"
#define CS_APC_CONTROLJOB_TYPE_CD_METROLOGY         (const char *)"CDMET"
#define CS_APC_INPUT_VALUE_UNUSED                   (const char *)"UNUSED"
#define CS_COMPLICATED_HOLD_ACTION_IMMEDIATE_HOLD   (const char *)"ImmediateHold"
#define CS_COMPLICATED_HOLD_ACTION_FUTURE_HOLD      (const char *)"FutureHold"
//INN-R170009 Add End

//INN-R170014 Add Start
#define CS_S_MAINPD_OPE_WETBATCHSIZE            (const char*)"S_MAINPD_OpeWetBatchSize"
#define CS_S_MAINPD_OPE_WETMINWAFERCOUNT        (const char*)"S_MAINPD_OpeWetMinWaferCount"
//INN-R170014 Add End

//INN-R170017 Add Start
#define CS_BWS_ConfigAction_Add         (const char*)"Add"
#define CS_BWS_ConfigAction_Delete      (const char*)"Delete"
#define CS_BWS_ConfigAction_Update      (const char*)"Update"
#define CS_S_BANK_BWSList               (const char*)"S_BANK_BWSList"
#define CS_S_EQP_BWSUsageType           (const char*)"S_EQP_BWSUsageType"
//INN-R170017 Add End

//INN-R170009 Add Start by Qufd
#define CS_APC_EVENT_USED                    (const char*)"UsedEvent"
#define CS_APC_EVENT_METROLOGY               (const char*)"MetrologyEvent"
#define CS_APC_EVENT_ACTION_OPE_COMP         (const char*)"OpeComp"
#define CS_APC_EVENT_ACTION_DATA_COLLECTION  (const char*)"DataCollection"
//INN-R170009 Add End by Qufd

//INN-R170019 Add Start
//#define CS_APC_LITHO_ITM_FLAG_TYPE_L           (const char*)"CS_APC_LITHO_ITM_FLAG_TYPE_L"
//#define CS_APC_INQUIRE_TYPE_OFF                (const char*)"CS_APC_INQUIRE_TYPE_OFF"
//#define CS_APC_INQUIRE_TYPE_L2L                (const char*)"CS_APC_INQUIRE_TYPE_L2L"
//INN-R170019 Add End

//INN-R170013 Add Start
#define CS_YESNOFLAG_YES   "Yes"
#define CS_YESNOFLAG_NO    "No"
//INN-R170013 Add End
//INN-R170027 Add start
#define CS_ProductCategory_NonProduction            (const char *)"Non-Production"
#define CS_ProductCategory_Production               (const char *)"Production"
#define CS_Reason_NPW_ProductChange_Hold            (const char *)"NPCH"
//INN-R170027 Add end

//INN-R170016 Add start
#define CS_EqpMonitor_NPW_Type_PreProcess           (const char*)"PreProcess"
#define CS_EqpMonitor_NPW_Type_Monitor              (const char*)"Monitor"
#define CS_EqpMonitor_NPW_Type_Recycle              (const char*)"Recycle"

#define CS_M_LOT_Monitor_PrepID                     (const char*)"M_LOT_Monitor_PrepID"
#define CS_M_WFR_Downgrade_Product                  (const char*)"M_WFR_DowngradeProduct"
#define CS_M_WFR_Downgrade_BankID                   (const char*)"M_WFR_Downgrade_BankID"
#define CS_M_WFR_Monitor_Grade                      (const char*)"M_WFR_Monitor_Grade"
#define CS_M_EQPM_LastPrepDate                      (const char*)"M_EQPM_LastPrepDate"
#define CS_M_EQPM_LastPrepSeqNo                     (const char*)"M_EQPM_LastPrepSeqNo"
#define CS_SP_CAPACITY_INCREMENT_500                500
#define CS_SP_DowngradeProduct_Prefix_Length        (const char*)"CS_SP_DOWNGRADEPRODUCT_PREFIX_LEN"
//INN-R170016 Add end

// INN-R170009-01 Add Start
#define CS_S_PHOTO_FIRST_LAYER                  (const char*)"S_PHOTO_FirstLayer"
#define CS_M_WAFER_FIRST_LITHO_USED_CHUCK       (const char*)"M_WAFER_FirstLithoUsedChuck"
#define CS_CHAMBER_CHUCK                        (const char*)"CHUCK"
// INN-R170009-01 Add End

//INN-R170017 Add Start
#define CS_WaferTransfer_BWSIn                           (const char*)"BWSIn"
#define CS_WaferTransfer_BWSOut                          (const char*)"BWSOut"
#define CS_EQP_SpecialEquipmentControl_BareWaferStocker  (const char*)"Bare Wafer Stocker"
#define CS_M_EQP_BWS_SORTERJOB                           (const char*)"M_EQP_BWS_SorterJob"
#define CS_Reason_BWS_Hold                               (const char*)"BWSH"
#define CS_Reason_BWS_HoldRelease                        (const char*)"BWSR"
//INN-R170017 Add End

//INN-R170085 Add start
#define CS_EQP_STATUS_RUNOUT_PM                  (const char*)"RUNOUT-PM"
#define CS_EQP_STATUS_WAIT_PM                    (const char*)"WAIT-PM"
#define CS_EQP_STATUS_IDLE                       (const char*)"IDLE"
//INN-R170085 Add end

//INN-R170020 Add Start
#define CS_SP_ActionCode_ProductHold              (const char *)"Inhibit-Product"
#define CS_SP_ActionCode_ReticleHold              (const char *)"Inhibit-Reticle"
#define CS_SP_ActionCode_ReticleGroupHold         (const char *)"Inhibit-Reticle Group"
#define CS_SP_ActionCode_ModuleHold               (const char *)"Inhibit-Module Def"
#define CS_SP_ActionCode_RouteOpeNoProductHold    (const char *)"Inhibit-Route Ope No and Product"
#define CS_SP_ActionCode_EqptOpeNoHold            (const char *)"Inhibit-Equipment and Ope No "
#define CS_SP_ActionCode_EqptReticleHold          (const char *)"Inhibit-Equipment and Reticle"
#define CS_SP_ActionCode_EqptProcessHold          (const char *)"Equipment and Process Hold"
#define CS_SP_ActionCode_EqptChamberRecipeHold    (const char *)"Equipment and Chamber and Recipe Hold"
#define CS_SP_ActionCode_EqptProductRecipeHold    (const char *)"Equipment and Product and Recipe Hold"
#define CS_SP_ActionCode_RouteOpeNoHold           (const char *)"Route and Ope No Hold"
#define CS_SP_ActionCode_EqptChamberHold          (const char *)"Equipment and Chamber Hold"
//INN-R170020 Add End
#endif
