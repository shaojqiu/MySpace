#ifndef lint
static char *sccsid =  "@(#) 1.2 superpos/src/csppt/source/posppt/svcmgr/cs_pptsm.cpp, mm_srv_90e_cspp, mm_srv_90e_cspp 1/10/08 15:43:06 [ 1/10/08 15:43:07 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SuperPOSEIDON - CS_PPTServiceManager
// Name: cs_pptsm.cpp
//
// ** Notice **
//   This is a sample code for customizing a PPT Manager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT Manager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//
// Change history:
//
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya      Initial Release for R5.0
// 2004/10/26 D6000025 K.Murakami      eBrokerMigration.
// 2005/06/13 D6000354 K.Murakami      follow up for eBroker.
// 2008/01/10 P9000165 M.Ishino        add a code to the constructor for free memory of "theServiceManagerName".
//

#include "cs_pptsm.hpp"
#include "cs_pptmgrof.hh"
#include "diagnose.hpp"
#include "parseini.hpp"
#include "pptenv.hpp"

#include "nl_types.h"

// Macro : CATCH_EXCEPTION_AND_THROW_FRAMEWORK_EXCEPTION
//
// Description :
//    Catchs all exceptions and throws Framework Error signal Ex.
//

#define CATCH_EXCEPTION_AND_THROW_FRAMEWORK_EXCEPTION(WhereOnWhat)\
catch( const CORBA::SystemException& ex)\
{\
    APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(ex);\
    throw  ;\
}\
catch( const CORBA::UserException& uex)\
{\
    APPERRLOG_USEREXCEPTION_FOR_PUREOBJ(uex);\
    throw ;\
}\
catch(...)\
{\
    APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ();\
    throw ;\
}


#define START_TRANSACTION(method)\
try\
{\
	CosTransactions::Current::begin();\
}\
CATCH_EXCEPTION_AND_THROW_FRAMEWORK_EXCEPTION( method )


#define COMMIT_TRANSACTION(method)\
try\
{ \
	CosTransactions::Current::commit();\
} \
CATCH_EXCEPTION_AND_THROW_FRAMEWORK_EXCEPTION( method )


#define COMMIT_ROLLBACK(method)\
try\
{ \
	CosTransactions::Current::rollback();\
} \
CATCH_EXCEPTION_AND_THROW_FRAMEWORK_EXCEPTION( method )


// Class: CS_PPTServiceManager
//
// Service: CS_PPTServiceManager_i()
//
// Change history:
// Date     Defect#  Person         Comments
// -------- -------- -------------- -------------------------------------------
// 01/10/08 P9000165 M.Ishino        add a code to the constructor for free memory of "theServiceManagerName".
//
// Description:
//     Constructor
//
// Return:
//
// Parameter:
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//
CS_PPTServiceManager_i::CS_PPTServiceManager_i()
{
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i::CS_PPTServiceManager_i");

    // P9000165 add start
    // The memory assigned by the constructor of PPTServiceManager_i is freed.
    CORBA::string_free(theServiceManagerName);
    // P9000165 add end

    theServiceManagerName = CIMFWStrDup("CS_PPTServiceManager");

    // Get PPT related environment variable
    //
    PPTEnv::initialize();

    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i::CS_PPTServiceManager_i");
}

// Class: CS_PPTServiceManager
//
// Service: ~CS_PPTServiceManager_i()
//
// Change history:
// Date     Defect#  Person         Comments
// -------- -------- -------------- -------------------------------------------
//
// Description:
//     Destructor
//
// Return:
//
// Parameter:
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//
CS_PPTServiceManager_i::~CS_PPTServiceManager_i()
{
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i::~CS_PPTServiceManager_i");
    CS_PPTServiceManager_uninit() ;
    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i::~CS_PPTServiceManager_i");
}

// Class: CS_PPTServiceManager
//
// Service: CS_PPTServiceManager_init()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2004/10/26 D6000025 K.Murakami     eBrokerMigration.
// 2005/06/13 D6000354 K.Murakami     follow up for eBroker.
//
// Description:
//     Initialization
//
// Return:
//
// Parameter:
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//
//D6000025void CS_PPTServiceManager_i::CS_PPTServiceManager_init(CORBA::Environment &IT_env)
void CS_PPTServiceManager_i::CS_PPTServiceManager_init(CORBAENV_ONLY_CPP)   //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i::CS_PPTServiceManager_init");

    START_TRANSACTION(CS_PPTServiceManager_init)

      char* strTxTimeout =  getenv(SP_TRANSACTION_TIMEOUT);  
      if ( strTxTimeout == NULL )
      {
          theTxTimeout = 0;
      }
      else
      {
          theTxTimeout = atol(strTxTimeout);
      }

      // set Global Timeout for lock        // D9900004
      char* strLockTimeout =  getenv(SP_LOCK_TIMEOUT);    
      if ( strLockTimeout == NULL )
      {
          theLockTimeout =  0; // try to lock once
  //      theLockTimeout = -1; // try to lock indefinitely
      }
      else
      {
          theLockTimeout = atol(strLockTimeout);
      }



    CS_PPTManagerObjectFactory_var aCS_PPTManagerObjectFactory ;
    try
    {
//      aPPTManagerObjectFactory = PPTManagerObjectFactory::_bind(aServerName,HostName) ; // D9900159
#ifdef EBROKER                                                                                                                               //D6000354 
        SP_GET_OBJECT(aCS_PPTManagerObjectFactory, PPTManagerObjectFactoryServerName, PPTManagerObjectFactoryHostName, CS_PPTManagerObjectFactory) //D6000354
#else                                                                                                                                        //D6000354
        aCS_PPTManagerObjectFactory = CS_PPTManagerObjectFactory::_bind(PPTManagerObjectFactoryServerName,PPTManagerObjectFactoryHostName) ; // D9900159
#endif                                                                                                                                       //D6000354
    }
    CATCH_EXCEPTION_AND_THROW_FRAMEWORK_EXCEPTION(CS_PPTServiceManager_init : PPTManagerObjectFactory::_bind)
    PPT_TRACE_THREAD_INFO
    try
    {
        thePPTManager = aCS_PPTManagerObjectFactory->createPPTManager() ;
    }
    CATCH_EXCEPTION_AND_THROW_FRAMEWORK_EXCEPTION(CS_PPTServiceManager_init : createPPTManager);

    if(CORBA::is_nil(thePPTManager))
    {
       PPT_TRACE_THREAD_INFO
    }
    else
    {
       theCS_PPTManager = CS_PPTManager::_narrow(thePPTManager); 
       //For debug
          if(CORBA::is_nil(theCS_PPTManager))
          {
             PPT_TRACE_THREAD_INFO
             cout << "CS_PPTManager is Nil" << endl;
          }
    }
    PPT_TRACE_THREAD_INFO
    COMMIT_TRANSACTION(PPTServiceManager_init)
    PPT_TRACE_THREAD_INFO

    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i::CS_PPTServiceManager_init");
}
// Class: CS_PPTServiceManager
//
// Service: CS_PPTServiceManager_uninit()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2004/10/26 D6000025 K.Murakami     eBrokerMigration.
//
// Description:
//     Un-Initialize
//
// Return:
//
// Parameter:
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//
//D6000025void CS_PPTServiceManager_i::CS_PPTServiceManager_uninit(CORBA::Environment &IT_env)
void CS_PPTServiceManager_i::CS_PPTServiceManager_uninit(CORBAENV_ONLY_CPP)    //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i::CS_PPTServiceManager_uninit");
    CORBA::string_free(theServiceManagerName);
    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i::CS_PPTServiceManager_uninit");
}
