// SCCS ID: %Z% %I% %W% %G% %U% [ %H% %T% ]
//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2017 rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView - CS PPT Service Manager
// Name:cs_ pptmsg.hpp
//
// Change history:
//
// Date       Defect#        Person           Comments
// ---------- -----------    --------------   -------------------------------------------
// 2017/09/04 INN-R170003    JJ.Zhang         Initial release for innotron
//

#include "cs_pptstr.hh"

void cs_set_message_and_returncode(pptRetCode* strResult, long msgid, long rc);
void cs_set_message_and_returncode(pptRetCode* strResult, long msgid, long rc, const char* key1);
void cs_set_message_and_returncode(pptRetCode* strResult, long msgid, long rc, const char* key1, const char* key2);
void cs_set_message_and_returncode(pptRetCode* strResult, long msgid, long rc, const char* key1, const char* key2, const char* key3);
void cs_set_message_and_returncode(pptRetCode* strResult, long msgid, long rc, const char* key1, const char* key2, const char* key3, const char* key4);
