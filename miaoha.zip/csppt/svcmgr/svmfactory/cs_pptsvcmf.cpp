// @(#) 1.4 superpos/src/csppt/source/posppt/svcmgr/svmfactory/cs_pptsvcmf.cpp, mm_srv_5_0_cspp, mm_srv_5_0_cspp 6/9/03 14:08:05 [ 6/9/03 14:08:06 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// File : cs_pptsvcmf.cpp
// Description : Implementation of Customized PPT ServiceManagerObjectFactory
//
// ** Notice **
//   This is a sample code for customizing a PPT ServiceManager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT ServiceManager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//
//
// Modeficaiton History:
// Date       Defect   Name             Description
// ---------- -------- ---------------- ----------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya      Initial Release for R5.0
// 2004/10/26 D6000025 K.Murakami      TIE was deleted in order to make it TIE to BOA.
//                                     eBrokerMigration.
//


#include "cs_pptsvcmf.hpp"
#include "cs_pptsm.hpp"

CS_PPTServiceManagerObjectFactory_i:: CS_PPTServiceManagerObjectFactory_i()
{ 
    thePPTServiceManager = CS_PPTServiceManager::_nil();
}

CS_PPTServiceManagerObjectFactory_i:: ~CS_PPTServiceManagerObjectFactory_i()
{
}

//D6000025void CS_PPTServiceManagerObjectFactory_i:: CS_PPTServiceManagerObjectFactory_init (CORBA::Environment &IT_env)  {
void CS_PPTServiceManagerObjectFactory_i:: CS_PPTServiceManagerObjectFactory_init (CORBAENV_ONLY_CPP)  {  //D6000025
}

//D6000025void CS_PPTServiceManagerObjectFactory_i:: CS_PPTServiceManagerObjectFactory_uninit (CORBA::Environment &IT_env)  {
void CS_PPTServiceManagerObjectFactory_i:: CS_PPTServiceManagerObjectFactory_uninit (CORBAENV_ONLY_CPP)  {  //D6000025
}

//D6000025PPTServiceManager_ptr CS_PPTServiceManagerObjectFactory_i:: createPPTServiceManager (CORBA::Environment &IT_env)
PPTServiceManager_ptr CS_PPTServiceManagerObjectFactory_i:: createPPTServiceManager (CORBAENV_ONLY_CPP)   //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManagerObjectFactory_i::createPPTServiceManager")
    PPTServiceManager_ptr retVal = PPTServiceManager::_nil();
    try
    {
        if(!CORBA::is_nil(thePPTServiceManager))
        {
            PPT_METHODTRACE_V1("CS_PPTServiceManagerObjectFactory_i::createPPTServiceManager", "Returning Existing PPTServiceManager")
            retVal = PPTServiceManager::_duplicate(thePPTServiceManager);
            return retVal;
        }

        PPT_METHODTRACE_V1("CS_PPTServiceManagerObjectFactory_i::createPPTServiceManager", "About To create Tie object of PPTServiceManager")
        try
        {
#ifdef MO_BOA    //D6000025
            retVal = new CS_PPTServiceManager_i();  //D6000025
#else     //D6000025
            CS_PPTServiceManager_i * aCS_PPTSvcMgr_i = new CS_PPTServiceManager_i();
            PPT_METHODTRACE_V1("CS_PPTServiceManagerObjectFactory_i::createPPTServiceManager", "new CS_PPTServiceManager_i()")

            retVal = new TIE_CS_PPTServiceManager(CS_PPTServiceManager_i)(aCS_PPTSvcMgr_i);
#endif    //D6000025
            if(CORBA::is_nil(retVal))
            {
                FrameworkErrorSignal fwes ;
                fwes.errorInformation <<= "Narrrow Failed While Creating PPT Service Manager" ;
                throw fwes;
            }
        }
        catch( const CORBA::UserException& uex)
        {
            PPT_METHODTRACE_V1("CS_PPTServiceManagerObjectFactory_i::createPPTServiceManager", "CORBA::SystemException raised while newing PPTServiceManager_i")
            FrameworkErrorSignal fwes ;
            fwes.errorInformation <<= "CORBA::UserException While Creating PPT Service Manager" ;
            throw fwes;
        }
		catch( const CORBA::SystemException& ex)
		{
            PPT_METHODTRACE_V1("CS_PPTServiceManagerObjectFactory_i::createPPTServiceManager", "CORBA::SystemException raised while newing PPTServiceManager_i")
			throw ;
		}
        catch(...)
        {
            PPT_METHODTRACE_V1("CS_PPTServiceManagerObjectFactory_i::createPPTServiceManager", "Unknown Exception raised while PPTServiceManager_init")
            throw ;
        }

        try
		{
			CS_PPTServiceManager_ptr csMgr;
			csMgr = CS_PPTServiceManager::_narrow(retVal);
			csMgr->CS_PPTServiceManager_init();
		}
        catch( const CORBA::UserException& uex)
        {
            PPT_METHODTRACE_V1("CS_PPTServiceManagerObjectFactory_i::createPPTServiceManager", "CORBA::UserException raised while PPTServiceManager_init")
            FrameworkErrorSignal fwes ;
            fwes.errorInformation <<= "CORBA::UserException While Creating PPT Service Manager" ;
            throw fwes;
        }
		catch( const CORBA::SystemException& ex)
		{
            PPT_METHODTRACE_V1("CS_PPTServiceManagerObjectFactory_i::createPPTServiceManager", "CORBA::SystemException raised while PPTServiceManager_init")
			throw ;
		}
        catch(...)
        {
            PPT_METHODTRACE_V1("CS_PPTServiceManagerObjectFactory_i::createPPTServiceManager", "Unknown Exception raised while PPTServiceManager_init")
            throw ;
        }

        thePPTServiceManager = PPTServiceManager::_duplicate(retVal);

        PPT_METHODTRACE_V1("CS_PPTServiceManagerObjectFactory_i::createPPTServiceManager", "Successful Creation of PPTServiceManager and returning")
        return retVal ;
    }
    catch( const CORBA::UserException& uex)
    {
        PPT_METHODTRACE_V1("CS_PPTServiceManagerObjectFactory_i::createPPTServiceManager", "CORBA::UserException Raised in Global Catch")
        FrameworkErrorSignal fwes ;
        fwes.errorInformation <<= "UnKnown UserException Raised" ;
        throw fwes ;
    }
    catch( const CORBA::SystemException& ex)
    {
        PPT_METHODTRACE_V1("CS_PPTServiceManagerObjectFactory_i::createPPTServiceManager", "CORBA::SystemException Raised in Global Catch")
        throw ;
    }
    catch(...)
    {
        PPT_METHODTRACE_V1("CS_PPTServiceManagerObjectFactory_i::createPPTServiceManager", "Unknown Exception Raised in Global Catch")
        throw ;
    }
    PPT_METHODTRACE_EXIT("CS_PPTServiceManagerObjectFactory_i::createPPTServiceManager")

}


