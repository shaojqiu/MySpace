################################################################################
#
# Orb Utility Set - Source Maker
#     (C) COPYRIGHT International Business Machines Corp. 1992,2010
#     (C) COPYRIGHT: IBM Japan Services Company Ltd, 2010
#     All Rights Reserved
#     Licensed Materials - Property of IBM
#
#     US Government User Restricted Rights - Use, duplication
#     or disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
#
# File Name:
#	AnalyzeTypedef.pl
#
# Description:
#	Analyze Type Definiton
#
# Histroy:
#	Date		No.			Person			Comments
#	----------- ----------- --------------- ------------------------------------
#	1999/05/19	0.00		T.Kataoka		Initial
#	1999/11/15	0.01		T.Kataoka		Apply enum
#	2000/05/01	0.02		T.Kataoka		Apply user define exception
#	2000/08/29	0.03		T.Kataoka		Apply Orbix 3.0
#   2010/08/04  SIV00002292 S.Yamamoto      Fix : missing definition of sequence.
#   2011/03/16  SIV00003059 S.Yamamoto      Add code for avoid duplicate error.
#
################################################################################

$debugAnalyzeTypedef = 0;		# debug mode

#
# $stateComment		: state of comment
#	$out			: outprocess for comment
#	$in				: searching asterisk-slash
#
# $stateTypedef
#	$out			: outprocess for typedef
#	$type			: searching type
#	$name			: searching name
#	$end			: searching semi-colon
#
# $stateStruct		: state of struct
#	$out			: outprocess for struct
#	$name			: searching name
#	$start			: searching left brace
#	$in				: inprocess for struct
#	$end			: searching semi-colon
#
# $stateMember		: state of struct
#	$out			: outprocess for member
#	$type			: searching type
#	$name			: searching name
#	$end			: searching semi-colon
#
# $stateSequence	: state of sequence
#	$out			: outprocess for sequence
#	$start			: searching left comparison
#	$type			: searching type
#	$end			: searching right comparison
#
# $stateException	: state of exception
#	$out			: outprocess for exception
#	$name			: searching name
#	$start			: searching left brace
#	$in				: inprocess for exception
#	$end			: searching semi-colon
#
# $stateEnum		: state of enum
#	$out			: outprocess for exception
#	$name			: searching name
#	$start			: searching left brace
#	$in				: searching right brace
#
# $out		= 0		: outprocess
# $in		= 1		: inprocess
# $start	= 2		: searching start
# $end		= 3		: searching end
# $name		= 4		: searching name
# $type		= 5		: searching type
#
# %typedefStruct	: typedef hash list for struct
# %typedefSequence	: typedef hash list for sequence
# $typedefKind		: typedef type kind
# $typedefType		: typedef original type
# $typedefName		: typedef alias name
#
# @structList		: defined struct list
# $structName		: struct name
#
# @sequenceList		: defined sequence list
# $sequenceType		: sequence name
#
# @memberList		: member name list
# $memberKind		: member type kind
# $memberType		: member type
# $memberName		: member name
#

$out				= 0;
$in					= 1;
$start				= 2;
$end				= 3;
$name				= 4;
$type				= 5;

$stateComment		= $out;
$stateTypedef		= $out;
$stateStruct		= $out;
$stateMember		= $out;
$stateSequence		= $out;
$stateException		= $out;
$stateEnum			= $out;

$kindNone			= 0;
$kindStruct			= 1;
$kindSequence		= 2;
$kindOther			= 3;

%typedefStruct		= ();
%typedefSequence	= ();
$typedefKind		= "";
$typedefType		= "";
$typedefName		= "";

@structList			= ();
$structName			= "";

@sequenceList		= ();
$sequenceType		= "";

@enumList			= ();
$enumName			= "";

@memberList			= ();
$memberKind			= "";
$memberType			= "";
$memberName			= "";

@exceptionList		= ();
$exceptionName		= "";

# analyze each line
while(<>)
{
	$line = $_;
	chop $line;

	# ignore emply line
	if( $line eq "" )
	{
		next;
	}

	# delete comment
	$newLine = "";
	while( 1 )
	{
		if( $stateComment == $in )
		{
			# search asterisk-slash
			$indexAsteriskSlash = index( $line, "*/" );
			if( $indexAsteriskSlash < 0 )
			{
				last;
			}
			$stateComment = $out;
			$line = substr( $line, $indexAsteriskSlash + 2 );
		}

		# search slash-slash or slash-asterisk
		$indexSlashSlash = index( $line, "//" );
		$indexSlashAsterisk = index( $line, "/*" );
		if( $indexSlashSlash < 0 && $indexSlashAsterisk < 0 )
		{
			$newLine = $newLine . $line;
			last;
		}
		elsif( $indexSlashSlash >= 0 &&
			( $indexSlashAsterisk < 0 || $indexSlashSlash < $indexSlashAsterisk ) )
		{
			$newLine = $newLine . substr( $line, 0, $indexSlashSlash );
			last;
		}
		elsif( $indexSlashAsterisk >= 0 )
		{
			$newLine = $newLine . substr( $line, 0, $indexSlashAsterisk );
			$stateComment = $in;
			$line = substr( $line, $indexSlashAsterisk + 2 );
		}
	}

	# remove space
	$line = $newLine;
	$line =~ s/\s+/ /g;		# multi space -> single space
	$line =~ s/^ //;		# remove head space
	$line =~ s/ $//;		# remove tail space

	# ignore emply line
	if( $line eq "" )
	{
		next;
	}

	# ignore pragma
	if( substr( $line, 0, 1 ) eq "#" )
	{
		next;
	}

	# do each word
	while( $line =~ /(\w+|[{}()<>,;:])/g )
	{
		$word = $1;

		if( $stateTypedef == $out )
		{
			# searching "typedef" or "struct" or "exception"
			if( $word eq "typedef" )
			{
				$stateTypedef = $type;
				next;
			}
			if( $word eq "struct" )
			{
				$typedefKind = $kindNone;
				$stateTypedef = $end;
				$stateStruct = $name;
				next;
			}
			if( $word eq "exception" )
			{
				$typedefKind = $kindNone;
				$stateTypedef = $end;
				$stateException = $name;
				next;
			}
			if( $word eq "enum" )
			{
				$typedefKind = $kindNone;
				$stateTypedef = $end;
				$stateEnum = $name;
				next;
			}
			next;
		}

		if( $stateEnum == $name )
		{
			# get enum name
			$enumName = $word;
			print "enumName = $enumName\n" if $debugAnalyzeTypedef;
			$stateEnum = $start;
			next;
		}

		if( $stateEnum == $start )
		{
			# search left brace
			if( $word eq $leftBrace )
			{
				$stateEnum = $in;
			}
			next;
		}

		if( $stateEnum == $in )
		{
			# search right brace
			if( $word eq $rightBrace )
			{
				$stateEnum = $out;
				@enumList = ( @enumList, $enumName );
			}
			next;
		}

		if( $stateSequence == $start )
		{
			# search left comparison
			if( $word eq $leftComparison )
			{
				$stateSequence = $type;
			}
			next;
		}

		if( $stateSequence == $type )
		{
			# get sequence type
			$sequenceType = $word;
			print "sequenceType = $sequenceType\n" if $debugAnalyzeTypedef;
			$stateSequence = $end;
			next;
		}

		if( $stateSequence == $end )
		{
			# search right comparison
			if( $word eq $rightComparison )
			{
				$stateSequence = $out;
#SIV00002292 add start
				$sequenceCount = grep { $_ =~ "^$sequenceType,*\$" } @sequenceList;#SIV00003059
#SIV00003059				$sequenceCount = grep { $_ =~ "$sequenceType,*" } @sequenceList;
				$sequenceType2 = $sequenceType;
				if( $sequenceCount > 0 ) { $sequenceType2 = "$sequenceType,$sequenceCount"; }
				@sequenceList = ( @sequenceList, $sequenceType2 );
#SIV00002292 add end
#SIV00002292				if( ! grep { $_ eq $sequenceType } @sequenceList )
#SIV00002292				{
#SIV00002292					@sequenceList = ( @sequenceList, $sequenceType );
#SIV00002292				}
			}
			next;
		}

		if( $stateStruct == $name )
		{
			# get struct name
			$structName = $word;
			print "structName = $structName\n" if $debugAnalyzeTypedef;
			$stateStruct = $start;
			next;
		}

		if( $stateStruct == $start )
		{
			# search left brace
			if( $word eq $leftBrace )
			{
				$stateStruct = $in;
				$stateMember = $type;
				@memberList = ();
			}
			next;
		}

		if( $stateException == $name )
		{
			# get exception name
			$exceptionName = $word;
			print "exceptionName = $exceptionName\n" if $debugAnalyzeTypedef;
			$stateException = $start;
			next;
		}

		if( $stateException == $start )
		{
			# search left brace
			if( $word eq $leftBrace )
			{
				$stateException = $in;
				$stateMember = $type;
				@memberList = ();
			}
			next;
		}

		if( $stateStruct == $in || $stateException == $in )
		{
			if( $stateMember == $type )
			{
				# check right brace
				if( $word eq $rightBrace )
				{
					$stateMember = $out;

					if( $stateException == $in )
					{
						$stateException = $out;
						@exceptionList = ( @exceptionList, [ $exceptionName, [ @memberList ] ] );
					}
					else
					{
						$stateStruct = $out;
						@structList = ( @structList, [ $structName, [ @memberList ] ] );
					}
					next;
				}

				# get member type
				if( $word eq "sequence" )
				{
					$memberKind = $kindSequence;
					$stateMember = $name;
					$stateSequence = $start;
					next;
				}

				$memberKind = $kindOther;
				$stateMember = $name;
				next;
			}

			if( $stateMember == $name )
			{
				# get member name
				if( $word eq "comment" )
				{
#					$memberName = "_$word";	# Orbix2.3
					$memberName = $word;	# Orbix3.0 later
				}
				else
				{
					$memberName = $word;
				}
				print "memberName = $memberName\n" if $debugAnalyzeTypedef;
				$stateMember = $end;
				next;
			}

			if( $stateMember == $end )
			{
				# search semi-colon
				if( $word eq $semiColon )
				{
					$stateMember = $type;
					@memberList = ( @memberList, $memberName );
				}
				next;
			}
			next;
		}

		if( $stateTypedef == $type )
		{
			# get typedef type
			if( $word eq "struct" )
			{
				$typedefKind = $kindStruct;
				$stateTypedef = $name;
				$stateStruct = $name;
				next;
			}

			if( $word eq "sequence" )
			{
				$typedefKind = $kindSequence;
				$stateTypedef = $name;
				$stateSequence = $start;
				next;
			}

			$typedefType = $word;
			$typedefKind = $kindOther;
			$stateTypedef = $name;
			next;
		}

		if( $stateTypedef == $name )
		{
			# get typedef name
			$typedefName = $word;
			print "typedefName = $typedefName\n" if $debugAnalyzeTypedef;
			$stateTypedef = $end;
			next;
		}

		if( $stateTypedef == $end )
		{
			# search semi-colon
			if( $word eq $semiColon )
			{
				if( $typedefKind == $kindStruct )
				{
					$typedefStruct{ $structName } = $typedefName;
				}
				elsif( $typedefKind == $kindSequence )
				{
					$typedefSequence{ $sequenceType2 } = $typedefName; #SIV00002292
					#SIV00002292 $typedefSequence{ $sequenceType } = $typedefName;
				}
				elsif( $typedefKind == $kindOther )
				{
					$typedefStruct{ $typedefType } = $typedefName;
				}
				$stateTypedef = $out;
			}
			next;
		}
	}
}

# print result for debug
if( $debugAnalyzeTypedef )
{
	foreach $struct ( @structList )
	{
		$structName = $$struct[0];
		print "structName = $structName\n";

		$typedefName = $typedefStruct{ $structName };
		print "typedefName = $typedefName\n";

		@memberList = @{$$struct[1]};
		foreach $memberName ( @memberList )
		{
			print " memberName = $memberName\n";
		}
	}

	foreach $sequenceType ( @sequenceList )
	{
		print "sequenceType = $sequenceType\n";

		$typedefName = $typedefSequence{ $sequenceType };
		print "typedefName = $typedefName\n";
	}

	foreach $enumName ( @enumList )
	{
		print "enumName = $enumName\n";
	}
}

1;
