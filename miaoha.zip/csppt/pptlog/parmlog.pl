################################################################################
#
# SCCS ID: @(#) 1.1 superpos/src/spppt/source/posppt/pptlog/parmlog.pl, mm_srv_40a_ppt, mm_srv_40a_ppt 11/12/01 15:04:31 [ 11/12/01 15:04:32 ]
#
# Parameter Log Output - Code Generator
#
# (c) Copyright: Information Technology Solutions Co., Ltd, 2001. All rights reserved
# (c) Copyright: International Business Machines Coorporation, 2001. All rights reserved.
#
# File Name:
#	parmlog.pl
#
# Description:
#	Generate parameter(structures) output codes. 
#
# Histroy:
# Date	      No.      Person          Comments
# ---------- -------- --------------- ------------------------------------
# 2001/11/12 D40A0013 Y.Yamaguchi     Newly created. 
#
################################################################################

$appTitle      = "Paramter log output - Automatic generation code";
$appCopyright1 = "(c) Copyright: Information Technology Solutions Co., Ltd, 2001. All rights reserved";
$appCopyright2 = "(c) Copyright: International Business Machines Coorporation, 2001. All rights reserved";

$leftBrace			= "{";
$rightBrace			= "}";

$leftParen			= "(";
$rightParen			= ")";

$leftComparison		= "<";
$rightComparison	= ">";

$comma				= ",";
$colon				= ":";
$semiColon			= ";";

$modeIn				= "in";
$modeOut			= "out";
$modeInOut			= "inout";

$raises				= "raises";

$typeVoid			= "void";
$typeUnsigned		= "unsigned";
$typeShort			= "short";
$typeUShort			= "unsigned short";
$typeLong			= "long";
$typeULong			= "unsigned long";
$typeFloat			= "float";
$typeDouble			= "double";
$typeChar			= "char";
$typeOctet			= "octet";
$typeBoolean		= "boolean";
$typeAny			= "any";
$typeString			= "string";
$typeObject			= "Object";

$corbaVoid			= "void";
$corbaShort			= "CORBA::Short";
$corbaUShort		= "CORBA::UShort";
$corbaLong			= "CORBA::Long";
$corbaULong			= "CORBA::ULong";
$corbaFloat			= "CORBA::Float";
$corbaDouble		= "CORBA::Double";
$corbaChar			= "CORBA::Char";
$corbaOctet			= "CORBA::Octet";
$corbaBoolean		= "CORBA::Boolean";
$corbaAny			= "CORBA::any";
$corbaString		= "char*";
$corbaObject		= "CORBA::Object";

%typeToCorba =
(
	$typeVoid		=>	$corbaVoid 		,
	$typeShort		=>	$corbaShort 	,
	$typeUShort 	=>	$corbaUShort	,
	$typeLong		=>	$corbaLong		,
	$typeULong		=>	$corbaULong 	,
	$typeFloat		=>	$corbaFloat 	,
	$typeDouble 	=>	$corbaDouble	,
	$typeChar		=>	$corbaChar		,
	$typeOctet		=>	$corbaOctet 	,
	$typeBoolean	=>	$corbaBoolean	,
	$typeAny		=>	$corbaAny		,
	$typeString 	=>	$corbaString	,
	$typeObject 	=>	$corbaObject	
);

sub outputHeader
{
	print "//\n";
	print "// $appTitle\n";
 	print "//\n";
	print "// $appCopyright1\n";
	print "// $appCopyright2\n";
	print "//\n";
	print "// $_[0]\n";
	print "//\n";
}

1;
