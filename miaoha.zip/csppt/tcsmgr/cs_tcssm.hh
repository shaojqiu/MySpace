//----------------------------------------------------------------------------
//
//  Generated from cs_tcssm.idl
//  On Thursday, November 2, 2017 7:16:41 PM GMT+07:00
//  by IBM CORBA 2.3 (hh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _cs_tcssm_server_defined
#ifndef _cs_tcssm_hh_included
#define _cs_tcssm_hh_included

#ifdef _MSC_VER
#define _export export
#endif
#ifndef _USE_NAMESPACE
#define _USE_NAMESPACE
#endif
#ifndef _DCL_CS_TCSServiceManager_SOM_IMPORTEXPORT
#define _DCL_CS_TCSServiceManager_SOM_IMPORTEXPORT 
#endif

#ifndef CORBA_included
#include <corba.h>
#endif
#ifdef SIVIEW_EBROKER
extern "C" {
   #include<stdlib.h>
}
 #if defined(minor)
  #undef minor
 #endif
#endif // SIVIEW_EBROKER

#ifndef IMTRIM
#define IMTRIM
#endif

#ifndef IM_EBROKER
#define IM_EBROKER
#endif

#ifndef CIMFWEVENTS_DISABLED
#define CIMFWEVENTS_DISABLED
#endif

#ifndef DB2PW
#define DB2PW
#endif

#ifndef _AIX
#define _AIX
#endif


#ifndef CS_TCSServiceManager_idl 
#define CS_TCSServiceManager_idl 
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _tcssm_hh_included
#include <tcssm.hh>
#endif
#else
#ifndef _tcssm_hh_included
#include "tcssm.hh"
#endif
#endif
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _cs_pptstr_hh_included
#include <cs_pptstr.hh>
#endif
#else
#ifndef _cs_pptstr_hh_included
#include "cs_pptstr.hh"
#endif
#endif
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _cs_tcsstr_hh_included
#include <cs_tcsstr.hh>
#endif
#else
#ifndef _cs_tcsstr_hh_included
#include "cs_tcsstr.hh"
#endif
#endif

// Begin mapping for interface ::CS_TCSServiceManager

#ifndef _DCL_CS_TCSServiceManager
#define _DCL_CS_TCSServiceManager
#ifndef _DCL_CS_TCSServiceManager_SOM_IMPORTEXPORT
#define _DCL_CS_TCSServiceManager_SOM_IMPORTEXPORT 
#endif
class _DCL_CS_TCSServiceManager_SOM_IMPORTEXPORT
   CS_TCSServiceManager
    ;
class _DCL_CS_TCSServiceManager_SOM_IMPORTEXPORT CS_TCSServiceManager_var;
typedef CS_TCSServiceManager* CS_TCSServiceManager_ptr;
typedef CS_TCSServiceManager* CS_TCSServiceManagerRef;

_DCL_CS_TCSServiceManager_SOM_IMPORTEXPORT CORBA::Object_ptr SOMLINK CS_TCSServiceManager_getBase(void *);

_DCL_CS_TCSServiceManager_SOM_IMPORTEXPORT CS_TCSServiceManager_ptr SOMLINK CS_TCSServiceManager_aux_duplicate(CS_TCSServiceManager_ptr);
_DCL_CS_TCSServiceManager_SOM_IMPORTEXPORT CS_TCSServiceManager_ptr SOMLINK CS_TCSServiceManager_aux_narrow(::CORBA::Object_ptr);
_DCL_CS_TCSServiceManager_SOM_IMPORTEXPORT CS_TCSServiceManager_ptr SOMLINK CS_TCSServiceManager_aux_nil();
_DCL_CS_TCSServiceManager_SOM_IMPORTEXPORT const char* SOMLINK CS_TCSServiceManager_aux_CN();

    class _DCL_CS_TCSServiceManager_SOM_IMPORTEXPORT CS_TCSServiceManager_StructElem
    {
        public:

        CS_TCSServiceManager_StructElem ();

        CS_TCSServiceManager_StructElem (const CS_TCSServiceManager_StructElem &s);

        CS_TCSServiceManager_StructElem &operator= (CS_TCSServiceManager_ptr p);

        CS_TCSServiceManager_StructElem &operator= (CS_TCSServiceManager_var v);

        CS_TCSServiceManager_StructElem &operator= (const CS_TCSServiceManager_StructElem &s);

        ~CS_TCSServiceManager_StructElem ();

        operator ::CORBA::Object_ptr() const;

        operator CS_TCSServiceManager_ptr () const;

        CS_TCSServiceManager_ptr _ptr;

    }; // CS_TCSServiceManager_StructElem

    class _DCL_CS_TCSServiceManager_SOM_IMPORTEXPORT CS_TCSServiceManager_SeqElem
    {
       public:

       CS_TCSServiceManager_SeqElem (CS_TCSServiceManager_ptr* p, unsigned char rel);

       CS_TCSServiceManager_SeqElem &operator= (CS_TCSServiceManager_ptr p);

        CS_TCSServiceManager_SeqElem &operator= (CS_TCSServiceManager_var v);

       CS_TCSServiceManager_SeqElem &operator= (const CS_TCSServiceManager_SeqElem &s);

       operator CS_TCSServiceManager_ptr () const;

       CS_TCSServiceManager_ptr operator->() const;

       protected:
       CS_TCSServiceManager_ptr *_ptr;
       unsigned char _release;
   }; // CS_TCSServiceManager_SeqElem


class  CS_TCSServiceManager_var : public ::CORBA::__vb__
{
    public:

    CS_TCSServiceManager_var ();
    CS_TCSServiceManager_var (CS_TCSServiceManager *p);
    CS_TCSServiceManager_var (const CS_TCSServiceManager_var &s);
    CS_TCSServiceManager_var (const CS_TCSServiceManager_StructElem &s);
    CS_TCSServiceManager_var (const CS_TCSServiceManager_SeqElem &s);
    CS_TCSServiceManager_var &operator= (CS_TCSServiceManager *p);
    CS_TCSServiceManager_var &operator= (const CS_TCSServiceManager_var &s);
    CS_TCSServiceManager_var &operator= (const CS_TCSServiceManager_StructElem &s);
    CS_TCSServiceManager_var &operator= (const CS_TCSServiceManager_SeqElem &s);
    ~CS_TCSServiceManager_var ();
    CS_TCSServiceManager_ptr in() const;
    CS_TCSServiceManager_ptr& inout();
    CS_TCSServiceManager_ptr& out();
    CS_TCSServiceManager_ptr _retn();
    CS_TCSServiceManager_ptr operator-> ();
    operator CS_TCSServiceManager_ptr& ();
    operator const CS_TCSServiceManager_ptr& () const;
#ifdef __sun
    operator CS_TCSServiceManager_ptr () { return _ptr; };
#endif

    protected:
       CS_TCSServiceManager *_ptr;

    private:
       ::CORBA::__vb__& operator= (::CORBA::__vb__&);

};  // CS_TCSServiceManager_var

#endif /* _DCL_CS_TCSServiceManager */ 


class 

   CS_TCSServiceManager
: virtual public ::TCSServiceManager {

public: 
    static const char* CS_TCSServiceManager_CN;
    static const char* CS_TCSServiceManager_RID;
    typedef CS_TCSServiceManager_ptr _ptr_type;
    typedef CS_TCSServiceManager_var _var_type;

    /* for Orbix compatibility */
    virtual void *_deref();

protected: 
    /* constructor */

   CS_TCSServiceManager
();
protected: 
    virtual ~

   CS_TCSServiceManager
();
private: 

   CS_TCSServiceManager
    (const 
   CS_TCSServiceManager
     &); // unimplemented

    void operator=(const 
   CS_TCSServiceManager
     &); // unimplemented
public: 

    static CS_TCSServiceManager_ptr SOMLINK _duplicate(CS_TCSServiceManager_ptr obj);

    static CS_TCSServiceManager_ptr SOMLINK _narrow (::CORBA::Object_ptr);

    virtual void* _has_ancestor(const char* classname);
    static CS_TCSServiceManager_ptr SOMLINK _nil ();

    CS_TCSServiceManager_ptr _self();
    CS_TCSServiceManager_ptr _this();
    virtual void *_SOMThis(const char *& ifname);


    virtual  ::tcsRecipeUploadReqResult*  CS_TxRecipeUploadReq (const ::pptUser& requestUserID, const char* requestID, const ::objectIdentifier& equipmentID, const char* fileLocation, const ::tcsRecipeSequence& recipeIDs, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::tcsRecipeUploadReqResult*  _req_CS_TxRecipeUploadReq (const ::pptUser& requestUserID, const char* requestID, const ::objectIdentifier& equipmentID, const char* fileLocation, const ::tcsRecipeSequence& recipeIDs, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::tcsEqpConstantInqResult*  CS_TxEqpConstantInq (const ::pptUser& requestUserID, const char* requestID, const ::objectIdentifier& equipmentID, const ::tcsEqpConstantSequence& ECIDs, const ::tcsEqpConstantSequence& SVIDs, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::tcsEqpConstantInqResult*  _req_CS_TxEqpConstantInq (const ::pptUser& requestUserID, const char* requestID, const ::objectIdentifier& equipmentID, const ::tcsEqpConstantSequence& ECIDs, const ::tcsEqpConstantSequence& SVIDs, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::tcsRecipeDownloadReqResult*  CS_TxRecipeDownloadReq (const ::pptUser& requestUserID, const char* requestID, const ::objectIdentifier& equipmentID, const char* fileLocation, const char* fileName, const ::tcsRecipeSequence& recipeIDs, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::tcsRecipeDownloadReqResult*  _req_CS_TxRecipeDownloadReq (const ::pptUser& requestUserID, const char* requestID, const ::objectIdentifier& equipmentID, const char* fileLocation, const char* fileName, const ::tcsRecipeSequence& recipeIDs, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::tcsTCSForceCompleteReqResult*  CS_TxTCSForceCompleteReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, ::CORBA::Boolean spcResultRequiredFlag, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::tcsTCSForceCompleteReqResult*  _req_CS_TxTCSForceCompleteReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, ::CORBA::Boolean spcResultRequiredFlag, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::tcsFurnaceBoatStatusChangeReqResult*  CS_TxTCSFurnaceBoatStatusChangeReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::tcsFurnaceBoatStatusChangeReqResult*  _req_CS_TxTCSFurnaceBoatStatusChangeReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::tcsChemicalStatusChangeReqResult*  CS_TxTCSChemicalStatusChangeReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::tcsChemicalStatusChangeReqResult*  _req_CS_TxTCSChemicalStatusChangeReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* claimMemo, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::tcsEqpChamberInProcessWaferCountInqResult*  CS_TxTCSEqpChamberInProcessWaferCountInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::tcsEqpChamberInProcessWaferCountInqResult*  _req_CS_TxTCSEqpChamberInProcessWaferCountInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::tcsBWSInventoryInqResult*  CS_TxTCSBWSInventoryInq (const ::pptUser& requestUserID, const ::objectIdentifier& BWSID, const char* zoneID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::tcsBWSInventoryInqResult*  _req_CS_TxTCSBWSInventoryInq (const ::pptUser& requestUserID, const ::objectIdentifier& BWSID, const char* zoneID, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:

}; // end nesting scope for interface class ::CS_TCSServiceManager

#ifdef _MSC_VER
#pragma warning(disable:4250)
#endif

class  CS_TCSServiceManager_ORBProxy : virtual public 

   CS_TCSServiceManager
, virtual public ::TCSServiceManager_ORBProxy {

public: 
    CS_TCSServiceManager_ORBProxy ();

    virtual  ::tcsRecipeUploadReqResult*  CS_TxRecipeUploadReq (const ::pptUser& requestUserID, const char* requestID, const ::objectIdentifier& equipmentID, const char* fileLocation, const ::tcsRecipeSequence& recipeIDs, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::tcsEqpConstantInqResult*  CS_TxEqpConstantInq (const ::pptUser& requestUserID, const char* requestID, const ::objectIdentifier& equipmentID, const ::tcsEqpConstantSequence& ECIDs, const ::tcsEqpConstantSequence& SVIDs, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::tcsRecipeDownloadReqResult*  CS_TxRecipeDownloadReq (const ::pptUser& requestUserID, const char* requestID, const ::objectIdentifier& equipmentID, const char* fileLocation, const char* fileName, const ::tcsRecipeSequence& recipeIDs, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::tcsTCSForceCompleteReqResult*  CS_TxTCSForceCompleteReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const ::objectIdentifier& controlJobID, ::CORBA::Boolean spcResultRequiredFlag, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::tcsFurnaceBoatStatusChangeReqResult*  CS_TxTCSFurnaceBoatStatusChangeReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::tcsChemicalStatusChangeReqResult*  CS_TxTCSChemicalStatusChangeReq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, const char* claimMemo, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::tcsEqpChamberInProcessWaferCountInqResult*  CS_TxTCSEqpChamberInProcessWaferCountInq (const ::pptUser& requestUserID, const ::objectIdentifier& equipmentID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::tcsBWSInventoryInqResult*  CS_TxTCSBWSInventoryInq (const ::pptUser& requestUserID, const ::objectIdentifier& BWSID, const char* zoneID, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

}; /* end of ::CS_TCSServiceManager_ORBProxy*/
#ifdef _MSC_VER
#pragma warning(default:4250)
#endif
class  CS_TCSServiceManagerProxyFactory : virtual public ::TCSServiceManagerProxyFactory {

public:
   CS_TCSServiceManagerProxyFactory (::CORBA::Boolean is_default = 0);

   virtual ::CORBA::Object_ptr create_proxy (const char* classname);
   virtual ::CORBA::Object_ptr asObject(void *obj);
}; // CS_TCSServiceManagerProxyFactory


class  CS_TCSServiceManager_Dispatcher : virtual public ::TCSServiceManager_Dispatcher {

  public:

   CS_TCSServiceManager_Dispatcher (::CORBA::Object_ptr target);

   CS_TCSServiceManager_Dispatcher (); 

   virtual ::CORBA::Boolean dispatch (::CORBA::Request &request);
#ifdef _MSC_VER
   ::CORBA::Boolean __CS_TCSServiceManager__dispatch(::CORBA::Request &_req);
#endif // _MSC_VER
}; // CS_TCSServiceManager_Dispatcher
#ifdef _MSC_VER
#pragma warning(disable:4250)
#endif
class  CS_TCSServiceManagerBOAImpl : virtual public 

   CS_TCSServiceManager
, virtual public ::CORBA::Object_ORBProxy { 
   public:
     CS_TCSServiceManagerBOAImpl() ;

     virtual ~CS_TCSServiceManagerBOAImpl();
     CS_TCSServiceManagerBOAImpl &operator= (const CS_TCSServiceManagerBOAImpl &s);
     CS_TCSServiceManagerBOAImpl (const CS_TCSServiceManagerBOAImpl &s);
};  // CS_TCSServiceManagerBOAImpl

    extern  ::CORBA::TypeCode_ptr _tc_CS_TCSServiceManager;
#endif   
/*
 * Guard codes of CORBA::Any operators.
 */
#ifdef __NOTUSE_ANYOPERATOR__
#define __NOTUSE_cs_tcssm_ANYOPERATOR__
#endif //__NOTUSE_ANYOPERATOR__

#ifdef __USE_cs_tcssm_ANYOPERATOR__
#undef __NOTUSE_cs_tcssm_ANYOPERATOR__
#endif //__USE_cs_tcssm_ANYOPERATOR__
#ifndef __NOTUSE_cs_tcssm_ANYOPERATOR__
#define _DCL_ANYOPS_CS_TCSServiceManager
#endif //__NOTUSE_cs_tcssm_ANYOPERATOR__

/*
 * Overloaded CORBA::Any operators.
 */
#ifdef _DCL_ANYOPS_CS_TCSServiceManager
#ifndef __NOTUSE_ANYOPERATOR_INTERFACE__
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::CS_TCSServiceManager_ptr _data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::CS_TCSServiceManager_ptr *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::CS_TCSServiceManager_ptr& _data);
#endif
#endif //__NOTUSE_ANYOPERATOR_INTERFACE__
#endif // _DCL_ANYOPS_CS_TCSServiceManager

#endif /* _cs_tcssm_hh_included */

#endif /* _cs_tcssm_server_defined */
