//
// Modification History :
// Date       Version       Author          Request No.          Comment
// ---------- ------------- --------------  -------------------- -------------------------------
// 2017/10/17 INN-R170016   Yangxiaojun     INN-R170016          NPW Monitor Customization
//

char            hCSFSNPWPRODPRODSPEC_ID[65];
char            hCSFSNPWPRODSUB_LOT_TYPE[21];
char            hCSFSNPWPRODNPW_TYPE[21];
char            hCSFSNPWPRODPROD_CATEGORY_ID[65];
char            hCSFSNPWPRODROUTE_ID[65];
char            hCSFSNPWPRODSTART_BANK_ID[65];
char            hCSFSNPWPRODSTART_BWS_ID[65];
char            hCSFSNPWPRODEND_BANK_ID[65];
char            hCSFSNPWPRODEND_BWS_ID[65];
sqlint32        hCSFSNPWPRODTARGET_QTY;
sqlint32        hCSFSNPWPRODCURRENT_QTY;
sqlint32        hCSFSNPWPRODCUR_SRC_QTY;
sqlint32        hCSFSNPWPRODUSE_LIMIT;
sqlint16        hCSFSNPWPRODAUTO_STB;
char            hCSFSNPWPRODMESSAGE[266];
char            hCSFSNPWPRODCLAIM_USER_ID[65];
char            hCSFSNPWPRODCLAIM_TIME[27];
char            hCSFSNPWPRODCHECK_TIME[27];
