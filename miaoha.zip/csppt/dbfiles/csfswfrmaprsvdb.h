//
// (c) Copyright: IBM Taiwan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: csfswfrmaprsvdb.h
//
// Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------  -------------- -------------------------------------------
// 2017/07/25 INN-R170084   Jacky Yeh      170084: Automatic Vendor Lot Receive and Prepare
//

char hCSFSWFRMAPRSVBANK_ID[65];
char hCSFSWFRMAPRSVLOT_TYPE[21];
char hCSFSWFRMAPRSVSUB_LOT_TYPE[21];
char hCSFSWFRMAPRSVSRC_PROD_ID[65];
char hCSFSWFRMAPRSVPART_NO[21];
char hCSFSWFRMAPRSVCAST_ID[65];
char hCSFSWFRMAPRSVCLAIM_USER[65];
char hCSFSWFRMAPRSVCLAIM_TIME[27];

char hCSFSWFRMAPRSV_DATACAST_ID[65];
char hCSFSWFRMAPRSV_DATANEW_LOT_ID[65];
char hCSFSWFRMAPRSV_DATANEW_WAFER_ID[65];
sqlint32 hCSFSWFRMAPRSV_DATANEW_SLOT_NO;
char hCSFSWFRMAPRSV_DATASRC_LOT_ID[65];
char hCSFSWFRMAPRSV_DATASRC_WAFER_ID[65];
