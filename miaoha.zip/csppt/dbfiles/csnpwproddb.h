
// Support host variable with short name

char            hCSNPWPROD_prodspec_id[65];                     // Host Variable for data in prodspec_id Data Member of corresponding BO.       
char            hCSNPWPROD_sub_lot_type[21];                    // Host Variable for data in sub_lot_type Data Member of corresponding BO.      
char            hCSNPWPROD_npw_type[21];                        // Host Variable for data in npw_type Data Member of corresponding BO.      
char            hCSNPWPROD_route_id[65];                        // Host Variable for data in route_id Data Member of corresponding BO.          
char            hCSNPWPROD_start_bank_id[65];                   // Host Variable for data in start_bank_id Data Member of corresponding BO.     
char            hCSNPWPROD_start_bws_id[65];                    // Host Variable for data in start_bws_id Data Member of corresponding BO       
char            hCSNPWPROD_end_bank_id[65];                     // Host Variable for data in end_bank_id Data Member of corresponding BO.       
char            hCSNPWPROD_end_bws_id[65];                      // Host Variable for data in end_bws_id Data Member of corresponding BO.        
sqlint32        hCSNPWPROD_target_qty;                          // Host Variable for data in target_qty Data Member of corresponding BO,    
sqlint32        hCSNPWPROD_current_qty;                         // Host Variable for data in current_qty Data Member of corresponding BO.   
sqlint32        hCSNPWPROD_cur_src_qty;                         // Host Variable for data in cur_src_qty Data Member of corresponding BO.   
sqlint32        hCSNPWPROD_use_limit;                           // Host Variable for data in use_limit Data Member of corresponding BO.     
sqlint16        hCSNPWPROD_auto_stb;                            // Host Variable for data in auto_stb Data Member of corresponding BO.      
char            hCSNPWPROD_message[266];                        // Host Variable for data in message Data Member of corresponding BO.       
char            hCSNPWPROD_claim_user_id[65];                   // Host Variable for data in claim_user_id Data Member of corresponding BO. 
char            hCSNPWPROD_claim_time[27];                      // Host Variable for data in claim_time Data Member of corresponding BO.    
