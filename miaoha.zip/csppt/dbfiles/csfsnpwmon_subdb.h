//
// Modification History :
// Date       Version       Author          Request No.          Comment
// ---------- ------------- --------------  -------------------- -------------------------------
// 2017/10/24 INN-R170016   Yangxiaojun     INN-R170016          NPW Monitor Customization
//

char            hCSFSNPWMON_SUBd_thesystemkey[65];
char            hCSFSNPWMON_SUBEQPMON_ID[65];
sqlint32        hCSFSNPWMON_SUBPOSITION;
char            hCSFSNPWMON_SUBPRODSPEC_ID[65];
sqlint32        hCSFSNPWMON_SUBCAST_SEQ_NO;
char            hCSFSNPWMON_SUBSUB_ROUTE_ID[65];

