//
// Modification History :
// Date       Version        Author         Request No.          Comment
// ---------- -------------  -------------- -------------------- -------------------------------
// 2017/10/17 INN-R17001701  LiHejing       INN-R170017          Initial Release
//
char             hCSFSBWSBWS_ID[65];
sqlint32         hCSFSBWSWAFER_COUNT;
char             hCSFSBWSCLAIM_TIME[27];
char             hCSFSBWSCLAIM_USER_ID[65];
char             hCSFSBWSCLAIM_MEMO[257];
