//
// Modification History :
// Date       Version       Author          Request No.          Comment
// ---------- ------------- --------------  -------------------- -------------------------------
// 2017/10/24 INN-R170016   Yangxiaojun     INN-R170016          NPW Monitor Customization
//

sqlint32        hCSFSNPWDWNGSEQ_NO;
char            hCSFSNPWDWNGORG_PRODSPEC_ID[65];
char            hCSFSNPWDWNGTO_PRODSPEC_ID[65];
char            hCSFSNPWDWNGEND_BANK_ID[65];
char            hCSFSNPWDWNGGRADE[11];
char            hCSFSNPWDWNGITEM01[13];
char            hCSFSNPWDWNGITEM02[13];
char            hCSFSNPWDWNGITEM03[13];
char            hCSFSNPWDWNGITEM04[13];
char            hCSFSNPWDWNGITEM05[13];
char            hCSFSNPWDWNGITEM06[13];
char            hCSFSNPWDWNGITEM07[13];
char            hCSFSNPWDWNGITEM08[13];
char            hCSFSNPWDWNGITEM09[13];
char            hCSFSNPWDWNGITEM10[13];
char            hCSFSNPWDWNGITEM11[13];
char            hCSFSNPWDWNGITEM12[13];
char            hCSFSNPWDWNGCLAIM_USER_ID[65];
char            hCSFSNPWDWNGCLAIM_TIME[27];

