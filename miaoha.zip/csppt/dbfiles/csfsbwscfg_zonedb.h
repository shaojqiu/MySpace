//
// Modification History :
// Date       Version        Author         Request No.          Comment
// ---------- -------------  -------------- -------------------- -------------------------------
// 2017/10/17 INN-R17001701  Cheng Li       INN-R170017          Initial Release
//
char             hCSFSBWSCFG_ZONEBWS_ID[65];
char             hCSFSBWSCFG_ZONEZONE_ID[65];
sqlint32         hCSFSBWSCFG_ZONEMAX_CAPACITY;
char             hCSFSBWSCFG_ZONECLAIM_TIME[27];
char             hCSFSBWSCFG_ZONECLAIM_USER_ID[65];
char             hCSFSBWSCFG_ZONECLAIM_MEMO[257];
