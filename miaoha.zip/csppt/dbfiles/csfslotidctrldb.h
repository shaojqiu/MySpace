//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// Innotron Modification history :
// Date         Defect#         Person          Comments
// ----------   ------------    --------------  -------------------------------------------
// 2017/09/22   INN-R170001     Vera Chen       Initial release
//

char        hCSFSLOTIDCTRLLEADING_CHAR      [3];
sqlint32    hCSFSLOTIDCTRLLAST_USED_NUMBER     ;
char        hCSFSLOTIDCTRLYEAR              [5];
char        hCSFSLOTIDCTRLSUB_CHAR          [2];
//sqlint32    hCSFSLOTIDCTRLWEEK                 ;

