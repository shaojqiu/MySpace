//
// (c) Copyright: IBM Services Company Ltd, 2017, 2027. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017, 2027. All rights reserved.
//
// SiView
// Name: cspcasdb.h 
//
// Modification history :
// Date       Defect#       Person           Comments
// ---------- ------------  -------------- -------------------------------------------
// 2017/09/21 INN-R170003   Jun Zhang      New Transfer State PI/PO 
//

char hFRCASTTRANS_STATE1[3];
