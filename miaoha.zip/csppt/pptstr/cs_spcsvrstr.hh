//----------------------------------------------------------------------------
//
//  Generated from cs_spcsvrstr.idl
//  On Wednesday, November 1, 2017 2:36:21 PM GMT+07:00
//  by IBM CORBA 2.3 (hh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _cs_spcsvrstr_server_defined
#ifndef _cs_spcsvrstr_hh_included
#define _cs_spcsvrstr_hh_included

#ifdef _MSC_VER
#define _export export
#endif
#ifndef _USE_NAMESPACE
#define _USE_NAMESPACE
#endif

#ifndef CORBA_included
#include <corba.h>
#endif
#ifdef SIVIEW_EBROKER
extern "C" {
   #include<stdlib.h>
}
 #if defined(minor)
  #undef minor
 #endif
#endif // SIVIEW_EBROKER

#ifndef IMTRIM
#define IMTRIM
#endif

#ifndef IM_EBROKER
#define IM_EBROKER
#endif

#ifndef CIMFWEVENTS_DISABLED
#define CIMFWEVENTS_DISABLED
#endif

#ifndef DB2PW
#define DB2PW
#endif

#ifndef _AIX
#define _AIX
#endif


#ifndef SPCSVRSTR_IDL 
#define SPCSVRSTR_IDL 
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _fwcommon_hh_included
#include <fwcommon.hh>
#endif
#else
#ifndef _fwcommon_hh_included
#include "fwcommon.hh"
#endif
#endif
    class  spcDcItem_struct_var;
    struct  spcDcItem_struct {
        typedef spcDcItem_struct_var _var_type;
       ::CORBA::String_StructElem dataItemName;
       ::CORBA::String_StructElem waferID;
       ::CORBA::String_StructElem waferPosition;
       ::CORBA::String_StructElem sitePosition;
       ::CORBA::Any dataValue;
       ::CORBA::Double targetValue;
       ::CORBA::String_StructElem specCheckResult;
       ::CORBA::String_StructElem comment;
       ::CORBA::String_StructElem chamber_list;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       spcDcItem_struct();
       spcDcItem_struct(const spcDcItem_struct&);
       spcDcItem_struct& operator=(const spcDcItem_struct&);
       static CORBA::Info<spcDcItem_struct> spcDcItem_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct spcDcItem_struct


typedef spcDcItem_struct* spcDcItem_struct_vPtr;
typedef const spcDcItem_struct* spcDcItem_struct_cvPtr;

class  spcDcItem_struct_var
{
    public:

    spcDcItem_struct_var ();

    spcDcItem_struct_var (spcDcItem_struct *_p);

    spcDcItem_struct_var (const spcDcItem_struct_var &_s);

    spcDcItem_struct_var &operator= (spcDcItem_struct *_p);

    spcDcItem_struct_var &operator= (const spcDcItem_struct_var &_s);

    ~spcDcItem_struct_var ();

    spcDcItem_struct* operator-> ();

    const spcDcItem_struct& in() const;
    spcDcItem_struct& inout();
    spcDcItem_struct*& out();
    spcDcItem_struct* _retn();

    operator spcDcItem_struct_cvPtr () const;

    operator spcDcItem_struct_vPtr& ();

    operator const spcDcItem_struct& () const;

    operator spcDcItem_struct& ();

    protected:
    spcDcItem_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_spcDcItem_struct;
    typedef spcDcItem_struct spcSpcDcItem;
    typedef spcDcItem_struct_var spcSpcDcItem_var;
    extern  ::CORBA::TypeCode_ptr _tc_spcSpcDcItem;
class  _IDL_SEQ_spcDcItemSequence_0_var;
class  _IDL_SEQ_spcDcItemSequence_0 {
    public:
        typedef _IDL_SEQ_spcDcItemSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    spcSpcDcItem *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_spcDcItemSequence_0 ();
    _IDL_SEQ_spcDcItemSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_spcDcItemSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, spcSpcDcItem* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_spcDcItemSequence_0 (const _IDL_SEQ_spcDcItemSequence_0&);

    ~_IDL_SEQ_spcDcItemSequence_0 ();

    _IDL_SEQ_spcDcItemSequence_0& operator= (const _IDL_SEQ_spcDcItemSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    spcSpcDcItem& operator [] (::CORBA::ULong indx);
    const spcSpcDcItem& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    spcSpcDcItem* get_buffer (::CORBA::Boolean orphan=0);
    const spcSpcDcItem* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, spcSpcDcItem* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, spcSpcDcItem* src, spcSpcDcItem* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, spcSpcDcItem* data); 
  public:

    static spcSpcDcItem* SOMLINK allocbuf(::CORBA::ULong nelems);
    static spcSpcDcItem* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(spcSpcDcItem* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_spcDcItemSequence_0> spcDcItemSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_spcDcItemSequence_0* _IDL_SEQ_spcDcItemSequence_0_vPtr;
typedef const _IDL_SEQ_spcDcItemSequence_0* _IDL_SEQ_spcDcItemSequence_0_cvPtr;

class  _IDL_SEQ_spcDcItemSequence_0_var
{
    public:

    _IDL_SEQ_spcDcItemSequence_0_var ();

    _IDL_SEQ_spcDcItemSequence_0_var (_IDL_SEQ_spcDcItemSequence_0 *_p);

    _IDL_SEQ_spcDcItemSequence_0_var (const _IDL_SEQ_spcDcItemSequence_0_var &_s);

    _IDL_SEQ_spcDcItemSequence_0_var &operator= (_IDL_SEQ_spcDcItemSequence_0 *_p);

    _IDL_SEQ_spcDcItemSequence_0_var &operator= (const _IDL_SEQ_spcDcItemSequence_0_var &_s);

    ~_IDL_SEQ_spcDcItemSequence_0_var ();

    _IDL_SEQ_spcDcItemSequence_0* operator-> ();

    operator _IDL_SEQ_spcDcItemSequence_0_cvPtr () const;

    operator _IDL_SEQ_spcDcItemSequence_0_vPtr& ();

    operator _IDL_SEQ_spcDcItemSequence_0() const;

    const spcSpcDcItem& operator[] (::CORBA::ULong index) const;
    spcSpcDcItem& operator[] (::CORBA::ULong index);
    const spcSpcDcItem& operator[] (int index) const;
    spcSpcDcItem& operator[] (int index);
    const _IDL_SEQ_spcDcItemSequence_0& in() const;
    _IDL_SEQ_spcDcItemSequence_0& inout();
    _IDL_SEQ_spcDcItemSequence_0*& out();
    _IDL_SEQ_spcDcItemSequence_0* _retn();

    protected:
    _IDL_SEQ_spcDcItemSequence_0 *_ptr;
};

    typedef _IDL_SEQ_spcDcItemSequence_0 _spcDcItemSequence_seq;
    typedef _IDL_SEQ_spcDcItemSequence_0 _spcDcItemSequence_seq_1;
    typedef _IDL_SEQ_spcDcItemSequence_0 spcDcItemSequence;
    typedef _IDL_SEQ_spcDcItemSequence_0_var spcDcItemSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_spcDcItemSequence;
    class  spcWaferIDByChamber_struct_var;
    struct  spcWaferIDByChamber_struct {
        typedef spcWaferIDByChamber_struct_var _var_type;
       ::CORBA::String_StructElem procChamber;
       ::stringSequence waferIDs;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       spcWaferIDByChamber_struct();
       spcWaferIDByChamber_struct(const spcWaferIDByChamber_struct&);
       spcWaferIDByChamber_struct& operator=(const spcWaferIDByChamber_struct&);
       static CORBA::Info<spcWaferIDByChamber_struct> spcWaferIDByChamber_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct spcWaferIDByChamber_struct


typedef spcWaferIDByChamber_struct* spcWaferIDByChamber_struct_vPtr;
typedef const spcWaferIDByChamber_struct* spcWaferIDByChamber_struct_cvPtr;

class  spcWaferIDByChamber_struct_var
{
    public:

    spcWaferIDByChamber_struct_var ();

    spcWaferIDByChamber_struct_var (spcWaferIDByChamber_struct *_p);

    spcWaferIDByChamber_struct_var (const spcWaferIDByChamber_struct_var &_s);

    spcWaferIDByChamber_struct_var &operator= (spcWaferIDByChamber_struct *_p);

    spcWaferIDByChamber_struct_var &operator= (const spcWaferIDByChamber_struct_var &_s);

    ~spcWaferIDByChamber_struct_var ();

    spcWaferIDByChamber_struct* operator-> ();

    const spcWaferIDByChamber_struct& in() const;
    spcWaferIDByChamber_struct& inout();
    spcWaferIDByChamber_struct*& out();
    spcWaferIDByChamber_struct* _retn();

    operator spcWaferIDByChamber_struct_cvPtr () const;

    operator spcWaferIDByChamber_struct_vPtr& ();

    operator const spcWaferIDByChamber_struct& () const;

    operator spcWaferIDByChamber_struct& ();

    protected:
    spcWaferIDByChamber_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_spcWaferIDByChamber_struct;
    typedef spcWaferIDByChamber_struct spcWaferIDByChamber;
    typedef spcWaferIDByChamber_struct_var spcWaferIDByChamber_var;
    extern  ::CORBA::TypeCode_ptr _tc_spcWaferIDByChamber;
class  _IDL_SEQ_spcWaferIDByChamberSequence_0_var;
class  _IDL_SEQ_spcWaferIDByChamberSequence_0 {
    public:
        typedef _IDL_SEQ_spcWaferIDByChamberSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    spcWaferIDByChamber *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_spcWaferIDByChamberSequence_0 ();
    _IDL_SEQ_spcWaferIDByChamberSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_spcWaferIDByChamberSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, spcWaferIDByChamber* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_spcWaferIDByChamberSequence_0 (const _IDL_SEQ_spcWaferIDByChamberSequence_0&);

    ~_IDL_SEQ_spcWaferIDByChamberSequence_0 ();

    _IDL_SEQ_spcWaferIDByChamberSequence_0& operator= (const _IDL_SEQ_spcWaferIDByChamberSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    spcWaferIDByChamber& operator [] (::CORBA::ULong indx);
    const spcWaferIDByChamber& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    spcWaferIDByChamber* get_buffer (::CORBA::Boolean orphan=0);
    const spcWaferIDByChamber* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, spcWaferIDByChamber* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, spcWaferIDByChamber* src, spcWaferIDByChamber* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, spcWaferIDByChamber* data); 
  public:

    static spcWaferIDByChamber* SOMLINK allocbuf(::CORBA::ULong nelems);
    static spcWaferIDByChamber* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(spcWaferIDByChamber* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_spcWaferIDByChamberSequence_0> spcWaferIDByChamberSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_spcWaferIDByChamberSequence_0* _IDL_SEQ_spcWaferIDByChamberSequence_0_vPtr;
typedef const _IDL_SEQ_spcWaferIDByChamberSequence_0* _IDL_SEQ_spcWaferIDByChamberSequence_0_cvPtr;

class  _IDL_SEQ_spcWaferIDByChamberSequence_0_var
{
    public:

    _IDL_SEQ_spcWaferIDByChamberSequence_0_var ();

    _IDL_SEQ_spcWaferIDByChamberSequence_0_var (_IDL_SEQ_spcWaferIDByChamberSequence_0 *_p);

    _IDL_SEQ_spcWaferIDByChamberSequence_0_var (const _IDL_SEQ_spcWaferIDByChamberSequence_0_var &_s);

    _IDL_SEQ_spcWaferIDByChamberSequence_0_var &operator= (_IDL_SEQ_spcWaferIDByChamberSequence_0 *_p);

    _IDL_SEQ_spcWaferIDByChamberSequence_0_var &operator= (const _IDL_SEQ_spcWaferIDByChamberSequence_0_var &_s);

    ~_IDL_SEQ_spcWaferIDByChamberSequence_0_var ();

    _IDL_SEQ_spcWaferIDByChamberSequence_0* operator-> ();

    operator _IDL_SEQ_spcWaferIDByChamberSequence_0_cvPtr () const;

    operator _IDL_SEQ_spcWaferIDByChamberSequence_0_vPtr& ();

    operator _IDL_SEQ_spcWaferIDByChamberSequence_0() const;

    const spcWaferIDByChamber& operator[] (::CORBA::ULong index) const;
    spcWaferIDByChamber& operator[] (::CORBA::ULong index);
    const spcWaferIDByChamber& operator[] (int index) const;
    spcWaferIDByChamber& operator[] (int index);
    const _IDL_SEQ_spcWaferIDByChamberSequence_0& in() const;
    _IDL_SEQ_spcWaferIDByChamberSequence_0& inout();
    _IDL_SEQ_spcWaferIDByChamberSequence_0*& out();
    _IDL_SEQ_spcWaferIDByChamberSequence_0* _retn();

    protected:
    _IDL_SEQ_spcWaferIDByChamberSequence_0 *_ptr;
};

    typedef _IDL_SEQ_spcWaferIDByChamberSequence_0 _spcWaferIDByChamberSequence_seq;
    typedef _IDL_SEQ_spcWaferIDByChamberSequence_0 _spcWaferIDByChamberSequence_seq_1;
    typedef _IDL_SEQ_spcWaferIDByChamberSequence_0 spcWaferIDByChamberSequence;
    typedef _IDL_SEQ_spcWaferIDByChamberSequence_0_var spcWaferIDByChamberSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_spcWaferIDByChamberSequence;
    class  spcInput_struct_var;
    struct  spcInput_struct {
        typedef spcInput_struct_var _var_type;
       ::objectIdentifier requestUserID;
       ::objectIdentifier lotID;
       ::objectIdentifier processEquipmentID;
       ::objectIdentifier processRecipeID;
       ::objectIdentifier processMainProcessDefinitionID;
       ::objectIdentifier processProcessDefinitionID;
       ::CORBA::String_StructElem processOperationNumber;
       ::objectIdentifier measurementEquipmentID;
       ::objectIdentifier technologyID;
       ::objectIdentifier productGroupID;
       ::objectIdentifier productID;
       ::objectIdentifier reticleID;
       ::objectIdentifierSequence reticleIDs;
       ::objectIdentifier fixtureID;
       ::objectIdentifier mainProcessDefinitionID;
       ::CORBA::String_StructElem operationNumber;
       ::CORBA::String_StructElem operationName;
       ::objectIdentifier ownerUserID;
       ::CORBA::String_StructElem collectionType;
       ::objectIdentifier dcDefID;
       ::spcDcItemSequence dcItems;
       ::spcWaferIDByChamberSequence waferIDByChambers;
       ::CORBA::String_StructElem lotComment;
       ::CORBA::String_StructElem processTimestamp;
       ::CORBA::String_StructElem measurementTimestamp;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       spcInput_struct();
       spcInput_struct(const spcInput_struct&);
       spcInput_struct& operator=(const spcInput_struct&);
       static CORBA::Info<spcInput_struct> spcInput_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct spcInput_struct


typedef spcInput_struct* spcInput_struct_vPtr;
typedef const spcInput_struct* spcInput_struct_cvPtr;

class  spcInput_struct_var
{
    public:

    spcInput_struct_var ();

    spcInput_struct_var (spcInput_struct *_p);

    spcInput_struct_var (const spcInput_struct_var &_s);

    spcInput_struct_var &operator= (spcInput_struct *_p);

    spcInput_struct_var &operator= (const spcInput_struct_var &_s);

    ~spcInput_struct_var ();

    spcInput_struct* operator-> ();

    const spcInput_struct& in() const;
    spcInput_struct& inout();
    spcInput_struct*& out();
    spcInput_struct* _retn();

    operator spcInput_struct_cvPtr () const;

    operator spcInput_struct_vPtr& ();

    operator const spcInput_struct& () const;

    operator spcInput_struct& ();

    protected:
    spcInput_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_spcInput_struct;
    typedef spcInput_struct spcInput;
    typedef spcInput_struct_var spcInput_var;
    extern  ::CORBA::TypeCode_ptr _tc_spcInput;
    class  spcHoldActionResult_struct_var;
    struct  spcHoldActionResult_struct {
        typedef spcHoldActionResult_struct_var _var_type;
       ::CORBA::String_StructElem holdAction;
       ::stringSequence triggerRules;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       spcHoldActionResult_struct();
       spcHoldActionResult_struct(const spcHoldActionResult_struct&);
       spcHoldActionResult_struct& operator=(const spcHoldActionResult_struct&);
       static CORBA::Info<spcHoldActionResult_struct> spcHoldActionResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct spcHoldActionResult_struct


typedef spcHoldActionResult_struct* spcHoldActionResult_struct_vPtr;
typedef const spcHoldActionResult_struct* spcHoldActionResult_struct_cvPtr;

class  spcHoldActionResult_struct_var
{
    public:

    spcHoldActionResult_struct_var ();

    spcHoldActionResult_struct_var (spcHoldActionResult_struct *_p);

    spcHoldActionResult_struct_var (const spcHoldActionResult_struct_var &_s);

    spcHoldActionResult_struct_var &operator= (spcHoldActionResult_struct *_p);

    spcHoldActionResult_struct_var &operator= (const spcHoldActionResult_struct_var &_s);

    ~spcHoldActionResult_struct_var ();

    spcHoldActionResult_struct* operator-> ();

    const spcHoldActionResult_struct& in() const;
    spcHoldActionResult_struct& inout();
    spcHoldActionResult_struct*& out();
    spcHoldActionResult_struct* _retn();

    operator spcHoldActionResult_struct_cvPtr () const;

    operator spcHoldActionResult_struct_vPtr& ();

    operator const spcHoldActionResult_struct& () const;

    operator spcHoldActionResult_struct& ();

    protected:
    spcHoldActionResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_spcHoldActionResult_struct;
    typedef spcHoldActionResult_struct spcHoldActionResult;
    typedef spcHoldActionResult_struct_var spcHoldActionResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_spcHoldActionResult;
    class  spcCheckResultByRule_struct_var;
    struct  spcCheckResultByRule_struct {
        typedef spcCheckResultByRule_struct_var _var_type;
       ::CORBA::String_StructElem rule;
       ::CORBA::String_StructElem description;
       ::CORBA::String_StructElem returnCodeStatus;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       spcCheckResultByRule_struct();
       spcCheckResultByRule_struct(const spcCheckResultByRule_struct&);
       spcCheckResultByRule_struct& operator=(const spcCheckResultByRule_struct&);
       static CORBA::Info<spcCheckResultByRule_struct> spcCheckResultByRule_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct spcCheckResultByRule_struct


typedef spcCheckResultByRule_struct* spcCheckResultByRule_struct_vPtr;
typedef const spcCheckResultByRule_struct* spcCheckResultByRule_struct_cvPtr;

class  spcCheckResultByRule_struct_var
{
    public:

    spcCheckResultByRule_struct_var ();

    spcCheckResultByRule_struct_var (spcCheckResultByRule_struct *_p);

    spcCheckResultByRule_struct_var (const spcCheckResultByRule_struct_var &_s);

    spcCheckResultByRule_struct_var &operator= (spcCheckResultByRule_struct *_p);

    spcCheckResultByRule_struct_var &operator= (const spcCheckResultByRule_struct_var &_s);

    ~spcCheckResultByRule_struct_var ();

    spcCheckResultByRule_struct* operator-> ();

    const spcCheckResultByRule_struct& in() const;
    spcCheckResultByRule_struct& inout();
    spcCheckResultByRule_struct*& out();
    spcCheckResultByRule_struct* _retn();

    operator spcCheckResultByRule_struct_cvPtr () const;

    operator spcCheckResultByRule_struct_vPtr& ();

    operator const spcCheckResultByRule_struct& () const;

    operator spcCheckResultByRule_struct& ();

    protected:
    spcCheckResultByRule_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_spcCheckResultByRule_struct;
    typedef spcCheckResultByRule_struct spcCheckResultByRule;
    typedef spcCheckResultByRule_struct_var spcCheckResultByRule_var;
    extern  ::CORBA::TypeCode_ptr _tc_spcCheckResultByRule;
class  _IDL_SEQ_spcCheckResultByRuleSequence_0_var;
class  _IDL_SEQ_spcCheckResultByRuleSequence_0 {
    public:
        typedef _IDL_SEQ_spcCheckResultByRuleSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    spcCheckResultByRule *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_spcCheckResultByRuleSequence_0 ();
    _IDL_SEQ_spcCheckResultByRuleSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_spcCheckResultByRuleSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, spcCheckResultByRule* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_spcCheckResultByRuleSequence_0 (const _IDL_SEQ_spcCheckResultByRuleSequence_0&);

    ~_IDL_SEQ_spcCheckResultByRuleSequence_0 ();

    _IDL_SEQ_spcCheckResultByRuleSequence_0& operator= (const _IDL_SEQ_spcCheckResultByRuleSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    spcCheckResultByRule& operator [] (::CORBA::ULong indx);
    const spcCheckResultByRule& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    spcCheckResultByRule* get_buffer (::CORBA::Boolean orphan=0);
    const spcCheckResultByRule* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, spcCheckResultByRule* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, spcCheckResultByRule* src, spcCheckResultByRule* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, spcCheckResultByRule* data); 
  public:

    static spcCheckResultByRule* SOMLINK allocbuf(::CORBA::ULong nelems);
    static spcCheckResultByRule* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(spcCheckResultByRule* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_spcCheckResultByRuleSequence_0> spcCheckResultByRuleSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_spcCheckResultByRuleSequence_0* _IDL_SEQ_spcCheckResultByRuleSequence_0_vPtr;
typedef const _IDL_SEQ_spcCheckResultByRuleSequence_0* _IDL_SEQ_spcCheckResultByRuleSequence_0_cvPtr;

class  _IDL_SEQ_spcCheckResultByRuleSequence_0_var
{
    public:

    _IDL_SEQ_spcCheckResultByRuleSequence_0_var ();

    _IDL_SEQ_spcCheckResultByRuleSequence_0_var (_IDL_SEQ_spcCheckResultByRuleSequence_0 *_p);

    _IDL_SEQ_spcCheckResultByRuleSequence_0_var (const _IDL_SEQ_spcCheckResultByRuleSequence_0_var &_s);

    _IDL_SEQ_spcCheckResultByRuleSequence_0_var &operator= (_IDL_SEQ_spcCheckResultByRuleSequence_0 *_p);

    _IDL_SEQ_spcCheckResultByRuleSequence_0_var &operator= (const _IDL_SEQ_spcCheckResultByRuleSequence_0_var &_s);

    ~_IDL_SEQ_spcCheckResultByRuleSequence_0_var ();

    _IDL_SEQ_spcCheckResultByRuleSequence_0* operator-> ();

    operator _IDL_SEQ_spcCheckResultByRuleSequence_0_cvPtr () const;

    operator _IDL_SEQ_spcCheckResultByRuleSequence_0_vPtr& ();

    operator _IDL_SEQ_spcCheckResultByRuleSequence_0() const;

    const spcCheckResultByRule& operator[] (::CORBA::ULong index) const;
    spcCheckResultByRule& operator[] (::CORBA::ULong index);
    const spcCheckResultByRule& operator[] (int index) const;
    spcCheckResultByRule& operator[] (int index);
    const _IDL_SEQ_spcCheckResultByRuleSequence_0& in() const;
    _IDL_SEQ_spcCheckResultByRuleSequence_0& inout();
    _IDL_SEQ_spcCheckResultByRuleSequence_0*& out();
    _IDL_SEQ_spcCheckResultByRuleSequence_0* _retn();

    protected:
    _IDL_SEQ_spcCheckResultByRuleSequence_0 *_ptr;
};

    typedef _IDL_SEQ_spcCheckResultByRuleSequence_0 _spcCheckResultByRuleSequence_seq;
    typedef _IDL_SEQ_spcCheckResultByRuleSequence_0 _spcCheckResultByRuleSequence_seq_1;
    typedef _IDL_SEQ_spcCheckResultByRuleSequence_0 spcCheckResultByRuleSequence;
    typedef _IDL_SEQ_spcCheckResultByRuleSequence_0_var spcCheckResultByRuleSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_spcCheckResultByRuleSequence;
    class  spcChartResult_struct_var;
    struct  spcChartResult_struct {
        typedef spcChartResult_struct_var _var_type;
       ::CORBA::String_StructElem chartGroupID;
       ::CORBA::String_StructElem chartID;
       ::CORBA::String_StructElem chartType;
       ::CORBA::String_StructElem processTimestamp;
       ::CORBA::String_StructElem inputTimestamp;
       ::CORBA::String_StructElem chartRC;
       ::spcHoldActionResult equipmentHoldAction;
       ::spcHoldActionResult processHoldAction;
       ::spcHoldActionResult recipeHoldAction;
       ::spcHoldActionResult chamberHoldAction;
       ::CORBA::String_StructElem chamberID;
       ::spcHoldActionResult chamberRecipeHoldAction;
       ::spcHoldActionResult routeHoldAction;
       ::spcHoldActionResult equipmentAndRecipeHoldAction;
       ::spcHoldActionResult processAndEquipmentHoldAction;
       ::spcHoldActionResult operationAndEquipmentHoldAction;
       ::spcHoldActionResult lotHoldAction;
       ::spcHoldActionResult reticleHoldAction;
       ::spcCheckResultByRuleSequence returnCodes;
       ::CORBA::String_StructElem chartOwnerMailAddress;
       ::stringSequence chartSubOwnerMailAddresses;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       spcChartResult_struct();
       spcChartResult_struct(const spcChartResult_struct&);
       spcChartResult_struct& operator=(const spcChartResult_struct&);
       static CORBA::Info<spcChartResult_struct> spcChartResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct spcChartResult_struct


typedef spcChartResult_struct* spcChartResult_struct_vPtr;
typedef const spcChartResult_struct* spcChartResult_struct_cvPtr;

class  spcChartResult_struct_var
{
    public:

    spcChartResult_struct_var ();

    spcChartResult_struct_var (spcChartResult_struct *_p);

    spcChartResult_struct_var (const spcChartResult_struct_var &_s);

    spcChartResult_struct_var &operator= (spcChartResult_struct *_p);

    spcChartResult_struct_var &operator= (const spcChartResult_struct_var &_s);

    ~spcChartResult_struct_var ();

    spcChartResult_struct* operator-> ();

    const spcChartResult_struct& in() const;
    spcChartResult_struct& inout();
    spcChartResult_struct*& out();
    spcChartResult_struct* _retn();

    operator spcChartResult_struct_cvPtr () const;

    operator spcChartResult_struct_vPtr& ();

    operator const spcChartResult_struct& () const;

    operator spcChartResult_struct& ();

    protected:
    spcChartResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_spcChartResult_struct;
    typedef spcChartResult_struct spcChartResult;
    typedef spcChartResult_struct_var spcChartResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_spcChartResult;
class  _IDL_SEQ_spcChartResultSequence_0_var;
class  _IDL_SEQ_spcChartResultSequence_0 {
    public:
        typedef _IDL_SEQ_spcChartResultSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    spcChartResult *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_spcChartResultSequence_0 ();
    _IDL_SEQ_spcChartResultSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_spcChartResultSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, spcChartResult* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_spcChartResultSequence_0 (const _IDL_SEQ_spcChartResultSequence_0&);

    ~_IDL_SEQ_spcChartResultSequence_0 ();

    _IDL_SEQ_spcChartResultSequence_0& operator= (const _IDL_SEQ_spcChartResultSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    spcChartResult& operator [] (::CORBA::ULong indx);
    const spcChartResult& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    spcChartResult* get_buffer (::CORBA::Boolean orphan=0);
    const spcChartResult* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, spcChartResult* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, spcChartResult* src, spcChartResult* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, spcChartResult* data); 
  public:

    static spcChartResult* SOMLINK allocbuf(::CORBA::ULong nelems);
    static spcChartResult* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(spcChartResult* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_spcChartResultSequence_0> spcChartResultSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_spcChartResultSequence_0* _IDL_SEQ_spcChartResultSequence_0_vPtr;
typedef const _IDL_SEQ_spcChartResultSequence_0* _IDL_SEQ_spcChartResultSequence_0_cvPtr;

class  _IDL_SEQ_spcChartResultSequence_0_var
{
    public:

    _IDL_SEQ_spcChartResultSequence_0_var ();

    _IDL_SEQ_spcChartResultSequence_0_var (_IDL_SEQ_spcChartResultSequence_0 *_p);

    _IDL_SEQ_spcChartResultSequence_0_var (const _IDL_SEQ_spcChartResultSequence_0_var &_s);

    _IDL_SEQ_spcChartResultSequence_0_var &operator= (_IDL_SEQ_spcChartResultSequence_0 *_p);

    _IDL_SEQ_spcChartResultSequence_0_var &operator= (const _IDL_SEQ_spcChartResultSequence_0_var &_s);

    ~_IDL_SEQ_spcChartResultSequence_0_var ();

    _IDL_SEQ_spcChartResultSequence_0* operator-> ();

    operator _IDL_SEQ_spcChartResultSequence_0_cvPtr () const;

    operator _IDL_SEQ_spcChartResultSequence_0_vPtr& ();

    operator _IDL_SEQ_spcChartResultSequence_0() const;

    const spcChartResult& operator[] (::CORBA::ULong index) const;
    spcChartResult& operator[] (::CORBA::ULong index);
    const spcChartResult& operator[] (int index) const;
    spcChartResult& operator[] (int index);
    const _IDL_SEQ_spcChartResultSequence_0& in() const;
    _IDL_SEQ_spcChartResultSequence_0& inout();
    _IDL_SEQ_spcChartResultSequence_0*& out();
    _IDL_SEQ_spcChartResultSequence_0* _retn();

    protected:
    _IDL_SEQ_spcChartResultSequence_0 *_ptr;
};

    typedef _IDL_SEQ_spcChartResultSequence_0 _spcChartResultSequence_seq;
    typedef _IDL_SEQ_spcChartResultSequence_0 _spcChartResultSequence_seq_1;
    typedef _IDL_SEQ_spcChartResultSequence_0 spcChartResultSequence;
    typedef _IDL_SEQ_spcChartResultSequence_0_var spcChartResultSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_spcChartResultSequence;
    class  spcItemResult_struct_var;
    struct  spcItemResult_struct {
        typedef spcItemResult_struct_var _var_type;
       ::CORBA::String_StructElem dataItemName;
       ::spcChartResultSequence chartResults;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       spcItemResult_struct();
       spcItemResult_struct(const spcItemResult_struct&);
       spcItemResult_struct& operator=(const spcItemResult_struct&);
       static CORBA::Info<spcItemResult_struct> spcItemResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct spcItemResult_struct


typedef spcItemResult_struct* spcItemResult_struct_vPtr;
typedef const spcItemResult_struct* spcItemResult_struct_cvPtr;

class  spcItemResult_struct_var
{
    public:

    spcItemResult_struct_var ();

    spcItemResult_struct_var (spcItemResult_struct *_p);

    spcItemResult_struct_var (const spcItemResult_struct_var &_s);

    spcItemResult_struct_var &operator= (spcItemResult_struct *_p);

    spcItemResult_struct_var &operator= (const spcItemResult_struct_var &_s);

    ~spcItemResult_struct_var ();

    spcItemResult_struct* operator-> ();

    const spcItemResult_struct& in() const;
    spcItemResult_struct& inout();
    spcItemResult_struct*& out();
    spcItemResult_struct* _retn();

    operator spcItemResult_struct_cvPtr () const;

    operator spcItemResult_struct_vPtr& ();

    operator const spcItemResult_struct& () const;

    operator spcItemResult_struct& ();

    protected:
    spcItemResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_spcItemResult_struct;
    typedef spcItemResult_struct spcItemResult;
    typedef spcItemResult_struct_var spcItemResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_spcItemResult;
class  _IDL_SEQ_spcItemResultSequence_0_var;
class  _IDL_SEQ_spcItemResultSequence_0 {
    public:
        typedef _IDL_SEQ_spcItemResultSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    spcItemResult *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_spcItemResultSequence_0 ();
    _IDL_SEQ_spcItemResultSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_spcItemResultSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, spcItemResult* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_spcItemResultSequence_0 (const _IDL_SEQ_spcItemResultSequence_0&);

    ~_IDL_SEQ_spcItemResultSequence_0 ();

    _IDL_SEQ_spcItemResultSequence_0& operator= (const _IDL_SEQ_spcItemResultSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    spcItemResult& operator [] (::CORBA::ULong indx);
    const spcItemResult& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    spcItemResult* get_buffer (::CORBA::Boolean orphan=0);
    const spcItemResult* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, spcItemResult* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, spcItemResult* src, spcItemResult* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, spcItemResult* data); 
  public:

    static spcItemResult* SOMLINK allocbuf(::CORBA::ULong nelems);
    static spcItemResult* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(spcItemResult* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_spcItemResultSequence_0> spcItemResultSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_spcItemResultSequence_0* _IDL_SEQ_spcItemResultSequence_0_vPtr;
typedef const _IDL_SEQ_spcItemResultSequence_0* _IDL_SEQ_spcItemResultSequence_0_cvPtr;

class  _IDL_SEQ_spcItemResultSequence_0_var
{
    public:

    _IDL_SEQ_spcItemResultSequence_0_var ();

    _IDL_SEQ_spcItemResultSequence_0_var (_IDL_SEQ_spcItemResultSequence_0 *_p);

    _IDL_SEQ_spcItemResultSequence_0_var (const _IDL_SEQ_spcItemResultSequence_0_var &_s);

    _IDL_SEQ_spcItemResultSequence_0_var &operator= (_IDL_SEQ_spcItemResultSequence_0 *_p);

    _IDL_SEQ_spcItemResultSequence_0_var &operator= (const _IDL_SEQ_spcItemResultSequence_0_var &_s);

    ~_IDL_SEQ_spcItemResultSequence_0_var ();

    _IDL_SEQ_spcItemResultSequence_0* operator-> ();

    operator _IDL_SEQ_spcItemResultSequence_0_cvPtr () const;

    operator _IDL_SEQ_spcItemResultSequence_0_vPtr& ();

    operator _IDL_SEQ_spcItemResultSequence_0() const;

    const spcItemResult& operator[] (::CORBA::ULong index) const;
    spcItemResult& operator[] (::CORBA::ULong index);
    const spcItemResult& operator[] (int index) const;
    spcItemResult& operator[] (int index);
    const _IDL_SEQ_spcItemResultSequence_0& in() const;
    _IDL_SEQ_spcItemResultSequence_0& inout();
    _IDL_SEQ_spcItemResultSequence_0*& out();
    _IDL_SEQ_spcItemResultSequence_0* _retn();

    protected:
    _IDL_SEQ_spcItemResultSequence_0 *_ptr;
};

    typedef _IDL_SEQ_spcItemResultSequence_0 _spcItemResultSequence_seq;
    typedef _IDL_SEQ_spcItemResultSequence_0 _spcItemResultSequence_seq_1;
    typedef _IDL_SEQ_spcItemResultSequence_0 spcItemResultSequence;
    typedef _IDL_SEQ_spcItemResultSequence_0_var spcItemResultSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_spcItemResultSequence;
    class  spcChamberHoldAction_struct_var;
    struct  spcChamberHoldAction_struct {
        typedef spcChamberHoldAction_struct_var _var_type;
       ::CORBA::String_StructElem chamberID;
       ::CORBA::String_StructElem chamberHoldAction;
       ::CORBA::String_StructElem chamberRecipeHoldAction;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       spcChamberHoldAction_struct();
       spcChamberHoldAction_struct(const spcChamberHoldAction_struct&);
       spcChamberHoldAction_struct& operator=(const spcChamberHoldAction_struct&);
       static CORBA::Info<spcChamberHoldAction_struct> spcChamberHoldAction_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct spcChamberHoldAction_struct


typedef spcChamberHoldAction_struct* spcChamberHoldAction_struct_vPtr;
typedef const spcChamberHoldAction_struct* spcChamberHoldAction_struct_cvPtr;

class  spcChamberHoldAction_struct_var
{
    public:

    spcChamberHoldAction_struct_var ();

    spcChamberHoldAction_struct_var (spcChamberHoldAction_struct *_p);

    spcChamberHoldAction_struct_var (const spcChamberHoldAction_struct_var &_s);

    spcChamberHoldAction_struct_var &operator= (spcChamberHoldAction_struct *_p);

    spcChamberHoldAction_struct_var &operator= (const spcChamberHoldAction_struct_var &_s);

    ~spcChamberHoldAction_struct_var ();

    spcChamberHoldAction_struct* operator-> ();

    const spcChamberHoldAction_struct& in() const;
    spcChamberHoldAction_struct& inout();
    spcChamberHoldAction_struct*& out();
    spcChamberHoldAction_struct* _retn();

    operator spcChamberHoldAction_struct_cvPtr () const;

    operator spcChamberHoldAction_struct_vPtr& ();

    operator const spcChamberHoldAction_struct& () const;

    operator spcChamberHoldAction_struct& ();

    protected:
    spcChamberHoldAction_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_spcChamberHoldAction_struct;
    typedef spcChamberHoldAction_struct spcChamberHoldAction;
    typedef spcChamberHoldAction_struct_var spcChamberHoldAction_var;
    extern  ::CORBA::TypeCode_ptr _tc_spcChamberHoldAction;
class  _IDL_SEQ_spcChamberHoldActionSequence_0_var;
class  _IDL_SEQ_spcChamberHoldActionSequence_0 {
    public:
        typedef _IDL_SEQ_spcChamberHoldActionSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    spcChamberHoldAction *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_spcChamberHoldActionSequence_0 ();
    _IDL_SEQ_spcChamberHoldActionSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_spcChamberHoldActionSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, spcChamberHoldAction* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_spcChamberHoldActionSequence_0 (const _IDL_SEQ_spcChamberHoldActionSequence_0&);

    ~_IDL_SEQ_spcChamberHoldActionSequence_0 ();

    _IDL_SEQ_spcChamberHoldActionSequence_0& operator= (const _IDL_SEQ_spcChamberHoldActionSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    spcChamberHoldAction& operator [] (::CORBA::ULong indx);
    const spcChamberHoldAction& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    spcChamberHoldAction* get_buffer (::CORBA::Boolean orphan=0);
    const spcChamberHoldAction* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, spcChamberHoldAction* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, spcChamberHoldAction* src, spcChamberHoldAction* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, spcChamberHoldAction* data); 
  public:

    static spcChamberHoldAction* SOMLINK allocbuf(::CORBA::ULong nelems);
    static spcChamberHoldAction* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(spcChamberHoldAction* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_spcChamberHoldActionSequence_0> spcChamberHoldActionSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_spcChamberHoldActionSequence_0* _IDL_SEQ_spcChamberHoldActionSequence_0_vPtr;
typedef const _IDL_SEQ_spcChamberHoldActionSequence_0* _IDL_SEQ_spcChamberHoldActionSequence_0_cvPtr;

class  _IDL_SEQ_spcChamberHoldActionSequence_0_var
{
    public:

    _IDL_SEQ_spcChamberHoldActionSequence_0_var ();

    _IDL_SEQ_spcChamberHoldActionSequence_0_var (_IDL_SEQ_spcChamberHoldActionSequence_0 *_p);

    _IDL_SEQ_spcChamberHoldActionSequence_0_var (const _IDL_SEQ_spcChamberHoldActionSequence_0_var &_s);

    _IDL_SEQ_spcChamberHoldActionSequence_0_var &operator= (_IDL_SEQ_spcChamberHoldActionSequence_0 *_p);

    _IDL_SEQ_spcChamberHoldActionSequence_0_var &operator= (const _IDL_SEQ_spcChamberHoldActionSequence_0_var &_s);

    ~_IDL_SEQ_spcChamberHoldActionSequence_0_var ();

    _IDL_SEQ_spcChamberHoldActionSequence_0* operator-> ();

    operator _IDL_SEQ_spcChamberHoldActionSequence_0_cvPtr () const;

    operator _IDL_SEQ_spcChamberHoldActionSequence_0_vPtr& ();

    operator _IDL_SEQ_spcChamberHoldActionSequence_0() const;

    const spcChamberHoldAction& operator[] (::CORBA::ULong index) const;
    spcChamberHoldAction& operator[] (::CORBA::ULong index);
    const spcChamberHoldAction& operator[] (int index) const;
    spcChamberHoldAction& operator[] (int index);
    const _IDL_SEQ_spcChamberHoldActionSequence_0& in() const;
    _IDL_SEQ_spcChamberHoldActionSequence_0& inout();
    _IDL_SEQ_spcChamberHoldActionSequence_0*& out();
    _IDL_SEQ_spcChamberHoldActionSequence_0* _retn();

    protected:
    _IDL_SEQ_spcChamberHoldActionSequence_0 *_ptr;
};

    typedef _IDL_SEQ_spcChamberHoldActionSequence_0 _spcChamberHoldActionSequence_seq;
    typedef _IDL_SEQ_spcChamberHoldActionSequence_0 _spcChamberHoldActionSequence_seq_1;
    typedef _IDL_SEQ_spcChamberHoldActionSequence_0 spcChamberHoldActionSequence;
    typedef _IDL_SEQ_spcChamberHoldActionSequence_0_var spcChamberHoldActionSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_spcChamberHoldActionSequence;
    class  spcOutput_struct_var;
    struct  spcOutput_struct {
        typedef spcOutput_struct_var _var_type;
       ::CORBA::String_StructElem txRC;
       ::objectIdentifier lotID;
       ::CORBA::String_StructElem lotRC;
       ::CORBA::String_StructElem lotHoldAction;
       ::spcChamberHoldActionSequence chamberHoldActions;
       ::CORBA::String_StructElem equipmentHoldAction;
       ::CORBA::String_StructElem processHoldAction;
       ::CORBA::String_StructElem recipeHoldAction;
       ::CORBA::String_StructElem reworkBranchAction;
       ::CORBA::String_StructElem mailSendAction;
       ::CORBA::String_StructElem bankMoveAction;
       ::CORBA::String_StructElem bankID;
       ::CORBA::String_StructElem reworkRouteID;
       ::CORBA::String_StructElem productHoldAction;
       ::CORBA::String_StructElem reticleHoldAction;
       ::CORBA::String_StructElem reticleGroupHoldAction;
       ::CORBA::String_StructElem moduleHoldAction;
       ::CORBA::String_StructElem routeHoldAction;
       ::CORBA::String_StructElem routeOpeNoProductHoldAction;
       ::CORBA::String_StructElem eqptRecipeHoldAction;
       ::CORBA::String_StructElem eqptOpeNoHoldAction;
       ::CORBA::String_StructElem eqptRecticleHoldAction;
       ::CORBA::String_StructElem eqptProcessHoldAction;
       ::CORBA::String_StructElem eqptChamberRecipeHoldAction;
       ::CORBA::String_StructElem eqptProductRecipeHoldAction;
       ::CORBA::String_StructElem routeOpeNoHoldAction;
       ::CORBA::String_StructElem eqptChamberHoldAction;
       ::CORBA::String_StructElem otherAction;
       ::spcItemResultSequence itemResults;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       spcOutput_struct();
       spcOutput_struct(const spcOutput_struct&);
       spcOutput_struct& operator=(const spcOutput_struct&);
       static CORBA::Info<spcOutput_struct> spcOutput_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct spcOutput_struct


typedef spcOutput_struct* spcOutput_struct_vPtr;
typedef const spcOutput_struct* spcOutput_struct_cvPtr;

class  spcOutput_struct_var
{
    public:

    spcOutput_struct_var ();

    spcOutput_struct_var (spcOutput_struct *_p);

    spcOutput_struct_var (const spcOutput_struct_var &_s);

    spcOutput_struct_var &operator= (spcOutput_struct *_p);

    spcOutput_struct_var &operator= (const spcOutput_struct_var &_s);

    ~spcOutput_struct_var ();

    spcOutput_struct* operator-> ();

    const spcOutput_struct& in() const;
    spcOutput_struct& inout();
    spcOutput_struct*& out();
    spcOutput_struct* _retn();

    operator spcOutput_struct_cvPtr () const;

    operator spcOutput_struct_vPtr& ();

    operator const spcOutput_struct& () const;

    operator spcOutput_struct& ();

    protected:
    spcOutput_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_spcOutput_struct;
    typedef spcOutput_struct spcOutput;
    typedef spcOutput_struct_var spcOutput_var;
    extern  ::CORBA::TypeCode_ptr _tc_spcOutput;
#endif   
/*
 * Guard codes of CORBA::Any operators.
 */
#ifdef __NOTUSE_ANYOPERATOR__
#define __NOTUSE_cs_spcsvrstr_ANYOPERATOR__
#endif //__NOTUSE_ANYOPERATOR__

#ifdef __USE_cs_spcsvrstr_ANYOPERATOR__
#undef __NOTUSE_cs_spcsvrstr_ANYOPERATOR__
#endif //__USE_cs_spcsvrstr_ANYOPERATOR__
#ifndef __NOTUSE_cs_spcsvrstr_ANYOPERATOR__
#define _DCL_ANYOPS_spcDcItem_struct
#define _DCL_ANYOPS_spcDcItemSequence
#define _DCL_ANYOPS_spcWaferIDByChamber_struct
#define _DCL_ANYOPS_spcWaferIDByChamberSequence
#define _DCL_ANYOPS_spcInput_struct
#define _DCL_ANYOPS_spcHoldActionResult_struct
#define _DCL_ANYOPS_spcCheckResultByRule_struct
#define _DCL_ANYOPS_spcCheckResultByRuleSequence
#define _DCL_ANYOPS_spcChartResult_struct
#define _DCL_ANYOPS_spcChartResultSequence
#define _DCL_ANYOPS_spcItemResult_struct
#define _DCL_ANYOPS_spcItemResultSequence
#define _DCL_ANYOPS_spcChamberHoldAction_struct
#define _DCL_ANYOPS_spcChamberHoldActionSequence
#define _DCL_ANYOPS_spcOutput_struct
#endif //__NOTUSE_cs_spcsvrstr_ANYOPERATOR__

/*
 * Overloaded CORBA::Any operators.
 */
#ifdef _DCL_ANYOPS_spcDcItem_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::spcDcItem_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::spcDcItem_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcDcItem_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcDcItem_struct*& _data);
#endif
#endif // _DCL_ANYOPS_spcDcItem_struct
#ifdef _DCL_ANYOPS_spcDcItemSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::spcDcItemSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::spcDcItemSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcDcItemSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcDcItemSequence*& _data);
#endif
#endif // _DCL_ANYOPS_spcDcItemSequence
#ifdef _DCL_ANYOPS_spcWaferIDByChamber_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::spcWaferIDByChamber_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::spcWaferIDByChamber_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcWaferIDByChamber_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcWaferIDByChamber_struct*& _data);
#endif
#endif // _DCL_ANYOPS_spcWaferIDByChamber_struct
#ifdef _DCL_ANYOPS_spcWaferIDByChamberSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::spcWaferIDByChamberSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::spcWaferIDByChamberSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcWaferIDByChamberSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcWaferIDByChamberSequence*& _data);
#endif
#endif // _DCL_ANYOPS_spcWaferIDByChamberSequence
#ifdef _DCL_ANYOPS_spcInput_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::spcInput_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::spcInput_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcInput_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcInput_struct*& _data);
#endif
#endif // _DCL_ANYOPS_spcInput_struct
#ifdef _DCL_ANYOPS_spcHoldActionResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::spcHoldActionResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::spcHoldActionResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcHoldActionResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcHoldActionResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_spcHoldActionResult_struct
#ifdef _DCL_ANYOPS_spcCheckResultByRule_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::spcCheckResultByRule_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::spcCheckResultByRule_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcCheckResultByRule_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcCheckResultByRule_struct*& _data);
#endif
#endif // _DCL_ANYOPS_spcCheckResultByRule_struct
#ifdef _DCL_ANYOPS_spcCheckResultByRuleSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::spcCheckResultByRuleSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::spcCheckResultByRuleSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcCheckResultByRuleSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcCheckResultByRuleSequence*& _data);
#endif
#endif // _DCL_ANYOPS_spcCheckResultByRuleSequence
#ifdef _DCL_ANYOPS_spcChartResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::spcChartResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::spcChartResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcChartResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcChartResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_spcChartResult_struct
#ifdef _DCL_ANYOPS_spcChartResultSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::spcChartResultSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::spcChartResultSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcChartResultSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcChartResultSequence*& _data);
#endif
#endif // _DCL_ANYOPS_spcChartResultSequence
#ifdef _DCL_ANYOPS_spcItemResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::spcItemResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::spcItemResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcItemResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcItemResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_spcItemResult_struct
#ifdef _DCL_ANYOPS_spcItemResultSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::spcItemResultSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::spcItemResultSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcItemResultSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcItemResultSequence*& _data);
#endif
#endif // _DCL_ANYOPS_spcItemResultSequence
#ifdef _DCL_ANYOPS_spcChamberHoldAction_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::spcChamberHoldAction_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::spcChamberHoldAction_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcChamberHoldAction_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcChamberHoldAction_struct*& _data);
#endif
#endif // _DCL_ANYOPS_spcChamberHoldAction_struct
#ifdef _DCL_ANYOPS_spcChamberHoldActionSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::spcChamberHoldActionSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::spcChamberHoldActionSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcChamberHoldActionSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcChamberHoldActionSequence*& _data);
#endif
#endif // _DCL_ANYOPS_spcChamberHoldActionSequence
#ifdef _DCL_ANYOPS_spcOutput_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::spcOutput_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::spcOutput_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcOutput_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcOutput_struct*& _data);
#endif
#endif // _DCL_ANYOPS_spcOutput_struct

#endif /* _cs_spcsvrstr_hh_included */

#endif /* _cs_spcsvrstr_server_defined */
