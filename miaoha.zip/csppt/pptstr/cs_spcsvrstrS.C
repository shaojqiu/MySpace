//----------------------------------------------------------------------------
//
//  Generated from cs_spcsvrstr.idl
//  On Wednesday, November 1, 2017 2:36:21 PM GMT+07:00
//  by IBM CORBA 2.3 (sc) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#define _cs_spcsvrstr_bindings_defined
#ifdef SOMCBNOLOCALINCLUDES
#include <cs_spcsvrstr.hh>
#else
#include "cs_spcsvrstr.hh"
#endif
#define _cs_spcsvrstr_server_defined
#ifdef SOMCBNOLOCALINCLUDES
#include <cs_spcsvrstrC.C>
#else
#include "cs_spcsvrstrC.C"
#endif

