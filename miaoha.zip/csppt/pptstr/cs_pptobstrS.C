//----------------------------------------------------------------------------
//
//  Generated from cs_pptobstr.idl
//  On Thursday, November 2, 2017 7:15:49 PM GMT+07:00
//  by IBM CORBA 2.3 (sc) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#define _cs_pptobstr_bindings_defined
#ifdef SOMCBNOLOCALINCLUDES
#include <cs_pptobstr.hh>
#else
#include "cs_pptobstr.hh"
#endif
#define _cs_pptobstr_server_defined
#ifdef SOMCBNOLOCALINCLUDES
#include <cs_pptobstrC.C>
#else
#include "cs_pptobstrC.C"
#endif

