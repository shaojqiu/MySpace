//----------------------------------------------------------------------------
//
//  Generated from cs_spcsvrstr.idl
//  On Wednesday, November 1, 2017 2:36:21 PM GMT+07:00
//  by IBM CORBA 2.3 (uc) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _cs_spcsvrstr_bindings_defined
#define _cs_spcsvrstr_bindings_defined
#endif 
#ifdef SOMCBNOLOCALINCLUDES
#include <cs_spcsvrstr.hh>
#else
#include "cs_spcsvrstr.hh"
#endif
#ifdef SIVIEW_EBROKER
 #ifdef linux
  #include <new>
 #else
  #include <new.h>
 #endif
#endif


#ifdef _AIX
#ifndef _UNIX
#define _UNIX
#endif
#endif
#include <private/wasdpriv.h>
#include <assert.h>

enum BoundaryCheckMode { BCM_None, BCM_Logging, BCM_Exception, BCM_Assertion };

#define SOMD_BOUNDARY_CHECK_ERROR(checkMode,index,maxlength)\
    switch(checkMode)\
    {\
    case BCM_Logging:\
            somdLogMsg( __FILE__, __LINE__,SOMRAS_EL_SEVERITY_ERROR,"",WASMessage(WASL_MSG_6S, WASLog::WASLogSvcCatalogName)<<"Boundary check error at " << __FUNCTION__ << ". index:" << index << ", "  #maxlength " :" << maxlength );\
            break;\
    case BCM_Exception:\
            throw CORBA::BAD_PARAM(SOMDMINOR_BAD_PARAM_OTHER,CORBA::COMPLETED_NO);\
            break;\
    case BCM_Assertion:\
            assert( index < maxlength );\
            break;\
    case BCM_None:\
    default:\
            break;\
    }\

static BoundaryCheckMode boundaryCheck_Maximum = BCM_None;
static BoundaryCheckMode boundaryCheck_Length = BCM_None;

static void __cs_spcsvrstr_initialize()
{
    class __cs_spcsvrstr_initializer
    {
    public:
        __cs_spcsvrstr_initializer()
        {
            boundaryCheck_Length = (BoundaryCheckMode)WasGetParmInt("com.ibm.CORBA.actionForBoundaryCheckOfSequenceLength", (int)BCM_None );
            boundaryCheck_Maximum = (BoundaryCheckMode)WasGetParmInt("com.ibm.CORBA.actionForBoundaryCheckOfSequenceMaxLength", (int)BCM_Logging );
        }
    };
    static __cs_spcsvrstr_initializer initialize;
}


void spcDcItem_struct::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("dataItemName");
    _req.encode_string_op(dataItemName);
    _req.setVarName("waferID");
    _req.encode_string_op(waferID);
    _req.setVarName("waferPosition");
    _req.encode_string_op(waferPosition);
    _req.setVarName("sitePosition");
    _req.encode_string_op(sitePosition);
    _req.setVarName("dataValue");
    dataValue.encodeOp(_req);
    _req.setVarName("targetValue");
    _req << targetValue;
    _req.setVarName("specCheckResult");
    _req.encode_string_op(specCheckResult);
    _req.setVarName("comment");
    _req.encode_string_op(comment);
    _req.setVarName("chamber_list");
    _req.encode_string_op(chamber_list);
    _req.setVarName("siInfo");
    siInfo.encodeOp(_req);
    _req.encodeEndStructure();
}

void spcDcItem_struct::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("dataItemName");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        dataItemName = _s;
    }
    _req.setVarName("waferID");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        waferID = _s;
    }
    _req.setVarName("waferPosition");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        waferPosition = _s;
    }
    _req.setVarName("sitePosition");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        sitePosition = _s;
    }
    _req.setVarName("dataValue");
    dataValue.decodeOp(_req);
    _req.setVarName("targetValue");
    _req >> targetValue;
    _req.setVarName("specCheckResult");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        specCheckResult = _s;
    }
    _req.setVarName("comment");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        comment = _s;
    }
    _req.setVarName("chamber_list");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chamber_list = _s;
    }
    _req.setVarName("siInfo");
    siInfo.decodeOp(_req);
    _req.decodeEndStructure();
}

void spcDcItem_struct::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("dataItemName");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        dataItemName = _s;
    }
    _req.setVarName("waferID");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        waferID = _s;
    }
    _req.setVarName("waferPosition");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        waferPosition = _s;
    }
    _req.setVarName("sitePosition");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        sitePosition = _s;
    }
    _req.setVarName("dataValue");
    dataValue.decodeInOutOp(_req);
    _req.setVarName("targetValue");
    _req >> targetValue;
    _req.setVarName("specCheckResult");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        specCheckResult = _s;
    }
    _req.setVarName("comment");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        comment = _s;
    }
    _req.setVarName("chamber_list");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chamber_list = _s;
    }
    _req.setVarName("siInfo");
    siInfo.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 spcDcItem_struct::__stubcode_version;
spcDcItem_struct::spcDcItem_struct()
{
}
spcDcItem_struct::spcDcItem_struct( const ::spcDcItem_struct &EB_s )
{
    operator=( EB_s );
}
spcDcItem_struct& spcDcItem_struct::operator=( const ::spcDcItem_struct &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   dataItemName = EB_s.dataItemName;
   waferID = EB_s.waferID;
   waferPosition = EB_s.waferPosition;
   sitePosition = EB_s.sitePosition;
   dataValue = EB_s.dataValue;
   targetValue = EB_s.targetValue;
   specCheckResult = EB_s.specCheckResult;
   comment = EB_s.comment;
   chamber_list = EB_s.chamber_list;
   siInfo = EB_s.siInfo;
   return *this;
}
spcDcItem_struct_var::spcDcItem_struct_var () {
   _ptr = 0;
}
spcDcItem_struct_var::spcDcItem_struct_var (::spcDcItem_struct*_p) {
   _ptr = _p;
}
spcDcItem_struct_var::spcDcItem_struct_var (const ::spcDcItem_struct_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::spcDcItem_struct ();
   *(_ptr) = *(_s._ptr);
}
spcDcItem_struct_var& spcDcItem_struct_var::operator= (::spcDcItem_struct *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

spcDcItem_struct_var& spcDcItem_struct_var::operator= (const ::spcDcItem_struct_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::spcDcItem_struct ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

spcDcItem_struct_var::~spcDcItem_struct_var () {
   delete _ptr;
}

::spcDcItem_struct * spcDcItem_struct_var::operator-> ()
{ return _ptr; }

spcDcItem_struct_var::operator ::spcDcItem_struct_cvPtr () const 
{ return _ptr;}

spcDcItem_struct_var::operator ::spcDcItem_struct_vPtr& () 
{ return _ptr;}

spcDcItem_struct_var::operator const ::spcDcItem_struct& () const 
{ return *_ptr;}

spcDcItem_struct_var::operator ::spcDcItem_struct& () 
{ return *_ptr;}

const ::spcDcItem_struct& spcDcItem_struct_var::in () const { return *_ptr; }
::spcDcItem_struct& spcDcItem_struct_var::inout () { return *_ptr; }
::spcDcItem_struct*& spcDcItem_struct_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::spcDcItem_struct* spcDcItem_struct_var::_retn () {
  // yield ownership 
  spcDcItem_struct* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::spcDcItem_struct > spcDcItem_struct::spcDcItem_struct_Info;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_spcDcItemSequence_0::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_spcDcItemSequence_0::__stubcode_dependents[] = {::spcSpcDcItem::__stubcode_version };
_IDL_SEQ_spcDcItemSequence_0::_IDL_SEQ_spcDcItemSequence_0()
{
  _defaultInit();
}
_IDL_SEQ_spcDcItemSequence_0::_IDL_SEQ_spcDcItemSequence_0 (const ::_IDL_SEQ_spcDcItemSequence_0& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_spcDcItemSequence_0::_IDL_SEQ_spcDcItemSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, ::spcSpcDcItem* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
  _maximum = max;
}
_IDL_SEQ_spcDcItemSequence_0::_IDL_SEQ_spcDcItemSequence_0 (::CORBA::ULong max)
{
  _defaultInit();
  _maximum = max;
  if (_maximum > 0)
    _buffer = allocbuf_throw (max);
}
_IDL_SEQ_spcDcItemSequence_0::~_IDL_SEQ_spcDcItemSequence_0 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_spcDcItemSequence_0::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer  = NULL;
  _maximum = 0;
}
::spcSpcDcItem* _IDL_SEQ_spcDcItemSequence_0::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  // Allocate an array of the element type (which may be a
  // self managed StructElem)
#ifdef SIVIEW_EBROKER
  ::spcSpcDcItem* _ret;
  ::CORBA::ULong alloc_len = sizeof(::spcSpcDcItem) * nelems + sizeof(::CORBA::ULong);
  ::CORBA::ULong * tmp = (::CORBA::ULong *)malloc( alloc_len );
  if( tmp )
  {
    memset( tmp, 0, alloc_len );
    *tmp = nelems;
    tmp++;
    _ret = (::spcSpcDcItem*)tmp;
    for( CORBA::ULong _index = 0; _index < nelems; _index++ )
    {
      (void)new ((void*)( _ret + _index)) ::spcSpcDcItem;
    }
  }
  return _ret;
#else
  return (::spcSpcDcItem*) new ::spcSpcDcItem[nelems];
#endif
}
::spcSpcDcItem* _IDL_SEQ_spcDcItemSequence_0::allocbuf_throw (::CORBA::ULong nelems)
{
  ::spcSpcDcItem* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_spcDcItemSequence_0::freebuf (::spcSpcDcItem* _data)
{
#ifdef SIVIEW_EBROKER
  if (_data)
  {
    ::CORBA::ULong * tmp = (CORBA::ULong *)_data;
    tmp--;
    for( CORBA::ULong _index = *tmp; _index; _index-- )
    {
    #ifdef _WIN32
      _data[ _index - 1 ].~spcDcItem_struct ();
    #else
      _data[ _index - 1 ].::spcSpcDcItem::~spcDcItem_struct ();
    #endif
    }
    free(tmp);
  }
#else
  if (_data)
    delete [] (::spcSpcDcItem*) _data;
#endif
}
void _IDL_SEQ_spcDcItemSequence_0::replace (::CORBA::ULong max,  ::CORBA::ULong length, ::spcSpcDcItem* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
  _maximum = max;
}
::_IDL_SEQ_spcDcItemSequence_0& _IDL_SEQ_spcDcItemSequence_0::operator= (const ::_IDL_SEQ_spcDcItemSequence_0& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  _maximum = max;
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_spcDcItemSequence_0::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::spcSpcDcItem* data)
{
  return; // simple elements don't require resetting.
}
void _IDL_SEQ_spcDcItemSequence_0::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::spcSpcDcItem* src, ::spcSpcDcItem* tgt)
{
  // Copy elements 
  ::spcSpcDcItem* _src = (::spcSpcDcItem*) src;
  ::spcSpcDcItem* _tgt = (::spcSpcDcItem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_spcDcItemSequence_0::maximum () const
{
  return   _maximum;
;
}
::CORBA::ULong _IDL_SEQ_spcDcItemSequence_0::length () const
{
  return _length;
}
void _IDL_SEQ_spcDcItemSequence_0::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  ::spcSpcDcItem* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace(max, len, newBuffer, 1);
  return;
}
::spcSpcDcItem& _IDL_SEQ_spcDcItemSequence_0::operator[] (::CORBA::ULong i)
{
  __cs_spcsvrstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return _buffer[i];
}
const ::spcSpcDcItem& _IDL_SEQ_spcDcItemSequence_0::operator[] (::CORBA::ULong i) const 
{
  __cs_spcsvrstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return ((const ::spcSpcDcItem*)_buffer) [i];
}
::CORBA::Boolean _IDL_SEQ_spcDcItemSequence_0::release() const 
{ return _release; }
::spcSpcDcItem* _IDL_SEQ_spcDcItemSequence_0::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::spcSpcDcItem* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::spcSpcDcItem* _IDL_SEQ_spcDcItemSequence_0::get_buffer () const
{
    return (const ::spcSpcDcItem*) _buffer;
}
void _IDL_SEQ_spcDcItemSequence_0::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       ::spcDcItem_struct const* _elem =     (::spcDcItem_struct*) _buffer;
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
           _elem->encodeOp(_req);
       }
    }
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_spcDcItemSequence_0::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
      ::spcDcItem_struct* _elem = (::spcDcItem_struct*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_spcDcItemSequence_0::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(max,__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
      ::spcDcItem_struct* _elem = (::spcDcItem_struct*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeInOutOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_spcDcItemSequence_0_var::_IDL_SEQ_spcDcItemSequence_0_var () {
   _ptr = 0;
    }

_IDL_SEQ_spcDcItemSequence_0_var::_IDL_SEQ_spcDcItemSequence_0_var (::_IDL_SEQ_spcDcItemSequence_0 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_spcDcItemSequence_0_var::_IDL_SEQ_spcDcItemSequence_0_var (const ::_IDL_SEQ_spcDcItemSequence_0_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_spcDcItemSequence_0 (*(_s._ptr));
    }

_IDL_SEQ_spcDcItemSequence_0_var& _IDL_SEQ_spcDcItemSequence_0_var::operator= (::_IDL_SEQ_spcDcItemSequence_0 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_spcDcItemSequence_0_var& _IDL_SEQ_spcDcItemSequence_0_var::operator= (const ::_IDL_SEQ_spcDcItemSequence_0_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_spcDcItemSequence_0 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_spcDcItemSequence_0_var::~_IDL_SEQ_spcDcItemSequence_0_var()
{
   delete _ptr;
}
::_IDL_SEQ_spcDcItemSequence_0 * _IDL_SEQ_spcDcItemSequence_0_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_spcDcItemSequence_0_var::operator ::_IDL_SEQ_spcDcItemSequence_0_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_spcDcItemSequence_0_var::operator ::_IDL_SEQ_spcDcItemSequence_0_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_spcDcItemSequence_0_var::operator _IDL_SEQ_spcDcItemSequence_0() const
{
   return *_ptr;
}
const ::spcSpcDcItem& _IDL_SEQ_spcDcItemSequence_0_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_spcDcItemSequence_0 *)_ptr)[index];
}
::spcSpcDcItem& _IDL_SEQ_spcDcItemSequence_0_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::spcSpcDcItem& _IDL_SEQ_spcDcItemSequence_0_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_spcDcItemSequence_0 *)_ptr)[index];
}
::spcSpcDcItem& _IDL_SEQ_spcDcItemSequence_0_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_spcDcItemSequence_0& _IDL_SEQ_spcDcItemSequence_0_var::in () const { return *_ptr; }
::_IDL_SEQ_spcDcItemSequence_0& _IDL_SEQ_spcDcItemSequence_0_var::inout () { return *_ptr; }
::_IDL_SEQ_spcDcItemSequence_0*& _IDL_SEQ_spcDcItemSequence_0_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_spcDcItemSequence_0* _IDL_SEQ_spcDcItemSequence_0_var::_retn () {
  // yield ownership 
  _IDL_SEQ_spcDcItemSequence_0* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_spcDcItemSequence_0 > _IDL_SEQ_spcDcItemSequence_0::spcDcItemSequence_0_Info;

void spcWaferIDByChamber_struct::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("procChamber");
    _req.encode_string_op(procChamber);
    _req.setVarName("waferIDs");
    waferIDs.encodeOp(_req);
    _req.setVarName("siInfo");
    siInfo.encodeOp(_req);
    _req.encodeEndStructure();
}

void spcWaferIDByChamber_struct::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("procChamber");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        procChamber = _s;
    }
    _req.setVarName("waferIDs");
    waferIDs.decodeOp(_req);
    _req.setVarName("siInfo");
    siInfo.decodeOp(_req);
    _req.decodeEndStructure();
}

void spcWaferIDByChamber_struct::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("procChamber");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        procChamber = _s;
    }
    _req.setVarName("waferIDs");
    waferIDs.decodeInOutOp(_req);
    _req.setVarName("siInfo");
    siInfo.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 spcWaferIDByChamber_struct::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 spcWaferIDByChamber_struct::__stubcode_dependents[] = {::stringSequence::__stubcode_version};
spcWaferIDByChamber_struct::spcWaferIDByChamber_struct()
{
}
spcWaferIDByChamber_struct::spcWaferIDByChamber_struct( const ::spcWaferIDByChamber_struct &EB_s )
{
    operator=( EB_s );
}
spcWaferIDByChamber_struct& spcWaferIDByChamber_struct::operator=( const ::spcWaferIDByChamber_struct &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   procChamber = EB_s.procChamber;
   waferIDs = EB_s.waferIDs;
   siInfo = EB_s.siInfo;
   return *this;
}
spcWaferIDByChamber_struct_var::spcWaferIDByChamber_struct_var () {
   _ptr = 0;
}
spcWaferIDByChamber_struct_var::spcWaferIDByChamber_struct_var (::spcWaferIDByChamber_struct*_p) {
   _ptr = _p;
}
spcWaferIDByChamber_struct_var::spcWaferIDByChamber_struct_var (const ::spcWaferIDByChamber_struct_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::spcWaferIDByChamber_struct ();
   *(_ptr) = *(_s._ptr);
}
spcWaferIDByChamber_struct_var& spcWaferIDByChamber_struct_var::operator= (::spcWaferIDByChamber_struct *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

spcWaferIDByChamber_struct_var& spcWaferIDByChamber_struct_var::operator= (const ::spcWaferIDByChamber_struct_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::spcWaferIDByChamber_struct ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

spcWaferIDByChamber_struct_var::~spcWaferIDByChamber_struct_var () {
   delete _ptr;
}

::spcWaferIDByChamber_struct * spcWaferIDByChamber_struct_var::operator-> ()
{ return _ptr; }

spcWaferIDByChamber_struct_var::operator ::spcWaferIDByChamber_struct_cvPtr () const 
{ return _ptr;}

spcWaferIDByChamber_struct_var::operator ::spcWaferIDByChamber_struct_vPtr& () 
{ return _ptr;}

spcWaferIDByChamber_struct_var::operator const ::spcWaferIDByChamber_struct& () const 
{ return *_ptr;}

spcWaferIDByChamber_struct_var::operator ::spcWaferIDByChamber_struct& () 
{ return *_ptr;}

const ::spcWaferIDByChamber_struct& spcWaferIDByChamber_struct_var::in () const { return *_ptr; }
::spcWaferIDByChamber_struct& spcWaferIDByChamber_struct_var::inout () { return *_ptr; }
::spcWaferIDByChamber_struct*& spcWaferIDByChamber_struct_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::spcWaferIDByChamber_struct* spcWaferIDByChamber_struct_var::_retn () {
  // yield ownership 
  spcWaferIDByChamber_struct* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::spcWaferIDByChamber_struct > spcWaferIDByChamber_struct::spcWaferIDByChamber_struct_Info;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_spcWaferIDByChamberSequence_0::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_spcWaferIDByChamberSequence_0::__stubcode_dependents[] = {::spcWaferIDByChamber::__stubcode_version };
_IDL_SEQ_spcWaferIDByChamberSequence_0::_IDL_SEQ_spcWaferIDByChamberSequence_0()
{
  _defaultInit();
}
_IDL_SEQ_spcWaferIDByChamberSequence_0::_IDL_SEQ_spcWaferIDByChamberSequence_0 (const ::_IDL_SEQ_spcWaferIDByChamberSequence_0& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_spcWaferIDByChamberSequence_0::_IDL_SEQ_spcWaferIDByChamberSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, ::spcWaferIDByChamber* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
  _maximum = max;
}
_IDL_SEQ_spcWaferIDByChamberSequence_0::_IDL_SEQ_spcWaferIDByChamberSequence_0 (::CORBA::ULong max)
{
  _defaultInit();
  _maximum = max;
  if (_maximum > 0)
    _buffer = allocbuf_throw (max);
}
_IDL_SEQ_spcWaferIDByChamberSequence_0::~_IDL_SEQ_spcWaferIDByChamberSequence_0 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_spcWaferIDByChamberSequence_0::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer  = NULL;
  _maximum = 0;
}
::spcWaferIDByChamber* _IDL_SEQ_spcWaferIDByChamberSequence_0::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  // Allocate an array of the element type (which may be a
  // self managed StructElem)
#ifdef SIVIEW_EBROKER
  ::spcWaferIDByChamber* _ret;
  ::CORBA::ULong alloc_len = sizeof(::spcWaferIDByChamber) * nelems + sizeof(::CORBA::ULong);
  ::CORBA::ULong * tmp = (::CORBA::ULong *)malloc( alloc_len );
  if( tmp )
  {
    memset( tmp, 0, alloc_len );
    *tmp = nelems;
    tmp++;
    _ret = (::spcWaferIDByChamber*)tmp;
    for( CORBA::ULong _index = 0; _index < nelems; _index++ )
    {
      (void)new ((void*)( _ret + _index)) ::spcWaferIDByChamber;
    }
  }
  return _ret;
#else
  return (::spcWaferIDByChamber*) new ::spcWaferIDByChamber[nelems];
#endif
}
::spcWaferIDByChamber* _IDL_SEQ_spcWaferIDByChamberSequence_0::allocbuf_throw (::CORBA::ULong nelems)
{
  ::spcWaferIDByChamber* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_spcWaferIDByChamberSequence_0::freebuf (::spcWaferIDByChamber* _data)
{
#ifdef SIVIEW_EBROKER
  if (_data)
  {
    ::CORBA::ULong * tmp = (CORBA::ULong *)_data;
    tmp--;
    for( CORBA::ULong _index = *tmp; _index; _index-- )
    {
    #ifdef _WIN32
      _data[ _index - 1 ].~spcWaferIDByChamber_struct ();
    #else
      _data[ _index - 1 ].::spcWaferIDByChamber::~spcWaferIDByChamber_struct ();
    #endif
    }
    free(tmp);
  }
#else
  if (_data)
    delete [] (::spcWaferIDByChamber*) _data;
#endif
}
void _IDL_SEQ_spcWaferIDByChamberSequence_0::replace (::CORBA::ULong max,  ::CORBA::ULong length, ::spcWaferIDByChamber* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
  _maximum = max;
}
::_IDL_SEQ_spcWaferIDByChamberSequence_0& _IDL_SEQ_spcWaferIDByChamberSequence_0::operator= (const ::_IDL_SEQ_spcWaferIDByChamberSequence_0& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  _maximum = max;
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_spcWaferIDByChamberSequence_0::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::spcWaferIDByChamber* data)
{
  return; // simple elements don't require resetting.
}
void _IDL_SEQ_spcWaferIDByChamberSequence_0::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::spcWaferIDByChamber* src, ::spcWaferIDByChamber* tgt)
{
  // Copy elements 
  ::spcWaferIDByChamber* _src = (::spcWaferIDByChamber*) src;
  ::spcWaferIDByChamber* _tgt = (::spcWaferIDByChamber*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_spcWaferIDByChamberSequence_0::maximum () const
{
  return   _maximum;
;
}
::CORBA::ULong _IDL_SEQ_spcWaferIDByChamberSequence_0::length () const
{
  return _length;
}
void _IDL_SEQ_spcWaferIDByChamberSequence_0::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  ::spcWaferIDByChamber* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace(max, len, newBuffer, 1);
  return;
}
::spcWaferIDByChamber& _IDL_SEQ_spcWaferIDByChamberSequence_0::operator[] (::CORBA::ULong i)
{
  __cs_spcsvrstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return _buffer[i];
}
const ::spcWaferIDByChamber& _IDL_SEQ_spcWaferIDByChamberSequence_0::operator[] (::CORBA::ULong i) const 
{
  __cs_spcsvrstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return ((const ::spcWaferIDByChamber*)_buffer) [i];
}
::CORBA::Boolean _IDL_SEQ_spcWaferIDByChamberSequence_0::release() const 
{ return _release; }
::spcWaferIDByChamber* _IDL_SEQ_spcWaferIDByChamberSequence_0::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::spcWaferIDByChamber* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::spcWaferIDByChamber* _IDL_SEQ_spcWaferIDByChamberSequence_0::get_buffer () const
{
    return (const ::spcWaferIDByChamber*) _buffer;
}
void _IDL_SEQ_spcWaferIDByChamberSequence_0::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       ::spcWaferIDByChamber_struct const* _elem =     (::spcWaferIDByChamber_struct*) _buffer;
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
           _elem->encodeOp(_req);
       }
    }
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_spcWaferIDByChamberSequence_0::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
      ::spcWaferIDByChamber_struct* _elem = (::spcWaferIDByChamber_struct*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_spcWaferIDByChamberSequence_0::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(max,__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
      ::spcWaferIDByChamber_struct* _elem = (::spcWaferIDByChamber_struct*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeInOutOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_spcWaferIDByChamberSequence_0_var::_IDL_SEQ_spcWaferIDByChamberSequence_0_var () {
   _ptr = 0;
    }

_IDL_SEQ_spcWaferIDByChamberSequence_0_var::_IDL_SEQ_spcWaferIDByChamberSequence_0_var (::_IDL_SEQ_spcWaferIDByChamberSequence_0 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_spcWaferIDByChamberSequence_0_var::_IDL_SEQ_spcWaferIDByChamberSequence_0_var (const ::_IDL_SEQ_spcWaferIDByChamberSequence_0_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_spcWaferIDByChamberSequence_0 (*(_s._ptr));
    }

_IDL_SEQ_spcWaferIDByChamberSequence_0_var& _IDL_SEQ_spcWaferIDByChamberSequence_0_var::operator= (::_IDL_SEQ_spcWaferIDByChamberSequence_0 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_spcWaferIDByChamberSequence_0_var& _IDL_SEQ_spcWaferIDByChamberSequence_0_var::operator= (const ::_IDL_SEQ_spcWaferIDByChamberSequence_0_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_spcWaferIDByChamberSequence_0 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_spcWaferIDByChamberSequence_0_var::~_IDL_SEQ_spcWaferIDByChamberSequence_0_var()
{
   delete _ptr;
}
::_IDL_SEQ_spcWaferIDByChamberSequence_0 * _IDL_SEQ_spcWaferIDByChamberSequence_0_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_spcWaferIDByChamberSequence_0_var::operator ::_IDL_SEQ_spcWaferIDByChamberSequence_0_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_spcWaferIDByChamberSequence_0_var::operator ::_IDL_SEQ_spcWaferIDByChamberSequence_0_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_spcWaferIDByChamberSequence_0_var::operator _IDL_SEQ_spcWaferIDByChamberSequence_0() const
{
   return *_ptr;
}
const ::spcWaferIDByChamber& _IDL_SEQ_spcWaferIDByChamberSequence_0_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_spcWaferIDByChamberSequence_0 *)_ptr)[index];
}
::spcWaferIDByChamber& _IDL_SEQ_spcWaferIDByChamberSequence_0_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::spcWaferIDByChamber& _IDL_SEQ_spcWaferIDByChamberSequence_0_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_spcWaferIDByChamberSequence_0 *)_ptr)[index];
}
::spcWaferIDByChamber& _IDL_SEQ_spcWaferIDByChamberSequence_0_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_spcWaferIDByChamberSequence_0& _IDL_SEQ_spcWaferIDByChamberSequence_0_var::in () const { return *_ptr; }
::_IDL_SEQ_spcWaferIDByChamberSequence_0& _IDL_SEQ_spcWaferIDByChamberSequence_0_var::inout () { return *_ptr; }
::_IDL_SEQ_spcWaferIDByChamberSequence_0*& _IDL_SEQ_spcWaferIDByChamberSequence_0_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_spcWaferIDByChamberSequence_0* _IDL_SEQ_spcWaferIDByChamberSequence_0_var::_retn () {
  // yield ownership 
  _IDL_SEQ_spcWaferIDByChamberSequence_0* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_spcWaferIDByChamberSequence_0 > _IDL_SEQ_spcWaferIDByChamberSequence_0::spcWaferIDByChamberSequence_0_Info;

void spcInput_struct::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("requestUserID");
    requestUserID.encodeOp(_req);
    _req.setVarName("lotID");
    lotID.encodeOp(_req);
    _req.setVarName("processEquipmentID");
    processEquipmentID.encodeOp(_req);
    _req.setVarName("processRecipeID");
    processRecipeID.encodeOp(_req);
    _req.setVarName("processMainProcessDefinitionID");
    processMainProcessDefinitionID.encodeOp(_req);
    _req.setVarName("processProcessDefinitionID");
    processProcessDefinitionID.encodeOp(_req);
    _req.setVarName("processOperationNumber");
    _req.encode_string_op(processOperationNumber);
    _req.setVarName("measurementEquipmentID");
    measurementEquipmentID.encodeOp(_req);
    _req.setVarName("technologyID");
    technologyID.encodeOp(_req);
    _req.setVarName("productGroupID");
    productGroupID.encodeOp(_req);
    _req.setVarName("productID");
    productID.encodeOp(_req);
    _req.setVarName("reticleID");
    reticleID.encodeOp(_req);
    _req.setVarName("reticleIDs");
    reticleIDs.encodeOp(_req);
    _req.setVarName("fixtureID");
    fixtureID.encodeOp(_req);
    _req.setVarName("mainProcessDefinitionID");
    mainProcessDefinitionID.encodeOp(_req);
    _req.setVarName("operationNumber");
    _req.encode_string_op(operationNumber);
    _req.setVarName("operationName");
    _req.encode_string_op(operationName);
    _req.setVarName("ownerUserID");
    ownerUserID.encodeOp(_req);
    _req.setVarName("collectionType");
    _req.encode_string_op(collectionType);
    _req.setVarName("dcDefID");
    dcDefID.encodeOp(_req);
    _req.setVarName("dcItems");
    dcItems.encodeOp(_req);
    _req.setVarName("waferIDByChambers");
    waferIDByChambers.encodeOp(_req);
    _req.setVarName("lotComment");
    _req.encode_string_op(lotComment);
    _req.setVarName("processTimestamp");
    _req.encode_string_op(processTimestamp);
    _req.setVarName("measurementTimestamp");
    _req.encode_string_op(measurementTimestamp);
    _req.setVarName("siInfo");
    siInfo.encodeOp(_req);
    _req.encodeEndStructure();
}

void spcInput_struct::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("requestUserID");
    requestUserID.decodeOp(_req);
    _req.setVarName("lotID");
    lotID.decodeOp(_req);
    _req.setVarName("processEquipmentID");
    processEquipmentID.decodeOp(_req);
    _req.setVarName("processRecipeID");
    processRecipeID.decodeOp(_req);
    _req.setVarName("processMainProcessDefinitionID");
    processMainProcessDefinitionID.decodeOp(_req);
    _req.setVarName("processProcessDefinitionID");
    processProcessDefinitionID.decodeOp(_req);
    _req.setVarName("processOperationNumber");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        processOperationNumber = _s;
    }
    _req.setVarName("measurementEquipmentID");
    measurementEquipmentID.decodeOp(_req);
    _req.setVarName("technologyID");
    technologyID.decodeOp(_req);
    _req.setVarName("productGroupID");
    productGroupID.decodeOp(_req);
    _req.setVarName("productID");
    productID.decodeOp(_req);
    _req.setVarName("reticleID");
    reticleID.decodeOp(_req);
    _req.setVarName("reticleIDs");
    reticleIDs.decodeOp(_req);
    _req.setVarName("fixtureID");
    fixtureID.decodeOp(_req);
    _req.setVarName("mainProcessDefinitionID");
    mainProcessDefinitionID.decodeOp(_req);
    _req.setVarName("operationNumber");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        operationNumber = _s;
    }
    _req.setVarName("operationName");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        operationName = _s;
    }
    _req.setVarName("ownerUserID");
    ownerUserID.decodeOp(_req);
    _req.setVarName("collectionType");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        collectionType = _s;
    }
    _req.setVarName("dcDefID");
    dcDefID.decodeOp(_req);
    _req.setVarName("dcItems");
    dcItems.decodeOp(_req);
    _req.setVarName("waferIDByChambers");
    waferIDByChambers.decodeOp(_req);
    _req.setVarName("lotComment");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        lotComment = _s;
    }
    _req.setVarName("processTimestamp");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        processTimestamp = _s;
    }
    _req.setVarName("measurementTimestamp");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        measurementTimestamp = _s;
    }
    _req.setVarName("siInfo");
    siInfo.decodeOp(_req);
    _req.decodeEndStructure();
}

void spcInput_struct::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("requestUserID");
    requestUserID.decodeInOutOp(_req);
    _req.setVarName("lotID");
    lotID.decodeInOutOp(_req);
    _req.setVarName("processEquipmentID");
    processEquipmentID.decodeInOutOp(_req);
    _req.setVarName("processRecipeID");
    processRecipeID.decodeInOutOp(_req);
    _req.setVarName("processMainProcessDefinitionID");
    processMainProcessDefinitionID.decodeInOutOp(_req);
    _req.setVarName("processProcessDefinitionID");
    processProcessDefinitionID.decodeInOutOp(_req);
    _req.setVarName("processOperationNumber");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        processOperationNumber = _s;
    }
    _req.setVarName("measurementEquipmentID");
    measurementEquipmentID.decodeInOutOp(_req);
    _req.setVarName("technologyID");
    technologyID.decodeInOutOp(_req);
    _req.setVarName("productGroupID");
    productGroupID.decodeInOutOp(_req);
    _req.setVarName("productID");
    productID.decodeInOutOp(_req);
    _req.setVarName("reticleID");
    reticleID.decodeInOutOp(_req);
    _req.setVarName("reticleIDs");
    reticleIDs.decodeInOutOp(_req);
    _req.setVarName("fixtureID");
    fixtureID.decodeInOutOp(_req);
    _req.setVarName("mainProcessDefinitionID");
    mainProcessDefinitionID.decodeInOutOp(_req);
    _req.setVarName("operationNumber");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        operationNumber = _s;
    }
    _req.setVarName("operationName");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        operationName = _s;
    }
    _req.setVarName("ownerUserID");
    ownerUserID.decodeInOutOp(_req);
    _req.setVarName("collectionType");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        collectionType = _s;
    }
    _req.setVarName("dcDefID");
    dcDefID.decodeInOutOp(_req);
    _req.setVarName("dcItems");
    dcItems.decodeInOutOp(_req);
    _req.setVarName("waferIDByChambers");
    waferIDByChambers.decodeInOutOp(_req);
    _req.setVarName("lotComment");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        lotComment = _s;
    }
    _req.setVarName("processTimestamp");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        processTimestamp = _s;
    }
    _req.setVarName("measurementTimestamp");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        measurementTimestamp = _s;
    }
    _req.setVarName("siInfo");
    siInfo.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 spcInput_struct::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 spcInput_struct::__stubcode_dependents[] = {::spcDcItemSequence::__stubcode_version,::spcWaferIDByChamberSequence::__stubcode_version,::objectIdentifier::__stubcode_version,::objectIdentifierSequence::__stubcode_version};
spcInput_struct::spcInput_struct()
{
}
spcInput_struct::spcInput_struct( const ::spcInput_struct &EB_s )
{
    operator=( EB_s );
}
spcInput_struct& spcInput_struct::operator=( const ::spcInput_struct &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   requestUserID = EB_s.requestUserID;
   lotID = EB_s.lotID;
   processEquipmentID = EB_s.processEquipmentID;
   processRecipeID = EB_s.processRecipeID;
   processMainProcessDefinitionID = EB_s.processMainProcessDefinitionID;
   processProcessDefinitionID = EB_s.processProcessDefinitionID;
   processOperationNumber = EB_s.processOperationNumber;
   measurementEquipmentID = EB_s.measurementEquipmentID;
   technologyID = EB_s.technologyID;
   productGroupID = EB_s.productGroupID;
   productID = EB_s.productID;
   reticleID = EB_s.reticleID;
   reticleIDs = EB_s.reticleIDs;
   fixtureID = EB_s.fixtureID;
   mainProcessDefinitionID = EB_s.mainProcessDefinitionID;
   operationNumber = EB_s.operationNumber;
   operationName = EB_s.operationName;
   ownerUserID = EB_s.ownerUserID;
   collectionType = EB_s.collectionType;
   dcDefID = EB_s.dcDefID;
   dcItems = EB_s.dcItems;
   waferIDByChambers = EB_s.waferIDByChambers;
   lotComment = EB_s.lotComment;
   processTimestamp = EB_s.processTimestamp;
   measurementTimestamp = EB_s.measurementTimestamp;
   siInfo = EB_s.siInfo;
   return *this;
}
spcInput_struct_var::spcInput_struct_var () {
   _ptr = 0;
}
spcInput_struct_var::spcInput_struct_var (::spcInput_struct*_p) {
   _ptr = _p;
}
spcInput_struct_var::spcInput_struct_var (const ::spcInput_struct_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::spcInput_struct ();
   *(_ptr) = *(_s._ptr);
}
spcInput_struct_var& spcInput_struct_var::operator= (::spcInput_struct *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

spcInput_struct_var& spcInput_struct_var::operator= (const ::spcInput_struct_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::spcInput_struct ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

spcInput_struct_var::~spcInput_struct_var () {
   delete _ptr;
}

::spcInput_struct * spcInput_struct_var::operator-> ()
{ return _ptr; }

spcInput_struct_var::operator ::spcInput_struct_cvPtr () const 
{ return _ptr;}

spcInput_struct_var::operator ::spcInput_struct_vPtr& () 
{ return _ptr;}

spcInput_struct_var::operator const ::spcInput_struct& () const 
{ return *_ptr;}

spcInput_struct_var::operator ::spcInput_struct& () 
{ return *_ptr;}

const ::spcInput_struct& spcInput_struct_var::in () const { return *_ptr; }
::spcInput_struct& spcInput_struct_var::inout () { return *_ptr; }
::spcInput_struct*& spcInput_struct_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::spcInput_struct* spcInput_struct_var::_retn () {
  // yield ownership 
  spcInput_struct* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::spcInput_struct > spcInput_struct::spcInput_struct_Info;
void spcHoldActionResult_struct::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("holdAction");
    _req.encode_string_op(holdAction);
    _req.setVarName("triggerRules");
    triggerRules.encodeOp(_req);
    _req.encodeEndStructure();
}

void spcHoldActionResult_struct::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("holdAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        holdAction = _s;
    }
    _req.setVarName("triggerRules");
    triggerRules.decodeOp(_req);
    _req.decodeEndStructure();
}

void spcHoldActionResult_struct::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("holdAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        holdAction = _s;
    }
    _req.setVarName("triggerRules");
    triggerRules.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 spcHoldActionResult_struct::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 spcHoldActionResult_struct::__stubcode_dependents[] = {::stringSequence::__stubcode_version};
spcHoldActionResult_struct::spcHoldActionResult_struct()
{
}
spcHoldActionResult_struct::spcHoldActionResult_struct( const ::spcHoldActionResult_struct &EB_s )
{
    operator=( EB_s );
}
spcHoldActionResult_struct& spcHoldActionResult_struct::operator=( const ::spcHoldActionResult_struct &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   holdAction = EB_s.holdAction;
   triggerRules = EB_s.triggerRules;
   return *this;
}
spcHoldActionResult_struct_var::spcHoldActionResult_struct_var () {
   _ptr = 0;
}
spcHoldActionResult_struct_var::spcHoldActionResult_struct_var (::spcHoldActionResult_struct*_p) {
   _ptr = _p;
}
spcHoldActionResult_struct_var::spcHoldActionResult_struct_var (const ::spcHoldActionResult_struct_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::spcHoldActionResult_struct ();
   *(_ptr) = *(_s._ptr);
}
spcHoldActionResult_struct_var& spcHoldActionResult_struct_var::operator= (::spcHoldActionResult_struct *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

spcHoldActionResult_struct_var& spcHoldActionResult_struct_var::operator= (const ::spcHoldActionResult_struct_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::spcHoldActionResult_struct ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

spcHoldActionResult_struct_var::~spcHoldActionResult_struct_var () {
   delete _ptr;
}

::spcHoldActionResult_struct * spcHoldActionResult_struct_var::operator-> ()
{ return _ptr; }

spcHoldActionResult_struct_var::operator ::spcHoldActionResult_struct_cvPtr () const 
{ return _ptr;}

spcHoldActionResult_struct_var::operator ::spcHoldActionResult_struct_vPtr& () 
{ return _ptr;}

spcHoldActionResult_struct_var::operator const ::spcHoldActionResult_struct& () const 
{ return *_ptr;}

spcHoldActionResult_struct_var::operator ::spcHoldActionResult_struct& () 
{ return *_ptr;}

const ::spcHoldActionResult_struct& spcHoldActionResult_struct_var::in () const { return *_ptr; }
::spcHoldActionResult_struct& spcHoldActionResult_struct_var::inout () { return *_ptr; }
::spcHoldActionResult_struct*& spcHoldActionResult_struct_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::spcHoldActionResult_struct* spcHoldActionResult_struct_var::_retn () {
  // yield ownership 
  spcHoldActionResult_struct* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::spcHoldActionResult_struct > spcHoldActionResult_struct::spcHoldActionResult_struct_Info;
void spcCheckResultByRule_struct::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("rule");
    _req.encode_string_op(rule);
    _req.setVarName("description");
    _req.encode_string_op(description);
    _req.setVarName("returnCodeStatus");
    _req.encode_string_op(returnCodeStatus);
    _req.encodeEndStructure();
}

void spcCheckResultByRule_struct::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("rule");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        rule = _s;
    }
    _req.setVarName("description");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        description = _s;
    }
    _req.setVarName("returnCodeStatus");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        returnCodeStatus = _s;
    }
    _req.decodeEndStructure();
}

void spcCheckResultByRule_struct::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("rule");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        rule = _s;
    }
    _req.setVarName("description");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        description = _s;
    }
    _req.setVarName("returnCodeStatus");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        returnCodeStatus = _s;
    }
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 spcCheckResultByRule_struct::__stubcode_version;
spcCheckResultByRule_struct::spcCheckResultByRule_struct()
{
}
spcCheckResultByRule_struct::spcCheckResultByRule_struct( const ::spcCheckResultByRule_struct &EB_s )
{
    operator=( EB_s );
}
spcCheckResultByRule_struct& spcCheckResultByRule_struct::operator=( const ::spcCheckResultByRule_struct &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   rule = EB_s.rule;
   description = EB_s.description;
   returnCodeStatus = EB_s.returnCodeStatus;
   return *this;
}
spcCheckResultByRule_struct_var::spcCheckResultByRule_struct_var () {
   _ptr = 0;
}
spcCheckResultByRule_struct_var::spcCheckResultByRule_struct_var (::spcCheckResultByRule_struct*_p) {
   _ptr = _p;
}
spcCheckResultByRule_struct_var::spcCheckResultByRule_struct_var (const ::spcCheckResultByRule_struct_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::spcCheckResultByRule_struct ();
   *(_ptr) = *(_s._ptr);
}
spcCheckResultByRule_struct_var& spcCheckResultByRule_struct_var::operator= (::spcCheckResultByRule_struct *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

spcCheckResultByRule_struct_var& spcCheckResultByRule_struct_var::operator= (const ::spcCheckResultByRule_struct_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::spcCheckResultByRule_struct ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

spcCheckResultByRule_struct_var::~spcCheckResultByRule_struct_var () {
   delete _ptr;
}

::spcCheckResultByRule_struct * spcCheckResultByRule_struct_var::operator-> ()
{ return _ptr; }

spcCheckResultByRule_struct_var::operator ::spcCheckResultByRule_struct_cvPtr () const 
{ return _ptr;}

spcCheckResultByRule_struct_var::operator ::spcCheckResultByRule_struct_vPtr& () 
{ return _ptr;}

spcCheckResultByRule_struct_var::operator const ::spcCheckResultByRule_struct& () const 
{ return *_ptr;}

spcCheckResultByRule_struct_var::operator ::spcCheckResultByRule_struct& () 
{ return *_ptr;}

const ::spcCheckResultByRule_struct& spcCheckResultByRule_struct_var::in () const { return *_ptr; }
::spcCheckResultByRule_struct& spcCheckResultByRule_struct_var::inout () { return *_ptr; }
::spcCheckResultByRule_struct*& spcCheckResultByRule_struct_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::spcCheckResultByRule_struct* spcCheckResultByRule_struct_var::_retn () {
  // yield ownership 
  spcCheckResultByRule_struct* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::spcCheckResultByRule_struct > spcCheckResultByRule_struct::spcCheckResultByRule_struct_Info;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_spcCheckResultByRuleSequence_0::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_spcCheckResultByRuleSequence_0::__stubcode_dependents[] = {::spcCheckResultByRule::__stubcode_version };
_IDL_SEQ_spcCheckResultByRuleSequence_0::_IDL_SEQ_spcCheckResultByRuleSequence_0()
{
  _defaultInit();
}
_IDL_SEQ_spcCheckResultByRuleSequence_0::_IDL_SEQ_spcCheckResultByRuleSequence_0 (const ::_IDL_SEQ_spcCheckResultByRuleSequence_0& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_spcCheckResultByRuleSequence_0::_IDL_SEQ_spcCheckResultByRuleSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, ::spcCheckResultByRule* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
  _maximum = max;
}
_IDL_SEQ_spcCheckResultByRuleSequence_0::_IDL_SEQ_spcCheckResultByRuleSequence_0 (::CORBA::ULong max)
{
  _defaultInit();
  _maximum = max;
  if (_maximum > 0)
    _buffer = allocbuf_throw (max);
}
_IDL_SEQ_spcCheckResultByRuleSequence_0::~_IDL_SEQ_spcCheckResultByRuleSequence_0 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_spcCheckResultByRuleSequence_0::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer  = NULL;
  _maximum = 0;
}
::spcCheckResultByRule* _IDL_SEQ_spcCheckResultByRuleSequence_0::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  // Allocate an array of the element type (which may be a
  // self managed StructElem)
#ifdef SIVIEW_EBROKER
  ::spcCheckResultByRule* _ret;
  ::CORBA::ULong alloc_len = sizeof(::spcCheckResultByRule) * nelems + sizeof(::CORBA::ULong);
  ::CORBA::ULong * tmp = (::CORBA::ULong *)malloc( alloc_len );
  if( tmp )
  {
    memset( tmp, 0, alloc_len );
    *tmp = nelems;
    tmp++;
    _ret = (::spcCheckResultByRule*)tmp;
    for( CORBA::ULong _index = 0; _index < nelems; _index++ )
    {
      (void)new ((void*)( _ret + _index)) ::spcCheckResultByRule;
    }
  }
  return _ret;
#else
  return (::spcCheckResultByRule*) new ::spcCheckResultByRule[nelems];
#endif
}
::spcCheckResultByRule* _IDL_SEQ_spcCheckResultByRuleSequence_0::allocbuf_throw (::CORBA::ULong nelems)
{
  ::spcCheckResultByRule* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_spcCheckResultByRuleSequence_0::freebuf (::spcCheckResultByRule* _data)
{
#ifdef SIVIEW_EBROKER
  if (_data)
  {
    ::CORBA::ULong * tmp = (CORBA::ULong *)_data;
    tmp--;
    for( CORBA::ULong _index = *tmp; _index; _index-- )
    {
    #ifdef _WIN32
      _data[ _index - 1 ].~spcCheckResultByRule_struct ();
    #else
      _data[ _index - 1 ].::spcCheckResultByRule::~spcCheckResultByRule_struct ();
    #endif
    }
    free(tmp);
  }
#else
  if (_data)
    delete [] (::spcCheckResultByRule*) _data;
#endif
}
void _IDL_SEQ_spcCheckResultByRuleSequence_0::replace (::CORBA::ULong max,  ::CORBA::ULong length, ::spcCheckResultByRule* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
  _maximum = max;
}
::_IDL_SEQ_spcCheckResultByRuleSequence_0& _IDL_SEQ_spcCheckResultByRuleSequence_0::operator= (const ::_IDL_SEQ_spcCheckResultByRuleSequence_0& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  _maximum = max;
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_spcCheckResultByRuleSequence_0::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::spcCheckResultByRule* data)
{
  return; // simple elements don't require resetting.
}
void _IDL_SEQ_spcCheckResultByRuleSequence_0::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::spcCheckResultByRule* src, ::spcCheckResultByRule* tgt)
{
  // Copy elements 
  ::spcCheckResultByRule* _src = (::spcCheckResultByRule*) src;
  ::spcCheckResultByRule* _tgt = (::spcCheckResultByRule*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_spcCheckResultByRuleSequence_0::maximum () const
{
  return   _maximum;
;
}
::CORBA::ULong _IDL_SEQ_spcCheckResultByRuleSequence_0::length () const
{
  return _length;
}
void _IDL_SEQ_spcCheckResultByRuleSequence_0::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  ::spcCheckResultByRule* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace(max, len, newBuffer, 1);
  return;
}
::spcCheckResultByRule& _IDL_SEQ_spcCheckResultByRuleSequence_0::operator[] (::CORBA::ULong i)
{
  __cs_spcsvrstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return _buffer[i];
}
const ::spcCheckResultByRule& _IDL_SEQ_spcCheckResultByRuleSequence_0::operator[] (::CORBA::ULong i) const 
{
  __cs_spcsvrstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return ((const ::spcCheckResultByRule*)_buffer) [i];
}
::CORBA::Boolean _IDL_SEQ_spcCheckResultByRuleSequence_0::release() const 
{ return _release; }
::spcCheckResultByRule* _IDL_SEQ_spcCheckResultByRuleSequence_0::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::spcCheckResultByRule* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::spcCheckResultByRule* _IDL_SEQ_spcCheckResultByRuleSequence_0::get_buffer () const
{
    return (const ::spcCheckResultByRule*) _buffer;
}
void _IDL_SEQ_spcCheckResultByRuleSequence_0::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       ::spcCheckResultByRule_struct const* _elem =     (::spcCheckResultByRule_struct*) _buffer;
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
           _elem->encodeOp(_req);
       }
    }
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_spcCheckResultByRuleSequence_0::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
      ::spcCheckResultByRule_struct* _elem = (::spcCheckResultByRule_struct*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_spcCheckResultByRuleSequence_0::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(max,__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
      ::spcCheckResultByRule_struct* _elem = (::spcCheckResultByRule_struct*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeInOutOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_spcCheckResultByRuleSequence_0_var::_IDL_SEQ_spcCheckResultByRuleSequence_0_var () {
   _ptr = 0;
    }

_IDL_SEQ_spcCheckResultByRuleSequence_0_var::_IDL_SEQ_spcCheckResultByRuleSequence_0_var (::_IDL_SEQ_spcCheckResultByRuleSequence_0 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_spcCheckResultByRuleSequence_0_var::_IDL_SEQ_spcCheckResultByRuleSequence_0_var (const ::_IDL_SEQ_spcCheckResultByRuleSequence_0_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_spcCheckResultByRuleSequence_0 (*(_s._ptr));
    }

_IDL_SEQ_spcCheckResultByRuleSequence_0_var& _IDL_SEQ_spcCheckResultByRuleSequence_0_var::operator= (::_IDL_SEQ_spcCheckResultByRuleSequence_0 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_spcCheckResultByRuleSequence_0_var& _IDL_SEQ_spcCheckResultByRuleSequence_0_var::operator= (const ::_IDL_SEQ_spcCheckResultByRuleSequence_0_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_spcCheckResultByRuleSequence_0 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_spcCheckResultByRuleSequence_0_var::~_IDL_SEQ_spcCheckResultByRuleSequence_0_var()
{
   delete _ptr;
}
::_IDL_SEQ_spcCheckResultByRuleSequence_0 * _IDL_SEQ_spcCheckResultByRuleSequence_0_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_spcCheckResultByRuleSequence_0_var::operator ::_IDL_SEQ_spcCheckResultByRuleSequence_0_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_spcCheckResultByRuleSequence_0_var::operator ::_IDL_SEQ_spcCheckResultByRuleSequence_0_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_spcCheckResultByRuleSequence_0_var::operator _IDL_SEQ_spcCheckResultByRuleSequence_0() const
{
   return *_ptr;
}
const ::spcCheckResultByRule& _IDL_SEQ_spcCheckResultByRuleSequence_0_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_spcCheckResultByRuleSequence_0 *)_ptr)[index];
}
::spcCheckResultByRule& _IDL_SEQ_spcCheckResultByRuleSequence_0_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::spcCheckResultByRule& _IDL_SEQ_spcCheckResultByRuleSequence_0_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_spcCheckResultByRuleSequence_0 *)_ptr)[index];
}
::spcCheckResultByRule& _IDL_SEQ_spcCheckResultByRuleSequence_0_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_spcCheckResultByRuleSequence_0& _IDL_SEQ_spcCheckResultByRuleSequence_0_var::in () const { return *_ptr; }
::_IDL_SEQ_spcCheckResultByRuleSequence_0& _IDL_SEQ_spcCheckResultByRuleSequence_0_var::inout () { return *_ptr; }
::_IDL_SEQ_spcCheckResultByRuleSequence_0*& _IDL_SEQ_spcCheckResultByRuleSequence_0_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_spcCheckResultByRuleSequence_0* _IDL_SEQ_spcCheckResultByRuleSequence_0_var::_retn () {
  // yield ownership 
  _IDL_SEQ_spcCheckResultByRuleSequence_0* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_spcCheckResultByRuleSequence_0 > _IDL_SEQ_spcCheckResultByRuleSequence_0::spcCheckResultByRuleSequence_0_Info;

void spcChartResult_struct::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("chartGroupID");
    _req.encode_string_op(chartGroupID);
    _req.setVarName("chartID");
    _req.encode_string_op(chartID);
    _req.setVarName("chartType");
    _req.encode_string_op(chartType);
    _req.setVarName("processTimestamp");
    _req.encode_string_op(processTimestamp);
    _req.setVarName("inputTimestamp");
    _req.encode_string_op(inputTimestamp);
    _req.setVarName("chartRC");
    _req.encode_string_op(chartRC);
    _req.setVarName("equipmentHoldAction");
    equipmentHoldAction.encodeOp(_req);
    _req.setVarName("processHoldAction");
    processHoldAction.encodeOp(_req);
    _req.setVarName("recipeHoldAction");
    recipeHoldAction.encodeOp(_req);
    _req.setVarName("chamberHoldAction");
    chamberHoldAction.encodeOp(_req);
    _req.setVarName("chamberID");
    _req.encode_string_op(chamberID);
    _req.setVarName("chamberRecipeHoldAction");
    chamberRecipeHoldAction.encodeOp(_req);
    _req.setVarName("routeHoldAction");
    routeHoldAction.encodeOp(_req);
    _req.setVarName("equipmentAndRecipeHoldAction");
    equipmentAndRecipeHoldAction.encodeOp(_req);
    _req.setVarName("processAndEquipmentHoldAction");
    processAndEquipmentHoldAction.encodeOp(_req);
    _req.setVarName("operationAndEquipmentHoldAction");
    operationAndEquipmentHoldAction.encodeOp(_req);
    _req.setVarName("lotHoldAction");
    lotHoldAction.encodeOp(_req);
    _req.setVarName("reticleHoldAction");
    reticleHoldAction.encodeOp(_req);
    _req.setVarName("returnCodes");
    returnCodes.encodeOp(_req);
    _req.setVarName("chartOwnerMailAddress");
    _req.encode_string_op(chartOwnerMailAddress);
    _req.setVarName("chartSubOwnerMailAddresses");
    chartSubOwnerMailAddresses.encodeOp(_req);
    _req.setVarName("siInfo");
    siInfo.encodeOp(_req);
    _req.encodeEndStructure();
}

void spcChartResult_struct::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("chartGroupID");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chartGroupID = _s;
    }
    _req.setVarName("chartID");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chartID = _s;
    }
    _req.setVarName("chartType");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chartType = _s;
    }
    _req.setVarName("processTimestamp");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        processTimestamp = _s;
    }
    _req.setVarName("inputTimestamp");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        inputTimestamp = _s;
    }
    _req.setVarName("chartRC");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chartRC = _s;
    }
    _req.setVarName("equipmentHoldAction");
    equipmentHoldAction.decodeOp(_req);
    _req.setVarName("processHoldAction");
    processHoldAction.decodeOp(_req);
    _req.setVarName("recipeHoldAction");
    recipeHoldAction.decodeOp(_req);
    _req.setVarName("chamberHoldAction");
    chamberHoldAction.decodeOp(_req);
    _req.setVarName("chamberID");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chamberID = _s;
    }
    _req.setVarName("chamberRecipeHoldAction");
    chamberRecipeHoldAction.decodeOp(_req);
    _req.setVarName("routeHoldAction");
    routeHoldAction.decodeOp(_req);
    _req.setVarName("equipmentAndRecipeHoldAction");
    equipmentAndRecipeHoldAction.decodeOp(_req);
    _req.setVarName("processAndEquipmentHoldAction");
    processAndEquipmentHoldAction.decodeOp(_req);
    _req.setVarName("operationAndEquipmentHoldAction");
    operationAndEquipmentHoldAction.decodeOp(_req);
    _req.setVarName("lotHoldAction");
    lotHoldAction.decodeOp(_req);
    _req.setVarName("reticleHoldAction");
    reticleHoldAction.decodeOp(_req);
    _req.setVarName("returnCodes");
    returnCodes.decodeOp(_req);
    _req.setVarName("chartOwnerMailAddress");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chartOwnerMailAddress = _s;
    }
    _req.setVarName("chartSubOwnerMailAddresses");
    chartSubOwnerMailAddresses.decodeOp(_req);
    _req.setVarName("siInfo");
    siInfo.decodeOp(_req);
    _req.decodeEndStructure();
}

void spcChartResult_struct::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("chartGroupID");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chartGroupID = _s;
    }
    _req.setVarName("chartID");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chartID = _s;
    }
    _req.setVarName("chartType");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chartType = _s;
    }
    _req.setVarName("processTimestamp");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        processTimestamp = _s;
    }
    _req.setVarName("inputTimestamp");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        inputTimestamp = _s;
    }
    _req.setVarName("chartRC");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chartRC = _s;
    }
    _req.setVarName("equipmentHoldAction");
    equipmentHoldAction.decodeInOutOp(_req);
    _req.setVarName("processHoldAction");
    processHoldAction.decodeInOutOp(_req);
    _req.setVarName("recipeHoldAction");
    recipeHoldAction.decodeInOutOp(_req);
    _req.setVarName("chamberHoldAction");
    chamberHoldAction.decodeInOutOp(_req);
    _req.setVarName("chamberID");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chamberID = _s;
    }
    _req.setVarName("chamberRecipeHoldAction");
    chamberRecipeHoldAction.decodeInOutOp(_req);
    _req.setVarName("routeHoldAction");
    routeHoldAction.decodeInOutOp(_req);
    _req.setVarName("equipmentAndRecipeHoldAction");
    equipmentAndRecipeHoldAction.decodeInOutOp(_req);
    _req.setVarName("processAndEquipmentHoldAction");
    processAndEquipmentHoldAction.decodeInOutOp(_req);
    _req.setVarName("operationAndEquipmentHoldAction");
    operationAndEquipmentHoldAction.decodeInOutOp(_req);
    _req.setVarName("lotHoldAction");
    lotHoldAction.decodeInOutOp(_req);
    _req.setVarName("reticleHoldAction");
    reticleHoldAction.decodeInOutOp(_req);
    _req.setVarName("returnCodes");
    returnCodes.decodeInOutOp(_req);
    _req.setVarName("chartOwnerMailAddress");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chartOwnerMailAddress = _s;
    }
    _req.setVarName("chartSubOwnerMailAddresses");
    chartSubOwnerMailAddresses.decodeInOutOp(_req);
    _req.setVarName("siInfo");
    siInfo.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 spcChartResult_struct::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 spcChartResult_struct::__stubcode_dependents[] = {::stringSequence::__stubcode_version,::spcHoldActionResult::__stubcode_version,::spcCheckResultByRuleSequence::__stubcode_version};
spcChartResult_struct::spcChartResult_struct()
{
}
spcChartResult_struct::spcChartResult_struct( const ::spcChartResult_struct &EB_s )
{
    operator=( EB_s );
}
spcChartResult_struct& spcChartResult_struct::operator=( const ::spcChartResult_struct &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   chartGroupID = EB_s.chartGroupID;
   chartID = EB_s.chartID;
   chartType = EB_s.chartType;
   processTimestamp = EB_s.processTimestamp;
   inputTimestamp = EB_s.inputTimestamp;
   chartRC = EB_s.chartRC;
   equipmentHoldAction = EB_s.equipmentHoldAction;
   processHoldAction = EB_s.processHoldAction;
   recipeHoldAction = EB_s.recipeHoldAction;
   chamberHoldAction = EB_s.chamberHoldAction;
   chamberID = EB_s.chamberID;
   chamberRecipeHoldAction = EB_s.chamberRecipeHoldAction;
   routeHoldAction = EB_s.routeHoldAction;
   equipmentAndRecipeHoldAction = EB_s.equipmentAndRecipeHoldAction;
   processAndEquipmentHoldAction = EB_s.processAndEquipmentHoldAction;
   operationAndEquipmentHoldAction = EB_s.operationAndEquipmentHoldAction;
   lotHoldAction = EB_s.lotHoldAction;
   reticleHoldAction = EB_s.reticleHoldAction;
   returnCodes = EB_s.returnCodes;
   chartOwnerMailAddress = EB_s.chartOwnerMailAddress;
   chartSubOwnerMailAddresses = EB_s.chartSubOwnerMailAddresses;
   siInfo = EB_s.siInfo;
   return *this;
}
spcChartResult_struct_var::spcChartResult_struct_var () {
   _ptr = 0;
}
spcChartResult_struct_var::spcChartResult_struct_var (::spcChartResult_struct*_p) {
   _ptr = _p;
}
spcChartResult_struct_var::spcChartResult_struct_var (const ::spcChartResult_struct_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::spcChartResult_struct ();
   *(_ptr) = *(_s._ptr);
}
spcChartResult_struct_var& spcChartResult_struct_var::operator= (::spcChartResult_struct *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

spcChartResult_struct_var& spcChartResult_struct_var::operator= (const ::spcChartResult_struct_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::spcChartResult_struct ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

spcChartResult_struct_var::~spcChartResult_struct_var () {
   delete _ptr;
}

::spcChartResult_struct * spcChartResult_struct_var::operator-> ()
{ return _ptr; }

spcChartResult_struct_var::operator ::spcChartResult_struct_cvPtr () const 
{ return _ptr;}

spcChartResult_struct_var::operator ::spcChartResult_struct_vPtr& () 
{ return _ptr;}

spcChartResult_struct_var::operator const ::spcChartResult_struct& () const 
{ return *_ptr;}

spcChartResult_struct_var::operator ::spcChartResult_struct& () 
{ return *_ptr;}

const ::spcChartResult_struct& spcChartResult_struct_var::in () const { return *_ptr; }
::spcChartResult_struct& spcChartResult_struct_var::inout () { return *_ptr; }
::spcChartResult_struct*& spcChartResult_struct_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::spcChartResult_struct* spcChartResult_struct_var::_retn () {
  // yield ownership 
  spcChartResult_struct* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::spcChartResult_struct > spcChartResult_struct::spcChartResult_struct_Info;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_spcChartResultSequence_0::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_spcChartResultSequence_0::__stubcode_dependents[] = {::spcChartResult::__stubcode_version };
_IDL_SEQ_spcChartResultSequence_0::_IDL_SEQ_spcChartResultSequence_0()
{
  _defaultInit();
}
_IDL_SEQ_spcChartResultSequence_0::_IDL_SEQ_spcChartResultSequence_0 (const ::_IDL_SEQ_spcChartResultSequence_0& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_spcChartResultSequence_0::_IDL_SEQ_spcChartResultSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, ::spcChartResult* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
  _maximum = max;
}
_IDL_SEQ_spcChartResultSequence_0::_IDL_SEQ_spcChartResultSequence_0 (::CORBA::ULong max)
{
  _defaultInit();
  _maximum = max;
  if (_maximum > 0)
    _buffer = allocbuf_throw (max);
}
_IDL_SEQ_spcChartResultSequence_0::~_IDL_SEQ_spcChartResultSequence_0 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_spcChartResultSequence_0::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer  = NULL;
  _maximum = 0;
}
::spcChartResult* _IDL_SEQ_spcChartResultSequence_0::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  // Allocate an array of the element type (which may be a
  // self managed StructElem)
#ifdef SIVIEW_EBROKER
  ::spcChartResult* _ret;
  ::CORBA::ULong alloc_len = sizeof(::spcChartResult) * nelems + sizeof(::CORBA::ULong);
  ::CORBA::ULong * tmp = (::CORBA::ULong *)malloc( alloc_len );
  if( tmp )
  {
    memset( tmp, 0, alloc_len );
    *tmp = nelems;
    tmp++;
    _ret = (::spcChartResult*)tmp;
    for( CORBA::ULong _index = 0; _index < nelems; _index++ )
    {
      (void)new ((void*)( _ret + _index)) ::spcChartResult;
    }
  }
  return _ret;
#else
  return (::spcChartResult*) new ::spcChartResult[nelems];
#endif
}
::spcChartResult* _IDL_SEQ_spcChartResultSequence_0::allocbuf_throw (::CORBA::ULong nelems)
{
  ::spcChartResult* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_spcChartResultSequence_0::freebuf (::spcChartResult* _data)
{
#ifdef SIVIEW_EBROKER
  if (_data)
  {
    ::CORBA::ULong * tmp = (CORBA::ULong *)_data;
    tmp--;
    for( CORBA::ULong _index = *tmp; _index; _index-- )
    {
    #ifdef _WIN32
      _data[ _index - 1 ].~spcChartResult_struct ();
    #else
      _data[ _index - 1 ].::spcChartResult::~spcChartResult_struct ();
    #endif
    }
    free(tmp);
  }
#else
  if (_data)
    delete [] (::spcChartResult*) _data;
#endif
}
void _IDL_SEQ_spcChartResultSequence_0::replace (::CORBA::ULong max,  ::CORBA::ULong length, ::spcChartResult* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
  _maximum = max;
}
::_IDL_SEQ_spcChartResultSequence_0& _IDL_SEQ_spcChartResultSequence_0::operator= (const ::_IDL_SEQ_spcChartResultSequence_0& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  _maximum = max;
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_spcChartResultSequence_0::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::spcChartResult* data)
{
  return; // simple elements don't require resetting.
}
void _IDL_SEQ_spcChartResultSequence_0::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::spcChartResult* src, ::spcChartResult* tgt)
{
  // Copy elements 
  ::spcChartResult* _src = (::spcChartResult*) src;
  ::spcChartResult* _tgt = (::spcChartResult*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_spcChartResultSequence_0::maximum () const
{
  return   _maximum;
;
}
::CORBA::ULong _IDL_SEQ_spcChartResultSequence_0::length () const
{
  return _length;
}
void _IDL_SEQ_spcChartResultSequence_0::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  ::spcChartResult* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace(max, len, newBuffer, 1);
  return;
}
::spcChartResult& _IDL_SEQ_spcChartResultSequence_0::operator[] (::CORBA::ULong i)
{
  __cs_spcsvrstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return _buffer[i];
}
const ::spcChartResult& _IDL_SEQ_spcChartResultSequence_0::operator[] (::CORBA::ULong i) const 
{
  __cs_spcsvrstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return ((const ::spcChartResult*)_buffer) [i];
}
::CORBA::Boolean _IDL_SEQ_spcChartResultSequence_0::release() const 
{ return _release; }
::spcChartResult* _IDL_SEQ_spcChartResultSequence_0::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::spcChartResult* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::spcChartResult* _IDL_SEQ_spcChartResultSequence_0::get_buffer () const
{
    return (const ::spcChartResult*) _buffer;
}
void _IDL_SEQ_spcChartResultSequence_0::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       ::spcChartResult_struct const* _elem =     (::spcChartResult_struct*) _buffer;
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
           _elem->encodeOp(_req);
       }
    }
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_spcChartResultSequence_0::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
      ::spcChartResult_struct* _elem = (::spcChartResult_struct*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_spcChartResultSequence_0::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(max,__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
      ::spcChartResult_struct* _elem = (::spcChartResult_struct*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeInOutOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_spcChartResultSequence_0_var::_IDL_SEQ_spcChartResultSequence_0_var () {
   _ptr = 0;
    }

_IDL_SEQ_spcChartResultSequence_0_var::_IDL_SEQ_spcChartResultSequence_0_var (::_IDL_SEQ_spcChartResultSequence_0 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_spcChartResultSequence_0_var::_IDL_SEQ_spcChartResultSequence_0_var (const ::_IDL_SEQ_spcChartResultSequence_0_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_spcChartResultSequence_0 (*(_s._ptr));
    }

_IDL_SEQ_spcChartResultSequence_0_var& _IDL_SEQ_spcChartResultSequence_0_var::operator= (::_IDL_SEQ_spcChartResultSequence_0 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_spcChartResultSequence_0_var& _IDL_SEQ_spcChartResultSequence_0_var::operator= (const ::_IDL_SEQ_spcChartResultSequence_0_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_spcChartResultSequence_0 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_spcChartResultSequence_0_var::~_IDL_SEQ_spcChartResultSequence_0_var()
{
   delete _ptr;
}
::_IDL_SEQ_spcChartResultSequence_0 * _IDL_SEQ_spcChartResultSequence_0_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_spcChartResultSequence_0_var::operator ::_IDL_SEQ_spcChartResultSequence_0_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_spcChartResultSequence_0_var::operator ::_IDL_SEQ_spcChartResultSequence_0_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_spcChartResultSequence_0_var::operator _IDL_SEQ_spcChartResultSequence_0() const
{
   return *_ptr;
}
const ::spcChartResult& _IDL_SEQ_spcChartResultSequence_0_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_spcChartResultSequence_0 *)_ptr)[index];
}
::spcChartResult& _IDL_SEQ_spcChartResultSequence_0_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::spcChartResult& _IDL_SEQ_spcChartResultSequence_0_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_spcChartResultSequence_0 *)_ptr)[index];
}
::spcChartResult& _IDL_SEQ_spcChartResultSequence_0_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_spcChartResultSequence_0& _IDL_SEQ_spcChartResultSequence_0_var::in () const { return *_ptr; }
::_IDL_SEQ_spcChartResultSequence_0& _IDL_SEQ_spcChartResultSequence_0_var::inout () { return *_ptr; }
::_IDL_SEQ_spcChartResultSequence_0*& _IDL_SEQ_spcChartResultSequence_0_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_spcChartResultSequence_0* _IDL_SEQ_spcChartResultSequence_0_var::_retn () {
  // yield ownership 
  _IDL_SEQ_spcChartResultSequence_0* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_spcChartResultSequence_0 > _IDL_SEQ_spcChartResultSequence_0::spcChartResultSequence_0_Info;

void spcItemResult_struct::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("dataItemName");
    _req.encode_string_op(dataItemName);
    _req.setVarName("chartResults");
    chartResults.encodeOp(_req);
    _req.setVarName("siInfo");
    siInfo.encodeOp(_req);
    _req.encodeEndStructure();
}

void spcItemResult_struct::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("dataItemName");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        dataItemName = _s;
    }
    _req.setVarName("chartResults");
    chartResults.decodeOp(_req);
    _req.setVarName("siInfo");
    siInfo.decodeOp(_req);
    _req.decodeEndStructure();
}

void spcItemResult_struct::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("dataItemName");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        dataItemName = _s;
    }
    _req.setVarName("chartResults");
    chartResults.decodeInOutOp(_req);
    _req.setVarName("siInfo");
    siInfo.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 spcItemResult_struct::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 spcItemResult_struct::__stubcode_dependents[] = {::spcChartResultSequence::__stubcode_version};
spcItemResult_struct::spcItemResult_struct()
{
}
spcItemResult_struct::spcItemResult_struct( const ::spcItemResult_struct &EB_s )
{
    operator=( EB_s );
}
spcItemResult_struct& spcItemResult_struct::operator=( const ::spcItemResult_struct &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   dataItemName = EB_s.dataItemName;
   chartResults = EB_s.chartResults;
   siInfo = EB_s.siInfo;
   return *this;
}
spcItemResult_struct_var::spcItemResult_struct_var () {
   _ptr = 0;
}
spcItemResult_struct_var::spcItemResult_struct_var (::spcItemResult_struct*_p) {
   _ptr = _p;
}
spcItemResult_struct_var::spcItemResult_struct_var (const ::spcItemResult_struct_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::spcItemResult_struct ();
   *(_ptr) = *(_s._ptr);
}
spcItemResult_struct_var& spcItemResult_struct_var::operator= (::spcItemResult_struct *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

spcItemResult_struct_var& spcItemResult_struct_var::operator= (const ::spcItemResult_struct_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::spcItemResult_struct ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

spcItemResult_struct_var::~spcItemResult_struct_var () {
   delete _ptr;
}

::spcItemResult_struct * spcItemResult_struct_var::operator-> ()
{ return _ptr; }

spcItemResult_struct_var::operator ::spcItemResult_struct_cvPtr () const 
{ return _ptr;}

spcItemResult_struct_var::operator ::spcItemResult_struct_vPtr& () 
{ return _ptr;}

spcItemResult_struct_var::operator const ::spcItemResult_struct& () const 
{ return *_ptr;}

spcItemResult_struct_var::operator ::spcItemResult_struct& () 
{ return *_ptr;}

const ::spcItemResult_struct& spcItemResult_struct_var::in () const { return *_ptr; }
::spcItemResult_struct& spcItemResult_struct_var::inout () { return *_ptr; }
::spcItemResult_struct*& spcItemResult_struct_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::spcItemResult_struct* spcItemResult_struct_var::_retn () {
  // yield ownership 
  spcItemResult_struct* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::spcItemResult_struct > spcItemResult_struct::spcItemResult_struct_Info;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_spcItemResultSequence_0::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_spcItemResultSequence_0::__stubcode_dependents[] = {::spcItemResult::__stubcode_version };
_IDL_SEQ_spcItemResultSequence_0::_IDL_SEQ_spcItemResultSequence_0()
{
  _defaultInit();
}
_IDL_SEQ_spcItemResultSequence_0::_IDL_SEQ_spcItemResultSequence_0 (const ::_IDL_SEQ_spcItemResultSequence_0& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_spcItemResultSequence_0::_IDL_SEQ_spcItemResultSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, ::spcItemResult* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
  _maximum = max;
}
_IDL_SEQ_spcItemResultSequence_0::_IDL_SEQ_spcItemResultSequence_0 (::CORBA::ULong max)
{
  _defaultInit();
  _maximum = max;
  if (_maximum > 0)
    _buffer = allocbuf_throw (max);
}
_IDL_SEQ_spcItemResultSequence_0::~_IDL_SEQ_spcItemResultSequence_0 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_spcItemResultSequence_0::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer  = NULL;
  _maximum = 0;
}
::spcItemResult* _IDL_SEQ_spcItemResultSequence_0::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  // Allocate an array of the element type (which may be a
  // self managed StructElem)
#ifdef SIVIEW_EBROKER
  ::spcItemResult* _ret;
  ::CORBA::ULong alloc_len = sizeof(::spcItemResult) * nelems + sizeof(::CORBA::ULong);
  ::CORBA::ULong * tmp = (::CORBA::ULong *)malloc( alloc_len );
  if( tmp )
  {
    memset( tmp, 0, alloc_len );
    *tmp = nelems;
    tmp++;
    _ret = (::spcItemResult*)tmp;
    for( CORBA::ULong _index = 0; _index < nelems; _index++ )
    {
      (void)new ((void*)( _ret + _index)) ::spcItemResult;
    }
  }
  return _ret;
#else
  return (::spcItemResult*) new ::spcItemResult[nelems];
#endif
}
::spcItemResult* _IDL_SEQ_spcItemResultSequence_0::allocbuf_throw (::CORBA::ULong nelems)
{
  ::spcItemResult* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_spcItemResultSequence_0::freebuf (::spcItemResult* _data)
{
#ifdef SIVIEW_EBROKER
  if (_data)
  {
    ::CORBA::ULong * tmp = (CORBA::ULong *)_data;
    tmp--;
    for( CORBA::ULong _index = *tmp; _index; _index-- )
    {
    #ifdef _WIN32
      _data[ _index - 1 ].~spcItemResult_struct ();
    #else
      _data[ _index - 1 ].::spcItemResult::~spcItemResult_struct ();
    #endif
    }
    free(tmp);
  }
#else
  if (_data)
    delete [] (::spcItemResult*) _data;
#endif
}
void _IDL_SEQ_spcItemResultSequence_0::replace (::CORBA::ULong max,  ::CORBA::ULong length, ::spcItemResult* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
  _maximum = max;
}
::_IDL_SEQ_spcItemResultSequence_0& _IDL_SEQ_spcItemResultSequence_0::operator= (const ::_IDL_SEQ_spcItemResultSequence_0& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  _maximum = max;
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_spcItemResultSequence_0::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::spcItemResult* data)
{
  return; // simple elements don't require resetting.
}
void _IDL_SEQ_spcItemResultSequence_0::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::spcItemResult* src, ::spcItemResult* tgt)
{
  // Copy elements 
  ::spcItemResult* _src = (::spcItemResult*) src;
  ::spcItemResult* _tgt = (::spcItemResult*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_spcItemResultSequence_0::maximum () const
{
  return   _maximum;
;
}
::CORBA::ULong _IDL_SEQ_spcItemResultSequence_0::length () const
{
  return _length;
}
void _IDL_SEQ_spcItemResultSequence_0::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  ::spcItemResult* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace(max, len, newBuffer, 1);
  return;
}
::spcItemResult& _IDL_SEQ_spcItemResultSequence_0::operator[] (::CORBA::ULong i)
{
  __cs_spcsvrstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return _buffer[i];
}
const ::spcItemResult& _IDL_SEQ_spcItemResultSequence_0::operator[] (::CORBA::ULong i) const 
{
  __cs_spcsvrstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return ((const ::spcItemResult*)_buffer) [i];
}
::CORBA::Boolean _IDL_SEQ_spcItemResultSequence_0::release() const 
{ return _release; }
::spcItemResult* _IDL_SEQ_spcItemResultSequence_0::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::spcItemResult* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::spcItemResult* _IDL_SEQ_spcItemResultSequence_0::get_buffer () const
{
    return (const ::spcItemResult*) _buffer;
}
void _IDL_SEQ_spcItemResultSequence_0::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       ::spcItemResult_struct const* _elem =     (::spcItemResult_struct*) _buffer;
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
           _elem->encodeOp(_req);
       }
    }
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_spcItemResultSequence_0::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
      ::spcItemResult_struct* _elem = (::spcItemResult_struct*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_spcItemResultSequence_0::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(max,__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
      ::spcItemResult_struct* _elem = (::spcItemResult_struct*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeInOutOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_spcItemResultSequence_0_var::_IDL_SEQ_spcItemResultSequence_0_var () {
   _ptr = 0;
    }

_IDL_SEQ_spcItemResultSequence_0_var::_IDL_SEQ_spcItemResultSequence_0_var (::_IDL_SEQ_spcItemResultSequence_0 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_spcItemResultSequence_0_var::_IDL_SEQ_spcItemResultSequence_0_var (const ::_IDL_SEQ_spcItemResultSequence_0_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_spcItemResultSequence_0 (*(_s._ptr));
    }

_IDL_SEQ_spcItemResultSequence_0_var& _IDL_SEQ_spcItemResultSequence_0_var::operator= (::_IDL_SEQ_spcItemResultSequence_0 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_spcItemResultSequence_0_var& _IDL_SEQ_spcItemResultSequence_0_var::operator= (const ::_IDL_SEQ_spcItemResultSequence_0_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_spcItemResultSequence_0 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_spcItemResultSequence_0_var::~_IDL_SEQ_spcItemResultSequence_0_var()
{
   delete _ptr;
}
::_IDL_SEQ_spcItemResultSequence_0 * _IDL_SEQ_spcItemResultSequence_0_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_spcItemResultSequence_0_var::operator ::_IDL_SEQ_spcItemResultSequence_0_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_spcItemResultSequence_0_var::operator ::_IDL_SEQ_spcItemResultSequence_0_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_spcItemResultSequence_0_var::operator _IDL_SEQ_spcItemResultSequence_0() const
{
   return *_ptr;
}
const ::spcItemResult& _IDL_SEQ_spcItemResultSequence_0_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_spcItemResultSequence_0 *)_ptr)[index];
}
::spcItemResult& _IDL_SEQ_spcItemResultSequence_0_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::spcItemResult& _IDL_SEQ_spcItemResultSequence_0_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_spcItemResultSequence_0 *)_ptr)[index];
}
::spcItemResult& _IDL_SEQ_spcItemResultSequence_0_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_spcItemResultSequence_0& _IDL_SEQ_spcItemResultSequence_0_var::in () const { return *_ptr; }
::_IDL_SEQ_spcItemResultSequence_0& _IDL_SEQ_spcItemResultSequence_0_var::inout () { return *_ptr; }
::_IDL_SEQ_spcItemResultSequence_0*& _IDL_SEQ_spcItemResultSequence_0_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_spcItemResultSequence_0* _IDL_SEQ_spcItemResultSequence_0_var::_retn () {
  // yield ownership 
  _IDL_SEQ_spcItemResultSequence_0* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_spcItemResultSequence_0 > _IDL_SEQ_spcItemResultSequence_0::spcItemResultSequence_0_Info;

void spcChamberHoldAction_struct::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("chamberID");
    _req.encode_string_op(chamberID);
    _req.setVarName("chamberHoldAction");
    _req.encode_string_op(chamberHoldAction);
    _req.setVarName("chamberRecipeHoldAction");
    _req.encode_string_op(chamberRecipeHoldAction);
    _req.setVarName("siInfo");
    siInfo.encodeOp(_req);
    _req.encodeEndStructure();
}

void spcChamberHoldAction_struct::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("chamberID");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chamberID = _s;
    }
    _req.setVarName("chamberHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chamberHoldAction = _s;
    }
    _req.setVarName("chamberRecipeHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chamberRecipeHoldAction = _s;
    }
    _req.setVarName("siInfo");
    siInfo.decodeOp(_req);
    _req.decodeEndStructure();
}

void spcChamberHoldAction_struct::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("chamberID");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chamberID = _s;
    }
    _req.setVarName("chamberHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chamberHoldAction = _s;
    }
    _req.setVarName("chamberRecipeHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        chamberRecipeHoldAction = _s;
    }
    _req.setVarName("siInfo");
    siInfo.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 spcChamberHoldAction_struct::__stubcode_version;
spcChamberHoldAction_struct::spcChamberHoldAction_struct()
{
}
spcChamberHoldAction_struct::spcChamberHoldAction_struct( const ::spcChamberHoldAction_struct &EB_s )
{
    operator=( EB_s );
}
spcChamberHoldAction_struct& spcChamberHoldAction_struct::operator=( const ::spcChamberHoldAction_struct &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   chamberID = EB_s.chamberID;
   chamberHoldAction = EB_s.chamberHoldAction;
   chamberRecipeHoldAction = EB_s.chamberRecipeHoldAction;
   siInfo = EB_s.siInfo;
   return *this;
}
spcChamberHoldAction_struct_var::spcChamberHoldAction_struct_var () {
   _ptr = 0;
}
spcChamberHoldAction_struct_var::spcChamberHoldAction_struct_var (::spcChamberHoldAction_struct*_p) {
   _ptr = _p;
}
spcChamberHoldAction_struct_var::spcChamberHoldAction_struct_var (const ::spcChamberHoldAction_struct_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::spcChamberHoldAction_struct ();
   *(_ptr) = *(_s._ptr);
}
spcChamberHoldAction_struct_var& spcChamberHoldAction_struct_var::operator= (::spcChamberHoldAction_struct *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

spcChamberHoldAction_struct_var& spcChamberHoldAction_struct_var::operator= (const ::spcChamberHoldAction_struct_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::spcChamberHoldAction_struct ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

spcChamberHoldAction_struct_var::~spcChamberHoldAction_struct_var () {
   delete _ptr;
}

::spcChamberHoldAction_struct * spcChamberHoldAction_struct_var::operator-> ()
{ return _ptr; }

spcChamberHoldAction_struct_var::operator ::spcChamberHoldAction_struct_cvPtr () const 
{ return _ptr;}

spcChamberHoldAction_struct_var::operator ::spcChamberHoldAction_struct_vPtr& () 
{ return _ptr;}

spcChamberHoldAction_struct_var::operator const ::spcChamberHoldAction_struct& () const 
{ return *_ptr;}

spcChamberHoldAction_struct_var::operator ::spcChamberHoldAction_struct& () 
{ return *_ptr;}

const ::spcChamberHoldAction_struct& spcChamberHoldAction_struct_var::in () const { return *_ptr; }
::spcChamberHoldAction_struct& spcChamberHoldAction_struct_var::inout () { return *_ptr; }
::spcChamberHoldAction_struct*& spcChamberHoldAction_struct_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::spcChamberHoldAction_struct* spcChamberHoldAction_struct_var::_retn () {
  // yield ownership 
  spcChamberHoldAction_struct* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::spcChamberHoldAction_struct > spcChamberHoldAction_struct::spcChamberHoldAction_struct_Info;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_spcChamberHoldActionSequence_0::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_spcChamberHoldActionSequence_0::__stubcode_dependents[] = {::spcChamberHoldAction::__stubcode_version };
_IDL_SEQ_spcChamberHoldActionSequence_0::_IDL_SEQ_spcChamberHoldActionSequence_0()
{
  _defaultInit();
}
_IDL_SEQ_spcChamberHoldActionSequence_0::_IDL_SEQ_spcChamberHoldActionSequence_0 (const ::_IDL_SEQ_spcChamberHoldActionSequence_0& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_spcChamberHoldActionSequence_0::_IDL_SEQ_spcChamberHoldActionSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, ::spcChamberHoldAction* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
  _maximum = max;
}
_IDL_SEQ_spcChamberHoldActionSequence_0::_IDL_SEQ_spcChamberHoldActionSequence_0 (::CORBA::ULong max)
{
  _defaultInit();
  _maximum = max;
  if (_maximum > 0)
    _buffer = allocbuf_throw (max);
}
_IDL_SEQ_spcChamberHoldActionSequence_0::~_IDL_SEQ_spcChamberHoldActionSequence_0 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_spcChamberHoldActionSequence_0::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer  = NULL;
  _maximum = 0;
}
::spcChamberHoldAction* _IDL_SEQ_spcChamberHoldActionSequence_0::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  // Allocate an array of the element type (which may be a
  // self managed StructElem)
#ifdef SIVIEW_EBROKER
  ::spcChamberHoldAction* _ret;
  ::CORBA::ULong alloc_len = sizeof(::spcChamberHoldAction) * nelems + sizeof(::CORBA::ULong);
  ::CORBA::ULong * tmp = (::CORBA::ULong *)malloc( alloc_len );
  if( tmp )
  {
    memset( tmp, 0, alloc_len );
    *tmp = nelems;
    tmp++;
    _ret = (::spcChamberHoldAction*)tmp;
    for( CORBA::ULong _index = 0; _index < nelems; _index++ )
    {
      (void)new ((void*)( _ret + _index)) ::spcChamberHoldAction;
    }
  }
  return _ret;
#else
  return (::spcChamberHoldAction*) new ::spcChamberHoldAction[nelems];
#endif
}
::spcChamberHoldAction* _IDL_SEQ_spcChamberHoldActionSequence_0::allocbuf_throw (::CORBA::ULong nelems)
{
  ::spcChamberHoldAction* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_spcChamberHoldActionSequence_0::freebuf (::spcChamberHoldAction* _data)
{
#ifdef SIVIEW_EBROKER
  if (_data)
  {
    ::CORBA::ULong * tmp = (CORBA::ULong *)_data;
    tmp--;
    for( CORBA::ULong _index = *tmp; _index; _index-- )
    {
    #ifdef _WIN32
      _data[ _index - 1 ].~spcChamberHoldAction_struct ();
    #else
      _data[ _index - 1 ].::spcChamberHoldAction::~spcChamberHoldAction_struct ();
    #endif
    }
    free(tmp);
  }
#else
  if (_data)
    delete [] (::spcChamberHoldAction*) _data;
#endif
}
void _IDL_SEQ_spcChamberHoldActionSequence_0::replace (::CORBA::ULong max,  ::CORBA::ULong length, ::spcChamberHoldAction* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
  _maximum = max;
}
::_IDL_SEQ_spcChamberHoldActionSequence_0& _IDL_SEQ_spcChamberHoldActionSequence_0::operator= (const ::_IDL_SEQ_spcChamberHoldActionSequence_0& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  _maximum = max;
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_spcChamberHoldActionSequence_0::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::spcChamberHoldAction* data)
{
  return; // simple elements don't require resetting.
}
void _IDL_SEQ_spcChamberHoldActionSequence_0::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::spcChamberHoldAction* src, ::spcChamberHoldAction* tgt)
{
  // Copy elements 
  ::spcChamberHoldAction* _src = (::spcChamberHoldAction*) src;
  ::spcChamberHoldAction* _tgt = (::spcChamberHoldAction*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_spcChamberHoldActionSequence_0::maximum () const
{
  return   _maximum;
;
}
::CORBA::ULong _IDL_SEQ_spcChamberHoldActionSequence_0::length () const
{
  return _length;
}
void _IDL_SEQ_spcChamberHoldActionSequence_0::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  ::spcChamberHoldAction* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace(max, len, newBuffer, 1);
  return;
}
::spcChamberHoldAction& _IDL_SEQ_spcChamberHoldActionSequence_0::operator[] (::CORBA::ULong i)
{
  __cs_spcsvrstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return _buffer[i];
}
const ::spcChamberHoldAction& _IDL_SEQ_spcChamberHoldActionSequence_0::operator[] (::CORBA::ULong i) const 
{
  __cs_spcsvrstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return ((const ::spcChamberHoldAction*)_buffer) [i];
}
::CORBA::Boolean _IDL_SEQ_spcChamberHoldActionSequence_0::release() const 
{ return _release; }
::spcChamberHoldAction* _IDL_SEQ_spcChamberHoldActionSequence_0::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::spcChamberHoldAction* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::spcChamberHoldAction* _IDL_SEQ_spcChamberHoldActionSequence_0::get_buffer () const
{
    return (const ::spcChamberHoldAction*) _buffer;
}
void _IDL_SEQ_spcChamberHoldActionSequence_0::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       ::spcChamberHoldAction_struct const* _elem =     (::spcChamberHoldAction_struct*) _buffer;
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
           _elem->encodeOp(_req);
       }
    }
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_spcChamberHoldActionSequence_0::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
      ::spcChamberHoldAction_struct* _elem = (::spcChamberHoldAction_struct*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_spcChamberHoldActionSequence_0::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(max,__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
      ::spcChamberHoldAction_struct* _elem = (::spcChamberHoldAction_struct*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeInOutOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_spcChamberHoldActionSequence_0_var::_IDL_SEQ_spcChamberHoldActionSequence_0_var () {
   _ptr = 0;
    }

_IDL_SEQ_spcChamberHoldActionSequence_0_var::_IDL_SEQ_spcChamberHoldActionSequence_0_var (::_IDL_SEQ_spcChamberHoldActionSequence_0 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_spcChamberHoldActionSequence_0_var::_IDL_SEQ_spcChamberHoldActionSequence_0_var (const ::_IDL_SEQ_spcChamberHoldActionSequence_0_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_spcChamberHoldActionSequence_0 (*(_s._ptr));
    }

_IDL_SEQ_spcChamberHoldActionSequence_0_var& _IDL_SEQ_spcChamberHoldActionSequence_0_var::operator= (::_IDL_SEQ_spcChamberHoldActionSequence_0 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_spcChamberHoldActionSequence_0_var& _IDL_SEQ_spcChamberHoldActionSequence_0_var::operator= (const ::_IDL_SEQ_spcChamberHoldActionSequence_0_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_spcChamberHoldActionSequence_0 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_spcChamberHoldActionSequence_0_var::~_IDL_SEQ_spcChamberHoldActionSequence_0_var()
{
   delete _ptr;
}
::_IDL_SEQ_spcChamberHoldActionSequence_0 * _IDL_SEQ_spcChamberHoldActionSequence_0_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_spcChamberHoldActionSequence_0_var::operator ::_IDL_SEQ_spcChamberHoldActionSequence_0_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_spcChamberHoldActionSequence_0_var::operator ::_IDL_SEQ_spcChamberHoldActionSequence_0_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_spcChamberHoldActionSequence_0_var::operator _IDL_SEQ_spcChamberHoldActionSequence_0() const
{
   return *_ptr;
}
const ::spcChamberHoldAction& _IDL_SEQ_spcChamberHoldActionSequence_0_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_spcChamberHoldActionSequence_0 *)_ptr)[index];
}
::spcChamberHoldAction& _IDL_SEQ_spcChamberHoldActionSequence_0_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::spcChamberHoldAction& _IDL_SEQ_spcChamberHoldActionSequence_0_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_spcChamberHoldActionSequence_0 *)_ptr)[index];
}
::spcChamberHoldAction& _IDL_SEQ_spcChamberHoldActionSequence_0_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_spcChamberHoldActionSequence_0& _IDL_SEQ_spcChamberHoldActionSequence_0_var::in () const { return *_ptr; }
::_IDL_SEQ_spcChamberHoldActionSequence_0& _IDL_SEQ_spcChamberHoldActionSequence_0_var::inout () { return *_ptr; }
::_IDL_SEQ_spcChamberHoldActionSequence_0*& _IDL_SEQ_spcChamberHoldActionSequence_0_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_spcChamberHoldActionSequence_0* _IDL_SEQ_spcChamberHoldActionSequence_0_var::_retn () {
  // yield ownership 
  _IDL_SEQ_spcChamberHoldActionSequence_0* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_spcChamberHoldActionSequence_0 > _IDL_SEQ_spcChamberHoldActionSequence_0::spcChamberHoldActionSequence_0_Info;

void spcOutput_struct::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("txRC");
    _req.encode_string_op(txRC);
    _req.setVarName("lotID");
    lotID.encodeOp(_req);
    _req.setVarName("lotRC");
    _req.encode_string_op(lotRC);
    _req.setVarName("lotHoldAction");
    _req.encode_string_op(lotHoldAction);
    _req.setVarName("chamberHoldActions");
    chamberHoldActions.encodeOp(_req);
    _req.setVarName("equipmentHoldAction");
    _req.encode_string_op(equipmentHoldAction);
    _req.setVarName("processHoldAction");
    _req.encode_string_op(processHoldAction);
    _req.setVarName("recipeHoldAction");
    _req.encode_string_op(recipeHoldAction);
    _req.setVarName("reworkBranchAction");
    _req.encode_string_op(reworkBranchAction);
    _req.setVarName("mailSendAction");
    _req.encode_string_op(mailSendAction);
    _req.setVarName("bankMoveAction");
    _req.encode_string_op(bankMoveAction);
    _req.setVarName("bankID");
    _req.encode_string_op(bankID);
    _req.setVarName("reworkRouteID");
    _req.encode_string_op(reworkRouteID);
    _req.setVarName("productHoldAction");
    _req.encode_string_op(productHoldAction);
    _req.setVarName("reticleHoldAction");
    _req.encode_string_op(reticleHoldAction);
    _req.setVarName("reticleGroupHoldAction");
    _req.encode_string_op(reticleGroupHoldAction);
    _req.setVarName("moduleHoldAction");
    _req.encode_string_op(moduleHoldAction);
    _req.setVarName("routeHoldAction");
    _req.encode_string_op(routeHoldAction);
    _req.setVarName("routeOpeNoProductHoldAction");
    _req.encode_string_op(routeOpeNoProductHoldAction);
    _req.setVarName("eqptRecipeHoldAction");
    _req.encode_string_op(eqptRecipeHoldAction);
    _req.setVarName("eqptOpeNoHoldAction");
    _req.encode_string_op(eqptOpeNoHoldAction);
    _req.setVarName("eqptRecticleHoldAction");
    _req.encode_string_op(eqptRecticleHoldAction);
    _req.setVarName("eqptProcessHoldAction");
    _req.encode_string_op(eqptProcessHoldAction);
    _req.setVarName("eqptChamberRecipeHoldAction");
    _req.encode_string_op(eqptChamberRecipeHoldAction);
    _req.setVarName("eqptProductRecipeHoldAction");
    _req.encode_string_op(eqptProductRecipeHoldAction);
    _req.setVarName("routeOpeNoHoldAction");
    _req.encode_string_op(routeOpeNoHoldAction);
    _req.setVarName("eqptChamberHoldAction");
    _req.encode_string_op(eqptChamberHoldAction);
    _req.setVarName("otherAction");
    _req.encode_string_op(otherAction);
    _req.setVarName("itemResults");
    itemResults.encodeOp(_req);
    _req.setVarName("siInfo");
    siInfo.encodeOp(_req);
    _req.encodeEndStructure();
}

void spcOutput_struct::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("txRC");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        txRC = _s;
    }
    _req.setVarName("lotID");
    lotID.decodeOp(_req);
    _req.setVarName("lotRC");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        lotRC = _s;
    }
    _req.setVarName("lotHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        lotHoldAction = _s;
    }
    _req.setVarName("chamberHoldActions");
    chamberHoldActions.decodeOp(_req);
    _req.setVarName("equipmentHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        equipmentHoldAction = _s;
    }
    _req.setVarName("processHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        processHoldAction = _s;
    }
    _req.setVarName("recipeHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        recipeHoldAction = _s;
    }
    _req.setVarName("reworkBranchAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        reworkBranchAction = _s;
    }
    _req.setVarName("mailSendAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        mailSendAction = _s;
    }
    _req.setVarName("bankMoveAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        bankMoveAction = _s;
    }
    _req.setVarName("bankID");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        bankID = _s;
    }
    _req.setVarName("reworkRouteID");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        reworkRouteID = _s;
    }
    _req.setVarName("productHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        productHoldAction = _s;
    }
    _req.setVarName("reticleHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        reticleHoldAction = _s;
    }
    _req.setVarName("reticleGroupHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        reticleGroupHoldAction = _s;
    }
    _req.setVarName("moduleHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        moduleHoldAction = _s;
    }
    _req.setVarName("routeHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        routeHoldAction = _s;
    }
    _req.setVarName("routeOpeNoProductHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        routeOpeNoProductHoldAction = _s;
    }
    _req.setVarName("eqptRecipeHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        eqptRecipeHoldAction = _s;
    }
    _req.setVarName("eqptOpeNoHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        eqptOpeNoHoldAction = _s;
    }
    _req.setVarName("eqptRecticleHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        eqptRecticleHoldAction = _s;
    }
    _req.setVarName("eqptProcessHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        eqptProcessHoldAction = _s;
    }
    _req.setVarName("eqptChamberRecipeHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        eqptChamberRecipeHoldAction = _s;
    }
    _req.setVarName("eqptProductRecipeHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        eqptProductRecipeHoldAction = _s;
    }
    _req.setVarName("routeOpeNoHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        routeOpeNoHoldAction = _s;
    }
    _req.setVarName("eqptChamberHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        eqptChamberHoldAction = _s;
    }
    _req.setVarName("otherAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        otherAction = _s;
    }
    _req.setVarName("itemResults");
    itemResults.decodeOp(_req);
    _req.setVarName("siInfo");
    siInfo.decodeOp(_req);
    _req.decodeEndStructure();
}

void spcOutput_struct::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("txRC");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        txRC = _s;
    }
    _req.setVarName("lotID");
    lotID.decodeInOutOp(_req);
    _req.setVarName("lotRC");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        lotRC = _s;
    }
    _req.setVarName("lotHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        lotHoldAction = _s;
    }
    _req.setVarName("chamberHoldActions");
    chamberHoldActions.decodeInOutOp(_req);
    _req.setVarName("equipmentHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        equipmentHoldAction = _s;
    }
    _req.setVarName("processHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        processHoldAction = _s;
    }
    _req.setVarName("recipeHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        recipeHoldAction = _s;
    }
    _req.setVarName("reworkBranchAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        reworkBranchAction = _s;
    }
    _req.setVarName("mailSendAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        mailSendAction = _s;
    }
    _req.setVarName("bankMoveAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        bankMoveAction = _s;
    }
    _req.setVarName("bankID");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        bankID = _s;
    }
    _req.setVarName("reworkRouteID");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        reworkRouteID = _s;
    }
    _req.setVarName("productHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        productHoldAction = _s;
    }
    _req.setVarName("reticleHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        reticleHoldAction = _s;
    }
    _req.setVarName("reticleGroupHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        reticleGroupHoldAction = _s;
    }
    _req.setVarName("moduleHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        moduleHoldAction = _s;
    }
    _req.setVarName("routeHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        routeHoldAction = _s;
    }
    _req.setVarName("routeOpeNoProductHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        routeOpeNoProductHoldAction = _s;
    }
    _req.setVarName("eqptRecipeHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        eqptRecipeHoldAction = _s;
    }
    _req.setVarName("eqptOpeNoHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        eqptOpeNoHoldAction = _s;
    }
    _req.setVarName("eqptRecticleHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        eqptRecticleHoldAction = _s;
    }
    _req.setVarName("eqptProcessHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        eqptProcessHoldAction = _s;
    }
    _req.setVarName("eqptChamberRecipeHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        eqptChamberRecipeHoldAction = _s;
    }
    _req.setVarName("eqptProductRecipeHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        eqptProductRecipeHoldAction = _s;
    }
    _req.setVarName("routeOpeNoHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        routeOpeNoHoldAction = _s;
    }
    _req.setVarName("eqptChamberHoldAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        eqptChamberHoldAction = _s;
    }
    _req.setVarName("otherAction");
    {
        char * _s = 0;
        _req.decode_string_op(_s);
        otherAction = _s;
    }
    _req.setVarName("itemResults");
    itemResults.decodeInOutOp(_req);
    _req.setVarName("siInfo");
    siInfo.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 spcOutput_struct::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 spcOutput_struct::__stubcode_dependents[] = {::spcItemResultSequence::__stubcode_version,::objectIdentifier::__stubcode_version,::spcChamberHoldActionSequence::__stubcode_version};
spcOutput_struct::spcOutput_struct()
{
}
spcOutput_struct::spcOutput_struct( const ::spcOutput_struct &EB_s )
{
    operator=( EB_s );
}
spcOutput_struct& spcOutput_struct::operator=( const ::spcOutput_struct &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   txRC = EB_s.txRC;
   lotID = EB_s.lotID;
   lotRC = EB_s.lotRC;
   lotHoldAction = EB_s.lotHoldAction;
   chamberHoldActions = EB_s.chamberHoldActions;
   equipmentHoldAction = EB_s.equipmentHoldAction;
   processHoldAction = EB_s.processHoldAction;
   recipeHoldAction = EB_s.recipeHoldAction;
   reworkBranchAction = EB_s.reworkBranchAction;
   mailSendAction = EB_s.mailSendAction;
   bankMoveAction = EB_s.bankMoveAction;
   bankID = EB_s.bankID;
   reworkRouteID = EB_s.reworkRouteID;
   productHoldAction = EB_s.productHoldAction;
   reticleHoldAction = EB_s.reticleHoldAction;
   reticleGroupHoldAction = EB_s.reticleGroupHoldAction;
   moduleHoldAction = EB_s.moduleHoldAction;
   routeHoldAction = EB_s.routeHoldAction;
   routeOpeNoProductHoldAction = EB_s.routeOpeNoProductHoldAction;
   eqptRecipeHoldAction = EB_s.eqptRecipeHoldAction;
   eqptOpeNoHoldAction = EB_s.eqptOpeNoHoldAction;
   eqptRecticleHoldAction = EB_s.eqptRecticleHoldAction;
   eqptProcessHoldAction = EB_s.eqptProcessHoldAction;
   eqptChamberRecipeHoldAction = EB_s.eqptChamberRecipeHoldAction;
   eqptProductRecipeHoldAction = EB_s.eqptProductRecipeHoldAction;
   routeOpeNoHoldAction = EB_s.routeOpeNoHoldAction;
   eqptChamberHoldAction = EB_s.eqptChamberHoldAction;
   otherAction = EB_s.otherAction;
   itemResults = EB_s.itemResults;
   siInfo = EB_s.siInfo;
   return *this;
}
spcOutput_struct_var::spcOutput_struct_var () {
   _ptr = 0;
}
spcOutput_struct_var::spcOutput_struct_var (::spcOutput_struct*_p) {
   _ptr = _p;
}
spcOutput_struct_var::spcOutput_struct_var (const ::spcOutput_struct_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::spcOutput_struct ();
   *(_ptr) = *(_s._ptr);
}
spcOutput_struct_var& spcOutput_struct_var::operator= (::spcOutput_struct *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

spcOutput_struct_var& spcOutput_struct_var::operator= (const ::spcOutput_struct_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::spcOutput_struct ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

spcOutput_struct_var::~spcOutput_struct_var () {
   delete _ptr;
}

::spcOutput_struct * spcOutput_struct_var::operator-> ()
{ return _ptr; }

spcOutput_struct_var::operator ::spcOutput_struct_cvPtr () const 
{ return _ptr;}

spcOutput_struct_var::operator ::spcOutput_struct_vPtr& () 
{ return _ptr;}

spcOutput_struct_var::operator const ::spcOutput_struct& () const 
{ return *_ptr;}

spcOutput_struct_var::operator ::spcOutput_struct& () 
{ return *_ptr;}

const ::spcOutput_struct& spcOutput_struct_var::in () const { return *_ptr; }
::spcOutput_struct& spcOutput_struct_var::inout () { return *_ptr; }
::spcOutput_struct*& spcOutput_struct_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::spcOutput_struct* spcOutput_struct_var::_retn () {
  // yield ownership 
  spcOutput_struct* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::spcOutput_struct > spcOutput_struct::spcOutput_struct_Info;
/*
 * TypeCode constants
 */
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcDcItem_struct = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcDcItem_struct =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcSpcDcItem = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcSpcDcItem =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcDcItemSequence = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcDcItemSequence =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcWaferIDByChamber_struct = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcWaferIDByChamber_struct =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcWaferIDByChamber = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcWaferIDByChamber =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcWaferIDByChamberSequence = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcWaferIDByChamberSequence =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcInput_struct = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcInput_struct =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcInput = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcInput =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcHoldActionResult_struct = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcHoldActionResult_struct =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcHoldActionResult = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcHoldActionResult =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcCheckResultByRule_struct = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcCheckResultByRule_struct =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcCheckResultByRule = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcCheckResultByRule =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcCheckResultByRuleSequence = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcCheckResultByRuleSequence =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcChartResult_struct = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcChartResult_struct =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcChartResult = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcChartResult =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcChartResultSequence = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcChartResultSequence =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcItemResult_struct = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcItemResult_struct =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcItemResult = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcItemResult =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcItemResultSequence = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcItemResultSequence =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcChamberHoldAction_struct = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcChamberHoldAction_struct =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcChamberHoldAction = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcChamberHoldAction =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcChamberHoldActionSequence = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcChamberHoldActionSequence =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcOutput_struct = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcOutput_struct =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_spcOutput = NULL;
#else
::CORBA::TypeCode_ptr _tc_spcOutput =NULL;
#endif // _USE_NAMESPACE
static void __cs_spcsvrstr_emit_tc(::CORBA::ORB_ptr _orb)
{ 

::CORBA::StructMemberSeq _members__tmp_tc__spcDcItem_struct(10);
_members__tmp_tc__spcDcItem_struct.length(10);
::CORBA::StructMember _StructMember__members__tmp_tc__spcDcItem_struct;
_StructMember__members__tmp_tc__spcDcItem_struct.type_def = NULL;
_StructMember__members__tmp_tc__spcDcItem_struct.name = (const char *)"dataItemName";
_StructMember__members__tmp_tc__spcDcItem_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcDcItem_struct[0] = _StructMember__members__tmp_tc__spcDcItem_struct;
_StructMember__members__tmp_tc__spcDcItem_struct.name = (const char *)"waferID";
_StructMember__members__tmp_tc__spcDcItem_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcDcItem_struct[1] = _StructMember__members__tmp_tc__spcDcItem_struct;
_StructMember__members__tmp_tc__spcDcItem_struct.name = (const char *)"waferPosition";
_StructMember__members__tmp_tc__spcDcItem_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcDcItem_struct[2] = _StructMember__members__tmp_tc__spcDcItem_struct;
_StructMember__members__tmp_tc__spcDcItem_struct.name = (const char *)"sitePosition";
_StructMember__members__tmp_tc__spcDcItem_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcDcItem_struct[3] = _StructMember__members__tmp_tc__spcDcItem_struct;
_StructMember__members__tmp_tc__spcDcItem_struct.name = (const char *)"dataValue";
_StructMember__members__tmp_tc__spcDcItem_struct.type = ::CORBA::_tc_any;
_members__tmp_tc__spcDcItem_struct[4] = _StructMember__members__tmp_tc__spcDcItem_struct;
_StructMember__members__tmp_tc__spcDcItem_struct.name = (const char *)"targetValue";
_StructMember__members__tmp_tc__spcDcItem_struct.type = ::CORBA::_tc_double;
_members__tmp_tc__spcDcItem_struct[5] = _StructMember__members__tmp_tc__spcDcItem_struct;
_StructMember__members__tmp_tc__spcDcItem_struct.name = (const char *)"specCheckResult";
_StructMember__members__tmp_tc__spcDcItem_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcDcItem_struct[6] = _StructMember__members__tmp_tc__spcDcItem_struct;
_StructMember__members__tmp_tc__spcDcItem_struct.name = (const char *)"comment";
_StructMember__members__tmp_tc__spcDcItem_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcDcItem_struct[7] = _StructMember__members__tmp_tc__spcDcItem_struct;
_StructMember__members__tmp_tc__spcDcItem_struct.name = (const char *)"chamber_list";
_StructMember__members__tmp_tc__spcDcItem_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcDcItem_struct[8] = _StructMember__members__tmp_tc__spcDcItem_struct;
_StructMember__members__tmp_tc__spcDcItem_struct.name = (const char *)"siInfo";
_StructMember__members__tmp_tc__spcDcItem_struct.type = ::CORBA::_tc_any;
_members__tmp_tc__spcDcItem_struct[9] = _StructMember__members__tmp_tc__spcDcItem_struct;
::CORBA::TypeCode_ptr _tmp_tc__spcDcItem_struct= _orb->create_struct_tc("IDL:spcDcItem_struct:1.0", "spcDcItem_struct", _members__tmp_tc__spcDcItem_struct, 0);
_tc_spcDcItem_struct = _tmp_tc__spcDcItem_struct;
_orb->setClassInfo(::_tc_spcDcItem_struct, &::spcDcItem_struct::spcDcItem_struct_Info );
::CORBA::TypeCode_ptr _tmp_tc__spcSpcDcItem= _orb->create_alias_tc("IDL:spcSpcDcItem:1.0", "spcSpcDcItem", _tmp_tc__spcDcItem_struct, 0);
_tc_spcSpcDcItem = _tmp_tc__spcSpcDcItem;
_orb->setClassInfo(::_tc_spcSpcDcItem, &::spcSpcDcItem::spcDcItem_struct_Info );
::CORBA::TypeCode_ptr _tmp_tc__spcDcItemSequence= _orb->create_alias_tc("IDL:spcDcItemSequence:1.0", "spcDcItemSequence",  _orb->create_sequence_tc(0, _tmp_tc__spcSpcDcItem, 0), 0);
_tc_spcDcItemSequence = _tmp_tc__spcDcItemSequence;
_orb->setClassInfo(::_tc_spcDcItemSequence, &::spcDcItemSequence::spcDcItemSequence_0_Info );
::CORBA::StructMemberSeq _members__tmp_tc__spcWaferIDByChamber_struct(3);
_members__tmp_tc__spcWaferIDByChamber_struct.length(3);
::CORBA::StructMember _StructMember__members__tmp_tc__spcWaferIDByChamber_struct;
_StructMember__members__tmp_tc__spcWaferIDByChamber_struct.type_def = NULL;
_StructMember__members__tmp_tc__spcWaferIDByChamber_struct.name = (const char *)"procChamber";
_StructMember__members__tmp_tc__spcWaferIDByChamber_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcWaferIDByChamber_struct[0] = _StructMember__members__tmp_tc__spcWaferIDByChamber_struct;
_StructMember__members__tmp_tc__spcWaferIDByChamber_struct.name = (const char *)"waferIDs";
::CORBA::TypeCode_ptr _tmp_tc__stringSequence= _orb->create_alias_tc("IDL:stringSequence:1.0", "stringSequence",  _orb->create_sequence_tc(0, _orb->create_string_tc(0, 0), 0), 0);
_StructMember__members__tmp_tc__spcWaferIDByChamber_struct.type = _tmp_tc__stringSequence;
_members__tmp_tc__spcWaferIDByChamber_struct[1] = _StructMember__members__tmp_tc__spcWaferIDByChamber_struct;
_StructMember__members__tmp_tc__spcWaferIDByChamber_struct.name = (const char *)"siInfo";
_StructMember__members__tmp_tc__spcWaferIDByChamber_struct.type = ::CORBA::_tc_any;
_members__tmp_tc__spcWaferIDByChamber_struct[2] = _StructMember__members__tmp_tc__spcWaferIDByChamber_struct;
::CORBA::TypeCode_ptr _tmp_tc__spcWaferIDByChamber_struct= _orb->create_struct_tc("IDL:spcWaferIDByChamber_struct:1.0", "spcWaferIDByChamber_struct", _members__tmp_tc__spcWaferIDByChamber_struct, 0);
_tc_spcWaferIDByChamber_struct = _tmp_tc__spcWaferIDByChamber_struct;
_orb->setClassInfo(::_tc_spcWaferIDByChamber_struct, &::spcWaferIDByChamber_struct::spcWaferIDByChamber_struct_Info );
::CORBA::TypeCode_ptr _tmp_tc__spcWaferIDByChamber= _orb->create_alias_tc("IDL:spcWaferIDByChamber:1.0", "spcWaferIDByChamber", _tmp_tc__spcWaferIDByChamber_struct, 0);
_tc_spcWaferIDByChamber = _tmp_tc__spcWaferIDByChamber;
_orb->setClassInfo(::_tc_spcWaferIDByChamber, &::spcWaferIDByChamber::spcWaferIDByChamber_struct_Info );
::CORBA::TypeCode_ptr _tmp_tc__spcWaferIDByChamberSequence= _orb->create_alias_tc("IDL:spcWaferIDByChamberSequence:1.0", "spcWaferIDByChamberSequence",  _orb->create_sequence_tc(0, _tmp_tc__spcWaferIDByChamber, 0), 0);
_tc_spcWaferIDByChamberSequence = _tmp_tc__spcWaferIDByChamberSequence;
_orb->setClassInfo(::_tc_spcWaferIDByChamberSequence, &::spcWaferIDByChamberSequence::spcWaferIDByChamberSequence_0_Info );
::CORBA::StructMemberSeq _members__tmp_tc__spcInput_struct(26);
_members__tmp_tc__spcInput_struct.length(26);
::CORBA::StructMember _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.type_def = NULL;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"requestUserID";
::CORBA::StructMemberSeq _members__tmp_tc__objectIdentifier_struct(2);
_members__tmp_tc__objectIdentifier_struct.length(2);
::CORBA::StructMember _StructMember__members__tmp_tc__objectIdentifier_struct;
_StructMember__members__tmp_tc__objectIdentifier_struct.type_def = NULL;
_StructMember__members__tmp_tc__objectIdentifier_struct.name = (const char *)"identifier";
_StructMember__members__tmp_tc__objectIdentifier_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__objectIdentifier_struct[0] = _StructMember__members__tmp_tc__objectIdentifier_struct;
_StructMember__members__tmp_tc__objectIdentifier_struct.name = (const char *)"stringifiedObjectReference";
_StructMember__members__tmp_tc__objectIdentifier_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__objectIdentifier_struct[1] = _StructMember__members__tmp_tc__objectIdentifier_struct;
::CORBA::TypeCode_ptr _tmp_tc__objectIdentifier_struct= _orb->create_struct_tc("IDL:objectIdentifier_struct:1.0", "objectIdentifier_struct", _members__tmp_tc__objectIdentifier_struct, 0);
::CORBA::TypeCode_ptr _tmp_tc__objectIdentifier= _orb->create_alias_tc("IDL:objectIdentifier:1.0", "objectIdentifier", _tmp_tc__objectIdentifier_struct, 0);
_StructMember__members__tmp_tc__spcInput_struct.type = _tmp_tc__objectIdentifier;
_members__tmp_tc__spcInput_struct[0] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"lotID";
_StructMember__members__tmp_tc__spcInput_struct.type = _tmp_tc__objectIdentifier;
_members__tmp_tc__spcInput_struct[1] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"processEquipmentID";
_StructMember__members__tmp_tc__spcInput_struct.type = _tmp_tc__objectIdentifier;
_members__tmp_tc__spcInput_struct[2] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"processRecipeID";
_StructMember__members__tmp_tc__spcInput_struct.type = _tmp_tc__objectIdentifier;
_members__tmp_tc__spcInput_struct[3] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"processMainProcessDefinitionID";
_StructMember__members__tmp_tc__spcInput_struct.type = _tmp_tc__objectIdentifier;
_members__tmp_tc__spcInput_struct[4] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"processProcessDefinitionID";
_StructMember__members__tmp_tc__spcInput_struct.type = _tmp_tc__objectIdentifier;
_members__tmp_tc__spcInput_struct[5] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"processOperationNumber";
_StructMember__members__tmp_tc__spcInput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcInput_struct[6] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"measurementEquipmentID";
_StructMember__members__tmp_tc__spcInput_struct.type = _tmp_tc__objectIdentifier;
_members__tmp_tc__spcInput_struct[7] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"technologyID";
_StructMember__members__tmp_tc__spcInput_struct.type = _tmp_tc__objectIdentifier;
_members__tmp_tc__spcInput_struct[8] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"productGroupID";
_StructMember__members__tmp_tc__spcInput_struct.type = _tmp_tc__objectIdentifier;
_members__tmp_tc__spcInput_struct[9] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"productID";
_StructMember__members__tmp_tc__spcInput_struct.type = _tmp_tc__objectIdentifier;
_members__tmp_tc__spcInput_struct[10] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"reticleID";
_StructMember__members__tmp_tc__spcInput_struct.type = _tmp_tc__objectIdentifier;
_members__tmp_tc__spcInput_struct[11] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"reticleIDs";
::CORBA::TypeCode_ptr _tmp_tc__objectIdentifierSequence= _orb->create_alias_tc("IDL:objectIdentifierSequence:1.0", "objectIdentifierSequence",  _orb->create_sequence_tc(0, _tmp_tc__objectIdentifier, 0), 0);
_StructMember__members__tmp_tc__spcInput_struct.type = _tmp_tc__objectIdentifierSequence;
_members__tmp_tc__spcInput_struct[12] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"fixtureID";
_StructMember__members__tmp_tc__spcInput_struct.type = _tmp_tc__objectIdentifier;
_members__tmp_tc__spcInput_struct[13] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"mainProcessDefinitionID";
_StructMember__members__tmp_tc__spcInput_struct.type = _tmp_tc__objectIdentifier;
_members__tmp_tc__spcInput_struct[14] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"operationNumber";
_StructMember__members__tmp_tc__spcInput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcInput_struct[15] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"operationName";
_StructMember__members__tmp_tc__spcInput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcInput_struct[16] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"ownerUserID";
_StructMember__members__tmp_tc__spcInput_struct.type = _tmp_tc__objectIdentifier;
_members__tmp_tc__spcInput_struct[17] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"collectionType";
_StructMember__members__tmp_tc__spcInput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcInput_struct[18] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"dcDefID";
_StructMember__members__tmp_tc__spcInput_struct.type = _tmp_tc__objectIdentifier;
_members__tmp_tc__spcInput_struct[19] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"dcItems";
_StructMember__members__tmp_tc__spcInput_struct.type = _tmp_tc__spcDcItemSequence;
_members__tmp_tc__spcInput_struct[20] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"waferIDByChambers";
_StructMember__members__tmp_tc__spcInput_struct.type = _tmp_tc__spcWaferIDByChamberSequence;
_members__tmp_tc__spcInput_struct[21] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"lotComment";
_StructMember__members__tmp_tc__spcInput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcInput_struct[22] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"processTimestamp";
_StructMember__members__tmp_tc__spcInput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcInput_struct[23] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"measurementTimestamp";
_StructMember__members__tmp_tc__spcInput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcInput_struct[24] = _StructMember__members__tmp_tc__spcInput_struct;
_StructMember__members__tmp_tc__spcInput_struct.name = (const char *)"siInfo";
_StructMember__members__tmp_tc__spcInput_struct.type = ::CORBA::_tc_any;
_members__tmp_tc__spcInput_struct[25] = _StructMember__members__tmp_tc__spcInput_struct;
::CORBA::TypeCode_ptr _tmp_tc__spcInput_struct= _orb->create_struct_tc("IDL:spcInput_struct:1.0", "spcInput_struct", _members__tmp_tc__spcInput_struct, 0);
_tc_spcInput_struct = _tmp_tc__spcInput_struct;
_orb->setClassInfo(::_tc_spcInput_struct, &::spcInput_struct::spcInput_struct_Info );
::CORBA::TypeCode_ptr _tmp_tc__spcInput= _orb->create_alias_tc("IDL:spcInput:1.0", "spcInput", _tmp_tc__spcInput_struct, 0);
_tc_spcInput = _tmp_tc__spcInput;
_orb->setClassInfo(::_tc_spcInput, &::spcInput::spcInput_struct_Info );
::CORBA::StructMemberSeq _members__tmp_tc__spcHoldActionResult_struct(2);
_members__tmp_tc__spcHoldActionResult_struct.length(2);
::CORBA::StructMember _StructMember__members__tmp_tc__spcHoldActionResult_struct;
_StructMember__members__tmp_tc__spcHoldActionResult_struct.type_def = NULL;
_StructMember__members__tmp_tc__spcHoldActionResult_struct.name = (const char *)"holdAction";
_StructMember__members__tmp_tc__spcHoldActionResult_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcHoldActionResult_struct[0] = _StructMember__members__tmp_tc__spcHoldActionResult_struct;
_StructMember__members__tmp_tc__spcHoldActionResult_struct.name = (const char *)"triggerRules";
_StructMember__members__tmp_tc__spcHoldActionResult_struct.type = _tmp_tc__stringSequence;
_members__tmp_tc__spcHoldActionResult_struct[1] = _StructMember__members__tmp_tc__spcHoldActionResult_struct;
::CORBA::TypeCode_ptr _tmp_tc__spcHoldActionResult_struct= _orb->create_struct_tc("IDL:spcHoldActionResult_struct:1.0", "spcHoldActionResult_struct", _members__tmp_tc__spcHoldActionResult_struct, 0);
_tc_spcHoldActionResult_struct = _tmp_tc__spcHoldActionResult_struct;
_orb->setClassInfo(::_tc_spcHoldActionResult_struct, &::spcHoldActionResult_struct::spcHoldActionResult_struct_Info );
::CORBA::TypeCode_ptr _tmp_tc__spcHoldActionResult= _orb->create_alias_tc("IDL:spcHoldActionResult:1.0", "spcHoldActionResult", _tmp_tc__spcHoldActionResult_struct, 0);
_tc_spcHoldActionResult = _tmp_tc__spcHoldActionResult;
_orb->setClassInfo(::_tc_spcHoldActionResult, &::spcHoldActionResult::spcHoldActionResult_struct_Info );
::CORBA::StructMemberSeq _members__tmp_tc__spcCheckResultByRule_struct(3);
_members__tmp_tc__spcCheckResultByRule_struct.length(3);
::CORBA::StructMember _StructMember__members__tmp_tc__spcCheckResultByRule_struct;
_StructMember__members__tmp_tc__spcCheckResultByRule_struct.type_def = NULL;
_StructMember__members__tmp_tc__spcCheckResultByRule_struct.name = (const char *)"rule";
_StructMember__members__tmp_tc__spcCheckResultByRule_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcCheckResultByRule_struct[0] = _StructMember__members__tmp_tc__spcCheckResultByRule_struct;
_StructMember__members__tmp_tc__spcCheckResultByRule_struct.name = (const char *)"description";
_StructMember__members__tmp_tc__spcCheckResultByRule_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcCheckResultByRule_struct[1] = _StructMember__members__tmp_tc__spcCheckResultByRule_struct;
_StructMember__members__tmp_tc__spcCheckResultByRule_struct.name = (const char *)"returnCodeStatus";
_StructMember__members__tmp_tc__spcCheckResultByRule_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcCheckResultByRule_struct[2] = _StructMember__members__tmp_tc__spcCheckResultByRule_struct;
::CORBA::TypeCode_ptr _tmp_tc__spcCheckResultByRule_struct= _orb->create_struct_tc("IDL:spcCheckResultByRule_struct:1.0", "spcCheckResultByRule_struct", _members__tmp_tc__spcCheckResultByRule_struct, 0);
_tc_spcCheckResultByRule_struct = _tmp_tc__spcCheckResultByRule_struct;
_orb->setClassInfo(::_tc_spcCheckResultByRule_struct, &::spcCheckResultByRule_struct::spcCheckResultByRule_struct_Info );
::CORBA::TypeCode_ptr _tmp_tc__spcCheckResultByRule= _orb->create_alias_tc("IDL:spcCheckResultByRule:1.0", "spcCheckResultByRule", _tmp_tc__spcCheckResultByRule_struct, 0);
_tc_spcCheckResultByRule = _tmp_tc__spcCheckResultByRule;
_orb->setClassInfo(::_tc_spcCheckResultByRule, &::spcCheckResultByRule::spcCheckResultByRule_struct_Info );
::CORBA::TypeCode_ptr _tmp_tc__spcCheckResultByRuleSequence= _orb->create_alias_tc("IDL:spcCheckResultByRuleSequence:1.0", "spcCheckResultByRuleSequence",  _orb->create_sequence_tc(0, _tmp_tc__spcCheckResultByRule, 0), 0);
_tc_spcCheckResultByRuleSequence = _tmp_tc__spcCheckResultByRuleSequence;
_orb->setClassInfo(::_tc_spcCheckResultByRuleSequence, &::spcCheckResultByRuleSequence::spcCheckResultByRuleSequence_0_Info );
::CORBA::StructMemberSeq _members__tmp_tc__spcChartResult_struct(22);
_members__tmp_tc__spcChartResult_struct.length(22);
::CORBA::StructMember _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.type_def = NULL;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"chartGroupID";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcChartResult_struct[0] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"chartID";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcChartResult_struct[1] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"chartType";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcChartResult_struct[2] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"processTimestamp";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcChartResult_struct[3] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"inputTimestamp";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcChartResult_struct[4] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"chartRC";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcChartResult_struct[5] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"equipmentHoldAction";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _tmp_tc__spcHoldActionResult;
_members__tmp_tc__spcChartResult_struct[6] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"processHoldAction";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _tmp_tc__spcHoldActionResult;
_members__tmp_tc__spcChartResult_struct[7] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"recipeHoldAction";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _tmp_tc__spcHoldActionResult;
_members__tmp_tc__spcChartResult_struct[8] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"chamberHoldAction";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _tmp_tc__spcHoldActionResult;
_members__tmp_tc__spcChartResult_struct[9] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"chamberID";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcChartResult_struct[10] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"chamberRecipeHoldAction";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _tmp_tc__spcHoldActionResult;
_members__tmp_tc__spcChartResult_struct[11] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"routeHoldAction";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _tmp_tc__spcHoldActionResult;
_members__tmp_tc__spcChartResult_struct[12] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"equipmentAndRecipeHoldAction";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _tmp_tc__spcHoldActionResult;
_members__tmp_tc__spcChartResult_struct[13] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"processAndEquipmentHoldAction";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _tmp_tc__spcHoldActionResult;
_members__tmp_tc__spcChartResult_struct[14] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"operationAndEquipmentHoldAction";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _tmp_tc__spcHoldActionResult;
_members__tmp_tc__spcChartResult_struct[15] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"lotHoldAction";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _tmp_tc__spcHoldActionResult;
_members__tmp_tc__spcChartResult_struct[16] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"reticleHoldAction";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _tmp_tc__spcHoldActionResult;
_members__tmp_tc__spcChartResult_struct[17] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"returnCodes";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _tmp_tc__spcCheckResultByRuleSequence;
_members__tmp_tc__spcChartResult_struct[18] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"chartOwnerMailAddress";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcChartResult_struct[19] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"chartSubOwnerMailAddresses";
_StructMember__members__tmp_tc__spcChartResult_struct.type = _tmp_tc__stringSequence;
_members__tmp_tc__spcChartResult_struct[20] = _StructMember__members__tmp_tc__spcChartResult_struct;
_StructMember__members__tmp_tc__spcChartResult_struct.name = (const char *)"siInfo";
_StructMember__members__tmp_tc__spcChartResult_struct.type = ::CORBA::_tc_any;
_members__tmp_tc__spcChartResult_struct[21] = _StructMember__members__tmp_tc__spcChartResult_struct;
::CORBA::TypeCode_ptr _tmp_tc__spcChartResult_struct= _orb->create_struct_tc("IDL:spcChartResult_struct:1.0", "spcChartResult_struct", _members__tmp_tc__spcChartResult_struct, 0);
_tc_spcChartResult_struct = _tmp_tc__spcChartResult_struct;
_orb->setClassInfo(::_tc_spcChartResult_struct, &::spcChartResult_struct::spcChartResult_struct_Info );
::CORBA::TypeCode_ptr _tmp_tc__spcChartResult= _orb->create_alias_tc("IDL:spcChartResult:1.0", "spcChartResult", _tmp_tc__spcChartResult_struct, 0);
_tc_spcChartResult = _tmp_tc__spcChartResult;
_orb->setClassInfo(::_tc_spcChartResult, &::spcChartResult::spcChartResult_struct_Info );
::CORBA::TypeCode_ptr _tmp_tc__spcChartResultSequence= _orb->create_alias_tc("IDL:spcChartResultSequence:1.0", "spcChartResultSequence",  _orb->create_sequence_tc(0, _tmp_tc__spcChartResult, 0), 0);
_tc_spcChartResultSequence = _tmp_tc__spcChartResultSequence;
_orb->setClassInfo(::_tc_spcChartResultSequence, &::spcChartResultSequence::spcChartResultSequence_0_Info );
::CORBA::StructMemberSeq _members__tmp_tc__spcItemResult_struct(3);
_members__tmp_tc__spcItemResult_struct.length(3);
::CORBA::StructMember _StructMember__members__tmp_tc__spcItemResult_struct;
_StructMember__members__tmp_tc__spcItemResult_struct.type_def = NULL;
_StructMember__members__tmp_tc__spcItemResult_struct.name = (const char *)"dataItemName";
_StructMember__members__tmp_tc__spcItemResult_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcItemResult_struct[0] = _StructMember__members__tmp_tc__spcItemResult_struct;
_StructMember__members__tmp_tc__spcItemResult_struct.name = (const char *)"chartResults";
_StructMember__members__tmp_tc__spcItemResult_struct.type = _tmp_tc__spcChartResultSequence;
_members__tmp_tc__spcItemResult_struct[1] = _StructMember__members__tmp_tc__spcItemResult_struct;
_StructMember__members__tmp_tc__spcItemResult_struct.name = (const char *)"siInfo";
_StructMember__members__tmp_tc__spcItemResult_struct.type = ::CORBA::_tc_any;
_members__tmp_tc__spcItemResult_struct[2] = _StructMember__members__tmp_tc__spcItemResult_struct;
::CORBA::TypeCode_ptr _tmp_tc__spcItemResult_struct= _orb->create_struct_tc("IDL:spcItemResult_struct:1.0", "spcItemResult_struct", _members__tmp_tc__spcItemResult_struct, 0);
_tc_spcItemResult_struct = _tmp_tc__spcItemResult_struct;
_orb->setClassInfo(::_tc_spcItemResult_struct, &::spcItemResult_struct::spcItemResult_struct_Info );
::CORBA::TypeCode_ptr _tmp_tc__spcItemResult= _orb->create_alias_tc("IDL:spcItemResult:1.0", "spcItemResult", _tmp_tc__spcItemResult_struct, 0);
_tc_spcItemResult = _tmp_tc__spcItemResult;
_orb->setClassInfo(::_tc_spcItemResult, &::spcItemResult::spcItemResult_struct_Info );
::CORBA::TypeCode_ptr _tmp_tc__spcItemResultSequence= _orb->create_alias_tc("IDL:spcItemResultSequence:1.0", "spcItemResultSequence",  _orb->create_sequence_tc(0, _tmp_tc__spcItemResult, 0), 0);
_tc_spcItemResultSequence = _tmp_tc__spcItemResultSequence;
_orb->setClassInfo(::_tc_spcItemResultSequence, &::spcItemResultSequence::spcItemResultSequence_0_Info );
::CORBA::StructMemberSeq _members__tmp_tc__spcChamberHoldAction_struct(4);
_members__tmp_tc__spcChamberHoldAction_struct.length(4);
::CORBA::StructMember _StructMember__members__tmp_tc__spcChamberHoldAction_struct;
_StructMember__members__tmp_tc__spcChamberHoldAction_struct.type_def = NULL;
_StructMember__members__tmp_tc__spcChamberHoldAction_struct.name = (const char *)"chamberID";
_StructMember__members__tmp_tc__spcChamberHoldAction_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcChamberHoldAction_struct[0] = _StructMember__members__tmp_tc__spcChamberHoldAction_struct;
_StructMember__members__tmp_tc__spcChamberHoldAction_struct.name = (const char *)"chamberHoldAction";
_StructMember__members__tmp_tc__spcChamberHoldAction_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcChamberHoldAction_struct[1] = _StructMember__members__tmp_tc__spcChamberHoldAction_struct;
_StructMember__members__tmp_tc__spcChamberHoldAction_struct.name = (const char *)"chamberRecipeHoldAction";
_StructMember__members__tmp_tc__spcChamberHoldAction_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcChamberHoldAction_struct[2] = _StructMember__members__tmp_tc__spcChamberHoldAction_struct;
_StructMember__members__tmp_tc__spcChamberHoldAction_struct.name = (const char *)"siInfo";
_StructMember__members__tmp_tc__spcChamberHoldAction_struct.type = ::CORBA::_tc_any;
_members__tmp_tc__spcChamberHoldAction_struct[3] = _StructMember__members__tmp_tc__spcChamberHoldAction_struct;
::CORBA::TypeCode_ptr _tmp_tc__spcChamberHoldAction_struct= _orb->create_struct_tc("IDL:spcChamberHoldAction_struct:1.0", "spcChamberHoldAction_struct", _members__tmp_tc__spcChamberHoldAction_struct, 0);
_tc_spcChamberHoldAction_struct = _tmp_tc__spcChamberHoldAction_struct;
_orb->setClassInfo(::_tc_spcChamberHoldAction_struct, &::spcChamberHoldAction_struct::spcChamberHoldAction_struct_Info );
::CORBA::TypeCode_ptr _tmp_tc__spcChamberHoldAction= _orb->create_alias_tc("IDL:spcChamberHoldAction:1.0", "spcChamberHoldAction", _tmp_tc__spcChamberHoldAction_struct, 0);
_tc_spcChamberHoldAction = _tmp_tc__spcChamberHoldAction;
_orb->setClassInfo(::_tc_spcChamberHoldAction, &::spcChamberHoldAction::spcChamberHoldAction_struct_Info );
::CORBA::TypeCode_ptr _tmp_tc__spcChamberHoldActionSequence= _orb->create_alias_tc("IDL:spcChamberHoldActionSequence:1.0", "spcChamberHoldActionSequence",  _orb->create_sequence_tc(0, _tmp_tc__spcChamberHoldAction, 0), 0);
_tc_spcChamberHoldActionSequence = _tmp_tc__spcChamberHoldActionSequence;
_orb->setClassInfo(::_tc_spcChamberHoldActionSequence, &::spcChamberHoldActionSequence::spcChamberHoldActionSequence_0_Info );
::CORBA::StructMemberSeq _members__tmp_tc__spcOutput_struct(30);
_members__tmp_tc__spcOutput_struct.length(30);
::CORBA::StructMember _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.type_def = NULL;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"txRC";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[0] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"lotID";
_StructMember__members__tmp_tc__spcOutput_struct.type = _tmp_tc__objectIdentifier;
_members__tmp_tc__spcOutput_struct[1] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"lotRC";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[2] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"lotHoldAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[3] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"chamberHoldActions";
_StructMember__members__tmp_tc__spcOutput_struct.type = _tmp_tc__spcChamberHoldActionSequence;
_members__tmp_tc__spcOutput_struct[4] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"equipmentHoldAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[5] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"processHoldAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[6] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"recipeHoldAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[7] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"reworkBranchAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[8] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"mailSendAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[9] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"bankMoveAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[10] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"bankID";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[11] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"reworkRouteID";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[12] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"productHoldAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[13] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"reticleHoldAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[14] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"reticleGroupHoldAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[15] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"moduleHoldAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[16] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"routeHoldAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[17] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"routeOpeNoProductHoldAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[18] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"eqptRecipeHoldAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[19] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"eqptOpeNoHoldAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[20] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"eqptRecticleHoldAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[21] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"eqptProcessHoldAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[22] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"eqptChamberRecipeHoldAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[23] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"eqptProductRecipeHoldAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[24] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"routeOpeNoHoldAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[25] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"eqptChamberHoldAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[26] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"otherAction";
_StructMember__members__tmp_tc__spcOutput_struct.type = _orb->create_string_tc(0, 0);
_members__tmp_tc__spcOutput_struct[27] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"itemResults";
_StructMember__members__tmp_tc__spcOutput_struct.type = _tmp_tc__spcItemResultSequence;
_members__tmp_tc__spcOutput_struct[28] = _StructMember__members__tmp_tc__spcOutput_struct;
_StructMember__members__tmp_tc__spcOutput_struct.name = (const char *)"siInfo";
_StructMember__members__tmp_tc__spcOutput_struct.type = ::CORBA::_tc_any;
_members__tmp_tc__spcOutput_struct[29] = _StructMember__members__tmp_tc__spcOutput_struct;
::CORBA::TypeCode_ptr _tmp_tc__spcOutput_struct= _orb->create_struct_tc("IDL:spcOutput_struct:1.0", "spcOutput_struct", _members__tmp_tc__spcOutput_struct, 0);
_tc_spcOutput_struct = _tmp_tc__spcOutput_struct;
_orb->setClassInfo(::_tc_spcOutput_struct, &::spcOutput_struct::spcOutput_struct_Info );
::CORBA::TypeCode_ptr _tmp_tc__spcOutput= _orb->create_alias_tc("IDL:spcOutput:1.0", "spcOutput", _tmp_tc__spcOutput_struct, 0);
_tc_spcOutput = _tmp_tc__spcOutput;
_orb->setClassInfo(::_tc_spcOutput, &::spcOutput::spcOutput_struct_Info );
}
static ::CORBA::TypeCodeInitStruct __cs_spcsvrstr_TypeCodeInitStruct = { __cs_spcsvrstr_emit_tc, 0 , "cs_spcsvrstr"};
static ::CORBA::TypeCodeInitializer __cs_spcsvrstr_TypeCodeInitializer(&__cs_spcsvrstr_TypeCodeInitStruct);
/*
 * Overloaded CORBA::Any operators.
 */
#ifndef _Anyops_for_spcDcItem_struct
#define _Anyops_for_spcDcItem_struct
void operator <<= (::CORBA::Any& _any, const ::spcDcItem_struct &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::spcDcItem_struct(_data);
   _any.replace(::_tc_spcDcItem_struct, (void*)EB_dc, 1, &spcDcItem_struct::spcDcItem_struct_Info);
}
void operator <<= (::CORBA::Any& _any, ::spcDcItem_struct *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_spcDcItem_struct, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcDcItem_struct*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_spcDcItem_struct)) {
     _data = (::spcDcItem_struct*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcDcItem_struct*& _data)
{
   return operator>>=(_any, (::spcDcItem_struct*&)_data );
}
#endif // _Anyops_for_spcDcItem_struct
#ifndef _Anyops_for__IDL_SEQ_spcDcItemSequence_0
#define _Anyops_for__IDL_SEQ_spcDcItemSequence_0
void operator <<= (::CORBA::Any& _any, const ::spcDcItemSequence &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::spcDcItemSequence(_data);
   _any.replace(::_tc_spcDcItemSequence, (void*)EB_dc, 1, &::spcDcItemSequence::spcDcItemSequence_0_Info );
}
void operator <<= (::CORBA::Any& _any, ::spcDcItemSequence *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_spcDcItemSequence, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcDcItemSequence*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_spcDcItemSequence)) {
     _data = (::spcDcItemSequence*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcDcItemSequence*& _data)
{
   return operator>>=(_any, (::spcDcItemSequence*&)_data );
}
#endif // _Anyops_for__IDL_SEQ_spcDcItemSequence_0
#ifndef _Anyops_for_spcWaferIDByChamber_struct
#define _Anyops_for_spcWaferIDByChamber_struct
void operator <<= (::CORBA::Any& _any, const ::spcWaferIDByChamber_struct &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::spcWaferIDByChamber_struct(_data);
   _any.replace(::_tc_spcWaferIDByChamber_struct, (void*)EB_dc, 1, &spcWaferIDByChamber_struct::spcWaferIDByChamber_struct_Info);
}
void operator <<= (::CORBA::Any& _any, ::spcWaferIDByChamber_struct *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_spcWaferIDByChamber_struct, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcWaferIDByChamber_struct*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_spcWaferIDByChamber_struct)) {
     _data = (::spcWaferIDByChamber_struct*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcWaferIDByChamber_struct*& _data)
{
   return operator>>=(_any, (::spcWaferIDByChamber_struct*&)_data );
}
#endif // _Anyops_for_spcWaferIDByChamber_struct
#ifndef _Anyops_for__IDL_SEQ_spcWaferIDByChamberSequence_0
#define _Anyops_for__IDL_SEQ_spcWaferIDByChamberSequence_0
void operator <<= (::CORBA::Any& _any, const ::spcWaferIDByChamberSequence &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::spcWaferIDByChamberSequence(_data);
   _any.replace(::_tc_spcWaferIDByChamberSequence, (void*)EB_dc, 1, &::spcWaferIDByChamberSequence::spcWaferIDByChamberSequence_0_Info );
}
void operator <<= (::CORBA::Any& _any, ::spcWaferIDByChamberSequence *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_spcWaferIDByChamberSequence, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcWaferIDByChamberSequence*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_spcWaferIDByChamberSequence)) {
     _data = (::spcWaferIDByChamberSequence*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcWaferIDByChamberSequence*& _data)
{
   return operator>>=(_any, (::spcWaferIDByChamberSequence*&)_data );
}
#endif // _Anyops_for__IDL_SEQ_spcWaferIDByChamberSequence_0
#ifndef _Anyops_for_spcInput_struct
#define _Anyops_for_spcInput_struct
void operator <<= (::CORBA::Any& _any, const ::spcInput_struct &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::spcInput_struct(_data);
   _any.replace(::_tc_spcInput_struct, (void*)EB_dc, 1, &spcInput_struct::spcInput_struct_Info);
}
void operator <<= (::CORBA::Any& _any, ::spcInput_struct *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_spcInput_struct, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcInput_struct*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_spcInput_struct)) {
     _data = (::spcInput_struct*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcInput_struct*& _data)
{
   return operator>>=(_any, (::spcInput_struct*&)_data );
}
#endif // _Anyops_for_spcInput_struct
#ifndef _Anyops_for_spcHoldActionResult_struct
#define _Anyops_for_spcHoldActionResult_struct
void operator <<= (::CORBA::Any& _any, const ::spcHoldActionResult_struct &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::spcHoldActionResult_struct(_data);
   _any.replace(::_tc_spcHoldActionResult_struct, (void*)EB_dc, 1, &spcHoldActionResult_struct::spcHoldActionResult_struct_Info);
}
void operator <<= (::CORBA::Any& _any, ::spcHoldActionResult_struct *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_spcHoldActionResult_struct, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcHoldActionResult_struct*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_spcHoldActionResult_struct)) {
     _data = (::spcHoldActionResult_struct*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcHoldActionResult_struct*& _data)
{
   return operator>>=(_any, (::spcHoldActionResult_struct*&)_data );
}
#endif // _Anyops_for_spcHoldActionResult_struct
#ifndef _Anyops_for_spcCheckResultByRule_struct
#define _Anyops_for_spcCheckResultByRule_struct
void operator <<= (::CORBA::Any& _any, const ::spcCheckResultByRule_struct &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::spcCheckResultByRule_struct(_data);
   _any.replace(::_tc_spcCheckResultByRule_struct, (void*)EB_dc, 1, &spcCheckResultByRule_struct::spcCheckResultByRule_struct_Info);
}
void operator <<= (::CORBA::Any& _any, ::spcCheckResultByRule_struct *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_spcCheckResultByRule_struct, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcCheckResultByRule_struct*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_spcCheckResultByRule_struct)) {
     _data = (::spcCheckResultByRule_struct*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcCheckResultByRule_struct*& _data)
{
   return operator>>=(_any, (::spcCheckResultByRule_struct*&)_data );
}
#endif // _Anyops_for_spcCheckResultByRule_struct
#ifndef _Anyops_for__IDL_SEQ_spcCheckResultByRuleSequence_0
#define _Anyops_for__IDL_SEQ_spcCheckResultByRuleSequence_0
void operator <<= (::CORBA::Any& _any, const ::spcCheckResultByRuleSequence &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::spcCheckResultByRuleSequence(_data);
   _any.replace(::_tc_spcCheckResultByRuleSequence, (void*)EB_dc, 1, &::spcCheckResultByRuleSequence::spcCheckResultByRuleSequence_0_Info );
}
void operator <<= (::CORBA::Any& _any, ::spcCheckResultByRuleSequence *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_spcCheckResultByRuleSequence, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcCheckResultByRuleSequence*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_spcCheckResultByRuleSequence)) {
     _data = (::spcCheckResultByRuleSequence*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcCheckResultByRuleSequence*& _data)
{
   return operator>>=(_any, (::spcCheckResultByRuleSequence*&)_data );
}
#endif // _Anyops_for__IDL_SEQ_spcCheckResultByRuleSequence_0
#ifndef _Anyops_for_spcChartResult_struct
#define _Anyops_for_spcChartResult_struct
void operator <<= (::CORBA::Any& _any, const ::spcChartResult_struct &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::spcChartResult_struct(_data);
   _any.replace(::_tc_spcChartResult_struct, (void*)EB_dc, 1, &spcChartResult_struct::spcChartResult_struct_Info);
}
void operator <<= (::CORBA::Any& _any, ::spcChartResult_struct *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_spcChartResult_struct, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcChartResult_struct*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_spcChartResult_struct)) {
     _data = (::spcChartResult_struct*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcChartResult_struct*& _data)
{
   return operator>>=(_any, (::spcChartResult_struct*&)_data );
}
#endif // _Anyops_for_spcChartResult_struct
#ifndef _Anyops_for__IDL_SEQ_spcChartResultSequence_0
#define _Anyops_for__IDL_SEQ_spcChartResultSequence_0
void operator <<= (::CORBA::Any& _any, const ::spcChartResultSequence &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::spcChartResultSequence(_data);
   _any.replace(::_tc_spcChartResultSequence, (void*)EB_dc, 1, &::spcChartResultSequence::spcChartResultSequence_0_Info );
}
void operator <<= (::CORBA::Any& _any, ::spcChartResultSequence *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_spcChartResultSequence, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcChartResultSequence*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_spcChartResultSequence)) {
     _data = (::spcChartResultSequence*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcChartResultSequence*& _data)
{
   return operator>>=(_any, (::spcChartResultSequence*&)_data );
}
#endif // _Anyops_for__IDL_SEQ_spcChartResultSequence_0
#ifndef _Anyops_for_spcItemResult_struct
#define _Anyops_for_spcItemResult_struct
void operator <<= (::CORBA::Any& _any, const ::spcItemResult_struct &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::spcItemResult_struct(_data);
   _any.replace(::_tc_spcItemResult_struct, (void*)EB_dc, 1, &spcItemResult_struct::spcItemResult_struct_Info);
}
void operator <<= (::CORBA::Any& _any, ::spcItemResult_struct *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_spcItemResult_struct, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcItemResult_struct*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_spcItemResult_struct)) {
     _data = (::spcItemResult_struct*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcItemResult_struct*& _data)
{
   return operator>>=(_any, (::spcItemResult_struct*&)_data );
}
#endif // _Anyops_for_spcItemResult_struct
#ifndef _Anyops_for__IDL_SEQ_spcItemResultSequence_0
#define _Anyops_for__IDL_SEQ_spcItemResultSequence_0
void operator <<= (::CORBA::Any& _any, const ::spcItemResultSequence &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::spcItemResultSequence(_data);
   _any.replace(::_tc_spcItemResultSequence, (void*)EB_dc, 1, &::spcItemResultSequence::spcItemResultSequence_0_Info );
}
void operator <<= (::CORBA::Any& _any, ::spcItemResultSequence *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_spcItemResultSequence, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcItemResultSequence*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_spcItemResultSequence)) {
     _data = (::spcItemResultSequence*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcItemResultSequence*& _data)
{
   return operator>>=(_any, (::spcItemResultSequence*&)_data );
}
#endif // _Anyops_for__IDL_SEQ_spcItemResultSequence_0
#ifndef _Anyops_for_spcChamberHoldAction_struct
#define _Anyops_for_spcChamberHoldAction_struct
void operator <<= (::CORBA::Any& _any, const ::spcChamberHoldAction_struct &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::spcChamberHoldAction_struct(_data);
   _any.replace(::_tc_spcChamberHoldAction_struct, (void*)EB_dc, 1, &spcChamberHoldAction_struct::spcChamberHoldAction_struct_Info);
}
void operator <<= (::CORBA::Any& _any, ::spcChamberHoldAction_struct *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_spcChamberHoldAction_struct, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcChamberHoldAction_struct*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_spcChamberHoldAction_struct)) {
     _data = (::spcChamberHoldAction_struct*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcChamberHoldAction_struct*& _data)
{
   return operator>>=(_any, (::spcChamberHoldAction_struct*&)_data );
}
#endif // _Anyops_for_spcChamberHoldAction_struct
#ifndef _Anyops_for__IDL_SEQ_spcChamberHoldActionSequence_0
#define _Anyops_for__IDL_SEQ_spcChamberHoldActionSequence_0
void operator <<= (::CORBA::Any& _any, const ::spcChamberHoldActionSequence &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::spcChamberHoldActionSequence(_data);
   _any.replace(::_tc_spcChamberHoldActionSequence, (void*)EB_dc, 1, &::spcChamberHoldActionSequence::spcChamberHoldActionSequence_0_Info );
}
void operator <<= (::CORBA::Any& _any, ::spcChamberHoldActionSequence *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_spcChamberHoldActionSequence, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcChamberHoldActionSequence*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_spcChamberHoldActionSequence)) {
     _data = (::spcChamberHoldActionSequence*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcChamberHoldActionSequence*& _data)
{
   return operator>>=(_any, (::spcChamberHoldActionSequence*&)_data );
}
#endif // _Anyops_for__IDL_SEQ_spcChamberHoldActionSequence_0
#ifndef _Anyops_for_spcOutput_struct
#define _Anyops_for_spcOutput_struct
void operator <<= (::CORBA::Any& _any, const ::spcOutput_struct &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::spcOutput_struct(_data);
   _any.replace(::_tc_spcOutput_struct, (void*)EB_dc, 1, &spcOutput_struct::spcOutput_struct_Info);
}
void operator <<= (::CORBA::Any& _any, ::spcOutput_struct *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_spcOutput_struct, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::spcOutput_struct*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_spcOutput_struct)) {
     _data = (::spcOutput_struct*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::spcOutput_struct*& _data)
{
   return operator>>=(_any, (::spcOutput_struct*&)_data );
}
#endif // _Anyops_for_spcOutput_struct
