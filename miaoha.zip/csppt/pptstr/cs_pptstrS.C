//----------------------------------------------------------------------------
//
//  Generated from cs_pptstr.idl
//  On Friday, November 3, 2017 4:06:56 PM GMT+07:00
//  by IBM CORBA 2.3 (sc) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#define _cs_pptstr_bindings_defined
#ifdef SOMCBNOLOCALINCLUDES
#include <cs_pptstr.hh>
#else
#include "cs_pptstr.hh"
#endif
#define _cs_pptstr_server_defined
#ifdef SOMCBNOLOCALINCLUDES
#include <cs_pptstrC.C>
#else
#include "cs_pptstrC.C"
#endif

