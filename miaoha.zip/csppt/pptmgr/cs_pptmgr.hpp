// @(#) 1.3 superpos/src/csppt/source/posppt/pptmgr/cs_pptmgr.hpp, mm_srv_5_0_cspp, mm_srv_5_0_cspp 6/9/03 14:14:37 [ 6/9/03 14:14:38 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView - CS PPT Manager
// Name: cs_pptmgr.hpp
// Description : Declaration of Customized PPT Manager
//
// ** Notice **
//   This is a sample code for customizing a PPT Manager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT Manager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//
// Change history:
//
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya      Initial Release for R5.0
// 09/15/04   D6000025 K.Murakami     BOAImpl was added in order to make it TIE to BOA.
// 10/26/04   D6000025 K.Murakami     eBrokerMigration.
// 11/29/04   D6000025 K.Murakami     Add include <ots/cborb/encina_cborb.H> for eBroker
//

#ifndef cs_pptmgr_ih
#define cs_pptmgr_ih

#include "pptmgr.hpp"
#include "sqlca.h"
#include "MO_i.hpp"
#ifdef EBROKER                         //D6000025
#include <ots/cborb/encina_cborb.H>    //D6000025
#else                                  //D6000025
#include <ots/orbix/encina_orbix.H>
#endif                                 //D6000025

#include "pptdefs.h"
#include "cs_pptdefs.h"
#include "posstate.hpp"

#include "pfwgls.hh"
#include "pfactry.hh"      // PosMESFactory
#include "pathmgr.hh"      // PosAuthenticationManager
#include "pcdmgr.hh"       // PosCodeManager
#include "pdcmgr.hh"       // PosDataCollectionSpecificationManager
#include "pdpmg.hh"        // PosDispatchingManager
#include "pdrmg.hh"        // PosDurableManager
#include "pevmg.hh"        // EventManager
#include "pmcmg.hh"        // PosMachineManager
#include "pmsdnmg.hh"      // PosMessageDistributionManager
#include "ppsmgr.hh"       // PosPersonManager
#include "pplmgr.hh"       // PosPlanManager
#include "ppcdfmg.hh"      // PosProcessDefinitionManager
#include "pprmgr.hh"       // PosProductManager
#include "pprspmg.hh"      // PosProductSpecificationManager
#include "pqtimmg.hh"      // PosQTimeRestrictionManager
#include "prcmg.hh"        // PosRecipeManager
#include "brsvariableinfoimizedmgr.hh"  // BRSVariableInfoIMizedMgr_var

// PPTManager & PPTServiceManager
#include "pptmgr.hh"
#include "pptstr.hh"
#include "pptobstr.hh"

#include "pptmgr.hpp"
#include "pptmacros.hpp"   // Macros used in PPT.
//#include "pptrc.h"         // Return codes.
//#include "pptmsg.h"        // Message defines.

#include "pfwgls.hpp"


// CS_PPTManager & CS_PPTServiceManager
#include "cs_pptrc.h"
#include "cs_pptmsg.h"
#include "cs_pptmgr.hh"
#include "cs_pptstr.hh"
#include "cs_pptobstr.hh"
#include "cs_pptmacros.hpp"
#include "cs_posconst.hpp"

#ifdef MO_BOA    //D6000025
class CS_PPTManager_i : virtual public PPTManager_i, virtual public CS_PPTManagerBOAImpl   //D6000025
#else  //D6000025
class CS_PPTManager_i : public PPTManager_i
#endif   //D6000025
{
    private:

    protected:

    public:
        CS_PPTManager_i() ;
        ~CS_PPTManager_i() ;
//D6000025        virtual void CS_PPTManager_init (CORBA::Environment &IT_env = CORBA::default_environment) ;
        virtual void CS_PPTManager_init (CORBAENV_ONLY_HPP) ;  //D6000025
//D6000025        virtual void CS_PPTManager_uninit (CORBA::Environment &IT_env = CORBA::default_environment) ;
        virtual void CS_PPTManager_uninit (CORBAENV_ONLY_HPP) ; //D6000025

        // small tx     
        #include "cs_prvmethd.hpp"
  
        // obj method
        #include "cs_objmethod.hpp"
};

//DEF_TIE_CS_PPTManager(CS_PPTManager_i);

#endif

