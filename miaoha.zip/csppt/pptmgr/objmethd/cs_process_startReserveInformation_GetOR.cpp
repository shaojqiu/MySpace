#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/csppt/source/posppt/pptmgr/objmethd/cs_process_startReserveInformation_GetOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 20:22:51 [ 7/13/07 20:22:52 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_process_startReserveInformation_GetOR.cpp
//

#include "cs_pptmgr.hpp"
#include "pportrs.hh"
#include "plcrc.hh"
#include "pmcrc.hh"
#include "prcmggl.hh"
#include "plot.hh"     //P5100203

//[Object Function Name]: long   process_startReserveInformation_Get
//
// Date        Level     Author         Note
// ----------  -----     -------------  -------------------------------------------
// 2000-08-01  0.00      Y.Iwasaki      Initial Release
// 2000-09-19  P3000202  Y.Iwasaki      Bug fix
// 2000/11/10  P2200204  R.Furuta       Initialize local pointers
// 2004/03/04  P5100203  T.Hikari       Change machineRecipeID for process_dataCollectionDefinition_Get()
// 2005/08/31  D6000415  K.Kido         Call findRecipeParametersForSubLotType() to get correct Recipe Parameter taken into account for Chamber Machine State.
// 2005/12/07  D7000042  K.Kido         Get Machine Recipe by findMachineRecipeForSubLotType for findRecipeParametersForSubLotType.
// 2006/11/23  D8000024  H.Mutoh        When FPC overwrite the machineRecipe, skip the logic of machineRecipe getting from PO.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009/10/27 DSIV00001443 S.Kawabe       Improve how to get the Machine Recipe
// 2010/06/25 PSIV00002149 S.Kawabe       Start Lot Reservation fails when a lot in FOUP is not on a route.
// 2014/05/13 DSN000085698 S.Wang         Support equipment monitor used count function
// 2017/02/13 DSN000104277 K.Yamaoku      Performance improvement(reference:lot_wafers_GetDR)
//
//
// Innotron Modification history :
// Date       Defect#        Person               Comments
// ---------- -------------- -------------------- -------------------------------------------
// 2017/10/16 INN-R170023    Sam Hsueh            initial, get route / OpeNo for TCS (temp solution)
//
//
//[Function Description]:
//
//  This object function fill the return structure's value as follows.
//  Only (MM) marked items will be filled.
//
//  typedef struct pptStartCassette_struct {
//      long                          loadSequenceNumber;            (C)
//      objectIdentifier              cassetteID;                    (C)
//      string                        loadPurposeType;               (C)
//      objectIdentifier              loadPortID;                    (C)
//      objectIdentifier              unloadPortID;                  (MM)
//      sequence <pptLotInCassette>   strLotInCassette;              (C)
//  } pptStartLot;
//
//  typedef struct pptLotInCassette_struct
//      boolean                       operationStartFlag;            (C)
//      boolean                       monitorLotFlag;                (C*)  (***)
//      objectIdentifier              lotID;                         (C)
//      string                        lotType;                       (C)   (***)
//      string                        subLotType;                    (C)   (***)
//      pptStartRecipe                strStartRecipe;                (C)   (***)
//      string                        recipeParameterChangeType;     (C**) (***)
//      sequence <pptLotWafer>        strLotWafer;                   (M)
//  } pptLotInCassette;
//
//  typedef struct pptLotWafer_struct {
//      objectIdentifier              waferID;                       (MM)
//      long                          slotNumber;                    (MM)
//      boolean                       controlWaferFlag;              (MM)
//      sequence <pptStartRecipeParameter> strStartRecipeParameter;  (MM)  (***)
//  } pptLotWafer;
//
//  typedef struct pptStartRecipeParameter_struct {
//      string                        parameterName;                 (MM)  (***)
//      string                        parameterValue;                (C**) (***)
//      string                        targetValue;                   (MM)  (***)
//      boolean                       useCurrentSettingValueFlag;    (MM)  (***)
//  } pptStartRecipeParameter;
//
//  typedef struct pptStartRecipe_struct {
//      objectIdentifier              logicalRecipeID;               (C)   (***)
//      objectIdentifier              machineRecipeID;               (C)   (***)
//      string                        physicalRecipeID;              (C)   (***)
//      sequence <pptStartReticle>    strStartReticle;               (MM)  (***)
//      sequence <pptStartFixture>    strStartFixture;               (MM)  (***)
//      boolean                       dataCollectioinFlag;           (MM)  (***)
//      sequence <pptDCDef>           strDCDef;                      (MM)  (***)
//  } pptStartRecipe;
//
//  typedef struct pptStartReticle_struct {
//     long                           sequenceNumber;                (MM)  (***)
//     objectIdentifier               reticleID;                     (MM)  (***)
//  } pptStartReticle;
//
//  typedef struct pptStartFixture_struct {
//     objectIdentifier               fixtureID;                     (MM)  (***)
//     string                         fixtureCategory;               (MM)  (***)
//  } pptStartFixture;
//
//  typedef struct pptDCDef_struct {
//      objectIdentifier              dataCollectionDefinitionID;    (MM)  (***)
//      string                        description;                   (MM)  (***)
//      string                        dataCollectionType;            (MM)  (***)
//      sequence <pptDCItem>          strDCItem;                     (MM)  (***)
//      boolean                       calculationRequiredFlag;       (MM)  (***)
//      boolean                       specCheckRequiredFlag;         (MM)  (***)
//      objectIdentifier              dataCollectionSpecificationID; (MM)  (***)
//      objectIdentifier              previousDataCollectionDefinitionID;  (MM)  (***)
//      objectIdentifier              previousOperationID;           (MM)  (***)
//      string                        previousOperationNumber;       (MM)  (***)
//  } pptDCDef;
//
//  typedef struct pptDCItem_struct {
//      string                        dataCollectionItemName;        (MM)  (***)
//      string                        dataCollectionMode;            (MM)  (***)
//      string                        dataCollectionUnit;            (MM)  (***)
//      string                        dataType;                      (MM)  (***)
//      string                        itemType;                      (MM)  (***)
//      string                        measurementType;               (MM)  (***)
//      objectIdentifier              waferID;                       (null)
//      string                        waferPosition;                 (MM)  (***)
//      string                        sitePosition;                  (MM)  (***)
//      boolean                       historyRequiredFlag;           (MM)  (***)
//      string                        calculationType;               (MM)  (***)
//      string                        calculationExpression;         (MM)  (***)
//      string                        dataValue;                     (null)
//      string                        targetValue;                   (MM)  (***)
//      string                        specCheckResult;               (null)
//      stringSequence                actionCode;                    (null)
//  } pptDCItem;
//
//
//[Input Parameters]:
//  in  pptObjCommonIn            strObjCommonIn;
//  in  objectIdentifier          equipmentID;
//
//[Output Parameters]:
//  out objProcess_startReserveInformation_Get_out   strProcess_startReserveInformation_Get_out;
//
//  typedef struct objProcess_startReserveInformation_Get_out_struct {
//      pptRetCode                strResult;
//      pptStartCassetteSequence  strStartCassette;
//  } objProcess_startReserveInformation_Get_out;
//
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_NOT_FOUND_PO             MSG_NOT_FOUND_PO
//  RC_NOT_FOUND_LOT            MSG_NOT_FOUND_LOT
//  RC_LOCKED_BY_ANOTHER        MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR             MSG_SYSTEM_ERROR
//  RC_NOT_FOUND_EQP            MSG_NOT_FOUND_EQP
//  RC_NOT_FOUND_MCRECIPE       MSG_NOT_FOUND_MCRECIPE
//  RC_NOT_FOUND_LCRECIPE       MSG_NOT_FOUND_LCRECIPE
//  RC_NOT_FOUND_RETICLE        MSG_NOT_FOUND_RETICLE
//  RC_NOT_FOUND_FIXTURE        MSG_NOT_FOUND_FIXTURE
//  RC_NOT_FOUND_DCDEF          MSG_NOT_FOUND_DCDEF
//  RC_NOT_FOUND_PROCGRP        MSG_NOT_FOUND_PROCGRP

CORBA::Long CS_PPTManager_i::process_startReserveInformation_Get(
                            objProcess_startReserveInformation_Get_out& strProcess_startReserveInformation_Get_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& equipmentID)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::process_startReserveInformation_Get");
        PPT_METHODTRACE_V2( "CS_PPTManager_i::process_startReserveInformation_Get","in-parm's equipmentID", equipmentID.identifier);

        /*----------------*/
        /*                */
        /*   Initialize   */
        /*                */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        CORBA::Long searchCondition = 0;                                                                   //DSIV00001443
        CORBA::String_var searchCondition_var = CIMFWStrDup(getenv("SP_ENTITY_INHIBIT_SEARCH_CONDITION")); //DSIV00001443
        if( CIMFWStrLen(searchCondition_var) > 0 )                                                         //DSIV00001443
        {                                                                                                  //DSIV00001443
            searchCondition = atoi(searchCondition_var);                                                   //DSIV00001443
        }                                                                                                  //DSIV00001443

        /*------------------------*/
        /*                        */
        /*   Get Machine Object   */
        /*                        */
        /*------------------------*/
        PosMachine_var aMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR(aMachine,equipmentID,strProcess_startReserveInformation_Get_out,process_startReserveInformation_Get);

        /*---------------------------------------------------*/
        /*                                                   */
        /*   Get and Set Information into strStartCassette   */
        /*                                                   */
        /*---------------------------------------------------*/
        CORBA::Long SCLength;
        SCLength = strProcess_startReserveInformation_Get_out.strStartCassette.length();
        for (CORBA::Long i=0 ; i<SCLength ; i++ )
        {
            PPT_METHODTRACE_V3("CS_PPTManager_i::process_startReserveInformation_Get", "loop to strProcess_startReserveInformation_Get_out.strStartCassette.length()",SCLength,i);
            /*------------------------------*/
            /*   Get / Set Unload Port ID   */
            /*------------------------------*/
            PortResource_var aPort;
            PosPortResource_var aLoadPort;
            PPT_CONVERT_PORTID_TO_PORTRESOURCE_OR(aMachine,aPort,strProcess_startReserveInformation_Get_out.strStartCassette[i].loadPortID,strProcess_startReserveInformation_Get_out,process_startReserveInformation_Get);
            aLoadPort = PosPortResource::_narrow(aPort);

            PosPortResource_var aUnloadPort;
            try
            {
                aUnloadPort = aLoadPort->getAssociatedPort();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::getAssociatedPort);
            
            PPT_SET_OBJECT_IDENTIFIER(strProcess_startReserveInformation_Get_out.strStartCassette[i].unloadPortID,aUnloadPort,strProcess_startReserveInformation_Get_out,process_startReserveInformation_Get,PosPortResource);

            /*-------------------------*/
            /*   Omit Empty Cassette   */
            /*-------------------------*/
            CORBA::String_var loadPurposeType;
            loadPurposeType = strProcess_startReserveInformation_Get_out.strStartCassette[i].loadPurposeType;
            if (CIMFWStrCmp(loadPurposeType,SP_LoadPurposeType_EmptyCassette) == 0)
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i::process_startReserveInformation_Get", "loadPurposeType == SP_LoadPurposeType_EmptyCassette");
                continue;
            }

            /*--------------------------------*/
            /*   Get / Set Lot Related Info   */
            /*--------------------------------*/
            CORBA::Long LICLength;
            LICLength = strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette.length();
            for (CORBA::Long j=0 ; j<LICLength ; j++ )
            {
                CORBA::Boolean skipFlag = FALSE;
                objLot_effectiveFPCInfo_Get_out strLot_effectiveFPCInfo_Get_out;

//D8000024 add start
                if( strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].operationStartFlag == TRUE ) //PSIV00002149
                {                                                                                                                   //PSIV00002149
                    PPT_METHODTRACE_V1("","operationStartFlag == TRUE");                                                            //PSIV00002149

                    PPT_METHODTRACE_V3("CS_PPTManager_i::process_startReserveInformation_Get", "loop to strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette",LICLength,j);
                    rc = lot_effectiveFPCInfo_Get( strLot_effectiveFPCInfo_Get_out, strObjCommonIn,
                                                   SP_FPC_ExchangeType_StartReserveInfo,
                                                   equipmentID,
                                                   strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_effectiveFPCInfo_Get() != RC_OK", rc);
                        strProcess_startReserveInformation_Get_out.strResult = strLot_effectiveFPCInfo_Get_out.strResult;
                        return rc;
                    }
                    
                    //INN-R170023 add start
                    objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
                    rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out, strObjCommonIn, strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_currentOperationInfo_Get() != RC_OK", rc);
                        strProcess_startReserveInformation_Get_out.strResult = strLot_currentOperationInfo_Get_out.strResult;
                        return( rc );
                    }
                    
                    strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID         = strLot_currentOperationInfo_Get_out.routeID;
                    strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationID     = strLot_currentOperationInfo_Get_out.operationID;
                    strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber = strLot_currentOperationInfo_Get_out.operationNumber;
                    PPT_METHODTRACE_V3("", "Set StartOperationInfo", strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID.identifier, strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber);
                    //INN-R170023 add end
//D8000024 add end
                }                                                                                                                   //PSIV00002149

                /*---------------------*/
                /*    Get Wafer Info   */
                /*---------------------*/
                CORBA::Long LWLength;
                LWLength = strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                if (LWLength == 0 )
                {
                    PPT_METHODTRACE_V1("CS_PPTManager_i::process_startReserveInformation_Get", "strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer.length() == 0");
                    /*------------------------------------------------------------------*/
                    /*   Set recipeParameterChangeType with SP_Rparm_ChangeType_ByLot   */
                    /*------------------------------------------------------------------*/
                    strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].recipeParameterChangeType = CIMFWStrDup(SP_Rparm_ChangeType_ByLot);

                    /*----------------------------------*/
                    /*   Get and Set Recipe Parameter   */
                    /*----------------------------------*/
//DSN000104277//DSN000085698                    objLot_wafers_GetDR_out strLot_wafers_GetDR_out;
//DSN000104277                    objLot_wafers_GetDR_out__150 strLot_wafers_GetDR_out;    //DSN000085698
//DSN000104277                    objLot_wafers_GetDR_in  strInParm ;
//DSN000104277                    strInParm.lotID          = strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID;
//DSN000104277                    strInParm.scrapCheckFlag = TRUE;   //omit scrapped wafer
//DSN000104277
//DSN000104277//DSN000085698                    rc = lot_wafers_GetDR(strLot_wafers_GetDR_out,strObjCommonIn,strInParm);
//DSN000104277                    rc = lot_wafers_GetDR__150(strLot_wafers_GetDR_out,strObjCommonIn,strInParm);    //DSN000085698
//DSN000104277                    if(rc != RC_OK)
//DSN000104277                    {
//DSN000104277//DSN000085698                        PPT_METHODTRACE_V1("CS_PPTManager_i::process_startReserveInformation_Get", "lot_wafers_GetDR() != RC_OK");
//DSN000104277                        PPT_METHODTRACE_V1("", "lot_wafers_GetDR__150() != RC_OK"); //DSN000085698
//DSN000104277                        strProcess_startReserveInformation_Get_out.strResult = strLot_wafers_GetDR_out.strResult;
//DSN000104277                        return(rc);
//DSN000104277                    }
//DSN000104277 add start
                    objLot_waferInfoList_GetDR_out strLot_waferInfoList_GetDR_out;
                    objLot_waferInfoList_GetDR_in  strLot_waferInfoList_GetDR_in;
                    strLot_waferInfoList_GetDR_in.lotID          = strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID;
                    strLot_waferInfoList_GetDR_in.scrapCheckFlag = TRUE; //omit scrapped wafer
                    rc = lot_waferInfoList_GetDR( strLot_waferInfoList_GetDR_out, strObjCommonIn, strLot_waferInfoList_GetDR_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "##### lot_waferInfoList_GetDR() != RC_OK", rc);
                        strProcess_startReserveInformation_Get_out.strResult = strLot_waferInfoList_GetDR_out.strResult;
                        return( rc );
                    }
//DSN000104277 add end

                    CORBA::Long wfrCnt;
//DSN000104277                    wfrCnt = strLot_wafers_GetDR_out.strLotWaferAttributes.length();
                    wfrCnt = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes.length(); //DSN000104277
                    strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer.length(wfrCnt);

                    /*---------------------------*/
                    /*   Omit Not OpeStart Lot   */
                    /*---------------------------*/
                    CORBA::Boolean operationStartFlag = strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].operationStartFlag;
                    if (operationStartFlag == FALSE)
                    {
                        PPT_METHODTRACE_V1("CS_PPTManager_i::process_startReserveInformation_Get", "operationStartFlag == FALSE");

                        //P3000202 add start
                        /*-------------------------------------------------------*/
                        /*   Set Wafer Info and Recipe parameter to Each Wafer   */
                        /*-------------------------------------------------------*/
                        for (CORBA::Long k=0 ; k<wfrCnt ; k++ )
                        {
//DSN000104277                            strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].waferID          = strLot_wafers_GetDR_out.strLotWaferAttributes[k].waferID;
//DSN000104277                            strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].slotNumber       = strLot_wafers_GetDR_out.strLotWaferAttributes[k].slotNumber;
//DSN000104277                            strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].controlWaferFlag = strLot_wafers_GetDR_out.strLotWaferAttributes[k].controlWaferFlag;
//DSN000104277 add start
                            strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].waferID          = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[k].waferID;
                            strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].slotNumber       = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[k].slotNumber;
                            strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].controlWaferFlag = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[k].controlWaferFlag;
//DSN000104277 add end
                            strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length(0);
                        }
                        //P3000202 add end
                        continue;
                    }

                    /*--------------------------*/
                    /*   Get Recipe parameter   */
                    /*--------------------------*/
                    PosLogicalRecipe_var aLogicalRecipe;
                    PPT_CONVERT_LOGICALRECIPEID_TO_LOGICALRECIPE_OR(aLogicalRecipe,strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID,strProcess_startReserveInformation_Get_out,process_startReserveInformation_Get);

                    PosMachineRecipe_var aMachineRecipe ;
//D7000042          PPT_CONVERT_RECIPEID_TO_MACHINERECIPE_OR(aMachineRecipe,strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID,strProcess_startReserveInformation_Get_out,process_startReserveInformation_Get)

//D6000415 add start
                    /************************/
                    /*   Get subLotType     */
                    /************************/
                    PosLot_var aLot ; //DSIV00001443
                    CORBA::String_var subLotType;
                    if( 0 == CIMFWStrLen( strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].subLotType ) )
                    {
//DSIV00001443                        PosLot_var aLot ;
                        PPT_CONVERT_LOTID_TO_LOT_OR( aLot,
                                                     strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID,
                                                     strProcess_startReserveInformation_Get_out,
                                                     process_startReserveInformation_Get ) ;

                        try
                        {
                            subLotType = aLot->getSubLotType();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType);
                    }
                    else
                    { 
                        subLotType = strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].subLotType ;
                    }
//D6000415 add end
                    if( searchCondition == 1 )                                                                                                     //DSIV00001443
                    {                                                                                                                              //DSIV00001443
                        if( CORBA::is_nil(aLot) == TRUE )                                                                                          //DSIV00001443
                        {
                            PPT_CONVERT_LOTID_TO_LOT_OR( aLot,
                                                         strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID, //DSIV00001443
                                                         strProcess_startReserveInformation_Get_out,                                               //DSIV00001443
                                                         process_startReserveInformation_Get ) ;                                                   //DSIV00001443
                        }                                                                                                                          //DSIV00001443
                        try                                                                                                                        //DSIV00001443
                        {                                                                                                                          //DSIV00001443
                            aMachineRecipe = aLogicalRecipe->findMachineRecipeFor(aLot,aMachine);                                                  //DSIV00001443
                        }                                                                                                                          //DSIV00001443
                        CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeFor)                                                         //DSIV00001443
                    }                                                                                                                              //DSIV00001443
                    else                                                                                                                           //DSIV00001443
                    {                                                                                                                              //DSIV00001443
//D7000042 add start
                        try
                        {
                            aMachineRecipe = aLogicalRecipe->findMachineRecipeForSubLotType(aMachine,subLotType);
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findLogicalRecipeForSubLotType);
//D7000042 add end
                    }                                                                                                                              //DSIV00001443

                    PosRecipeParameterSequence* recipeParameterSeq = NULL; //P2200204
                    PosRecipeParameterSequence_var varRecipeParameterSeq;
                    CORBA::Long rpmCnt;
                    try
                    {
//D6000415              recipeParameterSeq = aLogicalRecipe->findRecipeParametersFor(aMachine,aMachineRecipe);
                        recipeParameterSeq = aLogicalRecipe->findRecipeParametersForSubLotType(aMachine,aMachineRecipe, subLotType);    //D6000415
                        varRecipeParameterSeq = recipeParameterSeq;
                        rpmCnt = (*recipeParameterSeq).length();
                    }
//D6000415          CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findRecipeParametersFor);
                    CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findRecipeParametersForSubLotType);    //D6000415

                    /*-------------------------------------------------------*/
                    /*   Set Wafer Info and Recipe parameter to Each Wafer   */
                    /*-------------------------------------------------------*/
                    for (CORBA::Long k=0 ; k<wfrCnt ; k++)
                    {
//DSN000104277                        PPT_METHODTRACE_V3("CS_PPTManager_i::process_startReserveInformation_Get", "loop to strLot_wafers_GetDR_out.strLotWaferAttributes.length()",wfrCnt,k);
//DSN000104277                        strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].waferID          = strLot_wafers_GetDR_out.strLotWaferAttributes[k].waferID;
//DSN000104277                        strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].slotNumber       = strLot_wafers_GetDR_out.strLotWaferAttributes[k].slotNumber;
//DSN000104277                        strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].controlWaferFlag = strLot_wafers_GetDR_out.strLotWaferAttributes[k].controlWaferFlag;
//DSN000104277 add start
                        PPT_METHODTRACE_V3("CS_PPTManager_i::process_startReserveInformation_Get", "loop to strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes.length()",wfrCnt,k);
                        strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].waferID          = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[k].waferID;
                        strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].slotNumber       = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[k].slotNumber;
                        strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].controlWaferFlag = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[k].controlWaferFlag;
//DSN000104277 add end
                        strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length(rpmCnt);
                        for (CORBA::Long l=0 ; l<rpmCnt ; l++)
                        {
                            PPT_METHODTRACE_V3("CS_PPTManager_i::process_startReserveInformation_Get", "loop to recipeParameterSeq->length()",rpmCnt,l);
                            strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterName              = (*recipeParameterSeq)[l].parameterName;
                            if ( (*recipeParameterSeq)[l].useCurrentValueFlag == TRUE )
                            {
                                PPT_METHODTRACE_V1("CS_PPTManager_i::process_startReserveInformation_Get", "recipeParameterSeq[l].useCurrentValueFlag == TRUE");
                                strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterValue         = (const char*)"";
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("CS_PPTManager_i::process_startReserveInformation_Get", "recipeParameterSeq[l].useCurrentValueFlag != TRUE");
                                strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterValue         = (*recipeParameterSeq)[l].defaultValue;
                            }
                            strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].targetValue                = (*recipeParameterSeq)[l].defaultValue;
                            strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].useCurrentSettingValueFlag = (*recipeParameterSeq)[l].useCurrentValueFlag;
                        }
                    }
                }

                //P3000202 add start
                /*---------------------------*/
                /*   Omit Not OpeStart Lot   */
                /*---------------------------*/
                CORBA::Boolean operationStartFlag;
                operationStartFlag = strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].operationStartFlag;
                if (operationStartFlag == FALSE )
                {
                    PPT_METHODTRACE_V1("CS_PPTManager_i::process_startReserveInformation_Get", "strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE");
                    continue;
                }
                //P3000202 add end

//P5100203 Add STRAT
                /*-------------------------------*/
                /*   Get Machine Recipe Object   */
                /*-------------------------------*/
                PosLot_var aLot;
                PPT_CONVERT_LOTID_TO_LOT_OR(aLot,
                                            strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID,
                                            strProcess_startReserveInformation_Get_out,
                                            process_startReserveInformation_Get);

                CORBA::String_var subLotType;
                try
                {
                    subLotType = aLot->getSubLotType();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType);

                PosLogicalRecipe_var aLogicalRecipe;
                PPT_CONVERT_LOGICALRECIPEID_TO_LOGICALRECIPE_OR(aLogicalRecipe,
                                                                strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID,
                                                                strProcess_startReserveInformation_Get_out,
                                                                process_startReserveInformation_Get);

                PosMachineRecipe_var aMachineRecipe;
                if( searchCondition == 1 )                                                    //DSIV00001443
                {                                                                             //DSIV00001443
                    try                                                                       //DSIV00001443
                    {                                                                         //DSIV00001443
                        aMachineRecipe = aLogicalRecipe->findMachineRecipeFor(aLot,aMachine); //DSIV00001443
                    }                                                                         //DSIV00001443
                    CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeFor)        //DSIV00001443
                }                                                                             //DSIV00001443
                else                                                                          //DSIV00001443
                {                                                                             //DSIV00001443
                    try
                    {
                        aMachineRecipe = aLogicalRecipe->findMachineRecipeForSubLotType(aMachine,subLotType);
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findLogicalRecipeForSubLotType);
                }                                                                             //DSIV00001443

                if (CORBA::is_nil(aMachineRecipe) == TRUE)
                {
                    PPT_METHODTRACE_V1("CS_PPTManager_i::process_startReserveInformation_Get","CORBA::is_nil(aMachineRecipe) == TRUE");
//D8000024 add start
                    if( strLot_effectiveFPCInfo_Get_out.machineRecipeActionRequired == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "MachineRecipe is overwritten by FPC");
                        skipFlag = TRUE;
                    }
                    else
                    {
//D8000024 add end
                        SET_MSG_RC(strProcess_startReserveInformation_Get_out, MSG_NOT_FOUND_MCRECIPE, RC_NOT_FOUND_MCRECIPE);
                        return(RC_NOT_FOUND_MCRECIPE);
                    }    //D8000024
                }

//D8000024 add start
                if( skipFlag == FALSE )
                {
//D8000024 add end
                    objectIdentifier baseMachineRecipeID;
                    PPT_SET_OBJECT_IDENTIFIER(baseMachineRecipeID,
                                              aMachineRecipe,
                                              strProcess_startReserveInformation_Get_out,
                                              process_startReserveInformation_Get,
                                              PosMachineRecipe);

                    PPT_METHODTRACE_V2("CS_PPTManager_i::process_startReserveInformation_Get", "baseMachineRecipeID=", baseMachineRecipeID.identifier);
//P5100203 Add END
                    /*------------------------------------*/
                    /*   Get / Set Data Collection Info   */
                    /*------------------------------------*/
                    objProcess_dataCollectionDefinition_Get_out strProcess_dataCollectionDefinition_Get_out;
                    rc = process_dataCollectionDefinition_Get(  strProcess_dataCollectionDefinition_Get_out,
                                                                strObjCommonIn,
                                                                equipmentID,
                                                                strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID,
                                                                strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID,
//P5100203                                                                strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID);
                                                                baseMachineRecipeID);    //P5100203
                    if (rc != RC_OK)
                    {
                        strProcess_startReserveInformation_Get_out.strResult = strProcess_dataCollectionDefinition_Get_out.strResult;
                        return(rc);
                    }
                    strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.dataCollectionFlag = strProcess_dataCollectionDefinition_Get_out.dataCollectionFlag;
                    strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef           = strProcess_dataCollectionDefinition_Get_out.strDCDef;
                    if ( strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.dataCollectionFlag == TRUE )
                    {
                        CORBA::Long dcDEFLen = strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef.length();
                        PPT_METHODTRACE_V2("CS_PPTManager_i::process_startReserveInformation_Get", "<<< strStartCassette   >>>", i);
                        PPT_METHODTRACE_V2("CS_PPTManager_i::process_startReserveInformation_Get", "<<< strLotInCassette   >>>", j);
                        PPT_METHODTRACE_V2("CS_PPTManager_i::process_startReserveInformation_Get", "<<< dataCollectionFlag >>>", "TRUE");
                        PPT_METHODTRACE_V2("CS_PPTManager_i::process_startReserveInformation_Get", "<<< dcDEF count        >>>",  dcDEFLen);
                    }
                    else
                    {
                        CORBA::Long dcDEFLen = strProcess_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef.length();
                        PPT_METHODTRACE_V2("CS_PPTManager_i::process_startReserveInformation_Get", "<<< strStartCassette   >>>", i);
                        PPT_METHODTRACE_V2("CS_PPTManager_i::process_startReserveInformation_Get", "<<< strLotInCassette   >>>", j);
                        PPT_METHODTRACE_V2("CS_PPTManager_i::process_startReserveInformation_Get", "<<< dataCollectionFlag >>>", "FALSE");
                        PPT_METHODTRACE_V2("CS_PPTManager_i::process_startReserveInformation_Get", "<<< dcDEF count        >>>",  dcDEFLen);
                    }
                }    //D8000024
            }
        }
        /*----------------------*/
        /*                      */
        /*   Return to Caller   */
        /*                      */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::process_startReserveInformation_Get");
        return(RC_OK);
    }
    CATCH_GLOBAL_EXCEPTIONS(strProcess_startReserveInformation_Get_out, process_startReserveInformation_Get, methodName);
}

