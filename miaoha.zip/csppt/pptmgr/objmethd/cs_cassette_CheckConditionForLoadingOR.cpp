#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cs_cassette_CheckConditionForLoadingOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:31:41 [ 7/13/07 19:31:42 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_cassette_CheckConditionForLoadingOR.cpp
//

#include "cs_pptmgr.hpp"
#include "pcas.hh"
#include "pportrs.hh"     //D4000028

//[Object Function Name]: long   cassette_CheckConditionForLoading
//
// Date        Level    Author         Note
// ----------  -------  -------------  -------------------------------------------
// 2000-08-09  0.00     Y.Iwasaki      Initial Release
// 2000-08-24  0.01     Y.Iwasaki      Change method getCurrentState->getDurableState
// 2000-08-29  0.02     Y.Iwasaki      Change method getMultiRecipeCapability ->
//                                                   getMultipleRecipeCapability
// 2000-09-04  0.03     Y.Iwasaki      Change transferState check logic
// 2000-09-07  P3000062 Y.Iwasaki      Change define of multiRecipeCapability
//                                         A -> Multiple Recipe
//                                         B -> Single Recipe
//                                         C -> Batch
// 2000-09-20  Q3000107 Y.Iwasaki      Add check logic for EmptyCassette
// 2001-06-20  P4000029 K.Kido         Add check condition for combination of
//                                         Eqp's multiRecipeCapability and
//                                         cassette's multiLotType
// 2001-08-23  D4000056 M.Shimizu      Add Check Logic Equipment Category is Sorter
// 2001-09-03  D4000028 Y.Iwasaki      Add check logic for NPWXfer
// 2001-09-10  D4000028 Y.Iwasaki      Change DurableState Check Logic for NPWXfer
// 2007/06/21  D9000005 H.Hotta        WaferSorter automation support.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/11/04 DSIV00000214 S.Miyata       Multi Fab Transfer Support
//
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/10 INN-R170003  YangXigang     Durable Management Enhancement
//
//[Function Description]:
//  Check cassette's condition for Loading.
//  The following conditions are checked.
//
//  (*  marked item is not checked if NPW loading case)
//  (** marked item is not checked if loading port's loadPurposeType is "Other" case)  //D4000028
////D4000028  (** marked item is not checked if destination is "Sorter" case)
//
//  - multiLotType  (*)
//  - transferState
//  - cassetteState (**)
//
//
//  <<< multiLotType (*) >>>
//
//  Eqp's multiRecipeCapability and cassette's multiLotType must be kept
//  consistency as follows. (* no-check for Empty Cassette)   //Q3000107
//
//            Eqp's         ||                Cassette's
//    multiRecipeCapability ||               multiLotType
//    ======================||=============================================
//              A           ||               everything OK
//    --------------------- || --------------------------------------------
//              B           ||               everything OK
//    --------------------- || --------------------------------------------
//                          ||  SP_Cas_MultiLotType_SingleLotSingleRecipe
//              C           ||                     or
//                          ||  SP_Cas_MultiLotType_MultiLotSingleRecipe
//
//  <<< transferState >>>
//
//  Cassette's transfer state must be SO, MO, EO, IO, HO, or AO.
//
//  <<< cassetteState (**) >>>
//
//  Cassette's state must be _Available or _InUse.
//
//
//[Input Parameters]:
//  in  pptObjCommonIn              strObjCommonIn;
//  in  objectIdentifier            equipmentID;
//  in  objectIdentifier            portID;
//  in  objectIdentifier            cassetteID;
//
//[Output Parameters]:
//  out objCassette_CheckConditionForLoading_out   strCassette_CheckConditionForLoading_out;
//
//  typedef struct objCassette_CheckConditionForLoading_out_struct {
//      pptRetCode                  strResult;
//  } objCassette_CheckConditionForLoading_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_NOT_FOUND_CASSETTE       MSG_NOT_FOUND_CASSETTE
//  RC_NOT_FOUND_EQP            MSG_NOT_FOUND_EQP
//  RC_LOCKED_BY_ANOTHER        MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR             MSG_SYSTEM_ERROR

CORBA::Long CS_PPTManager_i::cassette_CheckConditionForLoading(
                            objCassette_CheckConditionForLoading_out& strCassette_CheckConditionForLoading_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& equipmentID,
                            const objectIdentifier& portID,
                            const objectIdentifier& cassetteID)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cassette_CheckConditionForLoading");
        PPT_METHODTRACE_V2("CS_PPTManager_i::cassette_CheckConditionForLoading", "in-parm's equipmentID", equipmentID.identifier);
        PPT_METHODTRACE_V2("CS_PPTManager_i::cassette_CheckConditionForLoading", "in-parm's portID", portID.identifier);
        PPT_METHODTRACE_V2("CS_PPTManager_i::cassette_CheckConditionForLoading", "in-parm's cassetteID", cassetteID.identifier);

        /*----------------*/
        /*                */
        /*   Initialize   */
        /*                */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        PosCassette_var aCassette;                                                                                                              //D4000028
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR(aCassette,cassetteID,strCassette_CheckConditionForLoading_out,cassette_CheckConditionForLoading); //D4000028

        //D4000028 add start
        //------------------------------//
        //                              //
        //   Judge NPW Loading or Not   //
        //                              //
        //------------------------------//
        CORBA::Boolean NPWFlag = FALSE;

        /*--------------------------*/
        /*   Get Equipment Object   */
        /*--------------------------*/
        PosMachine_var aMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR(aMachine,equipmentID,strCassette_CheckConditionForLoading_out,cassette_CheckConditionForLoading);

        //---------------------//
        //   Get Port Object   //
        //---------------------//
        PortResource_var    aBasePort;
        PosPortResource_var aPort;
        PPT_CONVERT_PORTID_TO_PORTRESOURCE_OR(aMachine,aBasePort,portID,strCassette_CheckConditionForLoading_out,cassette_CheckConditionForLoading);
        aPort = PosPortResource::_narrow(aBasePort);

        //--------------------------------//
        //   Get Port's LoadPurposeType   //
        //--------------------------------//
        CORBA::String_var portLoadPurposeType;
        try
        {
            portLoadPurposeType = aPort->getLoadPurposeType();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::getLoadPurposeType);

        //-----------------//
        //   Set NPWFlag   //
        //-----------------//
        if ( CIMFWStrCmp(portLoadPurposeType, SP_LoadPurposeType_SideDummyLot     )==0 ||
             CIMFWStrCmp(portLoadPurposeType, SP_LoadPurposeType_FillerDummy      )==0 ||
             CIMFWStrCmp(portLoadPurposeType, SP_LoadPurposeType_WaitingMonitorLot)==0 ||
             CIMFWStrCmp(portLoadPurposeType, SP_LoadPurposeType_Other            )==0 )
        {
            NPWFlag = TRUE;
        }
        //D4000028 add end

//D9000005 add start
        /*-------------------------------*/
        /*   Check SorterJob existence   */
        /*-------------------------------*/
        objectIdentifierSequence dummyIDs;
        pptEquipmentLoadPortAttribute equipmentPortAttribute;
        equipmentPortAttribute.strCassetteLoadPortSeq.length(1);
        equipmentPortAttribute.strCassetteLoadPortSeq[0].portID     = portID;
        equipmentPortAttribute.strCassetteLoadPortSeq[0].cassetteID = cassetteID;
        equipmentPortAttribute.equipmentID                          = equipmentID;

        objWaferSorter_sorterJob_CheckForOperation_out strWaferSorter_sorterJob_CheckForOperation_out;
        objWaferSorter_sorterJob_CheckForOperation_in  strWaferSorter_sorterJob_CheckForOperation_in;
        strWaferSorter_sorterJob_CheckForOperation_in.strEquipmentLoadPortAttribute = equipmentPortAttribute;
        strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs                   = dummyIDs;
        strWaferSorter_sorterJob_CheckForOperation_in.lotIDs                        = dummyIDs;
        strWaferSorter_sorterJob_CheckForOperation_in.operation                     = CIMFWStrDup(SP_Operation_LoadingLot);

        rc = waferSorter_sorterJob_CheckForOperation( strWaferSorter_sorterJob_CheckForOperation_out,
                                                      strObjCommonIn,
                                                      strWaferSorter_sorterJob_CheckForOperation_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "waferSorter_sorterJob_CheckForOperation() != RC_OK" );
            strCassette_CheckConditionForLoading_out.strResult = strWaferSorter_sorterJob_CheckForOperation_out.strResult;
            return( rc );
        }
//D9000005 add end

        /*--------------------------------------*/
        /*                                      */
        /*   Check Condition for MultiLotType   */
        /*                                      */
        /*--------------------------------------*/

        //---------------------//                          //D4000028
        //   Omit NPW Loading  //                          //D4000028
        //---------------------//                          //D4000028
        if ( NPWFlag == TRUE )                             //D4000028
        {                                                  //D4000028
            PPT_METHODTRACE_V1("", "NPWFlag == TRUE...");  //D4000028
            rc = RC_OK;                                    //D4000028
        }                                                  //D4000028
        else                                               //D4000028
        {                                                  //D4000028
            PPT_METHODTRACE_V1("", "NPWFlag == FALSE..."); //D4000028

//D4000028 /*--------------------------*/
//D4000028 /*   Get Equipment Object   */
//D4000028 /*--------------------------*/
//D4000028 PosMachine_var aMachine;
//D4000028 PPT_CONVERT_EQPID_TO_MACHINE_OR(aMachine,equipmentID,strCassette_CheckConditionForLoading_out,cassette_CheckConditionForLoading);

            /*-------------------------------------------*/
            /*   Get Equipment's MultiRecipeCapability   */
            /*-------------------------------------------*/
            CORBA::String_var multiRecipeCapability;
            try
            {
                multiRecipeCapability = aMachine->getMultipleRecipeCapability();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getMultipleRecipeCapability);

            /*---------------------------------*/
            /*   Get Cassette's MultiLotType   */
            /*---------------------------------*/
//D4000028  PosCassette_var aCassette;
//D4000028  PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR(aCassette,cassetteID,strCassette_CheckConditionForLoading_out,cassette_CheckConditionForLoading);
            CORBA::String_var multiLotType;
            try
            {
                multiLotType = aCassette->getMultiLotType();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getMultiLotType);

//Q3000107 start
            /*-------------------------------*/
            /*   Get Cassette's Empty Flag   */
            /*-------------------------------*/
            CORBA::Boolean emptyFlag;
            try
            {
                emptyFlag = aCassette->isEmpty();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isEmpty)

            if ( emptyFlag == TRUE )
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i::cassette_CheckConditionForLoading", "emptyFlag == TRUE");
                rc = RC_OK;
            }
            else
            {
//Q3000107 end
                PPT_METHODTRACE_V1("CS_PPTManager_i::cassette_CheckConditionForLoading", "emptyFlag == FALSE");

                //P4000029 add start
                /*-----------------------------------*/
                /*   Get Cassette's Cotrol Job ID    */
                /*-----------------------------------*/
                PosControlJob_var aControlJob;
                CORBA::Boolean    controlJobFlag = TRUE;

                try
                {
                    aControlJob = aCassette->getControlJob();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)

                if (  CORBA::is_nil(aControlJob) )
                {
                    PPT_METHODTRACE_V1("","There is not controlJob...");
                    controlJobFlag = FALSE;
                }
                //P4000029 add end

                /*-------------------------------------------------*/
                /*   Check MultiRecipeCapability VS MultiLotType   */
                /*-------------------------------------------------*/
//P3000062      if (CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_A) == 0)
                if (CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_MultipleRecipe) == 0) //P3000062
                {
                    PPT_METHODTRACE_V1("CS_PPTManager_i::cassette_CheckConditionForLoading", "multiRecipeCapability == SP_Eqp_MultiRecipeCapability_A");
                    rc = RC_OK;
                }
//P3000062      else if (CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_B) == 0)
//P4000029      else if (CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_SingleRecipe) == 0) //P3000062
//P4000029      {
//P4000029          PPT_METHODTRACE_V1("CS_PPTManager_i::cassette_CheckConditionForLoading", "multiRecipeCapability == SP_Eqp_MultiRecipeCapability_B");
//P4000029          rc = RC_OK;
//P4000029      }
//P4000029 add start
                else if (CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_SingleRecipe) == 0 &&
                         TRUE == controlJobFlag)
                {
                    PPT_METHODTRACE_V1("","controlJobFlag is filled");

                    PPT_METHODTRACE_V1("CS_PPTManager_i::cassette_CheckConditionForLoading", "multiRecipeCapability == SP_Eqp_MultiRecipeCapability_B");
                    rc = RC_OK;
                }
                else if (CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_SingleRecipe) == 0 &&
                         FALSE == controlJobFlag)
                {
                    PPT_METHODTRACE_V1("","controlJobFlag is not filled");

                    if (CIMFWStrCmp(multiLotType, SP_Cas_MultiLotType_SingleLotSingleRecipe) == 0 ||
                        CIMFWStrCmp(multiLotType, SP_Cas_MultiLotType_MultiLotSingleRecipe)  == 0)
                    {
                        PPT_METHODTRACE_V1("CS_PPTManager_i::cassette_CheckConditionForLoading", "multiLotType == (SP_Cas_MultiLotType_SingleLotSingleRecipe, SP_Cas_MultiLotType_MultiLotSingleRecipe)");
                        rc = RC_OK;
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("CS_PPTManager_i::cassette_CheckConditionForLoading", "multiLotType != (SP_Cas_MultiLotType_SingleLotSingleRecipe, SP_Cas_MultiLotType_MultiLotSingleRecipe)");
                        SET_MSG_RC(strCassette_CheckConditionForLoading_out, MSG_CAST_EQP_CONDITION_ERROR, RC_CAST_EQP_CONDITION_ERROR);
                        return( RC_CAST_EQP_CONDITION_ERROR );
                    }
                }
//P4000029 add end
//P3000062      else if (CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_C) == 0)
                else if (CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_Batch) == 0) //P3000062
                {
                    PPT_METHODTRACE_V1("CS_PPTManager_i::cassette_CheckConditionForLoading", "multiRecipeCapability == SP_Eqp_MultiRecipeCapability_C");
                    if (CIMFWStrCmp(multiLotType, SP_Cas_MultiLotType_SingleLotSingleRecipe) == 0 ||
                        CIMFWStrCmp(multiLotType, SP_Cas_MultiLotType_MultiLotSingleRecipe)  == 0)
                    {
                        PPT_METHODTRACE_V1("CS_PPTManager_i::cassette_CheckConditionForLoading", "multiLotType == (SP_Cas_MultiLotType_SingleLotSingleRecipe, SP_Cas_MultiLotType_MultiLotSingleRecipe)");
                        rc = RC_OK;
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("CS_PPTManager_i::cassette_CheckConditionForLoading", "multiLotType != (SP_Cas_MultiLotType_SingleLotSingleRecipe, SP_Cas_MultiLotType_MultiLotSingleRecipe)");
                        SET_MSG_RC(strCassette_CheckConditionForLoading_out, MSG_CAST_EQP_CONDITION_ERROR, RC_CAST_EQP_CONDITION_ERROR);
                        return( RC_CAST_EQP_CONDITION_ERROR );
                    }
                }
            }              //Q3000107
        }   //D4000028

        /*--------------------------------------*/
        /*                                      */
        /*   Check Cassette's Transfer Status   */
        /*                                      */
        /*--------------------------------------*/

        /*-----------------------*/
        /*   Get TransferState   */
        /*-----------------------*/
        CORBA::String_var transferState;
        try
        {
            transferState = aCassette->getTransportState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTransportState);

        if (CIMFWStrCmp(transferState, SP_TransState_StationOut     ) == 0 ||
            CIMFWStrCmp(transferState, SP_TransState_ManualOut      ) == 0 ||
            // INN-R170003 CIMFWStrCmp(transferState, SP_TransState_EquipmentOut   ) == 0 ||
            // INN-R170003 add start
            CIMFWStrCmp(transferState, CS_TRANS_STATE_PORT_IN   ) == 0 ||
            CIMFWStrCmp(transferState, CS_TRANS_STATE_PORT_OUT   ) == 0 ||
            // INN-R170003 add end
            CIMFWStrCmp(transferState, SP_TransState_IntermediateOut) == 0 ||
            CIMFWStrCmp(transferState, SP_TransState_ShelfOut       ) == 0 ||
            CIMFWStrCmp(transferState, SP_TransState_AbnormalOut    ) == 0 ||
            CIMFWStrCmp(transferState, SP_UNDEFINED_STATE           ) == 0)    //0.03
        {
            PPT_METHODTRACE_V2("", "transferState = ", transferState);
            PPT_METHODTRACE_V1("CS_PPTManager_i::cassette_CheckConditionForLoading", "transferState == (SP_TransState_StationOut, SP_TransState_ManualOut, SP_TransState_EquipmentOut, SP_TransState_IntermediateOut, SP_TransState_ShelfOut, SP_TransState_AbnormalOut)");
            rc = RC_OK;
        }
        else
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i::cassette_CheckConditionForLoading", "transferState != (SP_TransState_StationOut, SP_TransState_ManualOut, SP_TransState_EquipmentOut, SP_TransState_IntermediateOut, SP_TransState_ShelfOut, SP_TransState_AbnormalOut)");
            try
            {
                CORBA::String_var cassetteIdent;
                cassetteIdent = aCassette->getIdentifier();
                PPT_SET_MSG_RC_KEY2(strCassette_CheckConditionForLoading_out, MSG_INVALID_CAST_XFERSTAT, RC_INVALID_CAST_XFERSTAT, transferState, cassetteIdent);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getIdentifier);
            return( RC_INVALID_CAST_XFERSTAT );
        }

        /*-----------------------------*/
        /*                             */
        /*   Check Cassette's Status   */
        /*                             */
        /*-----------------------------*/
        PPT_METHODTRACE_V2("", "Check Cassette's Status...", __LINE__);

//D4000028 delete start
//      /*-----------------------*/
//      /*   Get TransferState   */
//      /*-----------------------*/
//      CORBA::String_var cassetteState;
//      try
//      {
//0.01      cassetteState = aCassette->getCurrentState();
//          cassetteState = aCassette->getDurableState();   //0.01
//      }
//      CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getDurableState);
//      if (CIMFWStrCmp(cassetteState, CIMFW_Durable_Available) == 0 ||
//          CIMFWStrCmp(cassetteState, CIMFW_Durable_InUse) == 0)
//      {
//          PPT_METHODTRACE_V1("CS_PPTManager_i::cassette_CheckConditionForLoading", "cassetteState == (CIMFW_Durable_Available, CIMFW_Durable_InUse)");
//          rc = RC_OK;
//      }
//      else
//      {
//          //D4000056 Start
//          //--------------------------------------------------
//          // Get Equipment Category And Check Wafer Sorter OR
//          //--------------------------------------------------
//          CORBA::String_var strEquipmentCategory;
//          strEquipmentCategory = CIMFWStrDup("");
//
//          CORBA::String_var strEqpInfoBySQL = theSP_EqpInfo_By_SQL;
//          PPT_METHODTRACE_V2("", "Env value is    ",strEqpInfoBySQL);
//
//          if(CIMFWStrCmp(strEqpInfoBySQL , "1") == 0)
//          {
//              PPT_METHODTRACE_V1("CS_PPTManager_i:: cassette_CheckConditionForLoading", "call equipment_brInfo_GetDR()...");
//              objEquipment_brInfo_GetDR_out strEquipment_brInfo_GetDR_out;
//              rc = equipment_brInfo_GetDR(strEquipment_brInfo_GetDR_out,
//                                          strObjCommonIn,
//                                          equipmentID);
//              PPT_METHODTRACE_V1("CS_PPTManager_i:: cassette_CheckConditionForLoading", "end equipment_brInfo_GetDR()...");
//              if ( rc != RC_OK )
//              {
//                  PPT_METHODTRACE_V2("CS_PPTManager_i:: cassette_CheckConditionForLoading", "rc = ",rc);
//                  PPT_METHODTRACE_V1("CS_PPTManager_i:: cassette_CheckConditionForLoading", "equipment_brInfo_GetDR() rc != RC_OK");
//                  strCassette_CheckConditionForLoading_out.strResult = strEquipment_brInfo_GetDR_out.strResult;
//                  return( rc );
//              }
//              strEquipmentCategory = CIMFWStrDup(strEquipment_brInfo_GetDR_out.equipmentBRInfo.equipmentCategory);
//          }
//          else
//          {
//              PPT_METHODTRACE_V1("CS_PPTManager_i:: cassette_CheckConditionForLoading", "call equipment_brInfo_Get()...");
//              objEquipment_brInfo_Get_out strEquipment_brInfo_Get_out;
//              rc = equipment_brInfo_Get(strEquipment_brInfo_Get_out,
//                                        strObjCommonIn,
//                                        equipmentID);
//              if ( rc != RC_OK )
//              {
//                  PPT_METHODTRACE_V2("CS_PPTManager_i:: cassette_CheckConditionForLoading", "rc = ",rc);
//                  PPT_METHODTRACE_V1("CS_PPTManager_i:: cassette_CheckConditionForLoading", "equipment_brInfo_Get() rc != RC_OK");
//                  strCassette_CheckConditionForLoading_out.strResult = strEquipment_brInfo_Get_out.strResult;
//                  return( rc );
//              }
//              strEquipmentCategory = CIMFWStrDup(strEquipment_brInfo_Get_out.equipmentBRInfo.equipmentCategory);
//          }
//
//          if (( CIMFWStrCmp(strEquipmentCategory, SP_Mc_Category_WaferSorter) == 0 )&&
//              ( CIMFWStrCmp(cassetteState, CIMFW_Durable_NotAvailable) == 0 ))
//          {
//              rc = RC_OK;
//          }
//          else
//          {
//          //D4000056 End
//              PPT_METHODTRACE_V1("CS_PPTManager_i::cassette_CheckConditionForLoading", "cassetteState != (CIMFW_Durable_Available, CIMFW_Durable_InUse)");
//              try
//              {
//                  CORBA::String_var cassetteIdent;
//                  cassetteIdent = aCassette->getIdentifier();
//                  PPT_SET_MSG_RC_KEY2(strCassette_CheckConditionForLoading_out,MSG_INVALID_CAST_STAT,RC_INVALID_CAST_STAT, cassetteState, cassetteIdent);
//              }
//              CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getIdentifier);
//              return( RC_INVALID_CAST_STAT );
//          }
//
//      }
//D4000028 delete end

        //D4000028 add start
        //-----------------------------------------------------------//
        //   If Port's LoadPurposeType = _Other, no-need to Check    //
        //-----------------------------------------------------------//
        if ( CIMFWStrCmp(portLoadPurposeType, SP_LoadPurposeType_Other)==0 )
        {
            PPT_METHODTRACE_V2("", "Port's LoadPurposeType is _Other! no-need to Check...", __LINE__);
            rc = RC_OK;
        }
        else
        {
            PPT_METHODTRACE_V2("", "Port's LoadPurposeType is Not _Other!", __LINE__);
            /*-----------------------*/
            /*   Get TransferState   */
            /*-----------------------*/
            CORBA::String_var cassetteState;
            try
            {
                cassetteState = aCassette->getDurableState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getDurableState);

            if (CIMFWStrCmp(cassetteState, CIMFW_Durable_Available) == 0 ||
                CIMFWStrCmp(cassetteState, CIMFW_Durable_InUse) == 0)
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i::cassette_CheckConditionForLoading", "cassetteState == (CIMFW_Durable_Available, CIMFW_Durable_InUse)");
                rc = RC_OK;
            }
            else
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i::cassette_CheckConditionForLoading", "cassetteState != (CIMFW_Durable_Available, CIMFW_Durable_InUse)");
                try
                {
                    CORBA::String_var cassetteIdent;
                    cassetteIdent = aCassette->getIdentifier();
                    PPT_SET_MSG_RC_KEY2(strCassette_CheckConditionForLoading_out,MSG_INVALID_CAST_STAT,RC_INVALID_CAST_STAT, cassetteState, cassetteIdent);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getIdentifier);
                return( RC_INVALID_CAST_STAT );
            }
        }
        //D4000028 add end

//DSIV00000214 add start
        //-----------------------------------------------------------
        // Check cassette interFabXferState
        //-----------------------------------------------------------
        objCassette_interFabXferState_Get_out strCassette_interFabXferState_Get_out;
        objCassette_interFabXferState_Get_in strCassette_interFabXferState_Get_in;
        strCassette_interFabXferState_Get_in.cassetteID = cassetteID;

        rc = cassette_interFabXferState_Get( strCassette_interFabXferState_Get_out,
                                             strObjCommonIn,
                                             strCassette_interFabXferState_Get_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cassette_interFabXferState_Get() != RC_OK");
            strCassette_CheckConditionForLoading_out.strResult = strCassette_interFabXferState_Get_out.strResult;
            return( rc );
        }

        if( CIMFWStrCmp( strCassette_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Transferring ) == 0 )
        {
             PPT_METHODTRACE_V1("", "interFabXferState == Transferring");
             PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForLoading_out,
                                  MSG_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                  RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                  cassetteID.identifier,
                                  strCassette_interFabXferState_Get_out.interFabXferState );
             return( RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ );
        }
//DSIV00000214 add end

        /*----------------------*/
        /*                      */
        /*   Return to Caller   */
        /*                      */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cassette_CheckConditionForLoading");
        return(rc);

    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_CheckConditionForLoading_out, cassette_CheckConditionForLoading, methodName);
}
