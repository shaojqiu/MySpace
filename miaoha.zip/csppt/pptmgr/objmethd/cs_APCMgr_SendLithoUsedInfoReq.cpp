//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
//
// SiView
// Name: cs_APCMgr_SendLithoUsedInfoReq.cpp
//

// Class: CS_PPTManager
//
// [Object Function Name]: long   cs_APCMgr_SendLithoUsedInfoReq.cpp
//
//
// Innotron Modification history:
// Date       Defect#   Person         Comments
// ---------- --------- -------------- -------------------------------------------
// 2017/09/26 INN-R170009  Xinxin_Liu      Add APC Litho
//
// Function Description:
//
// Input Parameters:
// in csobjAPCMgr_SendLithoUsedInfoReq_in  strObjAPCMgr_SendLithoUsedInfoReq_in;
//
//typedef struct csObjAPCMgr_SendLithoUsedInfoReq_in_struct {
//    objectIdentifier            equipmentID;
//    pptStartCassetteSequence    strStartCassette;
//    string                      action;
//    any                         siInfo;
//}csObjAPCMgr_SendLithoUsedInfoReq_in;

//
// Output Parameters:
// out csObjAPCMgr_SendLithoUsedInfoReq_out strObjAPCMgr_SendLithoUsedInfoReq_out;
//
//typedef struct csObjAPCMgr_SendLithoUsedInfoReq_out_struct {
//    pptRetCode                      strResult;
//    any                             siInfo;
//}csObjAPCMgr_SendLithoUsedInfoReq_out;

//
// Return Value:
//
// Exception:
//
// Pseudo code:
//

#include "cs_pptmgr.hpp"


CORBA::Long CS_PPTManager_i::cs_APCMgr_SendLithoUsedInfoReq(
    csObjAPCMgr_SendLithoUsedInfoReq_out&       strObjAPCMgr_SendLithoUsedInfoReq_out,
    const pptObjCommonIn&                              strObjCommonIn,
    const csObjAPCMgr_SendLithoUsedInfoReq_in&  strObjAPCMgr_SendLithoUsedInfoReq_in )
{
    CORBA::Long rc = RC_OK;

    return(RC_OK);
}