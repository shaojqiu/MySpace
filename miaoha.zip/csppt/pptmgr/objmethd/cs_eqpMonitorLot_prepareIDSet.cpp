//
// (c) Copyright: IBM Services Company Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// Name: cs_eqpMonitorLot_prepareIDSet.cpp
//

#include "cs_pptmgr.hpp"
#include "plot.hh"
#include "pemon.hh"

// Class: CS_PPTManager
//
// Service: cs_eqpMonitorLot_prepareIDSet()
//
// Change history:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/10/27 INN-R170016 JJ.Zhang       Initial Release
//
//[Function Description]
//  set same prepare ID for all monitor lot
//
//[Input Parameters]
//  const pptObjCommonIn&             strObjCommonIn
//  const csObjEqpMonitorLot_prepareIDSet_in&  strEqpMonitorLot_prepareIDSet_in
//
//  typedef struct csObjEqpMonitorLot_prepareIDSset_in_struct
//  {
//    objectIdentifier          eqpMonitorID;
//    objectIdentifier          carrierID;
//    objectIdentifierSequence  lotIDs;
//      any              siInfo;
//  }csObjEqpMonitorLot_prepareIDSet_in;
//
//[Output Parameters]
//  csObjEqpMonitorLot_prepareIDSet_out&   strEqpMonitorLot_prepareIDSet_out
//
//  typedef objBase_out csObjEqpMonitorLot_prepareIDSet_out;
//
//
//[Return Value]:
//
//  Return Code                        Messsage ID
//  ---------------------------------- -----------------------------------------
//  RC_OK                              MSG_OK
//  RC_SYSTEM_ERROR                    MSG_SYSTEM_ERROR
//

CORBA::Long CS_PPTManager_i::cs_eqpMonitorLot_prepareIDSet (
    csObjEqpMonitorLot_prepareIDSet_out& strEqpMonitorLot_prepareIDSet_out,
    const pptObjCommonIn&                strObjCommonIn,
    const csObjEqpMonitorLot_prepareIDSet_in&  strEqpMonitorLot_prepareIDSet_in  )
{
    char* methodName = NULL;

    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cs_eqpMonitorLot_prepareIDSet");

        //-----------------------------------------
        //  Initialize
        //-----------------------------------------
        CORBA::Long rc = RC_OK;
        CORBA::ULong i = 0, j = 0;
        CORBA::ULong nSeqLen = 0;

        //----------------------------------------------
        // Lock EqpMonitor object
        //----------------------------------------------
        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, strEqpMonitorLot_prepareIDSet_in.eqpMonitorID, SP_ClassName_PosEqpMonitor );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
            strEqpMonitorLot_prepareIDSet_out.strResult = strObject_Lock_out.strResult;
            return rc;
        }

        objectIdentifier carrierID = strEqpMonitorLot_prepareIDSet_in.carrierID;
        //----------------------------------------------
        // Check slot map matched the monitor definiton
        //----------------------------------------------
        objCassette_GetWaferMapDR_out strCassette_GetWaferMapDR_out;
        rc = cassette_GetWaferMapDR(strCassette_GetWaferMapDR_out, strObjCommonIn, carrierID);
        if(rc!= RC_OK)
        {
            PPT_METHODTRACE_V2("", "cassette_GetWaferMapDR() != RC_OK ", carrierID.identifier );
            strEqpMonitorLot_prepareIDSet_out.strResult = strCassette_GetWaferMapDR_out.strResult;
            return( rc );
        }

        //----------------------------------------------
        // pick-up wafers in carrier
        //----------------------------------------------
        CORBA::ULong mapLen = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo.length();
        pptWaferMapInCassetteInfoSequence strWaferMapInCassetteInfoSeq;
        strWaferMapInCassetteInfoSeq.length(mapLen);
        CORBA::Long waferCount = 0;

        for( i =0; i<mapLen; i++)
        {
            PPT_METHODTRACE_V2("", "waferID", strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].waferID.identifier );
            if( 0 < CIMFWStrLen(strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].waferID.identifier) )
            {
                strWaferMapInCassetteInfoSeq[waferCount] = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i];
                waferCount++ ;
            }
        }
        strWaferMapInCassetteInfoSeq.length(waferCount);
        PPT_METHODTRACE_V2("", "waferCount", waferCount );

        objEqpMonitor_info_Get_in strEqpMonitor_info_Get_in;
        strEqpMonitor_info_Get_in.eqpMonitorID = strEqpMonitorLot_prepareIDSet_in.eqpMonitorID;

        csObjEqpMonitor_info_Get_out strEqpMonitor_info_Get_out;
        rc = cs_eqpMonitor_info_GetDR( strEqpMonitor_info_Get_out,
                                  strObjCommonIn,
                                  strEqpMonitor_info_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cs_eqpMonitor_info_GetDR() != RC_OK", rc);
            strEqpMonitorLot_prepareIDSet_out.strResult = strEqpMonitor_info_Get_out.strResult;
            return rc;
        }

        csEqpMonitorSubInfoSequence& strEqpMonitorSubInfoSeq = strEqpMonitor_info_Get_out.strEqpMonitorDetailInfos[0].strEqpMonitorSubInfoSeq;
        nSeqLen = strEqpMonitorSubInfoSeq.length();
        if( waferCount != nSeqLen )
        {
            //slot map not matched the monitor definiton
            PPT_METHODTRACE_V2("", "waferCount!= nSeqLen", waferCount );
            CS_PPT_SET_MSG_RC_KEY2( strEqpMonitorLot_prepareIDSet_out,
                                    CS_MSG_WAFER_SLOTMAP_UNMATCH,
                                    CS_RC_WAFER_SLOTMAP_UNMATCH,
                                    carrierID.identifier,
                                    strEqpMonitorLot_prepareIDSet_in.eqpMonitorID.identifier );
            return CS_RC_WAFER_SLOTMAP_UNMATCH;
        }

        for( i =0; i<nSeqLen; i++)
        {
            //wafer in slot should have same attribute as what defined in EQPMON_SUB
            PPT_METHODTRACE_V2("", " check slotNumber", strEqpMonitorSubInfoSeq[i].slotNumber);
            if(strWaferMapInCassetteInfoSeq[i].slotNumber != strEqpMonitorSubInfoSeq[i].slotNumber)
            {
                PPT_METHODTRACE_V2("", "WaferID", strWaferMapInCassetteInfoSeq[i].waferID.identifier);
                char slotNumber[64];
                sprintf(slotNumber, "%ld", strWaferMapInCassetteInfoSeq[i].slotNumber);
                CS_PPT_SET_MSG_RC_KEY2( strEqpMonitorLot_prepareIDSet_out,
                                        CS_MSG_WAFER_NO_USE_BY_EQPMON,
                                        CS_RC_WAFER_NO_USE_BY_EQPMON,
                                        slotNumber,
                                        strEqpMonitorLot_prepareIDSet_in.eqpMonitorID.identifier );
                return CS_RC_WAFER_NO_USE_BY_EQPMON;
            }

            //----------------------------------------------
            // Get product ID for wafer
            //----------------------------------------------
            objLot_productID_Get_out strLot_productID_Get_out;
            rc = lot_productID_Get( strLot_productID_Get_out,
                                    strObjCommonIn,
                                    strWaferMapInCassetteInfoSeq[i].lotID );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "","lot_productID_Get != RC_OK", rc );
                strEqpMonitorLot_prepareIDSet_out.strResult = strLot_productID_Get_out.strResult;
                return rc;
            }
            PPT_METHODTRACE_V2("", "productID", strLot_productID_Get_out.productID.identifier);

            if ( 0 != CIMFWStrCmp(strLot_productID_Get_out.productID.identifier, strEqpMonitorSubInfoSeq[i].productID.identifier) )
            {
                PPT_METHODTRACE_V2("", "Product doesn't match", strWaferMapInCassetteInfoSeq[i].waferID.identifier);
                char slotNumber[64];
                sprintf(slotNumber, "%ld", strWaferMapInCassetteInfoSeq[i].slotNumber);
                CS_PPT_SET_MSG_RC_KEY2( strEqpMonitorLot_prepareIDSet_out,
                                        CS_MSG_WAFER_NO_USE_BY_EQPMON,
                                        CS_RC_WAFER_NO_USE_BY_EQPMON,
                                        slotNumber,
                                        strEqpMonitorLot_prepareIDSet_in.eqpMonitorID.identifier );
                return CS_RC_WAFER_NO_USE_BY_EQPMON;
            }
        }

        //----------------------------------------------
        // Generate new monitor prepare ID
        //----------------------------------------------
        PosEqpMonitor_var aPosEqpMonitor;
        PPT_CONVERT_EQPMONITORID_TO_EQPMONITOR_OR( aPosEqpMonitor,
                                                   strEqpMonitorLot_prepareIDSet_in.eqpMonitorID,
                                                   strEqpMonitorLot_prepareIDSet_out,
                                                   cs_eqpMonitorLot_prepareIDSet );
        CORBA::String_var strDate;
        SI_PPT_USERDATA_GET_STRING( aPosEqpMonitor, CS_M_EQPM_LastPrepDate, strDate );
        PPT_METHODTRACE_V2("", "CS_M_EQPM_LastPrepDate", strDate);

        //Get date today ex:20171031
        struct timeb t;
        t.time = time(0);
        struct tm  currentTime;
        localtime_r( &t.time, &currentTime );

        char workbuf[128];
        memset(workbuf,'\0', sizeof(workbuf));
        sprintf( workbuf, "%04d%02d%02d", // YYYYMMDD
                        currentTime.tm_year + 1900 + 1,
                        currentTime.tm_mon + 1,
                        currentTime.tm_mday );

        CORBA::Long seqNo = 1;
        CORBA::String_var strSeqNo;
        if( 0 == CIMFWStrCmp(strDate, workbuf) )
        {
            SI_PPT_USERDATA_GET_STRING( aPosEqpMonitor, CS_M_EQPM_LastPrepSeqNo, strSeqNo );
            PPT_METHODTRACE_V2("", "CS_M_EQPM_LastPrepSeqNo", strSeqNo);
            seqNo= atol(strSeqNo) + 1;
        }
        else
        {
            strDate = CIMFWStrDup(workbuf);
            SI_PPT_USERDATA_SET_STRING( aPosEqpMonitor, CS_M_EQPM_LastPrepDate, strDate );
            seqNo = 1;
        }

        sprintf(workbuf, "%02ld", seqNo);
        strSeqNo = CIMFWStrDup(workbuf);
        SI_PPT_USERDATA_SET_STRING( aPosEqpMonitor, CS_M_EQPM_LastPrepSeqNo, strSeqNo );

        //ex: EQPMON01-20171031-01
        CORBA::String_var strPrepareID;
        sprintf(workbuf, "%s-%s-%02ld", (const char*)strEqpMonitorLot_prepareIDSet_in.eqpMonitorID.identifier, (const char*)strDate, seqNo);
        strPrepareID = CIMFWStrDup(workbuf);
        PPT_METHODTRACE_V2("", "strPrepareID", strPrepareID);

        //----------------------------------------------
        // Set prepareID in udata for all lots
        //----------------------------------------------
        objCassette_GetLotList_out strCassette_GetLotList_out;
        rc = cassette_GetLotList( strCassette_GetLotList_out, strObjCommonIn, carrierID );

        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cassette_GetLotList() != RC_OK", rc);
            strEqpMonitorLot_prepareIDSet_out.strResult = strCassette_GetLotList_out.strResult;
            return( rc );
        }

        objectIdentifierSequence lotIDs;
        lotIDs = strCassette_GetLotList_out.strLotListInCassetteInfo.lotID;
        nSeqLen = lotIDs.length();
        for( i =0; i<nSeqLen; i++)
        {
            PPT_METHODTRACE_V2("", "lotIDs[i]", lotIDs[i].identifier);

            PosLot_var aPosLot;
            PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot, lotIDs[i], strEqpMonitorLot_prepareIDSet_out, cs_eqpMonitorLot_prepareIDSet );

            SI_PPT_USERDATA_SET_STRING( aPosLot, CS_M_LOT_Monitor_PrepID, strPrepareID );
        }

        //----------------------------------------
        //  Return to caller
        //----------------------------------------		
        PPT_METHODTRACE_EXIT( "CS_PPTManager_i::cs_eqpMonitorLot_prepareIDSet");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS( strEqpMonitorLot_prepareIDSet_out, cs_eqpMonitorLot_prepareIDSet, methodName );
}
