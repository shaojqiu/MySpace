//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
//
// SiView
// Name: cs_APC_LithoLotDataInfo_Get.cpp
//

// Class: CS_PPTManager
//
// [Object Function Name]: long   cs_APC_LithoLotDataInfo_Get
//
//
// Innotron Modification history:
// Date       Defect#     Person        Comments
// ---------- ----------- ------------- -------------------------------------------
// 2017/09/20 INN-R170009 Gary Ke       Add APC Litho Lot Data Info Get
//
// Function Description:
// in csObjAPC_LithoLotDataInfo_Get_in strAPC_LithoLotDataInfo_Get_in;
//
// typedef struct csObjAPC_LithoLotDataInfo_Get_in_struct {
//     objectIdentifier       lotID;
//     objectIdentifier       routeID;
//     string                 operationNumber;
//     any                    siInfo;    
// }csObjAPC_LithoLotDataInfo_Get_in;
//
// Output Parameters:
// out csObjAPC_LithoLotDataInfo_Get_out strAPC_LithoLotDataInfo_Get_out;
//
// typedef struct csObjAPC_LithoLotDataInfo_Get_out_struct {
//     pptRetCode             strResult; 
//     csLithoLotDataInfo     strLithoLotDataInfo;
//     any                    siInfo;     
// }csObjAPC_LithoLotDataInfo_Get_out;
//
// Return Value:
//
// Exception:
//
// Pseudo code:
//

#include "cs_pptmgr.hpp"
#include "plot.hh"
#include "ppcflwx.hh"
#include "ppcflw.hh"
#include "ppcope.hh"
#include "ppcopsp.hh"
#include "pwafer.hh"

CORBA::Long CS_PPTManager_i::cs_APC_LithoLotDataInfo_Get(
    csObjAPC_LithoLotDataInfo_Get_out&       strAPC_LithoLotDataInfo_Get_out,
    const pptObjCommonIn&                    strObjCommonIn,
    const csObjAPC_LithoLotDataInfo_Get_in&  strAPC_LithoLotDataInfo_Get_in )
{
    char * methodName = NULL;
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_APC_LithoLotDataInfo_Get");
    sqlca sqlca;
    try
    {
        CORBA::Long rc = RC_OK;
        PosLot_var aLot;
        PPT_METHODTRACE_V2("","lotID" ,strAPC_LithoLotDataInfo_Get_in.lotID.identifier);
        PPT_CONVERT_LOTID_TO_LOT_OR( aLot, strAPC_LithoLotDataInfo_Get_in.lotID, strAPC_LithoLotDataInfo_Get_out, strAPC_LithoLotDataInfo_Get);
        PosWaferInfoSequence_var aWaferInfoSeq;
        try
        {
            aWaferInfoSeq = aLot -> getAllWaferInfo();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getAllWaferInfo);
        strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.lotID = strAPC_LithoLotDataInfo_Get_in.lotID;
        char* rwkCntKey = CORBA::string_alloc((CORBA::ULong)CIMFWStrLen(strAPC_LithoLotDataInfo_Get_in.routeID.identifier) + CIMFWStrLen(SP_Key_Separator_Dot ) + CIMFWStrLen( strAPC_LithoLotDataInfo_Get_in.operationNumber ));
        if( rwkCntKey != NULL )
        {
            PPT_METHODTRACE_V1("", "rwkCntKey != NULL");
            rwkCntKey[0] = NULL;
            CIMFWStrCpy( rwkCntKey, strAPC_LithoLotDataInfo_Get_in.routeID.identifier );
            CIMFWStrCat( rwkCntKey, SP_Key_Separator_Dot );
            CIMFWStrCat( rwkCntKey, strAPC_LithoLotDataInfo_Get_in.operationNumber);
            PPT_METHODTRACE_V2("","rwkCntKey" , rwkCntKey);
        }	
        CORBA::Long lngWaferDataSeqLen = aWaferInfoSeq -> length();
        PPT_METHODTRACE_V2("","lngWaferDataSeqLen" , lngWaferDataSeqLen);	
        strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq.length(lngWaferDataSeqLen);
        for (CORBA::Long idx = 0 ; idx < lngWaferDataSeqLen ; idx++)
        {
            //waferID
            strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[idx].waferID = (*aWaferInfoSeq)[idx].waferID;
            PPT_METHODTRACE_V2("","waferID" , strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[idx].waferID.identifier);
            //slotNo
            strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[idx].slotNo  = (*aWaferInfoSeq)[idx].position;
            PPT_METHODTRACE_V2("","slotNo" , strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[idx].slotNo);
            //chuckID
            PosWafer_var aWafer;
            PPT_CONVERT_WAFERID_TO_WAFER_OR( aWafer,
                                             strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[idx].waferID,
                                             strAPC_LithoLotDataInfo_Get_out,
                                             cs_APC_LithoLotDataInfo_Get ) ;
            CORBA::String_var varWaferDataChuckID;
            try
            {
                SI_PPT_USERDATA_GET_STRING(aWafer,
                                           CS_M_WAFER_FIRST_LITHO_USED_CHUCK,
                                           varWaferDataChuckID);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getUserDataNamed);
            PPT_METHODTRACE_V2("","chuckID" , varWaferDataChuckID);	
            strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[idx].chuckID = atol (varWaferDataChuckID);
            //reworkCount
            CORBA::Long lngreworkCount = 0;
            try
            {
                lngreworkCount = aWafer->getReworkCount( rwkCntKey );
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getReworkCount);
            PPT_METHODTRACE_V2("","lngreworkCount" , lngreworkCount);
            strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[idx].reworkCount = lngreworkCount;
        }   
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_APC_LithoLotDataInfo_Get");
        return RC_OK;
    }    
    CATCH_GLOBAL_EXCEPTIONS(strAPC_LithoLotDataInfo_Get_out, cs_APC_LithoLotDataInfo_Get, methodName );
}
