#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/csppt/source/posppt/pptmgr/objmethd/cs_lot_NPWProduct_Change.cpp, mm_srv_90e_cspp, mm_srv_90e_cspp 7/13/07 19:54:32 [ 7/13/07 19:54:34 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// Name: cs_lot_NPWProduct_Change.cpp
// Change history:
//
// Innotron Modification history :
// Date       Defect#         Person               Comments
// ---------- --------------- -------------------- -------------------------------------------
// 2017/10/19 INN-R170027     Vera Chen            Initial Release
//
//
//


#include "cs_pptmgr.hpp"
#include "cs_posconst.hpp"
#include "plot.hh"
#include "ppsctgy.hh"
CORBA::Long CS_PPTManager_i::cs_lot_NPWProduct_Change(
			csObjLot_NPWProduct_Change_out&         strObjLot_NPWProduct_Change_out,
			const pptObjCommonIn&                   strObjCommonIn,
            const csObjLot_NPWProduct_Change_in&    strObjLot_NPWProduct_Change_in)

{
    char * methodName = NULL;
    try
    {
        
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_lot_NPWProduct_Change");
        CORBA::Long rc = RC_OK;
         
        PPT_METHODTRACE_V2("","orgProductID ", strObjLot_NPWProduct_Change_in.orgProductID.identifier);
        PPT_METHODTRACE_V2("","productID    ", strObjLot_NPWProduct_Change_in.productID.identifier);
        PPT_METHODTRACE_V2("","lotID        ", strObjLot_NPWProduct_Change_in.lotID.identifier);
                
        PosProductSpecification_var aPrevProductSpecification;
        PPT_CONVERT_PRODUCTID_TO_PRODUCTSP_OR(aPrevProductSpecification,strObjLot_NPWProduct_Change_in.orgProductID,strObjLot_NPWProduct_Change_out,cs_lot_NPWProduct_Change);
        
        //Step1.Check product category of orgProductID is non-Production
        PosProductCategory_var aPrevPosProdCategory;
        try
        {
            aPrevPosProdCategory = aPrevProductSpecification->getProductCategory();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProductSpecification::getProductCategory)

        if( !CORBA::is_nil(aPrevPosProdCategory) )
        {
            CORBA::String_var productCategory;
            try
            {
                productCategory = aPrevPosProdCategory->getIdentifier();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProductCategory::getIdentifier)

            PPT_METHODTRACE_V2("", "productCategory", productCategory);

            if( 0 == CIMFWStrCmp( productCategory, SP_ProductCategory_Production))
            {
                PPT_SET_MSG_RC_KEY( strObjLot_NPWProduct_Change_out,
                                    MSG_INVALID_PRODUCT_CATEGORY,   //000XXXXE:Invalid product category. [%s].
                                    RC_INVALID_PRODUCT_CATEGORY,
                                    productCategory );
                return RC_INVALID_PRODUCT_CATEGORY ;
            }
        }
        PosProductSpecification_var aPosProductSpecification;
        PPT_CONVERT_PRODUCTID_TO_PRODUCTSP_OR(aPosProductSpecification,strObjLot_NPWProduct_Change_in.productID,strObjLot_NPWProduct_Change_out,cs_lot_NPWProduct_Change);
        
        //Step2.Check product category of ProductID is non-Production
        PosProductCategory_var aPosProdCategory;
        try
        {
            aPosProdCategory = aPosProductSpecification->getProductCategory();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProductSpecification::getProductCategory)
        
        if( !CORBA::is_nil(aPosProdCategory) )
        {
            CORBA::String_var productCategory;
            try
            {
                productCategory = aPosProdCategory->getIdentifier();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProductCategory::getIdentifier)

            PPT_METHODTRACE_V2("", "productCategory", productCategory);

            if( 0 == CIMFWStrCmp( productCategory, SP_ProductCategory_Production))
            {
                PPT_SET_MSG_RC_KEY( strObjLot_NPWProduct_Change_out,
                                    MSG_INVALID_PRODUCT_CATEGORY,   //000XXXXE:Invalid product category. [%s].
                                    RC_INVALID_PRODUCT_CATEGORY,
                                    productCategory );
                return RC_INVALID_PRODUCT_CATEGORY ;
            }
        }
        
        PosLot_var aLot;
        PPT_CONVERT_LOTID_TO_LOT_OR(aLot,strObjLot_NPWProduct_Change_in.lotID,strObjLot_NPWProduct_Change_out,cs_lot_NPWProduct_Change);

        try
        {
            aLot->setProductSpecification( aPosProductSpecification ) ;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setProductSpecification)


        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_lot_NPWProduct_Change");

        return( rc );
    }
    CATCH_GLOBAL_EXCEPTIONS(strObjLot_NPWProduct_Change_out, cs_lot_NPWProduct_Change, methodName)

}
