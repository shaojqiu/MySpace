// (c) Copyright: International Business Machines Corporation, 2017, 2027. All rights reserved.
// SiView 
// Name : cs_person_PrivilegeCheckForTACertify.cpp

// Class: PPTManager
//
// Service: cs_person_PrivilegeCheckForTACertify()

// Date         Defect#         Person         Comments
// ----------   ------------    -------------- -------------------------------------------
// 2017/09/11   INN-R170008     Menghua Yin    TA Certify Support
// 2017/10/23   INN-R170008-01  Vera Chen      Add check logic of CS_TACERTIFY_SKILL_EXP_DURATION
//
// Description:
//
// Return:
//     Long
//
//[Input Parameters]:
//  in  pptObjCommonIn                                      strObjCommonIn
//  in  csObjPerson_PrivilegeCheckForTACertify_in&          strObjPerson_PrivilegeCheckForTACertify_in
//
//[Output Parameters]:
//  out csObjPerson_PrivilegeCheckForTACertify_out&         strObjPerson_PrivilegeCheckForTACertify_out

#include "cs_pptmgr.hpp"

CORBA::Long CS_PPTManager_i::cs_person_PrivilegeCheckForTACertify(
        csObjPerson_PrivilegeCheckForTACertify_out&         strObjPerson_PrivilegeCheckForTACertify_out,
        const pptObjCommonIn&                               strObjCommonIn,
        const csObjPerson_PrivilegeCheckForTACertify_in&    strObjPerson_PrivilegeCheckForTACertify_in)
{
    char * methodName = NULL;

    try
    {
        if (CIMFWStrLen(strObjPerson_PrivilegeCheckForTACertify_in.equipmentID.identifier) == 0)
        {
            SET_MSG_RC(strObjPerson_PrivilegeCheckForTACertify_out, MSG_OK, RC_OK);
            return RC_OK;
        }
        
        CORBA::Long rc = RC_OK;

        //INN-R170008-01 Add start
        CORBA::String_var tmpTACertifySkillExpDuration = CIMFWStrDup(getenv(CS_TACERTIFY_SKILL_EXP_DURATION));
        CORBA::Long nExpDuration = 0;
        if(CIMFWStrLen(tmpTACertifySkillExpDuration) > 0)
        {
            nExpDuration = atol(tmpTACertifySkillExpDuration);
        }
        //INN-R170008-01 Add end
        // prepare input parameter for get user's data
        pptUserDataInqInParm__101 strUserDataInqInParm;
        strUserDataInqInParm.className = CIMFWStrDup(SP_ClassName_PosPerson);
        strUserDataInqInParm.strHashedInfoSeq.length(1);
        strUserDataInqInParm.strHashedInfoSeq[0].hashKey = CIMFWStrDup(SP_HashData_USER_ID);
        strUserDataInqInParm.strHashedInfoSeq[0].hashData = strObjCommonIn.strUser.userID.identifier;
        strUserDataInqInParm.userDataName = CIMFWStrDup(CS_S_USER_CERTIFICATION_REQURIED);
        strUserDataInqInParm.userDataOriginator = CIMFWStrDup(SP_USERDATA_ORIG_SM);

        // Get user's string ifiedObjectReference via object_Get()
        objObject_Get_out strObject_Get_out;
        objObject_Get_in strObject_Get_in;
        
        strObject_Get_in.className = strUserDataInqInParm.className;
        strObject_Get_in.strHashedInfoSeq = strUserDataInqInParm.strHashedInfoSeq;

        rc = object_Get(strObject_Get_out, strObjCommonIn, strObject_Get_in);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "object_Get() rc != RC_OK");
            strObjPerson_PrivilegeCheckForTACertify_out.strResult = strObject_Get_out.strResult;
            return rc;
        }
        
        // get user's uData
        objObject_UserData_Get_out strObject_UserData_Get_out;
        rc = object_userData_Get__101( strObject_UserData_Get_out,
                                       strObjCommonIn,
                                       strUserDataInqInParm,
                                       strObject_Get_out.stringifiedObjectReference );

        if (rc != RC_OK && rc != RC_NOT_FOUND_UDATA)
        {
            PPT_METHODTRACE_V1("", "object_userData_Get() rc != RC_OK");
            strObjPerson_PrivilegeCheckForTACertify_out.strResult = strObject_UserData_Get_out.strResult;
            return rc;
        }
        //INN-R170008-01 Add start
        if(strObject_UserData_Get_out.strUserDataSeq.length() > 0 )
        {
        //INN-R170008 add end
            PPT_METHODTRACE_V1("", "Find TA UserData");
            PPT_METHODTRACE_V2("", "strObject_UserData_Get_out.strUserDataSeq.length()",strObject_UserData_Get_out.strUserDataSeq.length());
            PPT_METHODTRACE_V2("", "name", strObject_UserData_Get_out.strUserDataSeq[0].name);
            PPT_METHODTRACE_V2("", "value", strObject_UserData_Get_out.strUserDataSeq[0].value);
        }//INN-R170008-01
        CORBA::Boolean bCertifyFlag = FALSE;
        if (strObject_UserData_Get_out.strUserDataSeq.length() > 0 &&
            CIMFWStrCmp(strObject_UserData_Get_out.strUserDataSeq[0].name, CS_S_USER_CERTIFICATION_REQURIED) == 0 &&
            CIMFWStrCmp(strObject_UserData_Get_out.strUserDataSeq[0].value, CS_COMMON_YES) == 0)
        {
            PPT_METHODTRACE_V1("", "Need to certify!");
            bCertifyFlag = TRUE;
        }
        else
        {
            SET_MSG_RC(strObjPerson_PrivilegeCheckForTACertify_out, MSG_OK, RC_OK);
            return RC_OK;
        }
        
        if (bCertifyFlag)
        {
            // Get Eqp Type of Eqp ID
            objEquipment_getTypeDR_out strEquipment_getTypeDR_out;

            rc = equipment_getTypeDR( strEquipment_getTypeDR_out,
                                      strObjCommonIn,
                                      strObjPerson_PrivilegeCheckForTACertify_in.equipmentID );

            if (rc != RC_OK && rc !=SP_SQL_NOT_FOUND)
            {
                PPT_METHODTRACE_V2("", "equipment_getTypeDR_out() rc != RC_OK, rc = ", rc);
                PPT_SET_MSG_RC_KEY( strObjPerson_PrivilegeCheckForTACertify_out,
                                    MSG_NOT_FOUND_EQP, RC_NOT_FOUND_EQP,
                                    strObjPerson_PrivilegeCheckForTACertify_in.equipmentID.identifier );
                return (rc);
            }
            //INN-R170008-01 Add start
            if(CIMFWStrLen(strEquipment_getTypeDR_out.equipmentType) > 0)
            {
            //INN-R170008-01 Add end
                // prepare input parameter for get EqpTpyes's uData
                pptUserDataInqInParm__101 strUserDataInqInParm1;
                strUserDataInqInParm1.className = CIMFWStrDup(SP_ClassName_PosCode);
                strUserDataInqInParm1.strHashedInfoSeq.length(2);
                strUserDataInqInParm1.strHashedInfoSeq[0].hashKey = CIMFWStrDup(SP_HashData_CODE_ID);
                strUserDataInqInParm1.strHashedInfoSeq[0].hashData = strEquipment_getTypeDR_out.equipmentType;
                strUserDataInqInParm1.strHashedInfoSeq[1].hashKey = CIMFWStrDup(SP_HashData_CATEGORY_ID);
                strUserDataInqInParm1.strHashedInfoSeq[1].hashData = CIMFWStrDup(SP_CATEGORY_EQUIPMENTTYPE);
                strUserDataInqInParm1.userDataOriginator = CIMFWStrDup(SP_USERDATA_ORIG_SM);

                // Get Eqp Type's stringifiedObjectReference
                objObject_Get_out strobjObject_Get_out2;
                objObject_Get_in strobjObject_Get_in2;

                strobjObject_Get_in2.className = strUserDataInqInParm1.className;
                strobjObject_Get_in2.strHashedInfoSeq = strUserDataInqInParm1.strHashedInfoSeq;

                rc = object_Get( strobjObject_Get_out2,
                                 strObjCommonIn,
                                 strobjObject_Get_in2 );
                                 
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "object_Get() rc != RC_OK");
                    strObjPerson_PrivilegeCheckForTACertify_out.strResult = strobjObject_Get_out2.strResult;
                    return rc;
                }
                
                // Get EqpTye's all uData
                objObject_UserData_Get_out strObject_UserData_Get_out1;
                rc = object_userData_Get__101( strObject_UserData_Get_out1,
                                               strObjCommonIn,
                                               strUserDataInqInParm1,
                                               strobjObject_Get_out2.stringifiedObjectReference );

                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "object_userData_Get() rc != RC_OK");
                    strObjPerson_PrivilegeCheckForTACertify_out.strResult = strObject_UserData_Get_out1.strResult;
                    return rc;
                }

                // Call cs_person_SkillList_GetDR() to Get User's skill list
                csObjPerson_SkillList_GetDR_out strObjPerson_SkillList_GetDR_out;
                csObjPerson_SkillList_GetDR_in strObjPerson_SkillList_GetDR_in;

                strObjPerson_SkillList_GetDR_in.userID = strObjPerson_PrivilegeCheckForTACertify_in.userID;

                rc = cs_person_SkillList_GetDR( strObjPerson_SkillList_GetDR_out,
                                                strObjCommonIn,
                                                strObjPerson_SkillList_GetDR_in );

                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V2("", "cs_person_SkillList_GetDR() rc != RC_OK. ", rc);
                    strObjPerson_PrivilegeCheckForTACertify_out.strResult = strObjPerson_SkillList_GetDR_out.strResult;
                    return(rc);
                }
                
                PPT_METHODTRACE_V2("", "strObject_UserData_Get_out1.strUserDataSeq.length()",strObject_UserData_Get_out1.strUserDataSeq.length());
                for (CORBA::Long i = 0; i < strObject_UserData_Get_out1.strUserDataSeq.length(); i++)
                {
                    CORBA::Boolean bFindSkill = FALSE;
                    PPT_METHODTRACE_V2("","Value Length:",CIMFWStrLen(strObject_UserData_Get_out1.strUserDataSeq[i].value));
                    if (CIMFWStrLen(strObject_UserData_Get_out1.strUserDataSeq[i].value) == 0)
                    {
                        continue;
                    }
                           
                    CORBA::Long nSkillLen = strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo.length();
                    for (CORBA::Long j = 0; j < nSkillLen; j++)
                    {
                        PPT_METHODTRACE_V2("","value",strObject_UserData_Get_out1.strUserDataSeq[i].value);
                        PPT_METHODTRACE_V2("","skillID",strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo[j].skillID);
                        if (CIMFWStrCmp(strObject_UserData_Get_out1.strUserDataSeq[i].value, strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo[j].skillID) == 0)
                        {
                            PPT_METHODTRACE_V1("","Enter 181 line");
                            // Check TA Certify Date expire or not 
                            TimeStampImpl triggerTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
                            //INN-R170008-01 Add start
                            TimeStampImpl certifyTimeStame(strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo[j].certifiedDate);
                            CORBA::String_var expireTimeStame;
                            PPT_METHODTRACE_V2("", "certifyTimeStame=",certifyTimeStame);
                            if(nExpDuration > 0)
                            {
                                PPT_METHODTRACE_V2("", "nExpDuration=",nExpDuration);
                                DurationImpl aDuration, aTempDuration;
                                try
                                {
                                    aTempDuration = aDuration->days_hours_minutes_seconds_milliseconds(nExpDuration,
                                                                                                       0,
                                                                                                       0,
                                                                                                       0,
                                                                                                       0);
                                }
                                CATCH_AND_RAISE_EXCEPTIONS( Duration::days_hours_minutes_seconds_milliseconds )

                                PPT_METHODTRACE_V2("", "aTempDuration =" ,aTempDuration );

                                try
                                {
                                    expireTimeStame = certifyTimeStame.addDuration(aTempDuration);
                                }
                                CATCH_AND_RAISE_EXCEPTIONS( TimeStamp::addDuration )
                                PPT_METHODTRACE_V2("", "expireTimeStame=",expireTimeStame);
                            }    
                            //INN-R170008-01 Add end
                            //INN-R170008-01 if ( TRUE == triggerTimeStamp.isGreaterThan(strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo[j].certifiedDate) )
                                if ( TRUE == triggerTimeStamp.isGreaterThan(expireTimeStame) )//INN-R170008-01
                            {
                                //INN-R170008-01 PPT_METHODTRACE_V1("", "triggerTimeStamp.isGreaterThan is False!");
                                PPT_METHODTRACE_V1("", "triggerTimeStamp.isGreaterThan is TRUE!");//INN-R170008-01
                                SET_MSG_RC(strObjPerson_PrivilegeCheckForTACertify_out,MSG_NOT_AUTH_EQP,RC_NOT_AUTH_EQP)
                                return RC_NOT_AUTH_EQP;
                            }
                            bFindSkill = TRUE;
                            break;
                        }
                    }

                    if (bFindSkill == FALSE)
                    {
                        SET_MSG_RC(strObjPerson_PrivilegeCheckForTACertify_out,MSG_NOT_AUTH_EQP,RC_NOT_AUTH_EQP)
                        return RC_NOT_AUTH_EQP;  
                    }    
                }
            //INN-R170008-01 Add start
            }
            else
            {
                PPT_METHODTRACE_V1("", "bCertifyFlag is true , but equipment type is blank...");
                PPT_METHODTRACE_V1("", "No need to check.....");
            }
            //INN-R170008-01 Add end
        }
        
        SET_MSG_RC(strObjPerson_PrivilegeCheckForTACertify_out, MSG_OK, RC_OK);
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strObjPerson_PrivilegeCheckForTACertify_out, cs_person_PrivilegeCheckForTACertify, methodName)
}
