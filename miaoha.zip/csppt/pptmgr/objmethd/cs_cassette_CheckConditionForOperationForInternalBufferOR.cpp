#ifndef lint
static char *sccsid =  "@(#) 1.4 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_CheckConditionForOperationForInternalBuffer.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 10/26/07 13:34:44 [ 10/26/07 13:34:46 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cs_cassette_CheckConditionForOperationForInternalBufferOR.cpp
//

#include "cs_pptmgr.hpp"

#include "plot.hh"
#include "pcas.hh"
#include "ppcope.hh"
#include "pmc.hh"
#include "plcrc.hh"
#include "pmcrc.hh"
#include "pprsp.hh"


//[Object Function Name]: long   cassette_CheckConditionForOperationForInternalBuffer
//
// Date        Level        Author         Note
// ----------  -----------  -------------  -------------------------------------------
// 2001/06/26  D4000015     K.Matsuei      Internal Buffuer Contorl.
// 2001/08/20  P4000099     K.Matsuei      Invalid obj-method filename.
// 2001/08/22  D4000028     K.Matsuei      Add new logic for Non-WIP Carrier Xfer.
// 2001/08/23  D4000015     O.Sugiyama     Can not use loadPortID
// 2001/08/27  D4000015     O.Sugiyama     Remove loadSequenceNumber check
// 2001/08/29  D4000015(1)  K.Matsuei      change logic.
// 2001/08/31  D4000015(2)  K.Matsuei      add logic.
// 2001/09/01  D4000015(3)  K.Matsuei      add logic.
// 2001/09/03  D4000015(4)  K.Matsuei      add logic. CassetteDelivery of operation.
// 2001/09/03  D4000015(5)  K.Matsuei      change logic. EmptyCassette Count Logic.
// 2001/09/18  D4000015(6)  K.Matsuei      change logic. UnloadPortReserve Check.
// 2001/09/19  P4000213     S.Tokumasu     change NPW transfer logic.
// 2001/09/20  D4000015(7)  K.Matsuei      add logic. The check when Cassette is already on Port.
// 2001/09/26  P4000259     K.Matsuei      Error Message is invalid.
// 2002/02/01  D4100105     K.Matsuei      Cassette's XferStatus CheckLogic is Incorrect in StartLotsReservation.
// 2002/10/02  D4200122     K.Matsuei      Measure from which empty ControlJob is made by OpeStart.
// 2002/10/28  P4200230     K.Matsuei      There is a case where it fails in StartReserve from InternalBuffer.
//                                         D4100105 --> P4100105.
// 2002/10/28  P4200290     H.Adachi       Add Start Cassette and Start Lot Combination Check.
// 2002/11/22  P4200398     M.Kase         Modify check logic of recipe parameter value for OpeStart.
// 2003/02/05  P4200533     H.Adachi       Add ProcessMonitorLot Quantity Check
// 2003/03/13  P5000003     H.Adachi       MM Server Down at narrow to PosMachineObject.
// 2003/05/09  P5000043     H.Adachi       Fix StartReserve and OpeStart Fail.
// 2003/06/10  P5000075     H.Adachi       Fix StartReserve and OpeStart Fail for CassetteExchange type EQP.
// 2003/08/15  D5000194     K.Matsuei      ReRoute of Xfer is supported by CassetteDelivery.
// 2003/10/09  P5100030     K.Matsuei      Limit of Integer type of RecipeParameter is not checked.
// 2003/10/17  D5100053     T.Hikari       ProcessMonitoring By ProductionLot.
// 2005/08/31  D6000415     K.Kido         Call findRecipeParametersForSubLotType() to get correct Recipe Parameter taken into account for Chamber Machine State.
// 2005/11/14  D7000074     F.Masada       Multiple Recipe Type is supported for Internal Buffer EQP.
// 2005/12/07  D7000042     K.Kido         Get Machine Recipe by findMachineRecipeForSubLotType for findRecipeParametersForSubLotType.
// 2006/09/27  P7000426     K.Matsuei      Add shelf reservation check logic for current equipment (EI case).
// 2006/11/28  D8000024     H.Mutoh        When FPC overwrite the machineRecipe, skip the logic of machineRecipe getting from PO.
//                                           if FPC overwrite the recipeParameter, the parameter check is taken place with the FPC's parameter.
// 2007/02/23  P8000119     K.Matsuei      OpeStartCancel and OpeComp cannot perform.
// 2007/06/12  D9000005     H.Hotta        WaferSorter automation support.
// 2007/10/15  D9000001     K.Matsuei      64bit support.
// 2008/12/08  DSIV00000518   K.Matsuei    ReRoute of BO is permitted by Auto3.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009/10/27 DSIV00001443 S.Kawabe       Improve how to get the Machine Recipe
// 2012/12/18 PSN000062207 GC.Wang        Error message fix for Start Lots Reservation
// 2016/07/13 DSN000101569 K.Yamaoku      Durable Sub Status Control
//
// Innotron Modification history:
// Date       DCR/PCR No   Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/15 INN-R170003  Jun Zhang      New Transfer State PI/PO.
//
//[Function Description]:
//  Check cassette's condition for StartReservation, OpeStart, FlowBatching, NPWXfer.
//  The following conditions are checked for each specified operation.
//
//   ***Omission indication
//   ------------------------
//   StartReserve ........[R]
//   OpeStart ............[S]
//   FlowBatch ...........[F]
//   NPWXfer .............[N]
//
// ***[R][S][N]***********************************************************************
// 1. loadSequenceNumber of strStartCassette must be a sequence.
//
// ***[R][S][F][N]********************************************************************
// 2. Cassette Condition must be as the following.
//
//                |         |    MultiLot     |   Xfer   |   Xfer   | Dispatch |
//                | CtrlJob |     Type        |  State   | Reserved | Reserved |
//   ============================================================================
//   StartReserve | AllSame | SL-SR/ML-MR(*1) |   (*2)   |   (*2)   |   FALSE  |
//   OpeStart     |   NULL  | SL-SR/ML-MR(*1) |    EI    | no-check | no-check |
//   FlowBatch    |   NULL  | SL-SR/ML-MR(*1) | SI/BI/MI |   FALSE  |   FALSE  |
//   NPWXfer      |   NULL  |   no-check      | SI/BI/MI |   FALSE  |   FALSE  |
//
//  About (*1),
//    If LoadPurposeType is EmptyCassette case, this check is passed.
//
//  About (*2), the following conditions must be met.
//
//  - The cassette must not have Load reservation of other equipments.  //P7000426
//
//                        Eqp's                     ||       Cassette's
//    accessMode |        shelf       | EqpToEqpFlg || XferState | XferReserved
//   ============+==================================||===========|===============
//      MANUAL   |       no-check     |   no-check  || no-check  |   no-check
//       AUTO    |       no-check     |   no-check  || SI/MI/BI  |    FALSE
//       AUTO    | Cas Exist In Shelf |      ON     ||    EI     |    FALSE
//
// ***[R][S][F][N]********************************************************************
// 3. cassetteState must be "Available" or "InUse".
//
// ***[R][N]**************************************************************************
// 4. Shelf shouldn't have reservedUnloadPortID.
//
// ***[N]*****************************************************************************
// 5. Must not have processLot and EmptyCassette and processMonitor.
//
// ***[R][N]**************************************************************************
// 6. All StartCassettes should go into Shelf.
//
// ***[R][S][F][N]********************************************************************
// 7. minBatchSize >= processCassetteCount <= maxBatchSize.
//
// ***[R][S][F][N]********************************************************************
// 8. Check EmptyCassetteCount of StartCassette. [R][S][F][N]
//
//   ***Omission indication
//   ---------------------------------------
//   cassetteExchangeFlag ..............[CE]
//   monitorCreationFlag ...............[MC]
//   LogicalRecipe->MonitorProduct .....[MP]
//
//    Condition of [CE] , [MC] , [MP]    |   emptyCassetteCount
//   ================================================================
//   [CE]:TRUE  [MC]:TRUE                |  processCassetteCount + 1
//   [CE]:TRUE  [MC]:FALSE               |  processCassetteCount
//   [CE]:FALSE [MC]:TRUE   [MP]:NULL    |  1
//   [CE]:FALSE [MC]:TRUE   [MP]:NotNULL |  0
//   [CE]:FALSE [MC]:FALSE               |  0
//
// ***[R][S]**************************************************************************
// 9. eqp's multiRecipeCapability and recipeParameter.
//
//    the followings are not required to check for SP_Operation_NPWCarrierXfer in-param's.
//  - If equipment's multiRecipeCapability is Batch or Single-Recipe, all of startLots'
//    recipeParameter-set must be same.
//
// ***[R][S]**************************************************************************
// 10. The following input-parameters must be filled to call this object function.
//
//  - equipmentID
//  - operation
//  - strStartCassette[].cassetteID
//
//  From here, the followings are not required to fill for "FlowBatching" and "NPWCarrierXfer"
//  - strStartCassette[].strLotInCassette[].recipeParameterChangeType
//  - strStartCassette[].strLotInCassette[].strLotWafer[].strStartRecipeParameter[].parameterName
//  - strStartCassette[].strLotInCassette[].strLotWafer[].strStartRecipeParameter[].parameterValue
//
// ***[R][S]**************************************************************************
// 11. The number of Lot that MonitorLotFlag is TRUE should be 0 or 1.
//     And, the number (OperationStartFlag = TRUE) of Lot except for this Lot
//     should be beyond 1 with 1 the number of Lot that MonitorLotFlag is TRUE.
//
// ***[R][S][N]***********************************************************************
// 12. Check whether input cassette has SorterJob or not.
//     When the cassette has SorterJob, [R] and [S] are prevented.
//     If operation is [N], then the Sorter Job validity is checked.
//
//
//[Input Parameters]:
//  in  pptObjCommonIn              strObjCommonIn;
//  in  objectIdentifier            equipmentID;
//  in  sequence <pptStartCassette> strStartCassette;
//  in  string                      operation;
//
//[Output Parameters]:
//  out objCassette_CheckConditionForOperationForInternalBuffer_out   strCassette_CheckConditionForOperationForInternalBuffer_out;
//
//  typedef objCassette_CheckConditionForOperation_out  objCassette_CheckConditionForOperationForInternalBuffer_out
//
//  typedef struct objCassette_CheckConditionForOperation_out_struct {
//      pptRetCode                  strResult;
//  } objCassette_CheckConditionForOperation_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                                   MSG_OK
//  RC_ALREADY_DISPATCH_RESVED_CST          MSG_ALREADY_DISPATCH_RESVED_CST
//  RC_CAST_CTRLJOB_MIX                     MSG_CAST_CTRLJOB_MIX
//  RC_CAST_CTRLJOBID_FILLED                MSG_CAST_CTRLJOBID_FILLED
//  RC_CAST_EQP_CONDITION_ERROR             MSG_CAST_EQP_CONDITION_ERROR
//  RC_CST_NOT_IN_LOADER                    MSG_CST_NOT_IN_LOADER
//  RC_EXIST_UNLOAD_PORTID                  MSG_EXIST_UNLOAD_PORTID
//  RC_INVALID_CAST_STAT                    MSG_INVALID_CAST_STAT
//  RC_INVALID_CAST_XFERSTAT                MSG_INVALID_CAST_XFERSTAT
//  RC_INVALID_EMPTY_COUNT                  MSG_INVALID_EMPTY_COUNT
//  RC_INVALID_INPUT_CAST_COUNT             MSG_INVALID_INPUT_CAST_COUNT
//  RC_INVALID_INPUT_LOT_COUNT              MSG_INVALID_INPUT_LOT_COUNT
//  RC_INVALID_LOADING_SEQ                  MSG_INVALID_LOADING_SEQ
//  RC_INVALID_RPARM_CHANGETYPE             MSG_INVALID_RPARM_CHANGETYPE
//  RC_INVALID_PARAMETER_VALUE_RANGE        MSG_INVALID_PARAMETER_VALUE_RANGE
//  RC_INVALID_PARAMETERVALUE_MUST_BE_NULL  MSG_INVALID_PARAMETERVALUE_MUST_BE_NULL
//  RC_INVALID_PROCMONITOR_COUNT            MSG_INVALID_PROCMONITOR_COUNT
//  RC_INVALID_WAFER_CNT                    MSG_INVALID_WAFER_CNT
//  RC_NOT_SAME_RPARM_INFO                  MSG_NOT_SAME_RPARM_INFO
//  RC_NOT_SPACE_EQP_SELF                   MSG_NOT_SPACE_EQP_SELF
//  RC_MACHINE_TYPE_NOT_INTERNALBUFFER      MSG_MACHINE_TYPE_NOT_INTERNALBUFFER
//
//[Pseudo Code]:
//

CORBA::Long CS_PPTManager_i::cassette_CheckConditionForOperationForInternalBuffer(
        objCassette_CheckConditionForOperationForInternalBuffer_out&    strCassette_CheckConditionForOperationForInternalBuffer_out,
        const pptObjCommonIn&                                           strObjCommonIn,
        const objectIdentifier&                                         equipmentID,
        const pptStartCassetteSequence&                                 strStartCassette,
        const char*                                                     operation )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cassette_CheckConditionForOperationForInternalBuffer");

        PPT_METHODTRACE_V2("","InParam [equipmentID]", equipmentID.identifier);
        PPT_METHODTRACE_V2("","InParam [  operation]", operation);

        /*----------------*/
        /*                */
        /*   Initialize   */
        /*                */
        /*----------------*/
        CORBA::Long rc = RC_OK;
        CORBA::Long i, j, k, l, m;

        CORBA::Long searchCondition = 0;                                                                   //DSIV00001443
        CORBA::String_var searchCondition_var = CIMFWStrDup(getenv("SP_ENTITY_INHIBIT_SEARCH_CONDITION")); //DSIV00001443
        if( CIMFWStrLen(searchCondition_var) > 0 )                                                         //DSIV00001443
        {                                                                                                  //DSIV00001443
            searchCondition = atoi(searchCondition_var);                                                   //DSIV00001443
        }                                                                                                  //DSIV00001443

        /*-------------------------------------------------------------------------------------*/
        /*                                                                                     */
        /*   Check Condition of controlJobID, multiLotType, transferState, transferReserved,   */
        /*   dispatchState, and cassetteState for all cassettes                                */
        /*   dispatchState, cassetteState, and loadingSequenceNumber for all cassettes         */
        /*                                                                                     */
        /*-------------------------------------------------------------------------------------*/

        /*--------------------------*/
        /*   Get Equipment Object   */
        /*--------------------------*/
        PPT_METHODTRACE_V1("","Get Equipment Object");

        PosMachine_var aMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine,
                                         equipmentID,
                                         strCassette_CheckConditionForOperationForInternalBuffer_out,
                                         cassette_CheckConditionForOperationForInternalBuffer );

        /*-------------------------------------------*/
        /*   Get Equipment's MultiRecipeCapability   */
        /*-------------------------------------------*/
        PPT_METHODTRACE_V1("","Get Equipment's MultiRecipeCapability");

        CORBA::String_var multiRecipeCapability;
        try
        {
            multiRecipeCapability = aMachine->getMultipleRecipeCapability();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getMultipleRecipeCapability)
        PPT_METHODTRACE_V2("", "multiRecipeCapability", multiRecipeCapability);

//D4000015 start
        /*----------------------------------*/
        /*   Get Eqp Internal Buffer Info   */
        /*----------------------------------*/
        PPT_METHODTRACE_V1("", "call equipment_internalBufferInfo_Get()");
        objEquipment_internalBufferInfo_Get_out strEquipment_internalBufferInfo_Get_out;
        rc = equipment_internalBufferInfo_Get( strEquipment_internalBufferInfo_Get_out,
                                               strObjCommonIn,
                                               equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "##### RC_OK != equipment_internalBufferInfo_Get()");
            strCassette_CheckConditionForOperationForInternalBuffer_out.strResult = strEquipment_internalBufferInfo_Get_out.strResult;
            return rc;
        }
//D4000015 end

//D4000015        /*-----------------------------------------*/
//D4000015        /*   Get Equipment's Operation Mode Info   */
//D4000015        /*-----------------------------------------*/
//D4000015        PPT_METHODTRACE_V1("","/*-----------------------------------------*/");
//D4000015        PPT_METHODTRACE_V1("","/*   Get Equipment's Operation Mode Info   */");
//D4000015        PPT_METHODTRACE_V1("","/*-----------------------------------------*/");
//D4000015
//D4000015        if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart)
//D4000015          || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation)
//D4000015          || 0 == CIMFWStrCmp(operation, SP_Operation_NPWCarrierXfer) ) //D4000028
//D4000015        {
//D4000015            PPT_METHODTRACE_V1("","operation == [OpeStart] or [StartReservation]");
//D4000015
//D4000015            objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
//D4000015            rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
//D4000015                                                        strObjCommonIn,
//D4000015                                                        equipmentID,
//D4000015                                                        strStartCassette[0].loadPortID );
//D4000015
//D4000015            if ( rc != RC_OK )
//D4000015            {
//D4000015                PPT_METHODTRACE_V1("","##### RC_OK != portResource_currentOperationMode_Get()");
//D4000015                strCassette_CheckConditionForOperationForInternalBuffer_out.strResult = strPortResource_currentOperationMode_Get_out.strResult;
//D4000015                return rc;
//D4000015            }
//D4000015        }
//D4000015        else
//D4000015        {
//D4000015            PPT_METHODTRACE_V1("", "operation != [OpeStart] && operation != [StartReservation]")
//D4000015        }


        /******************************************************************************************/
        /*                                                                                        */
        /*     Check Cassette Condition                                                           */
        /*                                                                                        */
        /******************************************************************************************/
        PPT_METHODTRACE_V1("", "");
        PPT_METHODTRACE_V1("", "//***************************************************************");
        PPT_METHODTRACE_V1("", "//  Check Cassette Condition");
        PPT_METHODTRACE_V1("", "//***************************************************************");

        objectIdentifier saveControlJobID;
        CORBA::Long cjCastCnt;

        CORBA::Long lenCassette = strStartCassette.length();
        PPT_METHODTRACE_V2("","strStartCassette.length", lenCassette);

        for ( i=0; i < lenCassette; i++ )
        {
            PPT_METHODTRACE_V3("","strStartCassette[i].cassetteID", i, strStartCassette[i].cassetteID.identifier);

//D9000005 add start
            /*-------------------------------*/
            /*   Check SorterJob existence   */
            /*-------------------------------*/
            if( 0 == CIMFWStrCmp( operation, SP_Operation_NPWCarrierXfer )  ||
                0 == CIMFWStrCmp( operation, SP_Operation_StartReservation) ||
                0 == CIMFWStrCmp( operation, SP_Operation_OpeStart))
            {
                PPT_METHODTRACE_V1("", "Operation is NPWCarrierXfer or StartReservation or OpeStart." );

                objectIdentifierSequence dummyIDs;
                pptEquipmentLoadPortAttribute equipmentPortAttribute;
                equipmentPortAttribute.strCassetteLoadPortSeq.length(1);
                equipmentPortAttribute.strCassetteLoadPortSeq[0].portID     = strStartCassette[i].loadPortID;
                equipmentPortAttribute.strCassetteLoadPortSeq[0].cassetteID = strStartCassette[i].cassetteID;
                equipmentPortAttribute.equipmentID                          = equipmentID;

                objWaferSorter_sorterJob_CheckForOperation_out strWaferSorter_sorterJob_CheckForOperation_out;
                objWaferSorter_sorterJob_CheckForOperation_in  strWaferSorter_sorterJob_CheckForOperation_in;
                strWaferSorter_sorterJob_CheckForOperation_in.strEquipmentLoadPortAttribute = equipmentPortAttribute;
                strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs.length(1);
                strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs[0]                = strStartCassette[i].cassetteID;
                strWaferSorter_sorterJob_CheckForOperation_in.lotIDs                        = dummyIDs;
                strWaferSorter_sorterJob_CheckForOperation_in.operation                     = operation;

                rc = waferSorter_sorterJob_CheckForOperation( strWaferSorter_sorterJob_CheckForOperation_out,
                                                              strObjCommonIn,
                                                              strWaferSorter_sorterJob_CheckForOperation_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "waferSorter_sorterJob_CheckForOperation() != RC_OK" );
                    strCassette_CheckConditionForOperationForInternalBuffer_out.strResult = strWaferSorter_sorterJob_CheckForOperation_out.strResult;
                    return( rc );
                }
            }
//D9000005 add end

//D4000015 Remove loadSequenceNumber check
//D4000015            /*------------------------------------------*/
//D4000015            /*   Check Start Cassette's Loading Order   */
//D4000015            /*------------------------------------------*/
//D4000015            if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart)
//D4000015              || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation)
//D4000015              || 0 == CIMFWStrCmp(operation, SP_Operation_NPWCarrierXfer) ) //D4000028
//D4000015            {
//D4000015                PPT_METHODTRACE_V1("", "operation == [OpeStart] || operation == [StartReservation]");
//D4000015
//D4000015                if ( strStartCassette[i].loadSequenceNumber != (i+1) )
//D4000015                {
//D4000015                    PPT_METHODTRACE_V2("", "##### strStartCassette[i].loadSequenceNumber != i+1", i);
//D4000015                    PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForOperationForInternalBuffer_out,
//D4000015                                        MSG_INVALID_LOADING_SEQ,
//D4000015                                        RC_INVALID_LOADING_SEQ,
//D4000015                                        strStartCassette[i].cassetteID.identifier );
//D4000015
//D4000015                    return RC_INVALID_LOADING_SEQ;
//D4000015                }
//D4000015            }

            /*-------------------------*/
            /*   Get Cassette Object   */
            /*-------------------------*/
            PosCassette_var aCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                                   strStartCassette[i].cassetteID,
                                                   strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                   cassette_CheckConditionForOperationForInternalBuffer );

            /*--------------------------------*/
            /*   Get and Check ControlJobID   */
            /*--------------------------------*/
            PPT_METHODTRACE_V1("", "Get and Check ControlJobID");
            PosControlJob_var aControlJob;
            try
            {
                aControlJob = aCassette->getControlJob();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)

            if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart) )
            {
                PPT_METHODTRACE_V2("","operation == [OpeStart]", operation);

                if ( i == 0 )
                {
                    PPT_METHODTRACE_V1("","i == 0");

                    PPT_SET_OBJECT_IDENTIFIER( saveControlJobID,
                                               aControlJob,
                                               strCassette_CheckConditionForOperationForInternalBuffer_out,
                                               cassette_CheckConditionForOperationForInternalBuffer,
                                               PosControlJob );
                }
                else
                {
                    PPT_METHODTRACE_V1("","i != 0");

                    objectIdentifier castControlJobID;
                    PPT_SET_OBJECT_IDENTIFIER( castControlJobID,
                                               aControlJob,
                                               strCassette_CheckConditionForOperationForInternalBuffer_out,
                                               cassette_CheckConditionForOperationForInternalBuffer,
                                               PosControlJob );

                    if ( 0 != CIMFWStrCmp(castControlJobID.identifier, saveControlJobID.identifier) )
                    {
                        PPT_METHODTRACE_V1("","##### castControlJobID != saveControlJobID");
                        SET_MSG_RC( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                    MSG_CAST_CTRLJOB_MIX,
                                    RC_CAST_CTRLJOB_MIX );

                        return RC_CAST_CTRLJOB_MIX;
                    }
                }
            }
            else
            {
                PPT_METHODTRACE_V2("","operation != [OpeStart]", operation);

                if ( ! CORBA::is_nil(aControlJob) )
                {
                    PPT_METHODTRACE_V1("","##### aControlJob is not nil");
                    SET_MSG_RC( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                MSG_CAST_CTRLJOBID_FILLED,
                                RC_CAST_CTRLJOBID_FILLED );

                    return RC_CAST_CTRLJOBID_FILLED;
                }
            }

            /*---------------------------------*/
            /*   Get Cassette's MultiLotType   */
            /*---------------------------------*/
            PPT_METHODTRACE_V1("","Get Cassette's MultiLotType");

//D4000028 start
            if ( 0 == CIMFWStrCmp(operation, SP_Operation_NPWCarrierXfer) )
            {
                //-----------------------------------------------//
                //   For NPWCarrierXfer, MultiRecipeCapability   //
                //   VS MultiLotType is not required             //
                //-----------------------------------------------//
                PPT_METHODTRACE_V1("","operation == SP_Operation_NPWCarrierXfer");
                PPT_METHODTRACE_V1("","For NPWCarrierXfer, MultiRecipeCapability VS MultiLotType is not required");
                rc = RC_OK;
            }
            else
            {
//D4000028 end
                PPT_METHODTRACE_V1("","operation != SP_Operation_NPWCarrierXfer");

                CORBA::String_var multiLotType;
                try
                {
                    multiLotType = aCassette->getMultiLotType();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getMultiLotType)
                PPT_METHODTRACE_V2("","multiLotType", multiLotType);

                /*-------------------------------------------------*/
                /*   Check MultiRecipeCapability VS MultiLotType   */
                /*-------------------------------------------------*/
                PPT_METHODTRACE_V1("","/*-------------------------------------------------*/");
                PPT_METHODTRACE_V1("","/*   Check MultiRecipeCapability VS MultiLotType   */");
                PPT_METHODTRACE_V1("","/*-------------------------------------------------*/");

//D4000015(1) start
                if ( 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) )
                {
                    PPT_METHODTRACE_V1("","strStartCassette[i].loadPurposeType == [EmptyCassette] is OK");
                    rc = RC_OK;
                }
                else if ( 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_MultipleRecipe) )
                {
                    PPT_METHODTRACE_V1("","multiRecipeCapability == [MultipleRecipe]");
                    rc = RC_OK;         //D7000074
                //D7000074    PPT_METHODTRACE_V1("","##### return RC_CAST_EQP_CONDITION_ERROR!!");
                //D7000074    SET_MSG_RC( strCassette_CheckConditionForOperationForInternalBuffer_out,        //D4000015(1)
                //D7000074                MSG_CAST_EQP_CONDITION_ERROR,                                       //D4000015(1)
                //D7000074                RC_CAST_EQP_CONDITION_ERROR );                                      //D4000015(1)
                //D7000074    return RC_CAST_EQP_CONDITION_ERROR;                                             //D4000015(1)
                }
                else if ( 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_SingleRecipe) )
                {
                    PPT_METHODTRACE_V1("","multiRecipeCapability == [SingleRecipe] is OK");
                    rc = RC_OK;
                }
                else if ( 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_Batch) )
                {
                    PPT_METHODTRACE_V1("","multiRecipeCapability ==[Batch]");

                    if ( 0 == CIMFWStrCmp(multiLotType, SP_Cas_MultiLotType_SingleLotSingleRecipe)
                      || 0 == CIMFWStrCmp(multiLotType, SP_Cas_MultiLotType_MultiLotSingleRecipe) )
                    {
                        PPT_METHODTRACE_V1("","multiLotType = [SL-SR] or [ML-SR] is OK");
                        rc = RC_OK;
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","##### return RC_CAST_EQP_CONDITION_ERROR!!");
                        SET_MSG_RC( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                    MSG_CAST_EQP_CONDITION_ERROR,
                                    RC_CAST_EQP_CONDITION_ERROR );

                        return RC_CAST_EQP_CONDITION_ERROR;
                    }
                }
                else
                {
                    PPT_METHODTRACE_V1("","No Process <Check MultiRecipeCapability VS MultiLotType>");
                }
//D4000015(1) end
            } //D4000028

            /*--------------------------------------*/
            /*   Check Cassette's Transfer Status   */
            /*--------------------------------------*/

            /*-----------------------*/
            /*   Get TransferState   */
            /*-----------------------*/
            PPT_METHODTRACE_V1("","Get TransferState");
            CORBA::String_var transferState;
            try
            {
                transferState = aCassette->getTransportState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTransportState)

            /*------------------------------*/
            /*   Get TransferReserveState   */
            /*------------------------------*/
            PPT_METHODTRACE_V1("","Get TransferReserveState");
            CORBA::Boolean transferReserved;
            try
            {
                transferReserved = aCassette->isReserved();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isReserved)

            PPT_METHODTRACE_V2("", "operation ---------->", operation);
            PPT_METHODTRACE_V2("", "transferState ------>", transferState);
//D9000001            PPT_METHODTRACE_V2("", "transferReserved --->", (long)transferReserved);
            PPT_METHODTRACE_V2("", "transferReserved --->", (int)transferReserved); //D9000001

            /*===== for OpeStart =====*/
            if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart) )
            {
                PPT_METHODTRACE_V1("", "/*===== for OpeStart =====*/")
                PPT_METHODTRACE_V1("", "operation = [OpeStart]")

                if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn) )
                {
                    PPT_METHODTRACE_V1("","transferState == [EI] is OK");
                    rc = RC_OK;
                }
                else
                {
                    PPT_METHODTRACE_V1("","##### return RC_INVALID_CAST_XFERSTAT!!");
                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                         MSG_INVALID_CAST_XFERSTAT,
                                         RC_INVALID_CAST_XFERSTAT,
                                         transferState,
                                         strStartCassette[i].cassetteID.identifier );

                    return RC_INVALID_CAST_XFERSTAT;
                }
            }
            /*===== for FlowBatching =====*/
            else if ( 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatching) )
            {
                PPT_METHODTRACE_V1("", "/*===== for FlowBatching =====*/")
                PPT_METHODTRACE_V1("", "operation = [FlowBatching]")

                if ((0 == CIMFWStrCmp(transferState, SP_TransState_StationIn)
                  || 0 == CIMFWStrCmp(transferState, SP_TransState_BayIn)
                  || 0 == CIMFWStrCmp(transferState, SP_TransState_ManualIn))
                  && (transferReserved == FALSE) )
                {
                    PPT_METHODTRACE_V1("","transferState = [SI] or [BI] or [MI] is OK");
                    rc = RC_OK;
                }
                else
                {
                    PPT_METHODTRACE_V1("","##### return RC_INVALID_CAST_XFERSTAT");
                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                         MSG_INVALID_CAST_XFERSTAT,
                                         RC_INVALID_CAST_XFERSTAT,
                                         transferState,
                                         strStartCassette[i].cassetteID.identifier );

                    return RC_INVALID_CAST_XFERSTAT;
                }
            }
//D4000028 start
//P4000213  /*===== for NPWCarrierXfer =====*/
//P4000213  else if ( 0 == CIMFWStrCmp(operation, SP_Operation_NPWCarrierXfer) )
//P4000213  {
//P4000213      PPT_METHODTRACE_V1("", "/*===== for NPWCarrierXfer =====*/")
//P4000213      PPT_METHODTRACE_V1("", "operation = [NPWCarrierXfer]")
//P4000213
//P4000213      if ((0 == CIMFWStrCmp(transferState, SP_TransState_StationIn)
//P4000213        || 0 == CIMFWStrCmp(transferState, SP_TransState_BayIn)
//P4000213        || 0 == CIMFWStrCmp(transferState, SP_TransState_ManualIn))
//P4000213        && (transferReserved == FALSE) )
//P4000213      {
//P4000213          PPT_METHODTRACE_V1("","transferState = [SI] or [BI] or [MI] is OK");
//P4000213          rc = RC_OK;
//P4000213      }
//P4000213      else
//P4000213      {
//P4000213          PPT_METHODTRACE_V1("","##### return RC_INVALID_CAST_XFERSTAT");
//P4000213          PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
//P4000213                               MSG_INVALID_CAST_XFERSTAT,
//P4000213                               RC_INVALID_CAST_XFERSTAT,
//P4000213                               transferState,
//P4000213                               strStartCassette[i].cassetteID.identifier );
//P4000213
//P4000213          return RC_INVALID_CAST_XFERSTAT;
//P4000213      }
//P4000213  }
//D4000028 end
            /*===== for StartReservation =====*/
            else if ( 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation)
                   || 0 == CIMFWStrCmp(operation, SP_Operation_CassetteDelivery)    //D4000015(4)
                   || 0 == CIMFWStrCmp(operation, SP_Operation_NPWCarrierXfer)   )  //P4000213
            {
                PPT_METHODTRACE_V1("", "/*===== for StartReservation =====*/")
                PPT_METHODTRACE_V1("", "operation = [StartReservation] or [CassetteDelivery]")

                objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
                rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
                                                            strObjCommonIn,
                                                            equipmentID,
                                                            strStartCassette[i].loadPortID );

//P4100105 start
                pptEqpPortStatus strOrgEqpPortStatus;
                PosMachine_var aOrgMachine;

//INN-R170003   if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn) )
                if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn) ||  //INN-R170003
                     0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentOut) )  //INN-R170003
                {
                    /*-------------------------------*/
                    /*   Get Originator Eqp's Info   */
                    /*-------------------------------*/

                    /*--------------------------------*/
                    /*   Get Originator EquipmentID   */
                    /*--------------------------------*/
                    PPT_METHODTRACE_V1("","Get Originator EquipmentID");

                    //P5000003 Add Start
                    objectIdentifier orgEquipmentID;

                    Machine_var aMachine;
                    try
                    {
                        aMachine = aCassette->currentAssignedMachine();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::currentAssignedMachine)

                    if ( TRUE != CORBA::is_nil(aMachine) )
                    {
                        CORBA::Boolean isStorageBool = FALSE;
                        try
                        {
                            isStorageBool = aMachine->isStorageMachine();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(Machine::isStorageMachine)

                        if ( isStorageBool != TRUE )
                        {
                            aOrgMachine = PosMachine::_narrow( aMachine );

                            PPT_SET_OBJECT_IDENTIFIER( orgEquipmentID,
                                                       aOrgMachine,
                                                       strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                       cassette_CheckConditionForOperationForInternalBuffer,
                                                       Machine );

                            PPT_METHODTRACE_V2( "", "isStorageBool is not TRUE: Equipment", orgEquipmentID.identifier );
                        }
                        else
                        {
                            PPT_METHODTRACE_V1( "", "isStorageBool is TRUE: Storage" );
                        }
                    }
                    else
                    {
                        PPT_METHODTRACE_V1( "", "aMachine is Nill" );
                    }

                    if ( TRUE == CORBA::is_nil( aOrgMachine ) )
                    {
                         PPT_METHODTRACE_V1( "", "aOrgMachine is Nil" );
                         PPT_SET_MSG_RC_KEY(strCassette_CheckConditionForOperationForInternalBuffer_out,
                                            MSG_NOT_FOUND_EQP, RC_NOT_FOUND_EQP, orgEquipmentID.identifier)

                         return RC_NOT_FOUND_EQP;
                    }
                    //P5000003 Add End

//P5000003                    Machine_var aMachine;
//P5000003                    try
//P5000003                    {
//P5000003                        aMachine = aCassette->currentAssignedMachine();
//P5000003                        aOrgMachine = PosMachine::_narrow( aMachine );
//P5000003                    }
//P5000003                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::currentAssignedMachine)
//P5000003
//P5000003                    objectIdentifier orgEquipmentID;
//P5000003                    PPT_SET_OBJECT_IDENTIFIER( orgEquipmentID,
//P5000003                                               aOrgMachine,
//P5000003                                               strCassette_CheckConditionForOperationForInternalBuffer_out,
//P5000003                                               cassette_CheckConditionForOperation,
//P5000003                                               PosMachine );

                    /*---------------------------------*/
                    /*   Get Cassette Info in OrgEqp   */
                    /*---------------------------------*/
                    PPT_METHODTRACE_V1("","Get Cassette Info in OrgEqp");
//P4200230 start
                    pptEqpPortInfo equipmentPortInfo;
                    CORBA::String_var equipmentCategory;
                    try
                    {
                        equipmentCategory = aOrgMachine->getCategory();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getCategory)
                    PPT_METHODTRACE_V2("","aOrgMachine->getCategory()", equipmentCategory);

                    if ( 0 == CIMFWStrCmp(equipmentCategory, SP_Mc_Category_InternalBuffer) )
                    {
                        PPT_METHODTRACE_V1("","equipmentCategory is [InternalBuffer]");
                        objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
                        rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out,
                                                                        strObjCommonIn,
                                                                        orgEquipmentID );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "equipment_portInfoForInternalBuffer_GetDR != RC_OK")
                            strCassette_CheckConditionForOperationForInternalBuffer_out.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
                            return( rc );
                        }
                        equipmentPortInfo = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo;

//P7000426 start
                        PPT_METHODTRACE_V1("", "call equipment_internalBufferInfo_Get() for assigned eqp");
                        objEquipment_internalBufferInfo_Get_out strAssienedIBEqpInfo;
                        rc = equipment_internalBufferInfo_Get( strAssienedIBEqpInfo, strObjCommonIn, orgEquipmentID );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "##### RC_OK != equipment_internalBufferInfo_Get()");
                            strCassette_CheckConditionForOperationForInternalBuffer_out.strResult = strAssienedIBEqpInfo.strResult;
                            return rc;
                        }

                        CORBA::Long lenBufCate = strAssienedIBEqpInfo.equipmentInternalBufferInfo.length();
                        PPT_METHODTRACE_V2("", "lenBufCate", lenBufCate );

                        for ( CORBA::Long iBuf=0; iBuf < lenBufCate; iBuf++ )
                        {
                            CORBA::Long lenShelf = strAssienedIBEqpInfo.equipmentInternalBufferInfo[iBuf].strShelfInBuffer.length();

                            for( CORBA::Long jShelf=0; jShelf < lenShelf; jShelf++ )
                            {
                                if ( 0 == CIMFWStrCmp(strStartCassette[i].cassetteID.identifier,
                                                      strAssienedIBEqpInfo.equipmentInternalBufferInfo[iBuf].strShelfInBuffer[jShelf].reservedCarrierID.identifier)
                                  && 0 < CIMFWStrLen(strAssienedIBEqpInfo.equipmentInternalBufferInfo[iBuf].strShelfInBuffer[jShelf].reservedLoadPortID.identifier) )
                                {
                                    PPT_METHODTRACE_V1("","return RC_INVALID_CAST_XFERSTAT");
                                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                         MSG_INVALID_CAST_XFERSTAT,
                                                         RC_INVALID_CAST_XFERSTAT,
                                                         transferState,
                                                         strStartCassette[i].cassetteID.identifier );
                                    return RC_INVALID_CAST_XFERSTAT;
                                }
                            } //end of jShelf
                        } //end of iBuf
//P7000426 end
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","equipmentCategory is not [InternalBuffer]");
//P4200230 end
                        objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
                        rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                                     strObjCommonIn,
                                                     orgEquipmentID );

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "equipment_portInfo_Get != RC_OK")
                            strCassette_CheckConditionForOperationForInternalBuffer_out.strResult = strEquipment_portInfo_Get_out.strResult;
                            return rc;
                        }
                        equipmentPortInfo = strEquipment_portInfo_Get_out.strEqpPortInfo;   //P4200230
                    }                                                                       //P4200230

                    /*--------------------------------------*/
                    /*   Find Assigned Port's portGroupID   */
                    /*--------------------------------------*/
                    PPT_METHODTRACE_V1("","Find Assigned Port's portGroupID");

//P4200230 start
                    CORBA::Boolean bFound = FALSE;
                    CORBA::Long lenEqpPort = equipmentPortInfo.strEqpPortStatus.length();
                    for ( j=0; j < lenEqpPort; j++ )
                    {
                        PPT_METHODTRACE_V2("", "portID..............", equipmentPortInfo.strEqpPortStatus[j].portID.identifier);
                        PPT_METHODTRACE_V2("", "loadedCassetteID....", equipmentPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier);

                        if ( 0 == CIMFWStrCmp(strStartCassette[i].cassetteID.identifier,
                                              equipmentPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier) )
                        {
                            PPT_METHODTRACE_V1("","break!!");
                            strOrgEqpPortStatus = equipmentPortInfo.strEqpPortStatus[j];
                            bFound = TRUE;
                            break;
                        }
                    }
//P4200230 end
//P4200230                    CORBA::Boolean bFound = FALSE;
//P4200230                    CORBA::Long lenEqpPort = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
//P4200230                    for ( j=0; j < lenEqpPort; j++ )
//P4200230                    {
//P4200230                        if ( 0 == CIMFWStrCmp(strStartCassette[i].cassetteID.identifier,
//P4200230                                              strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier) )
//P4200230                        {
//P4200230                            PPT_METHODTRACE_V1("","break!!");
//P4200230                            strOrgEqpPortStatus = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j];
//P4200230                            bFound = TRUE;
//P4200230                            break;
//P4200230                        }
//P4200230                    }

                    if ( FALSE == bFound )
                    {
                        PPT_METHODTRACE_V1("","return RC_INVALID_CAST_XFERSTAT");
                        PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                             MSG_INVALID_CAST_XFERSTAT,
                                             RC_INVALID_CAST_XFERSTAT,
                                             transferState,
                                             strStartCassette[i].cassetteID.identifier );
                        return RC_INVALID_CAST_XFERSTAT;
                    }
                }
//P4100105 end

                if ( 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode,
                                      SP_Eqp_AccessMode_Manual) )
                {
                    PPT_METHODTRACE_V1("", ".strOperationMode.accessMode == [Manual]")
//D4000015(7) start
                    /*-------------------------------------------------------------------------*/
                    /*   When TransferStatus is EI, AccessMode makes it an error with Manual   */
                    /*-------------------------------------------------------------------------*/
                    if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn) )
                    {
                        PPT_METHODTRACE_V1("", "transferState == [EI]")
//P4100105 start
                        /*---------------------------------------------------------------------------*/
                        /*   Permit Carrier which a person can deliver in StartLotReserve.           */
                        /*   As for the condition, OperationMode is "***-1" and XferState is "EI".   */
                        /*                                                                           */
                        /*   And, Only in the case of InternalBufferEQP!!                            */
                        /*   Carrier must be on Port.                                                */
                        /*   Because, carrier may be in Shelf.                                       */
                        /*---------------------------------------------------------------------------*/
                        if ( 0 != CIMFWStrCmp(strOrgEqpPortStatus.accessMode, SP_Eqp_AccessMode_Manual)
                          || 0 == CIMFWStrLen(strOrgEqpPortStatus.loadedCassetteID.identifier) )
//P4100105 end
                        {
                            PPT_METHODTRACE_V1("", "accessMode != [Manual] or Port's loadedCassetteID.length == 0")
                            PPT_METHODTRACE_V1("","##### return RC_INVALID_CAST_XFERSTAT");
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                 MSG_INVALID_CAST_XFERSTAT,
                                                 RC_INVALID_CAST_XFERSTAT,
                                                 transferState,
                                                 strStartCassette[i].cassetteID.identifier );
                            return RC_INVALID_CAST_XFERSTAT;
                        }
                    }       //P4100105
//D4000015(7) end
                    PPT_METHODTRACE_V1("", "Condition is OK!")
                    rc = RC_OK;
                }
                else
                {
                    PPT_METHODTRACE_V1("", ".strOperationMode.accessMode != [Manual]")

//D5000194 start
                    CORBA::Boolean bReRouteFlg = FALSE;
                    CORBA::String_var reRouteXferFlag = CIMFWStrDup(getenv(SP_REROUTE_XFER_FLAG));
                    PPT_METHODTRACE_V2("","SP_REROUTE_XFER_FLAG ---> ",reRouteXferFlag);

                    PPT_METHODTRACE_V2("","operationMode", strPortResource_currentOperationMode_Get_out.strOperationMode.operationMode.identifier); //DSIV00000518

                    if ( 0 == CIMFWStrCmp(reRouteXferFlag, "1")
//DSIV00000518                      && ( 0 == CIMFWStrCmp("TXDSC008", strObjCommonIn.transactionID) || 0 == CIMFWStrCmp("TXDSC012", strObjCommonIn.transactionID) )
                      && ( 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.operationMode.identifier, SP_Eqp_Port_OperationMode_Auto_3) ) //DSIV00000518
                      && ( 0 == CIMFWStrCmp(transferState, SP_TransState_StationIn) ||
                           0 == CIMFWStrCmp(transferState, SP_TransState_BayIn)     ||
                           0 == CIMFWStrCmp(transferState, SP_TransState_ManualIn)  ||
                           0 == CIMFWStrCmp(transferState, SP_TransState_BayOut) )
                      && ( transferReserved == FALSE ) )
                    {
//DSIV00000518                        PPT_METHODTRACE_V1("", "Transaction is [TXDSC008]TxCassetteDelvieryReq or [TXDSC012]TxCassetteDeliveryForInternalBufferReq")
                        PPT_METHODTRACE_V1("", "operationMode is Auto-3") //DSIV00000518
                        PPT_METHODTRACE_V1("", "transferState = [SI], [BI], [MI], [BO] and transferReserved is FALSE")
                        rc = RC_OK;
                    }
//D5000194 end
//D5000194                    if (( 0 == CIMFWStrCmp(transferState, SP_TransState_StationIn)
                    else if (( 0 == CIMFWStrCmp(transferState, SP_TransState_StationIn)  //D5000194
                            || 0 == CIMFWStrCmp(transferState, SP_TransState_BayIn)
                            || 0 == CIMFWStrCmp(transferState, SP_TransState_ManualIn))
                            && (transferReserved == FALSE) )
                    {
                        PPT_METHODTRACE_V1("","(transferState = [SI] or [BI] or [MI]) and (XferReserved = FALSE) is OK");
                        rc = RC_OK;
                    }
//INN-R170003       else if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn)
                    else if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentOut)  //INN-R170003
                           && transferReserved == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "(transferState = [EO]) and (transferReserved == FALSE)")

//P4100105 start
                        /*--------------------------------------------------------------*/
                        /*   Make it an error when Carrier of FromEQP is [EO].          */ //INN-R170003
                        /*   Because, InternalBufferEQP can't do transfer EQP to EQP.   */
                        /*   Therefore, All Logics here are unnecessary.                */
                        /*--------------------------------------------------------------*/

                        PPT_METHODTRACE_V1("","##### return RC_INVALID_CAST_XFERSTAT");
                        PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                             MSG_INVALID_CAST_XFERSTAT,
                                             RC_INVALID_CAST_XFERSTAT,
                                             transferState,
                                             strStartCassette[i].cassetteID.identifier );
                        return RC_INVALID_CAST_XFERSTAT;
//P4100105 end

//P4100105 delete start
//P4100105                        /*--------------------------------------*/
//P4100105                        /*   Get Originator Eqp's Access Mode   */
//P4100105                        /*--------------------------------------*/
//P4100105
//P4100105                        /*--------------------------------*/
//P4100105                        /*   Get Originator EquipmentID   */
//P4100105                        /*--------------------------------*/
//P4100105                        PPT_METHODTRACE_V1("","Get Originator EquipmentID");
//P4100105
//P4100105                        Machine_var aMachine;
//P4100105                        PosMachine_var aOrgMachine;
//P4100105                        try
//P4100105                        {
//P4100105                            aMachine = aCassette->currentAssignedMachine();
//P4100105                            aOrgMachine = PosMachine::_narrow( aMachine );
//P4100105                        }
//P4100105                        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::currentAssignedMachine)
//P4100105 delete end

//D4000015                        objectIdentifier orgEquipmentID;
//D4000015                        PPT_SET_OBJECT_IDENTIFIER( orgEquipmentID,
//D4000015                                                   aOrgMachine,
//D4000015                                                   strCassette_CheckConditionForOperationForInternalBuffer_out,
//D4000015                                                   cassette_CheckConditionForOperationForInternalBuffer,
//D4000015                                                   PosMachine );
//D4000015
//D4000015                        /*---------------------------------*/
//D4000015                        /*   Get Cassette Info in OrgEqp   */
//D4000015                        /*---------------------------------*/
//D4000015                        PPT_METHODTRACE_V1("","Get Cassette Info in OrgEqp");
//D4000015
//D4000015                        objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
//D4000015                        rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
//D4000015                                                     strObjCommonIn,
//D4000015                                                     orgEquipmentID );
//D4000015
//D4000015                        if ( rc != RC_OK )
//D4000015                        {
//D4000015                            PPT_METHODTRACE_V1("", "##### equipment_portInfo_Get != RC_OK")
//D4000015                            strCassette_CheckConditionForOperationForInternalBuffer_out.strResult = strEquipment_portInfo_Get_out.strResult;
//D4000015                            return rc;
//D4000015                        }
//D4000015
//D4000015                        /*--------------------------------------*/
//D4000015                        /*   Find Assigned Port's portGroupID   */
//D4000015                        /*--------------------------------------*/
//D4000015                        PPT_METHODTRACE_V1("","/*--------------------------------------*/");
//D4000015                        PPT_METHODTRACE_V1("","/*   Find Assigned Port's portGroupID   */");
//D4000015                        PPT_METHODTRACE_V1("","/*--------------------------------------*/");
//D4000015
//D4000015                        CORBA::Long lenEqpPort = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
//D4000015                        for ( j=0; j < lenEqpPort; j++ )
//D4000015                        {
//D4000015                            if ( 0 == CIMFWStrCmp(strStartCassette[i].cassetteID.identifier,
//D4000015                                                  strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier) )
//D4000015                            {
//D4000015                                PPT_METHODTRACE_V1("","break!!");
//D4000015                                break;
//D4000015                            }
//D4000015                        }
//D4000015
//D4000015                        if ( j == lenEqpPort )
//D4000015                        {
//D4000015                            PPT_METHODTRACE_V1("","##### return RC_INVALID_CAST_XFERSTAT");
//D4000015                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
//D4000015                                                 MSG_INVALID_CAST_XFERSTAT,
//D4000015                                                 RC_INVALID_CAST_XFERSTAT,
//D4000015                                                 transferState,
//D4000015                                                 strStartCassette[i].cassetteID.identifier );
//D4000015
//D4000015                            return RC_INVALID_CAST_XFERSTAT;
//D4000015                        }

//P4100105 delete start
//P4100105//D4000015 start
//P4100105                        /*-------------------------------*/
//P4100105                        /*   Find Internal Buffer Info   */
//P4100105                        /*-------------------------------*/
//P4100105                        PPT_METHODTRACE_V1("","/*-------------------------------*/");
//P4100105                        PPT_METHODTRACE_V1("","/*   Find Internal Buffer Info   */");
//P4100105                        PPT_METHODTRACE_V1("","/*-------------------------------*/");
//P4100105
//P4100105                        CORBA::Boolean bCassetteFoundInBuffer = FALSE;
//P4100105                        CORBA::Long nBufferCategoryLen = strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo.length();
//P4100105                        PPT_METHODTRACE_V2("", "nBufferCategoryLen", nBufferCategoryLen );
//P4100105
//P4100105                        for ( j=0; j < nBufferCategoryLen; j++ )
//P4100105                        {
//P4100105                            CORBA::Long nShelfLen = strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[j].strShelfInBuffer.length();
//P4100105                            PPT_METHODTRACE_V3("", "nShelfLen", j, nShelfLen );
//P4100105
//P4100105                            // Loop of Cassette in Buffer
//P4100105                            for( k=0; k < nShelfLen; k++ )
//P4100105                            {
//P4100105                                if (0 == CIMFWStrCmp(strStartCassette[i].cassetteID.identifier,
//P4100105                                                     strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[j].strShelfInBuffer[k].loadedCarrierID.identifier) )
//P4100105                                {
//P4100105                                    PPT_METHODTRACE_V1("", "Input cassette was found in Internal Buffer of equipment.");
//P4100105                                    bCassetteFoundInBuffer = TRUE;
//P4100105                                    break;
//P4100105                                }
//P4100105                            } //end of [k]
//P4100105                        } //end of [j]
//P4100105
//P4100105                        if ( bCassetteFoundInBuffer != TRUE )
//P4100105                        {
//P4100105                            PPT_METHODTRACE_V1("", "##### Input cassette was NOT found in Internal Buffer of equipment.");
//P4100105                            PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForOperationForInternalBuffer_out,
//P4100105                                                MSG_CST_NOT_IN_LOADER,
//P4100105                                                RC_CST_NOT_IN_LOADER,
//P4100105                                                strStartCassette[i].cassetteID.identifier);
//P4100105                            return RC_CST_NOT_IN_LOADER;
//P4100105                        }
//P4100105//D4000015 end
//P4100105 delete end


//D4000015 start   already been doing by upper logic!!
//D4000015                        /*----------------------------------------------------*/
//D4000015                        /*   Get Originator Equipment's Operation Mode Info   */
//D4000015                        /*----------------------------------------------------*/
//D4000015                        PPT_METHODTRACE_V1("","Get Originator Equipment's Operation Mode Info");
//D4000015
//D4000015                        objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
//D4000015                        rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
//D4000015                                                                    strObjCommonIn,
//D4000015                                                                    equipmentID,
//D4000015                                                                    strStartCassette[i].loadPortID );
//D4000015
//D4000015                        if ( rc != RC_OK )
//D4000015                        {
//D4000015                            PPT_METHODTRACE_V1("", "portResource_currentOperationMode_Get != RC_OK")
//D4000015                            strCassette_CheckConditionForOperationForInternalBuffer_out.strResult = strPortResource_currentOperationMode_Get_out.strResult;
//D4000015                            return rc;
//D4000015                        }
//D4000015 end

//P4100105 delete start
//P4100105                        if ( 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode,
//P4100105                                              SP_Eqp_AccessMode_Auto) )
//P4100105                        {
//P4100105                            PPT_METHODTRACE_V1("","accessMode == [Auto]");
//P4100105                            rc = RC_OK;
//P4100105                        }
//P4100105                        else
//P4100105                        {
//P4100105                            PPT_METHODTRACE_V1("","##### return RC_INVALID_CAST_XFERSTAT");
//P4100105                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
//P4100105                                                 MSG_INVALID_CAST_XFERSTAT,
//P4100105                                                 RC_INVALID_CAST_XFERSTAT,
//P4100105                                                 transferState,
//P4100105                                                 strStartCassette[i].cassetteID.identifier );
//P4100105
//P4100105                            return RC_INVALID_CAST_XFERSTAT;
//P4100105                        }
//P4100105
//P4100105                        /*---------------------------------------------------------*/
//P4100105                        /*   Check orgEqp's EqpToEqpTransfer Flag is TRUE or Not   */
//P4100105                        /*---------------------------------------------------------*/
//P4100105                        PPT_METHODTRACE_V1("","/*---------------------------------------------------------*/");
//P4100105                        PPT_METHODTRACE_V1("","/*   Check orgEqp's EqpToEqpTransfer Flag is TRUE or Not   */");
//P4100105                        PPT_METHODTRACE_V1("","/*---------------------------------------------------------*/");
//P4100105
//P4100105                        CORBA::Boolean bEqpToEqpXFerFlag;
//P4100105                        try
//P4100105                        {
//P4100105                            bEqpToEqpXFerFlag = aOrgMachine->isEqpToEqpTransferFlagOn();
//P4100105                        }
//P4100105                        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::currentAssignedMachine)
//P4100105                        PPT_METHODTRACE_V2("", "bEqpToEqpXFerFlag", (long)bEqpToEqpXFerFlag);
//P4100105
//P4100105                        if ( TRUE == bEqpToEqpXFerFlag )
//P4100105                        {
//P4100105                            PPT_METHODTRACE_V1("","TRUE == bEqpToEqpXFerFlag");
//P4100105                            rc = RC_OK;
//P4100105                        }
//P4100105                        else
//P4100105                        {
//P4100105                            PPT_METHODTRACE_V1("","##### return RC_INVALID_CAST_XFERSTAT");
//P4100105                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
//P4100105                                                 MSG_INVALID_CAST_XFERSTAT,
//P4100105                                                 RC_INVALID_CAST_XFERSTAT,
//P4100105                                                 transferState,
//P4100105                                                 strStartCassette[i].cassetteID.identifier );
//P4100105
//P4100105                            return RC_INVALID_CAST_XFERSTAT;
//P4100105                        }
//P4100105 delete end
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","##### return RC_INVALID_CAST_XFERSTAT");
                        PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                             MSG_INVALID_CAST_XFERSTAT,
                                             RC_INVALID_CAST_XFERSTAT,
                                             transferState,
                                             strStartCassette[i].cassetteID.identifier );

                        return RC_INVALID_CAST_XFERSTAT;
                    }
                }
            }

            /*----------------------------------------------*/
            /*   Get and Check Cassette's Dispatch Status   */
            /*----------------------------------------------*/

            /*------------------------------------*/
            /*   Get Cassette's Dispatch Status   */
            /*------------------------------------*/
            PPT_METHODTRACE_V1("","/*------------------------------------*/");
            PPT_METHODTRACE_V1("","/*   Get Cassette's Dispatch Status   */");
            PPT_METHODTRACE_V1("","/*------------------------------------*/");
            if ( 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation)
              || 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatching)
              || 0 == CIMFWStrCmp(operation, SP_Operation_CassetteDelivery) )   //D4000015(4)
            {
                PPT_METHODTRACE_V1("","operation == [StartReservation] or [FlowBatching] or [CassetteDelivery]");

                CORBA::Boolean dispatchReserveFlag;
                try
                {
                    dispatchReserveFlag = aCassette->isDispatchReserved();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isDispatchtReserved)
//D9000001                PPT_METHODTRACE_V2("","dispatchReserveFlag", (long)dispatchReserveFlag);
                PPT_METHODTRACE_V2("","dispatchReserveFlag", (int)dispatchReserveFlag); //D9000001

                if ( dispatchReserveFlag != FALSE )
                {
                    PPT_METHODTRACE_V1("","##### dispatchReserveFlag != FALSE");
                    SET_MSG_RC( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                MSG_ALREADY_DISPATCH_RESVED_CST,
                                RC_ALREADY_DISPATCH_RESVED_CST );

                    return RC_ALREADY_DISPATCH_RESVED_CST;
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "----- Nothing is done -----");
            }
            PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");

            /*-------------------------------------*/
            /*   Get and Check Cassette's Status   */
            /*-------------------------------------*/
            PPT_METHODTRACE_V1("","/*-------------------------------------*/");
            PPT_METHODTRACE_V1("","/*   Get and Check Cassette's Status   */");
            PPT_METHODTRACE_V1("","/*-------------------------------------*/");

            CORBA::String_var cassetteState;
            try
            {
                cassetteState = aCassette->getDurableState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getCurrentState)
            PPT_METHODTRACE_V2("", "aCassette->getDurableState", cassetteState)

//DSN000101569 add start
            if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart) || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation) )
            {
                PPT_METHODTRACE_V1("","operation == SP_Operation_OpeStart or SP_Operation_StartReservation");

                SPDynamicTableS< char*, char*, char*, char*, stringSequence, stringSequence > subLotTypeList;

                // for empty carrier
                if ( 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) )
                {
                    PPT_METHODTRACE_V1("","Empty carrier");

                    // Get all carrier's start lots SubLotType
                    CORBA::ULong startCastLen = strStartCassette.length();
                    PPT_METHODTRACE_V2("", "startCastLen", startCastLen)
                    for ( CORBA::ULong startCastIndex = 0; startCastIndex < startCastLen; startCastIndex++ )
                    {
                        PPT_METHODTRACE_V2("", "startCastIndex", startCastIndex)

                        CORBA::ULong lotInCastLen = strStartCassette[startCastIndex].strLotInCassette.length();
                        PPT_METHODTRACE_V2("", "lotInCastLen", lotInCastLen)
                        for ( CORBA::ULong lotInCastIndex = 0; lotInCastIndex < lotInCastLen; lotInCastIndex++ )
                        {
                            PPT_METHODTRACE_V2("", "lotInCastIndex", lotInCastIndex)
                            if ( TRUE == strStartCassette[startCastIndex].strLotInCassette[lotInCastIndex].operationStartFlag )
                            {
                                const char* subLotType = strStartCassette[startCastIndex].strLotInCassette[lotInCastIndex].subLotType;
                                PPT_METHODTRACE_V2("", "subLotType", subLotType)
                                if( !subLotTypeList.exists( (char*)subLotType ) )
                                {
                                    PPT_METHODTRACE_V1("", "Add subLotType");
                                    subLotTypeList.add( CIMFWStrDup(subLotType), CIMFWStrDup(subLotType) );
                                }
                            }
                        }
                    }
                }
                // for lot in carrier
                else
                {
                    PPT_METHODTRACE_V1("","Lot in carrier");

                    // Get carrier's start lots SubLotType
                    CORBA::ULong lotInCastLen = strStartCassette[i].strLotInCassette.length();
                    PPT_METHODTRACE_V2("", "lotInCastLen", lotInCastLen)
                    for ( CORBA::ULong lotInCastIndex = 0; lotInCastIndex < lotInCastLen; lotInCastIndex++ )
                    {
                        PPT_METHODTRACE_V2("", "lotInCastIndex", lotInCastIndex)

                        if ( TRUE == strStartCassette[i].strLotInCassette[lotInCastIndex].operationStartFlag )
                        {
                            const char* subLotType = strStartCassette[i].strLotInCassette[lotInCastIndex].subLotType;
                            PPT_METHODTRACE_V2("", "subLotType", subLotType)
                            if( !subLotTypeList.exists( (char*)subLotType ) )
                            {
                                PPT_METHODTRACE_V1("", "Add subLotType");
                                subLotTypeList.add( CIMFWStrDup(subLotType), CIMFWStrDup(subLotType) );
                            }
                        }
                    }
                }

                stringSequence_var subLotTypeListSeq = subLotTypeList.getSequence();
                PPT_METHODTRACE_V2("", "subLotTypeListSeq length", subLotTypeListSeq->length())

                CORBA::Boolean availableFlag = FALSE;
                try
                {
                    availableFlag = aCassette->isLotProcessAvailable(subLotTypeListSeq);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isLotProcessAvailable)

                if ( TRUE == availableFlag )
                {
                    PPT_METHODTRACE_V1("", "availableFlag == TRUE");
                    rc = RC_OK;
                }
                else
                {
                    PPT_METHODTRACE_V1("", "availableFlag != TRUE");
                    PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                        MSG_DRBL_NOT_AVAILSTAT_FOR_LOTPROCESS,
                                        RC_DRBL_NOT_AVAILSTAT_FOR_LOTPROCESS,
                                        strStartCassette[i].cassetteID.identifier );
                    return RC_DRBL_NOT_AVAILSTAT_FOR_LOTPROCESS;
                }
            }
            else
            {
//DSN000101569 add end
                if ( 0 == CIMFWStrCmp(cassetteState, CIMFW_Durable_Available)
                  || 0 == CIMFWStrCmp(cassetteState, CIMFW_Durable_InUse) )
                {
                    PPT_METHODTRACE_V1("", "cassetteState = CIMFW_Durable_Available or CIMFW_Durable_InUse")
                    rc = RC_OK;
                }
                else
                {
                    PPT_METHODTRACE_V1("","##### return RC_INVALID_CAST_STAT");
                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                         MSG_INVALID_CAST_STAT,
                                         RC_INVALID_CAST_STAT,
                                         cassetteState,
                                         strStartCassette[i].cassetteID.identifier );

                    return RC_INVALID_CAST_STAT;
                }
            }  //DSN000101569
            PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");

//D4000015(3) start
            /*------------------------------------------------------*/
            /*   Check Exist LoadPort reserved and LoadedCassette   */
            /*------------------------------------------------------*/
            PPT_METHODTRACE_V1("","/*------------------------------------------------------*/");
            PPT_METHODTRACE_V1("","/*   Check Exist LoadPort reserved and LoadedCassette   */");
            PPT_METHODTRACE_V1("","/*------------------------------------------------------*/");

            if ( 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation)
              || 0 == CIMFWStrCmp(operation, SP_Operation_CassetteDelivery) )   //D4000015(4)
            {
                PPT_METHODTRACE_V1("", "operation = [StartReservation] or [CassetteDelivery]")

                CORBA::Long lenBufCategory = strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo.length();
                PPT_METHODTRACE_V2("", "lenBufCategory", lenBufCategory );

                for ( j=0; j < lenBufCategory; j++ )
                {
                    CORBA::Long nShelfLen = strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[j].strShelfInBuffer.length();
                    PPT_METHODTRACE_V3("", "nShelfLen", j, nShelfLen );

                    for( k=0; k < nShelfLen; k++ )
                    {
                        PPT_METHODTRACE_V2("", "--------------------------------- shelfOrderNo", strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[j].strShelfInBuffer[k].shelfOrderNumber);
                        PPT_METHODTRACE_V2("", "controlJobID----------->", strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[j].strShelfInBuffer[k].controlJobID.identifier);
                        PPT_METHODTRACE_V2("", "loadedCarrierID-------->", strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[j].strShelfInBuffer[k].loadedCarrierID.identifier);
                        PPT_METHODTRACE_V2("", "reservedCarrierID------>", strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[j].strShelfInBuffer[k].reservedCarrierID.identifier);
                        PPT_METHODTRACE_V2("", "reservedLoadPortID----->", strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[j].strShelfInBuffer[k].reservedLoadPortID.identifier);
                        PPT_METHODTRACE_V2("", "reservedUnloadPortID--->", strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[j].strShelfInBuffer[k].reservedUnloadPortID.identifier);

                        // check exist reservedCarrier
                        PPT_METHODTRACE_V1("","check exist reservedCarrier");
                        if ( 0 == CIMFWStrCmp(strStartCassette[i].cassetteID.identifier,
                                              strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[j].strShelfInBuffer[k].reservedCarrierID.identifier) )
                        {
                            PPT_METHODTRACE_V1("","##### EQP has been already unload reserved");
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                 MSG_INTERNAL_BUFFER_ALREADY_RESERVED,
                                                 RC_INTERNAL_BUFFER_ALREADY_RESERVED,
                                                 equipmentID.identifier,
                                                 "load" );
                            return RC_INTERNAL_BUFFER_ALREADY_RESERVED;
                        }

                        // check exist loadedCarrier
                        PPT_METHODTRACE_V1("","check exist loadedCarrier");
                        if ( 0 == CIMFWStrCmp(strStartCassette[i].cassetteID.identifier,
                                              strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[j].strShelfInBuffer[k].loadedCarrierID.identifier) )
                        {
                            PPT_METHODTRACE_V1("","##### Cassette is already loaded on the equipment");
                            PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                MSG_CST_ALREADY_LOADED,
                                                RC_CST_ALREADY_LOADED,
                                                strStartCassette[i].cassetteID.identifier );
                            return RC_CST_ALREADY_LOADED;
                        }
                    } //end of [k]
                } //end of [j]
            }
            else
            {
                PPT_METHODTRACE_V1("", "----- Nothing is done -----");
            }
            PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");

            //P4200290 Add Start
            //-----------------------------------------------
            // Check Start Cassette And Start Lot Combination
            //-----------------------------------------------
            if (( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart)) ||
                ( 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation)))
            {
                PPT_METHODTRACE_V2("", "Start Cassette and Start Lot Combination Check", operation);

                LotSequence*    aLotSequence = NULL;
                LotSequence_var aLotSequenceVar;

                try
                {
                    aLotSequence     = aCassette->allLots();
                    aLotSequenceVar  = aLotSequence;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::allLots);

                CORBA::Long lotLen           = aLotSequence->length();
                CORBA::Long lotLenInCassette = strStartCassette[i].strLotInCassette.length();

                if ( lotLen == lotLenInCassette )
                {
                    PPT_METHODTRACE_V2("", "Lot Count is Matching", lotLen );

                    CORBA::Boolean    bLotMatch = FALSE;
                    CORBA::Long jj = 0;
                    CORBA::Long kk = 0;

                    //--------------------------------
                    // All Lot in Start Cassette Loop
                    //--------------------------------
                    for ( jj=0; jj<lotLen; jj++ )
                    {
                        bLotMatch = FALSE;
                        CORBA::String_var    strTempLotID;

                        if ( TRUE != CORBA::is_nil((*aLotSequence)[jj]) )
                        {
                            try
                            {
                                strTempLotID = (*aLotSequence)[jj]->getIdentifier();
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getIdentifier)
                            //---------------------------------
                            // Inpara Lot in StartCassette Loop
                            //---------------------------------
                            for ( kk=0; kk<lotLenInCassette; kk++ )
                            {
                                if ( 0 == CIMFWStrCmp( strTempLotID,
                                                       strStartCassette[i].strLotInCassette[kk].lotID.identifier ) )
                                {
                                    PPT_METHODTRACE_V2("", "Find Matching Lot", strTempLotID );

                                    bLotMatch = TRUE;
                                    break;
                                }
                            }
                            if ( bLotMatch == FALSE )
                            {
                                PPT_METHODTRACE_V2("", "Lot in Start Cassette Miss Match", strTempLotID );
                                SET_MSG_RC( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                            MSG_LOT_START_CAST_UNMATCH,
                                            RC_LOT_START_CAST_UNMATCH );
                                return RC_LOT_START_CAST_UNMATCH;
                            }
                        }
                        else
                        {
                            PPT_METHODTRACE_V2("", "aLotSequence[jj] is Nill", jj );
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                 MSG_LOT_CAST_UNMATCH,
                                                 RC_LOT_CAST_UNMATCH,
                                                 "*****",
                                                 strStartCassette[i].cassetteID.identifier );
                            return RC_LOT_CAST_UNMATCH;
                        }
                    }

                    //--------------------------------
                    // Check Cassette & Lot combination
                    //  Inpara Lot --> Lot in Cassette
                    //--------------------------------
                    for ( jj=0; jj<lotLenInCassette; jj++ )
                    {
                        bLotMatch = FALSE;
                        CORBA::String_var    strTempLotID;

                        //---------------------------------
                        // All Lot of in Cassette Loop
                        //---------------------------------
                        for ( kk=0; kk<lotLen; kk++ )
                        {
                            if ( TRUE != CORBA::is_nil((*aLotSequence)[kk]) )
                            {
                                try
                                {
                                    strTempLotID = (*aLotSequence)[kk]->getIdentifier();
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getIdentifier)

                                if ( 0 == CIMFWStrCmp( strTempLotID,
                                                       strStartCassette[i].strLotInCassette[jj].lotID.identifier ) )
                                {
                                    PPT_METHODTRACE_V2("", "Find Matching Lot", strTempLotID );

                                    bLotMatch = TRUE;
                                    break;
                                }
                            }
                            else
                            {
                                PPT_METHODTRACE_V2("", "aLotSequence[kk] is Nill", kk );
                                PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                     MSG_LOT_CAST_UNMATCH,
                                                     RC_LOT_CAST_UNMATCH,
                                                     "*****",
                                                     strStartCassette[i].cassetteID.identifier );
                                return RC_LOT_CAST_UNMATCH;
                            }
                        }

                        if ( bLotMatch == FALSE )
                        {
                            PPT_METHODTRACE_V2("", "Lot in Start Cassette Miss Match", strTempLotID );
                            SET_MSG_RC( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                        MSG_LOT_START_CAST_UNMATCH,
                                        RC_LOT_START_CAST_UNMATCH );
                            return RC_LOT_START_CAST_UNMATCH;
                        }
                    }
                }
                else
                {
                    PPT_METHODTRACE_V3("", "Lot in Start Cassette Count Miss Match", lotLen, lotLenInCassette );
                    SET_MSG_RC( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                MSG_LOT_START_CAST_UNMATCH,
                                RC_LOT_START_CAST_UNMATCH );
                    return RC_LOT_START_CAST_UNMATCH;
                }
            }
            //P4200290 Add End

    //D4000015(3) end
        } //end of [i]
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>       Check Cassette Condition");



//D4000015 start
        /******************************************************************************************/
        /*                                                                                        */
        /*     Check unload port reserved                                                         */
        /*                                                                                        */
        /******************************************************************************************/
        PPT_METHODTRACE_V1("", "");
        PPT_METHODTRACE_V1("", "//***************************************************************");
        PPT_METHODTRACE_V1("", "//  Check unload port reserved");
        PPT_METHODTRACE_V1("", "//***************************************************************");

        if ( 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation)
          || 0 == CIMFWStrCmp(operation, SP_Operation_NPWCarrierXfer)
          || 0 == CIMFWStrCmp(operation, SP_Operation_CassetteDelivery) )       //D4000015(4)
        {
            PPT_METHODTRACE_V1("", "operation is [StartReservation] or [NPWCarrierXfer] or [CassetteDelivery]")

            CORBA::Long lenBufCategory = strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo.length();
            PPT_METHODTRACE_V2("", "lenBufCategory", lenBufCategory );

            for ( i=0; i < lenBufCategory; i++ )
            {
                CORBA::Long nShelfLen = strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[i].strShelfInBuffer.length();
                PPT_METHODTRACE_V3("", "nShelfLen", i, nShelfLen );

                // Loop of Cassette in Buffer
                for( j=0; j < nShelfLen; j++ )
                {
                    for ( k=0; k < lenCassette; k++ )       //D4000015(6)
                    {                                       //D4000015(6)
                        PPT_METHODTRACE_V2("", "strStartCassette[k].loadPortID", strStartCassette[k].loadPortID.identifier );

                        if ( 0 == CIMFWStrCmp(strStartCassette[k].loadPortID.identifier,                                                                                    //D4000015(6)
                                              strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[i].strShelfInBuffer[j].reservedUnloadPortID.identifier) ) //D4000015(6)
//D4000015(6)                    if ( 0 < CIMFWStrLen(strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo[i].strShelfInBuffer[j].reservedUnloadPortID.identifier) )
                        {
                            PPT_METHODTRACE_V1("","##### EQP has been already unload reserved");
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                 MSG_INTERNAL_BUFFER_ALREADY_RESERVED,
                                                 RC_INTERNAL_BUFFER_ALREADY_RESERVED,
                                                 equipmentID.identifier,
//D4000015(6)                                                "unload" );
                                                 strStartCassette[k].loadPortID.identifier );   //D4000015(6)
                            return RC_INTERNAL_BUFFER_ALREADY_RESERVED;
                        }                                   //D4000015(6)
                    } //end of [k]
                } //end of [j]
            } //end of [i]
        }
        else
        {
            PPT_METHODTRACE_V1("", "----- Nothing is done -----");
        }
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");
//D4000015 end



//D4000015 start
        /******************************************************************************************/
        /*                                                                                        */
        /*     Count of Cassette LoadPurposeType                                                  */
        /*                                                                                        */
        /******************************************************************************************/
        PPT_METHODTRACE_V1("", "");
        PPT_METHODTRACE_V1("", "//***************************************************************");
        PPT_METHODTRACE_V1("", "//  Count of Cassette LoadPurposeType");
        PPT_METHODTRACE_V1("", "//***************************************************************");

        CORBA::Long emptyCassetteCount = 0;
        CORBA::Long fillerDummyLotCount = 0;
        CORBA::Long processLotCount = 0;
        CORBA::Long processMonitorLotCount = 0;
        CORBA::Long sideDummyLotCount = 0;
        CORBA::Long waitingMonitorLotCount = 0;

        for ( i=0; i < lenCassette; i++ )
        {
            PPT_METHODTRACE_V3("","------------------------------round [i]", i, strStartCassette[i].loadPurposeType);

            if ( 0 == CIMFWStrCmp(SP_LoadPurposeType_EmptyCassette, strStartCassette[i].loadPurposeType) )
            {
                emptyCassetteCount++;
                PPT_METHODTRACE_V2("","emptyCassetteCount++", emptyCassetteCount);
            }
            else if ( 0 == CIMFWStrCmp(SP_LoadPurposeType_FillerDummy, strStartCassette[i].loadPurposeType) )
            {
                fillerDummyLotCount++;
                PPT_METHODTRACE_V2("","fillerDummyLotCount++", fillerDummyLotCount);
            }
            else if ( 0 == CIMFWStrCmp(SP_LoadPurposeType_ProcessLot, strStartCassette[i].loadPurposeType) )
            {
                processLotCount++;
                PPT_METHODTRACE_V2("","processLotCount++", processLotCount);
            }
            else if ( 0 == CIMFWStrCmp(SP_LoadPurposeType_ProcessMonitorLot, strStartCassette[i].loadPurposeType) )
            {
                processMonitorLotCount++;
                PPT_METHODTRACE_V2("","processMonitorLotCount++", processMonitorLotCount);
            }
            else if ( 0 == CIMFWStrCmp(SP_LoadPurposeType_SideDummyLot, strStartCassette[i].loadPurposeType) )
            {
                sideDummyLotCount++;
                PPT_METHODTRACE_V2("","sideDummyLotCount++", sideDummyLotCount);
            }
            else if ( 0 == CIMFWStrCmp(SP_LoadPurposeType_WaitingMonitorLot, strStartCassette[i].loadPurposeType) )
            {
                waitingMonitorLotCount++;
                PPT_METHODTRACE_V2("","waitingMonitorLotCount++", waitingMonitorLotCount);
            }
            else
            {
                PPT_METHODTRACE_V2("","##### Bad loadPurposeType!!", strStartCassette[i].loadPurposeType);
            }

//D4000028 start
            if ( 0 == CIMFWStrCmp(operation, SP_Operation_NPWCarrierXfer) )
            {
                PPT_METHODTRACE_V1("","operation == [NPWCarrierXfer]");

                if ( 0 != processLotCount || 0 != emptyCassetteCount || 0!= processMonitorLotCount )
                {
                    PPT_METHODTRACE_V1("","##### 0 != processLotCount || 0 != emptyCassetteCount || 0!= processMonitorLotCount");
                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                         MSG_INVALID_PURPOSE_TYPE,
                                         RC_INVALID_PURPOSE_TYPE,
                                         strStartCassette[i].cassetteID.identifier,
                                         equipmentID.identifier );
                    return RC_INVALID_PURPOSE_TYPE;
                }
            }
//D4000028 end
        } //end of [i]

        PPT_METHODTRACE_V1("", "============================================================");
        PPT_METHODTRACE_V2("", "emptyCassetteCount--------->", emptyCassetteCount);
        PPT_METHODTRACE_V2("", "fillerDummyLotCount-------->", fillerDummyLotCount);
        PPT_METHODTRACE_V2("", "processLotCount------------>", processLotCount);
        PPT_METHODTRACE_V2("", "processMonitorLotCount----->", processMonitorLotCount);
        PPT_METHODTRACE_V2("", "sideDummyLotCount---------->", sideDummyLotCount);
        PPT_METHODTRACE_V2("", "waitingMonitorLotCount----->", waitingMonitorLotCount);
        PPT_METHODTRACE_V1("", "============================================================");
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");



//D4000015(2) start
        /******************************************************************************************/
        /*                                                                                        */
        /*     Check ProcessLot Count                                                             */
        /*                                                                                        */
        /******************************************************************************************/
        PPT_METHODTRACE_V1("", "");
        PPT_METHODTRACE_V1("", "//***************************************************************");
        PPT_METHODTRACE_V1("", "//  Check ProcessLot Count");
        PPT_METHODTRACE_V1("", "//***************************************************************");

//P5000043        if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart)
//P5000043          || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation)
//P5000043          || 0 == CIMFWStrCmp(operation, SP_Operation_CassetteDelivery) )   //D4000015(4)

        if ( 0 == CIMFWStrCmp(operation, SP_Operation_CassetteDelivery) )             //P5000043
        {
            PPT_METHODTRACE_V1("", "operation = [OpeStart] or [StartReservation] or [CassetteDelivery]")
            /*----------------------------*/
            /*   Check ProcessLot Count   */
            /*----------------------------*/
            PPT_METHODTRACE_V1("", "Check ProcessLot Count");
            if ( 0 == processLotCount )
            {
                PPT_METHODTRACE_V1("", "##### 0 == processLotCount");
                PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                    MSG_NOT_FOUND_LOT,
                                    RC_NOT_FOUND_LOT,
                                    "ProcessLot" );
                return RC_NOT_FOUND_LOT;
            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "----- Nothing is done -----");
        }
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");
//D4000015(2) end



//D4000015 start
        /******************************************************************************************/
        /*                                                                                        */
        /*     Check Internal Buffer Free Space VS StartCassette LoadPurposeType Total            */
        /*                                                                                        */
        /******************************************************************************************/
        PPT_METHODTRACE_V1("", "");
        PPT_METHODTRACE_V1("", "//***************************************************************");
        PPT_METHODTRACE_V1("", "//  Check Internal Buffer Free Space VS StartCassette LoadPurposeType Total");
        PPT_METHODTRACE_V1("", "//***************************************************************");

        if ( 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation)     //D4000028
          || 0 == CIMFWStrCmp(operation, SP_Operation_NPWCarrierXfer)       //D4000028
          || 0 == CIMFWStrCmp(operation, SP_Operation_CassetteDelivery) )   //D4000015(4)
        {
            PPT_METHODTRACE_V1("","operation == [StartReservation] or [NPWCarrierXfer] or [CassetteDelivery]");

            /*------------------------------------*/
            /*   Get Internal Buffer Free Space   */
            /*------------------------------------*/
            PPT_METHODTRACE_V1("","Get Internal Buffer Free Space");
            objEquipment_shelfSpaceForInternalBuffer_Get_out  strEquipment_shelfSpaceForInternalBuffer_Get_out;
            rc = equipment_shelfSpaceForInternalBuffer_Get( strEquipment_shelfSpaceForInternalBuffer_Get_out,
                                                            strObjCommonIn,
                                                            equipmentID,
                                                            TRUE,
                                                            strEquipment_internalBufferInfo_Get_out.equipmentInternalBufferInfo );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "##### RC_OK != equipment_shelfSpaceForInternalBuffer_Get()");
                strCassette_CheckConditionForOperationForInternalBuffer_out.strResult = strEquipment_shelfSpaceForInternalBuffer_Get_out.strResult;
                return rc;
            }

            CORBA::String_var shelfCategory;
            CORBA::Boolean bFreeShelfErr = FALSE;

            if ( emptyCassetteCount > strEquipment_shelfSpaceForInternalBuffer_Get_out.emptyCassetteSpace )
            {
                PPT_METHODTRACE_V1("","emptyCassetteCount space over!!");
                shelfCategory = CIMFWStrDup( SP_LoadPurposeType_EmptyCassette );
                bFreeShelfErr = TRUE;
            }
            if ( fillerDummyLotCount > strEquipment_shelfSpaceForInternalBuffer_Get_out.fillerDummyLotSpace )
            {
                PPT_METHODTRACE_V1("","fillerDummyLotCount space over!!");
                shelfCategory = CIMFWStrDup( SP_LoadPurposeType_FillerDummy );
                bFreeShelfErr = TRUE;
            }
            if ( processLotCount > strEquipment_shelfSpaceForInternalBuffer_Get_out.processLotSpace )
            {
                PPT_METHODTRACE_V1("","processLotCount space over!!");
                shelfCategory = CIMFWStrDup( SP_LoadPurposeType_ProcessLot );
                bFreeShelfErr = TRUE;
            }
            if ( processMonitorLotCount > strEquipment_shelfSpaceForInternalBuffer_Get_out.processMonitorLotSpace )
            {
                PPT_METHODTRACE_V1("","processMonitorLotCount space over!!");
                shelfCategory = CIMFWStrDup( SP_LoadPurposeType_ProcessMonitorLot );
                bFreeShelfErr = TRUE;
            }
            if ( sideDummyLotCount > strEquipment_shelfSpaceForInternalBuffer_Get_out.sideDummyLotSpace )
            {
                PPT_METHODTRACE_V1("","sideDummyLotCount space over!!");
                shelfCategory = CIMFWStrDup( SP_LoadPurposeType_SideDummyLot );
                bFreeShelfErr = TRUE;
            }
            if ( waitingMonitorLotCount > strEquipment_shelfSpaceForInternalBuffer_Get_out.waitingMonitorLotSpace )
            {
                PPT_METHODTRACE_V1("","waitingMonitorLotCount space over!!");
                shelfCategory = CIMFWStrDup( SP_LoadPurposeType_WaitingMonitorLot );
                bFreeShelfErr = TRUE;
            }

            if ( TRUE == bFreeShelfErr )
            {
                PPT_METHODTRACE_V1("","##### TRUE == bFreeShelfErr");
                PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                    MSG_NOT_SPACE_EQP_SELF,
                                    RC_NOT_SPACE_EQP_SELF,
                                    shelfCategory );

                return RC_NOT_SPACE_EQP_SELF;
            }
        }       //D4000028
        else
        {
            PPT_METHODTRACE_V1("", "----- Nothing is done -----");
        }
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");
//D4000015 end

//P8000119 start
        /*---------------------------------------------------------*/
        /*   Check Cassette's ControlJobID vs Eqp's ControlJobID   */
        /*---------------------------------------------------------*/
        PPT_METHODTRACE_V1("","Check Cassette's ControlJobID vs Eqp's ControlJobID");

        if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart) )
        {
            PPT_METHODTRACE_V1("","operation == SP_Operation_OpeStart");

            /*===== get reserved controlJobID for each portGroup =====*/
            objEquipment_reservedControlJobID_Get_out strEquipment_reservedControlJobID_Get_out;
            rc = equipment_reservedControlJobID_Get( strEquipment_reservedControlJobID_Get_out,
                                                     strObjCommonIn,
                                                     equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("","equipment_reservedControlJobID_Get != RC_OK");
                strCassette_CheckConditionForOperationForInternalBuffer_out.strResult = strEquipment_reservedControlJobID_Get_out.strResult;
                return rc ;
            }

            /*===== find reserved controlJobID for specified portGroup =====*/
            objectIdentifier eqpControlJobID;

            PosStartCassetteInfoSequence*    startCassetteInfo = NULL;
            PosStartCassetteInfoSequence_var startCassetteInfoVar;

            if ( 0 < CIMFWStrLen(saveControlJobID.identifier) )
            {
                CORBA::Long rsvCJLen = strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo.length();
                for ( CORBA::Long nCJ=0; nCJ < rsvCJLen; nCJ++ )
                {
                    if ( 0 == CIMFWStrCmp(saveControlJobID.identifier,
                                          strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[nCJ].controlJobID.identifier) )
                    {
                        eqpControlJobID = strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[nCJ].controlJobID;

                        /*---------------------------*/
                        /*   Get ControlJob Object   */
                        /*---------------------------*/
                        PPT_METHODTRACE_V1("","Get ControlJob Object...");

                        PosControlJob_var aReserveControlJob;
                        PPT_CONVERT_CONTROLJOBID_TO_CONTROLJOB_OR(aReserveControlJob, eqpControlJobID, strCassette_CheckConditionForOperationForInternalBuffer_out, cassette_CheckConditionForOperationForInternalBuffer);

                        /*-------------------------------------------*/
                        /*   Get PosStartCassetteInfoSequence Info   */
                        /*-------------------------------------------*/
                        try
                        {
                            startCassetteInfo    = aReserveControlJob->getStartCassetteInfo();
                            startCassetteInfoVar = startCassetteInfo;
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosControlJob::getStartCassetteInfo);

                        cjCastCnt = (*startCassetteInfo).length();
                        PPT_METHODTRACE_V2("","controlJob's cassetteCount = ",cjCastCnt);
                        PPT_METHODTRACE_V1("","break!!");
                        break; //[nCJ]
                    }
                } //end of [nCJ]
            }

            /*===== compare reserved controlJobID vs cassette's controlJobID =====*/
            if ( 0 != CIMFWStrCmp(saveControlJobID.identifier, eqpControlJobID.identifier) )
            {
                PPT_METHODTRACE_V1("","compare reserved controlJobID vs cassette's controlJobID");

                SET_MSG_RC( strCassette_CheckConditionForOperationForInternalBuffer_out,
                            MSG_CAST_PORT_CTRLJOB_UNMATCH, RC_CAST_PORT_CTRLJOB_UNMATCH );
                return RC_CAST_PORT_CTRLJOB_UNMATCH;
            }

            /*===== check reserved controlJobID's cassette count vs in-parm's cassette count =====*/
            if ( 0 < CIMFWStrLen(saveControlJobID.identifier) )
            {
                PPT_METHODTRACE_V1("","check reserved controlJobID's cassette count vs in-parm's cassette count");

                lenCassette = strStartCassette.length();
                if ( cjCastCnt != lenCassette )
                {
                    PPT_METHODTRACE_V1("","return RC_CAST_PORT_CTRLJOB_COUNT_UNMATCH");
                    SET_MSG_RC( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                MSG_CAST_PORT_CTRLJOB_COUNT_UNMATCH, RC_CAST_PORT_CTRLJOB_COUNT_UNMATCH );
                    return RC_CAST_PORT_CTRLJOB_COUNT_UNMATCH;
                }
            }

            /*===== check reserved controlJobID's StartCassetteInfo vs in-parm's StartCassetteInfo =====*/
            if ( NULL != startCassetteInfo )
            {
                PPT_METHODTRACE_V1("", "check reserved controlJobID's StartCassetteInfo vs in-parm's StartCassetteInfo");

                // Loop of InParameter's StartCassette information.
                CORBA::Long nCstLen = strStartCassette.length();
                for ( CORBA::Long nCst=0; nCst < nCstLen; nCst++ )
                {
                    CORBA::Long nLotLen = strStartCassette[nCst].strLotInCassette.length();
                    for ( CORBA::Long nLot=0; nLot < nLotLen; nLot++ )
                    {
                        PPT_METHODTRACE_V2("", "LotID (InParam)", strStartCassette[nCst].strLotInCassette[nLot].lotID.identifier);

                        // Loop of ControlJob's StartCassette information.
                        CORBA::Boolean bSameCondition = FALSE;
                        CORBA::Long nCJCstLen = (*startCassetteInfo).length();
                        for ( CORBA::Long nCstCJ=0; nCstCJ < nCJCstLen; nCstCJ++ )
                        {
                            CORBA::Long nCJLotLen = (*startCassetteInfo)[nCstCJ].lotInCassetteInfo.length();
                            for ( CORBA::Long nLotCJ=0; nLotCJ < nCJLotLen; nLotCJ++ )
                            {
                                PPT_METHODTRACE_V2("", "  LotID (CJ)", (*startCassetteInfo)[nCstCJ].lotInCassetteInfo[nLotCJ].lotID.identifier);

                                if ( 0 == CIMFWStrCmp(strStartCassette[nCst].strLotInCassette[nLot].lotID.identifier,
                                                      (*startCassetteInfo)[nCstCJ].lotInCassetteInfo[nLotCJ].lotID.identifier)
                                  && strStartCassette[nCst].strLotInCassette[nLot].operationStartFlag == (*startCassetteInfo)[nCstCJ].lotInCassetteInfo[nLotCJ].operationStartFlag )
                                {
                                    PPT_METHODTRACE_V1("", "Found same condition Lot.");
                                    bSameCondition = TRUE;
                                    break;
                                }
                            } //end of [nLotCJ]

                            if ( bSameCondition )
                            {
                                break;
                            }
                        } //end of [nCstCJ]

                        if ( !bSameCondition )
                        {
                            PPT_METHODTRACE_V1("", "return RC_STARTRSVCJ_OPESTACJ_UNMATCH");
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                 MSG_STARTRSVCJ_OPESTACJ_UNMATCH, RC_STARTRSVCJ_OPESTACJ_UNMATCH,
                                                 equipmentID.identifier,
                                                 eqpControlJobID.identifier );
                            return RC_STARTRSVCJ_OPESTACJ_UNMATCH;
                        }
                    } //end of [nLot]
                } //end of [nCst]
            }
        }
//P8000119 end


//D4000015 start
//D4000015        /*---------------------------------------------------------*/
//D4000015        /*   Check Cassette's ControlJobID vs Eqp's ControlJobID   */
//D4000015        /*---------------------------------------------------------*/
//D4000015
//D4000015        if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart) )
//D4000015        {
//D4000015            /*===== get reserved controlJobID for each portGroup =====*/
//D4000015            objEquipment_reservedControlJobID_Get_out strEquipment_reservedControlJobID_Get_out;
//D4000015            rc = equipment_reservedControlJobID_Get( strEquipment_reservedControlJobID_Get_out,
//D4000015                                                     strObjCommonIn,
//D4000015                                                     equipmentID );
//D4000015            if ( rc != RC_OK )
//D4000015            {
//D4000015                PPT_METHODTRACE_V1("","equipment_reservedControlJobID_Get != RC_OK");
//D4000015                strCassette_CheckConditionForOperationForInternalBuffer_out.strResult = strEquipment_reservedControlJobID_Get_out.strResult;
//D4000015                return rc ;
//D4000015            }
//D4000015
//D4000015            CORBA::Long rsvCJLen = strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo.length();
//D4000015
//D4000015            /*===== find reserved controlJobID for specified portGroup =====*/
//D4000015            objectIdentifier eqpControlJobID;
//D4000015
//D4000015            for ( i=0; i < rsvCJLen; i++ )
//D4000015            {
//D4000015                if ( 0 == CIMFWStrCmp(strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[i].portGroupID,
//D4000015                                      portGroupID) )
//D4000015                {
//D4000015                    PPT_METHODTRACE_V1("","in-parm's portGroup is found in reservedControlJobInfo...");
//D4000015
//D4000015                    eqpControlJobID = strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[i].controlJobID;
//D4000015
//D4000015                    /*---------------------------*/
//D4000015                    /*   Get ControlJob Object   */
//D4000015                    /*---------------------------*/
//D4000015                    PPT_METHODTRACE_V1("","Get ControlJob Object...");
//D4000015
//D4000015                    PosControlJob_var aReserveControlJob;
//D4000015                    PPT_CONVERT_CONTROLJOBID_TO_CONTROLJOB_OR( aReserveControlJob,
//D4000015                                                               eqpControlJobID,
//D4000015                                                               strEquipment_reservedControlJobID_Get_out,
//D4000015                                                               equipment_reservedControlJobID_Get );
//D4000015
//D4000015                    /*-------------------------------------------*/
//D4000015                    /*   Get PosStartCassetteInfoSequence Info   */
//D4000015                    /*-------------------------------------------*/
//D4000015                    PosStartCassetteInfoSequence*    startCassetteInfo = NULL;
//D4000015                    PosStartCassetteInfoSequence_var startCassetteInfoVar;
//D4000015
//D4000015                    try
//D4000015                    {
//D4000015                        startCassetteInfo    = aReserveControlJob->getStartCassetteInfo();
//D4000015                        startCassetteInfoVar = startCassetteInfo;
//D4000015                    }
//D4000015                    CATCH_AND_RAISE_EXCEPTIONS(PosControlJob::getStartCassetteInfo);
//D4000015
//D4000015                    cjCastCnt = (*startCassetteInfo).length();
//D4000015                    PPT_METHODTRACE_V2("","controlJob's cassetteCount = ",cjCastCnt);
//D4000015
//D4000015                    PPT_METHODTRACE_V1("","break!!");
//D4000015                    break;
//D4000015                }
//D4000015            }
//D4000015
//D4000015            /*===== compare reserved controlJobID vs cassette's controlJobID =====*/
//D4000015            if ( 0 != CIMFWStrCmp(saveControlJobID.identifier, eqpControlJobID.identifier) )
//D4000015            {
//D4000015                PPT_METHODTRACE_V1("","compare reserved controlJobID vs cassette's controlJobID");
//D4000015
//D4000015                SET_MSG_RC( strCassette_CheckConditionForOperationForInternalBuffer_out,
//D4000015                            MSG_CAST_PORT_CTRLJOB_UNMATCH,
//D4000015                            RC_CAST_PORT_CTRLJOB_UNMATCH );
//D4000015
//D4000015                return RC_CAST_PORT_CTRLJOB_UNMATCH;
//D4000015            }
//D4000015
//D4000015            /*===== compare reserved controlJobID vs cassette's controlJobID =====*/
//D4000015            if ( 0 != CIMFWStrCmp(saveControlJobID.identifier, eqpControlJobID.identifier) )
//D4000015            {
//D4000015                PPT_METHODTRACE_V1("","compare reserved controlJobID vs cassette's controlJobID");
//D4000015
//D4000015                SET_MSG_RC( strCassette_CheckConditionForOperationForInternalBuffer_out,
//D4000015                            MSG_CAST_PORT_CTRLJOB_UNMATCH,
//D4000015                            RC_CAST_PORT_CTRLJOB_UNMATCH );
//D4000015
//D4000015                return RC_CAST_PORT_CTRLJOB_UNMATCH;
//D4000015            }
//D4000015
//D4000015            /*===== check reserved controlJobID's cassette count vs in-parm's cassette count =====*/
//D4000015            if ( 0 < CIMFWStrLen(saveControlJobID.identifier) )
//D4000015            {
//D4000015                PPT_METHODTRACE_V1("","check reserved controlJobID's cassette count vs in-parm's cassette count");
//D4000015
//D4000015                lenCassette = strStartCassette.length();
//D4000015                if ( cjCastCnt != lenCassette )
//D4000015                {
//D4000015                    PPT_METHODTRACE_V1("","return RC_CAST_PORT_CTRLJOB_COUNT_UNMATCH");
//D4000015                    SET_MSG_RC( strCassette_CheckConditionForOperationForInternalBuffer_out,
//D4000015                                MSG_CAST_PORT_CTRLJOB_COUNT_UNMATCH,
//D4000015                                RC_CAST_PORT_CTRLJOB_COUNT_UNMATCH );
//D4000015
//D4000015                    return RC_CAST_PORT_CTRLJOB_COUNT_UNMATCH;
//D4000015                }
//D4000015            }
//D4000015        }
//D4000015        else
//D4000015        {
//D4000015            PPT_METHODTRACE_V1("","operation != SP_Operation_OpeStart");
//D4000015        }
//D4000015 end
//D4000015        }



        /******************************************************************************************/
        /*                                                                                        */
        /*     Check Condition for maxBatchSize, minBatchSize, emptyCassetteCount                 */
        /*                                                                                        */
        /******************************************************************************************/
        PPT_METHODTRACE_V1("", "");
        PPT_METHODTRACE_V1("", "//***************************************************************");
        PPT_METHODTRACE_V1("", "//  Check Condition for maxBatchSize, minBatchSize, emptyCassetteCount");
        PPT_METHODTRACE_V1("", "//***************************************************************");

        if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart)
          || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation) )
        {
            PPT_METHODTRACE_V1("", "operation = [OpeStart] or [StartReservation]")

            /*---------------------------------------------*/
            /*   Get Equipment's Process Batch Condition   */
            /*---------------------------------------------*/
            objEquipment_processBatchCondition_Get_out strEquipment_processBatchCondition_Get_out;
            rc = equipment_processBatchCondition_Get( strEquipment_processBatchCondition_Get_out,
                                                      strObjCommonIn,
                                                      equipmentID );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "##### equipment_processBatchCondition_Get != RC_OK")
                strCassette_CheckConditionForOperationForInternalBuffer_out.strResult = strEquipment_processBatchCondition_Get_out.strResult;
                return rc;
            }

//D4000015 start   already been doing by upper logic!!
            CORBA::Long processCassetteCount = processLotCount;     //D4000015
//D4000015            CORBA::Long emptyCassetteCount   = emptyCassetteCount;
//D4000015            CORBA::Long processCassetteCount = 0;
//D4000015            CORBA::Long emptyCassetteCount   = 0;
//D4000015
//D4000015            lenCassette = strStartCassette.length();
//D4000015            for ( i=0; i < lenCassette; i++ )
//D4000015            {
//D4000015                if ( 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_ProcessLot)
//D4000015                  || 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_ProcessMonitorLot) )
//D4000015                {
//D4000015                    PPT_METHODTRACE_V1("","processCassetteCount++");
//D4000015
//D4000015                    processCassetteCount++;
//D4000015                }
//D4000015                else if ( 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) )
//D4000015                {
//D4000015                    PPT_METHODTRACE_V1("","emptyCassetteCount++");
//D4000015
//D4000015                    emptyCassetteCount++;
//D4000015                }
//D4000015                else
//D4000015                {
//D4000015                    PPT_METHODTRACE_V1("", "else loadPurposeType");
//D4000015                }
//D4000015            }

            PPT_METHODTRACE_V2("", "processCassetteCount ---> ", processCassetteCount);
            PPT_METHODTRACE_V2("", "emptyCassetteCount -----> ", emptyCassetteCount);
            PPT_METHODTRACE_V2("", "EQP.minBatchSize -------> ", strEquipment_processBatchCondition_Get_out.minBatchSize);
            PPT_METHODTRACE_V2("", "EQP.maxBatchSize -------> ", strEquipment_processBatchCondition_Get_out.maxBatchSize);

            /*------------------------------------*/
            /*   for maxBatchSize, minBatchSize   */
            /*------------------------------------*/
            PPT_METHODTRACE_V1("", "/*------------------------------------*/");
            PPT_METHODTRACE_V1("", "/*   for maxBatchSize, minBatchSize   */");
            PPT_METHODTRACE_V1("", "/*------------------------------------*/");
//P5000043            if ( processCassetteCount >= strEquipment_processBatchCondition_Get_out.minBatchSize
//P5000043              && processCassetteCount <= strEquipment_processBatchCondition_Get_out.maxBatchSize )

            CORBA::Long processAndProcMonCount = processCassetteCount + processMonitorLotCount;              //P5000043
            PPT_METHODTRACE_V4( "", "processCassetteCount,processMonitorLotCount,SUM",                       //P5000043
                                processCassetteCount, processMonitorLotCount, processAndProcMonCount );      //P5000043

            if (( processAndProcMonCount >= strEquipment_processBatchCondition_Get_out.minBatchSize ) &&     //P5000043
                ( processAndProcMonCount <= strEquipment_processBatchCondition_Get_out.maxBatchSize ))       //P5000043
            {
 //P5000075                PPT_METHODTRACE_V1("", "processCassetteCount >= .minBatchSize and processCassetteCount <= .maxBatchSize");
                PPT_METHODTRACE_V1("", "processAndProcMonCount >= .minBatchSize and processAndProcMonCount <= .maxBatchSize");    //P5000075
                rc = RC_OK;
            }
            else
            {
                PPT_METHODTRACE_V1("","##### return RC_PROCLOTCOUNT_OUT_OF_BATCHSIZE");

                char procCnt[16];
                char minSize[16];
                char maxSize[16];
//P5000075                sprintf( procCnt, "%d", processCassetteCount );
                sprintf( procCnt, "%d", processAndProcMonCount );        //P5000075
                sprintf( minSize, "%d", strEquipment_processBatchCondition_Get_out.minBatchSize );
                sprintf( maxSize, "%d", strEquipment_processBatchCondition_Get_out.maxBatchSize );

                PPT_SET_MSG_RC_KEY3( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                     MSG_INVALID_PROCESS_BATCH_COUNT,
                                     RC_INVALID_PROCESS_BATCH_COUNT,
                                     procCnt,
//P4000259                                     minSize,
//P4000259                                     maxSize );
                                     maxSize, minSize );    //P4000259

                return RC_INVALID_PROCESS_BATCH_COUNT;
            }

            /*----------------------------*/
            /*   for emptyCassetteCount   */
            /*----------------------------*/
            PPT_METHODTRACE_V1("", "/*----------------------------*/");
            PPT_METHODTRACE_V1("", "/*   for emptyCassetteCount   */");
            PPT_METHODTRACE_V1("", "/*----------------------------*/");

//D4000015(5) start
            /*-------------------------------------------*/
            /*   Check if MonitorCreation is necessary   */
            /*-------------------------------------------*/
            PPT_METHODTRACE_V1("", "/*-------------------------------------------*/");
            PPT_METHODTRACE_V1("", "/*   Check if MonitorCreation is necessary   */");
            PPT_METHODTRACE_V1("", "/*-------------------------------------------*/");
            CORBA::Boolean bMonitorCreationFlag = FALSE;

            if ( TRUE == strEquipment_processBatchCondition_Get_out.monitorCreationFlag )
            {
                PPT_METHODTRACE_V1("", "TRUE == strEquipment_processBatchCondition_Get_out.monitorCreationFlag");
                PosLogicalRecipe_var aLogicalRecipe;

                // find filled logicalRecipe
                objectIdentifier logicalRecipeID;
                lenCassette = strStartCassette.length();
                PPT_METHODTRACE_V2("", "lenCassette--->", lenCassette);
                for ( i=0; i < lenCassette; i++ )
                {
                    CORBA::Long lenLotInCassette = strStartCassette[i].strLotInCassette.length();
                    PPT_METHODTRACE_V2("", "lenLotInCassette--->", lenLotInCassette);

                    for ( j=0; j < lenLotInCassette; j++ )
                    {
                        PPT_METHODTRACE_V2("", "logicalRecipeID--->", strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID.identifier );
                        if ( CIMFWStrLen( strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID.identifier) == 0 )
                        {
                            continue;
                        }

                        logicalRecipeID = strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID;
                        PPT_METHODTRACE_V2("", "find logicalRecipeID--->", logicalRecipeID.identifier );
                        break;
                    }
                    if ( CIMFWStrLen( logicalRecipeID.identifier ) != 0 )
                    {
                        break;
                    }
                }
                PPT_CONVERT_LOGICALRECIPEID_TO_LOGICALRECIPE_OR( aLogicalRecipe,
                                                                 logicalRecipeID,
                                                                 strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                                 cassette_CheckConditionForOperationForInternalBuffer );

                PosProductSpecification_var aMonitorProduct;
                try
                {
                    aMonitorProduct = aLogicalRecipe->getMonitorProduct() ;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::getMonitorProduct)

                if( TRUE != CORBA::is_nil(aMonitorProduct) )
                {
                    PPT_METHODTRACE_V1("","@@@@@@@@@@ MonitorCreation is necessary!");
                    bMonitorCreationFlag = TRUE;
                }
            }
//D4000015(5) end

            if ( TRUE == strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag
              && TRUE == bMonitorCreationFlag )     //D4000015(5)
//D4000015(5)                 strEquipment_processBatchCondition_Get_out.monitorCreationFlag  == TRUE )
            {
                PPT_METHODTRACE_V1("","======================================");
                PPT_METHODTRACE_V1("","cassetteExchangeFlag == TRUE");
                PPT_METHODTRACE_V1("","monitorCreationFlag  == TRUE");
                PPT_METHODTRACE_V1("","======================================");

//P5000075                if ( emptyCassetteCount == processCassetteCount + 1 )
//P5000075                {
//P5000075                    PPT_METHODTRACE_V1("","emptyCassetteCount == processCassetteCount + 1");

                //------------------------------------------------------                         //P5000075
                // ProcessLot + ProcessMonitorLot + CreateMonitorLot(+1)                         //P5000075
                //------------------------------------------------------                         //P5000075
                if ( emptyCassetteCount == processAndProcMonCount + 1 )                          //P5000075
                {                                                                                //P5000075
                    PPT_METHODTRACE_V1("","emptyCassetteCount == processAndProcMonCount + 1");   //P5000075
                    rc = RC_OK;
                }
                else
                {
                    PPT_METHODTRACE_V1("","##### return RC_INVALID_EMPTY_COUNT");
                    char v1[16];
                    char v2[16];
                    sprintf( v1, "%d", emptyCassetteCount );
                    sprintf( v2, "%d", processAndProcMonCount+1 );                               //P5000075
//P5000075                    sprintf( v2, "%d", processCassetteCount+1 );

                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                         MSG_INVALID_EMPTY_COUNT,
                                         RC_INVALID_EMPTY_COUNT,
                                         v1,
                                         v2 );

                    return RC_INVALID_EMPTY_COUNT;
                }
            }
            else if ( TRUE == strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag
                   && FALSE == bMonitorCreationFlag )       //D4000015(5)
//D4000015(5)                      strEquipment_processBatchCondition_Get_out.monitorCreationFlag  == FALSE )
            {
                PPT_METHODTRACE_V1("","======================================");
                PPT_METHODTRACE_V1("","cassetteExchangeFlag == TRUE");
                PPT_METHODTRACE_V1("","monitorCreationFlag  == FALSE");
                PPT_METHODTRACE_V1("","======================================");

//P5000075                if ( emptyCassetteCount == processCassetteCount )
//P5000075                {
//P5000075                    PPT_METHODTRACE_V1("","emptyCassetteCount == processCassetteCount");

                //------------------------------------------------------                         //P5000075
                // ProcessLot + ProcessMonitorLot                                                //P5000075
                //------------------------------------------------------                         //P5000075
                if ( emptyCassetteCount == processAndProcMonCount )                              //P5000075
                {                                                                                //P5000075
                    PPT_METHODTRACE_V1("","emptyCassetteCount == processAndProcMonCount");       //P5000075
                    rc = RC_OK;
                }
                else
                {
                    PPT_METHODTRACE_V1("","##### return RC_INVALID_EMPTY_COUNT");
                    char v1[16];
                    char v2[16];
                    sprintf( v1, "%d", emptyCassetteCount );
                    sprintf( v2, "%d", processAndProcMonCount );                                 //P5000075
//P5000075                    sprintf( v2, "%d", processCassetteCount );

                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                         MSG_INVALID_EMPTY_COUNT,
                                         RC_INVALID_EMPTY_COUNT,
                                         v1,
                                         v2 );

                    return RC_INVALID_EMPTY_COUNT;
                }
            }
            else if ( FALSE == strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag
                   && TRUE == bMonitorCreationFlag )        //D4000015(5)
//D4000015(5)                      strEquipment_processBatchCondition_Get_out.monitorCreationFlag  == TRUE )
            {
                PPT_METHODTRACE_V1("","======================================");
                PPT_METHODTRACE_V1("","cassetteExchangeFlag == FALSE");
                PPT_METHODTRACE_V1("","monitorCreationFlag  == TRUE");
                PPT_METHODTRACE_V1("","======================================");

                if ( emptyCassetteCount == 1 )
                {
                    PPT_METHODTRACE_V1("","[OK] aMonitorProduct is nil && emptyCassetteCount == 0");
                    rc = RC_OK;
                }
                else
                {
                    PPT_METHODTRACE_V1("","##### return RC_INVALID_EMPTY_COUNT");
                    char v1[16];
                    char v2[16];
                    sprintf( v1, "%d", emptyCassetteCount );
                    sprintf( v2, "%d", 1 );

                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                         MSG_INVALID_EMPTY_COUNT,
                                         RC_INVALID_EMPTY_COUNT,
                                         v1,
                                         v2 );

                    return RC_INVALID_EMPTY_COUNT;
                }
            }
            else if ( FALSE == strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag
                   && FALSE == bMonitorCreationFlag )       //D4000015(5)
//D4000015(5)                      strEquipment_processBatchCondition_Get_out.monitorCreationFlag  == FALSE )
            {
                PPT_METHODTRACE_V1("","======================================");
                PPT_METHODTRACE_V1("","cassetteExchangeFlag == FALSE");
                PPT_METHODTRACE_V1("","monitorCreationFlag  == FALSE");
                PPT_METHODTRACE_V1("","======================================");

                if ( emptyCassetteCount == 0 )
                {
                    PPT_METHODTRACE_V1("","emptyCassetteCount == 0");
                    rc = RC_OK;
                }
                else
                {
                    PPT_METHODTRACE_V1("","##### return RC_INVALID_EMPTY_COUNT");
                    char v1[16];
                    char v2[16];
                    sprintf( v1, "%d", emptyCassetteCount );
                    sprintf( v2, "%d", 0 );

                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                         MSG_INVALID_EMPTY_COUNT,
                                         RC_INVALID_EMPTY_COUNT,
                                         v1,
                                         v2 );

                    return RC_INVALID_EMPTY_COUNT;
                }
            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "----- Nothing is done -----");
        }
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");



        /******************************************************************************************/
        /*                                                                                        */
        /*     Check Condition for Eqp's MultiRecipeCapability VS RecipeParameterValue            */
        /*                                                                                        */
        /******************************************************************************************/
        PPT_METHODTRACE_V1("", "");
        PPT_METHODTRACE_V1("", "//***************************************************************");
        PPT_METHODTRACE_V1("", "//  Check Condition for Eqp's MultiRecipeCapability VS RecipeParameterValue");
        PPT_METHODTRACE_V1("", "//***************************************************************");

        if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart)
          || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation)
          || 0 == CIMFWStrCmp(operation, SP_Operation_CassetteDelivery) )   //D4000015(4)
        {
            PPT_METHODTRACE_V1("", "operation = [OpeStart] or [StartReservation] or [CassetteDelivery]")

            if ( 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_SingleRecipe)
              || 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_Batch) )
            {
                PPT_METHODTRACE_V1("", "multiRecipeCapability = [SingleRecipe] or [Batch]")
                /*-----------------------------------*/
                /*   Work Valiable for Check Logic   */
                /*-----------------------------------*/
                CORBA::Long baseSetFlag = FALSE;
                CORBA::Long baseI       = 0;
                CORBA::Long baseJ       = 0;
                CORBA::Long baseRPLen   = 0;

                /*-------------------------------*/
                /*   Loop for strStartCassette   */
                /*-------------------------------*/
                for ( i=0; i < lenCassette; i++ )
                {
                    /*------------------------*/
                    /*   Omit EmptyCassette   */
                    /*------------------------*/
                    if ( 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) )
                    {
                        PPT_METHODTRACE_V1("","strStartCassette[i].loadPurposeType == [EmptyCassette]  ...<<<continue>>>");
                        continue;
                    }

                    /*-------------------------------*/
                    /*   Loop for strLotInCassette   */
                    /*-------------------------------*/
                    CORBA::Long lenLotInCassette = strStartCassette[i].strLotInCassette.length();

                    for ( j=0; j < lenLotInCassette; j++ )
                    {
                        /*------------------------*/
                        /*   Omit Non-Start Lot   */
                        /*------------------------*/
                        if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                        {
                            PPT_METHODTRACE_V1("","strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE  ...<<<continue>>>");
                            continue;
                        }

                        /*-------------------------------------*/
                        /*   Check RecipeParameterChangeType   */
                        /*-------------------------------------*/
                        PPT_METHODTRACE_V1("","Check RecipeParameterChangeType");
                        if ( 0 != CIMFWStrCmp( strStartCassette[i].strLotInCassette[j].recipeParameterChangeType, SP_Rparm_ChangeType_ByLot ) )
                        {
                            PPT_METHODTRACE_V1("","##### return RC_INVALID_RPARM_CHANGETYPE!!");
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                 MSG_INVALID_RPARM_CHANGETYPE,
                                                 RC_INVALID_RPARM_CHANGETYPE,
                                                 strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                                 strStartCassette[i].cassetteID.identifier );
                            return RC_INVALID_RPARM_CHANGETYPE;
                        }

                        /*--------------------*/
                        /*   Save Base Info   */
                        /*--------------------*/
                        PPT_METHODTRACE_V1("","Save Base Info");
                        if ( baseSetFlag == FALSE )
                        {
                            PPT_METHODTRACE_V1("","baseSetFlag == FALSE");
                            baseSetFlag = TRUE;
                            baseI       = i;
                            baseJ       = j;

                            if ( strStartCassette[i].strLotInCassette[j].strLotWafer.length() > 0 )
                            {
                                PPT_METHODTRACE_V1("","strStartCassette[i].strLotInCassette[j].strLotWafer.length() > 0");
                                baseRPLen = strStartCassette[i].strLotInCassette[j].strLotWafer[0].strStartRecipeParameter.length();
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("","##### return RC_INVALID_CAST_XFERSTAT!!");
                                PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                     MSG_INVALID_WAFER_CNT,
                                                     RC_INVALID_WAFER_CNT,
                                                     strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                                     strStartCassette[i].cassetteID.identifier );

                                return RC_INVALID_WAFER_CNT;
                            }
                        }

                        /*--------------------------*/
                        /*   Loop for strLotWafer   */
                        /*--------------------------*/
                        PPT_METHODTRACE_V1("","Loop for strLotWafer");
                        CORBA::Long lwLen = strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                        for ( k=0; k < lwLen; k++ )
                        {
                            /*---------------------------------*/
                            /*   Check RecipeParameter Count   */
                            /*---------------------------------*/
                            CORBA::Long rpLen = strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length();

                            if ( rpLen != baseRPLen )
                            {
                                PPT_METHODTRACE_V1("","##### return RC_NOT_SAME_PRARM_INFO!!");
                                PPT_SET_MSG_RC_KEY4( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                     MSG_NOT_SAME_RPARM_INFO,
                                                     RC_NOT_SAME_RPARM_INFO,
                                                     strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                                     strStartCassette[i].cassetteID.identifier,
                                                     strStartCassette[baseI].strLotInCassette[baseJ].lotID.identifier,
                                                     strStartCassette[baseI].cassetteID.identifier );

                                return RC_NOT_SAME_RPARM_INFO;
                            }

                            /*--------------------------------------*/
                            /*   Loop for strStartRecipeParameter   */
                            /*--------------------------------------*/
                            for ( l=0 ; l < rpLen ; l++ )
                            {
                                /*-----------------------------------------------*/
                                /*   Check RecipeParameter Info is Same or Not   */
                                /*-----------------------------------------------*/
                                /*===== parameterName check (string) =====*/
                                PPT_METHODTRACE_V1("","/*===== parameterName check (string) =====*/");
                                if ( 0 != CIMFWStrCmp( strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterName, strStartCassette[baseI].strLotInCassette[baseJ].strLotWafer[0].strStartRecipeParameter[l].parameterName ) )
                                {
                                    PPT_METHODTRACE_V1("","##### return RC_NOT_SAME_RPARM_INFO!!");
                                    PPT_SET_MSG_RC_KEY4( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                         MSG_NOT_SAME_RPARM_INFO,
                                                         RC_NOT_SAME_RPARM_INFO,
                                                         strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                                         strStartCassette[i].cassetteID.identifier,
                                                         strStartCassette[baseI].strLotInCassette[baseJ].lotID.identifier,
                                                         strStartCassette[baseI].cassetteID.identifier );

                                    return RC_NOT_SAME_RPARM_INFO;
                                }

                                /*===== parameterValue check (string) =====*/
                                PPT_METHODTRACE_V1("","/*===== parameterValue check (string) =====*/");
                                if ( 0 != CIMFWStrCmp( strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterValue, strStartCassette[baseI].strLotInCassette[baseJ].strLotWafer[0].strStartRecipeParameter[l].parameterValue ) )
                                {
                                    PPT_METHODTRACE_V1("","##### return RC_NOT_SAME_RPARM_INFO!!");
                                    PPT_SET_MSG_RC_KEY4( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                         MSG_NOT_SAME_RPARM_INFO,
                                                         RC_NOT_SAME_RPARM_INFO,
                                                         strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                                         strStartCassette[i].cassetteID.identifier,
                                                         strStartCassette[baseI].strLotInCassette[baseJ].lotID.identifier,
                                                         strStartCassette[baseI].cassetteID.identifier );

                                    return RC_NOT_SAME_RPARM_INFO;
                                }

                                /*===== useCurrentSettingValueFlag check (boolean) =====*/
                                PPT_METHODTRACE_V1("","/*===== useCurrentSettingValueFlag check (boolean) =====*/");
                                if ( strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].useCurrentSettingValueFlag !=  strStartCassette[baseI].strLotInCassette[baseJ].strLotWafer[0].strStartRecipeParameter[l].useCurrentSettingValueFlag )
                                {
                                    PPT_METHODTRACE_V1("","##### return RC_NOT_SAME_RPARM_INFO!!");
                                    PPT_SET_MSG_RC_KEY4( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                         MSG_NOT_SAME_RPARM_INFO,
                                                         RC_NOT_SAME_RPARM_INFO,
                                                         strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                                         strStartCassette[i].cassetteID.identifier,
                                                         strStartCassette[baseI].strLotInCassette[baseJ].lotID.identifier,
                                                         strStartCassette[baseI].cassetteID.identifier );

                                    return RC_NOT_SAME_RPARM_INFO;
                                }
                            } //end of [l]
                        } //end of [k]
                    } //end of [j]
                } //end of [i]
            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "----- Nothing is done -----");
        }
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");



        /******************************************************************************************/
        /*                                                                                        */
        /*     Check Upper/Lower Limit for RecipeParameterChange                                  */
        /*                                                                                        */
        /******************************************************************************************/
        PPT_METHODTRACE_V1("", "");
        PPT_METHODTRACE_V1("", "//***************************************************************");
        PPT_METHODTRACE_V1("", "//  Check Upper/Lower Limit for RecipeParameterChange");
        PPT_METHODTRACE_V1("", "//***************************************************************");

        if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart)
          || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation)
          || 0 == CIMFWStrCmp(operation, SP_Operation_CassetteDelivery) )   //D4000015(4)
        {
            PPT_METHODTRACE_V1("", "operation = [OpeStart] or [StartReservation] or [CassetteDelivery]")

            /*---------------------------------*/
            /*   Check StartRecipeParameters   */
            /*---------------------------------*/
            PPT_METHODTRACE_V2("", "lenCassette ---> ", lenCassette);
            for ( i=0; i < lenCassette; i++ )
            {
                PPT_METHODTRACE_V3("", "StartCassette-------------------------------round [i]", i, strStartCassette[i].cassetteID.identifier);
                /*------------------------*/
                /*   Omit EmptyCassette   */
                /*------------------------*/
                if ( 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) )
                {
                    PPT_METHODTRACE_V1("","strStartCassette[i].loadPurposeType == [EmptyCassette]  ...<<<continue>>>");
                    continue;
                }

                /*-------------------------------*/
                /*   Loop for strLotInCassette   */
                /*-------------------------------*/
                CORBA::Long lenLotInCassette = strStartCassette[i].strLotInCassette.length();
                PPT_METHODTRACE_V2("", "lenLotInCassette ---> ", lenLotInCassette);

                for ( j=0; j < lenLotInCassette; j++ )
                {
                    PPT_METHODTRACE_V3("", "LotInCassette-----------------------------------round [j]", j,
                                                strStartCassette[i].strLotInCassette[j].lotID.identifier);
                    /*------------------------*/
                    /*   Omit Non-Start Lot   */
                    /*------------------------*/
                    if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("","strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE  ...<<<continue>>>");
                        continue;
                    }

//D8000024 add start
                    CORBA::Boolean skipFlag = FALSE;
                    CORBA::Boolean paramCheckWithFPC = FALSE;
                    objLot_effectiveFPCInfo_Get_out strLot_effectiveFPCInfo_Get_out;
                    rc = lot_effectiveFPCInfo_Get( strLot_effectiveFPCInfo_Get_out, strObjCommonIn,
                                                   SP_FPC_ExchangeType_StartReserveInfo,
                                                   equipmentID,
                                                   strStartCassette[i].strLotInCassette[j].lotID );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_effectiveFPCInfo_Get() != RC_OK", rc);
                        strCassette_CheckConditionForOperationForInternalBuffer_out.strResult =
                            strLot_effectiveFPCInfo_Get_out.strResult;
                        return rc;
                    }
                    paramCheckWithFPC = strLot_effectiveFPCInfo_Get_out.recipeParameterActionRequired;
//D8000024 add end

                    PPT_METHODTRACE_V1("", "call PPT_CONVERT_EQPID_TO_MACHINE_OR");
                    PosMachine_var aMachine;
                    PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine, equipmentID,
                                                     strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                     cassette_CheckConditionForOperationForInternalBuffer );

                    PPT_METHODTRACE_V1("", "call PPT_CONVERT_LOGICALRECIPEID_TO_LOGICALRECIPE_OR");
                    PosLogicalRecipe_var aLogicalRecipe;
                    PPT_CONVERT_LOGICALRECIPEID_TO_LOGICALRECIPE_OR( aLogicalRecipe,
                                                                     strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID,
                                                                     strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                                     cassette_CheckConditionForOperationForInternalBuffer );

                    PPT_METHODTRACE_V1("", "call PPT_CONVERT_RECIPEID_TO_MACHINERECIPE_OR");
                    PosMachineRecipe_var aMachineRecipe;
//D7000042          PPT_CONVERT_RECIPEID_TO_MACHINERECIPE_OR( aMachineRecipe,
//D7000042                                                    strStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID,
//D7000042                                                    strCassette_CheckConditionForOperationForInternalBuffer_out,
//D7000042                                                    cassette_CheckConditionForOperationForInternalBuffer );

//D6000415          PPT_METHODTRACE_V1("", "call aLogicalRecipe->findRecipeParametersFor");
//D6000415 add start
                    /************************/
                    /*   Get subLotType     */
                    /************************/
                    PosLot_var aLot ; //DSIV00001443
                    CORBA::String_var subLotType;
                    if( 0 == CIMFWStrLen( strStartCassette[i].strLotInCassette[j].subLotType ) )
                    {
//DSIV00001443                        PosLot_var aLot ;
                        PPT_CONVERT_LOTID_TO_LOT_OR( aLot,
                                                     strStartCassette[i].strLotInCassette[j].lotID,
                                                     strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                     cassette_CheckConditionForOperationForInternalBuffer);

                        try
                        {
                            subLotType = aLot->getSubLotType();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType);
                    }
                    else
                    {
                        subLotType = strStartCassette[i].strLotInCassette[j].subLotType;
                    }
//D6000415 add end
                    if( searchCondition == 1 )                                                                        //DSIV00001443
                    {                                                                                                 //DSIV00001443
                        if( CORBA::is_nil(aLot) == TRUE )                                                             //DSIV00001443
                        {                                                                                             //DSIV00001443
                            PPT_CONVERT_LOTID_TO_LOT_OR( aLot,                                                        //DSIV00001443
                                                         strStartCassette[i].strLotInCassette[j].lotID,               //DSIV00001443
                                                         strCassette_CheckConditionForOperationForInternalBuffer_out, //DSIV00001443
                                                         cassette_CheckConditionForOperationForInternalBuffer);       //DSIV00001443
                        }                                                                                             //DSIV00001443
                        try                                                                                           //DSIV00001443
                        {                                                                                             //DSIV00001443
                            aMachineRecipe = aLogicalRecipe->findMachineRecipeFor( aLot, aMachine );                  //DSIV00001443
                        }                                                                                             //DSIV00001443
                        CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeFor)                            //DSIV00001443
                    }                                                                                                 //DSIV00001443
                    else                                                                                              //DSIV00001443
                    {                                                                                                 //DSIV00001443
//D7000042 add start
                        try
                        {
                            aMachineRecipe = aLogicalRecipe->findMachineRecipeForSubLotType( aMachine, subLotType );
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeForSubLotType)
//D7000042 add end
                    }                                                                                                 //DSIV00001443
//D8000024 add start
                    if( CORBA::is_nil(aMachineRecipe) == TRUE &&
                        strLot_effectiveFPCInfo_Get_out.machineRecipeActionRequired == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "MachineRecipe is overwritten by FPC");
                        skipFlag = TRUE;
                    }

//D8000024 add end
                    PosRecipeParameterSequence* aRecipeParameters = NULL;
//D8000024 add start
                    if( skipFlag == FALSE && paramCheckWithFPC == FALSE )
                    {
//D8000024 add end
//PSN000062207 add start
                        if( CORBA::is_nil(aMachineRecipe) )
                        {
                            PPT_METHODTRACE_V1("", "aMachineRecipe is nil");
                            SET_MSG_RC( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                        MSG_NOT_FOUND_MCRECIPE,
                                        RC_NOT_FOUND_MCRECIPE );
                            return RC_NOT_FOUND_MCRECIPE;
                        }
//PSN000062207 add end
                        try
                        {
//D6000415                  aRecipeParameters = aLogicalRecipe->findRecipeParametersFor( aMachine, aMachineRecipe );
                            aRecipeParameters = aLogicalRecipe->findRecipeParametersForSubLotType( aMachine, aMachineRecipe, subLotType );    //D6000415
                        }
//D6000415              CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::findRecipeParametersFor)
//PSN000062207                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::findRecipeParametersForSubLotType)    //D6000415
                        CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findRecipeParametersForSubLotType)                     //PSN000062207
                    }    //D8000024
                    PosRecipeParameterSequence_var aTmpRecipeParametersVar = aRecipeParameters;

//D8000024 add start
                    if( paramCheckWithFPC == FALSE )
                    {
                        PPT_METHODTRACE_V1("","Recipe Parameter Check with SM Information.");
//D8000024 add end
                        CORBA::Long lenParams = aRecipeParameters->length();
                        PPT_METHODTRACE_V2("", "lenParams ---> ", lenParams);
                        for ( k=0; k < lenParams; k++ )
                        {
                            PPT_METHODTRACE_V2("", "PosRecipeParameterSequence--------------------------round [k]", k);
                            PPT_METHODTRACE_V1("", "");
                            PPT_METHODTRACE_V2("", "aRecipeParameters->parameterName ------->", (*aRecipeParameters)[k].parameterName);
                            PPT_METHODTRACE_V2("", "aRecipeParameters->unit----------------->", (*aRecipeParameters)[k].unit);
                            PPT_METHODTRACE_V2("", "aRecipeParameters->dataType------------->", (*aRecipeParameters)[k].dataType);
                            PPT_METHODTRACE_V2("", "aRecipeParameters->defaultValue--------->", (*aRecipeParameters)[k].defaultValue);
                            PPT_METHODTRACE_V2("", "aRecipeParameters->lowerLimit----------->", (*aRecipeParameters)[k].lowerLimit);
                            PPT_METHODTRACE_V2("", "aRecipeParameters->upperLimit----------->", (*aRecipeParameters)[k].upperLimit);
//D9000001                            PPT_METHODTRACE_V2("", "aRecipeParameters->useCurrentValueFlag-->", (long)(*aRecipeParameters)[k].useCurrentValueFlag);
                            PPT_METHODTRACE_V2("", "aRecipeParameters->useCurrentValueFlag-->", (int)(*aRecipeParameters)[k].useCurrentValueFlag); //D9000001
                            PPT_METHODTRACE_V1("", "");

                            if ( 0 == CIMFWStrCmp( (*aRecipeParameters)[k].dataType, SP_DCDef_Val_String) )
                            {
                                PPT_METHODTRACE_V1("", "########## dataType is SP_DCDef_Val_String  ...<<<continue>>>");
                                continue;
                            }

                            /*----------------------------------------------------*/
                            /* Find strStartRecipeParameter from strStartCassette */
                            /*----------------------------------------------------*/
                            CORBA::Long lenLotWafer = strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                            PPT_METHODTRACE_V2("", "lenLotWafer ---> ", lenLotWafer);
                            for ( l=0; l < lenLotWafer; l++ )
                            {
                                PPT_METHODTRACE_V3("", "lenLotWafer---------------------------------------------round [l]", l,
                                                            strStartCassette[i].strLotInCassette[j].strLotWafer[l].waferID.identifier);

                                CORBA::Long lenRecipeParam = strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter.length();
                                PPT_METHODTRACE_V2("", "lenRecipeParam ---> ", lenRecipeParam);
                                for ( m=0; m < lenRecipeParam; m++ )
                                {
                                    PPT_METHODTRACE_V3("", "lenRecipeParam----------------------------------------------round [m]", m,
                                                strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterName);

                                    PPT_METHODTRACE_V2("", "    StartCassette.parameterValue------->", strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue);
                                    PPT_METHODTRACE_V2("", "    StartCassette.targetValue---------->", strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].targetValue);
//D9000001                                    PPT_METHODTRACE_V2("", "    StartCassette.useCurrentValueFlag-->", (long)strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].useCurrentSettingValueFlag);
                                    PPT_METHODTRACE_V2("", "    StartCassette.useCurrentValueFlag-->", (int)strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].useCurrentSettingValueFlag); //D9000001

                                    if ( 0 == CIMFWStrCmp(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterName,
                                                          (*aRecipeParameters)[k].parameterName) )
                                    {
                                        PPT_METHODTRACE_V2("", "### found ###  Same Parameter Name!!", (*aRecipeParameters)[k].parameterName);

                                        if ( TRUE == (*aRecipeParameters)[k].useCurrentValueFlag )
                                        {
                                            PPT_METHODTRACE_V1("", "TRUE == (*aRecipeParameters)[k].useCurrentValueFlag");

                                            if ( 0 < CIMFWStrLen(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue) )
                                            {
                                                PPT_METHODTRACE_V1("", "##### 0 < CIMFWStrLen(parameterValue)");
                                                PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                                    MSG_INVALID_PARAMETERVALUE_MUST_BE_NULL,
                                                                    RC_INVALID_PARAMETERVALUE_MUST_BE_NULL,
                                                                    (*aRecipeParameters)[k].parameterName );

                                                return RC_INVALID_PARAMETERVALUE_MUST_BE_NULL;
                                            }
                                            else
                                            {
                                                PPT_METHODTRACE_V1("", "parameterValue = NULL ---> <<<<< Check OK!! >>>>>");
                                            }
                                        }
                                        else
                                        {
                                            PPT_METHODTRACE_V1("", "FALSE == (*aRecipeParameters)[k].useCurrentValueFlag");

//P4200398 start
                                            if ( 0 == CIMFWStrCmp( (*aRecipeParameters)[k].dataType, SP_DCDef_Val_Integer) )
                                            {
                                                PPT_METHODTRACE_V1("", "########## dataType is SP_DCDef_Val_Integer");
//P5100030 start
                                                CORBA::Boolean bIsLong = TRUE;
                                                errno = 0;
                                                char *endptr;
                                                long nResult = strtol(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue, &endptr, 10);
                                                PPT_METHODTRACE_V2("", "nResult", nResult);
                                                if ( ERANGE == errno )
                                                {
                                                    // overflow or underflow
                                                    PPT_METHODTRACE_V1("", "bIsLong = FALSE");
                                                    bIsLong = FALSE;
                                                }
                                                else if ( strlen(endptr) == 0 )
                                                {
                                                    // The character which can be recognized as a numerical value
                                                    PPT_METHODTRACE_V1("", "bIsLong = TRUE");
                                                    bIsLong = TRUE;
                                                }
                                                else
                                                {
                                                    // // The character which cannot be recognized as a numerical value
                                                    PPT_METHODTRACE_V1("", "bIsLong = FALSE");
                                                    bIsLong = FALSE;
                                                }
//P5100030 end

                                                CORBA::Long parameterValue, lowerLimit, upperLimit;
//D9000001                                                sscanf(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue, "%ld", &parameterValue);
//D9000001                                                sscanf((*aRecipeParameters)[k].lowerLimit, "%ld", &lowerLimit);
//D9000001                                                sscanf((*aRecipeParameters)[k].upperLimit, "%ld", &upperLimit);

                                                sscanf(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue, "%d", &parameterValue); //D9000001
                                                sscanf((*aRecipeParameters)[k].lowerLimit, "%d", &lowerLimit); //D9000001
                                                sscanf((*aRecipeParameters)[k].upperLimit, "%d", &upperLimit); //D9000001

                                                if ( !bIsLong || ((parameterValue < lowerLimit) || (parameterValue > upperLimit)) ) //P5100030
//P5100030                                            if ( (parameterValue < lowerLimit) || (parameterValue > upperLimit) )
                                                {
                                                    PPT_METHODTRACE_V1("", "Limit Out!! parameterValue");
                                                    PPT_SET_MSG_RC_KEY3( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                                         MSG_INVALID_PARAMETER_VALUE_RANGE,
                                                                         RC_INVALID_PARAMETER_VALUE_RANGE,
                                                                         (*aRecipeParameters)[k].parameterName,
                                                                         (*aRecipeParameters)[k].lowerLimit,
                                                                         (*aRecipeParameters)[k].upperLimit );

                                                    return RC_INVALID_PARAMETER_VALUE_RANGE;
                                                }
                                                else
                                                {
                                                    PPT_METHODTRACE_V1("", "<<<<< Limit Check OK!! >>>>>");
                                                }
                                            }
                                            else if ( 0 == CIMFWStrCmp( (*aRecipeParameters)[k].dataType, SP_DCDef_Val_Float) )
                                            {
                                                PPT_METHODTRACE_V1("", "########## dataType is SP_DCDef_Val_Float");
                                                CORBA::Double parameterValue, lowerLimit, upperLimit;
                                                sscanf(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue, "%lf", &parameterValue);
                                                sscanf((*aRecipeParameters)[k].lowerLimit, "%lf", &lowerLimit);
                                                sscanf((*aRecipeParameters)[k].upperLimit, "%lf", &upperLimit);
                                                if ( (parameterValue < lowerLimit) || (parameterValue > upperLimit) )
                                                {
                                                    PPT_METHODTRACE_V1("", "Limit Out!! parameterValue");
                                                    PPT_SET_MSG_RC_KEY3( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                                         MSG_INVALID_PARAMETER_VALUE_RANGE,
                                                                         RC_INVALID_PARAMETER_VALUE_RANGE,
                                                                         (*aRecipeParameters)[k].parameterName,
                                                                         (*aRecipeParameters)[k].lowerLimit,
                                                                         (*aRecipeParameters)[k].upperLimit );

                                                    return RC_INVALID_PARAMETER_VALUE_RANGE;
                                                }
                                                else
                                                {
                                                    PPT_METHODTRACE_V1("", "<<<<< Limit Check OK!! >>>>>");
                                                }
                                            }
//P4200398 end
//P4200398                                        if ( atol(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue)
//P4200398                                           < atol((*aRecipeParameters)[k].lowerLimit) ||
//P4200398                                             atol(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue)
//P4200398                                           > atol((*aRecipeParameters)[k].upperLimit) )
//P4200398                                        {
//P4200398                                            PPT_METHODTRACE_V1("", "##### Limit Out!! parameterValue");
//P4200398                                            PPT_SET_MSG_RC_KEY3( strCassette_CheckConditionForOperationForInternalBuffer_out,
//P4200398                                                                 MSG_INVALID_PARAMETER_VALUE_RANGE,
//P4200398                                                                 RC_INVALID_PARAMETER_VALUE_RANGE,
//P4200398                                                                 (*aRecipeParameters)[k].parameterName,
//P4200398                                                                 (*aRecipeParameters)[k].lowerLimit,
//P4200398                                                                 (*aRecipeParameters)[k].upperLimit );
//P4200398
//P4200398                                            return RC_INVALID_PARAMETER_VALUE_RANGE;
//P4200398                                        }
//P4200398                                        else
//P4200398                                        {
//P4200398                                            PPT_METHODTRACE_V1("", "<<<<< Limit Check OK!! >>>>>");
//P4200398                                        }
                                        }
                                    }
                                } //end of [m]
                            } //end of [l]
                        } //end of [k]
//D8000024 add start
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","Recipe Parameter Check with FPC Information.");

                        //Following logic is based on paramCheckWithFPC == FALSE case.

                        /*----------------------------------------------------*/
                        /* Find strStartRecipeParameter from strStartCassette */
                        /*----------------------------------------------------*/
                        CORBA::Long lenLotWafer = strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                        PPT_METHODTRACE_V2("", "lenLotWafer ---> ", lenLotWafer);
                        for ( l=0; l < lenLotWafer; l++ )
                        {
                            PPT_METHODTRACE_V3("", "lenLotWafer---------------------------------------------round [l]", l,
                                                        strStartCassette[i].strLotInCassette[j].strLotWafer[l].waferID.identifier);

                            //FPC Wafer Matching
                            objectIdentifier  tmpWaferID;
                            tmpWaferID = strStartCassette[i].strLotInCassette[j].strLotWafer[l].waferID;
                            CORBA::Long  fpcWaferCount = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList.length();
                            PPT_METHODTRACE_V2("","FPCInfo waferCount", fpcWaferCount);
                            CORBA::Long  wPos = 0;
                            for(wPos = 0; wPos < fpcWaferCount; wPos++)
                            {
                                if( 0 == CIMFWStrCmp(tmpWaferID.identifier, strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].waferID.identifier) )
                                {
                                    PPT_METHODTRACE_V1("","wafer found in FPCInfo");
                                    break;
                                }
                            }
                            if( wPos == fpcWaferCount )
                            {
                                PPT_METHODTRACE_V2("","wafer not found in FPCInfo.", tmpWaferID.identifier);
                                SET_MSG_RC( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                            MSG_FPC_WAFER_MISMATCH_IN_FPC_GROUP,
                                            RC_FPC_WAFER_MISMATCH_IN_FPC_GROUP );

                                return RC_FPC_WAFER_MISMATCH_IN_FPC_GROUP;
                            }
                            //FPC Wafer Matching END. use wPos.

                            CORBA::Long lenRecipeParam = strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter.length();
                            PPT_METHODTRACE_V2("", "lenRecipeParam ---> ", lenRecipeParam);
                            for ( m=0; m < lenRecipeParam; m++ )
                            {
                                PPT_METHODTRACE_V3("", "lenRecipeParam----------------------------------------------round [m]", m,
                                            strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterName);

                                PPT_METHODTRACE_V2("", "    StartCassette.parameterValue------->", strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue);
                                PPT_METHODTRACE_V2("", "    StartCassette.targetValue---------->", strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].targetValue);
//D9000001                                PPT_METHODTRACE_V2("", "    StartCassette.useCurrentValueFlag-->", (long)strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].useCurrentSettingValueFlag);
                                PPT_METHODTRACE_V2("", "    StartCassette.useCurrentValueFlag-->", (int)strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].useCurrentSettingValueFlag); //D9000001

                                //FPC RecipeParam Matching
                                CORBA::String_var  fpcParamName = strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterName;
                                CORBA::Long  fpcRParamCount = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList.length();
                                PPT_METHODTRACE_V2("","FPCInfo RParamCount", fpcRParamCount);
                                CORBA::Long  pPos = 0;
                                for(pPos = 0; pPos < fpcRParamCount; pPos++)
                                {
                                    if( 0 == CIMFWStrCmp(fpcParamName, strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList[pPos].parameterName) )
                                    {
                                        PPT_METHODTRACE_V1("","recipeParam found in FPCInfo.");
                                        break;
                                    }
                                }
                                if( pPos == fpcRParamCount )
                                {
                                    PPT_METHODTRACE_V2("","recipeParam not found in FPCinfo.", fpcParamName);
                                    SET_MSG_RC( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                MSG_FPC_RECIPEPARM_ERROR, RC_FPC_RECIPEPARM_ERROR);

                                    return RC_FPC_RECIPEPARM_ERROR;
                                }
                                CORBA::String_var  fpcParamUnit          = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList[pPos].parameterUnit;
                                CORBA::String_var  fpcParamDataType      = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList[pPos].parameterDataType;
                                CORBA::String_var  fpcParamLowerLimit    = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList[pPos].parameterLowerLimit;
                                CORBA::String_var  fpcParamUpperLimit    = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList[pPos].parameterUpperLimit;
                                CORBA::Boolean  fpcUseCurrentSettingFlag = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList[pPos].useCurrentSettingValueFlag;
                                CORBA::String_var  fpcParamTargetValue   = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList[pPos].parameterTargetValue;
                                CORBA::String_var  fpcParamValue         = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList[pPos].parameterValue;
                                CORBA::String_var  fpcParamTag           = strLot_effectiveFPCInfo_Get_out.strFPCInfo.strLotWaferInfoList[wPos].strRecipeParameterInfoList[pPos].parameterTag;
                                //FPC RecipeParam Matching END.

                                if ( 0 == CIMFWStrCmp( fpcParamDataType, SP_DCDef_Val_String) )
                                {
                                    PPT_METHODTRACE_V1("", "########## dataType is SP_DCDef_Val_String  ...<<<continue>>>");
                                    continue;
                                }

                                if ( TRUE == fpcUseCurrentSettingFlag )
                                {
                                    PPT_METHODTRACE_V1("", "FPC useCurrentSettingValueFlag is TRUE");

                                    if ( 0 < CIMFWStrLen(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue) )
                                    {
                                        PPT_METHODTRACE_V1("", "##### 0 < CIMFWStrLen(parameterValue)");
                                        PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                            MSG_INVALID_PARAMETERVALUE_MUST_BE_NULL,
                                                            RC_INVALID_PARAMETERVALUE_MUST_BE_NULL,
                                                            fpcParamName );

                                        return RC_INVALID_PARAMETERVALUE_MUST_BE_NULL;
                                    }
                                    else
                                    {
                                        PPT_METHODTRACE_V1("", "parameterValue = NULL ---> <<<<< Check OK!! >>>>>");
                                    }
                                }
                                else
                                {
                                    PPT_METHODTRACE_V1("", "FPC useCurrentSettingValueFlag is FALSE");

                                    if ( 0 == CIMFWStrCmp( fpcParamDataType, SP_DCDef_Val_Integer) )
                                    {
                                        PPT_METHODTRACE_V1("", "########## dataType is SP_DCDef_Val_Integer");
                                        CORBA::Boolean bIsLong = TRUE;
                                        errno = 0;
                                        char *endptr = NULL;
                                        long nResult = strtol(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue, &endptr, 10);
                                        PPT_METHODTRACE_V2("", "nResult", nResult);
                                        if ( ERANGE == errno )
                                        {
                                            // overflow or underflow
                                            PPT_METHODTRACE_V1("", "bIsLong = FALSE");
                                            bIsLong = FALSE;
                                        }
                                        else if ( strlen(endptr) == 0 )
                                        {
                                            // The character which can be recognized as a numerical value
                                            PPT_METHODTRACE_V1("", "bIsLong = TRUE");
                                            bIsLong = TRUE;
                                        }
                                        else
                                        {
                                            // // The character which cannot be recognized as a numerical value
                                            PPT_METHODTRACE_V1("", "bIsLong = FALSE");
                                            bIsLong = FALSE;
                                        }

                                        CORBA::Long parameterValue = 0;
                                        CORBA::Long lowerLimit     = 0;
                                        CORBA::Long upperLimit     = 0;
//D9000001                                        sscanf(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue, "%ld", &parameterValue);
//D9000001                                        sscanf(fpcParamLowerLimit, "%ld", &lowerLimit);
//D9000001                                        sscanf(fpcParamUpperLimit, "%ld", &upperLimit);

                                        sscanf(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue, "%d", &parameterValue); //D9000001
                                        sscanf(fpcParamLowerLimit, "%d", &lowerLimit); //D9000001
                                        sscanf(fpcParamUpperLimit, "%d", &upperLimit); //D9000001

                                        if ( !bIsLong || ((parameterValue < lowerLimit) || (parameterValue > upperLimit)) )
                                        {
                                            PPT_METHODTRACE_V1("", "Limit Out!! parameterValue");
                                            PPT_SET_MSG_RC_KEY3( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                                 MSG_INVALID_PARAMETER_VALUE_RANGE,
                                                                 RC_INVALID_PARAMETER_VALUE_RANGE,
                                                                 fpcParamName,
                                                                 fpcParamLowerLimit,
                                                                 fpcParamUpperLimit );

                                            return RC_INVALID_PARAMETER_VALUE_RANGE;
                                        }
                                        else
                                        {
                                            PPT_METHODTRACE_V1("", "<<<<< Limit Check OK!! >>>>>");
                                        }
                                    }
                                    else if ( 0 == CIMFWStrCmp( fpcParamDataType, SP_DCDef_Val_Float) )
                                    {
                                        PPT_METHODTRACE_V1("", "########## dataType is SP_DCDef_Val_Float");
                                        CORBA::Double parameterValue = 0.0;
                                        CORBA::Double lowerLimit     = 0.0;
                                        CORBA::Double upperLimit     = 0.0;
                                        sscanf(strStartCassette[i].strLotInCassette[j].strLotWafer[l].strStartRecipeParameter[m].parameterValue, "%lf", &parameterValue);
                                        sscanf(fpcParamLowerLimit, "%lf", &lowerLimit);
                                        sscanf(fpcParamUpperLimit, "%lf", &upperLimit);
                                        if ( (parameterValue < lowerLimit) || (parameterValue > upperLimit) )
                                        {
                                            PPT_METHODTRACE_V1("", "Limit Out!! parameterValue");
                                            PPT_SET_MSG_RC_KEY3( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                                 MSG_INVALID_PARAMETER_VALUE_RANGE,
                                                                 RC_INVALID_PARAMETER_VALUE_RANGE,
                                                                 fpcParamName,
                                                                 fpcParamLowerLimit,
                                                                 fpcParamUpperLimit );

                                            return RC_INVALID_PARAMETER_VALUE_RANGE;
                                        }
                                        else
                                        {
                                            PPT_METHODTRACE_V1("", "<<<<< Limit Check OK!! >>>>>");
                                        }
                                    }
                                }
                            } //end of [m]
                        } //end of [l]
                    }
//D8000024 add end
                } //end of [j]
            } //end of [i]
        }
        else
        {
            PPT_METHODTRACE_V1("", "----- Nothing is done -----");
        }
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");



        /******************************************************************************************/
        /*                                                                                        */
        /*     Check MonitorLotCount and OperationStartLotCount                                   */
        /*                                                                                        */
        /******************************************************************************************/
        PPT_METHODTRACE_V1("", "");
        PPT_METHODTRACE_V1("", "//***************************************************************");
        PPT_METHODTRACE_V1("", "//  Check MonitorLotCount and OperationStartLotCount");
        PPT_METHODTRACE_V1("", "//***************************************************************");

        if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart)
          || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation)
          || 0 == CIMFWStrCmp(operation, SP_Operation_CassetteDelivery) )   //D4000015(4)
        {
            PPT_METHODTRACE_V1("", "operation = [OpeStart] or [StartReservation] or [CassetteDelivery]")

            CORBA::Long nStartLotCnt = 0;
            CORBA::Long nMonitorLotCnt = 0;

            /*-------------------------------*/
            /*   Loop for strStartCassette   */
            /*-------------------------------*/
            lenCassette = strStartCassette.length();
            PPT_METHODTRACE_V2("", "lenCassette--->", lenCassette);

            for ( i=0; i < lenCassette; i++ )
            {
                PPT_METHODTRACE_V3("","------------------------------round [i]", i, strStartCassette[i].loadPurposeType);

                if ( 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_ProcessLot)
                  || 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_ProcessMonitorLot) )
                {
                    PPT_METHODTRACE_V1("","loadPurposeType = [ProcessLot] or [ProcessMonitorLot]");

                    /*-------------------------------*/
                    /*   Loop for strLotInCassette   */
                    /*-------------------------------*/
                    CORBA::Long lenLotInCassette = strStartCassette[i].strLotInCassette.length();
                    PPT_METHODTRACE_V2("", "lenLotInCassette--->", lenLotInCassette);

                    for ( j=0; j < lenLotInCassette; j++ )
                    {
                        if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == TRUE )
                        {
                            PPT_METHODTRACE_V1("","strStartCassette[i].strLotInCassette[j].operationStartFlag == TRUE");
                            nStartLotCnt++;
//P4200533 Remove and Following Logic was Nested                        }

                            if ( strStartCassette[i].strLotInCassette[j].monitorLotFlag == TRUE )
                            {
                                PPT_METHODTRACE_V1("","strStartCassette[i].strLotInCassette[j].monitorLotFlag == TRUE");
                                nMonitorLotCnt++;
                            }
                        }       //P4200533
                    } //end of [j]
                }
            } //end of [i]

            if ( nMonitorLotCnt > 1 )
            {
                PPT_METHODTRACE_V1("", "##### nMonitorLotCnt > 1");
                SET_MSG_RC(strCassette_CheckConditionForOperationForInternalBuffer_out, MSG_INVALID_PROCMONITOR_COUNT, RC_INVALID_PROCMONITOR_COUNT);
                return RC_INVALID_PROCMONITOR_COUNT;
            }

            if ( nMonitorLotCnt == 1 && nStartLotCnt == 1 )
            {
                char strStatrLotCnt[16];
                sprintf(strStatrLotCnt, "%ld", nStartLotCnt);

                PPT_METHODTRACE_V1("", "##### nMonitorLotCnt == 1 && nStartLotCnt == 1");
                PPT_SET_MSG_RC_KEY3(strCassette_CheckConditionForOperationForInternalBuffer_out,
                                    MSG_INVALID_INPUT_LOT_COUNT,
                                    RC_INVALID_INPUT_LOT_COUNT,
                                    strStatrLotCnt,
                                    "2",
                                    "n");
                return RC_INVALID_INPUT_LOT_COUNT;
            }

//D4200122 start
            if ( 0 == nStartLotCnt )
            {
                PPT_METHODTRACE_V1("", "##### return RC_INVALID_INPUT_LOT_COUNT");
                PPT_SET_MSG_RC_KEY3( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                     MSG_INVALID_INPUT_LOT_COUNT,
                                     RC_INVALID_INPUT_LOT_COUNT,
                                     "0",
                                     "1",
                                     "n" );
                return( RC_INVALID_INPUT_LOT_COUNT );
            }
//D4200122 end

            //P4200533 add start
            //-----------------------------------------------------------//
            //                                                           //
            //   Final Check for LoadPurposeType:ProcessMonitorLot       //
            //                                                           //
            //   The lot, which meets fhe following conditions must be   //
            //   exist, and its lot count must be 1.                     //
            //      - OpeStartFlag   : TRUE                              //
            //      - LotType        : ProcessMonitor                    //
            //      - MonitorLotFlag : TRUE                              //
            //                                                           //
            //-----------------------------------------------------------//
            CORBA::Long    i_cast = 0;
            CORBA::Long    cassetteLen = strStartCassette.length();

            for ( i_cast = 0; i_cast < cassetteLen; i_cast++ )
            {
                PPT_METHODTRACE_V3("", "strStartCassette Info", strStartCassette[i_cast].cassetteID.identifier,
                                    strStartCassette[i_cast].loadPurposeType );

                if (CIMFWStrCmp( strStartCassette[i_cast].loadPurposeType,
                                 SP_LoadPurposeType_ProcessMonitorLot ) ==0 )
                {
                    PPT_METHODTRACE_V2( "", "loadPurposeType is ProcessMonitorLot", i_cast )

                    if ( nMonitorLotCnt != 1 )
                    {
                        PPT_METHODTRACE_V2( "", "nMonitorLotCnt != 1", nMonitorLotCnt );
                        SET_MSG_RC(strCassette_CheckConditionForOperationForInternalBuffer_out,
                                   MSG_INVALID_PROCMONITOR_COUNT, RC_INVALID_PROCMONITOR_COUNT);
                        return( RC_INVALID_PROCMONITOR_COUNT );
                    }

                    CORBA::Long    j_lot = 0;
                    CORBA::Long    lotLen = strStartCassette[i_cast].strLotInCassette.length();

                    for ( j_lot = 0 ; j_lot < lotLen ; j_lot++ )
                    {
                        if (( strStartCassette[i_cast].strLotInCassette[j_lot].monitorLotFlag     == TRUE )&&
                            ( strStartCassette[i_cast].strLotInCassette[j_lot].operationStartFlag == TRUE ))
                        {
                            PPT_METHODTRACE_V3( "", "LotID & LotType", strStartCassette[i_cast].strLotInCassette[j_lot].lotID.identifier,
                                                                       strStartCassette[i_cast].strLotInCassette[j_lot].lotType );

                            if ( CIMFWStrCmp(strStartCassette[i_cast].strLotInCassette[j_lot].lotType,
                                             SP_Lot_Type_ProductionMonitorLot ) != 0 )
                            {
//D5100053 Add Start
                                objLot_monitorRouteFlag_Get_out strLot_monitorRouteFlag_Get_out;

                                rc = lot_monitorRouteFlag_Get(strLot_monitorRouteFlag_Get_out,
                                                              strObjCommonIn,
                                                              strStartCassette[i_cast].strLotInCassette[j_lot].lotID);
                                if ( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V1("","lot_monitorRouteFlag_Get() != RC_OK");
                                    strCassette_CheckConditionForOperationForInternalBuffer_out.strResult = strLot_monitorRouteFlag_Get_out.strResult;
                                    return ( rc );
                                }

                                PPT_METHODTRACE_V2( "", "monitorRoute_Flag =", strLot_monitorRouteFlag_Get_out.monitorRoute_Flag );

                                if ( strLot_monitorRouteFlag_Get_out.monitorRoute_Flag == FALSE )
                                {
                                    PPT_METHODTRACE_V1( "", "Specified Lot Type is not ProductionMonitorLot" );
                                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
                                                         MSG_INVALID_LOT_TYPE, RC_INVALID_LOT_TYPE,
                                                         strStartCassette[i_cast].strLotInCassette[j_lot].lotType,
                                                         strStartCassette[i_cast].strLotInCassette[j_lot].lotID.identifier );
                                    return( RC_INVALID_LOT_TYPE );
                                }
//D5100053 Add End
//D5100053                                PPT_METHODTRACE_V1( "", "Specified Lot Type is not ProductionMonitorLot" );
//D5100053                                PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOperationForInternalBuffer_out,
//D5100053                                                     MSG_INVALID_LOT_TYPE, RC_INVALID_LOT_TYPE,
//D5100053                                                     strStartCassette[i_cast].strLotInCassette[j_lot].lotType,
//D5100053                                                     strStartCassette[i_cast].strLotInCassette[j_lot].lotID.identifier );
//D5100053                                return( RC_INVALID_LOT_TYPE );
                            }

                            break;

                        }
                    }
                }
            }
            //P4200533 add end
        }
        else
        {
            PPT_METHODTRACE_V1("", "----- Nothing is done -----");
        }
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");



        /*----------------------*/
        /*                      */
        /*   Return to Caller   */
        /*                      */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cassette_CheckConditionForOperationForInternalBuffer");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_CheckConditionForOperationForInternalBuffer_out, cassette_CheckConditionForOperationForInternalBuffer, methodName)
}
