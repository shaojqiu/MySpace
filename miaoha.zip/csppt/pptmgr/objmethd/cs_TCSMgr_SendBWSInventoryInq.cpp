#ifndef lint
static char *sccsid =  "@(#) 1.4 superpos/src/spppt/source/posppt/pptmgr/objmethd/cs_TCSMgr_SendBWSInventoryInq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 2/5/08 20:35:51 [ 2/5/08 20:35:52 ]";
#endif
//
//
// SiView
// Name: cs_TCSMgr_SendBWSInventoryInq.cpp
//

#include "cs_pptmgr.hpp"
#include "cs_tcssm.hh"
#include "cs_tcsstr.hh"
#include "tcssvcmf.hh"

//[Object Function Name]: long   cs_TCSMgr_SendBWSInventoryInq
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2017/10/25  0.00      Evie Su        Initial Release, 170017
// 
//
//[Function Description]:
//
//
//[Output Parameters]:
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------

CORBA::Long CS_PPTManager_i::cs_TCSMgr_SendBWSInventoryInq(
                            csObjTCSMgr_SendBWSInventoryInq_out&      strTCSMgr_SendBWSInventoryInq_out,
                            const pptObjCommonIn&                     strObjCommonIn,
                            const csObjTCSMgr_SendBWSInventoryInq_in& strTCSMgr_SendBWSInventoryInq_in )
{
    char * methodName = NULL;
    try
    {
        objectIdentifier equipmentID = strTCSMgr_SendBWSInventoryInq_in.BWSID;
        CORBA::String_var zoneID;        
        
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_TCSMgr_SendBWSInventoryInq");
        PPT_METHODTRACE_V2( "CS_PPTManager_i::cs_TCSMgr_SendBWSInventoryInq", "in-parm's requestUserID", "pptUser");
        PPT_METHODTRACE_V2( "CS_PPTManager_i::cs_TCSMgr_SendBWSInventoryInq", "in-parm's equipmentID(BWSID)", equipmentID.identifier);
        CORBA::Long lnLen = strTCSMgr_SendBWSInventoryInq_in.strBWSZoneSeq.length();
        PPT_METHODTRACE_V2( "", "strBWSZoneSeq.length()", lnLen ); 
        for( CORBA::Long ix=0; ix<lnLen; ix++ )
        {
            zoneID = CIMFWStrDup(strTCSMgr_SendBWSInventoryInq_in.strBWSZoneSeq[ix].zoneID);
            PPT_METHODTRACE_V3( "", ix, "zoneID", zoneID );
            break;
        }
        
        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        /*---------------------------*/
        /*   Get PosMachine object   */
        /*---------------------------*/
        PosMachine_var aMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR(aMachine,equipmentID,strTCSMgr_SendBWSInventoryInq_out,TCSMgr_SendBWSInventoryInq);

        /*------------------------------------------*/
        /*   Get Host Name of TCS Service Manager   */
        /*------------------------------------------*/
        CORBA::String_var TCSHostName;
        try
        {
            TCSHostName = aMachine->getCellController();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getCellController);

        if (CIMFWStrLen(TCSHostName) == 0)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i::cs_TCSMgr_SendBWSInventoryInq", "CIMFWStrLen(TCSHostName) == 0");
            SET_MSG_RC(strTCSMgr_SendBWSInventoryInq_out,MSG_NOT_FOUND_TCS,RC_NOT_FOUND_TCS);
            return(RC_NOT_FOUND_TCS);
        }

        //---------------------------------
        //   Bind to TCS Service Manager
        //---------------------------------
        PPT_METHODTRACE_V1("", "Bind to TCS Service Manager");

        objTCSMgr_GetServiceManager_out strTCSMgr_GetServiceManager_out;
        rc = TCSMgr_GetServiceManager(strTCSMgr_GetServiceManager_out, strObjCommonIn, SP_TCS_SERVER_NAME, TCSHostName);

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "TCSMgr_GetServiceManager() rc != RC_OK");
            strTCSMgr_SendBWSInventoryInq_out.strResult = strTCSMgr_GetServiceManager_out.strResult;
            return( rc );
        }
        PPT_METHODTRACE_V2("", "TCSSvcMgr ---> ", strTCSMgr_GetServiceManager_out.TCSSvcMgr);

        CORBA::Object_var anObject;
        try
        {
#ifdef EBROKER
            anObject = SP_STRING_TO_OBJECT(strTCSMgr_GetServiceManager_out.TCSSvcMgr);
#else
            anObject = CORBA::Orbix.string_to_object(strTCSMgr_GetServiceManager_out.TCSSvcMgr);
#endif 
        }
        catch(...)
        {
            PPT_METHODTRACE_V1("", "##### CORBA::Orbix.string_to_object() raises exception");
            SET_MSG_RC(strTCSMgr_SendBWSInventoryInq_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
            return RC_SYSTEM_ERROR;
        }

        CS_TCSServiceManager_var TCSSvcMgr = CS_TCSServiceManager::_narrow(anObject);

        if ( TRUE == CORBA::is_nil(TCSSvcMgr) )
        {
            PPT_METHODTRACE_V1("", "##### TCSSvcMgr is nil");
            SET_MSG_RC(strTCSMgr_SendBWSInventoryInq_out, MSG_EXT_SERVER_NIL_OBJ, RC_EXT_SERVER_NIL_OBJ);
            return(RC_EXT_SERVER_NIL_OBJ);
        }

        CORBA::Environment envTimeOut = SP_CORBAENV_DEFENV;   

        CORBA::String_var timeOutValue = CIMFWStrDup(getenv(SP_TX_Timeout_TCS));

        PPT_METHODTRACE_V2("","timeOutValue ---> ",timeOutValue);

        if ( 0 < CIMFWStrLen(timeOutValue) )
        {
            PPT_METHODTRACE_V1("", "setting timeout!!");
            envTimeOut.timeout(atol(timeOutValue) * 1000);
        }

        /*-------------------------*/
        /*   Send Request to TCS   */
        /*-------------------------*/
        tcsBWSInventoryInqResult*    results = NULL;
        tcsBWSInventoryInqResult_var resultsVar;

        pptUser tmpRequestUser = strObjCommonIn.strUser;

        CORBA::String_var configFlag = CIMFWStrDup( getenv(SP_USER_ID_PASSWORD_CONFIGRATION) );
        PPT_METHODTRACE_V2("","SP_USER_ID_PASSWORD_CONFIGRATION ", configFlag);

        if( 0 == CIMFWStrCmp( configFlag, "1" ) )
        {
            PPT_METHODTRACE_V1("","SP_USER_ID_PASSWORD_CONFIGRATION=1");

            tmpRequestUser.userID.identifier = CIMFWStrDup( getenv(SP_TCS_USER_ID) );
            tmpRequestUser.password          = CIMFWStrDup( getenv(SP_TCS_USER_PASSWORD) );
        }

        PPT_METHODTRACE_V2("","userID   ", tmpRequestUser.userID.identifier);
        PPT_METHODTRACE_V2("","password ", tmpRequestUser.password);

        try
        {
            results = TCSSvcMgr->CS_TxTCSBWSInventoryInq(tmpRequestUser, equipmentID, zoneID, envTimeOut);
            resultsVar = results;
        }
        catch(const CORBA::SystemException &SysEx)
        {
            PPT_METHODTRACE_V1("", "CORBA::SystemException caught");
            APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
            SET_MSG_RC( strTCSMgr_SendBWSInventoryInq_out, MSG_TCS_NO_RESPONSE, RC_TCS_NO_RESPONSE );
            try
            {
                externalServerList.remove((char *)TCSHostName);
            }
            catch( ... )
            {
                PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
            }
            return( RC_TCS_NO_RESPONSE );
        }
        catch( ... )
        {
            PPT_METHODTRACE_V1("", "Unknown exception caught");
            APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ( );
            SET_MSG_RC( strTCSMgr_SendBWSInventoryInq_out, MSG_TCS_NO_RESPONSE, RC_TCS_NO_RESPONSE );
            try
            {
                externalServerList.remove((char *)TCSHostName);
            }
            catch( ... )
            {
                PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
            }
            return( RC_TCS_NO_RESPONSE );
        }

        /*-------------------------------------------*/
        /*   Display                                 */
        /*-------------------------------------------*/


        /*-------------------------------------------*/
        /*   Set Return Value and Return to Caller   */
        /*-------------------------------------------*/
        strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo = results->strBWSInventoryInfo;
        strTCSMgr_SendBWSInventoryInq_out.strResult           = results->strResult;

        rc = atoi(strTCSMgr_SendBWSInventoryInq_out.strResult.returnCode);

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_TCSMgr_SendBWSInventoryInq");
        return ( rc );
    }
    CATCH_GLOBAL_EXCEPTIONS(strTCSMgr_SendBWSInventoryInq_out, cs_TCSMgr_SendBWSInventoryInq, methodName);
}
