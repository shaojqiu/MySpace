#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/emptyCassette_CheckCategoryForOperation.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:40:38 [ 7/13/07 19:40:39 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: emptyCassette_CheckCategoryForOperation.cpp
//

#include "cs_pptmgr.hpp"

#include "pcas.hh"
#include "pprsp.hh"  //INN-R170002


//[Object Function Name]: long   emptyCassette_CheckCategoryForOperation
//
// Date        Level        Author         Note
// ----------  -----------  -------------  -------------------------------------------
// 2006-04-03  D7000041     K.Matsuei      Initial Release
//
// Innotron Modification history :
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/09/30 INN-R170002 JJ.Zhang       Contamination Control
//
//[Function Description]:
//  If InParam's StartCassette has EmptyCarrier,
//     It investigates whether EmptyCarrier is valid category with NextOperation of Lot.
//
//[Input Parameters]:
//  in  pptObjCommonIn              strObjCommonIn;
//  in  sequence <pptStartCassette> strStartCassette;
//
//[Output Parameters]:
//  out objEmptyCassette_CheckCategoryForOperation_out   strEmptyCassette_CheckCategoryForOperation_out;
//
//  typedef struct objEmptyCassette_CheckCategoryForOperation_out_struct {
//      pptRetCode                  strResult;
//  } objEmptyCassette_CheckCategoryForOperation_out;
//
//[Return Value]:
//  Return Code                    Messsage ID
//  ------------------------------ ------------------------------------------------
//  RC_OK                          MSG_OK
//  RC_CASSETTE_CATEGORY_MISMATCH  MSG_CASSETTE_CATEGORY_MISMATCH
//

CORBA::Long CS_PPTManager_i::emptyCassette_CheckCategoryForOperation(
                            objEmptyCassette_CheckCategoryForOperation_out& strEmptyCassette_CheckCategoryForOperation_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const pptStartCassetteSequence& strStartCassette )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::emptyCassette_CheckCategoryForOperation");

        CORBA::Long rc = RC_OK;

        CORBA::Long nCastLen = strStartCassette.length();
        PPT_METHODTRACE_V2("", "nCastLen", nCastLen);

        //-------------------------------------------------------
        // Check whether StartCassette has EmptyCassette.
        //-------------------------------------------------------
        PPT_METHODTRACE_V1("", "Check whether StartCassette has EmptyCassette");
        CORBA::Boolean bExistEmpty = FALSE;
        for ( CORBA::Long i=0; i < nCastLen; i++ )
        {
            PPT_METHODTRACE_V2("", "cassetteID", strStartCassette[i].cassetteID.identifier);

            objCassette_CheckEmpty_out strCassette_CheckEmpty_out;
            rc = cassette_CheckEmpty( strCassette_CheckEmpty_out, strObjCommonIn, strStartCassette[i].cassetteID );
            if ( rc != RC_OK && rc != RC_CAST_NOT_EMPTY )
            {
                PPT_METHODTRACE_V2("", "cassette_CheckEmpty() != RC_OK and RC_CAST_NOT_EMPTY", rc);
                strEmptyCassette_CheckCategoryForOperation_out.strResult = strCassette_CheckEmpty_out.strResult;
                return( rc );
            }

            if ( rc == RC_OK )
            {
                PPT_METHODTRACE_V1("", "Cassette is Empty");
                bExistEmpty = TRUE;
                break;
            }
        } //end of [i]

        if ( !bExistEmpty )
        {
            PPT_METHODTRACE_EXIT("PPTManager_i::emptyCassette_CheckCategoryForOperation");
            return RC_OK;
        }

        //-----------------------------------------
        // Check category of EmptyCassette.
        //-----------------------------------------
        PPT_METHODTRACE_V1("", "Check category of EmptyCassette");

        objectIdentifierSequence alreadyCheckedEmptyCastSeq;
        alreadyCheckedEmptyCastSeq.length( nCastLen );
        CORBA::Long nCheckedEmptyCast = 0;

        for ( i=0; i < nCastLen; i++ )
        {
            PPT_METHODTRACE_V2("", "cassetteID", strStartCassette[i].cassetteID.identifier);

            CORBA::Long nLotInCas = strStartCassette[i].strLotInCassette.length();
            for ( CORBA::Long j=0; j < nLotInCas; j++ )
            {
                PPT_METHODTRACE_V2("", "lotID", strStartCassette[i].strLotInCassette[j].lotID.identifier);

                // It checkes only about first Lot in Cassette.
                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == TRUE )
                {
                    PPT_METHODTRACE_V1("", "operationStartFlag is TRUE");

                    // Get Lot's next operation category.
                    objLot_requiredCassetteCategory_GetForNextOperation_out strLot_requiredCassetteCategory_GetForNextOperation_out;
                    rc = lot_requiredCassetteCategory_GetForNextOperation( strLot_requiredCassetteCategory_GetForNextOperation_out,
                                                                           strObjCommonIn,
                                                                           strStartCassette[i].strLotInCassette[j].lotID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_requiredCassetteCategory_GetForNextOperation() != RC_OK", rc);
                        strEmptyCassette_CheckCategoryForOperation_out.strResult = strLot_requiredCassetteCategory_GetForNextOperation_out.strResult;
                        return( rc );
                    }
                    PPT_METHODTRACE_V2("", "nextRequiredCassetteCategory", strLot_requiredCassetteCategory_GetForNextOperation_out.nextRequiredCassetteCategory);

                    if ( 0 == CIMFWStrLen(strLot_requiredCassetteCategory_GetForNextOperation_out.nextRequiredCassetteCategory) )
                    {
                        PPT_METHODTRACE_V1("", "nextRequiredCassetteCategory is not specified");
                        continue;
                    }

//INN-R170002 Add Start
                    PosProductSpecification_var aProductSpecification;
                    PPT_CONVERT_PRODUCTID_TO_PRODUCTSP_OR( aProductSpecification,
                                                           strStartCassette[i].strLotInCassette[j].productID,
                                                           strEmptyCassette_CheckCategoryForOperation_out,
                                                           emptyCassette_CheckCategoryForOperation );
                    CORBA::String_var strReqUsageType;
                    SI_PPT_USERDATA_GET_STRING( aProductSpecification, CS_S_PROD_CarrierUsageType, strReqUsageType );
//INN-R170002 Add End

                    CORBA::Boolean bFoundMatchCategory = FALSE;
                    CORBA::Boolean bFoundMatchUsageType = FALSE; //INN-R170002
                    for ( CORBA::Long k=0; k < nCastLen; k++ )
                    {
                        CORBA::Boolean bAlreadyChecked = FALSE;
                        for ( CORBA::Long m=0; m < nCheckedEmptyCast; m++ )
                        {
                            if ( 0 == CIMFWStrCmp(alreadyCheckedEmptyCastSeq[m].identifier, strStartCassette[k].cassetteID.identifier) )
                            {
                                bAlreadyChecked = TRUE;
                                break;
                            }
                        } //end of [m]
                        if ( bAlreadyChecked )
                        {
                            PPT_METHODTRACE_V2("", "The carrier was already checked", strStartCassette[k].cassetteID.identifier);
                            continue;
                        }

                        if ( 0 == CIMFWStrCmp(strStartCassette[k].loadPurposeType, SP_LoadPurposeType_EmptyCassette) )
                        {
                            PosCassette_var aPosCassette;
                            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aPosCassette,
                                                                   strStartCassette[k].cassetteID,
                                                                   strEmptyCassette_CheckCategoryForOperation_out,
                                                                   emptyCassette_CheckCategoryForOperation );
                            CORBA::String_var emptyCastCategory;
                            try
                            {
                                emptyCastCategory = aPosCassette->getCassetteCategory();
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getCassetteCategory)
                            PPT_METHODTRACE_V2("", "emptyCastCategory", emptyCastCategory);

//INN-R170002 Add Start
                            CORBA::String_var strCarrierUsageType;
                            SI_PPT_USERDATA_GET_STRING( aPosCassette, CS_M_CAST_UsageType, strCarrierUsageType );
                            PPT_METHODTRACE_V2("", "strCarrierUsageType", strCarrierUsageType );

                            if ( 0 <  CIMFWStrLen(strReqUsageType) && 0 < CIMFWStrLen(strCarrierUsageType)
                              && 0 != CIMFWStrCmp(strCarrierUsageType, strReqUsageType ) )
                            {
                                PPT_METHODTRACE_V2("", "Usage Type not match", strReqUsageType);
                                bFoundMatchUsageType = FALSE;
                                continue;
                            }
                            bFoundMatchUsageType = TRUE;
//INN-R170002 Add End
                            if ( 0 == CIMFWStrCmp(emptyCastCategory, strLot_requiredCassetteCategory_GetForNextOperation_out.nextRequiredCassetteCategory) )
                            {
                                PPT_METHODTRACE_V1("", "Found same category EmptyCarrier");
                                bFoundMatchCategory = TRUE;
                                alreadyCheckedEmptyCastSeq[nCheckedEmptyCast] = strStartCassette[k].cassetteID;
                                nCheckedEmptyCast++;
                                break;
                            }
                        }
                    } //end of [k]

//INN-R170002 Add Start
                    if ( !bFoundMatchUsageType )
                    {
                        PPT_METHODTRACE_V2("", "Not found Usage Type", strReqUsageType);
                        CS_PPT_SET_MSG_RC_KEY2( strEmptyCassette_CheckCategoryForOperation_out,
                                                CS_MSG_CARRIER_USAGE_TYPE_MISMATCH,
                                                CS_RC_CARRIER_USAGE_TYPE_MISMATCH,
                                                strReqUsageType,
                                                strStartCassette[i].strLotInCassette[j].lotID.identifier );
                        return CS_RC_CARRIER_USAGE_TYPE_MISMATCH;
                    }
//INN-R170002 Add End
                    if ( !bFoundMatchCategory )
                    {
                        PPT_METHODTRACE_V1("", "##### return RC_CASSETTE_CATEGORY_MISMATCH");
                        SET_MSG_RC( strEmptyCassette_CheckCategoryForOperation_out, MSG_CASSETTE_CATEGORY_MISMATCH, RC_CASSETTE_CATEGORY_MISMATCH );
                        return RC_CASSETTE_CATEGORY_MISMATCH;
                    }

                    PPT_METHODTRACE_V1("", "Found match EmptyCarrier!!");
                    break;
                }
            } //end of [j]
        } //end of [i]

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::emptyCassette_CheckCategoryForOperation");

        return( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS(strEmptyCassette_CheckCategoryForOperation_out, emptyCassette_CheckCategoryForOperation, methodName)
}

