//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
//
// SiView
// Name: cs_APC_LithoContextInfo_Get.cpp
//

#include "cs_pptmgr.hpp"


// Class: CS_PPTManager
//
// [Object Function Name]: long   cs_APC_LithoContextInfo_Get.cpp
//
//
// Innotron Modification History:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/09/26 INN-R170009 Nick Tsai      Get Context Info for APC data preparation
//
// Function Description:
//
// Input Parameters:
//    csObjAPC_LithoContextInfo_Get_out&       strObjAPC_LithoContextInfo_Get_out,
//    const pptObjCommonIn&                    strObjCommonIn,
//    const csObjAPC_LithoContextInfo_Get_in&  strObjAPC_LithoContextInfo_Get_in
//
// typedef struct csObjAPC_LithoContextInfo_Get_in_struct {
//     objectIdentifier            equipmentID;
//     objectIdentifier            lotID;
//     objectIdentifier            routeID;
//     string                      operationNumber;
//     string                      action;
//     any                         siInfo;
// }csObjAPC_LithoContextInfo_Get_in;
//
//
// Output Parameters:
// typedef struct csObjAPC_LithoContextInfo_Get_out_struct {
//     pptRetCode                      strResult;
//     csAPCLithoContextInfo           strAPCLithoContextInfo;
//     any                             siInfo;
// }csObjAPC_LithoContextInfo_Get_out;
//
//
// Return Value:
//
// Exception:
//
// Pseudo code:
//


CORBA::Long CS_PPTManager_i::cs_APC_LithoContextInfo_Get (
    csObjAPC_LithoContextInfo_Get_out&       strObjAPC_LithoContextInfo_Get_out,
    const pptObjCommonIn&                    strObjCommonIn,
    const csObjAPC_LithoContextInfo_Get_in&  strObjAPC_LithoContextInfo_Get_in
)
{
    char * methodName = NULL;
    CORBA::Long rc = RC_OK;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_APC_LithoContextInfo_Get");
        //================================================================//
        //   Print input parameters                                       //
        //================================================================//
        PPT_METHODTRACE_V2("", "action ",           strObjAPC_LithoContextInfo_Get_in.action);
        PPT_METHODTRACE_V2("", "equipmentID ",      strObjAPC_LithoContextInfo_Get_in.equipmentID.identifier);
        PPT_METHODTRACE_V2("", "lotID ",            strObjAPC_LithoContextInfo_Get_in.lotID.identifier);
        PPT_METHODTRACE_V2("", "routeID ",          strObjAPC_LithoContextInfo_Get_in.routeID.identifier);
        PPT_METHODTRACE_V2("", "operationNumber ",  strObjAPC_LithoContextInfo_Get_in.operationNumber);

        //================================================================//
        //   Check input parameters                                       //
        //================================================================//
        if ( CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_RESV_RECOMMEND ) != 0 &&
             CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_OPST_RECOMMEND ) != 0 &&
             CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_USED           ) != 0 &&
             CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_METROLOGY      ) != 0   )
        {
            PPT_METHODTRACE_V1("","action is invalid");
            SET_MSG_RC( strObjAPC_LithoContextInfo_Get_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        if ( CIMFWStrLen ( strObjAPC_LithoContextInfo_Get_in.equipmentID.identifier) == 0 )
        {
            PPT_METHODTRACE_V1("","CIMFWStrLen ( strObjAPC_LithoContextInfo_Get_in.equipmentID.identifier) == 0");
            PPT_SET_MSG_RC_KEY( strObjAPC_LithoContextInfo_Get_out, MSG_NOT_FOUND_EQP, RC_NOT_FOUND_EQP, "*******" );
            return RC_NOT_FOUND_EQP;
        }

        if ( CIMFWStrLen ( strObjAPC_LithoContextInfo_Get_in.lotID.identifier) == 0 )
        {
            PPT_METHODTRACE_V1("","CIMFWStrLen ( strObjAPC_LithoContextInfo_Get_in.lotID.identifier) == 0");
            PPT_SET_MSG_RC_KEY( strObjAPC_LithoContextInfo_Get_out, MSG_NOT_FOUND_LOT, RC_NOT_FOUND_LOT, "*******" );
            return RC_NOT_FOUND_LOT;
        }

        objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
        rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out, strObjCommonIn, strObjAPC_LithoContextInfo_Get_in.lotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_currentOperationInfo_Get() != RC_OK", rc);
            strObjAPC_LithoContextInfo_Get_out.strResult = strLot_currentOperationInfo_Get_out.strResult;
            return( rc );
        }
        PPT_METHODTRACE_V2("", "Current RouteID",           strLot_currentOperationInfo_Get_out.routeID.identifier  );
        PPT_METHODTRACE_V2("", "Current OperationNumber",   strLot_currentOperationInfo_Get_out.operationNumber     );

        if ( CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.routeID.identifier, strLot_currentOperationInfo_Get_out.routeID.identifier ) != 0 ||
             CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.operationNumber,    strLot_currentOperationInfo_Get_out.operationNumber    ) != 0    )
        {
            PPT_METHODTRACE_V1("","input route/operationNumber are different with current route/operationNumber");
            SET_MSG_RC( strObjAPC_LithoContextInfo_Get_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        csAPCLithoContextInfo strAPCLithoContextInfo;
        //================================================================//
        //   controlJobType                                               //
        //================================================================//
        if ( CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_RESV_RECOMMEND ) == 0 ||
             CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_RESV_RECOMMEND ) == 0 ||
             CIMFWStrCmp ( strObjAPC_LithoContextInfo_Get_in.action, CS_APC_COMBINE_FLAG_ACTION_USED           ) == 0   )   //???
        {
            strAPCLithoContextInfo.controlJobType = CIMFWStrDup ( CS_APC_CONTROLJOB_TYPE_LITHO_RECOMMEND );
            PPT_METHODTRACE_V2("", "controlJobType = ", strAPCLithoContextInfo.controlJobType );
        }
        else
        {   // ???
            strAPCLithoContextInfo.controlJobType = CIMFWStrDup ( CS_APC_CONTROLJOB_TYPE_OL_METROLOGY );
            PPT_METHODTRACE_V2("", "controlJobType = ", strAPCLithoContextInfo.controlJobType );

            strAPCLithoContextInfo.controlJobType = CIMFWStrDup ( CS_APC_CONTROLJOB_TYPE_CD_METROLOGY );
            PPT_METHODTRACE_V2("", "controlJobType = ", strAPCLithoContextInfo.controlJobType );
        }

        //================================================================//
        //   transactionID   (LOT_IDYYYYmmddHHMMSS)                       //
        //================================================================//
        PPT_METHODTRACE_V2("", "lotID = ",           strObjAPC_LithoContextInfo_Get_in.lotID.identifier );
        PPT_METHODTRACE_V2("", "reportTimeStamp = ", strObjCommonIn.strTimeStamp.reportTimeStamp        );
        char arrReportTimeStamp[256];
        memset ( arrReportTimeStamp, '\0', sizeof (arrReportTimeStamp) );
        CIMFWStrCpy ( arrReportTimeStamp, strObjCommonIn.strTimeStamp.reportTimeStamp );

        CORBA::Long lIDLen = CIMFWStrLen(strObjAPC_LithoContextInfo_Get_in.lotID.identifier) + CIMFWStrLen(arrReportTimeStamp);
        PPT_METHODTRACE_V2("", "lIDLen = ", lIDLen );

        CORBA::String_var varTransactionID = CORBA::string_alloc ( lIDLen );

        CIMFWStrCpy ( varTransactionID, strObjAPC_LithoContextInfo_Get_in.lotID.identifier );
        PPT_METHODTRACE_V2("", "varTransactionID(LOT_ID) = ", varTransactionID );

        char* pReportTimeStamp = arrReportTimeStamp ;
        CIMFWStrnCat ( varTransactionID, pReportTimeStamp, 4 );   //YYYY
        pReportTimeStamp = pReportTimeStamp +5 ;
        PPT_METHODTRACE_V2("", "varTransactionID(YYYY) = ", varTransactionID );

        CIMFWStrnCat ( varTransactionID, pReportTimeStamp, 2 );   //mm
        pReportTimeStamp = pReportTimeStamp +3 ;
        PPT_METHODTRACE_V2("", "varTransactionID(mm) = ",   varTransactionID );

        CIMFWStrnCat ( varTransactionID, pReportTimeStamp, 2 );   //dd
        pReportTimeStamp = pReportTimeStamp +3 ;
        PPT_METHODTRACE_V2("", "varTransactionID(dd) = ",   varTransactionID );

        CIMFWStrnCat ( varTransactionID, pReportTimeStamp, 2 );   //HH
        pReportTimeStamp = pReportTimeStamp +3 ;
        PPT_METHODTRACE_V2("", "varTransactionID(HH) = ",   varTransactionID );

        CIMFWStrnCat ( varTransactionID, pReportTimeStamp, 2 );   //MM
        pReportTimeStamp = pReportTimeStamp +3 ;
        PPT_METHODTRACE_V2("", "varTransactionID(MM) = ",   varTransactionID );

        CIMFWStrnCat ( varTransactionID, pReportTimeStamp, 2 );   //SS
        pReportTimeStamp = pReportTimeStamp +3 ;
        PPT_METHODTRACE_V2("", "varTransactionID(SS) = ",   varTransactionID );

        strAPCLithoContextInfo.transactionID = varTransactionID;
        PPT_METHODTRACE_V2("", "transactionID = ",   strAPCLithoContextInfo.transactionID );


/*


======================== transactionID ========================
strAPCLithoRecommendContextInfo.transactionID               = LotID+yyyymmddhhmmss  (reportedTimeStamp, ex : LOTID00001.0120170905230812 )

======================== lotID ========================
strAPCLithoRecommendContextInfo.lotID                       = strLotInCassette.lotID

======================== lotType ========================
strAPCLithoRecommendContextInfo.lotType                     = P|E|M
===> strLotInCassette.lotType  (Lot Type : P:Production | E:Engineering | M:Monitor)  //For other lot type, such as Dummy. Confirm later.

======================== partID ========================
strAPCLithoRecommendContextInfo.partID                      = strLotInCassette.productID

======================== layer ========================
strAPCLithoRecommendContextInfo.layer                       = layer
PO = PosLot -> getProcessOperation(),
layer = PO -> getPhotoLayer()

======================== routeGroup ========================
strAPCLithoRecommendContextInfo.routeGroup                  = get route user data ( S_MAINPD_RouteGroup )

======================== reticleID ========================
strAPCLithoRecommendContextInfo.reticleID                   = "RETICLE1" or "RETICLE1 RETICLE2" <-- if double exposure
for ( strLotInCassette.startRecipe.strStartReticle.reticleID )
    ==> conbime reticleIDs to a string "RETICLE1 RETICLE2", separated reticleID by space

======================== processEquipmentType ========================
strAPCLithoRecommendContextInfo.processEquipmentType        = get equipmentID type user data (S_EQPTYPE_ProcessEquipmentType)

======================== processEquipmentID ========================
strAPCLithoRecommendContextInfo.processEquipmentID          = equipmentID

======================== reworkLotFlag ========================
strAPCLithoRecommendContextInfo.reworkLotFlag =             = TRUE|FALSE
for ( strLotInCassette.strLotWafer )
    convert WAFERID to WAFER
    reworkCount = aPosWafer -> getReworkCount( route + operationNumber );
    if ( reworkCount > 0 )
        TRUE
        break

======================== recommendMode ========================
strAPCLithoRecommendContextInfo.recommendMode               = CALCULATE|REWORK|SENDAHEAD    ( CALCULATE: 一般正常LOT, REWORK: Rework Lot, SENDAHEAD : Targeting Lot )
if action == Pilot_Reserve_Recommend or action == Pilot_OpeStart_Recommend
    SENDAHEAD
else if strAPCLithoRecommendContextInfo.reworkLotFlag == TRUE
    REWORK
else
    CALCULATE

======================== routeID ========================
strAPCLithoRecommendContextInfo.routeID                     = strLotInCassette.strStartOperationInfo.routeID

======================== operationNumber ========================
strAPCLithoRecommendContextInfo.operationNumber             = strLotInCassette.strStartOperationInfo.operationNumber

======================== parentLotID ========================
strAPCLithoRecommendContextInfo.parentLotID                 = lotFamilyID
lotFamily = lot->getLotFamily(),
lotFamilyID = lotFamily->getIdentifier()

======================== controlJobType ========================
strAPCLithoRecommendContextInfo.preToolID                   = preToolID
get cs_userData_GetByOperation(routeID, OperationNumber, S_MAINPD_OpeAPCPreOpeNo),
POS = lot ->getPO (S_MAINPD_OpeAPCPreOpeNo.value),
preToolID = POS->getAssignedMachine()

======================== sendAheadFlag ========================
strAPCLithoRecommendContextInfo.sendAheadFlag               = TRUE|FALSE
get lot user data (M_LOT_PilotFlag)
if flag == 1
    TRUE

======================== ParameterNames ========================
strAPCLithoRecommendContextInfo.ParameterNames              = "RParm1 RParm2 RParm3 ..."
for (strLotInCassette.strLotWafer[0].strStartRecipeParameter)   <-- just for the first wafer
    conbime strLotInCassette.strLotWafer[0].strStartRecipeParameter.parameterName to a string

======================== availableSubUnit ========================
strAPCLithoRecommendContextInfo.availableSubUnit            = 11|10|01|00
get chamber status of equipmentID
for ( chamber.length )
    //concat chamber status to a string,
    if chamber.status == AVAILABLE
        1           //Chamber1 == AVAILABLE >> 1, Chamber2 == AVAILABLE >> 11. Up to 2 chambers

======================== opeStartRecommendFlag ========================
strAPCLithoRecommendContextInfo.opeStartRecommendFlag
if action == OpeStart_Recommend
    TRUE

======================== feedForward1 ========================
strAPCLithoRecommendContextInfo.feedForward1                = empty

======================== feedForward2 ========================
strAPCLithoRecommendContextInfo.feedForward2                = empty

======================== feedForward3 ========================
strAPCLithoRecommendContextInfo.feedForward3                = empty

======================== feedForward4 ========================
strAPCLithoRecommendContextInfo.feedForward4                = empty

======================== extends ========================
strAPCLithoRecommendContextInfo.extends                     = empty (confirm later)
*/

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_APC_LithoContextInfo_Get");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strObjAPC_LithoContextInfo_Get_out, cs_APC_LithoContextInfo_Get, methodName)
}