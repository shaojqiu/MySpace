#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cs_controlJob_BatchSize_Check.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:40:38 [ 7/13/07 19:40:39 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_controlJob_BatchSize_Check.cpp
//

#include "cs_pptmgr.hpp"
#include "ppcopsp.hh"
//#include "cs_posconst.hpp"


//[Object Function Name]: long   cs_controlJob_BatchSize_Check
//
// Date        Level        Author         Note
// ----------  -----------  -------------  -------------------------------------------
// 2017-09-18  INN-R170014  shenql         Initial Release
//
//[Function Description]:
//  If InParam's StartCassette has EmptyCarrier,
//  It investigates whether EmptyCarrier is valid category with NextOperation of Lot.
//
//[Input Parameters]:
// in  sequence <pptStartCassette>     strStartCassette;
// in  CORBA::Boolean                  skipBatchSizeFlag;
// in  CORBA::Boolean                  skipWaferCountFlag; 
//
//[Output Parameters]:
//  csObjControlJob_BatchSize_Check_out   strObjControlJob_BatchSize_Check_out
//
//  typedef struct csObjControlJob_BatchSize_Check_out_struct{
//        pptRetCode          strResult;
//        any                 siInfo;
//    } csObjControlJob_BatchSize_Check_out;
//    typedef struct csObjControlJob_BatchSize_Check_in_struct{
//        pptStartCassetteSequence        strStartCassette;
//        CORBA::Boolean                  skipBatchSizeFlag;
//        CORBA::Boolean                  skipWaferCountFlag;
//    } csObjControlJob_BatchSize_Check_in;
//
//

CORBA::Long CS_PPTManager_i::cs_controlJob_BatchSize_Check(
                          csObjControlJob_BatchSize_Check_out&   strCJBatchSizeCheckOut,
                          const pptObjCommonIn&                   strObjCommonIn,
                          const csObjControlJob_BatchSize_Check_in&  strCJBatchSizeCheckIn)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_controlJob_BatchSize_Check");
        PPT_METHODTRACE_V2( "","strCJBatchSizeCheckIn:skipBatchSizeFlag", strCJBatchSizeCheckIn.skipBatchSizeFlag);
        PPT_METHODTRACE_V2( "","strCJBatchSizeCheckIn:skipWaferCountFlag", strCJBatchSizeCheckIn.skipWaferCountFlag);
        if (strCJBatchSizeCheckIn.skipBatchSizeFlag != true)
        {
            CORBA::Long extend_len  = 500;
            CORBA::Long t_objRefLen = extend_len;
            CORBA::Long objRefCnt   = 0;
            
            stringSequence aObjRefSeq;
            aObjRefSeq.length( t_objRefLen );
            
            CORBA::Long rc = RC_OK;
            
            CORBA::Long scLen = strCJBatchSizeCheckIn.strStartCassette.length();
            PPT_METHODTRACE_V2("", "strCJBatchSizeCheckIn.strStartCassette.length()", scLen) ;
            		
            for (CORBA::Long i = 0; i < scLen; i++)
            {
            	CORBA::Long nLen = strCJBatchSizeCheckIn.strStartCassette[i].strLotInCassette.length();
                PPT_METHODTRACE_V2("", "strCJBatchSizeCheckIn.strStartCassette[i].strLotInCassette.length()", nLen) ;
            	for (CORBA::Long j = 0; j < nLen; j++)
            	{
                    objObject_Get_out strObject_Get_out;
                    objObject_Get_in  strObject_Get_in;
                    strObject_Get_in.className = CIMFWStrDup(SP_ClassName_PosProcessOperationSpecification);
                    PPT_METHODTRACE_V2("", "csObjControlJob_BatchSize_Check_in", strCJBatchSizeCheckIn.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber) ;
                    PPT_METHODTRACE_V2("", "csObjControlJob_BatchSize_Check_in", strCJBatchSizeCheckIn.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID.identifier) ;
                    PPT_METHODTRACE_V2("", "csObjControlJob_BatchSize_Check_in", strCJBatchSizeCheckIn.strStartCassette[i].strLotInCassette[j].lotID.identifier) ;
                    strObject_Get_in.strHashedInfoSeq.length(3);
                    strObject_Get_in.strHashedInfoSeq[0].hashKey = CIMFWStrDup(SP_HashData_OPE_NO);
                    strObject_Get_in.strHashedInfoSeq[0].hashData = strCJBatchSizeCheckIn.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber;
                    strObject_Get_in.strHashedInfoSeq[1].hashKey = CIMFWStrDup(SP_HashData_PD_ID);
                    strObject_Get_in.strHashedInfoSeq[1].hashData = strCJBatchSizeCheckIn.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID.identifier;
                    strObject_Get_in.strHashedInfoSeq[2].hashKey = CIMFWStrDup(SP_HashData_PD_LEVEL);
                    strObject_Get_in.strHashedInfoSeq[2].hashData = CIMFWStrDup(SP_PD_FlowLevel_Main);
                    
                    CORBA::Long TotalwaferCount = strCJBatchSizeCheckIn.strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                    PPT_METHODTRACE_V2("", "csObjControlJob_BatchSize_Check_in.TotalwaferCount", strCJBatchSizeCheckIn.strStartCassette[i].strLotInCassette[j].strLotWafer.length()) ;
                    
                    CORBA::Long OpewetbatchsizeCount = 0;
                    CORBA::Long OpewetmainwafercountCount = 0;
                    CORBA::Long processJobExeccount = 0;
                    for (CORBA::Long n = 0; n < TotalwaferCount; n++)
                    {
                        if((strCJBatchSizeCheckIn.strStartCassette[i].strLotInCassette[j].operationStartFlag ==true) && (strCJBatchSizeCheckIn.strStartCassette[i].strLotInCassette[j].strLotWafer[n].processJobExecFlag ==true))
                        {
                            processJobExeccount++;
                        }
                    }
                    PPT_METHODTRACE_V2("", "csObjControlJob_BatchSize_Check_in.processJobExeccount",processJobExeccount) ;
                
                    rc = object_Get(strObject_Get_out,strObjCommonIn,strObject_Get_in);
                    PPT_METHODTRACE_V1("", "call object_Get(1)");
                
                    if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "object_Get() rc != RC_OK");
                        strCJBatchSizeCheckOut.strResult = strObject_Get_out.strResult;
                        return rc;
                    }
                    aObjRefSeq[objRefCnt++] = strObject_Get_out.stringifiedObjectReference;
                
                    PosProcessOperationSpecification_var aPOS;
                    PPT_CONVERT_STRING_TO_OBJECT(strObject_Get_out.stringifiedObjectReference ,aPOS, PosProcessOperationSpecification );
                    PPT_METHODTRACE_V1("", "call object_Get(2)");
                    try
                    {
                        PPT_METHODTRACE_V1("", "call object_Get(3)");
                        SI_PPT_USERDATA_GET_INTEGER(aPOS,
                                                    CS_S_MAINPD_OPE_WETBATCHSIZE,
                                                    OpewetbatchsizeCount);
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperationSpecification::getUserDataNamed);  
                    
                    try
                    {
                        PPT_METHODTRACE_V1("", "call object_Get(4)");
                        SI_PPT_USERDATA_GET_INTEGER(aPOS,
                                                    CS_S_MAINPD_OPE_WETMINWAFERCOUNT,
                                                    OpewetmainwafercountCount);
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperationSpecification::getUserDataNamed);  
                
                    PPT_METHODTRACE_V2("","cs_controlJob_BatchSize_Check:OpewetbatchsizeCount", OpewetbatchsizeCount); 
                    PPT_METHODTRACE_V2("","cs_controlJob_BatchSize_Check:OpewetmainwafercountCount", OpewetmainwafercountCount); 
                    PPT_METHODTRACE_V2("","cs_controlJob_BatchSize_Check:strStartCassette <>1", strCJBatchSizeCheckIn.strStartCassette.length()); 
                    
                    if(OpewetbatchsizeCount == 1)
                    {
                        PPT_METHODTRACE_V1("", "call object_Get(5)");
                        if(strCJBatchSizeCheckIn.strStartCassette.length() != 1)
                        {
                            PPT_METHODTRACE_V1("", "call object_Get(6)");
                            char chOpewetbatchsizeCount[10];
                            sprintf(chOpewetbatchsizeCount,"%d",OpewetbatchsizeCount);
                            PPT_METHODTRACE_V1("","cs_controlJob_BatchSize_Check:strStartCassette <>1"); 
                            CS_PPT_SET_MSG_RC_KEY1(strCJBatchSizeCheckOut, CS_MSG_INVAILD_WET_BATCH_SIZE, CS_RC_INVAILD_WET_BATCH_SIZE, chOpewetbatchsizeCount);
                            return CS_RC_INVAILD_WET_BATCH_SIZE;
                        }
                    }
                    else if(OpewetbatchsizeCount == 2 && OpewetmainwafercountCount ==0)
                    {
                        PPT_METHODTRACE_V1("", "call object_Get(7)");
                        if(strCJBatchSizeCheckIn.strStartCassette.length() != 2)
                        {
                            PPT_METHODTRACE_V1("", "call object_Get(8)");
                            char chOpewetbatchsizeCount[10];
                            sprintf(chOpewetbatchsizeCount,"%d",OpewetbatchsizeCount);
                            PPT_METHODTRACE_V1("","cs_controlJob_BatchSize_Check:strStartCassette <>2"); 
                            CS_PPT_SET_MSG_RC_KEY1(strCJBatchSizeCheckOut, CS_MSG_INVAILD_WET_BATCH_SIZE, CS_RC_INVAILD_WET_BATCH_SIZE, chOpewetbatchsizeCount);
                            return CS_RC_INVAILD_WET_BATCH_SIZE;
                        }
                    }
                    else if (OpewetbatchsizeCount == 2 && OpewetmainwafercountCount >0)
                    {
                        PPT_METHODTRACE_V1("", "call object_Get(9)");
                        if(strCJBatchSizeCheckIn.strStartCassette.length() != 2 || (TotalwaferCount <= OpewetmainwafercountCount))
                        {
                            PPT_METHODTRACE_V1("", "call object_Get(10)");
                            char chOpewetbatchsizeCount[10];
                            sprintf(chOpewetbatchsizeCount,"%d",OpewetbatchsizeCount);
                            PPT_METHODTRACE_V1("","cs_controlJob_BatchSize_Check:strStartCassette <> 2 & TotalwaferCount >= OpewetmainwafercountCount"); 
                            CS_PPT_SET_MSG_RC_KEY1(strCJBatchSizeCheckOut, CS_MSG_INVAILD_WET_BATCH_SIZE, CS_RC_INVAILD_WET_BATCH_SIZE, chOpewetbatchsizeCount);
                            return CS_RC_INVAILD_WET_BATCH_SIZE;
                        }
                    }
                    
                    if (OpewetbatchsizeCount > 0)
                    {
                        PPT_METHODTRACE_V1("", "call object_Get(11)");
                        if (strCJBatchSizeCheckIn.strStartCassette.length() != OpewetbatchsizeCount)
                        {
                            PPT_METHODTRACE_V1("", "call object_Get(12)");
                            char chOpewetbatchsizeCount[10];
                            sprintf(chOpewetbatchsizeCount,"%d",OpewetbatchsizeCount);
                            CS_PPT_SET_MSG_RC_KEY1(strCJBatchSizeCheckOut, CS_MSG_INVAILD_WET_BATCH_SIZE, CS_RC_INVAILD_WET_BATCH_SIZE, chOpewetbatchsizeCount);
                            return CS_RC_INVAILD_WET_BATCH_SIZE;
                        }
                        if  (OpewetbatchsizeCount == 2 && (strCJBatchSizeCheckIn.skipWaferCountFlag != true) )
                        {
                            PPT_METHODTRACE_V1("", "call object_Get(13)");
                            for (CORBA::Long m = 0; m < TotalwaferCount; m++)
                            {
                                if((strCJBatchSizeCheckIn.strStartCassette[i].strLotInCassette[j].operationStartFlag ==true) && (strCJBatchSizeCheckIn.strStartCassette[i].strLotInCassette[j].strLotWafer[m].processJobExecFlag ==true))
                                {
                                    processJobExeccount++;
                                }
                            }
                            PPT_METHODTRACE_V2("", "csObjControlJob_BatchSize_Check_in.processJobExeccount",processJobExeccount) ;
                            
                            if ( processJobExeccount <  OpewetmainwafercountCount)
                            {
                                PPT_METHODTRACE_V1("", "call object_Get(14)");
                                char chOpewetmainwafercountCount[10];
                                sprintf(chOpewetmainwafercountCount,"%d",OpewetmainwafercountCount);
                                CS_PPT_SET_MSG_RC_KEY1(strCJBatchSizeCheckOut, CS_MSG_INVAILD_WET_WAFER_COUNT, CS_RC_INVAILD_WET_WAFER_COUNT, chOpewetmainwafercountCount);
                                return CS_RC_INVAILD_WET_WAFER_COUNT;
                            }
                        }
                    }
                }
            }
        }
		return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCJBatchSizeCheckOut, cs_controlJob_BatchSize_Check, methodName)
}

