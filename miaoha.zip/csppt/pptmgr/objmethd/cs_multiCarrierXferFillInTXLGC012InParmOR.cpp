#ifndef lint
static char *sccsid =  "@(#) 1.5 superpos/src/spppt/source/posppt/pptmgr/objmethd/cs_multiCarrierXferFillInTXLGC012InParmOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 8/11/08 17:59:01 [ 8/11/08 17:59:03 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_multiCarrierXferFillInTXLGC012InParmOR.cpp
//

#include <time.h>

#include "cs_pptmgr.hpp"

#include "pcas.hh"

//[Object Function Name]: long   multiCarrierXferFillInTXLGC012InParm
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2000-11-09  D3000086  K.Matsuei      Initial Release
// 2000-11-24            O.Sugiyama     Modify Get Now Time 
// 2000-11-27  P3000339  S.Tokumasu     Add priority
// 2000-12-08  0.02      O.Sugiyama     Zero Fault (USTKR)
// 2001-02-14  P3100008  M.Mori         Fix multi thred
// 2002/05/27  P4100480  K.Matsuei      Size of EqpID for debug is short.
// 2002/10/03  P4200177  K.Matsuei      OpeStartCancel can not be performed in Xfer EQP to EQP.
// 2005/03/10  P6000292  K.Matsuei      EQP to EQP transfer may go fails.
// 2007/07/19  D9000001  K.Kido         64bit support.
// 2008/08/08  P9000002  K.Kido         Support reroute function for EO/SO
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/10 INN-R170003  YangXigang     Durable Management Enhancement
//
//[Function Description]:
//  Make Parameter Nulti Carrier Transfer for txMultiCarrierXferReq.
//
//[Input Parameters]:
//  in  pptObjCommonIn                    strObjCommonIn;
//  in  objectIdentifier                  equipmentID
//  in  pptStartCassetteSequence          strStartCassette;
//
//[Output Parameters]:
//
//  out objMultiCarrierXferFillInTXLGC012InParm_out  strMultiCarrierXferFillInTXLGC012InParm_out
//
//  typedef struct objMultiCarrierXferFillInTXLGC012InParm_out_struct {
//     pptRetCode                 strResult;
//     pptCarrierXferReqSequence  strCarrierXferReq;
//  } objMultiCarrierXferFillInTXLGC012InParm_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  -------------------------   --------------------------------------------------
//  RC_OK                       MSG_OK
//
// Set Output Parameter
//    CORBA::Boolean                rerouteFlag         : FALSE
//    const objectIdentifier&       carrierID           : in para strStartCassette[i].cassetteID
//    const objectIdentifier&       lotID               :
//    const char *                  zoneType            : get for in para trStartCassette[i].cassetteID
//    CORBA::Boolean                n2PurgeFlag         :
//    const objectIdentifier&       fromMachineID       : get stockerID for in para strStartCassette[i].cassetteID 
//    const objectIdentifier&       fromPortID          :
//    const char *                  toStockerGroup      :
//    const pptToMachineSequence&   strToMachine        : make sequence in para strStartCassette[i].loadPortID
//    const char *                  expectedStartTime   :
//    const char *                  expectedEndTime     : current time + 1 year (YYYYMMDDHHMMSS)
//    CORBA::Boolean                mandatoryFlag       :
//    const char *                  priority            : get for in para trStartCassette[i].cassetteID
//
//[Pseudo Code]:
//

CORBA::Long CS_PPTManager_i::multiCarrierXferFillInTXLGC012InParm(
                objMultiCarrierXferFillInTXLGC012InParm_out& strMultiCarrierXferFillInTXLGC012InParm_out,
                const pptObjCommonIn& strObjCommonIn,
                const objectIdentifier& equipmentID,
                const pptStartCassetteSequence& strStartCassette )
{
    char * methodName = NULL;
    try
    {
//P4100480        char strTrace[64];
        char strTrace[128];  //P4100480
        sprintf(strTrace, "DL@%s", (const char*)equipmentID.identifier);

        CORBA::Long rc = RC_OK;

        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::multiCarrierXferFillInTXLGC012InParm");
        PPT_METHODTRACE_V2(strTrace, "inParam [equipmentID]", equipmentID.identifier);

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        pptCarrierXferReqSequence strCarrierXferReq;
    
        CORBA::Long nLen = strStartCassette.length();
        PPT_METHODTRACE_V2(strTrace, "strStartCassette.length--->", nLen);
        strCarrierXferReq.length(nLen);
        CORBA::Long i;

        for ( i=0; i < nLen; i++ )
        {
            PPT_METHODTRACE_V2(strTrace, "rerouteFlag [i]", i);

//0.02 add start
            strCarrierXferReq[i].n2PurgeFlag    = FALSE;
            strCarrierXferReq[i].mandatoryFlag  = FALSE;
//0.02 add end

            PPT_METHODTRACE_V1(strTrace, "fromMachineID: Get Current Stocker Object By Assigned Cassette Object");
            /*---------------------------------------------------------------------------*/
            /*   fromMachineID: Get Current Stocker Object By Assigned Cassette Object   */
            /*---------------------------------------------------------------------------*/
            PosCassette_var aCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                                   strStartCassette[i].cassetteID,
                                                   strMultiCarrierXferFillInTXLGC012InParm_out,
                                                   multiCarrierXferFillInTXLGC012InParm );

            Machine_var aMachine;
            try
            {
                aMachine = aCassette->currentAssignedMachine();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::currentAssignedMachine);

//P9000002 add start
            CORBA::String_var xferStat;
            try
            {
                xferStat = aCassette->getTransportState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTransportState);
//P9000002 add end

//P4200177 start
            if ( TRUE == CORBA::is_nil( aMachine ) )
            {
                PPT_METHODTRACE_V1("", "##### aMachine is nil");
                PPT_SET_MSG_RC_KEY2( strMultiCarrierXferFillInTXLGC012InParm_out,
                                     MSG_INVALID_CAST_XFERSTAT, RC_INVALID_CAST_XFERSTAT,
                                     strStartCassette[i].cassetteID.identifier,
                                     "-" );
                return RC_INVALID_CAST_XFERSTAT;
            }
//P4200177 end

//INN-R170003 if( 0 != CIMFWStrCmp( xferStat, SP_TransState_EquipmentOut ) )    //P9000002
            if( 0 != CIMFWStrCmp( xferStat, CS_TRANS_STATE_PORT_OUT ) ) //INN-R170003 add end
            {                                                                 //P9000002
//P9000002 adjust indent below
                PPT_METHODTRACE_V2("", "xferStat = ", xferStat);
                try
                {
                    strCarrierXferReq[i].fromMachineID.identifier = aMachine->getIdentifier();
                }
                CATCH_AND_RAISE_EXCEPTIONS(Machine::getIdentifier);

                strCarrierXferReq[i].fromMachineID.stringifiedObjectReference = SP_OBJECT_TO_STRING( aMachine );

//P4200177 start
                PPT_METHODTRACE_V2("", "fromMachineID", strCarrierXferReq[i].fromMachineID.identifier);

                CORBA::Boolean bStorageFlag;
                try
                {
                    bStorageFlag = aMachine->isStorageMachine();
                }
                CATCH_AND_RAISE_EXCEPTIONS(Machine::isStorageMachine);
//D9000001            PPT_METHODTRACE_V2("", "bStorageFlag", (long)bStorageFlag);
                PPT_METHODTRACE_V2("", "bStorageFlag", (int)bStorageFlag); //D9000001

                if ( bStorageFlag == FALSE )
                {
//P6000292 start
                    PosMachine_var aEquipment;
                    aEquipment = PosMachine::_narrow(aMachine);

                    CORBA::String_var eqpCategory;
                    try
                    {
                        eqpCategory = aEquipment->getCategory();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getCategory);
                    PPT_METHODTRACE_V2("", "eqpCategory", eqpCategory);

                    pptEqpPortInfo strEqpPortInfo;

                    if ( 0 == CIMFWStrCmp(eqpCategory, SP_Mc_Category_InternalBuffer) )
                    {
                        PPT_METHODTRACE_V1("", "call equipment_portInfoForInternalBuffer_GetDR()");
                        objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
                        rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out,
                                                                        strObjCommonIn,
                                                                        strCarrierXferReq[i].fromMachineID );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2(strTrace, "##### equipment_portInfoForInternalBuffer_GetDR() != RC_OK", rc);
                            strMultiCarrierXferFillInTXLGC012InParm_out.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
                            return( rc );
                        }
                        strEqpPortInfo = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo;
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "call equipment_portInfo_GetDR()");
                        objEquipment_portInfo_GetDR_out strEquipment_portInfo_GetDR_out;
                        rc = equipment_portInfo_GetDR( strEquipment_portInfo_GetDR_out,
                                                       strObjCommonIn,
                                                       strCarrierXferReq[i].fromMachineID );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2(strTrace, "##### equipment_portInfo_GetDR() != RC_OK", rc);
                            strMultiCarrierXferFillInTXLGC012InParm_out.strResult = strEquipment_portInfo_GetDR_out.strResult;
                            return( rc );
                        }
                        strEqpPortInfo = strEquipment_portInfo_GetDR_out.strEqpPortInfo;
                    }

                    CORBA::Long lenPort = strEqpPortInfo.strEqpPortStatus.length();
                    PPT_METHODTRACE_V2(strTrace, "lenPort", lenPort);
                    for ( CORBA::Long j=0; j < lenPort; j++ )
                    {
                        if ( 0 == CIMFWStrCmp(strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier,
                                              strStartCassette[i].cassetteID.identifier) )
                        {
                            strCarrierXferReq[i].fromPortID = strEqpPortInfo.strEqpPortStatus[j].portID;
                            PPT_METHODTRACE_V2(strTrace, "Found!! fromPortID", strCarrierXferReq[i].fromPortID.identifier);
                            break;
                        }
                    }
                    if ( 0 == CIMFWStrLen(strCarrierXferReq[i].fromPortID.identifier) )
                    {
                        PPT_METHODTRACE_V1(strTrace, "##### fromPortID is null");
                        PPT_SET_MSG_RC_KEY( strMultiCarrierXferFillInTXLGC012InParm_out,
                                            MSG_NOT_FOUND_PORT, RC_NOT_FOUND_PORT,
                                            "*****" );
                        return RC_NOT_FOUND_PORT;
                    }
//P6000292 end

//P6000292                PPT_METHODTRACE_V1("", "call equipment_portInfo_Get()");
//P6000292                objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
//P6000292                rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out, strObjCommonIn, strCarrierXferReq[i].fromMachineID );
//P6000292
//P6000292                if ( rc != RC_OK )
//P6000292                {
//P6000292                    PPT_METHODTRACE_V2(strTrace, "##### equipment_portInfo_Get() != RC_OK", rc);
//P6000292                    strMultiCarrierXferFillInTXLGC012InParm_out.strResult = strEquipment_portInfo_Get_out.strResult;
//P6000292                    return( rc );
//P6000292                }
//P6000292
//P6000292                CORBA::Long lenPort = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
//P6000292                PPT_METHODTRACE_V2(strTrace, "lenPort", lenPort);
//P6000292                for ( CORBA::Long j=0; j < lenPort; j++ )
//P6000292                {
//P6000292                    if ( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier,
//P6000292                                          strStartCassette[i].cassetteID.identifier) )
//P6000292                    {
//P6000292                        strCarrierXferReq[i].fromPortID = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portID;
//P6000292                        PPT_METHODTRACE_V2(strTrace, "Found!! fromPortID", strCarrierXferReq[i].fromPortID.identifier);
//P6000292                        break;
//P6000292                    }
//P6000292                }
//P6000292                if ( 0 == CIMFWStrLen(strCarrierXferReq[i].fromPortID.identifier) )
//P6000292                {
//P6000292                    PPT_METHODTRACE_V1(strTrace, "##### fromPortID is null");
//P6000292                    PPT_SET_MSG_RC_KEY( strMultiCarrierXferFillInTXLGC012InParm_out,
//P6000292                                        MSG_NOT_FOUND_PORT, RC_NOT_FOUND_PORT,
//P6000292                                        "*****" );
//P6000292                    return RC_NOT_FOUND_PORT;
//P6000292                }
                }
//P4200177 end
            }    //P9000002

            PPT_METHODTRACE_V1(strTrace, "set carrierID");
            /*---------------*/
            /*   carrierID   */
            /*---------------*/
            strCarrierXferReq[i].carrierID = strStartCassette[i].cassetteID;

            PPT_METHODTRACE_V1(strTrace, "zoneType: Get By Cassette");
            /*-------------------------------*/
            /*   zoneType: Get By Cassette   */
            /*-------------------------------*/
            objCassette_zoneType_Get_out strCassette_zoneType_Get_out;
            rc = cassette_zoneType_Get( strCassette_zoneType_Get_out, strObjCommonIn, strStartCassette[i].cassetteID);
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1(strTrace, "cassette_zoneType_Get() rc != RC_OK");
                strMultiCarrierXferFillInTXLGC012InParm_out.strResult = strCassette_zoneType_Get_out.strResult;
                return( rc );
            }
            strCarrierXferReq[i].zoneType = strCassette_zoneType_Get_out.zoneType;
            strCarrierXferReq[i].priority = strCassette_zoneType_Get_out.priority;      //P3000339

            PPT_METHODTRACE_V1(strTrace, "strToMachine.toPortID: Set Load PortID");
            /*--------------------------------------------*/
            /*   strToMachine.toPortID: Set Load PortID   */
            /*--------------------------------------------*/
            strCarrierXferReq[i].strToMachine.length(1);
            strCarrierXferReq[i].strToMachine[0].toMachineID = equipmentID;
            strCarrierXferReq[i].strToMachine[0].toPortID = strStartCassette[i].loadPortID;
//2000.12.20 kuu add
//P4200177            strCarrierXferReq[i].fromPortID = strStartCassette[i].unloadPortID;

            PPT_METHODTRACE_V1(strTrace, "expectedEndTime: Set 1 Year After");
            /*---------------------------------------*/
            /*   expectedEndTime: Set 1 Year After   */
            /*---------------------------------------*/
//D9000001  int t;
            struct timeb t;    //D9000001
//D9000001  t = time(0);
            t.time = time(0);
//P3100008 del start
//P3100008            struct tm* currentTime = localtime(&t);
//P3100008            sprintf( scTime, "%04d%02d%02d%02d%02d%02d", // YYYYMMDDHHMMSS
//P3100008                            currentTime->tm_year + 1900 + 1,
//P3100008                            currentTime->tm_mon + 1,
//P3100008                            currentTime->tm_mday,
//P3100008                            currentTime->tm_hour,
//P3100008                            currentTime->tm_min,
//P3100008                            currentTime->tm_sec );
//P3100008            PPT_METHODTRACE_V2(strTrace, "scTime--->", scTime);
//P3100008            strCarrierXferReq[i].expectedEndTime = CIMFWStrDup(scTime);
//P3100008 del end

//P3100008 start
            struct tm  currentTime;
//D9000001  localtime_r( &t, &currentTime ) ;
            localtime_r( &t.time, &currentTime ) ;    //D9000001

            char scTime[32];
            sprintf( scTime, "%04d%02d%02d%02d%02d%02d", // YYYYMMDDHHMMSS
                            currentTime.tm_year + 1900 + 1,
                            currentTime.tm_mon + 1,
                            currentTime.tm_mday,
                            currentTime.tm_hour,
                            currentTime.tm_min,
                            currentTime.tm_sec );
//P3100008 end
            PPT_METHODTRACE_V2(strTrace, "scTime--->", scTime);
            strCarrierXferReq[i].expectedEndTime = CIMFWStrDup(scTime);

//            strCarrierXferReq[i].expectedEndTime = getTimeStamp();

//2000.11.5 sug start
PPT_METHODTRACE_V2(strTrace, "# strCarrierXferReq.fromMachineID              ", strCarrierXferReq[i].fromMachineID.identifier);
PPT_METHODTRACE_V2(strTrace, "# strCarrierXferReq.fromPortID                 ", strCarrierXferReq[i].fromPortID.identifier);
PPT_METHODTRACE_V2(strTrace, "# strCarrierXferReq.carrierID                  ", strCarrierXferReq[i].carrierID.identifier);
PPT_METHODTRACE_V2(strTrace, "# strCarrierXferReq.strToMachine[0].toMachineID", strCarrierXferReq[i].strToMachine[0].toMachineID.identifier);
PPT_METHODTRACE_V2(strTrace, "# strCarrierXferReq.strToMachine[0].toPortID   ", strCarrierXferReq[i].strToMachine[0].toPortID.identifier);
        }

        PPT_METHODTRACE_V1(strTrace, "Set Output Parameter");
        /*--------------------------*/
        /*   Set Output Parameter   */
        /*--------------------------*/
        strMultiCarrierXferFillInTXLGC012InParm_out.strCarrierXferReq = strCarrierXferReq;

        return( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS(strMultiCarrierXferFillInTXLGC012InParm_out, multiCarrierXferFillInTXLGC012InParm, methodName)
}

