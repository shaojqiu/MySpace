#ifndef lint
static char *sccsid =  "@(#) 1.12 superpos/src/spppt/source/posppt/pptmgr/objmethd/environmentVariable_Get.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 8/6/08 12:00:10 [ 8/6/08 12:00:11 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: environmentVariable_Get.cpp
//

//INN-A170001 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp"    //INN-A170001

//0.02 #define PPT_ENV_MAX_LEN 63
//D4000243#define PPT_ENV_MAX_LEN 69 //0.02
//D4100081#define PPT_ENV_MAX_LEN 70 //D4000243
//D4100069#define PPT_ENV_MAX_LEN 74 //D4100081
//D4100133#define PPT_ENV_MAX_LEN 73 //D4100069
//D4100206#define PPT_ENV_MAX_LEN 80 //D4100133
//D4100206#define PPT_ENV_MAX_LEN 77 //D4100206
//D4100237#define PPT_ENV_MAX_LEN 81 //D4100208
//D4100292#define PPT_ENV_MAX_LEN 82 //D4100237
//D4200075#define PPT_ENV_MAX_LEN 83 //D4100292
//D4200127#define PPT_ENV_MAX_LEN 84 //D4200075
//D4200245#define PPT_ENV_MAX_LEN 85 //D4200127
//D4200265#define PPT_ENV_MAX_LEN 86 //D4200245
//D4200273#define PPT_ENV_MAX_LEN 87 //D4200265
//D4200293#define PPT_ENV_MAX_LEN 88 //D4200273
//D4200322#define PPT_ENV_MAX_LEN 89 //D4200293
//D5000058#define PPT_ENV_MAX_LEN 96 //D4200322
//D5000123#define PPT_ENV_MAX_LEN 97 //D5000058
//D5000154#define PPT_ENV_MAX_LEN 98 //D5000123
//D5000194#define PPT_ENV_MAX_LEN 99 //D5000154
//D5000178#define PPT_ENV_MAX_LEN 100 //D5000194
//D5100016#define PPT_ENV_MAX_LEN 101 //D5000178
//D5100138#define PPT_ENV_MAX_LEN 102 //D5100016
//D5100065#define PPT_ENV_MAX_LEN 103 //D5100138
//D5100232#define PPT_ENV_MAX_LEN 106 //D5100065
//D51M0000#define PPT_ENV_MAX_LEN 114 //D5100232
//D6000009#define PPT_ENV_MAX_LEN 119 //D51M0000
//D6000073#define PPT_ENV_MAX_LEN 120 //D6000009
//D6000215 #define PPT_ENV_MAX_LEN 121 //D6000073
//D6000222 #define PPT_ENV_MAX_LEN 122 //D6000215
//D6000275,D6000313,D6000316 #define PPT_ENV_MAX_LEN 123 //D6000222
//D6000275 #define PPT_ENV_MAX_LEN 124   //D6000275, D6000313, D6000316
//D6000313 #define PPT_ENV_MAX_LEN 128   //D6000275
//D6000316 #define PPT_ENV_MAX_LEN 132   //D6000313
//D6000379 #define PPT_ENV_MAX_LEN 136   //D6000316
//D6000398 #define PPT_ENV_MAX_LEN 137   //D6000379
//D6000389 #define PPT_ENV_MAX_LEN 138   //D6000398
//D7000006 #define PPT_ENV_MAX_LEN 139   //D6000389
//D7000026 #define PPT_ENV_MAX_LEN 140 //D7000006

// Class: PPTManager
//
// Service: environmentVariable_Get()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2001-06-11 D4000012 M.Shimizu      The first coding(R40)
// 2001-08-21          M.Shimizu      Add Environment Variable
// 2001-08-27 D4000014 K.Kido         Add Environment Variable for APC I/F
// 2001-09-04 D4000137 K.Kido         Add for TCS environment value
// 2001-09-05 0.02     O.Sugiyama     Modify PPT_ENV_MAX_LEN 63 -> 66
// 2001-09-14 D4000157
//            D4000172
//            D4000171 K.Kido         Add Environment variable for ControlLot,MMQueryServer,BankIn Cancel
// 2001-10-05 P4000329 K.Kido         RollBack from DCR4000172
// 2001-10-05 D4000216 K.Kido         Add Environment variable for EqpModeChangeReq
// 2001-10-23 D4000243 K.Kido         Add Environment variable for lot_CheckDurationForOperation
// 2002-01-22 D4100081 Cinthia Jao    Add Environment variable for durableChangeEvent_Make
//                                    Modify PPT_ENV_MAX_LEN 70 -> 74
// 2002-01-22 D4100069 C.Tsuchiya     Delete Environment variable for LCFR
//                                    Modify PPT_ENV_MAX_LEN 74 -> 73
// 2002-02-19 D4100134 C.Tsuchiya     Delete Mgr class member and use getenv()
// 2002-02-26 D4100134(2) C.Tsuchiya  Add Environment Variables ( moved from PPTServerManager )
// 2002-02-26 D4100113 C.Tsuchiya     Add Environment Variables for Entitiy Inhibit wild card
// 2002-02-26 D4100133 C.Tsuchiya     Add Environment Variables for Bind timeout for TCS
//                                    Modify PPT_ENV_MAX_LEN 73 -> 80
// 2002-03-25 D4100206 C.Tsuchiya     Delete SP_xxx_By_SQL Environment Variables
//                                    Modify PPT_ENV_MAX_LEN 80 -> 77
// 2002-03-25 D4100208 H.Adachi       Add environment variable for Alarm List & Lot List
// 2002-04-18 D4100237 K.Matsuei      Add SmartTCS control.
// 2002-06-04 D4100292 K.Kimura       Change Logic of Lot Schedule Change after checking Control Job ID.
//                                    Modify PPT_ENV_MAX_LEN 82->83
// 2002-08-16 D4200075 K.Matsuei      Add EBrokerTCS control.
//                                    Modify PPT_ENV_MAX_LEN 83->84
// 2002-10-04 D4200127 C.Tsuchiya     Limit maximum lot list length returned from LotListInq
//                                    Modify PPT_ENV_MAX_LEN 84->85
// 2002-12-26 D4200245 M.Kase         Add environment variable for save/not save '*' data
//                                    Modify PPT_ENV_MAX_LEN 85->86
// 2003-01-22 D4200265 K.Matsuei      Add environment variable : SP_ZONETYPE_NEED_FLAG_IN_CASTLIST.
// 2003-01-24 D4200273 K.Matsuei      TakeOut Xfer is supported under EqpState:NotAvailable, PortState:UnloadReq conditions.
// 2003-02-10 D4200293 K.Matsuei      Set maximum to OperationHistoryInq.
// 2003-03-04 D4200322 H.Adachi       Add environment variable : SP_CASSETTELIST_SEQLEN_DEFAULT_FOR_CASSETTE_LIST_INQ
//                                                               SP_CASSETTELIST_SEQLEN_FOR_CASSETTE_LIST_INQ
//                                                               SP_CASSETTELIST_SEQLEN_MAX_FOR_CASSETTE_LIST_INQ
//                                                               SP_RETICLELIST_SEQLEN_DEFAULT_FOR_RETICLE_LIST_INQ
//                                                               SP_RETICLELIST_SEQLEN_FOR_RETICLE_LIST_INQ
//                                                               SP_RETICLELIST_SEQLEN_MAX_FOR_RETICLE_LIST_INQ
//                                                               SP_ALARMLIST_SEQLEN_MAX_FOR_EQP_ALARM_HISTORY_INQ
// 2003-04-23 D5000058 M.Kase         Add environment variable : SP_SCREENLIMITOVER_NOTCALCULATE_FLAG
//                                    Modify PPT_ENV_MAX_LEN 96->97
// 2003-07-04 D5000123 H.Adachi       Add environment variable : SP_PrivilegeCheck_BY_DR_FLAG
//                                    Modify PPT_ENV_MAX_LEN 97->98
// 2003-07-10 D5000154 K.Kido         Add environment variable : SP_LOTINFO_BY_SQL
//                                    Modify PPT_ENV_MAX_LEN 98->99
// 2003-08-15 D5000194 K.Matsuei      Add environment variable : SP_REROUTE_XFER_FLAG
//                                    Modify PPT_ENV_MAX_LEN 99->100
// 2003-09-03 D5000178 K.Kido         Add environment variable :SP_PROHIBIT_CHARACTER
//                                    Modify PPT_ENV_MAX_LEN 100->101
// 2003-11-19 D5100016 K.Matsuei      Add environment variable : SP_ORBIX_DEFAULT_TIMEOUT
//                                    Modify PPT_ENV_MAX_LEN 101->102
// 2004-01-09 D5100138 K.Matsuei      Add environment variable : SP_STAYONPORT_WITH_NO_DESTINATION
//                                    Modify PPT_ENV_MAX_LEN 102->103
// 2004-02-10 D5100065 M.Ameshita     Add environment variable : SP_SOOR_INHIBIT_CANCEL_BY_ACK
//                                                               SP_WSPC_SERVER_NAME
//                                                               SP_WSPC_HOST_NAME
//                                    Modify PPT_ENV_MAX_LEN 103->106
// 2004-04-07 D5100232 K.Matsuei      Add environment variable : SP_DCS_SERVER_NAME
//                                                               SP_DCS_HOST_NAME
//                                                               SP_BindEverytime_DCS
//                                                               SP_TX_Timeout_DCS
//                                                               SP_DCS_Available
//                                                               SP_DCS_Ignore_OpeStart_Result
//                                                               SP_DCS_Ignore_OpeStartCancel_Result
//                                                               SP_DCS_Ignore_OpeComp_Result
//                                    Modify PPT_ENV_MAX_LEN 106->114
// 2004-08-11 D51M0000 K.Tachibana    Add environment variable : SP_MM_SYSTEM_NAME
//                                                               APC_SYSTEM_NAME
//                                                               SP_INHIBIT_DURATION
//                                                               SP_INHIBIT_WHEN_APC_RPARMADJUST_NG
//                                                               SP_INHIBIT_WHILE_APCIF_DEFINE
//                                    Modify PPT_ENV_MAX_LEN 114->119
// 2004-10-22 D6000009 S.Yamamoto     Add environment variable : SP_HISTORY_EVENTFIFO_DISTRIBUTE
//                                    Modify PPT_ENV_MAX_LEN 119->120
// 2004-11-08 D6000073 M.Mori         Add environment variable : SP_APCENTVAL_MAX_COUNT
//                                    Modify PPT_ENV_MAX_LEN 120->121
// 2005-04-11 D6000215 K.Kido         Add SP_INHIBIT_MAX_SEQLEN_FOR_INHIBIT_LIST_INQ
//                                    Modify PPT_ENV_MAX_LEN 121->122
// 2005-05-09 D6000222 K.Matsuei      Add SP_RCOK_NoData_For_ListInq
//                                    Modify PPT_ENV_MAX_LEN 122->123
// 2005-05-13 D6000275 M.Murata       Add environment variable : SP_CheckExistenceFlag
// 2005-05-13 D6000313 M.Murata       Add environment variable : SP_CheckExistenceFlag
// 2005-05-13 D6000316 M.Murata       Add environment variable : SP_CheckExistenceFlag
//                                    Modify PPT_ENV_MAX_LEN 123->124
// 2005-05-13 D6000275 M.Murata       Add environment variables : SP_APC_SERVER_NAME_FOR_GENIOR
//                                                                SP_APC_HOST_NAME_FOR_GENIOR
//                                                                SP_APC_PORT_NO_FOR_GENIOR
//                                                                SP_APC_MARKER_NAME_FOR_GENIOR
//                                    Modify PPT_ENV_MAX_LEN 124->128
// 2005-05-13 D6000313 M.Murata       Add environment variables : SP_XMS_SERVER_NAME_FOR_GENIOR
//                                                                SP_XMS_HOST_NAME_FOR_GENIOR
//                                                                SP_XMS_PORT_NO_FOR_GENIOR
//                                                                SP_XMS_MARKER_NAME_FOR_GENIOR
//                                    Modify PPT_ENV_MAX_LEN 128->132
// 2005-05-13 D6000316 M.Murata       Add environment variables : SP_DCS_SERVER_NAME_FOR_GENIOR
//                                                                SP_DCS_HOST_NAME_FOR_GENIOR
//                                                                SP_DCS_PORT_NO_FOR_GENIOR
//                                                                SP_DCS_MARKER_NAME_FOR_GENIOR
//                                    Modify PPT_ENV_MAX_LEN 132->136
// 2005-07-11 D6000379 K.Kido         Add SP_BKUP_COUNT_SEQLEN_INQ
//                                    Modify PPT_ENV_MAX_LEN 136->137
// 2005-08-31 D6000398 M.Kase         Add SP_DCDEFDCSPEC_RELATION_CHECK_FLAG
//                                    Modify PPT_ENV_MAX_LEN 137->138
// 2005-09-02 D6000389 K.Kido         Add environment variable : SP_LOTFAMILY_DUPLICATION_ALLOWABLE_FLAG
//                                    Modify PPT_ENV_MAX_LEN 138->139
// 2005-11-01 D7000006 T.Ohsaki       Add environment variable : SP_CONTROLJOB_STATUS_CHANGE_HISTORY_MASK
//                                    Modify PPT_ENV_MAX_LEN 139->140
// 2005-11-10 D7000026 K.Kido         Remove environment variable : SP_LOTINFO_BY_SQL
// 2005-12-12 D7000096 Y.Kadowaki     Remove environment variable : SP_DELIVERY_REQ_EXIST
// 2006-01-27 D7000182 H.Mutoh        Add environment variable : SP_ROLLBACK_NOTIFY_TO_APC
// 2006-02-17 D7000183 K.Matsuei      Add environment variable : SP_MINIMUM_BATCH_CONDITION_APPLY_FLAG_FOR_DELIVERY
// 2006-03-16 D7000219 M.Kase         Add SP_CASSETTE_RELATION_CHECK_FOR_HOLD
// 2006-04-24 P7000243 S.Yamamoto     Add environment variables: SP_DR_RETRY_COUNT
//                                                               SP_DR_RETRY_INTERVAL
// 2006-10-26 D7000371 K.Kido         Add environment variable : SP_SHORTEST_QTIME_USE_FLAG
// 2006-11-06 D8000024 H.Mutoh        Add environment variable : SP_FPC_ADAPTATION_FLAG, SP_FPC_CONTINUOUS_SKIP_LIMIT
// 2006-11-09 D8000084 H.Hasegawa     Add environment variables: SP_CARRIER_CAPACITY, SP_CARRIER_NOMINALSIZE, SP_INSTANCE_NAME,
//                                                               SP_CARRIER_BASEINFO_UPDATE_CHECK, SP_RETICLEPOD_BASEINFO_UPDATE_CHECK
// 2007-02-15 P8000082 K.Matsuei      Add environment variables: SP_MONITOR_WAIT_HOLD_NEW_LOGIC
// 2007-02-27 P8000118 M.Nakano       Add environment variables: SP_RETICLEPOD_XFER_STATUS_CHANGE_LIMITING
// 2007-03-01 D8000184 K.Matsuei      Add environment variables: SP_EQP_STATUS_TRANSITION_LIMITATION
// 2007-03-09 D8000186 K.Kido         Add environment variable : SP_LOT_DELETION_CHECK_EVENT_FLAG
// 2007-03-19 D8000204 K.Kido         Add environment variable : SP_ENTITY_INHIBIT_THRESHOLD_COUNT
// 2007-04-02 D8000207 M.Murata       Add environment variable : SP_OPER_START_WAFER_FLAG_CONTROL
// 2007-06-28 D9000003 M.Nakano       Remove environment variable : SP_OPER_START_WAFER_FLAG_CONTROL
// 2007-07-09 D9000053 K.Kido         Add environment variable : SP_EQP_MODE_CHANGE_OFFLINE_TO_ONLINE_POSSIBLE
// 2007-09-26 D9000084 K.Kido         Add environment variable : SP_ARMS_FUNC_ENABLED, SP_RSP_ON_PORT_CHECK_FLAG
//                                                               RXM_HOST_NAME, RXM_SERVER_NAME
//                                                               SP_RXMSHostName_ForGenIOR, SP_RXMSServerName_ForGenIOR, SP_RXMSMarkerName_ForGenIOR, SP_RXMSPortNo_ForGenIOR
//                                                               SP_BindEverytime_RXM, SP_TX_Timeout_RXM
// 2007/09/20 D9000079 D.Tamura       Add environment variables: SP_FLOWBATCH_CLEARED_BY_OPERSTART
//                                                               SP_FLOWBATCH_CLEARED_BY_OPERCANCEL
// 2007-10-15 D9000056 H.Hotta        Add environment variable : SP_LOCK_HOLD_USE_FLAG
//                                                               SP_POSTPROC_FLAG_USE_FLAG
// 2007-02-21 P9000222 H.Hotta        Add environment variable : SP_SPLIT_LOT_REQUEUE_FLAG
// 2008-02-25 D9000175 K.Kido         Add environment variable : SP_DELIVERY_TAKE_OUTIN_ENABLE_FLAG
// 2008-06-26 D9000228 M.Ishino       Add environment variable : SP_HOLDEQP_UPDATE_FLAG
// 2008-07-08 DSIV00000099 M.Murata   Add environment variable : SP_SLM_SRC_CAST_PRIORITY   (SLM(Small Lot Manufacturing) Support.)
// 2008-08-06 D9000246 M.Ishino       Add environment variable : SP_FRLOTPO_MAINTENANCE
//                                                               SP_FRLOTPO_CHECK_FOR_DELETE
//                                                               SP_CHECK_FOR_DELETE_STAGE
//                                                               SP_CHECK_FOR_DELETE_SCRIPT
//                                                               SP_CHECK_FOR_DELETE_DCDEF
//                                                               SP_CHECK_FOR_DELETE_DCSPEC
//                                                               SP_CHECK_FOR_DELETE_STORAGEMACHINE
//                                                               SP_CHECK_FOR_DELETE_LOGICALRECIPE
//                                                               SP_CHECK_FOR_DELETE_MACHINERECIPE
// 2008-10-09 DSIV00000201 M.Ishino   Add environment variable : SP_POSTPROC_FOR_LOT_FLAG
//                                                               SP_ExternalPostProc_UseFlag
//                                                               SP_ExternalPostProc_UserGrp
// 2008-10-15 DSIV00000220 M.Ogawa    Add environment variable : SP_LOT_STBCANCEL
//                                                               SP_LOT_PREPARECANCEL
// 2008-10-28 DSIV00000286 H.Nonaka   Add environment variable : SP_USE_CDR_FOR_AUTO3DISPATCH
// 2008-10-10 DSIV00000214 K.Matsuei  Add environment variable : SP_FAB_ID
// 2009-06-03 DSIV00001049 R.Okano    Add environment variable : SP_AUTH_AUTHSERVER_AVAILABLE
// 2009/10/02 DSIV00001365 R.Okano    Add environment variable : SP_WSPC_LINK_URL
// 2009-10-07 DSIV00001021 H.Nonaka   Add environment variable : SP_MULTI_CORRESOPE_MODE
//                                                               SP_MULTI_CORRESOPE_MERGE_RULE
//                                                               SP_CORRES_DEFAULT_MODE
// 2009-10-08 DSIV00001441 S.Yamamoto Add environment variable : SP_SCRIPTPARAMETER_CHANGE_EVENT
// 2009-10-22 DSIV00001471 F.Chen     Add environment variable : SP_DC_DATA_CHECK_LEVEL
//                                                               SP_DC_DATA_CHECK_PHASE
// 2009-10-26 DSIV00001443 S.Kawabe   Add environment variable : SP_ENTITY_INHIBIT_SEARCH_CONDITION
// 2009-11-02 DSIV00001481 K.Yamaoku  Add environment variable : SP_USE_DB_TIMESTAMP
// 2010-07-05 DSIV00002162 K.Yamaoku  Add environment variable : SP_OWNER_CHANGE_MAX_COMMIT_COUNT
// 2010-07-09 DSIV00001788 S.Kawabe   Add environment variable : SP_CASSETTE_LOAD_SEQUENCE_CONDITION
// 2010-10-13 DSIV00002458 F.Chen     Add environment variable : SP_EQPSTAT_BACKUP
// 2010-10-15 DSIV00002326 N.Makino   Add environment variable : SP_DURABLEHIS_MAX_SEQLEN_FOR_DURABLEHIS_INQ
//                                                               SP_EQUIPMENTHIS_MAX_SEQLEN_FOR_EQUIPMENTHIS_INQ
// 2010-10-14 DSIV00002270 K.Yamaoku  Add environment variable : SP_POMAINT_EVENT_CREATE_TYPE
// 2011-05-23 PSIV00003221 S.Kawabe   Add environment variable : SP_BRANCH_RETURN_ACTIVE_MODULE
// 2011-08-09 DSN000015229 Yang Xia   Add environment variable : SP_DCS_PJCTRL_AVAILABLE
//                                                               SP_DCS_IGNORE_PJRPT_RESULT
//                                                               SP_PJCTRL_FUNC_ENABLED
//                                                               SP_PROCESSHIS_MAX_SEQLEN_FOR_PROCESSHIS_INQ
// 2011-10-21 DSN000022151 Qiang Wen  Add environment variable : SP_KEEP_QTIME_ON_SCHCHANGE
// 2012-02-15 DSN000033655 K.Yamaoku  Add environment variable : SP_QTIMEINFO_MERGE_RULE
// 2012-02-23 PSN000035912 K.Yamaoku  Remove environment variable : SP_PROCESSHIS_MAX_SEQLEN_FOR_PROCESSHIS_INQ
// 2012-04-18 DSN000041192 T.Ishida   Add environment variable : SP_LAGTIMEINFO_MERGE_RULE
// 2012-06-04 DSN000041621 F.Chen     Add environment variable : SP_EQP_UDATA_MODE
// 2012-06-04 DSN000041626 F.Chen     Add environment variable : SP_CTRLJOBID_GEN_BY_DISP
// 2012-06-04 DSN000041636 F.Chen     Add environment variable : SP_LAST_USED_RECIPE_UPDATE_FLAG/SP_EQPATTR_UPDATE_BY_POSTPROC
// 2012-07-25 DSN000043340 M.Ogawa    Add environment variable : SP_POSTPROC_SEARCH_SEPARATOR_CHAR
// 2012-11-13 PSN000043994 Sa Guo     Add environment variable : SP_CHAMBER_CHECK_POLICY
// 2012-11-27 DSN000049350 F.Chen     Add environment variable : SP_EQP_LOCK_MODE
//                                                               SP_SORTERJOB_LOCK_FLAG
// 2013-01-29 DSN000050720 M.Ogawa    Add environment variable : SP_POSTPROC_PARALLEL_SWITCH
//                                                               SP_POSTPROC_PARALLEL_WORKER_SEARCH_RETRY
//                                                               SP_POSTPROC_PARALLEL_RETRY_SLEEP_TIME
//                                                               SP_POSTPROC_PARALLEL_ACTION_RETRY_COUNT
// 2013-02-20 PSN000068955 H.Hayashi  Add environment variable  "SP_PROPERTYSET_CREATE_ENABLED"
// 2013-05-02 DSN000075358 S.Yamamoto Add environment variable : SP_SCRIPTPARAMETER_UPDATE_MODE
// 2013-05-08 DSN000071674 C.Mo       Add environment variable : SP_LOT_OPERATION_EI_CHECK
// 2013-05-13 PSN000075397 K.Yamaoku  Add environment variable : SP_PROPERTYSET_FOR_FACTORY_USE_SYSTEM_KEY_0
// 2013-05-14 DSN000075522 H.Hayashi  Add environment variable : SP_CREATE_PROPERTYSET_FOR_NEW_LOT
// 2013-08-10 DSN000080226 W.Zhang    Add environment variable : SP_PRIVILEGECHECK_FOR_CJ
//                                                               SP_PRIVILEGECHECK_FOR_CAST
// 2013-08-23 DSN000080287 T.Fujikawa Add environment variable : SP_KEEP_QTIME_ACTION_ON_CLEAR
// 2013-09-13 DSN000081739 Sa Guo     Add environment variable : SP_EQPMONITOR_SWITCH
// 2013-09-28 DSN000075328 JJ.Zhang   Add environment variable : SP_POSTPROC_CHAINED_MODE
// 2013-10-28 DSN000076129 T.Itou     Add environment variable : SP_DCSPEC_FOR_PROCESS
// 2014-02-12 DSN000085024 C.Mo       Add environment variable : SP_WARNING_ON_PSM_REGISTRATION
// 2014-05-17 PSN000081348 C.Mo       Add environment variable : SP_PROCESSHOLD_ALLOW_LOTMOVEMENT
// 2014-05-22 DSN000085698 S.Wang     Add environment variable : SP_RESET_EQPMON_USED_COUNT_ON_STB
// 2014-09-12 PSN000090028 VietNQ     Add environment variable : SP_OWNER_CHANGE_DELETE_DUPLICATE_RECORD
// 2014-10-13 DSN000085793 JJ.Zhang   Add environment variable : SP_WIP_LOT_RESET_UPDATE_LEVEL
// 2014-10-23 DSN000085792 Sa Guo     Add environment variable : SP_INACTIVE_QTIME_LIST
//                                                               SP_QTIME_REPLACETRIGGER_MAINPD_PRIORITY
// 2015-09-06 DSN000100527 JJ.Zhang   Add environment variable : SP_BANKINCANCEL_PRODUCT_CHECK
// 2015-09-10 DSN000096144 S.Kawabe   Add environment variable : SP_USER_PRIVILEGE_POLICY
// 2015-10-01 DSN000096141 S.Kawabe   Add environment variable : SP_PASSCOUNT_WAFERLEVEL_CONTROL
//                                                               SP_PASSCOUNT_WAFERLEVEL_EVENT_CREATION
//                                                               SP_LOT_OPERATION_MOVE_EVENT_CREATION_FOR_STB
// 2016-01-12 PSN000101301 K.Yamaoku  Add environment variable : SP_QTIME_DISPATCHPRECEDE_USE_CUSTOMFIELD
// 2016-06-06 DSN000102497 K.Yamaoku  Add environment variable : SP_DCS_REPORT
// 2016-07-26 DSN000101569 C.Mo       Add environment variable : SP_DURABLE_SUBSTATUS_TRANSITION_LIMITATION
//                                                               SP_RETRIEVE_RETICLE_DURING_LOTPROCESS
//                                                               SP_DURABLEPROCESS_FOR_NON_EMPTY_CARRIER
//                                                               SP_DURABLEPROCESS_FOR_NON_EMPTY_RETICLEPOD
// 2016-09-05 DSN000101643 R.Iriguchi Add environment variable : SP_ENCRYPT_PASSWORD
// 2017-02-27 DSN000104510 VietNQ     Add environment variable : SP_DISPATCH_CAST_CLEARED_BY_CHANGE_TO_ONLINE
// 2017-05-15 PSN000105028 S.Kawabe   Add environment variable : SP_FRLOTPO_DELETE_FOR_SCRAPPED
//                                                               SP_FRLOTPO_DELETE_FOR_EMPTIED
//                                                               SP_FRLOTPO_DELETE_FOR_SHIPPED
//                                                               SP_FRLOTPO_DELETE_FOR_STACKED
//
// Innotron Modification history :
// Date       Defect#     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
// 2017/09/25 INN-R170008 Menghua Yin    Add environment variable : CS_TACERTIFY_SKILL_EXP_DURATION
//                                       Add environment variable : CS_TACERTIFY_PRE_ALARM_DURATION
//
// Description:
//    Increase the value of define when you add an environment variable.
//
// Return:
//    Long
//
// Parameter:
//    objEnvironmentVariable_Get_out& strEnvironmentVariable_Get_out
//    const pptObjCommonIn& strObjCommonIn
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::environmentVariable_Get(
                            objEnvironmentVariable_Get_out& strEnvironmentVariable_Get_out,
                            const pptObjCommonIn& strObjCommonIn)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::environmentVariable_Get");
//D7000026 add start
        //------------------------
        // Set PPT Length
        //------------------------
        const CORBA::Long ENV_MAX_LEN = 500 ;
        CORBA::Long i = 0;
        strEnvironmentVariable_Get_out.strPptEnvVariable.length(ENV_MAX_LEN);
//D7000026 add end
//D7000026        //------------------------
//D7000026        // Set PPT Length
//D7000026        //------------------------
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable.length(PPT_ENV_MAX_LEN);
//D7000026
//D7000026        //---------------------------------
//D7000026        // Get PPTMGR Environment Variable
//D7000026        //---------------------------------
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 0].envName = CIMFWStrDup(BRS_HOST_NAME);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[ 0].envValue = theBRS_HOST_NAME;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 0].envValue = CIMFWStrDup( getenv(BRS_HOST_NAME) );           //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 1].envName = CIMFWStrDup(BRS_SERVER_NAME);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[ 1].envValue = theBRS_SERVER_NAME;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 1].envValue = CIMFWStrDup( getenv(BRS_SERVER_NAME) );         //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 2].envName = CIMFWStrDup(SP_BindEverytime_CSS);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[ 2].envValue = theSP_BindEverytime_CSS;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 2].envValue = CIMFWStrDup( getenv(SP_BindEverytime_CSS) );    //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 3].envName = CIMFWStrDup(SP_BindEverytime_RTD);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[ 3].envValue = theSP_BindEverytime_RTD;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 3].envValue = CIMFWStrDup( getenv(SP_BindEverytime_RTD) );    //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 4].envName = CIMFWStrDup(SP_BindEverytime_SPC);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[ 4].envValue = theSP_BindEverytime_SPC;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 4].envValue = CIMFWStrDup( getenv(SP_BindEverytime_SPC) );    //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 5].envName = CIMFWStrDup(SP_BindEverytime_TCS);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[ 5].envValue = theSP_BindEverytime_TCS;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 5].envValue = CIMFWStrDup( getenv(SP_BindEverytime_TCS) );    //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 6].envName = CIMFWStrDup(SP_BindEverytime_XMS);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[ 6].envValue = theSP_BindEverytime_XMS;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 6].envValue = CIMFWStrDup( getenv(SP_BindEverytime_XMS) );    //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 7].envName = CIMFWStrDup(SP_DELIVERY_REQ_EXIST);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[ 7].envValue = theSP_DELIVERY_REQ_EXIST;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 7].envValue = CIMFWStrDup( getenv(SP_DELIVERY_REQ_EXIST) );   //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 8].envName = CIMFWStrDup(SP_E10PRIORITY_FILE);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[ 8].envValue = theSP_E10PRIORITY_FILE;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 8].envValue = CIMFWStrDup( getenv(SP_E10PRIORITY_FILE) );     //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 9].envName = CIMFWStrDup(SP_NOSCHEDULE_FOR_CHILDLOT);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[ 9].envValue = theSP_NOSCHEDULE_FOR_CHILDLOT;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[ 9].envValue = CIMFWStrDup( getenv(SP_NOSCHEDULE_FOR_CHILDLOT) );        //D4100134
//D7000026//D4100206        strEnvironmentVariable_Get_out.strPptEnvVariable[10].envName = CIMFWStrDup(SP_WHATNEXT_BY_SQL);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[10].envValue = theSP_WHATNEXT_BY_SQL;
//D7000026//D4100206        strEnvironmentVariable_Get_out.strPptEnvVariable[10].envValue = CIMFWStrDup( getenv(SP_WHATNEXT_BY_SQL) );      //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[10].envName = CIMFWStrDup(SP_ZONE_TYPE_FLAG);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[11].envValue = theSP_ZONE_TYPE_FLAG;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[10].envValue = CIMFWStrDup( getenv(SP_ZONE_TYPE_FLAG) );       //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[11].envName = CIMFWStrDup(SP_ZONE_TYPE_INI);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[12].envValue = theSP_ZONE_TYPE_INI;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[11].envValue = CIMFWStrDup( getenv(SP_ZONE_TYPE_INI) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[12].envName = CIMFWStrDup(SP_EnvName_MaximumWafersInALot);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[13].envValue = theSP_EnvName_MaximumWafersInALot;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[12].envValue = CIMFWStrDup( getenv(SP_EnvName_MaximumWafersInALot) );        //D4100134
//D7000026//D4100206        strEnvironmentVariable_Get_out.strPptEnvVariable[14].envName = CIMFWStrDup(SP_EqpInfo_By_SQL);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[14].envValue = theSP_EqpInfo_By_SQL;
//D7000026//D4100206        strEnvironmentVariable_Get_out.strPptEnvVariable[14].envValue = CIMFWStrDup( getenv(SP_EqpInfo_By_SQL) );       //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[13].envName = CIMFWStrDup(SP_FIXTURE_SEQLEN_FOR_OPEHIS_INQ);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[15].envValue = theSP_FIXTURE_SEQLEN_FOR_OPEHIS_INQ;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[13].envValue = CIMFWStrDup( getenv(SP_FIXTURE_SEQLEN_FOR_OPEHIS_INQ) );        //D4100134
//D7000026        //D4100069 strEnvironmentVariable_Get_out.strPptEnvVariable[16].envName = CIMFWStrDup(SP_LCFR_Use_Flag);
//D7000026        //D4100069 strEnvironmentVariable_Get_out.strPptEnvVariable[16].envValue = theSP_LCFR_Use_Flag;
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[14].envName = CIMFWStrDup(SP_LOT_ON_PORT_SEQLEN_FOR_EQPINFO_INQ);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[16].envValue = theSP_LOT_ON_PORT_SEQLEN_FOR_EQPINFO_INQ;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[14].envValue = CIMFWStrDup( getenv(SP_LOT_ON_PORT_SEQLEN_FOR_EQPINFO_INQ) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[15].envName = CIMFWStrDup(SP_Max_Script_Execution);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[17].envValue = theSP_Max_Script_Execution;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[15].envValue = CIMFWStrDup( getenv(SP_Max_Script_Execution) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[16].envName = CIMFWStrDup(SP_MessageQueueNeed_STRING);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[18].envValue = theSP_MessageQueueNeed_STRING;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[16].envValue = CIMFWStrDup( getenv(SP_MessageQueueNeed_STRING) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[17].envName = CIMFWStrDup(SP_PD_EQP_SEQLEN_FOR_OPELIST_INQ);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[19].envValue = theSP_PD_EQP_SEQLEN_FOR_OPELIST_INQ;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[17].envValue = CIMFWStrDup( getenv(SP_PD_EQP_SEQLEN_FOR_OPELIST_INQ) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[18].envName = CIMFWStrDup(SP_PORT_SEQLEN_FOR_EQPINFO_INQ);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[20].envValue = theSP_PORT_SEQLEN_FOR_EQPINFO_INQ;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[18].envValue = CIMFWStrDup( getenv(SP_PORT_SEQLEN_FOR_EQPINFO_INQ) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[19].envName = CIMFWStrDup(SP_RCPPARM_SEQLEN_FOR_OPEHIS_INQ);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[21].envValue = theSP_RCPPARM_SEQLEN_FOR_OPEHIS_INQ;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[19].envValue = CIMFWStrDup( getenv(SP_RCPPARM_SEQLEN_FOR_OPEHIS_INQ) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[20].envName = CIMFWStrDup(SP_RTD_Available);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[22].envValue = theSP_RTD_Available;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[20].envValue = CIMFWStrDup( getenv(SP_RTD_Available) );        //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[21].envName = CIMFWStrDup(SP_RTD_HOST_NAME);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[23].envValue = theSP_RTD_HOST_NAME;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[21].envValue = CIMFWStrDup( getenv(SP_RTD_HOST_NAME) );        //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[22].envName = CIMFWStrDup(SP_RTD_Health_Rpt_Enforce);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[24].envValue = theSP_RTD_Health_Rpt_Enforce;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[22].envValue = CIMFWStrDup( getenv(SP_RTD_Health_Rpt_Enforce) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[23].envName = CIMFWStrDup(SP_RTD_Health_Rpt_Interval);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[25].envValue = theSP_RTD_Health_Rpt_Interval;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[23].envValue = CIMFWStrDup( getenv(SP_RTD_Health_Rpt_Interval) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[24].envName = CIMFWStrDup(SP_RTD_SERVER_NAME);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[26].envValue = theSP_RTD_SERVER_NAME;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[24].envValue = CIMFWStrDup( getenv(SP_RTD_SERVER_NAME) );      //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[25].envName = CIMFWStrDup(SP_SPC_HOST_NAME);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[27].envValue = theSP_SPC_HOST_NAME;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[25].envValue = CIMFWStrDup( getenv(SP_SPC_HOST_NAME) );        //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[26].envName = CIMFWStrDup(SP_SPC_SERVER_NAME);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[28].envValue = theSP_SPC_SERVER_NAME;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[26].envValue = CIMFWStrDup( getenv(SP_SPC_SERVER_NAME) );      //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[27].envName = CIMFWStrDup(SP_SendToTCS_In_Offline);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[29].envValue = theSP_SendToTCS_In_Offline;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[27].envValue = CIMFWStrDup( getenv(SP_SendToTCS_In_Offline) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[28].envName = CIMFWStrDup(SP_TX_Timeout_CSS);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[30].envValue = theSP_TX_Timeout_CSS;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[28].envValue = CIMFWStrDup( getenv(SP_TX_Timeout_CSS) );       //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[29].envName = CIMFWStrDup(SP_TX_Timeout_RTD);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[31].envValue = theSP_TX_Timeout_RTD;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[29].envValue = CIMFWStrDup( getenv(SP_TX_Timeout_RTD) );       //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[30].envName = CIMFWStrDup(SP_TX_Timeout_SPC);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[32].envValue = theSP_TX_Timeout_SPC;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[30].envValue = CIMFWStrDup( getenv(SP_TX_Timeout_SPC) );       //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[31].envName = CIMFWStrDup(SP_TX_Timeout_TCS);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[33].envValue = theSP_TX_Timeout_TCS;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[31].envValue = CIMFWStrDup( getenv(SP_TX_Timeout_TCS) );       //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[32].envName = CIMFWStrDup(SP_TX_Timeout_XMS);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[34].envValue = theSP_TX_Timeout_XMS;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[32].envValue = CIMFWStrDup( getenv(SP_TX_Timeout_XMS) );       //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[33].envName = CIMFWStrDup(SP_XMS_HOST_NAME);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[35].envValue = theSP_XMS_HOST_NAME;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[33].envValue = CIMFWStrDup( getenv(SP_XMS_HOST_NAME) );        //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[34].envName = CIMFWStrDup(SP_XMS_SERVER_NAME);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[36].envValue = theSP_XMS_SERVER_NAME;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[34].envValue = CIMFWStrDup( getenv(SP_XMS_SERVER_NAME) );      //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[35].envName = CIMFWStrDup(SP_PD_SEQLEN_FOR_OPELIST_INQ);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[37].envValue = theSP_PD_SEQLEN_FOR_OPELIST_INQ;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[35].envValue = CIMFWStrDup( getenv(SP_PD_SEQLEN_FOR_OPELIST_INQ) );        //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[36].envName = CIMFWStrDup(SP_APC_SERVER_NAME);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[38].envValue = theSP_APC_SERVER_NAME;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[36].envValue = CIMFWStrDup( getenv(SP_APC_SERVER_NAME) );      //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[37].envName = CIMFWStrDup(SP_APC_HOST_NAME);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[39].envValue = theSP_APC_HOST_NAME;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[37].envValue = CIMFWStrDup( getenv(SP_APC_HOST_NAME) );        //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[38].envName = CIMFWStrDup(SP_BindEverytime_APC);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[40].envValue = theSP_BindEverytime_APC;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[38].envValue = CIMFWStrDup( getenv(SP_BindEverytime_APC) );    //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[39].envName = CIMFWStrDup(SP_RETICLE_SEQLEN_FOR_OPEHIS_INQ);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[41].envValue = theSP_RETICLE_SEQLEN_FOR_OPEHIS_INQ;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[39].envValue = CIMFWStrDup( getenv(SP_RETICLE_SEQLEN_FOR_OPEHIS_INQ) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[40].envName = CIMFWStrDup(MM_CATALOG_FILE);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[42].envValue = theMM_CATALOG_FILE;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[40].envValue = CIMFWStrDup( getenv(MM_CATALOG_FILE) );         //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[41].envName = CIMFWStrDup(SP_LOCK_TIMEOUT);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[43].envValue = theSP_LOCK_TIMEOUT;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[41].envValue = CIMFWStrDup( getenv(SP_LOCK_TIMEOUT) );         //D4100134
//D7000026
//D7000026//D4100206        strEnvironmentVariable_Get_out.strPptEnvVariable[44].envName = CIMFWStrDup(SP_LOTINFO_BY_SQL);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[44].envValue = theSP_LOTINFO_BY_SQL;
//D7000026//D4100206        strEnvironmentVariable_Get_out.strPptEnvVariable[44].envValue = CIMFWStrDup( getenv(SP_LOTINFO_BY_SQL) );       //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[42].envName = CIMFWStrDup(SP_MULTIPLESERVER);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[45].envValue = theSP_MULTIPLESERVER;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[42].envValue = CIMFWStrDup( getenv(SP_MULTIPLESERVER) );       //D4100134
//D7000026
//D7000026//Add Start 2001-08-22
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[43].envName = CIMFWStrDup(SP_ACTIONLIST_SEQLEN_FOR_WAFERSORTER_INQ);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[46].envValue = theSP_ACTIONLIST_SEQLEN_FOR_WAFERSORTER_INQ;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[43].envValue = CIMFWStrDup( getenv(SP_ACTIONLIST_SEQLEN_FOR_WAFERSORTER_INQ) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[44].envName = CIMFWStrDup(SP_BANK_SEQLEN_FOR_BANKLIST_INQ);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[47].envValue = theSP_BANK_SEQLEN_FOR_BANKLIST_INQ;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[44].envValue = CIMFWStrDup( getenv(SP_BANK_SEQLEN_FOR_BANKLIST_INQ) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[45].envName = CIMFWStrDup(SP_BIND_RETRY_COUNT_TCS);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[48].envValue = theSP_BIND_RETRY_COUNT_TCS;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[45].envValue = CIMFWStrDup( getenv(SP_BIND_RETRY_COUNT_TCS) );       //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[46].envName = CIMFWStrDup(SP_BIND_SLEEP_TIME_TCS);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[49].envValue = theSP_BIND_SLEEP_TIME_TCS;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[46].envValue = CIMFWStrDup( getenv(SP_BIND_SLEEP_TIME_TCS) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[47].envName = CIMFWStrDup(SP_DCDEF_SEQLEN_FOR_CDHIS_INQ);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[50].envValue = theSP_DCDEF_SEQLEN_FOR_CDHIS_INQ;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[47].envValue = CIMFWStrDup( getenv(SP_DCDEF_SEQLEN_FOR_CDHIS_INQ) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[48].envName = CIMFWStrDup(SP_DCITEM_SEQLEN_FOR_CDHIS_INQ);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[51].envValue = theSP_DCITEM_SEQLEN_FOR_CDHIS_INQ;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[48].envValue = CIMFWStrDup( getenv(SP_DCITEM_SEQLEN_FOR_CDHIS_INQ) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[49].envName = CIMFWStrDup(SP_LOTQTIME_SEQLEN_FOR_QRESTLOT_INQ);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[52].envValue = theSP_LOTQTIME_SEQLEN_FOR_QRESTLOT_INQ;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[49].envValue = CIMFWStrDup( getenv(SP_LOTQTIME_SEQLEN_FOR_QRESTLOT_INQ) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[50].envName = CIMFWStrDup(SP_NEXTBANK_SEQLEN_FOR_BANKLIST_INQ);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[53].envValue = theSP_NEXTBANK_SEQLEN_FOR_BANKLIST_INQ;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[50].envValue = CIMFWStrDup( getenv(SP_NEXTBANK_SEQLEN_FOR_BANKLIST_INQ) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[51].envName = CIMFWStrDup(SP_OPEHIS_SEQLEN_FOR_OPEHIS_INQ);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[54].envValue = theSP_OPEHIS_SEQLEN_FOR_OPEHIS_INQ;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[51].envValue = CIMFWStrDup( getenv(SP_OPEHIS_SEQLEN_FOR_OPEHIS_INQ) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[52].envName = CIMFWStrDup(SP_OPEHIS_SEQLEN_FOR_OPEHIS_INQ_WITH_PINPOINT);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[55].envValue = theSP_OPEHIS_SEQLEN_FOR_OPEHIS_INQ_WITH_PINPOINT;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[52].envValue = CIMFWStrDup( getenv(SP_OPEHIS_SEQLEN_FOR_OPEHIS_INQ_WITH_PINPOINT) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[53].envName = CIMFWStrDup(SP_PORT_CATEGORY_CAPABILITY_LEN);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[56].envValue = theSP_PORT_CATEGORY_CAPABILITY_LEN;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[53].envValue = CIMFWStrDup( getenv(SP_PORT_CATEGORY_CAPABILITY_LEN) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[54].envName = CIMFWStrDup(SP_PRODUCT_SEQLEN_FOR_PRDLST_INQ);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[57].envValue = theSP_PRODUCT_SEQLEN_FOR_PRDLST_INQ;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[54].envValue = CIMFWStrDup( getenv(SP_PRODUCT_SEQLEN_FOR_PRDLST_INQ) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[55].envName = CIMFWStrDup(SP_QRESTLOT_SEQLEN_FOR_QRESTLOT_INQ);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[58].envValue = theSP_QRESTLOT_SEQLEN_FOR_QRESTLOT_INQ;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[55].envValue = CIMFWStrDup( getenv(SP_QRESTLOT_SEQLEN_FOR_QRESTLOT_INQ) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[56].envName = CIMFWStrDup(SP_RETICLEPOD_SEQLEN_FOR_RTCLSTK_INQ);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[59].envValue = theSP_RETICLEPOD_SEQLEN_FOR_RTCLSTK_INQ;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[56].envValue = CIMFWStrDup( getenv(SP_RETICLEPOD_SEQLEN_FOR_RTCLSTK_INQ) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[57].envName = CIMFWStrDup(SP_RETICLE_SEQLEN_FOR_RTCLSTK_INQ);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[60].envValue = theSP_RETICLE_SEQLEN_FOR_RTCLSTK_INQ;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[57].envValue = CIMFWStrDup( getenv(SP_RETICLE_SEQLEN_FOR_RTCLSTK_INQ) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[58].envName = CIMFWStrDup(SP_SRCPRODUCT_SEQLEN_FOR_PRDLST_INQ);
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[61].envValue = theSP_SRCPRODUCT_SEQLEN_FOR_PRDLST_INQ;
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[58].envValue = CIMFWStrDup( getenv(SP_SRCPRODUCT_SEQLEN_FOR_PRDLST_INQ) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[59].envName = CIMFWStrDup(SP_TX_Timeout_APC);                  //D4000014
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[62].envValue = theSP_TX_Timeout_APC;                           //D4000014
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[59].envValue = CIMFWStrDup( getenv(SP_TX_Timeout_APC) );       //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[60].envName = CIMFWStrDup(SP_APC_Available);                   //D4000014
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[63].envValue = theSP_APC_Available;                            //D4000014
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[60].envValue = CIMFWStrDup( getenv(SP_APC_Available) );        //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[61].envName = CIMFWStrDup(SP_TCS_SERVER_NAME);                 //D4000137
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[64].envValue = theSP_TCS_SERVER_NAME;                          //D4000137
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[61].envValue = CIMFWStrDup( getenv(SP_TCS_SERVER_NAME) );      //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[62].envName = CIMFWStrDup(SP_CTRLLOT_PRTYCLASS);               //D4000157
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[65].envValue = theSP_CTRLLOT_PRTYCLASS;                        //D4000157
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[62].envValue = CIMFWStrDup( getenv(SP_CTRLLOT_PRTYCLASS) );    //D4100134
//D7000026
//D7000026//P4000329        strEnvironmentVariable_Get_out.strPptEnvVariable[67].envName = CIMFWStrDup(SP_LOT_DELETION_RESERVE_PERIOD);     //D4000172
//D7000026//P4000329        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[67].envValue = theSP_LOT_DELETION_RESERVE_PERIOD;              //D4000172
//D7000026//        strEnvironmentVariable_Get_out.strPptEnvVariable[67].envValue = CIMFWStrDup( getenv(SP_LOT_DELETION_RESERVE_PERIOD) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[63].envName = CIMFWStrDup(SP_MM_QUERY_SERVER);                 //D4000171
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[66].envValue = theSP_MM_QUERY_SERVER ;                         //D4000171
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[63].envValue = CIMFWStrDup( getenv(SP_MM_QUERY_SERVER ) );     //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[64].envName = CIMFWStrDup(SP_LOT_CASSETTE_ON_PORT_CHECK_FLAG); //D4000216
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[67].envValue = theSP_LOT_CASSETTE_ON_PORT_CHECK_FLAG;          //D4000216
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[64].envValue = CIMFWStrDup( getenv(SP_LOT_CASSETTE_ON_PORT_CHECK_FLAG) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[65].envName = CIMFWStrDup(SP_LOT_DELETION_RESERVE_PERIOD);     //D4000243
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[68].envValue = theSP_LOT_DELETION_RESERVE_PERIOD;              //D4000243
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[65].envValue = CIMFWStrDup( getenv(SP_LOT_DELETION_RESERVE_PERIOD) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[66].envName = CIMFWStrDup(SP_CASETTE_XFER_HISTORY);            //D4100081
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[69].envValue = theSP_CASETTE_XFER_HISTORY;                     //D4100081
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[66].envValue = CIMFWStrDup( getenv(SP_CASETTE_XFER_HISTORY) ); //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[67].envName = CIMFWStrDup(SP_RETICLEPOD_XFER_HISTORY);         //D4100081
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[70].envValue = theSP_RETICLEPOD_XFER_HISTORY;                  //D4100081
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[67].envValue = CIMFWStrDup( getenv(SP_RETICLEPOD_XFER_HISTORY) );        //D4100134
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[68].envName = CIMFWStrDup(SP_RETICLE_XFER_HISTORY);            //D4100081
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[71].envValue = theSP_RETICLE_XFER_HISTORY;                     //D4100081
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[68].envValue = CIMFWStrDup( getenv(SP_RETICLE_XFER_HISTORY) ); //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[69].envName = CIMFWStrDup(SP_FIXTURE_XFER_HISTORY);            //D4100081
//D7000026        //D4100134 strEnvironmentVariable_Get_out.strPptEnvVariable[72].envValue = theSP_FIXTURE_XFER_HISTORY;                     //D4100081
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[69].envValue = CIMFWStrDup( getenv(SP_FIXTURE_XFER_HISTORY) ); //D4100134
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[70].envName  = CIMFWStrDup( EVENT_IPCKEY_MM );                 //D4100134(2)
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[70].envValue = CIMFWStrDup( getenv(EVENT_IPCKEY_MM) );         //D4100134(2)
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[71].envName  = CIMFWStrDup( SP_TRANSACTION_TIMEOUT );          //D4100134(2)
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[71].envValue = CIMFWStrDup( getenv(SP_TRANSACTION_TIMEOUT) );  //D4100134(2)
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[72].envName  = CIMFWStrDup( SP_TRANSACTION_LOGGING );          //D4100134(2)
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[72].envValue = CIMFWStrDup( getenv(SP_TRANSACTION_LOGGING) );  //D4100134(2)
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[73].envName  = CIMFWStrDup( SP_ORBIX_DAEMON_PORT );            //D4100134(2)
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[73].envValue = CIMFWStrDup( getenv(SP_ORBIX_DAEMON_PORT) );    //D4100134(2)
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[74].envName  = CIMFWStrDup( SP_ENTITY_INHIBIT_USE_WILDCARD );            //D4100113
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[74].envValue = CIMFWStrDup( getenv(SP_ENTITY_INHIBIT_USE_WILDCARD) );    //D4100113
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[75].envName  = CIMFWStrDup( SP_WILDCARD_CHAR );                          //D4100113
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[75].envValue = CIMFWStrDup( getenv(SP_WILDCARD_CHAR) );                  //D4100113
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[76].envName  = CIMFWStrDup( SP_BIND_TIMEOUT_TCS );                       //D4100133
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[76].envValue = CIMFWStrDup( getenv(SP_BIND_TIMEOUT_TCS) );               //D4100133
//D7000026
//D7000026//Add End 2001-08-22
//D7000026
//D7000026        //D4100208 Add Start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[77].envName  = CIMFWStrDup(SP_ALARMLIST_SEQLEN_FOR_EQP_ALARM_HISTORY_INQ);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[77].envValue = CIMFWStrDup( getenv(SP_ALARMLIST_SEQLEN_FOR_EQP_ALARM_HISTORY_INQ) );
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[78].envName  = CIMFWStrDup(SP_ALARMLIST_SEQLEN_DEFAULT_FOR_EQP_ALARM_HISTORY_INQ);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[78].envValue = CIMFWStrDup( getenv(SP_ALARMLIST_SEQLEN_DEFAULT_FOR_EQP_ALARM_HISTORY_INQ) );
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[79].envName  = CIMFWStrDup(SP_LOTLIST_SEQLEN_FOR_LOT_LIST_INQ);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[79].envValue = CIMFWStrDup( getenv(SP_LOTLIST_SEQLEN_FOR_LOT_LIST_INQ) );
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[80].envName  = CIMFWStrDup(SP_LOTLIST_SEQLEN_DEFAULT_FOR_LOT_LIST_INQ);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[80].envValue = CIMFWStrDup( getenv(SP_LOTLIST_SEQLEN_DEFAULT_FOR_LOT_LIST_INQ) );
//D7000026        //D4100208 Add End
//D7000026
//D7000026//D4100237 start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[81].envName  = CIMFWStrDup(SP_SmartTCS_Available);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[81].envValue = CIMFWStrDup( getenv(SP_SmartTCS_Available) );
//D7000026//D4100237 end
//D7000026
//D7000026//D4100292 start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[82].envName  = CIMFWStrDup(SP_LOT_SCHDCHANGE_RESERVE);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[82].envValue = CIMFWStrDup( getenv(SP_LOT_SCHDCHANGE_RESERVE) );
//D7000026//D4100292 end
//D7000026
//D7000026//D4200075 start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[83].envName  = CIMFWStrDup(SP_EBrokerTCS_Available);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[83].envValue = CIMFWStrDup( getenv(SP_EBrokerTCS_Available) );
//D7000026//D4200075 end
//D7000026
//D7000026//D4200127 start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[84].envName  = CIMFWStrDup(SP_LOTLIST_MAX_SEQLEN_FOR_LOT_LIST_INQ);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[84].envValue = CIMFWStrDup( getenv(SP_LOTLIST_MAX_SEQLEN_FOR_LOT_LIST_INQ) );
//D7000026//D4200127 end
//D7000026
//D7000026//D4200245 start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[85].envName  = CIMFWStrDup(SP_DATAVALUE_ASTERISK_SAVEFLAG);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[85].envValue = CIMFWStrDup( getenv(SP_DATAVALUE_ASTERISK_SAVEFLAG) );
//D7000026//D4200245 end
//D7000026
//D7000026//D4200265 Add Start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[86].envName  = CIMFWStrDup(SP_ZONETYPE_NEED_FLAG_IN_CASTLIST);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[86].envValue = CIMFWStrDup( getenv(SP_ZONETYPE_NEED_FLAG_IN_CASTLIST) );
//D7000026//4200265 Add End
//D7000026
//D7000026//D4200273 Add Start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[87].envName  = CIMFWStrDup(SP_TAKEOUT_XFER_IN_NOTAVAILABLE_STATE);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[87].envValue = CIMFWStrDup( getenv(SP_TAKEOUT_XFER_IN_NOTAVAILABLE_STATE) );
//D7000026//D4200273 Add End
//D7000026
//D7000026//D4200293 Add Start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[88].envName  = CIMFWStrDup(SP_OPEHIS_MAX_SEQLEN_FOR_OPEHIS_INQ);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[88].envValue = CIMFWStrDup( getenv(SP_OPEHIS_MAX_SEQLEN_FOR_OPEHIS_INQ) );
//D7000026//D4200293 Add End
//D7000026
//D7000026//D4200322 Add Start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[89].envName  = CIMFWStrDup(SP_CASSETTELIST_SEQLEN_DEFAULT_FOR_CASSETTE_LIST_INQ);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[89].envValue = CIMFWStrDup( getenv(SP_CASSETTELIST_SEQLEN_DEFAULT_FOR_CASSETTE_LIST_INQ) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[90].envName  = CIMFWStrDup(SP_CASSETTELIST_SEQLEN_FOR_CASSETTE_LIST_INQ);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[90].envValue = CIMFWStrDup( getenv(SP_CASSETTELIST_SEQLEN_FOR_CASSETTE_LIST_INQ) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[91].envName  = CIMFWStrDup(SP_CASSETTELIST_SEQLEN_MAX_FOR_CASSETTE_LIST_INQ);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[91].envValue = CIMFWStrDup( getenv(SP_CASSETTELIST_SEQLEN_MAX_FOR_CASSETTE_LIST_INQ) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[92].envName  = CIMFWStrDup(SP_RETICLELIST_SEQLEN_DEFAULT_FOR_RETICLE_LIST_INQ);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[92].envValue = CIMFWStrDup( getenv(SP_RETICLELIST_SEQLEN_DEFAULT_FOR_RETICLE_LIST_INQ) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[93].envName  = CIMFWStrDup(SP_RETICLELIST_SEQLEN_FOR_RETICLE_LIST_INQ);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[93].envValue = CIMFWStrDup( getenv(SP_RETICLELIST_SEQLEN_FOR_RETICLE_LIST_INQ) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[94].envName  = CIMFWStrDup(SP_RETICLELIST_SEQLEN_MAX_FOR_RETICLE_LIST_INQ);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[94].envValue = CIMFWStrDup( getenv(SP_RETICLELIST_SEQLEN_MAX_FOR_RETICLE_LIST_INQ) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[95].envName  = CIMFWStrDup(SP_ALARMLIST_SEQLEN_MAX_FOR_EQP_ALARM_HISTORY_INQ);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[95].envValue = CIMFWStrDup( getenv(SP_ALARMLIST_SEQLEN_MAX_FOR_EQP_ALARM_HISTORY_INQ) );
//D7000026//D4200322 Add Start
//D7000026
//D7000026//D5000058 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[96].envName  = CIMFWStrDup(SP_SCREENLIMITOVER_NOTCALCULATE_FLAG);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[96].envValue = CIMFWStrDup( getenv(SP_SCREENLIMITOVER_NOTCALCULATE_FLAG) );
//D7000026//D5000058 add end
//D7000026
//D7000026//D5000123 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[97].envName  = CIMFWStrDup(SP_PrivilegeCheck_BY_DR_FLAG);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[97].envValue = CIMFWStrDup( getenv(SP_PrivilegeCheck_BY_DR_FLAG) );
//D7000026//D5000123 add end
//D7000026
//D7000026//D5000154 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[98].envName  = CIMFWStrDup(SP_LOTINFO_BY_SQL);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[98].envValue = CIMFWStrDup( getenv(SP_LOTINFO_BY_SQL) );
//D7000026//D5000154 add end
//D7000026
//D7000026//D5000194 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[99].envName  = CIMFWStrDup(SP_REROUTE_XFER_FLAG);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[99].envValue = CIMFWStrDup( getenv(SP_REROUTE_XFER_FLAG) );
//D7000026//D5000194 add end
//D7000026
//D7000026//D5000178 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[100].envName  = CIMFWStrDup(SP_PROHIBIT_CHARACTER);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[100].envValue = CIMFWStrDup( getenv(SP_PROHIBIT_CHARACTER) );
//D7000026//D5000178 add end
//D7000026
//D7000026//D5100016 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[101].envName  = CIMFWStrDup(SP_ORBIX_DEFAULT_TIMEOUT);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[101].envValue = CIMFWStrDup( getenv(SP_ORBIX_DEFAULT_TIMEOUT) );
//D7000026//D5100016 add end
//D7000026
//D7000026//D5100138 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[102].envName  = CIMFWStrDup(SP_STAYONPORT_WITH_NO_DESTINATION);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[102].envValue = CIMFWStrDup( getenv(SP_STAYONPORT_WITH_NO_DESTINATION) );
//D7000026//D5100138 add end
//D7000026
//D7000026//D5100065 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[103].envName  = CIMFWStrDup( SP_SOOR_INHIBIT_CANCEL_BY_ACK );
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[103].envValue = CIMFWStrDup( getenv( SP_SOOR_INHIBIT_CANCEL_BY_ACK ) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[104].envName = CIMFWStrDup( SP_WSPC_SERVER_NAME);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[104].envValue = CIMFWStrDup( getenv(SP_WSPC_SERVER_NAME) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[105].envName = CIMFWStrDup(SP_WSPC_HOST_NAME);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[105].envValue = CIMFWStrDup( getenv(SP_WSPC_HOST_NAME) );
//D7000026//D5100065 add end
//D7000026
//D7000026//D5100232 start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[106].envName = CIMFWStrDup(SP_DCS_SERVER_NAME);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[106].envValue = CIMFWStrDup( getenv(SP_DCS_SERVER_NAME) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[107].envName = CIMFWStrDup(SP_DCS_HOST_NAME);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[107].envValue = CIMFWStrDup( getenv(SP_DCS_HOST_NAME) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[108].envName = CIMFWStrDup(SP_BindEverytime_DCS);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[108].envValue = CIMFWStrDup( getenv(SP_BindEverytime_DCS) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[109].envName = CIMFWStrDup(SP_TX_Timeout_DCS);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[109].envValue = CIMFWStrDup( getenv(SP_TX_Timeout_DCS) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[110].envName = CIMFWStrDup(SP_DCS_Available);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[110].envValue = CIMFWStrDup( getenv(SP_DCS_Available) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[111].envName = CIMFWStrDup(SP_DCS_Ignore_OpeStart_Result);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[111].envValue = CIMFWStrDup( getenv(SP_DCS_Ignore_OpeStart_Result) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[112].envName = CIMFWStrDup(SP_DCS_Ignore_OpeStartCancel_Result);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[112].envValue = CIMFWStrDup( getenv(SP_DCS_Ignore_OpeStartCancel_Result) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[113].envName = CIMFWStrDup(SP_DCS_Ignore_OpeComp_Result);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[113].envValue = CIMFWStrDup( getenv(SP_DCS_Ignore_OpeComp_Result) );
//D7000026//D5100232 end
//D7000026
//D7000026//D51M0000 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[114].envName = CIMFWStrDup(SP_MM_SYSTEM_NAME);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[114].envValue = CIMFWStrDup( getenv(SP_MM_SYSTEM_NAME) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[115].envName = CIMFWStrDup(SP_APC_SYSTEM_NAME);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[115].envValue = CIMFWStrDup( getenv(SP_APC_SYSTEM_NAME) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[116].envName = CIMFWStrDup(SP_INHIBIT_DURATION);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[116].envValue = CIMFWStrDup( getenv(SP_INHIBIT_DURATION) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[117].envName = CIMFWStrDup(SP_INHIBIT_WHEN_APC_RPARMADJUST_NG);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[117].envValue = CIMFWStrDup( getenv(SP_INHIBIT_WHEN_APC_RPARMADJUST_NG) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[118].envName = CIMFWStrDup(SP_INHIBIT_WHILE_APCIF_DEFINE);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[118].envValue = CIMFWStrDup( getenv(SP_INHIBIT_WHILE_APCIF_DEFINE) );
//D7000026//D51M0000 add end
//D7000026
//D7000026//D6000009 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[119].envName = CIMFWStrDup(SP_HISTORY_EVENTFIFO_DISTRIBUTE);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[119].envValue = CIMFWStrDup( getenv(SP_HISTORY_EVENTFIFO_DISTRIBUTE) );
//D7000026//D6000009 add end
//D7000026
//D7000026//D6000073 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[120].envName = CIMFWStrDup(SP_APCENTVAL_MAX_COUNT);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[120].envValue = CIMFWStrDup( getenv(SP_APCENTVAL_MAX_COUNT) );
//D7000026//D6000073 add end
//D7000026
//D7000026//D6000215 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[121].envName = CIMFWStrDup(SP_INHIBIT_MAX_SEQLEN_FOR_INHIBIT_LIST_INQ);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[121].envValue = CIMFWStrDup( getenv(SP_INHIBIT_MAX_SEQLEN_FOR_INHIBIT_LIST_INQ) );
//D7000026//D6000215 add end
//D7000026
//D7000026//D6000222 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[122].envName = CIMFWStrDup(SP_RCOK_NoData_For_ListInq);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[122].envValue = CIMFWStrDup( getenv(SP_RCOK_NoData_For_ListInq) );
//D7000026//D6000222 add end
//D7000026
//D7000026//D6000275, D6000313, D6000316 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[123].envName  = CIMFWStrDup(SP_CheckExistenceFlag);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[123].envValue = CIMFWStrDup( getenv(SP_CheckExistenceFlag) );
//D7000026//D6000275, D6000313, D6000316 add end
//D7000026
//D7000026//D6000275 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[124].envName  = CIMFWStrDup(SP_APCServerName_ForGenIOR);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[124].envValue = CIMFWStrDup( getenv(SP_APCServerName_ForGenIOR) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[125].envName  = CIMFWStrDup(SP_APCHostName_ForGenIOR);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[125].envValue = CIMFWStrDup( getenv(SP_APCHostName_ForGenIOR) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[126].envName  = CIMFWStrDup(SP_APCPortNo_ForGenIOR);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[126].envValue = CIMFWStrDup( getenv(SP_APCPortNo_ForGenIOR) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[127].envName  = CIMFWStrDup(SP_APCMarkerName_ForGenIOR);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[127].envValue = CIMFWStrDup( getenv(SP_APCMarkerName_ForGenIOR) );
//D7000026//D6000275 add end
//D7000026
//D7000026//D6000313 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[128].envName  = CIMFWStrDup(SP_XMSServerName_ForGenIOR);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[128].envValue = CIMFWStrDup( getenv(SP_XMSServerName_ForGenIOR) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[129].envName  = CIMFWStrDup(SP_XMSHostName_ForGenIOR);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[129].envValue = CIMFWStrDup( getenv(SP_XMSHostName_ForGenIOR) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[130].envName  = CIMFWStrDup(SP_XMSPortNo_ForGenIOR);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[130].envValue = CIMFWStrDup( getenv(SP_XMSPortNo_ForGenIOR) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[131].envName  = CIMFWStrDup(SP_XMSMarkerName_ForGenIOR);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[131].envValue = CIMFWStrDup( getenv(SP_XMSMarkerName_ForGenIOR) );
//D7000026//D6000313 add end
//D7000026
//D7000026//D6000316 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[132].envName  = CIMFWStrDup(SP_DCSServerName_ForGenIOR);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[132].envValue = CIMFWStrDup( getenv(SP_DCSServerName_ForGenIOR) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[133].envName  = CIMFWStrDup(SP_DCSHostName_ForGenIOR);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[133].envValue = CIMFWStrDup( getenv(SP_DCSHostName_ForGenIOR) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[134].envName  = CIMFWStrDup(SP_DCSPortNo_ForGenIOR);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[134].envValue = CIMFWStrDup( getenv(SP_DCSPortNo_ForGenIOR) );
//D7000026
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[135].envName  = CIMFWStrDup(SP_DCSMarkerName_ForGenIOR);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[135].envValue = CIMFWStrDup( getenv(SP_DCSMarkerName_ForGenIOR) );
//D7000026//D6000316 add end
//D7000026//D6000379 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[136].envName  = CIMFWStrDup(SP_BKUP_COUNT_SEQLEN_INQ);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[136].envValue = CIMFWStrDup( getenv(SP_BKUP_COUNT_SEQLEN_INQ) );
//D7000026//D6000379 add end
//D7000026//D6000398 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[137].envName  = CIMFWStrDup(SP_DCDEFDCSPEC_RELATION_CHECK_FLAG);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[137].envValue = CIMFWStrDup( getenv(SP_DCDEFDCSPEC_RELATION_CHECK_FLAG) );
//D7000026//D6000398 add end
//D7000026//D6000389 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[138].envName = CIMFWStrDup(SP_LOTFAMILY_DUPLICATION_ALLOWABLE_FLAG);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[138].envValue = CIMFWStrDup( getenv(SP_LOTFAMILY_DUPLICATION_ALLOWABLE_FLAG) );
//D7000026//D6000389 add end
//D7000026//D7000006 add start
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[139].envName = CIMFWStrDup(SP_CONTROLJOB_STATUS_CHANGE_HISTORY_MASK);
//D7000026        strEnvironmentVariable_Get_out.strPptEnvVariable[139].envValue = CIMFWStrDup( getenv(SP_CONTROLJOB_STATUS_CHANGE_HISTORY_MASK) );
//D7000026//D7000006 add end
//D7000026 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(BRS_HOST_NAME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(BRS_HOST_NAME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(BRS_SERVER_NAME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(BRS_SERVER_NAME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_BindEverytime_CSS);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_BindEverytime_CSS) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_BindEverytime_RTD);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_BindEverytime_RTD) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_BindEverytime_SPC);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_BindEverytime_SPC) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_BindEverytime_TCS);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_BindEverytime_TCS) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_BindEverytime_XMS);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_BindEverytime_XMS) );
//D7000096        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_DELIVERY_REQ_EXIST);
//D7000096        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DELIVERY_REQ_EXIST) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_E10PRIORITY_FILE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_E10PRIORITY_FILE) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_NOSCHEDULE_FOR_CHILDLOT);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_NOSCHEDULE_FOR_CHILDLOT) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_ZONE_TYPE_FLAG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_ZONE_TYPE_FLAG) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_ZONE_TYPE_INI);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_ZONE_TYPE_INI) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_EnvName_MaximumWafersInALot);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_EnvName_MaximumWafersInALot) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_FIXTURE_SEQLEN_FOR_OPEHIS_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_FIXTURE_SEQLEN_FOR_OPEHIS_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_LOT_ON_PORT_SEQLEN_FOR_EQPINFO_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_LOT_ON_PORT_SEQLEN_FOR_EQPINFO_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_Max_Script_Execution);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_Max_Script_Execution) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_MessageQueueNeed_STRING);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_MessageQueueNeed_STRING) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_PD_EQP_SEQLEN_FOR_OPELIST_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_PD_EQP_SEQLEN_FOR_OPELIST_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_PORT_SEQLEN_FOR_EQPINFO_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_PORT_SEQLEN_FOR_EQPINFO_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_RCPPARM_SEQLEN_FOR_OPEHIS_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RCPPARM_SEQLEN_FOR_OPEHIS_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_RTD_Available);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RTD_Available) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_RTD_HOST_NAME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RTD_HOST_NAME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_RTD_Health_Rpt_Enforce);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RTD_Health_Rpt_Enforce) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_RTD_Health_Rpt_Interval);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RTD_Health_Rpt_Interval) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_RTD_SERVER_NAME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RTD_SERVER_NAME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_SPC_HOST_NAME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_SPC_HOST_NAME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_SPC_SERVER_NAME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_SPC_SERVER_NAME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_SendToTCS_In_Offline);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_SendToTCS_In_Offline) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_TX_Timeout_CSS);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_TX_Timeout_CSS) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_TX_Timeout_RTD);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_TX_Timeout_RTD) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_TX_Timeout_SPC);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_TX_Timeout_SPC) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_TX_Timeout_TCS);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_TX_Timeout_TCS) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_TX_Timeout_XMS);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_TX_Timeout_XMS) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_XMS_HOST_NAME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_XMS_HOST_NAME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_XMS_SERVER_NAME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_XMS_SERVER_NAME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_PD_SEQLEN_FOR_OPELIST_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_PD_SEQLEN_FOR_OPELIST_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_APC_SERVER_NAME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_APC_SERVER_NAME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_APC_HOST_NAME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_APC_HOST_NAME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_BindEverytime_APC);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_BindEverytime_APC) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_RETICLE_SEQLEN_FOR_OPEHIS_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RETICLE_SEQLEN_FOR_OPEHIS_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(MM_CATALOG_FILE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(MM_CATALOG_FILE) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_LOCK_TIMEOUT);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_LOCK_TIMEOUT) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_MULTIPLESERVER);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_MULTIPLESERVER) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_ACTIONLIST_SEQLEN_FOR_WAFERSORTER_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_ACTIONLIST_SEQLEN_FOR_WAFERSORTER_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_BANK_SEQLEN_FOR_BANKLIST_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_BANK_SEQLEN_FOR_BANKLIST_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_BIND_RETRY_COUNT_TCS);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_BIND_RETRY_COUNT_TCS) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_BIND_SLEEP_TIME_TCS);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_BIND_SLEEP_TIME_TCS) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_DCDEF_SEQLEN_FOR_CDHIS_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DCDEF_SEQLEN_FOR_CDHIS_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_DCITEM_SEQLEN_FOR_CDHIS_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DCITEM_SEQLEN_FOR_CDHIS_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_LOTQTIME_SEQLEN_FOR_QRESTLOT_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_LOTQTIME_SEQLEN_FOR_QRESTLOT_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_NEXTBANK_SEQLEN_FOR_BANKLIST_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_NEXTBANK_SEQLEN_FOR_BANKLIST_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_OPEHIS_SEQLEN_FOR_OPEHIS_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_OPEHIS_SEQLEN_FOR_OPEHIS_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_OPEHIS_SEQLEN_FOR_OPEHIS_INQ_WITH_PINPOINT);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_OPEHIS_SEQLEN_FOR_OPEHIS_INQ_WITH_PINPOINT) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_PORT_CATEGORY_CAPABILITY_LEN);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_PORT_CATEGORY_CAPABILITY_LEN) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_PRODUCT_SEQLEN_FOR_PRDLST_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_PRODUCT_SEQLEN_FOR_PRDLST_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_QRESTLOT_SEQLEN_FOR_QRESTLOT_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_QRESTLOT_SEQLEN_FOR_QRESTLOT_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_RETICLEPOD_SEQLEN_FOR_RTCLSTK_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RETICLEPOD_SEQLEN_FOR_RTCLSTK_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_RETICLE_SEQLEN_FOR_RTCLSTK_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RETICLE_SEQLEN_FOR_RTCLSTK_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_SRCPRODUCT_SEQLEN_FOR_PRDLST_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_SRCPRODUCT_SEQLEN_FOR_PRDLST_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_TX_Timeout_APC);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_TX_Timeout_APC) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_APC_Available);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_APC_Available) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_TCS_SERVER_NAME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_TCS_SERVER_NAME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_CTRLLOT_PRTYCLASS);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CTRLLOT_PRTYCLASS) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_MM_QUERY_SERVER);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_MM_QUERY_SERVER ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_LOT_CASSETTE_ON_PORT_CHECK_FLAG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_LOT_CASSETTE_ON_PORT_CHECK_FLAG) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_LOT_DELETION_RESERVE_PERIOD);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_LOT_DELETION_RESERVE_PERIOD) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_CASETTE_XFER_HISTORY);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CASETTE_XFER_HISTORY) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_RETICLEPOD_XFER_HISTORY);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RETICLEPOD_XFER_HISTORY) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_RETICLE_XFER_HISTORY);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RETICLE_XFER_HISTORY) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_FIXTURE_XFER_HISTORY);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_FIXTURE_XFER_HISTORY) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup( EVENT_IPCKEY_MM );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(EVENT_IPCKEY_MM) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup( SP_TRANSACTION_TIMEOUT );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_TRANSACTION_TIMEOUT) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup( SP_TRANSACTION_LOGGING );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_TRANSACTION_LOGGING) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup( SP_ORBIX_DAEMON_PORT );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_ORBIX_DAEMON_PORT) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup( SP_ENTITY_INHIBIT_USE_WILDCARD );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_ENTITY_INHIBIT_USE_WILDCARD) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup( SP_WILDCARD_CHAR );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_WILDCARD_CHAR) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup( SP_BIND_TIMEOUT_TCS );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_BIND_TIMEOUT_TCS) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_ALARMLIST_SEQLEN_FOR_EQP_ALARM_HISTORY_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_ALARMLIST_SEQLEN_FOR_EQP_ALARM_HISTORY_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_ALARMLIST_SEQLEN_DEFAULT_FOR_EQP_ALARM_HISTORY_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_ALARMLIST_SEQLEN_DEFAULT_FOR_EQP_ALARM_HISTORY_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_LOTLIST_SEQLEN_FOR_LOT_LIST_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_LOTLIST_SEQLEN_FOR_LOT_LIST_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_LOTLIST_SEQLEN_DEFAULT_FOR_LOT_LIST_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_LOTLIST_SEQLEN_DEFAULT_FOR_LOT_LIST_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_SmartTCS_Available);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_SmartTCS_Available) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_LOT_SCHDCHANGE_RESERVE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_LOT_SCHDCHANGE_RESERVE) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_EBrokerTCS_Available);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_EBrokerTCS_Available) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_LOTLIST_MAX_SEQLEN_FOR_LOT_LIST_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_LOTLIST_MAX_SEQLEN_FOR_LOT_LIST_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_DATAVALUE_ASTERISK_SAVEFLAG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DATAVALUE_ASTERISK_SAVEFLAG) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_ZONETYPE_NEED_FLAG_IN_CASTLIST);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_ZONETYPE_NEED_FLAG_IN_CASTLIST) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_TAKEOUT_XFER_IN_NOTAVAILABLE_STATE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_TAKEOUT_XFER_IN_NOTAVAILABLE_STATE) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_OPEHIS_MAX_SEQLEN_FOR_OPEHIS_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_OPEHIS_MAX_SEQLEN_FOR_OPEHIS_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_CASSETTELIST_SEQLEN_DEFAULT_FOR_CASSETTE_LIST_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CASSETTELIST_SEQLEN_DEFAULT_FOR_CASSETTE_LIST_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_CASSETTELIST_SEQLEN_FOR_CASSETTE_LIST_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CASSETTELIST_SEQLEN_FOR_CASSETTE_LIST_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_CASSETTELIST_SEQLEN_MAX_FOR_CASSETTE_LIST_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CASSETTELIST_SEQLEN_MAX_FOR_CASSETTE_LIST_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_RETICLELIST_SEQLEN_DEFAULT_FOR_RETICLE_LIST_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RETICLELIST_SEQLEN_DEFAULT_FOR_RETICLE_LIST_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_RETICLELIST_SEQLEN_FOR_RETICLE_LIST_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RETICLELIST_SEQLEN_FOR_RETICLE_LIST_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_RETICLELIST_SEQLEN_MAX_FOR_RETICLE_LIST_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RETICLELIST_SEQLEN_MAX_FOR_RETICLE_LIST_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_ALARMLIST_SEQLEN_MAX_FOR_EQP_ALARM_HISTORY_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_ALARMLIST_SEQLEN_MAX_FOR_EQP_ALARM_HISTORY_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_SCREENLIMITOVER_NOTCALCULATE_FLAG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_SCREENLIMITOVER_NOTCALCULATE_FLAG) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_PrivilegeCheck_BY_DR_FLAG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_PrivilegeCheck_BY_DR_FLAG) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_REROUTE_XFER_FLAG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_REROUTE_XFER_FLAG) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_PROHIBIT_CHARACTER);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_PROHIBIT_CHARACTER) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_ORBIX_DEFAULT_TIMEOUT);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_ORBIX_DEFAULT_TIMEOUT) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_STAYONPORT_WITH_NO_DESTINATION);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_STAYONPORT_WITH_NO_DESTINATION) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup( SP_SOOR_INHIBIT_CANCEL_BY_ACK );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv( SP_SOOR_INHIBIT_CANCEL_BY_ACK ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup( SP_WSPC_SERVER_NAME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_WSPC_SERVER_NAME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_WSPC_HOST_NAME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_WSPC_HOST_NAME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_DCS_SERVER_NAME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DCS_SERVER_NAME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_DCS_HOST_NAME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DCS_HOST_NAME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_BindEverytime_DCS);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_BindEverytime_DCS) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_TX_Timeout_DCS);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_TX_Timeout_DCS) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_DCS_Available);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DCS_Available) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_DCS_Ignore_OpeStart_Result);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DCS_Ignore_OpeStart_Result) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_DCS_Ignore_OpeStartCancel_Result);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DCS_Ignore_OpeStartCancel_Result) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_DCS_Ignore_OpeComp_Result);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DCS_Ignore_OpeComp_Result) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_MM_SYSTEM_NAME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_MM_SYSTEM_NAME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_APC_SYSTEM_NAME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_APC_SYSTEM_NAME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_INHIBIT_DURATION);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_INHIBIT_DURATION) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_INHIBIT_WHEN_APC_RPARMADJUST_NG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_INHIBIT_WHEN_APC_RPARMADJUST_NG) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_INHIBIT_WHILE_APCIF_DEFINE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_INHIBIT_WHILE_APCIF_DEFINE) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_HISTORY_EVENTFIFO_DISTRIBUTE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_HISTORY_EVENTFIFO_DISTRIBUTE) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_APCENTVAL_MAX_COUNT);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_APCENTVAL_MAX_COUNT) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_INHIBIT_MAX_SEQLEN_FOR_INHIBIT_LIST_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_INHIBIT_MAX_SEQLEN_FOR_INHIBIT_LIST_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_RCOK_NoData_For_ListInq);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RCOK_NoData_For_ListInq) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_CheckExistenceFlag);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CheckExistenceFlag) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_APCServerName_ForGenIOR);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_APCServerName_ForGenIOR) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_APCHostName_ForGenIOR);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_APCHostName_ForGenIOR) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_APCPortNo_ForGenIOR);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_APCPortNo_ForGenIOR) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_APCMarkerName_ForGenIOR);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_APCMarkerName_ForGenIOR) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_XMSServerName_ForGenIOR);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_XMSServerName_ForGenIOR) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_XMSHostName_ForGenIOR);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_XMSHostName_ForGenIOR) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_XMSPortNo_ForGenIOR);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_XMSPortNo_ForGenIOR) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_XMSMarkerName_ForGenIOR);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_XMSMarkerName_ForGenIOR) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_DCSServerName_ForGenIOR);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DCSServerName_ForGenIOR) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_DCSHostName_ForGenIOR);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DCSHostName_ForGenIOR) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_DCSPortNo_ForGenIOR);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DCSPortNo_ForGenIOR) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_DCSMarkerName_ForGenIOR);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DCSMarkerName_ForGenIOR) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_BKUP_COUNT_SEQLEN_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_BKUP_COUNT_SEQLEN_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_DCDEFDCSPEC_RELATION_CHECK_FLAG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DCDEFDCSPEC_RELATION_CHECK_FLAG) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_LOTFAMILY_DUPLICATION_ALLOWABLE_FLAG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_LOTFAMILY_DUPLICATION_ALLOWABLE_FLAG) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_CONTROLJOB_STATUS_CHANGE_HISTORY_MASK);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CONTROLJOB_STATUS_CHANGE_HISTORY_MASK) );
//D7000182 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(SP_Rollback_Notify_To_APC);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_Rollback_Notify_To_APC) );
//D7000182 add end
//D7000183 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_MINIMUM_BATCH_CONDITION_APPLY_FLAG_FOR_DELIVERY);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_MINIMUM_BATCH_CONDITION_APPLY_FLAG_FOR_DELIVERY) );
//D7000183 add end
//D7000219 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_CASSETTE_RELATION_CHECK_FOR_HOLD);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CASSETTE_RELATION_CHECK_FOR_HOLD) );
//D7000219 add end
//P7000243 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_DR_RETRY_COUNT);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DR_RETRY_COUNT) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_DR_RETRY_INTERVAL);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DR_RETRY_INTERVAL) );
//P7000243 add end
//D7000371 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_SHORTEST_QTIME_USE_FLAG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_SHORTEST_QTIME_USE_FLAG) );
//D7000371 add end
//D8000024 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_FPC_Adaptation_Flag);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_FPC_Adaptation_Flag) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_FPC_ContinuousSkipLimit);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_FPC_ContinuousSkipLimit) );
//D8000024 add end
//D8000084 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i  ].envName  = CIMFWStrDup( SP_CARRIER_CAPACITY );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv( SP_CARRIER_CAPACITY ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i  ].envName  = CIMFWStrDup( SP_CARRIER_NOMINALSIZE );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv( SP_CARRIER_NOMINALSIZE ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i  ].envName  = CIMFWStrDup( SP_INSTANCE_NAME );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv( SP_INSTANCE_NAME ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i  ].envName  = CIMFWStrDup( SP_CARRIER_BASEINFO_UPDATE_CHECK );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv( SP_CARRIER_BASEINFO_UPDATE_CHECK ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i  ].envName  = CIMFWStrDup( SP_RETICLEPOD_BASEINFO_UPDATE_CHECK );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv( SP_RETICLEPOD_BASEINFO_UPDATE_CHECK ) );
//D8000084 Add End
//P8000082 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_MONITOR_WAIT_HOLD_NEW_LOGIC);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_MONITOR_WAIT_HOLD_NEW_LOGIC) );
//P8000082 add end
//P8000118 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_RETICLEPOD_XFER_STATUS_CHANGE_LIMITING);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RETICLEPOD_XFER_STATUS_CHANGE_LIMITING) );
//P8000118 add end
//D8000184 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_EQP_STATUS_TRANSITION_LIMITATION);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_EQP_STATUS_TRANSITION_LIMITATION) );
//D8000184 add end
//D8000186 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_LOT_DELETION_CHECK_EVENT_FLAG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_LOT_DELETION_CHECK_EVENT_FLAG) );
//D8000186 add end
//D8000204 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_ENTITY_INHIBIT_THRESHOLD_COUNT);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_ENTITY_INHIBIT_THRESHOLD_COUNT) );
//D8000204 add end
//D9000003 delete start
////D8000207 add start
//        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_OPER_START_WAFER_FLAG_CONTROL);
//        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_OPER_START_WAFER_FLAG_CONTROL) );
////D8000207 add end
//D9000003 delete end
//D9000053 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_EQP_MODE_CHANGE_OFFLINE_TO_ONLINE_POSSIBLE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_EQP_MODE_CHANGE_OFFLINE_TO_ONLINE_POSSIBLE) );
//D9000053add end
//D9000084 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_ARMS_FUNC_ENABLED);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_ARMS_FUNC_ENABLED) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_RSP_ON_PORT_CHECK_FLAG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RSP_ON_PORT_CHECK_FLAG) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_RXM_HOST_NAME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RXM_HOST_NAME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_RXM_SERVER_NAME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RXM_SERVER_NAME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_RXMSHostName_ForGenIOR);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RXMSHostName_ForGenIOR) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_RXMSServerName_ForGenIOR);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RXMSServerName_ForGenIOR) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_RXMSMarkerName_ForGenIOR);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RXMSMarkerName_ForGenIOR) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_RXMSPortNo_ForGenIOR);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RXMSPortNo_ForGenIOR) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_BindEverytime_RXM);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_BindEverytime_RXM) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_TX_Timeout_RXM);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_TX_Timeout_RXM) );
//D9000084 add end
//D9000079 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_FlowBatch_Cleared_By_OperStart);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_FlowBatch_Cleared_By_OperStart) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_FlowBatch_Cleared_By_OperCancel);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_FlowBatch_Cleared_By_OperCancel) );
//D9000079 add end
//D9000056 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_LOCK_HOLD_USE_FLAG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_LOCK_HOLD_USE_FLAG) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_POSTPROC_FLAG_USE_FLAG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_POSTPROC_FLAG_USE_FLAG) );
//D9000056 add end
//P9000222 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_SPLIT_LOT_REQUEUE_FLAG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_SPLIT_LOT_REQUEUE_FLAG) );
//P9000222 add end
//D9000175 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_DELIVERY_TAKE_OUTIN_ENABLE_FLAG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DELIVERY_TAKE_OUTIN_ENABLE_FLAG) );
//D9000175 add end
//D9000228 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_HOLDEQP_UPDATE_FLAG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_HOLDEQP_UPDATE_FLAG) );
//D9000228 add end
//DSIV00000099 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_SLM_SRC_CAST_PRIORITY);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_SLM_SRC_CAST_PRIORITY) );
//DSIV00000099 add end
//D9000246 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_FRLOTPO_MAINTENANCE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_FRLOTPO_MAINTENANCE) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_FRLOTPO_CHECK_FOR_DELETE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_FRLOTPO_CHECK_FOR_DELETE) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_CHECK_FOR_DELETE_STAGE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CHECK_FOR_DELETE_STAGE) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_CHECK_FOR_DELETE_SCRIPT);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CHECK_FOR_DELETE_SCRIPT) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_CHECK_FOR_DELETE_DCDEF);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CHECK_FOR_DELETE_DCDEF) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_CHECK_FOR_DELETE_DCSPEC);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CHECK_FOR_DELETE_DCSPEC) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_CHECK_FOR_DELETE_STORAGEMACHINE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CHECK_FOR_DELETE_STORAGEMACHINE) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_CHECK_FOR_DELETE_LOGICALRECIPE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CHECK_FOR_DELETE_LOGICALRECIPE) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_CHECK_FOR_DELETE_MACHINERECIPE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CHECK_FOR_DELETE_MACHINERECIPE) );
//D9000246 add end
//DSIV00000201 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_POSTPROC_FOR_LOT_FLAG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_POSTPROC_FOR_LOT_FLAG) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_ExternalPostProc_UseFlag);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_ExternalPostProc_UseFlag) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_ExternalPostProc_UserGrp);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_ExternalPostProc_UserGrp) );
//DSIV00000201 end
//DSIV00000220 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_LOT_STBCANCEL);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_LOT_STBCANCEL) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_LOT_PREPARECANCEL);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_LOT_PREPARECANCEL) );
//DSIV00000220 add end
//DSIV00000286 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_USE_CDR_FOR_AUTO3DISPATCH);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_USE_CDR_FOR_AUTO3DISPATCH) );
//DSIV00000286 add end
//DSIV00000214 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_FAB_ID);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_FAB_ID) );
//DSIV00000214 add end
//DSIV00001049 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_AUTH_AUTHSERVER_AVAILABLE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_AUTH_AUTHSERVER_AVAILABLE) );
//DSIV00001049 add end
//DSIV00001365 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_WSPC_LINK_URL);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_WSPC_LINK_URL) );
//DSIV00001365 add end
//DSIV00001021 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_MULTI_CORRESOPE_MODE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_MULTI_CORRESOPE_MODE) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_MULTI_CORRESOPE_MERGE_RULE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_MULTI_CORRESOPE_MERGE_RULE) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_CORRES_DEFAULT_MODE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CORRES_DEFAULT_MODE) );
//DSIV00001021 add end
//DSIV00001441 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_SCRIPTPARAMETER_CHANGE_EVENT);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_SCRIPTPARAMETER_CHANGE_EVENT) );
//DSIV00001441 add end
//DSIV00001471 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_DC_DATA_CHECK_LEVEL);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DC_DATA_CHECK_LEVEL) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_DC_DATA_CHECK_PHASE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DC_DATA_CHECK_PHASE) );
//DSIV00001471 add end
//DSIV00001443 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_ENTITY_INHIBIT_SEARCH_CONDITION);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_ENTITY_INHIBIT_SEARCH_CONDITION) );
//DSIV00001443 add end
//DSIV00001481 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_USE_DB_TIMESTAMP);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_USE_DB_TIMESTAMP) );
//DSIV00001481 add end
//DSIV00002162 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_OWNER_CHANGE_MAX_COMMIT_COUNT);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_OWNER_CHANGE_MAX_COMMIT_COUNT) );
//DSIV00002162 add end
//PSN000090028 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_OWNER_CHANGE_DELETE_DUPLICATE_RECORD);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_OWNER_CHANGE_DELETE_DUPLICATE_RECORD) );
//PSN000090028 Add End
//DSIV00001788 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_CASSETTE_LOAD_SEQUENCE_CONDITION);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CASSETTE_LOAD_SEQUENCE_CONDITION) );
//DSIV00001788 add end
//DSIV00002458 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_EQPSTAT_BACKUP);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_EQPSTAT_BACKUP) );
//DSIV00002458 add end
//DSIV00002326 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_DURABLEHIS_MAX_SEQLEN_FOR_DURABLEHIS_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DURABLEHIS_MAX_SEQLEN_FOR_DURABLEHIS_INQ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_EQUIPMENTHIS_MAX_SEQLEN_FOR_EQUIPMENTHIS_INQ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_EQUIPMENTHIS_MAX_SEQLEN_FOR_EQUIPMENTHIS_INQ) );
//DSIV00002326 add end
//DSIV00002270 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_POMAINT_EVENT_CREATE_TYPE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_POMAINT_EVENT_CREATE_TYPE) );
//DSIV00002270 add end
//PSIV00003221 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_BRANCH_RETURN_ACTIVE_MODULE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_BRANCH_RETURN_ACTIVE_MODULE) );
//PSIV00003221 add end

//DSN000015229 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_DCS_PJCTRL_AVAILABLE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DCS_PJCTRL_AVAILABLE) );

        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_DCS_IGNORE_PJRPT_RESULT);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DCS_IGNORE_PJRPT_RESULT) );

        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_PJCTRL_FUNC_ENABLED);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_PJCTRL_FUNC_ENABLED) );

//PSN000035912        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_PROCESSHIS_MAX_SEQLEN_FOR_PROCESSHIS_INQ);
//PSN000035912        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_PROCESSHIS_MAX_SEQLEN_FOR_PROCESSHIS_INQ) );
//DSN000015229 Add End
//DSN000022151 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_KEEP_QTIME_ON_SCHCHANGE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_KEEP_QTIME_ON_SCHCHANGE) );
//DSN000022151 Add End
//DSN000033655 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_QTIMEINFO_MERGE_RULE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_QTIMEINFO_MERGE_RULE) );
//DSN000033655 Add End

//DSN000041192 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_LAGTIMEINFO_MERGE_RULE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_LAGTIMEINFO_MERGE_RULE) );
//DSN000041192 Add End
//DSN000041621 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_EQP_UDATA_MODE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_EQP_UDATA_MODE) );
//DSN000041621 add end
//DSN000041626 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_CTRLJOBID_GEN_BY_DISP);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CTRLJOBID_GEN_BY_DISP) );
//DSN000041626 add end
//DSN000041636 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_LAST_USED_RECIPE_UPDATE_FLAG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_LAST_USED_RECIPE_UPDATE_FLAG) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_EQPATTR_UPDATE_BY_POSTPROC);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_EQPATTR_UPDATE_BY_POSTPROC) );
//DSN000041636 add end
//DSN000043340 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_POSTPROC_SEARCH_SEPARATOR_CHAR);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_POSTPROC_SEARCH_SEPARATOR_CHAR) );
//DSN000043340 add end
//PSN000043994 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_CHAMBER_CHECK_POLICY);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CHAMBER_CHECK_POLICY) );
//PSN000043994 Add End
//DSN000049350 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_EQP_LOCK_MODE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_EQP_LOCK_MODE) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_SORTERJOB_LOCK_FLAG);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_SORTERJOB_LOCK_FLAG) );
//DSN000049350 Add End
//DSN000050720 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_POSTPROC_PARALLEL_SWITCH);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_POSTPROC_PARALLEL_SWITCH) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_POSTPROC_PARALLEL_WORKER_SEARCH_RETRY);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_POSTPROC_PARALLEL_WORKER_SEARCH_RETRY) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_POSTPROC_PARALLEL_RETRY_SLEEP_TIME);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_POSTPROC_PARALLEL_RETRY_SLEEP_TIME) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_POSTPROC_PARALLEL_ACTION_RETRY_COUNT);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_POSTPROC_PARALLEL_ACTION_RETRY_COUNT) );
//DSN000050720 Add End
//PSN000068955 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_PROPERTYSET_CREATE_ENABLED);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_PROPERTYSET_CREATE_ENABLED) );
//PSN000068955 add end
//DSN000075358 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_SCRIPTPARAMETER_UPDATE_MODE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_SCRIPTPARAMETER_UPDATE_MODE) );
//DSN000075358 add end
//DSN000071674 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_LOT_OPERATION_EI_CHECK);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_LOT_OPERATION_EI_CHECK) );
//DSN000071674 Add End
//PSN000075397 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_PROPERTYSET_FOR_FACTORY_USE_SYSTEM_KEY_0);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_PROPERTYSET_FOR_FACTORY_USE_SYSTEM_KEY_0) );
//PSN000075397 add end
//DSN000075522 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_CREATE_PROPERTYSET_FOR_NEW_LOT);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_CREATE_PROPERTYSET_FOR_NEW_LOT) );
//DSN000075522 add end
//DSN000080287 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_KEEP_QTIME_ACTION_ON_CLEAR);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_KEEP_QTIME_ACTION_ON_CLEAR) );
//DSN000080287 Add End
//DSN000080226 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_PRIVILEGECHECK_FOR_CJ);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_PRIVILEGECHECK_FOR_CJ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_PRIVILEGECHECK_FOR_CAST);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_PRIVILEGECHECK_FOR_CAST) );
//DSN000080226 add end
//DSN000081739 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_EQPMONITOR_SWITCH);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_EQPMONITOR_SWITCH) );
//DSN000081739 add end
//DSN000075328 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_POSTPROC_CHAINED_MODE);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_POSTPROC_CHAINED_MODE) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_POSTPROC_MAX_CHAIN_EXEC);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_POSTPROC_MAX_CHAIN_EXEC) );
//DSN000075328 add end
//DSN000076129 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_DCSPEC_FOR_PROCESS);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DCSPEC_FOR_PROCESS) );
//DSN000076129 Add End
//DSN000085024 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_WARNING_ON_PSM_REGISTRATION);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_WARNING_ON_PSM_REGISTRATION) );
//DSN000085024 Add End
//PSN000081348 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_PROCESSHOLD_ALLOW_LOTMOVEMENT);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_PROCESSHOLD_ALLOW_LOTMOVEMENT) );
//PSN000081348 Add End
//DSN000085698 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_RESET_EQPMON_USED_COUNT_ON_STB);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RESET_EQPMON_USED_COUNT_ON_STB) );
//DSN000085698 Add End
//DSN000085793 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName  = CIMFWStrDup(SP_WIP_LOT_RESET_UPDATE_LEVEL);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_WIP_LOT_RESET_UPDATE_LEVEL) );
//DSN000085793 Add End
//DSN000085792 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_INACTIVE_QTIME_LIST);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_INACTIVE_QTIME_LIST) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_QTIME_REPLACETRIGGER_MAINPD_PRIORITY);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_QTIME_REPLACETRIGGER_MAINPD_PRIORITY) );
//DSN000085792 Add End
//DSN000100527 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_BANKINCANCEL_PRODUCT_CHECK);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_BANKINCANCEL_PRODUCT_CHECK) );
//DSN000100527 Add End
//DSN000096144 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_USER_PRIVILEGE_POLICY);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_USER_PRIVILEGE_POLICY) );
//DSN000096144 add end
//DSN000096141 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_PASSCOUNT_WAFERLEVEL_CONTROL);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_PASSCOUNT_WAFERLEVEL_CONTROL) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_PASSCOUNT_WAFERLEVEL_EVENT_CREATION);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_PASSCOUNT_WAFERLEVEL_EVENT_CREATION) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_LOT_OPERATION_MOVE_EVENT_CREATION_FOR_STB);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_LOT_OPERATION_MOVE_EVENT_CREATION_FOR_STB) );
//DSN000096141 add end
//PSN000101301 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_QTIME_DISPATCHPRECEDE_USE_CUSTOMFIELD);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_QTIME_DISPATCHPRECEDE_USE_CUSTOMFIELD) );
//PSN000101301 add end
//DSN000102497 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_DCS_REPORT);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DCS_REPORT) );
//DSN000102497 add end
//DSN000101569 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_DURABLE_SUBSTATUS_TRANSITION_LIMITATION);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DURABLE_SUBSTATUS_TRANSITION_LIMITATION) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_RETRIEVE_RETICLE_DURING_LOTPROCESS);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_RETRIEVE_RETICLE_DURING_LOTPROCESS) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_DURABLEPROCESS_FOR_NON_EMPTY_CARRIER);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DURABLEPROCESS_FOR_NON_EMPTY_CARRIER) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(SP_DURABLEPROCESS_FOR_NON_EMPTY_RETICLEPOD);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(SP_DURABLEPROCESS_FOR_NON_EMPTY_RETICLEPOD) );
//DSN000101569 add end
//DSN000101643 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup( SP_ENCRYPT_PASSWORD );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv( SP_ENCRYPT_PASSWORD ) );
//DSN000101643 Add End
//DSN000104510 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup( SP_DISPATCH_CAST_CLEARED_BY_CHANGE_TO_ONLINE );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv( SP_DISPATCH_CAST_CLEARED_BY_CHANGE_TO_ONLINE ) );
//DSN000104510 add end
//PSN000105028 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup( SP_FRLOTPO_DELETE_FOR_SCRAPPED );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv( SP_FRLOTPO_DELETE_FOR_SCRAPPED ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup( SP_FRLOTPO_DELETE_FOR_EMPTIED );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv( SP_FRLOTPO_DELETE_FOR_EMPTIED ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup( SP_FRLOTPO_DELETE_FOR_SHIPPED );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv( SP_FRLOTPO_DELETE_FOR_SHIPPED ) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup( SP_FRLOTPO_DELETE_FOR_STACKED );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv( SP_FRLOTPO_DELETE_FOR_STACKED ) );
//PSN000105028 add end
//INN-A170001 add start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup( CS_SP_RMS_HOST_NAME                 );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(CS_SP_RMS_HOST_NAME)         );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup( CS_SP_RMS_MARKER_NAME               );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(CS_SP_RMS_MARKER_NAME)       );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup( CS_SP_RMS_SERVER_NAME               );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(CS_SP_RMS_SERVER_NAME)       );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup( CS_SP_BindEverytime_RMS             );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(CS_SP_BindEverytime_RMS)     );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup( CS_SP_TX_TIMEOUT_RMS                );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(CS_SP_TX_TIMEOUT_RMS)        );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup( CS_SP_BIND_RETRY_COUNT_RMS          );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(CS_SP_BIND_RETRY_COUNT_RMS)  );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup( CS_SP_BIND_SLEEP_TIME_RMS           );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(CS_SP_BIND_SLEEP_TIME_RMS)   );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup( CS_SP_RMS_CHECK_ONLINE_FLAG         );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(CS_SP_RMS_CHECK_ONLINE_FLAG) );
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName    = CIMFWStrDup(CS_RMS_IGNOREAUDIT_EQPLIST);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup( getenv(CS_RMS_IGNOREAUDIT_EQPLIST) );
//INN-A170001 add end

//INN-R170008 Add Start
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(CS_TACERTIFY_SKILL_EXP_DURATION);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup(getenv(CS_TACERTIFY_SKILL_EXP_DURATION));
        strEnvironmentVariable_Get_out.strPptEnvVariable[i].envName = CIMFWStrDup(CS_TACERTIFY_PRE_ALARM_DURATION);
        strEnvironmentVariable_Get_out.strPptEnvVariable[i++].envValue = CIMFWStrDup(getenv(CS_TACERTIFY_PRE_ALARM_DURATION));
//INN-R170008 Add End

        strEnvironmentVariable_Get_out.strPptEnvVariable.length(i);
//D7000026 add end

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::environmentVariable_Get");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strEnvironmentVariable_Get_out, environmentVariable_Get, methodName)
}
