#ifndef lint
static char *sccsid =  "@(#) 1.2 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_multiLotType_Update.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 1/23/08 15:09:33 [ 1/23/08 15:09:34 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// SiView
// Name: cs_cassette_multiLotType_UpdateOR.cpp
//

#include "cs_pptmgr.hpp"

#include "pcas.hh"
#include "plcrc.hh"
#include "plot.hh"
#include "ppcope.hh"
#include "pprsp.hh"
#include "pwafer.hh"  // D4000098
//[Object Function Name]: long   cassette_multiLotType_Update
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2000-07-24  0.00      H.Ueda         Initial Release (R30)
// 2000-08-29  0.01      H.Ueda         Change to MultiLotMultiRecipe for MultiLot included inprocessing lot.
// 2000-09-07  0.02      H.Ueda         Set blank to multiLotType if Empty cassette.
// 2000-09-21  Q3000124  K.Matsuei      Nil Check
// 2000-09-21  0.03      H.Ueda         Set ML_MR if one of lots has no LogicalRecipe in cassette.
// 2000/10/23  P3000280  K.Matsuei      CORBA::Boolean does not initialized. sometime It causes error.
// 2001/08/22  D4000098  Y.Yoshihara    Add ScrapWafer Handling action
// 2002/01/09  P4100057  K.Matsuei      Memory Leak by PPT_METHODTRACE_Vx.
// 2002/05/13  P4100425  K.Matsuei      The number of Parameters to assemble Message in PPT_SET_MSG_RC_KEY*** mistakes it.
// 2003/07/08  D5000129  K.Matsuei      Wafer object is reactivated for ScrapWafer's existence check in cassette_multiLotType_Update.
// 2003/10/16  P5100038  H.Adachi       Add Transaction ID for ScrapWafer's existence check.
// 2006/12/05  D8000024  H.Mutoh        When the lot has FPC definition, cassette's multiLotType is updated to 'ML-MR'.
// 2008/01/23  P9000178  M.Ishino       The 'ML-MR' update logic for FPC is moved.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2013/01/24 DSN000050720 M.Ogawa        Don't update cassette's MultiLotType under Post Process parallel execution
//
//
// Innotron Modification History
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/20 INN-R170003  Joan Zhou      Change FOUP status in system control
//
//
//[Function Description]:
//  Update the specified cassette's MultiLotType according to the following cases.
//  Get all lots in the specified cassette.
//  For all lots, check HoldState, ProcessState and InventoryState and get each LogicalRecipeID by each,
//  then check if all of LogicalRecipeID are same or not.
//  Set MultiLotType as belows and return its value accroding to the combination of Lots in carrier.
//
//  D4000098 Add ScrapWafer Handling Routine
//  <ScrapWafer Exist>
//  If there are scrap Wafers in cassette, then MultiLotType turned to SP_Cas_MultiLotType_MultiLotSingleRecipe
//   --------------------------------------------------------------------------------------------------
//  |Case #   | Status                    | Recipe | MultiLotType                                      |
//  |=========|===========================|========|===================================================|
//  |Any Lot  | There are scrap wafer     | R1     | SP_Cas_MultiLotType_MultiLotMultiRecipe  (=MS)    |
//   --------------------------------------------------------------------------------------------------
//
//  <SingleLot case>
//   --------------------------------------------------------------------------------------------------
//  |Case #   | Status                    | Recipe | MultiLotType                                      |
//  |=========|===========================|========|===================================================|
//  |1. Lot-A | WAIT / HOLD / BANK /INPR  | R1     | SP_Cas_MultiLotType_MultiLotSingleRecipe (=MS)    |
//   --------------------------------------------------------------------------------------------------
//
//  <MultiLot and SingleRecipe case>
//   --------------------------------------------------------------------------------------------------
//  |Case #   | Status                    | Recipe | MultiLotType                                      |
//  |=========|===========================|========|===================================================|
//  |1. Lot-A | WAIT / INPR               | R1     | SP_Cas_MultiLotType_MultiLotSingleRecipe (=MS)    |
//  |   Lot-B | WAIT / INPR               | R1     |                                                   |
//  +---------+---------------------------+--------+---------------------------------------------------+
//  |2. Lot-A | WAIT / INPR               | R1     | SP_Cas_MultiLotType_MultiLotMultiRecipe  (=MM)    |
//  |   Lot-B | HOLD / BANK               | R1     |                                                   |
//  +---------+---------------------------+--------+---------------------------------------------------+
//  |3. Lot-A | HOLD / BANK               | R1     | SP_Cas_MultiLotType_MultiLotMultiRecipe  (=MM)    |
//  |   Lot-B | HOLD / BANK               | R1     |                                                   |
//   --------------------------------------------------------------------------------------------------
//
//  <MultiLot and MultiRecipe case>
//   --------------------------------------------------------------------------------------------------
//  |Case #   | Status                    | Recipe | MultiLotType                                      |
//  |=========|===========================|========|===================================================|
//  |1. Lot-A | WAIT / HOLD / BANK /INPR  | R1     | SP_Cas_MultiLotType_MultiLotMultiRecipe  (=MM)    |
//  |   Lot-B | WAIT / HOLD / BANK /INPR  | R2     |                                                   |
//   --------------------------------------------------------------------------------------------------
//
//[Input Parameters]:
//  in  pptObjCommonIn        strObjCommonIn;
//  in  objectIdentifier      cassetteID;
//
//[Output Parameters]:
//  out objCassette_multiLotType_Update_out   strCassette_multiLotType_Update_out;
//
//  typedef struct objCassette_multiLotType_Update_out_struct {
//      pptRetCode            strResult;
//      string                multiLotType;
//  } objCassette_multiLotType_Update_out;
//
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//  RC_NOT_FOUND_CASSETTE     MSG_NOT_FOUND_CASSETTE
//  RC_LOCKED_BY_ANOTHER      MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR           MSG_SYSTEM_ERROR
//  RC_CAST_IS_EMPTY          MSG_CAST_IS_EMPTY
//  RC_NOT_FOUND_PO           MSG_NOT_FOUND_PO
//  RC_NOT_FOUND_PRODUCTSPEC  MSG_NOT_FOUND_PRODUCTSPEC
//  RC_NOT_FOUND_LCRECIPE     MSG_NOT_FOUND_LCRECIPE
//
CORBA::Long  CS_PPTManager_i::cassette_multiLotType_Update(
                                  objCassette_multiLotType_Update_out&  strCassette_multiLotType_Update_out,
                                  const pptObjCommonIn& strObjCommonIn,
                                  const objectIdentifier& cassetteID)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cassette_multiLotType_Update");

        PPT_METHODTRACE_V2("CS_PPTManager_i::cassette_multiLotType_Update", "InParam[cassetteID]",cassetteID.identifier);

        CORBA::Long rc = RC_OK;  //D5000129
        PosCassette_var aCassette;
        //get memory data for one cassetteID
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                               cassetteID,
                                               strCassette_multiLotType_Update_out,
                                               cassette_multiLotType_Update );
        CORBA::Long nLen;
//INN-R170003 Add Start
        /*----------------------------------------------------------------------------*/
        /*   Control Cassette Status between Empty and InUse                          */
        /*----------------------------------------------------------------------------*/
         PosDurableSubState_var aDurableSubState;
         try
         {
             aDurableSubState = aCassette->getDurableSubState();
         }
         CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getDurableSubState)

         CORBA::String_var strDurableSubState;
         if ( CORBA::is_nil(aDurableSubState) )
         {
             PPT_METHODTRACE_V1("", "aDurableSubState is  nil");

             PPT_SET_MSG_RC_KEY( strCassette_multiLotType_Update_out,
                          MSG_NOT_FOUND_DURABLE_SUBSTAT,
                          RC_NOT_FOUND_DURABLE_SUBSTAT,
                          "***");

             return  RC_NOT_FOUND_DURABLE_SUBSTAT;
         }
        strDurableSubState = aDurableSubState->getIdentifier();
        PPT_METHODTRACE_V2("", "aDurableSubState---------------->", strDurableSubState);

        if (CIMFWStrCmp(strDurableSubState, CS_FOUP_DURABLE_SUB_STATE_FRESH) == 0 ||
            CIMFWStrCmp(strDurableSubState, CS_FOUP_DURABLE_SUB_STATE_WAITUSE) == 0 ||
            CIMFWStrCmp(strDurableSubState, CS_FOUP_DURABLE_SUB_STATE_FULLINUSE) == 0 ||
            CIMFWStrCmp(strDurableSubState, CS_FOUP_DURABLE_SUB_STATE_PARTIALINUSE) == 0)
        {
            PPT_METHODTRACE_V2("", "enter strDurableSubState FRESH||WAITUSE||FULLINUSE||PARTIALINUSE", strDurableSubState);
            MaterialSequence * pMaterialsSeq = NULL;
            //MaterialSequence_var varMaterialsSeq;
            try
            {
                pMaterialsSeq = aCassette->containedMaterial();
                //varMaterialsSeq = pMaterialsSeq;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::containedMaterial)

            CORBA::Long lngWaferLen = pMaterialsSeq->length();
            PPT_METHODTRACE_V2("", "lngWaferLen-->", lngWaferLen);

            objDurable_currentState_Change_out          strDurable_currentState_Change_out;
            objDurable_currentState_Change_in           strDurable_currentState_Change_in;
            strDurable_currentState_Change_in.durableID = cassetteID;
            strDurable_currentState_Change_in.durableCategory= CIMFWStrDup(SP_DurableCat_Cassette);
            if ( 0 == lngWaferLen )
            {
                PPT_METHODTRACE_V1("", "lngWaferLen ----------------> 0");
                if (CIMFWStrCmp(strDurableSubState, CS_FOUP_DURABLE_SUB_STATE_FRESH) != 0 &&
                    CIMFWStrCmp(strDurableSubState, CS_FOUP_DURABLE_SUB_STATE_WAITUSE) != 0)
                {
                    PPT_METHODTRACE_V1("", "strDurableSubState !FRESH and !WAITUSE");

                    strDurable_currentState_Change_in.durableStatus               = CIMFWStrDup(CIMFW_Durable_Available);
                    strDurable_currentState_Change_in.durableSubStatus.identifier = CIMFWStrDup(CS_FOUP_DURABLE_SUB_STATE_WAITUSE);
                    PPT_METHODTRACE_V2("", "strDurable_currentState_Change_in.durableSubStatus.identifier", strDurable_currentState_Change_in.durableSubStatus.identifier);
                    PPT_METHODTRACE_V2("", "DurableSubState set ", CS_FOUP_DURABLE_SUB_STATE_WAITUSE);

                    rc = durable_currentState_Change( strDurable_currentState_Change_out,
                                                      strObjCommonIn,
                                                      strDurable_currentState_Change_in);
                    if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V2("", "durable_currentState_Change() rc != RC_OK", rc);
                        strCassette_multiLotType_Update_out.strResult = strDurable_currentState_Change_out.strResult;
                        return(rc);
                    }
                }
            }
            else if ( SP_Cassette_Default_Capacity == lngWaferLen )
            {
                PPT_METHODTRACE_V2("", "lngWaferLen ----------------> ", SP_Cassette_Default_Capacity);
                if (CIMFWStrCmp(strDurableSubState, CS_FOUP_DURABLE_SUB_STATE_FULLINUSE) != 0)
                {
                    PPT_METHODTRACE_V2("", "DurableSubState is not ", CS_FOUP_DURABLE_SUB_STATE_FULLINUSE);

                    strDurable_currentState_Change_in.durableStatus                 = CIMFWStrDup(CIMFW_Durable_InUse);
                    strDurable_currentState_Change_in.durableSubStatus.identifier   = CIMFWStrDup(CS_FOUP_DURABLE_SUB_STATE_FULLINUSE);
                    PPT_METHODTRACE_V2("", "strDurable_currentState_Change_in.durableSubStatus.identifier", strDurable_currentState_Change_in.durableSubStatus.identifier);
                    PPT_METHODTRACE_V2("", "DurableSubState is not ", CS_FOUP_DURABLE_SUB_STATE_FULLINUSE);

                    
                    rc = durable_currentState_Change( strDurable_currentState_Change_out,
                                                      strObjCommonIn,
                                                      strDurable_currentState_Change_in);
                    if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V2("", "durable_currentState_Change() rc != RC_OK", rc);
                        strCassette_multiLotType_Update_out.strResult = strDurable_currentState_Change_out.strResult;
                        return(rc);
                    }
                }
            }
            else
            {
               PPT_METHODTRACE_V1("", "lngWaferLen is not SP_Cassette_Default_Capacity or 0");
                if (CIMFWStrCmp(strDurableSubState, CS_FOUP_DURABLE_SUB_STATE_PARTIALINUSE) != 0)
                {
                    PPT_METHODTRACE_V2("", "DurableSubState is not ", CS_FOUP_DURABLE_SUB_STATE_PARTIALINUSE);

                    strDurable_currentState_Change_in.durableStatus                = CIMFWStrDup(CIMFW_Durable_InUse);
                    strDurable_currentState_Change_in.durableSubStatus.identifier  = CIMFWStrDup(CS_FOUP_DURABLE_SUB_STATE_PARTIALINUSE);
                    PPT_METHODTRACE_V2("", "strDurable_currentState_Change_in.durableSubStatus.identifier", strDurable_currentState_Change_in.durableSubStatus.identifier);
                    PPT_METHODTRACE_V2("", "DurableSubState is not ", CS_FOUP_DURABLE_SUB_STATE_PARTIALINUSE);

                    rc = durable_currentState_Change( strDurable_currentState_Change_out,
                                                      strObjCommonIn,
                                                      strDurable_currentState_Change_in);
                    if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V2("", "durable_currentState_Change() rc != RC_OK", rc);
                        strCassette_multiLotType_Update_out.strResult = strDurable_currentState_Change_out.strResult;
                        return(rc);
                    }
                }
            }
        }

//INN-R170003 Add End

//DSN000050720 Add Start
        /*----------------------------------------------------------------------------*/
        /*   Not update cassette's MultiLotType in Post Process parallel execution.   */
        /*----------------------------------------------------------------------------*/
        CORBA::String_var strParallelPostProcFlag;
        try
        {
            strParallelPostProcFlag = getThreadSpecificDataString(SP_ThreadSpecificData_Key_PostProcParallelFlag);
        }
        CATCH_AND_RAISE_EXCEPTIONS(getThreadSpecificDataString);
        if ( 0 == CIMFWStrCmp(strParallelPostProcFlag, SP_PostProcess_ParallelExecution_ON) )
        {
            PPT_METHODTRACE_V1("", "Post Process parallel execution");
            SET_MSG_RC(strCassette_multiLotType_Update_out, MSG_OK, RC_OK);
            return RC_OK;
        }
//DSN000050720 Add End

        /*----------------------------------------*/
        /*   Get the set of Lots is in cassette   */
        /*----------------------------------------*/
        //PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
        //                                       cassetteID,
        //                                       strCassette_multiLotType_Update_out,
        //                                       cassette_multiLotType_Update );

        LotSequence* aLotSequence = NULL;
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aLotSequence = aCassette->allLots();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::allLots);

        LotSequence_var aTmpSeq;
        aTmpSeq = aLotSequence;
        nLen = aLotSequence->length();

        PPT_METHODTRACE_V2("PPTManager_i::cassette_multiLotType_Update", "aLotSequence->length()",nLen);

// D4000098 Scrap Wafer Check Routine
        if ( nLen != 0 )
        {
            //--------------------------------------------------------------
            //   Getting scrap flag marked record from DB that were on MMDB
            //-------------------------------------------------------------
//D5000129 This work is already finished.
//D5000129            PosCassette_var aCassette;
//D5000129            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
//D5000129                                                   cassetteID,
//D5000129                                                   strCassette_multiLotType_Update_out,
//D5000129                                                   Cassette_multiLotType_Update);

            PPT_METHODTRACE_V2("","Checking Scrap Wafer is existed on cassette",cassetteID.identifier);

//D5000129 start
            if ( 0 == CIMFWStrCmp("TXDFC003", strObjCommonIn.transactionID)   // TxScrapWaferCancelReq
              || 0 == CIMFWStrCmp("TXDFC002", strObjCommonIn.transactionID)   // TxScrapWaferReq
              || 0 == CIMFWStrCmp("TXPCR001", strObjCommonIn.transactionID)   // TxWaferSortRpt
              || 0 == CIMFWStrCmp("TXTRC067", strObjCommonIn.transactionID)   // TxWaferSorterPositionAdjustReq
              || 0 == CIMFWStrCmp("TXPCC039", strObjCommonIn.transactionID)   // TxWaferSortReq          P5100038
              || 0 == CIMFWStrCmp("TXTRR009", strObjCommonIn.transactionID) ) // TxWaferSorterOnEqpRpt   P5100038
            {
                PPT_METHODTRACE_V1("", "setMultiLotType [ML-MR]");
                PPT_METHODTRACE_V1("", "TransactionID is [TXDFC003] or [TXDFC002] or [TXPCR001] or [TXTRC067]");
                PPT_METHODTRACE_V1("", "              or [TXPCC039] or [TXTRR009]");                   //P5100038
//D5000129 end
                MaterialSequence * tmpMaterialSeq = NULL; //P2200204
                MaterialSequence_var tmpMaterialSeqVar;
                try
                {
                    tmpMaterialSeq = aCassette->containedMaterial();
                    tmpMaterialSeqVar = tmpMaterialSeq;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::containedMaterial)

                CORBA::Long  waferLen;
                CORBA::Long  i;

                waferLen = tmpMaterialSeq->length();

                for ( i = 0; i < waferLen ; ++ i)
                {
                    PosWafer_var aPosWafer = PosWafer::_narrow((*tmpMaterialSeq)[i]) ;
                    if( aPosWafer->isScrap() == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "aPosWafer->isScrap() == TRUE");  //D5000129
                        try
                        {
                            aCassette->setMultiLotType( SP_Cas_MultiLotType_MultiLotMultiRecipe );
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setMultiLotType);
    //P4100057                    PPT_METHODTRACE_V2("","Wafer is scrapped ", aPosWafer->getIdentifier() );

                        strCassette_multiLotType_Update_out.multiLotType = CIMFWStrDup(SP_Cas_MultiLotType_MultiLotMultiRecipe);

                        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_multiLotType_Update"); //D5000129
                        return( RC_OK );
                    }
    //P4100057                PPT_METHODTRACE_V2("","Wafer is not scrapped ", aPosWafer->getIdentifier() );
                }
//D5000129 start
            }
            else
            {
                PPT_METHODTRACE_V1("", "setMultiLotType [ML-MR]");

                objectIdentifierSequence cassetteIDs;
                cassetteIDs.length(1);
                cassetteIDs[0] = cassetteID;

                objCassette_scrapWafer_SelectDR_out  strCassette_scrapWafer_SelectDR_out;
                rc = cassette_scrapWafer_SelectDR( strCassette_scrapWafer_SelectDR_out, strObjCommonIn, cassetteIDs);
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "##### cassette_scrapWafer_SelectDR != RC_OK", rc);
                    strCassette_multiLotType_Update_out.strResult = strCassette_scrapWafer_SelectDR_out.strResult;
                    return( rc );
                }

                CORBA::Long lenScrapWafer = strCassette_scrapWafer_SelectDR_out.strLotWaferMap.length();
                PPT_METHODTRACE_V2("", "lenScrapWafer", lenScrapWafer);
                if ( 0 < lenScrapWafer )
                {
                    try
                    {
                        aCassette->setMultiLotType( SP_Cas_MultiLotType_MultiLotMultiRecipe );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setMultiLotType);

                    strCassette_multiLotType_Update_out.multiLotType = CIMFWStrDup(SP_Cas_MultiLotType_MultiLotMultiRecipe);

                    PPT_METHODTRACE_EXIT("PPTManager_i::cassette_multiLotType_Update");
                    return( RC_OK );
                }
            }
//D5000129 end
        }
        PPT_METHODTRACE_V1("","Not fount scrap wafer: ");
// D4000098 End

        /*----------------------------*/
        /*   No lot in Cassette       */
        /*----------------------------*/
        if (nLen == 0)
        {
            PPT_METHODTRACE_V1("PPTManager_i::cassette_multiLotType_Update", "nLen == 0");
//0.02 start
            /*----------------------------------------------*/
            /*   Set Blank to multiLotType                  */
            /*----------------------------------------------*/
            try
            {
                aCassette->setMultiLotType( "" );
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setMultiLotType);

            strCassette_multiLotType_Update_out.multiLotType = CIMFWStrDup("");

            PPT_METHODTRACE_EXIT("PPTManager_i::cassette_multiLotType_Update"); //D5000129
            return RC_OK;
//0.02 end

//0.02            PPT_METHODTRACE_V1("PPTManager_i::cassette_multiLotType_Update", "nLen == 0");
//0.02            PPT_SET_MSG_RC_KEY( strCassette_multiLotType_Update_out, MSG_CAST_IS_EMPTY, RC_CAST_IS_EMPTY, "*****" );
//0.02            return( RC_CAST_IS_EMPTY );
        }

        /*----------------------------*/
        /*   Single lot case          */
        /*----------------------------*/
//0.02        if (nLen == 1)
        else if (nLen == 1)     //0.02
        {
            PPT_METHODTRACE_V1("PPTManager_i::cassette_multiLotType_Update", "nLen == 1");

            /*------------------------------------------------*/
            /*   Set SingleLotSingleRecipe to multiLotType    */
            /*------------------------------------------------*/
            try
            {
                aCassette->setMultiLotType( SP_Cas_MultiLotType_SingleLotSingleRecipe );
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setMultiLotType);

            strCassette_multiLotType_Update_out.multiLotType = CIMFWStrDup(SP_Cas_MultiLotType_SingleLotSingleRecipe);
        }
        /*---------------------------*/
        /*   Multi lot case          */
        /*---------------------------*/
        else
        {
            PPT_METHODTRACE_V1("PPTManager_i::cassette_multiLotType_Update", "nLen != 0");

//P3000280            CORBA::Boolean HoldFlag, BankFlag, InprFlag;
            CORBA::Boolean HoldFlag = FALSE;  //P3000280
            CORBA::Boolean BankFlag = FALSE;  //P3000280
            CORBA::Boolean InprFlag = FALSE;  //P3000280
            CORBA::String_var tmpLogicalRecipeID;

            for ( CORBA::Long i=0; i < nLen; i++ )
            {
                PPT_METHODTRACE_V2("PPTManager_i::cassette_multiLotType_Update", "i = ", i);
                /*--------------------*/
                /*   Get Lot Object   */
                /*--------------------*/
                PosLot_var aLot;
                aLot = PosLot::_narrow((*aLotSequence)[i]);

//Q3000124 start
                if(CORBA::is_nil(aLot))
                {
                    PPT_SET_MSG_RC_KEY( strCassette_multiLotType_Update_out,
                                        MSG_NOT_FOUND_LOT,
                                        RC_NOT_FOUND_LOT, "" );
                    return RC_NOT_FOUND_LOT ;
                }
//Q3000124 end
//P9000178 delete start
//P9000178//D8000024 add start
//P9000178                objectIdentifier tmpLotID;
//P9000178                PPT_SET_OBJECT_IDENTIFIER( tmpLotID, aLot,
//P9000178                                           strCassette_multiLotType_Update_out,
//P9000178                                           cassette_multiLotType_Update, PosLot );
//P9000178
//P9000178                PPT_METHODTRACE_V2("", "LotID in Cassette", tmpLotID.identifier);
//P9000178                objectIdentifier equipmentID;
//P9000178                equipmentID.identifier = CIMFWStrDup("");
//P9000178                objLot_effectiveFPCInfo_Get_out strLot_effectiveFPCInfo_Get_out;
//P9000178                rc = lot_effectiveFPCInfo_Get( strLot_effectiveFPCInfo_Get_out, strObjCommonIn,
//P9000178                                               SP_FPC_ExchangeType_ALL, equipmentID, tmpLotID );
//P9000178                if( rc != RC_OK )
//P9000178                {
//P9000178                    PPT_METHODTRACE_V2("", "lot_effectiveFPCInfo_Get() != RC_OK", rc);
//P9000178                    strCassette_multiLotType_Update_out.strResult = strLot_effectiveFPCInfo_Get_out.strResult;
//P9000178                    return rc;
//P9000178                }
//P9000178
//P9000178                if( strLot_effectiveFPCInfo_Get_out.equipmentActionRequired       == TRUE ||
//P9000178                    strLot_effectiveFPCInfo_Get_out.machineRecipeActionRequired   == TRUE ||
//P9000178                    strLot_effectiveFPCInfo_Get_out.recipeParameterActionRequired == TRUE ||
//P9000178                    strLot_effectiveFPCInfo_Get_out.dcDefActionRequired           == TRUE ||
//P9000178                    strLot_effectiveFPCInfo_Get_out.dcSpecActionRequired          == TRUE ||
//P9000178                    strLot_effectiveFPCInfo_Get_out.reticleActionRequired         == TRUE )
//P9000178                {
//P9000178                    PPT_METHODTRACE_V1("", "If lot has FPC definition, update cassette multiLotType to MLMR.");
//P9000178                    try
//P9000178                    {
//P9000178                        aCassette->setMultiLotType( SP_Cas_MultiLotType_MultiLotMultiRecipe );
//P9000178                    }
//P9000178                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setMultiLotType);
//P9000178
//P9000178                    strCassette_multiLotType_Update_out.multiLotType = CIMFWStrDup(SP_Cas_MultiLotType_MultiLotMultiRecipe);
//P9000178
//P9000178                    PPT_METHODTRACE_EXIT("PPTManager_i::cassette_multiLotType_Update");
//P9000178                    return( RC_OK );
//P9000178                }
//P9000178//D8000024 add end
//P9000178 delete end

                /*----------------------------------------*/
                /*   Check if Status is OnHold or InBank  */
                /*----------------------------------------*/
                PPT_METHODTRACE_V1("PPTManager_i::cassette_multiLotType_Update", "Check if Status is OnHold or InBank");
                try
                {
                    PPT_DISPLAY_RESPONSE_TIME();
                    HoldFlag = aLot->isOnHold();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::isOnHold);

                try
                {
                    PPT_DISPLAY_RESPONSE_TIME();
                    BankFlag = aLot->isInBank();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::isInBank);

                try
                {
                    PPT_DISPLAY_RESPONSE_TIME();
                    InprFlag = aLot->isProcessing();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::isProcessing);

                if( HoldFlag == TRUE || BankFlag == TRUE || InprFlag  == TRUE )
                {
                    /*----------------------------------------------*/
                    /*   Set MultiLotMultiRecipe to multiLotType    */
                    /*----------------------------------------------*/
                    PPT_METHODTRACE_V2("PPTManager_i::cassette_multiLotType_Update", "HoldFlag == TRUE or BankFlag == TRUE or InprFlag  == TRUE", i);
                    try
                    {
                        aCassette->setMultiLotType( SP_Cas_MultiLotType_MultiLotMultiRecipe );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setMultiLotType);

                    strCassette_multiLotType_Update_out.multiLotType = CIMFWStrDup(SP_Cas_MultiLotType_MultiLotMultiRecipe);
                    PPT_METHODTRACE_EXIT("PPTManager_i::cassette_multiLotType_Update"); //D5000129
                    return( RC_OK );
                }

//P9000178 add start
                objectIdentifier tmpLotID;
                PPT_SET_OBJECT_IDENTIFIER( tmpLotID, aLot,
                                           strCassette_multiLotType_Update_out,
                                           cassette_multiLotType_Update, PosLot );

                PPT_METHODTRACE_V2("", "LotID in Cassette", tmpLotID.identifier);
                objectIdentifier equipmentID;
                equipmentID.identifier = CIMFWStrDup("");
                objLot_effectiveFPCInfo_Get_out strLot_effectiveFPCInfo_Get_out;
                rc = lot_effectiveFPCInfo_Get( strLot_effectiveFPCInfo_Get_out, strObjCommonIn,
                                               SP_FPC_ExchangeType_ALL, equipmentID, tmpLotID );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_effectiveFPCInfo_Get() != RC_OK", rc);
                    strCassette_multiLotType_Update_out.strResult = strLot_effectiveFPCInfo_Get_out.strResult;
                    return rc;
                }

                if( strLot_effectiveFPCInfo_Get_out.equipmentActionRequired       == TRUE ||
                    strLot_effectiveFPCInfo_Get_out.machineRecipeActionRequired   == TRUE ||
                    strLot_effectiveFPCInfo_Get_out.recipeParameterActionRequired == TRUE ||
                    strLot_effectiveFPCInfo_Get_out.dcDefActionRequired           == TRUE ||
                    strLot_effectiveFPCInfo_Get_out.dcSpecActionRequired          == TRUE ||
                    strLot_effectiveFPCInfo_Get_out.reticleActionRequired         == TRUE )
                {
                    PPT_METHODTRACE_V1("", "If lot has FPC definition, update cassette multiLotType to MLMR.");
                    try
                    {
                        aCassette->setMultiLotType( SP_Cas_MultiLotType_MultiLotMultiRecipe );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setMultiLotType);

                    strCassette_multiLotType_Update_out.multiLotType = CIMFWStrDup(SP_Cas_MultiLotType_MultiLotMultiRecipe);

                    PPT_METHODTRACE_EXIT("PPTManager_i::cassette_multiLotType_Update");
                    return( RC_OK );
                }
//P9000178 add end

                /*-------------------*/
                /*   Get PO Object   */
                /*-------------------*/
                ProcessOperation_var aBasePO;
                PosProcessOperation_var aPO;
                try
                {
                    aBasePO = aLot->getProcessOperation();
                    aPO = PosProcessOperation::_narrow( aBasePO );
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation);

                if ( CORBA::is_nil(aPO) )
                {
                    PPT_METHODTRACE_V1("PPTManager_i::cassette_multiLotType_Update", "aPO is nil");
//P4100425 start
                    objectIdentifier lotID;
                    PPT_SET_OBJECT_IDENTIFIER( lotID, aLot, strCassette_multiLotType_Update_out, cassette_multiLotType_Update, PosLot );
//P4100425 end
//P4100425                    PPT_SET_MSG_RC_KEY( strCassette_multiLotType_Update_out, MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO, "" );
                    PPT_SET_MSG_RC_KEY2( strCassette_multiLotType_Update_out, MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO, "", lotID.identifier );  //P4100425
                    return( RC_NOT_FOUND_PO );
                }

                /*-------------------------------------*/
                /*   Get ProductSpecification Object   */
                /*-------------------------------------*/
                ProductSpecification_var aBaseProdSpec;
                PosProductSpecification_var aProdSpec;
                try
                {
                    aBaseProdSpec = aLot->getProductSpecification();
                    aProdSpec = PosProductSpecification::_narrow(aBaseProdSpec);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification);

                if( CORBA::is_nil(aProdSpec) )
                {
                    PPT_METHODTRACE_V1("PPTManager_i::cassette_multiLotType_Update", "aProdSpec is nil");
                    SET_MSG_RC(strCassette_multiLotType_Update_out, MSG_NOT_FOUND_PRODUCTSPEC, RC_NOT_FOUND_PRODUCTSPEC );
                    return( RC_NOT_FOUND_PRODUCTSPEC );
                }

                /*-------------------------------*/
                /*   Get Logical Recipe Object   */
                /*-------------------------------*/
                PosLogicalRecipe_var aLogicalRecipe;
                try
                {
                    aLogicalRecipe = aPO->findLogicalRecipeFor( aProdSpec );
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::findLogicalRecipeFor);

                if( CORBA::is_nil(aLogicalRecipe) )
                {
//0.03                    PPT_METHODTRACE_V1("PPTManager_i::cassette_multiLotType_Update", "aLogicalRecipe is nil");
//0.03                    SET_MSG_RC(strCassette_multiLotType_Update_out, MSG_NOT_FOUND_LCRECIPE, RC_NOT_FOUND_LCRECIPE);
//0.03                    return( RC_NOT_FOUND_LCRECIPE );
//0.03 start
                    PPT_METHODTRACE_V1("PPTManager_i::cassette_multiLotType_Update", "aLogicalRecipe is nil");
                    /*----------------------------------------------*/
                    /*   Set MultiLotMultiRecipe to multiLotType    */
                    /*----------------------------------------------*/
                    try
                    {
                        aCassette->setMultiLotType( SP_Cas_MultiLotType_MultiLotMultiRecipe );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setMultiLotType);

                    strCassette_multiLotType_Update_out.multiLotType = CIMFWStrDup( SP_Cas_MultiLotType_MultiLotMultiRecipe );

                    PPT_METHODTRACE_EXIT("PPTManager_i::cassette_multiLotType_Update");
                    return RC_OK;
//0.03 end
                }

                if( i == 0 )
                {
                    PPT_METHODTRACE_V1("PPTManager_i::cassette_multiLotType_Update", "i == 0");
                    try
                    {
                        tmpLogicalRecipeID = aLogicalRecipe->getIdentifier();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::getIdentifier);
                }
                else
                {
                    PPT_METHODTRACE_V2("PPTManager_i::cassette_multiLotType_Update", "i != 0", i);
                    CORBA::String_var aLogicalRecipeID;
                    try
                    {
                        aLogicalRecipeID = aLogicalRecipe->getIdentifier();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::getIdentifier);

                    if(CIMFWStrCmp(tmpLogicalRecipeID, aLogicalRecipeID) != 0)
                    {
                        PPT_METHODTRACE_V2("PPTManager_i::cassette_multiLotType_Update", "CIMFWStrCmp(tmpLogicalRecipeID, aLogicalRecipeID) != 0", i);

                        /*----------------------------------------------*/
                        /*   Set MultiLotMultiRecipe to multiLotType    */
                        /*----------------------------------------------*/
                        try
                        {
                            aCassette->setMultiLotType( SP_Cas_MultiLotType_MultiLotMultiRecipe );
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setMultiLotType);

                        strCassette_multiLotType_Update_out.multiLotType = CIMFWStrDup(SP_Cas_MultiLotType_MultiLotMultiRecipe);

                        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_multiLotType_Update"); //D5000129
                        return( RC_OK );
                    }
                }
            }

            /*-----------------------------------------------*/
            /*   Set MultiLotSingleRecipe to multiLotType    */
            /*-----------------------------------------------*/
            PPT_METHODTRACE_V1("PPTManager_i::cassette_multiLotType_Update", "Set MultiLotSingleRecipe to multiLotType");
            try
            {
                aCassette->setMultiLotType( SP_Cas_MultiLotType_MultiLotSingleRecipe );
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setMultiLotType);

            strCassette_multiLotType_Update_out.multiLotType = CIMFWStrDup(SP_Cas_MultiLotType_MultiLotSingleRecipe);
        }

        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_multiLotType_Update");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_multiLotType_Update_out, cassette_multiLotType_Update, methodName)
}
