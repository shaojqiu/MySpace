//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// SiView
// Name: lot_STB.cpp
//

#include "cs_pptmgr.hpp"

#include "plot.hh"
#include "pbank.hh"
#include "pprrq.hh"
#include "pperson.hh"
#include "pwafer.hh"
#include "pprsp.hh"
#include "plotfm.hh"    //D6000389

//[Object Function Name]: long   lot_STB
//
// Date        Level       Author         Note
// ----------  ----------  -------------  -------------------------------------------
// 2000/08/10              H.Katoh        Initial Release
// 2000/09/05  PTR3000030  H.Katoh        Add logic to check wafer count
// 2001/08/16  DCR4000048  M.Ameshita     Reticle set support (Rel4.0)   
// 2002/01/17  P4100071    H.Adachi       Recycle Count of Wafer is Invalid when VendorLotPrepare
// 2002/05/07  P4100107    M.Ameshita     Add logic to set error message when createLotUsing() fails.
// 2002/10/09  D4200133    H.Adachi       Add try - catch
// 2002/11/27  P4200354    K.Matsuei      Incorrect Data input from Client when Control Lot STB.
// 2003/03/24  P5000006    H.Adachi       Fix wrong message parameter for MSG_INVALID_STATE_TRANS.
// 2003/09/09  P5000145    H.Adachi       Fix Message and Message Macro mismatch.
// 2004/11/29  D6000025    K.Murakami     Support eBroker
// 2005/09/02  D6000389    K.Kido         Split Number adjustment / Lot Family duplication check
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/19 DSIV00000220 M.Ogawa        Add logic for storing STB source lot info.(STB Cancel support)
// 2013/03/14 PSN000070720 JJ.Zhang       Product ID does not turn back to the original one when inherit STB is canceled.
// 2015/10/02 DSN000096141 S.Kawabe       Rework responsible operation tracking at wafer level
//
// Change history:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/11/02 INN-R170002 JJ.Zhang       Contaminaiton control
// 2017/11/02 INN-R170016 JJ.Zhang       NPW enhancement
//
//[Function Description]:
//  * Create lot from product request
//  * Add wafer to created lot
//  * Update lot's state
//      - Lot State :            ACTIVE
//      - Lot Production State : INPRODUCTION
//      - Lot Hold State :       NOTONHOLD
//      - Lot Processing State : Waiting
//      - Lot Invetory State :   OnFloor
//  * Add lot to route first operation dispatch queue
//
//
//[Input Parameters]:
//  in  pptObjCommonIn          strObjCommonIn;
//  in  objectIdentifier        productRequestID
//  in  pptNewLotAttributes     strNewLotAttributes,
//
//[Output Parameters]
//
//  out objLot_STB_out  strLot_STB_out;
//
//  typedef struct objLot_STB_out_struct {
//      pptRetCode          strResult;
//      objectIdentifier    createdLotID;
//      string              productType;
//      string              lotType'
//      string              subLotType'
//  } objLot_STB_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  -------------------------   --------------------------------------------------
//
//[Pseudo Code]:
//

//INN-R170016 CORBA::Long PPTManager_i::lot_STB(
CORBA::Long CS_PPTManager_i::lot_STB( //INN-R170016
                        objLot_STB_out& strLot_STB_out,
                        const pptObjCommonIn& strObjCommonIn,
                        const objectIdentifier& productRequestID,
                        const pptNewLotAttributes& strNewLotAttributes )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::lot_STB");

        //------------------------------------------------
        // Retrieve object reference from product request
        //------------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::lot_STB","Retrieve object reference from product request");

        PosProductRequest_var aProductRequest;
        PPT_CONVERT_PRODUCTREQUESTID_TO_PRODUCTREQUEST_OR( aProductRequest,
                                                           productRequestID,
                                                           strLot_STB_out,
                                                           lot_STB,
                                                           productRequestID.identifier );

        //PTR3000029 Start
        //------------------------------------------------
        // Compare Wafer Count
        //------------------------------------------------
        CORBA::Long nInputWaferCount = strNewLotAttributes.strNewWaferAttributes.length();
        CORBA::Long nProdReqWaferCount = 0;
        try
        {
            nProdReqWaferCount = aProductRequest->getProductQuantity();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProductRequest::getProductQuantity)

        if(nInputWaferCount != nProdReqWaferCount)
        {
            char tmpInputWaferCount[256];
            sprintf(tmpInputWaferCount, "%ld", nInputWaferCount);
            PPT_SET_MSG_RC_KEY2( strLot_STB_out,
                                 MSG_STB_WAFERCOUNT_NOT_ENOUGH,
                                 RC_STB_WAFERCOUNT_NOT_ENOUGH,
                                 tmpInputWaferCount,
                                 productRequestID.identifier );

            return RC_STB_WAFERCOUNT_NOT_ENOUGH;
        }
        //PTR3000029 End

//P4200354 start
        CORBA::Long i, j;

        //------------------------------------------------------
        // Check duplicate about NewWaferID and SourceWaferID
        //------------------------------------------------------
        PPT_METHODTRACE_V1("", "Check duplicate about NewWaferID and SourceWaferID");
        PPT_METHODTRACE_V2("", "nInputWaferCount", nInputWaferCount);
        for ( i=0; i < nInputWaferCount; i++ )
        {
            PPT_METHODTRACE_V3("", "newWaferID , sourceWaferID",
                            strNewLotAttributes.strNewWaferAttributes[i].newWaferID.identifier,
                            strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID.identifier);

            CORBA::Long nNewWaferCnt = 0;
            if ( 0 < CIMFWStrLen(strNewLotAttributes.strNewWaferAttributes[i].newWaferID.identifier) )
            {
                for ( j=0; j < nInputWaferCount; j++ )
                {
                    if ( 0 == CIMFWStrCmp(strNewLotAttributes.strNewWaferAttributes[i].newWaferID.identifier,
                                          strNewLotAttributes.strNewWaferAttributes[j].newWaferID.identifier) )
                    {
                        nNewWaferCnt++;
                    }
                } //end of [j]
                PPT_METHODTRACE_V2("", "nNewWaferCnt", nNewWaferCnt);
                if ( 1 != nNewWaferCnt )
                {
                    PPT_METHODTRACE_V1("", "##### return RC_INVALID_INPUT_PARM");
                    SET_MSG_RC( strLot_STB_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
                    return RC_INVALID_INPUT_PARM;
                }
            }

            CORBA::Long nSourceWaferCnt = 0;
            if ( 0 < CIMFWStrLen(strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID.identifier) )
            {
                for ( j=0; j < nInputWaferCount; j++ )
                {
                    if ( 0 == CIMFWStrCmp(strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID.identifier,
                                          strNewLotAttributes.strNewWaferAttributes[j].sourceWaferID.identifier) )
                    {
                        nSourceWaferCnt++;
                    }
                } //end of [j]
                PPT_METHODTRACE_V2("", "nSourceWaferCnt", nSourceWaferCnt);
                if ( 1 != nSourceWaferCnt )
                {
                    PPT_METHODTRACE_V1("", "##### return RC_INVALID_INPUT_PARM");
                    SET_MSG_RC( strLot_STB_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
                    return RC_INVALID_INPUT_PARM;
                }
            }
        } //end of [i]

        //------------------------------------------------------
        // Check relation about SourceLotID and SourceWaferID
        //------------------------------------------------------
        PPT_METHODTRACE_V1("", "Check relation about SourceLotID and SourceWaferID");
        for ( i=0; i < nInputWaferCount; i++ )
        {
            PPT_METHODTRACE_V3("", "sourceLotID , sourceWaferID",
                                        strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier,
                                        strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID.identifier);

            if ( 0 < CIMFWStrLen(strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier)
              && 0 < CIMFWStrLen(strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID.identifier) )
            {
                PPT_METHODTRACE_V1("", "call wafer_lot_Get()");
                objWafer_lot_Get_out  strWafer_lot_Get_out;
                CORBA::Long rc = wafer_lot_Get( strWafer_lot_Get_out,
                                                strObjCommonIn,
                                                strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "wafer_lot_Get != RC_OK", rc);
                    strLot_STB_out.strResult = strWafer_lot_Get_out.strResult;
                    return rc;
                }

                if ( 0 != CIMFWStrCmp(strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier,
                                      strWafer_lot_Get_out.lotID.identifier) )
                {
                    PPT_METHODTRACE_V1("", "##### return RC_INVALID_INPUT_PARM");
                    SET_MSG_RC( strLot_STB_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
                    return RC_INVALID_INPUT_PARM;
                }
            }
       } //end of [i]
//P4200354 end

//PSN000070720 add start
        //----------------------------------------------------------
        // Store STB source lot info if SP_LOT_STBCANCEL is ON.
        //----------------------------------------------------------
        PPT_METHODTRACE_V1("", "Check SP_LOT_STBCANCEL.");
        CORBA::String_var tmpSTBCancelEnv = CIMFWStrDup(getenv(SP_LOT_STBCANCEL));
        PPT_METHODTRACE_V2("","SP_LOT_STBCANCEL env value ON/OFF. tmpSTBCancelEnv = ", tmpSTBCancelEnv);

        PosSTBSourceLotInfoSequence aSTBsourceLotInfoSeq;
        aSTBsourceLotInfoSeq.length(0);
        if( 0 == CIMFWStrCmp(tmpSTBCancelEnv, SP_LOT_STBCANCEL_ON) )
        {
            CORBA::Long waferLen = strNewLotAttributes.strNewWaferAttributes.length();
            PPT_METHODTRACE_V2("","waferLen", waferLen);

            objectIdentifierSequence STBSrcLotIDs;
            STBSrcLotIDs.length(0) ;
            CORBA::Long STBSrcLotLen = 0;
            CORBA::Boolean addLotFlag = TRUE;
            for ( i = 0; i < waferLen; i++ )
            {
                //-----------------------------------------------
                // Get source lot info sequence ( no duplicate )
                //-----------------------------------------------
                addLotFlag = TRUE;
                PPT_METHODTRACE_V2("", "Round for Wafer.", strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID.identifier);
                for( j = 0; j < STBSrcLotLen; j++ )
                {
                    if( ( 0 <  CIMFWStrLen(strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier) )
                     && ( 0 == CIMFWStrCmp( strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier,
                          STBSrcLotIDs[j].identifier ) ) )
                    {
                        PPT_METHODTRACE_V3("", "Wafer's lot was already added. WaferID:LotID",
                                               strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID.identifier,
                                               strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier);
                        addLotFlag = FALSE;
                        break;
                    }
                }

                if( addLotFlag == TRUE )
                {
                    PPT_METHODTRACE_V2("", "add to tmpNewVendorLotInfoSeq", strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier);
                    STBSrcLotIDs.length(STBSrcLotLen + 1);
                    STBSrcLotIDs[STBSrcLotLen] = strNewLotAttributes.strNewWaferAttributes[i].sourceLotID;
                    STBSrcLotLen++;
                }

                //-------------------------------
                // Store source lot info to wafer
                //-------------------------------
                PPT_METHODTRACE_V1("", "Store source lot info to wafer.");
                PosWafer_var aTmpWafer;
                PPT_CONVERT_WAFERID_TO_WAFER_OR( aTmpWafer,
                                                 strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID,
                                                 strLot_STB_out,
                                                 lot_STB );

                PosSTBInfoSequence_var strSTBInfoSeqVar;
                try
                {
                    strSTBInfoSeqVar = aTmpWafer->getSTBInfo();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getSTBInfo)
                
                PPT_METHODTRACE_V2("", "STBSourceLotID ", strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier);
                PosSTBInfoSequence strSTBInfoSeq ;
                strSTBInfoSeq = strSTBInfoSeqVar ;
                strSTBInfoSeq.length(1);
                strSTBInfoSeq[0].STBSourceLotID = CIMFWStrDup(strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier) ;

                try
                {
                    aTmpWafer->setSTBInfo(strSTBInfoSeq);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosWafer::setSTBInfo)
            }

            //-------------------------------
            // Collect source lot info
            //-------------------------------
            PPT_METHODTRACE_V1("", "Collect source lot info.");
            PPT_METHODTRACE_V2("", "STBSrcLotLen", STBSrcLotLen);
            aSTBsourceLotInfoSeq.length(STBSrcLotLen);

            for( i = 0; i < STBSrcLotLen; i++ )
            {
                PosLot_var aSTBSourceLot;
                PPT_CONVERT_LOTID_TO_LOT_OR( aSTBSourceLot, STBSrcLotIDs[i], strLot_STB_out, lot_STB );

                CORBA::String_var STBSrcLotType;
                try
                {
                    STBSrcLotType = aSTBSourceLot->getLotType();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotType)

                CORBA::String_var STBSrcSubLotType;
                try
                {
                    STBSrcSubLotType = aSTBSourceLot->getSubLotType();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType)

                ProductSpecification_var aSTBSrcProdSpec;
                try
                {
                    aSTBSrcProdSpec = aSTBSourceLot->getProductSpecification();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification)

                objectIdentifier tmpProdSpecID;
                PPT_SET_OBJECT_IDENTIFIER( tmpProdSpecID, aSTBSrcProdSpec, strLot_STB_out, lot_STB, ProductSpecification );


                PPT_METHODTRACE_V2("", "sourceLotID",      STBSrcLotIDs[i].identifier);
                PPT_METHODTRACE_V2("", "STBSrcLotType",    STBSrcLotType);
                PPT_METHODTRACE_V2("", "STBSrcSubLotType", STBSrcSubLotType);
                PPT_METHODTRACE_V2("", "tmpProdSpecID",    tmpProdSpecID.identifier);

                aSTBsourceLotInfoSeq[i].sourceLotID         = CIMFWStrDup(STBSrcLotIDs[i].identifier);
                aSTBsourceLotInfoSeq[i].sourceLotLotType    = CIMFWStrDup(STBSrcLotType);
                aSTBsourceLotInfoSeq[i].sourceLotSubLotType = CIMFWStrDup(STBSrcSubLotType);
                aSTBsourceLotInfoSeq[i].sourceLotProdSpecID = tmpProdSpecID;
            }
        }
//PSN000070720 add end

        //-----------------------------
        // Retrieve source lot used count
        //-----------------------------
        PPT_METHODTRACE_V1("PPTManager_i::lot_STB","Retrieve source lot used count");

        CORBA::Long nMaxUsedCount = 0;
        CORBA::Long lenNewWaferAttr = strNewLotAttributes.strNewWaferAttributes.length();
//P4200354        CORBA::Long i;

        for ( i=0; i < lenNewWaferAttr; i++ )
        {
            if ( i > 0
              && 0 == CIMFWStrCmp(strNewLotAttributes.strNewWaferAttributes[i-1].sourceLotID.identifier,
                                  strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier) )
            {
                PPT_METHODTRACE_V1("PPTManager_i::lot_STB","continue!!");

                continue;
            }
            PosLot_var aSourceLot;
            PPT_CONVERT_LOTID_TO_LOT_OR( aSourceLot,
                                         strNewLotAttributes.strNewWaferAttributes[i].sourceLotID,
                                         strLot_STB_out,
                                         lot_STB );

            CORBA::Long tmpMaxUsedCount;
            try
            {
                tmpMaxUsedCount = aSourceLot->getUsedCount();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getUsedCount)

            if ( tmpMaxUsedCount > nMaxUsedCount )
            {
                PPT_METHODTRACE_V1("PPTManager_i::lot_STB","tmpMaxUsedCount > nMaxUsedCount");

                nMaxUsedCount = tmpMaxUsedCount;
            }
        }

        //-----------------------------
        // Lot Generation
        //-----------------------------
        PPT_METHODTRACE_V1("PPTManager_i::lot_STB","Lot Generation");

        Lot_var aTmpNewLot;
        try
        {
            aTmpNewLot = theProductManager->createLotUsing(aProductRequest);
        }
        catch ( ProductManager::DuplicateMaterialSignal &fwex )
        {
            CORBA::String_var errWaferID;
            if( !CORBA::is_nil( fwex.aMaterial ) )
            {
#ifdef EBROKER                                        //D6000025
                Material_var aTmpMaterial = fwex.aMaterial;  //D6000025
                errWaferID = aTmpMaterial->getIdentifier();  //D6000025
#else                                                 //D6000025
                errWaferID = fwex.aMaterial->getIdentifier();
#endif                                                //D6000025
            }
            SET_FW_MSG_RC_KEY2( strLot_STB_out,
                                lot_STB,
                                MSG_DUPLICATE_WAFER,
                                RC_DUPLICATE_WAFER,
                                ProductManager::createWafer,
                                ProductManager::DuplicateMaterialSignal,
                                errWaferID,
                                productRequestID.identifier );

            return RC_DUPLICATE_WAFER;
        }
        catch ( FrameworkErrorSignal &fes )                                              //P4100107
        {                                                                                //P4100107
            if ( fes.errorCode != SPFW_ERROR_INVALID_STATE )                             //P4100107
            {                                                                            //P4100107
                APPERRLOG_FRAMEWORKERRORSIGNAL_FOR_PUREOBJ( fes );                       //P4100107
                throw;                                                                   //P4100107
            }                                                                            //P4100107
            else                                                                         //P4100107
            {                                                                            //P4100107
                ProductSpecification_var aProductSpecification ;                         //P4100107
                CORBA::String_var aProdID ;                                              //P4100107
                try                                                                      //P4100107
                {                                                                        //P4100107
                    aProductSpecification = aProductRequest->getProductSpecification();  //P4100107
                                                                                         //P4100107
                    if(CORBA::is_nil( aProductSpecification ))                           //P4100107
                    {                                                                    //P4100107
//P5000145                        PPT_SET_MSG_RC_KEY( strLot_STB_out,                              //P4100107
//P5000145                                            MSG_NOT_FOUND_PRODUCTSPEC,                   //P4100107
//P5000145                                            RC_NOT_FOUND_PRODUCTSPEC, "" );              //P4100107
                        SET_MSG_RC( strLot_STB_out,                                      //P5000145
                                    MSG_NOT_FOUND_PRODUCTSPEC,                           //P5000145
                                    RC_NOT_FOUND_PRODUCTSPEC );                          //P5000145
                        return RC_NOT_FOUND_PRODUCTSPEC ;                                //P4100107
                    }                                                                    //P4100107
                }                                                                        //P4100107
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getUsedCount)                         //P4100107
                                                                                         //P4100107
                try                                                                      //P4100107
                {                                                                        //P4100107
                    aProdID = aProductSpecification->getIdentifier() ;                   //P4100107
                }                                                                        //P4100107
                CATCH_AND_RAISE_EXCEPTIONS(ProductSpecification::getIdentifier)          //P4100107
                                                                                         //P4100107
                PPT_SET_MSG_RC_KEY( strLot_STB_out,                                      //P4100107
                                    MSG_INVALID_PRODUCT_STAT,                            //P4100107
                                    RC_INVALID_PRODUCT_STAT,                             //P4100107
                                    aProdID );                                           //P4100107
                                                                                         //P4100107
                return RC_INVALID_PRODUCT_STAT ;                                         //P4100107
            }                                                                            //P4100107
        }                                                                                //P4100107
        CATCH_AND_RAISE_EXCEPTIONS(ProductManager::createLotUsing_fromProducts)

        PosLot_var aNewLot;
        aNewLot = PosLot::_narrow(aTmpNewLot);

        if ( CORBA::is_nil(aNewLot) )
        {
            PPT_SET_MSG_RC_KEY( strLot_STB_out,
                                MSG_NOT_FOUND_LOT,
                                RC_NOT_FOUND_LOT,
                                "" );

            return RC_NOT_FOUND_LOT;
        }

//D6000389 add start
        //-----------------------------------
        //   Adjust split number if need.
        //-----------------------------------
        LotFamily_var aLotFM;
        PosLotFamily_var aLotFamily;
        try
        {
            aLotFM = aNewLot->getLotFamily();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotFamily)

        aLotFamily = PosLotFamily::_narrow(aLotFM);

        if( CORBA::is_nil(aLotFamily) )
        {
            SET_MSG_RC(strLot_STB_out, MSG_NOT_FOUND_LOTFAMILY, RC_NOT_FOUND_LOTFAMILY);
            return RC_NOT_FOUND_LOTFAMILY ;
        }

        CORBA::Boolean notInheritedFlag = FALSE;
        try
        {
            notInheritedFlag = aLotFamily->isNewlyCreated();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLotFamily::isNewlyCreated)

        PPT_METHODTRACE_V2("","notInheritedFlag = ", notInheritedFlag);

        if( notInheritedFlag )
        {
            CORBA::Long rc = RC_OK ;
            objectIdentifier lotFamilyID ;
            PPT_SET_OBJECT_IDENTIFIER( lotFamilyID,
                                       aLotFamily,
                                       strLot_STB_out,
                                       lot_STB,
                                       PosLotFamily ) ;

            char* duplicationAllowableFlag = getenv(SP_LOTFAMILY_DUPLICATION_ALLOWABLE_FLAG);
            if( 0 == CIMFWStrCmp( duplicationAllowableFlag, "0" ) )
            {
                objLotFamily_DuplicationCheckDR_out strLotFamily_DuplicationCheckDR_out;
                rc = lotFamily_DuplicationCheckDR( strLotFamily_DuplicationCheckDR_out,
                                                   strObjCommonIn,
                                                   lotFamilyID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","lotFamily_DuplicationCheckDR != RC_OK");
                    strLot_STB_out.strResult = strLotFamily_DuplicationCheckDR_out.strResult;
                    return rc;
                }
            }

            objLotFamily_splitNo_Adjust_out strLotFamily_splitNo_Adjust_out;
            rc = lotFamily_splitNo_Adjust( strLotFamily_splitNo_Adjust_out,
                                           strObjCommonIn,
                                           lotFamilyID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("","lotFamily_splitNo_Adjust != RC_OK");
                strLot_STB_out.strResult = strLotFamily_splitNo_Adjust_out.strResult;
                return rc;
            }
        }
//D6000389 add end

        //------------------------
        // Prepare output structure
        //------------------------
        PPT_METHODTRACE_V1("PPTManager_i::lot_STB","Prepare output structure");

        PPT_SET_OBJECT_IDENTIFIER( strLot_STB_out.createdLotID,
                                   aNewLot,
                                   strLot_STB_out,
                                   lot_STB,
                                   PosLot );

//P4100071 delete start (Move to bottom)
//        //------------------------
//        // wafer assigned lot change
//        //------------------------
//        PPT_METHODTRACE_V1("PPTManager_i::lot_STB","wafer assigned lot change");
//
//        pptNewLotAttributes tmpNewLotAttributes;
//        tmpNewLotAttributes = strNewLotAttributes;
//
//        for ( i=0; i < lenNewWaferAttr; i++ )
//        {
//            tmpNewLotAttributes.strNewWaferAttributes[i].newLotID = strLot_STB_out.createdLotID;
//        }
//
//        objWafer_assignedLot_Change_out strWafer_assignedLot_Change;
//        CORBA::Long rc = wafer_assignedLot_Change( strWafer_assignedLot_Change,
//                                                   strObjCommonIn,
//                                                   tmpNewLotAttributes.strNewWaferAttributes );
//        if ( rc != RC_OK )
//        {
//            PPT_METHODTRACE_V1("PPTManager_i::lot_STB","wafer_assignedLot_Change != RC_OK");
//            strLot_STB_out.strResult = strWafer_assignedLot_Change.strResult;
//            return rc;
//        }
//
//P4100071 delete end (Move to bottom)

        //-----------------------------
        // Make lot's lot state as ACTIVE
        //-----------------------------
        PPT_METHODTRACE_V1("PPTManager_i::lot_STB","Make lot's lot state as ACTIVE");

        try
        {
            aNewLot->makeReleased();
        }
        catch ( InvalidStateTransitionSignal )
        {
            SET_FW_MSG_RC_KEY2( strLot_STB_out,
                                lot_STB,
                                MSG_INVALID_STATE_TRANS,
                                RC_INVALID_STATE_TRANS,
                                PosLot::makeReleased,
                                InvalidStateTransitionSignal,
                                "*****",                       //P5000006
                                CIMFW_Lot_State_Released );    //P5000006
//P5000006                                CIMFW_Lot_State_Released,
//P5000006                                "*****" );

            return RC_INVALID_STATE_TRANS;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::makeReleased)

        //-----------------------------
        // Make Lot's Production State as InProduction
        //-----------------------------
        PPT_METHODTRACE_V1("PPTManager_i::lot_STB","Make Lot's Production State as InProduction");

        try
        {
            aNewLot->makeInProduction();
        }
        catch(InvalidStateTransitionSignal)
        {
            SET_FW_MSG_RC_KEY2( strLot_STB_out,
                                lot_STB,
                                MSG_INVALID_STATE_TRANS,
                                RC_INVALID_STATE_TRANS,
                                PosLot::makeInProduction,
                                InvalidStateTransitionSignal,
                                "*****",                                     //P5000006
                                CIMFW_Lot_ProductionState_InProduction );    //P5000006
//P5000006                                CIMFW_Lot_ProductionState_InProduction,
//P5000006                                "*****" );

            return RC_INVALID_STATE_TRANS;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::makeInProduction)

        //-----------------------------
        // Make lot's Hold State as NotOnHold
        //-----------------------------
        PPT_METHODTRACE_V1("PPTManager_i::lot_STB","Make lot's Hold State as NotOnHold");

        try
        {
            aNewLot->makeNotOnHold();
        }
        catch(InvalidStateTransitionSignal)
        {
            SET_FW_MSG_RC_KEY2( strLot_STB_out,
                                lot_STB,
                                MSG_INVALID_STATE_TRANS,
                                RC_INVALID_STATE_TRANS,
                                PosLot::makeInProduction,
                                InvalidStateTransitionSignal,
                                "*****",                                     //P5000006
                                CIMFW_Lot_ProductionState_InProduction );    //P5000006
//P5000006                                CIMFW_Lot_ProductionState_InProduction,
//P5000006                                "*****" );

            return RC_INVALID_STATE_TRANS;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::makeNotOnHold)

        //-----------------------------
        // Make lot Process State as Waiting
        //-----------------------------
        PPT_METHODTRACE_V1("PPTManager_i::lot_STB","Make lot Process State as Waiting");

        try
        {
            aNewLot->makeWaiting();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::makeWaiting)

        //-----------------------------
        // Make lot Inventory State as OnFloor
        //-----------------------------
        PPT_METHODTRACE_V1("PPTManager_i::lot_STB","Make lot Inventory State as OnFloor");

        try
        {
            aNewLot->makeOnFloor();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::makeOnFloor)

        //-----------------------------
        // Collect necessary information of lot
        //-----------------------------
        PPT_METHODTRACE_V1("PPTManager_i::lot_STB","Collect necessary information of lot");

        PosPerson_var aPerson;
        PPT_GET_PERSON_FROM_USERID( aPerson,
                                    strObjCommonIn.strUser.userID,
                                    strLot_STB_out,
                                    lot_STB );

        PosLot_var aSourceLot;
        PPT_CONVERT_LOTID_TO_LOT_OR( aSourceLot,
                                     strNewLotAttributes.strNewWaferAttributes[0].sourceLotID,
                                     strLot_STB_out,
                                     lot_STB );

//D4200133        CORBA::String_var strVendorLotID = aSourceLot->getVendorLot();

        CORBA::String_var strVendorLotID;                     //D4200133
        try                                                   //D4200133
        {                                                     //D4200133
            strVendorLotID = aSourceLot->getVendorLot();      //D4200133
        }                                                     //D4200133
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getVendorLot);     //D4200133

        try
        {
            strVendorLotID = aSourceLot->getVendorLot();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getVendorLot)

        CORBA::String_var strVendor;
        try
        {
            strVendor = aSourceLot->getVendor();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getVendor)
//PSN000070720//DSIV00000220 add start
//PSN000070720        //-----------------------------
//PSN000070720        // Store STB source lot info if SP_LOT_STBCANCEL is ON.
//PSN000070720        //-----------------------------
//PSN000070720        PPT_METHODTRACE_V1("", "Check SP_LOT_STBCANCEL.");
//PSN000070720        CORBA::String_var tmpSTBCancelEnv = CIMFWStrDup(getenv(SP_LOT_STBCANCEL));
//PSN000070720        PPT_METHODTRACE_V2("","SP_LOT_STBCANCEL env value ON/OFF. tmpSTBCancelEnv = ", tmpSTBCancelEnv);
//PSN000070720
//PSN000070720        PosSTBSourceLotInfoSequence aSTBsourceLotInfoSeq;
//PSN000070720        aSTBsourceLotInfoSeq.length(0);
//PSN000070720        if( 0 == CIMFWStrCmp(tmpSTBCancelEnv, SP_LOT_STBCANCEL_ON) )
//PSN000070720        {
//PSN000070720            CORBA::Long waferLen = strNewLotAttributes.strNewWaferAttributes.length();
//PSN000070720            PPT_METHODTRACE_V2("","waferLen", waferLen);
//PSN000070720
//PSN000070720            objectIdentifierSequence STBSrcLotIDs;
//PSN000070720            STBSrcLotIDs.length(0) ;
//PSN000070720            CORBA::Long STBSrcLotLen = 0;
//PSN000070720            CORBA::Boolean addLotFlag = TRUE;
//PSN000070720            for ( i = 0; i < waferLen; i++ )
//PSN000070720            {
//PSN000070720                //-------------------------------
//PSN000070720                // Get source lot info sequence ( no duplicate )
//PSN000070720                //-------------------------------
//PSN000070720                addLotFlag = TRUE;
//PSN000070720                PPT_METHODTRACE_V2("", "Round for Wafer.", strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID.identifier);
//PSN000070720                for( j = 0; j < STBSrcLotLen; j++ )
//PSN000070720                {
//PSN000070720                    if( ( 0 <  CIMFWStrLen(strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier) )
//PSN000070720                     && ( 0 == CIMFWStrCmp( strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier,
//PSN000070720                          STBSrcLotIDs[j].identifier ) ) )
//PSN000070720                    {
//PSN000070720                        PPT_METHODTRACE_V3("", "Wafer's lot was already added. WaferID:LotID",
//PSN000070720                                               strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID.identifier,
//PSN000070720                                               strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier);
//PSN000070720                        addLotFlag = FALSE;
//PSN000070720                        break;
//PSN000070720                    }
//PSN000070720                }
//PSN000070720
//PSN000070720                if( addLotFlag == TRUE )
//PSN000070720                {
//PSN000070720                    PPT_METHODTRACE_V2("", "add to tmpNewVendorLotInfoSeq", strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier);
//PSN000070720                    STBSrcLotIDs.length(STBSrcLotLen + 1);
//PSN000070720                    STBSrcLotIDs[STBSrcLotLen] = strNewLotAttributes.strNewWaferAttributes[i].sourceLotID;
//PSN000070720                    STBSrcLotLen++;
//PSN000070720                }
//PSN000070720
//PSN000070720                //-------------------------------
//PSN000070720                // Store source lot info to wafer
//PSN000070720                //-------------------------------
//PSN000070720                PPT_METHODTRACE_V1("", "Store source lot info to wafer.");
//PSN000070720                PosWafer_var aTmpWafer;
//PSN000070720                PPT_CONVERT_WAFERID_TO_WAFER_OR( aTmpWafer,
//PSN000070720                                                 strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID,
//PSN000070720                                                 strLot_STB_out,
//PSN000070720                                                 lot_STB );
//PSN000070720
//PSN000070720                PosSTBInfoSequence_var strSTBInfoSeqVar;
//PSN000070720                try
//PSN000070720                {
//PSN000070720                    strSTBInfoSeqVar = aTmpWafer->getSTBInfo();
//PSN000070720                }
//PSN000070720                CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getSTBInfo)
//PSN000070720                
//PSN000070720                PPT_METHODTRACE_V2("", "STBSourceLotID ", strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier);
//PSN000070720                PosSTBInfoSequence strSTBInfoSeq ;
//PSN000070720                strSTBInfoSeq = strSTBInfoSeqVar ;
//PSN000070720                strSTBInfoSeq.length(1);
//PSN000070720                strSTBInfoSeq[0].STBSourceLotID = CIMFWStrDup(strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier) ;
//PSN000070720
//PSN000070720                try
//PSN000070720                {
//PSN000070720                    aTmpWafer->setSTBInfo(strSTBInfoSeq);
//PSN000070720                }
//PSN000070720                CATCH_AND_RAISE_EXCEPTIONS(PosWafer::setSTBInfo)
//PSN000070720            }
//PSN000070720
//PSN000070720            //-------------------------------
//PSN000070720            // Collect source lot info
//PSN000070720            //-------------------------------
//PSN000070720            PPT_METHODTRACE_V1("", "Collect source lot info.");
//PSN000070720            PPT_METHODTRACE_V2("", "STBSrcLotLen", STBSrcLotLen);
//PSN000070720            aSTBsourceLotInfoSeq.length(STBSrcLotLen);
//PSN000070720
//PSN000070720            for( i = 0; i < STBSrcLotLen; i++ )
//PSN000070720            {
//PSN000070720                PosLot_var aSTBSourceLot;
//PSN000070720                PPT_CONVERT_LOTID_TO_LOT_OR( aSTBSourceLot, STBSrcLotIDs[i], strLot_STB_out, lot_STB );
//PSN000070720
//PSN000070720                CORBA::String_var STBSrcLotType;
//PSN000070720                try
//PSN000070720                {
//PSN000070720                    STBSrcLotType = aSTBSourceLot->getLotType();
//PSN000070720                }
//PSN000070720                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotType)
//PSN000070720
//PSN000070720                CORBA::String_var STBSrcSubLotType;
//PSN000070720                try
//PSN000070720                {
//PSN000070720                    STBSrcSubLotType = aSTBSourceLot->getSubLotType();
//PSN000070720                }
//PSN000070720                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType)
//PSN000070720
//PSN000070720                ProductSpecification_var aSTBSrcProdSpec;
//PSN000070720                try
//PSN000070720                {
//PSN000070720                    aSTBSrcProdSpec = aSTBSourceLot->getProductSpecification();
//PSN000070720                }
//PSN000070720                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification)
//PSN000070720
//PSN000070720                objectIdentifier tmpProdSpecID;
//PSN000070720                PPT_SET_OBJECT_IDENTIFIER( tmpProdSpecID, aSTBSrcProdSpec, strLot_STB_out, lot_STB, ProductSpecification );
//PSN000070720
//PSN000070720
//PSN000070720                PPT_METHODTRACE_V2("", "sourceLotID",      STBSrcLotIDs[i].identifier);
//PSN000070720                PPT_METHODTRACE_V2("", "STBSrcLotType",    STBSrcLotType);
//PSN000070720                PPT_METHODTRACE_V2("", "STBSrcSubLotType", STBSrcSubLotType);
//PSN000070720                PPT_METHODTRACE_V2("", "tmpProdSpecID",    tmpProdSpecID.identifier);
//PSN000070720
//PSN000070720                aSTBsourceLotInfoSeq[i].sourceLotID         = CIMFWStrDup(STBSrcLotIDs[i].identifier);
//PSN000070720                aSTBsourceLotInfoSeq[i].sourceLotLotType    = CIMFWStrDup(STBSrcLotType);
//PSN000070720                aSTBsourceLotInfoSeq[i].sourceLotSubLotType = CIMFWStrDup(STBSrcSubLotType);
//PSN000070720                aSTBsourceLotInfoSeq[i].sourceLotProdSpecID = tmpProdSpecID;
//PSN000070720
//PSN000070720            }
//PSN000070720        }
//PSN000070720//DSIV00000220 add end
        //-----------------------------
        // Update new lot's attributes
        //-----------------------------
        PPT_METHODTRACE_V1("PPTManager_i::lot_STB","Update new lot's attributes");

        try
        {
            aNewLot->refreshQuantity();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::refreshQuantity)
        try
        {
            aNewLot->setVendorLot(strVendorLotID);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setVendorLot)
        try
        {
            aNewLot->setVendor(strVendor);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setVendor)
        try
        {
            aNewLot->setLastClaimedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setLastClaimedTimeStamp)
        try
        {
            aNewLot->setLastClaimedPerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setLastClaimedPerson)
        try
        {
            aNewLot->setStateChangedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setStateChangedTimeStamp)
        try
        {
            aNewLot->setStateChangedPerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setStateChangedPerson)
        try
        {
            aNewLot->setInventoryStateChangedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setInventoryStateChangedTimeStamp)
        try
        {
            aNewLot->setInventoryStateChangedPerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setInventoryStateChangedPerson)
//DSIV00000220 add start
        //-----------------------------
        // Set STB source lot info if SP_LOT_STBCANCEL is ON.
        //-----------------------------
        if( 0 == CIMFWStrCmp(tmpSTBCancelEnv, SP_LOT_STBCANCEL_ON) )
        {
            PPT_METHODTRACE_V1("", "0 == CIMFWStrCmp(tmpSTBCancelEnv, SP_LOT_STBCANCEL_ON");
            try
            {
                aNewLot->setSTBSourceLots(aSTBsourceLotInfoSeq);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::setSTBSourceLots)
        }
//DSIV00000220 add end

        //---------------------------------
        // Update lot's Used Count
        //---------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::lot_STB","Update lot's Used Count");

        CORBA::String_var strLotType;
        try
        {
            strLotType = aNewLot->getLotType();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotType)

        if ( 0 != CIMFWStrCmp(strLotType, SP_Lot_Type_ProductionLot)
          && 0 != CIMFWStrCmp(strLotType, SP_Lot_Type_EngineeringLot)
          && 0 != CIMFWStrCmp(strLotType, SP_Lot_Type_RecycleLot) )
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_STB","strLotType == SP_Lot_Type_ProductionLot, SP_Lot_Type_EngineeringLot, SP_Lot_Type_RecycleLot");
            try
            {
                aNewLot->setUsedCount(nMaxUsedCount+1);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::setUsedCount)
        }
        else
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_STB","else!!");
            try
            {
                aNewLot->setUsedCount(0);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::setUsedCount)
        }

        //---------------------------------
        // Update lot's Control Use State
        //---------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::lot_STB","Update lot's Control Use State");

        if ( 0 == CIMFWStrCmp(strLotType, SP_Lot_Type_RecycleLot) )
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_STB","strLotType == SP_Lot_Type_RecycleLot");
            try
            {
                aNewLot->makeInRecycle();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::makeInRecycle)

            //PTR3000030 PosWafer_var aPosWafer;
            //PTR3000030 lenNewWaferAttr = strNewLotAttributes.strNewWaferAttributes.length();
            //PTR3000030 for ( i=0; i < lenNewWaferAttr; i++ )
            //PTR3000030 {
            //PTR3000030     PPT_CONVERT_WAFERID_TO_WAFER_OR( aPosWafer,
            //PTR3000030                                      strNewLotAttributes.strNewWaferAttributes[i].newWaferID,
            //PTR3000030                                      strLot_STB_out,
            //PTR3000030                                      lot_STB );
            //PTR3000030     if ( CORBA::is_nil(aPosWafer) )
            //PTR3000030     {
            //PTR3000030         SET_MSG_RC( strLot_STB_out,
            //PTR3000030                     MSG_NOT_FOUND_WAFER,
            //PTR3000030                     RC_NOT_FOUND_WAFER );
            //PTR3000030         return RC_NOT_FOUND_WAFER;
            //PTR3000030     }
            //PTR3000030     try
            //PTR3000030     {
            //PTR3000030         aPosWafer->setRecycleCount(aPosWafer->getRecycleCount() + 1);
            //PTR3000030     }
            //PTR3000030     CATCH_AND_RAISE_EXCEPTIONS(PosWafer::setRecycleCount)
            //PTR3000030     try
            //PTR3000030     {
            //PTR3000030         aPosWafer->makeControlWafer();
            //PTR3000030     }
            //PTR3000030     CATCH_AND_RAISE_EXCEPTIONS(PosWafer::makeControlWafer)
            //PTR3000030 }
        }
        else if( 0 == CIMFWStrCmp(strLotType, SP_Lot_Type_EngineeringLot)
              || 0 == CIMFWStrCmp(strLotType, SP_Lot_Type_ProductionMonitorLot)
              || 0 == CIMFWStrCmp(strLotType, SP_Lot_Type_EquipmentMonitorLot)
              || 0 == CIMFWStrCmp(strLotType, SP_Lot_Type_DummyLot)
              || 0 == CIMFWStrCmp(strLotType, SP_Lot_Type_CorrelationLot) )
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_STB","strLotType = SP_Lot_Type_EngineeringLot, SP_Lot_Type_ProductionMonitorLot, SP_Lot_Type_DummyLot, SP_Lot_Type_CorrelationLot");
            try
            {
                aNewLot->makeInUse();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::makeInUse)
        }

//DSN000096141 add start
        //------------------------
        // wafer assigned lot change
        //------------------------
        PPT_METHODTRACE_V1("PPTManager_i::lot_STB","wafer assigned lot change");

        pptNewLotAttributes tmpNewLotAttributes;
        tmpNewLotAttributes = strNewLotAttributes;

        for ( i=0; i < lenNewWaferAttr; i++ )
        {
            tmpNewLotAttributes.strNewWaferAttributes[i].newLotID = strLot_STB_out.createdLotID;
        }

        objWafer_assignedLot_Change_out strWafer_assignedLot_Change;

        CORBA::Long rc = wafer_assignedLot_Change( strWafer_assignedLot_Change,
                                                   strObjCommonIn,
                                                   tmpNewLotAttributes.strNewWaferAttributes );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("PPTManager_i::lot_STB","wafer_assignedLot_Change != RC_OK");
            strLot_STB_out.strResult = strWafer_assignedLot_Change.strResult;
            return rc;
        }
//DSN000096141 add start

        //---------------------------------
        // Update lot's Operation Info
        //---------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::lot_STB","Update lot's Operation Info");

        try
        {
            aNewLot->beginNextProcessOperation();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::beginNextProcessOperation)
        try
        {
            theDispatchingManager->addToQueue(aNewLot);
        }
        CATCH_AND_RAISE_EXCEPTIONS(DispatchingManager::addToQueue)

        //---------------------------------                                          //D4000048
        // Get Product Specification                                                 //D4000048
        //---------------------------------                                          //D4000048
        ProductSpecification_var aPS;                                                //D4000048
        PosProductSpecification_var aPosProdSpec;                                    //D4000048
        try                                                                          //D4000048
        {                                                                            //D4000048
            aPS = aNewLot->getProductSpecification();                                //D4000048
            aPosProdSpec = PosProductSpecification::_narrow(aPS);                    //D4000048
        }                                                                            //D4000048
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification)                  //D4000048
                                                                                     //D4000048
        if ( CORBA::is_nil(aPosProdSpec) )                                           //D4000048
        {                                                                            //D4000048
            PPT_METHODTRACE_V1("PPTManager_i::lot_STB","aPosProdSpec is nil");       //D4000048
            SET_MSG_RC( strLot_STB_out,                                              //D4000048
                        MSG_NOT_FOUND_PRODUCTSPEC,                                   //D4000048
                        RC_NOT_FOUND_PRODUCTSPEC );                                  //D4000048
                                                                                     //D4000048
            return RC_NOT_FOUND_PRODUCTSPEC;                                         //D4000048
        }                                                                            //D4000048
                                                                                     //D4000048
        //---------------------------------                                          //D4000048
        // Set Reticle Set ID                                                        //D4000048
        //---------------------------------                                          //D4000048
        try                                                                          //D4000048
        {                                                                            //D4000048
            PosReticleSet_var aReticleSet = aPosProdSpec->getReticleSet();           //D4000048
            if( CORBA::is_nil(aReticleSet ) )                                        //D4000048
            {                                                                        //D4000048
                PPT_METHODTRACE_V1("PPTManager_i::lot_STB","aReticleSet is nil");    //D4000048
            }                                                                        //D4000048
            else                                                                     //D4000048
            {                                                                        //D4000048
                try                                                                  //D4000048
                {                                                                    //D4000048
		        	aNewLot->setReticleSet( aReticleSet );                           //D4000048
                }                                                                    //D4000048
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::setReticleSet)                    //D4000048
            }                                                                        //D4000048
        }                                                                            //D4000048
        CATCH_AND_RAISE_EXCEPTIONS(PosProductSpecification::getReticleSet)           //D4000048


        //---------------------------------
        // Set output structure
        //---------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::lot_STB","Set output structure");

        PPT_SET_OBJECT_IDENTIFIER( strLot_STB_out.createdLotID,
                                   aNewLot,
                                   strLot_STB_out,
                                   lot_STB,
                                   PosLot );

        strLot_STB_out.lotType = strLotType;

        try
        {
            strLot_STB_out.subLotType = aNewLot->getSubLotType();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getsubLotType)

//D4000048 /* Move to the place before Reticle Set setting.(D4000048) */
//D4000048
//D4000048       ProductSpecification_var aPS;
//D4000048       PosProductSpecification_var aPosProdSpec;
//D4000048       try
//D4000048       {
//D4000048           aPS = aNewLot->getProductSpecification();
//D4000048           aPosProdSpec = PosProductSpecification::_narrow(aPS);
//D4000048       }
//D4000048       CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification)
//D4000048
//D4000048       if ( CORBA::is_nil(aPosProdSpec) )
//D4000048       {
//D4000048           PPT_METHODTRACE_V1("PPTManager_i::lot_STB","aPosProdSpec is nil");
//D4000048           SET_MSG_RC( strLot_STB_out,
//D4000048                       MSG_NOT_FOUND_PRODUCTSPEC,
//D4000048                       RC_NOT_FOUND_PRODUCTSPEC );
//D4000048
//D4000048           return RC_NOT_FOUND_PRODUCTSPEC;
//D4000048       }

        try
        {
            strLot_STB_out.productType = aPosProdSpec->getProductType();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProductSpecification::getProductType)

//DSN000096141        //P4100071 add start (Move from before) 
//DSN000096141        //------------------------
//DSN000096141        // wafer assigned lot change
//DSN000096141        //------------------------
//DSN000096141        PPT_METHODTRACE_V1("PPTManager_i::lot_STB","wafer assigned lot change");
//DSN000096141
//DSN000096141        pptNewLotAttributes tmpNewLotAttributes;
//DSN000096141        tmpNewLotAttributes = strNewLotAttributes;
//DSN000096141
//DSN000096141        for ( i=0; i < lenNewWaferAttr; i++ )
//DSN000096141        {
//DSN000096141            tmpNewLotAttributes.strNewWaferAttributes[i].newLotID = strLot_STB_out.createdLotID;
//DSN000096141        }
//DSN000096141
//DSN000096141        objWafer_assignedLot_Change_out strWafer_assignedLot_Change;
//DSN000096141
//DSN000096141        CORBA::Long rc = wafer_assignedLot_Change( strWafer_assignedLot_Change,
//DSN000096141                                                   strObjCommonIn,
//DSN000096141                                                   tmpNewLotAttributes.strNewWaferAttributes );
//DSN000096141
//DSN000096141        if ( rc != RC_OK )
//DSN000096141        {
//DSN000096141            PPT_METHODTRACE_V1("PPTManager_i::lot_STB","wafer_assignedLot_Change != RC_OK");
//DSN000096141            strLot_STB_out.strResult = strWafer_assignedLot_Change.strResult;
//DSN000096141            return rc;
//DSN000096141        }
//DSN000096141        //P4100071 add end (Move from before) 
//DSIV00000220 add start
        //------------------------
        // Wafer STB count up
        //------------------------
        PPT_METHODTRACE_V1("", "Wafer STB count up");
        MaterialSequence_var aMaterialSequence;
        try
        {
            aMaterialSequence = aNewLot->allMaterial();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::allMaterial);

        CORBA::Long STBedCount = 0;
        CORBA::Long waferLen = aMaterialSequence->length();
        if( 0 < waferLen )
        {
            for( i = 0; i < waferLen; i++ )
            {
                PosWafer_var aPosWafer = PosWafer::_narrow((*aMaterialSequence)[i]);

                if( CORBA::is_nil(aPosWafer) )
                {
                    SET_MSG_RC( strLot_STB_out, MSG_NOT_FOUND_WAFER, RC_NOT_FOUND_WAFER );
                    return RC_NOT_FOUND_WAFER;
                }

                try
                {
                    STBedCount = aPosWafer->getSTBedCount();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getSTBedCount);

                STBedCount++;

                try
                {
                    aPosWafer->setSTBedCount(STBedCount);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getSTBedCount);
//INN-R170016 Add Start
                if ( 0 != CIMFWStrCmp(strLot_STB_out.productType, SP_Lot_Type_ProductionLot) )
                {
                    PPT_METHODTRACE_V1("", "clean up Dwongrade info for control lot");
                    CORBA::String_var tmpValue;
                    SI_PPT_USERDATA_GET_STRING(aPosWafer, CS_M_WFR_Downgrade_Product, tmpValue);
                    if( CIMFWStrLen(tmpValue) > 0 )
                    {
                        PPT_METHODTRACE_V2("", "M_WFR_Downgrade_Product", tmpValue);
                        SI_PPT_USERDATA_SET_STRING(aPosWafer, CS_M_WFR_Downgrade_Product, "");
                    }
                    SI_PPT_USERDATA_GET_STRING(aPosWafer, CS_M_WFR_Downgrade_BankID, tmpValue);
                    if( CIMFWStrLen(tmpValue) > 0 )
                    {
                        PPT_METHODTRACE_V2("", "M_WFR_Downgrade_BankID", tmpValue);
                        SI_PPT_USERDATA_SET_STRING(aPosWafer, CS_M_WFR_Downgrade_BankID,  "");
                    }
                    //SI_PPT_USERDATA_DEL(aPosWafer, M_WFR_Monitor_Grade);
                }
//INN-R170016 Add End
            }
        }
//DSIV00000220 add end
//INN-R170002 Add Start
        //clean up contamination info
        CORBA::String_var tmpValue;
        SI_PPT_USERDATA_GET_STRING(aNewLot, CS_M_LOT_Contamination_Flag, tmpValue);
        if( CIMFWStrLen(tmpValue) > 0 )
        {
            PPT_METHODTRACE_V2("", "M_LOT_Contamination_Flag", tmpValue);
            SI_PPT_USERDATA_SET_STRING(aNewLot, CS_M_LOT_Contamination_Flag, "");
        }
        SI_PPT_USERDATA_GET_STRING(aNewLot, CS_M_LOT_PR_Flag, tmpValue);
        if( CIMFWStrLen(tmpValue) > 0 )
        {
            PPT_METHODTRACE_V2("", "M_LOT_PR_Flag", tmpValue);
            SI_PPT_USERDATA_SET_STRING(aNewLot, CS_M_LOT_PR_Flag, "");
        }
//INN-R170002 Add End

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::lot_STB");                               
                                                                                     
        return RC_OK;                                                                
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_STB_out, lot_STB, methodName)
}
