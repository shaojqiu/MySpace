//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
//
// SiView
// Name: cs_lot_CheckConditionForEqpMonitorLotReserveOR.cpp
//

#include "cs_pptmgr.hpp"
#include "pemon.hh"
#include "plot.hh"
#include "pcas.hh"
#include "ppcope.hh"
#include "pmc.hh"
#include "plcrc.hh"
#include "pmcrc.hh"
#include "pdp.hh"
#include "pdpgl.hh"
#include "pflwbch.hh"
#include "prcssctv.hh"

// Class: PPTManager
//
// Service: lot_CheckConditionForEqpMonitorLotReserve()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2013/11/12 DSN000081739 Shudi Wang     Equipment Monitor Automation Support
//
//[Function Description]:
// check lot condition for equipment monitor lot reserve
//
//
//[Input/Output Parameters]:
//
// typedef struct objLot_CheckConditionForEqpMonitorLotReserve_in_struct {
//     objectIdentifier                    eqpMonitorID;
//     pptEqpMonitorProductLotMapSequence  strProductLotMap;
//     any                                 siInfo;
// }  objLot_CheckConditionForEqpMonitorLotReserve_in;
//
//
// typedef objBase_out objLot_CheckConditionForEqpMonitorLotReserve_out;

//
//[Return Value]:
//
//  Return Code                        Messsage ID
//  ---------------------------------- -----------------------------------------
//  RC_OK                              MSG_OK

//INN-R170016 CORBA::Long PPTManager_i::lot_CheckConditionForEqpMonitorLotReserve(
CORBA::Long CS_PPTManager_i::lot_CheckConditionForEqpMonitorLotReserve( //INN-R170016
    objLot_CheckConditionForEqpMonitorLotReserve_out&            strLot_CheckConditionForEqpMonitorLotReserve_out,
    const pptObjCommonIn&                                        strObjCommonIn,
    const objLot_CheckConditionForEqpMonitorLotReserve_in&       strLot_CheckConditionForEqpMonitorLotReserve_in)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::lot_CheckConditionForEqpMonitorLotReserve");

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;
        CORBA::ULong i = 0, j = 0, x = 0, y = 0;
        const pptEqpMonitorProductLotMapSequence& strProdLotMap = strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap;
        CORBA::ULong nSeqLen = 0;
        CORBA::ULong nLotLen = 0;

        //Trace InParameters
        PPT_METHODTRACE_V2("","in para eqpMonitorID",strLot_CheckConditionForEqpMonitorLotReserve_in.eqpMonitorID.identifier );

        //--------------------------------
        //  - Check Lot-Product relation
        //  - Check wafer count
        //--------------------------------
        CORBA::ULong nMonProdLen = strProdLotMap.length();
        PPT_METHODTRACE_V2("", "nMonProdLen", nMonProdLen);
        objectIdentifierSequence lotIDs(10);
        objectIdentifier carrierID; //INN-R170016

        for( i = 0; i < nMonProdLen; i++ )
        {
            CORBA::ULong nTotalWaferCnt = 0;

            PPT_METHODTRACE_V3("","loop for strProdLotMap[]", i, strProdLotMap[i].strEqpMonitorProductInfo.productID.identifier);
            CORBA::ULong nMonLotLen = strProdLotMap[i].eqpMonitorLotIDs.length();
            PPT_METHODTRACE_V2("", "nMonLotLen", nMonLotLen);
            for( j = 0; j < nMonLotLen; j++ )
            {
                PPT_METHODTRACE_V3("", "loop for strProdLotMap[]eqpMonitorLotIDs[]", j, strProdLotMap[i].eqpMonitorLotIDs[j].identifier);
                //Import all lot id to lotIDs
                if(nLotLen >= lotIDs.length())
                {
                    lotIDs.length(nLotLen+10);
                }
                lotIDs[nLotLen].identifier = strProdLotMap[i].eqpMonitorLotIDs[j].identifier;
                nLotLen++;

                PosLot_var aPosLot;
                PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot,
                                             strProdLotMap[i].eqpMonitorLotIDs[j],
                                             strLot_CheckConditionForEqpMonitorLotReserve_out,
                                             lot_CheckConditionForEqpMonitorLotReserve);

                ProductSpecification_var    aProdSpec;
                try
                {
                    aProdSpec = aPosLot->getProductSpecification();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification);

                CORBA::String_var prodSpecID;
                try
                {
                    prodSpecID = aProdSpec->getIdentifier();
                }
                CATCH_AND_RAISE_EXCEPTIONS(ProductSpecification::getIdentifier);

                PPT_METHODTRACE_V2("", "prodSpecID", prodSpecID);
                if ( 0 != CIMFWStrCmp(prodSpecID, strProdLotMap[i].strEqpMonitorProductInfo.productID.identifier) )
                {
                    PPT_METHODTRACE_V1("","Product doesn't match.");
                    PPT_SET_MSG_RC_KEY( strLot_CheckConditionForEqpMonitorLotReserve_out,
                                        MSG_INVALID_MONITOR_PRODUCT,    //000XXXXE:Lot's product is unmatch with the product defined in equipment monitor  [%s].
                                        RC_INVALID_MONITOR_PRODUCT,
                                        prodSpecID );
                    return RC_INVALID_MONITOR_PRODUCT ;
                }
//INN-R170016 Add Start
                objLot_cassette_Get_out    strLot_cassette_Get_out ;
                rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, strProdLotMap[i].eqpMonitorLotIDs[j]);
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "lot_cassette_Get() != RC_OK") ;
                    strLot_CheckConditionForEqpMonitorLotReserve_out.strResult = strLot_cassette_Get_out.strResult ;
                    return(rc);
                }
                if( 0 == CIMFWStrLen(carrierID.identifier) )
                {
                    carrierID = strLot_cassette_Get_out.cassetteID ;
                    PPT_METHODTRACE_V2("", "carrierID.identifier", carrierID.identifier) ;
                }
                if( 0 != CIMFWStrCmp(carrierID.identifier, strLot_cassette_Get_out.cassetteID.identifier) )
                {
                    PPT_METHODTRACE_V2("", "cassetteID not same", strLot_cassette_Get_out.cassetteID.identifier) ;
                    SET_MSG_RC(strLot_CheckConditionForEqpMonitorLotReserve_out, MSG_CAST_NOTSAME, RC_CAST_NOTSAME);
                    return( RC_CAST_NOTSAME );
                }
//INN-R170016 Add End
                CORBA::Long nWaferCnt = 0;
                try
                {
                    nWaferCnt = aPosLot->getQuantity();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getQuantity);

                nTotalWaferCnt = nTotalWaferCnt + nWaferCnt;
                PPT_METHODTRACE_V2("", "nWaferCnt", nWaferCnt);
                PPT_METHODTRACE_V2("", "nTotalWaferCnt", nTotalWaferCnt);
            }

            PPT_METHODTRACE_V2("", "strProdLotMap[i].strEqpMonitorProductInfo.waferCount", strProdLotMap[i].strEqpMonitorProductInfo.waferCount);
            PPT_METHODTRACE_V2("", "nTotalWaferCnt", nTotalWaferCnt);
            if ( strProdLotMap[i].strEqpMonitorProductInfo.waferCount > nTotalWaferCnt )
            {
                SET_MSG_RC( strLot_CheckConditionForEqpMonitorLotReserve_out,
                            MSG_EQPMONITOR_WAFER_NOT_ENOUGH,    //000XXXXE:The total wafer count of equipment monitor lots is shorter than required count.
                            RC_EQPMONITOR_WAFER_NOT_ENOUGH);
                return RC_EQPMONITOR_WAFER_NOT_ENOUGH ;
            }
        }

//INN-R170016 Add Start
        //----------------------------------------------
        // Check slot map matched the monitor definiton
        //----------------------------------------------
        objCassette_GetWaferMapDR_out strCassette_GetWaferMapDR_out;
        rc = cassette_GetWaferMapDR(strCassette_GetWaferMapDR_out, strObjCommonIn, carrierID);
        if(rc!= RC_OK)
        {
            PPT_METHODTRACE_V2("", "cassette_GetWaferMapDR() != RC_OK ", carrierID.identifier );
            strLot_CheckConditionForEqpMonitorLotReserve_out.strResult = strCassette_GetWaferMapDR_out.strResult;
            return( rc );
        }
        CORBA::Long mapLen = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo.length();

        objEqpMonitor_info_Get_in strEqpMonitor_info_Get_in;
        strEqpMonitor_info_Get_in.eqpMonitorID = strLot_CheckConditionForEqpMonitorLotReserve_in.eqpMonitorID;

        csObjEqpMonitor_info_Get_out strEqpMonitor_info_Get_out;
        rc = cs_eqpMonitor_info_GetDR( strEqpMonitor_info_Get_out,
                                  strObjCommonIn,
                                  strEqpMonitor_info_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cs_eqpMonitor_info_GetDR() != RC_OK", rc);
            strLot_CheckConditionForEqpMonitorLotReserve_out.strResult = strEqpMonitor_info_Get_out.strResult;
            return rc;
        }

        csEqpMonitorSubInfoSequence& strEqpMonitorSubInfoSeq = strEqpMonitor_info_Get_out.strEqpMonitorDetailInfos[0].strEqpMonitorSubInfoSeq;
        nSeqLen = strEqpMonitorSubInfoSeq.length();
        if( mapLen != nSeqLen )
        {
            //slot map not matched the monitor definiton
            PPT_METHODTRACE_V1("", "0001234E:Other wafer [%s] exist in slot [%s] of cassette [%s].");
            PPT_SET_MSG_RC_KEY3( strLot_CheckConditionForEqpMonitorLotReserve_out,
                                 MSG_NOT_USE_SLOT, RC_NOT_USE_SLOT,
                                 "****", //waferID
                                 "****", //slotNumber
                                 carrierID.identifier );
            return RC_NOT_USE_SLOT;
        }

        for( i =0; i<nSeqLen; i++)
        {
            //wafer in slot should have same attribute as what defined in EQPMON_SUB
            PPT_METHODTRACE_V2("", " check slotNumber", strEqpMonitorSubInfoSeq[i].slotNumber);
            if(strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].slotNumber != strEqpMonitorSubInfoSeq[i].slotNumber)
            {
                PPT_METHODTRACE_V2("", "WaferID", strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].waferID.identifier);
                char slotNumber[64];
                sprintf(slotNumber, "%ld", strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].slotNumber);
                PPT_SET_MSG_RC_KEY3( strLot_CheckConditionForEqpMonitorLotReserve_out,
                                     MSG_NOT_USE_SLOT, RC_NOT_USE_SLOT,
                                     strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].waferID.identifier,
                                     slotNumber,
                                     carrierID.identifier );
                return RC_NOT_USE_SLOT;
            }
            PosLot_var aPosLot;
            PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot,
                                         strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].lotID,
                                         strLot_CheckConditionForEqpMonitorLotReserve_out,
                                         lot_CheckConditionForEqpMonitorLotReserve);

            ProductSpecification_var aProdSpec;
            try
            {
                aProdSpec = aPosLot->getProductSpecification();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification);

            CORBA::String_var prodSpecID;
            try
            {
                prodSpecID = aProdSpec->getIdentifier();
            }
            CATCH_AND_RAISE_EXCEPTIONS(ProductSpecification::getIdentifier);

            PPT_METHODTRACE_V2("", "prodSpecID", prodSpecID);
            if ( 0 != CIMFWStrCmp(prodSpecID, strEqpMonitorSubInfoSeq[i].productID.identifier) )
            {
                PPT_METHODTRACE_V2("", "Product doesn't match", strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].waferID.identifier);
                char slotNumber[64];
                sprintf(slotNumber, "%ld", strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].slotNumber);
                PPT_SET_MSG_RC_KEY3( strLot_CheckConditionForEqpMonitorLotReserve_out,
                                     MSG_NOT_USE_SLOT, RC_NOT_USE_SLOT,
                                     strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].waferID.identifier,
                                     slotNumber,
                                     carrierID.identifier );
                return RC_NOT_USE_SLOT;
            }
        }
//INN-R170016 Add End

        //--------------------------------//
        //  Get Equipment Monitor Object  //
        //--------------------------------//
        PosEqpMonitor_var anEqpMonitor;
        PPT_CONVERT_EQPMONITORID_TO_EQPMONITOR_OR( anEqpMonitor, strLot_CheckConditionForEqpMonitorLotReserve_in.eqpMonitorID, strLot_CheckConditionForEqpMonitorLotReserve_out, lot_CheckConditionForEqpMonitorLotReserve );
        CORBA::Boolean bKitFlag;
        try
        {
            bKitFlag = anEqpMonitor->isKitFlag();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosEqpMonitor::isKitFlag)
        CORBA::String_var strCheckLevel;
        if(TRUE == bKitFlag)
        {
            PPT_METHODTRACE_V1("","TRUE == bKitFlag");
            strCheckLevel = CIMFWStrDup(SP_EqpMonitor_Level_EqpMonKit);
        }
        else
        {
            PPT_METHODTRACE_V1("","TRUE != bKitFlag");
            strCheckLevel = CIMFWStrDup(SP_EqpMonitor_Level_EqpMonNoKit);
        }
        PosMachine_var aMachine;
        try
        {
            aMachine = anEqpMonitor->getMachine();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosEqpMonitor::getMachine)
        if(CORBA::is_nil(aMachine))
        {
            PPT_METHODTRACE_V1("","anEqpMonitor->getMachine() is nil");
            SET_MSG_RC( strLot_CheckConditionForEqpMonitorLotReserve_out,
                            MSG_NOT_FOUND_MACHINE, RC_NOT_FOUND_MACHINE );
            return RC_NOT_FOUND_MACHINE;
        }
        CORBA::String_var multiRecipeCapability;
        try
        {
            multiRecipeCapability = aMachine->getMultipleRecipeCapability();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getMultipleRecipeCapability);
        objectIdentifier equipmentID;
        PPT_SET_OBJECT_IDENTIFIER( equipmentID,
                                   aMachine,
                                   strLot_CheckConditionForEqpMonitorLotReserve_out,
                                   lot_CheckConditionForEqpMonitorLotReserve,
                                   PosMachine );

        for( i =0; i<strProdLotMap.length(); i++)
        {
            PPT_METHODTRACE_V2("","loop strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap",i);
            PPT_METHODTRACE_V2("","length of strProductLotMap[i].eqpMonitorLotIDs",strProdLotMap[i].eqpMonitorLotIDs.length());
            for( j =0; j<strProdLotMap[i].eqpMonitorLotIDs.length(); j++)
            {
                PPT_METHODTRACE_V2("","loop strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap.eqpMonitorLotIDs",j);
                PPT_METHODTRACE_V2("","Lot ID",strProdLotMap[i].eqpMonitorLotIDs[j].identifier);
                objLot_CheckConditionForEqpMonitor_out    strLot_CheckConditionForEqpMonitor_out;
                objLot_CheckConditionForEqpMonitor_in     strLot_CheckConditionForEqpMonitor_in;
                strLot_CheckConditionForEqpMonitor_in.eqpMonitorID   = strLot_CheckConditionForEqpMonitorLotReserve_in.eqpMonitorID;
                strLot_CheckConditionForEqpMonitor_in.operation      = CIMFWStrDup(SP_EqpMonitor_OpeCategory_EqpMonReserve);
                strLot_CheckConditionForEqpMonitor_in.checkLevel     = strCheckLevel;
                strLot_CheckConditionForEqpMonitor_in.lotID          = strProdLotMap[i].eqpMonitorLotIDs[j];

                rc = lot_CheckConditionForEqpMonitor(strLot_CheckConditionForEqpMonitor_out,strObjCommonIn,strLot_CheckConditionForEqpMonitor_in);
                if(rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("","lot_CheckConditionForEqpMonitor rc != RC_OK");
                    strLot_CheckConditionForEqpMonitorLotReserve_out.strResult = strLot_CheckConditionForEqpMonitor_out.strResult;
                    return rc;
                }
            }
        }

        //This check is only for strCheckLevel=EqpMonKit
        //--------------------------------
        // Check StartSeqNo in a cassette
        // Lots which has different StartSeqNo should start with different control job.
        // If the equipment is batch, lots in cassette is started at the same time and shouldn't have different StartSeqNo.
        //--------------------------------
        if( 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_Batch) && bKitFlag == FALSE )
        {
            PPT_METHODTRACE_V1("","multiRecipeCapability is Batch and bKitFlag is FALSE.");
            CORBA::ULong nLenCast = 0;
            nSeqLen  = 5;
            pptStartSeqNoSequence strStartSeqNoForCast;
            strStartSeqNoForCast.length(nSeqLen);
            CORBA::Boolean bCastFoundFlag = FALSE;
            for( i =0; i<strProdLotMap.length(); i++)
            {
                PPT_METHODTRACE_V2("","loop strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap",i);
                for( j =0; j<strProdLotMap[i].eqpMonitorLotIDs.length(); j++)
                {
                    PPT_METHODTRACE_V2("","loop strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap.eqpMonitorLotIDs",j);
                    PPT_METHODTRACE_V2("","Lot ID",strProdLotMap[i].eqpMonitorLotIDs[j].identifier);
                    bCastFoundFlag = FALSE;

                    //Get Cassette object from Lot ID
                    objLot_cassette_Get_out  strLot_cassette_Get_out;
                    rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap[i].eqpMonitorLotIDs[j]);
                    if(rc != RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "##### lot_cassette_Get() != RC_OK");
                        strLot_CheckConditionForEqpMonitorLotReserve_out.strResult = strLot_cassette_Get_out.strResult;
                        return rc ;
                    }

                    for (x = 0; x<nLenCast; x++)
                    {
                        PPT_METHODTRACE_V2("","loop through strStartSeqNoForCast",x);
                        if ( 0 == CIMFWStrCmp( strStartSeqNoForCast[x].key, strLot_cassette_Get_out.cassetteID.identifier ) )
                        {
                            PPT_METHODTRACE_V2("","Found cassetteID",strLot_cassette_Get_out.cassetteID.identifier);
                            if ( strStartSeqNoForCast[x].startSeqNo != strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap[i].strEqpMonitorProductInfo.startSeqNo)
                            {
                                PPT_METHODTRACE_V1("","StartSeqNo condition isn't satisfied [Batch Equipment].");
                                SET_MSG_RC(strLot_CheckConditionForEqpMonitorLotReserve_out,MSG_MISMATCH_EQPMON_STARTSEQ,RC_MISMATCH_EQPMON_STARTSEQ);
                                return RC_MISMATCH_EQPMON_STARTSEQ;
                            }
                            bCastFoundFlag = TRUE;
                            break;
                        }
                    }
                    if ( FALSE == bCastFoundFlag )
                    {
                        PPT_METHODTRACE_V1("","new cassetteID");
                        //Add the combination of cassette ID and startSeqNo to strStartSeqNoForCast
                        if (nLenCast > nSeqLen)
                        {
                            PPT_METHODTRACE_V1("","increase sequence length by 5");
                            nSeqLen = nSeqLen +5;
                            strStartSeqNoForCast.length(nSeqLen);
                        }
                        strStartSeqNoForCast[nLenCast].key         = strLot_cassette_Get_out.cassetteID.identifier;
                        strStartSeqNoForCast[nLenCast].startSeqNo  = strProdLotMap[i].strEqpMonitorProductInfo.startSeqNo;
                        nLenCast++;
                    }
                }
            }
        }

        //--------------------------------
        // Check startSeqNo for Flow Batch
        // Lots which has different StartSeqNo should start with different control job.
        // If lots are included in Flow Batch, lots in Flow batch is started at the same time and shouldn't have different StartSeqNo.
        //--------------------------------
        nSeqLen = 5;
        pptStartSeqNoSequence strStartSeqNoForFlowBatch;
        strStartSeqNoForFlowBatch.length(nSeqLen);
        CORBA::ULong nLenFB = 0;
        CORBA::Boolean bFlowBatchFoundFlag = FALSE;
        PPT_METHODTRACE_V2("","length of strProdLotMap",strProdLotMap.length());
        for(i =0; i<strProdLotMap.length(); i++)
        {
            PPT_METHODTRACE_V2("","loop strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap",i);
            PPT_METHODTRACE_V2("","Product ID",strProdLotMap[i].strEqpMonitorProductInfo.productID.identifier);
            PPT_METHODTRACE_V2("","strProdLotMap[i].eqpMonitorLotIDs.length()",strProdLotMap[i].eqpMonitorLotIDs.length());
            for(j =0; j<strProdLotMap[i].eqpMonitorLotIDs.length(); j++)
            {
                PPT_METHODTRACE_V2("","loop strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap.eqpMonitorLotIDs",j);
                PPT_METHODTRACE_V2("","Lot ID",strProdLotMap[i].eqpMonitorLotIDs[j].identifier);
                bFlowBatchFoundFlag = FALSE;
                PosLot_var aPosLot;
                PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot,strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap[i].eqpMonitorLotIDs[j],strLot_CheckConditionForEqpMonitorLotReserve_out,lot_CheckConditionForEqpMonitorLotReserve);

                PosFlowBatch_var aLotFlowBatch;
                try
                {
                    aLotFlowBatch = aPosLot->getFlowBatch();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosFlowBatch::getFlowBatch);
                if(CORBA::is_nil(aLotFlowBatch))
                {
                    PPT_METHODTRACE_V1("","Lot isn't involved in FlowBatch. No need to check FlowBatch VS StartSeqNo for this lot.");
                    continue;
                }
                else
                {
                    PPT_METHODTRACE_V1("","Lot is involved in FlowBatch. Checking StartSeqNo condition.");
                    objectIdentifier flowBatchID;
                    PPT_SET_OBJECT_IDENTIFIER( flowBatchID,
                                               aLotFlowBatch,
                                               strLot_CheckConditionForEqpMonitorLotReserve_out,
                                               lot_CheckConditionForEqpMonitorLotReserve,
                                               PosFlowBatch );
                    PPT_METHODTRACE_V2("","Flow Batch ID",flowBatchID.identifier);
                    PosMachine_var aReservedMachine;
                    try
                    {
                        aReservedMachine = aLotFlowBatch->getMachine();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosFlowBatch::getMachine)


                    if ( CORBA::is_nil(aReservedMachine) )
                    {
                        PPT_METHODTRACE_V1("","Equipment isn't connected to FlowBatch");
                        continue;
                    }
                    objectIdentifier reservedEquipmentID;
                    PPT_SET_OBJECT_IDENTIFIER( reservedEquipmentID,
                                               aReservedMachine,
                                               strLot_CheckConditionForEqpMonitorLotReserve_out,
                                               lot_CheckConditionForEqpMonitorLotReserve,
                                               PosMachine );
                    PPT_METHODTRACE_V2("","reservedEquipmentID",reservedEquipmentID.identifier);
                    if( 0 != CIMFWStrCmp(reservedEquipmentID.identifier, equipmentID.identifier) )
                    {
                        PPT_METHODTRACE_V1("","Flow batch for other equipment. No need to check FlowBatch VS StartSeqNo for this lot.");
                        continue;
                    }

                    for ( x = 0; x<nLenFB; x++ )
                    {
                        PPT_METHODTRACE_V2("","loop through strStartSeqNoForFlowBatch",x);
                        PPT_METHODTRACE_V2("","strStartSeqNoForFlowBatch[x].key",strStartSeqNoForFlowBatch[x].key);
                        if ( 0 == CIMFWStrCmp( strStartSeqNoForFlowBatch[x].key, flowBatchID.identifier ) )
                        {
                            PPT_METHODTRACE_V2("","Found flowBatchID",flowBatchID.identifier);
                            if ( strStartSeqNoForFlowBatch[x].startSeqNo != strProdLotMap[i].strEqpMonitorProductInfo.startSeqNo)
                            {
                                PPT_METHODTRACE_V1("","StartSeqNo condition isn't satisfied [FlowBatch].");
                                SET_MSG_RC(strLot_CheckConditionForEqpMonitorLotReserve_out,MSG_MISMATCH_EQPMON_STARTSEQ,RC_MISMATCH_EQPMON_STARTSEQ);
                                return RC_MISMATCH_EQPMON_STARTSEQ;
                            }

                            bFlowBatchFoundFlag = TRUE;
                            break;
                        }
                    }
                    if ( FALSE == bFlowBatchFoundFlag )
                    {
                        PPT_METHODTRACE_V1("","new FlowBatch ID");
                        //Add the combination of FlowBatch ID and startSeqNo to strStartSeqNo
                        if (nLenFB > nSeqLen)
                        {
                            PPT_METHODTRACE_V1("","increase sequence length by 5");
                            nSeqLen = nSeqLen + 5;
                            strStartSeqNoForFlowBatch.length(nSeqLen);
                        }
                        strStartSeqNoForFlowBatch[nLenFB].key         = flowBatchID.identifier;
                        strStartSeqNoForFlowBatch[nLenFB].startSeqNo  = strProdLotMap[i].strEqpMonitorProductInfo.startSeqNo;
                        nLenFB++;
                    }
                }
            }
        }

        //--------------------------------
        // Check StartSeqNo for Bonding Group
        // Lots which has different StartSeqNo should start with different control job.
        // If lots are included in Bonding Group, lots in Bonding Group is started at the same time and shouldn't have different StartSeqNo.
        //--------------------------------
        nSeqLen = 5;
        pptStartSeqNoSequence strStartSeqNoForBondinGroup;
        strStartSeqNoForBondinGroup.length(nSeqLen);
        CORBA::ULong nLenBG = 0;
        PPT_METHODTRACE_V2("","strProdLotMap.length()",strProdLotMap.length());
        for( i =0; i<strProdLotMap.length(); i++)
        {
            PPT_METHODTRACE_V2("","loop strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap",i);
            PPT_METHODTRACE_V2("","Product ID",strProdLotMap[i].strEqpMonitorProductInfo.productID.identifier);
            PPT_METHODTRACE_V2("","strProdLotMap[i].eqpMonitorLotIDs.length()",strProdLotMap[i].eqpMonitorLotIDs.length());
            for( j =0; j<strProdLotMap[i].eqpMonitorLotIDs.length(); j++)
            {
                PPT_METHODTRACE_V2("","loop strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap.eqpMonitorLotIDs",j);
                PPT_METHODTRACE_V2("","Lot ID",strProdLotMap[i].eqpMonitorLotIDs[j].identifier);
                CORBA::Boolean bBondingGroupFoundFlag = FALSE;
                objLot_bondingGroupID_GetDR_out strLot_bondingGroupID_GetDR_out;
                objLot_bondingGroupID_GetDR_in strLot_bondingGroupID_GetDR_in;
                strLot_bondingGroupID_GetDR_in.lotID = strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap[i].eqpMonitorLotIDs[j];

                PPT_METHODTRACE_V1("", "call lot_bondingGroupID_GetDR()");
                rc = lot_bondingGroupID_GetDR( strLot_bondingGroupID_GetDR_out, strObjCommonIn, strLot_bondingGroupID_GetDR_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2( "", "lot_bondingGroupID_GetDR() != RC_OK", rc );
                    strLot_CheckConditionForEqpMonitorLotReserve_out.strResult = strLot_bondingGroupID_GetDR_out.strResult;
                    return rc;
                }

                if ( 0 == CIMFWStrLen( strLot_bondingGroupID_GetDR_out.bondingGroupID ) )
                {
                    PPT_METHODTRACE_V1("","Lot isn't involved in BondingGroup. No need to check BondingGroup VS StartSeqNo for this lot.");
                    continue;
                }
                else
                {
                    PPT_METHODTRACE_V1("","Lot is involved in BondingGroup");
                    PPT_METHODTRACE_V2("","BondingGroup ID", strLot_bondingGroupID_GetDR_out.bondingGroupID);
                    //------------------------------
                    // bondingGroup_info_GetDR
                    //------------------------------
                    objBondingGroup_info_GetDR_out strBondingGroup_info_GetDR_out;
                    objBondingGroup_info_GetDR_in  strBondingGroup_info_GetDR_in;
                    strBondingGroup_info_GetDR_in.bondingGroupID     = strLot_bondingGroupID_GetDR_out.bondingGroupID;
                    strBondingGroup_info_GetDR_in.bondingMapInfoFlag = FALSE;
                    rc = bondingGroup_info_GetDR( strBondingGroup_info_GetDR_out, strObjCommonIn, strBondingGroup_info_GetDR_in );

                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2( "", "bondingGroup_info_GetDR() != RC_OK", rc );
                        strLot_CheckConditionForEqpMonitorLotReserve_out.strResult = strBondingGroup_info_GetDR_out.strResult;
                        return rc;

                    }
                    PPT_METHODTRACE_V2("","targetEquipmentID", strBondingGroup_info_GetDR_out.strBondingGroupInfo.targetEquipmentID.identifier);
                    if( 0 != CIMFWStrCmp(strBondingGroup_info_GetDR_out.strBondingGroupInfo.targetEquipmentID.identifier, equipmentID.identifier))
                    {
                        PPT_METHODTRACE_V1("","Bonding Group for other equipment. No need to check Bonding Group VS StartSeqNo for this lot.");
                        continue;
                    }
                    for ( x = 0; x<nLenBG; x++ )
                    {
                        PPT_METHODTRACE_V2("", "loop through strStartSeqNoForBondinGroup", x);
                        PPT_METHODTRACE_V2("","strStartSeqNoForBondinGroup[x].key", strStartSeqNoForBondinGroup[x].key);
                        if ( 0 == CIMFWStrCmp( strStartSeqNoForBondinGroup[x].key, strLot_bondingGroupID_GetDR_out.bondingGroupID ) )
                        {
                            PPT_METHODTRACE_V2("", "Found bondingGroupID", strLot_bondingGroupID_GetDR_out.bondingGroupID);
                            if ( strStartSeqNoForBondinGroup[x].startSeqNo != strProdLotMap[i].strEqpMonitorProductInfo.startSeqNo)
                            {
                                PPT_METHODTRACE_V1("","StartSeqNo condition isn't satisfied [BondingGroup].");
                                SET_MSG_RC( strLot_CheckConditionForEqpMonitorLotReserve_out,MSG_MISMATCH_EQPMON_STARTSEQ,RC_MISMATCH_EQPMON_STARTSEQ);
                                return RC_MISMATCH_EQPMON_STARTSEQ;
                            }
                            bBondingGroupFoundFlag = TRUE;
                            break;
                        }
                    }
                    if ( FALSE == bBondingGroupFoundFlag )
                    {
                        PPT_METHODTRACE_V1("","new BondingGroup ID");
                        //Add the combination of BondingGroup ID and startSeqNo to strStartSeqNo
                        if (nLenBG >= nSeqLen)
                        {

                            PPT_METHODTRACE_V2("","increase sequence length by 5",nSeqLen);
                            nSeqLen = nSeqLen + 5;
                            strStartSeqNoForBondinGroup.length(nSeqLen);
                        }
                        strStartSeqNoForBondinGroup[nLenBG].key         = strLot_bondingGroupID_GetDR_out.bondingGroupID;
                        strStartSeqNoForBondinGroup[nLenBG].startSeqNo  = strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap[i].strEqpMonitorProductInfo.startSeqNo;
                        nLenBG++;
                    }
                }

            }
        }

        pptStartCassetteSequence tmpStartCassette; //Used for keeping cassette-lot relation
        if( bKitFlag == FALSE )
        {
            PPT_METHODTRACE_V1("","bKitFlag == FALSE ");

            //--------------------------------
            // Check Condition for Logical Recipe / Machine Recipe
            // Reuse logic in lot_CheckConditionForOperation()
            //--------------------------------

            for( i =0; i<strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap.length(); i++)
            {
                PPT_METHODTRACE_V2("","loop strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap",i);
                for( j =0; j<strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap[i].eqpMonitorLotIDs.length(); j++)
                {
                    PPT_METHODTRACE_V2("","loop strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap.eqpMonitorLotIDs",j);
                    //Set cassette ID and lot ID to tmpStartCassette
                    objLot_cassette_Get_out  strLot_cassette_Get_out;
                    rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap[i].eqpMonitorLotIDs[j]);
                    if(rc != RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "##### lot_cassette_Get() != RC_OK");
                        strLot_CheckConditionForEqpMonitorLotReserve_out.strResult = strLot_cassette_Get_out.strResult;
                        return rc ;
                    }
                    CORBA::ULong nLenST = tmpStartCassette.length();
                    CORBA::Boolean bFoundST = FALSE;
                    for(x = 0; x<nLenST; x++)
                    {
                        PPT_METHODTRACE_V2("", "##### loop through tmpStartCassette",x);
                        if( 0 == CIMFWStrCmp(strLot_cassette_Get_out.cassetteID.identifier,tmpStartCassette[x].cassetteID.identifier ))
                        {
                            PPT_METHODTRACE_V1("", "Found same cassetteID");
                            CORBA::ULong nLenLots = tmpStartCassette[x].strLotInCassette.length();
                            tmpStartCassette[x].strLotInCassette.length(nLenLots+1);
                            tmpStartCassette[x].strLotInCassette[nLenLots].lotID = strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap[i].eqpMonitorLotIDs[j];
                            bFoundST = TRUE;
                            break;
                        }
                    }
                    if(FALSE == bFoundST)
                    {
                        PPT_METHODTRACE_V1("", "new cassetteID");
                        tmpStartCassette.length(nLenST+1);
                        tmpStartCassette[nLenST].cassetteID = strLot_cassette_Get_out.cassetteID;
                        tmpStartCassette[nLenST].strLotInCassette.length(1);
                        tmpStartCassette[nLenST].strLotInCassette[0].lotID = strLot_CheckConditionForEqpMonitorLotReserve_in.strProductLotMap[i].eqpMonitorLotIDs[j];
                    }
                }
            }
            
            for(i = 0; i<tmpStartCassette.length();i++)
            {
                PPT_METHODTRACE_V2("", "loop through tmpStartCassette",i);
                PPT_METHODTRACE_V2("","tmpStartCassette[i].strLotInCassette.length()",tmpStartCassette[i].strLotInCassette.length());
                for(j = 0; j<tmpStartCassette[i].strLotInCassette.length(); j++)
                {
                    PPT_METHODTRACE_V2("", "loop through tmpStartCassette.strLotInCassette",j);
                    PPT_METHODTRACE_V2("", "Lot ID",tmpStartCassette[i].strLotInCassette[j].lotID.identifier);
                    CORBA::Boolean skipFlag = FALSE;
                    objLot_effectiveFPCInfo_Get_out strLot_effectiveFPCInfo_Get_out;
                    rc = lot_effectiveFPCInfo_Get( strLot_effectiveFPCInfo_Get_out, strObjCommonIn,
                                                   SP_FPC_ExchangeType_StartReserveInfo,
                                                   equipmentID,
                                                   tmpStartCassette[i].strLotInCassette[j].lotID );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_effectiveFPCInfo_Get() != RC_OK", rc);
                        strLot_CheckConditionForEqpMonitorLotReserve_out.strResult = strLot_effectiveFPCInfo_Get_out.strResult;
                        return rc;
                    }
                    PosLot_var aLot;
                    PPT_CONVERT_LOTID_TO_LOT_OR( aLot,tmpStartCassette[i].strLotInCassette[j].lotID,strLot_CheckConditionForEqpMonitorLotReserve_out,lot_CheckConditionForEqpMonitorLotReserve);
            
                    /*------------------------------------------*/
                    /*    Get / Set Lot Type and Sub Lot Type   */
                    /*------------------------------------------*/
                    try
                    {
                        tmpStartCassette[i].strLotInCassette[j].lotType = aLot->getLotType();
                        PPT_METHODTRACE_V2( "", "lotType", tmpStartCassette[i].strLotInCassette[j].lotType);
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotType)
            
                    try
                    {
                        tmpStartCassette[i].strLotInCassette[j].subLotType = aLot->getSubLotType();
                        PPT_METHODTRACE_V2( "", "subLotType", tmpStartCassette[i].strLotInCassette[j].subLotType);
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType)
            
                    /*===== get PO object =====*/
                    ProcessOperation_var    aPO;
                    PosProcessOperation_var aPosPO;
            
                    try
                    {
                        aPO    = aLot->getProcessOperation();
                        aPosPO = PosProcessOperation::_narrow(aPO);
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation);
            
                    if ( CORBA::is_nil(aPosPO) == TRUE )
                    {
                        PPT_SET_MSG_RC_KEY2( strLot_CheckConditionForEqpMonitorLotReserve_out,
                                             MSG_NOT_FOUND_PO,
                                             RC_NOT_FOUND_PO,
                                             "*****",
                                             tmpStartCassette[i].strLotInCassette[j].lotID.identifier );
                        return(RC_NOT_FOUND_PO);
                    }
            
                    /*===== get ProdSpec object =====*/
                    ProductSpecification_var    aProdSpec;
                    PosProductSpecification_var aPosProdSpec;
            
                    try
                    {
                        aProdSpec    = aLot->getProductSpecification();
                        aPosProdSpec = PosProductSpecification::_narrow(aProdSpec);
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification);
            
                    if ( CORBA::is_nil(aPosProdSpec) == TRUE )
                    {
                        SET_MSG_RC( strLot_CheckConditionForEqpMonitorLotReserve_out,
                                    MSG_NOT_FOUND_PRODUCTSPEC,
                                    RC_NOT_FOUND_PRODUCTSPEC );
                        return( RC_NOT_FOUND_PRODUCTSPEC );
                    }
            
                    /*===== get LogicalRecipe object and set objectIdentifier =====*/
                    PosLogicalRecipe_var aLogicalRecipe;
                    try
                    {
                        aLogicalRecipe = aPosPO->findLogicalRecipeFor(aPosProdSpec);
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::findLogicalRecipeFor);
            
                    if ( CORBA::is_nil(aLogicalRecipe) == TRUE )
                    {
                        SET_MSG_RC( strLot_CheckConditionForEqpMonitorLotReserve_out,
                                    MSG_NOT_FOUND_LCRECIPE,
                                    RC_NOT_FOUND_LCRECIPE );
                        return( RC_NOT_FOUND_LCRECIPE );
                    }
            
                    PPT_SET_OBJECT_IDENTIFIER( tmpStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID,
                                               aLogicalRecipe,
                                               strLot_CheckConditionForEqpMonitorLotReserve_out,
                                               lot_CheckConditionForEqpMonitorLotReserve,
                                               PosLogicalRecipe );
            
                    /*===== get / set MachineRecipe object and set objectIdentifier =====*/
                    PosMachineRecipe_var aMachineRecipe;
                    CORBA::Long searchCondition = 0;
                    CORBA::String_var searchCondition_var = CIMFWStrDup(getenv("SP_ENTITY_INHIBIT_SEARCH_CONDITION"));
                    if( CIMFWStrLen(searchCondition_var) > 0 )
                    {
                        PPT_METHODTRACE_V1("","SP_ENTITY_INHIBIT_SEARCH_CONDITION is not empty.");
                        searchCondition = atoi(searchCondition_var);
                    }
                    if( searchCondition == 1 )
                    {
                        PPT_METHODTRACE_V1("","SP_ENTITY_INHIBIT_SEARCH_CONDITION is 1");
                        try
                        {
                            aMachineRecipe = aLogicalRecipe->findMachineRecipeFor( aLot, aMachine );
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeFor)
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","SP_ENTITY_INHIBIT_SEARCH_CONDITION is not 1");
                        try
                        {
                            PPT_METHODTRACE_V2( "","subLotType", tmpStartCassette[i].strLotInCassette[j].subLotType);
                            aMachineRecipe = aLogicalRecipe->findMachineRecipeForSubLotType(aMachine, tmpStartCassette[i].strLotInCassette[j].subLotType);
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeForSubLotType);
                    }
            
                    if ( CORBA::is_nil(aMachineRecipe) == TRUE )
                    {
                        PPT_METHODTRACE_V1("","aMachineRecipe is nil.");
                        if( strLot_effectiveFPCInfo_Get_out.machineRecipeActionRequired == TRUE )
                        {
                            PPT_METHODTRACE_V1("", "MachineRecipe is overwritten by FPC");
                            skipFlag = TRUE;
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("","MachineRecipe is not overwritten by FPC");
                            SET_MSG_RC( strLot_CheckConditionForEqpMonitorLotReserve_out,
                                        MSG_NOT_FOUND_MCRECIPE,
                                        RC_NOT_FOUND_MCRECIPE );
                            return( RC_NOT_FOUND_MCRECIPE );
                        }
                    }
            
                    if( skipFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("","skipFlag == FALSE");
                        PPT_SET_OBJECT_IDENTIFIER( tmpStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID,
                                                   aMachineRecipe,
                                                   strLot_CheckConditionForEqpMonitorLotReserve_out,
                                                   lot_CheckConditionForEqpMonitorLotReserve,
                                                   PosMachineRecipe );
                    }
            
                    /*--------------------------------------------------------------*/
                    /*   Check if the recipe is available on Eqp.                   */
                    /*   This check is skipped when recipe is overwritten by FPC.   */
                    /*--------------------------------------------------------------*/
                    CORBA::Long tmpFPCAdoptFlag = atoi( getenv(SP_FPC_Adaptation_Flag) );
                    CORBA::Boolean bFPCFlag = FALSE;
                    if( 1 == tmpFPCAdoptFlag )
                    {
                        PPT_METHODTRACE_V1("", "Use FPC Infomation.");
                        objLot_effectiveFPCInfo_Get_out strLot_effectiveFPCInfo_Get_out;
                        rc = lot_effectiveFPCInfo_Get( strLot_effectiveFPCInfo_Get_out,
                                                       strObjCommonIn,
                                                       SP_FPC_ExchangeType_StartReserveInfo,
                                                       equipmentID,
                                                       tmpStartCassette[i].strLotInCassette[j].lotID );
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "lot_effectiveFPCInfo_Get() != RC_OK", rc);
                            strLot_CheckConditionForEqpMonitorLotReserve_out.strResult = strLot_effectiveFPCInfo_Get_out.strResult;
                            return rc;
                        }
            
                        if ( TRUE == strLot_effectiveFPCInfo_Get_out.machineRecipeActionRequired )
                        {
                            PPT_METHODTRACE_V1("", "TRUE == strLot_CheckConditionForEqpMonitor_out.machineRecipeActionRequired");
                            bFPCFlag = TRUE;
                        }
                    }
                    if ( FALSE == bFPCFlag )
                    {
            
                        PPT_METHODTRACE_V1("", "bFPCFlag == FALSE");
                        PosMachineRecipe_var aMachineRecipe;
                        PPT_CONVERT_RECIPEID_TO_MACHINERECIPE_OR( aMachineRecipe,
                                                                  tmpStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID,
                                                                  strLot_CheckConditionForEqpMonitorLotReserve_out,
                                                                  lot_CheckConditionForEqpMonitorLotReserve );
                        CORBA::Boolean bUsedFlag = FALSE;
                        try
                        {
                            bUsedFlag = aMachineRecipe->isUsedBy(aMachine);
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosMachineRecipe::isUsedBy);
            
                        if ( FALSE == bUsedFlag )
                        {
                            PPT_METHODTRACE_V1("", "bUsedFlag == FALSE");
                            PPT_SET_MSG_RC_KEY2( strLot_CheckConditionForEqpMonitorLotReserve_out,
                                                 MSG_INVALID_RECIPE_FOR_EQP,
                                                 RC_INVALID_RECIPE_FOR_EQP,
                                                 tmpStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID.identifier,
                                                 equipmentID.identifier );
                            return RC_INVALID_RECIPE_FOR_EQP;
                        }
                    }
            
                    /*------------------------------------------*/
                    /*   Check condition for recipe / chamber   */
                    /*------------------------------------------*/
                    CORBA::Long tmpChamberCheckPolicy = atoi( getenv(SP_CHAMBER_CHECK_POLICY) );
                    if ( 1 == tmpChamberCheckPolicy )
                    {
                        PPT_METHODTRACE_V1("", "Check condition for recipe/chamber.");
                        // Check chamber condition for logical recipe and recipe
                        //  - Chamber status
                        //  - Conditional available
                        objLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_out strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_out;
                        objLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_in  strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_in;
                        strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_in.lotID            = tmpStartCassette[i].strLotInCassette[j].lotID;
                        strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_in.equipmentID      = equipmentID;
                        strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_in.logicalRecipeID  = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID;
                        strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_in.machineRecipeID  = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID;
                        strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_in.inhibitCheckFlag = FALSE;
                        rc = logicalRecipe_candidateChamberInfo_GetByMachineRecipe( strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_out,
                                                                                    strObjCommonIn,
                                                                                    strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_in );
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "logicalRecipe_candidateChamberInfo_GetByMachineRecipe() != RC_OK", rc);
                            strLot_CheckConditionForEqpMonitorLotReserve_out.strResult = strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_out.strResult;
                            return rc;
                        }
            
                        if ( TRUE == strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_out.multiChamberFlag )
                        {
                            // Multi chamber case
                            PPT_METHODTRACE_V1("", "Multi chamber case.");
                            if ( TRUE == strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_out.recipeDefinedFlag
                              &&    0 == strLogicalRecipe_candidateChamberInfo_GetByMachineRecipe_out.strCandidateChamberSeq.length() )
                            {
            
                                // machine recipe is defined in logical recipe, but there is no available chamber
                                PPT_METHODTRACE_V1("", "machine recipe is defined in logical recipe, but there is no available chamber");
                                PPT_SET_MSG_RC_KEY( strLot_CheckConditionForEqpMonitorLotReserve_out,
                                                    MSG_CHAMBER_NOT_AVAIL_FOR_LOT,
                                                    RC_CHAMBER_NOT_AVAIL_FOR_LOT,
                                                    tmpStartCassette[i].strLotInCassette[j].lotID.identifier );
                                return RC_CHAMBER_NOT_AVAIL_FOR_LOT;
                            }
                            else
                            {
                                // Following 2 cases
                                // 1. Machine recipe isn't defined in logical recipe.
                                // 2. Machine recipe is defined in logical recipe and chambers are found which meets following condition
                                //     - Chamber Status
                                //     - Conditional available
                                PPT_METHODTRACE_V1("", "recipe/chamber check OK");
                            }
                        }
                        else
                        {
                            // Not multi chamber
                            PPT_METHODTRACE_V1("", "Not multi chamber.");
                        }
                    }
                }
            }

            if ( 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_Batch) )
            {
                PPT_METHODTRACE_V1("", "Equipment multiRecipeCapability is Batch." );
                for (i = 0; i<tmpStartCassette.length(); i++)
                {
                    /*------------------*/
                    /*   Check Recipe   */
                    /*------------------*/
                    PPT_METHODTRACE_V1("", "Check recipe conbination for Batch equipment..." );
                    CORBA::String_var baseLogicalRecipeID;
                    CORBA::String_var baseMachineRecipeID;
            
                    CORBA::Boolean bFirstFlag = TRUE;
                    CORBA::Boolean baseRecipeSetFlag = TRUE;
                    for (j = 0; j<tmpStartCassette[i].strLotInCassette.length(); j++)
                    {
                        PPT_METHODTRACE_V2("", "loop through tmpStartCassette.strLotInCassette",j);
                        if ( TRUE == bFirstFlag )
                        {
                            PPT_METHODTRACE_V1("", "baseRecipeSetFlag == FALSE" );
                            baseLogicalRecipeID = CIMFWStrDup( tmpStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID.identifier );
                            baseMachineRecipeID = CIMFWStrDup( tmpStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID.identifier );
                            PPT_METHODTRACE_V2("", "  baseLogicalRecipeID", baseLogicalRecipeID);
                            PPT_METHODTRACE_V2("", "  baseMachineRecipeID", baseMachineRecipeID);
            
                            baseRecipeSetFlag = FALSE;
                            bFirstFlag = FALSE;
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", "baseRecipeSetFlag != FALSE" );
                            PPT_METHODTRACE_V1("", "Check Recipe");
                            PPT_METHODTRACE_V2("", "  baseLogicalRecipeID", baseLogicalRecipeID);
                            PPT_METHODTRACE_V2("", "  baseMachineRecipeID", baseMachineRecipeID);
                            PPT_METHODTRACE_V2("", "  logicalRecipeID    ", tmpStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID.identifier);
                            PPT_METHODTRACE_V2("", "  machineRecipeID    ", tmpStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID.identifier);
            
                            if ( 0 == CIMFWStrCmp(baseLogicalRecipeID, tmpStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID.identifier) &&
                                 0 == CIMFWStrCmp(baseMachineRecipeID, tmpStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "logicalRecipe / MachineRecipe is same as baseRecipe" );
                                rc = RC_OK;
                            }
                            else
                            {
            
                                PPT_METHODTRACE_V1("", "##### logicalRecipe / MachineRecipe is not same as baseRecipe" );
                                SET_MSG_RC(strLot_CheckConditionForEqpMonitorLotReserve_out, MSG_INVALID_RECIPE_CONDITION_FOR_EQP, RC_INVALID_RECIPE_CONDITION_FOR_EQP);
                                return( RC_INVALID_RECIPE_CONDITION_FOR_EQP );
                            }
                        }
                    }
                }
            }

            //--------------------------------//
            //Get and Check Entity Inhibition
            //--------------------------------//
            PPT_METHODTRACE_V1("","Entity Inhibition -  checkLevel is EqpMonNoKit");
            objEquipment_CheckInhibitForLotWithMachineRecipe_out strEquipment_CheckInhibitForLotWithMachineRecipe_out;
            rc = equipment_CheckInhibitForLotWithMachineRecipe(strEquipment_CheckInhibitForLotWithMachineRecipe_out,
                                                               strObjCommonIn,
                                                               equipmentID,
                                                               lotIDs,
                                                               tmpStartCassette);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("","equipment_CheckInhibitForLot != RC_OK");
                strLot_CheckConditionForEqpMonitorLotReserve_out.strResult = strEquipment_CheckInhibitForLotWithMachineRecipe_out.strResult;
                return(rc);
            }
            //--------------------------------//
            //Durable condition check
            //--------------------------------//
            PPT_METHODTRACE_V1("","Durable condition -  checkLevel is EqpMonNoKit");
            for(i = 0; i< tmpStartCassette.length(); i++)
            {
                PPT_METHODTRACE_V2("","loop through tmpStartCassette",i);
                objProcessDurable_CheckConditionForOpeStart_out strProcessDurable_CheckConditionForOpeStart_out;
                rc = processDurable_CheckConditionForOpeStart( strProcessDurable_CheckConditionForOpeStart_out,
                                                               strObjCommonIn,
                                                               equipmentID,
                                                               tmpStartCassette[i].strLotInCassette[0].strStartRecipe.logicalRecipeID,
                                                               tmpStartCassette[i].strLotInCassette[0].strStartRecipe.machineRecipeID,
                                                               tmpStartCassette[i].strLotInCassette[0].lotID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","processDurable_CheckConditionForOpeStart() != RC_OK");
                    strLot_CheckConditionForEqpMonitorLotReserve_out.strResult = strProcessDurable_CheckConditionForOpeStart_out.strResult;
                    return rc;
                }

            }

        }

        PPT_METHODTRACE_EXIT("PPTManager_i::lot_CheckConditionForEqpMonitorLotReserve");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_CheckConditionForEqpMonitorLotReserve_out, lot_CheckConditionForEqpMonitorLotReserve, methodName)
}
