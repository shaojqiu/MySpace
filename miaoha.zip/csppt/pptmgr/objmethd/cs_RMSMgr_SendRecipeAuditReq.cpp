//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2003. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2003. All rights reserved.
//
// reference
// SiView name
// File : cs_RMSMgr_SendRecipeAuditReq.cpp
// Description :
//
// Modeficaiton History:
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
//
// Return:
//     Long
//
// Parameter:
//
//  csObjRMSMgr_SendRecipeAuditReq_out& strRMSMgr_SendRecipeAuditReq_out
//  const pptObjCommonIn&               strObjCommonIn
//  const objectIdentifier&             equipmentID
//  const objectIdentifier&             machineRecipeID
//  CORBA::Boolean                      bolEqpConstFlag
//  CORBA::Boolean                      bolBodyFlag
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

#include "cs_pptmgr.hpp"
#include "rmssm.hh"
#include "pmc.hh"
#include "pmcrc.hh"

CORBA::Long CS_PPTManager_i::cs_RMSMgr_SendRecipeAuditReq(csObjRMSMgr_SendRecipeAuditReq_out&         strRMSMgr_SendRecipeAuditReq_out,
                                                          const pptObjCommonIn&                       strObjCommonIn,
                                                          const objectIdentifier&                     equipmentID,
                                                          const objectIdentifier&                     machineRecipeID,
                                                          CORBA::Boolean                              bolEqpConstFlag,
                                                          CORBA::Boolean                              bolBodyFlag)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cs_RMSMgr_SendRecipeAuditReq");
        PPT_METHODTRACE_V2( "","in-parm's equipmentID", equipmentID.identifier);
        PPT_METHODTRACE_V2( "","in-parm's machineRecipeID", machineRecipeID.identifier);


        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        CORBA::String_var RMSServerName;
        CORBA::String_var RMSHostName;
        RMServiceManager_var RMSSvcMgr = RMServiceManager::_nil();
        {
            char scRMSServerName[512];

            if ( strstr(getenv(CS_SP_RMS_SERVER_NAME),":") == NULL )
            {
                CIMFWStrCpy(scRMSServerName, ":");
                CIMFWStrCat(scRMSServerName, getenv(CS_SP_RMS_SERVER_NAME));
            }
            else
            {
                CIMFWStrCpy(scRMSServerName, getenv(CS_SP_RMS_SERVER_NAME));
            }
            RMSServerName = CIMFWStrDup(scRMSServerName);
            PPT_METHODTRACE_V2( "","DEBUG_RMS RMSServerName", RMSServerName);


            char scRMSHostName[512];
            CIMFWStrCpy(scRMSHostName, getenv(CS_SP_RMS_HOST_NAME));
            RMSHostName = CIMFWStrDup(scRMSHostName);
        }

        /*--------------------------------------*/
        /*   Check RMSHostName is NULL or Not   */
        /*--------------------------------------*/
        if ( CIMFWStrLen(RMSHostName) == 0 )
        {
            PPT_METHODTRACE_V1("", "RMSHostName is null. return to caller with RC_OK..." );
            SET_MSG_RC(strRMSMgr_SendRecipeAuditReq_out, MSG_OK, RC_OK);
            PPT_METHODTRACE_EXIT("PPTManager_i::cs_RMSMgr_SendRecipeAuditReq");
            return( RC_OK );
        }
        PPT_METHODTRACE_V2( "","DEBUG_RMS RMSHostName", RMSHostName);

        /*---------------------------*/
        /*   Get PosMachine object   */
        /*---------------------------*/
        PosMachine_var aPosMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR(aPosMachine,equipmentID,strRMSMgr_SendRecipeAuditReq_out,cs_RMSMgr_SendRecipeAuditReq);

        /*-----------------------------------------*/
        /*   Get equipment's cell controller ID    */
        /*-----------------------------------------*/
        CORBA::String_var varCellController;
        try
        {
            varCellController = aPosMachine->getCellController();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getCellController);

        if (CIMFWStrLen(varCellController) == 0)
        {
            PPT_METHODTRACE_V1("", "CIMFWStrLen(varCellController) == 0");
            rc = RC_OK;
            PPT_METHODTRACE_EXIT("PPTManager_i::cs_RMSMgr_SendRecipeAuditReq");
            return (rc);
        }

        /*-----------------------------------------*/
        /*   Get equipment's Special Control       */
        /*   if it's "Inline Pilot", pass to RMS   */
        /*-----------------------------------------*/
        CORBA::String_var varEquipmentType;
        varEquipmentType = CIMFWStrDup("");

        stringSequence * SpcEquControls = NULL; 
        stringSequence_var SpcEquControlsVar;
        try
        {
            SpcEquControls = aPosMachine->getSpecialEquipmentControls();
            SpcEquControlsVar = SpcEquControls;
        }
        CATCH_AND_RAISE_EXCEPTIONS(Machine::getSpecialEquipmentControls);

        CORBA::Long spEqpCtrlLen = (*SpcEquControls).length();

        for ( CORBA::Long jj=0; jj<spEqpCtrlLen; jj++ )
        {
            PPT_METHODTRACE_V2("", "loop to (*SpcEquControls).length()", jj );
            if ( CIMFWStrCmp( (*SpcEquControls)[jj], SP_Mc_SpecialEquipmentControl_InlinePilot) == 0)
            {
                PPT_METHODTRACE_V2("", "Special Control is : ", (*SpcEquControls)[jj]);
                varEquipmentType = CIMFWStrDup (SP_Mc_SpecialEquipmentControl_InlinePilot);
            }
        }

        CORBA::String_var physicalRecipeID;
        physicalRecipeID=CIMFWStrDup("");
        if (CIMFWStrLen(machineRecipeID.identifier)!=0)
        { 
            /*-------------------------------------*/
            /*   Get PosMachineRecipe_var object   */
            /*-------------------------------------*/
            PosMachineRecipe_var aMachineRecipe;
            PPT_CONVERT_RECIPEID_TO_MACHINERECIPE_OR(aMachineRecipe,machineRecipeID,strRMSMgr_SendRecipeAuditReq_out,cs_RMSMgr_SendRecipeAuditReq);

            /*------------------------------------------*/
            /*   Get ecipe ID from machine recipe ID    */
            /*------------------------------------------*/
            try
            {
                physicalRecipeID = aMachineRecipe->getPhysicalRecipeId();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosMachineRecipe::getPhysicalRecipeId);

            if (CIMFWStrLen(physicalRecipeID) == 0)
            {
                PPT_METHODTRACE_V1("", "CIMFWStrLen(physicalRecipeID) == 0");
                rc = RC_OK;
                PPT_METHODTRACE_EXIT("PPTManager_i::cs_RMSMgr_SendRecipeAuditReq");
                return (rc);
            }
        }

        //---------------------------------
        //   Bind to RMS Service Manager
        //---------------------------------
        PPT_METHODTRACE_V1("", "Bind to RMS Service Manager");

        csObjRMSMgr_GetServiceManager_out strRMSMgr_GetServiceManager_out;
        rc = cs_RMSMgr_GetServiceManager(strRMSMgr_GetServiceManager_out, strObjCommonIn, RMSServerName, RMSHostName);

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cs_RMSMgr_GetServiceManager() rc != RC_OK");
            strRMSMgr_SendRecipeAuditReq_out.strResult = strRMSMgr_GetServiceManager_out.strResult;
            return( rc );
        }
        PPT_METHODTRACE_V2("", "RMSSvcMgr ---> ", strRMSMgr_GetServiceManager_out.RMSSvcMgr);

        CORBA::Object_var anObject;
        try
        {
#ifdef EBROKER
            anObject = SP_STRING_TO_OBJECT(strRMSMgr_GetServiceManager_out.RMSSvcMgr);
#else
            anObject = CORBA::Orbix.string_to_object(strRMSMgr_GetServiceManager_out.RMSSvcMgr);
#endif
        }
        catch(...)
        {
            PPT_METHODTRACE_V1("", "##### SP_STRING_TO_OBJECT() raises exception");
            SET_MSG_RC(strRMSMgr_SendRecipeAuditReq_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
            return RC_SYSTEM_ERROR;
        }
        RMSSvcMgr = RMServiceManager::_narrow(anObject);

        if ( TRUE == CORBA::is_nil(RMSSvcMgr) )
        {
            PPT_METHODTRACE_V1("", "##### RMSSvcMgr is nil");
            SET_MSG_RC(strRMSMgr_SendRecipeAuditReq_out, MSG_EXT_SERVER_NIL_OBJ, RC_EXT_SERVER_NIL_OBJ);
            return(RC_EXT_SERVER_NIL_OBJ);
        }
#ifdef EBROKER
        CORBA::Environment envTimeOut = SP_CORBAENV_DEFENV ;
#else
        CORBA::Environment envTimeOut = CORBA::IT_chooseDefaultEnv();
#endif
        CORBA::String_var timeOutValue = CIMFWStrDup(getenv(CS_SP_TX_TIMEOUT_RMS));

        PPT_METHODTRACE_V2("","timeOutValue ---> ",timeOutValue);

        if ( 0 < CIMFWStrLen(timeOutValue) )
        {
            PPT_METHODTRACE_V1("", "setting timeout!!");
            envTimeOut.timeout(atol(timeOutValue) * 1000);
        }

        /*-------------------------*/
        /*   Send Request to RMS   */
        /*-------------------------*/
        rmsAuditReqResult*    results = NULL;
        rmsAuditReqResult_var resultsVar;

        try
        {
            PPT_METHODTRACE_V2("", "DEBUG_bolEqpConstFlag",((bolEqpConstFlag)?1:0));
            PPT_METHODTRACE_V2("", "DEBUG_bolBodyFlag",((bolBodyFlag)?1:0));
            results = RMSSvcMgr->TxRMSAuditReq(strObjCommonIn.strUser,  
                                               equipmentID,
                                               varCellController,
                                               machineRecipeID,
                                               physicalRecipeID,
                                               bolEqpConstFlag,
                                               bolBodyFlag,
                                               varEquipmentType,  
                                               0,                 
                                               "",                
                                               "SYSAUTO:From MM", 
                                               envTimeOut );
            resultsVar = results;
        }
        catch(const CORBA::SystemException &SysEx)
        {
            PPT_METHODTRACE_V1("", "CORBA::SystemException caught");
            APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
            SET_MSG_RC( strRMSMgr_SendRecipeAuditReq_out, CS_MSG_NO_RESPONSE_RMS, CS_RC_NO_RESPONSE_RMS );
            try
            {
                externalServerList.remove((char *)RMSHostName);
            }
            catch( ... )
            {
                PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
            }
            return( CS_RC_NO_RESPONSE_RMS );
        }
        catch( ... )
        {
            PPT_METHODTRACE_V1("", "Unknown exception caught");
            APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ();
            SET_MSG_RC( strRMSMgr_SendRecipeAuditReq_out, CS_MSG_NO_RESPONSE_RMS, CS_RC_NO_RESPONSE_RMS );
            try
            {
                externalServerList.remove((char *)RMSHostName);
            }
            catch( ... )
            {
                PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
            }
            return( CS_RC_NO_RESPONSE_RMS );
        }

        /*-------------------------------------------*/
        /*   Set Return Value and Return to Caller   */
        /*-------------------------------------------*/
        strRMSMgr_SendRecipeAuditReq_out.strResult            = results->strResult;
        rc = atol(strRMSMgr_SendRecipeAuditReq_out.strResult.returnCode);
        PPT_METHODTRACE_EXIT("PPTManager_i::cs_RMSMgr_SendRecipeAuditReq");
        return ( rc );
    }
    CATCH_GLOBAL_EXCEPTIONS(strRMSMgr_SendRecipeAuditReq_out,cs_RMSMgr_SendRecipeAuditReq,methodName);
}
