//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_userData_GetByLotOperation.cpp
//


#include "cs_pptmgr.hpp"
#include "timstamp.hpp"
#include "duration.hpp"
#include "plot.hh"
#include "pltsch.hh"
#include "pltopsch.hh"
#include "plottype.hh"
#include "plotfm.hh"
#include "pwafer.hh"
#include "pltnt.hh"
#include "pltopnt.hh"
#include "pmongrp.hh"
#include "pltcmnt.hh"
#include "ppcope.hh"
#include "ppcdf.hh"
#include "ppcflwx.hh"
#include "ppcflw.hh"
#include "pqtime.hh"
#include "ppcopsp.hh"
#include "ppcdr.hh"
#include "ppcdrcp.hh"
#include "pperson.hh"
#include "pmc.hh"
#include "pstmc.hh"
#include "pperson.hh"
#include "pbufrs.hh"
#include "pdrmggl.hh"
#include "mtrllctn.hh"

// Class: CS_PPTManager

//
// Service: cs_userData_GetByLotOperation()
//
// Change history:
// Date     Defect#  Person         Comments
// -------- -------- -------------- -------------------------------------------
// 2017/09/15 INN-R170003  Joan Zhou      INN-R170003:Durable Management Enhancement
//
// Description:
//
// Return:
//     Long
//
// Parameter:
//    csObjUserData_GetByLotOperation_out& strUserData_GetByLotOperation_out
//    const pptObjCommonIn& strObjCommonIn
//    const csObjUserData_GetByLotOperation_in& strUserData_GetByLotOperation_in
//
//typedef struct csObjUserData_GetByLotOperation_out_struct {
//    pptRetCode              strResult;
//    pptUserDataSequence     strUserDataSeq;
//    any                     siInfo;
//}  csObjUserData_GetByLotOperation_out;
//
//typedef struct csObjUserData_GetByLotOperation_in_struct {
//    objectIdentifier        lotID;
//    stringSequence          userDataNameSeq;
//    any                     siInfo;
//}  csObjUserData_GetByLotOperation_in;
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::cs_userData_GetByLotOperation(
    csObjUserData_GetByLotOperation_out& strUserData_GetByLotOperation_out, 
    const pptObjCommonIn& strObjCommonIn, 
    const csObjUserData_GetByLotOperation_in& strUserData_GetByLotOperation_in)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_userData_GetByLotOperation");
        PosLot_var aLot;
        objectIdentifier lotID = strUserData_GetByLotOperation_in.lotID;
        PPT_METHODTRACE_V2("","lotID--------------------->", lotID.identifier);
        PPT_CONVERT_LOTID_TO_LOT_OR(aLot, lotID, strUserData_GetByLotOperation_out,cs_userData_GetByLotOperation);
        ProcessOperation_var aProcessOperation;
        PosProcessOperation_var aPO;
        try
        {
            aProcessOperation = aLot->getProcessOperation();
            aPO = PosProcessOperation::_narrow(aProcessOperation);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation);
        
        if (CORBA::is_nil(aPO))
        {
            PPT_SET_MSG_RC_KEY2(strUserData_GetByLotOperation_out, MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO, "", lotID.identifier);
            return(RC_NOT_FOUND_PO);
        }
        
        ProcessOperationSpecification_var aProcessOperationSpecification;
        PosProcessOperationSpecification_var aPOS;
        try
        {
            aProcessOperationSpecification = aPO->getProcessOperationSpecification();
            aPOS = PosProcessOperationSpecification::_narrow(aProcessOperationSpecification);
        }
        CATCH_AND_RAISE_EXCEPTIONS(ProcessOperation::getProcessOperationSpecificaiton)
        
        
        userDataSetSequence_var varUserDataSeq;
        varUserDataSeq->length(0);
        
        if (!CORBA::is_nil(aPOS))
        {
            try
            {
                varUserDataSeq = aPOS->allUserDataSets();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperationSpecification::getUserDataNamed)
        }
        
        //---------------------------------------------------------------------------
        //   Filter by input User Data Name
        //---------------------------------------------------------------------------
        CORBA::Long lngUserDataLen = varUserDataSeq->length();
        CORBA::Long lngNameLen = strUserData_GetByLotOperation_in.userDataNameSeq.length();
        strUserData_GetByLotOperation_out.strUserDataSeq.length(lngNameLen);
        PPT_METHODTRACE_V2("", "lngNameLen", lngNameLen);
        CORBA::Long lngCnt = 0;
        for (CORBA::Long lngNameCnt = 0; lngNameCnt < lngNameLen; lngNameCnt++)
        {
            PPT_METHODTRACE_V2("", "lngNameCnt", lngNameCnt);
            for (CORBA::Long lngUserDataCnt = 0; lngUserDataCnt < lngUserDataLen; lngUserDataCnt++)
            {
                PPT_METHODTRACE_V2("", "lngUserDataCnt", lngUserDataCnt);
                PPT_METHODTRACE_V2("", "strUserData_GetByLotOperation_in.userDataNameSeq[lngNameCnt]", strUserData_GetByLotOperation_in.userDataNameSeq[lngNameCnt]);
                PPT_METHODTRACE_V2("", "varUserDataSeq[lngUserDataCnt].name", varUserDataSeq[lngUserDataCnt].name);
                if (0 == CIMFWStrCmp(strUserData_GetByLotOperation_in.userDataNameSeq[lngNameCnt], varUserDataSeq[lngUserDataCnt].name))
                {
                    PPT_METHODTRACE_V2("", "found strUserData_GetByLotOperation_in.userDataNameSeq[lngNameCnt] in ", varUserDataSeq[lngUserDataCnt].name);
                    strUserData_GetByLotOperation_out.strUserDataSeq[lngCnt].name = CIMFWStrDup(varUserDataSeq[lngUserDataCnt].name);
                    strUserData_GetByLotOperation_out.strUserDataSeq[lngCnt].type = CIMFWStrDup(varUserDataSeq[lngUserDataCnt].type);
                    strUserData_GetByLotOperation_out.strUserDataSeq[lngCnt].value = CIMFWStrDup(varUserDataSeq[lngUserDataCnt].value);
                    strUserData_GetByLotOperation_out.strUserDataSeq[lngCnt].originator = CIMFWStrDup(varUserDataSeq[lngUserDataCnt].originator);

                    PPT_METHODTRACE_V2("", "===================UserDataSeq====================",lngUserDataCnt);
                    PPT_METHODTRACE_V2("", "strUserData_GetByLotOperation_out.strUserDataSeq[lngCnt].name",strUserData_GetByLotOperation_out.strUserDataSeq[lngCnt].name);
                    PPT_METHODTRACE_V2("", "strUserData_GetByLotOperation_out.strUserDataSeq[lngCnt].type",strUserData_GetByLotOperation_out.strUserDataSeq[lngCnt].type);
                    PPT_METHODTRACE_V2("", "strUserData_GetByLotOperation_out.strUserDataSeq[lngCnt].value",strUserData_GetByLotOperation_out.strUserDataSeq[lngCnt].value);                     
                    PPT_METHODTRACE_V2("", "strUserData_GetByLotOperation_out.strUserDataSeq[lngCnt].originator",strUserData_GetByLotOperation_out.strUserDataSeq[lngCnt].originator);                     
                    lngCnt++;                  
                break;
                }
            }
        }
        strUserData_GetByLotOperation_out.strUserDataSeq.length(lngCnt);
        
        //--------------------
        //   Return to Caller
        //--------------------
        //strUserData_GetByLotOperation_out.strUserDataSeq = strUserDataSeq;
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strUserData_GetByLotOperation_out, cs_userData_GetByLotOperation, methodName)
}
