//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_reticle_UsedDuration_Reset.cpp
//


#include "cs_pptmgr.hpp"
#include "timstamp.hpp"
#include "duration.hpp"
#include "ppcdr.hh"
#include "ppcdrcp.hh"
#include "pperson.hh"
#include "pmc.hh"
#include "pstmc.hh"
#include "pperson.hh"
#include "pbufrs.hh"
#include "pdrmggl.hh"
#include "mtrllctn.hh"

// Class: CS_PPTManager
//
// Service: cs_reticle_UsedDuration_Reset()
//
// Change history:
// Date       Defect#       Person        Comments
// ---------- --------      ------------- -------------------------------------------
// 2017/08/28 INN-R170003   Helios Zhen   INN-R170003:Durable Management Enhancement
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    objReticle_UsedDuration_Reset_out&      strReticle_UsedDuration_Reset_out,
//    const pptObjCommonIn&                   strObjCommonIn,
//    const objectIdentifier&                 reticleID,
//    const char*                             claimMemo
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_reticle_UsedDuration_Reset(
    csObjReticle_UsedDuration_Reset_out&    strReticle_UsedDuration_Reset_out,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&                 reticleID,
    const char*                             claimMemo) 

{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_reticle_UsedDuration_Reset");

        PosProcessDurable_var aReticle;
        PPT_CONVERT_RETICLEID_TO_RETICLE_OR(aReticle, 
                                            reticleID,
                                            strReticle_UsedDuration_Reset_out,
                                            cs_reticle_UsedDuration_Reset);

        try
        {
            SI_PPT_USERDATA_SET_STRING(aReticle,
                                       CS_M_RTCL_LAST_INSPECTION_TIME,
                                       strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setUserDataNamed);   

        try
        {
            aReticle->setLastMaintenanceTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setLastMaintenanceTimeStamp);

        PosPerson_var aPerson;
        PPT_GET_PERSON_FROM_USERID(aPerson, strObjCommonIn.strUser.userID, strReticle_UsedDuration_Reset_out,cs_reticle_UsedDuration_Reset)

        try
        {
            aReticle->setLastMaintenancePerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setLastMaintenancePerson);

        try
        {
            aReticle->setLastClaimedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setLastClaimedTimeStamp);

        try
        {
            aReticle->setLastClaimedPerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setLastClaimedPerson);

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_reticle_UsedDuration_Reset");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strReticle_UsedDuration_Reset_out, cs_reticle_UsedDuration_Reset, methodName)
}
