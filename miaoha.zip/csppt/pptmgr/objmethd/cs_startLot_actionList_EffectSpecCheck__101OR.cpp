#ifndef lint
static char *sccsid =  "%Z% %I% %W% %G% %U% [ %H% %T% ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2014. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2014. All rights reserved.
//
// SiView
// Name: cs_startLot_actionList_EffectSpecCheck__101OR.cpp
//

#include "cs_pptmgr.hpp"

#include "plot.hh"
#include "pmongrp.hh"
#include "ppcope.hh"
#include "ppcdf.hh"
#include "ppcflwx.hh"
#include "ppcflw.hh"
#include "pcas.hh"
#include "pmc.hh"
#include "pmcrc.hh"
#include "pwafer.hh" //INN-R170016


// Class: PPTManager
//
//[Object Function Name]: long   startLot_actionList_EffectSpecCheck__101
//
// Change history:
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2000-08-24  0.00      H.Ueda         Initial Release                 (R30)
// 2000-09-21  Q3000124  K.Matsuei      Nil Check
// 2000-09-21  P3000209  H.Ueda         Change logic when cassetteExchange was done.
// 2000-09-27  P3000162  H.Ueda         Bug Fix.
// 2000-10-10  Q3000284  Y.Iwasaki      Bug Fix
//                                       - TimeStamp set logic
//                                       - Entity inhibit list make logic
// 2002-01-08  P4100051  M.Shimizu      Entity Inhibit Owner Change
// 2002-01-28  P4100070  Y.Iwasaki      Add logic for CorrespondingOperation is
//                                      skipped case
// 2002/05/13  P4100425  K.Matsuei      The number of Parameters to assemble Message in PPT_SET_MSG_RC_KEY*** mistakes it.
// 2003/09/09  P5000145  H.Adachi       Fix Message and Message Macro mismatch.
// 2004/10/14  D6000049  M.Mori         APC Interface Spec-B Function Enhancement
// 2004/11/11  P6000053  M.Mori         Add logic of SpecError after Derived Error.
// 2006/02/03  D7000178  S.Kano         Add reference condition for PO.
//
// Date        Level        Author         Note
// ----------  ------------ -------------  -------------------------------------------
// 2008/10/20  DSIV00000214 H.Mutoh        Multi Fab Transfer Support
// 2009/09/07  DSIV00001021 H.Nonaka       Multiple Corresponding Operations Support (R101)
// 2009/10/02  DSIV00001365 R.Okano        Entity Inhibit Improvement. (R101)
// 2010-01-20  PSIV00001648 R.Iriguchi     Fix bug around lot_countForMailOtherFab.
// 2011-04-18  PSIV00003162 K.Yamaoku      In Delta DC specification, Multiple Corresponding Operation setting becomes invalid.
// 2011/08/30  DSN000015229 Li.Seal        Advanced Wafer Level Control
// 2013/11/26  PSN000083035 C.Mo           Corresponding Operation Function does not work correctly.
// 2014/04/23  PSN000016926 C.Mo           Corresponding Operation was not retrieved correctly when lot returned.
// 2016/09/26  PSN000103458 S.Kawabe       FPC doesn't support Multiple Corresponding Operation
// 2016/10/31  PSN000103685 C.Itoh         Inhibit does not show related OpeNo and related PDID correctly
//
// Change history:
// Date        Defect#      Person         Comments
// ----------  -----------  -------------- -------------------------------------------
// 2017/10/24  INN-R170016  Yangxiaojun    NPW Management Initial Release
//
//[Function Description]:
//  Check if actions of each strDCDef related to strLotInCassette.lotID included in strStartCassette.
//  Then return the out-parameter data sequence as bellows;
//  If, the lot which is required to do action of SPEC check result is Monitor-Lot,
//  and, some production lots are connected to its monitor, all of production lots are
//  effected the same action.
//
//  <1. strMessageList>
//     If actionCode is SP_ActionCode_Mail,
//        set message record to output parameter.
//
//  <2. strEntityInhibitions>
//     If actionCode is SP_ActionCode_Equipment,
//     If actionCode is SP_ActionCode_Recipe,
//     If actionCode is SP_ActionCode_Route,
//     If actionCode is SP_ActionCode_ProcessHold,
//
//     If actionCode has "ProcessHold", set the process hold record.
//     If the processed lot is monitored lot, set the monitored operation to output parameter.
//     If the processed lot is not monitored lot and it has a corresponding process operation, set it to output parameter.
//     If the processed lot is not monitored lot and it doesn't have a corresponding process operation,
//        set the current operation to output parameter.
//
//
//[Input Parameters]:
//  in  pptObjCommonIn            strObjCommonIn;
//  in  pptStartCassetteSequence& strStartCassette;
//  in  objectIdentifier&         equipmentID;
//
//[Output Parameters]:
//  out objStartLot_actionList_EffectSpecCheck_out__101 strStartLot_actionList_EffectSpecCheck_out;
//
//  typedef struct objStartLot_actionList_EffectSpecCheck_out__101_struct{
//       pptRetCode            strResult;
//       sequence <pptMessageAttributes>        strMessageList;
//       sequence <pptEntityInhibitDetailAttributes>  strEntityInhibitions;
//       sequence <pptMessageAttributeWithFabInfo> strMessageListWithFabInfo;
//       sequence <pptEntityInhibitAttributesWithFabInfo__101> strEntityInhibitionsWithFabInfo;
//       sequence <pptDCActionLotResult> strDCActionLotResult;
//  } objStartLot_actionList_EffectSpecCheck_out__101;
//
//
// 1)    typedef struct pptEntityInhibitDetailAttributes_struct
//       {
//           pptEntityIdentifierSequence entities;
//           stringSequence              subLotTypes;
//           string                      startTimeStamp;
//           string                      endTimeStamp;
//           string                      reasonCode;
//           string                      reasonDesc;
//           string                      memo;
//           objectIdentifier            ownerID;
//           string                      claimedTimeStamp;
//           pptEntityInhibitReasonDetailInfoSequence  strEntityInhibitReasonDetailInfos;
//       } pptEntityInhibitDetailAttributes;
//       typedef struct pptEntityIdentifier_struct
//       {
//           string           className;
//           objectIdentifier objectID;
//           string           attrib;
//       } pptEntityIdentifier;
//       typedef struct pptEntityInhibitReasonDetailInfo_struct
//       {
//           string                relatedLotID;
//           string                relatedControlJobID;
//           string                relatedFabID;
//           string                relatedRouteID;
//           string                relatedProcessDefinitionID;
//           string                relatedOperationNumber;
//           string                relatedOperationPassCount;
//           pptEntityInhibitSpcChartInfoSequence  strEntityInhibitSpcChartInfos;
//       } pptEntityInhibitReasonDetailInfo_struct;
//       typedef pptEntityInhibitSpcChartInfo_struct
//       {
//           string                relatedSpcDcType;
//           string                relatedSpcChartGroupID;
//           string                relatedSpcChartID;
//           string                relatedSpcChartType;
//           string                relatedSpcChartUrl;
//       } pptEntityInhibitSpcChartInfo;
//
// 2)    typedef struct pptMessageAttributes_struct
//       {
//           objectIdentifier      messageID;
//           objectIdentifier      lotID;
//           string                lotStatus;
//           objectIdentifier      equipmentID;
//           objectIdentifier      routeID;
//           string                operationNumber;
//           string                reasonCode;
//           string                messageText;
//       } pptMessageAttributes;
//
// 3)    typedef struct pptEntityInhibitAttributesWithFabInfo__101_struct
//       {
//           string                                   fabID;
//           pptEntityInhibititAttributes             strEntityInhibition;
//           pptEntityInhibitReasonDetailInfoSequence strEntityInhibitReasonDetailInfos;
//           any siInfo;
//       } pptEntityInhibitAttributesWithFabInfo__101;
//
// 4)    typedef struct pptMessageAttributesWithFabInfo_struct
//       {
//           string               fabID;
//           pptMessageAttributes strMessage;
//           any                  siInfo;
//       } pptMessageAttributesWithFabInfo;
//
// 5)    typedef struct pptDCActionLotResult_struct
//       {
//           objectIdentifier               measurementLotID;
//           pptDCActionResultInfoSequence  strDCActionResultInfo;
//           any                            siInfo;
//       } pptDCActionLotResult;
//
//[Return Value]:
//
//  Return Code                 Message ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_NOT_FOUND_LOT            MSG_NOT_FOUND_LOT
//  RC_NOT_FOUND_PO             MSG_NOT_FOUND_PO
//  RC_NOT_FOUND_ROUTE          MSG_NOT_FOUND_ROUTE
//  RC_LOCKED_BY_ANOTHER        MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR             MSG_SYSTEM_ERROR
//
//[Pseudo Code]
//

//INN-R170016 CORBA::Long PPTManager_i::startLot_actionList_EffectSpecCheck__101(
CORBA::Long CS_PPTManager_i::startLot_actionList_EffectSpecCheck__101( //INN-R170016
    objStartLot_actionList_EffectSpecCheck_out__101&      strStartLot_actionList_EffectSpecCheck_out,
    const pptObjCommonIn&                                 strObjCommonIn,
    const objStartLot_actionList_EffectSpecCheck_in__101& strStartLot_actionList_EffectSpecCheck_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::startLot_actionList_EffectSpecCheck__101");

//DSIV00000214 add start
        const pptStartCassetteSequence& strStartCassette = strStartLot_actionList_EffectSpecCheck_in.strStartCassette;
        const objectIdentifier&         equipmentID = strStartLot_actionList_EffectSpecCheck_in.equipmentID;;
        pptInterFabMonitorGroupActionInfoSequence strInterFabMonitorGroupActionInfoSequence;
        strInterFabMonitorGroupActionInfoSequence = strStartLot_actionList_EffectSpecCheck_in.strInterFabMonitorGroupActionInfoSequence;
        CORBA::Long rel_mong_count = strInterFabMonitorGroupActionInfoSequence.length();
        PPT_METHODTRACE_V2("", "rel_mong_count", rel_mong_count);
//DSIV00000214 add end
//DSIV00001021 add start
        pptDCActionLotResultSequence strDCActionLotResult;
        strDCActionLotResult = strStartLot_actionList_EffectSpecCheck_in.strDCActionLotResult;
        CORBA::Long dcActionLot_count = strDCActionLotResult.length();
        PPT_METHODTRACE_V2("", "dcActionLot_count", dcActionLot_count);

        CORBA::String_var correspondingOpeMode = CIMFWStrDup( getenv( SP_MULTI_CORRESOPE_MODE ) );
        PPT_METHODTRACE_V2( "", "SP_MULTI_CORRESOPE_MODE", correspondingOpeMode );
        CORBA::String_var correspondingDefaltMode = CIMFWStrDup( getenv( SP_CORRES_DEFAULT_MODE ) );
        PPT_METHODTRACE_V2( "", "SP_CORRES_DEFAULT_MODE", correspondingDefaltMode );
//DSIV00001021 add end

        CORBA::Long rc = RC_OK;        //D7000178
        CORBA::Long i, j, k, m, n, o;
        CORBA::Long scLen = strStartCassette.length();
        PPT_METHODTRACE_V2("", "strStartCassette.length", scLen);

        PosMonitoredLotSequence effectedLots;

        CORBA::Boolean findFlag;
        CORBA::Boolean registeredFlag = FALSE;          //DSN000015229
        CORBA::ULong actionRsltLen = 0;                 //DSN000015229
        CORBA::Long entity_count = 0;
        CORBA::Long msg_count = 0;
        CORBA::Long entity_countForOtherFab  = 0;       //DSIV00000214
//PSIV00001648        CORBA::Long lot_countForMailOtherFab = 0;       //DSIV00000214
        CORBA::Long p, msg_countPerMonLot    = 0;       //DSIV00000214
        CORBA::Boolean findLotFlag = FALSE;             //DSIV00000214
        CORBA::Boolean findMsgFlag = FALSE;             //DSIV00000214
        CORBA::Boolean findMonitoringLotFlag = FALSE;   //DSIV00000214

        CORBA::Long eCnt = 0;                           //DSIV00001365
        CORBA::Long entity_count_keep = 0;              //DSIV00001365
        CORBA::Long entity_countForOtherFab_keep  = 0;  //DSIV00001365

        for ( i = 0; i < scLen; i++ )
        {
//P3000209  if ( 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) )
//P3000209  {
//P3000209      continue;
//P3000209  }

            CORBA::Long lenStartCassette = strStartCassette[i].strLotInCassette.length();

            for ( j = 0; j < lenStartCassette; j++ )
            {
                /*---------------------------*/
                /*   Omit Not-OpeStart Lot   */
                /*---------------------------*/
                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    PPT_METHODTRACE_V1("", "operationStartFlag == FALSE");
                    continue;
                }

                /*---------------------------*/
                /*   Omit Non-DataCollection */
                /*---------------------------*/
                CORBA::Long lenDCDef = strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef.length();
                if ( 0 == lenDCDef )
                {
                    PPT_METHODTRACE_V1("", "lenDCDef.length == 0");
                    continue;
                }

                //-----------------------------------------
                //  Get Lot ojbect
                //-----------------------------------------
                PPT_METHODTRACE_V1("", "Get Lot ojbect");

                PosLot_var aPosLot;
                PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot,
                                             strStartCassette[i].strLotInCassette[j].lotID,
                                             strStartLot_actionList_EffectSpecCheck_out,
                                             startLot_actionList_EffectSpecCheck__101 );

                ProcessOperation_var aTmpProcessOperation;
                PosProcessOperation_var aPO;

//D7000178                try
//D7000178                {
//D7000178                    aTmpProcessOperation = aPosLot->getProcessOperation();
//D7000178                    aPO = PosProcessOperation::_narrow( aTmpProcessOperation );
//D7000178                }
//D7000178                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation)
//D7000178 add start
                //------------------------------------------
                // Current PO or Previous PO ?
                //------------------------------------------
                objLot_CheckConditionForPO_out  strLot_CheckConditionForPO_out;
                rc = lot_CheckConditionForPO( strLot_CheckConditionForPO_out,
                                              strObjCommonIn,
                                              strStartCassette[i].strLotInCassette[j].lotID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_CheckConditionForPO() != RC_OK");
                    strStartLot_actionList_EffectSpecCheck_out.strResult = strLot_CheckConditionForPO_out.strResult;
                    return( rc );
                }

                if ( strLot_CheckConditionForPO_out.currentPOFlag == TRUE )
                {
                    //--------------------------------------------------------------------------
                    // Get PO from Current Operation.
                    //--------------------------------------------------------------------------
                    PPT_METHODTRACE_V1("", "Get PO from the current Operation.")

                    try
                    {
                        aTmpProcessOperation = aPosLot->getProcessOperation();
                        aPO = PosProcessOperation::_narrow( aTmpProcessOperation );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation)
                }
                else
                {
                    //--------------------------------------------------------------------------
                    // Get PO from Previous Operation.
                    //--------------------------------------------------------------------------
                    PPT_METHODTRACE_V1("", "Get PO from the previous Operation.")

                    try
                    {
                        aTmpProcessOperation = aPosLot->getPreviousProcessOperation();
                        aPO = PosProcessOperation::_narrow( aTmpProcessOperation );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosLot::getPreviousProcessOperation);
                }
//D7000178 add end
                if ( CORBA::is_nil(aPO) )
                {
                    PPT_METHODTRACE_V1("", "aPO is nil");
                    PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSpecCheck_out,
                                        MSG_NOT_FOUND_OPERATION,
                                        RC_NOT_FOUND_OPERATION,
                                        "" );

                    return RC_NOT_FOUND_OPERATION;
                }
//PSN000016926 add start
                PosProcessDefinition_var aMainPD;
                try
                {
                    aMainPD = aPO->getMainProcessDefinition();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getMainProcessDefinition)

                if(CORBA::is_nil(aMainPD))
                {
                    PPT_METHODTRACE_V1("","CORBA::is_nil(aMainPD)");
                    PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSpecCheck_out,
                                        MSG_NOT_FOUND_PD,
                                        RC_NOT_FOUND_PD, "" );
                    return RC_NOT_FOUND_PD;
                }
                objectIdentifier mainPDID;
                PPT_SET_OBJECT_IDENTIFIER(  mainPDID,
                                            aMainPD,
                                            strStartLot_actionList_EffectSpecCheck_out,
                                            startLot_actionList_EffectSpecCheck__101,
                                            PosProcessDefinition );
                PPT_METHODTRACE_V2("","mainPDID", mainPDID.identifier);
//PSN000016926 add end

//DSIV00000214 add start
                CORBA::String_var currentFabID;
                try
                {
                    currentFabID = aPO->getFabID();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getProcessOperationLocation);

                PPT_METHODTRACE_V2("", "currentFabID", currentFabID);
                if ( CIMFWStrLen(currentFabID) == 0 )
                {
                    PPT_METHODTRACE_V1("", "currentFabID is null");
                }
//DSIV00000214 add end
//DSIV00001365 add start
                CORBA::String_var controlJobID;
                try
                {
                    controlJobID = aPO->getAssignedControlJobID();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getAssignedControlJobID);

                PPT_METHODTRACE_V2("", "controlJobID", controlJobID);
                if ( CIMFWStrLen(controlJobID) == 0 )
                {
                    PPT_METHODTRACE_V1("", "controlJobID is null");
                }
//DSIV00001365 add end
//DSN000015229 Add Start
                PosActionResultInfoSequence     actionResultInfoSeq;
                PosActionResultInfoSequence_var actionResultInfoSeqVar;
                try
                {
                    actionResultInfoSeqVar = aPO->getActionResultInfo();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getActionResultInfo);
                actionResultInfoSeq = actionResultInfoSeqVar;
                actionRsltLen = actionResultInfoSeq.length();
//DSN000015229 Add End
//PSN000103458 Add Start
                CORBA::String_var operationNoforFPC;
                try
                {
                    operationNoforFPC = aPO->getOperationNumber();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getOperationNumber)
//PSN000103458 Add End
                //-------------------------------------------------------
                //  Set always the input Lot to effectedLots[0]
                //  even if lot is monitor lot or not.
                //-------------------------------------------------------
                PPT_METHODTRACE_V1("", "Set always the input Lot to effectedLots[0]");

                effectedLots.length(1);

                effectedLots[0].lotID = strStartCassette[i].strLotInCassette[j].lotID;
                effectedLots[0].processOperation = SP_OBJECT_TO_STRING( aPO );

//Q3000284 add start
//DSIV00001021 delete start
//DSIV00001021                //-------------------------------------------------
//DSIV00001021                //  Get the corresponding processOperation
//DSIV00001021                //-------------------------------------------------
//DSIV00001021                PPT_METHODTRACE_V1("", "Get the corresponding processOperation");
//DSIV00001021 delete end

                PosProcessFlowContext_var aPFX;
                try
                {
                    aPFX = aPosLot->getProcessFlowContext();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessFlowContext)

                if ( CORBA::is_nil(aPFX) )
                {
                      PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSpecCheck_out,
                                          MSG_NOT_FOUND_PFX,
                                          RC_NOT_FOUND_PFX,
                                          "" );

                      return RC_NOT_FOUND_PFX;
                }

//P4100070 delete start
//              try
//              {
//                  aPO = aPFX->getCorrespondingProcessOperation();
//              }
//              CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlowContext::getCorrespondingProcessOperation);
//
//              if ( !CORBA::is_nil(aPO) )
//              {
//                  effectedLots[0].processOperation = SP_OBJECT_TO_STRING( aPO );
//              }
//P4100070 delete end
//Q3000284 add end
//DSIV00001021 delete start
//DSIV00001021                //-------------------------
//DSIV00001021                //   P4100070 add start
//DSIV00001021                //-------------------------
//DSIV00001021                CORBA::Boolean inhibitActionRequired = TRUE;
//DSIV00001021                PosProcessOperation_var aCorrPO;
//DSIV00001021//D7000178                try
//DSIV00001021//D7000178                {
//DSIV00001021//D7000178                    aCorrPO = aPFX->getCorrespondingProcessOperation();
//DSIV00001021//D7000178                }
//DSIV00001021//D7000178                CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlowContext::getCorrespondingProcessOperation);
//DSIV00001021//D7000178 add start
//DSIV00001021                try
//DSIV00001021                {
//DSIV00001021                    aCorrPO = aPFX->getCorrespondingProcessOperationFor( aPO );
//DSIV00001021                }
//DSIV00001021                CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlowContext::getCorrespondingProcessOperationFor);
//DSIV00001021//D7000178 add end
//DSIV00001021
//DSIV00001021                CORBA::Boolean requestOtherFabFlag = FALSE;    //DSIV00000214
//DSIV00001021                CORBA::String_var corrFabID;                   //DSIV00000214
//DSIV00001021
//DSIV00001021                if ( CORBA::is_nil(aCorrPO) != TRUE )
//DSIV00001021                {
//DSIV00001021                    //------------------------------------------------
//DSIV00001021                    //   Corresponding operation is Specified and
//DSIV00001021                    //   that operation was processed.
//DSIV00001021                    //------------------------------------------------
//DSIV00001021                    PPT_METHODTRACE_V3("","PFX's CorrespondingPO is existing...",i,j);
//DSIV00001021                    effectedLots[0].processOperation = SP_OBJECT_TO_STRING( aCorrPO );
//DSIV00001021//DSIV00000214 add start
//DSIV00001021                    try
//DSIV00001021                    {
//DSIV00001021                        corrFabID = aCorrPO->getFabID();
//DSIV00001021                    }
//DSIV00001021                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getProcessOperationLocation);
//DSIV00001021
//DSIV00001021                    PPT_METHODTRACE_V2("", "corrFabID", corrFabID);
//DSIV00001021                    if ( CIMFWStrLen(corrFabID) == 0 )
//DSIV00001021                    {
//DSIV00001021                        PPT_METHODTRACE_V1("", "corresponding FabID is null");
//DSIV00001021                    }
//DSIV00001021
//DSIV00001021                    if ( CIMFWStrLen(currentFabID) != 0 && CIMFWStrLen(corrFabID) != 0 &&
//DSIV00001021                        CIMFWStrCmp(currentFabID, corrFabID) != 0 )
//DSIV00001021                    {
//DSIV00001021                        requestOtherFabFlag = TRUE;
//DSIV00001021                    }
//DSIV00001021//DSIV00000214 add end
//DSIV00001021                }
//DSIV00001021                else
//DSIV00001021                {
//DSIV00001021                    PPT_METHODTRACE_V3("","PFX's CorrespondingPO is nill...",i,j);
//DSIV00001021                    CORBA::String_var corrOpeNo;
//DSIV00001021                    try
//DSIV00001021                    {
//DSIV00001021                        corrOpeNo = aPO->getCorrespondingProcessOperationNumber();
//DSIV00001021                    }
//DSIV00001021                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getCorrespondingProcessOperationNumber);
//DSIV00001021                    if ( CIMFWStrLen(corrOpeNo) == 0 )
//DSIV00001021                    {
//DSIV00001021                        //----------------------------------------------------
//DSIV00001021                        //   Corresponding operation is NOT specified in SM
//DSIV00001021                        //   In this case, current PO can be used for the
//DSIV00001021                        //   inhibit action.
//DSIV00001021                        //----------------------------------------------------
//DSIV00001021                        PPT_METHODTRACE_V3("","Corresponding Operation is not Defined in SM...",i,j);
//DSIV00001021                    }
//DSIV00001021                    else
//DSIV00001021                    {
//DSIV00001021                        //----------------------------------------------------
//DSIV00001021                        //   Corresponding operation is specified in SM,
//DSIV00001021                        //   however its operation's PO is not existing.
//DSIV00001021                        //   That means the corresponding operation is NOT
//DSIV00001021                        //   processed (using Locate Func.).
//DSIV00001021                        //   In this case, current PO can NOT be used for
//DSIV00001021                        //   the inhibit action.
//DSIV00001021                        //----------------------------------------------------
//DSIV00001021                        PPT_METHODTRACE_V3("","Corresponding Operation is Defined in SM, but it is not proceeded. Change inhibitActionRequiredFlag to :FALSE...",i,j);
//DSIV00001021                        inhibitActionRequired = FALSE;
//DSIV00001021                    }
//DSIV00001021                }
//DSIV00001021                //-------------------------
//DSIV00001021                //   P4100070 add end
//DSIV00001021                //-------------------------
//DSIV00001021
//DSIV00001021//DSIV00000214 add start
//DSIV00001021                objProcessOperation_Info_GetDR_out strProcessOperation_Info_GetDR_out;
//DSIV00001021                pptProcessOperationInfo strProcessOperationInfo;
//DSIV00001021                if ( requestOtherFabFlag == TRUE )
//DSIV00001021                {
//DSIV00001021                    PPT_METHODTRACE_V1("", "requestOtherFabFlag is TRUE. this lot has correspondingPO information(correspondingPO object is not null)");
//DSIV00001021                    //-------------------------------------
//DSIV00001021                    //   Get correspondingPO information
//DSIV00001021                    //-------------------------------------
//DSIV00001021                    objProcessOperation_Info_GetDR_in  strProcessOperation_Info_GetDR_in;
//DSIV00001021                    strProcessOperation_Info_GetDR_in.poObj = SP_OBJECT_TO_STRING(aCorrPO);
//DSIV00001021                    rc = processOperation_Info_GetDR( strProcessOperation_Info_GetDR_out, strObjCommonIn,
//DSIV00001021                                                      strProcessOperation_Info_GetDR_in );
//DSIV00001021                    if ( rc != RC_OK )
//DSIV00001021                    {
//DSIV00001021                        PPT_METHODTRACE_V2("", "processOperation_info_GetDR() != RC_OK", rc);
//DSIV00001021                        strStartLot_actionList_EffectSpecCheck_out.strResult = strProcessOperation_Info_GetDR_out.strResult;
//DSIV00001021                        return rc;
//DSIV00001021                    }
//DSIV00001021
//DSIV00001021                    strProcessOperationInfo = strProcessOperation_Info_GetDR_out.strProcessOperationInfo;
//DSIV00001021                }
//DSIV00001021//DSIV00000214 add end
//DSIV00001021 delete end
//DSIV00001021 add start
                CORBA::Boolean requestOtherFabFlagForMonitor = FALSE;
                CORBA::String_var generatedFabID;
//DSIV00001021 add end
                //-----------------------------------------------------------
                //  Check Monitor Grouping existnce
                //  If not existed, the input lot is not monitor lot.
                //  If existed, the input lot is monitor lot.
                //-----------------------------------------------------------
                PPT_METHODTRACE_V1("", "Check Monitor Grouping existnce");

                PosMonitorGroup_var aMonitorGroup;
                try
                {
                    aMonitorGroup = aPosLot->getControlMonitorGroup();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getControlMonitorGroup)

                if ( CORBA::is_nil(aMonitorGroup) )
                {
                    PPT_METHODTRACE_V1("", "aMonitorGroup is nil");
//Q3000284 delete start
//                    // if current process is measurement, find corresponding process operation for action.
//                    // else current process is process operation for action.
//
//                    PosProcessDefinition_var aProcessDefinition;
//                    try
//                    {
//                        aProcessDefinition = aPO->getProcessDefinition();
//                    }
//                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getProcessDefinition);
//
//                    if ( CORBA::is_nil(aProcessDefinition) )
//                    {
//                        PPT_METHODTRACE_V1("", "aProcessDefinition is nil");
//                        PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSpecCheck_out,
//                                            MSG_NOT_FOUND_PD,
//                                            RC_NOT_FOUND_PD,
//                                            "" );
//
//                        return RC_NOT_FOUND_PD;
//                    }
//
//                    CORBA::String_var pdType;
//                    try
//                    {
//                        pdType = aProcessDefinition->getProcessDefinitionType();
//                    }
//                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessDefinition::getProcessDefinitionType)
//
//                    PosProcessOperation_var aCorrespondingProcessOperation;
//
//                    if ( 0 == CIMFWStrCmp(pdType, SP_OPEPDTYPE_MEASUREMENT) )
//                    {
//                        PPT_METHODTRACE_V1("", "pdType == SP_OPEPDTYPE_MEASUREMENT");
//
//                        PosProcessFlowContext_var aPFX;
//                        try
//                        {
//                            aPFX = aPosLot->getProcessFlowContext();
//                        }
//                        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessFlowContext);
//
//                        if ( CORBA::is_nil(aPFX) )
//                        {
//                            PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSpecCheck_out,
//                                                MSG_NOT_FOUND_PFX,
//                                                RC_NOT_FOUND_PFX,
//                                                "" );
//
//                            return RC_NOT_FOUND_PFX;
//                        }
//                        //-------------------------------------------------
//                        //  Get the corresponding processOperation
//                        //-------------------------------------------------
//                        PPT_METHODTRACE_V1("", "Get the corresponding processOperation");
//
//                        try
//                        {
//                            aCorrespondingProcessOperation = aPFX->getCorrespondingProcessOperation();
//                        }
//                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlowContext::getCorrespondingProcessOperation);
//                    }
//
//                    if ( !CORBA::is_nil(aCorrespondingProcessOperation) )                                              //Q3000162
//                    {                                                                                                  //Q3000162
//                        //   Override processOperation aPO of the input lot.
//                        effectedLots[0].processOperation = SP_OBJECT_TO_STRING( aCorrespondingProcessOperation );      //Q3000162
////Q3000162              PPT_CONVERT_STRING_TO_OBJECT(effectedLots[0].processOperation, aCorrespondingProcessOperation, PosProcessOperation);
//                        PPT_METHODTRACE_V2("", "aCorrespondingProcessOperation--->", effectedLots[0].processOperation );
//
//                    }                                                                                                  //Q3000162
//Q3000284 delete end

                }
                //----------------------------------------------------------------
                //  When Monitor Grouping is existed get all related lots.
                //----------------------------------------------------------------
                else
                {
                    PPT_METHODTRACE_V1("", "When Monitor Grouping is existed get all related lots");

                    PosMonitoredLotSequence*    monitoredLots = NULL;
                    PosMonitoredLotSequence_var monitoredLots_var;
                    try
                    {
                        monitoredLots = aMonitorGroup->allLots();
                        monitoredLots_var = monitoredLots;
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::allLots)

                    CORBA::Long nLenMonitoredLots = monitoredLots->length();
                    effectedLots.length( nLenMonitoredLots + 1 );

                    for ( k = 0; k < nLenMonitoredLots; k++ )
                    {
//Q3000284              effectedLots[k+1].lotID            = (*monitoredLots)[k].lotID;
                        effectedLots[k+1].lotID            = (*monitoredLots)[k].lotID;   //Q3000284
                        effectedLots[k+1].processOperation = (*monitoredLots)[k].processOperation;
                    }
//DSIV00001021 add start
                    //-------------------------------------------------
                    //  Get GeneratedFabID
                    //-------------------------------------------------
                    try
                    {
                        generatedFabID = aMonitorGroup->getGeneratedFabID();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosMonitorGroup::getGeneratedFabID);

                    PPT_METHODTRACE_V2("", "generatedFabID", generatedFabID);
                    if ( CIMFWStrLen(generatedFabID) == 0 )
                    {
                        PPT_METHODTRACE_V1("", "generatedFabID is null");
                    }

                    if ( CIMFWStrLen(generatedFabID) != 0 && CIMFWStrLen(currentFabID) != 0 &&
                        CIMFWStrCmp(generatedFabID, currentFabID) != 0 )
                    {
                        PPT_METHODTRACE_V1("", "currentFabID and generatedFabID is not same");
                        requestOtherFabFlagForMonitor = TRUE;
                    }
//DSIV00001021 add end
                }

//P3000162      CORBA::Boolean equipment_hold_flag = FALSE;
//P3000162      CORBA::Boolean recipe_hold_flag    = FALSE;
//P3000162      CORBA::Boolean route_hold_flag     = FALSE;
//P3000162      CORBA::Boolean process_hold_flag   = FALSE;
//P3000162      CORBA::Boolean mail_flag           = FALSE;

//DSIV00001021 add start
                CORBA::Boolean findMeasurementLotFlag = FALSE;
                CORBA::Long dcActionLot_idx= 0;
                CORBA::Long dcActionInfo_count= 0;
                CORBA::Long coLen = 0;
                CORBA::Boolean findCorrespondingInfoFlag = FALSE;
                PosCorrespondingOperationInfoSequence tmpCorrOperations;
                pptOperationNameAttributesSequence opeNoList;
                CORBA::Long checkOpeCnt = 0;
//DSIV00001021 add end

                PPT_METHODTRACE_V2("", "lenDCDef-------------->", lenDCDef);
                for ( k = 0; k < lenDCDef; k++ )
                {
                    PPT_METHODTRACE_V2("", "counter k -------------->", k);
//PSIV00001648                    pptDCDef strDCDef;
//PSIV00001648                    strDCDef = strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k];
                    const pptDCDef& strDCDef = strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k];      //PSIV00001648

                    //=========================================================================================
                    // Check actionCode
                    //=========================================================================================
                    CORBA::String_var reasonCode = CIMFWStrDup("");
                    CORBA::String_var messageReason = CIMFWStrDup("");

                    CORBA::Long lenDCItem = strDCDef.strDCItem.length();
//PSN000103458 add start
                    // variable for multiple corresponding operation for FPC
                    CORBA::Long coFPCLen = 0;
                    stringSequence dcItemNames;
                    dcItemNames.length(0);
                    CORBA::Long dcItemLen=0;
                    CORBA::Long fpcCnt = 0;
                    CORBA::Long numFPC = 0;
                    CORBA::Long foundFPCCnt = 0;
                    CORBA::Long waferCntFromStartCassette = 0;
                    CORBA::Long waferCntFromFPC = 0;
                    CORBA::String_var singleCorrOpeFPC;
                    objFPC_info_GetDR_out__101 strFPC_info_GetDR_out;
//PSN000103458 add end
                    PPT_METHODTRACE_V2("", "lenDCItem -------------->", lenDCItem);
                    for ( m = 0; m < lenDCItem; m++ )
                    {
                        CORBA::Boolean equipment_hold_flag = FALSE;      //P3000162
                        CORBA::Boolean recipe_hold_flag    = FALSE;      //P3000162
                        CORBA::Boolean route_hold_flag     = FALSE;      //P3000162
                        CORBA::Boolean process_hold_flag   = FALSE;      //P3000162
                        CORBA::Boolean mail_flag           = FALSE;      //P3000162

                        PPT_METHODTRACE_V2("", "counter m -------------->", m);
                        CORBA::Long lenActionCode = strDCDef.strDCItem[m].actionCode.length();
                        PPT_METHODTRACE_V2("", "Check actionCode", lenActionCode);

                        PPT_METHODTRACE_V2("", "lenActionCode -------------->", lenActionCode );
                        for ( n = 0; n < lenActionCode; n++ )
                        {
                            PPT_METHODTRACE_V2("", "counter n -------------->", n);
                            if ( 0 == CIMFWStrCmp(strDCDef.strDCItem[m].actionCode[n], SP_ActionCode_EquipmentHold) )
                            {
                                PPT_METHODTRACE_V1("", "actionCode == SP_ActionCode_EquipmentHold");
                                equipment_hold_flag = TRUE;
                            }
                            if ( 0 == CIMFWStrCmp(strDCDef.strDCItem[m].actionCode[n], SP_ActionCode_RecipeHold) )
                            {
                                PPT_METHODTRACE_V1("", "actionCode == SP_ActionCode_RecipeHold");
                                recipe_hold_flag = TRUE;
                            }
                            if ( 0 == CIMFWStrCmp(strDCDef.strDCItem[m].actionCode[n], SP_ActionCode_RouteHold) )
                            {
                                PPT_METHODTRACE_V1("", "actionCode == SP_ActionCode_RouteHold");
                                route_hold_flag = TRUE;
                            }
                            if ( 0 == CIMFWStrCmp(strDCDef.strDCItem[m].actionCode[n], SP_ActionCode_ProcessHold) )
                            {
                                PPT_METHODTRACE_V1("", "actionCode == SP_ActionCode_ProcessHold");
                                process_hold_flag = TRUE;
                            }
                            if ( 0 == CIMFWStrCmp(strDCDef.strDCItem[m].actionCode[n], SP_ActionCode_Mail) )
                            {
                                PPT_METHODTRACE_V1("", "actionCode == SP_ActionCode_Mail");
                                mail_flag = TRUE;
                            }
                        }

                        //=========================================================================================
                        //   Check specCheckResult and set reasonCode / messageReason
                        //=========================================================================================
                        if ( 0 == CIMFWStrCmp(strDCDef.strDCItem[m].specCheckResult, SP_SpecCheckResult_UpperControlLimit) )
                        {
                            PPT_METHODTRACE_V1("", "strDCDef.specCheckResult == SP_SpecCheckResult_UpperControlLimit");
                            reasonCode    = CIMFWStrDup( SP_Reason_SpecOverHold_UpperControl );             // "SHUC"
                            messageReason = CIMFWStrDup( SP_Reason_SpecOverHold_UpperControl );
                        }
                        else if ( 0 == CIMFWStrCmp(strDCDef.strDCItem[m].specCheckResult, SP_SpecCheckResult_LowerControlLimit) )
                        {
                            PPT_METHODTRACE_V1("", "strDCDef.specCheckResult == SP_SpecCheckResult_LowerControlLimit");
                            reasonCode    = CIMFWStrDup( SP_Reason_SpecOverHold_LowerControl );             // "SHLC"
                            messageReason = CIMFWStrDup( SP_Reason_SpecOverHold_LowerControl );
                        }
                        else if ( 0 == CIMFWStrCmp(strDCDef.strDCItem[m].specCheckResult, SP_SpecCheckResult_UpperSpecLimit) )
                        {
                            PPT_METHODTRACE_V1("", "strDCDef.specCheckResult == SP_SpecCheckResult_UpperSpecLimit");
                            reasonCode    = CIMFWStrDup( SP_Reason_SpecOverHold_UpperSpec );                // "SHUS"
                            messageReason = CIMFWStrDup( SP_Reason_SpecOverHold_UpperSpec );
                        }
                        else if ( 0 == CIMFWStrCmp(strDCDef.strDCItem[m].specCheckResult, SP_SpecCheckResult_LowerSpecLimit) )
                        {
                            PPT_METHODTRACE_V1("", "strDCDef.specCheckResult == SP_SpecCheckResult_LowerSpecLimit");
                            reasonCode    = CIMFWStrDup( SP_Reason_SpecOverHold_LowerSpec );                // "SHLS"
                            messageReason = CIMFWStrDup( SP_Reason_SpecOverHold_LowerSpec );
                        }
                        else if ( 0 == CIMFWStrCmp(strDCDef.strDCItem[m].specCheckResult, SP_SpecCheckResult_UpperScreenLimit) )
                        {
                            PPT_METHODTRACE_V1("", "strDCDef.specCheckResult == SP_SpecCheckResult_UpperScreenLimit");
                            reasonCode    = CIMFWStrDup( SP_Reason_SpecOverHold_UpperScreen );              // "SHUR"
                            messageReason = CIMFWStrDup( SP_Reason_SpecOverHold_UpperScreen );
                        }
                        else if ( 0 == CIMFWStrCmp(strDCDef.strDCItem[m].specCheckResult, SP_SpecCheckResult_LowerScreenLimit) )
                        {
                            PPT_METHODTRACE_V1("", "strDCDef.specCheckResult == SP_SpecCheckResult_LowerScreenLimit");
                            reasonCode    = CIMFWStrDup( SP_Reason_SpecOverHold_LowerScreen );              // "SHLR"
                            messageReason = CIMFWStrDup( SP_Reason_SpecOverHold_LowerScreen );
                        }
//D6000049 add start
                        else if ( 0 == CIMFWStrCmp(strDCDef.strDCItem[m].specCheckResult, SP_SpecCheckResult_APCError) )
                        {
                            PPT_METHODTRACE_V1("", "strDCDef.specCheckResult == SP_SpecCheckResult_APCError");
//P6000053 change start
//P6000053                            reasonCode    = CIMFWStrDup( SP_Reason_EntityInhibit_For_APCError );            // "APCE"
//P6000053                            messageReason = CIMFWStrDup( SP_Reason_EntityInhibit_For_APCError );
                            reasonCode    = CIMFWStrDup( SP_Reason_APCErrorHold );                          // "APCE"
                            messageReason = CIMFWStrDup( SP_Reason_APCErrorHold );
//P6000053 change end
                        }
//D6000049 add end
                        else
                        {
                            PPT_METHODTRACE_V1("", "else");
                            reasonCode    = CIMFWStrDup( SP_Reason_SpecOverHold );                          // "SOHL"
                            messageReason = CIMFWStrDup( SP_Reason_SpecOverHold );
                        }
//P3000162          }

                        //------------------------------------------------------------------------------------------------
                        //  Make strEntityInhibitions of out parameter with SP_Reason_SpecOverInhibit reasonCode.
                        //
                        //    check actionCode of all strDCDef.dataCollectoinItemName.
                        //    ( actionCode are filled only when specCheckResult is out of spec. )
                        //       If actionCode is SP_ActionCode_Equipment,
                        //       If actionCode is SP_ActionCode_Recipe,
                        //       If actionCode is SP_ActionCode_Route,
                        //       If actionCode is SP_ActionCode_ProcessHold,
                        //
                        //       if actionCode has "ProcessHold", set the process hold record.
                        //       If the processed lot is monitored lot, set the monitored operation to output parameter.
                        //       If the processed lot is not monitored lot and it has a corresponding process operation,
                        //          set it to output parameter.
                        //       If the processed lot is not monitored lot and it doesn't have a corresponding process operation,
                        //          set the current operation to output parameter.
                        //
                        //------------------------------------------------------------------------------------------------
//DSIV00001021 delete start
//DSIV00001021                        //-------------------------
//DSIV00001021                        //   P4100070 add start
//DSIV00001021                        //-------------------------
//DSIV00001021                        if ( inhibitActionRequired == FALSE )
//DSIV00001021                        {
//DSIV00001021                            PPT_METHODTRACE_V5("","inhibitActionRequired is FALSE. change xxxx_hold_flag to :FALSE...",i,j,k,m);
//DSIV00001021                            equipment_hold_flag = FALSE;
//DSIV00001021                            recipe_hold_flag    = FALSE;
//DSIV00001021                            route_hold_flag     = FALSE;
//DSIV00001021                            process_hold_flag   = FALSE;
//DSIV00001021                        }
//DSIV00001021 delete end
                        //-------------------------
                        //   P4100070 add end
                        //-------------------------

                        if ( equipment_hold_flag == FALSE &&
                             recipe_hold_flag    == FALSE &&
                             route_hold_flag     == FALSE &&
                             process_hold_flag   == FALSE &&
                             mail_flag           == FALSE )
                        {
                            PPT_METHODTRACE_V1("", "Flag all FALSE");
                            continue;
                        }

                        CORBA::Long lenEffectedLots = effectedLots.length();
                        CORBA::Long interFabMonIdx;                 //PSIV00001648
                        CORBA::Long lot_countForMailOtherFab;       //PSIV00001648

//DSIV00000214 add start
//DSIV00001021                        if ( requestOtherFabFlag == TRUE )
                        if ( requestOtherFabFlagForMonitor == TRUE )     //DSIV00001021
                        {
                            findMonitoringLotFlag = FALSE;
                            if ( lenEffectedLots > 1 )
                            {
                                PPT_METHODTRACE_V2("", "this lot has monitoredLots.", effectedLots[0].lotID.identifier);
                                if ( rel_mong_count > 0 )
                                {
                                    // if monitoringLot already checked, no add
                                    for ( p = 0; p < rel_mong_count; p++ )
                                    {
                                        if ( CIMFWStrCmp( effectedLots[0].lotID.identifier,
                                                          strInterFabMonitorGroupActionInfoSequence[p].monitoringLotID.identifier ) == 0 )
                                        {
                                            PPT_METHODTRACE_V1("", "this monitoringLot already checked.");
                                            interFabMonIdx = p;                                                                                             //PSIV00001648
                                            lot_countForMailOtherFab = strInterFabMonitorGroupActionInfoSequence[p].strMonitoredLotMailInfoSeq.length();    //PSIV00001648
                                            findMonitoringLotFlag = TRUE;
                                            break;
                                        }
                                    }
                                 }

                                if ( findMonitoringLotFlag == FALSE )
                                {
                                    PPT_METHODTRACE_V1("", "this lot(monitoring) has not been chcked");
                                    //-------------------------------------------//
                                    // create data for mailSend of monitoredLots //
                                    //-------------------------------------------//
                                    strInterFabMonitorGroupActionInfoSequence.length( rel_mong_count + 1 );
//DSIV00001021                                    strInterFabMonitorGroupActionInfoSequence[rel_mong_count].fabID           = CIMFWStrDup(corrFabID);
                                    strInterFabMonitorGroupActionInfoSequence[rel_mong_count].fabID           = CIMFWStrDup(generatedFabID);    //DSIV00001021
                                    strInterFabMonitorGroupActionInfoSequence[rel_mong_count].monitoringLotID = effectedLots[0].lotID;
                                    //initialize
                                    strInterFabMonitorGroupActionInfoSequence[rel_mong_count].strMonitorGroupReleaseInfo.groupReleaseFlag = FALSE;
                                    interFabMonIdx = rel_mong_count;        //PSIV00001648
                                    lot_countForMailOtherFab = 0;           //PSIV00001648
                                    rel_mong_count++;
                                }
                            }
                        }
//DSIV00000214 add end
//DSIV00001021 add start
                        if ( findMeasurementLotFlag == FALSE )
                        {
                            //------------------------------------------//
                            // Get index of dcActionLot                 //
                            //------------------------------------------//
                            for ( CORBA::Long q = 0; q < dcActionLot_count; q++ )
                            {
                                if ( CIMFWStrCmp( effectedLots[0].lotID.identifier, strDCActionLotResult[q].measurementLotID.identifier ) == 0 )
                                {
                                    PPT_METHODTRACE_V1("", "this measurementLot already checked for Action Result.");
                                    dcActionLot_idx = q;
                                    dcActionInfo_count = strDCActionLotResult[q].strDCActionResultInfo.length();
                                    findMeasurementLotFlag = TRUE;
                                    break;
                                }
                            }

                            if ( findMeasurementLotFlag == FALSE )
                            {
                                PPT_METHODTRACE_V1("", "this lot(measurement) has not been checked for Action Result.");
                                //------------------------------------------//
                                // create data for DCActionLotResults       //
                                //------------------------------------------//
                                strDCActionLotResult.length( dcActionLot_count + 1 );
                                strDCActionLotResult[dcActionLot_count].measurementLotID = effectedLots[0].lotID;
                                dcActionLot_idx = dcActionLot_count;
                                dcActionLot_count++;
                                findMeasurementLotFlag = TRUE;
                            }
                            PPT_METHODTRACE_V3("", "strDCActionLotResult[dcActionLot_idx].measurementLotID", dcActionLot_idx, strDCActionLotResult[dcActionLot_idx].measurementLotID.identifier);
                            PPT_METHODTRACE_V3("", "strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length start", dcActionLot_idx , dcActionInfo_count);

                            //------------------------------------------//
                            // Get Corresponding Operation Info         //
                            //------------------------------------------//
//PSN000103458 add start
                            stringSequence dummyFPC_IDs;
                            dummyFPC_IDs.length(0);
                            objectIdentifier dummyID;
                            CORBA::String_var dummy;
                            rc = FPC_info_GetDR__101( strFPC_info_GetDR_out, strObjCommonIn,
                                                      dummyFPC_IDs,
                                                      strStartCassette[i].strLotInCassette[j].lotID,           //lotID
                                                      dummyID,           //lotFamilyID
                                                      mainPDID,          //mainPDID
                                                      operationNoforFPC,             //mainOperNo
                                                      dummyID,           //orgMainPDID
                                                      dummy,             //orgOperNo
                                                      dummyID,           //subMainPDID
                                                      dummy,             //subOperNo
                                                      equipmentID,       //equipmentID
                                                      TRUE,             //waferIDInfoGetFlag
                                                      FALSE,             //recipeParmInfoGetFlag
                                                      FALSE,             //reticleInfoGetFlag
                                                      TRUE );            //dcSpecItemInfoGetFlag
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "FPC_info_GetDR() != RC_OK", rc);
                                strStartLot_actionList_EffectSpecCheck_out.strResult = strFPC_info_GetDR_out.strResult;
                               return rc;
                            }
                            fpcCnt = strFPC_info_GetDR_out.strFPCInfoList.length();                            
                            PPT_METHODTRACE_V2("", "fpcCnt ", fpcCnt);
                            if ( fpcCnt > 0 )
                            {
                                waferCntFromStartCassette = strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                                CORBA::Boolean foundFPCFlag = FALSE;
                                for( numFPC=0; numFPC < fpcCnt; numFPC++)
                                {
                                    waferCntFromFPC = strFPC_info_GetDR_out.strFPCInfoList[numFPC].strLotWaferInfoList.length();
                                    for ( CORBA::Long inFPCWCnt = 0; inFPCWCnt < waferCntFromFPC; inFPCWCnt++)
                                    {
                                        PPT_METHODTRACE_V2("", "wafer key for FPC ", strFPC_info_GetDR_out.strFPCInfoList[numFPC].strLotWaferInfoList[inFPCWCnt].waferID.identifier);
                                        for(CORBA::Long inParaWCnt =0; inParaWCnt < waferCntFromStartCassette; inParaWCnt++)
                                        {
                                            PPT_METHODTRACE_V2("", "wafer key for startCassette", strStartCassette[i].strLotInCassette[j].strLotWafer[inParaWCnt].waferID.identifier);
                                            if(0 == CIMFWStrCmp(strFPC_info_GetDR_out.strFPCInfoList[numFPC].strLotWaferInfoList[inFPCWCnt].waferID.identifier, strStartCassette[i].strLotInCassette[j].strLotWafer[inParaWCnt].waferID.identifier) && strStartCassette[i].strLotInCassette[j].operationStartFlag == TRUE)
                                            {                            
                                                coFPCLen = strFPC_info_GetDR_out.strFPCInfoList[numFPC].strCorrespondingOperationInfoList.length();
                                                singleCorrOpeFPC = CIMFWStrDup(strFPC_info_GetDR_out.strFPCInfoList[numFPC].correspondingOperNo);
                                                PPT_METHODTRACE_V2("", "correspondingOperationInfo->length() from FPC", coFPCLen);
                                                PPT_METHODTRACE_V2("", "signleCorrespondingOperation", singleCorrOpeFPC);
                                                dcItemLen = strFPC_info_GetDR_out.strFPCInfoList[numFPC].strDCSpecList.length();
                                                foundFPCCnt = numFPC;
                                                foundFPCFlag = TRUE;
                                                break;
                                            }
                                        }
                                        if ( foundFPCFlag )
                                        {
                                            break;
                                        }
                                    }
                                    if ( foundFPCFlag )
                                    {
                                        break;
                                    }
                                }                        
                            }
                            dcItemNames.length(dcItemLen);
                            if ( fpcCnt == 0 || (fpcCnt > 0 && (CIMFWStrLen(singleCorrOpeFPC) == 0 && coFPCLen== 0 )))
                            {
//PSN000103458 add end
                                PosCorrespondingOperationInfoSequence_var correspondingOperationInfo;
                                try
                                {
                                    correspondingOperationInfo = aPO->getCorrespondingProcessOperationInfo();
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getCorrespondingProcessOperationInfo);

                                coLen = correspondingOperationInfo->length();
                                PPT_METHODTRACE_V2("", "correspondingOperationInfo->length()", coLen);
                                if ( coLen == 0 )
                                {
                                    //----------------------------------------------------
                                    //   Corresponding operation is NOT specified in SM
                                    //   In this case, current PO can be used for the
                                    //   inhibit action.
                                    //----------------------------------------------------
                                    PPT_METHODTRACE_V3("","Corresponding OperationInfo is not Defined in SM...",i,j);
                                }
                                else
                                {
                                    tmpCorrOperations.length( coLen );
                                    for ( CORBA::Long q=0; q < coLen; q++ )
                                    {
                                        tmpCorrOperations[q].dcSpecGroup                   = (*correspondingOperationInfo)[q].dcSpecGroup;
                                        tmpCorrOperations[q].correspondingOperationNumber  = (*correspondingOperationInfo)[q].correspondingOperationNumber;
                                    }
                                    findCorrespondingInfoFlag = TRUE;
                                }
//PSN000103458 add start
                            }
                            else
                            {
                                if(coFPCLen > 0)
                                {
                                    tmpCorrOperations.length( coFPCLen );
                                    for ( CORBA::Long qFPC=0; qFPC < coFPCLen; qFPC++ )
                                    {
                                        tmpCorrOperations[qFPC].dcSpecGroup                  = CIMFWStrDup(strFPC_info_GetDR_out.strFPCInfoList[foundFPCCnt].strCorrespondingOperationInfoList[qFPC].dcSpecGroup);
                                        tmpCorrOperations[qFPC].correspondingOperationNumber = CIMFWStrDup(strFPC_info_GetDR_out.strFPCInfoList[foundFPCCnt].strCorrespondingOperationInfoList[qFPC].correspondingOpeNo);
                                    }
                                    findCorrespondingInfoFlag = TRUE;
                                }
                                //Single Corresponding Operation in FPC
                                else if ( CIMFWStrLen(singleCorrOpeFPC) > 0 )
                                {
                                    PPT_METHODTRACE_V1("", "Single Corresponding Operation in FPC");
                                    coFPCLen = 1;
                                    tmpCorrOperations.length( coFPCLen );
                                    tmpCorrOperations[0].correspondingOperationNumber = CIMFWStrDup(singleCorrOpeFPC);
                                    findCorrespondingInfoFlag = TRUE;
                                }
                                else
                                {
                                    //----------------------------------------------------
                                    //   Corresponding operation is NOT specified in FPC
                                    //   In this case, current PO can be used for the
                                    //   inhibit action.
                                    //----------------------------------------------------
                                    PPT_METHODTRACE_V3("","Corresponding OperationInfo is not Defined in FPC...",i,j);                                
                                }
                            }
//PSN000103458 add end
                        }

                        CORBA::Long corrOpeLen = 0;
                        stringSequence correspondingOperaionNumbers;
                        if (findCorrespondingInfoFlag == TRUE)
                        {
                            //------------------------------------------//
                            // Get dcSpecGroup from PO                  //
                            //------------------------------------------//
//PSIV00003162                            if ( ( CIMFWStrCmp(correspondingOpeMode,"1") == 0 ) && ( CIMFWStrCmp(strDCDef.dataCollectionType, SP_DCDef_Collection_Measurement) == 0) )
//PSIV00003162 add start
                            //SP_MULTI_CORRESOPE_MODE is 1, and dcType is Measurement or Delta DC Def(blank)
                            if ( ( CIMFWStrCmp(correspondingOpeMode,"1") == 0 ) &&
                              ( ( CIMFWStrCmp(strDCDef.dataCollectionType, SP_DCDef_Collection_Measurement) == 0) ||
                                ( 0 == CIMFWStrLen(strDCDef.dataCollectionType) ) ) )
//PSIV00003162 add end
                            {
                                CORBA::String_var dcSpecGroup;
//PSN000103458 add start
                                if ( 0 != coFPCLen )
                                {
                                    if ( 0 != strFPC_info_GetDR_out.strFPCInfoList[foundFPCCnt].strDCSpecList.length())
                                    {           
                                        for ( CORBA::Long dcItemCnt=0; dcItemCnt < dcItemLen; dcItemCnt++ )
                                        {
                                            if ( 0 == CIMFWStrCmp( strFPC_info_GetDR_out.strFPCInfoList[foundFPCCnt].strDCSpecList[dcItemCnt].dataItemName, strDCDef.strDCItem[m].dataCollectionItemName ) ) 
                                            {
                                                dcSpecGroup = CIMFWStrDup(strFPC_info_GetDR_out.strFPCInfoList[foundFPCCnt].strDCSpecList[dcItemCnt].dcSpecGroup);
                                            }
                                        }
                                    }
                                    else
                                    {
                                         try
                                         {
                                             dcSpecGroup = aPO->findDCSpecGroup(strDCDef.dataCollectionSpecificationID.identifier, strDCDef.strDCItem[m].dataCollectionItemName);
                                         }
                                         CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::findDCSpecGroup);   
                                    }
                                    correspondingOperaionNumbers.length(coFPCLen);
                                    PPT_METHODTRACE_V2("", "coFPCLen -------------->", coFPCLen);
                                    for ( CORBA::Long coFPCCnt = 0; coFPCCnt < coFPCLen; coFPCCnt++ )
                                    {   
                                        PPT_METHODTRACE_V2("", "coFPCCnt -------------->", coFPCCnt);
                                        if ( CIMFWStrCmp(tmpCorrOperations[coFPCCnt].dcSpecGroup, dcSpecGroup) == 0 )
                                        {
                                            correspondingOperaionNumbers[corrOpeLen] = CIMFWStrDup(tmpCorrOperations[coFPCCnt].correspondingOperationNumber);
                                            corrOpeLen++;
                                        }
                                    }
                                }
                                else
                                {
                                    if ( fpcCnt > 0 && 0 != strFPC_info_GetDR_out.strFPCInfoList[foundFPCCnt].strDCSpecList.length())
                                    {
                                        for ( CORBA::Long dcItemCnt=0; dcItemCnt < dcItemLen; dcItemCnt++ )
                                        {
                                            if ( 0 == CIMFWStrCmp( strFPC_info_GetDR_out.strFPCInfoList[foundFPCCnt].strDCSpecList[dcItemCnt].dataItemName, strDCDef.strDCItem[m].dataCollectionItemName ) ) 
                                            {
                                                dcSpecGroup = CIMFWStrDup(strFPC_info_GetDR_out.strFPCInfoList[foundFPCCnt].strDCSpecList[dcItemCnt].dcSpecGroup);
                                            }
                                        }
                                    }
                                    else
                                    {
//PSN000103458 add end
                                            try
                                            {
                                                dcSpecGroup = aPO->findDCSpecGroup(strDCDef.dataCollectionSpecificationID.identifier, strDCDef.strDCItem[m].dataCollectionItemName);
                                            }
                                            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::findDCSpecGroup);
                                    }//PSN000103458
                                    PPT_METHODTRACE_V2("", "dcSpecGroup", dcSpecGroup);
                                    //------------------------------------------//
                                    // Get CorrespondingOperationNumber         //
                                    //------------------------------------------//
                                    correspondingOperaionNumbers.length(coLen);
                                    PPT_METHODTRACE_V2("", "coLen -------------->", coLen);
                                    for ( CORBA::Long coCnt = 0; coCnt < coLen; coCnt++ )
                                    {
                                        PPT_METHODTRACE_V2("", "coCnt -------------->", coCnt);
                                        if ( CIMFWStrCmp(tmpCorrOperations[coCnt].dcSpecGroup, dcSpecGroup) == 0 )
                                        {
                                            correspondingOperaionNumbers[corrOpeLen] = CIMFWStrDup(tmpCorrOperations[coCnt].correspondingOperationNumber);
                                            corrOpeLen++;
                                        }
                                    }
                                } //PSN000103458

                                //----------------------------------------------------
                                //   Corresponding operation is NOT specified
                                //----------------------------------------------------
                                if ( corrOpeLen == 0 )
                                {
                                    PPT_METHODTRACE_V2("", "Corresponding operation is NOT specified.", dcSpecGroup);
                                    if ( CIMFWStrCmp(correspondingDefaltMode,"1") == 0 )
                                    {
//PSN000103458 add start
                                        if ( 0 != coFPCLen )
                                        {
                                            for ( CORBA::Long coFPCCnt = 0; coFPCCnt < coFPCLen; coFPCCnt++)
                                            {
                                                PPT_METHODTRACE_V2("", "coFPCCnt -------------->", coFPCCnt);
                                                if ( CIMFWStrCmp(tmpCorrOperations[coFPCCnt].dcSpecGroup, "") == 0 )
                                                {
                                                    correspondingOperaionNumbers[corrOpeLen] = CIMFWStrDup(tmpCorrOperations[coFPCCnt].correspondingOperationNumber);
                                                    corrOpeLen++;
                                                }
                                            }
                                        }
                                        else 
                                        {
//PSN000103458 add end
                                            for ( CORBA::Long coCnt = 0; coCnt < coLen; coCnt++)
                                            {
                                                PPT_METHODTRACE_V2("", "coCnt -------------->", coCnt);
                                                if ( CIMFWStrCmp(tmpCorrOperations[coCnt].dcSpecGroup, "") == 0 )
                                                {
                                                    correspondingOperaionNumbers[corrOpeLen] = CIMFWStrDup(tmpCorrOperations[coCnt].correspondingOperationNumber);
                                                    corrOpeLen++;
                                                }
                                            }
                                        }//PSN000103458
                                    }
                                }
                                PPT_METHODTRACE_V2("", "corrOpeLen -------------->", corrOpeLen);
                                correspondingOperaionNumbers.length(corrOpeLen);
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("", "Multiple Corresponding Operations are NOT supported.");
                                corrOpeLen = 1;
                                correspondingOperaionNumbers.length(1);
                                correspondingOperaionNumbers[0] = CIMFWStrDup(tmpCorrOperations[0].correspondingOperationNumber);
                            }
                        }
//DSIV00001021 add end

                        PPT_METHODTRACE_V2("", "lenEffectedLots -------------->", lenEffectedLots);
                        for ( o = 0; o < lenEffectedLots; o++ )
                        {
                            PPT_METHODTRACE_V2("", "counter o -------------->", o );
//DSIV00001021 add start
                            CORBA::Boolean monitorLotFlag = FALSE;
                            CORBA::Long poLen = 0;
                            if ( corrOpeLen > 0 )
                            {
                                poLen = corrOpeLen;
                            }
                            else
                            {
                                poLen = 1;
                            }

                            if ( o == 0 )
                            {
                                monitorLotFlag = FALSE;
                            }
                            else
                            {
                                monitorLotFlag = TRUE;
                            }
                            PPT_METHODTRACE_V2("", "monitorLotFlag", monitorLotFlag);

//PSN000103685 delete                            entity_count_keep = entity_count;                          //DSIV00001365
//PSN000103685 delete                            entity_countForOtherFab_keep = entity_countForOtherFab;    //DSIV00001365

                            PPT_METHODTRACE_V2("", "poLen -------------->", poLen);
                            for ( CORBA::Long poCnt = 0; poCnt < poLen; poCnt++ )
                            {
//PSN000103685 add start
                                entity_count_keep = entity_count;
                                entity_countForOtherFab_keep = entity_countForOtherFab;
//PSN000103685 add end
                                PosProcessOperation_var aPOtmp;
                                pptProcessOperationInfo strProcessOperationInfo;
                                CORBA::String_var corrFabID;
                                CORBA::Boolean requestOtherFabFlag = FALSE;
                                PPT_METHODTRACE_V2("", "poCnt -------------->", poCnt);

                                if ( monitorLotFlag == TRUE )
                                {
                                    PPT_METHODTRACE_V1("", "monitorLotFlag == TRUE");
                                    //------------------------------------------//
                                    // Get requestOtherFabFlag                  //
                                    //------------------------------------------//
                                    corrFabID = generatedFabID;
                                    if ( CIMFWStrLen(currentFabID) != 0 && CIMFWStrLen(corrFabID) != 0 &&
                                        CIMFWStrCmp(currentFabID, corrFabID) != 0 )
                                    {
                                        PPT_METHODTRACE_V1("", "currentFabID and corrFabID is not same");
                                        requestOtherFabFlag = TRUE;
                                    }
                                    else
                                    {
                                        if ( poCnt > 0 )
                                        {
                                            PPT_METHODTRACE_V1("", "process operation of monitoredLot is single.");
                                            break;
                                        }
                                        PPT_CONVERT_STRING_TO_OBJECT( effectedLots[o].processOperation ,aPOtmp, PosProcessOperation );
                                        if ( CORBA::is_nil( aPOtmp ) )
                                        {
                                            PPT_SET_MSG_RC_KEY2( strStartLot_actionList_EffectSpecCheck_out, MSG_NOT_FOUND_PO,    //P5000145
                                                                 RC_NOT_FOUND_PO, effectedLots[o].processOperation,               //P5000145
                                                                 effectedLots[o].lotID.identifier );                              //P5000145

                                            return RC_NOT_FOUND_PO;
                                        }
                                    }
                                }

                                if ( monitorLotFlag == FALSE || ( monitorLotFlag == TRUE && requestOtherFabFlag == TRUE ) )
                                {
                                    PPT_METHODTRACE_V1("", "Corresponding Operation Get");
                                    if ( corrOpeLen > 0 )
                                    {
                                        PPT_METHODTRACE_V5("","Corresponding Operation is Defined in SM",i,j,k,poCnt);
                                        PPT_METHODTRACE_V2("","correspondingOperaionNumbers[poCnt]", correspondingOperaionNumbers[poCnt]);

                                        effectedLots[0].processOperation = CIMFWStrDup("");
                                        for ( CORBA::Long q = 0; q < checkOpeCnt; q++ )
                                        {
                                            if ( 0 == CIMFWStrCmp( opeNoList[q].operationNumber, correspondingOperaionNumbers[poCnt] ) )
                                            {
                                                effectedLots[0].processOperation = CIMFWStrDup(opeNoList[q].objrefPO);
                                                break;
                                            }
                                        }

                                        if ( CIMFWStrLen(effectedLots[0].processOperation) == 0 )
                                        {
                                            //------------------------------------------//
                                            // Get CorrespondingProcessOperation        //
                                            //------------------------------------------//
                                            PosProcessOperation_var aCorrPO;
                                            try
                                            {
//PSN000016926                                  aCorrPO = aPFX->findProcessOperationForOperationNumberBefore(correspondingOperaionNumbers[poCnt]);
                                                aCorrPO = aPFX->findProcessOperationForRouteOperationNumberBefore(mainPDID.identifier, correspondingOperaionNumbers[poCnt]); //PSN000016926
                                            }
                                            CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlowContext::findProcessOperationForOperationNumberBefore);

                                            if ( CORBA::is_nil(aCorrPO) != TRUE )
                                            {
                                                //------------------------------------------------
                                                //   Corresponding operation is Specified and
                                                //   that operation was processed.
                                                //------------------------------------------------
                                                PPT_METHODTRACE_V5("","PFX's CorrespondingPO is existing...",i,j,k,poCnt);
                                                effectedLots[0].processOperation = SP_OBJECT_TO_STRING( aCorrPO );
                                                aPOtmp = aCorrPO;

                                                opeNoList.length(checkOpeCnt + 1);
                                                opeNoList[checkOpeCnt].operationNumber  = CIMFWStrDup(correspondingOperaionNumbers[poCnt]);
                                                opeNoList[checkOpeCnt].objrefPO         = CIMFWStrDup(effectedLots[0].processOperation);
                                                checkOpeCnt++;

//DSN000015229 Add Start
                                                if ( 0 < CIMFWStrLen(strDCDef.strDCItem[m].waferID.identifier) ) //PSN000083035
                                                {                                                                //PSN000083035
//PSN000083035 Indent Start
                                                    PosProcessWaferSequence_var strProcessWaferSeq;
                                                    try
                                                    {
                                                        strProcessWaferSeq = aCorrPO->getProcessWafers();
                                                    }
                                                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getProcessWafers);

                                                    CORBA::ULong nWaferLen = strProcessWaferSeq->length();
                                                    if ( nWaferLen > 0 ) //PSN000083035
                                                    {                    //PSN000083035
                                                        CORBA::Boolean bWaferFoundFlag = FALSE;
                                                        PPT_METHODTRACE_V2("","nWaferLen",nWaferLen);
                                                        PPT_METHODTRACE_V1("","bWaferFoundFlag = FALSE");
                                                        for ( CORBA::ULong w_i = 0; w_i < nWaferLen; w_i++ )
                                                        {
                                                            PPT_METHODTRACE_V2("","w_i",w_i);
                                                            if ( 0 == CIMFWStrCmp( strProcessWaferSeq[w_i].waferID, strDCDef.strDCItem[m].waferID.identifier) )
                                                            {
                                                                PPT_METHODTRACE_V1("","bWaferFoundFlag = TRUE");
                                                                PPT_METHODTRACE_V2("","waferID",strProcessWaferSeq[w_i].waferID);
                                                                bWaferFoundFlag = TRUE;
                                                            }
                                                        }
                                                        if ( FALSE == bWaferFoundFlag )
                                                        {
//PSN000016926 move this section up
//PSN000016926                                                        PosProcessDefinition_var aMainPD;
//PSN000016926                                                        try
//PSN000016926                                                        {
//PSN000016926                                                            aMainPD = aPO->getMainProcessDefinition();
//PSN000016926                                                        }
//PSN000016926                                                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getMainProcessDefinition)
//PSN000016926
//PSN000016926                                                        if(CORBA::is_nil(aMainPD))
//PSN000016926                                                        {
//PSN000016926                                                            PPT_METHODTRACE_V1("","CORBA::is_nil(aMainPD)");
//PSN000016926                                                            PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSpecCheck_out,
//PSN000016926                                                                                MSG_NOT_FOUND_PD,
//PSN000016926                                                                                RC_NOT_FOUND_PD, "" );
//PSN000016926                                                            return RC_NOT_FOUND_PD;
//PSN000016926                                                        }
//PSN000016926                                                        objectIdentifier mainPDID;
//PSN000016926                                                        PPT_SET_OBJECT_IDENTIFIER(  mainPDID,
//PSN000016926                                                                                    aMainPD,
//PSN000016926                                                                                    strStartLot_actionList_EffectSpecCheck_out,
//PSN000016926                                                                                    startLot_actionList_EffectSpecCheck__101,
//PSN000016926                                                                                    PosProcessDefinition );
                                                            PPT_METHODTRACE_V2("","mainPDID", mainPDID.identifier);

                                                            try
                                                            {
                                                                aPOtmp = aPO->findProcessOperationForOperationNumberAndWafer( mainPDID.identifier,
                                                                                                                              correspondingOperaionNumbers[poCnt],
                                                                                                                              strDCDef.strDCItem[m].waferID.identifier);
                                                            }
                                                            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::findProcessOperationForOperationNumberAndWafer)

                                                            if ( CORBA::is_nil(aPOtmp) )
                                                            {
                                                                PPT_METHODTRACE_V1("","CORBA::is_nil(aPOtmp)");
                                                                continue;
                                                            }
                                                        }
                                                    } //PSN000083035
//PSN000083035 Indent End
                                                } //PSN000083035
//DSN000015229 Add End

                                                PPT_METHODTRACE_V2("","Corresponding Operaion ObjrefPO set.",effectedLots[0].processOperation);
                                            }
                                            else
                                            {
                                                PPT_METHODTRACE_V5("","PFX's CorrespondingPO is nill...",i,j,k,poCnt);
//DSN000015229 Add Start
//PSN000016926                                                PosProcessDefinition_var aMainPD;
//PSN000016926                                                try
//PSN000016926                                                {
//PSN000016926                                                    aMainPD = aPO->getMainProcessDefinition();
//PSN000016926                                                }
//PSN000016926                                                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getMainProcessDefinition)
//PSN000016926                                                if(CORBA::is_nil(aMainPD))
//PSN000016926                                                {
//PSN000016926                                                    PPT_METHODTRACE_V1("","CORBA::is_nil(aMainPD)");
//PSN000016926                                                    PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSpecCheck_out,
//PSN000016926                                                                        MSG_NOT_FOUND_PD,
//PSN000016926                                                                        RC_NOT_FOUND_PD, "" );
//PSN000016926                                                    return RC_NOT_FOUND_PD;
//PSN000016926                                                }
//PSN000016926                                                objectIdentifier mainPDID;
//PSN000016926                                                PPT_SET_OBJECT_IDENTIFIER( mainPDID,
//PSN000016926                                                                           aMainPD,
//PSN000016926                                                                           strStartLot_actionList_EffectSpecCheck_out,
//PSN000016926                                                                           startLot_actionList_EffectSpecCheck__120,
//PSN000016926                                                                           PosProcessDefinition );
                                                PPT_METHODTRACE_V2("","mainPDID", mainPDID.identifier);

                                                try
                                                {
                                                    aPOtmp = aPO->findProcessOperationForOperationNumberAndWafer( mainPDID.identifier,
                                                                                                                  correspondingOperaionNumbers[poCnt],
                                                                                                                  strDCDef.strDCItem[m].waferID.identifier);
                                                }
                                                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::findProcessOperationForOperationNumberAndWafer)

                                                if ( CORBA::is_nil(aPOtmp) )
                                                {
                                                    //----------------------------------------------------
                                                    //   Corresponding operation is specified in SM,
                                                    //   however its operation's PO is not existing.
                                                    //   That means the corresponding operation is NOT
                                                    //   processed (using Locate Func.).
                                                    //   In this case, current PO can NOT be used for
                                                    //   the inhibit action.
                                                    //----------------------------------------------------
                                                    PPT_METHODTRACE_V5("","Corresponding Operation is Defined in SM, but it is not proceeded.",i,j,k,poCnt);
                                                    continue;
                                                }
//DSN000015229 Add End
//DSN000015229                                                //----------------------------------------------------
//DSN000015229                                                //   Corresponding operation is specified in SM,
//DSN000015229                                                //   however its operation's PO is not existing.
//DSN000015229                                                //   That means the corresponding operation is NOT
//DSN000015229                                                //   processed (using Locate Func.).
//DSN000015229                                                //   In this case, current PO can NOT be used for
//DSN000015229                                                //   the inhibit action.
//DSN000015229                                                //----------------------------------------------------
//DSN000015229                                                PPT_METHODTRACE_V5("","Corresponding Operation is Defined in SM, but it is not proceeded.",i,j,k,poCnt);
//DSN000015229                                                continue;
                                            }
                                        }
                                        else
                                        {
                                            PPT_METHODTRACE_V2("","Corresponding Operaion ObjrefPO has already set.",effectedLots[0].processOperation);
                                            PPT_CONVERT_STRING_TO_OBJECT( effectedLots[0].processOperation ,aPOtmp, PosProcessOperation );
                                            if ( CORBA::is_nil( aPOtmp ) )
                                            {
                                                PPT_SET_MSG_RC_KEY2( strStartLot_actionList_EffectSpecCheck_out, MSG_NOT_FOUND_PO,    //P5000145
                                                                     RC_NOT_FOUND_PO, effectedLots[0].processOperation,               //P5000145
                                                                     effectedLots[0].lotID.identifier );                              //P5000145
                                                return RC_NOT_FOUND_PO;
                                            }
//DSN000015229 Add Start
                                            if ( 0 < CIMFWStrLen(strDCDef.strDCItem[m].waferID.identifier) ) //PSN000083035
                                            {
//PSN000083035 Indent Start
                                                PosProcessWaferSequence_var strProcessWaferSeq;
                                                try
                                                {
                                                    strProcessWaferSeq = aPOtmp->getProcessWafers();
                                                }
                                                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getProcessWafers)

                                                CORBA::ULong nWaferLen = strProcessWaferSeq->length();
                                                CORBA::Boolean bWaferFoundFlag = FALSE;
                                                PPT_METHODTRACE_V2("","nWaferLen",nWaferLen);
                                                PPT_METHODTRACE_V1("","bWaferFoundFlag = FALSE");
                                                if ( nWaferLen > 0 ) //PSN000083035
                                                {                    //PSN000083035
                                                    for ( CORBA::ULong w_i = 0; w_i < nWaferLen; w_i++ )
                                                    {
                                                        PPT_METHODTRACE_V2("","w_i",w_i);
                                                        if ( 0 == CIMFWStrCmp( strProcessWaferSeq[w_i].waferID, strDCDef.strDCItem[m].waferID.identifier ))
                                                        {
                                                            PPT_METHODTRACE_V1("","bWaferFoundFlag = TRUE");
                                                            PPT_METHODTRACE_V2("","waferID",strProcessWaferSeq[w_i].waferID);
                                                            bWaferFoundFlag = TRUE;
                                                        }
                                                    }
                                                    PPT_METHODTRACE_V2("","bWaferFoundFlag",bWaferFoundFlag);
                                                    if ( FALSE == bWaferFoundFlag )
                                                    {
                                                        PPT_METHODTRACE_V1("","FALSE == bWaferFoundFlag");
//PSN000016926                                                    PosProcessDefinition_var aMainPD;
//PSN000016926                                                    try
//PSN000016926                                                    {
//PSN000016926                                                        aMainPD = aPO->getMainProcessDefinition();
//PSN000016926                                                    }
//PSN000016926                                                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getMainProcessDefinition)
//PSN000016926                                                    if(CORBA::is_nil(aMainPD))
//PSN000016926                                                    {
//PSN000016926                                                        PPT_METHODTRACE_V1("","CORBA::is_nil(aMainPD)");
//PSN000016926                                                        PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSpecCheck_out,
//PSN000016926                                                                            MSG_NOT_FOUND_PD,
//PSN000016926                                                                            RC_NOT_FOUND_PD,
//PSN000016926                                                                            "" );
//PSN000016926                                                        return RC_NOT_FOUND_PD;
//PSN000016926                                                    }
//PSN000016926                                                    objectIdentifier mainPDID;
//PSN000016926                                                    PPT_SET_OBJECT_IDENTIFIER( mainPDID,
//PSN000016926                                                                               aMainPD,
//PSN000016926                                                                               strStartLot_actionList_EffectSpecCheck_out,
//PSN000016926                                                                               startLot_actionList_EffectSpecCheck__101,
//PSN000016926                                                                               PosProcessDefinition );
                                                        PPT_METHODTRACE_V2("","mainPDID", mainPDID.identifier);

                                                        try
                                                        {
                                                            aPOtmp = aPO->findProcessOperationForOperationNumberAndWafer( mainPDID.identifier,
                                                                                                                          correspondingOperaionNumbers[poCnt],
                                                                                                                          strDCDef.strDCItem[m].waferID.identifier);
                                                        }
                                                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::findProcessOperationForOperationNumberAndWafer)

                                                        if ( CORBA::is_nil(aPOtmp) )
                                                        {
                                                            PPT_METHODTRACE_V5("","Corresponding Operation is Defined in SM, but it is not proceeded.",i,j,k,poCnt);
                                                            continue;
                                                        }
                                                    }
                                                } //PSN000083035
//PSN000083035 Indent End
                                            } //PSN000083035
//DSN000015229 Add End
                                        }

                                        //------------------------------------------//
                                        // Get requestOtherFabFlag                  //
                                        //------------------------------------------//
                                        try
                                        {
                                            corrFabID = aPOtmp->getFabID();
                                        }
                                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getProcessOperationLocation);

                                        PPT_METHODTRACE_V2("", "corrFabID", corrFabID);
                                        if ( CIMFWStrLen(corrFabID) == 0 )
                                        {
                                            PPT_METHODTRACE_V1("", "corresponding FabID is null");
                                        }

                                        if ( CIMFWStrLen(currentFabID) != 0 && CIMFWStrLen(corrFabID) != 0 &&
                                            CIMFWStrCmp(currentFabID, corrFabID) != 0 )
                                        {
                                            PPT_METHODTRACE_V1("", "currentFabID and corrFabID is not same");
                                            requestOtherFabFlag = TRUE;
                                        }
                                    }
                                    else
                                    {
                                        //----------------------------------------------------
                                        //   Corresponding operation is not specified in SM,
                                        //   In this case, current PO can be used for
                                        //   the inhibit action.
                                        //----------------------------------------------------
                                        PPT_METHODTRACE_V5("","Corresponding Operation is not Defined in SM, current PO is used.",i,j,k,poCnt);
                                        effectedLots[0].processOperation = SP_OBJECT_TO_STRING( aPO );
                                        aPOtmp = aPO;
                                    }
                                }

                                if ( requestOtherFabFlag == TRUE )
                                {
                                    objProcessOperation_Info_GetDR_out strProcessOperation_Info_GetDR_out;
                                    PPT_METHODTRACE_V1("", "requestOtherFabFlag is TRUE. this lot has correspondingPO information(correspondingPO object is not null)");
                                    //-------------------------------------
                                    //   Get correspondingPO information
                                    //-------------------------------------
                                    objProcessOperation_Info_GetDR_in  strProcessOperation_Info_GetDR_in;
                                    strProcessOperation_Info_GetDR_in.poObj = effectedLots[0].processOperation;
                                    rc = processOperation_Info_GetDR( strProcessOperation_Info_GetDR_out, strObjCommonIn,
                                                                      strProcessOperation_Info_GetDR_in );
                                    if ( rc != RC_OK )
                                    {
                                        PPT_METHODTRACE_V2("", "processOperation_info_GetDR() != RC_OK", rc);
                                        strStartLot_actionList_EffectSpecCheck_out.strResult = strProcessOperation_Info_GetDR_out.strResult;
                                        return rc;
                                    }
                                    strProcessOperationInfo = strProcessOperation_Info_GetDR_out.strProcessOperationInfo;
                                }
//DSIV00001021 add end
//DSIV00001021 indent move start
                                if ( equipment_hold_flag == TRUE )
                                {
                                    PPT_METHODTRACE_V1("", "equipment_hold_flag == TRUE");
//DSIV00000214 add start
                                    if ( requestOtherFabFlag == FALSE )
                                    {
                                        PPT_METHODTRACE_V1("", "correspondingPO is currentFab");
//DSIV00000214 add end

//DSIV00001021                                        PosProcessOperation_var aPOtmp;
//DSIV00001021                                        PPT_CONVERT_STRING_TO_OBJECT( effectedLots[o].processOperation ,aPOtmp, PosProcessOperation );
//DSIV00001021//Q3000124 start
//DSIV00001021                                        if ( CORBA::is_nil( aPOtmp ) )
//DSIV00001021                                        {
//DSIV00001021//P5000145                                        SET_MSG_RC( strStartLot_actionList_EffectSpecCheck_out, MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO );
//DSIV00001021                                            PPT_SET_MSG_RC_KEY2( strStartLot_actionList_EffectSpecCheck_out, MSG_NOT_FOUND_PO,    //P5000145
//DSIV00001021                                                                 RC_NOT_FOUND_PO, effectedLots[o].processOperation,               //P5000145
//DSIV00001021                                                                 effectedLots[o].lotID.identifier );                              //P5000145
//DSIV00001021
//DSIV00001021                                            return RC_NOT_FOUND_PO;
//DSIV00001021                                        }
//Q3000124 end

                                        PosMachine_var aMachine;
                                        try
                                        {
                                            aMachine  = aPOtmp->getAssignedMachine();
                                        }
                                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getAssignedMachine)

                                        if ( ! CORBA::is_nil(aMachine) )
                                        {
                                            PPT_METHODTRACE_V1("", "aMachine is not nil");

                                            CORBA::String_var machineID;
                                            try
                                            {
                                                machineID = aMachine->getIdentifier();
                                            }
                                            CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getIdentifier)

                                            findFlag = FALSE;
                                            //-------------------------------------------------------------------
                                            //  Check equipment_hold_inhibition is already registed or not.
                                            //  If only not existed, entry new inhibition.
                                            //-------------------------------------------------------------------
                                            PPT_METHODTRACE_V1("", "Check equipment_hold_inhibition is already registed or not");

                                            PPT_METHODTRACE_V2("", "equipment_hold_flag entity_count -------------->", entity_count );
                                            for ( n = 0; n < entity_count; n++ )
                                            {
                                                PPT_METHODTRACE_V2("", "counter n -------------->", n );
//P3000162                                  if ( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[n].entities[0].className == SP_InhibitClassID_Equipment
//P3000162                                    && strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier == machineID)
                                                if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Equipment)   //P3000162
                                                  && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier , machineID) )        //P3000162
                                                {
                                                    findFlag = TRUE;
                                                    break;
                                                }
                                            }
//DSN000015229 Add Start
                                            if ( findFlag == FALSE )
                                            {
                                                PPT_METHODTRACE_V1("", "findFlag == FALSE");
                                                //-------------------------------------------------------------------
                                                //  Check FRENTINHBT for entitiy inhibit
                                                //-------------------------------------------------------------------
                                                CORBA::String_var strInhibitDcururationDays = CIMFWStrDup( getenv(SP_INHIBIT_DURATION) );
                                                objEntityInhibit_attributes_GetDR_out__101  strEntityInhibit_attributes_GetDR_out;
                                                objEntityInhibit_attributes_GetDR_in__101   strEntityInhibit_attributes_GetDR_in;
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.entities.length(1);
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.strEntityInhibitReasonDetailInfos.length(1);
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.endTimeStamp = strInhibitDcururationDays;
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.reasonCode   = CIMFWStrDup(SP_Reason_SpecOverInhibit);
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                                                PPT_SET_OBJECT_IDENTIFIER( strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.entities[0].objectID,
                                                                           aMachine,
                                                                           strStartLot_actionList_EffectSpecCheck_out,
                                                                           startLot_actionList_EffectSpecCheck__101,
                                                                           Machine );
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.strEntityInhibitReasonDetailInfos[0].relatedLotID = strStartCassette[i].strLotInCassette[j].lotID.identifier;
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.strEntityInhibitReasonDetailInfos[0].relatedControlJobID = controlJobID;
                                                strEntityInhibit_attributes_GetDR_in.entityInhibitReasonDetailInfoFlag = FALSE;

                                                PPT_METHODTRACE_V1("", "Call entityInhibit_attributes_GetDR__101");
                                                rc = entityInhibit_attributes_GetDR__101( strEntityInhibit_attributes_GetDR_out,
                                                                                          strObjCommonIn,
                                                                                          strEntityInhibit_attributes_GetDR_in );

                                                if ( rc != RC_OK )
                                                {
                                                    PPT_METHODTRACE_V2("", " entityInhibit_attributes_GetDR__101 : rc != RC_OK", rc);
                                                    strStartLot_actionList_EffectSpecCheck_out.strResult = strEntityInhibit_attributes_GetDR_out.strResult;
                                                }

                                                CORBA::ULong inhibitLen = strEntityInhibit_attributes_GetDR_out.entityInhibitInfo.length();
                                                PPT_METHODTRACE_V2("", "inhibitLen", inhibitLen);
                                                if ( inhibitLen > 0 )
                                                {
                                                    findFlag = TRUE;
                                                    registeredFlag = TRUE;
                                                }
                                            }
//DSN000015229 Add End
                                            if ( findFlag == FALSE )
                                            {
                                                PPT_METHODTRACE_V2("", "findFlag == FALSE  [machineID]", machineID);

                                                entity_count++;
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions.length(entity_count);

                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].entities.length(1);
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                                                PPT_SET_OBJECT_IDENTIFIER( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID,
                                                                           aMachine,
                                                                           strStartLot_actionList_EffectSpecCheck_out,
                                                                           startLot_actionList_EffectSpecCheck__101,
                                                                           Machine );
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib = CIMFWStrDup("");
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
//Q3000124                                  strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup("TIMESTAMP_NIL_OBJECT_STRING");
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING); //Q3000284
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].reasonCode = CIMFWStrDup( SP_Reason_SpecOverInhibit );
//P4100051                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].ownerID.identifier = CIMFWStrDup("PPTSvcMgr");
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].ownerID = strObjCommonIn.strUser.userID;    //P4100051
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                                            }
//DSIV00001021 add start
                                            findFlag = FALSE;
                                            if ( FALSE == registeredFlag )      //DSN000015229
                                            {                                   //DSN000015229
//DSN000015229 Indent Start
                                                PPT_METHODTRACE_V1("", "FALSE == registeredFlag");      //DSN000015229
                                                PPT_METHODTRACE_V2("", "equipment_hold_flag dcActionInfo_count -------------->", dcActionInfo_count );
                                                for ( n = 0; n < dcActionInfo_count; n++ )
                                                {
                                                    PPT_METHODTRACE_V2("", "counter n -------------->", n );
                                                    if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                                                    {
                                                        if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, machineID)
                                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SpecOverInhibit)
                                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, effectedLots[o].processOperation)
                                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[o].lotID.identifier) )
                                                        {
                                                            PPT_METHODTRACE_V1("", "Set findFlag = TRUE");      //DSN000015229
                                                            findFlag = TRUE;
                                                            break;
                                                        }
                                                    }
                                                }
//DSN000015229 Indent End
//DSN000015229 Add Start
                                            }
                                            else
                                            {
                                                PPT_METHODTRACE_V1("", "TRUE == registeredFlag");
                                                for ( n = 0; n < actionRsltLen; n++ )
                                                {
                                                    PPT_METHODTRACE_V2("", "counter n -------------->", n );
                                                    if ( actionResultInfoSeq[n].entities.length() == 1 )
                                                    {
                                                        if ( 0 == CIMFWStrCmp(actionResultInfoSeq[n].entities[0].className, SP_InhibitClassID_Equipment)
                                                          && 0 == CIMFWStrCmp(actionResultInfoSeq[n].entities[0].objectID.identifier, machineID)
                                                          && 0 == CIMFWStrCmp(actionResultInfoSeq[n].reasonCode, SP_Reason_SpecOverInhibit)
                                                          && 0 == CIMFWStrCmp(actionResultInfoSeq[n].correspondingObjrefPO, effectedLots[o].processOperation)
                                                          && 0 == CIMFWStrCmp(actionResultInfoSeq[n].lotID.identifier, effectedLots[o].lotID.identifier) )
                                                        {
                                                            PPT_METHODTRACE_V1("", "Set findFlag = TRUE");
                                                            findFlag = TRUE;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
//DSN000015229 Add End 
                                            if ( findFlag == FALSE )
                                            {
                                                PPT_METHODTRACE_V2("", "findFlag == FALSE  [machineID]", machineID);

                                                //-----------------------------------------------------------------------------
                                                // Add ActionResultInfo
                                                //-----------------------------------------------------------------------------
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[o].lotID;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = monitorLotFlag;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strDCDef.dataCollectionDefinitionID;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strDCDef.dataCollectionSpecificationID;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPEC );
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SpecOverInhibit );
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_EquipmentHold );
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = effectedLots[o].processOperation;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className  = CIMFWStrDup(SP_InhibitClassID_Equipment);
                                                PPT_SET_OBJECT_IDENTIFIER( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID,
                                                                           aMachine,
                                                                           strStartLot_actionList_EffectSpecCheck_out,
                                                                           startLot_actionList_EffectSpecCheck__101,
                                                                           Machine );
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib     = CIMFWStrDup("");

                                                dcActionInfo_count++;
                                            }
//DSIV00001021 add end
                                        }
//DSIV00000214 add start
                                    }
//PSIV00001648                                    else
                                    else if ( CIMFWStrLen( strProcessOperationInfo.asgnEqpID.identifier ) > 0 )         //PSIV00001648
                                    {
                                        PPT_METHODTRACE_V1("", "correspondingPO is other Fab. eqp hold request to other Fab.");
                                        findFlag = FALSE;
                                        PPT_METHODTRACE_V2("", "equipment_hold_flag entity_count -------------->", entity_count );
                                        for ( n = 0; n < entity_countForOtherFab; n++ )
                                        {
                                            PPT_METHODTRACE_V2("", "counter n -------------->", n );
                                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Equipment )
                                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier , strProcessOperationInfo.asgnEqpID.identifier ) )
                                            {
                                                findFlag = TRUE;
                                                break;
                                            }
                                        }
                                        if ( findFlag == FALSE )
                                        {
                                            PPT_METHODTRACE_V2("", "findFlag == FALSE  [machineID]",
                                                               strProcessOperationInfo.asgnEqpID.identifier);

                                            entity_countForOtherFab++;
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);

                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(corrFabID);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(1);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Equipment);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID = strProcessOperationInfo.asgnEqpID;
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib = CIMFWStrDup("");
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode = CIMFWStrDup( SP_Reason_SpecOverInhibit );
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID = strObjCommonIn.strUser.userID;
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                                        }
//DSIV00001021 add start
                                        findFlag = FALSE;
                                        PPT_METHODTRACE_V2("", "equipment_hold_flag dcActionInfo_count -------------->", dcActionInfo_count );
                                        for ( n = 0; n < dcActionInfo_count; n++ )
                                        {
                                            PPT_METHODTRACE_V2("", "counter n -------------->", n );
                                            if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                                            {
                                                if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Equipment)
                                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strProcessOperationInfo.asgnEqpID.identifier)
                                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SpecOverInhibit)
                                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, effectedLots[0].processOperation)
                                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[o].lotID.identifier) )
                                                {
                                                    findFlag = TRUE;
                                                    break;
                                                }
                                            }
                                        }
                                        if ( findFlag == FALSE )
                                        {
                                            PPT_METHODTRACE_V2("", "findFlag == FALSE  [machineID]",
                                                               strProcessOperationInfo.asgnEqpID.identifier);

                                            //-----------------------------------------------------------------------------
                                            // Add ActionResultInfo
                                            //-----------------------------------------------------------------------------
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[o].lotID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = monitorLotFlag;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strDCDef.dataCollectionDefinitionID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strDCDef.dataCollectionSpecificationID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPEC );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SpecOverInhibit );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_EquipmentHold );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = effectedLots[0].processOperation;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className  = CIMFWStrDup(SP_InhibitClassID_Equipment);
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID   = strProcessOperationInfo.asgnEqpID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib     = CIMFWStrDup("");

                                            dcActionInfo_count++;
                                        }
//DSIV00001021 add end
                                    }
//DSIV00000214 add end
                                }
                                if ( recipe_hold_flag == TRUE )
                                {
                                    PPT_METHODTRACE_V1("", "recipe_hold_flag == TRUE");
                                    PPT_METHODTRACE_V3("", "effectedLots[o].processOperation", o, effectedLots[o].processOperation);
//DSIV00000214 add start
                                    if ( requestOtherFabFlag == FALSE )
                                    {
                                        PPT_METHODTRACE_V1("", "correspondingPO is current Fab");
//DSIV00000214 add end

//DSIV00001021                                        PosProcessOperation_var aPOtmp;
//DSIV00001021                                        PPT_CONVERT_STRING_TO_OBJECT( effectedLots[o].processOperation ,aPOtmp, PosProcessOperation );
//DSIV00001021//Q3000124 start
//DSIV00001021                                        if ( CORBA::is_nil( aPOtmp ) )
//DSIV00001021                                        {
//DSIV00001021//P5000145                                        SET_MSG_RC( strStartLot_actionList_EffectSpecCheck_out, MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO );
//DSIV00001021                                            PPT_SET_MSG_RC_KEY2( strStartLot_actionList_EffectSpecCheck_out, MSG_NOT_FOUND_PO,    //P5000145
//DSIV00001021                                                                 RC_NOT_FOUND_PO, effectedLots[o].processOperation,               //P5000145
//DSIV00001021                                                                 effectedLots[o].lotID.identifier );                              //P5000145
//DSIV00001021
//DSIV00001021                                            return RC_NOT_FOUND_PO;
//DSIV00001021                                        }
//Q3000124 end

                                        PosMachineRecipe_var aRecipe;
                                        try
                                        {
                                            aRecipe = aPOtmp->getAssignedMachineRecipe();
                                        }
                                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getAssignedMachineRecipe)

                                        if ( ! CORBA::is_nil(aRecipe) )
                                        {
                                            PPT_METHODTRACE_V1("", "aRecipe is not nil");

                                            CORBA::String_var recipeID;
                                            try
                                            {
                                                recipeID = aRecipe->getIdentifier();
                                            }
                                            CATCH_AND_RAISE_EXCEPTIONS(PosMachineRecipe::getIdentifier)

                                            findFlag = FALSE;
                                            //-------------------------------------------------------------------
                                            //  Check recipe_hold_inhibition is already registed or not.
                                            //  If only not existed, entry new inhibition.
                                            //-------------------------------------------------------------------
                                            PPT_METHODTRACE_V2("", "recipe_hold_flag entity_count -------------->", entity_count );
                                            for ( n=0; n < entity_count; n++)
                                            {
                                                PPT_METHODTRACE_V2("", "counter n -------------->", n );

//P3000162                                  if ( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[n].entities[0].className == SP_InhibitClassID_MachineRecipe
//P3000162                                    && strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier == recipeID  )
                                                if ( 0 == CIMFWStrCmp(strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[n].entities[0].className , SP_InhibitClassID_MachineRecipe)  //P3000162
                                                  && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier , recipeID)            )  //P3000162
                                                {
                                                    findFlag = TRUE;
                                                    break;
                                                }
                                            }
//DSN000015229 Add Start
                                            if ( findFlag == FALSE )
                                            {
                                                PPT_METHODTRACE_V1("", "findFlag == FALSE");
                                                //-------------------------------------------------------------------
                                                //  Check FRENTINHBT for entitiy inhibit
                                                //-------------------------------------------------------------------
                                                CORBA::String_var strInhibitDcururationDays = CIMFWStrDup( getenv(SP_INHIBIT_DURATION) );
                                                objEntityInhibit_attributes_GetDR_out__101  strEntityInhibit_attributes_GetDR_out;
                                                objEntityInhibit_attributes_GetDR_in__101   strEntityInhibit_attributes_GetDR_in;
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.entities.length(1);
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.strEntityInhibitReasonDetailInfos.length(1);
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.endTimeStamp = strInhibitDcururationDays;
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.reasonCode   = CIMFWStrDup(SP_Reason_SpecOverInhibit);
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                                                PPT_SET_OBJECT_IDENTIFIER( strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.entities[0].objectID,
                                                                           aRecipe,
                                                                           strStartLot_actionList_EffectSpecCheck_out,
                                                                           startLot_actionList_EffectSpecCheck__101,
                                                                           MachineRecipe );
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.strEntityInhibitReasonDetailInfos[0].relatedLotID = strStartCassette[i].strLotInCassette[j].lotID.identifier;
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.strEntityInhibitReasonDetailInfos[0].relatedControlJobID = controlJobID;
                                                strEntityInhibit_attributes_GetDR_in.entityInhibitReasonDetailInfoFlag = FALSE;

                                                PPT_METHODTRACE_V1("", "Call entityInhibit_attributes_GetDR__101");
                                                rc = entityInhibit_attributes_GetDR__101( strEntityInhibit_attributes_GetDR_out,
                                                                                          strObjCommonIn,
                                                                                          strEntityInhibit_attributes_GetDR_in );

                                                if ( rc != RC_OK )
                                                {
                                                    PPT_METHODTRACE_V2("", " entityInhibit_attributes_GetDR__101 : rc != RC_OK", rc);
                                                    strStartLot_actionList_EffectSpecCheck_out.strResult = strEntityInhibit_attributes_GetDR_out.strResult;
                                                }

                                                CORBA::ULong inhibitLen = strEntityInhibit_attributes_GetDR_out.entityInhibitInfo.length();
                                                PPT_METHODTRACE_V2("", "inhibitLen", inhibitLen);
                                                if ( inhibitLen > 0 )
                                                {
                                                    findFlag = TRUE;
                                                    registeredFlag = TRUE;
                                                }
                                            }
//DSN000015229 Add End
                                            if ( findFlag == FALSE )
                                            {
                                                PPT_METHODTRACE_V2("", "findFlag == FALSE [recipeID]", recipeID);

                                                entity_count++;
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions.length(entity_count);

                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].entities.length(1);
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                                                PPT_SET_OBJECT_IDENTIFIER( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID,
                                                                           aRecipe,
                                                                           strStartLot_actionList_EffectSpecCheck_out,
                                                                           startLot_actionList_EffectSpecCheck__101,
                                                                           MachineRecipe );
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib = CIMFWStrDup("");
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
//Q3000124                                  strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup("TIMESTAMP_NIL_OBJECT_STRING");
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING); //Q3000284
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].reasonCode = CIMFWStrDup( SP_Reason_SpecOverInhibit );
//P4100051                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].ownerID.identifier = CIMFWStrDup("PPTSvcMgr");
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].ownerID = strObjCommonIn.strUser.userID;    //P4100051
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                                            }
//DSIV00001021 add start
                                            findFlag = FALSE;
                                            if ( FALSE == registeredFlag )      //DSN000015229
                                            {                                   //DSN000015229
                                                PPT_METHODTRACE_V1("", "FALSE == registeredFlag");      //DSN000015229
//DSN000015229 Indent Start
                                                PPT_METHODTRACE_V2("", "recipe_hold_flag dcActionInfo_count -------------->", dcActionInfo_count );
                                                for ( n=0; n < dcActionInfo_count; n++ )
                                                {
                                                    PPT_METHODTRACE_V2("", "counter n -------------->", n );
                                                    if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                                                    {
                                                        if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_MachineRecipe)
                                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, recipeID)
                                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SpecOverInhibit)
                                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, effectedLots[o].processOperation)
                                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[o].lotID.identifier) )
                                                        {
                                                            PPT_METHODTRACE_V1("", "Set findFlag = TRUE");      //DSN000015229
                                                            findFlag = TRUE;
                                                            break;
                                                        }
                                                    }
                                                }
//DSN000015229 Indent End
//DSN000015229 Add Start
                                            }
                                            else
                                            {
                                                PPT_METHODTRACE_V1("", "TRUE == registeredFlag");
                                                for ( n = 0; n < actionRsltLen; n++ )
                                                {
                                                    PPT_METHODTRACE_V2("", "counter n -------------->", n );
                                                    if ( actionResultInfoSeq[n].entities.length() == 1 )
                                                    {
                                                        if ( 0 == CIMFWStrCmp(actionResultInfoSeq[n].entities[0].className, SP_InhibitClassID_MachineRecipe)
                                                          && 0 == CIMFWStrCmp(actionResultInfoSeq[n].entities[0].objectID.identifier, recipeID)
                                                          && 0 == CIMFWStrCmp(actionResultInfoSeq[n].reasonCode, SP_Reason_SpecOverInhibit)
                                                          && 0 == CIMFWStrCmp(actionResultInfoSeq[n].correspondingObjrefPO, effectedLots[o].processOperation)
                                                          && 0 == CIMFWStrCmp(actionResultInfoSeq[n].lotID.identifier, effectedLots[o].lotID.identifier) )
                                                        {
                                                            PPT_METHODTRACE_V1("", "Set findFlag = TRUE");
                                                            findFlag = TRUE;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
//DSN000015229 Add End 
                                            if ( findFlag == FALSE )
                                            {
                                                PPT_METHODTRACE_V2("", "findFlag == FALSE [recipeID]", recipeID);

                                                //-----------------------------------------------------------------------------
                                                // Add ActionResultInfo
                                                //-----------------------------------------------------------------------------
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[o].lotID;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = monitorLotFlag;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strDCDef.dataCollectionDefinitionID;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strDCDef.dataCollectionSpecificationID;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPEC );
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SpecOverInhibit );
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_RecipeHold );
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = effectedLots[o].processOperation;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className  = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                                                PPT_SET_OBJECT_IDENTIFIER( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID,
                                                                           aRecipe,
                                                                           strStartLot_actionList_EffectSpecCheck_out,
                                                                           startLot_actionList_EffectSpecCheck__101,
                                                                           MachineRecipe );

                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib     = CIMFWStrDup("");

                                                dcActionInfo_count++;
                                            }
//DSIV00001021 add end
                                        }
//DSIV00000214 add start
                                    }
//PSIV00001648                                    else
                                    else if ( CIMFWStrLen( strProcessOperationInfo.asgnRecipeID.identifier ) > 0 )      //PSIV00001648
                                    {
                                        PPT_METHODTRACE_V1("", "correspondingPO is other Fab. recipe hold request to other Fab.");
                                        findFlag = FALSE;
                                        PPT_METHODTRACE_V2("", "recipe_hold_flag entity_countForOtherFab -------------->", entity_countForOtherFab );
                                        for ( n = 0; n < entity_countForOtherFab; n++ )
                                        {
                                            PPT_METHODTRACE_V2("", "counter n -------------->", n );

                                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className , SP_InhibitClassID_MachineRecipe )
                                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier , strProcessOperationInfo.asgnRecipeID.identifier ) )
                                            {
                                                findFlag = TRUE;
                                                break;
                                            }
                                        }
                                        if ( findFlag == FALSE )
                                        {
                                            PPT_METHODTRACE_V2("", "findFlag == FALSE [recipeID]",
                                                               strProcessOperationInfo.asgnRecipeID.identifier);

                                            entity_countForOtherFab++;
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);

                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(corrFabID);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(1);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID = strProcessOperationInfo.asgnRecipeID;
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib = CIMFWStrDup("");
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode = CIMFWStrDup( SP_Reason_SpecOverInhibit );
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID = strObjCommonIn.strUser.userID;
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                                        }
//DSIV00001021 add start
                                        findFlag = FALSE;
                                        PPT_METHODTRACE_V2("", "recipe_hold_flag dcActionInfo_count -------------->", dcActionInfo_count );
                                        for ( n = 0; n < dcActionInfo_count; n++ )
                                        {
                                            PPT_METHODTRACE_V2("", "counter n -------------->", n );
                                            if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                                            {
                                                if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_MachineRecipe)
                                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strProcessOperationInfo.asgnRecipeID.identifier)
                                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SpecOverInhibit)
                                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, effectedLots[0].processOperation)
                                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[o].lotID.identifier) )
                                                {
                                                    findFlag = TRUE;
                                                    break;
                                                }
                                            }
                                        }
                                        if ( findFlag == FALSE )
                                        {
                                            PPT_METHODTRACE_V2("", "findFlag == FALSE [recipeID]",
                                                               strProcessOperationInfo.asgnRecipeID.identifier);

                                            //-----------------------------------------------------------------------------
                                            // Add ActionResultInfo
                                            //-----------------------------------------------------------------------------
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[o].lotID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = monitorLotFlag;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strDCDef.dataCollectionDefinitionID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strDCDef.dataCollectionSpecificationID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPEC );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SpecOverInhibit );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_RecipeHold );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = effectedLots[0].processOperation;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className  = CIMFWStrDup(SP_InhibitClassID_MachineRecipe);
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID   = strProcessOperationInfo.asgnRecipeID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib     = CIMFWStrDup("");

                                            dcActionInfo_count++;
                                        }
//DSIV00001021 add end
                                    }
//DSIV00000214 add end
                                }
                                if ( route_hold_flag == TRUE )
                                {
                                    PPT_METHODTRACE_V1("", "route_hold_flag == TRUE");
//DSIV00000214 add start
                                    if ( requestOtherFabFlag == FALSE )
                                    {
                                        PPT_METHODTRACE_V1("", "correspondingPO is current Fab");
//DSIV00000214 add end

//DSIV00001021                                        PosProcessOperation_var aPOtmp;
//DSIV00001021                                        PPT_CONVERT_STRING_TO_OBJECT( effectedLots[o].processOperation ,aPOtmp, PosProcessOperation );
//DSIV00001021//Q3000124 start
//DSIV00001021                                        if ( CORBA::is_nil(aPOtmp) )
//DSIV00001021                                        {
//DSIV00001021//P5000145                                        SET_MSG_RC( strStartLot_actionList_EffectSpecCheck_out, MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO );
//DSIV00001021                                            PPT_SET_MSG_RC_KEY2( strStartLot_actionList_EffectSpecCheck_out, MSG_NOT_FOUND_PO,    //P5000145
//DSIV00001021                                                                 RC_NOT_FOUND_PO, effectedLots[o].processOperation,               //P5000145
//DSIV00001021                                                                 effectedLots[o].lotID.identifier );                              //P5000145
//DSIV00001021
//DSIV00001021                                            return RC_NOT_FOUND_PO;
//DSIV00001021                                        }
//Q3000124 end

                                        PosProcessDefinition_var aMainPD;
                                        try
                                        {
                                            aMainPD = aPOtmp->getMainProcessDefinition();
                                        }
                                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getMainProcessDefinition)

                                        if ( ! CORBA::is_nil(aMainPD) )
                                        {
                                            PPT_METHODTRACE_V1("", "aMainPD is not nil");

                                            CORBA::String_var mainPDID;
                                            try
                                            {
                                                mainPDID = aMainPD->getIdentifier();
                                            }
                                            CATCH_AND_RAISE_EXCEPTIONS(ProcessDefinition::getIdentifier)

                                            findFlag = FALSE;
                                            //-------------------------------------------------------------------
                                            //  Check route_hold_inhibition is already registed or not.
                                            //  If only not existed, entry new inhibition.
                                            //-------------------------------------------------------------------
                                            PPT_METHODTRACE_V2("", "route_hold_flag entity_count -------------->", entity_count );
                                            for ( n=0; n < entity_count; n++ )
                                            {
                                                PPT_METHODTRACE_V2("", "counter n -------------->", n );
                                                if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Route )
                                                  && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, mainPDID )
                                                  && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[n].entities[0].attrib, "" ) )
                                                {
                                                    findFlag = TRUE;
                                                    break;
                                                }
                                            }
//DSN000015229 Add Start
                                            if ( findFlag == FALSE )
                                            {
                                                PPT_METHODTRACE_V1("", "findFlag == FALSE");
                                                //-------------------------------------------------------------------
                                                //  Check FRENTINHBT for entitiy inhibit
                                                //-------------------------------------------------------------------
                                                CORBA::String_var strInhibitDcururationDays = CIMFWStrDup( getenv(SP_INHIBIT_DURATION) );
                                                objEntityInhibit_attributes_GetDR_out__101  strEntityInhibit_attributes_GetDR_out;
                                                objEntityInhibit_attributes_GetDR_in__101   strEntityInhibit_attributes_GetDR_in;
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.entities.length(1);
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.strEntityInhibitReasonDetailInfos.length(1);
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.endTimeStamp = strInhibitDcururationDays;
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.reasonCode   = CIMFWStrDup(SP_Reason_SpecOverInhibit);
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Route);
                                                PPT_SET_OBJECT_IDENTIFIER( strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.entities[0].objectID,
                                                                           aMainPD,
                                                                           strStartLot_actionList_EffectSpecCheck_out,
                                                                           startLot_actionList_EffectSpecCheck__101,
                                                                           ProcessDefinition );
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.strEntityInhibitReasonDetailInfos[0].relatedLotID = strStartCassette[i].strLotInCassette[j].lotID.identifier;
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.strEntityInhibitReasonDetailInfos[0].relatedControlJobID = controlJobID;
                                                strEntityInhibit_attributes_GetDR_in.entityInhibitReasonDetailInfoFlag = FALSE;

                                                PPT_METHODTRACE_V1("", "Call entityInhibit_attributes_GetDR__101");
                                                rc = entityInhibit_attributes_GetDR__101( strEntityInhibit_attributes_GetDR_out,
                                                                                          strObjCommonIn,
                                                                                          strEntityInhibit_attributes_GetDR_in );

                                                if ( rc != RC_OK )
                                                {
                                                    PPT_METHODTRACE_V2("", " entityInhibit_attributes_GetDR__101 : rc != RC_OK", rc);
                                                    strStartLot_actionList_EffectSpecCheck_out.strResult = strEntityInhibit_attributes_GetDR_out.strResult;
                                                }

                                                CORBA::ULong inhibitLen = strEntityInhibit_attributes_GetDR_out.entityInhibitInfo.length();
                                                PPT_METHODTRACE_V2("", "inhibitLen", inhibitLen);
                                                if ( inhibitLen > 0 )
                                                {
                                                    findFlag = TRUE;
                                                    registeredFlag = TRUE;
                                                }
                                            }
//DSN000015229 Add End
                                            if ( findFlag == FALSE )
                                            {
                                                PPT_METHODTRACE_V2("", "findFlag == FALSE [mainPDID]", mainPDID);

                                                entity_count++;
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions.length(entity_count);

                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].entities.length(1);
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Route);
                                                PPT_SET_OBJECT_IDENTIFIER( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID,
                                                                           aMainPD,
                                                                           strStartLot_actionList_EffectSpecCheck_out,
                                                                           startLot_actionList_EffectSpecCheck__101,
                                                                           ProcessDefinition );
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib = CIMFWStrDup("");
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
//Q3000124                                  strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup("TIMESTAMP_NIL_OBJECT_STRING");
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING); //Q3000284
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].reasonCode = CIMFWStrDup( SP_Reason_SpecOverInhibit );
//P4100051                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].ownerID.identifier = CIMFWStrDup("PPTSvcMgr");
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].ownerID = strObjCommonIn.strUser.userID;    //P4100051
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                                            }
//DSIV00001021 add start
                                            findFlag = FALSE;
                                            if ( FALSE == registeredFlag )      //DSN000015229
                                            {                                   //DSN000015229
//DSN000015229 Indent Start
                                                PPT_METHODTRACE_V1("", "FALSE == registeredFlag");      //DSN000015229
                                                PPT_METHODTRACE_V2("", "route_hold_flag dcActionInfo_count -------------->", dcActionInfo_count );
                                                for ( n = 0; n < dcActionInfo_count; n++ )
                                                {
                                                    PPT_METHODTRACE_V2("", "counter n -------------->", n );
                                                    if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                                                    {
                                                        if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Route)
                                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, mainPDID)
                                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].attrib, "" )
                                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SpecOverInhibit)
                                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, effectedLots[o].processOperation)
                                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[o].lotID.identifier) )
                                                        {
                                                            PPT_METHODTRACE_V1("", "Set findFlag = TRUE");      //DSN000015229
                                                            findFlag = TRUE;
                                                            break;
                                                        }
                                                    }
                                                }
//DSN000015229 Indent End
//DSN000015229 Add Start
                                            }
                                            else
                                            {
                                                PPT_METHODTRACE_V1("", "TRUE == registeredFlag");
                                                for ( n = 0; n < actionRsltLen; n++ )
                                                {
                                                    PPT_METHODTRACE_V2("", "counter n -------------->", n );
                                                    if ( actionResultInfoSeq[n].entities.length() == 1 )
                                                    {
                                                        if ( 0 == CIMFWStrCmp(actionResultInfoSeq[n].entities[0].className, SP_InhibitClassID_Route)
                                                          && 0 == CIMFWStrCmp(actionResultInfoSeq[n].entities[0].objectID.identifier, mainPDID)
                                                          && 0 == CIMFWStrCmp(actionResultInfoSeq[n].entities[0].attrib, "" )
                                                          && 0 == CIMFWStrCmp(actionResultInfoSeq[n].reasonCode, SP_Reason_SpecOverInhibit)
                                                          && 0 == CIMFWStrCmp(actionResultInfoSeq[n].correspondingObjrefPO, effectedLots[o].processOperation)
                                                          && 0 == CIMFWStrCmp(actionResultInfoSeq[n].lotID.identifier, effectedLots[o].lotID.identifier) )
                                                        {
                                                            PPT_METHODTRACE_V1("", "Set findFlag = TRUE");
                                                            findFlag = TRUE;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
//DSN000015229 Add End 
                                            if ( findFlag == FALSE )
                                            {
                                                PPT_METHODTRACE_V2("", "findFlag == FALSE [mainPDID]", mainPDID);

                                                //-----------------------------------------------------------------------------
                                                // Add ActionResultInfo
                                                //-----------------------------------------------------------------------------
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[o].lotID;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = monitorLotFlag;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strDCDef.dataCollectionDefinitionID;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strDCDef.dataCollectionSpecificationID;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPEC );
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SpecOverInhibit );
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_RouteHold );
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = effectedLots[o].processOperation;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className  = CIMFWStrDup(SP_InhibitClassID_Route);
                                                PPT_SET_OBJECT_IDENTIFIER( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID,
                                                                           aMainPD,
                                                                           strStartLot_actionList_EffectSpecCheck_out,
                                                                           startLot_actionList_EffectSpecCheck__101,
                                                                           ProcessDefinition );

                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib     = CIMFWStrDup("");

                                                dcActionInfo_count++;
                                            }
//DSIV00001021 add end
                                        }
//DSIV00000214 add start
                                    }
                                    else
                                    {
                                        PPT_METHODTRACE_V1("", "correspondingPO is other Fab. route hold request to other Fab.");
                                        findFlag = FALSE;
                                        PPT_METHODTRACE_V2("", "route_hold_flag entity_countForOtherFab -------------->", entity_countForOtherFab );
                                        for ( n = 0; n < entity_countForOtherFab; n++ )
                                        {
                                            PPT_METHODTRACE_V2("", "counter n -------------->", n );
                                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Route )
                                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strProcessOperationInfo.mainPDID.identifier )
                                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].attrib, "" ) )
                                            {
                                                findFlag = TRUE;
                                                break;
                                            }
                                        }
                                        if ( findFlag == FALSE )
                                        {
                                            PPT_METHODTRACE_V2("", "findFlag == FALSE [mainPDID]",
                                                               strProcessOperationInfo.mainPDID.identifier);

                                            entity_countForOtherFab++;
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);

                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(corrFabID);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(1);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Route);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID = strProcessOperationInfo.mainPDID;
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib = CIMFWStrDup("");
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode = CIMFWStrDup( SP_Reason_SpecOverInhibit );
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID = strObjCommonIn.strUser.userID;
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                                        }
//DSIV00001021 add start
                                        findFlag = FALSE;
                                        PPT_METHODTRACE_V2("", "route_hold_flag dcActionInfo_count -------------->", dcActionInfo_count );
                                        for ( n = 0; n < dcActionInfo_count; n++ )
                                        {
                                            PPT_METHODTRACE_V2("", "counter n -------------->", n );
                                            if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                                            {
                                                if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Route)
                                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strProcessOperationInfo.mainPDID.identifier)
                                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].attrib, "" )
                                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SpecOverInhibit)
                                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, effectedLots[0].processOperation)
                                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[o].lotID.identifier) )
                                                {
                                                    findFlag = TRUE;
                                                    break;
                                                }
                                            }
                                        }
                                        if ( findFlag == FALSE )
                                        {
                                            PPT_METHODTRACE_V2("", "findFlag == FALSE [mainPDID]",
                                                               strProcessOperationInfo.mainPDID.identifier);

                                            //-----------------------------------------------------------------------------
                                            // Add ActionResultInfo
                                            //-----------------------------------------------------------------------------
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[o].lotID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = monitorLotFlag;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strDCDef.dataCollectionDefinitionID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strDCDef.dataCollectionSpecificationID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPEC );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SpecOverInhibit );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_RouteHold );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = effectedLots[0].processOperation;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className  = CIMFWStrDup(SP_InhibitClassID_Route);
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID   =  strProcessOperationInfo.mainPDID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib     = CIMFWStrDup("");

                                            dcActionInfo_count++;
                                        }
//DSIV00001021 add end
                                    }
//DSIV00000214 add end
                                }
                                if ( process_hold_flag == TRUE )
                                {
                                    PPT_METHODTRACE_V1("", "process_hold_flag == TRUE");
//DSIV00000214 add start
                                    if ( requestOtherFabFlag == FALSE )
                                    {
                                        PPT_METHODTRACE_V1("", "correspondingPO is current Fab");
//DSIV00000214 add end

//DSIV00001021                                        PosProcessOperation_var aPOtmp;
//DSIV00001021                                        PPT_CONVERT_STRING_TO_OBJECT( effectedLots[o].processOperation ,aPOtmp, PosProcessOperation );
//DSIV00001021//Q3000124 start
//DSIV00001021                                        if ( CORBA::is_nil(aPOtmp) )
//DSIV00001021                                        {
//DSIV00001021//P4100425 start
//DSIV00001021                                            PPT_SET_MSG_RC_KEY2( strStartLot_actionList_EffectSpecCheck_out, MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO,
//DSIV00001021                                                                 "", effectedLots[o].lotID.identifier );
//DSIV00001021//P4100425 end
//DSIV00001021//P4100425                                        PPT_SET_MSG_RC_KEY( strStartLot_actionList_EffectSpecCheck_out, MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO, "" );
//DSIV00001021                                            return( RC_NOT_FOUND_PO );
//DSIV00001021                                        }
//Q3000124 end

                                        PosProcessDefinition_var aMainPD;
                                        try
                                        {
                                            aMainPD = aPOtmp->getMainProcessDefinition();
                                        }
                                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getMainProcessDefinition)

                                        CORBA::String_var operationNo;
                                        try
                                        {
                                            operationNo = aPOtmp->getOperationNumber();
                                        }
                                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getOperationNumber)

                                        if ( ! CORBA::is_nil(aMainPD) )
                                        {
                                            PPT_METHODTRACE_V1("", "aMainPD is not nil");

                                            CORBA::String_var mainPDID;
                                            try
                                            {
                                                mainPDID = aMainPD->getIdentifier();
                                            }
                                            CATCH_AND_RAISE_EXCEPTIONS(ProcessDefinition::getIdentifier)

                                            CORBA::Boolean findFlag = FALSE;
                                            //-------------------------------------------------------------------
                                            //  Check process_hold_inhibition is already registed or not.
                                            //  If only not existed, entry new inhibition.
                                            //-------------------------------------------------------------------
                                            PPT_METHODTRACE_V2("", "process_hold_flag entity_count -------------->", entity_count );
                                            for ( n=0; n < entity_count; n++ )
                                            {
                                                PPT_METHODTRACE_V2("", "counter n -------------->", n );
                                                if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[n].entities[0].className, SP_InhibitClassID_Operation )
                                                  && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[n].entities[0].objectID.identifier, mainPDID )
                                                  && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[n].entities[0].attrib, operationNo ) )
                                                {
                                                    findFlag = TRUE;
                                                    break;
                                                }
                                            }
//DSN000015229 Add Start
                                            if ( findFlag == FALSE )
                                            {
                                                PPT_METHODTRACE_V1("", "findFlag == FALSE");
                                                //-------------------------------------------------------------------
                                                //  Check FRENTINHBT for entitiy inhibit
                                                //-------------------------------------------------------------------
                                                CORBA::String_var strInhibitDcururationDays = CIMFWStrDup( getenv(SP_INHIBIT_DURATION) );
                                                objEntityInhibit_attributes_GetDR_out__101  strEntityInhibit_attributes_GetDR_out;
                                                objEntityInhibit_attributes_GetDR_in__101   strEntityInhibit_attributes_GetDR_in;
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.entities.length(1);
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.strEntityInhibitReasonDetailInfos.length(1);
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.endTimeStamp = strInhibitDcururationDays;
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.reasonCode   = CIMFWStrDup(SP_Reason_SpecOverInhibit);
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Operation);
                                                PPT_SET_OBJECT_IDENTIFIER( strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.entities[0].objectID,
                                                                           aMainPD,
                                                                           strStartLot_actionList_EffectSpecCheck_out,
                                                                           startLot_actionList_EffectSpecCheck__101,
                                                                           ProcessDefinition );
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.strEntityInhibitReasonDetailInfos[0].relatedLotID = strStartCassette[i].strLotInCassette[j].lotID.identifier;
                                                strEntityInhibit_attributes_GetDR_in.strEntityInhibitDetailAttributes.strEntityInhibitReasonDetailInfos[0].relatedControlJobID = controlJobID;
                                                strEntityInhibit_attributes_GetDR_in.entityInhibitReasonDetailInfoFlag = FALSE;

                                                PPT_METHODTRACE_V1("", "Call entityInhibit_attributes_GetDR__101");
                                                rc = entityInhibit_attributes_GetDR__101( strEntityInhibit_attributes_GetDR_out,
                                                                                          strObjCommonIn,
                                                                                          strEntityInhibit_attributes_GetDR_in );

                                                if ( rc != RC_OK )
                                                {
                                                    PPT_METHODTRACE_V2("", " entityInhibit_attributes_GetDR__101 : rc != RC_OK", rc);
                                                    strStartLot_actionList_EffectSpecCheck_out.strResult = strEntityInhibit_attributes_GetDR_out.strResult;
                                                }

                                                CORBA::ULong inhibitLen = strEntityInhibit_attributes_GetDR_out.entityInhibitInfo.length();
                                                PPT_METHODTRACE_V2("", "inhibitLen", inhibitLen);
                                                if ( inhibitLen > 0 )
                                                {
                                                    findFlag = TRUE;
                                                    registeredFlag = TRUE;
                                                }
                                            }
//DSN000015229 Add End
                                            if ( findFlag == FALSE )
                                            {
                                                PPT_METHODTRACE_V2("", "findFlag == FALSE [mainPDID]", mainPDID);

                                                entity_count++;
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions.length(entity_count);

                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].entities.length(1);
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].entities[0].className = CIMFWStrDup(SP_InhibitClassID_Operation);
                                                PPT_SET_OBJECT_IDENTIFIER( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].entities[0].objectID,
                                                                           aMainPD,
                                                                           strStartLot_actionList_EffectSpecCheck_out,
                                                                           startLot_actionList_EffectSpecCheck__101,
                                                                           ProcessDefinition );
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].entities[0].attrib = CIMFWStrDup(operationNo);
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].subLotTypes.length(0);
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].startTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
//Q3000124                                  strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup("TIMESTAMP_NIL_OBJECT_STRING");
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].endTimeStamp = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING); //Q3000284
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].reasonCode = CIMFWStrDup( SP_Reason_SpecOverInhibit );
//P4100051                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].ownerID.identifier = CIMFWStrDup("PPTSvcMgr");
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].ownerID = strObjCommonIn.strUser.userID;    //P4100051
                                                strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[entity_count-1].claimedTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                                            }
//DSIV00001021 add start
                                            findFlag = FALSE;
                                            if ( FALSE == registeredFlag )      //DSN000015229
                                            {                                   //DSN000015229
//DSN000015229 Indent Start
                                                PPT_METHODTRACE_V1("", "FALSE == registeredFlag");      //DSN000015229
                                                PPT_METHODTRACE_V2("", "process_hold_flag dcActionInfo_count -------------->", dcActionInfo_count );
                                                for ( n=0; n < dcActionInfo_count; n++ )
                                                {
                                                    PPT_METHODTRACE_V2("", "counter n -------------->", n );
                                                    if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                                                    {
                                                        if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Operation)
                                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, mainPDID)
                                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].attrib, operationNo )
                                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SpecOverInhibit)
                                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, effectedLots[o].processOperation)
                                                          && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[o].lotID.identifier) )
                                                        {
                                                            PPT_METHODTRACE_V1("", "Set findFlag = TRUE");
                                                            findFlag = TRUE;
                                                            break;
                                                        }
                                                    }
                                                }
//DSN000015229 Indent End
//DSN000015229 Add Start
                                            }
                                            else
                                            {
                                                PPT_METHODTRACE_V1("", "TRUE == registeredFlag");
                                                for ( n = 0; n < actionRsltLen; n++ )
                                                {
                                                    PPT_METHODTRACE_V2("", "counter n -------------->", n );
                                                    if ( actionResultInfoSeq[n].entities.length() == 1 )
                                                    {
                                                        if ( 0 == CIMFWStrCmp(actionResultInfoSeq[n].entities[0].className, SP_InhibitClassID_Operation)
                                                          && 0 == CIMFWStrCmp(actionResultInfoSeq[n].entities[0].objectID.identifier, mainPDID)
                                                          && 0 == CIMFWStrCmp(actionResultInfoSeq[n].entities[0].attrib, operationNo )
                                                          && 0 == CIMFWStrCmp(actionResultInfoSeq[n].reasonCode, SP_Reason_SpecOverInhibit)
                                                          && 0 == CIMFWStrCmp(actionResultInfoSeq[n].correspondingObjrefPO, effectedLots[o].processOperation)
                                                          && 0 == CIMFWStrCmp(actionResultInfoSeq[n].lotID.identifier, effectedLots[o].lotID.identifier) )
                                                        {
                                                            PPT_METHODTRACE_V1("", "Set findFlag = TRUE");
                                                            findFlag = TRUE;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
//DSN000015229 Add End 
                                            if ( findFlag == FALSE )
                                            {
                                                PPT_METHODTRACE_V2("", "findFlag == FALSE [mainPDID]", mainPDID);

                                                //-----------------------------------------------------------------------------
                                                // Add ActionResultInfo
                                                //-----------------------------------------------------------------------------
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[o].lotID;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = monitorLotFlag;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strDCDef.dataCollectionDefinitionID;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strDCDef.dataCollectionSpecificationID;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPEC );
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SpecOverInhibit );
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_ProcessHold );
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = effectedLots[o].processOperation;
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className  = CIMFWStrDup(SP_InhibitClassID_Operation);
                                                PPT_SET_OBJECT_IDENTIFIER( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID,
                                                                           aMainPD,
                                                                           strStartLot_actionList_EffectSpecCheck_out,
                                                                           startLot_actionList_EffectSpecCheck__101,
                                                                           ProcessDefinition );
                                                strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib     = CIMFWStrDup(operationNo);
                                                dcActionInfo_count++;
                                            }
//DSIV00001021 add end

                                        }
//DSIV00000214 add start
                                    }
                                    else
                                    {
                                        PPT_METHODTRACE_V1("", "correspondingPO is other Fab. process hold request to other Fab.");
                                        findFlag = FALSE;
                                        PPT_METHODTRACE_V2("", "process_hold_flag entity_countForOtherFab -------------->", entity_countForOtherFab );
                                        for ( n = 0; n < entity_countForOtherFab; n++ )
                                        {
                                            PPT_METHODTRACE_V2("", "counter n -------------->", n );
                                            if ( 0 == CIMFWStrCmp( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].className, SP_InhibitClassID_Operation )
                                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].objectID.identifier, strProcessOperationInfo.mainPDID.identifier )
                                              && 0 == CIMFWStrCmp( strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[n].strEntityInhibitAttributes.entities[0].attrib, strProcessOperationInfo.opeNo ) )
                                            {
                                                findFlag = TRUE;
                                                break;
                                            }
                                        }
                                        if ( findFlag == FALSE )
                                        {
                                            PPT_METHODTRACE_V2("", "findFlag == FALSE [mainPDID]",
                                                               strProcessOperationInfo.mainPDID.identifier);

                                            entity_countForOtherFab++;
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo.length(entity_countForOtherFab);

                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].fabID = CIMFWStrDup(corrFabID);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities.length(1);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].className = CIMFWStrDup(SP_InhibitClassID_Operation);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].objectID = strProcessOperationInfo.mainPDID;
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.entities[0].attrib = CIMFWStrDup(strProcessOperationInfo.opeNo);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.subLotTypes.length(0);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.startTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.endTimeStamp = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.reasonCode = CIMFWStrDup( SP_Reason_SpecOverInhibit );
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.ownerID = strObjCommonIn.strUser.userID;
                                            strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[entity_countForOtherFab-1].strEntityInhibitAttributes.claimedTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
                                        }
//DSIV00001021 add start
                                        findFlag = FALSE;
                                        PPT_METHODTRACE_V2("", "process_hold_flag dcActionInfo_count -------------->", dcActionInfo_count );
                                        for ( n = 0; n < dcActionInfo_count; n++ )
                                        {
                                            PPT_METHODTRACE_V2("", "counter n -------------->", n );
                                            if ( strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities.length() == 1 )
                                            {
                                                if ( 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].className, SP_InhibitClassID_Operation)
                                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].objectID.identifier, strProcessOperationInfo.mainPDID.identifier)
                                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].entities[0].attrib, strProcessOperationInfo.opeNo )
                                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].reasonCode, SP_Reason_SpecOverInhibit)
                                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].correspondingObjrefPO, effectedLots[0].processOperation)
                                                  && 0 == CIMFWStrCmp(strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[n].lotID.identifier, effectedLots[o].lotID.identifier) )
                                                {
                                                    findFlag = TRUE;
                                                    break;
                                                }
                                            }
                                        }
                                        if ( findFlag == FALSE )
                                        {
                                            PPT_METHODTRACE_V2("", "findFlag == FALSE [mainPDID]",
                                                               strProcessOperationInfo.mainPDID.identifier);

                                            //-----------------------------------------------------------------------------
                                            // Add ActionResultInfo
                                            //-----------------------------------------------------------------------------
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[o].lotID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = monitorLotFlag;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strDCDef.dataCollectionDefinitionID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strDCDef.dataCollectionSpecificationID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPEC );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = CIMFWStrDup( SP_Reason_SpecOverInhibit );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_ProcessHold );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = effectedLots[0].processOperation;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(1);
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].className  = CIMFWStrDup(SP_InhibitClassID_Operation);
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].objectID   = strProcessOperationInfo.mainPDID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities[0].attrib     = CIMFWStrDup(strProcessOperationInfo.opeNo);
                                            dcActionInfo_count++;
//DSIV00001021 add end
                                        }
                                    }
//DSIV00000214 add end
                                }

                                //------------------------------------------------------------------------------------------------
                                //  Make strMessageAttributes of out parameter.
                                //
                                //    check actionCode of all strDCDef.dataCollectoinItemName.
                                //    ( actionCode are filled only when specCheckResult is SP_ActionCode_Mail. )
                                //------------------------------------------------------------------------------------------------
                                if ( mail_flag == TRUE )
                                {
                                    PPT_METHODTRACE_V1("", "mail_flag == TRUE");
//DSIV00000214 add start
                                    if ( requestOtherFabFlag == FALSE || o == 0 )
                                    {
                                        PPT_METHODTRACE_V1("", "correspondingPO is current Fab");
//DSIV00000214 add end

//DSIV00001021                                        findFlag = FALSE;
//DSIV00001021                                        //-----------------------------------------------------------------------------------------
//DSIV00001021                                        //  Check if strMessageAttributes is already registed with the same lotID & reasonCode or not.
//DSIV00001021                                        //  If only not existed, entry new inhibition.
//DSIV00001021                                        //
//DSIV00001021                                        //-----------------------------------------------------------------------------------------
//DSIV00001021                                        PPT_METHODTRACE_V2("", "mail_flag msg count -------------->", msg_count );
//DSIV00001021                                        for ( n=0; n < msg_count; n++ )
//DSIV00001021                                        {
//DSIV00001021                                            PPT_METHODTRACE_V2("", "counter n -------------->", n );
//DSIV00001021                                            if ( 0 == CIMFWStrCmp(strStartLot_actionList_EffectSpecCheck_out.strMessageList[n].reasonCode, reasonCode)
//DSIV00001021                                              && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSpecCheck_out.strMessageList[n].lotID.identifier,
//DSIV00001021                                                                  effectedLots[o].lotID.identifier) )
//DSIV00001021                                            {
//DSIV00001021                                                findFlag = TRUE;
//DSIV00001021                                            }
//DSIV00001021                                        }
//DSIV00001021                                        if ( findFlag == FALSE )
//DSIV00001021                                        {
//DSIV00001021                                            PPT_METHODTRACE_V1("", "findFlag == FALSE");

                                            //-----------------------------------------
                                            //  Get Main PD ID
                                            //-----------------------------------------
//Q3000284                          PosLot_var aLot;
//Q3000284                          PPT_CONVERT_LOTID_TO_LOT_OR( aLot,
//Q3000284                                                       effectedLots[o].lotID,
//Q3000284                                                       strStartLot_actionList_EffectSpecCheck_out,
//Q3000284                                                       startLot_actionList_EffectSpecCheck );
//Q3000284
//Q3000284                          PosProcessDefinition_var mainPD;
//Q3000284                          try
//Q3000284                          {
//Q3000284                              mainPD = aLot->getMainProcessDefinition();
//Q3000284                          }
//Q3000284                          CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getMainProcessDefinition)

//Q3000284 add start
//DSIV00001021                                            PosProcessOperation_var aPOtmp;
//DSIV00001021                                            PPT_CONVERT_STRING_TO_OBJECT( effectedLots[o].processOperation ,aPOtmp, PosProcessOperation );
//DSIV00001021
//DSIV00001021                                            if ( CORBA::is_nil( aPOtmp ) )
//DSIV00001021                                            {
//DSIV00001021//P5000145                                            SET_MSG_RC( strStartLot_actionList_EffectSpecCheck_out, MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO );
//DSIV00001021                                                PPT_SET_MSG_RC_KEY2( strStartLot_actionList_EffectSpecCheck_out, MSG_NOT_FOUND_PO,    //P5000145
//DSIV00001021                                                                     RC_NOT_FOUND_PO, effectedLots[o].processOperation,               //P5000145
//DSIV00001021                                                                     effectedLots[o].lotID.identifier );                              //P5000145
//DSIV00001021
//DSIV00001021                                                return RC_NOT_FOUND_PO;
//DSIV00001021                                            }

                                        PosMachine_var aMachine;
                                        try
                                        {
                                            aMachine  = aPOtmp->getAssignedMachine();
                                        }
                                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getAssignedMachine)

                                        PosProcessDefinition_var aMainPD;
                                        try
                                        {
                                            aMainPD = aPOtmp->getMainProcessDefinition();
                                        }
                                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getMainProcessDefinition)

                                        CORBA::String_var operationNo;
                                        try
                                        {
                                            operationNo = aPOtmp->getOperationNumber();
                                        }
                                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getOperationNumber)

                                        objectIdentifier eqpID;
                                        PPT_SET_OBJECT_IDENTIFIER( eqpID,
                                                                   aMachine,
                                                                   strStartLot_actionList_EffectSpecCheck_out,
                                                                   startLot_actionList_EffectSpecCheck,
                                                                   PosMachine );
                                        objectIdentifier routeID;
                                        PPT_SET_OBJECT_IDENTIFIER( routeID,
                                                                   aMainPD,
                                                                   strStartLot_actionList_EffectSpecCheck_out,
                                                                   startLot_actionList_EffectSpecCheck,
                                                                   PosProcessDefinition );
//DSIV00001021 add start
                                        findFlag = FALSE;
                                        //--------------------------------------------------------------------------------------------------------------------
                                        //  Check if strMessageAttributes is already registed with the same lotID & reasonCode & routeID & operationNo or not.
                                        //  If only not existed, entry new inhibition.
                                        //
                                        //--------------------------------------------------------------------------------------------------------------------
                                        PPT_METHODTRACE_V2("", "mail_flag msg count -------------->", msg_count );
                                        for ( n = 0; n < msg_count; n++ )
                                        {
                                            PPT_METHODTRACE_V2("", "counter n -------------->", n );
                                            if ( 0 == CIMFWStrCmp(strStartLot_actionList_EffectSpecCheck_out.strMessageList[n].reasonCode, reasonCode)
                                              && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSpecCheck_out.strMessageList[n].lotID.identifier, effectedLots[o].lotID.identifier)
                                              && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSpecCheck_out.strMessageList[n].routeID.identifier, routeID.identifier)
                                              && 0 == CIMFWStrCmp(strStartLot_actionList_EffectSpecCheck_out.strMessageList[n].operationNumber, operationNo))
                                            {
                                                findFlag = TRUE;
                                            }
                                        }
                                        if ( findFlag == FALSE )
                                        {
                                            PPT_METHODTRACE_V1("", "findFlag == FALSE");
//DSIV00001021 add end
//Q3000284 add end

                                            msg_count++;
                                            strStartLot_actionList_EffectSpecCheck_out.strMessageList.length(msg_count);

                                            strStartLot_actionList_EffectSpecCheck_out.strMessageList[msg_count-1].messageID.identifier  = CIMFWStrDup( SP_MessageID_SpecCheckOver );
                                            strStartLot_actionList_EffectSpecCheck_out.strMessageList[msg_count-1].lotID                 = effectedLots[o].lotID;
                                            strStartLot_actionList_EffectSpecCheck_out.strMessageList[msg_count-1].lotStatus             = CIMFWStrDup("");
//Q3000284                              strStartLot_actionList_EffectSpecCheck_out.strMessageList[msg_count-1].equipmentID           = equipmentID;
//Q3000284                              PPT_SET_OBJECT_IDENTIFIER( strStartLot_actionList_EffectSpecCheck_out.strMessageList[msg_count-1].routeID,
//Q3000284                                                         mainPD,
//Q3000284                                                         strStartLot_actionList_EffectSpecCheck_out,
//Q3000284                                                         StartLot_actionList_EffectSpecCheck,
//Q3000284                                                         PosProcessDefinition );
//Q3000284                              strStartLot_actionList_EffectSpecCheck_out.strMessageList[msg_count-1].operationNumber       = CIMFWStrDup("");
//Q3000284 add start
                                            strStartLot_actionList_EffectSpecCheck_out.strMessageList[msg_count-1].equipmentID           = eqpID;
                                            strStartLot_actionList_EffectSpecCheck_out.strMessageList[msg_count-1].routeID               = routeID;
                                            strStartLot_actionList_EffectSpecCheck_out.strMessageList[msg_count-1].operationNumber       = operationNo;
//Q3000284 add end
                                            strStartLot_actionList_EffectSpecCheck_out.strMessageList[msg_count-1].reasonCode            = messageReason;
                                            strStartLot_actionList_EffectSpecCheck_out.strMessageList[msg_count-1].messageText           = CIMFWStrDup("");
//DSIV00001021 add start
                                            //-----------------------------------------------------------------------------
                                            // Add ActionResultInfo
                                            //-----------------------------------------------------------------------------
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[o].lotID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = monitorLotFlag;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strDCDef.dataCollectionDefinitionID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strDCDef.dataCollectionSpecificationID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPEC );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = messageReason;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_Mail );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = effectedLots[o].processOperation;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(0);
                                            dcActionInfo_count++;
//DSIV00001021 add end

                                        }
//DSIV00000214 add start
                                    }
                                    else
                                    {
                                        PPT_METHODTRACE_V1("", "correspondingPO is other Fab. mail send request to other Fab.");

                                        findLotFlag = FALSE;
                                        findMsgFlag = FALSE;
                                        msg_countPerMonLot = 0;
                                        CORBA::ULong mailIdx;   //PSIV00001648

                                        for ( n = 0; n < lot_countForMailOtherFab; n++ )
                                        {
                                            PPT_METHODTRACE_V2("", "counter n -------------->", n );

//DSIV00001021                                            if ( 0 == CIMFWStrCmp(strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[n].lotID.identifier,
//DSIV00001021                                                                  effectedLots[o].lotID.identifier) )
//PSIV00001648//DSIV00001021 add start
//PSIV00001648                                            if ( 0 == CIMFWStrCmp(strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[n].lotID.identifier, effectedLots[o].lotID.identifier)
//PSIV00001648                                                && 0 == CIMFWStrCmp(strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[n].routeID.identifier, strProcessOperationInfo.mainPDID.identifier)
//PSIV00001648                                                && 0 == CIMFWStrCmp(strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[n].opeNo, strProcessOperationInfo.opeNo))
//PSIV00001648//DSIV00001021 add end
                                            if ( 0 == CIMFWStrCmp( strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[n].lotID.identifier,   effectedLots[o].lotID.identifier )               //PSIV00001648
                                              && 0 == CIMFWStrCmp( strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[n].routeID.identifier, strProcessOperationInfo.mainPDID.identifier )    //PSIV00001648
                                              && 0 == CIMFWStrCmp( strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[n].opeNo,              strProcessOperationInfo.opeNo ) )                //PSIV00001648
                                            {
                                                PPT_METHODTRACE_V1("", "set findLotFlag = TRUE");
                                                mailIdx = n;                                                                                                                            //PSIV00001648
                                                msg_countPerMonLot = strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[n].reasonCodeSeq.length();    //PSIV00001648
                                                findLotFlag = TRUE;
                                                break;
                                            }
                                        }

                                        if ( findLotFlag == FALSE )
                                        {
                                            PPT_METHODTRACE_V1("", "findLotFlag == FALSE");

//PSIV00001648                                            lot_countForMailOtherFab++;
//PSIV00001648                                            strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq.length( lot_countForMailOtherFab );
//PSIV00001648                                            strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[lot_countForMailOtherFab-1].lotID = effectedLots[o].lotID;
//PSIV00001648                                            strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[lot_countForMailOtherFab-1].equipmentID = strProcessOperationInfo.asgnEqpID;
//PSIV00001648                                            strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[lot_countForMailOtherFab-1].routeID = strProcessOperationInfo.mainPDID;
//PSIV00001648                                            strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[lot_countForMailOtherFab-1].opeNo = strProcessOperationInfo.opeNo;
//PSIV00001648
//PSIV00001648                                            msg_countPerMonLot++;
//PSIV00001648                                            strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[lot_countForMailOtherFab-1].messageIDSeq.length( msg_countPerMonLot );
//PSIV00001648                                            strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[lot_countForMailOtherFab-1].messageIDSeq[msg_countPerMonLot-1].identifier = CIMFWStrDup( SP_MessageID_SpecCheckOver );
//PSIV00001648                                            strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[lot_countForMailOtherFab-1].reasonCodeSeq.length( msg_countPerMonLot );
//PSIV00001648                                            strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[lot_countForMailOtherFab-1].reasonCodeSeq[msg_countPerMonLot-1] = messageReason;
//PSIV00001648 Add Start
                                            mailIdx = lot_countForMailOtherFab++;
                                            msg_countPerMonLot = 0;
                                            strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq.length( lot_countForMailOtherFab );
                                            strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[mailIdx].lotID       = effectedLots[o].lotID;
                                            strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[mailIdx].equipmentID = strProcessOperationInfo.asgnEqpID;
                                            strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[mailIdx].routeID     = strProcessOperationInfo.mainPDID;
                                            strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[mailIdx].opeNo       = strProcessOperationInfo.opeNo;
//PSIV00001648 Add End
//DSIV00001021 add start
                                            //-----------------------------------------------------------------------------
                                            // Add ActionResultInfo
                                            //-----------------------------------------------------------------------------
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo.length( dcActionInfo_count + 1 );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].lotID                  = effectedLots[o].lotID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].monitorLotFlag         = monitorLotFlag;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcDefID                = strDCDef.dataCollectionDefinitionID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].dcSpecID               = strDCDef.dataCollectionSpecificationID;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].checkType              = CIMFWStrDup( SP_ActionResult_CheckType_SPEC );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reasonCode             = messageReason;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].actionCode             = CIMFWStrDup( SP_ActionCode_Mail );
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].correspondingObjrefPO  = effectedLots[0].processOperation;
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].bankID                 = CIMFWStrDup("");
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].reworkRouteID          = CIMFWStrDup("");
                                            strDCActionLotResult[dcActionLot_idx].strDCActionResultInfo[dcActionInfo_count].entities.length(0);
                                            dcActionInfo_count++;
//DSIV00001021 add end
                                        }
//PSIV00001648                                        else    //findLotFlag == TRUE
//PSIV00001648                                        {
//PSIV00001648                                            //keep current msg count
//PSIV00001648                                            msg_countPerMonLot = strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[n].reasonCodeSeq.length();
//PSIV00001648
//PSIV00001648                                            //check same message exist?
//PSIV00001648                                            for ( p = 0; p < msg_countPerMonLot; p++ )
//PSIV00001648                                            {
//PSIV00001648                                                if ( 0 == CIMFWStrCmp( strInterFabMonitorGroupActionInfoSequence[rel_mong_count - 1].strMonitoredLotMailInfoSeq[n].reasonCodeSeq[p], reasonCode ) )
//PSIV00001648                                                {
//PSIV00001648                                                    findMsgFlag = TRUE;
//PSIV00001648                                                    break;
//PSIV00001648                                                }
//PSIV00001648                                            }
//PSIV00001648
//PSIV00001648                                            if ( findMsgFlag == FALSE )
//PSIV00001648                                            {
//PSIV00001648                                                PPT_METHODTRACE_V1("", "findMsgFlag == FALSE");
//PSIV00001648                                                msg_countPerMonLot++;
//PSIV00001648                                                strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[n].messageIDSeq.length( msg_countPerMonLot );
//PSIV00001648                                                strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[n].messageIDSeq[msg_countPerMonLot-1].identifier =  CIMFWStrDup( SP_MessageID_SpecCheckOver );
//PSIV00001648                                                strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[n].reasonCodeSeq.length( msg_countPerMonLot );
//PSIV00001648                                                strInterFabMonitorGroupActionInfoSequence[rel_mong_count-1].strMonitoredLotMailInfoSeq[n].reasonCodeSeq[msg_countPerMonLot-1] = messageReason;
//PSIV00001648                                            }
//PSIV00001648                                        }
//PSIV00001648 Add Start
                                        //check same message exist?
                                        for ( p = 0; p < msg_countPerMonLot; p++ )
                                        {
                                            if ( 0 == CIMFWStrCmp( strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[mailIdx].reasonCodeSeq[p], reasonCode ) )
                                            {
                                                findMsgFlag = TRUE;
                                                break;
                                            }
                                        }

                                        if ( findMsgFlag == FALSE )
                                        {
                                            PPT_METHODTRACE_V1("", "findMsgFlag == FALSE");
                                            msg_countPerMonLot++;
                                            strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[mailIdx].messageIDSeq.length( msg_countPerMonLot );
                                            strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[mailIdx].messageIDSeq[msg_countPerMonLot-1].identifier =  CIMFWStrDup( SP_MessageID_SpecCheckOver );
                                            strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[mailIdx].reasonCodeSeq.length( msg_countPerMonLot );
                                            strInterFabMonitorGroupActionInfoSequence[interFabMonIdx].strMonitoredLotMailInfoSeq[mailIdx].reasonCodeSeq[msg_countPerMonLot-1] = messageReason;
                                        }
//PSIV00001648 Add End
                                    }
//DSIV00000214 add end
                                }
//DSIV00001365 add start
                                //-----------------------------------------------------------------------------
                                // Set Entity Inhibit Reason Detail Information
                                //-----------------------------------------------------------------------------
                                objProcessOperation_Info_GetDR_out strProcessOperation_Info_GetDR_out;
                                objProcessOperation_Info_GetDR_in  strProcessOperation_Info_GetDR_in;
                                if ( monitorLotFlag == TRUE && requestOtherFabFlag == TRUE )                                    //DSIV00001021
                                {                                                                                               //DSIV00001021
                                    strProcessOperation_Info_GetDR_in.poObj = effectedLots[0].processOperation;                 //DSIV00001021
                                }                                                                                               //DSIV00001021
                                else                                                                                            //DSIV00001021
                                {                                                                                               //DSIV00001021
                                    strProcessOperation_Info_GetDR_in.poObj = effectedLots[o].processOperation;
                                }                                                                                               //DSIV00001021
                                rc = processOperation_Info_GetDR( strProcessOperation_Info_GetDR_out, strObjCommonIn,
                                                                  strProcessOperation_Info_GetDR_in );
                                if ( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V2("", "processOperation_info_GetDR() != RC_OK", rc);
                                    strStartLot_actionList_EffectSpecCheck_out.strResult = strProcessOperation_Info_GetDR_out.strResult;
                                    return rc;
                                }
                                for ( eCnt = entity_count_keep; eCnt < entity_count; eCnt++ )
                                {
                                    strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[eCnt].strEntityInhibitReasonDetailInfos.length(1);
                                    strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[eCnt].strEntityInhibitReasonDetailInfos[0].relatedLotID
                                        = CIMFWStrDup( strStartCassette[i].strLotInCassette[j].lotID.identifier );
                                    strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[eCnt].strEntityInhibitReasonDetailInfos[0].relatedControlJobID
                                        = CIMFWStrDup( controlJobID );
                                    strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[eCnt].strEntityInhibitReasonDetailInfos[0].relatedFabID
                                        = CIMFWStrDup("");
                                    strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[eCnt].strEntityInhibitReasonDetailInfos[0].relatedRouteID
                                        = CIMFWStrDup( strProcessOperation_Info_GetDR_out.strProcessOperationInfo.mainPDID.identifier );
                                    strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[eCnt].strEntityInhibitReasonDetailInfos[0].relatedProcessDefinitionID
                                        = CIMFWStrDup( strProcessOperation_Info_GetDR_out.strProcessOperationInfo.pdID.identifier );
                                    strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[eCnt].strEntityInhibitReasonDetailInfos[0].relatedOperationNumber
                                        = CIMFWStrDup( strProcessOperation_Info_GetDR_out.strProcessOperationInfo.opeNo );
                                    strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[eCnt].strEntityInhibitReasonDetailInfos[0].relatedOperationPassCount
                                        = CIMFWStrDup( strProcessOperation_Info_GetDR_out.strProcessOperationInfo.passCount );
                                }   

                                // For Other Fab
                                for ( eCnt = entity_countForOtherFab_keep; eCnt < entity_countForOtherFab; eCnt++ )
                                {
                                    strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[eCnt].strEntityInhibitReasonDetailInfos.length(1);
                                    strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[eCnt].strEntityInhibitReasonDetailInfos[0].relatedLotID
                                        = CIMFWStrDup( strStartCassette[i].strLotInCassette[j].lotID.identifier );
                                    strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[eCnt].strEntityInhibitReasonDetailInfos[0].relatedControlJobID
                                        = CIMFWStrDup( controlJobID );
                                    strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[eCnt].strEntityInhibitReasonDetailInfos[0].relatedFabID
                                        = CIMFWStrDup( currentFabID );
                                    strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[eCnt].strEntityInhibitReasonDetailInfos[0].relatedRouteID
                                        = CIMFWStrDup( strProcessOperation_Info_GetDR_out.strProcessOperationInfo.mainPDID.identifier );
                                    strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[eCnt].strEntityInhibitReasonDetailInfos[0].relatedProcessDefinitionID
                                        = CIMFWStrDup( strProcessOperation_Info_GetDR_out.strProcessOperationInfo.pdID.identifier );
                                    strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[eCnt].strEntityInhibitReasonDetailInfos[0].relatedOperationNumber
                                        = CIMFWStrDup( strProcessOperation_Info_GetDR_out.strProcessOperationInfo.opeNo );
                                    strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitionsWithFabInfo[eCnt].strEntityInhibitReasonDetailInfos[0].relatedOperationPassCount
                                        = CIMFWStrDup( strProcessOperation_Info_GetDR_out.strProcessOperationInfo.passCount );
                                }
//DSIV00001021 indent move end
//DSIV00001365 add end
                            }  //CorrespondingOperation loop poCnt  //DSIV00001021
                        }  //effectedLots loop o
                    }   //P3000162  //dcitem loop m
                }  //dcdef loop k
            }  // lot loop j
        }  // cast loop i

        strStartLot_actionList_EffectSpecCheck_out.strInterFabMonitorGroupActionInfoSequence = strInterFabMonitorGroupActionInfoSequence;    //DSIV00000214

        strStartLot_actionList_EffectSpecCheck_out.strDCActionLotResult                      = strDCActionLotResult;                         //DSIV00001021
        PPT_METHODTRACE_V2("", "dcActionLot_count", dcActionLot_count);                                                                      //DSIV00001021

        //INN-R170016 Add Start
        for ( i = 0; i < scLen; i++ )
        {
            CORBA::Long lenStartCassette = strStartCassette[i].strLotInCassette.length();
            for ( j = 0; j < lenStartCassette; j++ )
            {
                //---------------------------
                // Omit Not-OpeStart Lot
                //---------------------------
                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE ||
                    CIMFWStrCmp(strStartCassette[i].strLotInCassette[j].lotType, SP_Lot_Type_ProductionLot) == 0 )
                {
                    PPT_METHODTRACE_V1("", "operationStartFlag == FALSE or ProductionLot");
                    continue;
                }

                //---------------------------
                // Omit Non-DataCollection
                //---------------------------
                CORBA::Long lenDCDef = strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef.length();
                if ( 0 == lenDCDef )
                {
                    PPT_METHODTRACE_V1("", "lenDCDef.length == 0");
                    continue;
                }

                csObjEqpMonitorInventory_ListGetDR_in strEqpMonitorInventory_ListGetDR_in;
                strEqpMonitorInventory_ListGetDR_in.npwType = CS_EqpMonitor_NPW_Type_Recycle;
                strEqpMonitorInventory_ListGetDR_in.productID = strStartCassette[i].strLotInCassette[j].productID.identifier;

                csObjEqpMonitorInventory_ListGetDR_out strEqpMonitorInventory_ListGetDR_out;
                rc = cs_eqpMonitorInventory_ListGetDR(strEqpMonitorInventory_ListGetDR_out,
                                             strObjCommonIn,
                                             strEqpMonitorInventory_ListGetDR_in);

                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "cs_eqpMonitorInventory_list_GetDR() rc != RC_OK");
                    strStartLot_actionList_EffectSpecCheck_out.strResult = strEqpMonitorInventory_ListGetDR_out.strResult;
                    return rc;
                }

                if (strEqpMonitorInventory_ListGetDR_out.strEqpMonitorInventoryInfoSeq.length() == 0)
                {
                    PPT_METHODTRACE_V1("", "not Monitor Recycle Product");
                    continue;
                }

                //-----------------------------------------
                //  Get downgrade items
                //-----------------------------------------
                csObjDowngradeItemList_GetDR_in strDowngradeItemList_GetDR_in;
                csObjDowngradeItemList_GetDR_out strDowngradeItemList_GetDR_out;
                rc = cs_downgradeItemList_GetDR(strDowngradeItemList_GetDR_out,
                                             strObjCommonIn,
                                             strDowngradeItemList_GetDR_in);

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "cs_downgradeItemList_GetDR() rc != RC_OK");
                    strStartLot_actionList_EffectSpecCheck_out.strResult = strDowngradeItemList_GetDR_out.strResult;
                    return rc;
                }
                csDowngradeItemSequence& strDowngradeItemSeq = strDowngradeItemList_GetDR_out.selectedDCItems;
                CORBA::Long dwgItemLen = strDowngradeItemSeq.length();
                
                CORBA::Long nWaferLen = strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                csWaferDowngradeValueSequence strWaferDowngradeValues;
                strWaferDowngradeValues.length(nWaferLen);

                //collect all data for wafers by format:
                //wafer1, data1, data2, data3 ...
                //wafer2, data1, data2, data3 ...
                //sequence of data1/data2... are defined by strDowngradeItemSeq (defID+itemName)
                for ( k = 0; k < nWaferLen; k++ )
                {
                    strWaferDowngradeValues[k].waferID = strStartCassette[i].strLotInCassette[j].strLotWafer[k].waferID;
                    strWaferDowngradeValues[k].dataValues.length(dwgItemLen);
                }

                PPT_METHODTRACE_V2("", "lenDCDef-------------->", lenDCDef);
                for ( k = 0; k < lenDCDef; k++ )
                {
                    PPT_METHODTRACE_V2("", "counter k -------------->", k);
                    const pptDCDef& strDCDef = strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k];

                    CORBA::Long lenDCItem = strDCDef.strDCItem.length();
                    PPT_METHODTRACE_V2("", "lenDCItem -------------->", lenDCItem);
                    for ( m = 0; m < lenDCItem; m++ )
                    {
                        PPT_METHODTRACE_V2("", "counter m -------------->", m);
                        for( n = 0; n < dwgItemLen; n++ )
                        {
                            if ( 0 == CIMFWStrCmp(strDowngradeItemSeq[n].dcDefID.identifier, strDCDef.dataCollectionDefinitionID.identifier)
                            && 0 == CIMFWStrCmp(strDowngradeItemSeq[n].dcItemName, strDCDef.strDCItem[m].dataCollectionItemName) )
                            {
                                PPT_METHODTRACE_V2("", "dataItem is defined as downgrade items", strDCDef.strDCItem[m].dataCollectionItemName);
                                for ( o = 0; o < nWaferLen; o++ )
                                {
                                    if ( 0 == CIMFWStrCmp(strWaferDowngradeValues[o].waferID.identifier, strDCDef.strDCItem[m].waferID.identifier) )
                                    {
                                        strWaferDowngradeValues[o].dataValues[n] = strDCDef.strDCItem[m].dataValue;
                                        break;
                                    }
                                }
                                break;
                            }
                        }
                    }
                }
                //-----------------------------------------
                //  Get downgrade value setting
                //-----------------------------------------
                CORBA::Long prefixLen = atol( getenv(CS_SP_DowngradeProduct_Prefix_Length) );
                if (prefixLen < 4)
                {
                    prefixLen = 4;
                }
                
                CORBA::Long nProdLen = CIMFWStrLen(strStartCassette[i].strLotInCassette[j].productID.identifier);
                if (prefixLen > nProdLen)
                {
                    prefixLen = nProdLen;
                }
                
                char workBuff[66]; //product maximum length 64+%
                memset(workBuff, 0, sizeof(workBuff));
                CIMFWStrnCpy(workBuff, strStartCassette[i].strLotInCassette[j].productID.identifier, prefixLen);
                CIMFWStrCat(workBuff, "%");

                csObjDowngradeSettingList_GetDR_in strDowngradeSettingList_GetDR_in;
                strDowngradeSettingList_GetDR_in.productID = CIMFWStrDup(workBuff);
                PPT_METHODTRACE_V2("", "workBuff", workBuff);
                csObjDowngradeSettingList_GetDR_out strDowngradeSettingList_GetDR_out;
                rc = cs_downgradeSettingList_GetDR(strDowngradeSettingList_GetDR_out,
                                             strObjCommonIn,
                                             strDowngradeSettingList_GetDR_in);

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "cs_downgradeSettingList_GetDR() rc != RC_OK");
                    strStartLot_actionList_EffectSpecCheck_out.strResult = strDowngradeSettingList_GetDR_out.strResult;
                    return rc;
                }
                
                csDowngradeSettingInfoSequence& strDowngradeSettingInfoSeq = strDowngradeSettingList_GetDR_out.strDowngradeSettingInfoSeq;
                CORBA::Long dwgSettingLen = strDowngradeSettingInfoSeq.length();
                for ( k = 0; k < nWaferLen; k++ )
                {
                    for (CORBA::Long iItem = 0; iItem < dwgSettingLen; iItem++)
                    {
                        if ( (0 == CIMFWStrLen(strWaferDowngradeValues[k].dataValues[iItem])) ||
                             ( atof(strWaferDowngradeValues[k].dataValues[iItem]) < atof(strDowngradeSettingInfoSeq[iItem].dataValue1) ) )
                        {
                            PosWafer_var aPosWafer;
                            PPT_CONVERT_WAFERID_TO_WAFER_OR( aPosWafer,
                                                             strWaferDowngradeValues[k].waferID,
                                                             strStartLot_actionList_EffectSpecCheck_out,
                                                             startLot_actionList_EffectSpecCheck__101 );

                            SI_PPT_USERDATA_SET_STRING(aPosWafer, CS_M_WFR_Monitor_Grade, strDowngradeSettingInfoSeq[iItem].grade);
                            SI_PPT_USERDATA_SET_STRING(aPosWafer, CS_M_WFR_Downgrade_BankID, strDowngradeSettingInfoSeq[iItem].endBank);
                            SI_PPT_USERDATA_SET_STRING(aPosWafer, CS_M_WFR_Downgrade_Product, strDowngradeSettingInfoSeq[iItem].toGroductID);
                        }
                    }
                }
            } //for lotLen
        }
        //INN-R170016 Add End

        PPT_METHODTRACE_EXIT("PPTManager_i::startLot_actionList_EffectSpecCheck__101");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strStartLot_actionList_EffectSpecCheck_out, startLot_actionList_EffectSpecCheck__101, methodName)
}
