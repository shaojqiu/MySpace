#ifndef lint
static char *sccsid =  "@(#) 1.2 superpos/src/spppt/source/posppt/pptmgr/objmethd/reticlePod_transferState_Change__160.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 9/19/07 11:15:02 [ 9/21/07 17:50:26 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: cs_reticlePod_transferState_Change__160OR.cpp
//
#include "cs_pptmgr.hpp"//INN-R170003 
//INN-R170003  #include "pptmgr.hpp"

#include "ppcdr.hh"
#include "prtclp.hh"
#include "pperson.hh"

//[Object Function Name]: long   reticlePod_transferState_Change__160
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2001-01-31            O.Sugiyama     Initial Release        (D3100008)
// 2001-02-22  0.01      M.Mori         Add Change Reticle's Status
// 2001-03-15  P3100120  K.Kido         get ReticleInfo for ReticleState is scrapped or not
// 2001-12-05  P4100026  M.Shimizu      Last Claimed Timestamp in Reticle POD List is not changed by EI/EO.
// 2002-01-18  D4100081  Cinthia Jao    Add call DurableChangeEvent_Make
// 2002-02-04  D4100110  S.Tokumasu     Add timeStamp into xferStatusChangeRpt
// 2002-02-14  D4100110-1Y.Iwasaki      Bug fix for D4100110
// 2002-02-21  D4100110-2S.Tokumasu     Bug fix for D4100110
// 2002-03-01  D4100110-3S.Tokumasu     Bug fix for D4100110
// 2002-04-04  P4100317  K.Matsuei      There is a place where CIMFWStrDup shouldn't be used.
// 2002-04-05  P4100272  K.Matsuei      Check and fix MemoryLeak every transaction.
// 2003-02-18  P4200529  M.Kase         Remove ReticleState change logic when ReticleXferState was changed to 'EI'
// 2003/09/09  P5000145  H.Adachi       Fix Message and Message Macro mismatch.
// 2007/09/19  D9000084  K.Kido         Clear Xfer destination and reserved user.
//
// Date       Defect#      Person         Comments
// ---------- ------------ ------------- -------------------------------------------
// 2013/04/08 PSN000073094 JJ.Zhang      Can not set Stocker in FHDRCHS.LOCATION
// 2015/10/07 PSN000081321 T.Ishida      Claim Memo Improvement
//
//[Function Description]:
//  ReticlePod transfer status is reported by RXM or OPI.
//  When some reticles are in the reportede POD, those reticles' transfer status
//  must be changed to same status of POD's one.
//
//
//[Input Parameters]:
//  in  pptObjCommonIn       strObjCommonIn;     // Tx, DateTime, User
//  in  objectIdentifier     stockerID;
//  in  objectIdentifier     equipmentID;
//  in  objectIdentifier     reticlePodID;
//  in  string               transferStatus;
//  in  string               transferStatusChangeTimeStamp;
//  in  string               claimMemo;
//
//
//[Output Parameters]:
//  out objReticlePod_transferState_Change_out    strReticlePod_transferState_Change_out;
//
//  typedef struct objReticlePod_transferState_Change_out_struct {
//      pptRetCode           strResult;
//  } objReticlePod_transferState_Change_out;
//
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//
//D4100110 CORBA::Long  PPTManager_i::reticlePod_transferState_Change(
//D4100110             objReticlePod_transferState_Change_out&     strReticlePod_transferState_Change_out,
//D4100110             const pptObjCommonIn&                       strObjCommonIn,
//D4100110             const objectIdentifier&                     stockerID,
//D4100110             const objectIdentifier&                     equipmentID,
//D4100110             const objectIdentifier&                     reticlePodID,
//D4100110             const char*                                 transferStatus)

//INN-R170003 CORBA::Long  PPTManager_i::reticlePod_transferState_Change__160(
CORBA::Long  CS_PPTManager_i::reticlePod_transferState_Change__160( //INN-R170003 
            objReticlePod_transferState_Change_out&     strReticlePod_transferState_Change_out,
            const pptObjCommonIn&                       strObjCommonIn,
            const objectIdentifier&                     stockerID,
            const objectIdentifier&                     equipmentID,
            const objectIdentifier&                     reticlePodID,
            const char*                                 transferStatus,
//PSN000081321            const char*                                 transferStatusChangeTimeStamp)
            const char *                                transferStatusChangeTimeStamp,    //PSN000081321
            const char *                                claimMemo)                        //PSN000081321
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::reticlePod_transferState_Change__160");

        PPT_METHODTRACE_V2("", "in para stockerID     ", stockerID.identifier );
        PPT_METHODTRACE_V2("", "in para equipmentID   ", equipmentID.identifier );
        PPT_METHODTRACE_V2("", "in para reticlePodID  ", reticlePodID.identifier );
        PPT_METHODTRACE_V2("", "in para transferStatus", transferStatus );
        PPT_METHODTRACE_V2("", "in para claimMemo     ", claimMemo );    //PSN000081321
        
        CORBA::Long rc = RC_OK;                            // Initialize rc

        /*------------------------*/
        /*   Get Machine Object   */
        /*------------------------*/
        PosMachine_var aMachine;
        if (CIMFWStrLen( equipmentID.identifier ) != 0)
        {
            PPT_METHODTRACE_V1("", "CIMFWStrLen( equipmentID,identifier ) != 0");
            PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine, equipmentID, strReticlePod_transferState_Change_out, reticlePod_transferState_Change__160 );
        }

        /*------------------------*/
        /*   Get Stocker Object   */
        /*------------------------*/
        PosStorageMachine_var aStocker;
        if (CIMFWStrLen( stockerID.identifier ) != 0)
        {
            PPT_METHODTRACE_V1("", "CIMFWStrLen( stockerID.identifier ) != 0");
            PPT_CONVERT_STOCKERID_TO_STORAGEMACHINE_OR( aStocker, stockerID, strReticlePod_transferState_Change_out, reticlePod_transferState_Change__160 );
        }

        /*----------------------------*/
        /*   Get Reticle Pod Object   */
        /*----------------------------*/
        PosReticlePod_var aReticlePod;
        PPT_CONVERT_RETICLEPODID_TO_RETICLEPOD_OR( aReticlePod, reticlePodID, strReticlePod_transferState_Change_out, reticlePod_transferState_Change__160 );

        CORBA::String_var location;  //PSN000073094
        /*------------------------------------*/
        /*   Check In-Parm's Validity Check   */
        /*------------------------------------*/
        if (CIMFWStrCmp( transferStatus, SP_TransState_EquipmentIn ) == 0 ||
            CIMFWStrCmp( transferStatus, SP_TransState_EquipmentOut) == 0)
        {
            PPT_METHODTRACE_V1("", "transferStatus == ( EquipmentIn, EquipmentOut )");
            if (CORBA::is_nil( aMachine ) == TRUE)
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil( aMachine ) == TRUE");
                SET_MSG_RC( strReticlePod_transferState_Change_out, MSG_INVALID_DATA_COMBINATION, RC_INVALID_DATA_COMBINATION );
                return ( RC_INVALID_DATA_COMBINATION );
            }
            location = equipmentID.identifier;  //PSN000073094
        }
        else
        {
            PPT_METHODTRACE_V1("", "transferStatus != ( EquipmentIn, EquipmentOut )");
            if (CORBA::is_nil( aStocker ) == TRUE)
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil( aStocker ) == TRUE");
                SET_MSG_RC( strReticlePod_transferState_Change_out, MSG_INVALID_DATA_COMBINATION, RC_INVALID_DATA_COMBINATION );
                return ( RC_INVALID_DATA_COMBINATION );
            }
            location = stockerID.identifier;  //PSN000073094
        }

        if (CIMFWStrCmp( transferStatus, SP_TransState_StationIn        ) == 0 ||
            CIMFWStrCmp( transferStatus, SP_TransState_StationOut       ) == 0 ||
            CIMFWStrCmp( transferStatus, SP_TransState_BayIn            ) == 0 ||
            CIMFWStrCmp( transferStatus, SP_TransState_BayOut           ) == 0 ||
            CIMFWStrCmp( transferStatus, SP_TransState_ManualIn         ) == 0 ||
            CIMFWStrCmp( transferStatus, SP_TransState_ManualOut        ) == 0 ||
            CIMFWStrCmp( transferStatus, SP_TransState_EquipmentIn      ) == 0 ||
            CIMFWStrCmp( transferStatus, SP_TransState_EquipmentOut     ) == 0 ||
            CIMFWStrCmp( transferStatus, SP_TransState_ShelfIn          ) == 0 ||
            CIMFWStrCmp( transferStatus, SP_TransState_ShelfOut         ) == 0 ||
            CIMFWStrCmp( transferStatus, SP_TransState_IntermediateIn   ) == 0 ||
            CIMFWStrCmp( transferStatus, SP_TransState_IntermediateOut  ) == 0 ||
            CIMFWStrCmp( transferStatus, SP_TransState_AbnormalIn       ) == 0 ||
            CIMFWStrCmp( transferStatus, SP_TransState_AbnormalOut      ) == 0)
        {
            PPT_METHODTRACE_V1("", "transferStatus == (StationIn,StationOut,BayIn,BayOut,ManualIn,ManualOut,EquipmentIn,EquipmentOut,ShelfIn,ShelfOut,IntermediateIn,IntermediateOut,AbnormalIn,AbnormalOut");
            rc = RC_OK;
        }
        else
        {
            PPT_METHODTRACE_V1("", "transferStatus != (StationIn,StationOut,BayIn,BayOut,ManualIn,ManualOut,EquipmentIn,EquipmentOut,ShelfIn,ShelfOut,IntermediateIn,IntermediateOut,AbnormalIn,AbnormalOut");
            SET_MSG_RC( strReticlePod_transferState_Change_out, MSG_INVALID_DATA_COMBINATION, RC_INVALID_DATA_COMBINATION );
            return ( RC_INVALID_DATA_COMBINATION );
        }

//D9000084 add start
        /**********************************************/
        /*  Clear Xfer destination and reserved user  */
        /**********************************************/
        //=========================================================================
        // Get reserved destination (target) equipment
        //=========================================================================
        PosMachine_var aPosMachine;
        try
        {
            aPosMachine = aReticlePod->getTransferDestinationEquipment();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::getTransferDestinationEquipment);

        CORBA::String_var destinationMachine;
        if (!CORBA::is_nil(aPosMachine))
        {
            try
            {
                destinationMachine = aPosMachine->getIdentifier() ;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getIdentifier);
        }

        //=========================================================================
        // Clear reserved destination (target) machine if necessary
        //=========================================================================
        PosStorageMachine_var aPosStorageMachine;
        try
        {
            aPosStorageMachine = aReticlePod->getTransferDestinationStocker();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::getTransferDestinationStocker);

        CORBA::String_var destinationStocker;
        if (!CORBA::is_nil(aPosStorageMachine))
        {
            try
            {
                destinationStocker = aPosStorageMachine->getIdentifier();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosStorageMachine::getIdentifier);
        }

        //=========================================================================
        // Clear reserved destination machine if necessary
        //=========================================================================
        if( CIMFWStrCmp(equipmentID.identifier, destinationMachine ) == 0 )
        {
            PosMachine_var aNilMachine;
            PosPerson_var  aNilPerson;

            try
            {
                aReticlePod->setTransferDestinationEquipment(aNilMachine);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::setTransferDestinationEquipment);

            try
            {
                aReticlePod->setTransferReserveUser(aNilPerson);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::setTransferReserveUser);
        }
        else if ( CIMFWStrCmp(stockerID.identifier, destinationStocker ) == 0 )
        {
            PosStorageMachine_var aNilStorageMachine;
            PosPerson_var aNilPerson;

            try
            {
                aReticlePod->setTransferDestinationStocker(aNilStorageMachine);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::setTransferDestinationStocker);

            try
            {
                aReticlePod->setTransferReserveUser(aNilPerson);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::setTransferReserveUser);

        }
//D9000084 add end

        //D4100110 Start
        /*---------------------------------------*/
        /*   Check Cassette's XferChgTimeStamp   */
        /*---------------------------------------*/
//P4100272        CORBA::String xferStatChgTimeStamp;
        CORBA::String_var xferStatChgTimeStamp;  //P4100272
        try
        {
            xferStatChgTimeStamp = aReticlePod->getTransferStatusChangedTimeStamp();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::getTransferStatusChangedTimeStamp);
        
//P4100317        TimeStamp recordTimeStamp;
        CORBA::String_var recordTimeStamp;  //P4100317
        if(CIMFWStrLen(transferStatusChangeTimeStamp) == 0 )
        {
            PPT_METHODTRACE_V1("", "transferStatusChangeTimeStamp is NULL");
//P4100317            recordTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);
            recordTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;  //P4100317
        }
        else
        {
            PPT_METHODTRACE_V2("", "transferStatusChangeTimeStamp", transferStatusChangeTimeStamp);
//P4100317            recordTimeStamp = CIMFWStrDup(transferStatusChangeTimeStamp);
            recordTimeStamp = transferStatusChangeTimeStamp;  //P4100317
        }

        PPT_METHODTRACE_V2("", "xferStatChgTimeStamp         ", xferStatChgTimeStamp);
        PPT_METHODTRACE_V2("", "recordatChgTimeStamp         ", recordTimeStamp);      //D4100110-1

//D4100110-1 if(recordTimeStamp < xferStatChgTimeStamp)
        if ( CIMFWStrCmp(recordTimeStamp, xferStatChgTimeStamp) < 0 )                  //D4100110-1
        {
//D4100110-1PPT_METHODTRACE_V1("", "transferStatusChangeTimeStamp < xferStatChgTimeStamp!");
            PPT_METHODTRACE_V1("", "recordTimeStamp < xferStatChgTimeStamp!");         //D4100110-1
            PPT_METHODTRACE_V1("", "XferStat is not updated. becouse it is old event!!");

            //D4100110-3 Start
            /*---------------------------------------------*/
            /*   D4100081  Create Durable Change Event     */
            /*---------------------------------------------*/
            objDurableXferStatusChangeEvent_Make_out   strDurableXferStatusChangeEvent_Make_out;
            rc = durableXferStatusChangeEvent_Make(strDurableXferStatusChangeEvent_Make_out,
                                         strObjCommonIn, 
                                         "", 
                                         reticlePodID, 
                                         SP_DurableCat_ReticlePod,
                                         SP_DurableEvent_Action_XferStateChange,
                                         "",
                                         transferStatus,
                                         recordTimeStamp,
//PSN000073094                           equipmentID.identifier,
                                         location, //PSN000073094
//PSN000081321                                         "") ;
                                         claimMemo) ;    //PSN000081321
            
            if( rc )
            {
                PPT_METHODTRACE_V1("", "rc != RC_OK")
                strReticlePod_transferState_Change_out.strResult = strDurableXferStatusChangeEvent_Make_out.strResult ;
//P5000145                PPT_SET_MSG_RC_KEY(strReticlePod_transferState_Change_out, MSG_FAIL_MAKE_HISTORY, rc ,reticlePodID.identifier);
                SET_MSG_RC( strReticlePod_transferState_Change_out, MSG_FAIL_MAKE_HISTORY, rc );    //P5000145
                return rc ;
            }
            //D4100110-3 End

            return( RC_OK );
        }
        //--- set TimeStamp
        try
        {
            aReticlePod->setTransferStatusChangedTimeStamp(recordTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::setTransferStatusChangeTimeStamp);

        //D4100110 End

        /*-----------------------------------------*/
        /*   Update ReticlePod's Transfer Status   */
        /*-----------------------------------------*/
        try
        {
            aReticlePod->setTransferStatus( transferStatus );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::setTransferStatus);

        /*---------------------------*/
        /*   Set AssignedToMachine   */
        /*---------------------------*/
        if (CIMFWStrCmp( transferStatus, SP_TransState_EquipmentIn ) == 0 ||
            CIMFWStrCmp( transferStatus, SP_TransState_EquipmentOut) == 0)
        {
            PPT_METHODTRACE_V1("", "transferStatus == (EquipmentIn,EquipmentOut)");
            try
            {
                aReticlePod->assign_toMachine( aMachine );
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::assign_toMachine);
        }
        else
        {
            PPT_METHODTRACE_V1("", "transferStatus != (EquipmentIn,EquipmentOut)");
            try
            {
                aReticlePod->assign_toMachine( aStocker );
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::assign_toMachine);
        }
        
//D4100110        /*---------------------------------------------*/
//D4100110        /*   D4100081  Create Durable Change Event     */
//D4100110        /*---------------------------------------------*/
//D4100110        objDurableChangeEvent_Make_out strDurableChangeEvent_Make_out;
//D4100110        rc = durableChangeEvent_Make(strDurableChangeEvent_Make_out,
//D4100110                                     strObjCommonIn, 
//D4100110                                     "", 
//D4100110                                     reticlePodID, 
//D4100110                                     SP_DurableCat_ReticlePod,
//D4100110                                     SP_DurableEvent_Action_XferStateChange,
//D4100110                                     "") ;
//D4100110        
//D4100110        if( rc )
//D4100110        {
//D4100110            PPT_METHODTRACE_V1("", "rc != RC_OK")
//D4100110            strReticlePod_transferState_Change_out.strResult = strDurableChangeEvent_Make_out.strResult ;
//D4100110            PPT_SET_MSG_RC_KEY(strReticlePod_transferState_Change_out, MSG_FAIL_MAKE_HISTORY, rc ,reticlePodID.identifier);
//D4100110            return rc ;
//D4100110        }
        // D4100081 End

        // D4100110 Start
        /*---------------------------------------------*/
        /*   D4100081  Create Durable Change Event     */
        /*---------------------------------------------*/
        objDurableXferStatusChangeEvent_Make_out   strDurableXferStatusChangeEvent_Make_out;
        rc = durableXferStatusChangeEvent_Make(strDurableXferStatusChangeEvent_Make_out,
                                     strObjCommonIn, 
                                     "", 
                                     reticlePodID, 
                                     SP_DurableCat_ReticlePod,
                                     SP_DurableEvent_Action_XferStateChange,
                                     "",
                                     transferStatus,
//D4100110-3                         transferStatusChangeTimeStamp,
                                     recordTimeStamp,
//PSN000073094                       equipmentID.identifier,
                                     location, //PSN000073094
//PSN000081321                                     "") ;
                                     claimMemo) ;    //PSN000081321
        
        if( rc )
        {
            PPT_METHODTRACE_V1("", "rc != RC_OK")
            strReticlePod_transferState_Change_out.strResult = strDurableXferStatusChangeEvent_Make_out.strResult ;
//P5000145            PPT_SET_MSG_RC_KEY(strReticlePod_transferState_Change_out, MSG_FAIL_MAKE_HISTORY, rc ,reticlePodID.identifier);
            SET_MSG_RC( strReticlePod_transferState_Change_out, MSG_FAIL_MAKE_HISTORY, rc );    //P5000145
            return rc ;
        }
        // D4100110 End

        /*-------------------------------------*/
        /*   Get Reticle List for ReticlePod   */
        /*-------------------------------------*/
        objReticlePod_reticleList_GetDR_out strReticlePod_reticleList_GetDR_out;
        rc = reticlePod_reticleList_GetDR( strReticlePod_reticleList_GetDR_out,
                                           strObjCommonIn,
                                           reticlePodID );     //new
        if ( rc != RC_OK )
        {
            strReticlePod_transferState_Change_out.strResult = strReticlePod_reticleList_GetDR_out.strResult;
            return ( rc );
        }
        CORBA::Long nLenReticleID = strReticlePod_reticleList_GetDR_out.reticleID.length();
        PPT_METHODTRACE_V2("", "nLenReticleID", nLenReticleID );
        for ( CORBA::Long i=0 ; i<nLenReticleID; i++ )
        {
            if (CIMFWStrLen( strReticlePod_reticleList_GetDR_out.reticleID[i].identifier) == 0 )
                continue;

            PPT_METHODTRACE_V3("", "reticleID", i, strReticlePod_reticleList_GetDR_out.reticleID[i].identifier );
            /*------------------------*/
            /*   Get Reticle Object   */
            /*------------------------*/
            PosProcessDurable_var aReticle;
            PPT_CONVERT_RETICLEID_TO_RETICLE_OR( aReticle, strReticlePod_reticleList_GetDR_out.reticleID[i], 
                                                 strReticlePod_transferState_Change_out, reticlePod_transferState_Change__160 );

//0.01 add start
            /*--------------------------------------*/
            /*   Get Reticle's Transfer Status   */
            /*--------------------------------------*/
            CORBA::String_var strReticleTransferStatus;
            try
            {
                strReticleTransferStatus = aReticle->getTransportState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::getTransferStatus);

            PPT_METHODTRACE_V2("","Reticle transferStatus", strReticleTransferStatus)
//0.01 add end

//P3100120 add start
            /*-------------------------*/
            /*   Get Reticle Status    */
            /*-------------------------*/
            CORBA::String_var strReticleState;
            try
            {
                strReticleState = aReticle->getDurableState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::getDurableState);

            PPT_METHODTRACE_V2("","Reticle Status", strReticleState)
//P3100120 add end
            /*--------------------------------------*/
            /*   Update Reticle's Transfer Status   */
            /*--------------------------------------*/
            try
            {
                aReticle->setTransportState( transferStatus );
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::setTransferStatus);
            /*---------------------------*/
            /*   Set AssignedToMachine   */
            /*---------------------------*/
            if (CIMFWStrCmp( transferStatus, SP_TransState_EquipmentIn ) == 0 ||
                CIMFWStrCmp( transferStatus, SP_TransState_EquipmentOut) == 0)
            {
                PPT_METHODTRACE_V1("", "transferStatus == (EquipmentIn,EquipmentOut)");
                try
                {
                    aReticle->assign_toMachine( aMachine );
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::assign_toMachine);
//INN-R170003 Start
                if(CIMFWStrCmp( transferStatus, SP_TransState_EquipmentIn ) == 0)
                {
                    try
                    {
                        SI_PPT_USERDATA_SET_STRING(aReticle,CS_M_RTCL_EQUIPMENTIN_TIME,
                                                   strObjCommonIn.strTimeStamp.reportTimeStamp);
                        PPT_METHODTRACE_V2("", "set aReticle CS_M_RTCL_EQUIPMENTIN_TIME", strObjCommonIn.strTimeStamp.reportTimeStamp);
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setUserDataNamed);
                   
                }
                if(CIMFWStrCmp( transferStatus, SP_TransState_EquipmentOut) == 0)
                {
                    try
                    {
                        SI_PPT_USERDATA_SET_STRING(aReticle,CS_M_RTCL_EQUIPMENTOUT_TIME,
                                                   strObjCommonIn.strTimeStamp.reportTimeStamp);
                        PPT_METHODTRACE_V2("", "set aReticle CS_M_RTCL_EQUIPMENTOUT_TIME", strObjCommonIn.strTimeStamp.reportTimeStamp);
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setUserDataNamed);

                    /*----------------------------------------------------*/
                    /*   Calcurate Run Time from EO and update EI NULL    */
                    /*----------------------------------------------------*/
                    try
                    {   
                        CORBA::String_var EquipmentInTimeStamp;
                        try
                        {
                            SI_PPT_USERDATA_GET_STRING(aReticle,
                                CS_M_RTCL_EQUIPMENTIN_TIME,
                                EquipmentInTimeStamp);
                            PPT_METHODTRACE_V2("", "SI_PPT_USERDATA_GET_STRING CS_M_RTCL_EQUIPMENTIN_TIME---------------->", EquipmentInTimeStamp);
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getUserDataNamed);
                        
                        PPT_METHODTRACE_V2("", "strObjCommonIn.strTimeStamp.reportTimeStamp", strObjCommonIn.strTimeStamp.reportTimeStamp);

                        if (EquipmentInTimeStamp != NULL && CIMFWStrLen(EquipmentInTimeStamp) != 0)
                        {
                            PPT_METHODTRACE_V1("", "EquipmentInTimeStamp != NULL && CIMFWStrLen(EquipmentInTimeStamp) != 0");
                            
                            TimeStampImpl aTimeStamp( strObjCommonIn.strTimeStamp.reportTimeStamp );
                            DurationImpl aDuration;
                            aDuration = aTimeStamp.substractTimeStamp( EquipmentInTimeStamp );
                            try
                            {
                                aReticle->setDurationUsed( aDuration );
                                PPT_METHODTRACE_V2("", "aReticle->setDurationUsed---------------------->", aDuration);                                    
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setDurationUsed) ;
                            try
                            {
                                SI_PPT_USERDATA_SET_STRING(aReticle,CS_M_RTCL_EQUIPMENTIN_TIME,"");
                                PPT_METHODTRACE_V1("", "set aReticle->CS_M_RTCL_EQUIPMENTIN_TIME null");                                    
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setUserDataNamed) ;
                        }
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getUserDataNamed);
                }
                //INN-R170003 End
            }
            else
            {
                PPT_METHODTRACE_V1("", "transferStatus != (EquipmentIn,EquipmentOut)");
                try
                {
                    aReticle->assign_toMachine( aStocker );
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::assign_toMachine);
            }
            
            /*---------------------------------------------*/
            /*   D4100081  Create Durable Change Event     */
            /*---------------------------------------------*/
//D4100110-2            objDurableChangeEvent_Make_out strDurableChangeEvent_Make_out;
//D4100110-2            rc = durableChangeEvent_Make(strDurableChangeEvent_Make_out,
//D4100110-2                                         strObjCommonIn, 
//D4100110-2                                         "", 
//D4100110-2                                         strReticlePod_reticleList_GetDR_out.reticleID[i], 
//D4100110-2                                         SP_DurableCat_Reticle,
//D4100110-2                                         SP_DurableEvent_Action_XferStateChange,
//D4100110-2                                         "") ;
//D4100110-2            
//D4100110-2            if( rc )
//D4100110-2            {
//D4100110-2                PPT_METHODTRACE_V1("", "rc != RC_OK")
//D4100110-2                strReticlePod_transferState_Change_out.strResult = strDurableChangeEvent_Make_out.strResult ;
//D4100110-2                PPT_SET_MSG_RC_KEY(strReticlePod_transferState_Change_out, MSG_FAIL_MAKE_HISTORY, rc ,strReticlePod_reticleList_GetDR_out.reticleID[i].identifier);
//D4100110-2                return rc ;
//D4100110-2            }
//D4100110-2            // D4100081 End
//D4100110-2
            //D4100110-2 Start
            /*-----------------------------------*/
            /*   Create Durable Change Event     */
            /*-----------------------------------*/
            objDurableXferStatusChangeEvent_Make_out   strDurableXferStatusChangeEvent_Make_out;
            rc = durableXferStatusChangeEvent_Make(strDurableXferStatusChangeEvent_Make_out,
                                         strObjCommonIn, 
                                         "", 
                                         strReticlePod_reticleList_GetDR_out.reticleID[i],
                                         SP_DurableCat_Reticle,
                                         SP_DurableEvent_Action_XferStateChange,
                                         "",
                                         transferStatus,
//D4100110-3                             transferStatusChangeTimeStamp,
                                         recordTimeStamp,
//PSN000073094                           equipmentID.identifier,
                                         location, //PSN000073094
//PSN000081321                                         "") ;
                                         claimMemo) ;    //PSN000081321
            
            if( rc )
            {
                PPT_METHODTRACE_V1("", "rc != RC_OK")
                strReticlePod_transferState_Change_out.strResult = strDurableXferStatusChangeEvent_Make_out.strResult ;
//P5000145                PPT_SET_MSG_RC_KEY(strReticlePod_transferState_Change_out, MSG_FAIL_MAKE_HISTORY, rc ,strReticlePod_reticleList_GetDR_out.reticleID[i].identifier);
                SET_MSG_RC( strReticlePod_transferState_Change_out, MSG_FAIL_MAKE_HISTORY, rc );    //P5000145
                return rc ;
            }
            // D4100110-2 End

//P3100120 add start
            if(CIMFWStrCmp(strReticleState,CIMFW_Durable_Scrapped) == 0       ||
                CIMFWStrCmp(strReticleState,CIMFW_Durable_NotAvailable) == 0  ||
                CIMFWStrCmp(strReticleState,CIMFW_Durable_Available) == 0)
            {
                PPT_METHODTRACE_V1("","Reticle Status not Change...")
            }
//P3100120 add end
//P3100120       if ( CIMFWStrCmp(transferStatus, SP_TransState_EquipmentIn) == 0 )
//0.01 add start
//P4200529            else if ( CIMFWStrCmp(transferStatus, SP_TransState_EquipmentIn) == 0 )
//P4200529            {
//P4200529                PPT_METHODTRACE_V1("","transferStatus == SP_TransState_EquipmentIn")
//P4200529
//P4200529                objReticle_state_Change_out strReticle_state_Change_out;
//P4200529                rc = reticle_state_Change( strReticle_state_Change_out,
//P4200529                                           strObjCommonIn,
//P4200529                                           strReticlePod_reticleList_GetDR_out.reticleID[i],
//P4200529                                           CIMFW_Durable_InUse);
//P4200529
//P4200529                if ( rc != RC_OK &&
//P4200529                     rc != RC_SAME_RETICLE_STAT )
//P4200529                {
//P4200529                    PPT_METHODTRACE_V1("", "reticle_status_Change() != RC_OK");
//P4200529                    strReticlePod_transferState_Change_out.strResult = strReticle_state_Change_out.strResult;
//P4200529                    return ( rc );
//P4200529                }
//P4200529                
//P4200529                /*---------------------------------------------*/
//P4200529                /*   D4100081  Create Durable Change Event     */
//P4200529                /*---------------------------------------------*/
//P4200529                objDurableChangeEvent_Make_out strDurableChangeEvent_Make_out;
//P4200529                rc = durableChangeEvent_Make(strDurableChangeEvent_Make_out,
//P4200529                                             strObjCommonIn, 
//P4200529                                             "", 
//P4200529                                             strReticlePod_reticleList_GetDR_out.reticleID[i], 
//P4200529                                             SP_DurableCat_Reticle,
//P4200529                                             SP_DurableEvent_Action_StateChange,
//P4200529                                             "") ;
//P4200529                
//P4200529                if( rc )
//P4200529                {
//P4200529                    PPT_METHODTRACE_V1("", "rc != RC_OK")
//P4200529                    strReticlePod_transferState_Change_out.strResult = strDurableChangeEvent_Make_out.strResult ;
//P4200529                    PPT_SET_MSG_RC_KEY(strReticlePod_transferState_Change_out, MSG_FAIL_MAKE_HISTORY, rc ,strReticlePod_reticleList_GetDR_out.reticleID[i].identifier);
//P4200529                    return rc ;
//P4200529                }
//P4200529                // D4100081 End
//P4200529                
//P4200529                
//P4200529            }
            else if( CIMFWStrCmp(strReticleTransferStatus, SP_TransState_EquipmentIn) == 0  &&
                     CIMFWStrCmp(transferStatus, SP_TransState_EquipmentIn) != 0 )
            {
                PPT_METHODTRACE_V1("", "strReticleTransferStatus == SP_TransState_EquipmentIn && transferStatus != SP_TransState_EquipmentOut")

                objReticle_state_Change_out strReticle_state_Change_out;
                rc = reticle_state_Change( strReticle_state_Change_out,
                                           strObjCommonIn,
                                           strReticlePod_reticleList_GetDR_out.reticleID[i],
                                           CIMFW_Durable_Available);

                if ( rc != RC_OK &&
                     rc != RC_SAME_RETICLE_STAT )
                {
                    PPT_METHODTRACE_V1("", "reticle_status_Change() != RC_OK");
                    strReticlePod_transferState_Change_out.strResult = strReticle_state_Change_out.strResult;
                    return ( rc );
                }
                
                /*---------------------------------------------*/
                /*   D4100081  Create Durable Change Event     */
                /*---------------------------------------------*/
                objDurableChangeEvent_Make_out strDurableChangeEvent_Make_out;
                rc = durableChangeEvent_Make(strDurableChangeEvent_Make_out,
                                             strObjCommonIn, 
                                             "TXPDR013", 
                                             strReticlePod_reticleList_GetDR_out.reticleID[i], 
                                             SP_DurableCat_Reticle,
                                             SP_DurableEvent_Action_StateChange,
                                             "") ;
                
                if( rc )
                {
                    PPT_METHODTRACE_V1("", "rc != RC_OK")
                    strReticlePod_transferState_Change_out.strResult = strDurableChangeEvent_Make_out.strResult ;
//P5000145                    PPT_SET_MSG_RC_KEY(strReticlePod_transferState_Change_out, MSG_FAIL_MAKE_HISTORY, rc ,strReticlePod_reticleList_GetDR_out.reticleID[i].identifier);
                    SET_MSG_RC( strReticlePod_transferState_Change_out, MSG_FAIL_MAKE_HISTORY, rc );    //P5000145
                    return rc ;
                }
                // D4100081 End
            }
//0.01 add end

        }

//P4100026 Add Start
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aReticlePod->setLastClaimedTimeStamp( strObjCommonIn.strTimeStamp.reportTimeStamp );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setLastClaimedTimeStamp);

        PosPerson_var aPerson;

        PPT_GET_PERSON_FROM_USERID( aPerson, strObjCommonIn.strUser.userID, strReticlePod_transferState_Change_out, reticlePod_transferState_Change__160 );
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aReticlePod->setLastClaimedPerson( aPerson );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setLastClaimedPerson);
//P4100026 Add End

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::reticlePod_transferState_Change__160");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS( strReticlePod_transferState_Change_out, reticlePod_transferState_Change__160, methodName );
}
