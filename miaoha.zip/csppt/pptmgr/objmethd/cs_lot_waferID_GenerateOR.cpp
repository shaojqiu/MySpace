#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/lot_waferID_Generate.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 20:13:23 [ 7/13/07 20:13:24 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: lot_waferID_Generate.cpp
//

//INN-R-170001 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp"//INN-R-170001

//[Object Function Name]: long   lot_waferID_Generate
//
// Date        Level    Author         Note
// ----------  -------- -------------  -------------------------------------------
// 2000/08/10           H.Katoh        Initial Release
// 2005/05/12  P6000464 H.Adachi       Add Null Clear For First Record of allocated memory.
//
//[Function Description]:
//  * Generate wafer ID for new Lot
//
//
//[Input Parameters]:
//  in  pptObjCommonIn          strObjCommonIn;
//  in  pptNewLotAttributes     strNewLotAttributes;
//
//[Output Parameters]:
//
//  out objLot_waferID_Generate_out  strLot_waferID_Generate_out;
//
//  typedef struct objLot_waferID_Generate_out_struct {
//      pptRetCode              strResult;
//      pptNewLotAttributes     strNewLotAttributes;
//  } objLot_waferID_Generate_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  -------------------------   --------------------------------------------------
//
//[Pseudo Code]:
//
// Class: CS_PPTManager
//
// Service: cs_lotType_lotID_Assign_GetDR()

// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/09/18 INN-R170001 Vera Chen      Lot ID naming rule
//


//INN-R-170001 CORBA::Long PPTManager_i::lot_waferID_Generate(
CORBA::Long CS_PPTManager_i::lot_waferID_Generate( //INN-R-170001
                        objLot_waferID_Generate_out& strLot_waferID_Generate_out,
                        const pptObjCommonIn& strObjCommonIn,
                        const pptNewLotAttributes& strNewLotAttributes )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::lot_waferID_Generate")

        //------------------------------------------------------------
        // In the begining, Copy input parameter ot output parameter
        //------------------------------------------------------------
        PPT_METHODTRACE_V1("CS_PPTManager_i::lot_waferID_Generate","In the begining, Copy input parameter ot output parameter");

        strLot_waferID_Generate_out.strNewLotAttributes = strNewLotAttributes;

        //------------------------------------------------------------
        // Generate wafer ID
        //------------------------------------------------------------
        CORBA::Long lenNewLotAttr = strLot_waferID_Generate_out.strNewLotAttributes.strNewWaferAttributes.length();
        CORBA::Long i;
        PPT_METHODTRACE_V2("CS_PPTManager_i::lot_waferID_Generate","Now Generating wafer ID", lenNewLotAttr);

        for ( i=0; i < lenNewLotAttr; i++ )
        {
            if(0 == CIMFWStrLen(strLot_waferID_Generate_out.strNewLotAttributes.strNewWaferAttributes[i].newLotID.identifier))
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i::lot_waferID_Generate","New Lot ID is Blank.");
                SET_MSG_RC(strLot_waferID_Generate_out, MSG_NEWLOTID_BLANK, RC_NEWLOTID_BLANK);
                return RC_NEWLOTID_BLANK;
            }

            //------------------------------------------------------------
            // generate wafer ID;
            //------------------------------------------------------------
            PPT_METHODTRACE_V2("CS_PPTManager_i::lot_waferID_Generate","Lot ID for Wafer ID Generate",
                               strLot_waferID_Generate_out.strNewLotAttributes.strNewWaferAttributes[i].newLotID.identifier);
            char tmpWaferID[256];
            char tmpWaferIDSeqNumber[128];
            //sprintf( tmpWaferID, "%s.%02ld",
            //         strLot_waferID_Generate_out.strNewLotAttributes.strNewWaferAttributes[i].newLotID.identifier,
            //         (i+1) );
            memset( tmpWaferID, '\0', sizeof(tmpWaferID) ); //INN-R-170001
            tmpWaferID[0] = NULL;    //P6000464
            
            sprintf (tmpWaferIDSeqNumber, "%02ld", (i+1));
//INN-R-170001            CIMFWStrCpy(tmpWaferID, strLot_waferID_Generate_out.strNewLotAttributes.strNewWaferAttributes[i].newLotID.identifier);
//INN-R-170001            CIMFWStrCat(tmpWaferID, ".");
            //INN-R-170001 Add start
            CIMFWStrnCpy(tmpWaferID,strLot_waferID_Generate_out.strNewLotAttributes.strNewWaferAttributes[i].newLotID.identifier, CIMFWStrLen(strLot_waferID_Generate_out.strNewLotAttributes.strNewWaferAttributes[i].newLotID.identifier) - 3);
            PPT_METHODTRACE_V2("CS_PPTManager_i::lot_waferID_Generate","tmpWaferID", tmpWaferID); 
            PPT_METHODTRACE_V2("CS_PPTManager_i::lot_waferID_Generate","tmpWaferIDSeqNumber", tmpWaferIDSeqNumber);
            //INN-R-170001 Add end
            CIMFWStrCat(tmpWaferID, tmpWaferIDSeqNumber);

            PPT_METHODTRACE_V2("CS_PPTManager_i::lot_waferID_Generate","Generated Wafer ID", tmpWaferID);

            //------------------------------------------------------------
            // Prepare output structure
            //------------------------------------------------------------
            strLot_waferID_Generate_out.strNewLotAttributes.strNewWaferAttributes[i].newWaferID.identifier
                = CIMFWStrDup(tmpWaferID);
        }

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::lot_waferID_Generate")

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_waferID_Generate_out, lot_waferID_Generate, methodName)
}
