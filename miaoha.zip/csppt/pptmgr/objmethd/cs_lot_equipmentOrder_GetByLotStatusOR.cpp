#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/lot_equipmentOrder_GetByLotStatus.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 20:06:09 [ 7/13/07 20:06:11 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_lot_equipmentOrder_GetByLotStatusOR.cpp
//

#include "cs_pptmgr.hpp"
#include "plot.hh"
#include "pctrlj.hh"
#include "ppcflwx.hh"
#include "ppcope.hh"
#include "ppcdf.hh"
#include "pstmc.hh"
#include "pbank.hh"

//
//[Object Function Name]: long   lot_equipmentOrder_GetByLotStatus
//
// Date        Level    Author         Note
// ----------  -------- -------------  -------------------------------------------------
// 2006-09-21  D8000028 K.Kido         Initial Release(R80) for where next improvement
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/11/04 DSIV00000214 K.Kido         Multi Fab Support.
//
// Innotron Modification history:
// Date       DCR/PCR No   Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/15 INN-R170003  Jun Zhang      New Transfer State PI/PO.
//
//[Function Description]
// This objmethod returns equipment priority order of lot.
// Obtained equipment list is decided as following rule.
//
// 1. If the input lot is on floor, lot queued machines are returned.
// 2. If the input lot is on flowbatch entry point, current operation machines are returned.
// 3. If the input lot is held, current operation machines are returned.
// 4. If the input lot is previous hold or floating batch,
//      - cassette transfer state SI/BI/AI/MI/II/HI, no machine list.
//      - EO and CJ not exist, cassette assigned machine is returned.    //INN-R17003
//      - Others(PO/SO...), previous operation's machines are returned.  //INN-R17003
// 5. If the input lot is bankIn,
//      - The bank does not have stocker and the cassette has equipment, then cassette assigned machine is returned.
//      - Others, no machine list.
//
//[Input Parameters]:
//  in  pptObjCommonIn    strObjCommonIn;
//  in  pptLotLocationInfo cassetteLocationInfo;
//  in  pptLotStatusInfo  lotStatus;
//
//[Output Parameters]:
//
//  out objLot_equipmentOrder_GetByLotStatus_out  strLot_equipmentOrder_GetByLotStatus_out;
//
//  typedef struct objLot_equipmentOrder_GetByLotStatus_out_struct {
//     pptRetCode                      strResult;
//     boolean                         notFoundAvailableEqp;
//     pptWhereNextEqpStatusSequence   strWhereNextEqpStatusSeq;
//  } objLot_equipmentOrder_GetByLotStatus_out;
//
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//  RC_NOT_FOUND_PRODUCTSPEC  MSG_NOT_FOUND_PRODUCTSPEC
//  RC_NOT_FOUND_PFX          MSG_NOT_FOUND_PFX
//  RC_NOT_FOUND_PO_FOR_LOT   MSG_NOT_FOUND_PO_FOR_LOT
//  RC_NOT_FOUND_PD           MSG_NOT_FOUND_PD
//  RC_NOT_FOUND_BANK         MSG_NOT_FOUND_BANK
//
CORBA::Long CS_PPTManager_i::lot_equipmentOrder_GetByLotStatus(
                            objLot_equipmentOrder_GetByLotStatus_out& strLot_equipmentOrder_GetByLotStatus_out,
                            const pptObjCommonIn&     strObjCommonIn,
                            const pptLotLocationInfo& cassetteLocationInfo,
                            const pptLotStatusInfo&   lotStatus)
{
    char * methodName = NULL;
    CORBA::Long rc = RC_OK;
    try
    {
        PPT_METHODTRACE_V2("", "### Inpara lotID = ", lotStatus.lotID.identifier );

        /*****************************/
        /*  Check input parameter.   */
        /*****************************/
        if( 0 == CIMFWStrLen(lotStatus.lotID.identifier) )
        {
            SET_MSG_RC(strLot_equipmentOrder_GetByLotStatus_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM);
            return RC_INVALID_INPUT_PARM;
        }

        objectIdentifierSequence eqpIDs;
        enum element{ setQueuedMachine, setOperationDispatchedMachine, setCassetteMachine, setNoMachine }el;
        CORBA::Long setMachineType = -1 ;
        objectIdentifier operationID;   //Set operationID for dispatch equipment
        CORBA::Boolean previousEquipmentFlag = FALSE;

        /*****************************/
        /* When Lot is on Floor.     */
        /*****************************/
        switch((lotStatus.onFloorFlag?1:0))
        {
            case 1:
            {
                PPT_METHODTRACE_V1("", "### The cassette is on floor." );
//DSIV00000214 add start
                /**********************************/
                /*  Check lot InterFabXfer plan   */
                /**********************************/
                //------------------------------
                //  Get Lot current operation
                //------------------------------
                objLot_currentOperationInfo_GetDR_out strLot_currentOperationInfo_GetDR_out;
                rc = lot_currentOperationInfo_GetDR( strLot_currentOperationInfo_GetDR_out,
                                                     strObjCommonIn,
                                                     lotStatus.lotID );

                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2(""," #### lot_currentOperationInfo_GetDR != RC_OK : rc = ", rc );
                    strLot_equipmentOrder_GetByLotStatus_out.strResult = strLot_currentOperationInfo_GetDR_out.strResult;
                    return rc;
                }

                //--------------------------------------
                //  Get original FabID
                //--------------------------------------
                const char* orgFabID = getenv(SP_FAB_ID);

                //--------------------------------------
                //  Check lot InterFab transfer plan
                //--------------------------------------
                objInterFab_xferPlanList_GetDR_out strInterFab_xferPlanList_GetDR_out;

                objInterFab_xferPlanList_GetDR_in  strInterFab_xferPlanList_GetDR_in;
                strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.lotID = lotStatus.lotID;
                strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalFabID = CIMFWStrDup(orgFabID);
                strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalRouteID = strLot_currentOperationInfo_GetDR_out.mainPDID;
                strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalOpeNumber = strLot_currentOperationInfo_GetDR_out.opeNo;

                rc = interFab_xferPlanList_GetDR( strInterFab_xferPlanList_GetDR_out, strObjCommonIn,
                                                  strInterFab_xferPlanList_GetDR_in );

                if( rc != RC_OK && rc != RC_INTERFAB_NOT_FOUND_XFERPLAN )
                {
                    PPT_METHODTRACE_V2(""," #### interFab_xferPlanList_GetDR != RC_OK : rc = ", rc );
                    strLot_equipmentOrder_GetByLotStatus_out.strResult = strInterFab_xferPlanList_GetDR_out.strResult;
                    return rc;
                }

                if(0 != strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq.length())
                {
                    if(  0 == CIMFWStrCmp(strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq[0].state, SP_InterFab_XferPlanState_Created)
                      || 0 == CIMFWStrCmp(strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq[0].state, SP_InterFab_XferPlanState_Canceled) )
                    {
                        PPT_METHODTRACE_V1("", " #### The cassette lots have InterFab Xfer plan. Get current machine.");
                        setMachineType = setCassetteMachine ;
                        break;
                    }
                }
//DSIV00000214 add end
                /********************************/
                /*                              */
                /*  Get queued machine List     */
                /*                              */
                /********************************/
                objLot_queuedMachines_GetByOperationOrder_out strLot_queuedMachines_GetByOperationOrder_out;
                rc = lot_queuedMachines_GetByOperationOrder( strLot_queuedMachines_GetByOperationOrder_out, strObjCommonIn,
                                                             lotStatus.lotID, 
                                                             lotStatus.productID );

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_queuedMachines_GetByOperationOrderDR() rc != RC_OK");
                    strLot_equipmentOrder_GetByLotStatus_out.strResult = strLot_queuedMachines_GetByOperationOrder_out.strResult;
                    return rc ;
                }

                CORBA::ULong nQueuedEqpLen = strLot_queuedMachines_GetByOperationOrder_out.queuedMachineSeq.length() ;
                if(nQueuedEqpLen)
                {
                    eqpIDs = strLot_queuedMachines_GetByOperationOrder_out.queuedMachineSeq ;
                    setMachineType = setQueuedMachine;
                    break;
                }

//DSIV00000214                /******************************/
//DSIV00000214                /*    Get lot current info    */
//DSIV00000214                /******************************/
//DSIV00000214                objLot_currentOperationInfo_GetDR_out strLot_currentOperationInfo_GetDR_out;
//DSIV00000214                rc = lot_currentOperationInfo_GetDR( strLot_currentOperationInfo_GetDR_out,
//DSIV00000214                                                     strObjCommonIn,
//DSIV00000214                                                     lotStatus.lotID );
//DSIV00000214                if( rc != RC_OK )
//DSIV00000214                {
//DSIV00000214                    PPT_METHODTRACE_V2(""," #### lot_currentOperationInfo_GetDR != RC_OK : rc = ", rc );
//DSIV00000214                    strLot_equipmentOrder_GetByLotStatus_out.strResult = strLot_currentOperationInfo_GetDR_out.strResult;
//DSIV00000214                    return rc;
//DSIV00000214                }

                /************************************/
                /*   FlowBatch-WaitingLot Support   */
                /************************************/
                if ( 0 == nQueuedEqpLen &&
                     0 == CIMFWStrCmp(lotStatus.currentStatus.holdState, CIMFW_Lot_HoldState_NotOnHold) &&
                     0 == CIMFWStrCmp(lotStatus.currentStatus.processState, SP_Lot_ProcState_Waiting) )
                {
                    PPT_METHODTRACE_V1("", "nQueuedEqpLen is 0 , Lot is NotOnHold , Lot is Waiting ---> FlowBatchWaitingLot!!");

                    objProcess_flowBatchDefinition_GetDR_out strProcess_flowBatchDefinition_GetDR_out;
                    rc = process_flowBatchDefinition_GetDR( strProcess_flowBatchDefinition_GetDR_out,
                                                            strObjCommonIn,
                                                            strLot_currentOperationInfo_GetDR_out.modulePOS ) ;
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2(""," #### process_flowBatchDefinition_GetDR != RC_OK : rc = ", rc );
                        strLot_equipmentOrder_GetByLotStatus_out.strResult = strProcess_flowBatchDefinition_GetDR_out.strResult;
                        return rc ;
                    }

                    if( TRUE == strProcess_flowBatchDefinition_GetDR_out.flowBatchSection.entryOperationFlag )
                    {
                        PPT_METHODTRACE_V1(""," #### FlowBatch entry point == TRUE. Get Equipment info from current operation." );
                        operationID = strLot_currentOperationInfo_GetDR_out.operationID;
                        setMachineType = setOperationDispatchedMachine;
                        break;
                    }
                }

                /*************************************/
                /* When held Lot is detected         */
                /*************************************/
                CORBA::Boolean PreviousHoldFlag = FALSE;
                if( 0 == CIMFWStrCmp( lotStatus.currentStatus.holdState, CIMFW_Lot_HoldState_OnHold ) )
                {
                    PPT_METHODTRACE_V1("", "The Lot is on hold. Check hold detail info.");
                    /********************************/
                    /*    Check hold detail info    */
                    /********************************/
                    objLot_FillInTxTRQ005DR_out strLot_FillInTxTRQ005DR_out;
                    rc = lot_FillInTxTRQ005DR( strLot_FillInTxTRQ005DR_out, strObjCommonIn, lotStatus.lotID );

                    if ( rc != RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "lot_FillInTxTRQ005DR() rc != RC_OK" )
                        strLot_equipmentOrder_GetByLotStatus_out.strResult = strLot_FillInTxTRQ005DR_out.strResult;
                        return(rc);
                    }

                    CORBA::Long hrLen = 0;
                    CORBA::ULong holdRecLen = strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes.length();
                    for ( CORBA::ULong i = 0 ; i < holdRecLen ; i++ )
                    {
                        if ( 0 == CIMFWStrCmp( strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes[i].responsibleOperationMark, SP_ResponsibleOperation_Previous) )
                        {
                            PreviousHoldFlag = TRUE;
                            PPT_METHODTRACE_V1("", "### PreviousHoldFlag is TRUE!" );
                        }
                        PPT_METHODTRACE_V2("", "PreviousHoldFlag is array No ", i );

                        PPT_METHODTRACE_V2("", "### holdType is ", strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes[i].holdType );
                        PPT_METHODTRACE_V2("", "### responsibleOperationMark is ", strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes[i].responsibleOperationMark );
                    }
                }

                /*************************************/
                /* When Lot is on Floor and          */
                /*   is not WIP lot.                 */
                /*  - FlowBatch floating lot         */
                /*  - Previous Hold lot              */
                /*************************************/
                if ( 0 == CIMFWStrCmp(lotStatus.currentStatus.holdState, CIMFW_Lot_HoldState_NotOnHold) ||
                     PreviousHoldFlag == TRUE  )
                {
                    PPT_METHODTRACE_V1("", "### The lot is flowbatch floating lot. or previous hold.");
                    CORBA::String_var transferStatus = cassetteLocationInfo.transferStatus;

                    if( (CIMFWStrCmp(transferStatus, SP_TransState_StationIn      ) == 0) ||
                        (CIMFWStrCmp(transferStatus, SP_TransState_BayIn          ) == 0) ||
                        (CIMFWStrCmp(transferStatus, SP_TransState_ManualIn       ) == 0) ||
                        (CIMFWStrCmp(transferStatus, SP_TransState_ShelfIn        ) == 0) ||
                        (CIMFWStrCmp(transferStatus, SP_TransState_IntermediateIn ) == 0) ||
                        (CIMFWStrCmp(transferStatus, SP_TransState_AbnormalIn     ) == 0) )
                    {
                        PPT_METHODTRACE_V1("", "### The cassette is stock in (bay in). The carrier has no machine list.");
                        setMachineType = setNoMachine ;
                        break;
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "### XferStatus is not StockIn")
                        previousEquipmentFlag = TRUE;
                        PosLot_var aLot;
                        PPT_CONVERT_LOTID_TO_LOT_OR( aLot,
                                                     lotStatus.lotID,
                                                     strLot_equipmentOrder_GetByLotStatus_out,
                                                     lot_equipmentOrder_GetByLotStatus );

                        PosControlJob_var aControlJob;
                        try
                        {
                            aControlJob = aLot->getControlJob();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getControlJob)

//INN-R170003           if ( 0 == CIMFWStrCmp( transferStatus, SP_TransState_EquipmentIn) && CORBA::is_nil(aControlJob) )
                        if ( 0 == CIMFWStrCmp( transferStatus, SP_TransState_EquipmentOut) && CORBA::is_nil(aControlJob) )  //INN-R170003
                        {
                            PPT_METHODTRACE_V1("", "### The equipmet is opeComped and on the equipment. Get Current Equipment.") ;
                            setMachineType = setCassetteMachine;
                            break;
                        }
                        else
                        {
//INN-R170003               PPT_METHODTRACE_V1("", "### The cassette is EO or SO (or xO). Get equipment from Previous PO")
                            PPT_METHODTRACE_V1("", "### The cassette is PO or SO (or xO). Get equipment from Previous Process Operation")  //INN-R170003
                            /********************************/
                            /*                              */
                            /* Get the previous equipment   */
                            /*                              */
                            /********************************/
                            PosProcessFlowContext_var aFlowContext;
                            try
                            {
                                aFlowContext = aLot->getProcessFlowContext();
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessFlowContext);

                            if( CORBA::is_nil(aFlowContext) )
                            {
                                PPT_SET_MSG_RC_KEY( strLot_equipmentOrder_GetByLotStatus_out,
                                                    MSG_NOT_FOUND_PFX,
                                                    RC_NOT_FOUND_PFX, "" );
                                return RC_NOT_FOUND_PFX ;
                            }

                            PosProcessOperation_var prevPO;
                            try
                            {
                                prevPO = aFlowContext->getPreviousProcessOperation();
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlowContext::getPreviousProcessOperation);

                            if (CORBA::is_nil(prevPO))
                            {
                                SET_MSG_RC( strLot_equipmentOrder_GetByLotStatus_out, MSG_NOT_FOUND_PO_FOR_LOT, RC_NOT_FOUND_PO_FOR_LOT );
                                return RC_NOT_FOUND_PO_FOR_LOT ;
                            }

                            PosProcessDefinition_var aPD ;
                            try
                            {
                                aPD = prevPO->getProcessDefinition();
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getProcessDefinition)

                            if ( TRUE == CORBA::is_nil(aPD) )
                            {
                                PPT_SET_MSG_RC_KEY( strLot_equipmentOrder_GetByLotStatus_out, MSG_NOT_FOUND_PD, RC_NOT_FOUND_PD, "****" ) ;
                                return RC_NOT_FOUND_PD;
                            }

                            /********************************/
                            /*                              */
                            /*   Get queued machine List    */
                            /*                              */
                            /********************************/
                            PPT_SET_OBJECT_IDENTIFIER( operationID ,
                                                       aPD ,
                                                       strLot_equipmentOrder_GetByLotStatus_out ,
                                                       lot_equipmentOrder_GetByLotStatus ,
                                                       PosProcessDefinition ) ;
                            setMachineType = setOperationDispatchedMachine;
                            break;
                        }
                    }
                }
                /*********************************/
                /* When Lot is on Floor and      */
                /*   Held on Current Operation.  */
                /*********************************/
                else
                {
                    PPT_METHODTRACE_V1("", "Current Hold or FutureHold. Get current machine list.");

                    operationID = strLot_currentOperationInfo_GetDR_out.operationID;
                    setMachineType = setOperationDispatchedMachine;
                    break;
                }

                //Any case will not reach here.
                break;
            }
            case 0:
            {
                /**********************************/
                /* When Lot is in Bank.           */
                /**********************************/
                PPT_METHODTRACE_V1("", "### The cassette is bankIn." );
                PosLot_var aLot;
                PPT_CONVERT_LOTID_TO_LOT_OR( aLot,
                                             lotStatus.lotID,
                                             strLot_equipmentOrder_GetByLotStatus_out,
                                             lot_equipmentOrder_GetByLotStatus );

                PosBank_var aBank;
                try
                {
                    aBank = aLot->getBank();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getBank)

                if(CORBA::is_nil(aBank))
                {
                    PPT_SET_MSG_RC_KEY( strLot_equipmentOrder_GetByLotStatus_out,
                                        MSG_NOT_FOUND_BANK,
                                        RC_NOT_FOUND_BANK, "" );
                    return RC_NOT_FOUND_BANK ;
                }

                PosStorageMachine_var aStocker;
                try
                {
                    aStocker = aBank->getStorageMachine();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosBank::getStorageMachine) ;

                if(CORBA::is_nil(aStocker))
                {
                    PPT_METHODTRACE_V1("", "### The bank does not have stocker. Get Current Equipment") ;
                    if( 0 < CIMFWStrLen(cassetteLocationInfo.equipmentID.identifier) )
                    {
                        PPT_METHODTRACE_V1("", "### The cassette is in equipment. Set current equipment.") ;
                        previousEquipmentFlag = TRUE;
                        setMachineType = setCassetteMachine;
                        break;
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "### The cassette is not in equipment. No machine list.") ;
                    }
                }
                else
                {
                    PPT_METHODTRACE_V1("", "### The bank has stocker. No machine list.") ;
                }

                setMachineType = setNoMachine ;
                break;
            }
            default:
            {
                //Any case will not reach here.
                break;
            }
        }

        switch(setMachineType)
        {
            case setQueuedMachine:
            {
                //Already set equipment...
                break;
            }
            case setOperationDispatchedMachine:
            {
                /***********************************************/
                /*    Call process_dispatchEquipments_GetDR    */
                /***********************************************/
                objProcess_dispatchEquipments_GetDR_out strProcess_dispatchEquipments_GetDR_out;
                rc = process_dispatchEquipments_GetDR( strProcess_dispatchEquipments_GetDR_out,
                                                       strObjCommonIn,
                                                       lotStatus.productID,
                                                       operationID ) ;
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "process_dispatchEquipments_GetDR() rc != RC_OK");
                    strLot_equipmentOrder_GetByLotStatus_out.strResult = strProcess_dispatchEquipments_GetDR_out.strResult ;
                    return (rc);
                }
                eqpIDs = strProcess_dispatchEquipments_GetDR_out.equipmentIDs ;

                break;
            }
            case setCassetteMachine:
            {
                /*************************************/
                /*  Set Cassette related Machine.    */
                /*************************************/
                eqpIDs.length(1);
                eqpIDs[0] = cassetteLocationInfo.equipmentID ;
                break;
            }
            case setNoMachine:
            {
                eqpIDs.length(0);
                break;
            }
            default:
            {
                //Any case will not reach here.
                break;
            }
        }

        CORBA::Long eqpLen = eqpIDs.length();
        if( 0 != eqpLen )
        {
            CORBA::Boolean checkInhibitFlag = TRUE ;
            CORBA::Boolean checkMachineAvailabilityFlag = TRUE ;
            if( TRUE == previousEquipmentFlag )
            {
                /********************************************************************************/
                /*  Responsible operation of this Lot is previous operation.                    */
                /*  So it should not be checked its availability for the previous equipment.    */
                /********************************************************************************/
                checkInhibitFlag = FALSE;
                checkMachineAvailabilityFlag = FALSE;
            }

            /**********************************/
            /*  Sort the Equipment.           */
            /**********************************/
            objEquipment_priorityOrder_GetByLotAvailability_out strEquipment_priorityOrder_GetByLotAvailability_out;
            rc = equipment_priorityOrder_GetByLotAvailability( strEquipment_priorityOrder_GetByLotAvailability_out, strObjCommonIn,
                                                               eqpIDs,
                                                               lotStatus.lotID,
                                                               checkInhibitFlag,
                                                               checkMachineAvailabilityFlag );

            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "equipment_priorityOrder_GetByLotAvailability() rc != RC_OK" );
                strLot_equipmentOrder_GetByLotStatus_out.strResult = strEquipment_priorityOrder_GetByLotAvailability_out.strResult;
                return rc;
            }

            /**********************************/
            /*  Set Equipment information.    */
            /**********************************/
            strLot_equipmentOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq = strEquipment_priorityOrder_GetByLotAvailability_out.strWhereNextEqpStatusSeq ;
            strLot_equipmentOrder_GetByLotStatus_out.availableEqpExistFlag = strEquipment_priorityOrder_GetByLotAvailability_out.availableEqpExistFlag ;
        }
        else
        {
            strLot_equipmentOrder_GetByLotStatus_out.availableEqpExistFlag = TRUE;
            PPT_METHODTRACE_V1("", " ### No machine list...");
        }

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::lot_equipmentOrder_GetByLotStatus");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_equipmentOrder_GetByLotStatus_out, lot_equipmentOrder_GetByLotStatus, methodName)
}
