//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
//
// SiView
// Name: cs_APC_LithoRecipeParameter_Replace.cpp
//

#include "cs_pptmgr.hpp"


// Class: CS_PPTManager
//
// [Object Function Name]: long   cs_APC_LithoRecipeParameter_Replace.cpp
//
//
// Innotron Modification History:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/09/26 INN-R170009 Nick Tsai      Replace APC recommended recipe parameter to strStartCassette
//
// Function Description:
//
// Input Parameters:
//    csObjAPC_LithoRecipeParameter_Replace_out&       strObjAPC_LithoRecipeParameter_Replace_out,
//    const pptObjCommonIn&                            strObjCommonIn,
//    const csObjAPC_LithoRecipeParameter_Replace_in&  strObjAPC_LithoRecipeParameter_Replace_in
//
// typedef struct csObjAPC_LithoRecipeParameter_Replace_in_struct {
//     pptStartRecipeParameterSequence           strStartRecipeParameterSeq;
//     csAPCLithoRecommendReticleSequence        strAPCLithoRecommendReticleSeq;
//     any                                       siInfo;
// }csObjAPC_LithoRecipeParameter_Replace_in;
//
//
// Output Parameters:
// typedef struct csObjAPC_LithoRecipeParameter_Replace_out_struct {
//     pptRetCode                      strResult;
//     pptStartRecipeParameterSequence strStartRecipeParameterSeq;
//     any                             siInfo;
// }csObjAPC_LithoRecipeParameter_Replace_out;
//
//
// Return Value:
//
// Exception:
//
// Pseudo code:
//


CORBA::Long CS_PPTManager_i::cs_APC_LithoRecipeParameter_Replace (
    csObjAPC_LithoRecipeParameter_Replace_out&       strObjAPC_LithoRecipeParameter_Replace_out,
    const pptObjCommonIn&                            strObjCommonIn,
    const csObjAPC_LithoRecipeParameter_Replace_in&  strObjAPC_LithoRecipeParameter_Replace_in
)
{
    char * methodName = NULL;
    CORBA::Long rc = RC_OK;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_APC_LithoRecipeParameter_Replace");

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;
        
        pptStartRecipeParameterSequence tmpstrStartRecipeParameterSeq;
        csAPCLithoRecommendReticleSequence tmpstrAPCLithoRecommendReticleSeq;

        tmpstrStartRecipeParameterSeq    = strObjAPC_LithoRecipeParameter_Replace_in.strStartRecipeParameterSeq;
        tmpstrAPCLithoRecommendReticleSeq = strObjAPC_LithoRecipeParameter_Replace_in.strAPCLithoRecommendReticleSeq;

        CORBA::Long SRPLen = tmpstrStartRecipeParameterSeq.length();

        strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq.length(SRPLen);

        for ( CORBA::Long i = 0; i < SRPLen; i++ )
        {
            PPT_METHODTRACE_V2("", "loop tmpstrStartRecipeParameterSeq",i ); 

            PPT_METHODTRACE_V2("", "in para Recipe.parameterName....   ",tmpstrStartRecipeParameterSeq[i].parameterName );
            PPT_METHODTRACE_V2("", "in para Recipe.parameterValue...   ",tmpstrStartRecipeParameterSeq[i].parameterValue );
            PPT_METHODTRACE_V2("", "in para Recipe.targetValue......   ",tmpstrStartRecipeParameterSeq[i].targetValue );


            /**********************************************************************************
             Use Current| MM Default            |APC	            |Result
             Value      |                       |                       |
             ----------------------------------------------------------------------------------
                        | Parameter | Parameter | Parameter | Parameter | Parameter | Parameter  
                        | Name      | Value     | Name      | Value     | Name      | Value
             ----------------------------------------------------------------------------------
             No         | Parm001   | 10        | Parm001   | 15        | Parm001   | 15
             ----------------------------------------------------------------------------------
             No         | Parm002   | 20        | Parm002   | 20        | Parm002   | 20
             ----------------------------------------------------------------------------------
             No         | Parm003   | 35        |           |           | Parm003   | 35
             ----------------------------------------------------------------------------------
                        |           |           | Parm004   | 30        |           |
             ----------------------------------------------------------------------------------
             Yes        | Parm005   | 120       | Parm005   | 127       | Parm005   | 120
             ----------------------------------------------------------------------------------
             No         | Parm006   | -999      |           |           |           |
             ----------------------------------------------------------------------------------
             No         | Parm007   | -999      | Parm007   | 127       | Parm007   | 127
             ----------------------------------------------------------------------------------
             No         | Parm008   | *         | Parm008   | -999      |           |
             *********************************************************************************/ 

            //If the parameter value is defined -999 in SM system
            // MM will not report the parameter to TCS expect if APC recommend the parameter value.

            if ( CIMFWStrCmp( tmpstrStartRecipeParameterSeq[i].targetValue, "Yes" ) == 0 )
            { 
                strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[i].parameterName = tmpstrStartRecipeParameterSeq[i].parameterName;
                strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[i].parameterValue = tmpstrStartRecipeParameterSeq[i].parameterValue;
            }
            else if ( CIMFWStrCmp( tmpstrStartRecipeParameterSeq[i].targetValue, "No" ) == 0 )
            {
                CORBA::Long ALRLen = tmpstrAPCLithoRecommendReticleSeq.length();
            
                for ( CORBA::Long j = 0; j < ALRLen; j++ )
                {
                    PPT_METHODTRACE_V2("", "in para reticleID....   ",tmpstrAPCLithoRecommendReticleSeq[j].reticleID.identifier);
                    PPT_METHODTRACE_V2("", "loop tmpstrAPCLithoRecommendReticleSeq", j ); 

                    CORBA::Long ARPLen = tmpstrAPCLithoRecommendReticleSeq[j].strAPCLithoRecipeParameterSeq.length();

                    if ( ARPLen > 2 )
                    {
                       //qufd : return msg
                       return 100;
                    }

                    for ( CORBA::Long k = 0; k < ARPLen; k++ )
                    {
                        csAPCLithoRecipeParameter strAPCLithoRecipeParameter;

                        strAPCLithoRecipeParameter = tmpstrAPCLithoRecommendReticleSeq[j].strAPCLithoRecipeParameterSeq[k];

                        //Recipe parameter in double exposure
                        //Naming rule is "D1_" and "D2_".
                        //"D1_" is reticle1, "D2_" is reticle2.
                        CORBA::String_var dRecipeName; 

                        if ( ARPLen == 2 )
                        {
                            char *ptr = CORBA::string_alloc(CIMFWStrLen(strAPCLithoRecipeParameter.parameterName)+4);
             
                            CIMFWStrCpy( ptr, strAPCLithoRecipeParameter.parameterName); 
                            sprintf(ptr, "D%d_%s", k, ptr ); 

                            dRecipeName = ptr;
                        } 

                        PPT_METHODTRACE_V2("", "loop strAPCLithoRecipeParameter",k ); 
    
                        PPT_METHODTRACE_V2("", "in para Reticle.parameterName  ",strAPCLithoRecipeParameter.parameterName );
                        PPT_METHODTRACE_V2("", "in para Reticle.parameterValue ",strAPCLithoRecipeParameter.parameterValue);

                        if ( CIMFWStrCmp( dRecipeName, tmpstrStartRecipeParameterSeq[i].parameterName  ) == 0 )
                        {
                            if ( CIMFWStrCmp( strAPCLithoRecipeParameter.parameterValue, "-999" ) != 0 )
                            { 
                                strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[i].parameterName = strAPCLithoRecipeParameter.parameterName;
                                strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[i].parameterValue = strAPCLithoRecipeParameter.parameterValue;
                            }

                            break;
                        }
                    }

                    if ( k == ARPLen )
                        continue;
                    else
                    {
                        if ( ARPLen != 2 )
                        {
                            CORBA::Long TmpLen = ALRLen;
                            tmpstrAPCLithoRecommendReticleSeq[j] = tmpstrAPCLithoRecommendReticleSeq[TmpLen-1];
                            TmpLen--;
                            tmpstrAPCLithoRecommendReticleSeq.length( TmpLen );
                        }
                        break;
                    }
                }

                if ( j == ALRLen ) 
                {
                    strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[i].parameterName = tmpstrStartRecipeParameterSeq[i].parameterName;
                    strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[i].parameterValue = tmpstrStartRecipeParameterSeq[i].parameterValue;
                }
            } 
            else
            {
                //return wrong msg
                return 200;
            }
        }

        //Trace For: strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq 
        CORBA::Long OSRPLen = strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq.length();
        for (CORBA::Long h = 0; h < OSRPLen; h++)
        {
            PPT_METHODTRACE_V2("", "loop Out:strStartRecipeParameterSeq",h ); 

            PPT_METHODTRACE_V2("", "in para Out.parameterName....   ",strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[i].parameterName );
            PPT_METHODTRACE_V2("", "in para Out.parameterValue...   ",strObjAPC_LithoRecipeParameter_Replace_out.strStartRecipeParameterSeq[i].parameterValue );
        }
 

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_APC_LithoRecipeParameter_Replace");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strObjAPC_LithoRecipeParameter_Replace_out, cs_APC_LithoRecipeParameter_Replace, methodName)
}
