//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_lot_ContaminationInfo_CheckForProcess.cpp
//
#include "cs_pptmgr.hpp"

#include "pcas.hh"
//
// Class: CS_PPTManager
//
// Service: cs_lot_ContaminationInfo_CheckForProcess()
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------  -------------- -------------------------------------------
// 2017-09-07 INN-R170002   JJ.Zhang       Contamination control
//
//[Function Description]:
//
//
//[Input Parameters]:
//  in  pptObjCommonIn      strObjCommonIn;
//  in  csObjLot_ContaminationInfo_CheckForProcess_in    strLot_ContaminationInfo_CheckForProcess_in
//
//[Output Parameters]:
//
//  out csObjLot_ContaminationInfo_CheckForProcess_out  strLot_ContaminationInfo_CheckForProcess_out;
//
//  typedef struct csObjLot_ContaminationInfo_CheckForProcess_out_struct {
//     boolean                  matchFlag;
//     objectIdentifierSequence errorLotIDs;
//     any                      siInfo;
//} csObjLot_ContaminationInfo_CheckForProcess_out;
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::cs_lot_ContaminationInfo_CheckForProcess(
    csObjLot_ContaminationInfo_CheckForProcess_out&      strLot_ContaminationInfo_CheckForProcess_out, 
    const pptObjCommonIn &                               strObjCommonIn, 
    const csObjLot_ContaminationInfo_CheckForProcess_in& strLot_ContaminationInfo_CheckForProcess_in)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_lot_ContaminationInfo_CheckForProcess");
        CORBA::Long rc = RC_OK;
        strLot_ContaminationInfo_CheckForProcess_out.matchFlag = TRUE;
        strLot_ContaminationInfo_CheckForProcess_out.holdLotIDs.length(0);

        //----------------------------------------------
        // Get equipment PR control action
        //----------------------------------------------
        PosMachine_var aPosMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aPosMachine,
                                         strLot_ContaminationInfo_CheckForProcess_in.equipmentID,
                                         strLot_ContaminationInfo_CheckForProcess_out,
                                         cs_lot_ContaminationInfo_CheckForProcess );

        CORBA::String_var varEqpContamiControl;
        SI_PPT_USERDATA_GET_STRING( aPosMachine, CS_S_EQP_PRControl, varEqpContamiControl );
        PPT_METHODTRACE_V2("", "CS_S_EQP_PRControl", varEqpContamiControl);


        PosCassette_var aPosCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aPosCassette, strLot_ContaminationInfo_CheckForProcess_in.carrierID,
                                               strLot_ContaminationInfo_CheckForProcess_out,
                                               cs_lot_ContaminationInfo_CheckForProcess );

        //---------------------------------------------------
        // Get Contamination In/Out and PR flag for all lots
        //---------------------------------------------------
        CORBA::Long nLotLen = strLot_ContaminationInfo_CheckForProcess_in.strLotInCassette.length();
        CORBA::Long i=0, j=0;
        csLotContaminationInfoSequence strLotContaminationInfoSeq;
        strLotContaminationInfoSeq.length(nLotLen);

        for( i=0; i<nLotLen; i++ )
        {
            PPT_METHODTRACE_V2("", "cs_lot_ContaminationInfo_Get() lotID",strLot_ContaminationInfo_CheckForProcess_in.strLotInCassette[i].lotID.identifier);

            csObjLot_ContaminationInfo_Get_out strLot_ContaminationInfo_Get_out;
            csObjLot_ContaminationInfo_Get_in  strLot_ContaminationInfo_Get_in;
            strLot_ContaminationInfo_Get_in.lotID = strLot_ContaminationInfo_CheckForProcess_in.strLotInCassette[i].lotID;

            rc = cs_lot_ContaminationInfo_Get(strLot_ContaminationInfo_Get_out, strObjCommonIn,
                                         strLot_ContaminationInfo_Get_in); 
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V2("", "cs_lot_ContaminationInfo_Get() rc != RC_OK",rc);
                strLot_ContaminationInfo_CheckForProcess_out.strResult = strLot_ContaminationInfo_Get_out.strResult;
                return(rc);
            }
            strLotContaminationInfoSeq[i] = strLot_ContaminationInfo_Get_out.strLotContaminationInfo;
            strLotContaminationInfoSeq[i].operationStartFlag = strLot_ContaminationInfo_CheckForProcess_in.strLotInCassette[i].operationStartFlag;
        }

        //---------------------------------------------------
        // Check Contamination In/Out and PR flag
        // -if tool is avoidPR, process lot should not have PR
        // -all lots in carrier should have same contami flag
        // -lot contamiFlag should match operation contamiInLevel
        // -process lot should have same contamiOut level
        //---------------------------------------------------
        CORBA::Boolean bMatchFlag = TRUE;
        CORBA::String_var varSavedLotContamiFlag;
        CORBA::String_var varSavedContamiOutFlag;
        for( i=0; i<nLotLen; i++ )
        {
            PPT_METHODTRACE_V2("", "lotPRFlag", strLotContaminationInfoSeq[i].lotPRFlag);
            //1. process lot should not have PR flag when eqp is avoidPR
            if( TRUE == strLotContaminationInfoSeq[i].operationStartFlag
                && 0 == CIMFWStrCmp(varEqpContamiControl, CS_PRControl_Action_AvoidPR)
                && 0 == CIMFWStrCmp(strLotContaminationInfoSeq[i].lotPRFlag, CS_M_LOT_PR_Flag_Yes) )
            {
                PPT_METHODTRACE_V1("", "varLotPRFlag==Yes && EqpContamiControl == AvoidPR");
                bMatchFlag = FALSE;
                break;
            }

            //2. all lot should have same contaminaiton flag
            //but for dynamic sorter operaiton, which have ContamiIn=NoCheck, the check will be skipped.
            PPT_METHODTRACE_V2("", "lotContamiFlag", strLotContaminationInfoSeq[i].lotContamiFlag);
            if( 0 == CIMFWStrLen(varSavedLotContamiFlag) 
             && 0 <  CIMFWStrLen(strLotContaminationInfoSeq[i].lotContamiFlag)
             && 0 <  CIMFWStrLen(strLotContaminationInfoSeq[i].opeContamiInLevel) ) //except No-Check
            {
                varSavedLotContamiFlag = strLotContaminationInfoSeq[i].lotContamiFlag;
                PPT_METHODTRACE_V2("", "varSavedLotContamiFlag", varSavedLotContamiFlag);
            }
            if( 0 != CIMFWStrCmp(varSavedLotContamiFlag, strLotContaminationInfoSeq[i].lotContamiFlag)
             && 0 <  CIMFWStrLen(strLotContaminationInfoSeq[i].lotContamiFlag)
             && 0 <  CIMFWStrLen(strLotContaminationInfoSeq[i].opeContamiInLevel) ) //except No-Check
            {
                PPT_METHODTRACE_V2("", "varSavedLotContamiFlag!=lotContamiFlag", strLotContaminationInfoSeq[i].lotContamiFlag);
                bMatchFlag = FALSE;
                break;
            }

            //3.lot contamiFlag should match operation contamiInLevel
            if( TRUE == strLotContaminationInfoSeq[i].operationStartFlag
                && 0 <  CIMFWStrLen(strLotContaminationInfoSeq[i].opeContamiInLevel) //except No-Check
                && 0 <  CIMFWStrLen(strLotContaminationInfoSeq[i].lotContamiFlag)
                && 0 != CIMFWStrCmp(strLotContaminationInfoSeq[i].lotContamiFlag, strLotContaminationInfoSeq[i].opeContamiInLevel) )
            {
                PPT_METHODTRACE_V1("", "varLotPRFlag==Yes && EqpContamiControl == AvoidPR");
                bMatchFlag = FALSE;
                break;
            }

            //4. process lot should have same contamiOut level
            //but for dynamic sorter operaiton, which have ContamiIn=NoCheck, the check will be skipped.
            PPT_METHODTRACE_V2("", "opeContamiOutLevel", strLotContaminationInfoSeq[i].opeContamiOutLevel);
            if( 0 == CIMFWStrLen(varSavedContamiOutFlag) )
            {
                if( TRUE == strLotContaminationInfoSeq[i].operationStartFlag )
                {
                    varSavedContamiOutFlag = strLotContaminationInfoSeq[i].opeContamiOutLevel;
                    PPT_METHODTRACE_V2("", "varSavedContamiOutFlag=opeContamiOutLevel", strLotContaminationInfoSeq[i].opeContamiOutLevel);
                }
                else
                {
                    //LotContami will not change for no-process lot
                    varSavedContamiOutFlag = strLotContaminationInfoSeq[i].lotContamiFlag;
                    PPT_METHODTRACE_V2("", "varSavedContamiOutFlag=lotContamiFlag", strLotContaminationInfoSeq[i].lotContamiFlag);
                }
                PPT_METHODTRACE_V2("", "varSavedContamiOutFlag", varSavedContamiOutFlag);
            }
            if( TRUE == strLotContaminationInfoSeq[i].operationStartFlag )
            {
                PPT_METHODTRACE_V2("", "operationStartFlag=TRUE", strLotContaminationInfoSeq[i].opeContamiOutLevel);
                if( 0 <  CIMFWStrLen(strLotContaminationInfoSeq[i].opeContamiOutLevel) //except No-Check
                 && 0 <  CIMFWStrLen(varSavedContamiOutFlag)
                 && 0 != CIMFWStrCmp(varSavedContamiOutFlag, strLotContaminationInfoSeq[i].opeContamiOutLevel) )
                {
                    PPT_METHODTRACE_V2("", "varSavedContamiOutFlag!=opeContamiOutLevel", strLotContaminationInfoSeq[i].opeContamiOutLevel);
                    bMatchFlag = FALSE;
                    break;
                }
            }
            else
            {
                PPT_METHODTRACE_V2("", "operationStartFlag=FALSE", strLotContaminationInfoSeq[i].lotContamiFlag);
                if( 0 <  CIMFWStrLen(varSavedContamiOutFlag) && 0 <  CIMFWStrLen(strLotContaminationInfoSeq[i].lotContamiFlag)
                 && 0 != CIMFWStrCmp(varSavedContamiOutFlag, strLotContaminationInfoSeq[i].lotContamiFlag) )
                {
                    PPT_METHODTRACE_V2("", "varSavedContamiOutFlag!=lotContamiFlag", strLotContaminationInfoSeq[i].lotContamiFlag);
                    bMatchFlag = FALSE;
                    break;
                }
            }
        }

        //---------------------------------------------------
        // Hold the lot if not matched
        //---------------------------------------------------
        strLot_ContaminationInfo_CheckForProcess_out.matchFlag = bMatchFlag;
        CORBA::Long lngHoldLotLen = 0;
        if( FALSE == bMatchFlag )
        {
            strLot_ContaminationInfo_CheckForProcess_out.holdLotIDs.length(nLotLen);
            for( i=0; i<nLotLen; i++ )
            {
                PPT_METHODTRACE_V2("", "lotID", strLotContaminationInfoSeq[i].lotID.identifier);
                CORBA::Boolean bFoundFlag = FALSE;

                if( TRUE == strLotContaminationInfoSeq[i].operationStartFlag )
                {
                    //process lot, certainly no hold exist
                }
                else
                {
                    objLot_FillInTxTRQ005DR_out strLot_FillInTxTRQ005DR_out;
                    rc = lot_FillInTxTRQ005DR( strLot_FillInTxTRQ005DR_out, strObjCommonIn, 
                                               strLotContaminationInfoSeq[i].lotID );
                    if( rc == RC_OK )
                    {
                        CORBA::Long lngHoldLen = 0;
                        CORBA::Long lngHoldCnt = 0;
                        lngHoldLen = strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes.length();

                        for( lngHoldCnt = 0; lngHoldCnt < lngHoldLen; lngHoldCnt++ )
                        {
                            if( CIMFWStrCmp( strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes[lngHoldCnt].reasonCodeID.identifier, CS_SP_Reason_ContaminationMismatchHold ) == 0 )
                            {
                                PPT_METHODTRACE_V1( "", "ContaminationMismatchHold record exists!" );
                                bFoundFlag = TRUE;
                                break;
                            }
                        }
                    }
                    else if( rc != RC_NOT_FOUND_ENTRY )
                    {
                        PPT_METHODTRACE_V2( "", "lot_FillInTxTRQ005DR() rc=", rc);
                        strLot_ContaminationInfo_CheckForProcess_out.strResult = strLot_FillInTxTRQ005DR_out.strResult;
                        return( rc );
                    }
                }
                if( FALSE == bFoundFlag )
                {
                    //add the lot to hold Lot list
                    strLot_ContaminationInfo_CheckForProcess_out.holdLotIDs[lngHoldLotLen] = strLotContaminationInfoSeq[i].lotID;
                    lngHoldLotLen++;
                }
            }
            strLot_ContaminationInfo_CheckForProcess_out.holdLotIDs.length(lngHoldLotLen);
        }

        //----------------------------
        //  Return to Caller
        //----------------------------
        SET_MSG_RC(strLot_ContaminationInfo_CheckForProcess_out, MSG_OK, RC_OK);
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_lot_ContaminationInfo_CheckForProcess");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_ContaminationInfo_CheckForProcess_out, cs_lot_ContaminationInfo_CheckForProcess, methodName)
}
