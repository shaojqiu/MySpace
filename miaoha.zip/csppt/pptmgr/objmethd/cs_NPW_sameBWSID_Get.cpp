//
// (c) Copyright: IBM Services Company Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// Name: cs_NPW_sameBWSID_Get.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: cs_NPW_sameBWSID_Get()
//
// Change history:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/10/20 INN-R170016 Yangxiaojun    Initial Release
//
//[Function Description]
//  Get same BWS IDs from all used BWSID by monitor product
//
//[Input Parameters]
//  const pptObjCommonIn&             strObjCommonIn
//  const csObjNPW_sameBWSID_Get_in&  strNPW_sameBWSID_Get_in
//
//  typedef struct csObjNPW_sameBWSID_Get_in_struct
//  {
//      stringSequence   strOrgBWSIDSeq;
//      any              siInfo;
//  }csObjNPW_sameBWSID_Get_in;
//
//[Output Parameters]
//  csObjNPW_sameBWSID_Get_out&   strNPW_sameBWSID_Get_out
//
//  typedef struct csObjNPW_sameBWSID_Get_out_struct
//  {
//      pptRetCode           strResult;
//      stringSequence       BWSIDs;
//      any                  siInfo;
//  }csObjNPW_sameBWSID_Get_out;
//
//
//[Return Value]:
//
//  Return Code                        Messsage ID
//  ---------------------------------- -----------------------------------------
//  RC_OK                              MSG_OK
//  RC_SYSTEM_ERROR                    MSG_SYSTEM_ERROR
//
  
#define BWSID_SEPARATOR         ";"
#define BWSID_SEPARATOR_CHAR    ';'

CORBA::Long CS_PPTManager_i::cs_NPW_sameBWSID_Get (
    csObjNPW_sameBWSID_Get_out&         strNPW_sameBWSID_Get_out,
    const pptObjCommonIn&               strObjCommonIn,
    const csObjNPW_sameBWSID_Get_in&    strNPW_sameBWSID_Get_in)
{
    char* methodName = NULL;

    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_NPW_sameBWSID_Get");

        //-----------------------------------------
        //  Initialize
        //-----------------------------------------
        strNPW_sameBWSID_Get_out.BWSIDs.length(0);

        //-----------------------------------------
        //  Get the header string in strOrgBWSIDSeq,  extract IDs from it.
        //  Check them whether as same as the IDs in Seq[1], Seq[2] ...
        //-----------------------------------------
        CORBA::Long nBWSIDSeqLen = strNPW_sameBWSID_Get_in.strOrgBWSIDSeq.length();
        PPT_METHODTRACE_V2("", "nBWSIDSeqLen", nBWSIDSeqLen);
        if (nBWSIDSeqLen != 0)
        {
            CORBA::ULong nCnt = 0;
            CORBA::ULong nMax = SP_CAPACITY_INCREMENT_10;
            strNPW_sameBWSID_Get_out.BWSIDs.length(nMax);
            
            CORBA::String_var strHeader = CIMFWStrDup(strNPW_sameBWSID_Get_in.strOrgBWSIDSeq[0]);
            PPT_METHODTRACE_V2("", "strHeader", strHeader);
            
            char *Header = (char *)strHeader;
            if (CIMFWStrLen(Header) > 0)
            {
                while (Header != NULL)
                {
                    char *token = Header;
                    char *pos = strstr(Header, BWSID_SEPARATOR);
                    if (pos != NULL)
                    {
                        //-----------------------------------------
                        //  truncating pos[0] to make token as a C-string
                        //  then make Header point the next ID
                        //-----------------------------------------                        
                        pos[0] = 0;
                        Header = pos + 1;
                    }
                    else
                    {
                        //-----------------------------------------
                        //  come here to end loop next time
                        //-----------------------------------------    
                        Header = NULL;
                    }
  
                    PPT_METHODTRACE_V2("", "token", token);
                    CORBA::Long nCount = 1;     // save count of same IDs
                    for (CORBA::Long i = 1; i < nBWSIDSeqLen; i++)  // loop from index 1, excluding index 0
                    {
                        CORBA::String_var Cur = CIMFWStrDup(strNPW_sameBWSID_Get_in.strOrgBWSIDSeq[i]);
                        PPT_METHODTRACE_V2("", "Cur", Cur);
                        pos = strstr(Cur, token);
                        if (pos != NULL)
                        {
                            //-----------------------------------------
                            //  make sure the matching string in Cur equals to token
                            //  pos[nLen] is the tail data, it should be '\0' or ';' if matching exactly
                            //  so excluding matching string longer than token
                            //-----------------------------------------
                            CORBA::Long nLen = CIMFWStrLen(token);
                            if (pos[nLen] == '\0' || pos[nLen] == BWSID_SEPARATOR_CHAR)
                            {
                                nCount++;
                            }
                        }
                    }

                    //-----------------------------------------
                    //  if count equals to BWSIDSeqLen, it means the ID is a common ID
                    //  then save it into sequence
                    //-----------------------------------------
                    if (nCount == nBWSIDSeqLen)
                    {
                        if (nCnt >= nMax)
                        {
                            nMax += SP_CAPACITY_INCREMENT_10;
                            strNPW_sameBWSID_Get_out.BWSIDs.length(nMax);
                        }
                        strNPW_sameBWSID_Get_out.BWSIDs[nCnt] = CIMFWStrDup(token);
                        PPT_METHODTRACE_V4("", "nCnt : ", nCnt, " token : ", token);
                        nCnt++;
                    }
                } 
            }
            
            strNPW_sameBWSID_Get_out.BWSIDs.length(nCnt);
        }

        //----------------------------------------
        //  Return to caller
        //----------------------------------------
        SET_MSG_RC(strNPW_sameBWSID_Get_out, MSG_OK, RC_OK);
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_NPW_sameBWSID_Get");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strNPW_sameBWSID_Get_out, cs_NPW_sameBWSID_Get, methodName);
}
