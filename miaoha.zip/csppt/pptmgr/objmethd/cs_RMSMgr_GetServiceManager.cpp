#ifndef lint
static char *sccsid =  "@(#) 1.3 superpos/src/spppt/source/posppt/pptmgr/objmethd/cs_RMSMgr_GetServiceManager.cpp, mm_srv_5_0_ppt, mm_srv_5_0_ppt 5/26/03 19:51:17 [ 5/26/03 19:51:18 ]";
#endif
//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2003. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2003. All rights reserved.
//
// SiView
// Name: cs_RMSMgr_GetServiceManager.cpp
//

#include"cs_pptmgr.hpp"     
#include "rmssm.hh"         

//[Object Function Name]: long   cs_RMSMgr_GetServiceManager()
//
// Change history:
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
//
//[Function Description]
//  get RMS Service Manager
//
//[Input Parameters]:
//  in  pptObjCommonIn      strObjCommonIn;
//  in  string              RMSServerName;
//  in  string              RMSHostName;
//
//[Output Parameters]:
//
//  out objcs_RMSMgr_GetServiceManager_out strRMSMgr_GetServiceManager_out;
//
//  typedef struct objcs_RMSMgr_GetServiceManager_out_struct {
//     pptRetCode         strResult;
//     string             RMSSvcMgr;
//  } objcs_RMSMgr_GetServiceManager_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  -------------------------   --------------------------------------------------

CORBA::Long CS_PPTManager_i::cs_RMSMgr_GetServiceManager(
    csObjRMSMgr_GetServiceManager_out& strRMSMgr_GetServiceManager_out,
    const pptObjCommonIn&              strObjCommonIn,
    const char*                        RMSServerName,
    const char*                        RMSHostName)
{
    char *methodName=NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_RMSMgr_GetServiceManager");

        RMServiceManager_var RMSSvcMgr = RMServiceManager::_nil();
        PPT_METHODTRACE_V2("","RMS Server Name is --> ",RMSServerName);
        PPT_METHODTRACE_V2("","RMS Host Name is ---> ",RMSHostName); 

        CORBA::String_var BindEverytimeFlg = CIMFWStrDup (getenv(CS_SP_BindEverytime_RMS)); 

        PPT_METHODTRACE_V2("","BindEverytimeFlg ---> ",BindEverytimeFlg);

        CORBA::Boolean bExecBind = FALSE;

        if ( 0 == CIMFWStrCmp(BindEverytimeFlg, "1") )
        {
            /*--------------------*/
            /*   Everytime Bind   */
            /*--------------------*/
            PPT_METHODTRACE_V1("","/*--------------------*/");
            PPT_METHODTRACE_V1("","/*   Everytime Bind   */");
            PPT_METHODTRACE_V1("","/*--------------------*/");

            bExecBind = TRUE;
        }

        if ( FALSE == bExecBind )
        {
            /*----------------------------*/
            /*   Search Service Manager   */
            /*----------------------------*/
            PPT_METHODTRACE_V1("","/*----------------------------*/");
            PPT_METHODTRACE_V1("","/*   Search Service Manager   */");
            PPT_METHODTRACE_V1("","/*----------------------------*/");

            CORBA::Boolean existFlag = FALSE;
            char* objRef = CORBA::String(NULL);
            try
            {
               existFlag = externalServerList.find((char*)RMSServerName, objRef);
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "externalServerList.find() raises exception");
                SET_MSG_RC(strRMSMgr_GetServiceManager_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
                return(RC_SYSTEM_ERROR);
            }
            if ( existFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "existFlag == TRUE...");
                CORBA::Object_var tmpRMS = CORBA::Object::_nil();
                try
                {
#ifdef EBROKER         //D02.0057
                    tmpRMS = SP_STRING_TO_OBJECT(objRef);   //D02.0057
#else                  //D02.0057
                    tmpRMS = CORBA::Orbix.string_to_object(objRef);
#endif                 //D02.0057
                }
                catch(...)
                {
                    PPT_METHODTRACE_V1("", "CORBA::Orbix.string_to_object() raises exception");
                    SET_MSG_RC( strRMSMgr_GetServiceManager_out,
                                CS_MSG_RMS_SERVER_BIND_FAIL,
                                CS_RC_RMS_SERVER_BIND_FAIL);
                    try
                    {
                        externalServerList.remove((char *)RMSServerName);
                    }
                    catch( ... )
                    {
                        PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                    }
                    return(CS_RC_RMS_SERVER_BIND_FAIL);
                }
                if (CORBA::is_nil(tmpRMS) == TRUE)
                {
                    PPT_METHODTRACE_V1("", "CORBA::is_nil(tmpRMS) == TRUE");
                    SET_MSG_RC(strRMSMgr_GetServiceManager_out, MSG_EXT_SERVER_NIL_OBJ, RC_EXT_SERVER_NIL_OBJ);
                    try
                    {
                        externalServerList.remove((char *)RMSServerName);
                    }
                    catch( ... )
                    {
                        PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                    }
                    return(RC_EXT_SERVER_NIL_OBJ);
                }
                RMSSvcMgr = RMServiceManager::_narrow(tmpRMS);
            }
            else
            {
                bExecBind = TRUE;
            }
        }

//D02.0057        CORBA::Environment envTimeOut = CORBA::IT_chooseDefaultEnv();
        CORBA::Environment envTimeOut = SP_CORBAENV_DEFENV;   //D02.0057
        CORBA::String_var timeOutValue = CIMFWStrDup(getenv(CS_SP_TX_TIMEOUT_RMS));
        PPT_METHODTRACE_V2("","timeOutValue ---> ",timeOutValue);

        if ( 0 < CIMFWStrLen(timeOutValue) )
        {
            PPT_METHODTRACE_V1("", "setting timeout!!");
            envTimeOut.timeout(atol(timeOutValue) * 1000);
        }

        if ( TRUE == bExecBind )
        {
            /*--------------------------*/
            /*   Bind Service Manager   */
            /*--------------------------*/
            PPT_METHODTRACE_V1("","/*--------------------------*/");
            PPT_METHODTRACE_V1("","/*   Bind Service Manager   */");
            PPT_METHODTRACE_V1("","/*--------------------------*/");

            CORBA::String_var newObjRef;
            try
            {
#ifdef EBROKER            //D02.0057
                SP_GET_OBJECT_WITH_ENV(RMSSvcMgr, RMSServerName, RMSHostName, RMServiceManager, envTimeOut);    //D02.0057
#else                     //D02.0057
                RMSSvcMgr = RMServiceManager::_bind( RMSServerName, RMSHostName, envTimeOut );
#endif                    //D02.0057
            }
            catch(const CORBA::SystemException &SysEx)
            {
                PPT_METHODTRACE_V1("", "RMServiceManager::_bind() raises system exception");
                APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
                SET_MSG_RC(strRMSMgr_GetServiceManager_out, CS_MSG_RMS_SERVER_BIND_FAIL, CS_RC_RMS_SERVER_BIND_FAIL);
                return(CS_RC_RMS_SERVER_BIND_FAIL);
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "RMServiceManager::_bind() raises unknown exception");
                APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ();
                SET_MSG_RC(strRMSMgr_GetServiceManager_out, CS_MSG_RMS_SERVER_BIND_FAIL, CS_RC_RMS_SERVER_BIND_FAIL);
                return(CS_RC_RMS_SERVER_BIND_FAIL);
            }
            if (CORBA::is_nil(RMSSvcMgr) == TRUE)
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil(RMSSvcMgr) == TRUE");
                SET_MSG_RC(strRMSMgr_GetServiceManager_out, MSG_EXT_SERVER_NIL_OBJ, RC_EXT_SERVER_NIL_OBJ);
                return(RC_EXT_SERVER_NIL_OBJ);
            }
            try
            {
#ifdef EBROKER                                                      //D02.0057
                newObjRef = IMRegistry::orbPtr->object_to_string(RMSSvcMgr);             //D02.0057
#else                                                               //D02.0057
                newObjRef = RMSSvcMgr->_object_to_string();
#endif                                                              //D02.0057                               
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "RMSSvcMgr->_object_to_string() raises exception");
                SET_MSG_RC(strRMSMgr_GetServiceManager_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
                return(RC_SYSTEM_ERROR);
            }
            try
            {
                PPT_METHODTRACE_V1("", "externalServerList.remove()");
                try
                {
                    externalServerList.remove((char *)RMSServerName);
                }
                catch( ... )
                {
                    PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                }

                externalServerList.add(CIMFWStrDup(RMSServerName), CIMFWStrDup(newObjRef));
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "externalServerList.add() raises exception");
                SET_MSG_RC(strRMSMgr_GetServiceManager_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
                return(RC_SYSTEM_ERROR);
            }
        }

        /*--------------------------*/
        /*   set output parameter   */
        /*--------------------------*/
        try
        {
#ifdef EBROKER                                                      //D02.0057
                strRMSMgr_GetServiceManager_out.RMSSvcMgr = IMRegistry::orbPtr->object_to_string(RMSSvcMgr);             //D02.0057
#else                                                               //D02.0057
                strRMSMgr_GetServiceManager_out.RMSSvcMgr = RMSSvcMgr->_object_to_string();
#endif                                                              //D02.0057                               
        }
        catch(...)
        {
            PPT_METHODTRACE_V1("", "RMSSvcMgr->_object_to_string() raises exception");
            SET_MSG_RC(strRMSMgr_GetServiceManager_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
            return(RC_SYSTEM_ERROR);
        }

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_RMSMgr_GetServiceManager");

        return (RC_OK);
    }
    CATCH_GLOBAL_EXCEPTIONS(strRMSMgr_GetServiceManager_out, cs_RMSMgr_GetServiceManager, methodName);
}
