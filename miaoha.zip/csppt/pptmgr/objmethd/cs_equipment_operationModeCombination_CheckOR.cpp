#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/equipment_operationModeCombination_Check.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:46:43 [ 7/13/07 19:46:44 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: equipment_operationModeCombination_Check.cpp
//

//INN-R170012 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp"//INN-R170012

#include "ppcope.hh"
#include "pportrs.hh"
#include "pcodegl.hh"
#include "pmom.hh"


// Class: PPTManager
//
// Service: equipment_operationModeCombination_Check()
//
// Change history: 
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/01          H.Katoh        Initial Release
// 2000/09/21 Q3000124 S.Kawabe       Add Nil Check
//
// Description: 
// 
// Return: 
//     Long
//
//[Function Description]:
//
//  * Check whether all requested operation mode for ports in 1 group is same or not
//  * If requested mode change type contains Equipment-Online-Mode-Change at least for 1 port,
//    all requested mode change must contain Equipment-Online-Mode-Change.
//  * Return mode change type for each port group.
//      - If reqested mode change contains Equipment-Online-Mode-Change, then modeChangeType
//        of return structure is set as SP_Eqp_Operation_OnlineMode_Change
//      - If reqested mode change contains PortGroup-Access-Mode-Change, then modeChangeType
//        of return structure is set as SP_Eqp_Operation_AccessMode_Change
//      - If reqested mode change does not contains both of Equipment-Online-Mode-Change and
//        PortGroup-Access-Mode-Change, then modeChangeType of return structure is set as
//        SP_Eqp_Operation_OtherMode_Change
//
//
//[Input Parameters]:
//  in  pptObjCommonIn                  strObjCommonIn;
//  in  objectIdentifier                equipmentID;
//  in  pptPortOperationModeSequence    strPortOperationModeSeq;
//
//
//[Output Parameters]:
//
//  out objEquipment_operationModeCombination_Check_out  strEquipment_operationModeCombination_Check_out;
//
//  typedef struct objEquipment_operationModeCombination_Check_out_struct {
//      pptRetCode              strResult;
//      stringSequence          portGroup;
//      stringSequence          modeChangeType;
//  } objEquipment_operationModeCombination_Check_out;
//
//
// Require: 
//
// Ensure:
//
// Exception: 
// 
// Pseudo code: 
// 
// Innotron Modification history:
// Date       DCR/PCR No   Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/11 INN-R170012  Vera Chen      FOUP Exchanger Support
//
//
//INN-R170012 CORBA::Long PPTManager_i::equipment_operationModeCombination_Check(   
CORBA::Long CS_PPTManager_i::equipment_operationModeCombination_Check( //INN-R170012
                                objEquipment_operationModeCombination_Check_out& strEquipment_operationModeCombination_Check_out,
                                const pptObjCommonIn& strObjCommonIn,
                                const objectIdentifier& equipmentID,
                                const pptPortOperationModeSequence& strPortOperationModeSeq )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::equipment_operationModeCombination_Check");

        //-------------------------------------
        // Get object reference of Equipment
        // object reference must be retrieved
        //-------------------------------------
        PPT_METHODTRACE_V1("CS_PPTManager_i::equipment_operationModeCombination_Check","Get object reference of Equipment object reference must be retrieved");

        PosMachine_var aPosMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aPosMachine,
                                         equipmentID,
                                         strEquipment_operationModeCombination_Check_out,
                                         equipment_operationModeCombination_Check );

        //-------------------------------------
        // Get object reference of PosPortResource
        // object reference must be retrieved
        // and retrieve each port's operation mode.
        //-------------------------------------
        CORBA::Long lenModeSeq = strPortOperationModeSeq.length();
        PPT_METHODTRACE_V2("CS_PPTManager_i::equipment_operationModeCombination_Check","Get object reference of PosPortResource", lenModeSeq);

        pptPortOperationModeSequence tmpPortOperationModeSeq;
        tmpPortOperationModeSeq.length( lenModeSeq );

        CORBA::Long i, j, k;
        for ( i=0; i < lenModeSeq; i++ )
        {
            PortResource_var aPort;
            PPT_CONVERT_PORTID_TO_PORTRESOURCE_OR( aPosMachine,
                                                   aPort,
                                                   strPortOperationModeSeq[i].portID,
                                                   strEquipment_operationModeCombination_Check_out,
                                                   equipment_operationModeCombination_Check );
            PosPortResource_var aPosPort;
            aPosPort = PosPortResource::_narrow(aPort);

            //Q3000124 add start
            if ( CORBA::is_nil(aPosPort) )
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i::equipment_operationModeCombination_Check","aPosPort is nil");
                PPT_SET_MSG_RC_KEY(strEquipment_operationModeCombination_Check_out,
                                   MSG_NOT_FOUND_PORTRESOURCE,
                                   RC_NOT_FOUND_PORTRESOURCE,
                                   "strPortOperationModeSeq[i].portID.identifier");
                return( RC_NOT_FOUND_PORTRESOURCE );
            }
            //Q3000124 add end

            PosMachineOperationMode_var aMachineMode;
            try
            {
                aMachineMode = aPosPort->getMachineOperationMode();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::getMachineOperationMode)

            if ( CORBA::is_nil(aMachineMode) )
            {
                SET_MSG_RC( strEquipment_operationModeCombination_Check_out,
                            MSG_NOT_FOUND_MACHINEOPEMODE,
                            RC_NOT_FOUND_MACHINEOPEMODE );

                return RC_NOT_FOUND_MACHINEOPEMODE;
            }

            posOperationModeInfo_var anOperationModeInfo;
            try
            {
               anOperationModeInfo = aMachineMode->getOperationModeInfo();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosMachineOperationMode::getOperationModeInfo)

            PPT_SET_OBJECT_IDENTIFIER( tmpPortOperationModeSeq[i].portID,
                                       aPosPort,
                                       strEquipment_operationModeCombination_Check_out,
                                       equipment_operationModeCombination_Check,
                                       PosPortResource );

            try
            {
               tmpPortOperationModeSeq[i].portGroup = aPosPort->getPortGroup();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::getPortGroup)

            PPT_SET_OBJECT_IDENTIFIER( tmpPortOperationModeSeq[i].strOperationMode.operationMode,
                                       aMachineMode,
                                       strEquipment_operationModeCombination_Check_out,
                                       equipment_operationModeCombination_Check,
                                       PosMachineOperationMode );

            tmpPortOperationModeSeq[i].strOperationMode.onlineMode         = anOperationModeInfo->onlineMode;
            tmpPortOperationModeSeq[i].strOperationMode.dispatchMode       = anOperationModeInfo->dispatchMode;
            tmpPortOperationModeSeq[i].strOperationMode.accessMode         = anOperationModeInfo->accessMode;
            tmpPortOperationModeSeq[i].strOperationMode.operationStartMode = anOperationModeInfo->operationStartMode;
            tmpPortOperationModeSeq[i].strOperationMode.operationCompMode  = anOperationModeInfo->operationCompMode;
        }
        
        //INN-R170012 add start
        stringSequence_var specialControls;
        try
        {
            specialControls = aPosMachine->getSpecialEquipmentControls();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getSpecialEquipmentControls)
        CORBA::Boolean bInlinePilot = FALSE;
        for ( CORBA::ULong iCnt=0; iCnt < specialControls->length(); iCnt++ )
        {
            PPT_METHODTRACE_V2("", "loop to specialControls->length()", iCnt);
            if ( 0 == CIMFWStrCmp((*specialControls)[iCnt], SP_Mc_SpecialEquipmentControl_InlinePilot))
            {
                PPT_METHODTRACE_V1("", "specialControl is Inline Pilot");
                bInlinePilot=TRUE;
                break;
            }
        }
        //INN-R170012 add end
        
        
        //-------------------------------------
        // Check OperationMode Combination
        // in each port group
        //-------------------------------------
        CORBA::Long lenTmpModeSeq = tmpPortOperationModeSeq.length();
        PPT_METHODTRACE_V2("CS_PPTManager_i::equipment_operationModeCombination_Check","Check OperationMode Combination", lenTmpModeSeq);

        for ( i=0; i < lenModeSeq; i++ )
        {
            for ( j=0; j < lenTmpModeSeq; j++ )
            {
                if ( 0 == CIMFWStrCmp(strPortOperationModeSeq[i].portID.identifier, tmpPortOperationModeSeq[j].portID.identifier) )
                {
                    PPT_METHODTRACE_V1("CS_PPTManager_i::equipment_operationModeCombination_Check","strPortOperationModeSeq[i].portID == tmpPortOperationModeSeq[j].portID");

                    if ( 0 != CIMFWStrCmp(strPortOperationModeSeq[i].portGroup, tmpPortOperationModeSeq[j].portGroup) )
                    {
                        SET_MSG_RC( strEquipment_operationModeCombination_Check_out,
                                    MSG_INVALID_INPUT_PARM,
                                    RC_INVALID_INPUT_PARM );

                        return RC_INVALID_INPUT_PARM ;
                    }
                }
            }
        }

        stringSequence tmpPortGroupSeq;
        objectIdentifierSequence tmpOperationModeSeq;

        for ( i=0; i < lenModeSeq; i++ )
        {
            CORBA::Long nTmpPortGroupPos = 0;
            CORBA::Boolean bPortGroupAdded = FALSE;

            CORBA::Long lenGroupSeq = tmpPortGroupSeq.length();
            for ( j=0; j < lenGroupSeq; j++ )
            {
                if ( 0 == CIMFWStrCmp(strPortOperationModeSeq[i].portGroup, tmpPortGroupSeq[j]) )
                {
                    PPT_METHODTRACE_V1("CS_PPTManager_i::equipment_operationModeCombination_Check","strPortOperationModeSeq[i].portGroup == tmpPortGroupSeq[j]");

                    nTmpPortGroupPos = j;
                    bPortGroupAdded = TRUE;
                    break;
                }
            }
            if ( bPortGroupAdded == FALSE )
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i::equipment_operationModeCombination_Check", "bPortGroupAdded = FALSE");

                tmpPortGroupSeq.length(lenGroupSeq + 1);

                CORBA::Long lenOpeMode = tmpOperationModeSeq.length();
                tmpOperationModeSeq.length(lenOpeMode + 1);

                tmpPortGroupSeq[lenGroupSeq] = strPortOperationModeSeq[i].portGroup;
                tmpOperationModeSeq[lenOpeMode] = strPortOperationModeSeq[i].strOperationMode.operationMode;
            }
            else
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i::equipment_operationModeCombination_Check","bPortGroupAdded == TRUE");

                if ( 0 != CIMFWStrCmp(strPortOperationModeSeq[i].strOperationMode.operationMode.identifier,
                                      tmpOperationModeSeq[nTmpPortGroupPos].identifier) )
                {
                    SET_MSG_RC( strEquipment_operationModeCombination_Check_out,
                                MSG_INVALID_PORT_MODE_COMBINATION,
                                RC_INVALID_PORT_MODE_COMBINATION );

                    return RC_INVALID_PORT_MODE_COMBINATION;
                }
            }
        }

        //-------------------------------------
        // Check OperationMode Change Type
        //-------------------------------------
        PPT_METHODTRACE_V1("CS_PPTManager_i::equipment_operationModeCombination_Check","Check OperationMode Change Type");

        lenModeSeq = strPortOperationModeSeq.length();
        lenTmpModeSeq = tmpPortOperationModeSeq.length();

        for ( i=0; i < lenModeSeq; i++ )
        {
            for ( j=0; j < lenModeSeq; j++ )
            {
                CORBA::String_var modeChangeType;

                if ( 0 == CIMFWStrCmp(strPortOperationModeSeq[i].portID.identifier, tmpPortOperationModeSeq[j].portID.identifier) )
                {
                    PPT_METHODTRACE_V1("CS_PPTManager_i::equipment_operationModeCombination_Check","strPortOperationModeSeq[i].portID == tmpPortOperationModeSeq[j].portID");

                    if ( 0 != CIMFWStrCmp(strPortOperationModeSeq[i].strOperationMode.onlineMode,
                                          tmpPortOperationModeSeq[j].strOperationMode.onlineMode)
                        && 0 != CIMFWStrCmp(modeChangeType, SP_Eqp_Operation_OnlineMode_Change) )
                    {
                        PPT_METHODTRACE_V1("CS_PPTManager_i::equipment_operationModeCombination_Check","set modeChangeType = SP_Eqp_Operation_OnlineMode_Change");

                        modeChangeType = CIMFWStrDup( SP_Eqp_Operation_OnlineMode_Change );
                    }

                    if ( 0 == CIMFWStrCmp(strPortOperationModeSeq[i].strOperationMode.onlineMode,
                                          tmpPortOperationModeSeq[j].strOperationMode.onlineMode)
                        && 0 != CIMFWStrCmp(strPortOperationModeSeq[i].strOperationMode.accessMode,
                                            tmpPortOperationModeSeq[j].strOperationMode.accessMode)
//P3000054              && 0 != CIMFWStrCmp(modeChangeType, SP_Eqp_Operation_AccessMode_Change)
                        && 0 != CIMFWStrCmp(modeChangeType, SP_Eqp_Operation_OnlineMode_Change)
                        && 0 != CIMFWStrCmp(modeChangeType, SP_Eqp_Operation_AccessMode_Change) )
                    {
                        PPT_METHODTRACE_V1("CS_PPTManager_i::equipment_operationModeCombination_Check","set modeChangeType = SP_Eqp_Operation_AccessMode_Change");

                        modeChangeType = CIMFWStrDup( SP_Eqp_Operation_AccessMode_Change );
                    }

                    if ( 0 == CIMFWStrCmp(strPortOperationModeSeq[i].strOperationMode.onlineMode,
                                          tmpPortOperationModeSeq[j].strOperationMode.onlineMode)
                        && 0 == CIMFWStrCmp(strPortOperationModeSeq[i].strOperationMode.accessMode,
                                            tmpPortOperationModeSeq[j].strOperationMode.accessMode)
                        && 0 != CIMFWStrCmp(modeChangeType, SP_Eqp_Operation_OnlineMode_Change)
                        && 0 != CIMFWStrCmp(modeChangeType, SP_Eqp_Operation_AccessMode_Change) )
                    {
                        PPT_METHODTRACE_V1("CS_PPTManager_i::equipment_operationModeCombination_Check","set modeChangeType = SP_Eqp_Operation_OtherMode_Change");

                        modeChangeType = CIMFWStrDup( SP_Eqp_Operation_OtherMode_Change );
                    }

                    CORBA::Boolean bPortGroupAdded = FALSE;
                    CORBA::Long lenPortGroup = strEquipment_operationModeCombination_Check_out.portGroup.length();

                    for ( k=0; k < lenPortGroup; k++ )
                    {
                        if ( 0 == CIMFWStrCmp(strEquipment_operationModeCombination_Check_out.portGroup[k], tmpPortOperationModeSeq[j].portGroup) )
                        {
                            PPT_METHODTRACE_V1("CS_PPTManager_i::equipment_operationModeCombination_Check","portGroup[k] == tmpPortOperationModeSeq[j].portGroup");

                            bPortGroupAdded = TRUE;
                            break;
                        }
                    }
                    if ( bPortGroupAdded == FALSE )
                    {
                        PPT_METHODTRACE_V1("CS_PPTManager_i::equipment_operationModeCombination_Check","bPortGroupAdded == FALSE");

                        strEquipment_operationModeCombination_Check_out.portGroup.length(lenPortGroup + 1);
                        strEquipment_operationModeCombination_Check_out.modeChangeType.length(lenPortGroup + 1);

                        strEquipment_operationModeCombination_Check_out.portGroup[lenPortGroup] = strPortOperationModeSeq[i].portGroup;
                        strEquipment_operationModeCombination_Check_out.modeChangeType[lenPortGroup] = modeChangeType;
                    }

                    break;
                }
            }
        }

        //-------------------------------
        // Check requested Operation mode
        // change type combination
        //-------------------------------
        PPT_METHODTRACE_V1("CS_PPTManager_i::equipment_operationModeCombination_Check","Check requested Operation mode change type combination");

        CORBA::Boolean bModeChangeTypeOnline = FALSE;

        CORBA::Long lenChgType = strEquipment_operationModeCombination_Check_out.modeChangeType.length();
        for ( i=0; i < lenChgType; i++ )
        {
            if ( 0 == CIMFWStrCmp(strEquipment_operationModeCombination_Check_out.modeChangeType[i], SP_Eqp_Operation_OnlineMode_Change) )
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i::equipment_operationModeCombination_Check","modeChangeType[i] == SP_Eqp_Operation_OnlineMode_Change");

                bModeChangeTypeOnline = TRUE;
                break;
            }
        }
        CORBA::Long nChangeOperationModeSeqLen = strPortOperationModeSeq.length();
        if ( bModeChangeTypeOnline 
          && nChangeOperationModeSeqLen>1 )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i::equipment_operationModeCombination_Check","bModeChangeTypeOnline == TRUE");

            for ( i=1; i < nChangeOperationModeSeqLen; i++ )
            {
                if ( 0 != CIMFWStrCmp(strPortOperationModeSeq[0].strOperationMode.onlineMode,
                                      strPortOperationModeSeq[i].strOperationMode.onlineMode) )
                {
                    //INN-R170012 add start
                    if(!bInlinePilot)
                    {
                    //INN-R170012 add end
                        SET_MSG_RC( strEquipment_operationModeCombination_Check_out,
                                    MSG_INVALID_PORT_MODE_COMBINATION,
                                    RC_INVALID_PORT_MODE_COMBINATION );

                        return RC_INVALID_PORT_MODE_COMBINATION;
                    }//INN-R170012
                }
            }
        }

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::equipment_operationModeCombination_Check");

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strEquipment_operationModeCombination_Check_out, equipment_operationModeCombination_Check, methodName)
}
