//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cs_durable_subState_GetOR.cpp
//
//INN-R170003  #include "pptmgr.hpp"
#include "cs_pptmgr.hpp"   //INN-R170003
#include "pcas.hh"
#include "prtclp.hh"
#include "ppcdr.hh"
#include "pdstat.hh"

// Class: CS_PPTManager
//
// Service: durable_subState_Get()
//
// Change history:
// Date       Defect#   Person         Comments
// ---------- --------- -------------- -------------------------------------------
// 2016/07/27 DSN000101569 C.Mo      Durable Sub Status Control Support.
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/11/02 INN-R170003  Nick Tsai      Support Fixture
//
//
//[Function Description]:
//  This function returns Durable Sub State of specified durable.
//
//[Input Parameters]:
//  const pptObjCommonIn&                    strObjCommonIn,
//  const objDurable_subState_Get_in&        strDurable_subState_Get_in
//
//  typedef struct objDurable_subState_Get_in_struct{
//      string                              durableCategory;
//      objectIdentifier                    durableID;
//      any                                 siInfo;
//  } objDurable_subState_Get_in;
//
//[Output Parameters]:
//  objDurable_subState_Get_out&             strDurable_subState_Get_out
//
//  typedef struct objDurable_subState_Get_out_struct{
//      pptRetCode                          strResult;
//      string                              durableState;
//      objectIdentifier                    durableSubStatus;
//      any                                 siInfo;
//  } objDurable_subState_Get_out;
//
//[Return Value]:
//  Return Code                  Messsage ID
//  -------------------------   --------------------------------------------------
//  RC_OK                        MSG_OK
//
//INN-R170003 CORBA::Long PPTManager_i::durable_subState_Get(
CORBA::Long CS_PPTManager_i::durable_subState_Get(    //INN-R170003
    objDurable_subState_Get_out&             strDurable_subState_Get_out,
    const pptObjCommonIn&                    strObjCommonIn,
    const objDurable_subState_Get_in&        strDurable_subState_Get_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::durable_subState_Get");

        CORBA::String_var durableStatus = CIMFWStrDup("");
        PosDurableSubState_var aDurableSubState;

        if (CIMFWStrCmp(strDurable_subState_Get_in.durableCategory, SP_DurableCat_Cassette) == 0)
        {
            PPT_METHODTRACE_V1("", "durableCategory is Cassette");
            PosCassette_var aCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR(aCassette,
                                                  strDurable_subState_Get_in.durableID,
                                                  strDurable_subState_Get_out,
                                                  durable_subState_Get);

            try
            {
                durableStatus = aCassette->getDurableState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getDurableState)

            try
            {
                aDurableSubState = aCassette->getDurableSubState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getDurableSubState)
        }
        else if (CIMFWStrCmp(strDurable_subState_Get_in.durableCategory, SP_DurableCat_ReticlePod) == 0)
        {
            PPT_METHODTRACE_V1("", "durableCategory is ReticlePod");
            PosReticlePod_var aReticlePod;
            PPT_CONVERT_RETICLEPODID_TO_RETICLEPOD_OR(aReticlePod,
                                                      strDurable_subState_Get_in.durableID,
                                                      strDurable_subState_Get_out,
                                                      durable_subState_Get);

            CORBA::Boolean isAvailableFlag = FALSE;
            try
            {
                isAvailableFlag = aReticlePod->isAvailable();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::isAvailable)

            CORBA::Boolean isNotAvailableFlag = FALSE;
            try
            {
                isNotAvailableFlag = aReticlePod->isNotAvailable();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::isNotAvailable)

            CORBA::Boolean isInUseFlag = FALSE;
            try
            {
                isInUseFlag = aReticlePod->isInUse();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::isInUse);

            CORBA::Boolean isScrappedFlag = FALSE;
            try
            {
                isScrappedFlag = aReticlePod->isScrapped();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::isScrapped);

            if (isAvailableFlag == TRUE)
            {
                PPT_METHODTRACE_V1("", "durableStatus == CIMFW_Durable_Available");
                durableStatus = CIMFWStrDup(CIMFW_Durable_Available);
            }
            else if (isNotAvailableFlag == TRUE)
            {
                PPT_METHODTRACE_V1("", "durableStatus == CIMFW_Durable_NotAvailable");
                durableStatus = CIMFWStrDup(CIMFW_Durable_NotAvailable);
            }
            else if (isInUseFlag == TRUE)
            {
                PPT_METHODTRACE_V1("", "durableStatus == CIMFW_Durable_InUse");
                durableStatus = CIMFWStrDup(CIMFW_Durable_InUse);
            }
            else if (isScrappedFlag == TRUE)
            {
                PPT_METHODTRACE_V1("", "durableStatus == CIMFW_Durable_Scrapped");
                durableStatus = CIMFWStrDup(CIMFW_Durable_Scrapped);
            }
            else
            {
                PPT_METHODTRACE_V1("", "durableStatus == CIMFW_Durable_Undefined");
                durableStatus = CIMFWStrDup(CIMFW_Durable_Undefined);
            }

            try
            {
                aDurableSubState = aReticlePod->getDurableSubState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::getDurableSubState)
        }
        else if (CIMFWStrCmp(strDurable_subState_Get_in.durableCategory, SP_DurableCat_Reticle) == 0)
        {
            PPT_METHODTRACE_V1("", "durableCategory is Reticle");
            PosProcessDurable_var aReticle;
            PPT_CONVERT_RETICLEID_TO_RETICLE_OR(aReticle,
                                                strDurable_subState_Get_in.durableID,
                                                strDurable_subState_Get_out,
                                                durable_subState_Get);

            try
            {
                durableStatus = aReticle->getDurableState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getDurableState)

            try
            {
                aDurableSubState = aReticle->getDurableSubState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getDurableSubState)
        }
        //INN-R170003 add start
        else if (CIMFWStrCmp(strDurable_subState_Get_in.durableCategory, SP_DurableCat_Fixture) == 0)
        {
            PPT_METHODTRACE_V1("", "durableCategory is Fixture");
            PosProcessDurable_var aFixture;
            PPT_CONVERT_FIXTUREID_TO_FIXTURE_OR(aFixture,
                                                strDurable_subState_Get_in.durableID,
                                                strDurable_subState_Get_out,
                                                durable_subState_Get);

            try
            {
                durableStatus = aFixture->getDurableState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getDurableState)

            try
            {
                aDurableSubState = aFixture->getDurableSubState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getDurableSubState)
        }
        //INN-R170003 add end
        strDurable_subState_Get_out.durableStatus = durableStatus;

        if (CORBA::is_nil(aDurableSubState) != TRUE)
        {
            PPT_METHODTRACE_V1("", "durableSubState is null");
            PPT_SET_OBJECT_IDENTIFIER(strDurable_subState_Get_out.durableSubStatus, aDurableSubState, strDurable_subState_Get_out, durable_subState_Get, PosDurableSubState);
        }

        PPT_METHODTRACE_V2("", "Durable Status is",     strDurable_subState_Get_out.durableStatus);
        PPT_METHODTRACE_V2("", "Durable Sub Status is", strDurable_subState_Get_out.durableSubStatus.identifier);
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::durable_subState_Get");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strDurable_subState_Get_out, durable_subState_Get, methodName)
}

