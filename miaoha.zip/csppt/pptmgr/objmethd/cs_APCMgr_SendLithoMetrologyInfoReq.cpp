//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
//
// SiView
// Name: cs_APCMgr_SendLithoMetrologyInfoReq.cpp
//

// Class: CS_PPTManager
//
// [Object Function Name]: long   cs_APCMgr_SendLithoMetrologyInfoReq.cpp
//
//
// Innotron Modification history:
// Date       Defect#   Person         Comments
// ---------- --------- -------------- -------------------------------------------
// 2017/09/26 INN-R170009  Xinxin_Liu      Add APC Litho
//
// Function Description:
//
// Input Parameters:
// in csobjAPCMgr_SendLithoMetrologyInfoReq_in  strObjAPCMgr_SendLithoMetrologyInfoReq_in;
//
//typedef struct csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct {
//    objectIdentifier            equipmentID;
//    pptStartCassetteSequence    strStartCassette;
//    string                      action;
//    any                         siInfo;
//}csObjAPCMgr_SendLithoMetrologyInfoReq_in;

//
// Output Parameters:
// out csObjAPCMgr_SendLithoMetrologyInfoReq_out strObjAPCMgr_SendLithoMetrologyInfoReq_out;
//
//typedef struct csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct {
//    pptRetCode                      strResult;
//    any                             siInfo;
//}csObjAPCMgr_SendLithoMetrologyInfoReq_out;

//
// Return Value:
//
// Exception:
//
// Pseudo code:
//

#include "cs_pptmgr.hpp"


CORBA::Long CS_PPTManager_i::cs_APCMgr_SendLithoMetrologyInfoReq(
    csObjAPCMgr_SendLithoMetrologyInfoReq_out&       strObjAPCMgr_SendLithoMetrologyInfoReq_out,
    const pptObjCommonIn&                              strObjCommonIn,
    const csObjAPCMgr_SendLithoMetrologyInfoReq_in&  strObjAPCMgr_SendLithoMetrologyInfoReq_in )
{
    CORBA::Long rc = RC_OK;

    return(RC_OK);
}