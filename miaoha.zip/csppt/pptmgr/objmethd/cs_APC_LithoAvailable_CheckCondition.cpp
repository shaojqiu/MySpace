//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
//
// SiView
// Name: cs_APC_LithoAvailable_CheckCondition.cpp
//

// Class: CS_PPTManager
//
// [Object Function Name]: long   cs_APC_LithoAvailable_CheckCondition
//
//
// Innotron Modification history:
// Date       Defect#     Person        Comments
// ---------- ----------- ------------- -------------------------------------------
// 2017/09/15 INN-R170009 Gary Ke       Add for APC Litho Available Check COndition
//
// Function Description:
//
// Input Parameters:
// in csObjUserData_GetByOperation_in  strUserData_GetByOperation_in;
//
// typedef struct csObjUserData_GetByOperation_in_struct {
//    objectIdentifier        routeID;
//    string                  operationNumber;
//    stringSequence          userDataNameSeq;
//    any                     siInfo;
// } csObjUserData_GetByOperation_in
//
// Output Parameters:
// out csObjUserData_GetByOperation_out strUserData_GetByOperation_out;
//
// typedef struct csObjUserData_GetByOperation_out_struct {
//     pptRetCode             strResult;
//     pptUserDataSequence    strUserDataSeq;
//     any                    siInfo;
// } csObjUserData_GetByOperation_out;
//
// Return Value:
//
// Exception:
//
// Pseudo code:
//

#include "cs_pptmgr.hpp"
#include "plot.hh"
#include "ppcflwx.hh"
#include "ppcflw.hh"
#include "ppcope.hh"
#include "ppcopsp.hh"
#include "pportrs.hh"

CORBA::Long CS_PPTManager_i::cs_APC_LithoAvailable_CheckCondition(
    csObjAPC_LithoAvailable_CheckCondition_out&       strAPC_LithoAvailable_CheckCondition_out,
    const pptObjCommonIn&                             strObjCommonIn,
    const csObjAPC_LithoAvailable_CheckCondition_in&  strAPC_LithoAvailable_CheckCondition_in )
{
    char * methodName = NULL;
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_APC_LithoAvailable_CheckCondition");
    sqlca sqlca;
    try
    {
        CORBA::Long rc = RC_OK;
        /*------------------*/
        /*    Initialize    */
        /*------------------*/
        CIMFWStrCpy(strAPC_LithoAvailable_CheckCondition_out.inquireType,"OFF");
        strAPC_LithoAvailable_CheckCondition_out.recommendFlag = FALSE;
        strAPC_LithoAvailable_CheckCondition_out.usedFlag      = FALSE;
        strAPC_LithoAvailable_CheckCondition_out.metrologyFlag = FALSE;
        /*-------------------------------*/
        /*    Get APCLithoCombineFlag    */
        /*-------------------------------*/
        csObjUserData_GetByOperation_out strUserData_GetByOperation_out;
        csObjUserData_GetByOperation_in  strUserData_GetByOperation_in;
        strUserData_GetByOperation_in.routeID         = strAPC_LithoAvailable_CheckCondition_in.routeID; 
        strUserData_GetByOperation_in.operationNumber = strAPC_LithoAvailable_CheckCondition_in.operationNumber; 
        PPT_METHODTRACE_V2( "", "routeID"        , strUserData_GetByOperation_in.routeID.identifier);
        PPT_METHODTRACE_V2( "", "operationNumber", strUserData_GetByOperation_in.operationNumber);
        rc = cs_userData_GetByOperation( strUserData_GetByOperation_out,
                                         strObjCommonIn,   
                                         strUserData_GetByOperation_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cs_userData_GetByOperation() != RC_OK", rc);
            strAPC_LithoAvailable_CheckCondition_out.strResult = strUserData_GetByOperation_out.strResult;
            return( rc );
        }
        /*-------------------*/
        /*    Get Main PD    */
        /*-------------------*/
        ProcessDefinition_var    aPD;
        PosProcessDefinition_var aPosPD;
        try
        {
            aPD = theProcessDefinitionManager->findMainProcessDefinitionNamed(strAPC_LithoAvailable_CheckCondition_in.routeID.identifier) ;
        }
        CATCH_AND_RAISE_EXCEPTIONS(ProcessDefinitionManager::findMainProcessDefinitionNamed)
        aPosPD = PosProcessDefinition::_narrow( aPD );
        if(CORBA::is_nil(aPosPD) == TRUE)
        {
            PPT_METHODTRACE_V1("", "CORBA::is_nil(aPosPD) == TRUE");
            return(RC_NOT_FOUND_PF);
        }
        PosProcessFlow_var aPPF;
        try
        {
            aPPF = aPosPD -> getActiveProcessFlow();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDefinition::getActiveProcessFlow)
        if(CORBA::is_nil(aPPF) == TRUE)
        {
            PPT_METHODTRACE_V1("", "CORBA::is_nil(aPPF) == TRUE");
            return RC_NOT_FOUND_PF;
        }
        /*---------------------------*/
        /*    Get operationNumber    */
        /*---------------------------*/
        PosProcessOperationSpecification_var aMainPOS;
        try
        {
            aMainPOS = aPPF -> findProcessOperationSpecificationOnDefault( strUserData_GetByOperation_in.operationNumber );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlow::findProcessOperationSpecificationOnDefault)
        /*----------------------*/
        /*    Get photolayer    */
        /*----------------------*/        
        CORBA::String_var varphotoLayer;
        try
        {
            varphotoLayer = aMainPOS -> getPhotoLayer ();
        }
        CATCH_AND_RAISE_EXCEPTIONS(MainPOS::getPhotoLayer);
        PPT_METHODTRACE_V2("","varphotoLayer" , varphotoLayer);
        PosMachine_var aMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine,
                                         strAPC_LithoAvailable_CheckCondition_in.equipmentID,
                                         strAPC_LithoAvailable_CheckCondition_out,
                                         csObjAPC_LithoAvailable_CheckCondition );

        /*-----------------------------------*/
        /*    Get CS_M_EQP_LITHO_ITM_FLAG    */
        /*-----------------------------------*/
        CORBA::String_var varLithoITMFlag;
        try
        {
            varLithoITMFlag = aMachine->getUserDataNamed( CS_M_EQP_LITHO_ITM_FLAG );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getUserDataNamed)
        CORBA::Boolean bAPCConditionAvailable = FALSE;
        PPT_METHODTRACE_V2("","varLithoITMFlag"          , varLithoITMFlag);
        PPT_METHODTRACE_V2("","bAPCConditionAvailable =" , bAPCConditionAvailable);
        /*----------------------------------------------*/
        /*    Check CS_M_EQP_LITHO_ITM_FLAG Validity    */
        /*----------------------------------------------*/
        if( CIMFWStrCmp(varLithoITMFlag, "L") == 0 )
        {
            PPT_METHODTRACE_V1("", "varLithoITMFlag == L");
            bAPCConditionAvailable = TRUE;
            PPT_METHODTRACE_V2("","bAPCConditionAvailable =" , bAPCConditionAvailable);
            /*-----------------------------------------*/
            /*    Get CS_M_EQP_LITHO_ITM_LAYER_FLAG    */
            /*-----------------------------------------*/
            CORBA::String_var varLithoITMLayerFlag;
            try
            {
                varLithoITMLayerFlag = aMachine->getUserDataNamed( CS_M_EQP_LITHO_ITM_LAYER_FLAG );
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getUserDataNamed)
            PPT_METHODTRACE_V2("","varLithoITMLayerFlag" , varLithoITMLayerFlag);
            //--------------------------------------------------------------------------
            // Make a strITMLayerFlagSeq string. Parse strITMLayerFlagSeq string
            // For example,
            // A string is "PL01=L;PL02=L".   ==> strITMLayerFlagSeq[0]  <-- PL01=L
            //                                ==> strITMLayerFlagSeq[1]  <-- PL02=L
            //--------------------------------------------------------------------------
            stringSequence strITMLayerFlagSeq;
            strITMLayerFlagSeq.length(20);
            char *ptr = NULL;
            char *tmpptr = NULL;
            char buf[4096];
            memset( buf, '\0', sizeof( buf ) );
            CORBA::Long upLen = 20;
            CORBA::Long t_len = 20;
            CORBA::Long index = 0;
            CIMFWStrCpy( buf, varLithoITMLayerFlag );
            for (ptr = strtok_r(buf, ";",&tmpptr); ptr != NULL; ptr = strtok_r(NULL, ";", &tmpptr))
            {
                if(index >= t_len);
                {
                    t_len += upLen;
                    strITMLayerFlagSeq.length(t_len);
                }
                strITMLayerFlagSeq[index] = CIMFWStrDup( ptr );
                PPT_METHODTRACE_V2("","strITMLayerFlagSeq" , strITMLayerFlagSeq[index]);
                index++;
            }
            strITMLayerFlagSeq.length(index);
            PPT_METHODTRACE_V2("","index" , index);
            //--------------------------------------------------------------------------
            // Make a strITMLayerFlagNewSeq string. Parse strITMLayerFlagNewSeq string
            // For example,
            // A string is "PL01=L".   ==> strITMLayerFlagNewSeq[0]  <-- PL01
            //                         ==> strITMLayerFlagNewSeq[1]  <-- L
            //--------------------------------------------------------------------------
            CORBA::Long ITMLayerFlagSeqLen = strITMLayerFlagSeq.length();
            PPT_METHODTRACE_V2("","ITMLayerFlagSeqLen" , ITMLayerFlagSeqLen);			
            stringSequence strITMLayerFlagNewSeq;
            strITMLayerFlagNewSeq.length(20);
            CORBA::Long uptmpLen = 20;
            CORBA::Long tmplen   = 20;
            CORBA::Long newindex = 0;
            for (CORBA::Long lngITMLayerFlagSeqCnt = 0; lngITMLayerFlagSeqCnt < ITMLayerFlagSeqLen; lngITMLayerFlagSeqCnt++ )
            {
                char *newptr = NULL;
                char *tmpnewptr = NULL;
                char tmpbuf[4096];
                memset( tmpbuf, '\0', sizeof( tmpbuf ) );
                CIMFWStrCpy( tmpbuf, strITMLayerFlagSeq[lngITMLayerFlagSeqCnt] );
                PPT_METHODTRACE_V2("","tmpbuf" , tmpbuf);
                for (newptr = strtok_r(tmpbuf, "=",&tmpnewptr); newptr != NULL; newptr = strtok_r(NULL,"=",&tmpnewptr))
                {
                    if(newindex >= tmplen);
                    {
                        tmplen += uptmpLen;
                        strITMLayerFlagNewSeq.length(tmplen);
                    }
                    strITMLayerFlagNewSeq[newindex] = CIMFWStrDup( newptr );
                    PPT_METHODTRACE_V2("","strITMLayerFlagNewSeq" , strITMLayerFlagNewSeq[newindex]);
                    newindex++;
                }
            }
            strITMLayerFlagNewSeq.length(newindex);
            CORBA::Long ITMLayerFlagSeqNewLen = strITMLayerFlagNewSeq.length();            
            csLithoITMLayerFlagSequence strITMLayerFlagAllSeq;	
            CORBA::Long ITMLayerFlagAllSeqLen = ITMLayerFlagSeqNewLen/2;
            strITMLayerFlagAllSeq.length(ITMLayerFlagAllSeqLen);
            PPT_METHODTRACE_V2("","newindex"              , newindex);
            PPT_METHODTRACE_V2("","ITMLayerFlagSeqNewLen" , ITMLayerFlagSeqNewLen);
            PPT_METHODTRACE_V2("","ITMLayerFlagAllSeqLen" , ITMLayerFlagAllSeqLen);
            CORBA::Long lngITMLayerFlagNewCnt = 0;
            /*------------------------------------------*/
            /*    Assign photolayer and ITMLayerFlag    */
            /*------------------------------------------*/ 			
            for ( CORBA::Long lngITMLayerFlagAllCnt = 0; lngITMLayerFlagAllCnt < ITMLayerFlagAllSeqLen; lngITMLayerFlagAllCnt++ )
            {
                strITMLayerFlagAllSeq[lngITMLayerFlagAllCnt].photolayer.identifier = strITMLayerFlagNewSeq[lngITMLayerFlagNewCnt++];                
                strITMLayerFlagAllSeq[lngITMLayerFlagAllCnt].ITMLayerFlag          = strITMLayerFlagNewSeq[lngITMLayerFlagNewCnt++];
                PPT_METHODTRACE_V2("","photolayer"   , strITMLayerFlagAllSeq[lngITMLayerFlagAllCnt].photolayer.identifier);
                PPT_METHODTRACE_V2("","ITMLayerFlag" , strITMLayerFlagAllSeq[lngITMLayerFlagAllCnt].ITMLayerFlag);
            }
            /*-----------------------------------------*/
            /*    Check photolayer and ITMLayerFlag    */
            /*-----------------------------------------*/ 
            for ( CORBA::Long lngFlagCnt = 0; lngFlagCnt < ITMLayerFlagAllSeqLen; lngFlagCnt++ )
            {
                if(CIMFWStrCmp(strITMLayerFlagAllSeq[lngFlagCnt].photolayer.identifier,varphotoLayer) == 0 &&
                   CIMFWStrCmp(strITMLayerFlagAllSeq[lngFlagCnt].ITMLayerFlag,"N") == 0) 
                {
                    PPT_METHODTRACE_V1("", "bAPCConditionAvailable == FALSE");
                    bAPCConditionAvailable = FALSE;
                    break;
                }
            }
            /*-----------------------------------------------------*/
            /*    Check varAPCLithoCombineFlag is TRUE or FALSE    */
            /*-----------------------------------------------------*/ 
            CORBA::String_var varAPCLithoCombineFlag;            
            if (bAPCConditionAvailable == TRUE)
            {
                PPT_METHODTRACE_V1("", "bAPCConditionAvailable == TRUE"); 
                CIMFWStrCpy(strAPC_LithoAvailable_CheckCondition_out.inquireType,"L");
                try
                {
                    SI_PPT_USERDATA_GET_STRING(aMainPOS,
                                               CS_S_MAINPD_OPE_APC_COMBINE_FLAG,
                                               varAPCLithoCombineFlag);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperationSpecification::getUserDataNamed);
                PPT_METHODTRACE_V2("","varAPCLithoCombineFlag" , varAPCLithoCombineFlag);
                //--------------------------------------------------------------------------
                // Make a strAPCLithoCombineFlagSeq string. Parse strAPCLithoCombineFlagSeq string
                // For example,
                // A string is "1;1;1".   ==> strAPCLithoCombineFlagSeq[0]  <-- 1
                //                        ==> strAPCLithoCombineFlagSeq[1]  <-- 1
                //                        ==> strAPCLithoCombineFlagSeq[2]  <-- 1
                //--------------------------------------------------------------------------                
                char *newflagptr = NULL;
                char *tmpflagptr = NULL;
                char flagbuf[4096];
                memset( flagbuf, '\0', sizeof( flagbuf ) );
                CORBA::Long upflagLen    = 5;
                CORBA::Long tmpflaglen   = 5;
                CORBA::Long newflagindex = 0;
                CIMFWStrCpy( flagbuf, varAPCLithoCombineFlag );
                stringSequence strAPCLithoCombineFlagSeq;
                strAPCLithoCombineFlagSeq.length(5);
                for (newflagptr = strtok_r(flagbuf, ";",&tmpflagptr); newflagptr != NULL; newflagptr = strtok_r(NULL,";",&tmpflagptr))
                {
                    if(newflagindex >= tmpflaglen);
                    {
                        tmpflaglen += upflagLen;
                        strAPCLithoCombineFlagSeq.length(tmpflaglen);
                    }
                    strAPCLithoCombineFlagSeq[newflagindex] = newflagptr;
                    PPT_METHODTRACE_V2("","APCLithoCombineFlagSequence" , strAPCLithoCombineFlagSeq[newflagindex]);   
                    newflagindex++;
                    
                }
                strAPCLithoCombineFlagSeq.length(newflagindex);
                CORBA::Long APCLithoCombineFlagSeqLen = strAPCLithoCombineFlagSeq.length();
                PPT_METHODTRACE_V2("","APCLithoCombineFlagSeqLen" , APCLithoCombineFlagSeqLen); 
                /*----------------------------------*/
                /*    Assign APCLithoCombineFlag    */
                /*----------------------------------*/ 
                for(CORBA::Long CombineFlagindex = 0; CombineFlagindex < APCLithoCombineFlagSeqLen; CombineFlagindex++)
	            {
                    if(CIMFWStrCmp(strAPCLithoCombineFlagSeq[CombineFlagindex], "1") == 0)
                    {
                        PPT_METHODTRACE_V1("", "strAPCLithoCombineFlagSeq[CombineFlagindex]==1");
                        strAPC_LithoAvailable_CheckCondition_out.recommendFlag = TRUE;
                        CombineFlagindex++;
                        PPT_METHODTRACE_V2("","CombineFlagindex=" , CombineFlagindex);
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "strAPCLithoCombineFlagSeq[CombineFlagindex]==0");
                        strAPC_LithoAvailable_CheckCondition_out.recommendFlag = FALSE; 
                        CombineFlagindex++;             
                        PPT_METHODTRACE_V2("","CombineFlagindex=" , CombineFlagindex);
                    } 
                    if(CIMFWStrCmp(strAPCLithoCombineFlagSeq[CombineFlagindex], "1") == 0)
                    {
                        PPT_METHODTRACE_V1("", "strAPCLithoCombineFlagSeq[CombineFlagindex]==1");
                        strAPC_LithoAvailable_CheckCondition_out.usedFlag = TRUE;
                        CombineFlagindex++;
                        PPT_METHODTRACE_V2("","CombineFlagindex=" , CombineFlagindex);
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "strAPCLithoCombineFlagSeq[CombineFlagindex]==0");
                        strAPC_LithoAvailable_CheckCondition_out.usedFlag = FALSE; 
                        CombineFlagindex++;             
                        PPT_METHODTRACE_V2("","CombineFlagindex=" , CombineFlagindex);
                    } 
                    if(CIMFWStrCmp(strAPCLithoCombineFlagSeq[CombineFlagindex], "1") == 0)
                    {
                        PPT_METHODTRACE_V1("", "strAPCLithoCombineFlagSeq[CombineFlagindex]==1");
                        strAPC_LithoAvailable_CheckCondition_out.metrologyFlag = TRUE;
                        CombineFlagindex++;
                        PPT_METHODTRACE_V2("","CombineFlagindex=" , CombineFlagindex);
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "strAPCLithoCombineFlagSeq[CombineFlagindex]==0");
                        strAPC_LithoAvailable_CheckCondition_out.metrologyFlag = FALSE; 
                        CombineFlagindex++;  
                        PPT_METHODTRACE_V2("","CombineFlagindex=" , CombineFlagindex);	
                    }
                }    
                
                PPT_METHODTRACE_V2("","recommendFlag" , strAPC_LithoAvailable_CheckCondition_out.recommendFlag);
                PPT_METHODTRACE_V2("","usedFlag" ,      strAPC_LithoAvailable_CheckCondition_out.usedFlag);
                PPT_METHODTRACE_V2("","metrologyFlag" , strAPC_LithoAvailable_CheckCondition_out.metrologyFlag);
            }
        }
        
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_APC_LithoAvailable_CheckCondition");
        return RC_OK;
    }    
    CATCH_GLOBAL_EXCEPTIONS(strAPC_LithoAvailable_CheckCondition_out, cs_APC_LithoAvailable_CheckCondition, methodName );
}