#ifndef lint
static char *sccsid =  "@(#) 1.7 superpos/src/spppt/source/posppt/pptmgr/objmethd/whatNextLotList_to_StartCassetteForDeliveryReq.cpp, mm_srv_120e_ppt, mm_srv_120e_ppt 8/11/08 17:58:54 [ 8/11/08 17:58:56 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cs_whatNextLotList_to_StartCassetteForDeliveryReqOR.cpp
//

#include "cs_pptmgr.hpp"
#include "pcas.hh"
#include "plcrc.hh"     //D4000184
#include "pprsp.hh"     //D4000184
#include "pmcrc.hh"     //D4200092
#include "plot.hh"      //P4200137
#include "pptconvert.h" //D9000005
#include "pptconverter.h" //DSIV00000099
#include "ppcflwx.hh"     //DSN000081739
#include "ppcope.hh"      //DSN000081739

//[Object Function Name]: long   whatNextLotList_to_StartCassetteForDeliveryReq
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2000-11-01  D3000086  S.Kawabe       Add Delivery Request Logic
// 2000-11-15            K.Matsuei      Bug Fix
// 2000-11-17            O.Sugiyama     Bug Fix
// 2000-11-20            O.Sugiyama     Bug Fix
// 2000-11-21            O.Sugiyama     Bug Fix
// 2000-11-22            O.Sugiyama     Bug Fix. Select Illegal Base Recipe
// 2000-11-23            M.Mori         Bug Fix. Min Batch Size 2, Empty Cassette
// 2000-11.24            O.Sugiyama     Add Min Batch Size Check.
// 2000-11.29  0.01      O.Sugiyama     Add physicalRecipeID
// 2001-07-05  D4000016  M.Shimizu      Contamination Control(Copper/Non Copper [R40 Core])
// 2001-08-09  D4000048  M.Ameshita     Reticle set support                     [R40 Core]
// 2001-09-13  P4000168  K.Matsuei      Change Logic of CassetteDeliveryReq.
// 2001-09-17  D4000184  K.Matsuei      The problem of CopperNonCopper was found with CassetteDelivery.
// 2001-09-19  0.02      K.Matusei      Comment Out Unnecessary Logic.
// 2001-09-26  0.03      K.Matusei      Add Logic. Check WIP Count.
// 2001-10-23  D4000227  K.Matsuei      The specification change of CassetteDelivery.
// 2001/10/25  P4000390  K.Matsuei      EmptyCarrier was acquired without checking of OpeStartFlag in CassetteDelivery.
// 2001/11/22  P4100010  K.Matsuei      Copper/NonCopper Check doesn't go well in CassetteDelivery.
// 2001/01/08  D4100036  K.Matsuei      FlowBatch Control.
// 2002/01/15  P4100073  K.Matsuei      Bug Fix. Xfer EQP to EQP of CassetteDelivery.
// 2002/03/25  P4100258  K.Matsuei      Lot isn't select in CassetteDelivery. Unnecessary MinWaferCheck.
// 2002/08/29  D4200092  K.Matsuei      RecipeParameter is not stored into PosPO with Auto-3.
// 2002/09/06  P4200137  K.Matsuei      There is an item which is not set to StartCassette by StartReserve of CassetteDelivery(Auto3).
// 2002/10/03  P4200182  K.Matsuei      FlowBatching Lot of ML-SR cannot Dispatch by CassetteDelivery.
// 2003/02/18  D4200302  K.Matsuei      Assign EmptyCassette to AnyPort by CassetteDelivery.
// 2004/09/07  D51M0007  K.Matsuei      Performance improvement of WhatsNext.
// 2005/08/31  D6000415  K.Kido         Call findRecipeParametersForSubLotType() to get correct Recipe Parameter taken into account for Chamber Machine State.
// 2005/12/07  D7000042  K.Kido         Get Machine Recipe by findMachineRecipeForSubLotType for findRecipeParametersForSubLotType.
// 2006/02/17  P7000106  K.Matsuei      StartReserve is completed incorrectly.
// 2006/02/17  D7000183  K.Matsuei      Select Lot in consideration of MinBatchSize in CassetteDelivery.
// 2006/12/05  D8000024  H.Mutoh        Flexible Process Condition Change (R80)
// 2007/04/20  D9000001  H.Murakami     64bit support.
// 2007/09/20  D9000079  D.Tamura       FlowBatch Enhancement.
// 2007/10/25  D9000005  K.Kido         Change cassette_FillInTxPDQ007DR ==> cassette_ListGetDR__090
// 2008/08/08  P9000002  K.Kido         Support reroute for SO/EO cassette.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/04 DSIV00000099 M.Ogawa        cassette_ListGetDR__090 -> cassette_ListGetDR__100
// 2009/10/27 DSIV00001443 S.Kawabe       Improve how to get the Machine Recipe
// 2011/09/28 DSN000020767 T.Ishida       Auto Dispatch Control Support
// 2013/10/31 DSN000081739 Shudi Wang     Equipment Monitor Automation Support
// 2015/11/10 DSN000096126 C.Mo           cassette_ListGetDR__100 ==> cassette_ListGetDR__160
//                                        cassette_DBInfo_GetDR__120 ==> cassette_DBInfo_GetDR__160
// 2016/07/27 DSN000101569 C.Mo           cassette_ListGetDR__160 ==> cassette_ListGetDR__170
//                                        cassette_DBInfo_GetDR__160 ==> cassette_DBInfo_GetDR__170
//
// Innotron Modification history:
// Date       DCR/PCR No   Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/02 INN-R170002  JJ.Zhang       Contamination Control
//
//[Function Description]:
//  This object is make strStartCassette from in-param's pptWhatNextLotList for DeliveryReq.
//  1. make strStartCassette from in-param's pptWhatNextLotList.
//  2. check strStartCassette on each check's process.
//  3. focus strStartCassette with Equipment's multiRecipeCapability and Cassette's multiLotType.
//
//  The following input-parameters must be filled to call this object function.
//  - equipmentID
//  - strPortGroup
//  - strWhatNextLotListInqResult
//
//
//[Input Parameters]:
//  in  pptObjCommonIn              strObjCommonIn;
//  in  objectIdentifier            equipmentID;
//  in  pptPortGroupSequence        strPortGroup;
//  in  pptWhatNextLotListInqResult strWhatNextLotListInqResult;
//
//[Output Parameters]:
//  out objWhatNextLotList_to_StartCassetteForDeliveryReq_out   strWhatNextLotList_to_StartCassetteForDeliveryReq_out;
//
//  typedef struct objWhatNextLotList_to_StartCassetteForDeliveryReq_out_struct {
//      pptRetCode                  strResult;
//      pptStartCassetteSequence    strStartCassette;
//  } objWhatNextLotList_to_StartCassetteForDeliveryReq_out;
//
//typedef sequence <pptStartCassette> pptStartCassetteSequence;
//
//typedef struct pptStartCassette_struct {
//    long                          loadSequenceNumber;
//    objectIdentifier              cassetteID;
//    string                        loadPurposeType;
//    objectIdentifier              loadPortID;
//    objectIdentifier              unloadPortID;
//    pptLotInCassetteSequence      strLotInCassette;
//    any siInfo;
//} pptStartCassette;
//
//typedef sequence <pptLotInCassette> pptLotInCassetteSequence;
//
//typedef struct pptLotInCassette_struct {
//    boolean                       operationStartFlag;
//    boolean                       monitorLotFlag;
//    objectIdentifier              lotID;
//    string                        lotType;
//    string                        subLotType;
//    pptStartRecipe                strStartRecipe;
//    string                        recipeParameterChangeType;
//    pptLotWaferSequence           strLotWafer;
//    any siInfo;
//} pptLotInCassette;
//
//typedef sequence <pptStartLot> pptStartLotSequence;
//
//typedef struct pptLotWafer_struct {
//    objectIdentifier    waferID;
//    long                slotNumber;
//    boolean             controlWaferFlag;
//    pptStartRecipeParameterSequence  strStartRecipeParameter;
//    any siInfo;
//} pptLotWafer;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_NOT_FOUND_CASSETTE       MSG_NOT_FOUND_CASSETTE
//  RC_NOT_FOUND_EQP            MSG_NOT_FOUND_EQP
//
//[Pseudo Code]:
//

CORBA::Long CS_PPTManager_i::whatNextLotList_to_StartCassetteForDeliveryReq(
    objWhatNextLotList_to_StartCassetteForDeliveryReq_out&  strWhatNextLotList_to_StartCassetteForDeliveryReq_out,
    const pptObjCommonIn&                                   strObjCommonIn,
    const objectIdentifier&                                 equipmentID,
    const pptPortGroupSequence&                             strPortGroup,
    const pptWhatNextLotListInqResult&                      strWhatNextLotListInqResult )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::whatNextLotList_to_StartCassetteForDeliveryReq");

        /*---------------------------------*/
        /*   Debug Trace Input Parameter   */
        /*---------------------------------*/
{
        PPT_METHODTRACE_V1("","*****************************************************************");
        PPT_METHODTRACE_V1("","  Input Parameter");
        PPT_METHODTRACE_V1("","*****************************************************************");
        PPT_METHODTRACE_V2("","equipmentID__________________________",equipmentID.identifier);
        PPT_METHODTRACE_V1("","=================================================================");
        PPT_METHODTRACE_V2("", "portGroup___________________________", strPortGroup[0].portGroup);
        CORBA::Long ii, jj;
        CORBA::Long len = strPortGroup[0].strPortID.length();
        PPT_METHODTRACE_V2("", "strPortID[0].length_________________", len);
        for (ii=0; ii < len; ii++)
        {
        PPT_METHODTRACE_V2("", "portID /////////////////////////////", strPortGroup[0].strPortID[ii].portID.identifier);
        PPT_METHODTRACE_V2("", "  loadSequenceNoInPortGroup_________", strPortGroup[0].strPortID[ii].loadSequenceNoInPortGroup);
        PPT_METHODTRACE_V2("", "  portUsage_________________________", strPortGroup[0].strPortID[ii].portUsage);
        PPT_METHODTRACE_V2("", "  usageType_________________________", strPortGroup[0].strPortID[ii].usageType);
        PPT_METHODTRACE_V2("", "  loadPurposeType___________________", strPortGroup[0].strPortID[ii].loadPurposeType);
        PPT_METHODTRACE_V2("", "  portState_________________________", strPortGroup[0].strPortID[ii].portState);
        PPT_METHODTRACE_V2("", "  categoryCapability.length()_______", strPortGroup[0].strPortID[ii].categoryCapability.length());
        for (jj=0; jj < strPortGroup[0].strPortID[ii].categoryCapability.length(); jj++)
        {
        PPT_METHODTRACE_V2("", "  categoryCapability________________", strPortGroup[0].strPortID[ii].categoryCapability[jj]);
        }
        }
        PPT_METHODTRACE_V1("","=================================================================");

        PPT_METHODTRACE_V2("", "equipmentCategory___________________", strWhatNextLotListInqResult.equipmentCategory);
        PPT_METHODTRACE_V2("", "processRunSizeMaximum_______________", strWhatNextLotListInqResult.processRunSizeMaximum);
        PPT_METHODTRACE_V2("", "processRunSizeMinimum_______________", strWhatNextLotListInqResult.processRunSizeMinimum);
        len = strWhatNextLotListInqResult.strWhatNextAttributes.length();
        PPT_METHODTRACE_V2("", "strWhatNextAttributes.length________", len);
        for (ii=0; ii < len; ii++)
        {
        PPT_METHODTRACE_V2("", "lotID //////////////////////////////", strWhatNextLotListInqResult.strWhatNextAttributes[ii].lotID.identifier);
        PPT_METHODTRACE_V2("", "  cassetteID________________________", strWhatNextLotListInqResult.strWhatNextAttributes[ii].cassetteID.identifier);
        PPT_METHODTRACE_V2("", "  lotType___________________________", strWhatNextLotListInqResult.strWhatNextAttributes[ii].lotType);
        PPT_METHODTRACE_V2("", "  multiLotType______________________", strWhatNextLotListInqResult.strWhatNextAttributes[ii].multiLotType);
        PPT_METHODTRACE_V2("", "  transferStatus____________________", strWhatNextLotListInqResult.strWhatNextAttributes[ii].transferStatus);
        PPT_METHODTRACE_V2("", "  requiredCassetteCategory__________", strWhatNextLotListInqResult.strWhatNextAttributes[ii].requiredCassetteCategory);
        PPT_METHODTRACE_V2("", "  cassetteCategory__________________", strWhatNextLotListInqResult.strWhatNextAttributes[ii].cassetteCategory);
        PPT_METHODTRACE_V2("", "  next2requiredCassetteCategory_____", strWhatNextLotListInqResult.strWhatNextAttributes[ii].next2requiredCassetteCategory);
        PPT_METHODTRACE_V2("", "  routeID___________________________", strWhatNextLotListInqResult.strWhatNextAttributes[ii].routeID.identifier); //P7000106
        PPT_METHODTRACE_V2("", "  operationID_______________________", strWhatNextLotListInqResult.strWhatNextAttributes[ii].operationID.identifier); //P7000106
        PPT_METHODTRACE_V2("", "  operationNumber___________________", strWhatNextLotListInqResult.strWhatNextAttributes[ii].operationNumber); //P7000106
        }
        PPT_METHODTRACE_V1("","");
}


        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;
        CORBA::String_var portGroupID;
        CORBA::String_var multiLotType;

        CORBA::Long searchCondition = 0;                                                                   //DSIV00001443
        CORBA::String_var searchCondition_var = CIMFWStrDup(getenv("SP_ENTITY_INHIBIT_SEARCH_CONDITION")); //DSIV00001443
        if( CIMFWStrLen(searchCondition_var) > 0 )                                                         //DSIV00001443
        {                                                                                                  //DSIV00001443
            searchCondition = atoi(searchCondition_var);                                                   //DSIV00001443
        }                                                                                                  //DSIV00001443

        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*   Check Condition and Get Information                                                                      */
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/

        /*--------------------------*/
        /*   Get Equipment Object   */
        /*--------------------------*/
        PosMachine_var aMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine, equipmentID,
                                         strWhatNextLotList_to_StartCassetteForDeliveryReq_out,
                                         whatNextLotList_to_StartCassetteForDeliveryReq );

        /*-------------------------------------------*/
        /*   Get Equipment's MultiRecipeCapability   */
        /*-------------------------------------------*/
        CORBA::String_var multiRecipeCapability;
        try
        {
            multiRecipeCapability = aMachine->getMultipleRecipeCapability();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getMultipleRecipeCapability);
        PPT_METHODTRACE_V2("", "aMachine->getMultipleRecipeCapability", multiRecipeCapability);

        /**********************************************************************/
        /*                                                                    */
        /*   Get PortID List                                                  */
        /*                                                                    */
        /**********************************************************************/
        PPT_METHODTRACE_V1("", "//***************************************************************");
        PPT_METHODTRACE_V1("", "//  Get PortID List");
        PPT_METHODTRACE_V1("", "//***************************************************************");

        objectIdentifierSequence portID;
        longSequence loadSequenceNumber;
        stringSequence loadPurposeType;

        CORBA::Long PortCount = 0;
        CORBA::Long nPortGrpLen = strPortGroup.length();
        PPT_METHODTRACE_V2("", "strPortGroup.length() =",nPortGrpLen);
        for (CORBA::Long i=0; i<nPortGrpLen; i++)
        {
            CORBA::Long nPortLen = strPortGroup[i].strPortID.length();
            PPT_METHODTRACE_V2("", "strPortGroup[i].strPortID.lenght() =",nPortLen);
            for (CORBA::Long j=0; j<nPortLen; j++)
            {
                if (CIMFWStrCmp(strPortGroup[i].strPortID[j].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
                {
                    PPT_METHODTRACE_V1("", "port.loadPurposeType == EmptyCassette   ...<<continue>>");
                    continue; //[j]
                }
                portID.length(PortCount+1);
                portID[PortCount] = strPortGroup[i].strPortID[j].portID;
                loadSequenceNumber.length(PortCount + 1);
                loadSequenceNumber[PortCount] = strPortGroup[i].strPortID[j].loadSequenceNoInPortGroup;
                loadPurposeType.length(PortCount + 1);
                loadPurposeType[PortCount] = CIMFWStrDup(strPortGroup[i].strPortID[j].loadPurposeType);

                PPT_METHODTRACE_V1("", "-----------------------------------------");
                PPT_METHODTRACE_V2("", "portID.................", portID[PortCount].identifier);
                PPT_METHODTRACE_V2("", "loadSequenceNumber.....", loadSequenceNumber[PortCount]);
                PPT_METHODTRACE_V2("", "loadPurposeType........", loadPurposeType[PortCount]);
                PortCount++;
            }
        }
        PPT_METHODTRACE_V2("","PortCount", PortCount);
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");

        /*-----------------------------------------------*/
        /*   Check PortCount and processRunSizeMaximum   */
        /*-----------------------------------------------*/
        PPT_METHODTRACE_V1("","/*-----------------------------------------------*/");
        PPT_METHODTRACE_V1("","/*   Check PortCount and processRunSizeMaximum   */");
        PPT_METHODTRACE_V1("","/*-----------------------------------------------*/");
        CORBA::Long processRunCount = 0;
        CORBA::Long processRunSizeMaximum = strWhatNextLotListInqResult.processRunSizeMaximum;

        PPT_METHODTRACE_V2("","processRunSizeMaximum", processRunSizeMaximum);

        if ( PortCount == 0 || PortCount < processRunSizeMaximum)
        {
            PPT_METHODTRACE_V1("","##### PortCount == 0 || PortCount < processRunSizeMaximum");
            SET_MSG_RC(strWhatNextLotList_to_StartCassetteForDeliveryReq_out, MSG_NOT_FOUND_FILLEDCAST, RC_NOT_FOUND_FILLEDCAST);
            return RC_NOT_FOUND_FILLEDCAST;
        }

        /*---------------------------------------------*/
        /*   Get Equipment's Process Batch Condition   */
        /*---------------------------------------------*/
        PPT_METHODTRACE_V1("","/*-------------------------------------------*/");
        PPT_METHODTRACE_V1("","/*   equipment_processBatchCondition_Get()   */");
        PPT_METHODTRACE_V1("","/*-------------------------------------------*/");
        objEquipment_processBatchCondition_Get_out strEquipment_processBatchCondition_Get_out;
        rc = equipment_processBatchCondition_Get( strEquipment_processBatchCondition_Get_out,
                                                  strObjCommonIn,
                                                  equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "##### equipment_processBatchCondition_Get() != RC_OK")
            strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strResult = strEquipment_processBatchCondition_Get_out.strResult;
            return ( rc );
        }
        PPT_METHODTRACE_V2("","maxBatchSize...........", strEquipment_processBatchCondition_Get_out.maxBatchSize);
        PPT_METHODTRACE_V2("","minBatchSize...........", strEquipment_processBatchCondition_Get_out.minBatchSize);
        PPT_METHODTRACE_V2("","minWaferSize...........", strEquipment_processBatchCondition_Get_out.minWaferSize);
//D9000001        PPT_METHODTRACE_V2("","cassetteExchangeFlag...", (long)strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag);
        PPT_METHODTRACE_V2("","cassetteExchangeFlag...", (int)strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag); //D9000001
//D9000001        PPT_METHODTRACE_V2("","monitorCreationFlag....", (long)strEquipment_processBatchCondition_Get_out.monitorCreationFlag);
        PPT_METHODTRACE_V2("","monitorCreationFlag....", (int)strEquipment_processBatchCondition_Get_out.monitorCreationFlag); //D9000001
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");

//0.03 start
        /*-------------------------*/
        /*   Check WIP Lot Count   */
        /*-------------------------*/
        PPT_METHODTRACE_V1("","/*-------------------------*/");
        PPT_METHODTRACE_V1("","/*   Check WIP Lot Count   */");
        PPT_METHODTRACE_V1("","/*-------------------------*/");
        CORBA::Long attrLen = strWhatNextLotListInqResult.strWhatNextAttributes.length();
        PPT_METHODTRACE_V2("","strWhatNextLotListInqResult.strWhatNextAttributes.length()", attrLen);
        if ( 0 == attrLen )
        {
            PPT_METHODTRACE_V1("","0 == strWhatNextAttributes.length");
            SET_MSG_RC( strWhatNextLotList_to_StartCassetteForDeliveryReq_out, MSG_NOT_FOUND_FILLEDCAST, RC_NOT_FOUND_FILLEDCAST );
            return RC_NOT_FOUND_FILLEDCAST;
        }
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");
//0.03 end

//D4000184 start
        /**********************************************************************/
        /*                                                                    */
        /*   Get Empty Cassette                                               */
        /*                                                                    */
        /**********************************************************************/
        PPT_METHODTRACE_V1("", "//***************************************************************");
        PPT_METHODTRACE_V1("", "//  Get Empty Cassette");
        PPT_METHODTRACE_V1("", "//***************************************************************");

        objCassetteList_emptyAvailable_Pickup_out strCassetteList_emptyAvailable_Pickup_out;

        if ( TRUE == strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag
          || TRUE == strEquipment_processBatchCondition_Get_out.monitorCreationFlag )
        {
            PPT_METHODTRACE_V1("","EmptyCassette is necessary");

            /*------------------------*/
            /*   Get Empty Cassette   */
            /*------------------------*/
//D9000005  PPT_METHODTRACE_V1("", "/*---------------------------------*/");
//D9000005  PPT_METHODTRACE_V1("", "/*   cassette_FillInTxPDQ007DR()   */");
//D9000005  PPT_METHODTRACE_V1("", "/*---------------------------------*/");
//D9000005  objectIdentifier aTempOI;
//D9000005
//D9000005  objCassette_FillInTxPDQ007DR_out strCassette_FillInTxPDQ007DR_out;
//D9000005  rc = cassette_FillInTxPDQ007DR( strCassette_FillInTxPDQ007DR_out,
//D9000005                                  strObjCommonIn,
//D9000005                                  "",                         // const char * cassetteCategory,
//D9000005                                  TRUE,                       // CORBA::Boolean emptyFlag,
//D9000005                                  aTempOI,                    // const objectIdentifier& stockerID,
//D9000005                                  aTempOI,                    // const objectIdentifier& cassetteID
//D9000005                                  CIMFW_Durable_Available,    // const char * cassetteStatus
//D9000005                                  -1 );                       // CORBA:Long maxRetrieveCount
//D9000005  if ( rc != RC_OK )
//D9000005  {
//D9000005      PPT_METHODTRACE_V1("", "##### RC_OK != cassette_FillInTxPDQ007DR()");
//D9000005      strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strResult = strCassette_FillInTxPDQ007DR_out.strResult;
//D9000005      return( rc );
//D9000005  }
//DSIV00000099//D9000005 add start
//DSIV00000099            PPT_METHODTRACE_V1("", "/*-------------------------------*/");
//DSIV00000099            PPT_METHODTRACE_V1("", "/*   cassette_ListGetDR__090()   */");
//DSIV00000099            PPT_METHODTRACE_V1("", "/*-------------------------------*/");
//DSIV00000099            objCassette_ListGetDR_in__090  strCassette_ListGetDR_in;
//DSIV00000099            strCassette_ListGetDR_in.emptyFlag                  = TRUE;
//DSIV00000099            strCassette_ListGetDR_in.cassetteStatus             = CIMFWStrDup(CIMFW_Durable_Available);
//DSIV00000099            strCassette_ListGetDR_in.maxRetrieveCount           = -1;
//DSIV00000099            strCassette_ListGetDR_in.sorterJobCreationCheckFlag = FALSE;
//DSIV00000099
//DSIV00000099            objCassette_ListGetDR_out__090 strCassette_ListGetDR_out;
//DSIV00000099            rc = cassette_ListGetDR__090( strCassette_ListGetDR_out,
//DSIV00000099                                          strObjCommonIn,
//DSIV00000099                                          strCassette_ListGetDR_in );
//DSIV00000099            if ( rc != RC_OK )
//DSIV00000099            {
//DSIV00000099                PPT_METHODTRACE_V1("", "cassette_ListGetDR__090() rc != RC_OK");
//DSIV00000099                strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strResult = strCassette_ListGetDR_out.strResult ;
//DSIV00000099                return( rc );
//DSIV00000099            }
//DSIV00000099
//DSIV00000099            PPTConvert convFoundCast(strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette);
//DSIV00000099            pptFoundCassetteSequence strFoundCassette = convFoundCast;
//DSIV00000099//D9000005 add end
//DSIV00000099 add start
            PPT_METHODTRACE_V1("", "/*-------------------------------*/");
//DSN000096126            PPT_METHODTRACE_V1("", "/*   cassette_ListGetDR__100()   */");
            PPT_METHODTRACE_V1("", "/*   cassette_ListGetDR__170()   */"); //DSN000096126
            PPT_METHODTRACE_V1("", "/*-------------------------------*/");
//DSN000096126            objCassette_ListGetDR_in__100  strCassette_ListGetDR_in;
//DSN000101569            objCassette_ListGetDR_in__160  strCassette_ListGetDR_in; //DSN000096126
            objCassette_ListGetDR_in__170  strCassette_ListGetDR_in;                                                            //DSN000101569
            strCassette_ListGetDR_in.emptyFlag                  = TRUE;
            strCassette_ListGetDR_in.cassetteStatus             = CIMFWStrDup(CIMFW_Durable_Available);
            strCassette_ListGetDR_in.maxRetrieveCount           = -1;
            strCassette_ListGetDR_in.sorterJobCreationCheckFlag = FALSE;
            objectIdentifier dummyID;                                      //DSN000096126
            dummyID.identifier = CIMFWStrDup("");                          //DSN000096126
            strCassette_ListGetDR_in.bankID                     = dummyID; //DSN000096126
            strCassette_ListGetDR_in.durableSubStatus           = dummyID;                                                      //DSN000101569
            strCassette_ListGetDR_in.flowStatus                 = CIMFWStrDup("");                                              //DSN000101569
//DSN000096126            objCassette_ListGetDR_out__100 strCassette_ListGetDR_out;
//DSN000096126            rc = cassette_ListGetDR__100( strCassette_ListGetDR_out,
//DSN000096126                                          strObjCommonIn,
//DSN000096126                                          strCassette_ListGetDR_in );
//DSN000101569            objCassette_ListGetDR_out__160 strCassette_ListGetDR_out; //DSN000096126
//DSN000101569            rc = cassette_ListGetDR__160(strCassette_ListGetDR_out, strObjCommonIn, strCassette_ListGetDR_in); //DSN000096126
            objCassette_ListGetDR_out__170 strCassette_ListGetDR_out;                                                           //DSN000101569
            rc = cassette_ListGetDR__170(strCassette_ListGetDR_out, strObjCommonIn, strCassette_ListGetDR_in);                  //DSN000101569
            if ( rc != RC_OK )
            {
//DSN000096126                PPT_METHODTRACE_V1("", "cassette_ListGetDR__100() rc != RC_OK");
                PPT_METHODTRACE_V1("", "cassette_ListGetDR__170() rc != RC_OK"); //DSN000096126
                strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strResult = strCassette_ListGetDR_out.strResult ;
                return( rc );
            }

            pptFoundCassetteSequence strFoundCassette;
            PPTConverter converter;
//DSN000096126            converter.Convert100_to_080( strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette, strFoundCassette );
//DSN000101569            converter.Convert160_to_080( strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette, strFoundCassette ); //DSN000096126
            converter.Convert170_to_080( strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette, strFoundCassette );//DSN000101569
//DSIV00000099 add end
            /*-----------------------------------*/
            /*   Pick Up Target Empty Cassette   */
            /*-----------------------------------*/
            PPT_METHODTRACE_V1("", "/*------------------------------------------*/");
            PPT_METHODTRACE_V1("", "/*   cassetteList_emptyAvailable_Pickup()   */");
            PPT_METHODTRACE_V1("", "/*------------------------------------------*/");
            rc = cassetteList_emptyAvailable_Pickup( strCassetteList_emptyAvailable_Pickup_out,
                                                     strObjCommonIn,
//D9000005                                           strCassette_FillInTxPDQ007DR_out.strCassetteListInqResult.strFoundCassette);  // Send to Node of equipmentID.
                                                     strFoundCassette);  // Send to Node of equipmentID.   //D9000005
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "##### RC_OK != cassetteList_emptyAvailable_Pickup()");
                strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strResult = strCassetteList_emptyAvailable_Pickup_out.strResult;
                return( rc );
            }
            PPT_METHODTRACE_V2("","Found Empty Cassette Count--->", strCassetteList_emptyAvailable_Pickup_out.strFoundCassette.length());
        }
        else
        {
            PPT_METHODTRACE_V1("","EmptyCassette is unnecessary");
        }
        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");
//D4000184 end

//D4100036 start  <<< FlowBatch Control >>>
        /**********************************************************************/
        /*                                                                    */
        /*   Get and Check FlowBatch Info                                     */
        /*                                                                    */
        /**********************************************************************/
        PPT_METHODTRACE_V1("", "//***************************************************************");
        PPT_METHODTRACE_V1("", "//  Get and Check FlowBatch Info");
        PPT_METHODTRACE_V1("", "//***************************************************************");

        PPT_METHODTRACE_V1("", "call flowBatch_CheckConditionForCassetteDelivery()");
        objFlowBatch_CheckConditionForCassetteDelivery_out   strFlowBatch_CheckConditionForCassetteDelivery_out;
        rc = flowBatch_CheckConditionForCassetteDelivery( strFlowBatch_CheckConditionForCassetteDelivery_out,
                                                          strObjCommonIn,
                                                          equipmentID,
                                                          strWhatNextLotListInqResult );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "##### RC_OK != flowBatch_CheckConditionForCassetteDelivery()");
            strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strResult = strFlowBatch_CheckConditionForCassetteDelivery_out.strResult;
            return( rc );
        }
//D4100036 end  <<< FlowBatch Control >>>


        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*   Make strStartCassette Process                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        PPT_METHODTRACE_V1("","");
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*  make strStartCassette Process                                           */");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");

        pptStartCassetteSequence  strStartCassette;

//D7000183 start
        CORBA::Boolean bCheckMinBatchSize = FALSE;
        CORBA::String_var checkMinBatchSize = CIMFWStrDup(getenv(SP_MINIMUM_BATCH_CONDITION_APPLY_FLAG_FOR_DELIVERY));
        PPT_METHODTRACE_V2("","SP_MINIMUM_BATCH_CONDITION_APPLY_FLAG_FOR_DELIVERY ---> ", checkMinBatchSize);
        if ( 0 == CIMFWStrCmp(checkMinBatchSize, "1") && 1 < strEquipment_processBatchCondition_Get_out.minBatchSize )
        {
            PPT_METHODTRACE_V1("","bCheckMinBatchSize is 1");
            bCheckMinBatchSize = TRUE;
        }

        CORBA::Long nSetStartCassetteCnt = 0;
        objectIdentifierSequence omitCassetteSeq;
        omitCassetteSeq.length(0);

        while ( 1 ) // MinBatchSize support loop.
        {
            // Reset variable.
            processRunCount = 0;
//D7000183 end

    //D4000015        strStartCassette.length( processRunSizeMaximum );
            CORBA::Long nPortLen = strPortGroup[0].strPortID.length();      //D4000015
            PPT_METHODTRACE_V2("","portID.length", nPortLen);
            strStartCassette.length( nPortLen );                            //D4000015

    //0.03        CORBA::Long attrLen = strWhatNextLotListInqResult.strWhatNextAttributes.length();
            PPT_METHODTRACE_V2("","strWhatNextLotListInqResult.strWhatNextAttributes.length()", attrLen);
            CORBA::Long startNo = 0;
            CORBA::Boolean bWhileExitFlag = FALSE;
            objectIdentifier baseLogicalRecipeID;
            objectIdentifier baseMachineRecipeID;
            objectIdentifier tmpBaseLogicalRecipeID;
            objectIdentifier tmpBaseMachineRecipeID;

    //D4000184 start
            CORBA::Boolean bAlreadyCheckMonitorCreationFlag = FALSE;
//D7000183        CORBA::Long nSetStartCassetteCnt = 0;
            nSetStartCassetteCnt = 0; //D7000183
            CORBA::Long nAssignEmptyCassetteCnt = 0;
            objectIdentifierSequence useEmptyCassetteIDSeq;
            objectIdentifierSequence useAssignEmptyCassettePortSeq;
            useEmptyCassetteIDSeq.length( nPortLen );
            useAssignEmptyCassettePortSeq.length( nPortLen );
    //D4000184 end

    //P4100010 start
            CORBA::Long nWIPLotLoopEndCnt = 0;
            CORBA::Long nSaveProcessRunCount = -1;
    //P4100010 end

            while ( processRunCount < processRunSizeMaximum )
            {
                PPT_METHODTRACE_V1("","");
                PPT_METHODTRACE_V1("","while ( processRunCount < processRunSizeMaximum ) --------------------------");
                PPT_METHODTRACE_V2("", "processRunCount =", processRunCount);

                if ( bWhileExitFlag == TRUE )
                {
                    PPT_METHODTRACE_V1("","bWhileExitFlag == TRUE    break!!");
                    break;
                }

                CORBA::Boolean bTmpBaseRecipeFlag = FALSE;      // Temporary Base Recipe Flag

                pptStartCassetteSequence  tmpStartCassette;
                tmpStartCassette.length(0);

                /**********************************************************************************/
                /*                                                                                */
                /*   Set Cassette Info                                                            */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  Set Cassette Info");
                PPT_METHODTRACE_V1("", "//***************************************************************");

    //P4100010 start
                if ( nSaveProcessRunCount != processRunCount )
                {
                    PPT_METHODTRACE_V1("", "Change processRunCount!!  WIPLot start index <--- 0");
                    startNo = 0;
                    nWIPLotLoopEndCnt = 0;
                }
                nSaveProcessRunCount = processRunCount;
    //P4100010 end

                for ( i=startNo; i < attrLen; i++ )
                {
                    PPT_METHODTRACE_V2("","for-loop counter--------------------------------------[i]",i);

                    PPT_METHODTRACE_V1("","Entry WhatNextData=====================================");
                    PPT_METHODTRACE_V2("","lotID...........................", strWhatNextLotListInqResult.strWhatNextAttributes[i].lotID.identifier);
                    PPT_METHODTRACE_V2("","cassetteID......................", strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID.identifier);
                    PPT_METHODTRACE_V2("","lotType.........................", strWhatNextLotListInqResult.strWhatNextAttributes[i].lotType);
                    PPT_METHODTRACE_V2("","multiLotType....................", strWhatNextLotListInqResult.strWhatNextAttributes[i].multiLotType);
                    PPT_METHODTRACE_V2("","transferStatus..................", strWhatNextLotListInqResult.strWhatNextAttributes[i].transferStatus);
                    PPT_METHODTRACE_V2("","stockerID.......................", strWhatNextLotListInqResult.strWhatNextAttributes[i].stockerID.identifier);
                    PPT_METHODTRACE_V2("","logicalRecipeID.................", strWhatNextLotListInqResult.strWhatNextAttributes[i].logicalRecipeID.identifier);
                    PPT_METHODTRACE_V2("","machineRecipeID.................", strWhatNextLotListInqResult.strWhatNextAttributes[i].machineRecipeID.identifier);
                    PPT_METHODTRACE_V2("","totalWaferCount.................", strWhatNextLotListInqResult.strWhatNextAttributes[i].totalWaferCount);
                    PPT_METHODTRACE_V2("","requiredCassetteCategory........", strWhatNextLotListInqResult.strWhatNextAttributes[i].requiredCassetteCategory);
                    PPT_METHODTRACE_V2("","cassetteCategory................", strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteCategory);
                    PPT_METHODTRACE_V2("","next2requiredCassetteCategory...", strWhatNextLotListInqResult.strWhatNextAttributes[i].next2requiredCassetteCategory);
                    PPT_METHODTRACE_V2("","routeID.........................", strWhatNextLotListInqResult.strWhatNextAttributes[i].routeID.identifier); //P7000106
                    PPT_METHODTRACE_V2("","operationID.....................", strWhatNextLotListInqResult.strWhatNextAttributes[i].operationID.identifier); //P7000106
                    PPT_METHODTRACE_V2("","operationNumber.................", strWhatNextLotListInqResult.strWhatNextAttributes[i].operationNumber); //P7000106
                    PPT_METHODTRACE_V1("","=======================================================");

                    /*-----------------------------*/
                    /*   Omit CassetteID is NULL   */
                    /*-----------------------------*/
                    if ( CIMFWStrLen(strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID.identifier) == 0 )
                    {
                        PPT_METHODTRACE_V1("","CassetteID is NULL   ..<<continue>>");
                        continue; // [i]
                    }

//D7000183 start
                    CORBA::Boolean bOmitCassette = FALSE;
                    CORBA::Long lenOmitCst = omitCassetteSeq.length();
                    for ( CORBA::Long m=0; m < lenOmitCst; m++ )
                    {
                        if ( 0 == CIMFWStrCmp(omitCassetteSeq[m].identifier,
                                              strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID.identifier) )
                        {
                            bOmitCassette = TRUE;
                            break;
                        }
                    }
                    if ( bOmitCassette )
                    {
                        PPT_METHODTRACE_V1("","Omit CassetteID   ..<<continue>>");
                        continue; // [i]
                    }
//D7000183 end

                    /*------------------------------------------*/
                    /*   Omit already saved strStartCassette    */
                    /*------------------------------------------*/
                    CORBA::Boolean bFoundFlag = FALSE;
    //D4200302                for ( CORBA::Long j=0; j < processRunCount; j++ )
                    CORBA::Long lenStartCassette = strStartCassette.length();       //D4200302
                    PPT_METHODTRACE_V2("","lenStartCassette", lenStartCassette);    //D4200302
                    for ( CORBA::Long j=0; j < lenStartCassette; j++ )              //D4200302
                    {
                        if (CIMFWStrCmp(strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID.identifier,
                                        strStartCassette[j].cassetteID.identifier) == 0)
                        {
                            bFoundFlag = TRUE;
                            break; // [j]
                        }
                    }
                    if ( bFoundFlag == TRUE )
                    {
                        PPT_METHODTRACE_V2("","CassetteID is Exist   ..<<continue>>", strStartCassette[j].cassetteID.identifier);
                        continue; // [i]
                    }

    //D4100036 start  <<< FlowBatch Control >>>
                    /*---------------------------------------------------------------------*/
                    /*   Omit Lot which is not FlowBatchingLots in the case of FlowBatch   */
                    /*---------------------------------------------------------------------*/
                    if ( 0 < CIMFWStrLen(strFlowBatch_CheckConditionForCassetteDelivery_out.flowBatchID.identifier) )
                    {
                        PPT_METHODTRACE_V1("","Omit Lot which is not FlowBatchingLots in the case of FlowBatch");
                        CORBA::Boolean bFound = FALSE;
                        CORBA::Long lenFlowBatchLots = strFlowBatch_CheckConditionForCassetteDelivery_out.strContainedLotsInFlowBatch.length();
                        for ( j=0; j < lenFlowBatchLots; j++ )
                        {
                            if ( 0 == CIMFWStrCmp(strWhatNextLotListInqResult.strWhatNextAttributes[i].lotID.identifier,
                                                  strFlowBatch_CheckConditionForCassetteDelivery_out.strContainedLotsInFlowBatch[j].lotID.identifier) )
                            {
                                bFound = TRUE;
                                break; // [j]
                            }
                        } //end of [j]
                        if ( FALSE == bFound )
                        {
                            PPT_METHODTRACE_V1("","LotID is not FlowBatchingLots   ..<<continue>>");
                            continue; // [i]
                        }

                        PPT_METHODTRACE_V2("","Lot is FlowBatching Lot!!", strWhatNextLotListInqResult.strWhatNextAttributes[i].lotID.identifier);
                    }
    //D4100036 end  <<< FlowBatch Control >>>

    //P4100010                if ( tmpStartCassette.length() != 0 )
    //P4100010                {
    //P4100010                    if (CIMFWStrCmp(strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID.identifier,
    //P4100010                                    tmpStartCassette[0].cassetteID.identifier) != 0)
    //P4100010                    {
    //P4100010                        startNo = i;
    //P4100010                        PPT_METHODTRACE_V2("","Next for-loop StartNo.=", startNo);
    //P4100010                        PPT_METHODTRACE_V1("","whatNext[i].cassetteID != tmpStartCassette[0].cassetteID  ..<<break!! whatNextInfo Loop>>");
    //P4100010                        break;
    //P4100010                    }
    //P4100010                    else
    //P4100010                    {
    //P4100010                        PPT_METHODTRACE_V1("","whatNext[i].cassetteID == tmpStartCassette[0].cassetteID   ..<<continue>>");
    //P4100010                        continue; // [i]
    //P4100010                    }
    //P4100010                }

//DSN000081739 Add Start
                    //----------------------------------------------------------------------------------------
                    //   Omit lot if "Monitor" label is put on lot's process and the lot doesn't have EqpMonitor job
                    //----------------------------------------------------------------------------------------
                    if ( 0 == CIMFWStrCmp( getenv(SP_EQPMONITOR_SWITCH), "1" ) )
                    {
                        PPT_METHODTRACE_V1("","SP_EQPMONITOR_SWITCH is 1");

                        //Check Lot type
                        objLot_lotType_Get_out strLot_lotType_Get_out;
                        objLot_lotType_Get_in  strLot_lotType_Get_in;
                        strLot_lotType_Get_in.lotID = strWhatNextLotListInqResult.strWhatNextAttributes[i].lotID;
                        rc = lot_lotType_Get(strLot_lotType_Get_out,strObjCommonIn,strLot_lotType_Get_in);
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "lot_lotType_Get() != RC_OK", rc);
                            strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strResult = strLot_lotType_Get_out.strResult;
                            return (rc);
                        }
                        if ( 0 == CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_EquipmentMonitorLot)
                          || 0 == CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_DummyLot))
                        {
                            PPT_METHODTRACE_V1("","lotType is Equipment Monitor or Dummy.");
                            objLot_eqpMonitorOperationLabel_Get_out strLot_eqpMonitorOperationLabel_Get_out;
                            objLot_eqpMonitorOperationLabel_Get_in  strLot_eqpMonitorOperationLabel_Get_in;
                            strLot_eqpMonitorOperationLabel_Get_in.lotID = strWhatNextLotListInqResult.strWhatNextAttributes[i].lotID;
                            rc = lot_eqpMonitorOperationLabel_Get( strLot_eqpMonitorOperationLabel_Get_out,
                                                                   strObjCommonIn,
                                                                   strLot_eqpMonitorOperationLabel_Get_in );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "lot_eqpMonitorOperationLabel_Get() != RC_OK", rc);
                                strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strResult = strLot_eqpMonitorOperationLabel_Get_out.strResult;
                                return (rc);
                            }
                            CORBA::Boolean bMonitorLabel = FALSE;
                            for ( CORBA::ULong x=0; x<strLot_eqpMonitorOperationLabel_Get_out.strEqpMonitorLabelInfoSeq.length(); x++ )
                            {
                                PPT_METHODTRACE_V2("","Loop through strEqpMonitorLabelInfoSeq",x);
                                if( 0 == CIMFWStrCmp(strLot_eqpMonitorOperationLabel_Get_out.strEqpMonitorLabelInfoSeq[x].operationLabel,SP_EqpMonitor_OpeLabel_Monitor) )
                                {
                                    PPT_METHODTRACE_V1("","Found Monitor label.");
                                    bMonitorLabel = TRUE;
                                    break;
                                }
                            }

                            if ( TRUE == bMonitorLabel )
                            {
                                PPT_METHODTRACE_V1("","bMonitorLabel is TRUE.");
                                objLot_eqpMonitorJob_Get_out strLot_eqpMonitorJob_Get_out;
                                objLot_eqpMonitorJob_Get_in  strLot_eqpMonitorJob_Get_in;
                                strLot_eqpMonitorJob_Get_in.lotID = strWhatNextLotListInqResult.strWhatNextAttributes[i].lotID;
                                rc = lot_eqpMonitorJob_Get(strLot_eqpMonitorJob_Get_out,strObjCommonIn,strLot_eqpMonitorJob_Get_in);
                                if ( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V2("", "lot_eqpMonitorJob_Get() rc != RC_OK", rc);
                                    strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strResult = strLot_eqpMonitorJob_Get_out.strResult;
                                    return rc;
                                }

                                if( 0 == CIMFWStrLen(strLot_eqpMonitorJob_Get_out.strEqpMonitorJobLotInfo.eqpMonitorJobID.identifier))
                                {
                                    PPT_METHODTRACE_V1("", "eqpMonitorJobID is not attached to lot");
                                    continue;
                                }

                                PosLot_var aPosLot;
                                PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot,strWhatNextLotListInqResult.strWhatNextAttributes[i].lotID,strWhatNextLotList_to_StartCassetteForDeliveryReq_out,whatNextLotList_to_StartCassetteForDeliveryReq);
                                PosProcessOperation_var aPosPO;
                                try
                                {
                                    ProcessOperation_var aPO = aPosLot->getProcessOperation();
                                    aPosPO = PosProcessOperation::_narrow(aPO);
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation);
                                if( CORBA::is_nil(aPosPO) )
                                {
                                    PPT_METHODTRACE_V1("", "aPosPO is nill");
                                    PPT_SET_MSG_RC_KEY2( strWhatNextLotList_to_StartCassetteForDeliveryReq_out,
                                                         MSG_NOT_FOUND_PO,
                                                         RC_NOT_FOUND_PO,
                                                         "",
                                                         strWhatNextLotListInqResult.strWhatNextAttributes[i].lotID.identifier );
                                    return RC_NOT_FOUND_PO;
                                }

                                CORBA::String_var strOPNumber;
                                try
                                {
                                    strOPNumber = aPosPO->getOperationNumber();
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getOperationNumber);
                                PosProcessFlowContext_var aPFX ;
                                try
                                {
                                    aPFX = aPosLot->getProcessFlowContext() ;
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessFlowContext);
                                if ( CORBA::is_nil(aPFX) == TRUE )
                                {
                                    PPT_METHODTRACE_V1("", "CORBA::is_nil(aPFX)")

                                    PPT_SET_MSG_RC_KEY(strWhatNextLotList_to_StartCassetteForDeliveryReq_out,
                                                       MSG_NOT_FOUND_PFX,
                                                       RC_NOT_FOUND_PFX,
                                                       "");

                                    return( RC_NOT_FOUND_PFX );
                                }

                                CORBA::String_var strEqpMonitorKey;
                                try
                                {
                                    strEqpMonitorKey = aPFX->getEqpMonOperationKey(strOPNumber);
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlowContext::getEqpMonOperationKey);

                                if( 0 != CIMFWStrCmp(strEqpMonitorKey, strLot_eqpMonitorJob_Get_out.strEqpMonitorJobLotInfo.monitorOpeKey))
                                {
                                    //The EqpMonitor job is for another Monitor process
                                    PPT_METHODTRACE_V1("","EqpMonitorKey is not same.");
                                    continue;
                                }
                                else
                                {
                                    // Check OK
                                    PPT_METHODTRACE_V1("","EqpMonitorKey is same.");
                                }
                            }
                        }
                    }
//DSN000081739 Add End
    //D4200302 start
                    /*--------------------------------*/
                    /*   Search Port for ProcessLot   */
                    /*--------------------------------*/
                    PPT_METHODTRACE_V1("","Search Port for ProcessLot");
                    CORBA::Long nAssignPortIdx = -1;
                    CORBA::Long lenAssignPort = useAssignEmptyCassettePortSeq.length();
                    CORBA::Long lenPort = portID.length();
                    PPT_METHODTRACE_V2("","lenAssignPort.....", lenAssignPort);
                    PPT_METHODTRACE_V2("","lenPort...........", lenPort);
                    for ( j=0; j < lenPort; j++ )
                    {
                        CORBA::Boolean bFoundPort = FALSE;

                        for ( CORBA::Long k=0; k < lenAssignPort; k++ )
                        {
                            if ( 0 == CIMFWStrLen(useAssignEmptyCassettePortSeq[k].identifier) )
                            {
                                continue; //[k]
                            }
                            if ( 0 == CIMFWStrCmp(useAssignEmptyCassettePortSeq[k].identifier, portID[j].identifier) )
                            {
                                bFoundPort = TRUE;
                                break; //[k]
                            }
                        }
                        if ( TRUE != bFoundPort )
                        {
                            nAssignPortIdx = j;
                            break; //[j]
                        }
                    }
                    if ( 0 > nAssignPortIdx )
                    {
                        PPT_METHODTRACE_V1("","##### 0 > nAssignPortIdx #####");
                        break; //[i]
                    }
                    PPT_METHODTRACE_V2("","assignPortID=====>", portID[nAssignPortIdx].identifier);
    //D4200302 end

    //P4100010 start
                    /*------------------------------------------*/
                    /*   Check Category for Copper/Non Copper   */
                    /*------------------------------------------*/
                    PPT_METHODTRACE_V1("","Check Category for Copper/Non Copper");
                    objLot_CassetteCategory_CheckForContaminationControl_out strLot_CassetteCategory_CheckForContaminationControl_out;
                    rc = lot_CassetteCategory_CheckForContaminationControl(
                                                strLot_CassetteCategory_CheckForContaminationControl_out,
                                                strObjCommonIn,
                                                strWhatNextLotListInqResult.strWhatNextAttributes[i].lotID,
                                                strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID,
                                                equipmentID,
                                                portID[nAssignPortIdx] );  //D4200302
    //D4200302                                            portID[processRunCount] );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("","UnMatch CarrierCategory (Copper/NonCopper)   ..<<continue>>", rc);
                        continue; //[i]
                    }
    //P4100010 end

    //D4000227 start
                    /*----------------------------------------------------*/
                    /*   Check Stocker which Lot belongs to, Available?   */
                    /*----------------------------------------------------*/
    //P4100073 start
                    objectIdentifier checkID;
                    if ( 0 == CIMFWStrCmp(strWhatNextLotListInqResult.strWhatNextAttributes[i].transferStatus, SP_TransState_EquipmentIn)
                      && 0 != CIMFWStrCmp(strWhatNextLotListInqResult.strWhatNextAttributes[i].equipmentID.identifier, equipmentID.identifier) )
                    {
                        checkID = equipmentID;
                        PPT_METHODTRACE_V2("","*** Delivery Process is [EQP to EQP]", checkID.identifier);
                    }
                    else
                    {
                        checkID = strWhatNextLotListInqResult.strWhatNextAttributes[i].stockerID;
                        PPT_METHODTRACE_V2("","*** Delivery Process is [EQP to Stocker]", checkID.identifier);
                    }
//P9000002 add start
                    if(   0 == CIMFWStrCmp(strWhatNextLotListInqResult.strWhatNextAttributes[i].transferStatus, SP_TransState_EquipmentOut)
                       || 0 == CIMFWStrCmp(strWhatNextLotListInqResult.strWhatNextAttributes[i].transferStatus, SP_TransState_StationOut)
                      )
                    {
                        PPT_METHODTRACE_V1("","### Cassette is PO or SO. No need to check machine availability.");
                    }
                    else
                    {
//P9000002 add end
//P9000002 adjust indent below
                        PPT_METHODTRACE_V2("","Call equipment_CheckAvail()   check EqpID or StockerID --->", checkID.identifier);
    //P4100073 end
    //P4100073                PPT_METHODTRACE_V2("","Call equipment_CheckAvail()   stockerID --->", strWhatNextLotListInqResult.strWhatNextAttributes[i].stockerID.identifier);
                        objEquipment_CheckAvail_out   strEquipment_CheckAvail_out;
                        rc = equipment_CheckAvail( strEquipment_CheckAvail_out, strObjCommonIn,
    //P4100073                                           strWhatNextLotListInqResult.strWhatNextAttributes[i].stockerID );
                                                   checkID );  //P4100073
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("","RC_OK != equipment_CheckAvail()   ..<<continue>>", strEquipment_CheckAvail_out.strResult.returnCode);
                            continue; //[i]
                        }
    //D4000227 end
                    }    //P9000002
    //D51M0007 start
                    /*-----------------------*/
                    /*   Check Scrap Wafer   */
                    /*-----------------------*/
                    objectIdentifierSequence cassetteIDs;
                    cassetteIDs.length(1);
                    cassetteIDs[0] = strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID;

                    PPT_METHODTRACE_V1("", "call cassette_scrapWafer_SelectDR()");
                    objCassette_scrapWafer_SelectDR_out strCassette_scrapWafer_SelectDR_out;
                    rc = cassette_scrapWafer_SelectDR( strCassette_scrapWafer_SelectDR_out, strObjCommonIn, cassetteIDs );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "##### cassette_scrapWafer_SelectDR() != RC_OK", rc);
                        strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strResult = strCassette_scrapWafer_SelectDR_out.strResult;
                        return(rc);
                    }
                    CORBA::Long nScrapCnt = strCassette_scrapWafer_SelectDR_out.strLotWaferMap.length();
                    PPT_METHODTRACE_V2("", "nScrapCnt", nScrapCnt);
                    if ( 0 < nScrapCnt )
                    {
                        PPT_METHODTRACE_V1("","Cassette has ScrapWafer ..<<continue>>");
                        continue; //[i]
                    }
    //D51M0007 end

//DSN000020767 Add Start
//DSN000096126                    objCassette_DBInfo_GetDR_out__120 strCassette_DBInfo_GetDR_out;
//DSN000096126                    objCassette_DBInfo_GetDR_in__100 strCassette_DBInfo_GetDR_in;
//DSN000096126                    strCassette_DBInfo_GetDR_in.cassetteID = strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID;
//DSN000096126
//DSN000096126                    rc = cassette_DBInfo_GetDR__120( strCassette_DBInfo_GetDR_out, strObjCommonIn, strCassette_DBInfo_GetDR_in );
//DSN000096126                    if ( rc != RC_OK )
//DSN000096126                    {
//DSN000096126                        PPT_METHODTRACE_V2("", "cassette_DBInfo_GetDR__120() != RC_OK",rc);
//DSN000096126                        strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strResult = strCassette_DBInfo_GetDR_out.strResult ;
//DSN000096126                        return( rc );
//DSN000096126                    }
//DSN000096126 Add Start
//DSN000101569                objCassette_DBInfo_GetDR_out__160  strCassette_DBInfo_GetDR_out;
                objCassette_DBInfo_GetDR_out__170  strCassette_DBInfo_GetDR_out;                                                //DSN000101569
                objCassette_DBInfo_GetDR_in__160   strCassette_DBInfo_GetDR_in;
                strCassette_DBInfo_GetDR_in.cassetteID                  = strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID;
                strCassette_DBInfo_GetDR_in.durableOperationInfoFlag    = FALSE;
                strCassette_DBInfo_GetDR_in.durableWipOperationInfoFlag = FALSE;
//DSN000101569                rc = cassette_DBInfo_GetDR__160(strCassette_DBInfo_GetDR_out, strObjCommonIn, strCassette_DBInfo_GetDR_in);
                rc = cassette_DBInfo_GetDR__170(strCassette_DBInfo_GetDR_out, strObjCommonIn, strCassette_DBInfo_GetDR_in);     //DSN000101569
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "objCassette_DBInfo_GetDR_out__170() != RC_OK",rc);
                    strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strResult = strCassette_DBInfo_GetDR_out.strResult;
                    return rc;
                }
//DSN000096126 Add End

                    CORBA::Long lotLen = 0;
                    CORBA::Long lotCnt = 0;
                    CORBA::Boolean bCastDispatchDisableFlag = FALSE;
                    lotLen = strCassette_DBInfo_GetDR_out.strCassetteStatusInqResult.cassetteStatusInfo.strContainedLotInfo.length();
                    for( lotCnt = 0; lotCnt < lotLen; lotCnt++ )
                    {
                        if( strCassette_DBInfo_GetDR_out.strCassetteStatusInqResult.cassetteStatusInfo.strContainedLotInfo[lotCnt].autoDispatchDisableFlag == TRUE )
                        {
                            bCastDispatchDisableFlag = TRUE;
                            break;
                        }
                    }

                    if( bCastDispatchDisableFlag == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "##### Cassette Auto Dispatch Disable Flag == TRUE ..<<continue>>");
                        continue; //[i]
                    }
//DSN000020767 Add End

                    tmpStartCassette.length(1);
                    tmpStartCassette[0].cassetteID = strWhatNextLotListInqResult.strWhatNextAttributes[i].cassetteID;

                    PPT_METHODTRACE_V2("","Candidate CassetteID--->", tmpStartCassette[0].cassetteID.identifier);

                    /*-------------------------------*/
                    /*   Set Temporary Base Recipe   */
                    /*-------------------------------*/
                    PPT_METHODTRACE_V1("","===== Set Temporary Base Recipe ===============");
                    if ( processRunCount == 0 )
                    {
                        PPT_METHODTRACE_V1("","processRunCount == 0");
                        if ( bTmpBaseRecipeFlag == FALSE )
                        {
                            // Temporary Base Recipe
                            PPT_METHODTRACE_V1("","bTmpBaseRecipeFlag == FALSE");
                            tmpBaseLogicalRecipeID = strWhatNextLotListInqResult.strWhatNextAttributes[i].logicalRecipeID;
                            tmpBaseMachineRecipeID = strWhatNextLotListInqResult.strWhatNextAttributes[i].machineRecipeID;
                            bTmpBaseRecipeFlag = TRUE;

                            PPT_METHODTRACE_V2("","  tmpBaseLogicalRecipeID --->", tmpBaseLogicalRecipeID.identifier);
                            PPT_METHODTRACE_V2("","  tmpBaseMachineRecipeID --->", tmpBaseMachineRecipeID.identifier);
                        }
                    }

                    /*-------------------*/
                    /*   Set Port Info   */
                    /*-------------------*/
                    PPT_METHODTRACE_V1("","===== Set Port Info ==================");
    //D4200302                tmpStartCassette[0].loadSequenceNumber = loadSequenceNumber[processRunCount];
                    tmpStartCassette[0].loadSequenceNumber = loadSequenceNumber[nAssignPortIdx];  //D4200302
    //P4000168                tmpStartCassette[0].loadPurposeType    = CIMFWStrDup(loadPurposeType[processRunCount]);
    //P4000168 start
                    if ( 0 == CIMFWStrCmp(loadPurposeType[nAssignPortIdx], SP_LoadPurposeType_ProcessMonitorLot) )  //D4200302
    //D4200302                if ( 0 == CIMFWStrCmp(loadPurposeType[processRunCount], SP_LoadPurposeType_ProcessMonitorLot) )
                    {
                        if ( 0 == CIMFWStrCmp(strWhatNextLotListInqResult.strWhatNextAttributes[i].lotType, SP_Lot_Type_ProductionMonitorLot) )
                        {
                            PPT_METHODTRACE_V1("","loadPurposeType == ProcessMonitorLot and LotType == ProcessMonitorLot");
                            tmpStartCassette[0].loadPurposeType = CIMFWStrDup(SP_LoadPurposeType_ProcessMonitorLot);
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("","UnMatch LoadPurposeType  ..<<continue>>");
                            continue; // [i]
                        }
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","Set LoadPurposeType [ProcessLot]");
                        tmpStartCassette[0].loadPurposeType = CIMFWStrDup(SP_LoadPurposeType_ProcessLot);
                    }
    //P4000168 end
    //D4200302                tmpStartCassette[0].loadPortID = portID[processRunCount];
                    tmpStartCassette[0].loadPortID = portID[nAssignPortIdx];  //D4200302

                    /*---------------------*/
                    /*   Get PortGroupID   */
                    /*---------------------*/
                    PPT_METHODTRACE_V1("","===== Get PortGroupID ==================");
                    bFoundFlag = FALSE;
                    for ( j=0; j < nPortGrpLen; j++ )
                    {
                        nPortLen = strPortGroup[j].strPortID.length();
                        for ( CORBA::Long k=0; k < nPortLen; k++ )
                        {
                            if ( CIMFWStrCmp(tmpStartCassette[0].loadPortID.identifier, strPortGroup[j].strPortID[k].portID.identifier) == 0 )
                            {
                                portGroupID = CIMFWStrDup(strPortGroup[j].portGroup);
                                bFoundFlag = TRUE;
                                break; // [k]
                            }
                        }
                        if ( bFoundFlag == TRUE )
                        {
                            break; // [j]
                        }
                    } //end of [j]
                    PPT_METHODTRACE_V1("","-------------------------------------------------");
                    PPT_METHODTRACE_V2("","  cassetteID...........", tmpStartCassette[0].cassetteID.identifier);
                    PPT_METHODTRACE_V2("","  loadSequenceNumber...", tmpStartCassette[0].loadSequenceNumber);
                    PPT_METHODTRACE_V2("","  loadPurposeType......", tmpStartCassette[0].loadPurposeType);
                    PPT_METHODTRACE_V2("","  loadPortID...........", tmpStartCassette[0].loadPortID.identifier);
                    PPT_METHODTRACE_V2("","  portGroupID..........", portGroupID);
                    PPT_METHODTRACE_V1("","-------------------------------------------------");

                    /*-----------------------------------*/
                    /*   Get Contained Lot in Cassette   */
                    /*-----------------------------------*/
                    PPT_METHODTRACE_V2("","===== cassette_GetLotList() ==================", tmpStartCassette[0].cassetteID.identifier);
                    objCassette_GetLotList_out strCassette_GetLotList_out;
                    rc = cassette_GetLotList( strCassette_GetLotList_out, strObjCommonIn, tmpStartCassette[0].cassetteID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "cassette_GetLotList() != RC_OK   ...<<continue>>", rc);
                        continue; // [i]
                    }

                    CORBA::Long nLotLen = strCassette_GetLotList_out.strLotListInCassetteInfo.lotID.length();
                    PPT_METHODTRACE_V2("","strCassette_GetLotList_out.strLotListInCassetteInfo.lotID.length", nLotLen);

                    tmpStartCassette[0].strLotInCassette.length(nLotLen);

                    for (j=0; j < nLotLen; j++)
                    {
                        tmpStartCassette[0].strLotInCassette[j].recipeParameterChangeType = CIMFWStrDup(SP_Rparm_ChangeType_ByLot);
                        tmpStartCassette[0].strLotInCassette[j].operationStartFlag = TRUE;
                        tmpStartCassette[0].strLotInCassette[j].lotID = strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[j];

    //P4200137 start
                        PosLot_var aLot;
                        PPT_CONVERT_LOTID_TO_LOT_OR( aLot, tmpStartCassette[0].strLotInCassette[j].lotID,
                                                     strWhatNextLotList_to_StartCassetteForDeliveryReq_out,
                                                     whatNextLotList_to_StartCassetteForDeliveryReq );
                        try
                        {
                            tmpStartCassette[0].strLotInCassette[j].lotType = aLot->getLotType();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotType)
                        PPT_METHODTRACE_V2("", "lotType", tmpStartCassette[0].strLotInCassette[j].lotType);

                        try
                        {
                            tmpStartCassette[0].strLotInCassette[j].subLotType = aLot->getSubLotType();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType)
                        PPT_METHODTRACE_V2("", "subLotType", tmpStartCassette[0].strLotInCassette[j].subLotType);

                        objLot_productID_Get_out  strLot_productID_Get_out;
                        rc = lot_productID_Get( strLot_productID_Get_out, strObjCommonIn, tmpStartCassette[0].strLotInCassette[j].lotID );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "##### lot_productID_Get() != RC_OK")
                            strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strResult = strLot_productID_Get_out.strResult;
                            return ( rc );
                        }

                        tmpStartCassette[0].strLotInCassette[j].productID = strLot_productID_Get_out.productID;
                        PPT_METHODTRACE_V2("", "productID", tmpStartCassette[0].strLotInCassette[j].productID.identifier);
    //P4200137 end

    //P7000106 start
                        /*------------------------*/
                        /*   Set Operation Info   */
                        /*------------------------*/
                        PPT_METHODTRACE_V1("", "Set Operation Info")
                        for ( CORBA::Long m=0; m < attrLen; m++ )
                        {
                            if ( 0 == CIMFWStrCmp(tmpStartCassette[0].strLotInCassette[j].lotID.identifier,
                                                  strWhatNextLotListInqResult.strWhatNextAttributes[m].lotID.identifier) )
                            {
                                tmpStartCassette[0].strLotInCassette[j].strStartOperationInfo.routeID         = strWhatNextLotListInqResult.strWhatNextAttributes[m].routeID;
                                tmpStartCassette[0].strLotInCassette[j].strStartOperationInfo.operationID     = strWhatNextLotListInqResult.strWhatNextAttributes[m].operationID;
                                tmpStartCassette[0].strLotInCassette[j].strStartOperationInfo.operationNumber = strWhatNextLotListInqResult.strWhatNextAttributes[m].operationNumber;

                                PPT_METHODTRACE_V2("", "lotID          ", tmpStartCassette[0].strLotInCassette[j].lotID.identifier);
                                PPT_METHODTRACE_V2("", "routeID        ", tmpStartCassette[0].strLotInCassette[j].strStartOperationInfo.routeID.identifier);
                                PPT_METHODTRACE_V2("", "operationID    ", tmpStartCassette[0].strLotInCassette[j].strStartOperationInfo.operationID.identifier);
                                PPT_METHODTRACE_V2("", "operationNumber", tmpStartCassette[0].strLotInCassette[j].strStartOperationInfo.operationNumber);
                                break;
                            }
                        }
    //P7000106 end

                        if ( CIMFWStrCmp(tmpStartCassette[0].loadPurposeType, SP_LoadPurposeType_ProcessMonitorLot ) == 0 )
                        {
                            /*------------------*/
                            /*   Get Lot Type   */
                            /*------------------*/
                            PPT_METHODTRACE_V2("","===== lot_type_Get() ==================", tmpStartCassette[0].strLotInCassette[j].lotID.identifier);
                            objLot_type_Get_out strLot_type_Get_out;
                            rc = lot_type_Get( strLot_type_Get_out, strObjCommonIn, tmpStartCassette[0].strLotInCassette[j].lotID );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "lot_type_Get() != RC_OK", rc);
                                continue; // [j]
                            }
                            if ( CIMFWStrCmp(strLot_type_Get_out.theLotType, SP_Lot_Type_ProductionMonitorLot ) == 0 )
                            {
                                PPT_METHODTRACE_V1("","LotType == [MonitorLot]");
                                tmpStartCassette[0].strLotInCassette[j].monitorLotFlag = TRUE;
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("","LotType != [MonitorLot]");
                                tmpStartCassette[0].strLotInCassette[j].monitorLotFlag = FALSE;
                            }
                        }
                        else
                        {
                            tmpStartCassette[0].strLotInCassette[j].monitorLotFlag = FALSE;
                        }

                        /*-----------------------------------*/
                        /*   Get Contained Wafer in Lot      */
                        /*-----------------------------------*/
                        PPT_METHODTRACE_V2("","===== lot_waferMap_Get() ==================", tmpStartCassette[0].strLotInCassette[j].lotID.identifier);
                        objLot_waferMap_Get_out strLot_waferMap_Get_out;
                        rc = lot_waferMap_Get( strLot_waferMap_Get_out, strObjCommonIn, tmpStartCassette[0].strLotInCassette[j].lotID );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "lot_waferMap_Get() != RC_OK   ..<<continue>>");
                            continue; // [j]
                        }
                        CORBA::Long nWafLen = strLot_waferMap_Get_out.strLotWaferMap.length();
                        tmpStartCassette[0].strLotInCassette[j].strLotWafer.length(nWafLen);

                        for ( CORBA::Long k=0; k < nWafLen; k++ )
                        {
                            tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].waferID          = strLot_waferMap_Get_out.strLotWaferMap[k].waferID;
                            tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].slotNumber       = strLot_waferMap_Get_out.strLotWaferMap[k].slotNumber;
                            tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].controlWaferFlag = strLot_waferMap_Get_out.strLotWaferMap[k].controlWaferFlag;
                            tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length(0);

                            PPT_METHODTRACE_V4("","waferID--->", j,k,tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].waferID.identifier);
                        } //end of [k]
                    } //end of [j]

    //P4100010 start
                    PPT_METHODTRACE_V1("", "Finished tmpStartCassette Info  ..<<break!! WhatNextInfo Loop>>");
                    break;  //[i]
    //P4100010 end

    //0.02 No used
    //0.02                /*-------------------------------------------*/
    //0.02                /*   Get Information for Start Reservation   */
    //0.02                /*-------------------------------------------*/
    //0.02                objProcess_startReserveInformation_GetBaseInfoForClient_out strProcess_startReserveInformation_GetBaseInfoForClient_out;
    //0.02                rc = process_startReserveInformation_GetBaseInfoForClient( strProcess_startReserveInformation_GetBaseInfoForClient_out,
    //0.02                                                                           strObjCommonIn,
    //0.02                                                                           equipmentID,
    //0.02                                                                           tmpStartCassette );
    //0.02                if ( rc != RC_OK )
    //0.02                {
    //0.02                    PPT_METHODTRACE_V1("", "process_startReserveInformation_GetBaseInfoForClient() != RC_OK   ..<<continue>>");
    //0.02                    continue;
    //0.02                }
                } //end of [i]
                PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");

    //P4100010 start
                /*--------------------------------------------------------------------*/
                /*   It is finished if Loop of WhatNextInfo finishes turning twice.   */
                /*--------------------------------------------------------------------*/
                if ( i >= attrLen - 1 )     // WhatNextInfo was seen to the end.
                {
                    nWIPLotLoopEndCnt++;    // Count it.
                    PPT_METHODTRACE_V2("","Turned WhatNextInfo Loop!!  Therefore Count It", nWIPLotLoopEndCnt);

                    if ( 1 < nWIPLotLoopEndCnt )
                    {
                        PPT_METHODTRACE_V2("","Turned <<Twice>> WhatNextInfo Loop!!   Therefore ..<<break!! WhatNextInfo Loop>>", nWIPLotLoopEndCnt);
                        break;
                    }
                }

                // Set Next Index of WIPLot loop
                startNo = i + 1;
    //P4100010 end

    //P4100010            if ( i == attrLen )
    //P4100010            {
    //P4100010                PPT_METHODTRACE_V1("","i==attLen   set bWhileExitFlag = TRUE");
    //P4100010                bWhileExitFlag = TRUE;
    //P4100010            }

                PPT_METHODTRACE_V1("","----------------------------------------------");
                PPT_METHODTRACE_V1("","make strStartCassette Process  done.");
                PPT_METHODTRACE_V2("","CassetteID", tmpStartCassette[0].cassetteID.identifier);
                PPT_METHODTRACE_V1("","----------------------------------------------");

    //D4000227 start
                if ( 0 == CIMFWStrLen(tmpStartCassette[0].cassetteID.identifier) )
                {
                    PPT_METHODTRACE_V1("","tmpStartCassette[0].cassetteID.identifier is null  ..<<continue>>");
                    continue; //base loop
                }
    //D4000227 end

                /**********************************************************************************/
                /*                                                                                */
                /*   Set logicalRecipeID, machineRecipeID and Set not use operationStartFlag      */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  Set logicalRecipeID, machineRecipeID and Set not use operationStartFlag");
                PPT_METHODTRACE_V1("", "//***************************************************************");

                CORBA::Long nLotLen = tmpStartCassette[0].strLotInCassette.length();
                PPT_METHODTRACE_V2("","  atteLen", attrLen);
                PPT_METHODTRACE_V2("","  nLotLen", nLotLen);

                for ( CORBA::Long i=0; i < nLotLen; i++ )
                {
                    CORBA::Long bLotFindFlag = FALSE;
                    for ( CORBA::Long j=0; j < attrLen; j++ )
                    {
                        if ( CIMFWStrCmp(strWhatNextLotListInqResult.strWhatNextAttributes[j].lotID.identifier,
                                         tmpStartCassette[0].strLotInCassette[i].lotID.identifier) == 0)
                        {
                            /*--------------------------------------------------------------------------*/
                            /*   Set logicalRecipeID, machineRecipeID for strWhatNextLotListInqResult   */
                            /*--------------------------------------------------------------------------*/
                            tmpStartCassette[0].strLotInCassette[i].strStartRecipe.logicalRecipeID
                                                = strWhatNextLotListInqResult.strWhatNextAttributes[j].logicalRecipeID;
                            tmpStartCassette[0].strLotInCassette[i].strStartRecipe.machineRecipeID
                                                = strWhatNextLotListInqResult.strWhatNextAttributes[j].machineRecipeID;
                            tmpStartCassette[0].strLotInCassette[i].strStartRecipe.physicalRecipeID
                                                = strWhatNextLotListInqResult.strWhatNextAttributes[j].physicalRecipeID;

                            bLotFindFlag = TRUE;

                            PPT_METHODTRACE_V3("","    lotID             ", i, tmpStartCassette[0].strLotInCassette[i].lotID.identifier);
                            PPT_METHODTRACE_V3("","      logicalRecipeID ", i, tmpStartCassette[0].strLotInCassette[i].strStartRecipe.logicalRecipeID.identifier);
                            PPT_METHODTRACE_V3("","      machineRecipeID ", i, tmpStartCassette[0].strLotInCassette[i].strStartRecipe.machineRecipeID.identifier);
                            PPT_METHODTRACE_V3("","      physicalRecipeID", i, tmpStartCassette[0].strLotInCassette[i].strStartRecipe.physicalRecipeID);
                        }
                    }
                    if ( bLotFindFlag == FALSE )
                    {
                        /*------------------------------------------------------------*/
                        /*   Set operationStartFlag for strWhatNextLotListInqResult   */
                        /*------------------------------------------------------------*/
                        PPT_METHODTRACE_V2("","      operationStartFlag <--- FALSE", i);
                        tmpStartCassette[0].strLotInCassette[i].operationStartFlag = FALSE;
                    }
                }
                PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");


                /**********************************************************************************/
                /*                                                                                */
                /*   Set operationStartFlag for Recipe                                            */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  Set operationStartFlag for Recipe");
                PPT_METHODTRACE_V1("", "//***************************************************************");

                /*---------------------------------*/
                /*   Get Cassette's MultiLotType   */
                /*---------------------------------*/
                PosCassette_var aCassette;
                PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                                       tmpStartCassette[0].cassetteID,
                                                       strWhatNextLotList_to_StartCassetteForDeliveryReq_out,
                                                       whatNextLotList_to_StartCassetteForDeliveryReq );
                try
                {
                    multiLotType = aCassette->getMultiLotType();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getMultiLotType);

                PPT_METHODTRACE_V2("","multiRecipeCapability", multiRecipeCapability);
                PPT_METHODTRACE_V2("","multiLotType         ", multiLotType);

                if (CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_SingleRecipe) == 0 &&
                    CIMFWStrCmp(multiLotType         , SP_Cas_MultiLotType_MultiLotMultiRecipe)   == 0 )
                {
                    PPT_METHODTRACE_V1("", "multiRecipeCapability is [SingleRecipe] and multiLotType is [ML-MR]");

                    CORBA::Long nLotLen = tmpStartCassette[0].strLotInCassette.length();
                    PPT_METHODTRACE_V2("","tmpStartCassette[0].strLotInCassette.length", nLotLen);
                    for (CORBA::Long j=0; j<nLotLen; j++)
                    {
                        // Set operationStartFlag for Recipe
                        PPT_METHODTRACE_V3("","#     lotID", j, tmpStartCassette[0].strLotInCassette[j].lotID.identifier);

                        /*-------------------------------*/
                        /*   Set Temporary Base Recipe   */
                        /*-------------------------------*/
                        if ( processRunCount == 0 )
                        {
                            // Temporary Base Recipe
                            PPT_METHODTRACE_V1("","Temporary Base Recipe");
                        }
                        else
                        {
                            // Final Base Recipe
                            PPT_METHODTRACE_V2("","processRunCount", processRunCount);
                            PPT_METHODTRACE_V1("","Final Base Recipe");
                            tmpBaseLogicalRecipeID = baseLogicalRecipeID;
                            tmpBaseMachineRecipeID = baseMachineRecipeID;
                        }

                        objectIdentifier logicalRecipeID = tmpStartCassette[0].strLotInCassette[j].strStartRecipe.logicalRecipeID;
                        objectIdentifier machineRecipeID = tmpStartCassette[0].strLotInCassette[j].strStartRecipe.machineRecipeID;

                        PPT_METHODTRACE_V1("","    Recipe Check");
                        PPT_METHODTRACE_V2("","      tmpBaseLogicalRecipeID", tmpBaseLogicalRecipeID.identifier);
                        PPT_METHODTRACE_V2("","      tmpBaseMachineRecipeID", tmpBaseMachineRecipeID.identifier);
                        PPT_METHODTRACE_V2("","      logicalRecipeID       ", logicalRecipeID.identifier);
                        PPT_METHODTRACE_V2("","      machineRecipeID       ", machineRecipeID.identifier);

                        if ( CIMFWStrCmp(tmpBaseLogicalRecipeID.identifier, logicalRecipeID.identifier) == 0 &&
                             CIMFWStrCmp(tmpBaseMachineRecipeID.identifier, machineRecipeID.identifier) == 0)
                        {
                            PPT_METHODTRACE_V1("","tmpBaseLogicalRecipeID == logicalRecipeID && tmpBaseMachineRecipeID == machineRecipeID");
                        }
                        else
                        {
                            PPT_METHODTRACE_V2("","#       operationStartFlag <--- FALSE", j);
                            tmpStartCassette[0].strLotInCassette[j].operationStartFlag = FALSE;
                        }
                    }
                }
                PPT_METHODTRACE_V1("","<<<<< End Block >>>>>   Set operationStartFlag for Recipe");

    //D4200092 start
                /**********************************************************************************/
                /*                                                                                */
                /*   Set StartRecipeParameter                                                     */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  Set StartRecipeParameter");
                PPT_METHODTRACE_V1("", "//***************************************************************");

                for ( CORBA::Long j=0; j < nLotLen; j++ )
                {
                    if ( TRUE != tmpStartCassette[0].strLotInCassette[j].operationStartFlag )
                    {
                        PPT_METHODTRACE_V1("", "tmpStartCassette[0].strLotInCassette[j].operationStartFlag is FALSE  ..<continue>");
                        continue;
                    }

                    PosLogicalRecipe_var aLogicalRecipe;
                    PPT_CONVERT_LOGICALRECIPEID_TO_LOGICALRECIPE_OR( aLogicalRecipe,
                                                                     tmpStartCassette[0].strLotInCassette[j].strStartRecipe.logicalRecipeID,
                                                                     strWhatNextLotList_to_StartCassetteForDeliveryReq_out,
                                                                     whatNextLotList_to_StartCassetteForDeliveryReq );

                    PosMachineRecipe_var aMachineRecipe;
    //D7000042      PPT_CONVERT_RECIPEID_TO_MACHINERECIPE_OR( aMachineRecipe,
    //D7000042                                                tmpStartCassette[0].strLotInCassette[j].strStartRecipe.machineRecipeID,
    //D7000042                                                strWhatNextLotList_to_StartCassetteForDeliveryReq_out,
    //D7000042                                                whatNextLotList_to_StartCassetteForDeliveryReq );
    //D6000415 add start
                    /************************/
                    /*   Get subLotType     */
                    /************************/
                    PosLot_var aLot ; //DSIV00001443
                    CORBA::String_var subLotType;
                    if( 0 == CIMFWStrLen( tmpStartCassette[0].strLotInCassette[j].subLotType) )
                    {
//DSIV00001443                        PosLot_var aLot ;
                        PPT_CONVERT_LOTID_TO_LOT_OR( aLot,
                                                     tmpStartCassette[0].strLotInCassette[j].lotID,
                                                     strWhatNextLotList_to_StartCassetteForDeliveryReq_out,
                                                     whatNextLotList_to_StartCassetteForDeliveryReq);
                        try
                        {
                            subLotType = aLot->getSubLotType();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType);
                    }
                    else
                    {
                        subLotType = tmpStartCassette[0].strLotInCassette[j].subLotType ;
                    }
    //D6000415 add end
    //D8000024 add start
                    CORBA::Boolean skipFlag = FALSE;
                    objLot_effectiveFPCInfo_Get_out strLot_effectiveFPCInfo_Get_out;
                    rc = lot_effectiveFPCInfo_Get( strLot_effectiveFPCInfo_Get_out, strObjCommonIn,
                                                   SP_FPC_ExchangeType_StartReserveInfo,
                                                   equipmentID,
                                                   tmpStartCassette[0].strLotInCassette[j].lotID );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_effectiveFPCInfo_Get() != RC_OK", rc);
                        strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strResult =
                            strLot_effectiveFPCInfo_Get_out.strResult;
                        return rc;
                    }

                    if( strLot_effectiveFPCInfo_Get_out.machineRecipeActionRequired == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "MachineRecipe is overwritten by FPC");
                    }
                    else
                    {
    //D8000024 add end
                        if( searchCondition == 1 )                                                                  //DSIV00001443
                        {                                                                                           //DSIV00001443
                            if ( CORBA::is_nil(aLot) == TRUE )                                                      //DSIV00001443
                            {                                                                                       //DSIV00001443
                                PPT_CONVERT_LOTID_TO_LOT_OR( aLot,                                                  //DSIV00001443
                                                             tmpStartCassette[0].strLotInCassette[j].lotID,         //DSIV00001443
                                                             strWhatNextLotList_to_StartCassetteForDeliveryReq_out, //DSIV00001443
                                                             whatNextLotList_to_StartCassetteForDeliveryReq);       //DSIV00001443
                            }                                                                                       //DSIV00001443
                            try                                                                                     //DSIV00001443
                            {                                                                                       //DSIV00001443
                                aMachineRecipe = aLogicalRecipe->findMachineRecipeFor( aLot, aMachine );            //DSIV00001443
                            }                                                                                       //DSIV00001443
                            CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeFor)                      //DSIV00001443
                        }                                                                                           //DSIV00001443
                        else                                                                                        //DSIV00001443
                        {                                                                                           //DSIV00001443
    //D7000042 add start
                            try
                            {
                                aMachineRecipe = aLogicalRecipe->findMachineRecipeForSubLotType( aMachine, subLotType );
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findMachineRecipeForSubLotType)
    //D7000042 add end
                        }                                                                                           //DSIV00001443

                        PosRecipeParameterSequence*    recipeParameterSeq = NULL;
                        PosRecipeParameterSequence_var recipeParameterSeqVar;
                        try
                        {
    //D6000415          recipeParameterSeq = aLogicalRecipe->findRecipeParametersFor( aMachine, aMachineRecipe );
                            recipeParameterSeq = aLogicalRecipe->findRecipeParametersForSubLotType( aMachine, aMachineRecipe, subLotType );    //D6000415
                            recipeParameterSeqVar = recipeParameterSeq;
                        }
    //D6000415      CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findRecipeParametersFor);
                        CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::findRecipeParametersForSubLotType);    //D6000415

                        CORBA::Long rpmCnt = recipeParameterSeq->length();
                        PPT_METHODTRACE_V2("", "recipeParameterSeq->length()", rpmCnt);

                        CORBA::Long nWafLen = tmpStartCassette[0].strLotInCassette[j].strLotWafer.length();
                        for ( CORBA::Long k=0; k < nWafLen; k++ )
                        {
                            if ( NULL == recipeParameterSeq )
                            {
                                tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length(0);
                            }
                            else
                            {
                                tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length( rpmCnt );

                                for ( CORBA::Long l=0; l < rpmCnt; l++ )
                                {
                                    PPT_METHODTRACE_V2("", "rpmCnt----------------------------", l);
                                    tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterName = (*recipeParameterSeq)[l].parameterName;
                                    if ( TRUE == (*recipeParameterSeq)[l].useCurrentValueFlag )
                                    {
                                        PPT_METHODTRACE_V1("", "(*recipeParameterSeq)[l].useCurrentValueFlag is TRUE");
                                        tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterValue = (const char*)"";
                                    }
                                    else
                                    {
                                        tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterValue = (*recipeParameterSeq)[l].defaultValue;
                                    }
                                    tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].targetValue = (*recipeParameterSeq)[l].defaultValue;
                                    tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].useCurrentSettingValueFlag = (*recipeParameterSeq)[l].useCurrentValueFlag;

                                    PPT_METHODTRACE_V2("", ".parameterName _______________", tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterName);
                                    PPT_METHODTRACE_V2("", ".parameterValue ______________", tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterValue);
                                    PPT_METHODTRACE_V2("", ".targetValue _________________", tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].targetValue);
//D9000001                                    PPT_METHODTRACE_V2("", ".useCurrentSettingValueFlag __", (long)tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].useCurrentSettingValueFlag);
                                    PPT_METHODTRACE_V2("", ".useCurrentSettingValueFlag __", (int)tmpStartCassette[0].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].useCurrentSettingValueFlag); //D9000001
                                }
                            }
                        }
                    }    //D8000024
                }
    //D4200092 end

                /**********************************************************************************/
                /*                                                                                */
                /*   check strStartCassette Process                                               */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  check strStartCassette Process");
                PPT_METHODTRACE_V1("", "//***************************************************************");

                /*-----------------------------------------------------------------------*/
                /*                                                                       */
                /*   Check Process for Cassette                                          */
                /*                                                                       */
                /*   The following conditions are checked by this object                 */
                /*                                                                       */
                /*   - controlJobID                                                      */
                /*   - multiLotType                                                      */
                /*   - transferState                                                     */
                /*   - transferReserved                                                  */
                /*   - dispatchState                                                     */
                /*   - maxBatchSize                                                      */
                /*   - minBatchSize                                                      */
                /*   - emptyCassetteCount                                                */
                /*   - cassette'sloadingSequenceNomber                                   */
                /*   - eqp's multiRecipeCapability and recipeParameter                   */
                /*                                                                       */
                /*-----------------------------------------------------------------------*/
                PPT_METHODTRACE_V1("","===== Check Process for Cassette ==========");
                CORBA::Long saveLoadSequenceNumber = tmpStartCassette[0].loadSequenceNumber;
                tmpStartCassette[0].loadSequenceNumber = 1;

                /*===== for emptyCassetteCount =====*/
//D9000001                PPT_METHODTRACE_V2("", "cassetteExchangeFlag  ", (long)strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag);
                PPT_METHODTRACE_V2("", "cassetteExchangeFlag  ", (int)strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag); //D9000001
//D9000001                PPT_METHODTRACE_V2("", "monitorCreationFlag   ", (long)strEquipment_processBatchCondition_Get_out.monitorCreationFlag);
                PPT_METHODTRACE_V2("", "monitorCreationFlag   ", (int)strEquipment_processBatchCondition_Get_out.monitorCreationFlag); //D9000001
                PPT_METHODTRACE_V2("", "minBatchSize          ", strEquipment_processBatchCondition_Get_out.minBatchSize);

                if ( strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag == TRUE ||
                     strEquipment_processBatchCondition_Get_out.monitorCreationFlag  == TRUE ||
                     strEquipment_processBatchCondition_Get_out.minBatchSize > 1)
                {
                    PPT_METHODTRACE_V1("", "cassetteExchangeFlag == TRUE or monitorCreationFlag  == TRUE or minBatchSize > 1");
                    PPT_METHODTRACE_V1("", "call cassette_CheckConditionForDelivery()");
                    objCassette_CheckConditionForDelivery_out strCassette_CheckConditionForDelivery_out;
                    rc = cassette_CheckConditionForDelivery( strCassette_CheckConditionForDelivery_out,
                                                             strObjCommonIn,
                                                             equipmentID,
                                                             portGroupID,
                                                             tmpStartCassette,
                                                             SP_Operation_StartReservation );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "cassette_CheckConditionForDelivery() != RC_OK   ..<<continue>>");
                        continue; //base loop
                    }
                }
                else
                {
                    PPT_METHODTRACE_V1("", "!cassetteExchangeFlag == TRUE or monitorCreationFlag  == TRUE or minBatchSize > 1");
                    PPT_METHODTRACE_V1("", "call cassette_CheckConditionForOperation()");

                    objCassette_CheckConditionForOperation_out strCassette_CheckConditionForOperation_out;
                    rc = cassette_CheckConditionForOperation( strCassette_CheckConditionForOperation_out,
                                                              strObjCommonIn,
                                                              equipmentID,
                                                              portGroupID,
                                                              tmpStartCassette,
                                                              SP_Operation_StartReservation );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "cassette_CheckConditionForOperation() != RC_OK   ..<<continue>>");
                        continue; //base loop
                    }
                }

                tmpStartCassette[0].loadSequenceNumber = saveLoadSequenceNumber;

                /*-----------------------------------------------------------------------*/
                /*                                                                       */
                /*   Check Process for Lot                                               */
                /*                                                                       */
                /*   The following conditions are checked by this object                 */
                /*                                                                       */
                /*   - controlJobID                                                      */
                /*   - lot's equipmentID                                                 */
                /*   - lotHoldState                                                      */
                /*   - lotProcessState                                                   */
                /*   - lotInventoryState                                                 */
                /*   - entityInhibition                                                  */
                /*   - minWaferCount                                                     */
                /*   - equipment's availability for specified lot                        */
                /*                                                                       */
                /*-----------------------------------------------------------------------*/
                PPT_METHODTRACE_V1("","===== lot_CheckConditionForOperation() ==========");
                objLot_CheckConditionForOperation_out strLot_CheckConditionForOperation_out;
                rc = lot_CheckConditionForOperation( strLot_CheckConditionForOperation_out,
                                                     strObjCommonIn,
                                                     equipmentID,
                                                     portGroupID,
                                                     tmpStartCassette,
    //P4100258                                                 SP_Operation_StartReservation );
                                                     SP_Operation_CassetteDelivery );    //P4100258
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_CheckConditionForOperation() != RC_OK   ..<<continue>>");
                    continue; //base loop
                }

                /*-----------------------------------------------------------------------------*/
                /*                                                                             */
                /*   Check Equipment Port for Start Reservation                                */
                /*                                                                             */
                /*   The following conditions are checked by this object                       */
                /*                                                                             */
                /*   1. In-parm's portGroupID must not have controlJobID.                      */
                /*   2. All of ports' loadMode must be CIMFW_PortRsc_Input or _InputOutput.    */
                /*   3. All of port, which is registered as in-parm's portGroup, must be       */
                /*      _LoadAvail or _LoadReq when equipment is online.                       */
                /*      As exceptional case, if equipment's takeOutInTransferFlag is True,     */
                /*      _UnloadReq is also OK for start reservation when equipment is Online.  */
                /*   4. All of port, which is registered as in-parm's portGroup,               */
                /*      must not have loadedCassetteID.                                        */
                /*   5. strStartCassette[].loadPortID's portGroupID must be same               */
                /*      as in-parm's portGroupID.                                              */
                /*   6. strStartCassette[].loadPurposeType must be match as specified port's   */
                /*      loadPutposeType.                                                       */
                /*   7. strStartCassette[].loadSequenceNumber must be same as specified port's */
                /*      loadSequenceNumber.                                                    */
                /*                                                                             */
                /*-----------------------------------------------------------------------------*/
                PPT_METHODTRACE_V1("","===== equipment_portState_CheckForStartReservation() ==========");
                objEquipment_portState_CheckForStartReservation_out strEquipment_portState_CheckForStartReservation_out;
                rc = equipment_portState_CheckForStartReservation( strEquipment_portState_CheckForStartReservation_out,
                                                                   strObjCommonIn,
                                                                   equipmentID,
                                                                   portGroupID,
                                                                   tmpStartCassette );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "equipment_portState_CheckForStartReservation() != RC_OK   ..<<continue>>");
                    continue; //base loop
                }

    //D4100036 delete start
    //D4100036            /*-----------------------------------------------------------------------*/
    //D4100036            /*                                                                       */
    //D4100036            /*   Check Process for FlowBatch                                         */
    //D4100036            /*                                                                       */
    //D4100036            /*   The following conditions are checked by this object                 */
    //D4100036            /*                                                                       */
    //D4100036            /*   1. whether in-parm's equipment has reserved flowBatchID or not      */
    //D4100036            /*      fill  -> all of flowBatch member and in-parm's lot must be       */
    //D4100036            /*               same perfectly.                                         */
    //D4100036            /*      blank -> no check                                                */
    //D4100036            /*                                                                       */
    //D4100036            /*   2. whether lot is in flowBatch section or not                       */
    //D4100036            /*      in    -> lot must have flowBatchID, and flowBatch must have      */
    //D4100036            /*               reserved equipmentID.                                   */
    //D4100036            /*               if lot is on target operation, flowBatch's reserved     */
    //D4100036            /*               equipmentID and in-parm's equipmentID must be same.     */
    //D4100036            /*      out   -> no check                                                */
    //D4100036            /*                                                                       */
    //D4100036            /*-----------------------------------------------------------------------*/
    //D4100036            PPT_METHODTRACE_V1("","===== equipment_lot_CheckFlowBatchConditionForOpeStart() ==========");
    //D4100036            objEquipment_lot_CheckFlowBatchConditionForOpeStart_out strEquipment_lot_CheckFlowBatchConditionForOpeStart_out;
    //D4100036            rc = equipment_lot_CheckFlowBatchConditionForOpeStart( strEquipment_lot_CheckFlowBatchConditionForOpeStart_out,
    //D4100036                                                                   strObjCommonIn,
    //D4100036                                                                   equipmentID,
    //D4100036                                                                   portGroupID,
    //D4100036                                                                   tmpStartCassette );
    //D4100036            if ( rc != RC_OK )
    //D4100036            {
    //D4100036                PPT_METHODTRACE_V1("", "equipment_lot_CheckFlowBatchConditionForOpeStart() != RC_OK   ..<<continue>>");
    //D4100036                continue; //base loop
    //D4100036            }
    //D4100036 delete end

                /*-----------------------------------------------------------------------*/
                /*                                                                       */
                /*   Check Process for Process Durable                                   */
                /*                                                                       */
                /*   The following conditions are checked by this object                 */
                /*                                                                       */
                /*   1. Whether equipment requires process durable or not                */
                /*      If no-need, return OK;                                           */
                /*                                                                       */
                /*   2. At least one of reticle / fixture for each reticleGroup /        */
                /*      fixtureGroup is in the equipment or not.                         */
                /*      Even if required reticle is in the equipment, its status must    */
                /*      be _Available or _InUse.                                         */
                /*                                                                       */
                /*-----------------------------------------------------------------------*/
                PPT_METHODTRACE_V1("","===== Check Process for Process Durable ==========");

                CORBA::Boolean DurableRequiredFlag = FALSE;

                PPT_METHODTRACE_V1("", "call equipment_processDurableRequiredFlag_Get()");
                objEquipment_processDurableRequiredFlag_Get_out strEquipment_processDurableRequiredFlag_Get_out;
                rc = equipment_processDurableRequiredFlag_Get( strEquipment_processDurableRequiredFlag_Get_out,
                                                               strObjCommonIn,
                                                               equipmentID );
                if ( rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD )
                {
                    PPT_METHODTRACE_V1("","rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD");

                    if ( CIMFWStrCmp(tmpStartCassette[0].loadPurposeType, SP_LoadPurposeType_EmptyCassette) != 0)
                    {
                        PPT_METHODTRACE_V1("","tmpStartCassette[0].loadPurposeType != SP_LoadPurposeType_EmptyCassette");

                        CORBA::Long nLotLen = tmpStartCassette[0].strLotInCassette.length();
                        PPT_METHODTRACE_V2("","nLotLen", nLotLen);
                        for (CORBA::Long j=0; j<nLotLen; j++)
                        {
                            PPT_METHODTRACE_V2("","counter[j]", j);

                            if ( tmpStartCassette[0].strLotInCassette[j].operationStartFlag == FALSE )
                            {
                                PPT_METHODTRACE_V1("","tmpStartCassette[0].strLotInCassette[j].operationStartFlag == FALSE");
                                continue; //base loop
                            }

                            PPT_METHODTRACE_V2("","logicalRecipeID", tmpStartCassette[0].strLotInCassette[j].strStartRecipe.logicalRecipeID.identifier);
                            PPT_METHODTRACE_V2("","machineRecipeID", tmpStartCassette[0].strLotInCassette[j].strStartRecipe.machineRecipeID.identifier);

                            /*--------------------------------------------------*/
                            /*   Check Process Durable Condition for OpeStart   */
                            /*--------------------------------------------------*/
                            PPT_METHODTRACE_V1("", "call processDurable_CheckConditionForOpeStart()");
                            objProcessDurable_CheckConditionForOpeStart_out strProcessDurable_CheckConditionForOpeStart_out;
                            rc = processDurable_CheckConditionForOpeStart( strProcessDurable_CheckConditionForOpeStart_out,
                                                                           strObjCommonIn,
                                                                           equipmentID,
                                                                           tmpStartCassette[0].strLotInCassette[j].strStartRecipe.logicalRecipeID,
    //D4000048                                                             tmpStartCassette[0].strLotInCassette[j].strStartRecipe.machineRecipeID );
                                                                           tmpStartCassette[0].strLotInCassette[j].strStartRecipe.machineRecipeID,       //D4000048
                                                                           tmpStartCassette[0].strLotInCassette[j].lotID );                              //D4000048
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("","processDurable_CheckConditionForOpeStart() != RC_OK");
                                DurableRequiredFlag = TRUE;
                                PPT_METHODTRACE_V1("","DurableRequiredFlag = TRUE");
                                break;
                            }

                            /*---------------------------------------*/
                            /*   Set Available Reticles / Fixtures   */
                            /*---------------------------------------*/
                            tmpStartCassette[0].strLotInCassette[j].strStartRecipe.strStartReticle = strProcessDurable_CheckConditionForOpeStart_out.strStartReticle;
                            tmpStartCassette[0].strLotInCassette[j].strStartRecipe.strStartFixture = strProcessDurable_CheckConditionForOpeStart_out.strStartFixture;
                        }
                        if ( DurableRequiredFlag == TRUE)
                        {
                            PPT_METHODTRACE_V1("","DurableRequiredFlag == TRUE   ..<<continue>>");
                            continue; //base loop
                        }
                    }
                }
                else if ( rc != RC_EQP_PROCDRBL_NOT_REQD )
                {
                    PPT_METHODTRACE_V1("","rc != RC_EQP_PROCDRBL_NOT_REQD   ..<<continue>>");
                    continue; //base loop
                }

    //P4100010 delete start
    //P4100010//D4000016 Add Start
    //P4100010            /*---------------------------------------------------------------------------*/
    //P4100010            /*                                                                           */
    //P4100010            /*   Check Category for Copper/Non Copper                                    */
    //P4100010            /*                                                                           */
    //P4100010            /*   It is checked in the following method whether it is the condition       */
    //P4100010            /*   that Lot of the object is made of OpeStart.                             */
    //P4100010            /*                                                                           */
    //P4100010            /*   1. It is checked whether CassetteCategory of RequiredCassetteCategory   */
    //P4100010            /*      of PosLot and PosCassette is the same.                               */
    //P4100010            /*                                                                           */
    //P4100010            /*   2. It is checked whether CassetteCategoryCapability of CassetteCategory */
    //P4100010            /*      of PosCassette and PosPortResource is the same.                      */
    //P4100010            /*                                                                           */
    //P4100010            /*   3. It is proper condition if CassetteCategoryCapability is the same     */
    //P4100010            /*      as RequiredCassetteCategory and CassetteCategory.                    */
    //P4100010            /*                                                                           */
    //P4100010            /*---------------------------------------------------------------------------*/
    //P4100010            PPT_METHODTRACE_V1("","===== Check Category for Copper/Non Copper ==========");
    //P4100010            CORBA::Long ii;
    //P4100010            CORBA::Long jj;
    //P4100010            CORBA::Long nCastLen = strStartCassette.length();
    //P4100010            CORBA::Long nLotInCastLen;
    //P4100010            CORBA::Boolean bCategory = TRUE;
    //P4100010
    //P4100010            for ( ii = 0; ii < nCastLen; ii++ )
    //P4100010            {
    //P4100010                nLotInCastLen = strStartCassette[ii].strLotInCassette.length();
    //P4100010                for ( jj = 0; jj < nLotInCastLen; jj++ )
    //P4100010                {
    //P4100010                    PPT_METHODTRACE_V1("","call lot_CassetteCategory_CheckForContaminationControl()");
    //P4100010                    objLot_CassetteCategory_CheckForContaminationControl_out strLot_CassetteCategory_CheckForContaminationControl_out;
    //P4100010                    rc = lot_CassetteCategory_CheckForContaminationControl( strLot_CassetteCategory_CheckForContaminationControl_out,
    //P4100010                                                              strObjCommonIn,
    //P4100010                                                              strStartCassette[ii].strLotInCassette[jj].lotID,
    //P4100010                                                              strStartCassette[ii].cassetteID,
    //P4100010                                                              equipmentID,
    //P4100010                                                              strStartCassette[0].loadPortID);
    //P4100010                    if ( rc != RC_OK )
    //P4100010                    {
    //P4100010                        bCategory = FALSE;
    //P4100010                        break;
    //P4100010                    }
    //P4100010                }
    //P4100010            }
    //P4100010
    //P4100010            if ( bCategory == FALSE )
    //P4100010            {
    //P4100010                PPT_METHODTRACE_V1("","bCategory == FALSE   ..<<continue>>");
    //P4100010                continue; //base loop
    //P4100010            }
    //P4100010//D4000016 Add End
    //P4100010 delete end
                PPT_METHODTRACE_V1("","<<<<< End Block >>>>>   check strStartCassette Process");


                /**********************************************************************************/
                /*                                                                                */
                /*   Check multiRecipeCapability and multiLotType                                 */
                /*   and Decide finally to put it in StartCassette                                */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  Check multiRecipeCapability and multiLotType");
                PPT_METHODTRACE_V1("", "//***************************************************************");

                //----------------------------------------------------------------------
                //      Equipment's         Cassette's
                // multiRecipeCapability    multiLotType    Same Recipe Check
                // =====================================================================
                // M-Recipe                 SL-SR           FALSE
                //                          ML-SR           FALSE
                //                          ML-MR           FALSE
                // -----------------------  --------------------------------------------
                // S-Recipe                 SL-SR           TRUE
                //                          ML-SR           TRUE
                //                          ML-MR           TRUE
                // -----------------------  --------------------------------------------
                // Batch                    SL-SR           TRUE
                //                          ML-SR           TRUE
                //                          ML-MR           Error
                // -----------------------  --------------------------------------------
                CORBA::Boolean bAddStartCassette = FALSE;       //D4000184

                if ( CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_MultipleRecipe) == 0 )
                {
                    // M-Recipe: SL-SR, ML-SR, ML-MR
                    // Same Recipe Check : FALSE
                    PPT_METHODTRACE_V1("","M-Recipe: SL-SR, ML-SR, ML-MR");
                    PPT_METHODTRACE_V1("","Same Recipe Check : FALSE");

                    PPT_METHODTRACE_V2("","### Add cassetteID", tmpStartCassette[0].cassetteID.identifier);

    //D4000184                strStartCassette[processRunCount] = tmpStartCassette[0];
    //D4000184                processRunCount++;
                    bAddStartCassette = TRUE;       //D4000184
                }
                else if ( CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_Batch)      == 0 &&
                          CIMFWStrCmp(multiLotType         , SP_Cas_MultiLotType_MultiLotMultiRecipe) == 0 )
                {
                    // Batch and ML-MR
                    // Error
                    PPT_METHODTRACE_V1("","Batch and ML-MR: continue");
                    continue; //base loop
                }
                else
                {
                    // S-Recipe: SL-SR, ML-SR, ML-MR
                    // Batch   : SL-SR, ML-SR
                    // Same Recipe Check : TRUE
                    PPT_METHODTRACE_V1("","S-Recipe: SL-SR, ML-SR, ML-MR");
                    PPT_METHODTRACE_V1("","Batch   : SL-SR, ML-SR");
                    PPT_METHODTRACE_V1("","Same Recipe Check : TRUE");

                    if ( processRunCount == 0 )
                    {
                        PPT_METHODTRACE_V1("","processRunCount == 0");

                        PPT_METHODTRACE_V2("","### Add cassetteID", tmpStartCassette[0].cassetteID.identifier);
    //D4000184                    strStartCassette[0] = tmpStartCassette[0];
    //D4000184                    processRunCount++;
                        bAddStartCassette = TRUE;       //D4000184

                        /*------------------------------------------------------------*/
                        /*   Set Base Recipe (First operationStartFlag=TRUE Recipe)   */
                        /*------------------------------------------------------------*/
                        CORBA::Long nLotLen = tmpStartCassette[0].strLotInCassette.length();
                        PPT_METHODTRACE_V2("","nLotLen", nLotLen);
                        for (CORBA::Long i=0; i<nLotLen; i++)
                        {
                            if (tmpStartCassette[0].strLotInCassette[i].operationStartFlag == TRUE)
                            {
                                baseLogicalRecipeID = tmpStartCassette[0].strLotInCassette[i].strStartRecipe.logicalRecipeID;
                                baseMachineRecipeID = tmpStartCassette[0].strLotInCassette[i].strStartRecipe.machineRecipeID;
                                break;
                            }
                        }
                        if (CIMFWStrLen(baseLogicalRecipeID.identifier) == 0 || CIMFWStrLen(baseMachineRecipeID.identifier) == 0)
                        {
                            PPT_METHODTRACE_V1("","################## Can not Found Base Recipe!! ###################");
                            PPT_METHODTRACE_V2("","###  baseLogicalRecipeID", baseLogicalRecipeID.identifier);
                            PPT_METHODTRACE_V2("","###  baseMachineRecipeID", baseMachineRecipeID.identifier);
                            PPT_METHODTRACE_V1("","##################################################################");
                        }
                    }
                    else
                    {
                        objectIdentifier logicalRecipeID;
                        objectIdentifier machineRecipeID;
                        /*--------------------------------------------------------*/
                        /*   Find Recipe (First operationStartFlag=TRUE Recipe)   */
                        /*--------------------------------------------------------*/
                        CORBA::Long nLotLen = tmpStartCassette[0].strLotInCassette.length();
                        PPT_METHODTRACE_V2("","nLotLen", nLotLen);
                        for (CORBA::Long i=0; i<nLotLen; i++)
                        {
                            if (tmpStartCassette[0].strLotInCassette[i].operationStartFlag == TRUE)
                            {
                                logicalRecipeID = tmpStartCassette[0].strLotInCassette[i].strStartRecipe.logicalRecipeID;
                                machineRecipeID = tmpStartCassette[0].strLotInCassette[i].strStartRecipe.machineRecipeID;
                                break;
                            }
                        }
                        if (CIMFWStrLen(logicalRecipeID.identifier) == 0 || CIMFWStrLen(machineRecipeID.identifier) == 0)
                        {
                            PPT_METHODTRACE_V1("","################## Can not Found Recipe!! ###################");
                            PPT_METHODTRACE_V2("","###  logicalRecipeID", logicalRecipeID.identifier);
                            PPT_METHODTRACE_V2("","###  machineRecipeID", machineRecipeID.identifier);
                            PPT_METHODTRACE_V1("","#############################################################");
                        }

                        PPT_METHODTRACE_V1("","Recipe Check");
                        PPT_METHODTRACE_V2("","  baseLogicalRecipeID", baseLogicalRecipeID.identifier);
                        PPT_METHODTRACE_V2("","  baseMachineRecipeID", baseMachineRecipeID.identifier);
                        PPT_METHODTRACE_V2("","  logicalRecipeID    ", logicalRecipeID.identifier);
                        PPT_METHODTRACE_V2("","  machineRecipeID    ", machineRecipeID.identifier);

                        if ( CIMFWStrCmp(baseLogicalRecipeID.identifier, logicalRecipeID.identifier) == 0 &&
                             CIMFWStrCmp(baseMachineRecipeID.identifier, machineRecipeID.identifier) == 0)
                        {
                            PPT_METHODTRACE_V1("","baseLogicalRecipeID == logicalRecipeID && baseMachineRecipeID == machineRecipeID");

                            PPT_METHODTRACE_V2("","### Add cassetteID", tmpStartCassette[0].cassetteID.identifier);

    //D4000184                        strStartCassette[processRunCount] = tmpStartCassette[0];
    //D4000184                        processRunCount++;
                            bAddStartCassette = TRUE;       //D4000184
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("","###############################################");
                            PPT_METHODTRACE_V1("","Deferent Recipe.  ...<<<continue>>>");
                            PPT_METHODTRACE_V1("","###############################################");
                            continue; //base loop
                        }
                    }
                }
                PPT_METHODTRACE_V1("","<<<<< End Block >>>>>   Add tmpStartCassette to StartCassette");

    //D4000184 start
                /**********************************************************************************/
                /*                                                                                */
                /*   Add tmpStartCassette to StartCassette                                        */
                /*                                                                                */
                /**********************************************************************************/
                PPT_METHODTRACE_V1("", "//***************************************************************");
                PPT_METHODTRACE_V1("", "//  Add tmpStartCassette to StartCassette");
                PPT_METHODTRACE_V1("", "//***************************************************************");

                if ( TRUE == bAddStartCassette )
                {
                    /*******************************************************************************/
                    /*   Check MonitorCreationFlag                                                 */
                    /*   Only one time of the beginnings                                           */
                    /*******************************************************************************/
                    if ( FALSE == bAlreadyCheckMonitorCreationFlag
                      && TRUE == strEquipment_processBatchCondition_Get_out.monitorCreationFlag )
                    {
                        PPT_METHODTRACE_V1("","===== Check MonitorCreationFlag ==========");
                        PosLogicalRecipe_var aLogicalRecipe;
                        PPT_CONVERT_LOGICALRECIPEID_TO_LOGICALRECIPE_OR( aLogicalRecipe,
                                                                         tmpBaseLogicalRecipeID,
                                                                         strWhatNextLotList_to_StartCassetteForDeliveryReq_out,
                                                                         whatNextLotList_to_StartCassetteForDeliveryReq );
                        PosProductSpecification_var aMonitorProduct;
                        try
                        {
                            aMonitorProduct = aLogicalRecipe->getMonitorProduct();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLogicalRecipe::getMonitorProduct)

                        if ( TRUE != CORBA::is_nil(aMonitorProduct) )
                        {
                            //***** EmptyCassette is necessary! *****
                            PPT_METHODTRACE_V1("", "===== Set EmptyCassette for MonitorCreation ==========");
//INN-R170002 Add Start
                            CORBA::String_var strReqUsageType;
                            SI_PPT_USERDATA_GET_STRING( aMonitorProduct, CS_S_PROD_CarrierUsageType, strReqUsageType );
//INN-R170002 Add End

                            /*------------------------------------------------*/
                            /*   Look for Port to assign, and EmptyCassette   */
                            /*------------------------------------------------*/
                            PPT_METHODTRACE_V1("","/*------------------------------------------------*/");
                            PPT_METHODTRACE_V1("","/*   Look for Port to assign, and EmptyCassette   */");
                            PPT_METHODTRACE_V1("","/*------------------------------------------------*/");
                            objectIdentifier dummyLotID;
                            objCassetteDelivery_SearchEmptyCassetteAssignPort_out strCassetteDelivery_SearchEmptyCassetteAssignPort_out;
//INN-R170002               rc = cassetteDelivery_SearchEmptyCassetteAssignPort(
                            rc = cs_cassetteDelivery_SearchEmptyCassetteAssignPort( //INN-R170002
                                            strCassetteDelivery_SearchEmptyCassetteAssignPort_out,
                                            strObjCommonIn,
                                            dummyLotID,     // Because it is MonitorCreation, it doesn't have Lot
                                            strPortGroup[0].strPortID,
                                            strReqUsageType,    //INN-R170002
                                            strCassetteList_emptyAvailable_Pickup_out.strFoundCassette,
                                            useEmptyCassetteIDSeq,
                                            useAssignEmptyCassettePortSeq );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("","##### NotFound!! Assign EmptyCassette or Assign Port!   set bWhileExitFlag = TRUE  ...<<<continue>>>");
                                bWhileExitFlag = TRUE;
                                continue; //base loop
                            }

                            // Hold EmptyCasstte and Port to prevent duplication
                            PPT_METHODTRACE_V1("", "Hold EmptyCasstte and Port to prevent duplication");
                            useAssignEmptyCassettePortSeq[ nAssignEmptyCassetteCnt ] = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.strFoundPort.portID;
                            useEmptyCassetteIDSeq[ nAssignEmptyCassetteCnt ] = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.foundEmptyCassetteID;
                            nAssignEmptyCassetteCnt++;
                            PPT_METHODTRACE_V2("", "nAssignEmptyCassetteCnt--------->", nAssignEmptyCassetteCnt);

                            /*-------------------------------------------------------------------------*/
                            /*   Found!! Assign EmptyCassette. ---> Add information on startCassette   */
                            /*   Put it at the head of StartCassette surely!!                          */
                            /*-------------------------------------------------------------------------*/
                            PPT_METHODTRACE_V1("", "Found!! Assign EmptyCassette. ---> Add information on startCassette");

                            strStartCassette[0].loadSequenceNumber = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.strFoundPort.loadSequenceNoInPortGroup;
                            strStartCassette[0].cassetteID         = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.foundEmptyCassetteID;
                            strStartCassette[0].loadPurposeType    = CIMFWStrDup(SP_LoadPurposeType_EmptyCassette);
                            strStartCassette[0].loadPortID         = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.strFoundPort.portID;

                            nSetStartCassetteCnt++;

                            PPT_METHODTRACE_V1("","--------------------------------------------------------------------");
                            PPT_METHODTRACE_V2("","strStartCassette[0].loadSequenceNumber", strStartCassette[0].loadSequenceNumber);
                            PPT_METHODTRACE_V2("","strStartCassette[0].cassetteID        ", strStartCassette[0].cassetteID.identifier);
                            PPT_METHODTRACE_V2("","strStartCassette[0].loadPurposeType   ", strStartCassette[0].loadPurposeType);
                            PPT_METHODTRACE_V2("","strStartCassette[0].loadPortID        ", strStartCassette[0].loadPortID.identifier);
                            PPT_METHODTRACE_V1("","--------------------------------------------------------------------");

    //D4200302 start
                            if ( strStartCassette[0].loadSequenceNumber == tmpStartCassette[0].loadSequenceNumber )
                            {
                                PPT_METHODTRACE_V1("","strStartCassette[0].loadSequenceNumber == tmpStartCassette[0].loadSequenceNumber");
                                PPT_METHODTRACE_V1("","@@@@@ Duplication Setting PortInfo!! @@@@@");

                                CORBA::Long lenPortIDs = portID.length();
                                PPT_METHODTRACE_V2("","lenPortIDs", lenPortIDs);
                                if ( 1 < lenPortIDs )
                                {
                                    // Set next port info.
                                    tmpStartCassette[0].loadSequenceNumber = loadSequenceNumber[1];
                                    tmpStartCassette[0].loadPortID = portID[1];
                                    PPT_METHODTRACE_V2("","tmpStartCassette[0].loadSequenceNumber", tmpStartCassette[0].loadSequenceNumber);
                                    PPT_METHODTRACE_V2("","tmpStartCassette[0].loadPortID        ", tmpStartCassette[0].loadPortID.identifier);
                                }
                            }
    //D4200302 end
                        }

                        bAlreadyCheckMonitorCreationFlag = TRUE;
                        PPT_METHODTRACE_V1("","<<<<< End Block >>>>>");
                    }

    //D4200302 start
                    /*------------------------------------------------------------------------------------------------------*/
                    /*   Selected PortID and CassetteID is stocked.                                                         */
                    /*   Originally this Sequence(useAssignEmptyCassettePortSeq, useEmptyCassetteIDSeq) exists for Empty.   */
                    /*   But, by D4200302, Cassette must assign also to AnyPort.                                            */
                    /*   Here, if it does not set to these Sequences, following problem arises                              */
                    /*                                               by cassetteDelivery_SearchEmptyCassetteAssignPort().   */
                    /*     Equipment is CassetteExchange Type.                                                              */
                    /*                                                                                                      */
                    /*     PortID  PortGrp  Purpose                                                                         */
                    /*     --------------------------                                                                       */
                    /*       P1       A       Any                                                                           */
                    /*       P2       A       Any                                                                           */
                    /*                                                                                                      */
                    /*    First, P1 is assigned with ProcessLot.                                                            */
                    /*    Next, Search EmpPort by cassetteDelivery_SearchEmptyCassetteAssignPort().                         */
                    /*    But Function chooses P1.                                                                          */
                    /*    Because P1 is not set to useEmptyCassetteIDSeq.                                                   */
                    /*                                                                                                      */
                    /*    It is not necessary to put CassetteID into useAssignEmptyCassettePortSeq.                         */
                    /*    But sequence counter(nAssignEmptyCassetteCnt) becomes mismatching.                                */
                    /*    So, CassetteID is set also to useEmptyCassetteIDSeq.                                              */
                    /*------------------------------------------------------------------------------------------------------*/
                    useAssignEmptyCassettePortSeq[ nAssignEmptyCassetteCnt ] = tmpStartCassette[0].loadPortID;
                    useEmptyCassetteIDSeq[ nAssignEmptyCassetteCnt ] = tmpStartCassette[0].cassetteID;
                    nAssignEmptyCassetteCnt++;

                    PPT_METHODTRACE_V1("", "-----------------------------------------------------");
                    PPT_METHODTRACE_V1("", "[D4200302] Selected PortID and CassetteID is stocked.");
                    PPT_METHODTRACE_V1("", "-----------------------------------------------------");
                    PPT_METHODTRACE_V2("", "PortID-------------------------->", tmpStartCassette[0].loadPortID.identifier);
                    PPT_METHODTRACE_V2("", "CassetteID---------------------->", tmpStartCassette[0].cassetteID.identifier);
                    PPT_METHODTRACE_V2("", "nAssignEmptyCassetteCnt--------->", nAssignEmptyCassetteCnt);
    //D4200302 end

                    /*******************************************************************************/
                    /*   Set EmptyCassette if it is necessary                                      */
                    /*******************************************************************************/
                    if ( TRUE == strEquipment_processBatchCondition_Get_out.cassetteExchangeFlag )
                    {
                        PPT_METHODTRACE_V1("", "===== Set EmptyCassette for CassetteExchange ==========");

    //P4000390 start
                        /*------------------------------------------------------*/
                        /*   Look for the first Lot when OpeStartFlag is TRUE   */
                        /*------------------------------------------------------*/
                        PPT_METHODTRACE_V1("","/*------------------------------------------------------*/");
                        PPT_METHODTRACE_V1("","/*   Look for the first Lot when OpeStartFlag is TRUE   */");
                        PPT_METHODTRACE_V1("","/*------------------------------------------------------*/");
                        objectIdentifier targetLotID;
                        CORBA::Long nLotLen = tmpStartCassette[0].strLotInCassette.length();
                        PPT_METHODTRACE_V2("","tmpStartCassette[0].strLotInCassette.length", nLotLen);
                        for ( CORBA::Long i=0; i < nLotLen; i++ )
                        {
                            PPT_METHODTRACE_V3("","tmpStartCassette[0].strLotInCassette[i].lotID", i, tmpStartCassette[0].strLotInCassette[i].lotID.identifier);
                            if ( TRUE == tmpStartCassette[0].strLotInCassette[i].operationStartFlag )
                            {
                                PPT_METHODTRACE_V2("","Found!! Target LotID --->", tmpStartCassette[0].strLotInCassette[i].lotID.identifier);
                                targetLotID = tmpStartCassette[0].strLotInCassette[i].lotID;
                                break;
                            }
                        }
                        if ( 0 == CIMFWStrLen(targetLotID.identifier) )
                        {
                            PPT_METHODTRACE_V1("","targetLotID is null  ...<<<continue>>>");
                            continue; //base loop
                        }
    //P4000390 end
//INN-R170002 Add Start
                        PosProductSpecification_var aProductSpecification;
                        PPT_CONVERT_PRODUCTID_TO_PRODUCTSP_OR( aProductSpecification,
                                                               tmpStartCassette[0].strLotInCassette[i].productID,
                                                               strWhatNextLotList_to_StartCassetteForDeliveryReq_out,
                                                               whatNextLotList_to_StartCassetteForDeliveryReq );

                        CORBA::String_var strReqUsageType;
                        SI_PPT_USERDATA_GET_STRING( aProductSpecification, CS_S_PROD_CarrierUsageType, strReqUsageType );
//INN-R170002 Add End

                        /*------------------------------------------------*/
                        /*   Look for Port to assign, and EmptyCassette   */
                        /*------------------------------------------------*/
                        PPT_METHODTRACE_V1("","/*------------------------------------------------*/");
                        PPT_METHODTRACE_V1("","/*   Look for Port to assign, and EmptyCassette   */");
                        PPT_METHODTRACE_V1("","/*------------------------------------------------*/");
                        objCassetteDelivery_SearchEmptyCassetteAssignPort_out strCassetteDelivery_SearchEmptyCassetteAssignPort_out;
//INN-R170002           rc = cassetteDelivery_SearchEmptyCassetteAssignPort(
                        rc = cs_cassetteDelivery_SearchEmptyCassetteAssignPort( //INN-R170002
                                        strCassetteDelivery_SearchEmptyCassetteAssignPort_out,
                                        strObjCommonIn,
    //P4000390                                    tmpStartCassette[0].strLotInCassette[0].lotID,
                                        targetLotID,                //P4000390
                                        strPortGroup[0].strPortID,
                                        strReqUsageType,    //INN-R170002
                                        strCassetteList_emptyAvailable_Pickup_out.strFoundCassette,
                                        useEmptyCassetteIDSeq,
                                        useAssignEmptyCassettePortSeq );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("","##### NotFound!! Assign EmptyCassette or Assign Port!   set bWhileExitFlag = TRUE  ...<<<continue>>>");
                            bWhileExitFlag = TRUE;
                            continue; //base loop
                        }

                        // Hold EmptyCasstte and Port to prevent duplication
                        PPT_METHODTRACE_V1("", "Hold EmptyCasstte and Port to prevent duplication");
                        useAssignEmptyCassettePortSeq[ nAssignEmptyCassetteCnt ] = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.strFoundPort.portID;
                        useEmptyCassetteIDSeq[ nAssignEmptyCassetteCnt ] = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.foundEmptyCassetteID;
                        nAssignEmptyCassetteCnt++;
                        PPT_METHODTRACE_V2("", "nAssignEmptyCassetteCnt--------->", nAssignEmptyCassetteCnt);

                        /*-------------------------------------------------------------------------*/
                        /*   Found!! Assign EmptyCassette. -----> Add information on TmpCassette   */
                        /*-------------------------------------------------------------------------*/
                        PPT_METHODTRACE_V1("", "Found!! Assign EmptyCassette. -----> Add information on TmpCassette");
                        CORBA::Long lenTmp = tmpStartCassette.length();
                        tmpStartCassette.length(lenTmp + 1);
                        tmpStartCassette[lenTmp].loadSequenceNumber = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.strFoundPort.loadSequenceNoInPortGroup;
                        tmpStartCassette[lenTmp].cassetteID         = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.foundEmptyCassetteID;
                        tmpStartCassette[lenTmp].loadPurposeType    = CIMFWStrDup(SP_LoadPurposeType_EmptyCassette);
                        tmpStartCassette[lenTmp].loadPortID         = strCassetteDelivery_SearchEmptyCassetteAssignPort_out.strFoundPort.portID;

                        PPT_METHODTRACE_V1("","--------------------------------------------------------------------");
                        PPT_METHODTRACE_V3("","tmpStartCassette[lenTmp].loadSequenceNumber", lenTmp, tmpStartCassette[lenTmp].loadSequenceNumber);
                        PPT_METHODTRACE_V3("","tmpStartCassette[lenTmp].cassetteID        ", lenTmp, tmpStartCassette[lenTmp].cassetteID.identifier);
                        PPT_METHODTRACE_V3("","tmpStartCassette[lenTmp].loadPurposeType   ", lenTmp, tmpStartCassette[lenTmp].loadPurposeType);
                        PPT_METHODTRACE_V3("","tmpStartCassette[lenTmp].loadPortID        ", lenTmp, tmpStartCassette[lenTmp].loadPortID.identifier);
                        PPT_METHODTRACE_V1("","--------------------------------------------------------------------");
                    }

                    /*******************************************************************************/
                    /*   Add tmpStartCassette to StartCassette                                     */
                    /*******************************************************************************/
                    PPT_METHODTRACE_V1("","===== Add tmpStartCassette to StartCassette ==========");
                    CORBA::Long lenTmp = tmpStartCassette.length();
                    for ( CORBA::Long j=0; j < lenTmp; j++ )
                    {
                        PPT_METHODTRACE_V2("","Set tmpStartCassette on strStartCassette[n]", nSetStartCassetteCnt);
                        strStartCassette[ nSetStartCassetteCnt ] = tmpStartCassette[j];
                        nSetStartCassetteCnt++;
                    }

                    processRunCount++;
                    PPT_METHODTRACE_V2("","processRunCount++", processRunCount);
                }
                PPT_METHODTRACE_V1("","<<<<< End Block >>>>>   Add tmpStartCassette to StartCassette");
    //D4000184 end
            }

            PPT_METHODTRACE_V1("","                       @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
            PPT_METHODTRACE_V2("","Select Cassette Result @@@@@ ProcessRunCount      @@@@@", processRunCount);
    //D4200302        PPT_METHODTRACE_V2("","                       @@@@@ EmptyCassetteCount   @@@@@", nAssignEmptyCassetteCnt);
            PPT_METHODTRACE_V2("","                       @@@@@ nSetStartCassetteCnt @@@@@", nSetStartCassetteCnt);
            PPT_METHODTRACE_V1("","                       @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

//D7000183 start
            /*-----------------------------------------------------------------------------------------*/
            /*   If selected Carrier does not fulfill MinBatchSize, they are omitted from candidate.   */
            /*-----------------------------------------------------------------------------------------*/
            if ( bCheckMinBatchSize
              && 0 < processRunCount && processRunCount < strEquipment_processBatchCondition_Get_out.minBatchSize )
            {
                PPT_METHODTRACE_V1("", "processRunCount < minBatchSize");
                for ( CORBA::Long m=0; m < nSetStartCassetteCnt; m++ )
                {
                    CORBA::Long lenOmitCst = omitCassetteSeq.length();
                    omitCassetteSeq.length( lenOmitCst + 1 );
                    omitCassetteSeq[ lenOmitCst ] = strStartCassette[m].cassetteID;
                    PPT_METHODTRACE_V2("", "Omit CassetteID", strStartCassette[m].cassetteID.identifier);
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "MinBatchSize support loop");
                break;
            }
        } // MinBatchSize support loop.
//D7000183 end


        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*   Final Check                                                                                              */
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*  Final Check                                                             */");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");

        /*---------------------------*/
        /*   Check processRunCount   */
        /*---------------------------*/
        if ( processRunCount == 0 )
        {
            PPT_METHODTRACE_V1("","processRunCount == 0");
            PPT_METHODTRACE_V1("","##### return RC_NOT_FOUND_FILLEDCAST");
            SET_MSG_RC(strWhatNextLotList_to_StartCassetteForDeliveryReq_out, MSG_NOT_FOUND_FILLEDCAST, RC_NOT_FOUND_FILLEDCAST);
            return RC_NOT_FOUND_FILLEDCAST;
        }

        if ( processRunCount < strEquipment_processBatchCondition_Get_out.minBatchSize )
        {
            PPT_METHODTRACE_V1("","processRunCount < minBatchSize");
            PPT_METHODTRACE_V1("","##### return RC_NOT_FOUND_FILLEDCAST");
            SET_MSG_RC(strWhatNextLotList_to_StartCassetteForDeliveryReq_out, MSG_NOT_FOUND_FILLEDCAST, RC_NOT_FOUND_FILLEDCAST);
            return RC_NOT_FOUND_FILLEDCAST;
        }

//P4100258 start
        /*-------------------------------*/
        /*   Check Mininum Wafer Count   */
        /*-------------------------------*/
        PPT_METHODTRACE_V1("","Check Mininum Wafer Count");
        CORBA::Long nTotalWaferCount = 0;
        for ( i=0; i < nSetStartCassetteCnt; i++ )
        {
            CORBA::Long lenLot = strStartCassette[i].strLotInCassette.length();
            for ( CORBA::Long j=0; j < lenLot; j++ )
            {
                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == TRUE )
                {
                    nTotalWaferCount += strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                    PPT_METHODTRACE_V2( "","Add nTotalWaferCount", nTotalWaferCount);
                }
            }
        }
        PPT_METHODTRACE_V2( "","nTotalWaferCount", nTotalWaferCount);
        if ( strEquipment_processBatchCondition_Get_out.minWaferSize > nTotalWaferCount )
        {
            PPT_METHODTRACE_V1( "","##### return RC_INVALID_INPUT_WAFER_COUNT");
            SET_MSG_RC(strWhatNextLotList_to_StartCassetteForDeliveryReq_out, MSG_INVALID_INPUT_WAFER_COUNT, RC_INVALID_INPUT_WAFER_COUNT);
            return RC_INVALID_INPUT_WAFER_COUNT;
        }
//P4100258 end

//D4100036 start  <<< FlowBatch Control >>>
        if ( 0 < CIMFWStrLen(strFlowBatch_CheckConditionForCassetteDelivery_out.flowBatchID.identifier) )
        {
            PPT_METHODTRACE_V1("","Check!! processRunCount must be the same as FlowBatching Lots Count");
            /*-----------------------------------------------------------------*/
            /*   processRunCount must be the same as FlowBatching Lots Count   */
            /*-----------------------------------------------------------------*/
            CORBA::Long lenFlowBatchLots = strFlowBatch_CheckConditionForCassetteDelivery_out.strContainedLotsInFlowBatch.length();
//P4200182 start
            PPT_METHODTRACE_V2("","lenFlowBatchLots", lenFlowBatchLots);
            objectIdentifierSequence cassetteIDSeq;
            cassetteIDSeq.length( lenFlowBatchLots );
            CORBA::Long nFlowBatchCasIdx = 0;
            for ( i=0; i < lenFlowBatchLots; i++ )
            {
                CORBA::Boolean bFound = FALSE;
                CORBA::Long lenCas = cassetteIDSeq.length();
                for ( CORBA::Long j=0; j < lenCas; j++ )
                {
                    if ( 0 == CIMFWStrCmp(cassetteIDSeq[j].identifier,
                                          strFlowBatch_CheckConditionForCassetteDelivery_out.strContainedLotsInFlowBatch[i].cassetteID.identifier) )
                    {
                        bFound = TRUE;
                        break;
                    }
                }
                if ( TRUE != bFound )
                {
                    cassetteIDSeq[nFlowBatchCasIdx] = strFlowBatch_CheckConditionForCassetteDelivery_out.strContainedLotsInFlowBatch[i].cassetteID;
                    nFlowBatchCasIdx++;
                }
            }
            cassetteIDSeq.length( nFlowBatchCasIdx );
            PPT_METHODTRACE_V2("","nFlowBatchCasIdx", nFlowBatchCasIdx);
//P4200182 end

            if ( processRunCount != nFlowBatchCasIdx )  //P4200182
//P4200182            if ( processRunCount != lenFlowBatchLots )
            {
                // return [All FlowBatchingLotss weren't select.]
                PPT_METHODTRACE_V1("","##### return RC_NOT_SELECT_ALL_FLOWBATCH_LOTS");
                SET_MSG_RC(strWhatNextLotList_to_StartCassetteForDeliveryReq_out, MSG_NOT_SELECT_ALL_FLOWBATCH_LOTS, RC_NOT_SELECT_ALL_FLOWBATCH_LOTS);
                return RC_NOT_SELECT_ALL_FLOWBATCH_LOTS;
            }
        }

        /*-----------------------------------------------------------------------*/
        /*                                                                       */
        /*   Check Process for FlowBatch                                         */
        /*                                                                       */
        /*   The following conditions are checked by this object                 */
        /*                                                                       */
        /*   1. whether in-parm's equipment has reserved flowBatchID or not      */
        /*      fill  -> all of flowBatch member and in-parm's lot must be       */
        /*               same perfectly.                                         */
        /*      blank -> no check                                                */
        /*                                                                       */
        /*   2. whether lot is in flowBatch section or not                       */
        /*      in    -> lot must have flowBatchID, and flowBatch must have      */
        /*               reserved equipmentID.                                   */
        /*               if lot is on target operation, flowBatch's reserved     */
        /*               equipmentID and in-parm's equipmentID must be same.     */
        /*      out   -> no check                                                */
        /*                                                                       */
        /*-----------------------------------------------------------------------*/
//D9000079        PPT_METHODTRACE_V1("","===== equipment_lot_CheckFlowBatchConditionForOpeStart() ==========");
//D9000079        objEquipment_lot_CheckFlowBatchConditionForOpeStart_out strEquipment_lot_CheckFlowBatchConditionForOpeStart_out;
//D9000079        rc = equipment_lot_CheckFlowBatchConditionForOpeStart( strEquipment_lot_CheckFlowBatchConditionForOpeStart_out,
//D9000079                                                               strObjCommonIn,
//D9000079                                                               equipmentID,
//D9000079                                                               portGroupID,
//D9000079                                                               strStartCassette );
//D9000079 add starts
        PPT_METHODTRACE_V1("","===== equipment_lot_CheckFlowBatchConditionForOpeStart__090() ==========");
        objEquipment_lot_CheckFlowBatchConditionForOpeStart_out__090 strEquipment_lot_CheckFlowBatchConditionForOpeStart_out;
        objEquipment_lot_CheckFlowBatchConditionForOpeStart_in__090  strEquipment_lot_CheckFlowBatchConditionForOpeStart_in;
        strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.equipmentID      = equipmentID;
        strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.portGroupID      = portGroupID;
        strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.strStartCassette = strStartCassette;
        rc  = equipment_lot_CheckFlowBatchConditionForOpeStart__090( strEquipment_lot_CheckFlowBatchConditionForOpeStart_out,
                                                                     strObjCommonIn,
                                                                     strEquipment_lot_CheckFlowBatchConditionForOpeStart_in );
//D9000079 add end
        if ( rc != RC_OK )
        {
//D9000079            PPT_METHODTRACE_V2("", "##### RC_OK != equipment_lot_CheckFlowBatchConditionForOpeStart()", rc);
            PPT_METHODTRACE_V2("", "##### RC_OK != equipment_lot_CheckFlowBatchConditionForOpeStart__090()", rc);           //D9000079
            strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strResult = strEquipment_lot_CheckFlowBatchConditionForOpeStart_out.strResult;
            return rc;
        }
//D4100036 end  <<< FlowBatch Control >>>

//D8000024 add start
//D9000001        CORBA::Long  tmpFPCAdoptFlag = atol( getenv(SP_FPC_Adaptation_Flag) );
        CORBA::Long  tmpFPCAdoptFlag = atoi( getenv(SP_FPC_Adaptation_Flag) );    //D9000001
        if( 1 == tmpFPCAdoptFlag )
        {
            PPT_METHODTRACE_V1("","FPC Adopt Flag is ON. Now apply FPCInfo.");
            objFPCStartCassetteInfo_Exchange_out  strFPCStartCassetteInfo_Exchange_out;
            rc = FPCStartCassetteInfo_Exchange( strFPCStartCassetteInfo_Exchange_out,
                                                strObjCommonIn,
                                                SP_FPC_ExchangeType_StartReserveInfo,
                                                equipmentID,
                                                strStartCassette );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("","FPCStartCassetteInfo_Exchange() != RC_OK", rc);
                strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strResult = strFPCStartCassetteInfo_Exchange_out.strResult;
                return rc;
            }

            strStartCassette = strFPCStartCassetteInfo_Exchange_out.strStartCassette;
        }
        else
        {
            PPT_METHODTRACE_V1("","FPC Adopt Flag is OFF.");
        }
//D8000024 add end

        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*   Set Return Struct                                                                                        */
        /*                                                                                                            */
        /*                                                                                                            */
        /*                                                                                                            */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*  Set Return Struct                                                       */");
        PPT_METHODTRACE_V1("", "/*                                                                          */");
        PPT_METHODTRACE_V1("", "/*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/");

        strStartCassette.length( nSetStartCassetteCnt );
        strWhatNextLotList_to_StartCassetteForDeliveryReq_out.strStartCassette = strStartCassette;

        PPT_METHODTRACE_V1("","@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        PPT_METHODTRACE_V1("","@@@@@ Normal End.");
        PPT_METHODTRACE_V1("","@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");




PPT_METHODTRACE_V1("","******************** DEBUG TRACE StartCassette start ********************");
CORBA::Long lenSC = strStartCassette.length();
for (i=0; i<lenSC; i++)
{
    PPT_METHODTRACE_V2("", "------------------------------------------round[i]", i);
    PPT_METHODTRACE_V2("", "[cassetteID        ]" , strStartCassette[i].cassetteID.identifier );
    PPT_METHODTRACE_V2("", "[loadSequenceNumber]" , strStartCassette[i].loadSequenceNumber );
    PPT_METHODTRACE_V2("", "[loadPurposeType   ]" , strStartCassette[i].loadPurposeType );
    PPT_METHODTRACE_V2("", "[loadPortID        ]" , strStartCassette[i].loadPortID.identifier );

    CORBA::Long nLotInCassetteLen = strStartCassette[i].strLotInCassette.length();
    for (CORBA::Long j=0; j<nLotInCassetteLen; j++)
    {
        PPT_METHODTRACE_V2("", "  [lotID              ]" , strStartCassette[i].strLotInCassette[j].lotID.identifier );
        PPT_METHODTRACE_V2("", "  [lotType            ]" , strStartCassette[i].strLotInCassette[j].lotType);
        PPT_METHODTRACE_V2("", "  [subLotType         ]" , strStartCassette[i].strLotInCassette[j].subLotType );
//D9000001        PPT_METHODTRACE_V2("", "  [operationStartFlag ]" , (long)strStartCassette[i].strLotInCassette[j].operationStartFlag );
        PPT_METHODTRACE_V2("", "  [operationStartFlag ]" , (int)strStartCassette[i].strLotInCassette[j].operationStartFlag ); //D9000001
//D9000001        PPT_METHODTRACE_V2("", "  [monitorLotFlag     ]" , (long)strStartCassette[i].strLotInCassette[j].monitorLotFlag );
        PPT_METHODTRACE_V2("", "  [monitorLotFlag     ]" , (int)strStartCassette[i].strLotInCassette[j].monitorLotFlag ); //D9000001
    }
}
PPT_METHODTRACE_V1("","******************** DEBUG TRACE StartCassette end ********************");

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::whatNextLotList_to_StartCassetteForDeliveryReq");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strWhatNextLotList_to_StartCassetteForDeliveryReq_out, whatNextLotList_to_StartCassetteForDeliveryReq, methodName);
}

