//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cs_durable_currentState_ChangeOR.cpp
//

#include "cs_pptmgr.hpp"
#include "pcas.hh"
#include "prtclp.hh"
#include "ppcdr.hh"
#include "pperson.hh"

// Class: CS_PPTManager
//
// Service: cs_durable_currentState_ChangeOR()
//
// Change history:
// Date       Defect#   Person         Comments
// ---------- --------- -------------- -------------------------------------------
// 2016/07/25 DSN000101569 C.Mo           Durable Sub Status Control Support.
//
//
// Innotron Modification history:
// Date       Defect#         Person             Comments
// ---------- --------------- ------------------ -------------------------------------------
// 2017/08/29 INN-R170003     Gary Ke            Durable Sub Status Control Modify.
// 2017/11/02 INN-R170003-01  Nick Tsai          Support fixture durable sub state.
//
//[Function Description]:
//  This function change Durable Sub Status.
//
//[Input Parameters]:
//  const pptObjCommonIn&                    strObjCommonIn,
//  const objDurable_currentState_Change_in& strDurable_currentState_Change_in
//
//  typedef struct objDurable_currentState_Change_in_struct {
//      string                              durableCategory;                        //<i>Durable Category
//      objectIdentifier                    durableID;                              //<i>Durable ID
//      string                              durableStatus;                          //<i>Durable Status
//      objectIdentifier                    durableSubStatus;                       //<i>Durable Sub Status
//      any                                 siInfo;                                 //<i>Reserved for SI customization
//  } objDurable_currentState_Change_in;
//
//[Output Parameters]:
//  objDurable_currentState_Change_out&      strDurable_currentState_Change_out
//
//  typedef objBase_out objDurable_currentState_Change_out;
//
//[Return Value]:
//  Return Code                                   Messsage ID
//  -------------------------                     --------------------------------------------------
//  RC_OK                                         MSG_OK
//
//durable_currentState_Change
CORBA::Long CS_PPTManager_i::durable_currentState_Change(
    objDurable_currentState_Change_out&         strDurable_currentState_Change_out,
    const pptObjCommonIn&                       strObjCommonIn,
    const objDurable_currentState_Change_in&    strDurable_currentState_Change_in)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::durable_currentState_Change");
        CORBA::Long rc = RC_OK;

        if (CIMFWStrLen(strDurable_currentState_Change_in.durableSubStatus.identifier) == 0)
        {
            PPT_METHODTRACE_V1("", "param's durableSubStatus is blank");

            //--------------------------------------
            //   Change durable stauts
            //--------------------------------------
            if (CIMFWStrCmp(strDurable_currentState_Change_in.durableCategory, SP_DurableCat_Cassette) == 0)
            {
                PPT_METHODTRACE_V1("", "durableCategory is SP_DurableCat_Cassette");
                objCassette_state_Change_out strCassette_state_Change_out;
                rc = cassette_state_Change(strCassette_state_Change_out,
                                           strObjCommonIn,
                                           strDurable_currentState_Change_in.durableID,
                                           strDurable_currentState_Change_in.durableStatus);
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "cassette_state_Change() != RC_OK")
                    strDurable_currentState_Change_out.strResult = strCassette_state_Change_out.strResult;
                    return rc;
                }
            }
            else if (CIMFWStrCmp(strDurable_currentState_Change_in.durableCategory, SP_DurableCat_Reticle) == 0)
            {
                PPT_METHODTRACE_V1("", "durableCategory is SP_DurableCat_Reticle");
                objReticle_state_Change_out strReticle_state_Change_out;
                rc = reticle_state_Change(strReticle_state_Change_out,
                                          strObjCommonIn,
                                          strDurable_currentState_Change_in.durableID,
                                          strDurable_currentState_Change_in.durableStatus);
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "reticle_state_Change() != RC_OK")
                    strDurable_currentState_Change_out.strResult = strReticle_state_Change_out.strResult;
                    return rc;
                }
            }
            else if (CIMFWStrCmp(strDurable_currentState_Change_in.durableCategory, SP_DurableCat_ReticlePod) == 0)
            {
                PPT_METHODTRACE_V1("", "durableCategory is SP_DurableCat_ReticlePod");
                objReticlePod_status_Change_out strReticlePod_status_Change_out;
                rc = reticlePod_status_Change(strReticlePod_status_Change_out,
                                              strObjCommonIn,
                                              strDurable_currentState_Change_in.durableStatus,
                                              strDurable_currentState_Change_in.durableID);
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "reticlePod_status_Change() != RC_OK")
                    strDurable_currentState_Change_out.strResult = strReticlePod_status_Change_out.strResult;
                    return rc;
                }
            }
            //INN-R170003-01 add start
            else if (CIMFWStrCmp(strDurable_currentState_Change_in.durableCategory, SP_DurableCat_Fixture) == 0)
            {
                PPT_METHODTRACE_V1("", "durableCategory is SP_DurableCat_Fixture");
                objFixture_state_Change_out strFixture_state_Change_out;
                rc = fixture_state_Change ( strFixture_state_Change_out,
                                            strObjCommonIn,
                                            strDurable_currentState_Change_in.durableID,
                                            strDurable_currentState_Change_in.durableStatus);
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "fixture_state_Change() != RC_OK")
                    strDurable_currentState_Change_out.strResult = strFixture_state_Change_out.strResult;
                    return rc;
                }
            }
            //INN-R170003-01 add end
        }
        //--------------------------------------
        //   Change durable sub stauts
        //--------------------------------------
        else
        {
            PPT_METHODTRACE_V2("", "param's durableSubStatus ", strDurable_currentState_Change_in.durableSubStatus.identifier);

            PosDurableSubState_var aDurableSubState;
            PPT_CONVERT_DURABLESUBSTATECODE_TO_DURABLESUBSTATE_OR(aDurableSubState,
                                                                  strDurable_currentState_Change_in.durableSubStatus,
                                                                  strDurable_currentState_Change_out,
                                                                  durable_currentState_Change);

            PosPerson_var aPerson;
            PPT_GET_PERSON_FROM_USERID(aPerson,
                                       strObjCommonIn.strUser.userID,
                                       strDurable_currentState_Change_out,
                                       durable_currentState_Change);

            /*----------------------------------*/
            /*  Get Current Durable Sub-Status  */
            /*----------------------------------*/
            objDurable_subState_Get_out strDurable_subState_Get_out;
            objDurable_subState_Get_in  strDurable_subState_Get_in;
            strDurable_subState_Get_in.durableCategory = strDurable_currentState_Change_in.durableCategory;
            strDurable_subState_Get_in.durableID       = strDurable_currentState_Change_in.durableID;
            rc = durable_subState_Get(strDurable_subState_Get_out, strObjCommonIn, strDurable_subState_Get_in);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "durable_subState_Get() != RC_OK");
                strDurable_currentState_Change_out.strResult = strDurable_subState_Get_out.strResult;
                return  rc;
            }

            char currentDrblState[1024];
            memset(currentDrblState, 0, sizeof(currentDrblState));
            CIMFWStrCpy(currentDrblState, strDurable_subState_Get_out.durableStatus);
            if (CIMFWStrLen(strDurable_subState_Get_out.durableSubStatus.identifier) > 0)
            {
                CIMFWStrCat(currentDrblState, ".");
                CIMFWStrCat(currentDrblState, strDurable_subState_Get_out.durableSubStatus.identifier);
            }

            char drblState[1024];
            memset(drblState, 0, sizeof(drblState));
            CIMFWStrCpy(drblState, strDurable_currentState_Change_in.durableStatus);
            CIMFWStrCat(drblState, ".");
            CIMFWStrCat(drblState, strDurable_currentState_Change_in.durableSubStatus.identifier);

            if (CIMFWStrCmp(strDurable_currentState_Change_in.durableCategory, SP_DurableCat_Cassette) == 0)
            {
                PPT_METHODTRACE_V1("", "durableCategory is SP_DurableCat_Cassette");
                PosCassette_var aCassette;
                PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                                       strDurable_currentState_Change_in.durableID,
                                                       strDurable_currentState_Change_out,
                                                       durable_currentState_Change );
                //INN-R170003 Add Start
                CORBA::String_var varDurableState;
                try
                {
                    varDurableState=aCassette->getDurableState();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getDurableState)

                if( CIMFWStrCmp(strDurable_currentState_Change_in.durableStatus, CIMFW_Durable_NotAvailable)==0 &&
                    CIMFWStrCmp(varDurableState, CIMFW_Durable_InUse)==0 )
                {
                    PPT_METHODTRACE_V1("","durableStatus is NOTAVAILABLE && varDurableState is INUSE");
                    try
                    {
                        aCassette->makeAvailable();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::makeAvailable)
                }
                //INN-R170003 Add End
                /*--------------------------*/
                /*  Set Durable Sub-Status  */
                /*--------------------------*/
                try
                {
                    aCassette->setDurableSubState(aDurableSubState);
                }
                catch(InvalidStateTransitionSignal)
                {
                    PPT_METHODTRACE_V1("", "InvalidStateTransitionSignal exception");
                    PPT_SET_MSG_RC_KEY2(strDurable_currentState_Change_out,
                                        MSG_INVALID_STATE_TRANS, RC_INVALID_STATE_TRANS,
                                        CIMFWStrDup(currentDrblState), CIMFWStrDup(drblState));
                    return RC_INVALID_STATE_TRANS;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setDurableSubState)

                /*--------------------------*/
                /*  Set Claimed Time Stamp  */
                /*--------------------------*/
                try
                {
                    aCassette->setLastClaimedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setLastClaimedTimeStamp)

                /*--------------------------*/
                /*  Set Claimed Person      */
                /*--------------------------*/
                try
                {
                    aCassette->setLastClaimedPerson(aPerson);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setLastClaimedPerson)

                /*--------------------------*/
                /*  Set Changed Time Stamp  */
                /*--------------------------*/
                try
                {
                    aCassette->setStateChangedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setStateChangedTimeStamp)

                try
                {
                    aCassette->setStateChangedPerson(aPerson);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setStateChangedPerson)
            }
            else if (CIMFWStrCmp(strDurable_currentState_Change_in.durableCategory, SP_DurableCat_ReticlePod) == 0)
            {
                PPT_METHODTRACE_V1("", "durableCategory is SP_DurableCat_Reticle");
                PosReticlePod_var aReticlePod;
                PPT_CONVERT_RETICLEPODID_TO_RETICLEPOD_OR( aReticlePod,
                                                           strDurable_currentState_Change_in.durableID,
                                                           strDurable_currentState_Change_out,
                                                           durable_currentState_Change );
                //INN-R170003 Add Start
                PosDurableSubState_var aCurrentDurableSubState;
                try
                {
                    aCurrentDurableSubState=aReticlePod->getDurableSubState();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::getDurableSubState)

                if ( CORBA::is_nil(aCurrentDurableSubState) == FALSE )
                {
                    CORBA::String_var varDurableStateforReticlePod;
                    try
                    {
                        varDurableStateforReticlePod=aCurrentDurableSubState->getDurableState();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::getDurableState)

                    if( CIMFWStrCmp(strDurable_currentState_Change_in.durableStatus, CIMFW_Durable_NotAvailable)==0 &&
                        CIMFWStrCmp(varDurableStateforReticlePod, CIMFW_Durable_InUse)==0 )
                    {
                        PPT_METHODTRACE_V1("","durableStatus is NOTAVAILABLE && varDurableStateforReticlePod is INUSE");
                        try
                        {
                            aReticlePod->makeAvailable();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::makeAvailable)
                    }
                }
                //INN-R170003 Add End
                /*--------------------------*/
                /*  Set Durable Sub-Status  */
                /*--------------------------*/
                try
                {
                    aReticlePod->setDurableSubState(aDurableSubState);
                }
                catch(InvalidStateTransitionSignal)
                {
                    PPT_METHODTRACE_V1("", "InvalidStateTransitionSignal exception");
                    PPT_SET_MSG_RC_KEY2(strDurable_currentState_Change_out,
                                        MSG_INVALID_STATE_TRANS, RC_INVALID_STATE_TRANS,
                                        CIMFWStrDup(currentDrblState), CIMFWStrDup(drblState));
                    return RC_INVALID_STATE_TRANS;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::setDurableSubState)

                /*--------------------------*/
                /*  Set Claimed Time Stamp  */
                /*--------------------------*/
                try
                {
                    aReticlePod->setLastClaimedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::setLastClaimedTimeStamp)

                /*--------------------------*/
                /*  Set Claimed Person      */
                /*--------------------------*/
                try
                {
                    aReticlePod->setLastClaimedPerson(aPerson);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::setLastClaimedPerson)

                /*--------------------------*/
                /*  Set Changed Time Stamp  */
                /*--------------------------*/
                try
                {
                    aReticlePod->setStateChangedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::setStateChangedTimeStamp)

                try
                {
                    aReticlePod->setStateChangedPerson(aPerson);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosReticlePod::setStateChangedPerson)
            }
            else if (CIMFWStrCmp(strDurable_currentState_Change_in.durableCategory, SP_DurableCat_Reticle) == 0)
            {
                PPT_METHODTRACE_V1("", "durableCategory is SP_DurableCat_ReticlePod");
                PosProcessDurable_var aReticle;
                PPT_CONVERT_RETICLEID_TO_RETICLE_OR( aReticle,
                                                     strDurable_currentState_Change_in.durableID,
                                                     strDurable_currentState_Change_out,
                                                     durable_currentState_Change);
                /*--------------------------*/
                /*  Set Durable Sub-Status  */
                /*--------------------------*/
                try
                {
                    aReticle->setDurableSubState(aDurableSubState);
                }
                catch(InvalidStateTransitionSignal)
                {
                    PPT_METHODTRACE_V1("", "InvalidStateTransitionSignal exception");
                    PPT_SET_MSG_RC_KEY2(strDurable_currentState_Change_out,
                                        MSG_INVALID_STATE_TRANS, RC_INVALID_STATE_TRANS,
                                        CIMFWStrDup(currentDrblState), CIMFWStrDup(drblState));
                    return RC_INVALID_STATE_TRANS;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setDurableSubState)

                /*--------------------------*/
                /*  Set Claimed Time Stamp  */
                /*--------------------------*/
                try
                {
                    aReticle->setLastClaimedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setLastClaimedTimeStamp)

                /*--------------------------*/
                /*  Set Claimed Person      */
                /*--------------------------*/
                try
                {
                    aReticle->setLastClaimedPerson(aPerson);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setLastClaimedPerson)

                /*--------------------------*/
                /*  Set Changed Time Stamp  */
                /*--------------------------*/
                try
                {
                    aReticle->setStateChangedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setStateChangedTimeStamp)

                try
                {
                    aReticle->setStateChangedPerson(aPerson);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setStateChangedPerson)
            }
            //INN-R170003-01 add start
            else if (CIMFWStrCmp(strDurable_currentState_Change_in.durableCategory, SP_DurableCat_Fixture) == 0)
            {
                PPT_METHODTRACE_V1("", "durableCategory is SP_DurableCat_Fixture");
                PosProcessDurable_var aFixture;
                PPT_CONVERT_FIXTUREID_TO_FIXTURE_OR( aFixture,
                                                     strDurable_currentState_Change_in.durableID,
                                                     strDurable_currentState_Change_out,
                                                     durable_currentState_Change);
                /*--------------------------*/
                /*  Set Durable Sub-Status  */
                /*--------------------------*/
                try
                {
                    aFixture->setDurableSubState(aDurableSubState);
                }
                catch(InvalidStateTransitionSignal)
                {
                    PPT_METHODTRACE_V1("", "InvalidStateTransitionSignal exception");
                    PPT_SET_MSG_RC_KEY2(strDurable_currentState_Change_out,
                                        MSG_INVALID_STATE_TRANS, RC_INVALID_STATE_TRANS,
                                        CIMFWStrDup(currentDrblState), CIMFWStrDup(drblState));
                    return RC_INVALID_STATE_TRANS;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setDurableSubState)

                /*--------------------------*/
                /*  Set Claimed Time Stamp  */
                /*--------------------------*/
                try
                {
                    aFixture->setLastClaimedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setLastClaimedTimeStamp)

                /*--------------------------*/
                /*  Set Claimed Person      */
                /*--------------------------*/
                try
                {
                    aFixture->setLastClaimedPerson(aPerson);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setLastClaimedPerson)

                /*--------------------------*/
                /*  Set Changed Time Stamp  */
                /*--------------------------*/
                try
                {
                    aFixture->setStateChangedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setStateChangedTimeStamp)

                try
                {
                    aFixture->setStateChangedPerson(aPerson);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setStateChangedPerson)
            }
            //INN-R170003-01 add end
        }
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::durable_currentState_Change");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strDurable_currentState_Change_out, durable_currentState_Change, methodName)
}
