#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cs_lot_requiredCassetteCategory_GetForNextOperationOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 20:12:33 [ 7/13/07 20:12:34 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_lot_requiredCassetteCategory_GetForNextOperationOR.cpp
//
#include "cs_pptmgr.hpp"
#include "plot.hh"
#include "ppcflwx.hh"
#include "ppcflw.hh"
#include "ppcopsp.hh"
// Class: CS_PPTManager
//
// Service: lot_requiredCassetteCategory_GetForNextOperation()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2001/08/17 D4000016 M.Shimizu      The first coding (R40)
// 2002/01/16 D4100020 K.Kido         Change for EfficientModuleProcessRelease(Rel4.1).
// 2002/06/14 P4100568 F.Masada       Add nil check. 
// 2003/07/31 P5000112 K.Kido         Change invalid nil check.
// 2003/09/09 P5000145 H.Adachi       Fix Message and Message Macro mismatch.
// 2003/12/16 P5100055 K.Kido         Get next POS
// 2004/12/08 D6000025 K.Murakami     Change CORBA::String_var to 'char *' to call method


// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------  -------------- -------------------------------------------
// 2017-09-08 INN-R170002   JQ.Shao        Change required 'Carrier Category' from 'no check' to blank


//
// Description:
//     RequiredCassetteCategory of the process is acquired one after another. 
//
// Return:
//     Long
//
// [Input Parameters]:
//   in  pptObjCommonIn    strObjCommonIn;
//   in  objectIdentifier  lotID;
//
// [Output Parameters]:
//   out objLot_requiredCassetteCategory_GetForNextOperation_out   strLot_requiredCassetteCategory_GetForNextOperation_out;
//
//   typedef struct objLot_requiredCassetteCategory_GetForNextOperation_out_struct {
//       pptRetCode                     strResult;
//       string                         nextRequiredCassetteCategory,
//       any                            siInfo;
//   } objLot_requiredCassetteCategory_GetForNextOperation_out;
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
// [Return Value]:
//
//   Return Code               Messsage ID
//   ------------------------- --------------------------------------------------
//   RC_OK                     MSG_OK
//   RC_INVALID_CATEGORY       MSG_INVALID_CATEGORY
//
CORBA::Long CS_PPTManager_i::lot_requiredCassetteCategory_GetForNextOperation(
                                objLot_requiredCassetteCategory_GetForNextOperation_out& strLot_requiredCassetteCategory_GetForNextOperation_out,
                                const pptObjCommonIn& strObjCommonIn,
                                const objectIdentifier& lotID)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::lot_requiredCassetteCategory_GetForNextOperation")

        CORBA::Long rc = RC_OK;

        //------------------------------------------------
        // Get PosLot Object
        //------------------------------------------------
        PosLot_var aLot;
        PPT_CONVERT_LOTID_TO_LOT_OR(aLot, lotID,
                                    strLot_requiredCassetteCategory_GetForNextOperation_out,
                                    lot_requiredCassetteCategory_GetForNextOperation);

        /*------------------------------------------------*/
        /*   Get Next Operation requiredCassetteCategory  */
        /*------------------------------------------------*/
        PosProcessFlowContext_var aProcessFlowContext ;
        try
        {
            aProcessFlowContext = aLot->getProcessFlowContext() ;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessFlowContext)

        if(CORBA::is_nil(aProcessFlowContext))
        {
            PPT_SET_MSG_RC_KEY( strLot_requiredCassetteCategory_GetForNextOperation_out,
                                MSG_NOT_FOUND_PFX,
                                RC_NOT_FOUND_PFX, "" );
            return RC_NOT_FOUND_PFX ;
        }

//D4100020        PosProcessFlow_ptr aProcessFlow ;
//D4100020        PosProcessOperationSpecification_var aNextProcessOpSpec ;
//D4100020        try
//D4100020        {
//D4100020            aNextProcessOpSpec = aProcessFlowContext->getNextProcessOperationSpecification( aProcessFlow ) ;
//D4100020        }
//D4100020        CATCH_AND_RAISE_EXCEPTIONS(ProcessFlowContext::getNextProcessOperationSpecification)
//D4100020 start
        PosProcessOperationSpecification_var aNextProcessOpSpec, aNextModulePOS ;
        PosProcessFlow_var outMainPF, outModulePF ;
        //D6000025CORBA::String_var outModuleNo ;
        char *outModuleNo = NULL;            //D6000025
        CORBA::String_var var_outModuleNo;   //D6000025

        try
        {
            aNextModulePOS = aProcessFlowContext->getNextProcessOperationSpecification( outMainPF, outModuleNo, outModulePF ) ;
        }
        CATCH_AND_RAISE_EXCEPTIONS(ProcessFlowContext::getNextProcessOperationSpecification)

        var_outModuleNo = outModuleNo;   //D6000025

        //P4100568 start 
        if(CORBA::is_nil(aNextModulePOS))
        {
//P5000145            PPT_SET_MSG_RC_KEY( strLot_requiredCassetteCategory_GetForNextOperation_out,
//P5000145                                MSG_NOT_FOUND_POS,
//P5000145                                RC_NOT_FOUND_POS, "" );
            PPT_SET_MSG_RC_KEY2( strLot_requiredCassetteCategory_GetForNextOperation_out,    //P5000145
                                 MSG_NOT_FOUND_POS,                                          //P5000145
                                 RC_NOT_FOUND_POS, "*****", lotID.identifier );              //P5000145

            return RC_NOT_FOUND_POS ;
        }
        //P4100568 end 

        CORBA::String_var aModuleOpeNo, opeNo ;
        try
        {
            aModuleOpeNo = aNextModulePOS->getOperationNumber() ;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperationSpecification::getOperationNumber)
   
        PPT_CONVERT_MODULEOPENO_TO_OPENO( opeNo, outModuleNo, aModuleOpeNo ) ;

//P5100055        ProcessFlow_var aPF ;
//P5100055        PosProcessFlow_var aPPF ;
//P5100055
//P5100055        try
//P5100055        {
//P5100055            aPF = aLot->getProcessFlow() ;
//P5100055        }
//P5100055        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessFlow)
//P5100055
//P5100055        //P4100568 start 
//P5100055        if(CORBA::is_nil(aPF))
//P5100055        {
//P5100055            PPT_SET_MSG_RC_KEY( strLot_requiredCassetteCategory_GetForNextOperation_out,
//P5100055                                MSG_NOT_FOUND_PF,
//P5100055                                RC_NOT_FOUND_PF, "" );
//P5100055            return RC_NOT_FOUND_PF ;
//P5100055        }
//P5100055        //P4100568 end 
//P5100055
//P5100055        aPPF = PosProcessFlow::_narrow( aPF ) ;
//P5100055
//P5100055        aNextProcessOpSpec = aPPF->findProcessOperationSpecificationOnDefault( opeNo ) ;
//P5100055 add start
        if(CORBA::is_nil(outMainPF))
        {
            PPT_SET_MSG_RC_KEY( strLot_requiredCassetteCategory_GetForNextOperation_out,
                                MSG_NOT_FOUND_PF,
                                RC_NOT_FOUND_PF, "" );
            return RC_NOT_FOUND_PF ;
        }

        ProcessDefinition_var aPD;
        PosProcessDefinition_var aPosProcessDefinition;

        try
        {
            aPD = outMainPF->getRootProcessDefinition();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlow::getRootProcessDefinition)

        aPosProcessDefinition = PosProcessDefinition::_narrow(aPD);
        if(CORBA::is_nil(aPosProcessDefinition))
        {
            PPT_SET_MSG_RC_KEY( strLot_requiredCassetteCategory_GetForNextOperation_out,
                                MSG_NOT_FOUND_PD,
                                RC_NOT_FOUND_PD, "" );
            return RC_NOT_FOUND_PD ;
        }

        PosProcessFlow_var aPosProcessFlow;
        try
        {
            aPosProcessFlow = aPosProcessDefinition->getActiveProcessFlow();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDefinition::getActiveProcessFlow)

        if(CORBA::is_nil(aPosProcessFlow))
        {
            PPT_SET_MSG_RC_KEY( strLot_requiredCassetteCategory_GetForNextOperation_out,
                                MSG_NOT_FOUND_PF,
                                RC_NOT_FOUND_PF, "" );
            return RC_NOT_FOUND_PF ;
        }

        try
        {
            aNextProcessOpSpec = aPosProcessFlow->findProcessOperationSpecificationOnDefault( opeNo );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlow::findProcessOperationSpecificationOnDefault)
//P5100055 add end

//P5000112        //P4100568 start 
//P5000112        if(CORBA::is_nil(aNextProcessOpSpec))
//P5000112        {
//P5000112            PPT_SET_MSG_RC_KEY( strLot_requiredCassetteCategory_GetForNextOperation_out,
//P5000112                                MSG_NOT_FOUND_POS,
//P5000112                                RC_NOT_FOUND_POS, "" );
//P5000112            return RC_NOT_FOUND_POS ;
//P5000112        }
//P5000112        //P4100568 end 
//D4100020 end
        /*-----------------------------------------------*/
        /*   Set Next Operation requiredCassetteCategory */
        /*-----------------------------------------------*/
        if(!CORBA::is_nil(aNextProcessOpSpec))    //P5000112
        {                                         //P5000112
            try
            {
                strLot_requiredCassetteCategory_GetForNextOperation_out.nextRequiredCassetteCategory = aNextProcessOpSpec->getRequiredCassetteCategory();
//INN-R170002 Add Start
                if( 0 == CIMFWStrCmp(strLot_requiredCassetteCategory_GetForNextOperation_out.nextRequiredCassetteCategory, CS_CarrierCategory_NoCheck) )
                {
                    PPT_METHODTRACE_V1("", "nextRequiredCassetteCategory=NoCheck");
                    strLot_requiredCassetteCategory_GetForNextOperation_out.nextRequiredCassetteCategory = CIMFWStrDup("");
                }
                PPT_METHODTRACE_V2("", "nextRequiredCassetteCategory", strLot_requiredCassetteCategory_GetForNextOperation_out.nextRequiredCassetteCategory);
//R170002 Add End
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getCassetteCategory);
        }                                         //P5000112

        return rc;
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_requiredCassetteCategory_GetForNextOperation_out, lot_requiredCassetteCategory_GetForNextOperation, methodName)

}
