// (c) Copyright: IBM  Company Ltd, 2017, 2027. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017, 2027. All rights reserved.
//
// SiView
// Name: cs_txUserCertifiedEqpTypeSkillInq.cpp
//
// Modeficaiton History:
// Date       Defect           Name             Description
// ---------- -------- ---------------- ----------------------------------------------
// 2017/09/04 INN-R170008      Menghua Yin      TA Certify EqpTypeSkill Inq

// Class: PPTServiceManager
//
// Service: cs_txUserCertifiedEqpTypeSkillInq()

// Description:
//<Method Summary>

//</Method Summary>

// Return:
//     long
//
// Parameter:
//
//     csUserCertifiedEqpTypeSkillInqResult&          strUserCertifiedEqpTypeSkillInqResult
//     const pptObjCommonIn&                          strObjCommonIn
//     const csUserCertifiedEqpTypeSkillInqInParm&    strUserCertifiedEqpTypeSkillInqInParm

//<Method Start>
#include "cs_pptmgr.hpp"

CORBA::Long CS_PPTManager_i::cs_txUserCertifiedEqpTypeSkillInq (
    csUserCertifiedEqpTypeSkillInqResult&          strUserCertifiedEqpTypeSkillInqResult,
    const pptObjCommonIn&                          strObjCommonIn,
    const csUserCertifiedEqpTypeSkillInqInParm&    strUserCertifiedEqpTypeSkillInqInParm CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("PPTManager_i::cs_txUserCertifiedEqpTypeSkillInq");
    CORBA::Long rc = RC_OK;

    //----------------------------------------------------------------
    //
    //  Pre Process
    //
    //----------------------------------------------------------------
    // get user's udata
    pptUserDataInqResult strUserDataInqResult;
    pptUserDataInqInParm__101 strUserDataInqInParm;

    strUserDataInqInParm.className = CIMFWStrDup(SP_ClassName_PosPerson);
    strUserDataInqInParm.userDataName = CIMFWStrDup(CS_S_USER_CERTIFICATION_REQURIED);

    strUserDataInqInParm.strHashedInfoSeq.length(1);
    strUserDataInqInParm.strHashedInfoSeq[0].hashKey = CIMFWStrDup(SP_HashData_USER_ID);
    strUserDataInqInParm.strHashedInfoSeq[0].hashData = strObjCommonIn.strUser.userID.identifier;
    strUserDataInqInParm.userDataOriginator = CIMFWStrDup(SP_USERDATA_ORIG_SM);
    PPT_METHODTRACE_V2("", "strUserDataInqInParm.hashKey  is ", strUserDataInqInParm.strHashedInfoSeq[0].hashKey);    
    
    rc = txUserDataInq__101(strUserDataInqResult, strObjCommonIn, strUserDataInqInParm, NULL);
    if (rc != RC_OK && rc != RC_NOT_FOUND_UDATA)
    {
        PPT_METHODTRACE_V2("", "txUserDataInq__101() rc != RC_OK", rc);
        strUserCertifiedEqpTypeSkillInqResult.strResult = strUserDataInqResult.strResult;
        return(rc);
    }

    if (strUserDataInqResult.strUserDataSeq.length() == 0)
    {
        PPT_METHODTRACE_V2("", "strUserDataInqResult.strUserDataSeq.length() == 0", rc);
        strUserCertifiedEqpTypeSkillInqResult.strResult = strUserDataInqResult.strResult;
        return rc;
    }
    
    // get user's certifiedskill
    csObjPerson_SkillList_GetDR_out strObjPerson_SkillList_GetDR_out;
    csObjPerson_SkillList_GetDR_in strObjPerson_SkillList_GetDR_in;

    strObjPerson_SkillList_GetDR_in.userID = strUserCertifiedEqpTypeSkillInqInParm.userID;

    rc = cs_person_SkillList_GetDR( strObjPerson_SkillList_GetDR_out,
                                    strObjCommonIn,
                                    strObjPerson_SkillList_GetDR_in );

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "cs_person_SkillList_GetDR() rc != RC_OK. ", rc);
        strUserCertifiedEqpTypeSkillInqResult.strResult = strObjPerson_SkillList_GetDR_out.strResult;
        return(rc);
    }
    
    // get all Eqp Type's required skill info by txCodeListInq and txUserDataInq__101
    pptCodeListInqResult strCodeListInqResult;
    objectIdentifier category;
    category.identifier = SP_CATEGORY_EQUIPMENTTYPE;

    rc = txCodeListInq(strCodeListInqResult, strObjCommonIn, category);

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("PPTServiceManager_i:: cs_txUserCertifiedEqpTypeSkillInq", "rc != RC_OK");
        strUserCertifiedEqpTypeSkillInqResult.strResult = strCodeListInqResult.strResult;
        return rc;
    }
    
    CORBA::Long nResultCnt = 0;
    PPT_METHODTRACE_V2("","strCodeListInqResult.strCodeInfoList.length",strCodeListInqResult.strCodeInfoList.length());
    for (CORBA::Long i = 0; i < strCodeListInqResult.strCodeInfoList.length(); i++)
    {
        PPT_METHODTRACE_V2("", "strCodeListInqResult.strCodeInfoList[i].code.identifier", strCodeListInqResult.strCodeInfoList[i].code.identifier);//vera
        // call txUserDataInq__101
        pptUserDataInqResult strUserDataInqResult1;
        pptUserDataInqInParm__101 strUserDataInqInParm1;

        strUserDataInqInParm1.className = CIMFWStrDup(SP_ClassName_PosCode);
        strUserDataInqInParm1.strHashedInfoSeq.length(2);
        strUserDataInqInParm1.strHashedInfoSeq[0].hashKey = CIMFWStrDup(SP_HashData_CODE_ID);
        strUserDataInqInParm1.strHashedInfoSeq[0].hashData = strCodeListInqResult.strCodeInfoList[i].code.identifier;
        strUserDataInqInParm1.strHashedInfoSeq[1].hashKey = CIMFWStrDup(SP_HashData_CATEGORY_ID);
        strUserDataInqInParm1.strHashedInfoSeq[1].hashData = CIMFWStrDup(SP_CATEGORY_EQUIPMENTTYPE);
        //strUserDataInqInParm1.userDataOriginator = CIMFWStrDup(SP_USERDATA_ORIG_SM);
        
        rc = txUserDataInq__101(strUserDataInqResult1, strObjCommonIn, strUserDataInqInParm1, NULL);
        if (rc != RC_OK && rc != RC_NOT_FOUND_UDATA)
        {
            PPT_METHODTRACE_V2("", "txUserDataInq__101() rc != RC_OK", rc);
            strUserCertifiedEqpTypeSkillInqResult.strResult = strUserDataInqResult1.strResult;
            return(rc);
        }
        
        if (strUserDataInqResult1.strUserDataSeq.length() == 0)
        {
            // add eqp type to struct
            PPT_METHODTRACE_V1("","enter 129 line");
            nResultCnt++;
            strUserCertifiedEqpTypeSkillInqResult.strEqpTypeRequiredSkillSeq.length(nResultCnt);
            strUserCertifiedEqpTypeSkillInqResult.strEqpTypeRequiredSkillSeq[nResultCnt - 1].eqpType = strCodeListInqResult.strCodeInfoList[i].code.identifier;
            continue;
        }
        else
        {
            CORBA::Boolean bFindAll = FALSE;
            CORBA::Boolean bCntFlag = FALSE;
            int nReqSkillCnt = 0;
            PPT_METHODTRACE_V2("","strUserDataInqResult1.strUserDataSeq.length()",strUserDataInqResult1.strUserDataSeq.length());
            for (int j = 0; j < strUserDataInqResult1.strUserDataSeq.length(); j++)
            {
                PPT_METHODTRACE_V2("","strUserDataInqResult1.strUserDataSeq[j].value",strUserDataInqResult1.strUserDataSeq[j].value);
                PPT_METHODTRACE_V2("","strUserDataInqResult1.strUserDataSeq[j].name",strUserDataInqResult1.strUserDataSeq[j].name);
                CORBA::Boolean bFind = FALSE;
                csSkillSequence strSkillSequence = strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo;
                PPT_METHODTRACE_V2("","strSkillSequence.length()",strSkillSequence.length());
                for (int k = 0; k < strSkillSequence.length(); k++)
                {
                    PPT_METHODTRACE_V2("","strSkillSequence[k].skillID",strSkillSequence[k].skillID);
                    if (CIMFWStrCmp(strUserDataInqResult1.strUserDataSeq[j].value, strSkillSequence[k].skillID) == 0)
                    {
                        if (!bCntFlag)
                        {
                            bCntFlag = TRUE;
                            bFindAll = TRUE;
                            strUserCertifiedEqpTypeSkillInqResult.strEqpTypeRequiredSkillSeq.length(nResultCnt + 1);
                        }
                        
                        strUserCertifiedEqpTypeSkillInqResult.strEqpTypeRequiredSkillSeq[nResultCnt].strRequiredSkill.length(nReqSkillCnt + 1);
                        strUserCertifiedEqpTypeSkillInqResult.strEqpTypeRequiredSkillSeq[nResultCnt].strRequiredSkill[nReqSkillCnt] =
                            strUserDataInqResult1.strUserDataSeq[j].value;
                        bFind = TRUE;
                        
                        nReqSkillCnt++;
                        break;
                    }
                }

                // if (bFind == FALSE)
                   // bFindAll = FALSE;
            }
            
            if (bFindAll == TRUE)
            {
                // add eqp type to struct
                PPT_METHODTRACE_V1("","Enter bFindAll");
                // strUserCertifiedEqpTypeSkillInqResult.strEqpTypeRequiredSkillSeq.length(nResultCnt);
                strUserCertifiedEqpTypeSkillInqResult.strEqpTypeRequiredSkillSeq[nResultCnt].eqpType =
                    strCodeListInqResult.strCodeInfoList[i].code.identifier;
                strUserCertifiedEqpTypeSkillInqResult.strEqpTypeRequiredSkillSeq[nResultCnt].eqpTypeDesc =
                    strCodeListInqResult.strCodeInfoList[i].description;
                nResultCnt++;
            }
        }
    }
    
    // call txCodeListInq to get each's skill's desc
    pptCodeListInqResult strCodeListInqSkillResult;
    objectIdentifier categorySkill;
    categorySkill.identifier = CS_USER_DEFINED_CATEGORY_SKILL;

    rc = txCodeListInq(strCodeListInqSkillResult, strObjCommonIn, categorySkill);

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("PPTServiceManager_i:: cs_txUserCertifiedEqpTypeSkillInq", "rc != RC_OK");
        strUserCertifiedEqpTypeSkillInqResult.strResult = strCodeListInqSkillResult.strResult;
        return rc;
    }
    
    int nSkillLen = strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo.length();
    if (nSkillLen > 0)
    {
        strUserCertifiedEqpTypeSkillInqResult.strUserSkillInfoSeq.length(1);
        strUserCertifiedEqpTypeSkillInqResult.strUserSkillInfoSeq[0].requiredCertication = strUserDataInqResult.strUserDataSeq[0].name;
    }
    PPT_METHODTRACE_V2("","nSkillLen",nSkillLen);
    for (int m = 0; m < nSkillLen; m++)
    {
        strUserCertifiedEqpTypeSkillInqResult.strUserSkillInfoSeq[0].strSkillInfo.length(m + 1);
        strUserCertifiedEqpTypeSkillInqResult.strUserSkillInfoSeq[0].strSkillInfo[m].skillID = strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo[m].skillID;
        strUserCertifiedEqpTypeSkillInqResult.strUserSkillInfoSeq[0].strSkillInfo[m].certifiedDate = strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo[m].certifiedDate;
        PPT_METHODTRACE_V2("","strObjPerson_SkillList_GetDR_out_skillID",strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo[m].skillID);
        PPT_METHODTRACE_V2("","strUserCertifiedEqpTypeSkillInqResult.skill",strUserCertifiedEqpTypeSkillInqResult.strUserSkillInfoSeq[0].strSkillInfo[m].skillID);
        PPT_METHODTRACE_V2("","strCodeInfoList.length",strCodeListInqSkillResult.strCodeInfoList.length());
        for (int j = 0; j < strCodeListInqSkillResult.strCodeInfoList.length(); j++)
        {
            PPT_METHODTRACE_V2("","skillID",strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo[m].skillID);
            PPT_METHODTRACE_V2("","code.identifier",strCodeListInqSkillResult.strCodeInfoList[j].code.identifier);
            if (CIMFWStrCmp(strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo[m].skillID, strCodeListInqSkillResult.strCodeInfoList[j].code.identifier) == 0)
            {
                strUserCertifiedEqpTypeSkillInqResult.strUserSkillInfoSeq[0].strSkillInfo[m].skillDesc = strCodeListInqSkillResult.strCodeInfoList[j].description;
                PPT_METHODTRACE_V2("","description",strCodeListInqSkillResult.strCodeInfoList[j].description);
            }
        }
    }

    // Return to caller
    PPT_METHODTRACE_EXIT("PPTManager_i::cs_txUserCertifiedEqpTypeSkillInq");
    return RC_OK;
}