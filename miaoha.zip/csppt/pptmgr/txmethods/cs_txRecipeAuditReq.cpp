#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txRecipeAuditReq.cpp, mm_srv_4_2_ppt, mm_srv_4_2_ppt 6/20/02 14:52:18 [ 6/20/02 14:52:19 ]";
#endif
//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2003. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2003. All rights reserved.
//
// SiView
// Name: cs_txRecipeAuditReq.cpp
//

#include "cs_pptmgr.hpp"

#include <unistd.h>

//
//
// Subsystem Name      : CS_PPT Service Manager
//
//
// Change history:
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
//
CORBA::Long CS_PPTManager_i::cs_txRecipeAuditReq( csRecipeAuditReqResult&          strRecipeAuditReqResult,
                                                  const pptObjCommonIn&            strObjCommonIn,
                                                  const objectIdentifier&          equipmentID,
                                                  const objectIdentifier&          machineRecipeID,
                                                  CORBA::Boolean                   bolEqpConstFlag,
                                                  CORBA::Boolean                   bolBodyFlag,
                                                  CORBA::Environment               &IT_env )
{
     PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txRecipeAuditReq");

     /*--------------------*/
     /*   Initialization   */
     /*--------------------*/
     CORBA::Long rc = RC_OK;
     SET_MSG_RC( strRecipeAuditReqResult, MSG_OK, RC_OK );

     /*------------------------------*/
     /*   Get Eqp's Operation Mode   */
     /*------------------------------*/
     PPT_METHODTRACE_V1("CS_PPTManager_i::cs_txRecipeAuditReq", "Get Eqp's Operation Mode...");

    objEquipment_portInfo_Get_out    strEquipment_portInfo_Get_out;
    rc = equipment_portInfo_Get(strEquipment_portInfo_Get_out, strObjCommonIn, equipmentID);
    if(rc!=RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: cs_txRecipeAuditReq", "equipment_portInfo_Get() rc != RC_OK") ;
        strRecipeAuditReqResult.strResult = strEquipment_portInfo_Get_out.strResult ;
        return rc ;
    }
    
    if ( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length() <= 0 )
    {
        PPT_METHODTRACE_V1("", "strEqpPortStatus.length <= 0") ;
        strRecipeAuditReqResult.strResult = strEquipment_portInfo_Get_out.strResult ;
        return (RC_NOT_FOUND_PORT);
    }
    
    if( CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[0].onlineMode, SP_Eqp_OnlineMode_Offline) == 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: cs_txRecipeAuditReq",
                           "CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[0].onlineMode, SP_Eqp_OnlineMode_Offline) == 0");
        PPT_SET_MSG_RC_KEY2(strRecipeAuditReqResult,
                            MSG_INVALID_EQP_MODE,
                            RC_INVALID_EQP_MODE,
                            equipmentID.identifier,
                            strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[0].onlineMode) ;
        return RC_INVALID_EQP_MODE ;
    }

    // Ignore Audit if EQP in CS_RMS_IGNOREAUDIT_EQPLIST
    const char* ignoreAuditEqpList = getenv("CS_RMS_IGNOREAUDIT_EQPLIST");
    if ( NULL != strstr( ignoreAuditEqpList, equipmentID.identifier ))
    {
        PPT_METHODTRACE_V3( "", "EQP_ID:ignoreAuditEqpList = ", equipmentID.identifier, ignoreAuditEqpList );

        SET_MSG_RC(strRecipeAuditReqResult, MSG_OK, RC_OK);
        return( RC_OK );
    }    

    /*---------------------------------------*/
    /*   Send Recipe Upload Request to RMS   */
    /*---------------------------------------*/
    CORBA::String_var tmpSleepTimeValue=CIMFWStrDup(getenv(CS_SP_BIND_SLEEP_TIME_RMS));
    CORBA::String_var tmpRetryCountValue=CIMFWStrDup(getenv(CS_SP_BIND_RETRY_COUNT_RMS));
    CORBA::Long sleepTimeValue;
    CORBA::Long retryCountValue;

    if (CIMFWStrLen(tmpSleepTimeValue) == 0)
    {
        sleepTimeValue = CS_SP_DEFAULT_SLEEP_TIME_RMS;
    }
    else
    {
        sleepTimeValue = atol(tmpSleepTimeValue) ;
    }

    if (CIMFWStrLen(tmpRetryCountValue) == 0)
    {
        retryCountValue = CS_SP_DEFAULT_RETRY_COUNT_RMS;
    }
    else
    {
        retryCountValue = atol(tmpRetryCountValue);
    }

    PPT_METHODTRACE_V2("","env value of CS_SP_BIND_SLEEP_TIME_RMS  = ",sleepTimeValue);
    PPT_METHODTRACE_V2("","env value of CS_SP_BIND_RETRY_COUNT_RMS = ",retryCountValue);

    csObjRMSMgr_SendRecipeAuditReq_out strRMSMgr_SendRecipeAuditReq_out;  
    //'retryCountValue + 1' means first try plus retry count
    for(CORBA::Long i = 0 ; i < (retryCountValue + 1) ; i++)  
    {
        /*--------------------------*/
        /*    Send Request to RMS   */
        /*--------------------------*/
        rc = cs_RMSMgr_SendRecipeAuditReq( strRMSMgr_SendRecipeAuditReq_out,
                                           strObjCommonIn,
                                           equipmentID,
                                           machineRecipeID,
                                           bolEqpConstFlag,
                                           bolBodyFlag);
        PPT_METHODTRACE_V2("","rc = ",rc);

        if(rc == RC_OK)
        {
            PPT_METHODTRACE_V1("","Now RMS subSystem is alive!! Go ahead");
            break;
        }
        else if ( rc == RC_EXT_SERVER_BIND_FAIL ||
                  rc == RC_EXT_SERVER_NIL_OBJ   ||
                  rc == CS_RC_NO_RESPONSE_RMS   ||    
                  rc == CS_RC_RMS_SERVER_BIND_FAIL  ) 
        {
            PPT_METHODTRACE_V2("","RMS subsystem has return NO_RESPONSE!! just retry now!!  now count...",i);
            PPT_METHODTRACE_V2("","now sleeping... ",sleepTimeValue);
            sleep(sleepTimeValue);
            continue;
        }
        else
        {
            PPT_METHODTRACE_V1("", "cs_RMSMgr_SendRecipeAuditReq() != RC_OK");
            strRecipeAuditReqResult.strResult = strRMSMgr_SendRecipeAuditReq_out.strResult;
            return( rc );
        }

    }

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cs_RMSMgr_SendRecipeAuditReq() != RC_OK");
        strRecipeAuditReqResult.strResult = strRMSMgr_SendRecipeAuditReq_out.strResult;
        return( rc );
    }

    /*--------------------*/
    /*   Return to Main   */
    /*--------------------*/
    SET_MSG_RC(strRecipeAuditReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txRecipeAuditReq");
    return( RC_OK );

}
