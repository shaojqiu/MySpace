#include "cs_pptmgr.hpp"
// @(#) 1.4 superpos/src/csppt/source/posppt/pptmgr/txmethods/cs_txNPWProductChangeReq.cpp, mm_srv_5_0_cspp, mm_srv_5_0_cspp 6/9/03 14:16:50 [ 6/9/03 14:16:52 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_txNPWProductChangeReq.cpp
// INNOTRON Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/19 INN-R170027  Vera Chen      NPW Product Change
// Description:
//
// Return:
//     long
//
// Parameter:
//
// Require:
// 
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_txNPWProductChangeReq (
    csNPWProductChangeReqResult&                    strNPWProductChangeReqResult,
    const pptObjCommonIn&                           strObjCommonIn,
    const csNPWProductChangeReqInParm&              strNPWProductChangeReqInParm,
    const char*                                     claimMemo
    CORBAENV_LAST_CPP )
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txNPWProductChangeReq") ;
    
    PPT_METHODTRACE_V2("", "in para orgProductID ", strNPWProductChangeReqInParm.orgProductID.identifier);
    PPT_METHODTRACE_V2("", "in para productID    ", strNPWProductChangeReqInParm.productID.identifier);
    PPT_METHODTRACE_V2("", "in para lotID        ", strNPWProductChangeReqInParm.lotID.identifier );

    //--------------
    // Initialize
    //--------------
    CORBA::Long rc = RC_OK;

    //Step1.Check inpput parameter
    if( CIMFWStrLen(strNPWProductChangeReqInParm.orgProductID.identifier) == 0 ||
        CIMFWStrLen(strNPWProductChangeReqInParm.productID.identifier) == 0 ||
        CIMFWStrLen(strNPWProductChangeReqInParm.lotID.identifier) == 0 )
    {
        PPT_METHODTRACE_V2("", "in para orgProductID ", strNPWProductChangeReqInParm.orgProductID.identifier);
        SET_MSG_RC(strNPWProductChangeReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM) ;
        return (RC_INVALID_INPUT_PARM);
    }
    
    
    objLot_inventoryState_Get_out   strLot_inventoryState_Get_out;
    
    rc=lot_inventoryState_Get(  strLot_inventoryState_Get_out,
                                strObjCommonIn,
                                strNPWProductChangeReqInParm.lotID);
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","lot_inventoryState_Get() != RC_OK");
        strNPWProductChangeReqResult.strResult = strLot_inventoryState_Get_out.strResult ;
        return(rc); 
    }
    
    PPT_METHODTRACE_V2("", "strLot_inventoryState_Get_out.lotInventoryState   ",strLot_inventoryState_Get_out.lotInventoryState) ;
    if(CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState,SP_Lot_InventoryState_InBank)!=0)
    {
        PPT_METHODTRACE_V1("", "CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState,SP_Lot_InventoryState_InBank)!=0") ;
        PPT_SET_MSG_RC_KEY2(strNPWProductChangeReqResult,
                            MSG_INVALID_LOT_INVENTORYSTAT,
                            RC_INVALID_LOT_INVENTORYSTAT,
                            strNPWProductChangeReqInParm.lotID.identifier,
                            strLot_inventoryState_Get_out.lotInventoryState) ;
        return(RC_INVALID_LOT_INVENTORYSTAT);       
    }
    
    //Step2.Change lot's product 
    csObjLot_NPWProduct_Change_out      strObjLot_NPWProduct_Change_out;
    csObjLot_NPWProduct_Change_in       strObjLot_NPWProduct_Change_in;
    strObjLot_NPWProduct_Change_in.orgProductID = strNPWProductChangeReqInParm.orgProductID;
    strObjLot_NPWProduct_Change_in.productID    = strNPWProductChangeReqInParm.productID;
    strObjLot_NPWProduct_Change_in.lotID        = strNPWProductChangeReqInParm.lotID;
    
    rc = cs_lot_NPWProduct_Change(  strObjLot_NPWProduct_Change_out,
                                    strObjCommonIn,
                                    strObjLot_NPWProduct_Change_in);

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","cs_lot_NPWProduct_Change() != RC_OK");
        strNPWProductChangeReqResult.strResult = strObjLot_NPWProduct_Change_out.strResult ;
        return(rc);    
    }
    
    //Step3.Hold lot 
    pptHoldBankLotReqResult     strHoldBankLotReqResult;
    objectIdentifierSequence    lotIDs;
    lotIDs.length(1);
    lotIDs[0] = strNPWProductChangeReqInParm.lotID;
    objectIdentifier            reasonCodeID;
    reasonCodeID.identifier                 =   CIMFWStrDup(CS_Reason_NPW_ProductChange_Hold);
    reasonCodeID.stringifiedObjectReference =   CIMFWStrDup("");
    CORBA::Long seqIx = 0;
    
    rc = txHoldBankLotReq(  strHoldBankLotReqResult,
                            strObjCommonIn,
                            seqIx,
                            lotIDs,
                            reasonCodeID,
                            claimMemo);
    
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","txHoldBankLotReq() != RC_OK");
        strNPWProductChangeReqResult.strResult = strHoldBankLotReqResult.strResult ;
        return(rc);  
    }
    
    
    SET_MSG_RC(strNPWProductChangeReqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: cs_txNPWProductChangeReq") ;
    return(RC_OK);
}
