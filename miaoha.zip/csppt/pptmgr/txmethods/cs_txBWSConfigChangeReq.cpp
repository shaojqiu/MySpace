// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
//
// SiView
// Name: cs_txBWSConfigChangeReq.cpp
//
// Modeficaiton History:
// Date       Defect        Name          Description
// ---------- ------------- ------------- ----------------------------------------------
// 2017/10/20 INN-R170017   ChengLi      BWS Config Change Request
//
// Class: PPTServiceManager
//
// Service: cs_txBWSConfigChangeReq()
//
// Description:
//<Method Summary>
//
//</Method Summary>
//
// Return:
//     long
//
// Parameter:
//
//     csBWSConfigChangeReqResult&              strBWSConfigChangeReqResult,
//     const pptObjCommonIn&                    strObjCommonIn,
//     const csBWSConfigChangeReqInParm&        strBWSConfigChangeReqInParm
//     const char *                             claimMemo
//
#include "cs_pptmgr.hpp"
CORBA::Long CS_PPTManager_i::cs_txBWSConfigChangeReq(
        csBWSConfigChangeReqResult&         strBWSConfigChangeReqResult,
        const pptObjCommonIn&               strObjCommonIn,
        const csBWSConfigChangeReqInParm&   strBWSConfigChangeReqInParm,
        const char *                        claimMemo
        CORBAENV_LAST_CPP)
{

    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txBWSConfigChangeReq")
    CORBA::Long rc = RC_OK ;

    CORBA::Long nLenBWS = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq.length();

    //--------------------------------------------------------------------
    // Add
    //--------------------------------------------------------------------
    if (0 == CIMFWStrCmp(strBWSConfigChangeReqInParm.actionType, CS_BWS_ConfigAction_Add))
    {
        //----------------------------------------
        // Check Incoming Paramter
        //----------------------------------------
        for (CORBA::Long i = 0; i < nLenBWS; i++)
        {
            CORBA::Long nLenBWSZone = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq.length();
            CORBA::Long bwsZoneCapacityTotal = 0;
            for (CORBA::Long j = 0; j < nLenBWSZone; j++) {
                bwsZoneCapacityTotal = bwsZoneCapacityTotal
                                       +
                                       strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq[j].maxCapacity;
            }

            if (strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].maxCapacity < bwsZoneCapacityTotal) {
                PPT_METHODTRACE_V2("",
                                   "BWS Max Capacity is not big than total Zone Capacity",
                                   CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY);

                CS_SET_MSG_RC(strBWSConfigChangeReqResult,
                           CS_MSG_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY,
                           CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY);
                return (CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY);
            }
        }

        //------------------------------------------
        // Call Add BWS Config obj method
        //------------------------------------------
        for (CORBA::Long ix = 0; ix < nLenBWS; ix++)
        {

            csObjBWS_Config_AddDR_out strBWS_Config_AddDR_out;
            csObjBWS_Config_AddDR_in strBWS_Config_AddDR_in;

            strBWS_Config_AddDR_in.strBWSConfigInfo.BWSID
                    = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].BWSID;
            strBWS_Config_AddDR_in.strBWSConfigInfo.maxCapacity
                    = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].maxCapacity;
            strBWS_Config_AddDR_in.strBWSConfigInfo.strZoneConfigInfoSeq
                    = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].strZoneConfigInfoSeq;

            rc = cs_BWS_Config_AddDR(strBWS_Config_AddDR_out,
                                     strObjCommonIn,
                                     strBWS_Config_AddDR_in,"");

            if (rc != RC_OK) {
                PPT_METHODTRACE_V2("", "cs_BWS_Config_AddDR != RC_OK", rc);
                strBWSConfigChangeReqResult.strResult = strBWS_Config_AddDR_out.strResult;
                return rc;
            }
        }
        SET_MSG_RC(strBWSConfigChangeReqResult, MSG_OK, RC_OK);
    }

    //--------------------------------------------------------------------
    // Update
    //--------------------------------------------------------------------
    if (0 == CIMFWStrCmp(strBWSConfigChangeReqInParm.actionType, CS_BWS_ConfigAction_Update))
    {
        //----------------------------------------
        // Check Incoming Paramter
        //----------------------------------------
        for (CORBA::Long i = 0; i < nLenBWS; i++)
        {
            CORBA::Long nLenBWSZone = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq.length();
            CORBA::Long bwsZoneCapacityTotal = 0;
            for (CORBA::Long j = 0; j < nLenBWSZone; j++) {
                bwsZoneCapacityTotal = bwsZoneCapacityTotal
                                       +
                                       strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].strZoneConfigInfoSeq[j].maxCapacity;
            }

            if (strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[i].maxCapacity < bwsZoneCapacityTotal) {
                PPT_METHODTRACE_V2("",
                                   "BWS Max Capacity is not big than total Zone Capacity",
                                   CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY);

                CS_SET_MSG_RC(strBWSConfigChangeReqResult,
                           CS_MSG_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY,
                           CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY);
                return (CS_RC_BWS_CONFIG_INVALID_BWS_MAX_CAPACITY);
            }
        }

        //------------------------------------------
        // Call Update BWS Config obj method
        //------------------------------------------
        for (CORBA::Long ix = 0; ix < nLenBWS; ix++)
        {

            csObjBWS_Config_UpdateDR_out strBWS_Config_UpdateDR_out;
            csObjBWS_Config_UpdateDR_in strBWS_Config_UpdateDR_in;

            strBWS_Config_UpdateDR_in.strBWSConfigInfo.BWSID
                    = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].BWSID;
            strBWS_Config_UpdateDR_in.strBWSConfigInfo.maxCapacity
                    = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].maxCapacity;
            strBWS_Config_UpdateDR_in.strBWSConfigInfo.strZoneConfigInfoSeq
                    = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].strZoneConfigInfoSeq;

            rc = cs_BWS_Config_UpdateDR(strBWS_Config_UpdateDR_out,
                                        strObjCommonIn,
                                        strBWS_Config_UpdateDR_in,
                                        "");

            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V2("", "cs_BWS_Config_UpdateDR != RC_OK", rc);
                strBWSConfigChangeReqResult.strResult = strBWS_Config_UpdateDR_out.strResult;
                return rc;
            }
        }
        SET_MSG_RC(strBWSConfigChangeReqResult, MSG_OK, RC_OK);
    }


    //--------------------------------------------------------------------
    // Delete
    //--------------------------------------------------------------------
    for (CORBA::Long ix = 0; ix < nLenBWS; ix++)
    {
        csObjBWS_Config_DeleteDR_out strBWS_Config_DeleteDR_out;
        csObjBWS_Config_DeleteDR_in strBWS_Config_DeleteDR_in;
        strBWS_Config_DeleteDR_in.BWSID = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].BWSID;

        CORBA::Long bwsZonelen = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].strZoneConfigInfoSeq.length();

        //------------------------------------------
        // Call Delete BWS Config obj method
        //------------------------------------------
        for(CORBA::Long jx = 0; jx < bwsZonelen; jx++)
        {
            strBWS_Config_DeleteDR_in.zoneID
                    = strBWSConfigChangeReqInParm.strBWSConfigInfoSeq[ix].strZoneConfigInfoSeq[jx].zoneID;

            rc = cs_BWS_Config_DeleteDR(strBWS_Config_DeleteDR_out,
                                        strObjCommonIn,
                                        strBWS_Config_DeleteDR_in,
                                        "");
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V2("", "cs_BWS_Config_DeleteDR != RC_OK", rc);
                strBWSConfigChangeReqResult.strResult = strBWS_Config_DeleteDR_out.strResult;
                return rc;
            }
        }
        SET_MSG_RC(strBWSConfigChangeReqResult, MSG_OK, RC_OK);
    }

    return rc;
}
