#ifndef lint
static char *sccsid =  "@(#) 1.2 superpos/src/spppt/source/posppt/pptmgr/txmethods/txSplitWaferLotNotOnRouteReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 8/3/07 15:58:53 [ 8/3/07 15:58:54 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: txSplitWaferLotNotOnRouteReq.cpp
//

#include "cs_pptmgr.hpp"
#include "penin.hh"

// Class: PPTManager
//
// Service: txSplitWaferLotNotOnRouteReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/11          O.Sugiyama     Initial Release
// 2000/09/26 Q3000147 S.Kawabe       Add Check Lot's Control Job ID
// 2000/10/23 P3000280 S.Kawabe       Boolean variable initialize
// 2001-03-02 P3100069 O.Sugiyama     Add LotWaferMoveEvent
// 2001/07/02 P4000037 K.Kido         Add XferStatus check
// 2001/07/16 P4000053 K.kido         set childLotID to return structure
// 2001/08/01 P4000079 K.Kido         Change XferState check logic
// 2002/07/02 P4200026 H.Adachi       Fix wrong waferID setting For Event Make
// 2003/09/09 P5000145 H.Adachi       Fix Message and Message Macro mismatch.
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2004/11/08 P6000017 S.Yamamoto     Fix : Object Lock missing or delay.
// 2007/06/15 D9000038 D.Tamura       Remove In-Cassette Limitation.
// 2007/06/13 D9000005 H.Hotta        WaferSorter automation support.
// 2007/06/15 P9000011 H.Murakami     Bug Fix.
// 2007/08/03 D9000056 H.Hotta        Add check logic for InPostProcessFlag.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/23 DSIV00000099 M.Ogawa        SLM support (R10.0).
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
// 2010/03/15 DSIV00001830 S.Kawabe       Wafer Stacking Operation Support
// 2013/05/10 DSN000071674 C.Mo           Remove part of the EI state limitation
// 2014/01/21 PSN000083176 C.Mo           Data inconsistency might occur when start lot reservation is called together with lot operation transactions for the same cassette
// 2017/05/01 PSN000081334 C.Itoh         MM does not update FHOPEHS.WFRHS_TIME when split the Vendor Lot.
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    pptSplitWaferLotNotOnRouteReqResult&    strSplitWaferLotNotOnRouteReqResult
//    const pptObjCommonIn&                   strObjCommonIn
//    const pptUser&                          requestUserID
//    const objectIdentifier&                 parentLotID
//    CORBA::Long                             parentLotWaferCount
//    CORBA::Long                             childLotWaferCount
//    const objectIdentifierSequence&         childWaferID
//    const char *                            claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i:: txSplitWaferLotNotOnRouteReq(
    pptSplitWaferLotNotOnRouteReqResult&    strSplitWaferLotNotOnRouteReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const pptUser&                          requestUserID,
    const objectIdentifier&                 parentLotID,
    CORBA::Long                             parentLotWaferCount,
    CORBA::Long                             childLotWaferCount,
    const objectIdentifierSequence&         childWaferID,
//D6000025     const char *                            claimMemo,
//D6000025     CORBA::Environment &                    IT_env)
    const char *                            claimMemo  //D6000025
    CORBAENV_LAST_CPP)                                 //D6000025
{
    PPT_METHODTRACE_ENTRY("PPTManager_i:: txSplitWaferLotNotOnRouteReq");

    {
        CORBA::Long nLen = childWaferID.length();
        PPT_METHODTRACE_V2("", "in para parentLotID           ", parentLotID.identifier );
        PPT_METHODTRACE_V2("", "in para parentLotWaferCount   ", parentLotWaferCount );
        PPT_METHODTRACE_V2("", "in para childLotWaferCount    ", childLotWaferCount );
        PPT_METHODTRACE_V2("", "in para childWaferID.length() ", nLen );
        for ( CORBA::Long i=0; i< nLen; i++)
        {
            PPT_METHODTRACE_V3("", "in para   .identifier         ", i, childWaferID[i].identifier );
        }
    }

    CORBA::Long rc = RC_OK ;

    objObject_Lock_out strObject_Lock_out;
//P6000017    rc = object_Lock( strObject_Lock_out, strObjCommonIn, parentLotID, SP_ClassName_PosLot);
//P6000017    if ( rc != RC_OK )
//P6000017    {
//P6000017        PPT_METHODTRACE_V1("", "object_Lock() rc != RC_OK");
//P6000017        strSplitWaferLotNotOnRouteReqResult.strResult = strObject_Lock_out.strResult;
//P6000017        return(rc);
//P6000017    }

    //-------------------------------------
    // Prepare objectIdentifier structure
    // for local lot
    //-------------------------------------
    objectIdentifier aPparentLotID = parentLotID;
    objectIdentifier aParentCassetteID;

    // When childWaferID is filled in tx.
    if ( childWaferID.length() > 0 )
    {
        PPT_METHODTRACE_V1("", "childWaferID.length() > 0");

        //-------------------------------------------------------------
        // Get cassetteID which childWaferID[0] is in for object_Lock().
        //-------------------------------------------------------------
        objWafer_LotCassette_Get_out strWafer_LotCassette_Get_out;
        rc = wafer_LotCassette_Get( strWafer_LotCassette_Get_out, strObjCommonIn, childWaferID[0] );
        // set childWaferID[0] of in-parm.
                   // in sequence waferIDs
                   // out lotID
                   // out cassetteID

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "wafer_LotCassette_Get() rc != RC_OK");
            strSplitWaferLotNotOnRouteReqResult.strResult = strWafer_LotCassette_Get_out.strResult;
            return(rc);
        }

        if (CIMFWStrLen( strWafer_LotCassette_Get_out.cassetteID.identifier ) != 0)
        {
            PPT_METHODTRACE_V1("", "CIMFWStrLen(strWafer_LotCassette_Get_out.cassetteID.identifier) != 0");
            // Copy the returned cassetteID to parentCassetteID
            aParentCassetteID = strWafer_LotCassette_Get_out.cassetteID;
        }

        // Check if parentLotID is same as returned lotID
        if (CIMFWStrCmp( strWafer_LotCassette_Get_out.lotID.identifier, parentLotID.identifier ) != 0 )
        {
            PPT_METHODTRACE_V1("", "CIMFWStrCmp(strWafer_LotCassette_Get_out.lotID.identifier, parentLotID.identifier) != 0");
            PPT_SET_MSG_RC_KEY(strSplitWaferLotNotOnRouteReqResult, MSG_INVALID_LOT_CONTENTS, RC_INVALID_LOT_CONTENTS,
                               parentLotID.identifier);
            return( RC_INVALID_LOT_CONTENTS );
        }
    }
    // When childWaferID is not filled in tx.
    else
    {
        PPT_METHODTRACE_V1("", "childWaferID.length() <= 0");

        //-------------------------------------------------------------
        // Get cassetteID which parentLot is in for object_Lock().
        //-------------------------------------------------------------
        objLot_cassette_Get_out strLot_cassette_Get_out;
//P9000011        lot_cassette_Get( strLot_cassette_Get_out, strObjCommonIn, parentLotID);        // set parentLotID of in-parm.

        //----------------------------
        // set parentLotID of in-parm.
        //----------------------------
        rc = lot_cassette_Get( strLot_cassette_Get_out, strObjCommonIn, parentLotID);        //P9000011
        if ( rc != RC_OK && rc != RC_NOT_FOUND_CST )
        {
            PPT_METHODTRACE_V1("", "lot_cassette_Get() rc != RC_OK");
            strSplitWaferLotNotOnRouteReqResult.strResult = strLot_cassette_Get_out.strResult;
            return(rc);
        }
        // When parentLot is in parentCassetteID.
        if ( rc == RC_OK )
        {
            // Copy the returned cassetteID to parentCassetteID
            aParentCassetteID = strLot_cassette_Get_out.cassetteID;
        }
    }

//DSN000071674 add start
    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );

    CORBA::Boolean updateControlJobFlag = FALSE;
    CORBA::Long lockMode = 0; //PSN000083176

    objCassette_transferState_Get_out strCassetteTransferState;
//DSN000071674 add end

    //-------------------------------
    // If parentCassetteID is filled
    //-------------------------------
    if (CIMFWStrLen( aParentCassetteID.identifier ) != 0)
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(aParentCassetteID.identifier) != 0");

//DSN000071674 add start
        if ( 0 == lotOperationEIcheck )
        {
            //-------------------------------
            // Get carrier transfer status
            //-------------------------------
            rc = cassette_transferState_Get(strCassetteTransferState, strObjCommonIn,
                                            aParentCassetteID);
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "rc != RC_OK");
                strSplitWaferLotNotOnRouteReqResult.strResult = strCassetteTransferState.strResult ;
                return( rc );
            }

            /*------------------------------------*/
            /*   Get equipment ID in Cassette     */
            /*------------------------------------*/
            objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
            rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                           strObjCommonIn,
                                           aParentCassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "", "cassette_equipmentID_Get != RC_OK", rc);
                strSplitWaferLotNotOnRouteReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
                return( rc );
            }

            //-------------------------------
            // Get required equipment lock mode
            //-------------------------------
            objObject_lockMode_Get_out strObject_lockMode_Get_out;
            objObject_lockMode_Get_in  strObject_lockMode_Get_in;
            strObject_lockMode_Get_in.objectID           = strCassette_equipmentID_Get_out.equipmentID;
            strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
            strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXTRC048" ); // TxSplitWaferLotNotOnRouteReq
            strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

            rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                      strObjCommonIn,
                                      strObject_lockMode_Get_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
                strSplitWaferLotNotOnRouteReqResult.strResult = strObject_lockMode_Get_out.strResult;
                return( rc );
            }

//PSN000083176            CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
            lockMode = strObject_lockMode_Get_out.lockMode; //PSN000083176
            PPT_METHODTRACE_V2( "", "lockMode", lockMode );

            if ( 0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) )
            {
                updateControlJobFlag = TRUE;

                if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
                {
                    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
                    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;

                    // Lock Equipment Main Object
                    stringSequence dummySeq;
                    dummySeq.length(0);
                    strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                    strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                    strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
                    strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
                    strAdvanced_object_Lock_in.keySeq     = dummySeq;

                    rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                                strObjCommonIn,
                                                strAdvanced_object_Lock_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                        strSplitWaferLotNotOnRouteReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                        return( rc );
                    }

                    // Lock Equipment LoadCassette Element (Write)
                    stringSequence loadCastSeq;
                    loadCastSeq.length(1);
                    loadCastSeq[0] = aParentCassetteID.identifier;
                    strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                    strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                    strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
                    strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
                    strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

                    rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                                strObjCommonIn,
                                                strAdvanced_object_Lock_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                        strSplitWaferLotNotOnRouteReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                        return( rc );
                    }
                }
                else
                {
                    /*--------------------------------*/
                    /*   Lock Macihne object          */
                    /*--------------------------------*/
                    rc = object_Lock( strObject_Lock_out, strObjCommonIn, strCassette_equipmentID_Get_out.equipmentID, SP_ClassName_PosMachine );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc) ;
                        strSplitWaferLotNotOnRouteReqResult.strResult = strObject_Lock_out.strResult ;
                        return( rc );
                    }
                }
            }

//PSN000083176            if ( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176            {
//PSN000083176                //---------------------------------
//PSN000083176                //   Get Cassette's ControlJobID
//PSN000083176                //---------------------------------
//PSN000083176                objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

//PSN000083176                rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
//PSN000083176                                                strObjCommonIn,
//PSN000083176                                                aParentCassetteID );
//PSN000083176                if ( rc != RC_OK )
//PSN000083176                {
//PSN000083176                    PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
//PSN000083176                    strSplitWaferLotNotOnRouteReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
//PSN000083176                    return( rc );
//PSN000083176                }
//PSN000083176                if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
//PSN000083176                {
//PSN000083176                    PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
//PSN000083176                    updateControlJobFlag = TRUE;

//PSN000083176                    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176                    {
//PSN000083176                        /*------------------------------*/
//PSN000083176                        /*   Lock ControlJob Object     */
//PSN000083176                        /*------------------------------*/
//PSN000083176                        rc = object_Lock( strObject_Lock_out,
//PSN000083176                                          strObjCommonIn, 
//PSN000083176                                          strCassette_controlJobID_Get_out.controlJobID, 
//PSN000083176                                          SP_ClassName_PosControlJob );
//PSN000083176                        if ( rc != RC_OK )
//PSN000083176                        {
//PSN000083176                            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
//PSN000083176                            strSplitWaferLotNotOnRouteReqResult.strResult = strObject_Lock_out.strResult;
//PSN000083176                            return( rc );
//PSN000083176                        }
//PSN000083176                    }
//PSN000083176                }
//PSN000083176            }
        }
//DSN000071674 add end

        //-------------------------------
        // Lock objects to be updated
        //-------------------------------
        rc = object_Lock( strObject_Lock_out, strObjCommonIn,
                          aParentCassetteID, SP_ClassName_PosCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "object_Lock(aParentCassetteID) rc != RC_OK");
            strSplitWaferLotNotOnRouteReqResult.strResult = strObject_Lock_out.strResult;
            return(rc);
        }
//PSN000083176 add start
        if ( 0 == lotOperationEIcheck )
        {
            if ( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
            {
                //---------------------------------
                //   Get Cassette's ControlJobID
                //---------------------------------
                objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

                rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                                strObjCommonIn,
                                                aParentCassetteID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
                    strSplitWaferLotNotOnRouteReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
                    return( rc );
                }
                if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
                {
                    PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
                    updateControlJobFlag = TRUE;

                    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
                    {
                        /*------------------------------*/
                        /*   Lock ControlJob Object     */
                        /*------------------------------*/
                        rc = object_Lock( strObject_Lock_out,
                                          strObjCommonIn, 
                                          strCassette_controlJobID_Get_out.controlJobID, 
                                          SP_ClassName_PosControlJob );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                            strSplitWaferLotNotOnRouteReqResult.strResult = strObject_Lock_out.strResult;
                            return( rc );
                        }
                    }
                }
            }
        }
//PSN000083176 add end
        //P6000017 start
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, parentLotID, SP_ClassName_PosLot);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "object_Lock() rc != RC_OK");
            strSplitWaferLotNotOnRouteReqResult.strResult = strObject_Lock_out.strResult;
            return(rc);
        }
        //P6000017 end

        //-------------------------------
        // Check carrier transfer status
        //-------------------------------
        objCassette_transferState_Get_out strCassette_transferState_Get_out;

//DSN000071674 add start
        if ( 1 == lotOperationEIcheck
        || ( 0 == lotOperationEIcheck && 0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) ) )
        {
//DSN000071674 add end
            rc = cassette_transferState_Get( strCassette_transferState_Get_out, strObjCommonIn, aParentCassetteID);        // for parent cassette
//P4000037        if (CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_BayOut )      == 0 ||
//P4000037            CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn ) == 0)
//P4000037        {
//P4000037            PPT_METHODTRACE_V1("", "SP_TransState_BayOut || SP_TransState_BayOut");
//P4000037            PPT_SET_MSG_RC_KEY2( strSplitWaferLotNotOnRouteReqResult, MSG_INVALID_CAST_XFERSTAT, RC_INVALID_CAST_XFERSTAT,
//P4000037                                 strCassette_transferState_Get_out.transferState,
//P4000037                                 aParentCassetteID.identifier);
//P4000037            return( RC_INVALID_CAST_XFERSTAT );
//P4000037        }

//P4000037 add start
            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "rc != RC_OK");
                strSplitWaferLotNotOnRouteReqResult.strResult = strCassette_transferState_Get_out.strResult ;
                return(rc);
            }
//DSN000071674 add start
            if ( 0 == lotOperationEIcheck )
            {
                PPT_METHODTRACE_V1("", "lotOperationEIcheck = 0");
                if ( 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) )                                                     //D4100091
                {
                    PPT_METHODTRACE_V1("","Changed to EI by other operation");
                    strSplitWaferLotNotOnRouteReqResult.strResult = strCassette_transferState_Get_out.strResult ;
                    PPT_SET_MSG_RC_KEY(strSplitWaferLotNotOnRouteReqResult, MSG_CHANGED_TO_EI_BY_OTHER_OPERATION, RC_CHANGED_TO_EI_BY_OTHER_OPERATION,
                                       aParentCassetteID.identifier);
                    return( RC_CHANGED_TO_EI_BY_OTHER_OPERATION );
                }
            }
//DSN000071674 add end
//P4000079    else if(!(CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_EquipmentOut)    == 0  ||
//P4000079              CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_ManualOut)       == 0  ||
//P4000079              CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_IntermediateOut) == 0  ||
//P4000079              CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_ShelfOut)        == 0  ||
//P4000079              CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_UNDEFINED_STATE)            == 0  ||
//P4000079              CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_AbnormalOut)     == 0  ||
//P4000079              CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_StationOut)      == 0) )
            else if (CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_BayOut    ) == 0 ||
                     CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0)             //P4000079
            {
                PPT_METHODTRACE_V1("","XferState is invalid...");
                strSplitWaferLotNotOnRouteReqResult.strResult = strCassette_transferState_Get_out.strResult ;
                PPT_SET_MSG_RC_KEY2(strSplitWaferLotNotOnRouteReqResult, MSG_INVALID_CAST_XFERSTAT, RC_INVALID_CAST_XFERSTAT,
                                    strCassette_transferState_Get_out.transferState,
                                    aParentCassetteID.identifier);
                return( RC_INVALID_CAST_XFERSTAT );
            }
//P4000037 add end
        } //DSN000071674

//DSN000071674 add start
        if ( 1 == lotOperationEIcheck )
        {
//DSN000071674 add end
            //-------------------------------
            // Check carrier dispatch status
            //-------------------------------
            objCassette_dispatchState_Get_out strCassette_dispatchState_Get_out;
            strCassette_dispatchState_Get_out.dispatchReservedFlag = FALSE; //P3000280
            rc = cassette_dispatchState_Get( strCassette_dispatchState_Get_out, strObjCommonIn, aParentCassetteID);  // for parent cassette
            if ( strCassette_dispatchState_Get_out.dispatchReservedFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "SP_TransState_BayOut || SP_TransState_BayOut");
                SET_MSG_RC( strSplitWaferLotNotOnRouteReqResult, MSG_ALREADY_DISPATCH_RESVED_CST, RC_ALREADY_DISPATCH_RESVED_CST );
                return( RC_ALREADY_DISPATCH_RESVED_CST );
            }
        } //DSN000071674

        //-------------------------------
        // Check carrier reserved flag
        //-------------------------------
        objCassette_reservedState_Get_out strCassette_reservedState_Get_out;
        strCassette_reservedState_Get_out.transferReserved = FALSE; //P3000280
        rc = cassette_reservedState_Get( strCassette_reservedState_Get_out, strObjCommonIn, aParentCassetteID);  // for parent cassette
        if ( strCassette_reservedState_Get_out.transferReserved == TRUE )
        {
            PPT_METHODTRACE_V1("", "SP_TransState_BayOut || SP_TransState_BayOut");
            SET_MSG_RC( strSplitWaferLotNotOnRouteReqResult, MSG_ALREADY_RESERVED_CST, RC_ALREADY_RESERVED_CST);
            return( RC_ALREADY_RESERVED_CST );
        }
    }
    //P6000017 start
    else
    {
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, parentLotID, SP_ClassName_PosLot);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "object_Lock() rc != RC_OK");
            strSplitWaferLotNotOnRouteReqResult.strResult = strObject_Lock_out.strResult;
            return(rc);
        }
    }
    //P6000017 end

//D9000005 add start
    /*-------------------------------*/
    /*   Check SorterJob existence   */
    /*-------------------------------*/
    pptEquipmentLoadPortAttribute dummyEquipmentPortAttribute;
    objectIdentifierSequence dummyCastIDs, lotIDs;
    lotIDs.length(1);
    lotIDs[0] = parentLotID;

    objWaferSorter_sorterJob_CheckForOperation_out strWaferSorter_sorterJob_CheckForOperation_out;
    objWaferSorter_sorterJob_CheckForOperation_in  strWaferSorter_sorterJob_CheckForOperation_in;
    strWaferSorter_sorterJob_CheckForOperation_in.strEquipmentLoadPortAttribute = dummyEquipmentPortAttribute;
    strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs                   = dummyCastIDs;
    strWaferSorter_sorterJob_CheckForOperation_in.lotIDs                        = lotIDs;
    strWaferSorter_sorterJob_CheckForOperation_in.operation                     = CIMFWStrDup(SP_Operation_For_Lot);

    rc = waferSorter_sorterJob_CheckForOperation( strWaferSorter_sorterJob_CheckForOperation_out,
                                                  strObjCommonIn,
                                                  strWaferSorter_sorterJob_CheckForOperation_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "waferSorter_sorterJob_CheckForOperation() != RC_OK" );
        strSplitWaferLotNotOnRouteReqResult.strResult = strWaferSorter_sorterJob_CheckForOperation_out.strResult;
        return( rc );
    }
//D9000005 add end

//DSIV00000099 add start
    /*------------------------------------------------------------------------*/
    /*   Check if the wafers in lot don't have machine container position     */
    /*------------------------------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call equipmentContainerPosition_info_GetByLotDR()");
    objEquipmentContainerPosition_info_GetByLotDR_out strEquipmentContainerPosition_info_GetByLotDR_out;
    objEquipmentContainerPosition_info_GetByLotDR_in  strEquipmentContainerPosition_info_GetByLotDR_in;
    strEquipmentContainerPosition_info_GetByLotDR_in.lotID = parentLotID;
    rc = equipmentContainerPosition_info_GetByLotDR( strEquipmentContainerPosition_info_GetByLotDR_out,
                                                     strObjCommonIn,
                                                     strEquipmentContainerPosition_info_GetByLotDR_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipmentContainerPosition_info_GetByLotDR() != RC_OK", rc);
        strSplitWaferLotNotOnRouteReqResult.strResult = strEquipmentContainerPosition_info_GetByLotDR_out.strResult;
        return ( rc );
    }

    CORBA::Long lenEqpContPos = strEquipmentContainerPosition_info_GetByLotDR_out.strEqpContainerPositionSeq.length();
    PPT_METHODTRACE_V2("", "lenEqpContPos", lenEqpContPos);
    if ( 0 < lenEqpContPos )
    {
        PPT_METHODTRACE_V1("", "Some wafers contained in this lot have equipment container positions.");
        PPT_SET_MSG_RC_KEY( strSplitWaferLotNotOnRouteReqResult,
                            MSG_WAFER_IN_LOT_HAVE_CONTAINER_POSITION, RC_WAFER_IN_LOT_HAVE_CONTAINER_POSITION,
                            parentLotID.identifier );
        return( RC_WAFER_IN_LOT_HAVE_CONTAINER_POSITION );
    }
//DSIV00000099 add end

    //----------------------------------------------
    // Check Lot contents die, chip, wafer, etc...
    //----------------------------------------------
    objLot_contents_Get_out strLot_contents_Get_out;
    rc = lot_contents_Get(strLot_contents_Get_out, strObjCommonIn, parentLotID );  //for parentLot
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lot_contents_Get() rc != RC_OK");
        strSplitWaferLotNotOnRouteReqResult.strResult = strLot_contents_Get_out.strResult;
        return(rc);
    }
    else if (CIMFWStrCmp( strLot_contents_Get_out.theLotContents, SP_ProdType_Wafer ) != 0 &&
             CIMFWStrCmp( strLot_contents_Get_out.theLotContents, SP_ProdType_Die )   != 0)
    {
        PPT_METHODTRACE_V1("", "lot_contents_Get() returned lotContent is not SP_ProdType_Wafer nor SP_ProdType_Die");
        PPT_SET_MSG_RC_KEY( strSplitWaferLotNotOnRouteReqResult, MSG_INVALID_LOT_CONTENTS, RC_INVALID_LOT_CONTENTS,
                            parentLotID.identifier);
        return( RC_INVALID_LOT_CONTENTS );
    }

    //-------------------------
    // Get lot's all state
    //-------------------------
    objLot_allState_Get_out strLot_allState_Get_out;
    rc = lot_allState_Get( strLot_allState_Get_out, strObjCommonIn, parentLotID );
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() rc != RC_OK");
        strSplitWaferLotNotOnRouteReqResult.strResult = strLot_allState_Get_out.strResult;
        return(rc);
    }

    //-------------------------
    // Check Lot hold state
    //-------------------------
    if (CIMFWStrCmp( strLot_allState_Get_out.holdState, CIMFW_Lot_HoldState_OnHold ) == 0)
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() returned lotHoldState is CIMFW_Lot_HoldState_OnHold");
        SET_MSG_RC(strSplitWaferLotNotOnRouteReqResult, MSG_CANNOT_SPLIT_HELDLOT, RC_CANNOT_SPLIT_HELDLOT);
        return( RC_CANNOT_SPLIT_HELDLOT );
    }

    //-------------------------
    // Check Lot finish state
    //-------------------------
    if (CIMFWStrCmp( strLot_allState_Get_out.finishedState, CIMFW_Lot_FinishedState_Scrapped ) == 0 ||
        CIMFWStrCmp( strLot_allState_Get_out.finishedState, CIMFW_Lot_FinishedState_Emptied  ) == 0 ||
        CIMFWStrCmp( strLot_allState_Get_out.finishedState, SP_LOT_FINISHED_STATE_STACKED  ) == 0) //DSIV00001830
    {
//DSIV00001830        PPT_METHODTRACE_V1("", "lot_allState_Get() returned lotFinishedState is CIMFW_Lot_FinishedState_Scrapped or CIMFW_Lot_FinishedState_Emptied");
        PPT_METHODTRACE_V1("", "lot_allState_Get() returned lotFinishedState is CIMFW_Lot_FinishedState_Scrapped or CIMFW_Lot_FinishedState_Emptied or SP_LOT_FINISHED_STATE_STACKED"); //DSIV00001830
        PPT_SET_MSG_RC_KEY( strSplitWaferLotNotOnRouteReqResult, MSG_INVALID_LOT_STAT, RC_INVALID_LOT_STAT,
                            strLot_allState_Get_out.finishedState);
        return( RC_INVALID_LOT_STAT );
    }

//DSIV00001830 add start
    //-------------------------
    // Check Bonding Group
    //-------------------------
    objLot_bondingGroupID_GetDR_in  strLot_bondingGroupID_GetDR_in;
    strLot_bondingGroupID_GetDR_in.lotID = parentLotID;

    objLot_bondingGroupID_GetDR_out strLot_bondingGroupID_GetDR_out;
    rc = lot_bondingGroupID_GetDR( strLot_bondingGroupID_GetDR_out, strObjCommonIn, strLot_bondingGroupID_GetDR_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_bondingGroupID_GetDR() rc != RC_OK");
        strSplitWaferLotNotOnRouteReqResult.strResult = strLot_bondingGroupID_GetDR_out.strResult;
        return rc;
    }
    if( CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0");
        PPT_SET_MSG_RC_KEY2( strSplitWaferLotNotOnRouteReqResult,
                             MSG_LOT_HAS_BONDINGGROUP,
                             RC_LOT_HAS_BONDINGGROUP,
                             strLot_bondingGroupID_GetDR_in.lotID.identifier,
                             strLot_bondingGroupID_GetDR_out.bondingGroupID );
        return RC_LOT_HAS_BONDINGGROUP;
    }
//DSIV00001830 add end

    //-------------------------
    // Check Lot process state
    //-------------------------
    if (CIMFWStrCmp( strLot_allState_Get_out.processState, SP_Lot_ProcState_Processing ) == 0)
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() returned lotProcessState is SP_Lot_ProcState_Processing");
        PPT_SET_MSG_RC_KEY2( strSplitWaferLotNotOnRouteReqResult, MSG_INVALID_LOT_PROCSTAT, RC_INVALID_LOT_PROCSTAT,
                             parentLotID.identifier,
                             strLot_allState_Get_out.processState);
        return( RC_INVALID_LOT_PROCSTAT );
    }

    //-------------------------
    // Check Lot Inventory state
    //-------------------------
    if (CIMFWStrCmp( strLot_allState_Get_out.inventoryState, SP_Lot_InventoryState_InBank ) != 0)
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() returned lotInventoryState is not SP_Lot_InventoryState_InBank");
        PPT_SET_MSG_RC_KEY2( strSplitWaferLotNotOnRouteReqResult, MSG_INVALID_LOT_INVENTORYSTAT, RC_INVALID_LOT_INVENTORYSTAT,
                             parentLotID.identifier,
                             strLot_allState_Get_out.inventoryState);
        return( RC_INVALID_LOT_INVENTORYSTAT );
    }

//D9000056 add start
    PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
    //----------------------------------
    //  Get InPostProcessFlag of Lot
    //----------------------------------
    objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
    objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
    strLot_inPostProcessFlag_Get_in.lotID = parentLotID;

    rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                    strObjCommonIn,
                                    strLot_inPostProcessFlag_Get_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
        strSplitWaferLotNotOnRouteReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
        return( rc );
    }

    //----------------------------------------------
    //  If Lot is in post process, returns error
    //----------------------------------------------
    if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
    {
        PPT_METHODTRACE_V1("", "Lot is in post process.");
//DSIV00000201 Add Start
        /*---------------------------*/
        /* Get UserGroupID By UserID */
        /*---------------------------*/
        objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
        rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                         strObjCommonIn,
                                         strObjCommonIn.strUser.userID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
            strSplitWaferLotNotOnRouteReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
            return( rc );
        }
        objectIdentifierSequence userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
        CORBA::ULong userGroupIDsLen = userGroupIDs.length();
        PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);
        
        CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
        PPT_METHODTRACE_V2("", "extPostProc", extPostProc);
        
        CORBA::ULong nCnt = 0;
        for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
        {
            PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
            if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
            {
                PPT_METHODTRACE_V1("", "# External Post Process User!");
                break;
            }
            
        }
        if (nCnt == userGroupIDsLen)
        {
            PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
            PPT_SET_MSG_RC_KEY( strSplitWaferLotNotOnRouteReqResult,
                                MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                parentLotID.identifier );
            return( RC_LOT_INPOSTPROCESS );
        }   //DSIV00000201
    }
//D9000056 add end

//Q3000147 add start
    /*----------------------------------*/
    /*   Check Lot's Control Job ID     */
    /*----------------------------------*/
    objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, parentLotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_controlJobID_Get() != RC_OK");
        strSplitWaferLotNotOnRouteReqResult.strResult = strLot_controlJobID_Get_out.strResult ;
        return(rc);
    }
    if (CIMFWStrLen( strLot_controlJobID_Get_out.controlJobID.identifier ) == 0)
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) = 0") ;
        rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) > 0") ;
        PPT_SET_MSG_RC_KEY2( strSplitWaferLotNotOnRouteReqResult,
                             MSG_LOT_CTLJOBID_FILLED,
                             RC_LOT_CTLJOBID_FILLED,
                             parentLotID.identifier,
                             strLot_controlJobID_Get_out.controlJobID.identifier ) ;
        return( RC_LOT_CTLJOBID_FILLED );
    }
//Q3000147 add end

    //---------------------------------
    // Get Lot's Route ID (Main PD ID)
    //---------------------------------
    objLot_routeID_Get_out strLot_routeID_Get_out;
    rc = lot_routeID_Get( strLot_routeID_Get_out, strObjCommonIn, parentLotID );
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lot_routeID_Get() rc != RC_OK");
        strSplitWaferLotNotOnRouteReqResult.strResult = strLot_routeID_Get_out.strResult;
        return(rc);
    }
    else if (CIMFWStrLen( strLot_routeID_Get_out.routeID.identifier ) != 0)
    {
        //-----------------------------------------------------------------------------
        //  -- New Message --
        //  MSG_LOT_ONROUTE "Lot is on a %s Route process flow."
        //-----------------------------------------------------------------------------
        PPT_METHODTRACE_V1("", "lot_allState_Get() lot is on route");
//P5000145        PPT_SET_MSG_RC_KEY( strSplitWaferLotNotOnRouteReqResult, MSG_LOT_ONROUTE, RC_LOT_ONROUTE,
//P5000145                            strLot_routeID_Get_out.routeID.identifier);
        SET_MSG_RC( strSplitWaferLotNotOnRouteReqResult, MSG_LOT_ONROUTE, RC_LOT_ONROUTE );        //P5000145
        return( RC_LOT_ONROUTE );
    }

    //-----------------
    //   Change State
    //-----------------
    objLot_SplitWaferLotNotOnRoute_out strLot_SplitWaferLotNotOnRoute_out;
    rc = lot_SplitWaferLotNotOnRoute( strLot_SplitWaferLotNotOnRoute_out, strObjCommonIn,
                                      parentLotID, parentLotWaferCount, childLotWaferCount,
                                      childWaferID);
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lot_SplitWaferLotNotOnRoute() rc != RC_OK");
        strSplitWaferLotNotOnRouteReqResult.strResult = strLot_SplitWaferLotNotOnRoute_out.strResult;
        return(rc);
    }

    /*---------------------------------------*/
    /*   Update Cassette's MultiLotType      */
    /*---------------------------------------*/
    if(CIMFWStrLen( aParentCassetteID.identifier ) > 0)
    {
//DSN000071674 add start
        if ( TRUE == updateControlJobFlag )
        {
            //----------------------
            // Update control Job Info and
            // Machine Cassette info if information exist
            //----------------------
            objectIdentifierSequence tmpCassetteIDSeq;
            tmpCassetteIDSeq.length(1);
            tmpCassetteIDSeq[0] = aParentCassetteID;
            objControlJob_relatedInfo_Update_out strControlJob_relatedInfo_Update_out;
            rc = controlJob_relatedInfo_Update(strControlJob_relatedInfo_Update_out, strObjCommonIn,
                                               tmpCassetteIDSeq);
            if (rc)
            {
                PPT_METHODTRACE_V2("", "controlJob_relatedInfo_Update() != RC_OK", rc);
                strSplitWaferLotNotOnRouteReqResult.strResult = strControlJob_relatedInfo_Update_out.strResult;
                return(rc);
            }
        }
//DSN000071674 add end

        objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
        rc = cassette_multiLotType_Update( strCassette_multiLotType_Update_out, strObjCommonIn, aParentCassetteID);
        if (rc)
        {
            PPT_METHODTRACE_V1("", "cassette_multiLotType_Update() rc != RC_OK");
            strSplitWaferLotNotOnRouteReqResult.strResult = strCassette_multiLotType_Update_out.strResult;
            return(rc);
        }
    }

//PSN000081334 add start
    /*------------------------------------------------------------------------*/
    /*   Make History                                                         */
    /*------------------------------------------------------------------------*/

    objectIdentifier aLotID ; // Child Lot ID
    aLotID = strLot_SplitWaferLotNotOnRoute_out.childLotID;

    objLot_waferLotHistoryPointer_Update_out strLot_waferLotHistoryPointer_Update_out;
    rc = lot_waferLotHistoryPointer_Update(strLot_waferLotHistoryPointer_Update_out, strObjCommonIn,
                                           parentLotID);  //for Parent lot
    if (rc)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txSplitWaferLotReq", "lot_waferLotHistoryPointer_Update() rc != RC_OK");
        strSplitWaferLotNotOnRouteReqResult.strResult = strLot_waferLotHistoryPointer_Update_out.strResult ;
        SET_MSG_RC(strSplitWaferLotNotOnRouteReqResult,MSG_FAIL_MAKE_HISTORY, rc) ;
        return(rc);
    }

    rc = lot_waferLotHistoryPointer_Update(strLot_waferLotHistoryPointer_Update_out, strObjCommonIn,
                                           aLotID);  //for Child lot
    if (rc)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txSplitWaferLotReq", "lot_waferLotHistoryPointer_Update() rc != RC_OK");
        strSplitWaferLotNotOnRouteReqResult.strResult = strLot_waferLotHistoryPointer_Update_out.strResult ;
        SET_MSG_RC(strSplitWaferLotNotOnRouteReqResult,MSG_FAIL_MAKE_HISTORY, rc) ;
        return(rc);
    }
//PSN000081334 add end

//P3100069 add start
    //-----------------------------------------------------
    // Prepare input parameter of lotWaferMoveEvent_Make()
    //-----------------------------------------------------
//D9000038    objLot_waferMap_Get_out strLot_waferMap_Get_out;
//D9000038    rc = lot_waferMap_Get( strLot_waferMap_Get_out,
//D9000038                           strObjCommonIn,
//D9000038                           strLot_SplitWaferLotNotOnRoute_out.childLotID );     // for child lot
//D9000038 add start
    objLot_materials_GetWafers_out strLot_materials_GetWafers_out;
    rc = lot_materials_GetWafers( strLot_materials_GetWafers_out,
                           strObjCommonIn,
                           strLot_SplitWaferLotNotOnRoute_out.childLotID );     // for child lot
//D9000038 add end
    if (rc)
    {
//D9000038        PPT_METHODTRACE_V1("", "lot_waferMap_Get() rc != RC_OK");
//D9000038        strSplitWaferLotNotOnRouteReqResult.strResult = strLot_waferMap_Get_out.strResult ;
//D9000038 add start
        PPT_METHODTRACE_V1("", "lot_materials_GetWafers() rc != RC_OK");
        strSplitWaferLotNotOnRouteReqResult.strResult = strLot_materials_GetWafers_out.strResult ;
//D9000038 add end
        return(rc);
    }

//D9000038    CORBA::Long nLen = strLot_waferMap_Get_out.strLotWaferMap.length();
//D9000038    PPT_METHODTRACE_V2("", "# strLotWaferMap.length ", nLen );
//D9000038 add start
    CORBA::Long nLen = strLot_materials_GetWafers_out.strLotWaferAttributes.length();
    PPT_METHODTRACE_V2("", "# strLotWaferAttributes.length ", nLen );
//D9000038 add end
//D9000038    if (nLen != 0 )
    if (nLen != 0 && childWaferID.length() > 0 )  //D9000038
    {
        objLotWaferMoveEvent_Make_out strLotWaferMoveEvent_Make_out;
        pptNewLotAttributes           strNewLotAttributes;

        strNewLotAttributes.cassetteID = aParentCassetteID;
        CORBA::Long i = 0;
        strNewLotAttributes.strNewWaferAttributes.length( nLen );
        PPT_METHODTRACE_V1("", "############# MoveEvent_Make (TXTRC048) #############" );
        PPT_METHODTRACE_V2("", "# strNewLotAttributes.cassetteID                   ", strNewLotAttributes.cassetteID.identifier );
        PPT_METHODTRACE_V2("", "# strNewLotAttributes.strNewWaferAttributes.length ", nLen );
        for (i=0; i<nLen; i++)
        {
            strNewLotAttributes.strNewWaferAttributes[i].newLotID      = strLot_SplitWaferLotNotOnRoute_out.childLotID;
//P4200026            strNewLotAttributes.strNewWaferAttributes[i].newWaferID    = childWaferID[i];
//D9000038            strNewLotAttributes.strNewWaferAttributes[i].newWaferID    = strLot_waferMap_Get_out.strLotWaferMap[i].waferID;    //P4200026
//D9000038            strNewLotAttributes.strNewWaferAttributes[i].newSlotNumber = strLot_waferMap_Get_out.strLotWaferMap[i].slotNumber;
            strNewLotAttributes.strNewWaferAttributes[i].newWaferID    = strLot_materials_GetWafers_out.strLotWaferAttributes[i].waferID;    //D9000038
            strNewLotAttributes.strNewWaferAttributes[i].newSlotNumber = strLot_materials_GetWafers_out.strLotWaferAttributes[i].slotNumber; //D9000038
            strNewLotAttributes.strNewWaferAttributes[i].sourceLotID   = parentLotID;
//P4200026            strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID = childWaferID[i];
//D9000038            strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID = strLot_waferMap_Get_out.strLotWaferMap[i].waferID;    //P4200026
            strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID = strLot_materials_GetWafers_out.strLotWaferAttributes[i].waferID;    //D9000038

            PPT_METHODTRACE_V3("", "#   .newLotID      ", i, strNewLotAttributes.strNewWaferAttributes[i].newLotID.identifier );
            PPT_METHODTRACE_V3("", "#   .newWaferID    ", i, strNewLotAttributes.strNewWaferAttributes[i].newWaferID.identifier );
            PPT_METHODTRACE_V3("", "#   .newSlotNumber ", i, strNewLotAttributes.strNewWaferAttributes[i].newSlotNumber );
            PPT_METHODTRACE_V3("", "#   .sourceLotID   ", i, strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier );
            PPT_METHODTRACE_V3("", "#   .sourceWaferID ", i, strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID.identifier );
        }
        rc = lotWaferMoveEvent_Make( strLotWaferMoveEvent_Make_out, strObjCommonIn,
                                     "TXTRC048",
                                     strNewLotAttributes,
                                     claimMemo );      //for Child lot  (normalSplit)

            //  transactionID = "TXTRC048"
            //  strNewLotAttributes.cassetteID = cassetteID which is returned from lot_cassette_Get()
            //  strNewLotAttributes.pptNewWaferAttributesSequence[].newLotID = childLotID which is returned from lot_SplitWaferLotNotOnRoute()
            //  strNewLotAttributes.pptNewWaferAttributesSequence[].newWaferID = childWaferID[]
            //  strNewLotAttributes.pptNewWaferAttributesSequence[].newSlotNumber = slot number which is returned from lot_waferMap_Get()
            //  strNewLotAttributes.pptNewWaferAttributesSequence[].sourceLotID = parentLotID
            //  strNewLotAttributes.pptNewWaferAttributesSequence[].sourceWaferID = childWaferID[]
            //

        if (rc)
        {
            PPT_METHODTRACE_V1("", "lotWaferMoveEvent_Make() rc != RC_OK");
            strSplitWaferLotNotOnRouteReqResult.strResult = strLotWaferMoveEvent_Make_out.strResult;
            SET_MSG_RC( strSplitWaferLotNotOnRouteReqResult, MSG_FAIL_MAKE_HISTORY, rc );
            return(rc);
        }
    }
//P3100069 add end

    // Set childLotID of OjbLot_SplitWaferLotNotOnRoute_out to Out parameter.
    strSplitWaferLotNotOnRouteReqResult.childLotID = strLot_SplitWaferLotNotOnRoute_out.childLotID;        //P4000053

    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
    SET_MSG_RC(strSplitWaferLotNotOnRouteReqResult, MSG_OK, RC_OK ) ;

    PPT_METHODTRACE_EXIT("PPTManager_i:: txSplitWaferLotNotOnRouteReq");
    return(RC_OK);
}
