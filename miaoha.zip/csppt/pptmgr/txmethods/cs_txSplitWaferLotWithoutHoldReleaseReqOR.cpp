#ifndef lint
static char *sccsid =  "@(#) 1.2 superpos/src/spppt/source/posppt/pptmgr/txmethods/txSplitWaferLotWithoutHoldReleaseReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 8/23/07 14:35:05 [ 8/23/07 14:35:06 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: txSplitWaferLotWithoutHoldReleaseReq.cpp
//

#include "cs_pptmgr.hpp"

// Class: PPTManager
//
// Service: txSplitWaferLotWithoutHoldReleaseReq()
//
// Change history:
// Date       Defect#    Person         Comments
// ---------- ---------- -------------- -------------------------------------------
// 2005/04/13 D6000259   H.Hasegawa     Initial Release (R6.0.1)
// 2005/11/18 D7000021   M.Murata       Add : Check lot's hold state. (LOCK)
// 2005/12/14 D7000067   F.Masada       Add check logic of return operation by process_GetReturnOperation().
// 2006/04/14 D7000252   M.Kase         Add logic to check whether lot is in Backup Operation or not
// 2007/06/12 D9000005   H.Hotta        WaferSorter automation support.
// 2007/06/15 D9000038   D.Tamura       Remove In-Cassette Limitation.
// 2007/08/23 D9000056   H.Hotta        Add check logic for InPostProcessFlag.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/08 DSIV00000099 M.Ogawa        Add check logic for MachineContainerPosition.
// 2008/08/27 PSIV00000186 H.Mutoh        Fix using claim memo.
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
// 2010/03/15 DSIV00001830 S.Kawabe       Wafer Stacking Operation Support
// 2012/06/05 PSN000043987 T.Ishida       Wrong hold information is inherit to child lot on split without hold release operation.
// 2013/05/09 DSN000071674 C.Mo           Remove part of the EI state limitation
// 2014/01/21 PSN000083176 C.Mo           Data inconsistency might occur when start lot reservation is called together with lot operation transactions for the same cassette
// 2014/05/17 PSN000081348 C.Mo           ProcessHolds: Split with "Without Hold release" can't inherit the hold
// 2014/10/14 DSN000085792 K.Yamaoku      Q-Time Improvements.
// 2017/05/02 PSN000104952 C.Itoh         Split without hold release transaction does not correctly inherit userID to child lot when lot is on BankHold
//
// Description:
//   This function performs Split to a Lot whose Hold State is "ONHOLD".
//   To inherit Hold Records to Child Lot from Parent Lot is possible.
//   However Process Hold, Merge Hold, Rework Hold and so on is not so.
//   The other processes are same as txSplitWaferLotReq().
//   * If the lot is held with "LOCK", it's not performed.    //D7000021
//
// Return:
//   long
//
// Parameter:
//   pptSplitWaferLotWithoutHoldReleaseReqResult&  strSplitWaferLotWithoutHoldReleaseReqResult
//   const pptObjCommonIn&                         strObjCommonIn
//   const objectIdentifier&                       parentLotID
//   const objectIdentifierSequence&               childWaferIDs
//   CORBA::Boolean                                futureMergeFlag
//   const objectIdentifier&                       mergedRouteID
//   const char*                                   mergedOperationNumber
//   CORBA::Boolean                                branchingRouteSpecifyFlag
//   const objectIdentifier&                       subRouteID
//   const char*                                   returnOperationNumber
//   const char*                                   claimMemo
//   const pptHoldListSequence&                    strLotHoldRequests,
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long  CS_PPTManager_i::txSplitWaferLotWithoutHoldReleaseReq(
    pptSplitWaferLotWithoutHoldReleaseReqResult&  strSplitWaferLotWithoutHoldReleaseReqResult,
    const pptObjCommonIn&                         strObjCommonIn,
    const objectIdentifier&                       parentLotID,
    const objectIdentifierSequence&               childWaferIDs,
    CORBA::Boolean                                futureMergeFlag,
    const objectIdentifier&                       mergedRouteID,
    const char*                                   mergedOperationNumber,
    CORBA::Boolean                                branchingRouteSpecifyFlag,
    const objectIdentifier&                       subRouteID,
    const char*                                   returnOperationNumber,
    const char*                                   claimMemo,
    const pptHoldListSequence&                    strLotHoldRequests CORBAENV_LAST_CPP )
{
    PPT_METHODTRACE_ENTRY("PPTManager_i::txSplitWaferLotWithoutHoldReleaseReq");
    CORBA::Long  rc = RC_OK;

//D7000252 add start
    /*------------------------------------------------------------------------*/
    /*   Check Lot's Backup State                                             */
    /*------------------------------------------------------------------------*/
    objLot_backupInfo_Get_out strLot_backupInfo_Get_out;
    rc = lot_backupInfo_Get( strLot_backupInfo_Get_out, strObjCommonIn, parentLotID );
    if( rc != RC_OK )
    {
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLot_backupInfo_Get_out.strResult;
        return rc;
    }
    else if( strLot_backupInfo_Get_out.strLotBackupInfo.backupProcessingFlag == TRUE )
    {
        PPT_METHODTRACE_V1("", "##### lot's backupProcessingFlag == TRUE");
        SET_MSG_RC( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_LOT_IN_BACKUPOPERATION, RC_LOT_IN_BACKUPOPERATION );
        return RC_LOT_IN_BACKUPOPERATION;
    }
//D7000252 add end

    //===========================================================================
    // Lock for objects
    //===========================================================================
    //----- Gets Parent Lot's Cassette. -------//
    objLot_cassette_Get_out  strLot_cassette_Get_out;
    rc = lot_cassette_Get( strLot_cassette_Get_out, strObjCommonIn, parentLotID );
//D9000038    if( rc != RC_OK )
    if ( rc != RC_OK && rc != RC_NOT_FOUND_CST ) //D9000038
    {
        PPT_METHODTRACE_V1("", "cassette_lot_Get() != RC_OK");
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLot_cassette_Get_out.strResult;
        return rc;
    }
    objectIdentifier  cassetteID = strLot_cassette_Get_out.cassetteID;

//DSN000071674 add start
    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );

    CORBA::Boolean updateControlJobFlag = FALSE;
    CORBA::Long lockMode = 0; //PSN000083176

    objCassette_transferState_Get_out strCassetteTransferState;
    objObject_Lock_out strObject_Lock_out;

    if ( 0 == lotOperationEIcheck && 0 < CIMFWStrLen( cassetteID.identifier ) )
    {
        //-------------------------------
        // Get carrier transfer status
        //-------------------------------
        rc = cassette_transferState_Get(strCassetteTransferState, strObjCommonIn,
                                        cassetteID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "rc != RC_OK");
            strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strCassetteTransferState.strResult ;
            return( rc );
        }

        /*------------------------------------*/
        /*   Get equipment ID in Cassette     */
        /*------------------------------------*/
        objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
        rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                       strObjCommonIn,
                                       cassetteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "cassette_equipmentID_Get != RC_OK", rc);
            strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
            return( rc );
        }

        //-------------------------------
        // Get required equipment lock mode
        //-------------------------------
        objObject_lockMode_Get_out strObject_lockMode_Get_out;
        objObject_lockMode_Get_in  strObject_lockMode_Get_in;
        strObject_lockMode_Get_in.objectID           = strCassette_equipmentID_Get_out.equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXTRC072" ); // TxSplitWaferLotWithoutHoldReleaseReq
        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }

//PSN000083176        CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
        lockMode = strObject_lockMode_Get_out.lockMode; //PSN000083176
        PPT_METHODTRACE_V2( "", "lockMode", lockMode );

        if ( 0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) )
        {
            updateControlJobFlag = TRUE;

            if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
            {
                objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
                objAdvanced_object_Lock_in strAdvanced_object_Lock_in;

                // Lock Equipment Main Object
                stringSequence dummySeq;
                dummySeq.length(0);
                strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
                strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
                strAdvanced_object_Lock_in.keySeq     = dummySeq;

                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }

                // Lock Equipment LoadCassette Element (Write)
                stringSequence loadCastSeq;
                loadCastSeq.length(1);
                loadCastSeq[0] = cassetteID.identifier;
                strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
                strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
                strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }
            }
            else
            {
                /*--------------------------------*/
                /*   Lock Macihne object          */
                /*--------------------------------*/
                rc = object_Lock( strObject_Lock_out, strObjCommonIn, strCassette_equipmentID_Get_out.equipmentID, SP_ClassName_PosMachine );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc) ;
                    strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strObject_Lock_out.strResult ;
                    return( rc );
                }
            }
        }

//PSN000083176        if ( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176        {
//PSN000083176            //---------------------------------
//PSN000083176            //   Get Cassette's ControlJobID
//PSN000083176            //---------------------------------
//PSN000083176            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

//PSN000083176            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
//PSN000083176                                            strObjCommonIn,
//PSN000083176                                            cassetteID );
//PSN000083176            if ( rc != RC_OK )
//PSN000083176            {
//PSN000083176                PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
//PSN000083176                strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
//PSN000083176                return( rc );
//PSN000083176            }
//PSN000083176            if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
//PSN000083176            {
//PSN000083176                PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
//PSN000083176                updateControlJobFlag = TRUE;

//PSN000083176                if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176                {
//PSN000083176                    /*------------------------------*/
//PSN000083176                    /*   Lock ControlJob Object     */
//PSN000083176                    /*------------------------------*/
//PSN000083176                    rc = object_Lock( strObject_Lock_out,
//PSN000083176                                      strObjCommonIn, 
//PSN000083176                                      strCassette_controlJobID_Get_out.controlJobID, 
//PSN000083176                                      SP_ClassName_PosControlJob );
//PSN000083176                    if ( rc != RC_OK )
//PSN000083176                    {
//PSN000083176                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
//PSN000083176                        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strObject_Lock_out.strResult;
//PSN000083176                        return( rc );
//PSN000083176                    }
//PSN000083176                }
//PSN000083176            }
//PSN000083176        }
    }
//DSN000071674 add end

    //----- Lock for Cassette -------//
//DSN000071674    objObject_Lock_out  strObject_Lock_out;
    rc = object_Lock( strObject_Lock_out, strObjCommonIn, cassetteID, SP_ClassName_PosCassette );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", cassetteID.identifier);
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strObject_Lock_out.strResult;
        return rc;
    }
//PSN000083176 add start
    if ( 0 == lotOperationEIcheck && 0 < CIMFWStrLen( cassetteID.identifier ) )
    {
        if ( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
        {
            //---------------------------------
            //   Get Cassette's ControlJobID
            //---------------------------------
            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                            strObjCommonIn,
                                            cassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
                strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
                return( rc );
            }
            if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
            {
                PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
                updateControlJobFlag = TRUE;

                if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
                {
                    /*------------------------------*/
                    /*   Lock ControlJob Object     */
                    /*------------------------------*/
                    rc = object_Lock( strObject_Lock_out,
                                      strObjCommonIn, 
                                      strCassette_controlJobID_Get_out.controlJobID, 
                                      SP_ClassName_PosControlJob );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strObject_Lock_out.strResult;
                        return( rc );
                    }
                }
            }
        }
    }
//PSN000083176 add end
    //----- Lock for Parent Lot -------//
    rc = object_Lock( strObject_Lock_out, strObjCommonIn, parentLotID, SP_ClassName_PosLot );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", parentLotID.identifier);
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strObject_Lock_out.strResult;
        return rc;
    }

//D9000005 add start
    if( 0 != CIMFWStrCmp(strObjCommonIn.strUser.userID.identifier, SP_SorterWatchDog_Person) )
    {
        /*-------------------------------*/
        /*   Check SorterJob existence   */
        /*-------------------------------*/
        pptEquipmentLoadPortAttribute dummyEquipmentPortAttribute;
        objectIdentifierSequence dummyCastIDs, lotIDs;
        lotIDs.length(1);
        lotIDs[0] = parentLotID;

        objWaferSorter_sorterJob_CheckForOperation_out strWaferSorter_sorterJob_CheckForOperation_out;
        objWaferSorter_sorterJob_CheckForOperation_in  strWaferSorter_sorterJob_CheckForOperation_in;
        strWaferSorter_sorterJob_CheckForOperation_in.strEquipmentLoadPortAttribute = dummyEquipmentPortAttribute;
        strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs                   = dummyCastIDs;
        strWaferSorter_sorterJob_CheckForOperation_in.lotIDs                        = lotIDs;
        strWaferSorter_sorterJob_CheckForOperation_in.operation                     = CIMFWStrDup(SP_Operation_For_Lot);

        rc = waferSorter_sorterJob_CheckForOperation( strWaferSorter_sorterJob_CheckForOperation_out,
                                                      strObjCommonIn,
                                                      strWaferSorter_sorterJob_CheckForOperation_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "waferSorter_sorterJob_CheckForOperation() != RC_OK" );
            strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strWaferSorter_sorterJob_CheckForOperation_out.strResult;
            return( rc );
        }
    }
//D9000005 add end


    //===========================================================================
    // Check for conditions
    //===========================================================================

//D7000067 add start
    /*------------------------------------------------------------------------*/
    /*   Check SubRouteID and return operation                                */
    /*------------------------------------------------------------------------*/
    if ( CIMFWStrLen(subRouteID.identifier) > 0 ) // if subRouteID is specified, check it.
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(subRouteID.identifier) > 0" );

        objProcess_checkForDynamicRoute_out strProcess_checkForDynamicRoute_out;
        rc = process_checkForDynamicRoute( strProcess_checkForDynamicRoute_out, strObjCommonIn, subRouteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "process_checkForDynamicRoute() != RC_OK", rc);
            strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strProcess_checkForDynamicRoute_out.strResult;
            return(rc);
        }

        if ( strProcess_checkForDynamicRoute_out.bDynamicRoute != TRUE )  // if subRouteID is not dynamic route, check the return operation.
        {
            PPT_METHODTRACE_V1("", "strProcess_checkForDynamicRoute_out.bDynamicRoute != TRUE" );

            objProcess_GetReturnOperation_out strProcess_GetReturnOperation_out;
            rc = process_GetReturnOperation( strProcess_GetReturnOperation_out, strObjCommonIn, parentLotID, subRouteID );

            if (rc == RC_OK)
            {
                if ( CIMFWStrLen( returnOperationNumber ) >0  &&
                     CIMFWStrCmp( strProcess_GetReturnOperation_out.operationNumber, returnOperationNumber) != 0 )
                {
                    PPT_METHODTRACE_V1("","return RC_INVALID_INPUT_PARM");
                    SET_MSG_RC( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
                    return RC_INVALID_INPUT_PARM;
                }
            }
            else   // Error case and RC_NOT_FOUND_SUBROUTE
            {
                PPT_METHODTRACE_V2("", "process_GetReturnOperation() != RC_OK : ", rc) ;
                strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strProcess_GetReturnOperation_out.strResult ;
                return(rc);
            }
        }
    }
//D7000067 add end

    //-----------------------------------------------------------
    // Check for combination of Return Point and Merge Point
    //-----------------------------------------------------------
    objProcess_CheckSplit_out  strProcess_CheckSplit_out;
    rc = process_CheckSplit( strProcess_CheckSplit_out, strObjCommonIn, mergedRouteID, mergedOperationNumber, returnOperationNumber );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "process_CheckSplit() != RC_OK");
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strProcess_CheckSplit_out.strResult;
        return rc;
    }

    //-----------------------------------------------------------
    // Check for consistency of Sub Route
    //-----------------------------------------------------------
    //----- Gets Parent Lot's Current Route. -------//
    objLot_currentRouteID_Get_out  strLot_currentRouteID_Get_out;
    rc = lot_currentRouteID_Get( strLot_currentRouteID_Get_out, strObjCommonIn, parentLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_currentRouteID_Get() != RC_OK");
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLot_currentRouteID_Get_out.strResult;
        return rc;
    }

    //----- Check for Current Route : It should not be same as Sub Route. -------//
    if( CIMFWStrCmp( strLot_currentRouteID_Get_out.currentRouteID.identifier, subRouteID.identifier ) == 0 )
    {
        PPT_METHODTRACE_V2("", "Sub Route is Invalid !!!", subRouteID.identifier);
        SET_MSG_RC( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_INVALID_BRANCH_ROUTEID, RC_INVALID_BRANCH_ROUTEID );
        return RC_INVALID_BRANCH_ROUTEID;
    }

    //----- Gets Parent Lot's Original Route. -------//
    objLot_originalRouteList_Get_out  strLot_originalRouteList_Get_out;
    rc = lot_originalRouteList_Get( strLot_originalRouteList_Get_out, strObjCommonIn, parentLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_originalRouteList_Get() != RC_OK");
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLot_originalRouteList_Get_out.strResult;
        return rc;
    }

    //----- Check for Original Route : It should not be same as Sub Route. -------//
    CORBA::Long originalRouteLen = strLot_originalRouteList_Get_out.originalRouteID.length();
    for( CORBA::Long  routeCnt = 0; routeCnt < originalRouteLen; routeCnt++ )
    {
        if( CIMFWStrCmp( strLot_originalRouteList_Get_out.originalRouteID[routeCnt].identifier, subRouteID.identifier ) == 0 )
        {
            PPT_METHODTRACE_V2("", "Sub Route is Invalid !!!", subRouteID.identifier);
            SET_MSG_RC( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_INVALID_BRANCH_ROUTEID, RC_INVALID_BRANCH_ROUTEID );
            return RC_INVALID_BRANCH_ROUTEID;
        }
    }

    //-----------------------------------------------------------
    // Check for contents of Parent Lot
    //-----------------------------------------------------------
    //----- Gets Parent Lot's contents. -------//
    objLot_contents_Get_out  strLot_contents_Get_out;
    rc = lot_contents_Get( strLot_contents_Get_out, strObjCommonIn, parentLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_contents_Get() != RC_OK");
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLot_contents_Get_out.strResult;
        return rc;
    }

    //----- Check for contents : It should be "Wafer" or "Die". -------//
    if( CIMFWStrCmp( strLot_contents_Get_out.theLotContents, SP_ProdType_Wafer ) != 0 &&
        CIMFWStrCmp( strLot_contents_Get_out.theLotContents, SP_ProdType_Die   ) != 0   )
    {
        PPT_METHODTRACE_V2("", "Lot's contents is Invalid !!!", strLot_contents_Get_out.theLotContents);
        PPT_SET_MSG_RC_KEY( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_INVALID_LOT_CONTENTS, RC_INVALID_LOT_CONTENTS, parentLotID.identifier );
        return RC_INVALID_LOT_CONTENTS;
    }

    //-----------------------------------------------------------
    // Check for each state of Parent Lot
    //-----------------------------------------------------------
    //----- Gets Parent Lot's all state. -------//
    objLot_allState_Get_out  strLot_allState_Get_out;
    rc = lot_allState_Get( strLot_allState_Get_out, strObjCommonIn, parentLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() != RC_OK");
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLot_allState_Get_out.strResult;
        return rc;
    }

    //----- Check for Lot State : It should not be "SHIPPED". -------//
    if( CIMFWStrCmp( strLot_allState_Get_out.lotState, CIMFW_Lot_State_Shipped ) == 0 )
    {
        PPT_METHODTRACE_V2("", "Lot State is Invalid !!!", strLot_allState_Get_out.lotState);
        PPT_SET_MSG_RC_KEY( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_INVALID_LOT_STAT, RC_INVALID_LOT_STAT, strLot_allState_Get_out.lotState );
        return RC_INVALID_LOT_STAT;
    }
    //----- Check for Lot Hold State : It should be "ONHOLD". -------//
    if( CIMFWStrCmp( strLot_allState_Get_out.holdState, CIMFW_Lot_HoldState_OnHold ) != 0 )
    {
        PPT_METHODTRACE_V2("", "Lot Hold State is Invalid !!!", strLot_allState_Get_out.holdState);
        PPT_SET_MSG_RC_KEY( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_LOT_NOT_HELD, RC_LOT_NOT_HELD, parentLotID.identifier );
        return RC_LOT_NOT_HELD;
    }
//D7000021 add start
    //---- But, the lot should not be held by "LOCK". -----//
    PPT_METHODTRACE_V1("", "Check LOCK Hold. ");
    objectIdentifierSequence lotIDSeq;
    lotIDSeq.length(1);
    lotIDSeq[0] = parentLotID;
    objLot_CheckLockHoldConditionForOperation_out  strLot_CheckLockHoldConditionForOperation_out;
    rc = lot_CheckLockHoldConditionForOperation( strLot_CheckLockHoldConditionForOperation_out, strObjCommonIn, lotIDSeq );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "lot_CheckLockHoldConditionForOperation rc != RC_OK", lotIDSeq[0].identifier );
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLot_CheckLockHoldConditionForOperation_out.strResult;
        return ( rc );
    }
//D7000021 add end
    //----- Check for Lot Finished State : It should not be "SCRAPPED" or "EMPTIED". -------//
    if( CIMFWStrCmp( strLot_allState_Get_out.finishedState, CIMFW_Lot_FinishedState_Scrapped ) == 0 ||
        CIMFWStrCmp( strLot_allState_Get_out.finishedState, SP_LOT_FINISHED_STATE_STACKED ) == 0 ||     //DSIV00001830
        CIMFWStrCmp( strLot_allState_Get_out.finishedState, CIMFW_Lot_FinishedState_Emptied  ) == 0   )
    {
        PPT_METHODTRACE_V2("", "Lot Finished State is Invalid !!!", strLot_allState_Get_out.finishedState);
        PPT_SET_MSG_RC_KEY( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_INVALID_LOT_FINISHSTAT, RC_INVALID_LOT_FINISHSTAT,
                            strLot_allState_Get_out.finishedState );
        return RC_INVALID_LOT_FINISHSTAT;
    }
    //----- Check for Lot Process State : It should not be "Processing". -------//
    if( CIMFWStrCmp( strLot_allState_Get_out.processState, SP_Lot_ProcState_Processing ) == 0 )
    {
        PPT_METHODTRACE_V2("", "Lot Process State is Invalid !!!", strLot_allState_Get_out.processState);
        PPT_SET_MSG_RC_KEY2( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_INVALID_LOT_PROCSTAT, RC_INVALID_LOT_PROCSTAT,
                             parentLotID.identifier, strLot_allState_Get_out.processState );
        return RC_INVALID_LOT_PROCSTAT;
    }

//D7000252 add start
    //-----------------------------------------------------------
    // Check for hold record inheritance from Parent Lot
    //-----------------------------------------------------------
    //----- Check for Lot Inventory State : If it is "NonProBank", the hold record that the reason code is "NPBH" should be inherited. -------//
    if( CIMFWStrCmp( strLot_allState_Get_out.inventoryState, SP_Lot_InventoryState_NonProBank ) == 0 )
    {
        PPT_METHODTRACE_V1("", "Lot's inventory state is 'NonProBank'. So, hold record inheritance is checked.")

        CORBA::Long holdRequestsLen = strLotHoldRequests.length();
        for( CORBA::Long holdRequestsCnt = 0; holdRequestsCnt < holdRequestsLen; holdRequestsCnt++ )
        {
            if( CIMFWStrCmp( strLotHoldRequests[holdRequestsCnt].holdReasonCodeID.identifier, SP_Reason_NonProBankHold ) == 0 )
            {
                PPT_METHODTRACE_V1("", "Hold record that the reason code is 'NPBH' is inherited from Parent Lot.");
                break;
            }
        }

        if( holdRequestsCnt == holdRequestsLen )
        {
            PPT_METHODTRACE_V1("", "Hold record that the reason code is 'NPBH' is not inherited from Parent Lot.");
            SET_MSG_RC( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }
    }
//D7000252 add end

//D9000056 add start
    //------------------------------------
    //  Check InPostProcessFlag of Lot
    //------------------------------------
    PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");

    //----- Get Parent Lot's InPostProcessFlag. -------//
    objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
    objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
    strLot_inPostProcessFlag_Get_in.lotID = parentLotID;

    rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                    strObjCommonIn,
                                    strLot_inPostProcessFlag_Get_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
        return( rc );
    }

    //----- Check for InPostProcessFlag : It should be OFF. -------//
    if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
    {
        PPT_METHODTRACE_V1("", "Lot is in post process.");
//DSIV00000201 Add Start
        /*---------------------------*/
        /* Get UserGroupID By UserID */
        /*---------------------------*/
        objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
        rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                         strObjCommonIn,
                                         strObjCommonIn.strUser.userID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
            strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
            return( rc );
        }
        objectIdentifierSequence userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
        CORBA::ULong userGroupIDsLen = userGroupIDs.length();
        PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);

        CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
        PPT_METHODTRACE_V2("", "extPostProc", extPostProc);

        CORBA::ULong nCnt = 0;
        for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
        {
            PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
            if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
            {
                PPT_METHODTRACE_V1("", "# External Post Process User!");
                break;
            }

        }
        if (nCnt == userGroupIDsLen)
        {
            PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
            PPT_SET_MSG_RC_KEY( strSplitWaferLotWithoutHoldReleaseReqResult,
                                MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                parentLotID.identifier );
            return( RC_LOT_INPOSTPROCESS );
        }   //DSIV00000201
    }
//D9000056 add end

    //-----------------------------------------------------------
    // Check for Flow Batch condition of Parent Lot
    //-----------------------------------------------------------
    //----- Gets Parent Lot's Flow Batch ID. -------//
    objLot_flowBatchID_Get_out  strLot_flowBatchID_Get_out;
    rc = lot_flowBatchID_Get( strLot_flowBatchID_Get_out, strObjCommonIn, parentLotID );

    //----- Check for Flow Batch ID : It should not exist. -------//
    if ( rc == RC_LOT_FLOW_BATCH_ID_FILLED )
    {
        PPT_METHODTRACE_V2("", "Lot Flow Batch condition is Invalid !!!", strLot_flowBatchID_Get_out.flowBatchID.identifier);
        SET_MSG_RC( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_FLOW_BATCH_LIMITATION, RC_FLOW_BATCH_LIMITATION );
        return RC_FLOW_BATCH_LIMITATION;
    }
    else if( rc == RC_OK || rc == RC_LOT_FLOW_BATCH_ID_BLANK )
    {
        PPT_METHODTRACE_V1("", "Lot doesn't belong to Flow Batch.") ;
    }
    else
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() != RC_OK") ;
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLot_flowBatchID_Get_out.strResult;
        return rc;
    }

//DSIV00001830 add start
    //-------------------------
    // Check Bonding Group
    //-------------------------
    objLot_bondingGroupID_GetDR_in  strLot_bondingGroupID_GetDR_in;
    strLot_bondingGroupID_GetDR_in.lotID = parentLotID;

    objLot_bondingGroupID_GetDR_out strLot_bondingGroupID_GetDR_out;
    rc = lot_bondingGroupID_GetDR( strLot_bondingGroupID_GetDR_out, strObjCommonIn, strLot_bondingGroupID_GetDR_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2( "", "lot_bondingGroupID_GetDR() != RC_OK", rc );
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLot_bondingGroupID_GetDR_out.strResult;
        return rc;
    }
    if ( CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0");
        PPT_SET_MSG_RC_KEY2( strSplitWaferLotWithoutHoldReleaseReqResult,
                             MSG_LOT_HAS_BONDINGGROUP,
                             RC_LOT_HAS_BONDINGGROUP,
                             strLot_bondingGroupID_GetDR_in.lotID.identifier,
                             strLot_bondingGroupID_GetDR_out.bondingGroupID );
        return RC_LOT_HAS_BONDINGGROUP;
    }
//DSIV00001830 add end
//DSIV00000099 add start
    /*------------------------------------------------------------------------*/
    /*   Check if the wafers in lot don't have machine container position     */
    /*------------------------------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call equipmentContainerPosition_info_GetByLotDR()");
    objEquipmentContainerPosition_info_GetByLotDR_out strEquipmentContainerPosition_info_GetByLotDR_out;
    objEquipmentContainerPosition_info_GetByLotDR_in  strEquipmentContainerPosition_info_GetByLotDR_in;
    strEquipmentContainerPosition_info_GetByLotDR_in.lotID = parentLotID;
    rc = equipmentContainerPosition_info_GetByLotDR( strEquipmentContainerPosition_info_GetByLotDR_out,
                                                     strObjCommonIn,
                                                     strEquipmentContainerPosition_info_GetByLotDR_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipmentContainerPosition_info_GetByLotDR() != RC_OK", rc);
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strEquipmentContainerPosition_info_GetByLotDR_out.strResult;
        return ( rc );
    }

    CORBA::Long lenEqpContPos = strEquipmentContainerPosition_info_GetByLotDR_out.strEqpContainerPositionSeq.length();
    PPT_METHODTRACE_V2("", "lenEqpContPos", lenEqpContPos);
    if ( 0 < lenEqpContPos )
    {
        PPT_METHODTRACE_V1("", "Some wafers contained in this lot have equipment container positions.");
        PPT_SET_MSG_RC_KEY( strSplitWaferLotWithoutHoldReleaseReqResult,
                            MSG_WAFER_IN_LOT_HAVE_CONTAINER_POSITION, RC_WAFER_IN_LOT_HAVE_CONTAINER_POSITION,
                            parentLotID.identifier );
        return( RC_WAFER_IN_LOT_HAVE_CONTAINER_POSITION );
    }
//DSIV00000099 add end

    //-----------------------------------------------------------
    // Check for Control Job of Parent Lot
    //-----------------------------------------------------------
    //----- Gets Parent Lot's Control Job. -------//
    objLot_controlJobID_Get_out  strLot_controlJobID_Get_out;
    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, parentLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_controlJobID_Get() != RC_OK");
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLot_controlJobID_Get_out.strResult;
        return rc;
    }

    //----- Check for Control Job : It should not exist. -------//
    if( CIMFWStrLen( strLot_controlJobID_Get_out.controlJobID.identifier ) > 0 )
    {
        PPT_METHODTRACE_V2("", "Lot Control Job condition is Invalid !!!", strLot_controlJobID_Get_out.controlJobID.identifier);
        PPT_SET_MSG_RC_KEY2( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_LOT_CTLJOBID_FILLED, RC_LOT_CTLJOBID_FILLED,
                             parentLotID.identifier, strLot_controlJobID_Get_out.controlJobID.identifier );
        return RC_LOT_CTLJOBID_FILLED;
    }

    //-----------------------------------------------------------
    // Check for Future Hold Request of Parent Lot
    //-----------------------------------------------------------
    objLot_futureHoldRequests_CheckSplit_out  strLot_futureHoldRequests_CheckSplit;
    rc = lot_futureHoldRequests_CheckSplit( strLot_futureHoldRequests_CheckSplit, strObjCommonIn,
                                            parentLotID, mergedOperationNumber, returnOperationNumber );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_futureHoldRequests_CheckSplit() != RC_OK");
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLot_futureHoldRequests_CheckSplit.strResult;
        return rc;
    }

    //-----------------------------------------------------------
    // Check for Xfer State of Cassette
    //-----------------------------------------------------------
    //----- Gets Cassette's Xfer State. -------//
    objCassette_transferState_Get_out  strCassette_transferState_Get_out;
//D9000038 add start
    if( CIMFWStrLen( cassetteID.identifier ) > 0)
    {
//D9000038 add end
//DSN000071674 add start
        PPT_METHODTRACE_V1("", "CIMFWStrLen( cassetteID.identifier ) > 0");
        if ( 1 == lotOperationEIcheck
        || ( 0 == lotOperationEIcheck && 0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) ) )
        {
//DSN000071674 add end
            rc = cassette_transferState_Get( strCassette_transferState_Get_out, strObjCommonIn, cassetteID );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "cassette_transferState_Get() != RC_OK");
                strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strCassette_transferState_Get_out.strResult;
                return rc;
            }

//DSN000071674 add start
            if ( 0 == lotOperationEIcheck )
            {
                PPT_METHODTRACE_V1("", "lotOperationEIcheck = 0");
                if ( 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) )                                                     //D4100091
                {
                    PPT_METHODTRACE_V1("","Changed to EI by other operation");
                    strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strCassette_transferState_Get_out.strResult ;
                    PPT_SET_MSG_RC_KEY(strSplitWaferLotWithoutHoldReleaseReqResult, MSG_CHANGED_TO_EI_BY_OTHER_OPERATION, RC_CHANGED_TO_EI_BY_OTHER_OPERATION,
                                       cassetteID.identifier);
                    return( RC_CHANGED_TO_EI_BY_OTHER_OPERATION );
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "lotOperationEIcheck = 1");
//DSN000071674 add end
                //----- Check for Xfer State : It should not be "BO" and "EI". -------//
                if( CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_BayOut ) == 0          ||
                    ( CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn ) == 0 &&
                      CIMFWStrCmp( strObjCommonIn.transactionID,                    "TXTRC004"                ) != 0 &&       //TXTRC004:TxOpeCompWithDataReq
                      CIMFWStrCmp( strObjCommonIn.transactionID,                    "TXTRC055"                ) != 0   ) )    //TXTRC055:TxOpeCompForInternalBufferReq
                {
                    PPT_METHODTRACE_V2("", "Xfer State is Invalid !!!", strCassette_transferState_Get_out.transferState);
                    PPT_SET_MSG_RC_KEY2( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_INVALID_CAST_XFERSTAT, RC_INVALID_CAST_XFERSTAT,
                                         strCassette_transferState_Get_out.transferState, cassetteID.identifier );
                    return RC_INVALID_CAST_XFERSTAT;
                }
//DSN000071674 add start
            }
        }
        if ( 0 == lotOperationEIcheck )
        {
            strCassette_transferState_Get_out = strCassetteTransferState;
        }
//DSN000071674 add end
//D9000038 add start
    }
    else
    {
        PPT_METHODTRACE_V1("PPTManager_i::txSplitWaferLotWithoutHoldReleaseReq", "The cassetteID is empty. Skip cassette_transferState_Get().");
    }
//D9000038 add end

//DSN000071674 add start
    if ( 1 == lotOperationEIcheck )
    {
        PPT_METHODTRACE_V1("", "lotOperationEIcheck = 1");
//DSN000071674 add end
        //-----------------------------------------------------------
        // Check for Dispatch State of Cassette
        //-----------------------------------------------------------
        //----- Gets Cassette's Dispatch State. -------//
//D9000038 add start
        if( CIMFWStrLen( cassetteID.identifier ) > 0)
        {
//D9000038 add end
            objCassette_dispatchState_Get_out  strCassette_dispatchState_Get_out;
            strCassette_dispatchState_Get_out.dispatchReservedFlag = FALSE;
            rc = cassette_dispatchState_Get( strCassette_dispatchState_Get_out, strObjCommonIn, cassetteID );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "cassette_dispatchState_Get() != RC_OK");
                strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strCassette_dispatchState_Get_out.strResult;
                return rc;
            }

            //----- Check for Dispatch State : It should not be dispatched. -------//
            if( strCassette_dispatchState_Get_out.dispatchReservedFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "Dispatch State is Invalid!!! Cassette is dispatched.");
                SET_MSG_RC( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_ALREADY_DISPATCH_RESVED_CST, RC_ALREADY_DISPATCH_RESVED_CST );
                return RC_ALREADY_DISPATCH_RESVED_CST;
            }
//D9000038 add start
        }
        else
        {
            PPT_METHODTRACE_V1("PPTManager_i::txSplitWaferLotWithoutHoldReleaseReq", "The cassetteID is empty. Skip cassette_dispatchState_Get().");
        }
//D9000038 add end
    } //DSN000071674

    //-----------------------------------------------------------
    // Check for Reserve State of Cassette
    //-----------------------------------------------------------
    //----- Gets Cassette's Reserve State. -------//
//D9000038 add start
    if( CIMFWStrLen( cassetteID.identifier ) > 0)
    {
//D9000038 add end
        objCassette_reservedState_Get_out  strCassette_reservedState_Get_out;
        strCassette_reservedState_Get_out.transferReserved = FALSE;
        rc = cassette_reservedState_Get( strCassette_reservedState_Get_out, strObjCommonIn, cassetteID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cassette_reservedState_Get() != RC_OK");
            strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strCassette_reservedState_Get_out.strResult;
            return rc;
        }

        //----- Check for Reserve State : It should not be reserved. -------//
        if( strCassette_reservedState_Get_out.transferReserved == TRUE )
        {
            PPT_METHODTRACE_V1("", "Reserved State is Invalid!!! Cassette is reserved to transfer.");
            SET_MSG_RC( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_ALREADY_RESERVED_CST, RC_ALREADY_RESERVED_CST );
            return RC_ALREADY_RESERVED_CST;
        }
//D9000038 add start
    }
    else
    {
        PPT_METHODTRACE_V1("PPTManager_i::txSplitWaferLotWithoutHoldReleaseReq", "The cassetteID is empty. Skip cassette_reservedState_Get().");
    }
//D9000038 add end

    //-----------------------------------------------------------
    // Check for consistency of Hold Requests
    //-----------------------------------------------------------
    CORBA::Long  requestLen = strLotHoldRequests.length();
//D7000252    if( requestLen > 0 && CIMFWStrCmp( strLot_allState_Get_out.lotState, CIMFW_Lot_State_Active ) != 0 )
//D7000252    {
//D7000252        PPT_METHODTRACE_V1("", "Child Lot will not be ACTIVE, so any Hold records cannot be inherited from Parent Lot.");
//D7000252        SET_MSG_RC( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_HOLDRECORD_INHERITANCE_INVALID, RC_HOLDRECORD_INHERITANCE_INVALID );
//D7000252        return RC_HOLDRECORD_INHERITANCE_INVALID;
//D7000252    }
//PSN000081348 Add Start
    CORBA::Long processHoldAllowLotMovement = atoi( getenv(SP_PROCESSHOLD_ALLOW_LOTMOVEMENT) );
    CORBA::Boolean inheritProcessHold = FALSE;
    CORBA::ULong procHoldReqLen = 0;
    CORBA::ULong holdReqWithoutProcHoldLen = 0;
    pptHoldListSequence procHoldReq;
    pptHoldListSequence holdReqWithoutProcHold;
    procHoldReq.length(requestLen);
    holdReqWithoutProcHold.length(requestLen);
//PSN000081348 Add End

    for( CORBA::Long  requestCnt = 0; requestCnt < requestLen; requestCnt++ )
    {
        if( CIMFWStrCmp( strLotHoldRequests[requestCnt].holdType, SP_HoldType_ProcessHold ) == 0 )
        {
            if ( processHoldAllowLotMovement == 0 ) //PSN000081348
            { //PSN000081348
                PPT_METHODTRACE_V1("", "Process Hold cannot be inherited.");
                PPT_SET_MSG_RC_KEY4( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_HOLDRECORD_CANNOT_INHERIT, RC_HOLDRECORD_CANNOT_INHERIT,
                                     strLotHoldRequests[requestCnt].holdType, strLotHoldRequests[requestCnt].holdReasonCodeID.identifier,
                                     strLotHoldRequests[requestCnt].holdUserID.identifier, strLotHoldRequests[requestCnt].relatedLotID.identifier );
                return RC_HOLDRECORD_CANNOT_INHERIT;
            } //PSN000081348
            inheritProcessHold = TRUE; //PSN000081348
            procHoldReq[procHoldReqLen++] = strLotHoldRequests[requestCnt]; //PSN000081348
        }
        else if( CIMFWStrLen( strLotHoldRequests[requestCnt].relatedLotID.identifier ) > 0 )
        {
            PPT_METHODTRACE_V1("", "Merge Hold, Rework Hold and so on cannot be inherited.");
            PPT_SET_MSG_RC_KEY4( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_HOLDRECORD_CANNOT_INHERIT, RC_HOLDRECORD_CANNOT_INHERIT,
                                 strLotHoldRequests[requestCnt].holdType, strLotHoldRequests[requestCnt].holdReasonCodeID.identifier,
                                 strLotHoldRequests[requestCnt].holdUserID.identifier, strLotHoldRequests[requestCnt].relatedLotID.identifier );
            return RC_HOLDRECORD_CANNOT_INHERIT;
        }
        else
        {
            PPT_METHODTRACE_V1("", "Inherited Hold Request");
            PPT_METHODTRACE_V3("", strLotHoldRequests[requestCnt].holdType, strLotHoldRequests[requestCnt].holdReasonCodeID.identifier,
                                   strLotHoldRequests[requestCnt].holdUserID.identifier);
            holdReqWithoutProcHold[holdReqWithoutProcHoldLen++] = strLotHoldRequests[requestCnt]; //PSN000081348
        }
    }
    procHoldReq.length(procHoldReqLen); //PSN000081348
    holdReqWithoutProcHold.length(holdReqWithoutProcHoldLen); //PSN000081348
    PPT_METHODTRACE_V2( "", "ProcessHold Request length", procHoldReqLen ); //PSN000081348
    PPT_METHODTRACE_V2( "", "Hold Request Without ProcessHold length", holdReqWithoutProcHoldLen ); //PSN000081348

    //PSN000043987 Add Start
    //---------------------------
    // Get the lot's hold list.
    //---------------------------
    PPT_METHODTRACE_V2( "", "Get the lot's hold list. ", parentLotID.identifier );

    objLot_FillInTxTRQ005DR_out strLot_FillInTxTRQ005DR_out;
    rc = lot_FillInTxTRQ005DR( strLot_FillInTxTRQ005DR_out, strObjCommonIn, parentLotID );

    if( rc != RC_OK && rc != RC_NOT_FOUND_ENTRY )
    {
        PPT_METHODTRACE_V1( "", "lot_FillInTxTRQ005DR() != RC_OK" );
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLot_FillInTxTRQ005DR_out.strResult;
        return ( rc ) ;
    }

    CORBA::Long inheritLen = 0;
    inheritLen = strLotHoldRequests.length();

    if( rc == RC_OK )
    {
        //---------------------------
        // Check Inherit Hold Record
        //---------------------------
        CORBA::Long holdLen = 0;
        CORBA::Boolean existFlag = FALSE;

        holdLen = strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes.length();

        PPT_METHODTRACE_V2( "", "strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes.length()", holdLen );

        for( CORBA::Long inheritCnt=0; inheritCnt<inheritLen; inheritCnt++ )
        {
            existFlag = FALSE;
            for( CORBA::Long holdCnt=0; holdCnt<holdLen; holdCnt++ )
            {
                if( ( CIMFWStrCmp( strLotHoldRequests[inheritCnt].holdType,                    strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes[holdCnt].holdType ) == 0 ) &&
                    ( CIMFWStrCmp( strLotHoldRequests[inheritCnt].holdReasonCodeID.identifier, strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes[holdCnt].reasonCodeID.identifier ) == 0 ) &&
                    ( CIMFWStrCmp( strLotHoldRequests[inheritCnt].holdUserID.identifier,       strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes[holdCnt].userID.identifier ) == 0 ) &&
                    ( CIMFWStrCmp( strLotHoldRequests[inheritCnt].relatedLotID.identifier,     strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes[holdCnt].relatedLotID.identifier ) == 0 ) )
                {
                    PPT_METHODTRACE_V5( "", "Hold Record Exist!", strLotHoldRequests[inheritCnt].holdType, strLotHoldRequests[inheritCnt].holdReasonCodeID.identifier, strLotHoldRequests[inheritCnt].holdUserID.identifier, strLotHoldRequests[inheritCnt].relatedLotID.identifier );
                    existFlag = TRUE;
                    break;
                }
            }

            if( existFlag == FALSE )
            {
                PPT_METHODTRACE_V5( "", "Hold Record Not Exist! Cannot be inherited", strLotHoldRequests[inheritCnt].holdType, strLotHoldRequests[inheritCnt].holdReasonCodeID.identifier, strLotHoldRequests[inheritCnt].holdUserID.identifier, strLotHoldRequests[inheritCnt].relatedLotID.identifier );

                PPT_SET_MSG_RC_KEY4( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_HOLDRECORD_CANNOT_INHERIT, RC_HOLDRECORD_CANNOT_INHERIT,
                                     strLotHoldRequests[inheritCnt].holdType, strLotHoldRequests[inheritCnt].holdReasonCodeID.identifier,
                                     strLotHoldRequests[inheritCnt].holdUserID.identifier, strLotHoldRequests[inheritCnt].relatedLotID.identifier );
                return RC_HOLDRECORD_CANNOT_INHERIT;
            }
        }
    }
    else
    {
        if( inheritLen > 0 )
        {
            PPT_SET_MSG_RC_KEY4( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_HOLDRECORD_CANNOT_INHERIT, RC_HOLDRECORD_CANNOT_INHERIT,
                                 strLotHoldRequests[0].holdType, strLotHoldRequests[0].holdReasonCodeID.identifier,
                                 strLotHoldRequests[0].holdUserID.identifier, strLotHoldRequests[0].relatedLotID.identifier );
            return RC_HOLDRECORD_CANNOT_INHERIT;
        }
    }
    //PSN000043987 Add End

    //===========================================================================
    // Change for objects
    //===========================================================================
    //-----------------------------------------------------------
    // Creates Child Lot
    //-----------------------------------------------------------
    objLot_SplitWaferLot_out  strLot_SplitWaferLot_out ;
    rc = lot_SplitWaferLot( strLot_SplitWaferLot_out, strObjCommonIn, parentLotID, childWaferIDs );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_SplitWaferLot() != RC_OK");
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLot_SplitWaferLot_out.strResult;
        return rc;
    }
    objectIdentifier  childLotID = strLot_SplitWaferLot_out.childLotID;
    strSplitWaferLotWithoutHoldReleaseReqResult.childLotID = strLot_SplitWaferLot_out.childLotID;

    //----- Updates History Time Stamp to Parent Lot : Those data are used in Event. -------//
    objLot_waferLotHistoryPointer_Update_out  strLot_waferLotHistoryPointer_Update_out;
    rc = lot_waferLotHistoryPointer_Update( strLot_waferLotHistoryPointer_Update_out, strObjCommonIn, parentLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_waferLotHistoryPointer_Update() != RC_OK");
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLot_waferLotHistoryPointer_Update_out.strResult;
        return rc;
    }

    //----- Updates History Time Stamp to Child Lot : Those data are used in Event. -------//
    rc = lot_waferLotHistoryPointer_Update( strLot_waferLotHistoryPointer_Update_out, strObjCommonIn, childLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_waferLotHistoryPointer_Update() != RC_OK");
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLot_waferLotHistoryPointer_Update_out.strResult;
        return rc;
    }

    //----- Prepares data of Split Event. -------//
//D9000038    objLot_waferMap_Get_out  strLot_waferMap_Get_out;
//D9000038    rc = lot_waferMap_Get( strLot_waferMap_Get_out, strObjCommonIn, childLotID );
//D9000038 add start
    objLot_materials_GetWafers_out strLot_materials_GetWafers_out;
    rc = lot_materials_GetWafers(  strLot_materials_GetWafers_out, strObjCommonIn, childLotID );
//D9000038 add end
    if( rc != RC_OK )
    {
//D9000038        PPT_METHODTRACE_V1("", "lot_waferMap_Get() != RC_OK");
//D9000038        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLot_waferMap_Get_out.strResult;
//D9000038 add start
        PPT_METHODTRACE_V1("", "lot_materials_GetWafers() != RC_OK");
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLot_materials_GetWafers_out.strResult;
//D9000038 add end
        return rc;
    }
//D9000038    CORBA::Long  waferLen = strLot_waferMap_Get_out.strLotWaferMap.length();
    CORBA::Long  waferLen = strLot_materials_GetWafers_out.strLotWaferAttributes.length();  //D9000038

    //----- Makes Split Event. -------//
    pptNewLotAttributes  strNewLotAttributes;
    strNewLotAttributes.cassetteID = cassetteID;
    strNewLotAttributes.strNewWaferAttributes.length( waferLen );
    for( CORBA::Long  waferCnt = 0; waferCnt < waferLen; waferCnt++ )
    {
        strNewLotAttributes.strNewWaferAttributes[waferCnt].newLotID      = childLotID;
//D9000038        strNewLotAttributes.strNewWaferAttributes[waferCnt].newWaferID    = strLot_waferMap_Get_out.strLotWaferMap[waferCnt].waferID;
//D9000038        strNewLotAttributes.strNewWaferAttributes[waferCnt].newSlotNumber = strLot_waferMap_Get_out.strLotWaferMap[waferCnt].slotNumber;
        strNewLotAttributes.strNewWaferAttributes[waferCnt].newWaferID    = strLot_materials_GetWafers_out.strLotWaferAttributes[waferCnt].waferID;   //D9000038
        strNewLotAttributes.strNewWaferAttributes[waferCnt].newSlotNumber = strLot_materials_GetWafers_out.strLotWaferAttributes[waferCnt].slotNumber;//D9000038
        strNewLotAttributes.strNewWaferAttributes[waferCnt].sourceLotID   = parentLotID;
//D9000038        strNewLotAttributes.strNewWaferAttributes[waferCnt].sourceWaferID = strLot_waferMap_Get_out.strLotWaferMap[waferCnt].waferID;
        strNewLotAttributes.strNewWaferAttributes[waferCnt].sourceWaferID = strLot_materials_GetWafers_out.strLotWaferAttributes[waferCnt].waferID;   //D9000038
    }

    objLotWaferMoveEvent_Make_out  strLotWaferMoveEvent_Make_out;
    rc = lotWaferMoveEvent_Make( strLotWaferMoveEvent_Make_out, strObjCommonIn, "TXTRC072", strNewLotAttributes, claimMemo );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lotWaferMoveEvent_Make() != RC_OK");
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLotWaferMoveEvent_Make_out.strResult;
        return rc;
    }

//PSN000081348 Add Start
    //-----------------------------------------------------------
    // Performs Process Hold to Child Lot
    //-----------------------------------------------------------
    if ( inheritProcessHold == TRUE )
    {
        pptHoldLotReqResult strProcessHoldLotReqResult;
        rc = txHoldLotReq( strProcessHoldLotReqResult, strObjCommonIn, childLotID, procHoldReq );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK" );
            strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strProcessHoldLotReqResult.strResult;
            return rc;
        }
    }
//PSN000081348 Add End

    //-----------------------------------------------------------
    // Performs Branch to Child Lot
    //-----------------------------------------------------------
    if( branchingRouteSpecifyFlag == TRUE )
    {
//DSN000085792 Add start
        objQTime_CheckConditionForReplaceTarget_in strQTime_CheckConditionForReplaceTarget_in;
        objQTime_CheckConditionForReplaceTarget_out strQTime_CheckConditionForReplaceTarget_out;
        strQTime_CheckConditionForReplaceTarget_in.lotID = childLotID;
        rc = qTime_CheckConditionForReplaceTarget(strQTime_CheckConditionForReplaceTarget_out,strObjCommonIn,strQTime_CheckConditionForReplaceTarget_in);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "qTime_CheckConditionForReplaceTarget() != RC_OK") ;
            strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strQTime_CheckConditionForReplaceTarget_out.strResult ;
            return rc ;
        }
//DSN000085792 Add end

        objProcess_BranchRoute_out  strProcess_BranchRoute_out;
        rc = process_BranchRoute( strProcess_BranchRoute_out, strObjCommonIn, childLotID, subRouteID, returnOperationNumber );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "process_BranchRoute() != RC_OK");
            strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strProcess_BranchRoute_out.strResult;
            return rc;
        }

//DSN000085792 Add Start
        //--------------------------------------------------------------------------------------------------
        // Replace Target Operation for sub route
        //--------------------------------------------------------------------------------------------------
        objQTime_targetOpe_Replace_out strQTime_targetOpe_Replace_out;
        objQTime_targetOpe_Replace_in  strQTime_targetOpe_Replace_in;
        strQTime_targetOpe_Replace_in.lotID               = childLotID;
        strQTime_targetOpe_Replace_in.specificControlFlag = FALSE;
        rc = qTime_targetOpe_Replace( strQTime_targetOpe_Replace_out,
                                      strObjCommonIn,
                                      strQTime_targetOpe_Replace_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "qTime_targetOpe_Replace() != RC_OK", rc);
            strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strQTime_targetOpe_Replace_out.strResult;
            return rc;
        }
//DSN000085792 Add End

        //----- Makes Branch Event. -------//
        objLotOperationMoveEvent_MakeBranch_out  strLotOperationMoveEvent_MakeBranch_out;
        rc = lotOperationMoveEvent_MakeBranch( strLotOperationMoveEvent_MakeBranch_out, strObjCommonIn, "TXTRC072", childLotID,
                                               strProcess_BranchRoute_out.oldCurrentPOData, claimMemo );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lotOperationMoveEvent_MakeBranch() rc != RC_OK");
            strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLotOperationMoveEvent_MakeBranch_out.strResult;
            return rc;
        }
    }

    //-----------------------------------------------------------
    // Performs Merge Hold
    //-----------------------------------------------------------
    objectIdentifier reasonCodeID;
    reasonCodeID.identifier = CIMFWStrDup( SP_Reason_MergeHold );

    //----- Creates Merge Hold Request if Merge Point is specified. -------//
    if( futureMergeFlag == TRUE )
    {
        //----- Creates Merge Hold Request of Parent Lot -------//
        pptEnhancedFutureHoldReqResult  strEnhancedFutureHoldReqResult;
        rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult, strObjCommonIn, SP_HoldType_MergeHold, parentLotID,
                                      mergedRouteID, mergedOperationNumber, reasonCodeID, childLotID, FALSE, FALSE, NULL );
        // rc = txEnhancedFutureHoldReq( returnStructure, commonInfo, holdType, lotID,
        //                               routeID, operationNumber, reasonCodeID, relatedLotID, postFlag, singleTriggerFlag, claimMemo );
        if( rc != RC_OK && rc != RC_DUPLICATE_FTHOLD_ENTRY )
        {
            PPT_METHODTRACE_V1("", "txEnhancedFutureHoldReq() != RC_OK")
            strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strEnhancedFutureHoldReqResult.strResult;
            return rc;
        }

        //----- Creates Merge Hold Request of Child Lot -------//
        rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult, strObjCommonIn , SP_HoldType_MergeHold, childLotID,
                                      mergedRouteID, mergedOperationNumber, reasonCodeID, parentLotID, FALSE, FALSE, NULL );
        // rc = txEnhancedFutureHoldReq( returnStructure, commonInfo, holdType, lotID,
        //                               routeID, operationNumber, reasonCodeID, relatedLotID, postFlag, singleTriggerFlag, claimMemo );
        if( rc != RC_OK && rc != RC_DUPLICATE_FTHOLD_ENTRY )
        {
            PPT_METHODTRACE_V1("", "txEnhancedFutureHoldReq() != RC_OK")
            strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strEnhancedFutureHoldReqResult.strResult;
            return rc;
        }
    }

    //----- Performs Merge Hold Request to Lot on Merge Point. -------//
    objProcess_CompareCurrent_out  strProcess_CompareCurrent_out;
    rc = process_CompareCurrent( strProcess_CompareCurrent_out, strObjCommonIn, parentLotID, mergedRouteID, mergedOperationNumber );
    if( rc == RC_CURRENTOPERATION_SAME )
    {
        //----- Performs Merge Hold Request to Parent Lot -------//
        pptHoldListSequence  strMergeHoldRequests;
        strMergeHoldRequests.length( 1 );
        strMergeHoldRequests[0].holdType                 = CIMFWStrDup( SP_HoldType_MergeHold );
        strMergeHoldRequests[0].holdReasonCodeID         = reasonCodeID;
        strMergeHoldRequests[0].holdUserID               = strObjCommonIn.strUser.userID;
        strMergeHoldRequests[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Current );
        strMergeHoldRequests[0].routeID                  = mergedRouteID;
        strMergeHoldRequests[0].operationNumber          = CIMFWStrDup( mergedOperationNumber );
        strMergeHoldRequests[0].relatedLotID             = childLotID;
//PSIV00000186        strMergeHoldRequests[0].claimMemo                = CIMFWStrDup( claimMemo );
        strMergeHoldRequests[0].claimMemo                = CIMFWStrDup( "" );    //PSIV00000186

        pptHoldLotReqResult  strHoldLotReqResult;
        rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, parentLotID, strMergeHoldRequests );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK");
            strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strHoldLotReqResult.strResult;
            return rc;
        }

        if( branchingRouteSpecifyFlag == FALSE )
        {
            //----- Performs Merge Hold Request to Child Lot -------//
            strMergeHoldRequests[0].holdType                 = CIMFWStrDup( SP_HoldType_MergeHold );
            strMergeHoldRequests[0].holdReasonCodeID         = reasonCodeID;
            strMergeHoldRequests[0].holdUserID               = strObjCommonIn.strUser.userID;
            strMergeHoldRequests[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Current );
            strMergeHoldRequests[0].routeID                  = mergedRouteID;
            strMergeHoldRequests[0].operationNumber          = CIMFWStrDup( mergedOperationNumber );
            strMergeHoldRequests[0].relatedLotID             = parentLotID;
//PSIV00000186            strMergeHoldRequests[0].claimMemo                = CIMFWStrDup( claimMemo );
            strMergeHoldRequests[0].claimMemo                = CIMFWStrDup( "" );    //PSIV00000186

            rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, childLotID, strMergeHoldRequests );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK");
                strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strHoldLotReqResult.strResult;
                return rc;
            }
        }
    }
    else if( rc == RC_OK || rc == RC_CURRENTOPERATION_EARLY || rc == RC_CURRENTOPERATION_LATE )
    {
        PPT_METHODTRACE_V1("", "Parent Lot doesn't locate on Merge Point.");
    }
    else
    {
        PPT_METHODTRACE_V1("", "process_CompareCurrent() != RC_OK");
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strProcess_CompareCurrent_out.strResult;
        return rc;
    }

    //-----------------------------------------------------------
    // Performs Process Hold to Child Lot
    //-----------------------------------------------------------
    if( branchingRouteSpecifyFlag == TRUE ) //PSN000081348
    { //PSN000081348
        pptProcessHoldExecReqResult  strProcessHoldExecReqResult;
        rc = txProcessHoldExecReq( strProcessHoldExecReqResult, strObjCommonIn, childLotID, claimMemo );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","txProcessHoldExecReq() != RC_OK" );
            strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strProcessHoldExecReqResult.strResult;
            return rc;
        }
    } //PSN000081348

    //-----------------------------------------------------------
    // Inherits Hold Records to Child Lot
    //-----------------------------------------------------------
//PSN000081348    if( strLotHoldRequests.length() > 0 )
    if( holdReqWithoutProcHold.length() > 0 ) //PSN000081348
    {
//D7000252 add start
        if( CIMFWStrCmp( strLot_allState_Get_out.inventoryState, SP_Lot_InventoryState_InBank ) == 0 )
        {
            PPT_METHODTRACE_V1("", "Lot's inventory state is 'InBank'. So, txHoldBankLotReq() is called.")

            pptHoldBankLotReqResult strHoldBankLotReqResult;
            strHoldBankLotReqResult.strHoldBankLotResult.length(1);
            CORBA::Long lotSeqLen = 0;
            objectIdentifierSequence lotIDs;
            lotIDs.length(1);
            lotIDs[0] = childLotID;
//PSN000104952 add start
            pptObjCommonIn tmpObjCommonIn;
            tmpObjCommonIn = strObjCommonIn;
            tmpObjCommonIn.strUser.userID = holdReqWithoutProcHold[0].holdUserID;
//PSN000104952 add end
            rc = txHoldBankLotReq( strHoldBankLotReqResult,
//PSN000104952                                   strObjCommonIn,
                                   tmpObjCommonIn, //PSN000104952
                                   lotSeqLen,
                                   lotIDs,
//PSN000081348                                   strLotHoldRequests[0].holdReasonCodeID,
                                   holdReqWithoutProcHold[0].holdReasonCodeID,
//PSIV00000186                                   claimMemo );
//PSN000081348                                   strLotHoldRequests[0].claimMemo );    //PSIV00000186
                                   holdReqWithoutProcHold[0].claimMemo ); //PSN000081348
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("","txHoldBankLotReq() != RC_OK" );
                strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strHoldBankLotReqResult.strResult;
                return rc;
            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "Lot's inventory state is not 'InBank'. So, txHoldLotReq() is called.")

//D7000252 add end
        pptHoldLotReqResult  strHoldLotReqResult_inheritance;
//PSN000081348        rc = txHoldLotReq( strHoldLotReqResult_inheritance, strObjCommonIn, childLotID, strLotHoldRequests );
            rc = txHoldLotReq( strHoldLotReqResult_inheritance, strObjCommonIn, childLotID, holdReqWithoutProcHold ); //PSN000081348
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK" );
            strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strHoldLotReqResult_inheritance.strResult;
            return rc;
        }
        }    //D7000252
    }

    //-----------------------------------------------------------
    // Updates Cassette's Multi Lot Type
    //-----------------------------------------------------------
//D9000038 add start
    if( CIMFWStrCmp( cassetteID.identifier, "") != 0 )
    {
//D9000038 add end
        objCassette_multiLotType_Update_out  strCassette_multiLotType_Update_out;
        rc = cassette_multiLotType_Update( strCassette_multiLotType_Update_out, strObjCommonIn, cassetteID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cassette_multiLotType_Update() != RC_OK");
            strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strCassette_multiLotType_Update_out.strResult;
            return rc;
        }
//D9000038 add start
    }
    else
    {
        PPT_METHODTRACE_V1("PPTManager_i::txSplitWaferLotWithoutHoldReleaseReq", "The cassetteID is empty. Skip cassette_multiLotType_Update().");
    }
//D9000038 add end

    //-----------------------------------------------------------
    // Updates Child Lot's Required Cassette Category
    //-----------------------------------------------------------
    objLot_CassetteCategory_UpdateForContaminationControl_out   strLot_CassetteCategory_UpdateForContaminationControl_out;
    rc = lot_CassetteCategory_UpdateForContaminationControl( strLot_CassetteCategory_UpdateForContaminationControl_out, strObjCommonIn, childLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","lot_CassetteCategory_UpdateForContaminationControl != RC_OK");
        strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strLot_CassetteCategory_UpdateForContaminationControl_out.strResult;
        return rc;
    }

    //-----------------------------------------------------------
    // Updates Equipment's Cassette/Lot data etc.
    //-----------------------------------------------------------
//D9000038 add start
    if( CIMFWStrLen( cassetteID.identifier ) > 0)
    {
//D9000038 add end
//DSN000071674        if( CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn ) == 0 )
//DSN000071674 add start
        if ( TRUE == updateControlJobFlag
          || 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) )
//DSN000071674 add end
        {
            objectIdentifierSequence  cassetteIDs;
            cassetteIDs.length( 1 );
            cassetteIDs[0] = cassetteID;

            objControlJob_relatedInfo_Update_out  strControlJob_relatedInfo_Update_out;
            rc = controlJob_relatedInfo_Update( strControlJob_relatedInfo_Update_out, strObjCommonIn, cassetteIDs );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "controlJob_relatedInfo_Update() != RC_OK");
                strSplitWaferLotWithoutHoldReleaseReqResult.strResult = strControlJob_relatedInfo_Update_out.strResult;
                return rc;
            }
        }
//D9000038 add start
    }
    else
    {
        PPT_METHODTRACE_V1("PPTManager_i::txSplitWaferLotWithoutHoldReleaseReq", "The cassetteID is empty. Skip controlJob_relatedInfo_Update().");
    }
//D9000038 add end

    SET_MSG_RC( strSplitWaferLotWithoutHoldReleaseReqResult, MSG_OK, RC_OK );
    PPT_METHODTRACE_EXIT("PPTManager_i::txSplitWaferLotWithoutHoldReleaseReq");
    return RC_OK;
}
