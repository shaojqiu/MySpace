#ifndef lint
static char *sccsid =  "@(#) 1.3 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txLotReQueueReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 8/3/07 14:23:15 [ 8/3/07 14:23:16 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: cs_txLotReQueueReqOR.cpp
//

#include "cs_pptmgr.hpp"
#include "pcas.hh"
#include "pctrlj.hh"

// Class: CS_PPTManager
//
// Service: txLotReQueueReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2002/02/14 D4100120 N.Minami       Initial Release
// 2002/06/11 P4100536 T.Nishimura    Source Check : Wrong reference to dimension.
// 2002/07/04 P4200025 T.Nishimura    Source Check : return without message.
// 2002/08/21 D4200062 K.Kido         Change for backupOperation(Rel4.2)
// 2002/10/08 D4200039 H.Adachi       Replace Direct FW Calling.
// 2002/10/23 P4200271 K.Kido         Add : Check lot's inventry state.
// 2003/09/09 P5000145 H.Adachi       Fix Message and Message Macro mismatch.
// 2003/12/09 P5100060 H.Adachi       Set Original Route and Operaiton information for lot_ChangeSchedule() calling.
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2005/11/09 D7000026 K.Kido         Delete unnecessary methods. (lot_GetInfoDR ==> lot_detailInfo_GetDR)
// 2005/11/18 D7000021 M.Murata       Add : Check lot's hold state. (LOCK)
// 2006/10/20 D8000028 K.Kido         Change cassette_representLot_Get ==> cassette_lotList_GetWithPriorityOrder
// 2006/10/26 D7000354 H.Hasegawa     Add the logic which resets Q-Time actions
// 2007/08/03 D9000056 H.Hotta        Add check logic for InPostProcessFlag.
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/30 DSIV00000214 K.Kido         Multi Fab Transfer Support
// 2010/03/15 DSIV00001830 S.Kawabe       Wafer Stacking Operation Support
// 2010/11/02 DSIV00002435 M.Ogawa        Support SubLotType change by Schedule Change Reservation
// 2011/05/26 PSIV00003236 Li.Seal        Object Lock mechanism is lack, and it caused production Lot issue.
// 2011/10/21 DSN000022151 Qiang Wen      Q-Time clearance control
// 2013/05/09 DSN000071674 C.Mo           Remove part of the EI state limitation
// 2014/05/13 DSN000085698 S.Wang         Support equipment monitor used count function
// 2015/11/11 DSN000096135 XF.Ming        lot_detailInfo_GetDR__150 ==> lot_detailInfo_GetDR__160
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/08/28 INN-R170002  Yangxiaojun    Overide txLotReQueueReq
//
// [Function Description]:
//  Get ScheduleChangeReservationList by ScheduleChangeReservation's Data Members.
//
// [Input Parameters]:
//  pptLotReQueueReqResult&               strLotReQueueReqResult,
//  const pptObjCommonIn&                 strObjCommonIn
//  const pptLotReQueueAttributeSequence& strLotReQueueAttributes
//  const char *                          claimMemo
//
//  typedef struct pptLotReQueueAttribute_struct
//  {
//    objectIdentifier lotID;
//    objectIdentifier productID;
//    objectIdentifier routeID;
//    string           currentOperationNumber;
//    any siInfo;
//  } pptLotReQueueAttribute;
//
//  typedef sequence <pptLotReQueueAttribute> pptLotReQueueAttributeSequence;
//
// [Output Parameters]:
//  typedef struct pptLotReQueueReqResult_struct {
//    pptRetCode      strResult;
//    pptLotReQueueReturnSequence strLotReQueueReturn;
//    any siInfo;
//  } pptLotReQueueReqResult;
//
//  typedef struct pptLotReQueueReturn_struct {
//    objectIdentifier lotID;
//    string          returnCode;
//    any siInfo;
//  } pptLotReQueueReturn;
//
//  typedef sequence <pptLotReQueueReturn> pptLotReQueueReturnSequence;
//
// [Return Value]:
//   Return Code                 Message ID
//   --------------------------- -------------------------------------
//   RC_OK                       MSG_OK
//
// [Pseudo code]:
//

#include "pptmgr.hpp"

CORBA::Long CS_PPTManager_i::txLotReQueueReq (pptLotReQueueReqResult&               strLotReQueueReqResult,
                                           const pptObjCommonIn&                 strObjCommonIn,
                                           const pptLotReQueueAttributeSequence& strLotReQueueAttributes,
//D6000025                                            const char *                          claimMemo,
//D6000025                                            CORBA::Environment&                   IT_env)
                                           const char *                          claimMemo //D6000025
                                           CORBAENV_LAST_CPP)                              //D6000025

{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txLotReQueueReq") ;
    CORBA::Long rc = RC_OK ;

    CORBA::Long nLen = strLotReQueueAttributes.length();
    PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "strLotReQueueAttributes.length()",nLen) ;

    //P4100536 add start
    // Check length of In-Parameter
    if(nLen > strLotReQueueReqResult.strLotReQueueReturn.length())
    {
        SET_MSG_RC(strLotReQueueReqResult, MSG_INVALID_PARAMETER, RC_INVALID_PARAMETER); //P4200025 add
        return RC_INVALID_PARAMETER;
    }
    //P4100536 add end

//PSIV00003236 add start
    //--------------------------------
    //   Lock objects to be updated
    //--------------------------------
    for (CORBA::Long iCntL=0; iCntL < nLen; iCntL++)
    {
        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn,strLotReQueueAttributes[iCntL].lotID, SP_ClassName_PosLot );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() rc != RC_OK", rc);
            strLotReQueueReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    }
//PSIV00003236 add end

    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );  //DSN000071674

    char * methodName = NULL;
    objectIdentifier lotID;
    objectIdentifier cassetteID;

    for (CORBA::Long iCnt=0; iCnt < nLen; iCnt++)
    {
        lotID = strLotReQueueAttributes[iCnt].lotID;
        PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "lotID ",lotID.identifier)

//DSN000071674 add start
        if ( 0 == lotOperationEIcheck )
        {
            //----------------------------------
            //   Check Lot's Control Job ID
            //----------------------------------
            objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
            rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, lotID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "lot_controlJobID_Get() != RC_OK", rc);
                strLotReQueueReqResult.strResult = strLot_controlJobID_Get_out.strResult;
                return( rc );
            }
            if ( 0 == CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) )
            {
                PPT_METHODTRACE_V1("", "strLot_controlJobID_Get_out.controlJobID.identifier == 0");
            }
            else
            {
                PPT_METHODTRACE_V1("", "strLot_controlJobID_Get_out.controlJobID.identifier != 0");
                PPT_SET_MSG_RC_KEY2( strLotReQueueReqResult,
                                     MSG_LOT_CTLJOBID_FILLED,
                                     RC_LOT_CTLJOBID_FILLED,
                                     lotID.identifier,
                                     strLot_controlJobID_Get_out.controlJobID.identifier );
                return RC_LOT_CTLJOBID_FILLED;
            }
        }
        else
        {
//DSN000071674 add end
            objLot_cassette_Get_out strLot_cassette_Get_out;
            rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, lotID);

            if (rc == RC_OK)
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i::txLotReQueueReq", "lot_cassette_Get() == RC_OK") ;
                cassetteID = strLot_cassette_Get_out.cassetteID ;

//D4200039 Add Start
                //------------------------------
                // Check Cassette Xfer Stat
                //------------------------------
                CORBA::String_var strCassetteXferState;
                objCassette_transferState_Get_out strCassette_transferState_Get_out;

                rc = cassette_transferState_Get(strCassette_transferState_Get_out,strObjCommonIn ,cassetteID);

                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "rc != RC_OK")
                    strLotReQueueReqResult.strResult = strCassette_transferState_Get_out.strResult;
                    return(rc);
                }
                strCassetteXferState = strCassette_transferState_Get_out.transferState;

                PPT_METHODTRACE_V2("", "CassetteXferStatus id", strCassetteXferState );

                if( 0 == CIMFWStrCmp(strCassetteXferState, SP_TransState_EquipmentIn) )
                {
                    PPT_METHODTRACE_V1("", "##### strCassetteXferState == SP_TransState_EquipmentIn");
                    PPT_SET_MSG_RC_KEY2( strLotReQueueReqResult,
                                         MSG_INVALID_CAST_XFERSTAT,
                                         RC_INVALID_CAST_XFERSTAT,
                                         strCassetteXferState,
                                         cassetteID.identifier );
                    return RC_INVALID_CAST_XFERSTAT;
                }

                //---------------------------------
                //   Get Cassette's ControlJobID
                //---------------------------------
                objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

                rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                                strObjCommonIn,
                                                cassetteID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
                    strLotReQueueReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
                    return( rc );
                }

                if ( CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) > 0 )
                {
                    PPT_METHODTRACE_V1( "", "len(controlJobID) > 0" );
                    SET_MSG_RC( strLotReQueueReqResult,
                                MSG_CAST_CTRLJOBID_FILLED,
                                RC_CAST_CTRLJOBID_FILLED );

                    return RC_CAST_CTRLJOBID_FILLED;
                }
                else
                {
                    PPT_METHODTRACE_V1("", "strCassette_controlJobID_Get_out.controlJobID.identifier is nil") ;
                }
            }
        } //DSN000071674
    }
//D4200039 Add End

//D4200039            PosCassette_var aPosCassette;
//D4200039            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aPosCassette, cassetteID,
//D4200039                                                   strLotReQueueReqResult, txLotReQueueReq );
//D4200039
//D4200039            if ( ! CORBA::is_nil( aPosCassette ) )
//D4200039            {
//D4200039                PPT_METHODTRACE_V1("CS_PPTManager_i::txLotReQueueReq", "aPosCassette is not nil");
//D4200039
//D4200039                /*----------------------*/
//D4200039                /*   check XferStetus   */
//D4200039                /*----------------------*/
//D4200039                PPT_METHODTRACE_V1("CS_PPTManager_i::txLotReQueueReq", "-----------check XferStetus-----------");
//D4200039                CORBA::String_var strCassetteXferState;
//D4200039                try
//D4200039                {
//D4200039                    strCassetteXferState = aPosCassette->getTransportState();
//D4200039                }
//D4200039                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)
//D4200039
//D4200039                PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "strCassetteXferState--->", strCassetteXferState);
//D4200039                if( 0 == CIMFWStrCmp(strCassetteXferState, SP_TransState_EquipmentIn) )
//D4200039                {
//D4200039                    PPT_METHODTRACE_V1("CS_PPTManager_i::txLotReQueueReq", "##### strCassetteXferState == SP_TransState_EquipmentIn");
//D4200039                    PPT_SET_MSG_RC_KEY2( strLotReQueueReqResult,
//D4200039                                         MSG_INVALID_CAST_XFERSTAT,
//D4200039                                         RC_INVALID_CAST_XFERSTAT,
//D4200039                                         strCassetteXferState,
//D4200039                                         cassetteID.identifier );
//D4200039
//D4200039                    strLotReQueueReqResult.strLotReQueueReturn[iCnt].returnCode = ConvertLongtoString(RC_INVALID_CAST_XFERSTAT) ;        //P4000090
//D4200039                    return RC_INVALID_CAST_XFERSTAT;
//D4200039                }
//D4200039
//D4200039                /*------------------------*/
//D4200039                /*   check controlJobID   */
//D4200039                /*------------------------*/
//D4200039                PPT_METHODTRACE_V1("CS_PPTManager_i::txLotReQueueReq", "-----------check controlJobID-----------");
//D4200039                PosControlJob_var aPosControlJob;
//D4200039                try
//D4200039                {
//D4200039                    aPosControlJob = aPosCassette->getControlJob();
//D4200039                }
//D4200039                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)
//D4200039
//D4200039                if ( ! CORBA::is_nil(aPosControlJob) )
//D4200039                {
//D4200039                    PPT_METHODTRACE_V1("CS_PPTManager_i::txLotReQueueReq", "##### aPosControlJob is not nil");
//D4200039
//D4200039                    SET_MSG_RC( strLotReQueueReqResult,
//D4200039                                MSG_CAST_CTRLJOBID_FILLED,
//D4200039                                RC_CAST_CTRLJOBID_FILLED );
//D4200039
//D4200039                    strLotReQueueReqResult.strLotReQueueReturn[iCnt].returnCode = ConvertLongtoString(RC_CAST_CTRLJOBID_FILLED) ;        //P4000090
//D4200039                    return RC_CAST_CTRLJOBID_FILLED;
//D4200039                }
//D4200039                else
//D4200039                {
//D4200039                    PPT_METHODTRACE_V1("CS_PPTManager_i::txLotReQueueReq", "aPosControlJob is nil");
//D4200039                }
//D4200039            }
//D4200039            else
//D4200039            {
//D4200039                PPT_METHODTRACE_V1("CS_PPTManager_i::txLotReQueueReq", "aPosCassette is nil") ;
//D4200039            }
//D4200039        }
//D4200039    }

//D7000021 add start
    //------------------------------------
    // Check LOCK Hold.
    //------------------------------------
    PPT_METHODTRACE_V1("", "Check LOCK Hold. ");
    for(CORBA::Long loopCnt = 0; loopCnt<nLen; loopCnt++)
    {
//DSIV00000214 add start
        //----------------------------------
        //  Check lot InterFabXfer state
        //----------------------------------
        PPT_METHODTRACE_V2("", "call lot_interFabXferState_Get()", strLotReQueueAttributes[loopCnt].lotID.identifier);
        objLot_interFabXferState_Get_out strLot_interFabXferState_Get_out;

        objLot_interFabXferState_Get_in  strLot_interFabXferState_Get_in;
        strLot_interFabXferState_Get_in.lotID = strLotReQueueAttributes[loopCnt].lotID;

        rc = lot_interFabXferState_Get( strLot_interFabXferState_Get_out,
                                        strObjCommonIn,
                                        strLot_interFabXferState_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", " #### lot_interFabXferState_Get() != RC_OK", rc);
            strLotReQueueReqResult.strResult = strLot_interFabXferState_Get_out.strResult;
            return (rc);
        }

        if( 0 == CIMFWStrCmp(strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Required ))
        {
            PPT_METHODTRACE_V1("", "##### The Lot interFabXfer state is required... No need to check LOCK Hold. ");
            continue;
        }
//DSIV00000214 add end
        objectIdentifierSequence lotIDSeq;
        lotIDSeq.length(1);
        lotIDSeq[0] = strLotReQueueAttributes[loopCnt].lotID;
        objLot_CheckLockHoldConditionForOperation_out  strLot_CheckLockHoldConditionForOperation_out;
        rc = lot_CheckLockHoldConditionForOperation( strLot_CheckLockHoldConditionForOperation_out, strObjCommonIn, lotIDSeq );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_CheckLockHoldConditionForOperation rc != RC_OK", lotIDSeq[0].identifier );
            strLotReQueueReqResult.strResult                               = strLot_CheckLockHoldConditionForOperation_out.strResult;
            strLotReQueueReqResult.strLotReQueueReturn[loopCnt].returnCode = ConvertLongtoString(rc);
            return ( rc );
        }
    }
//D7000021 add end

//D9000056 add start
    //------------------------------------
    //  Check InPostProcessFlag
    //------------------------------------
    PPT_METHODTRACE_V1("", "Check LOCK Hold. ");

//DSIV00000201 Add Start
    objectIdentifierSequence userGroupIDs;
    userGroupIDs.length(0);
    CORBA::ULong userGroupIDsLen = userGroupIDs.length();

//DSIV00000201 Add End
    for( loopCnt = 0; loopCnt < nLen; loopCnt++ )
    {
        //----------------------------------
        //  Get InPostProcessFlag of Lot
        //----------------------------------
        objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
        objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
        strLot_inPostProcessFlag_Get_in.lotID = strLotReQueueAttributes[loopCnt].lotID;

        rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                        strObjCommonIn,
                                        strLot_inPostProcessFlag_Get_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
            strLotReQueueReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
            strLotReQueueReqResult.strLotReQueueReturn[loopCnt].returnCode = ConvertLongtoString( rc );
            return( rc );
        }

//DSIV00000214 add start
        //----------------------------------
        //  Check lot InterFabXfer state
        //----------------------------------
        PPT_METHODTRACE_V2("", "call lot_interFabXferState_Get()", strLotReQueueAttributes[loopCnt].lotID.identifier);

        objLot_interFabXferState_Get_out strLot_interFabXferState_Get_out;

        objLot_interFabXferState_Get_in  strLot_interFabXferState_Get_in;
        strLot_interFabXferState_Get_in.lotID = strLotReQueueAttributes[loopCnt].lotID;

        rc = lot_interFabXferState_Get( strLot_interFabXferState_Get_out,
                                        strObjCommonIn,
                                        strLot_interFabXferState_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "##### lot_interFabXferState_Get() != RC_OK", rc);
            strLotReQueueReqResult.strResult = strLot_interFabXferState_Get_out.strResult;
            return (rc);
        }
//DSIV00000214 add end

        //----------------------------------------------
        //  If Lot is in post process, returns error
        //----------------------------------------------
        if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
        {
            PPT_METHODTRACE_V1("", "Lot is in post process.");
//DSIV00000214 add start
            if( 0 == CIMFWStrCmp(strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Required ))
            {
                PPT_METHODTRACE_V1("", " #### The Lot interFabXfer state is required... No need to check post process flag. ");
                continue;
            }
//DSIV00000214 add end
//DSIV00000201 Add Start
            if (userGroupIDsLen == 0)
            {
                /*---------------------------*/
                /* Get UserGroupID By UserID */
                /*---------------------------*/
                objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
                rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                                 strObjCommonIn,
                                                 strObjCommonIn.strUser.userID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
                    strLotReQueueReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
                    return( rc );
                }
                userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
                userGroupIDsLen = userGroupIDs.length();
                PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);
            }
            CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
            PPT_METHODTRACE_V2("", "extPostProc", extPostProc);

            CORBA::ULong nCnt = 0;
            for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
            {
                PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
                if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
                {
                    PPT_METHODTRACE_V1("", "# External Post Process User!");
                    break;
                }

            }
            if (nCnt == userGroupIDsLen)
            {
                PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
                PPT_SET_MSG_RC_KEY( strLotReQueueReqResult,
                                    MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                    strLotReQueueAttributes[loopCnt].lotID.identifier );
                strLotReQueueReqResult.strLotReQueueReturn[loopCnt].returnCode = ConvertLongtoString( RC_LOT_INPOSTPROCESS );
                return( RC_LOT_INPOSTPROCESS );
            }   //DSIV00000201

        }
    }
//D9000056 add end

    for (CORBA::Long seqIx = 0; seqIx < nLen; seqIx++)
    {
        strLotReQueueReqResult.strLotReQueueReturn[seqIx].lotID = strLotReQueueAttributes[seqIx].lotID;
        /*------------------------------------------------------------------------*/
        /*   Check Lot Process State                                              */
        /*------------------------------------------------------------------------*/
        objLot_processState_Get_out strLot_processState_Get_out;
        rc = lot_processState_Get(strLot_processState_Get_out,strObjCommonIn, strLotReQueueAttributes[seqIx].lotID );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "lot_processState_Get() != RC_OK", seqIx) ;
            strLotReQueueReqResult.strResult =  strLot_processState_Get_out.strResult ;
            strLotReQueueReqResult.strLotReQueueReturn[seqIx].returnCode = ConvertLongtoString(rc);
            return(rc);
        }
        else if (CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Waiting) != 0 )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Waiting) != 0", seqIx) ;
            PPT_SET_MSG_RC_KEY2( strLotReQueueReqResult,
                                 MSG_INVALID_LOT_PROCSTAT,
                                 RC_INVALID_LOT_PROCSTAT,
                                 strLotReQueueAttributes[seqIx].lotID.identifier,
                                 strLot_processState_Get_out.theLotProcessState ) ;
            strLotReQueueReqResult.strLotReQueueReturn[seqIx].returnCode = ConvertLongtoString(RC_INVALID_LOT_PROCSTAT) ;
            return(RC_INVALID_LOT_PROCSTAT);
        }

//DSIV00001830 add start
        /*------------------------------------------------------------------------*/
        /*   Check Finished State of lot                                          */
        /*------------------------------------------------------------------------*/
        objLot_finishedState_Get_out strLot_finishedState_Get_out;
        rc = lot_finishedState_Get(strLot_finishedState_Get_out, strObjCommonIn, strLotReQueueAttributes[seqIx].lotID);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_finishedState_Get() != RC_OK" );
            strLotReQueueReqResult.strResult = strLot_finishedState_Get_out.strResult;
            return rc;
        }
        else if( CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,SP_LOT_FINISHED_STATE_STACKED) == 0 )
        {
            PPT_METHODTRACE_V1("", "CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,SP_LOT_FINISHED_STATE_STACKED) == 0");
            continue;
        }
//DSIV00001830 add end

//P4200271 add start
        /*------------------------------------------------------------------------*/
        /*   Check Lot Inventory State                                            */
        /*------------------------------------------------------------------------*/
        if( (CIMFWStrLen(strLotReQueueAttributes[seqIx].routeID.identifier)     > 0)  &&
            (CIMFWStrLen(strLotReQueueAttributes[seqIx].currentOperationNumber) > 0) )
        {
            objLot_inventoryState_Get_out strLot_inventoryState_Get_out ;
            rc = lot_inventoryState_Get( strLot_inventoryState_Get_out, strObjCommonIn,
                                         strLotReQueueAttributes[seqIx].lotID ) ;
            if (rc != RC_OK)
            {
                strLotReQueueReqResult.strResult = strLot_inventoryState_Get_out.strResult ;
                return( rc );
            }
            else if ( CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState, SP_Lot_InventoryState_OnFloor) != 0 )
            {
                PPT_SET_MSG_RC_KEY2( strLotReQueueReqResult,
                                     MSG_INVALID_LOT_INVENTORYSTAT,
                                     RC_INVALID_LOT_INVENTORYSTAT,
                                     strLotReQueueAttributes[seqIx].lotID.identifier,
                                     strLot_inventoryState_Get_out.lotInventoryState );
                return(RC_INVALID_LOT_INVENTORYSTAT);
            }
        }
//P4200271 add end

//D4100120 Add
        /*----------------------------------------------*/
        /*   Get RouteID,OperationID,ProductID for Lot  */
        /*----------------------------------------------*/
//D7000026        objLot_GetInfoDR_out strLot_GetInfoDR_out;
//D7000026        rc = lot_GetInfoDR ( strLot_GetInfoDR_out,
//D7000026                             strObjCommonIn,
//D7000026                             strLotReQueueAttributes[seqIx].lotID,
//D7000026                             False,
//D7000026                             False,
//D7000026                             False,
//D7000026                             False,
//D7000026                             True,
//D7000026                             False,
//D7000026                             False,
//D7000026                             True,
//D7000026                             False,
//D7000026                             False,
//D7000026                             False,
//D7000026                             False,
//D7000026                             False );    //D4200062 lotBackupInfoFlag
//D7000026        if ( rc != RC_OK )
//D7000026        {
//D7000026            PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "lot_GetInfoDR() != RC_OK", seqIx) ;
//D7000026            strLotReQueueReqResult.strResult =  strLot_GetInfoDR_out.strResult ;
//D7000026            strLotReQueueReqResult.strLotReQueueReturn[seqIx].returnCode = ConvertLongtoString(rc);
//D7000026            return(rc);
//D7000026        }
//D7000026 add start
        CORBA::Boolean lotBasicInfoFlag        = FALSE ;
        CORBA::Boolean lotControlUseInfoFlag   = FALSE ;
        CORBA::Boolean lotFlowBatchInfoFlag    = FALSE ;
        CORBA::Boolean lotNoteFlagInfoFlag     = FALSE ;
        CORBA::Boolean lotOperationInfoFlag    = TRUE ;
        CORBA::Boolean lotOrderInfoFlag        = FALSE ;
        CORBA::Boolean lotControlJobInfoFlag   = FALSE ;
        CORBA::Boolean lotProductInfoFlag      = TRUE ;
        CORBA::Boolean lotRecipeInfoFlag       = FALSE ;
        CORBA::Boolean lotLocationInfoFlag     = FALSE ;
        CORBA::Boolean lotWipOperationInfoFlag = FALSE ;
        CORBA::Boolean lotWaferAttributesFlag  = FALSE ;
        CORBA::Boolean lotBackupInfoFlag       = FALSE ;

//DSN000085698        objLot_detailInfo_GetDR_out strLot_detailInfo_GetDR_out;
//DSN000096135        objLot_detailInfo_GetDR_out__150 strLot_detailInfo_GetDR_out;    //DSN000085698
        objLot_detailInfo_GetDR_out__160 strLot_detailInfo_GetDR_out;    //DSN000096135
//DSN000085698        rc = lot_detailInfo_GetDR( strLot_detailInfo_GetDR_out, strObjCommonIn,
//DSN000096135        rc = lot_detailInfo_GetDR__150( strLot_detailInfo_GetDR_out, strObjCommonIn,     //DSN000085698
        rc = lot_detailInfo_GetDR__160( strLot_detailInfo_GetDR_out, strObjCommonIn,     //DSN000096135
                                   strLotReQueueAttributes[seqIx].lotID,
                                   lotBasicInfoFlag,
                                   lotControlUseInfoFlag,
                                   lotFlowBatchInfoFlag,
                                   lotNoteFlagInfoFlag,
                                   lotOperationInfoFlag,
                                   lotOrderInfoFlag,
                                   lotControlJobInfoFlag,
                                   lotProductInfoFlag,
                                   lotRecipeInfoFlag,
                                   lotLocationInfoFlag,
                                   lotWipOperationInfoFlag,
                                   lotWaferAttributesFlag,
                                   lotBackupInfoFlag);

        if ( rc != RC_OK )
        {
//DSN000085698            PPT_METHODTRACE_V2("", "lot_detailInfo_GetDR() != RC_OK", seqIx) ;
            PPT_METHODTRACE_V2("", "lot_detailInfo_GetDR()__150 != RC_OK", seqIx) ;      //DSN000085698
            strLotReQueueReqResult.strResult =  strLot_detailInfo_GetDR_out.strResult ;
            strLotReQueueReqResult.strLotReQueueReturn[seqIx].returnCode = ConvertLongtoString(rc);
            return(rc);
        }
//D7000026 add end
//D7000026        if ( CIMFWStrCmp(strLotReQueueAttributes[seqIx].routeID.identifier,strLot_GetInfoDR_out.strLotInfo.strLotOperationInfo.routeID.identifier) != 0 )
        if ( CIMFWStrCmp(strLotReQueueAttributes[seqIx].routeID.identifier,strLot_detailInfo_GetDR_out.strLotInfo.strLotOperationInfo.routeID.identifier) != 0 )    //D7000026
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq","INVALID_CURRENT_ROUTE", seqIx) ;
            SET_MSG_RC(strLotReQueueReqResult,MSG_INVALID_CURRENT_ROUTE,RC_INVALID_CURRENT_ROUTE);
            strLotReQueueReqResult.strLotReQueueReturn[seqIx].returnCode = ConvertLongtoString(RC_INVALID_CURRENT_ROUTE);
            return(RC_INVALID_CURRENT_ROUTE);
        }

//D7000026        if ( CIMFWStrCmp(strLotReQueueAttributes[seqIx].currentOperationNumber,strLot_GetInfoDR_out.strLotInfo.strLotOperationInfo.operationNumber) != 0 )
        if ( CIMFWStrCmp(strLotReQueueAttributes[seqIx].currentOperationNumber,strLot_detailInfo_GetDR_out.strLotInfo.strLotOperationInfo.operationNumber) != 0 )    //D7000026
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq","INVALID_CURRENT_OPERATION", seqIx) ;
            SET_MSG_RC(strLotReQueueReqResult,MSG_INVALID_CURRENT_OPERATION,RC_INVALID_CURRENT_OPERATION);
            strLotReQueueReqResult.strLotReQueueReturn[seqIx].returnCode = ConvertLongtoString(RC_INVALID_CURRENT_OPERATION);
            return(RC_INVALID_CURRENT_OPERATION);
        }

//D7000026        if ( CIMFWStrCmp(strLotReQueueAttributes[seqIx].productID.identifier,strLot_GetInfoDR_out.strLotInfo.strLotProductInfo.productID.identifier) != 0 )
        if ( CIMFWStrCmp(strLotReQueueAttributes[seqIx].productID.identifier,strLot_detailInfo_GetDR_out.strLotInfo.strLotProductInfo.productID.identifier) != 0 )    //D7000026
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq","INVALID_CURRENT_PRODUCT", seqIx) ;
            SET_MSG_RC(strLotReQueueReqResult,MSG_INVALID_CURRENT_PRODUCT,RC_INVALID_CURRENT_PRODUCT);
            strLotReQueueReqResult.strLotReQueueReturn[seqIx].returnCode = ConvertLongtoString(RC_INVALID_CURRENT_PRODUCT);
            return(RC_INVALID_CURRENT_PRODUCT);
        }
//D4100120 Add

        /*------------------------------------------------------------------------*/
        /*   Register Product Request                                             */
        /*------------------------------------------------------------------------*/
        objLot_ChangeSchedule_out strLot_ChangeSchedule_out;
        strLot_ChangeSchedule_out.opehsMoveFlag = FALSE;

//D4100120 Add
//DSIV00002435        pptRescheduledLotAttributes strRescheduledLotAttributes;
        pptRescheduledLotAttributes__110 strRescheduledLotAttributes;                                                   //DSIV00002435
        strRescheduledLotAttributes.lotID = strLotReQueueAttributes[seqIx].lotID;
        strRescheduledLotAttributes.productID = strLotReQueueAttributes[seqIx].productID;
        strRescheduledLotAttributes.routeID = strLotReQueueAttributes[seqIx].routeID;
        strRescheduledLotAttributes.currentOperationNumber = strLotReQueueAttributes[seqIx].currentOperationNumber;
//D4100120 Add

        strRescheduledLotAttributes.originalRouteID = strLotReQueueAttributes[seqIx].routeID.identifier;                //P5100060
        strRescheduledLotAttributes.originalOperationNumber = strLotReQueueAttributes[seqIx].currentOperationNumber;    //P5100060
        strRescheduledLotAttributes.subLotType = CIMFWStrDup("");                                                       //DSIV00002435

        objLot_ChangeSchedule_in__110   strLot_ChangeSchedule_in;                                                       //DSIV00002435
        strLot_ChangeSchedule_in.strRescheduledLotAttributes = strRescheduledLotAttributes;                             //DSIV00002435
//DSIV00002435        rc = lot_ChangeSchedule(strLot_ChangeSchedule_out,strObjCommonIn,strRescheduledLotAttributes);
        rc = lot_ChangeSchedule__110(strLot_ChangeSchedule_out, strObjCommonIn, strLot_ChangeSchedule_in);              //DSIV00002435
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "lot_ChangeSchedule() != RC_OK", seqIx);
            strLotReQueueReqResult.strResult =  strLot_ChangeSchedule_out.strResult ;
            strLotReQueueReqResult.strLotReQueueReturn[seqIx].returnCode = ConvertLongtoString(rc);
            return(rc);
        }

        /*------------------------------------------------------------------------*/
        /*   Delete all qtime restrictions for previous route                     */
        /*------------------------------------------------------------------------*/
        if( strLot_ChangeSchedule_out.opehsMoveFlag == TRUE )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "strLot_ChangeSchedule_out.opehsMoveFlag == TRUE", seqIx);
//DSN000022151 Add Start
            CORBA::String_var keepQTime = CIMFWStrDup(getenv(SP_KEEP_QTIME_ON_SCHCHANGE));
            
            if( 0 == CIMFWStrCmp( keepQTime, SP_Function_Available_TRUE ) )
            {
                PPT_METHODTRACE_V1("", "SP_KEEP_QTIME_ON_SCHCHANGE=1");
                PPT_METHODTRACE_V1("", "Not clear Q-Time info");
                //Not clear Q-Time information
            }
            else
            {
                PPT_METHODTRACE_V1("", "SP_KEEP_QTIME_ON_SCHCHANGE=0");
                PPT_METHODTRACE_V1("", "Clear Q-Time info");
//DSN000022151 Add End
//DSN000022151 Indent Start
                objQtime_AllClearByRouteChange_out strQtime_AllClearByRouteChange_out ;
                rc = qtime_AllClearByRouteChange( strQtime_AllClearByRouteChange_out , strObjCommonIn , strLotReQueueAttributes[seqIx].lotID);
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "qtime_AllClearByRouteChange() != RC_OK", seqIx);
                    strLotReQueueReqResult.strResult =  strQtime_AllClearByRouteChange_out.strResult ;
                    strLotReQueueReqResult.strLotReQueueReturn[seqIx].returnCode = ConvertLongtoString( rc );
                    return(rc);
                }

                //D7000354 Add Start
                //--------------------------------------------------
                // Reset Q-Time actions
                //--------------------------------------------------
                objectIdentifier  resetReasonCodeID;
                resetReasonCodeID.identifier = CIMFWStrDup( SP_Reason_QTimeClear );

                //----- Lot Hold Actions -------//
                if( strQtime_AllClearByRouteChange_out.strLotHoldReleaseList.length() > 0 )
                {
                    PPT_METHODTRACE_V1("", "The lot hold actions to reset was found.");

                    pptHoldLotReleaseReqResult  strHoldLotReleaseReqResult;
                    rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, strLotReQueueAttributes[seqIx].lotID,
                                              resetReasonCodeID, strQtime_AllClearByRouteChange_out.strLotHoldReleaseList );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "txHoldLotReleaseReq() != RC_OK");
                        strLotReQueueReqResult.strResult                             = strHoldLotReleaseReqResult.strResult;
                        strLotReQueueReqResult.strLotReQueueReturn[seqIx].returnCode = ConvertLongtoString( rc );
                        return rc;
                    }
                }

                //----- Future Hold Actions -------//
                if( strQtime_AllClearByRouteChange_out.strFutureHoldCancelList.length() > 0 )
                {
                    PPT_METHODTRACE_V1("", "The future hold actions to cancel was found.");

                    pptFutureHoldCancelReqResult  strFutureHoldCancelReqResult;
                    rc = txFutureHoldCancelReq( strFutureHoldCancelReqResult, strObjCommonIn, strLotReQueueAttributes[seqIx].lotID, resetReasonCodeID,
                                                SP_EntryType_Cancel, strQtime_AllClearByRouteChange_out.strFutureHoldCancelList );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "txFutureHoldCancelReq() != RC_OK");
                        strLotReQueueReqResult.strResult                             = strFutureHoldCancelReqResult.strResult;
                        strLotReQueueReqResult.strLotReQueueReturn[seqIx].returnCode = ConvertLongtoString( rc );
                        return rc;
                    }
                }

                //----- Future Rework Actions -------//
                CORBA::Long  cancelLen = strQtime_AllClearByRouteChange_out.strFutureReworkCancelList.length();
                if( cancelLen > 0 )
                {
                    PPT_METHODTRACE_V2("", "The future rework actions to cancel was found.", cancelLen);

                    for( CORBA::Long  cancelCnt = 0; cancelCnt < cancelLen; cancelCnt++ )
                    {
                        pptFutureReworkInfo  strFutureRework = strQtime_AllClearByRouteChange_out.strFutureReworkCancelList[cancelCnt];

                        pptFutureReworkCancelReqResult  strFutureReworkCancelReqResult;
                        rc = txFutureReworkCancelReq( strFutureReworkCancelReqResult, strObjCommonIn, strFutureRework.lotID, strFutureRework.routeID,
                                                      strFutureRework.operationNumber, strFutureRework.strFutureReworkDetailInfoSeq, "" );
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "txFutureReworkCancelReq() != RC_OK");
                            strLotReQueueReqResult.strResult                             = strFutureReworkCancelReqResult.strResult;
                            strLotReQueueReqResult.strLotReQueueReturn[seqIx].returnCode = ConvertLongtoString( rc );
                            return rc;
                        }
                    }
                }
                //D7000354 Add End
//DSN000022151 Indent End
            }   //DSN000022151
        }

        //--------------------------------------------------------------------------------------------------
        // UpDate RequiredCassetteCategory
        //--------------------------------------------------------------------------------------------------
        objLot_CassetteCategory_UpdateForContaminationControl_out strLot_CassetteCategory_UpdateForContaminationControl_out;
        rc = lot_CassetteCategory_UpdateForContaminationControl( strLot_CassetteCategory_UpdateForContaminationControl_out,
                                                   strObjCommonIn,
                                                   strLotReQueueAttributes[seqIx].lotID );

        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i::txLotReQueueReq","lot_CassetteCategory_UpdateForContaminationControl != RC_OK");
            strLotReQueueReqResult.strResult = strLot_CassetteCategory_UpdateForContaminationControl_out.strResult;
            return rc;
        }

//INN-R170002 Add Start
        objLot_cassette_Get_out strLot_cassette_Get_out;
        rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, strLotReQueueAttributes[seqIx].lotID);
        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V1("","lot_cassette_Get != RC_OK");
            strLotReQueueReqResult.strResult = strLot_cassette_Get_out.strResult;
            return rc;
        }

        //--------------------------------------------------------------------------------------------------
        // Check Contamination Level
        //--------------------------------------------------------------------------------------------------
        csObjLot_ContaminationInfo_CheckForMove_in strLot_ContaminationInfo_CheckForMove_in;
        strLot_ContaminationInfo_CheckForMove_in.lotID = strLotReQueueAttributes[seqIx].lotID;
        strLot_ContaminationInfo_CheckForMove_in.carrierID = strLot_cassette_Get_out.cassetteID;

        csObjLot_ContaminationInfo_CheckForMove_out strLot_ContaminationInfo_CheckForMove_out;
        rc = cs_lot_ContaminationInfo_CheckForMove( strLot_ContaminationInfo_CheckForMove_out,
                                                    strObjCommonIn,
                                                    strLot_ContaminationInfo_CheckForMove_in );

        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V1("","cs_lot_ContaminationInfo_CheckForMove != RC_OK");
            strLotReQueueReqResult.strResult = strLot_ContaminationInfo_CheckForMove_out.strResult;
            return rc;
        }

        if(strLot_ContaminationInfo_CheckForMove_out.holdReqFlag == TRUE)
        {
            pptHoldListSequence strLotHoldReqList;
            strLotHoldReqList.length( 1 );
            strLotHoldReqList[0].holdType                    = CIMFWStrDup( SP_HoldType_LotHold );
            strLotHoldReqList[0].holdReasonCodeID.identifier = CIMFWStrDup( CS_SP_Reason_ContaminationMismatchHold );
            strLotHoldReqList[0].holdUserID                  = strObjCommonIn.strUser.userID;
            strLotHoldReqList[0].responsibleOperationMark    = CIMFWStrDup( SP_ResponsibleOperation_Current );
            strLotHoldReqList[0].claimMemo                   = CIMFWStrDup("");

            pptHoldLotReqResult strHoldLotReqResult;
            rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn,
                               strLotReQueueAttributes[seqIx].lotID,
                               strLotHoldReqList );

            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
                strLotReQueueReqResult.strResult = strHoldLotReqResult.strResult ;
                return rc ;
            }
            else
            {
                PPT_METHODTRACE_V1("", "txHoldLotReq() == RC_OK For LotHold") ;
            }
        }
//INN-R170002 Add End

        /*------------------------------------------------------------------------*/
        /*   Make History                                                         */
        /*------------------------------------------------------------------------*/
        if(strLot_ChangeSchedule_out.opehsAddFlag == TRUE)
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "strLot_ChangeSchedule_out.opehsAddFlag == TRUE", seqIx);
            objLotOperationMoveEvent_MakeChangeRoute_out strLotOperationMoveEvent_MakeChangeRoute_out;
            rc = lotOperationMoveEvent_MakeChangeRoute(strLotOperationMoveEvent_MakeChangeRoute_out,
                                                       strObjCommonIn,
                                                       "TXOMC010",
                                                       strLotReQueueAttributes[seqIx].lotID,
                                                       strLot_ChangeSchedule_out.oldCurrentPOData,
                                                       claimMemo);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "lotOperationMoveEvent_MakeChangeRoute() != RC_OK", seqIx) ;
//P5000145                PPT_SET_MSG_RC_KEY(strLotReQueueReqResult,MSG_FAIL_MAKE_HISTORY ,rc,strLotReQueueAttributes[seqIx].lotID.identifier) ;
                SET_MSG_RC( strLotReQueueReqResult, MSG_FAIL_MAKE_HISTORY ,rc );        //P5000145
                strLotReQueueReqResult.strLotReQueueReturn[seqIx].returnCode = ConvertLongtoString(rc);
                return(rc);
            }
        }

        objLotChangeEvent_Make_out strLotChangeEvent_Make_out;
        rc = lotChangeEvent_Make(strLotChangeEvent_Make_out, strObjCommonIn,
                                 "TXOMC010",
                                 strLotReQueueAttributes[seqIx].lotID.identifier,
                                 "0",
                                 "",
                                 "",
                                 "",
                                 "",
                                 "0",
                                 strLotReQueueAttributes[seqIx].productID.identifier,
                                 strLot_ChangeSchedule_out.previousProductID.identifier,
                                 strRescheduledLotAttributes.plannedStartTime,  //D4100120 Add
                                 strRescheduledLotAttributes.plannedFinishTime, //D4100120 Add
                                 claimMemo) ;
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "lotChangeEvent_Make() != RC_OK", seqIx) ;
//P5000145            PPT_SET_MSG_RC_KEY(strLotReQueueReqResult, MSG_FAIL_MAKE_HISTORY ,rc ,strLotReQueueAttributes[seqIx].lotID.identifier) ;
            SET_MSG_RC( strLotReQueueReqResult, MSG_FAIL_MAKE_HISTORY ,rc );        //P5000145
            strLotReQueueReqResult.strLotReQueueReturn[seqIx].lotID = strLotReQueueAttributes[seqIx].lotID ;
            strLotReQueueReqResult.strLotReQueueReturn[seqIx].returnCode = ConvertLongtoString(rc);
        }

        objLotReticleSetChangeEvent_Make_out strLotReticleSetChangeEvent_Make_out;
        rc = lotReticleSetChangeEvent_Make( strLotReticleSetChangeEvent_Make_out,
                                            strObjCommonIn,
                                            "TXOMC010",
                                            strLotReQueueAttributes[seqIx].lotID,
                                            claimMemo);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "lotReticleSetChangeEvent_Make() != RC_OK", seqIx);
//P5000145            PPT_SET_MSG_RC_KEY( strLotReQueueReqResult, MSG_FAIL_MAKE_HISTORY, rc , strLotReQueueAttributes[seqIx].lotID.identifier ) ;  //D4000177
            SET_MSG_RC( strLotReQueueReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145
            strLotReQueueReqResult.strLotReQueueReturn[seqIx].lotID = strLotReQueueAttributes[seqIx].lotID;                          //D4000177
            strLotReQueueReqResult.strLotReQueueReturn[seqIx].returnCode = ConvertLongtoString(rc);
            return(rc);
        }
    }

    /*------------------------------------------*/
    /*   AMHS I/F for Priority Change Request   */
    /*------------------------------------------*/
    PPT_METHODTRACE_V1("CS_PPTManager_i::txLotReQueueReq", "Start AMHS I/F")

    CORBA::Long cLen=0;

    pptPriorityChangeReq priorityChangeReq;

    objectIdentifier aLotID ;
    objectIdentifier aCassetteID ;

    for (CORBA::Long jCnt = 0; jCnt < nLen; jCnt++)
    {
        PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "Lot Loop Count ",jCnt)
        /*------------------------------------------------------------------------*/
        /*   Get cassette / lot connection                                        */
        /*------------------------------------------------------------------------*/
        aLotID = strLotReQueueAttributes[jCnt].lotID;
        objLot_cassette_Get_out strLot_cassette_Get_out ;

        PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "aLotID ",aLotID.identifier)

        rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, aLotID);
        if (rc == RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i::txLotReQueueReq", "lot_cassette_Get() == RC_OK") ;
            aCassetteID = strLot_cassette_Get_out.cassetteID ;

            PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "aCassetteID ",aCassetteID.identifier)
            /*----------------------------------------------*/
            /*   Check the representative lotID             */
            /*----------------------------------------------*/
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txLotReQueueReq", "Check the representative lotID");

//D8000028  objCassette_representLot_Get_out strCassette_representLot_Get_out;
//D8000028
//D8000028  rc = cassette_representLot_Get( strCassette_representLot_Get_out, strObjCommonIn, aCassetteID );
//D8000028  if (rc == RC_OK)
//D8000028  {
//D8000028      PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "cassette_representLot_Get().lotID ",strCassette_representLot_Get_out.lotID.identifier)
//D8000028      if(0 == CIMFWStrCmp(aLotID.identifier,strCassette_representLot_Get_out.lotID.identifier))
//D8000028      {
//D8000028          PPT_METHODTRACE_V1("CS_PPTManager_i::txLotReQueueReq", "cassette_representLot_Get() == RC_OK")
//D8000028          priorityChangeReq.priorityInfoData.length(cLen+1);
//D8000028          priorityChangeReq.priorityInfoData[cLen].priority = CIMFWStrDup(""); //D4100120 Add
//D8000028          priorityChangeReq.priorityInfoData[cLen].carrierID= aCassetteID;
//D8000028          PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "priorityInfoData.length",cLen+1)
//D8000028          PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "priorityInfoData[cLen].priority",priorityChangeReq.priorityInfoData[cLen].priority)
//D8000028          PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "priorityInfoData[cLen].carrierID",priorityChangeReq.priorityInfoData[cLen].carrierID.identifier)
//D8000028          cLen++;
//D8000028      }
//D8000028  }
//D8000028  else
//D8000028  {
//D8000028      PPT_METHODTRACE_V1("CS_PPTManager_i::txLotReQueueReq", "cassette_representLot_Get() != RC_OK")
//D8000028  }
//D8000028 add start
            objCassette_lotList_GetWithPriorityOrder_out strCassette_lotList_GetWithPriorityOrder_out;

            rc = cassette_lotList_GetWithPriorityOrder( strCassette_lotList_GetWithPriorityOrder_out, strObjCommonIn, aCassetteID );
            if (rc == RC_OK && 0 < strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq.length() )
            {
                PPT_METHODTRACE_V2("", "cassette_lotList_GetWithPriorityOrder.lotID ",strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].lotID.identifier)
                if(0 == CIMFWStrCmp( aLotID.identifier,strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].lotID.identifier ))
                {
                    priorityChangeReq.priorityInfoData.length(cLen+1);
                    priorityChangeReq.priorityInfoData[cLen].priority = CIMFWStrDup("");
                    priorityChangeReq.priorityInfoData[cLen].carrierID = aCassetteID ;
                    PPT_METHODTRACE_V2("", "### priorityInfoData.length = ",cLen+1);
                    PPT_METHODTRACE_V2("", "### priorityInfoData[cLen].priority  = ",priorityChangeReq.priorityInfoData[cLen].priority);
                    PPT_METHODTRACE_V2("", "### priorityInfoData[cLen].carrierID = ",priorityChangeReq.priorityInfoData[cLen].carrierID.identifier);
                    cLen++;
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "cassette_lotList_GetWithPriorityOrder() != RC_OK")
            }
//D8000028 add end
        }
        else
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i::txLotReQueueReq", "lot_cassette_Get() != RC_OK")
        }
    }

    CORBA::Long xLen = priorityChangeReq.priorityInfoData.length();
    PPT_METHODTRACE_V2("CS_PPTManager_i::txLotReQueueReq", "xLen",xLen)

    if (0 < xLen)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i::txLotReQueueReq", "Call XMSMgr_SendPriorityChangeReq")

        objXMSMgr_SendPriorityChangeReq_out strXMSMgr_SendPriorityChangeReq_out;
        rc = XMSMgr_SendPriorityChangeReq(strXMSMgr_SendPriorityChangeReq_out,
                                          strObjCommonIn,
                                          strObjCommonIn.strUser,
                                          priorityChangeReq);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i::txLotReQueueReq", "XMSMgr_SendPriorityChangeReq() != RC_OK") ;
        }
    }

    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
    for (CORBA::Long kCnt = 0; kCnt < nLen; kCnt++)
    {
        strLotReQueueReqResult.strLotReQueueReturn[kCnt].returnCode = ConvertLongtoString( RC_OK );
        strLotReQueueReqResult.strLotReQueueReturn[kCnt].lotID = strLotReQueueAttributes[kCnt].lotID ;
    }

    SET_MSG_RC(strLotReQueueReqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txLotReQueueReq") ;
    return(RC_OK);
}
