//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txEqpMonitorLotSTBReq.cpp
//
#include "cs_pptmgr.hpp"
//
// Class: CS_PPTManager
//
// Service: cs_txEqpMonitorLotSTBReq()
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------- -------------- -------------------------------------------
// 2017-10-31 INN-R170016   JJ.Zhang       Equipment monitor enhancement
//
// Description:
//
// Return:
//     long
//
// Parameter:
//     csEqpMonitorLotSTBReqResult&            strEqpMonitorLotSTBReqResult
//     const pptObjCommonIn&                   strObjCommonIn
//     const csEqpMonitorLotSTBReqInParm&      strEqpMonitorLotSTBReqInParm
//     const char *                            claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//
CORBA::Long CS_PPTManager_i::cs_txEqpMonitorLotSTBReq(
    csEqpMonitorLotSTBReqResult&            strEqpMonitorLotSTBReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const csEqpMonitorLotSTBReqInParm&      strEqpMonitorLotSTBReqInParm,
    const char*                             claimMemo
  	CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txEqpMonitorLotSTBReq")
    CORBA::Long rc = RC_OK ;

    PPT_METHODTRACE_V2("","in para BWSID", strEqpMonitorLotSTBReqInParm.BWSID.identifier );
    PPT_METHODTRACE_V2("","in para carrierID", strEqpMonitorLotSTBReqInParm.carrierID.identifier );

    strEqpMonitorLotSTBReqResult.lotIDs.length(0);
    objectIdentifier carrierID = strEqpMonitorLotSTBReqInParm.carrierID;
    //----------------------------------
    //  get BWSOut slotMap for carrier
    //----------------------------------
    csObjBWSOutSTB_slotMap_GetDR_in strBWSOutSTB_slotMap_GetDR_in;
    strBWSOutSTB_slotMap_GetDR_in.carrierID = carrierID;

    csObjBWSOutSTB_slotMap_GetDR_out strBWSOutSTB_slotMap_GetDR_out;
    rc = cs_BWSOutSTB_slotMap_GetDR(strBWSOutSTB_slotMap_GetDR_out,
                                    strObjCommonIn, 
                                    strBWSOutSTB_slotMap_GetDR_in);
    if( rc == CS_RC_NOT_EXIST_BWSOUTSTB_INFO)
    {
        PPT_METHODTRACE_V2("","BWS Out&STB info for carrier not exist", carrierID.identifier);
        SET_MSG_RC(strEqpMonitorLotSTBReqResult, MSG_OK, RC_OK);
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txEqpMonitorLotSTBReq")
        return( RC_OK );
    }
    else if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("","cs_BWSOutSTB_slotMap_GetDR() rc != RC_OK", rc);
        strEqpMonitorLotSTBReqResult.strResult = strBWSOutSTB_slotMap_GetDR_out.strResult;
        return(rc);
    }

    CORBA::ULong mapLen1 = strBWSOutSTB_slotMap_GetDR_out.strNPWSTB_SlotMapSeq.length();
    PPT_METHODTRACE_V2("","mapLen1", mapLen1);

    //--------------------------------
    //   Object Lock for Cassette
    //--------------------------------
    objObject_Lock_out  strObject_Lock_out;
    rc = object_Lock(strObject_Lock_out, strObjCommonIn, carrierID, SP_ClassName_PosCassette);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
        strEqpMonitorLotSTBReqResult.strResult = strObject_Lock_out.strResult;
        return(rc);
    }

    //--------------------------------
    //  Get cassette lot list.
    //--------------------------------
    objCassette_GetLotList_out strCassette_GetLotList_out;
    rc = cassette_GetLotList( strCassette_GetLotList_out, strObjCommonIn, carrierID );

    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cassette_GetLotList() != RC_OK", rc);
        strEqpMonitorLotSTBReqResult.strResult = strCassette_GetLotList_out.strResult;
        return( rc );
    }

    CORBA::ULong i = 0, j = 0;
    CORBA::ULong nSeqLen = 0;
    CORBA::ULong nLotLen = 0;

    nLotLen = strCassette_GetLotList_out.strLotListInCassetteInfo.lotID.length();
    PPT_METHODTRACE_V2("","strLotListInCassetteInfo.lotID.length", nLotLen);

    for( i =0; i<nLotLen; i++)
    {
        PPT_METHODTRACE_V2("","object_Lock", strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[i].identifier);

        //------------------------------
        // Lock lot for update
        //------------------------------
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, 
                        strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[i],
                        SP_ClassName_PosLot );
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
            strEqpMonitorLotSTBReqResult.strResult = strObject_Lock_out.strResult;
            return(rc);
        }
    }

    CORBA::Boolean bValidSTBInfo = TRUE;
    csEqpMonitorSubInfoSequence strEqpMonitorSubInfoSeq;
    //----------------------------------------------
    // Check slot map matched the monitor definiton
    //----------------------------------------------
    objCassette_GetWaferMapDR_out strCassette_GetWaferMapDR_out;
    rc = cassette_GetWaferMapDR(strCassette_GetWaferMapDR_out, strObjCommonIn, carrierID);
    if(rc!= RC_OK)
    {
        PPT_METHODTRACE_V2("", "cassette_GetWaferMapDR() != RC_OK ", carrierID.identifier );
        strEqpMonitorLotSTBReqResult.strResult = strCassette_GetWaferMapDR_out.strResult;
        return( rc );
    }
    CORBA::ULong mapLen2 = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo.length();
    PPT_METHODTRACE_V2("","mapLen2", mapLen2);

    if( mapLen1 != mapLen2 )
    {
        //slot map not matched the monitor definiton
        PPT_METHODTRACE_V1("", "0001234E:Other wafer [%s] exist in slot [%s] of cassette [%s].");
        PPT_SET_MSG_RC_KEY3( strEqpMonitorLotSTBReqResult,
                             MSG_NOT_USE_SLOT, RC_NOT_USE_SLOT,
                             "****", //waferID
                             "****", //slotNumber
                             carrierID.identifier );
        bValidSTBInfo = FALSE;
    }
    if( bValidSTBInfo )
    {
        PPT_METHODTRACE_V1("", "bValidSTBInfo, continue to check slotmap");
        for( i =0; i<nSeqLen; i++)
        {
            if( 0 != CIMFWStrCmp(strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].waferID.identifier, 
                                 strBWSOutSTB_slotMap_GetDR_out.strNPWSTB_SlotMapSeq[i].waferID.identifier) )
            {
                PPT_METHODTRACE_V2("", "WaferID not matched", strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].waferID.identifier);
                char slotNo[64];
                sprintf(slotNo, "%ld", strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].slotNumber);
                PPT_SET_MSG_RC_KEY3( strEqpMonitorLotSTBReqResult,
                                     MSG_NOT_USE_SLOT, RC_NOT_USE_SLOT,
                                     strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].waferID.identifier,
                                     slotNo,
                                     carrierID.identifier );
                bValidSTBInfo = FALSE;
                break;
            }
        }
    }

    //----------------------------------------------
    //  Get EqpMonitor definition info
    //----------------------------------------------
    if( bValidSTBInfo )
    {
        objEqpMonitor_info_Get_in strEqpMonitor_info_Get_in;
        strEqpMonitor_info_Get_in.eqpMonitorID = strBWSOutSTB_slotMap_GetDR_out.eqpMonitorID;

        csObjEqpMonitor_info_Get_out strEqpMonitor_info_Get_out;
        rc = cs_eqpMonitor_info_GetDR( strEqpMonitor_info_Get_out,
                                  strObjCommonIn,
                                  strEqpMonitor_info_Get_in );

        if ( rc == RC_NOT_FOUND_EQPMONITOR )
        {
            PPT_METHODTRACE_V2("", "not found eqpMonitorID", strBWSOutSTB_slotMap_GetDR_out.eqpMonitorID.identifier );
            strEqpMonitorLotSTBReqResult.strResult = strEqpMonitor_info_Get_out.strResult;
            bValidSTBInfo = FALSE;
        }
        else if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cs_eqpMonitor_info_GetDR() != RC_OK", rc);
            strEqpMonitorLotSTBReqResult.strResult = strEqpMonitor_info_Get_out.strResult;
            return rc;
        }
        else
        {
            PPT_METHODTRACE_V2("", "found eqpMonitorID", strBWSOutSTB_slotMap_GetDR_out.eqpMonitorID.identifier );
            strEqpMonitorSubInfoSeq = strEqpMonitor_info_Get_out.strEqpMonitorDetailInfos[0].strEqpMonitorSubInfoSeq;
            nSeqLen = strEqpMonitorSubInfoSeq.length();
        }
    }

    if( bValidSTBInfo )
    {
        if( mapLen1 != nSeqLen )
        {
            //slot map not matched the monitor definiton
            PPT_METHODTRACE_V1("", "0001234E:Other wafer [%s] exist in slot [%s] of cassette [%s].");
            PPT_SET_MSG_RC_KEY3( strEqpMonitorLotSTBReqResult,
                                 MSG_NOT_USE_SLOT, RC_NOT_USE_SLOT,
                                 "****", //waferID
                                 "****", //slotNumber
                                 carrierID.identifier );
            bValidSTBInfo = FALSE;
        }
    }

    if( bValidSTBInfo )
    {
        PPT_METHODTRACE_V1("", "bValidSTBInfo, continue to check slotmap");
        for( i =0; i<nSeqLen; i++)
        {
            //wafer in slot should have same attribute as what defined in EQPMON_SUB
            PPT_METHODTRACE_V2("", " check slotNumber", strEqpMonitorSubInfoSeq[i].slotNumber);
            if(strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].slotNumber != strEqpMonitorSubInfoSeq[i].slotNumber)
            {
                PPT_METHODTRACE_V2("", "WaferID not matched", strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].waferID.identifier);
                char slotNo[64];
                sprintf(slotNo, "%ld", strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].slotNumber);
                PPT_SET_MSG_RC_KEY3( strEqpMonitorLotSTBReqResult,
                                     MSG_NOT_USE_SLOT, RC_NOT_USE_SLOT,
                                     strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].waferID.identifier,
                                     slotNo,
                                     carrierID.identifier );
                bValidSTBInfo = FALSE;
                break;
            }

            //----------------------------------------------
            // Get product ID for wafer
            //----------------------------------------------
            objLot_productID_Get_out strLot_productID_Get_out;
            rc = lot_productID_Get( strLot_productID_Get_out,
                                    strObjCommonIn,
                                    strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].lotID );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "","lot_productID_Get != RC_OK", rc );
                strEqpMonitorLotSTBReqResult.strResult = strLot_productID_Get_out.strResult;
                return rc;
            }
            PPT_METHODTRACE_V2("", "productID", strLot_productID_Get_out.productID.identifier);

            //----------------------------------------------
            // valid source product or not
            //----------------------------------------------
            PPT_METHODTRACE_V2("", "get strProductIDListInqResult.strProductIDListAttributes for ", strEqpMonitorSubInfoSeq[i].productID.identifier) ;
            objProductSpecification_FillInTxPCQ015DR_out strProductSpecification_FillInTxPCQ015DR_out ;
            objProductSpecification_FillInTxPCQ015DR_in__160 strProductSpecification_FillInTxPCQ015DR_in;
            strProductSpecification_FillInTxPCQ015DR_in.strProductIDListInqInParm.productID = strEqpMonitorSubInfoSeq[i].productID.identifier;
            rc = productSpecification_FillInTxPCQ015DR__160(strProductSpecification_FillInTxPCQ015DR_out, strObjCommonIn, strProductSpecification_FillInTxPCQ015DR_in);

            if( rc != RC_OK && rc != RC_SOMEPRODSP_DATA_ERROR)
            {
                PPT_METHODTRACE_V2( "","productSpecification_FillInTxPCQ015DR__160 != RC_OK", rc );
                strEqpMonitorLotSTBReqResult.strResult = strProductSpecification_FillInTxPCQ015DR_out.strResult;
                return rc;
            }
            pptProductIDListAttributesSequence& strProductIDListAttributes = strProductSpecification_FillInTxPCQ015DR_out.strProductIDListAttributes ;
            CORBA::Long nProdLen = strProductIDListAttributes.length();
            PPT_METHODTRACE_V2("", "nProdLen", nProdLen);

            bValidSTBInfo = FALSE;
            for( j=0; j<nProdLen; j++)
            {
                if ( 0 == CIMFWStrCmp(strProductIDListAttributes[j].productID.identifier, strLot_productID_Get_out.productID.identifier) )
                {
                    PPT_METHODTRACE_V1("", "source Product match");
                    bValidSTBInfo = TRUE;
                    break;
                }
            }
            if( !bValidSTBInfo)
            {
                PPT_METHODTRACE_V2("", "Not valid source product", strLot_productID_Get_out.productID.identifier);
                PPT_SET_MSG_RC_KEY( strEqpMonitorLotSTBReqResult,
                                    MSG_SOURCEPRODUCT_UNMATCH, RC_SOURCEPRODUCT_UNMATCH,
                                    strLot_productID_Get_out.productID.identifier );
                break;
            }
        }
    }

    //----------------------------------------------
    // STB lots by Sub-Route
    //----------------------------------------------
    if( bValidSTBInfo )
    {
        pptNewLotAttributes strNewLotAttributes;
        strNewLotAttributes.cassetteID = carrierID;

        nSeqLen = strEqpMonitorSubInfoSeq.length();
        strEqpMonitorLotSTBReqResult.lotIDs.length(nSeqLen);
        nLotLen = 0;
        for( i =0; i<nSeqLen; i++)
        {
            PPT_METHODTRACE_V2("", "STB for", strEqpMonitorSubInfoSeq[i].productID.identifier);

            if( 0 == strEqpMonitorSubInfoSeq[i].slotNumber )
            {
                PPT_METHODTRACE_V2("", "already checked.", i);
                continue;
            }

            //----------------------------------------------
            // collect wafers for same product and sub-route
            //----------------------------------------------
            strNewLotAttributes.strNewWaferAttributes.length(nSeqLen-i);
            CORBA::Long waferCount = 1;
            strNewLotAttributes.strNewWaferAttributes[0].newSlotNumber = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].slotNumber;
            strNewLotAttributes.strNewWaferAttributes[0].sourceLotID   = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].lotID;
            strNewLotAttributes.strNewWaferAttributes[0].sourceWaferID = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].waferID;
            //mark colleted flag
            strEqpMonitorSubInfoSeq[i].slotNumber = 0;
            for( j =i+1; j<nSeqLen; j++)
            {
                if( 0 <  strEqpMonitorSubInfoSeq[i].slotNumber
                 && 0 == CIMFWStrCmp(strEqpMonitorSubInfoSeq[i].productID.identifier, strEqpMonitorSubInfoSeq[j].productID.identifier )
                 && 0 == CIMFWStrCmp(strEqpMonitorSubInfoSeq[i].subRouteID.identifier,strEqpMonitorSubInfoSeq[j].subRouteID.identifier) )
                 {
                    strNewLotAttributes.strNewWaferAttributes[waferCount].newSlotNumber = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[j].slotNumber;
                    strNewLotAttributes.strNewWaferAttributes[waferCount].sourceLotID   = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[j].lotID;
                    strNewLotAttributes.strNewWaferAttributes[waferCount].sourceWaferID = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[j].waferID;
                    //mark colleted flag
                    strEqpMonitorSubInfoSeq[j].slotNumber = 0;
                    waferCount++;
                 }
            }
            strNewLotAttributes.strNewWaferAttributes.length(waferCount);
            //---------------------------------------------
            // Check lot is on sub-route or not
            //---------------------------------------------
            pptCtrlLotSTBReqResult strCtrlLotSTBReqResult;
            rc = txCtrlLotSTBReq(strCtrlLotSTBReqResult, 
                                 strObjCommonIn, 
                                 strBWSOutSTB_slotMap_GetDR_out.strNPWSTB_SlotMapSeq[i].productID,
                                 waferCount,
                                 SP_ProductCategory_EquipmentMonitor, //lotType
                                 strBWSOutSTB_slotMap_GetDR_out.strNPWSTB_SlotMapSeq[i].subLotType,
                                 strNewLotAttributes,
                                 claimMemo);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "","txCtrlLotSTBReq != RC_OK", rc );
                strEqpMonitorLotSTBReqResult.strResult = strCtrlLotSTBReqResult.strResult;
                return rc;
            }

            //---------------------------------------------
            // Get all sub route info for this lot
            //---------------------------------------------
            PPT_METHODTRACE_V2("", "controlLotID", strCtrlLotSTBReqResult.controlLotID.identifier);
            strEqpMonitorLotSTBReqResult.lotIDs[nLotLen] = strCtrlLotSTBReqResult.controlLotID;
            nLotLen++;
        }
        strEqpMonitorLotSTBReqResult.lotIDs.length(nLotLen);
    }
    else
    {
        PPT_METHODTRACE_V1("", "not ValidSTBInfo");

        char     messageText[2048];
        char     m1[] = "<<< STB for BWS Out wafers failed. >>>";
        char     m2[] = "\n    Carrier ID            : ";
        char     m3[] = "\n    EqpMonitor ID         : ";
        char     m4[] = "\n    Error Message         : ";

        sprintf( messageText, "%s%s%s%s%d%s%d%s%d%s%d",
                 m1,
                 m2, (const char *)carrierID.identifier,
                 m3, (const char *)strBWSOutSTB_slotMap_GetDR_out.eqpMonitorID.identifier,
                 m4, (const char *)strEqpMonitorLotSTBReqResult.strResult.messageText );

        /*-------------------------*/
        /*   Call System Message   */
        /*-------------------------*/
        pptSystemMsgRptResult strSystemMsgRptResult;
        objectIdentifier dummy;

        rc = txSystemMsgRpt( strSystemMsgRptResult,
                             strObjCommonIn,
                             SP_SubSystemID_MM,
                             SP_MessageID_MonitorFail,
                             messageText,
                             TRUE,
                             dummy,
                             "",
                             dummy,
                             "",
                             dummy,
                             "",
                             dummy,
                             "",
                             dummy,
                             dummy,
                             "",
                             strObjCommonIn.strTimeStamp.reportTimeStamp,
                             "" );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "txSystemMsgRpt() != RC_OK") ;
            strEqpMonitorLotSTBReqResult.strResult = strSystemMsgRptResult.strResult ;
            return( rc );
        }
    }

    //----------------------------------
    // delete BWSOut slotMap for carrier
    //----------------------------------
    csObjBWSOutSTB_slotMap_DeleteDR_in strBWSOutSTB_slotMap_DeleteDR_in;
    strBWSOutSTB_slotMap_DeleteDR_in.carrierID = carrierID;

    csObjBWSOutSTB_slotMap_DeleteDR_out strBWSOutSTB_slotMap_DeleteDR_out;
    rc = cs_BWSOutSTB_slotMap_DeleteDR(strBWSOutSTB_slotMap_DeleteDR_out, strObjCommonIn, strBWSOutSTB_slotMap_DeleteDR_in);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("","cs_BWSOutSTB_slotMap_DeleteDR() rc != RC_OK", rc);
        strEqpMonitorLotSTBReqResult.strResult = strBWSOutSTB_slotMap_DeleteDR_out.strResult;
        return(rc);
    }

    //---------------------------
    //  Set out structure
    //---------------------------
    SET_MSG_RC(strEqpMonitorLotSTBReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txEqpMonitorLotSTBReq")
    return( RC_OK );

}