// @(#) 1.4 superpos/src/csppt/source/posppt/pptmgr/txmethods/cs_txTestFunction.cpp, mm_srv_5_0_cspp, mm_srv_5_0_cspp 6/9/03 14:16:50 [ 6/9/03 14:16:52 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_txTestFunction.cpp
//
// ** Notice **
//   This is a sample code for customizing a PPT Manager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT Manager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//


#include "cs_pptmgr.hpp"
// Class: CS_PPTManager
//
// Service: cs_txTestFunction()
//
// Change history:
// Date       Defect#   Person        Comments
// ---------- --------  ------------- -------------------------------------------
// 2003/06/09 D5000014  C.Tsuchiya    Initial Release for R5.0
// 2004/10/26 D6000025  K.Murakami    eBrokerMigration.
//
// INNOTRON Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/27 INN-R170009  Gary Ke         170009: APC Condition check 
// 2017/10/23 INN-R170009-01  Gary Ke         170009: APC Litho Lot Data Info
// 2017/10/23 INN-R170009  Qufd            170009: Add APC Queue
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::cs_txTestFunction (
    csTestFunctionResult&                strTestFunctionResult,
    const pptObjCommonIn&                strObjCommonIn,
    const char *                         functionName,
    const objectIdentifier&              lotID,
    const objectIdentifier&              equipmentID,
    const objectIdentifier&              routeID, //INN-R170009
    const char *                         operationNumber,//INN-R170009
    const objectIdentifier&              controlJobID, // add by Qufd 170009
    const char *                         eventID,      // add by Qufd 170009
    const char *                         claimMemo     //D6000025
                                    CORBAENV_LAST_CPP )  //D6000025
//D6000025    const char *                         claimMemo,
//D6000025    CORBA::Environment &                 IT_env )
{

    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txTestFunction") ;
    PPT_METHODTRACE_V2("", "in para functionName ",   functionName);
    PPT_METHODTRACE_V2("", "in para lotID        ",   lotID.identifier);
    PPT_METHODTRACE_V2("", "in para equipmentID  ",   equipmentID.identifier );
    //INN-R170009 add start                           
    PPT_METHODTRACE_V2("", "in para routeID      ",   routeID.identifier );
    PPT_METHODTRACE_V2("", "in para operationNumber", operationNumber );   
    //INN-R170009 add end	
    PPT_METHODTRACE_V2("", "in para userID       ", strObjCommonIn.strUser.userID.identifier);

    //INN-R170009 add start                           
    PPT_METHODTRACE_V2("", "in para controlJboID   ",   controlJobID.identifier );
    PPT_METHODTRACE_V2("", "in para eventID        ",   eventID );   
    //INN-R170009 add end	

    //--------------
    // Initialize
    //--------------
    CORBA::Long rc = RC_OK;
#if 0
    //--------------------------------------------------------------
    // Test Function
    //-------------------------------------------------------------
    //INN-R170009 objTestFunction_Obj_out strTestFunction_Obj_out;
    //INN-R170009 add start
    csObjAPC_LithoLotDataInfo_Get_out              strAPC_LithoLotDataInfo_Get_out;
    csObjAPC_LithoLotDataInfo_Get_in      strAPC_LithoLotDataInfo_Get_in;
    strAPC_LithoLotDataInfo_Get_in.routeID         = routeID;
    strAPC_LithoLotDataInfo_Get_in.operationNumber = operationNumber;
    strAPC_LithoLotDataInfo_Get_in.lotID           = lotID;
    //strAPC_LithoLotDataInfo_Get_in.equipmentID     = equipmentID;
    rc = cs_APC_LithoLotDataInfo_Get( strAPC_LithoLotDataInfo_Get_out, strObjCommonIn, strAPC_LithoLotDataInfo_Get_in );

    //------------------------------------------------------
    // When Error Occures.
    //------------------------------------------------------
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","cs_testFunction() returned error");
        strTestFunctionResult.strResult = strAPC_LithoLotDataInfo_Get_out.strResult ;
        return(rc); 
    }
    
    //------------------------------------------------------
    // Set Object returned value to Tx Value
    //------------------------------------------------------
    //
    //INN-R170009 add end
    //INN-R170009-01 add start
    CORBA::Long WaferDataSeqlen = strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq.length();
    PPT_METHODTRACE_V2("","WaferDataSeqlen" , WaferDataSeqlen);
    strTestFunctionResult.infos.length(WaferDataSeqlen);
    for (CORBA::Long infoidx = 0; infoidx < WaferDataSeqlen; infoidx++)
    {
        strTestFunctionResult.infos[infoidx].waferID           = strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[infoidx].waferID;
        strTestFunctionResult.infos[infoidx].slotNo            = strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[infoidx].slotNo;
        strTestFunctionResult.infos[infoidx].chuckID           = strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[infoidx].chuckID;
        strTestFunctionResult.infos[infoidx].reworkCount       = strAPC_LithoLotDataInfo_Get_out.strLithoLotDataInfo.strWaferDataSeq[infoidx].reworkCount;
        PPT_METHODTRACE_V2("","waferID" ,     strTestFunctionResult.infos[infoidx].waferID.identifier);
        PPT_METHODTRACE_V2("","slotNo" ,      strTestFunctionResult.infos[infoidx].slotNo);
        PPT_METHODTRACE_V2("","chuckID" ,     strTestFunctionResult.infos[infoidx].chuckID);
        PPT_METHODTRACE_V2("","reworkCount" , strTestFunctionResult.infos[infoidx].reworkCount);
    }
   
    //INN-R170009-01 add end
#endif
    //INN-R170009 add start by Qufd
    csObjAPC_LithoRecipeParameter_Replace_out      strObjAPC_LithoRecipeParameter_Replace_out;
    const csObjAPC_LithoRecipeParameter_Replace_in strObjAPC_LithoRecipeParameter_Replace_in;

    strObjAPC_LithoRecipeParameter_Replace_in.strStartRecipeParameterSeq.length(3);
    strObjAPC_LithoRecipeParameter_Replace_in.strStartRecipeParameterSeq[0].parameterName = CIMFWStrDup( "Parm001" ) ;
    strObjAPC_LithoRecipeParameter_Replace_in.strStartRecipeParameterSeq[0].parameterValue = CIMFWStrDup( "10" ) ;
    strObjAPC_LithoRecipeParameter_Replace_in.strStartRecipeParameterSeq[0].targetValue = CIMFWStrDup( "No" ) ;

    strObjAPC_LithoRecipeParameter_Replace_in.strStartRecipeParameterSeq[1].parameterName = CIMFWStrDup( "Parm002" ) ;
    strObjAPC_LithoRecipeParameter_Replace_in.strStartRecipeParameterSeq[1].parameterValue = CIMFWStrDup( "20" ) ;
    strObjAPC_LithoRecipeParameter_Replace_in.strStartRecipeParameterSeq[1].targetValue = CIMFWStrDup( "Yes" ) ;

    strObjAPC_LithoRecipeParameter_Replace_in.strStartRecipeParameterSeq[2].parameterName = CIMFWStrDup( "Parm003" ) ;
    strObjAPC_LithoRecipeParameter_Replace_in.strStartRecipeParameterSeq[2].parameterValue = CIMFWStrDup( "35" ) ;
    strObjAPC_LithoRecipeParameter_Replace_in.strStartRecipeParameterSeq[2].targetValue = CIMFWStrDup( "No" ) ;

    strObjAPC_LithoRecipeParameter_Replace_in.strStartRecipeParameterSeq[3].parameterName = CIMFWStrDup( "Parm004" ) ;
    strObjAPC_LithoRecipeParameter_Replace_in.strStartRecipeParameterSeq[3].parameterValue = CIMFWStrDup( "50" ) ;
    strObjAPC_LithoRecipeParameter_Replace_in.strStartRecipeParameterSeq[3].targetValue = CIMFWStrDup( "No" ) ;

    strObjAPC_LithoRecipeParameter_Replace_in.strAPCLithoRecommendReticleSeq.length(3);
    strObjAPC_LithoRecipeParameter_Replace_in.strAPCLithoRecommendReticleSeq[0].reticleID = CIMFWStrDup( "Ret1" );
    strObjAPC_LithoRecipeParameter_Replace_in.strAPCLithoRecommendReticleSeq.strAPCLithoRecipeParameterSeq.length(1);

    strObjAPC_LithoRecipeParameter_Replace_in.strAPCLithoRecommendReticleSeq[0].strAPCLithoRecipeParameterSeq[0].parameterName = CIMFWStrDup( "Parm002" ) ;
    strObjAPC_LithoRecipeParameter_Replace_in.strAPCLithoRecommendReticleSeq[0].strAPCLithoRecipeParameterSeq[0].parameterValue = CIMFWStrDup( "20" ) ;

    strObjAPC_EventQueue_DelDR_in.strAPCEventQueueSeq[0].lotID = lotID;
    strObjAPC_EventQueue_DelDR_in.strAPCEventQueueSeq[0].controlJobID.identifier = CIMFWStrDup("GR-EQP01-20171030-0001");


    rc = cs_APC_LithoRecipeParameter_Replace (strObjAPC_LithoRecipeParameter_Replace_out,
                                              strObjCommonIn,
                                              strObjAPC_LithoRecipeParameter_Replace_in
                                             );


    //------------------------------------------------------
    // When Error Occures.
    //------------------------------------------------------
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","cs_testFunction() returned error");
        strTestFunctionResult.strResult = strObjAPC_LithoRecipeParameter_Replace_out.strResult ;
        return(rc); 
    }
    
    //------------------------------------------------------
    // Set Object returned value to Tx Value
    //------------------------------------------------------
    //
    //INN-R170009 add end by Qufd

    //----------
    //   Return
    //----------
    SET_MSG_RC(strTestFunctionResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: cs_txTestFunction") ;
    return(RC_OK);
}
