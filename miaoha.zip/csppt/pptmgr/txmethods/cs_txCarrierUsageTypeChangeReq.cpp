//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txCarrierUsageTypeChangeReq.cpp
//
#include "cs_pptmgr.hpp"
//
// Class: PPTManager
//
// Service: txFixtureUsageCountResetReq()
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------- -------------- -------------------------------------------
// 2017-09-14 INN-R170002   JJ.Zhang       Contamination control 
//
// Description:
//
// Return:
//     long
//
// Parameter:
//     csCarrierUsageTypeChangeReqResult&       strCarrierUsageTypeChangeReqResult
//     const pptObjCommonIn&                    strObjCommonIn
//     const csCarrierUsageTypeChangeReqInParm& strCarrierUsageTypeChangeReqInParm
//     const char *                             claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//
CORBA::Long CS_PPTManager_i::cs_txCarrierUsageTypeChangeReq(
    csCarrierUsageTypeChangeReqResult&       strCarrierUsageTypeChangeReqResult,
    const pptObjCommonIn&                    strObjCommonIn,
    const csCarrierUsageTypeChangeReqInParm& strCarrierUsageTypeChangeReqInParm,
    const char*                              claimMemo
	CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txCarrierUsageTypeChangeReq")
    CORBA::Long rc = RC_OK ;

    //---------------------------------------
    //  Call to change carrier Udata
    //---------------------------------------
    csObjCarrier_UsageTypeChange_in strCarrier_UsageTypeChange_in;
    strCarrier_UsageTypeChange_in.carrierIDs = strCarrierUsageTypeChangeReqInParm.carrierIDs;
    strCarrier_UsageTypeChange_in.usageType  = strCarrierUsageTypeChangeReqInParm.usageType;
    strCarrier_UsageTypeChange_in.claimMemo  = claimMemo;

    csObjCarrier_UsageTypeChange_out strCarrier_UsageTypeChange_out;
    rc = cs_carrier_UsageTypeChange(strCarrier_UsageTypeChange_out,
                                 strObjCommonIn, 
                                 strCarrier_UsageTypeChange_in) ;
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "cs_carrier_UsageTypeChange() rc != RC_OK" );
        strCarrierUsageTypeChangeReqResult.strResult = strCarrier_UsageTypeChange_out.strResult;
        return rc;
    }

    //---------------------------
    //  Set out structure
    //---------------------------
    SET_MSG_RC(strCarrierUsageTypeChangeReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txCarrierUsageTypeChangeReq")
    return( RC_OK );

}