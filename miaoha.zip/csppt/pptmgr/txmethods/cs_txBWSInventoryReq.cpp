//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
//
// SiView
// Name: cs_txBWSInventoryReq.cpp
//
// Modeficaiton History:
// Date       Defect        Name          Description
// ---------- ------------- ------------- ----------------------------------------------
// 2017/10/25 INN-R170017   Wang Fang     Initial Release
//
// Class: PPTServiceManager
//
// Service: cs_txBWSInventoryReq()
//
// Description:
//<Method Summary>
//
//</Method Summary>
//
// Return:
//     long
//
// Parameter:
//
//     csBWSInventoryReqResult&            strBWSInventoryReqResult,
//     const pptObjCommonIn&               strObjCommonIn,
//     const csBWSInventoryReqInParm&      strBWSInventoryReqInParm,
//     const char *                        claimMemo
//
#include "cs_pptmgr.hpp"
CORBA::Long CS_PPTManager_i::cs_txBWSInventoryReq(
        csBWSInventoryReqResult&            strBWSInventoryReqResult,
        const pptObjCommonIn&               strObjCommonIn,
        const csBWSInventoryReqInParm&      strBWSInventoryReqInParm,
        const char *                        claimMemo
        CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txBWSInventoryReq ");
    CORBA::Long rc = RC_OK ;
    CORBA::Long ix = 0;
    CORBA::Long iy = 0;
    CORBA::Long lnLen = 0;
 
    /*-----------------------------------------------------------*/
    /*  Input Parameter Check                                    */
    /*-----------------------------------------------------------*/
    PPT_METHODTRACE_V2("", "In-parm BWSID",   strBWSInventoryReqInParm.BWSID.identifier);
    
    lnLen=strBWSInventoryReqInParm.strBWSZoneSeq.length();
    for(ix=0; ix<lnLen;ix++)
    {
        PPT_METHODTRACE_V2("", "In-parm zoneID",  strBWSInventoryReqInParm.strBWSZoneSeq[ix].zoneID);    
        CORBA::Long lnLenWafer=strBWSInventoryReqInParm.strBWSZoneSeq[ix].wafers.length();
        
        for(iy=0; iy<lnLenWafer;iy++)
        {
            PPT_METHODTRACE_V3("", ix, "In-parm waferID",  strBWSInventoryReqInParm.strBWSZoneSeq[ix].wafers[iy].waferID.identifier); 
        }
    }
    if(CIMFWStrLen(strBWSInventoryReqInParm.BWSID.identifier)<0 || CIMFWStrLen(strBWSInventoryReqInParm.BWSID.stringifiedObjectReference)<0)
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(BWSID.identifier)<0 || CIMFWStrLen(BWSID.stringifiedObjectReference)<0");

        SET_MSG_RC(strBWSInventoryReqResult,
                  MSG_INVALID_INPUT_PARM,
                  RC_INVALID_INPUT_PARM);

        return (RC_INVALID_INPUT_PARM);
    }
    
    /*-----------------------------------------------------------*/
    /*  Initialize                                               */
    /*-----------------------------------------------------------*/
    CORBA::Long msgCnt = strBWSInventoryReqResult.strBWSInvMsgSeq.length();
    objectIdentifier equipmentID = strBWSInventoryReqInParm.BWSID;
    
    /*-----------------------------------------------------------*/
    /*  Object lock                                              */
    /*-----------------------------------------------------------*/
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = equipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup(SP_ClassName_PosMachine);
    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup(SP_FunctionCategory_SorterTxID);
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;
    
    PPT_METHODTRACE_V2("", "calling object_lockMode_Get()", equipmentID.identifier);
    
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    rc = object_lockMode_Get(strObject_lockMode_Get_out,
                             strObjCommonIn,
                             strObject_lockMode_Get_in);
                             
    if( rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK, rc=", rc);
        strBWSInventoryReqResult.strResult = strObject_lockMode_Get_out.strResult;
        return ( rc );
    }
    PPT_METHODTRACE_V2("", "lockMode", strObject_lockMode_Get_out.lockMode);
    
    if(strObject_lockMode_Get_out.lockMode != SP_EQP_LOCK_MODE_WRITE)
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
        
        // Advanced Modeficaiton
        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        
        objAdvanced_object_Lock_in  strAdvanced_object_Lock_in;
        strAdvanced_object_Lock_in.objectID           = equipmentID;
        strAdvanced_object_Lock_in.className          = CIMFWStrDup(SP_ClassName_PosMachine);
        strAdvanced_object_Lock_in.objectType         = CIMFWStrDup(SP_ObjectLock_ObjectType_MainObject);
        strAdvanced_object_Lock_in.lockType           = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq             = dummySeq; 
        
        PPT_METHODTRACE_V2("", "calling advanced_object_lock()", SP_ObjectLock_ObjectType_MainObject);
        
        objAdvanced_object_Lock_out  strAdvanced_object_Lock_out;
        rc= advanced_object_Lock(strAdvanced_object_Lock_out,
                                 strObjCommonIn,
                                 strAdvanced_object_Lock_in);
        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK, rc=", rc);
            strBWSInventoryReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return ( rc );
        }            
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
        /*-----------------------------------------------------------*/
        /*  Lock Objects to be updated                               */
        /*-----------------------------------------------------------*/
        PPT_METHODTRACE_V1("", "Lock objects to be updated");
        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out,
                          strObjCommonIn,
                          equipmentID,
                          SP_ClassName_PosMachine);
        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V2("", "object_Lock != RC_OK, rc=", rc);
            strBWSInventoryReqResult.strResult = strObject_Lock_out.strResult;
            return (rc);           
        }              
    }
    
    /*-----------------------------------------------------------*/
    /*  Check sorter job                                         */
    /*-----------------------------------------------------------*/
    objSorter_jobList_GetDR_in strSorter_jobList_GetDR_in;
    strSorter_jobList_GetDR_in.equipmentID = equipmentID;
    
    objSorter_jobList_GetDR_out strSorter_jobList_GetDR_out;
    rc = sorter_jobList_GetDR(strSorter_jobList_GetDR_out,
                              strObjCommonIn,
                              strSorter_jobList_GetDR_in);
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "sorter_jobList_GetDR != RC_OK, rc=", rc);
        strBWSInventoryReqResult.strResult = strSorter_jobList_GetDR_out.strResult;
        return (rc);  
    }
    
    lnLen = strSorter_jobList_GetDR_out.strSortJobListAttributesSeq.length();
    for( ix=0;ix<lnLen;ix++)
    {
        if( CIMFWStrLen(strSorter_jobList_GetDR_out.strSortJobListAttributesSeq[ix].sorterJobID.identifier) > 0)
        {
            PPT_METHODTRACE_V1("", "SorterJob Information exists on equipment.");
            
            CS_SET_MSG_RC( strBWSInventoryReqResult,
                           CS_MSG_BWS_INVENTORY_UPLOAD_NOT_ALLOWED,
                           CS_RC_BWS_INVENTORY_UPLOAD_NOT_ALLOWED);
                                 
            return CS_RC_BWS_INVENTORY_UPLOAD_NOT_ALLOWED;
        }
    }

    /*-----------------------------------------------------------*/
    /*  Eqp info get                                             */
    /*-----------------------------------------------------------*/
    pptEqpInfoInqResult__160 strEqpInfoInqResult;
    rc = txEqpInfoInq__160( strEqpInfoInqResult,
                           strObjCommonIn,
                           equipmentID,
                           TRUE,       //requestFlagForBRInfo
                           FALSE,      //requestFlagForStatusInfo
                           FALSE,      //requestFlagForPMInfo
                           TRUE,       //requestFlagForPortInfo
                           FALSE,      //requestFlagForChamberInfo
                           FALSE,      //requestFlagForStockerInfo
                           TRUE,       //requestFlagForInprocessingLotInfo
                           FALSE,      //requestFlagForReservedControlJobInfo
                           TRUE,       //requestFlagForRSPortInfo
                           FALSE);     //requestFlagForEqpContainerInfo
    if( rc != RC_OK ) 
    {
        PPT_METHODTRACE_V2("", "txEqpInfoInq__160() != RC_OK, rc=", rc);
        strBWSInventoryReqResult.strResult = strEqpInfoInqResult.strResult;
        return (rc);  
    }   
    
    /*-----------------------------------------------------------*/
    /*  Special control check                                    */
    /*-----------------------------------------------------------*/
    CORBA::Boolean bBWSSpecialCtrlFlag = FALSE;
    lnLen = strEqpInfoInqResult.equipmentBRInfo.specialControl.length();
    for( ix=0;ix<lnLen;ix++)
    {
        if(0== CIMFWStrCmp(strEqpInfoInqResult.equipmentBRInfo.specialControl[ix],CS_EQP_SpecialEquipmentControl_BareWaferStocker))
        {
            bBWSSpecialCtrlFlag=TRUE;
            break;
        }
    }
    
    if(bBWSSpecialCtrlFlag!=TRUE )
    {
        PPT_METHODTRACE_V1("", "Eqp Special Control is not Bare Wafer Stocker");
        
        CS_PPT_SET_MSG_RC_KEY1( strBWSInventoryReqResult,
                    CS_MSG_BWS_NOT_BARE_WAFER_STOCKER,
                    CS_RC_BWS_NOT_BARE_WAFER_STOCKER,
                    equipmentID.identifier);
        
        return CS_RC_BWS_NOT_BARE_WAFER_STOCKER;
    }
    
    /*-----------------------------------------------------------*/
    /*  Equipment catagory check                                 */
    /*-----------------------------------------------------------*/
    if(0!= CIMFWStrCmp(strEqpInfoInqResult.equipmentBRInfo.equipmentCategory, SP_Mc_Category_WaferSorter))
    {
        PPT_METHODTRACE_V1("", "Eqp category is not WaferSorter");
        
        PPT_SET_MSG_RC_KEY2( strBWSInventoryReqResult,
                    MSG_EQP_CATEGORY_TXID_MISMATCH,
                    RC_EQP_CATEGORY_TXID_MISMATCH,
					strObjCommonIn.transactionID,
                    strEqpInfoInqResult.equipmentBRInfo.equipmentCategory);

        return RC_EQP_CATEGORY_TXID_MISMATCH;
    }
    
    /*-----------------------------------------------------------*/
    /*  BWS Wafer config info get                                */
    /*-----------------------------------------------------------*/
    csObjBWS_Config_GetDR_in strBWS_Config_GetDR_in;
    strBWS_Config_GetDR_in.BWSID  = equipmentID;
    strBWS_Config_GetDR_in.zoneID = CIMFWStrDup("");
    
    csObjBWS_Config_GetDR_out strBWS_Config_GetDR_out;
    rc = cs_BWS_Config_GetDR(strBWS_Config_GetDR_out,
                             strObjCommonIn,
                             strBWS_Config_GetDR_in);
    if( rc != RC_OK ) 
    {
        PPT_METHODTRACE_V2("", "cs_BWS_Config_GetDR() != RC_OK, rc=", rc);
        strBWSInventoryReqResult.strResult = strBWS_Config_GetDR_out.strResult;
        return (rc);  
    }          
    
    csBWSConfigInfo strBWSConfigInfo;
    CORBA::Boolean bBWSConfigFlag = FALSE;
    lnLen = strBWS_Config_GetDR_out.strBWSConfigInfoSeq.length();
    for(ix=0;ix<lnLen;ix++)
    {
        if( 0 == CIMFWStrCmp(equipmentID.identifier,strBWS_Config_GetDR_out.strBWSConfigInfoSeq[ix].BWSID.identifier ) )
        {
            strBWSConfigInfo = strBWS_Config_GetDR_out.strBWSConfigInfoSeq[ix];
            bBWSConfigFlag = TRUE;
            break;
        }
    }
    
    if(bBWSConfigFlag!=TRUE)
    {
        PPT_METHODTRACE_V1("", "BWS Config not found.");
        
        CS_PPT_SET_MSG_RC_KEY1( strBWSInventoryReqResult,
                    CS_MSG_BWS_CONFIG_NOT_FOUND_BWS,
                    CS_RC_BWS_CONFIG_NOT_FOUND_BWS,
                    strBWSInventoryReqInParm.BWSID.identifier);
        
        return CS_RC_BWS_CONFIG_NOT_FOUND_BWS;
    }
    
    /*-----------------------------------------------------------*/
    /*  Initialize return message                                */
    /*-----------------------------------------------------------*/
    char description[1024];
    char condition[1024];
    char exHandling[1024];
    
    /*-----------------------------------------------------------*/
    /*  Get BWS WaferList                                        */
    /*-----------------------------------------------------------*/ 
    csObjBWS_WaferList_GetDR_in strBWS_WaferList_GetDR_in;
    strBWS_WaferList_GetDR_in.BWSID = equipmentID;
    strBWS_WaferList_GetDR_in.lSearchType = 1;
    
    csObjBWS_WaferList_GetDR_out strBWS_WaferList_GetDR_out;
    rc = cs_BWS_WaferList_GetDR( strBWS_WaferList_GetDR_out,
                                 strObjCommonIn,
                                 strBWS_WaferList_GetDR_in);
                                 
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","cs_BWS_WaferList_GetDR() != RC_OK, rc=",rc);
        strBWSInventoryReqResult.strResult = strBWS_WaferList_GetDR_out.strResult;
        return (rc);
    }    
    
    /*-----------------------------------------------------------*/
    /*  Send to TCS                                              */
    /*-----------------------------------------------------------*/ 
    CORBA::String_var tmpSleepTimeValue = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
    CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));   
    CORBA::Long sleepTimeValue=0;
    CORBA::Long retryCountValue=0;
    
    if(CIMFWStrLen(tmpSleepTimeValue)==0)
    {
        sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
    }    
    else
    {
        sleepTimeValue = atoi(tmpSleepTimeValue);
    }
    
    if(CIMFWStrLen(tmpRetryCountValue)==0)
    {
        retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
    }    
    else
    {
        retryCountValue = atoi(tmpRetryCountValue);
    }
    
    PPT_METHODTRACE_V2("", "env value of SP_BIND_SLEEP_TIME_TCS = ",sleepTimeValue);
    PPT_METHODTRACE_V2("", "env value of SP_BIND_REPLY_COUNT_TCS = ",retryCountValue);
    
    csObjTCSMgr_SendBWSInventoryInq_in  strTCSMgr_SendBWSInventoryInq_in;
    strTCSMgr_SendBWSInventoryInq_in.BWSID = equipmentID;
	strTCSMgr_SendBWSInventoryInq_in.strBWSZoneSeq = strBWSInventoryReqInParm.strBWSZoneSeq;

    
    csObjTCSMgr_SendBWSInventoryInq_out  strTCSMgr_SendBWSInventoryInq_out;
    //'retryCountValue+1' means first try plus retry count
    for(int i=0;i<(retryCountValue+1);i++)
    {
        /*-----------------------------------------------------------*/
        /*  Send Request to TCS                                      */
        /*-----------------------------------------------------------*/
        rc = cs_TCSMgr_SendBWSInventoryInq(strTCSMgr_SendBWSInventoryInq_out,
                                        strObjCommonIn,
                                        strTCSMgr_SendBWSInventoryInq_in);
        PPT_METHODTRACE_V2("", "rc = ",rc);
        
        if(rc == RC_OK)
        {
            PPT_METHODTRACE_V1("", "Now TCS subSystem is alive!! Go ahead.");
            break;
        }
        else if( rc == RC_EXT_SERVER_BIND_FAIL ||
                 rc == RC_EXT_SERVER_NIL_OBJ   ||
                 rc == RC_TCS_NO_RESPONSE)
        {
            PPT_METHODTRACE_V2("", "TCS subSystem has return NO_RESPONSE!! just retry now!! now count...",i);
            PPT_METHODTRACE_V2("", "now sleeping...",sleepTimeValue);
            sleep(sleepTimeValue);
            continue;
        }
        else
        {
            PPT_METHODTRACE_V2("", "TCSMgr_SendBWSInventoryReq != RC_OK, rc=",rc);
            strBWSInventoryReqResult.strResult = strTCSMgr_SendBWSInventoryInq_out.strResult;
            
            // set message
            memset( description, '\0', sizeof(description));
            sprintf(description,
                    "TCS Send BWS Inventory Upload Fail. claimMemo:%s #TxID:%s ",
                    claimMemo,(const char*)strObjCommonIn.transactionID);
                    
            memset( condition, '\0', sizeof(condition));
            sprintf(condition,
                    "TCS Send BWS Inventory Upload Fail. TCS Other Error: rc=%s",rc);
                    
            memset( exHandling, '\0', sizeof(exHandling));
            sprintf(exHandling,
                    "TCS Send BWS Inventory Fail (Mode change fail).");      

            msgCnt = strBWSInventoryReqResult.strBWSInvMsgSeq.length();
            strBWSInventoryReqResult.strBWSInvMsgSeq.length(msgCnt+1);
            strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].bwsID             = CIMFWStrDup(strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.BWSID.identifier);
            strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].zoneID            = CIMFWStrDup("");
            strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].waferID           = CIMFWStrDup("");
            strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].lotID             = CIMFWStrDup("");
            strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].description       = CIMFWStrDup(description);
            strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].condition         = CIMFWStrDup(condition);
            strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].exceptionHandling = CIMFWStrDup(exHandling);
            
            return (rc);
        }   
    }
    
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "TCSMgr_SendEqpDetailInfoInq()!= RC_OK, rc=",rc);
        strBWSInventoryReqResult.strResult = strTCSMgr_SendBWSInventoryInq_out.strResult;
        
        // set message
        memset( description, '\0', sizeof(description));
        sprintf(description,
                "TCS Send BWS Inventory Upload Fail. claimMemo:%s #TxID:%s ",
                claimMemo,(const char*)strObjCommonIn.transactionID);
                    
        memset( condition, '\0', sizeof(condition));
        sprintf(condition,
                "TCS Send BWS Inventory Upload Fail. TCS Error: rc=%s",rc);
                    
        memset( exHandling, '\0', sizeof(exHandling));
        sprintf(exHandling,
                "TCS Send BWS Inventory Fail (Mode change fail).");      

        msgCnt = strBWSInventoryReqResult.strBWSInvMsgSeq.length();
        strBWSInventoryReqResult.strBWSInvMsgSeq.length(msgCnt+1);
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].bwsID             =
        CIMFWStrDup(strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.BWSID.identifier);
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].zoneID            = CIMFWStrDup("");
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].waferID           = CIMFWStrDup("");
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].lotID             = CIMFWStrDup("");
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].description       = CIMFWStrDup(description);
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].condition         = CIMFWStrDup(condition);
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].exceptionHandling = CIMFWStrDup(exHandling);
            
        return (rc);       
    }
    
    /*-----------------------------------------------------------*/
    /*  BWS Check 1:                                             */
    /*  BWS Inventory fail and mode change fail if the following */
    /*      conditions happened                                  */
    /*---------------------------------------------------------- */  
    PPT_METHODTRACE_V1("", "###-------- Start to BWS Check 1 : BWS Inventory Fail (mode change fail) condition(s) check --------###");
    
    /*-----------------------------------------------------------*/
    /*  1-1 : check BWSID                                        */
    /*---------------------------------------------------------- */    
    PPT_METHODTRACE_V1("", "###-------- 1-1 check BWSID");
    PPT_METHODTRACE_V2("", "   [from Inventory]", strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.BWSID.identifier);
    PPT_METHODTRACE_V2("", "   [from Config]",    strBWSConfigInfo.BWSID.identifier);

    if(strBWS_WaferList_GetDR_out.strBWSDataSeq.length() ==0 ||
       0!= CIMFWStrCmp( strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.BWSID.identifier,
                        strBWS_WaferList_GetDR_out.strBWSDataSeq[0].BWSID.identifier)||
       0!= CIMFWStrCmp( strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.BWSID.identifier,
                        strBWSConfigInfo.BWSID.identifier))    
    {
        // set message
        memset( description, '\0', sizeof(description));
        sprintf(description,
                "BWS ID Mismatch. claimMemo:%s #TxID:%s ",
                claimMemo,(const char*)strObjCommonIn.transactionID);
                    
        memset( condition, '\0', sizeof(condition));

        if(strBWS_WaferList_GetDR_out.strBWSDataSeq.length() > 0 )
        {
            sprintf(condition,
                    "BWS ID %s Mismatch. #(config)%s #(MES)%s #(Inventory)%s ",
                    (const char*)equipmentID.identifier,
                    (const char*)strBWSConfigInfo.BWSID.identifier,
                    (const char*)strBWS_WaferList_GetDR_out.strBWSDataSeq[0].BWSID.identifier,
                    (const char*)strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.BWSID.identifier);
        }
        else
        {
            sprintf(condition,
                    "BWS ID %s Mismatch. #(config)%s #(MES)%s #(Inventory)%s ",
                    (const char*)equipmentID.identifier,
                    (const char*)strBWSConfigInfo.BWSID.identifier,
                    "",
                    (const char*)strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.BWSID.identifier);
        }      
                    
        memset( exHandling, '\0', sizeof(exHandling));
        sprintf(exHandling,
                "BWS Inventory fail (Mode change fail).");      

        msgCnt = strBWSInventoryReqResult.strBWSInvMsgSeq.length();
        strBWSInventoryReqResult.strBWSInvMsgSeq.length(msgCnt+1);
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].bwsID             =
        CIMFWStrDup(strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.BWSID.identifier);
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].zoneID            = CIMFWStrDup("");
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].waferID           = CIMFWStrDup("");
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].lotID             = CIMFWStrDup("");
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].description       = CIMFWStrDup(description);
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].condition         = CIMFWStrDup(condition);
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].exceptionHandling = CIMFWStrDup(exHandling);
            
        // return
        PPT_METHODTRACE_V1("", "BWS ID mismatch!!!");
        
        CS_PPT_SET_MSG_RC_KEY1( strBWSInventoryReqResult,
                            CS_MSG_BWS_INVENTORY_MISMATCH_BWSID,
                            CS_RC_BWS_INVENTORY_MISMATCH_BWSID,
                            equipmentID.identifier);
        return CS_RC_BWS_INVENTORY_MISMATCH_BWSID;
    }
    
    /*-----------------------------------------------------------*/
    /*  1-2 : check BWS capacity                                 */
    /*---------------------------------------------------------- */ 
    PPT_METHODTRACE_V1("", "###-------- 1-2 check BWS capacity(waferCount)");
    PPT_METHODTRACE_V2("", "   [from Inventory] used Capacity",            strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.usedCapacity);
    PPT_METHODTRACE_V2("", "   [from Config] maxCapacity",                 strBWSConfigInfo.maxCapacity);

    if(strBWSConfigInfo.maxCapacity < strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.usedCapacity)  
    {
        // set message
        memset( description, '\0', sizeof(description));
        sprintf(description,
                "BWS Inventory used capacity is out of range(BWS Config max. capacity). claimMemo:%s #TxID:%s ",
                claimMemo,(const char*)strObjCommonIn.transactionID);
                    
        memset( condition, '\0', sizeof(condition));
        sprintf(condition,
                "BWS %s Inventory used capacity is out of BWS Config max. capacity. #(config)%ld #(Inventory)%ld ",
                (const char*)equipmentID.identifier,
                strBWSConfigInfo.maxCapacity,
                strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.usedCapacity);
                    
        memset( exHandling, '\0', sizeof(exHandling));
        sprintf(exHandling,
                "BWS Inventory fail (Mode change fail).");      

        msgCnt = strBWSInventoryReqResult.strBWSInvMsgSeq.length();
        strBWSInventoryReqResult.strBWSInvMsgSeq.length(msgCnt+1);
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].bwsID             =
        CIMFWStrDup(strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.BWSID.identifier);
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].zoneID            = CIMFWStrDup("");
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].waferID           = CIMFWStrDup("");
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].lotID             = CIMFWStrDup("");
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].description       = CIMFWStrDup(description);
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].condition         = CIMFWStrDup(condition);
        strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].exceptionHandling = CIMFWStrDup(exHandling);
            
        // return
        PPT_METHODTRACE_V1("", "BWS Inventory Max. capacity is out of the range of BWS Config Max. capacity!!!");
        CORBA::String_var usedCapacityBWSInventory = ConvertLongtoString( strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.usedCapacity );
        CORBA::String_var maxCapacityBWSConfig     = ConvertLongtoString( strBWSConfigInfo.maxCapacity );
        CS_PPT_SET_MSG_RC_KEY2( strBWSInventoryReqResult,
                             CS_MSG_BWS_INVENTORY_INVALID_BWS_CAPACITY,
                             CS_RC_BWS_INVENTORY_INVALID_BWS_CAPACITY,
                             usedCapacityBWSInventory,
                             maxCapacityBWSConfig);
        return CS_RC_BWS_INVENTORY_INVALID_BWS_CAPACITY;        
    }        
    
    /*-----------------------------------------------------------*/
    /*  1-3 : check each zone capacity of BWS                    */
    /*---------------------------------------------------------- */ 
    PPT_METHODTRACE_V1("", "###-------- 1-3 check zone capacity(waferCount)");
    
    CORBA::Long zoneInvCnt = strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq.length();
    CORBA::Long zoneConfigCnt = strBWSConfigInfo.strZoneConfigInfoSeq.length();
    CORBA::Boolean zoneFoundInConfig = FALSE;
    for( ix=0;ix<zoneInvCnt;ix++)
    {
        zoneFoundInConfig=FALSE;
        for(iy=0;iy<zoneConfigCnt;iy++)
        {
            if( 0 == CIMFWStrCmp(strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].zoneID,
                                 strBWSConfigInfo.strZoneConfigInfoSeq[iy].zoneID))
            {                              
                PPT_METHODTRACE_V2("", "BWS Zone Found in Config!!! zone=",strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].zoneID);
                zoneFoundInConfig=TRUE;
                
                if(strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].usedCapacity >
                   strBWSConfigInfo.strZoneConfigInfoSeq[ix].maxCapacity)
                {                 
                    PPT_METHODTRACE_V1("", "BWS Zone used capacity is out of the range of Zone Config Max. capacity!!!");
            
                    CORBA::String_var usedCapacityZoneInv = ConvertLongtoString( strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].usedCapacity );
                    CORBA::String_var maxCapacityZoneConfig     = ConvertLongtoString( strBWSConfigInfo.strZoneConfigInfoSeq[ix].maxCapacity );
                
                    CS_PPT_SET_MSG_RC_KEY2( strBWSInventoryReqResult,
                                         CS_MSG_BWS_INVENTORY_INVALID_ZONE_CAPACITY,
                                         CS_RC_BWS_INVENTORY_INVALID_ZONE_CAPACITY,
                                         usedCapacityZoneInv,
                                         maxCapacityZoneConfig);           
                    return CS_RC_BWS_INVENTORY_INVALID_ZONE_CAPACITY;  
                }                  
            }
        }
        
        if(zoneFoundInConfig==FALSE)
        {
            PPT_METHODTRACE_V2("", "BWS Zone Not Found in Config!!! zone=",strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].zoneID);
            CS_PPT_SET_MSG_RC_KEY2( strBWSInventoryReqResult,
                             CS_MSG_BWS_CONFIG_NOT_FOUND_ZONE,
                             CS_RC_BWS_CONFIG_NOT_FOUND_ZONE,
                             strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].zoneID,
                             strBWSInventoryReqInParm.BWSID.identifier);
            return CS_RC_BWS_CONFIG_NOT_FOUND_ZONE;
        }
    }
    
	/*----------------------------------------------------------------------------------------*/
	/*  BWS Check 2: (wafer ID check)                                                         */
	/*  BWS Inventory ok but the result has mismatch between  current inventory and existing  */
	/*      MES data, using BWS inventory uploaded result as accurate data                    */
	/*--------------------------------------------------------------------------------------- */
	PPT_METHODTRACE_V1("", "###--------- Start to BWS Check 2 : BWS Inventory ok, result mismatch condition(s) check & process ---------###");
        
    /*-----------------------------------------------------------*/
    /*  2-1 : Parse ZoneInvInfoSeq by Wafer State                */
    /*---------------------------------------------------------- */    
    CORBA::Long  lnCnt_WaferNotInBWS_Del_Zone= 0;    
	CORBA::Long  lnCnt_WaferInBank_Add_Zone  = 0;
	CORBA::Long  lnCnt_WaferOnFloor_Zone     = 0;
	CORBA::Long  lnCnt_WaferNotExist_Zone    = 0;
    
    csZoneInventoryInfoSequence strZoneInvInfoSeq_WaferNotInBWS_Del;    
    csZoneInventoryInfoSequence strZoneInvInfoSeq_WaferInBank_Add;
    csZoneInventoryInfoSequence strZoneInvInfoSeq_WaferOnFloor;
    csZoneInventoryInfoSequence strZoneInvInfoSeq_WaferNotExist;
    
	zoneInvCnt = strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq.length();  
    CORBA::ULong nlMaxLenZone = 5;
    strZoneInvInfoSeq_WaferNotInBWS_Del.length(nlMaxLenZone);        
    strZoneInvInfoSeq_WaferInBank_Add.length(nlMaxLenZone);
    strZoneInvInfoSeq_WaferOnFloor.length(nlMaxLenZone);
    strZoneInvInfoSeq_WaferNotExist.length(nlMaxLenZone); 
	for (ix = 0; ix < zoneInvCnt; ix++)
	{
        lnCnt_WaferNotInBWS_Del_Zone = 0;        
        lnCnt_WaferInBank_Add_Zone   = 0;
        lnCnt_WaferOnFloor_Zone      = 0; 
        lnCnt_WaferNotExist_Zone     = 0;
        
        if( ix>= nlMaxLenZone )
        {
            nlMaxLenZone += 5;
            strZoneInvInfoSeq_WaferNotInBWS_Del.length(nlMaxLenZone);        
            strZoneInvInfoSeq_WaferInBank_Add.length(nlMaxLenZone);
            strZoneInvInfoSeq_WaferOnFloor.length(nlMaxLenZone);
            strZoneInvInfoSeq_WaferNotExist.length(nlMaxLenZone);	
        }
        
        strZoneInvInfoSeq_WaferNotInBWS_Del[ix].zoneID  = CIMFWStrDup(strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].zoneID);        
        strZoneInvInfoSeq_WaferInBank_Add[ix].zoneID    = CIMFWStrDup(strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].zoneID);
        strZoneInvInfoSeq_WaferOnFloor[ix].zoneID       = CIMFWStrDup(strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].zoneID);      
        strZoneInvInfoSeq_WaferNotExist[ix].zoneID      = CIMFWStrDup(strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].zoneID);  

        CORBA::ULong nlMaxLen_WaferNotInBWS_Del = 5;
        CORBA::ULong nlMaxLen_WaferInBank_Add = 5;
        CORBA::ULong nlMaxLen_WaferOnFloor = 5;
        CORBA::ULong nlMaxLen_WaferNotExist = 5;
		strZoneInvInfoSeq_WaferNotInBWS_Del[ix].strWaferInvInfoSeq.length(nlMaxLen_WaferNotInBWS_Del);
		strZoneInvInfoSeq_WaferInBank_Add[ix].strWaferInvInfoSeq.length(nlMaxLen_WaferInBank_Add);
		strZoneInvInfoSeq_WaferOnFloor[ix].strWaferInvInfoSeq.length(nlMaxLen_WaferOnFloor);
		strZoneInvInfoSeq_WaferNotExist[ix].strWaferInvInfoSeq.length(nlMaxLen_WaferNotExist);

		CORBA::Long waferCnt = strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].strWaferInvInfoSeq.length();
		PPT_METHODTRACE_V2("", "BWS Check 2 zoneId=", strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].zoneID);
		for (iy = 0; iy < waferCnt; iy++)
		{
			PPT_METHODTRACE_V2("", "BWS Check 2 waferId=", strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].strWaferInvInfoSeq[iy].waferID.identifier);
            
            // get LotID
            objWafer_lot_Get_out strWafer_lot_Get_out;
            rc = wafer_lot_Get( strWafer_lot_Get_out, 
                                strObjCommonIn,
                                strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].strWaferInvInfoSeq[iy].waferID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2(" ", "# RC_OK != wafer_lot_Get()", rc);
                strBWSInventoryReqResult.strResult = strWafer_lot_Get_out.strResult;
                return( rc );
            }
            
            // get Lot Info
            pptLotInfoInqResult__160 strLotInfoInqResult; 
            objectIdentifierSequence lotIDs;
            lotIDs.length(1);
            lotIDs[0] = strWafer_lot_Get_out.lotID;
            
            rc = txLotInfoInq__160 ( strLotInfoInqResult,  //DSN000096135
                                     strObjCommonIn,
                                     lotIDs,
                                     TRUE,       // lotBasicInfoFlag
                                     FALSE,      // lotControlUseInfoFlag
                                     FALSE,      // lotFlowBatchInfoFlag
                                     FALSE,      // lotNoteFlagInfoFlag
                                     FALSE,      // lotOperationInfoFlag
                                     FALSE,      // lotOrderInfoFlag
                                     FALSE,      // lotControlJobInfoFlag
                                     TRUE,       // lotProductInfoFlag
                                     FALSE,      // lotRecipeInfoFlag
                                     FALSE,      // lotLocationInfoFlag
                                     FALSE,      // lotWipOperationInfoFlag
                                     FALSE,      // lotWaferAttributesFlag
                                     FALSE,      // lotListInCassetteInfoFlag
                                     FALSE,      // waferMapInCassetteInfoFlag
                                     FALSE );    // lotBackupInfoFlag
                                                
            if( rc != RC_OK ) 
            {
                PPT_METHODTRACE_V2("", "txLotInfoInq__160() != RC_OK, rc=", rc);
                strBWSInventoryReqResult.strResult = strLotInfoInqResult.strResult;
                return (rc);  
            }
            
            if(2==strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].strWaferInvInfoSeq[iy].currentWaferState)
            {
                PPT_METHODTRACE_V1(" ", "BWS Check 2 currentWaferState == 2!!!");                

                if(0<strLotInfoInqResult.strLotInfo.length())
                {
                    lnLen=strLotInfoInqResult.strLotInfo[0].strLotBasicInfo.strLotStatusList.length();
                    for (CORBA::Long k=0;k<lnLen;k++)
                    {
                        if(0 == CIMFWStrCmp(strLotInfoInqResult.strLotInfo[0].strLotBasicInfo.strLotStatusList[k].stateName,SP_LotStateCat_InventoryState) &&
                           0 == CIMFWStrCmp(strLotInfoInqResult.strLotInfo[0].strLotBasicInfo.strLotStatusList[k].stateValue,SP_Lot_InventoryState_InBank))
                            {
                                PPT_METHODTRACE_V2(" ", "BWS Check 2 stateName =",strLotInfoInqResult.strLotInfo[0].strLotBasicInfo.strLotStatusList[k].stateName);
                                PPT_METHODTRACE_V2(" ", "BWS Check 2 stateValue=",strLotInfoInqResult.strLotInfo[0].strLotBasicInfo.strLotStatusList[k].stateValue);
                                
                                if( lnCnt_WaferInBank_Add_Zone >= nlMaxLen_WaferInBank_Add )
                                {
                                    nlMaxLen_WaferInBank_Add += 5;
                                    strZoneInvInfoSeq_WaferInBank_Add[ix].strWaferInvInfoSeq.length(nlMaxLen_WaferInBank_Add);
                                }                                								
								strZoneInvInfoSeq_WaferInBank_Add[ix].strWaferInvInfoSeq[lnCnt_WaferInBank_Add_Zone] = strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].strWaferInvInfoSeq[iy];
                                lnCnt_WaferInBank_Add_Zone++;                                
                                break;                               
                            }
                        else if(0 == CIMFWStrCmp(strLotInfoInqResult.strLotInfo[0].strLotBasicInfo.strLotStatusList[k].stateName,SP_LotStateCat_InventoryState) &&
                                0 == CIMFWStrCmp(strLotInfoInqResult.strLotInfo[0].strLotBasicInfo.strLotStatusList[k].stateValue,SP_Lot_InventoryState_OnFloor))
                            {
                                PPT_METHODTRACE_V2(" ", "BWS Check 2 stateName =",strLotInfoInqResult.strLotInfo[0].strLotBasicInfo.strLotStatusList[k].stateName);
                                PPT_METHODTRACE_V2(" ", "BWS Check 2 stateValue=",strLotInfoInqResult.strLotInfo[0].strLotBasicInfo.strLotStatusList[k].stateValue);

                                if( lnCnt_WaferOnFloor_Zone >= nlMaxLen_WaferOnFloor )
                                {
                                    nlMaxLen_WaferOnFloor += 5;
 								    strZoneInvInfoSeq_WaferOnFloor[ix].strWaferInvInfoSeq.length(nlMaxLen_WaferOnFloor); 
                                }  
								strZoneInvInfoSeq_WaferOnFloor[ix].strWaferInvInfoSeq[lnCnt_WaferOnFloor_Zone] = strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].strWaferInvInfoSeq[iy];
                                lnCnt_WaferOnFloor_Zone++;
                                break;                                     
                            }
                    }
                }               
            }            
            else if(0==strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].strWaferInvInfoSeq[iy].currentWaferState)
            {
                PPT_METHODTRACE_V1(" ", "BWS Check 2 currentWaferState == 0!!!");
             
                if(0<strLotInfoInqResult.strLotInfo.length())
                {
                    lnLen=strLotInfoInqResult.strLotInfo[0].strLotBasicInfo.strLotStatusList.length();
                    for (CORBA::Long k=0;k<lnLen;k++)
                    {                     
                        if( lnCnt_WaferNotInBWS_Del_Zone >= nlMaxLen_WaferNotInBWS_Del )
                        {
                            nlMaxLen_WaferNotInBWS_Del += 5;
						    strZoneInvInfoSeq_WaferNotInBWS_Del[ix].strWaferInvInfoSeq.length(nlMaxLen_WaferNotInBWS_Del);
                        } 
						strZoneInvInfoSeq_WaferNotInBWS_Del[ix].strWaferInvInfoSeq[lnCnt_WaferNotInBWS_Del_Zone] = strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].strWaferInvInfoSeq[iy];
                        lnCnt_WaferNotInBWS_Del_Zone++;
                        break; 
                    }
                }                                 
            }
            else if(-1==strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].strWaferInvInfoSeq[iy].currentWaferState)
            {
                PPT_METHODTRACE_V1(" ", "BWS Check 2 currentWaferState == -1!!!");
             
                if(0<strLotInfoInqResult.strLotInfo.length())
                {
                    lnLen=strLotInfoInqResult.strLotInfo[0].strLotBasicInfo.strLotStatusList.length();
                    for (CORBA::Long k=0;k<lnLen;k++)
                    {                     
                        if( lnCnt_WaferNotExist_Zone >= nlMaxLen_WaferNotExist )
                        {
                            nlMaxLen_WaferNotExist += 5;
					    	strZoneInvInfoSeq_WaferNotExist[ix].strWaferInvInfoSeq.length(nlMaxLen_WaferNotExist);
                        } 
						strZoneInvInfoSeq_WaferNotExist[ix].strWaferInvInfoSeq[lnCnt_WaferNotExist_Zone] = strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].strWaferInvInfoSeq[iy];
                        lnCnt_WaferNotExist_Zone++;
                        break; 
                    }
                }                                 
            }             
		}
        strZoneInvInfoSeq_WaferInBank_Add[ix].strWaferInvInfoSeq.length(nlMaxLen_WaferInBank_Add);
        strZoneInvInfoSeq_WaferOnFloor[ix].strWaferInvInfoSeq.length(nlMaxLen_WaferOnFloor); 
        strZoneInvInfoSeq_WaferNotInBWS_Del[ix].strWaferInvInfoSeq.length(nlMaxLen_WaferNotInBWS_Del);
        strZoneInvInfoSeq_WaferNotExist[ix].strWaferInvInfoSeq.length(nlMaxLen_WaferNotExist);
	}
    strZoneInvInfoSeq_WaferNotInBWS_Del.length(ix);        
    strZoneInvInfoSeq_WaferInBank_Add.length(ix);
    strZoneInvInfoSeq_WaferOnFloor.length(ix);
    strZoneInvInfoSeq_WaferNotExist.length(ix);
     
    /*-----------------------------------------------------------*/
    /*  2-2 : check each zone capacity of BWS                    */
    /*---------------------------------------------------------- */ 
    PPT_METHODTRACE_V1("", "###-------- 2-2 check zone capacity(waferCount)");
    
    zoneInvCnt = strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq.length();
    zoneConfigCnt = strBWSConfigInfo.strZoneConfigInfoSeq.length();
    zoneFoundInConfig = FALSE;
    for( ix=0;ix<zoneInvCnt;ix++)
    {
        for(iy=0;iy<zoneConfigCnt;iy++)
        {
            if( 0 == CIMFWStrCmp(strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].zoneID,
                                 strBWSConfigInfo.strZoneConfigInfoSeq[iy].zoneID))
            {    

				for (CORBA::Long ip = 0; ip < strBWS_WaferList_GetDR_out.strBWSDataSeq[0].strBWSZoneDataSeq.length(); ip++)
				{
					if (0 == CIMFWStrCmp(strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].zoneID,
						                 strBWS_WaferList_GetDR_out.strBWSDataSeq[0].strBWSZoneDataSeq[ip].zoneID))
					{
						CORBA::Long lnWaferCountNewMES = strBWS_WaferList_GetDR_out.strBWSDataSeq[0].strBWSZoneDataSeq[ip].strBWSWaferDataSeq.length() -
							                             strZoneInvInfoSeq_WaferNotInBWS_Del[ix].strWaferInvInfoSeq.length() + strZoneInvInfoSeq_WaferInBank_Add[ix].strWaferInvInfoSeq.length();

						if (lnWaferCountNewMES > strBWSConfigInfo.strZoneConfigInfoSeq[iy].maxCapacity)
						{
							PPT_METHODTRACE_V1("", "MES Zone Wafer count + wafer count add - wafer count delete is out of the range of Zone Config max. capacity!!!");
							PPT_METHODTRACE_V2("", "MES Zone wafer count = ", strBWS_WaferList_GetDR_out.strBWSDataSeq[0].strBWSZoneDataSeq[ip].strBWSWaferDataSeq.length());
							PPT_METHODTRACE_V2("", "MES Zone wafer count add = ", strZoneInvInfoSeq_WaferInBank_Add[ix].strWaferInvInfoSeq.length());
							PPT_METHODTRACE_V2("", "MES Zone wafer count delete = ", strZoneInvInfoSeq_WaferNotInBWS_Del[ix].strWaferInvInfoSeq.length());
							PPT_METHODTRACE_V2("", "Zone Config max. capacity = ", strBWSConfigInfo.strZoneConfigInfoSeq[iy].maxCapacity);

							char errMsg[1024];
							char waferListAdd[2048];
							char waferListDelete[2048];
							memset(errMsg, '\0', sizeof(errMsg));
							memset(waferListAdd, '\0', sizeof(waferListAdd));
							memset(waferListDelete, '\0', sizeof(waferListDelete));
                            
                            CORBA::Long iq = 0;
							for (iq = 0; iq < strZoneInvInfoSeq_WaferNotInBWS_Del[ix].strWaferInvInfoSeq.length(); iq++)
							{
								if (strlen(waferListDelete) == 0)
								{
									sprintf(waferListDelete, "%s", (const char*)strZoneInvInfoSeq_WaferNotInBWS_Del[ix].strWaferInvInfoSeq[iq].waferID.identifier);
								}
								else
								{
									sprintf(waferListDelete + strlen(waferListDelete), ",%s", (const char*)strZoneInvInfoSeq_WaferNotInBWS_Del[ix].strWaferInvInfoSeq[iq].waferID.identifier);
								}

							}

							for (iq = 0; iq < strZoneInvInfoSeq_WaferInBank_Add[ix].strWaferInvInfoSeq.length(); iq++)
							{
								if (strlen(waferListAdd) == 0)
								{
									sprintf(waferListAdd, "%s", (const char*)strZoneInvInfoSeq_WaferInBank_Add[ix].strWaferInvInfoSeq[iq].waferID.identifier);
								}
								else
								{
									sprintf(waferListAdd + strlen(waferListAdd), ",%s", (const char*)strZoneInvInfoSeq_WaferInBank_Add[ix].strWaferInvInfoSeq[iq].waferID.identifier);
								}
							}
							sprintf(errMsg, "MES Zone [%s] wafer count (%ld) + wafer count add (%ld) - wafer count delete (%ld) is out of range of Zone Config max. capacity (%ld) \nWafer List to add: %s\n Wafer List to delete: %s!",
								    (const char*)strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.strZoneInvInfoSeq[ix].zoneID,
								    strBWS_WaferList_GetDR_out.strBWSDataSeq[0].strBWSZoneDataSeq[ip].strBWSWaferDataSeq.length(),
								    strZoneInvInfoSeq_WaferInBank_Add[ix].strWaferInvInfoSeq.length(),
								    strZoneInvInfoSeq_WaferNotInBWS_Del[ix].strWaferInvInfoSeq.length(),
								    strBWSConfigInfo.strZoneConfigInfoSeq[iy].maxCapacity,
								    waferListDelete,
								    waferListAdd);

							CORBA::String_var strErrMsg = CIMFWStrDup(errMsg);

							CS_PPT_SET_MSG_RC_KEY1(strBWSInventoryReqResult,
								                   CS_MSG_BWS_INVENTORY_ERROR,
								                   CS_RC_BWS_INVENTORY_ERROR,
								                   strErrMsg);
							return CS_RC_BWS_INVENTORY_ERROR;
						}
					}
				}
            }
        }
    }    
    
    
 //   /*--------------------------------------------------------------*/
 //   /*  2-3-1 : Inventory Wafer strZoneInvInfoSeq_WaferNotInBWS_Del */
 //   /*--------------------------------------------------------------*/
 //   PPT_METHODTRACE_V1("", "BWS Check 2-3-1 Inventory Wafer strZoneInvInfoSeq_WaferNotInBWS_Del");
	//zoneInvCnt = strZoneInvInfoSeq_WaferNotInBWS_Del.length();       
	//for (ix = 0; ix < zoneInvCnt; ix++)
	//{
	//	CORBA::Long waferCnt = strZoneInvInfoSeq_WaferNotInBWS_Del[ix].strWaferInvInfoSeq.length();
	//	PPT_METHODTRACE_V2("", "BWS Check 2-3-1 zoneId=", strZoneInvInfoSeq_WaferNotInBWS_Del[ix].zoneID);
	//	for (iy = 0; iy < waferCnt; iy++)
	//	{
	//		PPT_METHODTRACE_V2("", "BWS Check 2-3-1 waferId=", strZoneInvInfoSeq_WaferNotInBWS_Del[ix].strWaferInvInfoSeq[iy].waferID.identifier);
 //           
 //           // get LotID
 //           objWafer_lot_Get_out strWafer_lot_Get_out;
 //           rc = wafer_lot_Get( strWafer_lot_Get_out, 
 //                               strObjCommonIn,
 //                               strZoneInvInfoSeq_WaferNotInBWS_Del[ix].strWaferInvInfoSeq[iy].waferID );
 //           if ( rc != RC_OK )
 //           {
 //               PPT_METHODTRACE_V2(" ", "# RC_OK != wafer_lot_Get()", rc);
 //               strBWSInventoryReqResult.strResult = strWafer_lot_Get_out.strResult;
 //               return( rc );
 //           }
 //           
 //           // get Lot Info
 //           pptLotInfoInqResult__160 strLotInfoInqResult; 
 //           objectIdentifierSequence lotIDs;
 //           lotIDs.length(1);
 //           lotIDs[0] = strWafer_lot_Get_out.lotID;
 //           
 //           rc = txLotInfoInq__160 ( strLotInfoInqResult,  //DSN000096135
 //                                    strObjCommonIn,
 //                                    lotIDs,
 //                                    TRUE,       // lotBasicInfoFlag
 //                                    FALSE,      // lotControlUseInfoFlag
 //                                    FALSE,      // lotFlowBatchInfoFlag
 //                                    FALSE,      // lotNoteFlagInfoFlag
 //                                    FALSE,      // lotOperationInfoFlag
 //                                    FALSE,      // lotOrderInfoFlag
 //                                    FALSE,      // lotControlJobInfoFlag
 //                                    TRUE,       // lotProductInfoFlag
 //                                    FALSE,      // lotRecipeInfoFlag
 //                                    FALSE,      // lotLocationInfoFlag
 //                                    FALSE,      // lotWipOperationInfoFlag
 //                                    FALSE,      // lotWaferAttributesFlag
 //                                    FALSE,      // lotListInCassetteInfoFlag
 //                                    FALSE,      // waferMapInCassetteInfoFlag
 //                                    FALSE );    // lotBackupInfoFlag
 //                                               
 //           if( rc != RC_OK ) 
 //           {
 //               PPT_METHODTRACE_V2("", "txLotInfoInq__160() != RC_OK, rc=", rc);
 //               strBWSInventoryReqResult.strResult = strLotInfoInqResult.strResult;
 //               return (rc);  
 //           }
 //           
 //           //Wafer List Delete
 //           csObjBWS_WaferList_DeleteDR_out   strBWS_WaferList_DeleteDR_out;
 //           csObjBWS_WaferList_DeleteDR_in    strBWS_WaferList_DeleteDR_in;
 //           strBWS_WaferList_DeleteDR_in.BWSID               = strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.BWSID;
 //           strBWS_WaferList_DeleteDR_in.zoneID              = CIMFWStrDup(strZoneInvInfoSeq_WaferNotInBWS_Del[ix].zoneID);
 //           strBWS_WaferList_DeleteDR_in.waferIDs.length(1);
 //           strBWS_WaferList_DeleteDR_in.waferIDs[0] = strZoneInvInfoSeq_WaferNotInBWS_Del[ix].strWaferInvInfoSeq[iy].waferID;                            
 //                      
 //           rc=cs_BWS_WaferList_DeleteDR (strBWS_WaferList_DeleteDR_out,
 //                                         strObjCommonIn,
 //                                         strBWS_WaferList_DeleteDR_in,
 //                                         claimMemo);
 //                     

 //           if( rc!= RC_OK)
 //           {
 //               PPT_METHODTRACE_V2("", "cs_BWS_WaferList_DeleteDR() != RC_OK, rc=", rc);
 //               strBWSInventoryReqResult.strResult = strBWS_WaferList_DeleteDR_out.strResult;
 //               return (rc);
 //           }
 //           
 //           // Hold Bank Lot
 //           pptHoldBankLotReqResult strHoldBankLotReqResult;
 //           strHoldBankLotReqResult.strHoldBankLotResult.length(1);
 //           CORBA::Long lotSeqLen = 0;
 //           lotIDs.length(1);
 //           lotIDs[0] = strWafer_lot_Get_out.lotID;

 //           pptObjCommonIn tmpObjCommonIn;
 //           tmpObjCommonIn = strObjCommonIn;
 //           tmpObjCommonIn.strUser.userID = strObjCommonIn.strUser.userID;
 //           
 //           objectIdentifier reasonCodeID;
 //           reasonCodeID.identifier = CIMFWStrDup(CS_Reason_BWS_Hold);

 //           rc = txHoldBankLotReq( strHoldBankLotReqResult,
 //                                  tmpObjCommonIn, 
 //                                  lotSeqLen,
 //                                  lotIDs,
 //                                  reasonCodeID,
 //                                  claimMemo ); 
 //           if( rc != RC_OK )
 //           {
 //               PPT_METHODTRACE_V1("","txHoldBankLotReq() != RC_OK" );
 //               strBWSInventoryReqResult.strResult = strHoldBankLotReqResult.strResult;
 //               return (rc);
 //           }  
 //           
 //           // Set Message
 //           memset( description, '\0', sizeof(description));
 //           sprintf(description,
 //                   "Wafer not in BWS. claimMemo:%s #TxID:%s ",
 //                   claimMemo,(const char*)strObjCommonIn.transactionID);
 //                   
 //           memset( condition, '\0', sizeof(condition));
 //           sprintf(condition,
 //                   "Wafer not in BWS.");
 //                   
 //           memset( exHandling, '\0', sizeof(exHandling));
 //           sprintf(exHandling,
 //                   "cs_BWS_WaferList_DeleteDR & txHoldBankLotReq.");  
 //                   
 //           msgCnt = strBWSInventoryReqResult.strBWSInvMsgSeq.length();
 //           strBWSInventoryReqResult.strBWSInvMsgSeq.length(msgCnt+1);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].bwsID             = CIMFWStrDup(strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.BWSID.identifier);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].zoneID            = CIMFWStrDup(strZoneInvInfoSeq_WaferNotInBWS_Del[ix].zoneID);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].waferID           = CIMFWStrDup(strZoneInvInfoSeq_WaferNotInBWS_Del[ix].strWaferInvInfoSeq[iy].waferID.identifier);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].lotID             = CIMFWStrDup(strWafer_lot_Get_out.lotID.identifier);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].description       = CIMFWStrDup(description);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].condition         = CIMFWStrDup(condition);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].exceptionHandling = CIMFWStrDup(exHandling);            
 //       }                                 	
	//}
 //   
 //   /*--------------------------------------------------------------*/
 //   /*  2-3-2 : Inventory Wafer strZoneInvInfoSeq_WaferInBank_Add   */
 //   /*--------------------------------------------------------------*/  
 //   PPT_METHODTRACE_V1("", "BWS Check 2-3-2 Inventory Wafer strZoneInvInfoSeq_WaferInBank_Add");    
	//zoneInvCnt = strZoneInvInfoSeq_WaferInBank_Add.length();       
	//for (ix = 0; ix < zoneInvCnt; ix++)
	//{
	//	CORBA::Long waferCnt = strZoneInvInfoSeq_WaferInBank_Add[ix].strWaferInvInfoSeq.length();
	//	PPT_METHODTRACE_V2("", "BWS Check 2-3-2 zoneId=", strZoneInvInfoSeq_WaferInBank_Add[ix].zoneID);
	//	for (iy = 0; iy < waferCnt; iy++)
	//	{
	//		PPT_METHODTRACE_V2("", "BWS Check 2-3-2 waferId=", strZoneInvInfoSeq_WaferInBank_Add[ix].strWaferInvInfoSeq[iy].waferID.identifier);
 //           
 //           // get LotID
 //           objWafer_lot_Get_out strWafer_lot_Get_out;
 //           rc = wafer_lot_Get( strWafer_lot_Get_out, 
 //                               strObjCommonIn,
 //                               strZoneInvInfoSeq_WaferInBank_Add[ix].strWaferInvInfoSeq[iy].waferID );
 //           if ( rc != RC_OK )
 //           {
 //               PPT_METHODTRACE_V2("", "# RC_OK != wafer_lot_Get()", rc);
 //               strBWSInventoryReqResult.strResult = strWafer_lot_Get_out.strResult;
 //               return( rc );
 //           }
 //           
 //           // get Lot Info
 //           pptLotInfoInqResult__160 strLotInfoInqResult; 
 //           objectIdentifierSequence lotIDs;
 //           lotIDs.length(1);
 //           lotIDs[0] = strWafer_lot_Get_out.lotID;
 //           
 //           rc = txLotInfoInq__160 ( strLotInfoInqResult,  //DSN000096135
 //                                    strObjCommonIn,
 //                                    lotIDs,
 //                                    TRUE,       // lotBasicInfoFlag
 //                                    FALSE,      // lotControlUseInfoFlag
 //                                    FALSE,      // lotFlowBatchInfoFlag
 //                                    FALSE,      // lotNoteFlagInfoFlag
 //                                    FALSE,      // lotOperationInfoFlag
 //                                    FALSE,      // lotOrderInfoFlag
 //                                    FALSE,      // lotControlJobInfoFlag
 //                                    TRUE,       // lotProductInfoFlag
 //                                    FALSE,      // lotRecipeInfoFlag
 //                                    FALSE,      // lotLocationInfoFlag
 //                                    FALSE,      // lotWipOperationInfoFlag
 //                                    FALSE,      // lotWaferAttributesFlag
 //                                    FALSE,      // lotListInCassetteInfoFlag
 //                                    FALSE,      // waferMapInCassetteInfoFlag
 //                                    FALSE );    // lotBackupInfoFlag
 //                                               
 //           if( rc != RC_OK ) 
 //           {
 //               PPT_METHODTRACE_V2("", "txLotInfoInq__160() != RC_OK, rc=", rc);
 //               strBWSInventoryReqResult.strResult = strLotInfoInqResult.strResult;
 //               return (rc);  
 //           }
 //           
 //           //Wafer List Add
 //           csObjBWS_WaferList_AddDR_out   strBWS_WaferList_AddDR_out;
 //           csObjBWS_WaferList_AddDR_in    strBWS_WaferList_AddDR_in;
 //           strBWS_WaferList_AddDR_in.BWSID                               = strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.BWSID;
 //           strBWS_WaferList_AddDR_in.zoneID                              = CIMFWStrDup(strZoneInvInfoSeq_WaferInBank_Add[ix].zoneID);
 //           strBWS_WaferList_AddDR_in.strBWSWaferDataSeq.length(1);
 //           strBWS_WaferList_AddDR_in.strBWSWaferDataSeq[0].waferID       = strZoneInvInfoSeq_WaferInBank_Add[ix].strWaferInvInfoSeq[iy].waferID;
 //           strBWS_WaferList_AddDR_in.strBWSWaferDataSeq[0].waferGradeID  = CIMFWStrDup("");
 //           strBWS_WaferList_AddDR_in.strBWSWaferDataSeq[0].lotID         = strWafer_lot_Get_out.lotID;
 //           strBWS_WaferList_AddDR_in.strBWSWaferDataSeq[0].bankID        = strLotInfoInqResult.strLotInfo[0].strLotBasicInfo.bankID;
 //           strBWS_WaferList_AddDR_in.strBWSWaferDataSeq[0].productID     = strLotInfoInqResult.strLotInfo[0].strLotProductInfo.productID;
 //           strBWS_WaferList_AddDR_in.strBWSWaferDataSeq[0].subLotType    = CIMFWStrDup(strLotInfoInqResult.strLotInfo[0].strLotBasicInfo.subLotType);                              
 //              
 //           rc=cs_BWS_WaferList_AddDR (strBWS_WaferList_AddDR_out,
 //                                      strObjCommonIn,
 //                                      strBWS_WaferList_AddDR_in,
 //                                      claimMemo);
 //             

 //           if( rc!= RC_OK)
 //           {
 //               PPT_METHODTRACE_V2("", "cs_BWS_WaferList_AddDR() != RC_OK, rc=", rc);
 //               strBWSInventoryReqResult.strResult = strBWS_WaferList_AddDR_out.strResult;
 //               return (rc);
 //           }
 //            
 //           // Set Message           
 //           memset( description, '\0', sizeof(description));
 //           sprintf(description,
 //                   "Wafer in BWS but not input-parm. Wafer is InBank. claimMemo:%s #TxID:%s ",
 //                   claimMemo,(const char*)strObjCommonIn.transactionID);
 //                   
 //           memset( condition, '\0', sizeof(condition));
 //           sprintf(condition,
 //                   "Wafer in BWS but not input-parm. Wafer is InBank.");
 //                   
 //           memset( exHandling, '\0', sizeof(exHandling));
 //           sprintf(exHandling,
 //                   "cs_BWS_WaferList_AddDR.");  
 //           
 //           msgCnt = strBWSInventoryReqResult.strBWSInvMsgSeq.length();
 //           strBWSInventoryReqResult.strBWSInvMsgSeq.length(msgCnt+1);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].bwsID             = CIMFWStrDup(strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.BWSID.identifier);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].zoneID            = CIMFWStrDup(strZoneInvInfoSeq_WaferInBank_Add[ix].zoneID);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].waferID           = strZoneInvInfoSeq_WaferInBank_Add[ix].strWaferInvInfoSeq[iy].waferID.identifier;
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].lotID             = CIMFWStrDup(strWafer_lot_Get_out.lotID.identifier);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].description       = CIMFWStrDup(description);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].condition         = CIMFWStrDup(condition);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].exceptionHandling = CIMFWStrDup(exHandling);   
 //       }                                 	
	//}  

 //   /*--------------------------------------------------------------*/
 //   /*  2-3-3 : Inventory Wafer strZoneInvInfoSeq_WaferOnFloor      */
 //   /*--------------------------------------------------------------*/  
 //   PPT_METHODTRACE_V1("", "BWS Check 2-3-3 Inventory Wafer strZoneInvInfoSeq_WaferOnFloor");    
	//zoneInvCnt = strZoneInvInfoSeq_WaferOnFloor.length();       
	//for (ix = 0; ix < zoneInvCnt; ix++)
	//{
	//	CORBA::Long waferCnt = strZoneInvInfoSeq_WaferOnFloor[ix].strWaferInvInfoSeq.length();
	//	PPT_METHODTRACE_V2("", "BWS Check 2-3-3 zoneId=", strZoneInvInfoSeq_WaferOnFloor[ix].zoneID);
	//	for (iy = 0; iy < waferCnt; iy++)
	//	{
	//		PPT_METHODTRACE_V2("", "BWS Check 2-3-3 waferId=", strZoneInvInfoSeq_WaferOnFloor[ix].strWaferInvInfoSeq[iy].waferID.identifier);
 //           
 //           // get LotID
 //           objWafer_lot_Get_out strWafer_lot_Get_out;
 //           rc = wafer_lot_Get( strWafer_lot_Get_out, 
 //                               strObjCommonIn,
 //                               strZoneInvInfoSeq_WaferOnFloor[ix].strWaferInvInfoSeq[iy].waferID );
 //           if ( rc != RC_OK )
 //           {
 //               PPT_METHODTRACE_V2("", "# RC_OK != wafer_lot_Get()", rc);
 //               strBWSInventoryReqResult.strResult = strWafer_lot_Get_out.strResult;
 //               return( rc );
 //           }
 //           
 //           // get Lot Info
 //           pptLotInfoInqResult__160 strLotInfoInqResult; 
 //           objectIdentifierSequence lotIDs;
 //           lotIDs.length(1);
 //           lotIDs[0] = strWafer_lot_Get_out.lotID;
 //           
 //           rc = txLotInfoInq__160 ( strLotInfoInqResult,  //DSN000096135
 //                                    strObjCommonIn,
 //                                    lotIDs,
 //                                    TRUE,       // lotBasicInfoFlag
 //                                    FALSE,      // lotControlUseInfoFlag
 //                                    FALSE,      // lotFlowBatchInfoFlag
 //                                    FALSE,      // lotNoteFlagInfoFlag
 //                                    FALSE,      // lotOperationInfoFlag
 //                                    FALSE,      // lotOrderInfoFlag
 //                                    FALSE,      // lotControlJobInfoFlag
 //                                    TRUE,       // lotProductInfoFlag
 //                                    FALSE,      // lotRecipeInfoFlag
 //                                    FALSE,      // lotLocationInfoFlag
 //                                    FALSE,      // lotWipOperationInfoFlag
 //                                    FALSE,      // lotWaferAttributesFlag
 //                                    FALSE,      // lotListInCassetteInfoFlag
 //                                    FALSE,      // waferMapInCassetteInfoFlag
 //                                    FALSE );    // lotBackupInfoFlag
 //                                               
 //           if( rc != RC_OK ) 
 //           {
 //               PPT_METHODTRACE_V2("", "txLotInfoInq__160() != RC_OK, rc=", rc);
 //               strBWSInventoryReqResult.strResult = strLotInfoInqResult.strResult;
 //               return (rc);  
 //           }
 //           
 //           objectIdentifier  dummyID;
 //           pptHoldListSequence  strHoldListSeq;
 //           strHoldListSeq.length(1);
 //           strHoldListSeq[0].holdType                    = CIMFWStrDup(SP_HoldType_LotHold);
 //           strHoldListSeq[0].holdReasonCodeID.identifier = CIMFWStrDup(CS_Reason_BWS_Hold);
 //           strHoldListSeq[0].holdUserID                  = strObjCommonIn.strUser.userID;
 //           strHoldListSeq[0].responsibleOperationMark    = CIMFWStrDup(SP_ResponsibleOperation_Current);
 //           strHoldListSeq[0].relatedLotID                = dummyID;
 //           strHoldListSeq[0].claimMemo                   = claimMemo;
 //           
 //           pptHoldLotReqResult  strHoldLotReqResult;
 //           rc = txHoldLotReq( strHoldLotReqResult, 
 //                              strObjCommonIn, 
 //                              strWafer_lot_Get_out.lotID, 
 //                              strHoldListSeq );
 //           if ( rc != RC_OK )
 //           {
 //               PPT_METHODTRACE_V2( "","txHoldLotReq() != RC_OK", rc );
 //               strBWSInventoryReqResult.strResult = strHoldLotReqResult.strResult;
 //               return (rc);
 //           }
 //           
 //           // Set Message 
 //           memset( description, '\0', sizeof(description));
 //           sprintf(description,
 //                   "Wafer in BWS but not input-parm. Wafer is OnFloor. claimMemo:%s #TxID:%s ",
 //                   claimMemo,(const char*)strObjCommonIn.transactionID);
 //                   
 //           memset( condition, '\0', sizeof(condition));
 //           sprintf(condition,
 //                   "Wafer in BWS but not input-parm. Wafer is OnFloor.");
 //                   
 //           memset( exHandling, '\0', sizeof(exHandling));
 //           sprintf(exHandling,
 //                   "txHoldLotReq.");  
 //           
 //           msgCnt = strBWSInventoryReqResult.strBWSInvMsgSeq.length();
 //           strBWSInventoryReqResult.strBWSInvMsgSeq.length(msgCnt+1);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].bwsID             = CIMFWStrDup(strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.BWSID.identifier);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].zoneID            = CIMFWStrDup(strZoneInvInfoSeq_WaferOnFloor[ix].zoneID);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].waferID           = strZoneInvInfoSeq_WaferOnFloor[ix].strWaferInvInfoSeq[iy].waferID.identifier;
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].lotID             = CIMFWStrDup(strWafer_lot_Get_out.lotID.identifier);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].description       = CIMFWStrDup(description);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].condition         = CIMFWStrDup(condition);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].exceptionHandling = CIMFWStrDup(exHandling);   
 //       }                                 	
	//} 

 //   /*--------------------------------------------------------------*/
 //   /*  2-3-4 : Inventory Wafer strZoneInvInfoSeq_WaferNotExist     */
 //   /*--------------------------------------------------------------*/   
 //   PPT_METHODTRACE_V1("", "BWS Check 2-3-4 Inventory Wafer strZoneInvInfoSeq_WaferNotExist");  
	//zoneInvCnt = strZoneInvInfoSeq_WaferNotExist.length();       
	//for (ix = 0; ix < zoneInvCnt; ix++)
	//{
	//	CORBA::Long waferCnt = strZoneInvInfoSeq_WaferNotExist[ix].strWaferInvInfoSeq.length();
	//	PPT_METHODTRACE_V2("", "BWS Check 2-3-4 zoneId=", strZoneInvInfoSeq_WaferNotExist[ix].zoneID);
	//	for (iy = 0; iy < waferCnt; iy++)
	//	{
	//		PPT_METHODTRACE_V2("", "BWS Check 2-3-4 waferId=", strZoneInvInfoSeq_WaferNotExist[ix].strWaferInvInfoSeq[iy].waferID.identifier);           
 //           
 //           // get LotID
 //           objWafer_lot_Get_out strWafer_lot_Get_out;
 //           rc = wafer_lot_Get( strWafer_lot_Get_out, 
 //                               strObjCommonIn,
 //                               strZoneInvInfoSeq_WaferOnFloor[ix].strWaferInvInfoSeq[iy].waferID );
 //           if ( rc != RC_OK )
 //           {
 //               PPT_METHODTRACE_V2("", "# RC_OK != wafer_lot_Get()", rc);
 //               strBWSInventoryReqResult.strResult = strWafer_lot_Get_out.strResult;
 //               return( rc );
 //           }
 //           
 //           objectIdentifierSequence lotIDs;        
 //           lotIDs.length(1);
 //           lotIDs[0] = strWafer_lot_Get_out.lotID;
 //           
 //           objectIdentifier  dummyID;
	//		PPT_METHODTRACE_V1("", "The BWS's mail action flag is on, so mail is send.");
	//		pptSystemMsgRptResult strSystemMsgRptResult;
	//		rc = txSystemMsgRpt(strSystemMsgRptResult,
	//			                strObjCommonIn,
	//			                SP_SubSystemID_MM,                           //subSystemID
	//			                SP_SystemMsgCode_PSMExec,                    //systemMessageCode
	//			                "",                                          //systemMessageText
	//			                TRUE,                                        //notifyFalg
	//			                equipmentID,                                 //equipmentID
	//			                "",                                          //equipmentStatus
	//			                dummyID,                                     //stockerID
	//			                "",                                          //stockerStatus
	//			                dummyID,                                     //AGVID
	//			                "",                                          //AGStatus
	//			                lotIDs[0],                                   //lotID
	//			                "",                                          //lotStatus
	//			                dummyID,                                     //routeID
	//			                dummyID,                                     //operationID
	//			                "",                                          //operationNumber
	//			                strObjCommonIn.strTimeStamp.reportTimeStamp, //systemMessageTimeStamp
	//			                claimMemo);                                  //claimMemo
 //           if ( rc != RC_OK )
 //           {
 //               PPT_METHODTRACE_V1("","txSystemMsgRpt() != RC_OK");
 //               strBWSInventoryReqResult.strResult=strSystemMsgRptResult.strResult;
 //               return (rc);
 //           }                

 //          // Set Message 
 //           memset( description, '\0', sizeof(description));
 //           sprintf(description,
 //                   "Wafer in BWS but not input-parm. Wafer is OnFloor. claimMemo:%s #TxID:%s ",
 //                   claimMemo,(const char*)strObjCommonIn.transactionID);
 //                   
 //           memset( condition, '\0', sizeof(condition));
 //           sprintf(condition,
 //                   "Wafer in BWS but not input-parm. Wafer is OnFloor.");
 //                   
 //           memset( exHandling, '\0', sizeof(exHandling));
 //           sprintf(exHandling,
 //                   "txHoldLotReq.");  
 //           
 //           msgCnt = strBWSInventoryReqResult.strBWSInvMsgSeq.length();
 //           strBWSInventoryReqResult.strBWSInvMsgSeq.length(msgCnt+1);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].bwsID             = CIMFWStrDup(strTCSMgr_SendBWSInventoryInq_out.strBWSInventoryInfo.BWSID.identifier);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].zoneID            = CIMFWStrDup(strZoneInvInfoSeq_WaferNotExist[ix].zoneID);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].waferID           = strZoneInvInfoSeq_WaferNotExist[ix].strWaferInvInfoSeq[iy].waferID.identifier;
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].lotID             = CIMFWStrDup(strWafer_lot_Get_out.lotID.identifier);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].description       = CIMFWStrDup(description);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].condition         = CIMFWStrDup(condition);
 //           strBWSInventoryReqResult.strBWSInvMsgSeq[msgCnt].exceptionHandling = CIMFWStrDup(exHandling);   
 //       }                                 	
	//} 
 //   
  return (rc);
}