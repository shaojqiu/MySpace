//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// SiView
// Name: cs_txBankInReqOR.cpp
//

#include "cs_pptmgr.hpp"

// Class: PPTManager
//
// Service: txBankInReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/08          S.Kawabe       Initial Release (R30)
// 2001/08/13 P4000090 K.Kido         Set return structure in sequence
// 2003/02/25 P4200571 K.Matsuei      Data inconsistency by MonitorLot's Scrap/BankIn.
// 2003/09/09 P5000145 H.Adachi       Fix Message and Message Macro mismatch.
// 2003/12/05 P5100063 K.Matsuei      OpeComp fails by AutoBankIn.
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2004/11/08 P6000017 S.Yamamoto     Fix : Object Lock missing or delay. 
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/30 DSIV00000214 S.Miyata       Multi Fab Transfer Support
// 2013/01/23 DSN000050720 M.Ogawa        Skip cassette lock in Post Process parallel execution
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------  -------------- -------------------------------------------
// 2017/10/28 INN-R170016   JJ.Zhang       Equipment Monitor ehnancement
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptBankInReqResult& strBankInReqResult
//     const pptObjCommonIn& strObjCommonIn
//     CORBA::Long seqIndex
//     const objectIdentifierSequence& lotID
//     const char * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

//INN-R170016 CORBA::Long PPTManager_i::txBankInReq (pptBankInReqResult& strBankInReqResult,
CORBA::Long CS_PPTManager_i::txBankInReq (pptBankInReqResult& strBankInReqResult, //INN-R170016
                                       const pptObjCommonIn& strObjCommonIn,
                                       CORBA::Long seqIndex,
                                       const objectIdentifierSequence& lotID,
//D6000025                                        const char * claimMemo,
//D6000025                                        CORBA::Environment &IT_env)
                                       const char * claimMemo //D6000025
                                       CORBAENV_LAST_CPP)     //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txBankInReq") ;
    CORBA::Long rc = RC_OK ;

    objectIdentifier aLotID ;
    objectIdentifier aCassetteID ;
    aLotID = lotID[seqIndex] ;

    //P6000017 start
    /*------------------------------------------------------------------------*/
    /*   Get lot / cassette connection                                        */
    /*------------------------------------------------------------------------*/
    objLot_cassette_Get_out strLot_cassette_Get_out ;
    rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txBankInReq", "lot_cassette_Get() != RC_OK") ;
        strBankInReqResult.strResult = strLot_cassette_Get_out.strResult ;
        strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        strBankInReqResult.strBankInLotResult[seqIndex].lotID = aLotID ;
        return(rc);
    }
    aCassetteID = strLot_cassette_Get_out.cassetteID ;
//DSN000050720 Add Start
    // Get PostProcForLotFlag from thread specific data
    CORBA::Boolean bParallelPostProcFlag = FALSE;
    char* methodName = NULL;
    CORBA::String_var strParallelPostProcFlag;
    try
    {
        methodName = CIMFWStrDup("getThreadSpecificDataString");
        strParallelPostProcFlag = getThreadSpecificDataString(SP_ThreadSpecificData_Key_PostProcParallelFlag);
        CORBA::string_free(methodName);
        methodName = NULL;
    }
    CATCH_GLOBAL_EXCEPTIONS(strBankInReqResult, txBankInReq, methodName);

    PPT_METHODTRACE_V2("", "strParallelPostProcFlag", strParallelPostProcFlag);

    if ( 0 == CIMFWStrCmp(strParallelPostProcFlag, SP_PostProcess_ParallelExecution_ON) )
    {
        PPT_METHODTRACE_V1("","strParallelPostProcFlag=SP_PostProcess_ParallelExecution_ON");
        bParallelPostProcFlag = TRUE;
    }
//DSN000050720 Add End

    /*--------------------------------*/
    /*   Lock objects to be updated   */
    /*--------------------------------*/
    objObject_Lock_out strObject_Lock_out;

//DSN000050720 Add Start
    //----------------------------------------------------------//
    //   Skip cassette lock to increase parallel availability   //
    //   under PostProcess parallel execution                   //
    //----------------------------------------------------------//
    if( FALSE == bParallelPostProcFlag )
    {
        //PostProcess sequential execution
        PPT_METHODTRACE_V1("", "Lock cassette object.");
//DSN000050720 Add End
//DSN000050720 Indent Start
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, aCassetteID, SP_ClassName_PosCassette );
        if (rc != RC_OK)
        {
           PPT_METHODTRACE_V1("PPTManager_i:: txBankInReq ", "object_Lock() rc != RC_OK") ;
           strBankInReqResult.strResult = strObject_Lock_out.strResult ;
           strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(rc);
           return( rc );
        }
//DSN000050720 Indent End
    }   //DSN000050720
    rc = object_Lock( strObject_Lock_out, strObjCommonIn, aLotID, SP_ClassName_PosLot );
    if (rc != RC_OK)
    {
       PPT_METHODTRACE_V1("PPTManager_i:: txBankInReq ", "object_Lock() rc != RC_OK") ;
       strBankInReqResult.strResult = strObject_Lock_out.strResult ;
       strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(rc);        //P4000090
       return( rc );
    }
    //P6000017 end
//DSN000050720 Add Start
    if( TRUE == bParallelPostProcFlag )
    {
        //------------------------------------------------------//
        //   Write Lock MonitorGroup to keep data consistency   //
        //------------------------------------------------------//
        objMonitorGroup_GetDR_out strMonitorGroup_GetDR_out ;
        rc = monitorGroup_GetDR( strMonitorGroup_GetDR_out,
                                 strObjCommonIn,
                                 aLotID ) ;
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "monitorGroup_GetDR() != RC_OK", rc);
            strBankInReqResult.strResult = strMonitorGroup_GetDR_out.strResult;
            return( rc );
        }

        CORBA::ULong monGrpLen = strMonitorGroup_GetDR_out.strMonitorGroups.length();
        PPT_METHODTRACE_V2("", "monGrpLen", monGrpLen);
        for( CORBA::ULong i = 0; i < monGrpLen; i++ )
        {
            PPT_METHODTRACE_V2( "", "Loop for monitor group.", strMonitorGroup_GetDR_out.strMonitorGroups[i].monitorGroupID.identifier ) ;
            rc = object_Lock( strObject_Lock_out, strObjCommonIn, strMonitorGroup_GetDR_out.strMonitorGroups[i].monitorGroupID, SP_ClassName_PosMonitorGroup );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                strBankInReqResult.strResult = strObject_Lock_out.strResult;
                return( rc );
            }
        } //[i]
    }
//DSN000050720 Add End

//P5100063//P4200571 start
//P5100063    PPT_METHODTRACE_V1("", "call lot_monitorGroup_CheckForCancelDR()");
//P5100063    objLot_monitorGroup_CheckForCancelDR_out  strLot_monitorGroup_CheckForCancelDR_out;
//P5100063    rc = lot_monitorGroup_CheckForCancelDR( strLot_monitorGroup_CheckForCancelDR_out, strObjCommonIn, aLotID );
//P5100063
//P5100063    if ( rc != RC_OK )
//P5100063    {
//P5100063        PPT_METHODTRACE_V2("", "##### lot_monitorGroup_CheckForCancelDR() != RC_OK", rc);
//P5100063        strBankInReqResult.strResult = strLot_monitorGroup_CheckForCancelDR_out.strResult;
//P5100063        strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(rc);
//P5100063        return ( rc );
//P5100063    }
//P5100063//P4200571 end
//P5100063 start
    PPT_METHODTRACE_V1("", "call lot_RemoveFromMonitorGroup()");
    objLot_RemoveFromMonitorGroup_out  strLot_RemoveFromMonitorGroup_out;
    rc = lot_RemoveFromMonitorGroup( strLot_RemoveFromMonitorGroup_out, strObjCommonIn, aLotID );

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "##### lot_RemoveFromMonitorGroup() != RC_OK", rc);
        strBankInReqResult.strResult = strLot_RemoveFromMonitorGroup_out.strResult;
        strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(rc);
        return ( rc );
    }
//P5100063 end

//P6000017    /*------------------------------------------------------------------------*/
//P6000017    /*   Get lot / cassette connection                                        */
//P6000017    /*------------------------------------------------------------------------*/
//P6000017    objLot_cassette_Get_out strLot_cassette_Get_out ;
//P6000017    rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, aLotID);
//P6000017    if (rc != RC_OK)
//P6000017    {
//P6000017        PPT_METHODTRACE_V1("PPTManager_i:: txBankInReq", "lot_cassette_Get() != RC_OK") ;
//P6000017        strBankInReqResult.strResult = strLot_cassette_Get_out.strResult ;
//P6000017        strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
//P6000017        strBankInReqResult.strBankInLotResult[seqIndex].lotID = aLotID ;
//P6000017        return(rc);
//P6000017    }
//P6000017    aCassetteID = strLot_cassette_Get_out.cassetteID ;
//P6000017
//P6000017    /*--------------------------------*/
//P6000017    /*   Lock objects to be updated   */
//P6000017    /*--------------------------------*/
//P6000017    objObject_Lock_out strObject_Lock_out;
//P6000017    rc = object_Lock( strObject_Lock_out, strObjCommonIn, aLotID, SP_ClassName_PosLot );
//P6000017    if (rc != RC_OK)
//P6000017    {
//P6000017       PPT_METHODTRACE_V1("PPTManager_i:: txBankInReq ", "object_Lock() rc != RC_OK") ;
//P6000017       strBankInReqResult.strResult = strObject_Lock_out.strResult ;
//P6000017       strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(rc);        //P4000090
//P6000017       return( rc );
//P6000017    }

    // Initialisation of lotid done here itself.
    strBankInReqResult.strBankInLotResult[seqIndex].lotID = aLotID ;

    /*------------------------------------------------------------------------*/
    /*   Check Condition                                                      */
    /*------------------------------------------------------------------------*/
    objLot_state_Get_out strLot_state_Get_out ;
    rc = lot_state_Get(strLot_state_Get_out, strObjCommonIn, aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txBankInReq", "lot_state_Get() != RC_OK") ;
        strBankInReqResult.strResult = strLot_state_Get_out.strResult ;
        strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Active) != 0)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txBankInReq",
                           "CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Active) != 0") ;
        strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(RC_INVALID_LOT_STAT) ;
        PPT_SET_MSG_RC_KEY(strBankInReqResult,
                           MSG_INVALID_LOT_STAT,
                           RC_INVALID_LOT_STAT,
                           strLot_state_Get_out.lotState) ;
        return(RC_INVALID_LOT_STAT);
    }

    objLot_holdState_Get_out strLot_holdState_Get_out ;
    rc = lot_holdState_Get(strLot_holdState_Get_out, strObjCommonIn, aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txBankInReq", "lot_holdState_Get() != RC_OK") ;
        strBankInReqResult.strResult = strLot_holdState_Get_out.strResult ;
        strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState,CIMFW_Lot_HoldState_NotOnHold) != 0 )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txBankInReq",
                           "CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState,CIMFW_Lot_HoldState_NotOnHold) != 0") ;
        strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(RC_INVALID_LOT_HOLDSTAT) ;
        PPT_SET_MSG_RC_KEY2(strBankInReqResult,
                            MSG_INVALID_LOT_HOLDSTAT,
                            RC_INVALID_LOT_HOLDSTAT,
                            aLotID.identifier,
                            strLot_holdState_Get_out.lotHoldState) ;
        return(RC_INVALID_LOT_HOLDSTAT);
    }

    objLot_processState_Get_out strLot_processState_Get_out ;
    rc = lot_processState_Get(strLot_processState_Get_out, strObjCommonIn, aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txBankInReq", "rc") ;
        strBankInReqResult.strResult = strLot_processState_Get_out.strResult ;
        strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Waiting) != 0 )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txBankInReq",
                           "CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Waiting) != 0") ;
        strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(RC_INVALID_LOT_PROCSTAT) ;
        PPT_SET_MSG_RC_KEY2(strBankInReqResult,
                            MSG_INVALID_LOT_PROCSTAT,
                            RC_INVALID_LOT_PROCSTAT,
                            aLotID.identifier,
                            strLot_processState_Get_out.theLotProcessState) ;
        return(RC_INVALID_LOT_PROCSTAT);
    }

    objLot_inventoryState_Get_out strLot_inventoryState_Get_out ;
    rc = lot_inventoryState_Get(strLot_inventoryState_Get_out, strObjCommonIn, aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txBankInReq", "lot_inventoryState_Get() != RC_OK") ;
        strBankInReqResult.strResult = strLot_inventoryState_Get_out.strResult ;
        strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState,SP_Lot_InventoryState_OnFloor) != 0)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txBankInReq",
                           "CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState,SP_Lot_InventoryState_OnFloor) != 0") ;
        strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(RC_INVALID_LOT_INVENTORYSTAT) ;
        PPT_SET_MSG_RC_KEY2(strBankInReqResult,
                            MSG_INVALID_LOT_INVENTORYSTAT,
                            RC_INVALID_LOT_INVENTORYSTAT,
                            aLotID.identifier,
                            strLot_inventoryState_Get_out.lotInventoryState) ;
        return(RC_INVALID_LOT_INVENTORYSTAT);
    }

    objProcess_CheckBankIn_out strProcess_CheckBankIn_out ;
    rc = process_CheckBankIn(strProcess_CheckBankIn_out, strObjCommonIn, aLotID);
    if (rc != RC_BANKIN_OPERATION)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txBankInReq", "process_CheckBankIn() != RC_OK") ;
        strBankInReqResult.strResult = strProcess_CheckBankIn_out.strResult ;
        strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        return(rc);
    }

//DSIV00000214 add start
    //-----------------------------------------------------------
    // Check lot interFabXferState
    //-----------------------------------------------------------
    objLot_interFabXferState_Get_out strLot_interFabXferState_Get_out;
    objLot_interFabXferState_Get_in  strLot_interFabXferState_Get_in;
    strLot_interFabXferState_Get_in.lotID = aLotID;
    rc = lot_interFabXferState_Get( strLot_interFabXferState_Get_out,    
                                    strObjCommonIn,
                                    strLot_interFabXferState_Get_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_interFabXferState_Get() != RC_OK");
        strBankInReqResult.strResult = strLot_interFabXferState_Get_out.strResult;
        return( rc );
    }

    //-----------------------------------------------------------
    // "Transferring"
    //-----------------------------------------------------------
    if( CIMFWStrCmp(strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Transferring) == 0 )
    {
         PPT_METHODTRACE_V1("", "interFabXferState == Transferring");
         PPT_SET_MSG_RC_KEY2( strBankInReqResult,
                              MSG_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ,
                              RC_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ,
                              aLotID.identifier,
                              strLot_interFabXferState_Get_out.interFabXferState );
         return( RC_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ );
    }
//DSIV00000214 add end

//INN-R170016 Add Start
    //----------------------------------------------
    // Get product ID for wafer
    //----------------------------------------------
    objLot_productID_Get_out strLot_productID_Get_out;
    rc = lot_productID_Get( strLot_productID_Get_out,
                            strObjCommonIn,
                            aLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2( "","lot_productID_Get != RC_OK", rc );
        strBankInReqResult.strResult = strLot_productID_Get_out.strResult;
        return rc;
    }
    PPT_METHODTRACE_V2("", "productID", strLot_productID_Get_out.productID.identifier);

    //-----------------------------------------------------------
    //  Check whether lot is NPW downgrade product or not
    //-----------------------------------------------------------
    objLot_lotType_Get_out strLot_lotType_Get_out;
    objLot_lotType_Get_in  strLot_lotType_Get_in;
    strLot_lotType_Get_in.lotID = aLotID;
    rc = lot_lotType_Get( strLot_lotType_Get_out,
                          strObjCommonIn,
                          strLot_lotType_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "lot_lotType_Get() != RC_OK", rc);
        strBankInReqResult.strResult = strLot_lotType_Get_out.strResult;
        return rc;
    }
    PPT_METHODTRACE_V2("", "strLot_lotType_Get_out.lotType", strLot_lotType_Get_out.lotType);

    CORBA::Boolean bRcyclProduct = FALSE;
    if ( 0 != CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_ProductionLot) )
    {
        csObjEqpMonitorInventory_ListGetDR_in strEqpMonitorInventory_ListGetDR_in;
        strEqpMonitorInventory_ListGetDR_in.productID = strLot_productID_Get_out.productID.identifier;

        csObjEqpMonitorInventory_ListGetDR_out strEqpMonitorInventory_ListGetDR_out;
        rc = cs_eqpMonitorInventory_ListGetDR(strEqpMonitorInventory_ListGetDR_out,
                                     strObjCommonIn,
                                     strEqpMonitorInventory_ListGetDR_in) ;

        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cs_eqpMonitorInventory_ListGetDR() rc != RC_OK")
            strBankInReqResult.strResult = strEqpMonitorInventory_ListGetDR_out.strResult ;
            return rc ;
        }
        if( strEqpMonitorInventory_ListGetDR_out.strEqpMonitorInventoryInfoSeq.length() > 0 )
        {
            PPT_METHODTRACE_V1("", "Monitor Recycle Product");
            bRcyclProduct = TRUE;
        }
    }

    if( bRcyclProduct )
    {
        PPT_METHODTRACE_V1("", "Monitor Recycle Product");
        pptObjCommonIn tmpObjCommonIn;
        tmpObjCommonIn = strObjCommonIn;
        tmpObjCommonIn.transactionID = CIMFWStrDup(CS_EqpMonitor_NPW_Type_Recycle);

        objLot_waferMap_Get_out strLot_waferMap_Get_out;
        rc = lot_waferMap_Get(strLot_waferMap_Get_out, strObjCommonIn, aLotID);
        if(rc!= RC_OK)
        {
            PPT_METHODTRACE_V2("", "lot_waferMap_Get() != RC_OK ", rc );
            strBankInReqResult.strResult = strLot_waferMap_Get_out.strResult;
            return( rc );
        }
        CORBA::Long waferLen = strLot_waferMap_Get_out.strLotWaferMap.length();
        objectIdentifierSequence bankInLotIDs;
        bankInLotIDs.length(waferLen);
        bankInLotIDs[0] = aLotID;

        for( CORBA::Long i=1; i<waferLen; i++ )
        {
            objectIdentifierSequence childWaferID;
            childWaferID.length(1);
            childWaferID[0] = strLot_waferMap_Get_out.strLotWaferMap[i].waferID;

            pptSplitWaferLotReqResult strSplitWaferLotReqResult;
            objectIdentifier dummyID;
            dummyID.identifier = CIMFWStrDup("");
            rc = txSplitWaferLotReq( strSplitWaferLotReqResult,
                                     strObjCommonIn,
                                     aLotID,            // parentLotID,
                                     childWaferID,      // childWaferID,
                                     FALSE,             // futureMergeFlag,
                                     dummyID,           // mergedRouteID,
                                     "",                // mergedOperationNumber,
                                     FALSE,             // branchingRouteSpecifyFlag,
                                     dummyID,           // subRouteID,
                                     "",                // returnOperationNumber,
                                     claimMemo );       // claimMemo                                                   
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "txSplitWaferLotReq() != RC_OK", rc);
                strBankInReqResult.strResult = strSplitWaferLotReqResult.strResult;
                return rc;
            }
            bankInLotIDs[i] = strSplitWaferLotReqResult.childLotID;
            PPT_METHODTRACE_V2("", "New splitted lot", bankInLotIDs[i].identifier);
        }
        for( i=0; i<waferLen; i++ )
        {
            PPT_METHODTRACE_V2("", "bank-in lot", bankInLotIDs[i].identifier);
            //------------------------------------------------------
            //  Perform bank-in/product change for every recycle lot
            //------------------------------------------------------
            objLot_BankIn_out strLot_BankIn_out ;
            rc = lot_BankIn(strLot_BankIn_out, tmpObjCommonIn, bankInLotIDs[i]);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "lot_BankIn() != RC_OK") ;
                strBankInReqResult.strResult = strLot_BankIn_out.strResult ;
                strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
                return(rc);
            }
        }
        PPT_METHODTRACE_V2("", "waferLen", waferLen);
    }
    else
    {
        PPT_METHODTRACE_V1("", "normal Product bank-in")
//INN-R170016 Add End
        /*------------------------------------------------------------------------*/
        /*   Change State                                                         */
        /*------------------------------------------------------------------------*/
        objLot_BankIn_out strLot_BankIn ;
        rc = lot_BankIn(strLot_BankIn, strObjCommonIn, aLotID);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txBankInReq", "lot_BankIn() != RC_OK") ;
            strBankInReqResult.strResult = strLot_BankIn.strResult ;
            strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
            return(rc);
        }
    }//INN-R170016

    /*---------------------------------------*/
    /*   Update Cassette's MultiLotType      */
    /*---------------------------------------*/
    objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
    rc = cassette_multiLotType_Update(strCassette_multiLotType_Update_out, strObjCommonIn, aCassetteID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txBankInReq", "cassette_multiLotType_Update() != RC_OK") ;
        strBankInReqResult.strResult = strCassette_multiLotType_Update_out.strResult ;
        strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(rc);        //P4000090
        return(rc);
    }

    /*------------------------------------------------------------------------*/
    /*   Make History                                                         */
    /*------------------------------------------------------------------------*/
    objLotBankMoveEvent_Make_out strLotBankMoveEvent_Make_out;
    rc = lotBankMoveEvent_Make(strLotBankMoveEvent_Make_out, strObjCommonIn, "TXTRC016", aLotID, claimMemo);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txBankInReq", "lotBankMoveEvent_Make() != RC_OK") ;
        strBankInReqResult.strResult = strLotBankMoveEvent_Make_out.strResult ;
        strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
//P5000145        PPT_SET_MSG_RC_KEY(strBankInReqResult,MSG_FAIL_MAKE_HISTORY, rc, aLotID.identifier) ;
        SET_MSG_RC( strBankInReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145
        return(rc);
    }

    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
    strBankInReqResult.strBankInLotResult[seqIndex].returnCode = ConvertLongtoString(RC_OK) ;

    SET_MSG_RC(strBankInReqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txBankInReq") ;
    return(RC_OK);
}
