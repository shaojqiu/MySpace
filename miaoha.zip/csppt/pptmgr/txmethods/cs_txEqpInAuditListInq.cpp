//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2003. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2003. All rights reserved.
//
// SiView
// Name: cs_txEqpInAuditListInq.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: cs_txEqpInAuditListInq()
//
// Change history:
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
//
// Description:
//
// Return:
//     long
//
// Parameter:
//      csEqpInAuditListInqResult&              strCsEqpInAuditListInqResult,
//      const pptObjCommonIn&                   strObjCommonIn,
//      CORBA::Boolean                          bodyFlag,
//      CORBA::Boolean                          constFlag
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_txEqpInAuditListInq(
    csEqpInAuditListInqResult&              strCsEqpInAuditListInqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    CORBA::Boolean                          bodyFlag,
    CORBA::Boolean                          constFlag,
    CORBA::Environment&                     IT_env)
{
    /*------------------------------------------------------------------------*/
    /*   Return Code Initialization                                           */
    /*------------------------------------------------------------------------*/

    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txEqpInAuditListInq")
    CORBA::Long rc = RC_OK ;

    /*-------------------*/
    /*   Get area list   */
    /*-------------------*/
    csObjEquipment_InAuditList_GetDR_out strCsObjEquipment_InAuditList_GetDR_out;
    rc = cs_equipment_InAuditList_GetDR (strCsObjEquipment_InAuditList_GetDR_out, strObjCommonIn, bodyFlag, constFlag);

    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cs_txEqpInAuditListInq() != RC_OK");
        strCsEqpInAuditListInqResult.strResult = strCsObjEquipment_InAuditList_GetDR_out.strResult;
        return( rc );
    }
    strCsEqpInAuditListInqResult.EquipmentIDs = strCsObjEquipment_InAuditList_GetDR_out.EquipmentIDs;

    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
    SET_MSG_RC(strCsEqpInAuditListInqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: cs_txEqpInAuditListInq ") ;
    return(RC_OK);
}
