#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/txWaferSorterOnEqpRpt.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:41:07 [ 7/13/07 21:41:08 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2012. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2012. All rights reserved.
//
// SiView
// Name: txWaferSorterOnEqpRpt.cpp
//

#include "cs_pptmgr.hpp"

// Class: PPTManager
//
// Service: txWaferSorterOnEqpRpt()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2001/07/11 D4000056 M.Shimizu      The first coding (WaferSorter R40 CORE)
// 2001-08-21 P4000099 H.Adachi       Change objectName(waferSorter_SlotMapStatus_UpdateDR to waferSorter_slotMapStatus_UpdateDR)
//                                                     (waferSorter_LotMaterialsScrap to waferSorter_lotMaterials_Scrap)
// 2001/08/23 D4000056 M.Shimizu      Add Param's destinationCassetteManagedBySiViewFlag
//                                                originalCassetteManagedBySiViewFlag
// 2001/08/23 D4000056 M.Shimizu      Add Logic to cassette_MultiLotType_Update()
// 2001/08/31 D4000056 M.Shimizu      Add Logic to originalCassetteID is made NotAvailable in the case of the error, too.
// 2001-09-05 0.0.1    H.Adachi       Add Logic for Empty Cassette Read and Mini Read case
//                                    Add Logic for Prulal Cassette
// 2001-09-06 0.0.2    H.Adachi       Add Logic for SorterStatus Brunk Check
// 2001-09-10 0.0.3    H.Adachi       Add Logic for Empty Carrier Case
// 2001-09-11 0.0.4    M.Shimizu      Add Logic for Multi Cassette Correspondence
// 2001-09-13 0.0.5    M.Shimizu      Add Logic for Multi Cassette Correspondence
// 2001-09-14 0.0.6    M.Shimizu      Edit Return Logic For MiniRead Compare
// 2001-09-14 P4000218 M.Shimizu      MM not accepted cassette status NOTAVELABLE
// 2001-09-26 D4000201 M.Shimizu      Insert TCS reply data to FSSLOTMAP in case of TCS ERRORED
// 2001-10-01 P4000293 M.Shimizu      When treatment inside TCS is error condition, RPT is being made to return it on an error.
// 2001-10-01 P4000300 M.Shimizu      A comparative result surely becomes an error when  Fosb Cassette is compared with Read, MiniRead.
// 2001/10/04 P4000323 M.Shimizu      Bug Fix Unnecessary CheckLogic runs with Adjust.
// 2001/10/05 D4000220 M.Shimizu      If all Wafers inside Lot are being done with Scrap, MM is made be to make of ScrapOut in Cassette to manage.
// 2001/10/23 P4000373 M.Shimizu      Invalid initialization variable.
// 2001/10/23 P4000374 M.Shimizu      It is sometimes finished normally even if the comparative result of MiniRead is wrong.
// 2001/10/23 D4000234 M.Shimizu      Add a Action Code 'AdjustToSorter'
// 2001/10/23 D4000236 M.Shimizu      Update Newly Wafer ID Read DATA in FSSLOTMAP when wafer position was chenged.
// 2001/11/13 P40A0010 M.Shimizu      SlotmapComp of WaferIDMiniRead becomes Errored.
// 2002/10/04 P4200131 H.Adachi       Makes Cassete NotAvailable only MM Compare Error Cassette.
// 2003/10/16 P5100038 H.Adachi       Add CassetteID collection and calling of Multi Lot Type Update for ScrapWaferOut.
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2005/02/25 P6000242 H.Adachi       Fix memory error of BMW and LEAK.
// 2006/05/22 D7000092 Y.Kadowaki     Add object lock for cassette.
// 2007/04/13 P8000194 K.Kido         Add equipment lot in cast info adjustment logic.
// 2007/06/20 D9000005 K.Kido         Wafer Sorter automation support. 
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2012/12/04 DSN000049350 K.Yamaoku      Equipment parallel processing support (P2)
//
// Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/24 INN-R170003   Xinxin Liu     Change Foup state to hold
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptWaferSorterOnEqpRptResult&         strWaferSorterOnEqpRptResult
//     const pptObjCommonIn&                 strObjCommonIn
//     const objectIdentifier&               equipmentID,
//     const char *                          actionCode,
//     const pptWaferSorterSlotMapSequence   strWaferSorterSlotMapSequence,
//     CORBA::Long                           rcTCS
//
//     typedef struct pptWaferSorterSlotMap_struct {
//         string                                    portGroup;
//         objectIdentifier                          equipmentID;
//         string                                    actionCode;
//         string                                    requestTime;
//         string                                    direction;
//         objectIdentifier                          waferID;
//         objectIdentifier                          lotID;
//         objectIdentifier                          destinationCassetteID;
//         objectIdentifier                          destinationPortID;
//         boolean                                   bDestinationCassetteManagedBySiView;
//         long                                      destinationSlotNumber;
//         objectIdentifier                          originalCassetteID;
//         objectIdentifier                          originalPortID;
//         boolean                                   bOriginalCassetteManagedBySiView;
//         long                                      originalSlotNumber;
//         objectIdentifier                          requestUserID;
//         string                                    replyTime;
//         string                                    sorterStatus;
//         string                                    slotMapCompareStatus;
//         string                                    mmCompareStatus;
//     } pptWaferSorterSlotMap;
//
//     typedef sequence <pptWaferSorterSlotMap> pptWaferSorterSlotMapSequence;
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::txWaferSorterOnEqpRpt (pptWaferSorterOnEqpRptResult& strWaferSorterOnEqpRptResult,
                                                 const pptObjCommonIn& strObjCommonIn,
                                                 const objectIdentifier& equipmentID,
                                                 const char * actionCode,
                                                 const pptWaferSorterSlotMapSequence& strWaferSorterSlotMapSequence,
//D6000025                                                  CORBA::Long rcTCS,
//D6000025                                                  CORBA::Environment &IT_env)
                                                 CORBA::Long rcTCS  //D6000025
                                                 CORBAENV_LAST_CPP) //D6000025
{

    PPT_METHODTRACE_ENTRY("PPTManager_i::txWaferSorterOnEqpRpt ")

    //---------------------------------
    // INITIALIZATION
    //---------------------------------
    CORBA::Long rc = RC_OK ;
    CORBA::Long rcParamChk = RC_OK;                     //0.0.2

    CORBA::Long i = 0;
    CORBA::Long j = 0;

    CORBA::String_var strDummyClaimMemo;
    strDummyClaimMemo = CIMFWStrDup("");

    objectIdentifierSequence tmpCassetteIDs;            //0.0.4
    CORBA::Long castLen = 0;                            //0.0.4
    CORBA::Boolean bExist = FALSE;                      //0.0.4

    //P4000099 Start
    //----------------------------------------
    //  Check Equipment ID is SORTER or
    //----------------------------------------
    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","equipment_categoryVsTxID_CheckCombination() returned error.");

        strWaferSorterOnEqpRptResult.strResult
            = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return (rc);
    }
    //P4000099 End

    //-------------------------------------------------------------------------
    //    Check INPUT PARAMETER: TCS Reply Sequence Length Check
    //-------------------------------------------------------------------------
    //0.0.1 Add Start
    CORBA::Long nListLen = strWaferSorterSlotMapSequence.length();

    if ( nListLen == 0 )
    {
        PPT_METHODTRACE_V1("", " In Para strWaferSorterSlotMapSequence.length == 0");
//D4000201        SET_MSG_RC(strWaferSorterOnEqpRptResult,MSG_INVALID_PARAMETER,RC_INVALID_PARAMETER)
//D4000201        return ( RC_INVALID_PARAMETER );
        SET_MSG_RC(strWaferSorterOnEqpRptResult,MSG_INVALID_TCS_RESULT,RC_INVALID_TCS_RESULT)   //D4000201
        return ( RC_INVALID_TCS_RESULT );                                                       //D4000201
    }
    //0.0.1 Add End

    //-------------------------------------------------------------------------
    //    Check INPUT PARAMETER: Action Code exist And Same Data And Sorter Status
    //-------------------------------------------------------------------------
    CORBA::String_var tempRequestTime = strWaferSorterSlotMapSequence[0].requestTime;
    CORBA::String_var tempDirection   = strWaferSorterSlotMapSequence[0].direction;
    CORBA::String_var tempPortGroup   = strWaferSorterSlotMapSequence[0].portGroup;

    for ( i = 0 ; i < nListLen ; i++ )
    {
        //-----------------------------
        //    Check Action Code exist
        //-----------------------------
        if (( CIMFWStrCmp(strWaferSorterSlotMapSequence[i].actionCode,SP_Sorter_Read           ) != 0 ) &&
            ( CIMFWStrCmp(strWaferSorterSlotMapSequence[i].actionCode,SP_Sorter_MiniRead       ) != 0 ) &&
            ( CIMFWStrCmp(strWaferSorterSlotMapSequence[i].actionCode,SP_Sorter_PositionChange ) != 0 ) &&
            ( CIMFWStrCmp(strWaferSorterSlotMapSequence[i].actionCode,SP_Sorter_PositionChangeRead ) != 0 ) && //INN-R170003
            ( CIMFWStrCmp(strWaferSorterSlotMapSequence[i].actionCode,SP_Sorter_JustIn         ) != 0 ) &&
            ( CIMFWStrCmp(strWaferSorterSlotMapSequence[i].actionCode,SP_Sorter_JustOut        ) != 0 ) &&
            ( CIMFWStrCmp(strWaferSorterSlotMapSequence[i].actionCode,SP_Sorter_Scrap          ) != 0 ) &&
            ( CIMFWStrCmp(strWaferSorterSlotMapSequence[i].actionCode,SP_Sorter_AdjustToMM     ) != 0 ) &&      //P4000323
            ( CIMFWStrCmp(strWaferSorterSlotMapSequence[i].actionCode,SP_Sorter_AdjustToSorter ) != 0 ) &&      //D4000234
            ( CIMFWStrCmp(strWaferSorterSlotMapSequence[i].actionCode,SP_Sorter_AutoSorting    ) != 0 ) &&      //D9000005
            ( CIMFWStrCmp(strWaferSorterSlotMapSequence[i].actionCode,actionCode               ) != 0 ))
        {
            PPT_METHODTRACE_V2("", "actionCode Check Error = ", strWaferSorterSlotMapSequence[i].actionCode);
            PPT_SET_MSG_RC_KEY(strWaferSorterOnEqpRptResult,
                               MSG_INVALID_ACTION_CODE,RC_INVALID_ACTION_CODE,
                               strWaferSorterSlotMapSequence[i].actionCode)
//0.0.2            return ( RC_INVALID_ACTION_CODE );
            rcParamChk = RC_INVALID_ACTION_CODE;    //0.0.2
            break;                                  //0.0.2
        }

        //-----------------------------
        //    Check In Parameter
        //-----------------------------
        if(( CIMFWStrCmp(strWaferSorterSlotMapSequence[i].requestTime,tempRequestTime                    ) != 0 ) ||
           ( CIMFWStrCmp(strWaferSorterSlotMapSequence[i].direction,tempDirection                        ) != 0 ) ||
           ( CIMFWStrCmp(strWaferSorterSlotMapSequence[i].portGroup,tempPortGroup                        ) != 0 ) ||
           ( CIMFWStrCmp(strWaferSorterSlotMapSequence[i].equipmentID.identifier,equipmentID.identifier) != 0 ))
        {
            PPT_METHODTRACE_V1("", " Others Code Check Error ");
            SET_MSG_RC(strWaferSorterOnEqpRptResult,MSG_INVALID_PARAMETER,RC_INVALID_PARAMETER)
//0.0.2            return ( RC_INVALID_PARAMETER );
            rcParamChk = RC_INVALID_PARAMETER;      //0.0.2
            break;                                  //0.0.2
        }

        //-------------------------------
        //  Check In sorterStatus exist
        //-------------------------------
        //0.0.2 Add Start
        if ( CIMFWStrCmp(strWaferSorterSlotMapSequence[i].sorterStatus, SP_Sorter_Succeeded ) != 0 )
        {
            PPT_METHODTRACE_V1("", " Sorter Statu Error ");
//D4000201            SET_MSG_RC(strWaferSorterOnEqpRptResult,MSG_INVALID_PARAMETER,RC_INVALID_PARAMETER)
//D4000201            rcParamChk = RC_INVALID_PARAMETER;
            SET_MSG_RC(strWaferSorterOnEqpRptResult,MSG_INVALID_SORTERSTATUS,RC_INVALID_SORTERSTATUS) //D4000201
            rcParamChk = RC_INVALID_SORTERSTATUS;    //D4000201
            break;
        }
        //0.0.2 Add Ebd
    }

//DSN000049350 //P8000194 add start
//DSN000049350     /*--------------------------------*/
//DSN000049350     /*   Lock Macihne object          */
//DSN000049350     /*--------------------------------*/
//DSN000049350     objObject_Lock_out  strObject_Lock_out;
//DSN000049350     rc = object_Lock( strObject_Lock_out, strObjCommonIn, equipmentID, SP_ClassName_PosMachine );
//DSN000049350     if ( rc != RC_OK )
//DSN000049350     {
//DSN000049350         PPT_METHODTRACE_V1("", "object_Lock() != RC_OK") ;
//DSN000049350         strWaferSorterOnEqpRptResult.strResult = strObject_Lock_out.strResult ;
//DSN000049350         return( rc );
//DSN000049350     }
//DSN000049350 //P8000194 add end

//D7000092 add start
    //---------------------------------------------------------------------------------
    // Collect participant cassettes (original/destination) from WaferSorterSlotMapSeq.
    //---------------------------------------------------------------------------------
    CORBA::Long  waferMapLen = strWaferSorterSlotMapSequence.length();
    CORBA::Long  casLen = 0;
    objectIdentifierSequence  cassetteIDs;
    cassetteIDs.length(waferMapLen * 2);

    for( i=0; i<waferMapLen; i++ )
    {
        // interested in SiView managed casettes only.
        if( strWaferSorterSlotMapSequence[i].bOriginalCassetteManagedBySiView == TRUE )
        {
            //P8000194 add start
            CORBA::Boolean dupCastFlag = FALSE ;
            for(CORBA::ULong j= 0 ; j < casLen ; j++ )
            {
                if(0 == CIMFWStrCmp( cassetteIDs[j].identifier, strWaferSorterSlotMapSequence[i].originalCassetteID.identifier))
                {
                    dupCastFlag = TRUE;
                    break;
                }
            }
            //P8000194 add end
            if( FALSE == dupCastFlag )    //P8000194
            {                             //P8000194
                cassetteIDs[casLen] = strWaferSorterSlotMapSequence[i].originalCassetteID;
                PPT_METHODTRACE_V2("","SiView managed original cassette found.", cassetteIDs[casLen].identifier);
                casLen++;
            }                             //P8000194
        }
        if( strWaferSorterSlotMapSequence[i].bDestinationCassetteManagedBySiView == TRUE )
        {
            //P8000194 add start
            CORBA::Boolean dupCastFlag = FALSE ;
            for(CORBA::ULong j= 0 ; j < casLen ; j++ )
            {
                if(0 == CIMFWStrCmp( cassetteIDs[j].identifier, strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier))
                {
                    dupCastFlag = TRUE;
                    break;
                }
            }
            //P8000194 add end
            if( FALSE == dupCastFlag )    //P8000194
            {                             //P8000194
                cassetteIDs[casLen] = strWaferSorterSlotMapSequence[i].destinationCassetteID;
                PPT_METHODTRACE_V2("","SiView managed destination cassette found.", cassetteIDs[casLen].identifier);
                casLen++;
            }                             //P8000194
        }
    }
    cassetteIDs.length(casLen);

//DSN000049350 Add Start
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;

    CORBA::Long sorterJobLockFlag = atoi( getenv(SP_SORTERJOB_LOCK_FLAG) );
    PPT_METHODTRACE_V2("","sorterJobLockFlag", sorterJobLockFlag);

    if ( 1 == sorterJobLockFlag && 0 == CIMFWStrCmp( actionCode, SP_Sorter_AutoSorting ) )
    {
        PPT_METHODTRACE_V1("","sorterJobLockFlag = 1 and actionCode = SP_Sorter_AutoSorting");

        //---------------------------------
        // Lock Sort Jobs
        //---------------------------------
        objectIdentifier dummyID;
        objSorter_sorterJob_LockDR_out strSorter_sorterJob_LockDR_out;
        objSorter_sorterJob_LockDR_in strSorter_sorterJob_LockDR_in;
        strSorter_sorterJob_LockDR_in.sorterJobID          = dummyID;
        strSorter_sorterJob_LockDR_in.sorterComponentJobID = dummyID;
        strSorter_sorterJob_LockDR_in.cassetteID           = cassetteIDs[0];
        strSorter_sorterJob_LockDR_in.lockType             = SP_ObjectLock_LockType_WRITE;

        PPT_METHODTRACE_V1( "", "calling sorter_sorterJob_LockDR()" );
        rc = sorter_sorterJob_LockDR ( strSorter_sorterJob_LockDR_out,
                                       strObjCommonIn,
                                       strSorter_sorterJob_LockDR_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "sorter_sorterJob_LockDR() != RC_OK", rc);
            strWaferSorterOnEqpRptResult.strResult = strSorter_sorterJob_LockDR_out.strResult;
            return( rc );
        }
    }

    CORBA::Long lockMode = SP_EQP_LOCK_MODE_WRITE;
    if ( 1 == sorterJobLockFlag )
    {
        PPT_METHODTRACE_V1("","sorterJobLockFlag = 1");

        // Get required equipment lock mode
        strObject_lockMode_Get_in.objectID           = equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( SP_FunctionCategory_SorterTxID ); // SorterTxID
        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strWaferSorterOnEqpRptResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }
        lockMode = strObject_lockMode_Get_out.lockMode;
    }
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );

    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strWaferSorterOnEqpRptResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }

        // Lock Equipment LoadCassette Element (Write)
        stringSequence loadCastSeq;
        loadCastSeq.length(casLen);
        for ( CORBA::ULong loadCastNo = 0; loadCastNo < casLen; loadCastNo++ )
        {
            loadCastSeq[loadCastNo] = cassetteIDs[loadCastNo].identifier;
        }
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
        strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
        strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_LoadCassette );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strWaferSorterOnEqpRptResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");

        /*--------------------------------*/
        /*   Lock Macihne object          */
        /*--------------------------------*/
        objObject_Lock_out  strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, equipmentID, SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "object_Lock() != RC_OK") ;
            strWaferSorterOnEqpRptResult.strResult = strObject_Lock_out.strResult ;
            return( rc );
        }
    }
//DSN000049350 Add End

    //---------------------------------------
    // Lock cassette objects for update.
    //---------------------------------------
    objObjectSequence_Lock_out  strObjectSequence_Lock_out;
    rc = objectSequence_Lock( strObjectSequence_Lock_out, strObjCommonIn, cassetteIDs, SP_ClassName_PosCassette );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","objectSequence_Lock() rc != RC_OK", rc);
        strWaferSorterOnEqpRptResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }
//D7000092 add end

    //----------------------------------------
    // Set Sorter Status Value for UPDATE
    //----------------------------------------
    CORBA::String_var updateStatus = CIMFWStrDup(SP_Sorter_Errored);
//0.0.2    if ( rcTCS == RC_OK )
    if (( rcTCS == RC_OK ) && ( rcParamChk == RC_OK ))    //0.0.2
    {
        PPT_METHODTRACE_V1("", "rcTCS & rcParamChk == RC_OK : SET SP_Sorter_Succeeded  ");
        updateStatus = CIMFWStrDup(SP_Sorter_Succeeded);
    }

//P4000099    objWaferSorter_SlotMapStatus_UpdateDR_out strWaferSorter_SlotMapStatus_UpdateDR_out;
//P4000099    rc = waferSorter_SlotMapStatus_UpdateDR( strWaferSorter_SlotMapStatus_UpdateDR_out,
//P4000099                                             strObjCommonIn,
//P4000099                                             strWaferSorterSlotMapUpdateReferenceCondition,
//P4000099                                             updateStatus );

    //----------------------------------------
    //  Update Sorter Status On SLOTMAP
    //----------------------------------------
    pptWaferSorterSlotMap  strWaferSorterSlotMapUpdateReferenceCondition;

    strWaferSorterSlotMapUpdateReferenceCondition.portGroup              = CIMFWStrDup(strWaferSorterSlotMapSequence[0].portGroup);
    strWaferSorterSlotMapUpdateReferenceCondition.equipmentID.identifier = equipmentID.identifier;
    strWaferSorterSlotMapUpdateReferenceCondition.actionCode             = CIMFWStrDup(actionCode);
    strWaferSorterSlotMapUpdateReferenceCondition.requestTime            = CIMFWStrDup(strWaferSorterSlotMapSequence[0].requestTime);
    strWaferSorterSlotMapUpdateReferenceCondition.direction              = CIMFWStrDup(SP_Sorter_Direction_MM);
    strWaferSorterSlotMapUpdateReferenceCondition.sorterStatus           = CIMFWStrDup(SP_Sorter_Requested);

    //----------------------------------------
    // Slot Map UPDATE to Requested Record
    //----------------------------------------
    objWaferSorter_slotMapStatus_UpdateDR_out strWaferSorter_slotMapStatus_UpdateDR_out;    //P4000099
    rc = waferSorter_slotMapStatus_UpdateDR( strWaferSorter_slotMapStatus_UpdateDR_out,
                                             strObjCommonIn,
                                             strWaferSorterSlotMapUpdateReferenceCondition,
                                             updateStatus );                                //P4000099

    if(rc != RC_OK)
    {
//P4000099        PPT_METHODTRACE_V2("PPTManager_i::txWaferSorterOnEqpRpt",
//P4000099                           "waferSorter_SlotMapStatus_UpdateDR() != RC_OK", rc);
//P4000099        strWaferSorterOnEqpRptResult.strResult = strWaferSorter_SlotMapStatus_UpdateDR_out.strResult;
        PPT_METHODTRACE_V2("", "waferSorter_slotMapStatus_UpdateDR() != RC_OK", rc);            //P4000099
        strWaferSorterOnEqpRptResult.strResult = strWaferSorter_slotMapStatus_UpdateDR_out.strResult;  //P4000099
        return ( rc );
    }

//D4000201 DELETE START
//D4000201    //0.0.2 Add Start
//D4000201    //------------------------------------
//D4000201    // Judge Parameter Check
//D4000201    //------------------------------------
//D4000201    if ( rcParamChk != RC_OK )
//D4000201    {
//D4000201        PPT_METHODTRACE_V2("", "rcParamChk != RC_OK : rcParamChk = ", rcParamChk);
//D4000201        return(rcParamChk);
//D4000201    }
//D4000201    //0.0.2 Add End
//D4000201 DELETE END

    //------------------------------------
    //  Reserve Writing Buffer All Record
    //------------------------------------
    pptWaferSorterSlotMapSequence strWaferSorterSlotMapWrite;
    strWaferSorterSlotMapWrite = strWaferSorterSlotMapSequence;

//0.0.5 Add Start
    //----------------------------------
    // GET Requesting Slot Map
    //----------------------------------
    pptWaferSorterSlotMap strWaferSorterGetSlotMapReferenceCondition;
    CORBA::String_var requiredData;
    requiredData = CIMFWStrDup(SP_Sorter_SlotMap_LatestData);

    strWaferSorterGetSlotMapReferenceCondition.portGroup                           = CIMFWStrDup(strWaferSorterSlotMapSequence[0].portGroup);
    strWaferSorterGetSlotMapReferenceCondition.equipmentID.identifier              = equipmentID.identifier;
    strWaferSorterGetSlotMapReferenceCondition.actionCode                          = CIMFWStrDup(actionCode);
    strWaferSorterGetSlotMapReferenceCondition.requestTime                         = CIMFWStrDup(strWaferSorterSlotMapSequence[0].requestTime);
    strWaferSorterGetSlotMapReferenceCondition.direction                           = CIMFWStrDup(SP_Sorter_Direction_MM);
    strWaferSorterGetSlotMapReferenceCondition.waferID.identifier                  = CIMFWStrDup("");
    strWaferSorterGetSlotMapReferenceCondition.lotID.identifier                    = CIMFWStrDup("");
    strWaferSorterGetSlotMapReferenceCondition.destinationCassetteID.identifier    = CIMFWStrDup("");
    strWaferSorterGetSlotMapReferenceCondition.destinationPortID.identifier        = CIMFWStrDup("");
    strWaferSorterGetSlotMapReferenceCondition.bDestinationCassetteManagedBySiView = FALSE;
    strWaferSorterGetSlotMapReferenceCondition.destinationSlotNumber               = 0;
    strWaferSorterGetSlotMapReferenceCondition.originalCassetteID.identifier       = CIMFWStrDup("");
    strWaferSorterGetSlotMapReferenceCondition.originalPortID.identifier           = CIMFWStrDup("");
    strWaferSorterGetSlotMapReferenceCondition.bOriginalCassetteManagedBySiView    = FALSE;
    strWaferSorterGetSlotMapReferenceCondition.originalSlotNumber                  = 0;
    strWaferSorterGetSlotMapReferenceCondition.requestUserID.identifier            = CIMFWStrDup("");
    strWaferSorterGetSlotMapReferenceCondition.replyTime                           = CIMFWStrDup("");
    strWaferSorterGetSlotMapReferenceCondition.sorterStatus                        = CIMFWStrDup("");
    strWaferSorterGetSlotMapReferenceCondition.slotMapCompareStatus                = CIMFWStrDup("");
    strWaferSorterGetSlotMapReferenceCondition.mmCompareStatus                     = CIMFWStrDup("");

    objWaferSorter_slotMap_SelectDR_out strWaferSorter_slotMap_SelectDR_out;
    rc = waferSorter_slotMap_SelectDR( strWaferSorter_slotMap_SelectDR_out,
                                       strObjCommonIn,
                                       requiredData,
                                       "",
                                       SP_Sorter_Ignore_SiViewFlag,
                                       SP_Sorter_Ignore_SiViewFlag,
                                       strWaferSorterGetSlotMapReferenceCondition );

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "strWaferSorter_slotMap_SelectDR_out() != RC_OK",rc);
        strWaferSorterOnEqpRptResult.strResult = strWaferSorter_slotMap_SelectDR_out.strResult;
        return ( rc );
    }

    //-------------------------------------------------------------------------
    //  SlotMap Request Sequence Reserve Writing Buffer All Record
    //-------------------------------------------------------------------------
    pptWaferSorterSlotMapSequence strSlotMapRequestSeq;
    strSlotMapRequestSeq = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence;
    CORBA::Long SlotMapRequestLen = strSlotMapRequestSeq.length();

    //-------------------------------------------------------------------------
    //  CassetteIDs of the object is acquired for NOT AVAILABLE.
    //-------------------------------------------------------------------------
    //0.0.4 Add Start
    for(i = 0; i < SlotMapRequestLen; i++)
    {
        //--------------------------------
        //  Get All destinationCassetteID
        //--------------------------------
        bExist = FALSE;
        castLen = tmpCassetteIDs.length();
        for(j = 0; j < castLen; j++)
        {
            if(CIMFWStrCmp(tmpCassetteIDs[j].identifier,strSlotMapRequestSeq[i].destinationCassetteID.identifier) == 0)
            {
                PPT_METHODTRACE_V1("destinationCassetteID", " bExist == TRUE ");
                bExist = TRUE;
            }
        }

        if(bExist == FALSE)
        {
            if(CIMFWStrLen(strSlotMapRequestSeq[i].destinationCassetteID.identifier) != 0)
            {
                castLen++;
                tmpCassetteIDs.length(castLen);
                tmpCassetteIDs[castLen-1] = strSlotMapRequestSeq[i].destinationCassetteID;
            }
        }

        //--------------------------------
        //  Get All originalCassetteID
        //--------------------------------
        bExist = FALSE;
        castLen = tmpCassetteIDs.length();
        for(j = 0; j < castLen; j++)
        {
            if(CIMFWStrCmp(tmpCassetteIDs[j].identifier,strSlotMapRequestSeq[i].originalCassetteID.identifier) == 0)
            {
                PPT_METHODTRACE_V1("originalCassetteID", " bExist == TRUE ");
                bExist = TRUE;
            }
        }

        if(bExist == FALSE)
        {
            if(CIMFWStrLen(strSlotMapRequestSeq[i].originalCassetteID.identifier) != 0)
            {
                castLen++;
                tmpCassetteIDs.length(castLen);
                tmpCassetteIDs[castLen-1] = strSlotMapRequestSeq[i].originalCassetteID;
            }
        }
    }

    //--------------------------------
    //  All CassetteIDs TRACE
    //--------------------------------
    castLen = tmpCassetteIDs.length();
    PPT_METHODTRACE_V2("", "tmpCassetteIDs.length() = ",castLen);

    PPT_METHODTRACE_V1("", "//---------------------------//");
    PPT_METHODTRACE_V1("", "// All CassetteIDs Start     //");
    PPT_METHODTRACE_V1("", "//---------------------------//");

    for(j = 0; j < castLen; j++)
    {
        PPT_METHODTRACE_V2("", "tmpCassetteIDs = ",tmpCassetteIDs[j].identifier);
    }

    PPT_METHODTRACE_V1("", "//---------------------------//");
    PPT_METHODTRACE_V1("", "// All CassetteIDs E n d     //");
    PPT_METHODTRACE_V1("", "//---------------------------//");
    //0.0.4 Add END
    //0.0.5 Add END

    //-------------------------
    //  When TCS RC is ERROR
    //-------------------------
//D4000201    if ( rcTCS != RC_OK )
    if (( rcTCS != RC_OK ) || ( rcParamChk != RC_OK ))    //D4000201
    {
        PPT_METHODTRACE_V2("", "rcTCS != RC_OK", rcTCS);

        //----------------------------------------
        //  MKAE A CASSETTE NOT AVAILABLE
        //----------------------------------------
        castLen = tmpCassetteIDs.length();
        for(i = 0; i < castLen; i++)
        {
           //P4000218 Add Start
           //INN-R-17003 strCassette_getStatusDR_out;
           //INN-R-17003 rc = cassette_getStatusDR( strCassette_getStatusDR_out,
           //INN-R-17003                            strObjCommonIn,
           //INN-R-17003                            tmpCassetteIDs[i] );

           //INN-R-17003 if(rc == RC_NOT_FOUND_CASSETTE)
           //INN-R-17003 {
           //INN-R-17003     PPT_METHODTRACE_V1( "","cassette_getStatusDR() == RC_NOT_FOUND_CASSETTE");
           //INN-R-17003    continue;
           //INN-R-17003 }

           //INN-R-17003 if ( rc != RC_OK )
           //INN-R-17003 {
           //INN-R-17003     PPT_METHODTRACE_V2( "","cassette_getStatusDR() != RC_OK", rc);
           //INN-R-17003     strWaferSorterOnEqpRptResult.strResult = strCassette_getStatusDR_out.strResult;
           //INN-R-17003     return rc;
           //INN-R-17003 }
           //INN-R-17003 PPT_METHODTRACE_V2( "","strCassette_getStatusDR_out.drbl_state--->", strCassette_getStatusDR_out.drbl_state);

           //INN-R-17003 if( CIMFWStrCmp(strCassette_getStatusDR_out.drbl_state, CIMFW_Durable_NotAvailable) == 0)
           //INN-R-17003 {
           //INN-R-17003     PPT_METHODTRACE_V1( "","Cassette Status == Not Available");
           //INN-R-17003     continue;
           //INN-R-17003 }
           //P4000218 Add End

           //INN-R-17003 pptCassetteStatusChangeRptResult strCassetteStatusChangeRptResult;
           //INN-R-17003 rc = txCassetteStatusChangeRpt(strCassetteStatusChangeRptResult,
           //INN-R-17003                                strObjCommonIn,
           //INN-R-17003                                tmpCassetteIDs[i],
           //INN-R-17003                                CIMFW_Durable_NotAvailable,
           //INN-R-17003                                strDummyClaimMemo) ;
           //INN-R-17003 if(rc != RC_OK && rc != RC_NOT_FOUND_CASSETTE)
           //INN-R-17003 {
           //INN-R-17003     PPT_METHODTRACE_V2("", "txCassetteStatusChangeRpt() != RC_OK", rc);
           //INN-R-17003     strWaferSorterOnEqpRptResult.strResult = strCassetteStatusChangeRptResult.strResult;
           //INN-R-17003     return ( rc );
           //INN-R-17003 }
			
           //INN-R-170003 Add Start
            objDurable_subState_Get_out strDurable_subState_Get_out;
            objDurable_subState_Get_in  strDurable_subState_Get_in;
            strDurable_subState_Get_in.durableCategory = CIMFWStrDup(SP_DurableCat_Cassette);
            strDurable_subState_Get_in.durableID = tmpCassetteIDs[i];
            rc = durable_subState_Get(strDurable_subState_Get_out, strObjCommonIn, strDurable_subState_Get_in);
            if (rc == RC_NOT_FOUND_CASSETTE)
            {
                PPT_METHODTRACE_V1("", "cassette_getStatusDR() == RC_NOT_FOUND_CASSETTE");
                continue;
            }
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V2("", "cassette_getStatusDR() != RC_OK", rc);
                strWaferSorterOnEqpRptResult.strResult = strDurable_subState_Get_out.strResult;
                return rc;
            }
            if (0 == CIMFWStrCmp(strDurable_subState_Get_out.durableSubStatus.identifier, CS_FOUP_DURABLE_SUB_STATE_HOLD))
            {
                PPT_METHODTRACE_V1("", "Cassette Status == Foup Hold");
                continue;
            }
            pptDurableStatusMultiChangeReqResult strDurableStatusMultiChangeReqResult;
            pptDurableStatusMultiChangeReqInParm strDurableStatusMultiChangeReqInParm;
            strDurableStatusMultiChangeReqInParm.durableStatus
                = CORBA::string_dup(CIMFW_Durable_NotAvailable);
            strDurableStatusMultiChangeReqInParm.durableSubStatus.identifier
                = CORBA::string_dup(CS_FOUP_DURABLE_SUB_STATE_HOLD);
            strDurableStatusMultiChangeReqInParm.durableCategory
                = CORBA::string_dup(SP_DurableCat_Cassette);
            strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq.length(1);
            strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableID.identifier
                = CORBA::string_dup(tmpCassetteIDs[i].identifier);
            strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableStatus
                = CORBA::string_dup(strDurable_subState_Get_out.durableStatus);
            strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableSubStatus.identifier
				= CORBA::string_dup(strDurable_subState_Get_out.durableSubStatus.identifier);

            rc = txDurableStatusMultiChangeReq(strDurableStatusMultiChangeReqResult, strObjCommonIn, strDurableStatusMultiChangeReqInParm, strDummyClaimMemo);

            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V2("", "txDurableStatusMultiChangeReq() rc != RC_OK", rc);
                strWaferSorterOnEqpRptResult.strResult = strDurableStatusMultiChangeReqResult.strResult;
                return(rc);
            }
            //INN-R-170003 Add End
        }

        //D4000201 ADD START
        if ( rcParamChk != RC_INVALID_PARAMETER )
        {
            //-------------------------------
            //  Insert TCS Data to SLOTMAP
            //-------------------------------
            objWaferSorter_slotMap_InsertDR_out strWaferSorter_slotMap_InsertDR_out;
            rc = waferSorter_slotMap_InsertDR( strWaferSorter_slotMap_InsertDR_out,
                                                   strObjCommonIn,
                                                   strWaferSorterSlotMapWrite );
            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V2("", "waferSorter_SlotMap_InsertDR() != RC_OK", rc);
                strWaferSorterOnEqpRptResult.strResult = strWaferSorter_slotMap_InsertDR_out.strResult;
                return(rc);
            }
        }
        //D4000201 ADD END
//D9000005 add start
        //--------------------------------------------------------------------
        //  Sorter Job Status Update (Executing -> Errored)
        //--------------------------------------------------------------------
        if ( 0 == CIMFWStrCmp( actionCode, SP_Sorter_AutoSorting ) )
        {
            PPT_METHODTRACE_V1("","actionCode == SP_Sorter_AutoSorting");

            objSorter_sorterJob_status_GetDR_in strSorter_sorterJob_status_GetDR_in ;
            strSorter_sorterJob_status_GetDR_in.equipmentID = equipmentID ;
            strSorter_sorterJob_status_GetDR_in.originalCassetteID = strWaferSorterSlotMapSequence[0].originalCassetteID ;
            strSorter_sorterJob_status_GetDR_in.destinationCassetteID = strWaferSorterSlotMapSequence[0].destinationCassetteID;
            strSorter_sorterJob_status_GetDR_in.portGroupID = strWaferSorterSlotMapSequence[0].portGroup;

            objSorter_sorterJob_status_GetDR_out strSorter_sorterJob_status_GetDR_out;
            rc = sorter_sorterJob_status_GetDR( strSorter_sorterJob_status_GetDR_out,
                                                strObjCommonIn,
                                                strSorter_sorterJob_status_GetDR_in );

            if ( rc != RC_OK )
            {
                strWaferSorterOnEqpRptResult.strResult = strSorter_sorterJob_status_GetDR_out.strResult;
                return( rc );
            }

            objectIdentifier portGrp ;
            portGrp.identifier = strWaferSorterSlotMapSequence[0].portGroup;
            pptSortJobStatusChangeRptResult strSortJobStatusChangeRptResult;
            rc = txSortJobStatusChangeRpt( strSortJobStatusChangeRptResult,
                                           strObjCommonIn,
                                           equipmentID,
                                           portGrp,
                                           strSorter_sorterJob_status_GetDR_out.sorterComponentJobID,
                                           SP_Sorter_Job_Type_ComponentJob,
                                           SP_SorterComponentJobStatus_Error,
                                           strDummyClaimMemo );

            if ( rc != RC_OK )
            {
                strWaferSorterOnEqpRptResult.strResult = strSortJobStatusChangeRptResult.strResult;
                return( rc );
            }
        }
//D9000005 add end
    }
    else
    {
        //----------------------------------------
        //   CASE Action Code is Read OR MINI Read
        //----------------------------------------
        if ( CIMFWStrCmp(actionCode,SP_Sorter_Read    ) == 0 ||
             CIMFWStrCmp(actionCode,SP_Sorter_MiniRead) == 0 )
        {
            PPT_METHODTRACE_V1("", "actionCode() == SP_Sorter_Read or SP_Sorter_MiniRead");

            //0.0.3 Add Start
            CORBA::Boolean ckeckSTATUS = TRUE;
            CORBA::Boolean bRecCompStat = FALSE;
            CORBA::Boolean bFosb = FALSE;

            //---------------------------------
            // Check MM and TCS Srlot NO For MINI READ
            //---------------------------------
            if ( CIMFWStrCmp(actionCode,SP_Sorter_MiniRead) == 0 )
            {
                //----------------------------------------
                //  TCS Reply Data -> Request Data Compare
                //----------------------------------------
                CORBA::Long nGetSlotMapDRLen = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence.length();
                CORBA::Boolean bSlotNmCompStat = FALSE;

                if(nListLen == nGetSlotMapDRLen )
                {
                    //----------------------------------------
                    //  Data Compare SLOT NUMBER
                    //----------------------------------------
                    for ( i = 0; i < nListLen; i++ )
                    {
                        bSlotNmCompStat = FALSE;
                        PPT_METHODTRACE_V1("", "//--------------------------------//")
                        PPT_METHODTRACE_V1("", "//       DATA COMPARE START       //")
                        PPT_METHODTRACE_V1("", "//--------------------------------//")
                        for ( j = 0; j < nGetSlotMapDRLen; j++ )
                        {
                            //------------------------------------------
                            // Compare CassetteID,PortID,SlotNumber
                            // MM Request and TCS Reply
                            //------------------------------------------
                            PPT_METHODTRACE_V2("","nWaferMap Count = ",j)
                            PPT_METHODTRACE_V2("","[TCS] destinationCassetteID = ",
                                                       strWaferSorterSlotMapWrite[i].destinationCassetteID.identifier);
                            PPT_METHODTRACE_V2("","[SLOTMAP ] destinationCassetteID = ",
                                                   strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[j].destinationCassetteID.identifier);
                            PPT_METHODTRACE_V2("","[TCS] destinationPortID = ",
                                                   strWaferSorterSlotMapWrite[i].destinationPortID.identifier);
                            PPT_METHODTRACE_V2("","[SLOTMAP ] destinationPortID = ",
                                                   strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[j].destinationPortID.identifier);
                            PPT_METHODTRACE_V2("","[TCS] destinationSlotNumber = ",
                                                   strWaferSorterSlotMapWrite[i].destinationSlotNumber);
                            PPT_METHODTRACE_V2("","[SLOTMAP ] destinationSlotNumber = ",
                                                   strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[j].destinationSlotNumber);
                            PPT_METHODTRACE_V1("", "//--------------------------------//")

                            if((CIMFWStrCmp(strWaferSorterSlotMapWrite[i].destinationCassetteID.identifier,
                                            strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[j].destinationCassetteID.identifier ) == 0) &&
                               (CIMFWStrCmp(strWaferSorterSlotMapWrite[i].destinationPortID.identifier,
                                            strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[j].destinationPortID.identifier     ) == 0) &&
                               (strWaferSorterSlotMapWrite[i].destinationSlotNumber ==
                                            strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[j].destinationSlotNumber))
                            {
                                //P40A0010 Add Start
                                PPT_METHODTRACE_V1("","slotMapCompareStatus = OK(brank) ");
                                strWaferSorterSlotMapWrite[i].slotMapCompareStatus = CIMFWStrDup("");
                                //P40A0010 Add End

                                PPT_METHODTRACE_V1("","bSlotNmCompStat = TRUE ");
                                bSlotNmCompStat = TRUE;
                                break;
                            }
                            else
                            {
                                //P4000374 Add Start
                                PPT_METHODTRACE_V1("","slotMapCompareStatus = SP_Sorter_ERROR ");
                                strWaferSorterSlotMapWrite[i].slotMapCompareStatus = CIMFWStrDup(SP_Sorter_ERROR);
                                //P4000374 Add End
                            }
                        }

                        PPT_METHODTRACE_V1("", "//--------------------------------//")
                        PPT_METHODTRACE_V1("", "//       DATA COMPARE END         //")
                        PPT_METHODTRACE_V1("", "//--------------------------------//")
                        PPT_METHODTRACE_V1("","bSlotNmCompStat Check !!!");

                        //---------------------------------------
                        // Check Compare Status
                        //---------------------------------------
                        if ( bSlotNmCompStat == FALSE )
                        {
                            PPT_METHODTRACE_V1("","Invalid Reply Data !!!");
                            PPT_METHODTRACE_V1("","bSlotNmCompStat ckeckSTATUS = FALSE !!!");
//0.0.6                        SET_MSG_RC(strWaferSorterOnEqpRptResult,MSG_INVALID_PARAMETER,RC_INVALID_PARAMETER)
//0.0.6                        return (RC_INVALID_PARAMETER);
                            ckeckSTATUS = FALSE;    //0.0.6
                        }
                    }
                }
                else
                {
                    ckeckSTATUS = FALSE;    //0.0.
                }
            }
            //0.0.3 Add End (Mini Read)

            //---------------------------------
            //   Get a object length
            //---------------------------------
            objCassette_GetWaferMapDR_out strCassette_GetWaferMapDR_out;
//0.0.1            CORBA::Long nWaferMap = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo.length();
            CORBA::Long nWaferMap = 0;    //0.0.1
            CORBA::Long nSlotMap = strWaferSorterSlotMapWrite.length();

            PPT_METHODTRACE_V2("", "WaferMap Count= ",nWaferMap);
            PPT_METHODTRACE_V2("", "SlotMap Count = ",nSlotMap);

            CORBA::String_var strTempCassetteID = CIMFWStrDup("");    //0.0.1

            //P4200131 Add Start
            objectIdentifierSequence cassetteIDsForNotAvailable;
            CORBA::Long notAvairableCassetteCnt = 0;
            //P4200131 Add End

            for ( i = 0; i < nSlotMap; i++ )
            {
                bRecCompStat = FALSE;
//P4000373                bFosb = FALSE;

                strWaferSorterSlotMapWrite[i].mmCompareStatus      = CIMFWStrDup(SP_Sorter_ERROR);
//P4000373                strWaferSorterSlotMapWrite[i].slotMapCompareStatus = CIMFWStrDup("");

                //0.0.1 Add Start
                //---------------------------------------------------
                // Check Cassette Change By Record
                //---------------------------------------------------
                PPT_METHODTRACE_V2("","Compare Cassette ID : strTempCassetteID          =  ", strTempCassetteID);
                PPT_METHODTRACE_V2("","Compare Cassette ID : TCS Slotmap SEQ CassetteID =  ",
                                              strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier);

                if ( CIMFWStrCmp( strTempCassetteID, strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier) != 0 )
                {
                    //---------------------------------------------------
                    // Get Slot Map On MM Server (TCS Key)
                    //---------------------------------------------------
                    bFosb = FALSE;           //P4000373
                    strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo.length(0);    //0.0.4
                    rc = cassette_GetWaferMapDR( strCassette_GetWaferMapDR_out,
                                                 strObjCommonIn,
                                                 strWaferSorterSlotMapSequence[i].destinationCassetteID );

//P4000300                    if( (rc != RC_OK) && (rc != RC_NOT_FOUND_CASSETTE) )
//P4000300                    {
//P4000300                        PPT_METHODTRACE_V2("", "cassette_GetWaferMapDR() != RC_OK", rc);
//P4000300                        strWaferSorterOnEqpRptResult.strResult = strCassette_GetWaferMapDR_out.strResult;
//P4000300                        return(rc);
//P4000300                    }
//P4000300 Add Start
                    if(rc == RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "cassette_GetWaferMapDR() == RC_OK");
                    }
                    else if (rc == RC_NOT_FOUND_CASSETTE)
                    {
                        PPT_METHODTRACE_V1("", "cassette_GetWaferMapDR() == RC_NOT_FOUND_CASSETTE is FOSB");
                        bFosb = TRUE;
                    }
                    else
                    {
                        PPT_METHODTRACE_V2("", "cassette_GetWaferMapDR() != RC_OK", rc);
                        strWaferSorterOnEqpRptResult.strResult = strCassette_GetWaferMapDR_out.strResult;
                        return(rc);
                    }
//P4000300 Add End

                    //---------------------------------------------------
                    // Store Changed Cassette ID and Sequence Length
                    //---------------------------------------------------
                    strTempCassetteID = CIMFWStrDup(strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier);
                    nWaferMap = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo.length();

                    PPT_METHODTRACE_V2("","NEW strTempCassetteID = ", strTempCassetteID);
                    PPT_METHODTRACE_V2("","NEW nWaferMap         = ", nWaferMap);
                }
                //0.0.1 Add End

                //--------------------------------
                //   DATA COMPARE
                //--------------------------------
                CORBA::Boolean bMMCastEmpty = TRUE;    //0.0.3

                PPT_METHODTRACE_V1("", "//--------------------------------//")
                PPT_METHODTRACE_V1("", "//       DATA COMPARE START       //")
                PPT_METHODTRACE_V1("", "//--------------------------------//")

                if(bFosb == FALSE)               //P4000300
                {
                    for ( j = 0; j < nWaferMap; j++ )
                    {
                        PPT_METHODTRACE_V2("","nWaferMap Count = ",j)
                        PPT_METHODTRACE_V2("","[TCS] slotNumber", strWaferSorterSlotMapWrite[i].destinationSlotNumber);
                        PPT_METHODTRACE_V2("","[MM ] slotNumber", strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[j].slotNumber);
                        PPT_METHODTRACE_V2("","[TCS] waferID", strWaferSorterSlotMapWrite[i].waferID.identifier);
                        PPT_METHODTRACE_V2("","[MM ] waferID", strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[j].waferID.identifier);
                        PPT_METHODTRACE_V1("", "//--------------------------------//")

                        //0.0.3 Add Start
                        //--------------------------------
                        // Case of Read Empty Carrier
                        //--------------------------------
                        if ( strWaferSorterSlotMapWrite[i].destinationSlotNumber == 0 )
                        {
                            if ( CIMFWStrLen(strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[j].waferID.identifier) != 0)
                            {
                                bMMCastEmpty = FALSE;
                                break;
                            }
                        }
                        else
                        {   //0.0.3 Add End
                            if((strWaferSorterSlotMapWrite[i].destinationSlotNumber ==
                                strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[j].slotNumber) &&
                              (CIMFWStrCmp(strWaferSorterSlotMapWrite[i].waferID.identifier,
                                strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[j].waferID.identifier) == 0    ))
                            {
                                PPT_METHODTRACE_V1("","bRecCompStat = TRUE ");
                                strWaferSorterSlotMapWrite[i].mmCompareStatus = CIMFWStrDup(SP_Sorter_OK);
                                bRecCompStat = TRUE;
                                break;
                            }
                        }
                    }
                }                                                                                   //P4000300
                else                                                                                //P4000300
                {                                                                                   //P4000300
                    PPT_METHODTRACE_V1("", "Cassette Is Fosb")                                      //P4000300
                    strWaferSorterSlotMapWrite[i].mmCompareStatus = CIMFWStrDup(SP_Sorter_OK);      //P4000300
                    bRecCompStat = TRUE; //P4000373
//P4000374                    ckeckSTATUS = TRUE;                                                             //P4000300
                }
                PPT_METHODTRACE_V1("", "//--------------------------------//")
                PPT_METHODTRACE_V1("", "//       DATA COMPARE END         //")
                PPT_METHODTRACE_V1("", "//--------------------------------//")

                //0.0.3 Add Start
                //---------------------------------
                // Enpty Casstte Compare
                //---------------------------------
                if ( CIMFWStrCmp(actionCode,SP_Sorter_Read) == 0)
                {
                    if (( bMMCastEmpty == TRUE ) &&
                        ( strWaferSorterSlotMapWrite[i].destinationSlotNumber == 0 ))
                    {
                        strWaferSorterSlotMapWrite[i].mmCompareStatus = CIMFWStrDup(SP_Sorter_OK);
                        bRecCompStat = TRUE;
                    }
                }
                else if ( CIMFWStrCmp(actionCode,SP_Sorter_MiniRead) == 0)
                {
                    if (( bMMCastEmpty == TRUE ) && (nWaferMap == 0))
                    {
                        strWaferSorterSlotMapWrite[i].mmCompareStatus = CIMFWStrDup(SP_Sorter_OK);
                        bRecCompStat = TRUE;
                    }
                }
                //0.0.3 Add End

                PPT_METHODTRACE_V1("","bRecCompStat Check !!!");
                if ( bRecCompStat == FALSE )
                {
                    PPT_METHODTRACE_V1("","ckeckSTATUS = FALSE !!!");
                    ckeckSTATUS = FALSE;

                    //P4200131 Add Start
                    notAvairableCassetteCnt++;
                    cassetteIDsForNotAvailable.length(notAvairableCassetteCnt);
                    cassetteIDsForNotAvailable[notAvairableCassetteCnt - 1] = strWaferSorterSlotMapSequence[i].destinationCassetteID;

                    PPT_METHODTRACE_V3("","cassetteIDsForNotAvailable is ",
                                           notAvairableCassetteCnt, cassetteIDsForNotAvailable[notAvairableCassetteCnt - 1].identifier );
                    //P4200131 Add End
                }
            }

            //0.0.5 Add Start
            if ( CIMFWStrCmp(actionCode,SP_Sorter_Read) == 0 )
            {
                castLen = tmpCassetteIDs.length();
                CORBA::Long getWaferMapLen = 0;
                objectIdentifier tmpWaferID;
                CORBA::Long k = 0;
                for(i = 0; i < castLen; i++)
                {
                    PPT_METHODTRACE_V2("","Cassette Loop", i);        //P6000242
                    //---------------------------------------------------
                    // Get Slot Map On MM Server (SlotMap Key)
                    //---------------------------------------------------
                    objCassette_GetWaferMapDR_out strCassette_GetWaferMapDR_out;
                    rc = cassette_GetWaferMapDR( strCassette_GetWaferMapDR_out,
                                                 strObjCommonIn,
                                                 tmpCassetteIDs[i] );

//P4000300                    if( (rc != RC_OK) && (rc != RC_NOT_FOUND_CASSETTE) )
//P4000300                    {
//P4000300                        PPT_METHODTRACE_V2("", "cassette_GetWaferMapDR() != RC_OK", rc);
//P4000300                        strWaferSorterOnEqpRptResult.strResult = strCassette_GetWaferMapDR_out.strResult;
//P4000300                        return(rc);
//P4000300                    }
//P4000300 Add Start
                    if(rc == RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "cassette_GetWaferMapDR() == RC_OK");
                    }
                    else if (rc == RC_NOT_FOUND_CASSETTE)
                    {
                        PPT_METHODTRACE_V1("", "cassette_GetWaferMapDR() == RC_NOT_FOUND_CASSETTE is FOSB");
                        bFosb = TRUE;
                    }
                    else
                    {
                        PPT_METHODTRACE_V2("", "cassette_GetWaferMapDR() != RC_OK", rc);
                        strWaferSorterOnEqpRptResult.strResult = strCassette_GetWaferMapDR_out.strResult;
                        return(rc);
                    }
//P4000300 Add End
                    if(bFosb == FALSE)   //P4000300
                    {                   //P4000300
                        getWaferMapLen = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo.length();
                        for(j = 0; j < getWaferMapLen; j++)
                        {
                            bRecCompStat = FALSE;
                            tmpWaferID = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[j].waferID;
                            if(CIMFWStrLen(tmpWaferID.identifier) == 0)
                            {
                                PPT_METHODTRACE_V2("", "tmpWaferID is Blunk slotNumber = ",j + 1);
                                continue;
                            }

                            //---------------------------------------------------
                            // MM Exist Sequence VS TCS Repry Sequence
                            //---------------------------------------------------
                            for(k = 0; k < nSlotMap; k++)
                            {
                                if((CIMFWStrCmp(tmpCassetteIDs[i].identifier,
                                    strWaferSorterSlotMapWrite[k].destinationCassetteID.identifier) == 0      ) &&
                                   (strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[j].slotNumber ==
                                    strWaferSorterSlotMapWrite[k].destinationSlotNumber                       ) &&
                                   (CIMFWStrCmp(tmpWaferID.identifier,
                                    strWaferSorterSlotMapWrite[k].waferID.identifier) == 0                     ))
                                {
                                    PPT_METHODTRACE_V1("","bRecCompStat = TRUE ");

//P6000242                                    strWaferSorterSlotMapWrite[i].mmCompareStatus = CIMFWStrDup(SP_Sorter_OK);

                                    bRecCompStat = TRUE;
                                    break;
                                }
                            }

                            if ( bRecCompStat == FALSE )
                            {
                                PPT_METHODTRACE_V1("","ckeckSTATUS = FALSE !!!");
                                ckeckSTATUS = FALSE;

                                //P4200131 Add Start
                                notAvairableCassetteCnt++;
                                cassetteIDsForNotAvailable.length(notAvairableCassetteCnt);
                                cassetteIDsForNotAvailable[notAvairableCassetteCnt - 1] = tmpCassetteIDs[i];

                                PPT_METHODTRACE_V3("","cassetteIDsForNotAvailable is ",
                                                       notAvairableCassetteCnt,
                                                       cassetteIDsForNotAvailable[notAvairableCassetteCnt - 1].identifier );
                                //P4200131 Add End
                            }
                        }
                    }                                                                                   //P4000300
                    else                                                                                //P4000300
                    {                                                                                   //P4000300
                        PPT_METHODTRACE_V1("", "Cassette Is Fosb")                                      //P4000300
//P6000242                        strWaferSorterSlotMapWrite[i].mmCompareStatus = CIMFWStrDup(SP_Sorter_OK);      //P4000300
                        bRecCompStat = TRUE;    //P4000373
//P4000374                        ckeckSTATUS = TRUE;                                                             //P4000300
                    }                                                                                   //P4000300
                }
            }
            //0.0.5 Add E n d

            //-------------------------------
            //  Insert TCS Data to SLOTMAP
            //-------------------------------
            objWaferSorter_slotMap_InsertDR_out strWaferSorter_slotMap_InsertDR_out;
            rc = waferSorter_slotMap_InsertDR( strWaferSorter_slotMap_InsertDR_out,
                                                   strObjCommonIn,
                                                   strWaferSorterSlotMapWrite );
            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V2("", "waferSorter_SlotMap_InsertDR() != RC_OK", rc);
                strWaferSorterOnEqpRptResult.strResult = strWaferSorter_slotMap_InsertDR_out.strResult;
                return(rc);
            }

            //----------------------------------------
            //  MAKE A CASSETTE IS NOT AVAILABLE
            //----------------------------------------
            if ( ckeckSTATUS == FALSE )
            {
                //P4200131 Add Start
                objectIdentifierSequence tmpNotAvailableCasts;
                CORBA::Long              tmpNotAvailableCastsLen = 0;

                tmpNotAvailableCasts.length(notAvairableCassetteCnt);

                //-------------------------------
                // Checking Duplicate Cassette ID
                //-------------------------------
                PPT_METHODTRACE_V2("", "Cassette Duplicate Check notAvairableCassetteCnt is",  notAvairableCassetteCnt);

                for ( i = 0; i < notAvairableCassetteCnt; i++ )
                {
                    if ( i == 0 )
                    {
                        tmpNotAvailableCasts[tmpNotAvailableCastsLen] = cassetteIDsForNotAvailable[i];
                        tmpNotAvailableCastsLen++;

                        PPT_METHODTRACE_V3("", " Duplicate Check Result tmpNotAvailableCasts is",
                                                 tmpNotAvailableCastsLen, cassetteIDsForNotAvailable[i].identifier );

                        continue;
                    }
                    CORBA::Boolean    notAvailableCastsFind = FALSE;
                    for ( j = 0; j < tmpNotAvailableCastsLen; j++ )
                    {
                        PPT_METHODTRACE_V3("", "Cassette Duplicate Check", tmpNotAvailableCasts[j].identifier,
                                                cassetteIDsForNotAvailable[i].identifier );

                        if ( CIMFWStrCmp( tmpNotAvailableCasts[j].identifier, cassetteIDsForNotAvailable[i].identifier ) == 0 )
                        {
                            PPT_METHODTRACE_V1("", "Find Duplicate Cassette." );

                            notAvailableCastsFind = TRUE;
                            break;
                        }
                    }
                    if ( notAvailableCastsFind == FALSE )
                    {
                        tmpNotAvailableCasts[tmpNotAvailableCastsLen] = cassetteIDsForNotAvailable[i];
                        tmpNotAvailableCastsLen++;

                        PPT_METHODTRACE_V3("", " Duplicate Check Result tmpNotAvailableCasts is",
                                                 tmpNotAvailableCastsLen, cassetteIDsForNotAvailable[i].identifier );
                    }
                }
                tmpNotAvailableCasts.length(tmpNotAvailableCastsLen);

                PPT_METHODTRACE_V2("", "Final ! tmpNotAvailableCastsLen is", tmpNotAvailableCastsLen);
                //P4200131 Add End

//P4200131                castLen = tmpCassetteIDs.length();
//P4200131                for(i = 0; i < castLen; i++)
                for(i = 0; i < tmpNotAvailableCastsLen; i++)                                                        //P4200131
                {
//INN-R-170003                    PPT_METHODTRACE_V2("", "Makes Cassette NotAvailable ", tmpNotAvailableCasts[i].identifier );    //P4200131
//INN-R-170003
//INN-R-170003                   //P4000218 Add Start
//INN-R-170003                   objCassette_getStatusDR_out strCassette_getStatusDR_out;
//P4200131                    rc = cassette_getStatusDR( strCassette_getStatusDR_out,
//P4200131                                               strObjCommonIn,
//P4200131                                               tmpCassetteIDs[i] );
//INN-R-170003
//INN-R-170003                    rc = cassette_getStatusDR( strCassette_getStatusDR_out,
//INN-R-170003                                               strObjCommonIn,
//INN-R-170003                                               tmpNotAvailableCasts[i] );                                           //P4200131
//INN-R-170003
//INN-R-170003                    if(rc == RC_NOT_FOUND_CASSETTE)
//INN-R-170003                    {
//INN-R-170003                        PPT_METHODTRACE_V1( "","cassette_getStatusDR() == RC_NOT_FOUND_CASSETTE");
//INN-R-170003                       continue;
//INN-R-170003                    }
//INN-R-170003
//INN-R-170003                    if ( rc != RC_OK )
//INN-R-170003                    {
//INN-R-170003                        PPT_METHODTRACE_V2( "","cassette_getStatusDR() != RC_OK", rc);
//INN-R-170003                        strWaferSorterOnEqpRptResult.strResult = strCassette_getStatusDR_out.strResult;
//INN-R-170003                        return rc;
//INN-R-170003                    }
//INN-R-170003                    PPT_METHODTRACE_V2( "","strCassette_getStatusDR_out.drbl_state--->", strCassette_getStatusDR_out.drbl_state);
//INN-R-170003
//INN-R-170003                    if( CIMFWStrCmp(strCassette_getStatusDR_out.drbl_state, CIMFW_Durable_NotAvailable) == 0)
//INN-R-170003                    {
//INN-R-170003                        PPT_METHODTRACE_V1( "","Cassette Status == Not Available");
//INN-R-170003                        continue;
//INN-R-170003                    }
//INN-R-170003                    //P4000218 Add End
//INN-R-170003
//INN-R-170003                   pptCassetteStatusChangeRptResult strCassetteStatusChangeRptResult;
//P4200131                    rc = txCassetteStatusChangeRpt(strCassetteStatusChangeRptResult,
//P4200131                                                   strObjCommonIn,
//P4200131                                                   tmpCassetteIDs[i],
//P4200131                                                   CIMFW_Durable_NotAvailable,
//P4200131                                                   strDummyClaimMemo) ;
//INN-R-170003
//INN-R-170003                    rc = txCassetteStatusChangeRpt(strCassetteStatusChangeRptResult,
//INN-R-170003                                                   strObjCommonIn,
//INN-R-170003                                                   tmpNotAvailableCasts[i],
//INN-R-170003                                                   CIMFW_Durable_NotAvailable,
//INN-R-170003                                                   strDummyClaimMemo) ;            //P4200131
//INN-R-170003
//INN-R-170003                    if(rc != RC_OK && rc != RC_NOT_FOUND_CASSETTE)
//INN-R-170003                    {
//INN-R-170003                        PPT_METHODTRACE_V2("", "txCassetteStatusChangeRpt() != RC_OK", rc);
//INN-R-170003                        strWaferSorterOnEqpRptResult.strResult = strCassetteStatusChangeRptResult.strResult;
//INN-R-170003                        return ( rc );
//INN-R-170003                    }
                     //INN-R-170003 Add Start
                     objDurable_subState_Get_out strDurable_subState_Get_out;
                     objDurable_subState_Get_in  strDurable_subState_Get_in;
                     strDurable_subState_Get_in.durableCategory = CIMFWStrDup(SP_DurableCat_Cassette);
                     strDurable_subState_Get_in.durableID = tmpCassetteIDs[i];
                     rc = durable_subState_Get(strDurable_subState_Get_out, strObjCommonIn, strDurable_subState_Get_in);
                     if (rc == RC_NOT_FOUND_CASSETTE)
                     {
                         PPT_METHODTRACE_V1("", "cassette_getStatusDR() == RC_NOT_FOUND_CASSETTE");
                         continue;
                      }
                     if (rc != RC_OK)
					 {
                        PPT_METHODTRACE_V2("", "cassette_getStatusDR() != RC_OK", rc);
                        strWaferSorterOnEqpRptResult.strResult = strDurable_subState_Get_out.strResult;
                        return rc;
                     }
                    if (0 == CIMFWStrCmp(strDurable_subState_Get_out.durableSubStatus.identifier, CS_FOUP_DURABLE_SUB_STATE_HOLD))
                    {
                        PPT_METHODTRACE_V1("", "Cassette Status == Foup Hold");
                        continue;
                    }
                    pptDurableStatusMultiChangeReqResult strDurableStatusMultiChangeReqResult;
                    pptDurableStatusMultiChangeReqInParm strDurableStatusMultiChangeReqInParm;
                    strDurableStatusMultiChangeReqInParm.durableStatus
                        = CORBA::string_dup(CIMFW_Durable_NotAvailable); 
                    strDurableStatusMultiChangeReqInParm.durableSubStatus.identifier
                        = CORBA::string_dup(CS_FOUP_DURABLE_SUB_STATE_HOLD);
                    strDurableStatusMultiChangeReqInParm.durableCategory
                        = CORBA::string_dup(SP_DurableCat_Cassette);
                    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq.length(1);
                    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableID.identifier
                        = CORBA::string_dup(tmpCassetteIDs[i].identifier);
                    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableStatus
                        = CORBA::string_dup(strDurable_subState_Get_out.durableStatus);
                    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableSubStatus.identifier
                        = CORBA::string_dup(strDurable_subState_Get_out.durableSubStatus.identifier);

                    rc = txDurableStatusMultiChangeReq(strDurableStatusMultiChangeReqResult, strObjCommonIn, strDurableStatusMultiChangeReqInParm, strDummyClaimMemo);

                    if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V2("", "txDurableStatusMultiChangeReq() rc != RC_OK", rc);
                        strWaferSorterOnEqpRptResult.strResult = strDurableStatusMultiChangeReqResult.strResult;
                        return(rc);
                     }
                     //INN-R-170003 Add End
                }

                SET_MSG_RC(strWaferSorterOnEqpRptResult,                //D4000201
                           MSG_WAFERSORTER_SLOTMAP_COMPARE_ERROR,     //D4000201
                           RC_WAFERSORTER_SLOTMAP_COMPARE_ERROR)      //D4000201
                rcParamChk = RC_WAFERSORTER_SLOTMAP_COMPARE_ERROR;    //D4000201
            }
        }
        else
        {
            //----------------------------------------------------------------------
            //   CASE Action Code is PosChange, JustIn, JustOut, Scrap ,AdjustToMM
            //----------------------------------------------------------------------
            PPT_METHODTRACE_V1("", "actionCode() != SP_Sorter_Read or SP_Sorter_MiniRead");

            //----------------------------------------
            //  TCS Reply Data -> Request Data Compare
            //----------------------------------------
            CORBA::Long nSlotMapWriteLen = strWaferSorterSlotMapWrite.length();
            CORBA::Long nGetSlotMapDRLen = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence.length();
            pptWaferSorterSlotMapSequence tmpSlotSeq;
            tmpSlotSeq = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence;

            CORBA::Boolean  ckeckSTATUS  = TRUE;
            CORBA::Boolean  bRecCompStat = FALSE;

            if( nSlotMapWriteLen != nGetSlotMapDRLen )
            {
               ckeckSTATUS = FALSE;
            }
            else
            {
                //----------------------------------------
                //  Data Compare
                //----------------------------------------
                for ( i = 0; i < nSlotMapWriteLen; i++ )
                {
                    bRecCompStat = FALSE;

                    strWaferSorterSlotMapWrite[i].mmCompareStatus      = CIMFWStrDup("");
                    strWaferSorterSlotMapWrite[i].slotMapCompareStatus = CIMFWStrDup(SP_Sorter_ERROR);

                    for ( j = 0; j < nGetSlotMapDRLen; j++ )
                    {
                        if((CIMFWStrCmp(strWaferSorterSlotMapWrite[i].waferID.identifier,tmpSlotSeq[j].waferID.identifier                             ) == 0) &&
                           (CIMFWStrCmp(strWaferSorterSlotMapWrite[i].destinationCassetteID.identifier,tmpSlotSeq[j].destinationCassetteID.identifier ) == 0) &&
                           (CIMFWStrCmp(strWaferSorterSlotMapWrite[i].destinationPortID.identifier,tmpSlotSeq[j].destinationPortID.identifier         ) == 0) &&
                           (strWaferSorterSlotMapWrite[i].destinationSlotNumber == tmpSlotSeq[j].destinationSlotNumber) &&
                           (CIMFWStrCmp(strWaferSorterSlotMapWrite[i].originalCassetteID.identifier,tmpSlotSeq[j].originalCassetteID.identifier       ) == 0) &&
                           (CIMFWStrCmp(strWaferSorterSlotMapWrite[i].originalPortID.identifier,tmpSlotSeq[j].originalPortID.identifier               ) == 0) &&
                           (strWaferSorterSlotMapWrite[i].originalSlotNumber == tmpSlotSeq[j].originalSlotNumber                                      ))
                        {
                            PPT_METHODTRACE_V1("","bRecCompStat = TRUE ");
                            strWaferSorterSlotMapWrite[i].slotMapCompareStatus = CIMFWStrDup(SP_Sorter_OK);
                            bRecCompStat = TRUE;
                            break;
                        }
                    }

                    PPT_METHODTRACE_V1("","bRecCompStat Check !!!");

                    if ( bRecCompStat == FALSE )
                    {
                        PPT_METHODTRACE_V1("","ckeckSTATUS = FALSE !!!");
                        ckeckSTATUS = FALSE;
                    }
                }
            }

			


            //----------------------------------------
            //  MKAE A CASSETTE NOT AVAILABLE
            //----------------------------------------
            if ( ckeckSTATUS == FALSE )
            {
                castLen = tmpCassetteIDs.length();
                for(i = 0; i < castLen; i++)
                {
                    //P4000218 Add Start
                   //INN-R-170003 objCassette_getStatusDR_out strCassette_getStatusDR_out;
                   //INN-R-170003 rc = cassette_getStatusDR( strCassette_getStatusDR_out,
                   //INN-R-170003                           strObjCommonIn,
                   //INN-R-170003                            tmpCassetteIDs[i] );

                   //INN-R-170003 if(rc == RC_NOT_FOUND_CASSETTE)
                   //INN-R-170003 {
                   //INN-R-170003     PPT_METHODTRACE_V1( "","cassette_getStatusDR() == RC_NOT_FOUND_CASSETTE");
                   //INN-R-170003    continue;
                   //INN-R-170003 }

                   //INN-R-170003 if ( rc != RC_OK )
                   //INN-R-170003 {
                   //INN-R-170003     PPT_METHODTRACE_V2( "","cassette_getStatusDR() != RC_OK", rc);
                   //INN-R-170003     strWaferSorterOnEqpRptResult.strResult = strCassette_getStatusDR_out.strResult;
                   //INN-R-170003     return rc;
                   //INN-R-170003 }
                   //INN-R-170003 PPT_METHODTRACE_V2( "","strCassette_getStatusDR_out.drbl_state--->", strCassette_getStatusDR_out.drbl_state);

                   //INN-R-170003 if( CIMFWStrCmp(strCassette_getStatusDR_out.drbl_state, CIMFW_Durable_NotAvailable) == 0)
                   //INN-R-170003 {
                   //INN-R-170003     PPT_METHODTRACE_V1( "","Cassette Status == Not Available");
                   //INN-R-170003     continue;
                   //INN-R-170003 }
                    //P4000218 Add End

                   //INN-R-170003 pptCassetteStatusChangeRptResult strCassetteStatusChangeRptResult;
                   //INN-R-170003 rc = txCassetteStatusChangeRpt(strCassetteStatusChangeRptResult,
                   //INN-R-170003                                strObjCommonIn,
                   //INN-R-170003                                tmpCassetteIDs[i],
                   //INN-R-170003                                CIMFW_Durable_NotAvailable,
                   //INN-R-170003                               strDummyClaimMemo) ;
                   //INN-R-170003 if(rc != RC_OK && rc != RC_NOT_FOUND_CASSETTE)
                   //INN-R-170003 {
                   //INN-R-170003    PPT_METHODTRACE_V2("", "txCassetteStatusChangeRpt() != RC_OK", rc);
                   //INN-R-170003     strWaferSorterOnEqpRptResult.strResult = strCassetteStatusChangeRptResult.strResult;
                   //INN-R-170003     return ( rc );
                   //INN-R-170003 }
                     //INN-R-170003 Add Start
                     objDurable_subState_Get_out strDurable_subState_Get_out;
                     objDurable_subState_Get_in  strDurable_subState_Get_in;
                     strDurable_subState_Get_in.durableCategory = CIMFWStrDup(SP_DurableCat_Cassette);
                     strDurable_subState_Get_in.durableID = tmpCassetteIDs[i];
                     rc = durable_subState_Get(strDurable_subState_Get_out, strObjCommonIn, strDurable_subState_Get_in);
                     if (rc == RC_NOT_FOUND_CASSETTE)
                     {
                          PPT_METHODTRACE_V1("", "cassette_getStatusDR() == RC_NOT_FOUND_CASSETTE");
                          continue;
                     }
                    if (rc != RC_OK)
                    {
                         PPT_METHODTRACE_V2("", "cassette_getStatusDR() != RC_OK", rc);
                         strWaferSorterOnEqpRptResult.strResult = strDurable_subState_Get_out.strResult;
                         return rc;
                    }
                    if (0 == CIMFWStrCmp(strDurable_subState_Get_out.durableSubStatus.identifier, CS_FOUP_DURABLE_SUB_STATE_HOLD))
                    {
                         PPT_METHODTRACE_V1("", "Cassette Status == Foup Hold");
                         continue;
                    }
                    pptDurableStatusMultiChangeReqResult strDurableStatusMultiChangeReqResult;
                    pptDurableStatusMultiChangeReqInParm strDurableStatusMultiChangeReqInParm;
                    strDurableStatusMultiChangeReqInParm.durableStatus
                        = CORBA::string_dup(CIMFW_Durable_NotAvailable);
                    strDurableStatusMultiChangeReqInParm.durableSubStatus.identifier
                        = CORBA::string_dup(CS_FOUP_DURABLE_SUB_STATE_HOLD);
                    strDurableStatusMultiChangeReqInParm.durableCategory
                        = CORBA::string_dup(SP_DurableCat_Cassette);
                    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq.length(1);
                    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableID.identifier
                        = CORBA::string_dup(tmpCassetteIDs[i].identifier);
                    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableStatus
                        = CORBA::string_dup(strDurable_subState_Get_out.durableStatus);
                    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableSubStatus.identifier
                        = CORBA::string_dup(strDurable_subState_Get_out.durableSubStatus.identifier);

                    rc = txDurableStatusMultiChangeReq(strDurableStatusMultiChangeReqResult, strObjCommonIn, strDurableStatusMultiChangeReqInParm, strDummyClaimMemo);

                    if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V2("", "txDurableStatusMultiChangeReq() rc != RC_OK", rc);
                        strWaferSorterOnEqpRptResult.strResult = strDurableStatusMultiChangeReqResult.strResult;
                        return(rc);
                    }
                    //INN-R-17003
                }

                SET_MSG_RC(strWaferSorterOnEqpRptResult,                //D4000201
                           MSG_WAFERSORTER_SLOTMAP_COMPARE_ERROR,     //D4000201
                           RC_WAFERSORTER_SLOTMAP_COMPARE_ERROR)      //D4000201
                rcParamChk = RC_WAFERSORTER_SLOTMAP_COMPARE_ERROR;    //D4000201
            }

            //---------------------------------------------------------
            //  The one with the relation of Wafer and Carrier is cut.
            //---------------------------------------------------------
            if ( ckeckSTATUS == TRUE )
            {
                CORBA::Boolean bMMKnownCastFlg = FALSE;    //D4000220
                if(CIMFWStrCmp(actionCode , SP_Sorter_Scrap ) == 0)
                {
                    //D4000220 Add Start
                    //------------------------------------------------------------------------------------------------------
                    //  MM doesn't go with Scrap through destinationCassetteID to cut the one with the relation if it knows.
                    //------------------------------------------------------------------------------------------------------
                    CORBA::Long len = strWaferSorterSlotMapSequence.length();
                    CORBA::Long seqlen = 0;

                    pptWaferSorterSlotMapSequence strMMKnownSeq;
                    pptWaferSorterSlotMapSequence strMMUnKnownSeq;
                    strMMUnKnownSeq.length(1);

                    objectIdentifierSequence tmpOriginalCasstteIDs;        //P5100038
                    CORBA::Long              tmpOriginalCasstteIDLen = 0;  //P5100038

                    for(i = 0; i < len; i++)
                    {
                        objCassette_getStatusDR_out strCassette_getStatusDR_out;
                        rc = cassette_getStatusDR( strCassette_getStatusDR_out,
                                                   strObjCommonIn,
                                                   strWaferSorterSlotMapSequence[i].destinationCassetteID );

                        switch (rc)
                        {
                            case RC_OK :
                                PPT_METHODTRACE_V1( "","cassette_getStatusDR() == RC_OK");
                                seqlen = strMMKnownSeq.length();
                                strMMKnownSeq.length(seqlen + 1);
                                seqlen++;
                                strMMKnownSeq[seqlen-1] = strWaferSorterSlotMapSequence[i];
                                bMMKnownCastFlg = TRUE;        //Known
                                break ;
                            case RC_NOT_FOUND_CASSETTE :
                                PPT_METHODTRACE_V1( "","cassette_getStatusDR() == RC_NOT_FOUND_CASSETTE");
                                strMMUnKnownSeq[0] = strWaferSorterSlotMapSequence[i];
                                bMMKnownCastFlg = FALSE;        //UnKnown
                                break;
                            default :
                                PPT_METHODTRACE_V2( "","cassette_getStatusDR() != RC_OK", rc);
                                strWaferSorterOnEqpRptResult.strResult = strCassette_getStatusDR_out.strResult;
                                return (rc);
                        }

    //P4000099          objWaferSorter_LotMaterialsScrap_out strWaferSorter_LotMaterialsScrap_out;
    //P4000099          rc = waferSorter_LotMaterialsScrap( strWaferSorter_LotMaterialsScrap_out,
    //P4000099                                              strObjCommonIn,
    //P4000099                                              strWaferSorterSlotMapSequence );

                        if(bMMKnownCastFlg == FALSE)                                                        //D4000220
                        {                                                                                   //D4000220
                            PPT_METHODTRACE_V1("", "actionCode is Scrap");
                            objWaferSorter_lotMaterials_Scrap_out strWaferSorter_lotMaterials_Scrap_out;    //P4000099
                            rc = waferSorter_lotMaterials_Scrap( strWaferSorter_lotMaterials_Scrap_out,
                                                                 strObjCommonIn,
        //D4000220                                               strWaferSorterSlotMapSequence );           //P4000099
                                                                 strMMUnKnownSeq );                         //D4000220
                            if(rc != RC_OK)
                            {
                                PPT_METHODTRACE_V2("", "waferSorter_lotMaterials_Scrap() != RC_OK", rc);
        //P4000099              strWaferSorterOnEqpRptResult.strResult = strWaferSorter_LotMaterialsScrap_out.strResult;
                                strWaferSorterOnEqpRptResult.strResult = strWaferSorter_lotMaterials_Scrap_out.strResult;  //P4000099
                                return(rc);
                            }
                            //P5100038 Add Start
                            //----------------------------------------------------
                            // Collect Original Cassette ID For MultiLotTypeUpdate
                            //----------------------------------------------------
                            PPT_METHODTRACE_V2( "", "MultiLotTypeUpdate Caaseete is",
                                                strWaferSorterSlotMapSequence[i].originalCassetteID.identifier );

                            if ( tmpOriginalCasstteIDLen == 0 )
                            {
                                tmpOriginalCasstteIDLen++;
                                tmpOriginalCasstteIDs.length(tmpOriginalCasstteIDLen);
                                tmpOriginalCasstteIDs[tmpOriginalCasstteIDLen-1] = strWaferSorterSlotMapSequence[i].originalCassetteID;
                            }
                            else
                            {
                                CORBA::Long      i_cas = 0;
                                CORBA::Boolean   bSameCas = FALSE;

                                for ( i_cas =0; i_cas < tmpOriginalCasstteIDLen; i_cas++ )
                                {
                                    PPT_METHODTRACE_V3( "","Casstte ID Compare", tmpOriginalCasstteIDs[i_cas].identifier,
                                                        strWaferSorterSlotMapSequence[i].originalCassetteID.identifier );

                                    if ( CIMFWStrCmp( tmpOriginalCasstteIDs[i_cas].identifier,
                                                      strWaferSorterSlotMapSequence[i].originalCassetteID.identifier ) == 0 )
                                    {
                                        PPT_METHODTRACE_V1( "", "Find same cassette. BREAK!" );
                                        bSameCas = TRUE;
                                        break;
                                    }
                                }
                                if ( bSameCas == FALSE )
                                {
                                    tmpOriginalCasstteIDLen++;
                                    tmpOriginalCasstteIDs.length(tmpOriginalCasstteIDLen);
                                    tmpOriginalCasstteIDs[tmpOriginalCasstteIDLen-1] = strWaferSorterSlotMapSequence[i].originalCassetteID;
                                }
                            }
                            PPT_METHODTRACE_V2( "", "Collected Cassette Cout is", tmpOriginalCasstteIDLen );
                            //P5100038 Add End
                        }                                                                               //D4000220
                    }
                    //P5100038 Add Start
                    //--------------------------------------------
                    // Multi Lot Type Update For Collected Casstte
                    //--------------------------------------------
                    CORBA::Long   i_cas = 0;

                    for ( i_cas = 0; i_cas < tmpOriginalCasstteIDLen; i_cas++ )
                    {
                        PPT_METHODTRACE_V3( "", "MultiLotTypeUpdate Caaseete is", i_cas, tmpOriginalCasstteIDs[i_cas].identifier );
                        objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
                        rc = cassette_multiLotType_Update( strCassette_multiLotType_Update_out,
                                                           strObjCommonIn,
                                                           tmpOriginalCasstteIDs[i_cas] );

                        if (rc != RC_OK && rc != RC_NOT_FOUND_CASSETTE)
                        {
                            PPT_METHODTRACE_V2( "", "cassette_multiLotType_Update() rc != RC_OK and rc != RC_NOT_FOUND_CASSETTE", i_cas );
                            strWaferSorterOnEqpRptResult.strResult = strCassette_multiLotType_Update_out.strResult;
                            return( rc );
                        }
                    }
                    //P5100038 Add End

                    len = strMMKnownSeq.length();
                    if(len > 0)
                    {
                        bMMKnownCastFlg = TRUE;
                        strWaferSorterSlotMapWrite = strMMKnownSeq;
                    }
                    //D4000220 Add End
                }

                //-------------------------------------------------------------------------             //P4000323
                //  It doesn't need to update data on MM in the case of AdjustToMM.                     //P4000323
                //-------------------------------------------------------------------------             //P4000323
                if(CIMFWStrCmp(actionCode , SP_Sorter_AdjustToMM ) == 0)                                //P4000323
                {                                                                                       //P4000323
                    PPT_METHODTRACE_V1("", "actionCode is AdjustToMM");                                 //P4000323
//D4000236 Add Start
                    //---------------------------------------
                    // update the data base of FSSLOTMAP
                    //---------------------------------------
                    PPT_METHODTRACE_V1("","Calling Method:waferSorter_slotMap_WaferIdRead_UpdateDR");

                    objWaferSorter_slotMap_WaferIdRead_UpdateDR_out strWaferSorter_slotMap_WaferIdRead_UpdateDR_out;
                    rc = waferSorter_slotMap_WaferIdRead_UpdateDR( strWaferSorter_slotMap_WaferIdRead_UpdateDR_out,
                                                                   strObjCommonIn,
                                                                   strWaferSorterSlotMapSequence );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("","waferSorter_slotMap_WaferIdRead_UpdateDR != RC_OK");
                        strWaferSorterOnEqpRptResult.strResult = strWaferSorter_slotMap_WaferIdRead_UpdateDR_out.strResult;
                        return rc;
                    }
//D4000236 Add End
                }

                //-------------------------------------------------------------------------             //D4000234
                //  It doesn't need to update data on MM in the case of AdjustToSorter.                 //D4000234
                //-------------------------------------------------------------------------             //D4000234
                if(CIMFWStrCmp(actionCode , SP_Sorter_AdjustToSorter ) == 0)                            //D4000234
                {                                                                                       //D4000234
                    PPT_METHODTRACE_V1("", "actionCode is AdjustToSorter");                             //D4000234
                }                                                                                       //D4000234

                //-------------------------------------------------------------------------
                //  Other Action Code (JustIn JustOut PositionChange
                //-------------------------------------------------------------------------
                if(CIMFWStrCmp(actionCode , SP_Sorter_JustIn         ) == 0 ||                          //D4000220
                   CIMFWStrCmp(actionCode , SP_Sorter_JustOut        ) == 0 ||                          //D4000220
                   CIMFWStrCmp(actionCode , SP_Sorter_PositionChange ) == 0 ||                          //D4000220
                   CIMFWStrCmp(actionCode , SP_Sorter_AutoSorting    ) == 0 ||                          //D9000005
                   bMMKnownCastFlg == TRUE                              )                               //D4000220
                {
                    PPT_METHODTRACE_V1("", "actionCode is JustIn,JustOut,PosChange");
                    //---------------------------
                    //  Set Slot Map Data For Update
                    //---------------------------
                    pptWaferTransferSequence    strWaferXferSeq;
                    CORBA::Long nLen = strWaferSorterSlotMapWrite.length();
                    strWaferXferSeq.length(nLen);

                    for ( i =0 ; i < nLen ; i++  )
                    {
                        strWaferXferSeq[i].waferID.identifier                  = CIMFWStrDup(strWaferSorterSlotMapWrite[i].waferID.identifier);
                        strWaferXferSeq[i].destinationCassetteID.identifier    = CIMFWStrDup(strWaferSorterSlotMapWrite[i].destinationCassetteID.identifier);
                        strWaferXferSeq[i].bDestinationCassetteManagedBySiView = strWaferSorterSlotMapWrite[i].bDestinationCassetteManagedBySiView;
                        strWaferXferSeq[i].destinationSlotNumber               = strWaferSorterSlotMapWrite[i].destinationSlotNumber;
                        strWaferXferSeq[i].originalCassetteID.identifier       = CIMFWStrDup(strWaferSorterSlotMapWrite[i].originalCassetteID.identifier);
                        strWaferXferSeq[i].bOriginalCassetteManagedBySiView    = strWaferSorterSlotMapWrite[i].bOriginalCassetteManagedBySiView;
                        strWaferXferSeq[i].originalSlotNumber                  = strWaferSorterSlotMapWrite[i].originalSlotNumber;
                    }

                    //---------------------------
                    //  Slot Map Update
                    //---------------------------
                    pptWaferSortRptResult strWaferSortRptResult;
                    rc = txWaferSortRpt ( strWaferSortRptResult,
                                          strObjCommonIn,
                                          equipmentID,
                                          strWaferXferSeq,
                                          strDummyClaimMemo ) ;
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "txWaferSortRpt() != RC_OK",rc);
                        strWaferSorterOnEqpRptResult.strResult = strWaferSortRptResult.strResult;
                        return( rc );
                    }

                    //--------------------------------
                    // Update cassette multi lot type
                    //--------------------------------
//
//It is removed because there is the same treatment in txWaferSortRpt.
//
//                    for(i = 0 ; i < nSlotMapWriteLen; i++)
//                    {
//                        objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
//                        rc = cassette_multiLotType_Update(strCassette_multiLotType_Update_out,
//                                                          strObjCommonIn,
//                                                          strWaferSorterSlotMapWrite[i].destinationCassetteID);
//                        if ( rc != RC_OK && rc != RC_NOT_FOUND_CASSETTE )
//                        {
//                            PPT_METHODTRACE_V2("", "cassette_multiLotType_Update() != RC_OK",rc);
//                            strWaferSorterOnEqpRptResult.strResult = strCassette_multiLotType_Update_out.strResult;
//                            return(rc);
//                        }
//                    }
                }
//P8000194 add start
                /*******************************************************/
                /* Adjust equipment lot info by actual cassette info.  */
                /*******************************************************/
                for(CORBA::ULong castCnt = 0 ; castCnt < casLen ; castCnt++ )
                {
                    objEquipment_lotInCassette_Adjust_out strEquipment_lotInCassette_Adjust_out;
                    rc = equipment_lotInCassette_Adjust( strEquipment_lotInCassette_Adjust_out,
                                                         strObjCommonIn,
                                                         equipmentID,
                                                         cassetteIDs[castCnt]);
                    if(rc != RC_OK)
                    {
                        PPT_METHODTRACE_V2("", "equipment_lotInCassette_Adjust() != RC_OK", rc);
                        strWaferSorterOnEqpRptResult.strResult = strEquipment_lotInCassette_Adjust_out.strResult;
                        return rc;
                    }
                }
//P8000194 add end
            }

            //-------------------------------
            //  Insert TCS Data to SLOTMAP
            //-------------------------------
//P4000099            objWaferSorter_SlotMap_InsertDR_out strWaferSorter_SlotMap_InsertDR_out;
//P4000099            rc = waferSorter_SlotMap_InsertDR( strWaferSorter_SlotMap_InsertDR_out,
//P4000099                                                strObjCommonIn,
//P4000099                                                strWaferSorterSlotMapWrite );

            objWaferSorter_slotMap_InsertDR_out strWaferSorter_slotMap_InsertDR_out;    //P4000099
            rc = waferSorter_slotMap_InsertDR( strWaferSorter_slotMap_InsertDR_out,
                                                strObjCommonIn,
                                                strWaferSorterSlotMapWrite );           //P4000099
            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V2("", "waferSorter_SlotMap_InsertDR() != RC_OK", rc);
//P4000099      strWaferSorterOnEqpRptResult.strResult = strWaferSorter_SlotMap_InsertDR_out.strResult;
                strWaferSorterOnEqpRptResult.strResult = strWaferSorter_slotMap_InsertDR_out.strResult;  //P4000099
                return(rc);
            }
        }
//D9000005 add start
        //--------------------------------------------------------------
        //  Auto Sorting
        //--------------------------------------------------------------
        if ( 0 == CIMFWStrCmp( actionCode, SP_Sorter_AutoSorting ) )
        {
            PPT_METHODTRACE_V1("","actionCode == SP_Sorter_AutoSorting");

            if( rcParamChk == RC_WAFERSORTER_SLOTMAP_COMPARE_ERROR )
            {
                //--------------------------------------------------------------------
                //  Sorter Job Status Update (Executing -> Errored)
                //--------------------------------------------------------------------
                PPT_METHODTRACE_V1("","actionCode == SP_Sorter_AutoSorting");

                objSorter_sorterJob_status_GetDR_in strSorter_sorterJob_status_GetDR_in ;
                strSorter_sorterJob_status_GetDR_in.equipmentID = equipmentID ;
                strSorter_sorterJob_status_GetDR_in.originalCassetteID = strWaferSorterSlotMapSequence[0].originalCassetteID ;
                strSorter_sorterJob_status_GetDR_in.destinationCassetteID = strWaferSorterSlotMapSequence[0].destinationCassetteID;
                strSorter_sorterJob_status_GetDR_in.portGroupID = strWaferSorterSlotMapSequence[0].portGroup;

                objSorter_sorterJob_status_GetDR_out strSorter_sorterJob_status_GetDR_out;
                rc = sorter_sorterJob_status_GetDR( strSorter_sorterJob_status_GetDR_out,
                                                    strObjCommonIn,
                                                    strSorter_sorterJob_status_GetDR_in );

                if ( rc != RC_OK )
                {
                    strWaferSorterOnEqpRptResult.strResult = strSorter_sorterJob_status_GetDR_out.strResult;
                    return( rc );
                }

                objectIdentifier portGrp ;
                portGrp.identifier = strWaferSorterSlotMapSequence[0].portGroup;
                pptSortJobStatusChangeRptResult strSortJobStatusChangeRptResult;
                rc = txSortJobStatusChangeRpt( strSortJobStatusChangeRptResult,
                                               strObjCommonIn,
                                               equipmentID,
                                               portGrp,
                                               strSorter_sorterJob_status_GetDR_out.sorterComponentJobID,
                                               SP_Sorter_Job_Type_ComponentJob,
                                               SP_SorterComponentJobStatus_Error,
                                               strDummyClaimMemo );

                if ( rc != RC_OK )
                {
                    strWaferSorterOnEqpRptResult.strResult = strSortJobStatusChangeRptResult.strResult;
                    return( rc );
                }
            }
            else
            {
                //----------------------------------------------------------
                //  Sorter Job Status Update (Update -> Completed)
                //----------------------------------------------------------
                objSorter_sorterJob_status_GetDR_in strSorter_sorterJob_status_GetDR_in ;
                strSorter_sorterJob_status_GetDR_in.equipmentID = equipmentID ;
                strSorter_sorterJob_status_GetDR_in.originalCassetteID = strWaferSorterSlotMapSequence[0].originalCassetteID;
                strSorter_sorterJob_status_GetDR_in.destinationCassetteID = strWaferSorterSlotMapSequence[0].destinationCassetteID;
                strSorter_sorterJob_status_GetDR_in.portGroupID = strWaferSorterSlotMapSequence[0].portGroup;

                objSorter_sorterJob_status_GetDR_out strSorter_sorterJob_status_GetDR_out;
                rc = sorter_sorterJob_status_GetDR( strSorter_sorterJob_status_GetDR_out,
                                                    strObjCommonIn,
                                                    strSorter_sorterJob_status_GetDR_in );

                if ( rc != RC_OK )
                {
                    strWaferSorterOnEqpRptResult.strResult = strSorter_sorterJob_status_GetDR_out.strResult;
                    return( rc );
                }

                if( 0 == CIMFWStrLen( strSorter_sorterJob_status_GetDR_out.sorterComponentJobID.identifier ) )
                {
                    PPT_SET_MSG_RC_KEY( strWaferSorterOnEqpRptResult,
                                        MSG_NOT_FOUND_SORTERJOB, 
                                        RC_NOT_FOUND_SORTERJOB,
                                        "*****");
                    return RC_NOT_FOUND_SORTERJOB;
                }

                objectIdentifier portGrp;
                portGrp.identifier = CIMFWStrDup(strSorter_sorterJob_status_GetDR_in.portGroupID);
                pptSortJobStatusChangeRptResult strSortJobStatusChangeRptResult;
                rc = txSortJobStatusChangeRpt( strSortJobStatusChangeRptResult,
                                               strObjCommonIn,
                                               equipmentID,
                                               portGrp,
                                               strSorter_sorterJob_status_GetDR_out.sorterComponentJobID,
                                               SP_Sorter_Job_Type_ComponentJob,
                                               SP_SorterComponentJobStatus_Completed,
                                               strDummyClaimMemo );

                if ( rc != RC_OK )
                {
                    strWaferSorterOnEqpRptResult.strResult = strSortJobStatusChangeRptResult.strResult;
                    return( rc );
                }

                //----------------------------------------------------------
                //  Delete soter job, if Sorter Job Status is all compeleted
                //----------------------------------------------------------
                objSorter_jobList_GetDR_in strSorter_jobList_GetDR_in;
                strSorter_jobList_GetDR_in.equipmentID = equipmentID;
                strSorter_jobList_GetDR_in.sorterJobID = strSorter_sorterJob_status_GetDR_out.sorterJobID;

                objSorter_jobList_GetDR_out strSorter_jobList_GetDR_out;
                rc = sorter_jobList_GetDR( strSorter_jobList_GetDR_out,
                                           strObjCommonIn,
                                           strSorter_jobList_GetDR_in);

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "sorter_jobList_GetDR() rc != RC_OK");
                    strWaferSorterOnEqpRptResult.strResult = strSorter_jobList_GetDR_out.strResult;
                    return rc;
                }

                CORBA::Long srtJobLen = strSorter_jobList_GetDR_out.strSortJobListAttributesSeq.length();

                if (srtJobLen > 0)
                {
                    PPT_METHODTRACE_V1("", "sorter job status check.");

                    CORBA::Long compStatusLen = 0;
                    CORBA::Long compoJobLen   = strSorter_jobList_GetDR_out.strSortJobListAttributesSeq[0].strSorterComponentJobListAttributesSeq.length();
                    for (CORBA::Long iCJLen = 0; iCJLen < compoJobLen; iCJLen++)
                    {
                        if ( 0 == CIMFWStrCmp( SP_SorterComponentJobStatus_Completed, strSorter_jobList_GetDR_out.strSortJobListAttributesSeq[0].strSorterComponentJobListAttributesSeq[iCJLen].componentSorterJobStatus) )
                        {
                            PPT_METHODTRACE_V1("", "sorter job status is 'Completed'.");
                            compStatusLen++;
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", "sorter job status is not 'Completed'.");
                            break;
                        }
                    }

                    //----------------------------------------------------------
                    //  Delete sorter job
                    //----------------------------------------------------------
                    PPT_METHODTRACE_V3("", "compStatusLen : compoJobLen", compStatusLen, compoJobLen);

                    if (compStatusLen == compoJobLen)
                    {
                        PPT_METHODTRACE_V1("", "compStatusLen == compoJobLen");

                        pptSortJobStatusChangeRptResult strSortJobStatusChangeRptResult;
                        rc = txSortJobStatusChangeRpt( strSortJobStatusChangeRptResult,
                                                       strObjCommonIn,
                                                       equipmentID,
                                                       portGrp,
                                                       strSorter_sorterJob_status_GetDR_out.sorterJobID,
                                                       SP_Sorter_Job_Type_SorterJob,
                                                       SP_SorterJobStatus_Completed,
                                                       strDummyClaimMemo );

                        if ( rc != RC_OK )
                        {
                            strWaferSorterOnEqpRptResult.strResult = strSortJobStatusChangeRptResult.strResult;
                            return( rc );
                        }

                        pptSortJobCancelReqResult strSortJobCancelReqResult;
                        CORBA::Boolean notifyToTCSFlag = TRUE;
                        objectIdentifierSequence dummySequence;
                        rc = txSortJobCancelReq( strSortJobCancelReqResult,
                                                 strObjCommonIn,
                                                 strSorter_sorterJob_status_GetDR_out.sorterJobID,
                                                 dummySequence,
                                                 notifyToTCSFlag,
                                                 strDummyClaimMemo );
                        if (rc != RC_OK)
                        {
                            strWaferSorterOnEqpRptResult.strResult = strSortJobCancelReqResult.strResult;
                            return rc;
                        }
                    }
                }
                else
                {
                    PPT_METHODTRACE_V1("", "sorter job information is invalid.");
                    PPT_SET_MSG_RC_KEY( strWaferSorterOnEqpRptResult, 
                                        MSG_INVALID_SORTER_JOBID, 
                                        RC_INVALID_SORTER_JOBID, 
                                        strSorter_sorterJob_status_GetDR_out.sorterJobID.identifier );
                    return RC_INVALID_SORTER_JOBID;
                }
            }
        }
//D9000005 add end
    }

    /*----------------------------*/
    /*       Return to Caller     */
    /*----------------------------*/
    PPT_METHODTRACE_EXIT("PPTManager_i::txWaferSorterOnEqpRpt ")
//D4000201    SET_MSG_RC(strWaferSorterOnEqpRptResult,MSG_OK,RC_OK)
//D4000201    return( RC_OK );
//D4000201 Add Start
//P4000293    if(rcTCS != RC_OK)
//P4000293    {
//P4000293        SET_MSG_RC(strWaferSorterOnEqpRptResult,MSG_TCSWAFERSORT_ERROR,RC_TCSWAFERSORT_ERROR)
//P4000293        return( RC_TCSWAFERSORT_ERROR );
//P4000293    }
//P4000293    else if(rcParamChk != RC_OK)
    if(rcParamChk != RC_OK)
    {
        return( rcParamChk );
    }
    else
    {
        SET_MSG_RC(strWaferSorterOnEqpRptResult,MSG_OK,RC_OK)
        return( RC_OK );
    }
//D4000201 Add End
}
