#ifndef lint
static char *sccsid =  "@(#) 1.4 superpos/src/spppt/source/posppt/pptmgr/txmethods/txEqpStatusChangeReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 10/5/07 11:53:37 [ 10/5/07 11:53:38 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2012. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2012. All rights reserved.
//
// SiView
// Name: cs_txEqpStatusChangeReqOR.cpp
//

//INN-R170085 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp"  //INN-R170085

//=============================================================================
// For TXEQC007 : txEqpStatusChangeReq
//=============================================================================
// Class: CS_PPTManager
//
// Service: txEqpStatusChangeReq()
//
// Change history:
// Date     Defect#  Person         Comments
// -------- -------- -------------- -------------------------------------------
// 04/13/99 D9800405 R.Furuta       DCR9800405
// 11/16/00 P3000333 S.Tokumasu     Support Stocker
// 01/05/16 P3100349 K.Kido         Add Routin that Select EqpID or StkID When EventMake 
// 02/10/08 D4200039 H.Adachi       Replace Direct FW Calling.
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 09/20/07 D9000079 D.Tamura       FlowBatch Enhancement.
// 2010-10-13 DSIV00002458 F.Chen       Change for Equipment Status transition enhancement under Offline mode
// 2010-11-30 PSIV00002675 F.Chen       Fixed for OperationStartCancel for internal buffer
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2011/10/20 DSN000015229 M.Ogawa        Advanced Wafer Level Control
// 2012/11/22 DSN000049350 S.Liu          Equipment parellel processing support (P2)
//
// Innotron Modification history:
// Date       DCR/PCR No   Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/30 INN-R170085  Jun Zhang      Equipment status for PM
//
// Description:
//     TXEQC007
// Return:
//     long
//
// Parameter:
//
//     pptEqpStatusChangeReqResult& strEqpStatusChangeReqResult
//     const pptObjCommonIn& strObjCommonIn
//     const objectIdentifier& equipmentID
// //DCR 9900001    const char * equipmentStatus
//     const objectIdentifier equipmentStatusCode   //DCR 9900001
//     const char * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

//2.00CORBA::Long PPTManager_i::txEqpStatusChangeReq (pptEqpStatusChangeReqResult& strEqpStatusChangeReqResult, const pptObjCommonIn& strObjCommonIn,  const objectIdentifier& equipmentID,  const char * equipmentStatus,  const char * claimMemo, CORBA::Environment &IT_env)
//D6000025 CORBA::Long PPTManager_i::txEqpStatusChangeReq (pptEqpStatusChangeReqResult& strEqpStatusChangeReqResult, const pptObjCommonIn& strObjCommonIn,  const objectIdentifier& equipmentID,  const objectIdentifier& equipmentStatusCode,  const char * claimMemo, CORBA::Environment &IT_env)
CORBA::Long CS_PPTManager_i::txEqpStatusChangeReq (pptEqpStatusChangeReqResult& strEqpStatusChangeReqResult, const pptObjCommonIn& strObjCommonIn,  const objectIdentifier& equipmentID,  const objectIdentifier& equipmentStatusCode,  const char * claimMemo CORBAENV_LAST_CPP) //D6000025
{
    char * methodName = NULL;                                                                     //P3100349
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txEqpStatusChangeReq ")

    CORBA::Long rc;

    /*--------------------------------*/                                                          //1.02 (DCR9800405)
    /*   Lock objects to be updated   */                                                          //1.02 (DCR9800405)
    /*--------------------------------*/                                                          //1.02 (DCR9800405)
    objObject_Lock_out strObject_Lock_out;                                                        //1.02 (DCR9800405)

    /** P3000333 for Stocker Status **/
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txEqpStatusChangeReq", "Get Machine Type");
    objStocker_type_GetDR_out strStocker_type_GetDR_out;
    rc = stocker_type_GetDR(strStocker_type_GetDR_out, strObjCommonIn,
                            equipmentID);
    if ( rc == RC_OK ) {
       PPT_METHODTRACE_V1("CS_PPTManager_i:: txEqpStatusChangeReq", "stockerType = SP_Stocker_Type_Auto, _Interm, _Shelf, ...");
       rc = object_Lock( strObject_Lock_out, strObjCommonIn, equipmentID, SP_ClassName_PosStorageMachine );
       if ( rc != RC_OK ) 
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txEqpStatusChangeReq", "== Stocker ==") 
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txEqpStatusChangeReq", "object_Lock() rc != RC_OK")    //1.02 (DCR9800405)
            strEqpStatusChangeReqResult.strResult = strObject_Lock_out.strResult ;                    //1.02 (DCR9800405)
            return( rc );
        }
    } else {
//DSN000049350 Add Start
        objObject_lockMode_Get_out strObject_lockMode_Get_out;
        objObject_lockMode_Get_in  strObject_lockMode_Get_in;
        strObject_lockMode_Get_in.objectID           = equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXEQC007" ); // TxEqpStatusChangeReq
        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strEqpStatusChangeReqResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }

        objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
        objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
        
        CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
        PPT_METHODTRACE_V2( "", "lockMode", lockMode );
        if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
        {
            PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

            // Advanced Mode
            // Lock Equipment Main Object
            stringSequence dummySeq;
            dummySeq.length(0);
            strAdvanced_object_Lock_in.objectID   = equipmentID;
            strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
            strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
            strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
            strAdvanced_object_Lock_in.keySeq     = dummySeq;

            PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
            rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                       strObjCommonIn,
                                       strAdvanced_object_Lock_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                strEqpStatusChangeReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                return( rc );
            }
            
            // Lock Equipment ProcLot Element (Count)
            dummySeq.length(0);
            strAdvanced_object_Lock_in.objectID   = equipmentID;
            strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
            strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_InProcessingLot );
            strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_COUNT;
            strAdvanced_object_Lock_in.keySeq     = dummySeq;

            PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_InProcessingLot );
            rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                       strObjCommonIn,
                                       strAdvanced_object_Lock_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                strEqpStatusChangeReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                return( rc );
            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
            rc = object_Lock( strObject_Lock_out, strObjCommonIn, equipmentID, SP_ClassName_PosMachine ); //1.02 (DCR9800405)
            if ( rc != RC_OK ) {                                                                          //1.02 (DCR9800405)
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txEqpStatusChangeReq", "object_Lock() rc!=RC_OK")      //1.02 (DCR9800405)
                strEqpStatusChangeReqResult.strResult = strObject_Lock_out.strResult;                     //1.02 (DCR9800405)
                return( rc );                                                                             //1.02 (DCR9800405)
            }                                                                                             //1.02 (DCR9800405)
        } //DSN000049350
    } // end of P3000333
//Start DCR 9900001 Modification
    /*---------------------------------------------------------------*/
    /* Convert Equipment Status DCR 9900001                                 */
    /*---------------------------------------------------------------*/
//DSIV00002458 Add Start
    CORBA::Boolean isStorageBool = FALSE ;
    objEquipment_statusInfo_Get_out__090 strEquipment_statusInfo_GetDR_out;
    objEquipment_statusInfo_Get_in__090  strEquipment_statusInfo_GetDR_in;
    strEquipment_statusInfo_GetDR_in.equipmentID = equipmentID;
    PPT_METHODTRACE_V1("", "call equipment_statusInfo_Get__090()...");
    rc = equipment_statusInfo_Get__090( strEquipment_statusInfo_GetDR_out, strObjCommonIn, strEquipment_statusInfo_GetDR_in ); 
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipmentState_Convert() rc!=RC_OK", rc)
        if ( rc == RC_NOT_FOUND_EQP )
        {
            PPT_METHODTRACE_V1("", "isStorageBool is TRUE !");
            isStorageBool = TRUE;
        }
        else
        {
            PPT_METHODTRACE_V1("", "isStorageBool is FALSE !");
            strEqpStatusChangeReqResult.strResult = strEquipment_statusInfo_GetDR_out.strResult;
            return( rc );
        }
    }
    if ( isStorageBool == TRUE )
    {
        PPT_METHODTRACE_V2("", "isStorageBool is TRUE !", equipmentID.identifier);
    }
    else
    {
        PPT_METHODTRACE_V2("", "isStorageBool is FALSE !", equipmentID.identifier);
    }
    
    
    // Get SP_EQPSTAT_BACKUP
    CORBA::String_var envEqpStatusBackup = CIMFWStrDup(getenv(SP_EQPSTAT_BACKUP));
    PPT_METHODTRACE_V2("", "SP_EQPSTAT_BACKUP", envEqpStatusBackup);
    objectIdentifier backupEquipmentStatus;
    
    if (CIMFWStrCmp (envEqpStatusBackup, "1") == 0)
    {
        PPT_METHODTRACE_V1("", "SP_EQPSTAT_BACKUP == 1");
        
        // If OpeStart, backup the previous equipment status: strEquipment_statusInfo_GetDR_out.equipmentStatusInfo.E10Status
        if (0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC002")    //TxOpeStartReq
        || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC054"))    //TxOpeStartForInternalBufferReq
        {
            PPT_METHODTRACE_V2("", "transactionID is OpeStart = ", strObjCommonIn.transactionID);
            // Get inProcessingControlJob to check if I am the first controlJob 
            // Here using DR method to select existing controlJob only (not include myself)
            objEquipment_inProcessingControlJob_GetDR_out strEquipment_inProcessingControlJob_GetDR_out;
            objEquipment_inProcessingControlJob_GetDR_in strEquipment_inProcessingControlJob_GetDR_in;
            strEquipment_inProcessingControlJob_GetDR_in.equipmentID = equipmentID;
            
            rc = equipment_inProcessingControlJob_GetDR(strEquipment_inProcessingControlJob_GetDR_out, strObjCommonIn, 
                                                        strEquipment_inProcessingControlJob_GetDR_in);
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "equipment_inProcessingControlJob_GetDR() != RC_OK rc = ", rc);
                strEqpStatusChangeReqResult.strResult = strEquipment_inProcessingControlJob_GetDR_out.strResult;
                return( rc );
            }
            PPT_METHODTRACE_V2("", "inProcessingControlJobs.length() = ", strEquipment_inProcessingControlJob_GetDR_out.inProcessingControlJobs.length());
            
            if (strEquipment_inProcessingControlJob_GetDR_out.inProcessingControlJobs.length() == 0)
            {
                PPT_METHODTRACE_V1("", "First ControlJob for this equipment");
                // Update equipment backup status
                objEquipment_backupState_Update_out strEquipment_backupState_Update_out;

                objEquipment_backupState_Update_in  strEquipment_backupState_Update_in;
                strEquipment_backupState_Update_in.equipmentID = equipmentID;
                strEquipment_backupState_Update_in.backupEquipmentStatus = strEquipment_statusInfo_GetDR_out.equipmentStatusInfo.equipmentStatusCode;

                rc = equipment_backupState_Update( strEquipment_backupState_Update_out, strObjCommonIn,
                                                   strEquipment_backupState_Update_in);

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "equipment_backupState_Update() != RC_OK rc = ", rc);
                    strEqpStatusChangeReqResult.strResult = strEquipment_backupState_Update_out.strResult ;
                    return rc;
                }
                PPT_METHODTRACE_V2("", "backupState is updated to ", strEquipment_statusInfo_GetDR_out.equipmentStatusInfo.equipmentStatusCode.identifier);
            }
        } // Operation Start
        else
        {
            // do nothing
            ;
        }
        
    }
    else
    {
        ;
        // do nothing
    }
    // If opeComp or opeStartCancel, switch in-para equipmentStatusCode to back equipment status
    if ( 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC004")    //TxOpeCompWithDataReq
    || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC055")           //TxOpeCompForInternalBufferReq
    || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC010")           //TxForceOpeCompReq
    || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC015")           //TxPartialOpeCompWithDataReq           //DSN000015229
    || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC016")           //TxPartialOpeCompForInternalBufferReq  //DSN000015229
    || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC011")           //TxForceOpeCompForInternalBufferReq
    || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC003")           //TxOpeStartCancelReq
//PSIV00002675     || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC054"))          //TxOpeStartForInternalBufferReq
    || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC061"))          //TxOpeStartCancelForInternalBufferReq //PSIV00002675

    {
        PPT_METHODTRACE_V2("", "transactionID is OpeComp or OpeStartCancel = ", strObjCommonIn.transactionID);
        
        // Get inProcessingControlJob to check if I am the last controlJob 
        // Here using DR method to select existing controlJob only (not include myself)
        objEquipment_inProcessingControlJob_GetDR_out strEquipment_inProcessingControlJob_GetDR_out;
        objEquipment_inProcessingControlJob_GetDR_in strEquipment_inProcessingControlJob_GetDR_in;
        strEquipment_inProcessingControlJob_GetDR_in.equipmentID = equipmentID;
        
        rc = equipment_inProcessingControlJob_GetDR(strEquipment_inProcessingControlJob_GetDR_out, strObjCommonIn, 
                                                    strEquipment_inProcessingControlJob_GetDR_in);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_inProcessingControlJob_GetDR() != RC_OK rc = ", rc);
            strEqpStatusChangeReqResult.strResult = strEquipment_inProcessingControlJob_GetDR_out.strResult;
            return( rc );
        }
        PPT_METHODTRACE_V2("", "inProcessingControlJobs.length() = ", strEquipment_inProcessingControlJob_GetDR_out.inProcessingControlJobs.length());
        
        if (strEquipment_inProcessingControlJob_GetDR_out.inProcessingControlJobs.length() == 1)
        {
            PPT_METHODTRACE_V1("", "Last ControlJob for this equipment");
            // Get backup equipment status
            objEquipment_backupState_Get_out strEquipment_backupState_Get_out;

            objEquipment_backupState_Get_in  strEquipment_backupState_Get_in;
            strEquipment_backupState_Get_in.equipmentID = equipmentID;

            rc = equipment_backupState_Get( strEquipment_backupState_Get_out, strObjCommonIn,
                                          strEquipment_backupState_Get_in);

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "equipment_backupState_Get() != RC_OK rc = ", rc);
                strEqpStatusChangeReqResult.strResult = strEquipment_backupState_Get_out.strResult ;
                return rc;
            }
            PPT_METHODTRACE_V2("", "backupState : ", strEquipment_backupState_Get_out.backupEquipmentStatus.identifier);
            PPT_METHODTRACE_V2("", "backupE10   : ", strEquipment_backupState_Get_out.backupE10Status.identifier);
            backupEquipmentStatus = strEquipment_backupState_Get_out.backupEquipmentStatus;
        }
    }
//DSIV00002458 Add End

    objEquipmentState_Convert_out strEquipmentState_Convert_out;
//DSIV00002458 Add Start
    if (CIMFWStrLen (backupEquipmentStatus.identifier) > 0 && CIMFWStrCmp (envEqpStatusBackup, "1") == 0)
    {
        PPT_METHODTRACE_V2("", "Convert to backupState : ", backupEquipmentStatus.identifier);
        rc = equipmentState_Convert(strEquipmentState_Convert_out, strObjCommonIn,equipmentID, backupEquipmentStatus);
    }
    else
    {
        PPT_METHODTRACE_V2("", "Convert to equipmentStatusCode : ", equipmentStatusCode.identifier);
//DSIV00002458 Add End
        rc = equipmentState_Convert(strEquipmentState_Convert_out, strObjCommonIn,equipmentID, equipmentStatusCode);
    } //DSIV00002458
    switch (rc)
    {
        case RC_OK:
            break;
        default:
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txEqpStatusChangeReq", "equipmentState_Convert() rc!=RC_OK")
            strEqpStatusChangeReqResult.strResult = strEquipmentState_Convert_out.strResult;
            return rc;
    }
//End   DCR 9900001 Modification

    /*---------------------------------------------------------------*/
    /* Check input-eqp-status vs. allowed-new-staus by Current mode  */
    /*---------------------------------------------------------------*/

    objEquipment_currentState_CheckTransition_out strEquipment_currentState_CheckTransition_out;

//DCR 9900001    rc = equipment_currentState_CheckTransition(strEquipment_currentState_CheckTransition_out, strObjCommonIn,equipmentID, equipmentStatus);
    rc = equipment_currentState_CheckTransition(strEquipment_currentState_CheckTransition_out, strObjCommonIn,equipmentID, strEquipmentState_Convert_out.convertedStatusCode,FALSE); //DCR 9900001
    switch (rc)
    {
        case RC_OK:
        case RC_CURRSTATE_SAME:  //DCR 9900001
            break;
//DCR 9900001  case RC_CURRSTATE_SAME:
//DCR 9900001      PPT_METHODTRACE_V1("PPTManager_i:: txEqpStatusChangeReq", "equipment_currentState_CheckTransition() RC_CURSTATE_SAME") ;
//DCR 9900001      strEqpStatusChangeReqResult.strResult = strEquipment_currentState_CheckTransition_out.strResult;
//DCR 9900001      SET_MSG_RC(strEqpStatusChangeReqResult, MSG_OK, RC_OK);
//DCR 9900001      return RC_OK;
        default:
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txEqpStatusChangeReq", "equipment_currentState_CheckTransition() rc!=RC_OK")
            strEqpStatusChangeReqResult.strResult = strEquipment_currentState_CheckTransition_out.strResult;
            return rc;
    }

    /*-----------------------------------------------------------*/
    /* Change Equipment status by Input data                     */
    /*-----------------------------------------------------------*/

    objEquipment_currentState_Change_out strEquipment_currentState_Change_out;
    
//INN-R170085 add start
    /*-----------------------------------------------------------*/
    /* if RUNOUT-PM and lot CJC, change to WAIT-PM.              */
    /* or follow original logic.                                 */
    /*-----------------------------------------------------------*/
    objectIdentifier curEqpState = strEquipment_statusInfo_GetDR_out.equipmentStatusInfo.equipmentStatusCode;
    objectIdentifier covEqpState = strEquipmentState_Convert_out.convertedStatusCode;
	
    PPT_METHODTRACE_V2("", "current equipment status is",   curEqpState.identifier);
    PPT_METHODTRACE_V2("", "converted equipment status is", covEqpState.identifier);
    
    if (0 == CIMFWStrCmp(curEqpState.identifier, CS_EQP_STATUS_RUNOUT_PM)  
    &&  0 == CIMFWStrCmp(covEqpState.identifier, CS_EQP_STATUS_IDLE) )
    {
        PPT_METHODTRACE_V1("", "current status == CS_EQP_STATUS_RUNOUT_PM && converted status == CS_EQP_STATUS_IDLE")
			
        // change eqp status to WAIT-PM
        objectIdentifier toEqpState;
        toEqpState.identifier                 = CIMFWStrDup(CS_EQP_STATUS_WAIT_PM);
        toEqpState.stringifiedObjectReference = CIMFWStrDup("");
        rc = equipment_currentState_Change(strEquipment_currentState_Change_out, strObjCommonIn, equipmentID, toEqpState);
    }
    else
    {
        PPT_METHODTRACE_V1("", "current status != CS_EQP_STATUS_RUNOUT_PM || converted status != CS_EQP_STATUS_IDLE")
        
        //follow original logic
		    rc = equipment_currentState_Change(strEquipment_currentState_Change_out, strObjCommonIn, equipmentID, strEquipmentState_Convert_out.convertedStatusCode);
    }
//INN-R170085 add end

    //DCR 9900001	 rc = equipment_currentState_Change(strEquipment_currentState_Change_out, strObjCommonIn, equipmentID, equipmentStatus);
    //INN-R170085 rc = equipment_currentState_Change(strEquipment_currentState_Change_out, strObjCommonIn, equipmentID, strEquipmentState_Convert_out.convertedStatusCode);  //DCR 9900001
                                                                                                
    switch (rc)
    {
        case RC_OK:
            break;
        default:
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txEqpStatusChangeReq", "equipment_currentState_Change() rc!=RC_OK")
            strEqpStatusChangeReqResult.strResult = strEquipment_currentState_Change_out.strResult;
            return (rc);
    }

    /*------------------------------------------*/
    /*   Create Equipment Status Change Event   */
    /*------------------------------------------*/

    objectIdentifier dummy;
//DSIV00002458 Add Start
    // If from opeComp or opeStartCancel, reset backup equipment status
    if (CIMFWStrLen (backupEquipmentStatus.identifier) > 0 )  // backup equipment status exists and it is opeComp
    {
        PPT_METHODTRACE_V3("", "E10 Status is changed from/to", 
                                strEquipment_currentState_Change_out.previousE10Status.identifier,
                                strEquipment_currentState_Change_out.E10Status.identifier);
        
        // reset backup status
        objEquipment_backupState_Update_out strEquipment_backupState_Update_out;

        objEquipment_backupState_Update_in  strEquipment_backupState_Update_in;
        strEquipment_backupState_Update_in.equipmentID = equipmentID;
        strEquipment_backupState_Update_in.backupEquipmentStatus = dummy;

        rc = equipment_backupState_Update( strEquipment_backupState_Update_out, strObjCommonIn,
                                           strEquipment_backupState_Update_in);

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_backupState_Update() != RC_OK rc = ", rc);
            strEqpStatusChangeReqResult.strResult = strEquipment_backupState_Update_out.strResult ;
            return rc;
        }
        PPT_METHODTRACE_V1("", "backupState is reset");
    }
    else
    {
        // do nothing
        ;
    }
//DSIV00002458 Add End

//DSIV00002458 //P3100349 add start
//DSIV00002458     Machine_var aMachine;
//DSIV00002458     CORBA::Boolean isStorageBool = FALSE ;
//DSIV00002458 
//DSIV00002458 //D4200039    PPT_CONVERT_EQPID_TO_BASEMACHINE_OR(aMachine,
//DSIV00002458 //D4200039                                        equipmentID,
//DSIV00002458 //D4200039                                        strEqpStatusChangeReqResult,
//DSIV00002458 //D4200039                                        txEqpStatusChangeReq,
//DSIV00002458 //D4200039                                        isStorageBool);
//DSIV00002458 
//DSIV00002458     //D4200039 Add Start
//DSIV00002458 //D9000079    objEquipment_statusInfo_Get_out strEquipment_statusInfo_GetDR_out;
//DSIV00002458 //D9000079    PPT_METHODTRACE_V1("", "call equipment_statusInfo_Get()...");
//DSIV00002458 //D9000079    rc = equipment_statusInfo_Get(strEquipment_statusInfo_GetDR_out, strObjCommonIn, equipmentID);
//DSIV00002458 //D9000079 add start
//DSIV00002458     objEquipment_statusInfo_Get_out__090 strEquipment_statusInfo_GetDR_out;
//DSIV00002458     objEquipment_statusInfo_Get_in__090  strEquipment_statusInfo_GetDR_in;
//DSIV00002458     strEquipment_statusInfo_GetDR_in.equipmentID = equipmentID;
//DSIV00002458     PPT_METHODTRACE_V1("", "call equipment_statusInfo_Get__090()...");
//DSIV00002458     rc = equipment_statusInfo_Get__090( strEquipment_statusInfo_GetDR_out, strObjCommonIn, strEquipment_statusInfo_GetDR_in ); 
//DSIV00002458 //D9000079 end
//DSIV00002458     if ( rc != RC_OK )
//DSIV00002458     {
//DSIV00002458         if ( rc == RC_NOT_FOUND_EQP )
//DSIV00002458         {
//DSIV00002458             PPT_METHODTRACE_V1("", "isStorageBool is TRUE !");
//DSIV00002458             isStorageBool = TRUE;
//DSIV00002458         }
//DSIV00002458         else
//DSIV00002458         {
//DSIV00002458             PPT_METHODTRACE_V1("", "isStorageBool is FALSE !");
//DSIV00002458 //D9000079            PPT_METHODTRACE_V2("", "equipment_statusInfo_Get() rc != RC_OK", rc);
//DSIV00002458             PPT_METHODTRACE_V2("", "equipment_statusInfo_Get__090() rc != RC_OK", rc);            //D9000079
//DSIV00002458             strEqpStatusChangeReqResult.strResult = strEquipment_statusInfo_GetDR_out.strResult;
//DSIV00002458             return( rc );
//DSIV00002458         }
//DSIV00002458     }
//DSIV00002458     if ( isStorageBool == TRUE )
//DSIV00002458     {
//DSIV00002458         PPT_METHODTRACE_V2("", "isStorageBool is TRUE !", equipmentID.identifier);
//DSIV00002458     }
//DSIV00002458     else
//DSIV00002458     {
//DSIV00002458         PPT_METHODTRACE_V2("", "isStorageBool is FALSE !", equipmentID.identifier);
//DSIV00002458     }
//DSIV00002458     //D4200039 Add End

//P3100349 add end
    objEquipmentStatusChangeEvent_Make_out strEquipmentStatusChangeEvent_Make_out ;
//DCR 9900001    rc = equipmentStatusChangeEvent_Make(strEquipmentStatusChangeEvent_Make_out, strObjCommonIn, "TXEQC007", equipmentID, dummy, equipmentStatus, strEquipment_currentState_Change_out.previousOpeMode, strEquipment_currentState_Change_out.previousStatus, strEquipment_currentState_Change_out.previousOpeMode, strEquipment_currentState_Change_out.prevStateStartTime, claimMemo);
    if (!isStorageBool)           //P3100349
    {
        rc = equipmentStatusChangeEvent_Make(strEquipmentStatusChangeEvent_Make_out, strObjCommonIn, "TXEQC007", equipmentID, dummy, strEquipmentState_Convert_out.convertedStatusCode, strEquipment_currentState_Change_out.E10Status, strEquipment_currentState_Change_out.actualStatus, strEquipment_currentState_Change_out.actualE10Status, strEquipment_currentState_Change_out.operationMode, strEquipment_currentState_Change_out.previousStatus, strEquipment_currentState_Change_out.previousE10Status, strEquipment_currentState_Change_out.previousActualStatus, strEquipment_currentState_Change_out.previousActualE10Status, strEquipment_currentState_Change_out.previousOpeMode, strEquipment_currentState_Change_out.prevStateStartTime, claimMemo); //DCR 9900001
    }
//P3100349 add start
    else             
    {
        rc = equipmentStatusChangeEvent_Make(strEquipmentStatusChangeEvent_Make_out, 
                                             strObjCommonIn, 
                                             "TXEQC007", 
                                             dummy,
                                             equipmentID, 
                                             strEquipmentState_Convert_out.convertedStatusCode, 
                                             strEquipment_currentState_Change_out.E10Status,
                                             strEquipment_currentState_Change_out.actualStatus,
                                             strEquipment_currentState_Change_out.actualE10Status, 
                                             strEquipment_currentState_Change_out.operationMode, 
                                             strEquipment_currentState_Change_out.previousStatus,
                                             strEquipment_currentState_Change_out.previousE10Status, 
                                             strEquipment_currentState_Change_out.previousActualStatus, 
                                             strEquipment_currentState_Change_out.previousActualE10Status,
                                             strEquipment_currentState_Change_out.previousOpeMode, 
                                             strEquipment_currentState_Change_out.prevStateStartTime, 
                                             claimMemo);
    }
//P3100349 add end

    if(rc!=RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txChamberStatusChangeReq", "equipmentStatusChangeEvent_Make() rc != RC_OK")
        strEqpStatusChangeReqResult.strResult = strEquipmentStatusChangeEvent_Make_out.strResult ;
        return rc ;
    }

    strEqpStatusChangeReqResult.equipmentID = equipmentID;
    strEqpStatusChangeReqResult.equipmentStatusCode = strEquipmentState_Convert_out.convertedStatusCode;
    SET_MSG_RC(strEqpStatusChangeReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txEqpStatusChangeReq ")
    return(RC_OK);
}

