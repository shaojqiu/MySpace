#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txFixtureUsageCountResetReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:20:51 [ 7/13/07 21:20:52 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: txFixtureUsageCountResetReq.cpp
//

#include "cs_pptmgr.hpp"


// Add for R20CP-Fixture
// Class: PPTManager
//
// Service: txFixtureUsageCountResetReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 04/23/99            M.Yoshino      Started with 2.00
// 2000/09/12 P3000139 O.Sugiyama     add SET_MSG_RC
// 2000/09/18 P3000139 T.Yamano       add SET_MSG_RC
// 2002/01/18 D4100081 Cinthia Jao    Add call DurableChangeEvent_Make
// 2003/09/09 P5000145 H.Adachi       Fix Message and Message Macro mismatch.
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
//
// Innotron Modification history :
// Date       Defect#       Person               Comments
// ---------- ------------- -------------------- -------------------------------------------
// 2017/09/11 INN-R170006   YangXigang           For fixture
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptFixtureUsageCountResetReqResult& strFixtureUsageCountResetReqResult
//     const pptObjCommonIn& strObjCommonIn
//     const objectIdentifier& fixtureID
//     const char * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::txFixtureUsageCountResetReq (pptFixtureUsageCountResetReqResult& strFixtureUsageCountResetReqResult,
                                                              const pptObjCommonIn& strObjCommonIn,
                                                              const objectIdentifier& fixtureID,
//D6000025                                                    const char * claimMemo,
//D6000025                                                    CORBA::Environment &IT_env)
                                                              const char * claimMemo //D6000025
                                                              CORBAENV_LAST_CPP)     //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txFixtureUsageCountResetReq")
    CORBA::Long rc = RC_OK ;
     /*-------------------------------------*/
     /*   Reset fixture usage information   */
     /*-------------------------------------*/

    objFixture_usageInfo_Reset_out strFixture_usageInfo_Reset_out ;
    rc = fixture_usageInfo_Reset(strFixture_usageInfo_Reset_out,strObjCommonIn,fixtureID);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txFixtureUsageCountResetReq", "rc != RC_OK")
        strFixtureUsageCountResetReqResult.strResult = strFixture_usageInfo_Reset_out.strResult ;
        return( rc );
    }
    //INN-R170006 add start 
    csObjFixture_touchCount_Set_out strFixture_touchCount_Set_out;
    csObjFixture_touchCount_Set_in strFixture_touchCount_Set_in;
    strFixture_touchCount_Set_in.fixtureID = fixtureID;
    strFixture_touchCount_Set_in.strFixtureTouchCountInfo.touchCount = 0;
    strFixture_touchCount_Set_in.strFixtureTouchCountInfo.accumTouchCount = -1;
    rc = cs_fixture_touchCount_Set( strFixture_touchCount_Set_out, strObjCommonIn, strFixture_touchCount_Set_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i::txFixtureUsageCountResetReq", "rc != RC_OK")
        strFixtureUsageCountResetReqResult.strResult = strFixture_touchCount_Set_out.strResult ;
        //SET_MSG_RC( strFixtureUsageCountResetReqResult, MSG_FAIL_MAKE_HISTORY, rc )
        return rc; 
    } 
    //INN-R170006 add end
    /*---------------------------------------------*/
    /*   D4100081  Create Durable Change Event     */
    /*---------------------------------------------*/
    objDurableChangeEvent_Make_out strDurableChangeEvent_Make_out;
    rc = durableChangeEvent_Make(strDurableChangeEvent_Make_out,
                                 strObjCommonIn, 
                                 "TXPDC003", 
                                 fixtureID, 
                                 SP_DurableCat_Fixture,
                                 SP_DurableEvent_Action_PMReset,
                                 claimMemo) ;
    
    if( rc )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i::txFixtureUsageCountResetReq", "rc != RC_OK")
        strFixtureUsageCountResetReqResult.strResult = strDurableChangeEvent_Make_out.strResult ;
//P5000145        PPT_SET_MSG_RC_KEY(strFixtureUsageCountResetReqResult, MSG_FAIL_MAKE_HISTORY, rc ,fixtureID.identifier);
        SET_MSG_RC( strFixtureUsageCountResetReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145
        return rc ;
    }
    // D4100081 End

     /*-----------------------*/
     /*   Set out structure   */
     /*-----------------------*/
    strFixtureUsageCountResetReqResult.fixtureID = fixtureID ;
//P3000139    strFixtureUsageCountResetReqResult.strResult = strFixture_usageInfo_Reset_out.strResult ;

    SET_MSG_RC(strFixtureUsageCountResetReqResult, MSG_OK, RC_OK); //P3000139

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txFixtureUsageCountResetReq")
    return( RC_OK );
}
