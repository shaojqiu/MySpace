//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txDowngradeSettingUpdateReq.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: cs_txDowngradeSettingUpdateReq()
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/24 INN-R170016  Yangxiaojun    Equipment Monitor customization
//
// Description:
//
// Return:
//     long
//
// Parameter:
//     csDowngradeSettingUpdateReqResult& strDowngradeSettingUpdateReqResult
//     const pptObjCommonIn& strObjCommonIn
//
//  typedef  pptBaseResult csDowngradeSettingUpdateReqResult
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_txDowngradeSettingUpdateReq (csDowngradeSettingUpdateReqResult& strDowngradeSettingUpdateReqResult,
                                                        const pptObjCommonIn& strObjCommonIn,
                                                        const csDowngradeSettingUpdateReqInParm& strDowngradeSettingUpdateReqInParm,
                                                        const char* claimMemo
                                                        CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txDowngradeSettingUpdateReq")
    CORBA::Long rc = RC_OK ;

    //---------------------------------------------
    // save DcItems to CSFSNPWDWNG
    //---------------------------------------------
    csObjDowngradeSetting_UpdateDR_in strDowngradeSetting_UpdateDR_in;
    strDowngradeSetting_UpdateDR_in.strDowngradeSettingInfoSeq = strDowngradeSettingUpdateReqInParm.strDowngradeSettingInfoSeq;

    csObjDowngradeSetting_UpdateDR_out strDowngradeSetting_UpdateDR_out;
    rc = cs_downgradeSetting_UpdateDR( strDowngradeSetting_UpdateDR_out,
                               strObjCommonIn,
                               strDowngradeSetting_UpdateDR_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_downgradeSetting_UpdateDR() != RC_OK", rc);
        strDowngradeSettingUpdateReqResult.strResult = strDowngradeSetting_UpdateDR_out.strResult;
        return rc;
    }
 
    /*-----------------------*/
    /*   Set out structure   */
    /*-----------------------*/
    SET_MSG_RC(strDowngradeSettingUpdateReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: cs_txDowngradeSettingUpdateReq")
    return( RC_OK );
}
