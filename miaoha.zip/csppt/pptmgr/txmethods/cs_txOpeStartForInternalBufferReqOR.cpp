#ifndef lint
static char *sccsid =  "@(#) 1.9 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txOpeStartForInternalBufferReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/15/07 15:44:18 [ 11/15/07 15:44:19 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cs_txOpeStartForInternalBufferReqOR.cpp
//

#include "cs_pptmgr.hpp"
#include "penin.hh"

#include <unistd.h>

extern void traceSampledStartCassette( const pptStartCassetteSequence& strStartCassette );    //D9000003 for Cassette trace

// Class: CS_PPTManager
//
// Service: txOpeStartForInternalBufferReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2001/07/02 D4000015 O.Sugiyama     Initial Release (R4.0)
// 2001/08/23 D4000015 O.Sugiyama     equipment_processingLot_Add -> equipment_processingLot_AddForInternalBuffer
//                                    Can not use loadPortID
// 2001/08/28 D4000016 N.Maeda        add Process Contamination Control check logic (Copper/NonCopper) (R4.0)
// 2001/08/30 D4000015 O.Sugiyama     Modify TCSMgr function "0.01"
// 2001/08/30 D4000015 O.Sugiyama     Add In para log
// 2001/09/05 D4000015 O.Sugiyama     Change TX_ID TXTRC002 -> TXTRC054 "0.02"
// 2001/09/07 D4000060 K.Kido         Add retry TCS request logic
// 2001/12/05 P4100018 M.Shimizu      Add LogicalScrap Check(Except loadPurposeType=Other carrier)
// 2002/06/11 P4100536 T.Nishimura    Source Check : Wrong reference to dimension.
// 2002/06/14 P4100570 T.Nishimura    Source Check : Wrong reference to dimension.
// 2002/07/04 P4200025 T.Nishimura    Source Check : return without message.
// 2002/09/20 D4200031 H.Adachi       Chg not to check reticle for the case a lot is in a operation with no photo layer.
// 2003/04/08 D5000001 K.Matsuei      Wafer Level Control.
// 2003/08/25 P5000247 H.Adachi       Add Inparameter check of Control Job Combination.
// 2004/04/07 D5100232 K.Matsuei      Initial Release. Add DCS Interfact to MM.
// 2004/08/11 D51M0000 K.Tachibana    APC I/F Enhance for Interface Spec-B
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2005/10/31 D7000006 T.Ohsaki       exchange "controlJob_Create()" and "controlJob_status_Change()" to "txControlJobManageReq()"
// 2006/01/20 D7000182 H.Mutoh        Enhancement of re-sending APCControlJobInformation.
// 2006/04/03 D7000041 K.Matsuei      Need to check empty carrier's category on next operation.
// 2006/07/25 D7000228 M.Murata       Add the logic to send OpeStartCancel to DCS.
// 2006/11/28 D8000024 H.Mutoh        Flexible Process Condition Change (R80)
// 2007/04/02 D8000207 M.Murata       Add changing logic processJobExecFlag.
// 2007/04/20 D9000001 H.Murakami     64bit support.
// 2007/06/04 D9000003 M.Nakano       Modify changing and registering logic processJobExecFlag for wafer sampling operation. 
// 2007/09/20 D9000079 D.Tamura       FlowBatch Enhancement.
// 2007/10/10 D9000084 H.Hotta        Add check of reticle required for the lot
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2010/06/25 PSIV00002149 S.Kawabe       Start Lot Reservation fails when a lot in FOUP is not on a route.
// 2011/08/11 DSN000015229 Sa Guo         lot_processJobExecFlag_ValidCheck ==> lot_processJobExecFlag_ValidCheckForOpeStart
// 2012/11/28 DSN000049350 F.Chen         Equipment parallel processing support (P2)
// 2013/08/29 DSN000081739 Sa Guo         Equipment Monitor Automation Support
// 2014/05/27 DSN000085791 C.Mo           Entity Inhibit Exception Lot Support. (R150)
// 2015/11/11 DSN000096126 C.Mo           reticle_detailInfo_GetDR__090 ==> reticle_detailInfo_GetDR__160
// 2016/06/06 DSN000102497 K.Yamaoku      Support tMSP
// 2016/07/13 DSN000101569 K.Yamaoku      Durable Sub Status Control
// 2016/07/27 DSN000101569 C.Mo           reticle_detailInfo_GetDR__160 ==> reticle_detailInfo_GetDR__170
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/15 INN-R170002  JJ.Zhang       Contamination Control
// 2017/09/28 INN-R170003  Joan Zhou      Record WaferCount
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    pptOpeStartForInternalBufferReqResult&        strOpeStartForInternalBufferReqResult
//    const pptObjCommonIn&                         strObjCommonIn
//    const objectIdentifier&                       equipmentID
//    const objectIdentifier&                       controlJobID
//    const pptStartCassetteSequence&               strStartCassette
//    CORBA::Boolean                                processJobPauseFlag  //D5000001
//    const char*                                   claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i:: txOpeStartForInternalBufferReq (
    pptOpeStartForInternalBufferReqResult&  strOpeStartForInternalBufferReqResult, 
    const pptObjCommonIn&                   strObjCommonIn, 
    const objectIdentifier&                 equipmentID, 
    const objectIdentifier&                 controlJobID, 
    const pptStartCassetteSequence&         strStartCassette,
    CORBA::Boolean                          processJobPauseFlag,  //D5000001
//D6000025     const char*                             claimMemo, 
//D6000025     CORBA::Environment &                    IT_env)
//D7000182    const char*                             claimMemo  //D6000025
    const char*                             claimMemo,           //D7000182
    char *&                                 APCIFControlStatus,  //D7000182
    char *&                                 DCSIFControlStatus   //D7000182
    CORBAENV_LAST_CPP)                                 //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txOpeStartForInternalBufferReq");
    CORBA::Long rc = RC_OK ;

    {
        PPT_METHODTRACE_V2("","in para equipmentID                                            ", equipmentID.identifier );
        PPT_METHODTRACE_V2("","in para controlJobID                                           ", controlJobID.identifier );
        CORBA::Long nLen = strStartCassette.length();
        PPT_METHODTRACE_V2("","in para strStartCassette.length()                              ", nLen );
        for (CORBA::Long i=0; i<nLen; i++ )
        {
            PPT_METHODTRACE_V3("","in para   .cassetteID                                          ", i, strStartCassette[i].cassetteID.identifier );
            CORBA::Long nJLen = strStartCassette[i].strLotInCassette.length();
            PPT_METHODTRACE_V2("","in para   .strLotInCassette.strLotInCassette.length()          ", nJLen );
            for (CORBA::Long j=0; j<nJLen; j++ )
            {
                PPT_METHODTRACE_V2("","in para     .strLotInCassette[j].operationStartFlag            ", (int)strStartCassette[i].strLotInCassette[j].operationStartFlag );
                PPT_METHODTRACE_V2("","in para     .strLotInCassette[j].monitorLotFlag                ", (int)strStartCassette[i].strLotInCassette[j].monitorLotFlag );
                PPT_METHODTRACE_V2("","in para     .strLotInCassette[j].lotID                         ", strStartCassette[i].strLotInCassette[j].lotID.identifier );
                PPT_METHODTRACE_V2("","in para     .strLotInCassette[j].strStartRecipe.logicalRecipeID", strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID.identifier );
            }
        }
    }

    traceSampledStartCassette( strStartCassette );  //D9000003

//D51M0000 add start
    pptStartCassetteSequence tmpStartCassette;
    tmpStartCassette = strStartCassette;

//D8000207 add start
    //----------------------------------------
    // Change processJobExecFlag to True.
    //----------------------------------------
//D9000003 delete start
//    PPT_METHODTRACE_V2("","SP_OPER_START_WAFER_FLAG_CONTROL is ", atol(getenv(SP_OPER_START_WAFER_FLAG_CONTROL)));
//    if( 1 == atol(getenv(SP_OPER_START_WAFER_FLAG_CONTROL)) )
//    {
//        if( processJobPauseFlag == FALSE )
//        {
//            objStartCassette_processJobExecFlag_Set_out   strStartCassette_processJobExecFlag_Set_out;
//            rc = startCassette_processJobExecFlag_Set(strStartCassette_processJobExecFlag_Set_out, strObjCommonIn, strStartCassette );
//            if( rc != RC_OK )
//            {
//                PPT_METHODTRACE_V1("","objStartCassette_processJobExecFlag_Set() != RC_OK ");
//                strOpeStartForInternalBufferReqResult.strResult = strStartCassette_processJobExecFlag_Set_out.strResult;
//                return rc;
//            }
//            tmpStartCassette = strStartCassette_processJobExecFlag_Set_out.strStartCassette;
//        }
//    }
//D9000003 delete end
//D8000207 add end

//D9000003 add start    
    //Input parameter check.
    //Check every lot has at least one wafer with processJobExecFlag == TRUE
    PPT_METHODTRACE_V1("","Check every lot has at least one wafer with processJobExecFlag == TRUE.");
//DSN000015229    objLot_processJobExecFlag_ValidCheck_out strLot_processJobExecFlag_ValidCheck_out;
//DSN000015229    objLot_processJobExecFlag_ValidCheck_in strLot_processJobExecFlag_ValidCheck_in;
//DSN000015229    strLot_processJobExecFlag_ValidCheck_in.strStartCassette = tmpStartCassette;
//DSN000015229    
//DSN000015229    rc = lot_processJobExecFlag_ValidCheck(strLot_processJobExecFlag_ValidCheck_out, strObjCommonIn, strLot_processJobExecFlag_ValidCheck_in);
//DSN000015229    if( rc != RC_OK)
//DSN000015229    {
//DSN000015229        PPT_METHODTRACE_V1("","objLot_processJobExecFlag_ValidCheck() != RC_OK ");
//DSN000015229        strOpeStartForInternalBufferReqResult.strResult = strLot_processJobExecFlag_ValidCheck_out.strResult;
//DSN000015229        return rc;
//DSN000015229    }
//DSN000015229 Add Start
    objLot_processJobExecFlag_ValidCheckForOpeStart_out strLot_processJobExecFlag_ValidCheckForOpeStart_out;
    objLot_processJobExecFlag_ValidCheckForOpeStart_in strLot_processJobExecFlag_ValidCheckForOpeStart_in;
    strLot_processJobExecFlag_ValidCheckForOpeStart_in.strStartCassette = tmpStartCassette;
    strLot_processJobExecFlag_ValidCheckForOpeStart_in.processJobPauseFlag = processJobPauseFlag;
    rc = lot_processJobExecFlag_ValidCheckForOpeStart(strLot_processJobExecFlag_ValidCheckForOpeStart_out, strObjCommonIn, strLot_processJobExecFlag_ValidCheckForOpeStart_in);
    if( rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "lot_processJobExecFlag_ValidCheckForOpeStart() != RC_OK", rc);
        strOpeStartForInternalBufferReqResult.strResult = strLot_processJobExecFlag_ValidCheckForOpeStart_out.strResult;
        return rc;
    }
//DSN000015229 Add End
//D9000003 add end

    CORBA::Boolean sendTxFlag = FALSE;
    // sendTxFlag and strAPCRunTimeCapabilityInqResult is used by APCRuntimeCapability_RegistDR()
    // So, these cannot move into 'if sentence' and must initialize 'sendTxFlag=FALSE' and skip calling it.
    pptAPCRunTimeCapabilityInqResult strAPCRunTimeCapabilityInqResult;
    if(CIMFWStrLen(controlJobID.identifier) == 0)
    {
        PPT_METHODTRACE_V1("", "controlJobID.length() == 0");
        sendTxFlag = TRUE;
        /*-----------------------------------------*/
        /*   call txAPCRunTimeCapabilityInq        */
        /*-----------------------------------------*/
        PPT_METHODTRACE_V1("","call txAPCRunTimeCapabilityInq");
        rc = txAPCRunTimeCapabilityInq(strAPCRunTimeCapabilityInqResult,
                                       strObjCommonIn,
                                       equipmentID,
                                       controlJobID,
                                       tmpStartCassette,
                                       TRUE);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "txAPCRunTimeCapabilityInq() != RC_OK");
            strOpeStartForInternalBufferReqResult.strResult = strAPCRunTimeCapabilityInqResult.strResult;
            return( rc );
        }

//D7000182 add start
        CORBA::Long RunCapaRespCount = strAPCRunTimeCapabilityInqResult.strAPCRunTimeCapabilityResponse.length();
        if( rc == RC_OK && RunCapaRespCount > 0 )
        {
            PPT_METHODTRACE_V1("", "Received RunTimeCapabilityResponse from APC.");
            CORBA::String_var tmpString = APCIFControlStatus;
            APCIFControlStatus = CIMFWStrDup(SP_APC_ControlJobStatus_Canceled);
        }
//D7000182 add end
        /*---------------------------------------------*/
        /*   call txAPCRecipeParameterAdjustInq        */
        /*---------------------------------------------*/
        PPT_METHODTRACE_V1("","call txAPCRecipeParameterAdjustInq");
        pptAPCRecipeParameterAdjustInqResult strAPCRecipeParameterAdjustInqResult;
        rc = txAPCRecipeParameterAdjustInq(strAPCRecipeParameterAdjustInqResult,
                                           strObjCommonIn,
                                           equipmentID,
                                           tmpStartCassette,
                                           strAPCRunTimeCapabilityInqResult.strAPCRunTimeCapabilityResponse,
                                           TRUE);
//D7000182        if( rc != RC_OK )
        if( rc != RC_OK && rc != RC_OK_NO_IF )    //D7000182
        {
            PPT_METHODTRACE_V1("","txAPCRecipeParameterAdjustInq() != RC_OK");
            strOpeStartForInternalBufferReqResult.strResult = strAPCRecipeParameterAdjustInqResult.strResult;
            return( rc );
        }
        PPT_METHODTRACE_V1("", "Move structure(strAPCRecipeParameterAdjustInqResult.strStartCassette) to temporary domain");
        tmpStartCassette = strAPCRecipeParameterAdjustInqResult.strStartCassette;

//D7000182 add start
        if( rc == RC_OK )
        {
            PPT_METHODTRACE_V1("", "Received APCRecipeParameterResponse normally.");
            CORBA::String_var tmpString = APCIFControlStatus;
            APCIFControlStatus = CIMFWStrDup(SP_APC_ControlJobStatus_Canceled);
        }
//D7000182 add end
    }
    strOpeStartForInternalBufferReqResult.strStartCassette = tmpStartCassette;
//D51M0000 add end

//D4000015 add start
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Check Process                                                       */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    
//D9000003 add start
    //APC result check.
    //Check every lot has at least one wafer with processJobExecFlag == TRUE
    PPT_METHODTRACE_V1("","Check every lot has at least one wafer with processJobExecFlag == TRUE.");
//DSN000015229    strLot_processJobExecFlag_ValidCheck_in.strStartCassette = tmpStartCassette;
//DSN000015229    
//DSN000015229    rc = lot_processJobExecFlag_ValidCheck(strLot_processJobExecFlag_ValidCheck_out, strObjCommonIn, strLot_processJobExecFlag_ValidCheck_in);
//DSN000015229    if( rc != RC_OK)
//DSN000015229    {
//DSN000015229        PPT_METHODTRACE_V1("","objLot_processJobExecFlag_ValidCheck() != RC_OK ");
//DSN000015229        strOpeStartForInternalBufferReqResult.strResult = strLot_processJobExecFlag_ValidCheck_out.strResult;
//DSN000015229        return rc;
//DSN000015229    }
//DSN000015229 Add Start
    strLot_processJobExecFlag_ValidCheckForOpeStart_in.strStartCassette = tmpStartCassette;
    strLot_processJobExecFlag_ValidCheckForOpeStart_in.processJobPauseFlag = processJobPauseFlag;
    
    rc = lot_processJobExecFlag_ValidCheckForOpeStart(strLot_processJobExecFlag_ValidCheckForOpeStart_out, strObjCommonIn, strLot_processJobExecFlag_ValidCheckForOpeStart_in);
    if( rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "lot_processJobExecFlag_ValidCheckForOpeStart() != RC_OK", rc);
        strOpeStartForInternalBufferReqResult.strResult = strLot_processJobExecFlag_ValidCheckForOpeStart_out.strResult;
        return rc;
    }
//DSN000015229 Add End
//D9000003 add end

    
    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","equipment_categoryVsTxID_CheckCombination() returned error.");
        strOpeStartForInternalBufferReqResult.strResult = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return (rc);
    }
//D4000015 add end

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Object Lock Process                                                 */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

//DSN000049350 Add Start
    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = equipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    // controlJobID is not empty
    if ( 0 < CIMFWStrLen(controlJobID.identifier) )
    {
        PPT_METHODTRACE_V1("", "controlJobID exists");
        strObject_lockMode_Get_in.functionCategory = CIMFWStrDup( "TXTRC054" ); // TxOpeStartForInternalBufferReq
    }
    // controlJobID is empty
    else
    {
        PPT_METHODTRACE_V1("", "controlJobID is empty");
        strObject_lockMode_Get_in.functionCategory = CIMFWStrDup( SP_FunctionCategory_OpeStartForIBWithCJIDGenTxID ); // TxOpeStartForInternalBufferReq with control job ID generation
    }
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

    PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strOpeStartForInternalBufferReqResult.strResult = strObject_lockMode_Get_out.strResult;
        return( rc );
    }
    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;
    
    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
    if (lockMode != SP_EQP_LOCK_MODE_WRITE)
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strOpeStartForInternalBufferReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
        /*--------------------------------*/
        /*   Lock objects to be updated   */
        /*--------------------------------*/
//DSN000049350        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn,
                          equipmentID, SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "object_Lock(equipmentID) rc != RC_OK");
            strOpeStartForInternalBufferReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    } //DSN000049350

    CORBA::Long i = 0;
//D51M0000    CORBA::Long nILen = strStartCassette.length();
    CORBA::Long nILen = tmpStartCassette.length();              //D51M0000
    PPT_METHODTRACE_V2("", "nILen", nILen);

//DSN000049350 Add Start
    objectIdentifierSequence lotIDs;
    objectIdentifierSequence cassetteIDs;
    CORBA::ULong extendLen     = 25;
    CORBA::ULong t_lotIDLen    = extendLen;
    CORBA::ULong lotIDCnt      = 0;
    lotIDs.length(t_lotIDLen);
    cassetteIDs.length(nILen);
//DSN000049350 Add End

    for (i=0; i<nILen; i++)
    {

//DSN000049350        rc = object_Lock( strObject_Lock_out, strObjCommonIn,
//DSN000049350//D51M0000                          strStartCassette[i].cassetteID, SP_ClassName_PosCassette );
//DSN000049350                          tmpStartCassette[i].cassetteID, SP_ClassName_PosCassette );               //D51M0000
//DSN000049350        if ( rc != RC_OK )
//DSN000049350        {
//DSN000049350            PPT_METHODTRACE_V2("", "object_Lock(cassetteID) rc != RC_OK", i);
//DSN000049350            strOpeStartForInternalBufferReqResult.strResult = strObject_Lock_out.strResult;
//DSN000049350            return( rc );
//DSN000049350        }

        cassetteIDs[i] = tmpStartCassette[i].cassetteID;  //DSN000049350

        CORBA::Long j = 0;
//D51M0000        CORBA::Long nJLen = strStartCassette[i].strLotInCassette.length();
        CORBA::Long nJLen = tmpStartCassette[i].strLotInCassette.length();                          //D51M0000
        PPT_METHODTRACE_V2("", "nJLen", nJLen);
        for (j=0 ; j<nJLen; j++)
        {
//DSN000049350            rc = object_Lock( strObject_Lock_out, strObjCommonIn,
//DSN000049350//D51M0000                              strStartCassette[i].strLotInCassette[j].lotID, SP_ClassName_PosLot );
//DSN000049350                              tmpStartCassette[i].strLotInCassette[j].lotID, SP_ClassName_PosLot );//D51M0000
//DSN000049350            if ( rc != RC_OK )
//DSN000049350            {
//DSN000049350                PPT_METHODTRACE_V3("", "object_Lock(lotID) rc != RC_OK", i, j);
//DSN000049350                strOpeStartForInternalBufferReqResult.strResult = strObject_Lock_out.strResult;
//DSN000049350                return( rc );
//DSN000049350            }
//DSN000049350 Add Start
            if( lotIDCnt >= t_lotIDLen )
            {
                PPT_METHODTRACE_V1("", "lotIDCnt >= t_lotIDLen");
                t_lotIDLen += extendLen;
                lotIDs.length( t_lotIDLen );
            }
            lotIDs[lotIDCnt++] = tmpStartCassette[i].strLotInCassette[j].lotID;
//DSN000049350 Add End
        }
    }
    lotIDs.length(lotIDCnt);                        //DSN000049350
    PPT_METHODTRACE_V2( "", "lotIDCnt", lotIDCnt);  //DSN000049350

//DSN000049350 Add Start
    if (lockMode != SP_EQP_LOCK_MODE_WRITE)
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
        objEquipment_onlineMode_Get_out strEquipment_onlineMode_Get_out;
        rc = equipment_onlineMode_Get( strEquipment_onlineMode_Get_out, strObjCommonIn, equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_onlineMode_Get() rc != RC_OK", rc);
            strOpeStartForInternalBufferReqResult.strResult = strEquipment_onlineMode_Get_out.strResult;
            return rc;
        }
        
        if ( 0 == CIMFWStrCmp( strEquipment_onlineMode_Get_out.onlineMode, SP_Eqp_OnlineMode_Offline ) )
        {
            // Lock Equipment ProcLot Element (Count)
            stringSequence dummySeq;
            dummySeq.length(0);
            strAdvanced_object_Lock_in.objectID   = equipmentID;
            strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
            strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_InProcessingLot );
            strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_COUNT;
            strAdvanced_object_Lock_in.keySeq     = dummySeq;

            PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_InProcessingLot );
            rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                       strObjCommonIn,
                                       strAdvanced_object_Lock_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                strOpeStartForInternalBufferReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                return( rc );
            }
        }
        // Lock Equipment LoadCassette Element (Read)
        CORBA::ULong cassetteLen = cassetteIDs.length();
        stringSequence loadCastSeq;
        loadCastSeq.length(cassetteLen);
        for (i=0; i<cassetteLen; i++)
        {
            loadCastSeq[i] = cassetteIDs[i].identifier;
        }
        
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
        strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_READ;
        strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_LoadCassette );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strOpeStartForInternalBufferReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }        
        
        // controlJobID is not empty
        if ( 0 < CIMFWStrLen(controlJobID.identifier) )
        {
            PPT_METHODTRACE_V1("", "controlJobID exists");
            /*------------------------------*/
            /*   Lock ControlJob Object     */
            /*------------------------------*/
            PPT_METHODTRACE_V2( "", "calling object_Lock()", SP_ClassName_PosControlJob );
            rc = object_Lock( strObject_Lock_out,
                              strObjCommonIn,
                              controlJobID,
                              SP_ClassName_PosControlJob );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                strOpeStartForInternalBufferReqResult.strResult = strObject_Lock_out.strResult;
                return( rc );
            }        
        }
        // controlJobID is empty
        else
        {
            PPT_METHODTRACE_V1("", "controlJobID is empty");
            /*------------------------------*/
            /*   Lock Dispatcher Object     */
            /*------------------------------*/
            PPT_METHODTRACE_V2( "", "calling object_Lock()", SP_ClassName_PosDispatcher );
            rc = object_Lock( strObject_Lock_out,
                              strObjCommonIn,
                              equipmentID,
                              SP_ClassName_PosDispatcher );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                strOpeStartForInternalBufferReqResult.strResult = strObject_Lock_out.strResult;
                return( rc );
            }            

        }
    }
    /*------------------------------*/
    /*   Lock Cassette/Lot Object   */
    /*-------------------------------*/
    objObjectSequence_Lock_out strObjectSequence_Lock_out;

    PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosCassette );
    rc = objectSequence_Lock( strObjectSequence_Lock_out,
                              strObjCommonIn,
                              cassetteIDs,
                              SP_ClassName_PosCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
        strOpeStartForInternalBufferReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }

    PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosLot );
    rc = objectSequence_Lock( strObjectSequence_Lock_out,
                              strObjCommonIn,
                              lotIDs,
                              SP_ClassName_PosLot );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
        strOpeStartForInternalBufferReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }
//DSN000049350 Add End

//DSN000081739 Add Start
    CORBA::Long eqpMonitorSwitch = atoi( getenv(SP_EQPMONITOR_SWITCH) );
    if ( 1 == eqpMonitorSwitch )
    {
        PPT_METHODTRACE_V1("", "1 == SP_EQPMONITOR_SWITCH");
        objectIdentifierSequence eqpMonitorList;
        CORBA::ULong eqpMonitorCnt = 0;
        CORBA::ULong eqpMonitorLen = 5;
        eqpMonitorList.length(eqpMonitorLen);
        pptEqpMonitorJobInfoSequence strEqpMonitorJobInfoSeq;
        CORBA::ULong eqpMonJobCnt = 0;
        CORBA::ULong eqpMonJobLen = 5;
        strEqpMonitorJobInfoSeq.length(eqpMonJobLen);
        CORBA::ULong castLen = tmpStartCassette.length();
        for ( i=0; i<castLen; i++ )
        {
            PPT_METHODTRACE_V2("", "loop to tmpStartCassette.length()", i);
            CORBA::ULong lotLen = tmpStartCassette[i].strLotInCassette.length();
            for ( CORBA::ULong j=0; j<lotLen; j++ )
            {
                PPT_METHODTRACE_V2("", "loop to tmpStartCassette[i].strLotInCassette.length()", j);
                /*---------------------------*/
                /*   Omit Not-OpeStart Lot   */
                /*---------------------------*/
                if ( FALSE == tmpStartCassette[i].strLotInCassette[j].operationStartFlag )
                {
                    PPT_METHODTRACE_V1("", "tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE, continue");
                    continue;
                }

                if ( 0 != CIMFWStrCmp(tmpStartCassette[i].strLotInCassette[j].lotType, SP_Lot_Type_EquipmentMonitorLot)
                  && 0 != CIMFWStrCmp(tmpStartCassette[i].strLotInCassette[j].lotType, SP_Lot_Type_DummyLot) )
                {
                    PPT_METHODTRACE_V1("", "tmpStartCassette[i].strLotInCassette[j].lotType is not Equipment Monitor and Dummy, continue");
                    continue;
                }

                objLot_eqpMonitorSectionInfo_GetForJob_out strLot_eqpMonitorSectionInfo_GetForJob_out;
                objLot_eqpMonitorSectionInfo_GetForJob_in  strLot_eqpMonitorSectionInfo_GetForJob_in;
                strLot_eqpMonitorSectionInfo_GetForJob_in.lotID = tmpStartCassette[i].strLotInCassette[j].lotID;
                rc = lot_eqpMonitorSectionInfo_GetForJob( strLot_eqpMonitorSectionInfo_GetForJob_out,
                                                          strObjCommonIn,
                                                          strLot_eqpMonitorSectionInfo_GetForJob_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_eqpMonitorSectionInfo_GetForJob() != RC_OK", rc);
                    strOpeStartForInternalBufferReqResult.strResult = strLot_eqpMonitorSectionInfo_GetForJob_out.strResult;
                    return rc;
                }

                if ( 0 < CIMFWStrLen( strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier ) )
                {
                    PPT_METHODTRACE_V1("", "0 < CIMFWStrLen( strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier )");
                    if ( 0 == CIMFWStrCmp(strLot_eqpMonitorSectionInfo_GetForJob_out.operationLabel, SP_EqpMonitor_OpeLabel_Monitor) )
                    {
                        PPT_METHODTRACE_V1("", "strLot_eqpMonitorSectionInfo_GetForJob_out.operationLabel is Monitor");
                        CORBA::Boolean bNewEqpMonitor = TRUE;
                        for ( CORBA::ULong iCnt1=0; iCnt1<eqpMonitorCnt; iCnt1++ )
                        {
                            PPT_METHODTRACE_V2("", "loop to eqpMonitorCnt", iCnt1);
                            if ( 0 == CIMFWStrCmp(eqpMonitorList[iCnt1].identifier, strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "eqpMonitorList[iCnt1].identifier == strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID.identifier");
                                bNewEqpMonitor = FALSE;
                                break;
                            }
                        }

                        if ( TRUE == bNewEqpMonitor )
                        {
                            PPT_METHODTRACE_V1("", "TRUE == bNewEqpMonitor");
                            if ( eqpMonitorCnt > eqpMonitorLen )
                            {
                                PPT_METHODTRACE_V1("", "eqpMonitorCnt > eqpMonitorLen");
                                eqpMonitorLen = eqpMonitorLen + 5;
                                eqpMonitorList.length(eqpMonitorLen);
                            }
                            eqpMonitorList[eqpMonitorCnt] = strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID;

                            eqpMonitorCnt++;
                        }
                    }

                    if ( 0 == CIMFWStrCmp(strLot_eqpMonitorSectionInfo_GetForJob_out.operationLabel, SP_EqpMonitor_OpeLabel_Monitor)
                      || TRUE == strLot_eqpMonitorSectionInfo_GetForJob_out.exitFlag )
                    {
                        PPT_METHODTRACE_V1("", "strLot_eqpMonitorSectionInfo_GetForJob_out.operationLabel is Monitor or strLot_eqpMonitorSectionInfo_GetForJob_out.exitFlag is TRUE");
                        CORBA::Boolean bNewEqpMonJob = TRUE;
                        for ( CORBA::ULong iCnt2=0; iCnt2<eqpMonJobCnt; iCnt2++ )
                        {
                            PPT_METHODTRACE_V2("", "loop to eqpMonJobCnt", iCnt2);
                            if ( 0 == CIMFWStrCmp(strEqpMonitorJobInfoSeq[iCnt2].eqpMonitorJobID.identifier,
                                                  strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "strEqpMonitorJobInfoSeq[iCnt2].eqpMonitorJobID.identifier == strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier");
                                bNewEqpMonJob = FALSE;
                                break;
                            }
                        }

                        if ( TRUE == bNewEqpMonJob )
                        {
                            PPT_METHODTRACE_V1("", "TRUE == bNewEqpMonJob");
                            if ( eqpMonJobCnt > eqpMonJobLen )
                            {
                                PPT_METHODTRACE_V1("", "eqpMonJobCnt > eqpMonJobLen");
                                eqpMonJobLen = eqpMonJobLen + 5;
                                strEqpMonitorJobInfoSeq.length(eqpMonJobLen);
                            }
                            strEqpMonitorJobInfoSeq[eqpMonJobCnt].eqpMonitorJobID = strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID;
                            strEqpMonitorJobInfoSeq[eqpMonJobCnt].eqpMonitorID    = strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID;

                            eqpMonJobCnt++;
                        }
                    }
                }
            }
        }
        eqpMonitorList.length(eqpMonitorCnt);
        strEqpMonitorJobInfoSeq.length(eqpMonJobCnt);
        for ( CORBA::ULong iCnt3=0; iCnt3<eqpMonitorCnt; iCnt3++ )
        {
            PPT_METHODTRACE_V2("", "loop to eqpMonitorCnt", iCnt3);
            //Lock EqpMonitor object
            objObject_Lock_out strObject_Lock_out;
            rc = object_Lock( strObject_Lock_out, strObjCommonIn, eqpMonitorList[iCnt3], SP_ClassName_PosEqpMonitor );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2(" ", "##### RC_OK != object_Lock()", rc);
                strOpeStartForInternalBufferReqResult.strResult = strObject_Lock_out.strResult;
                return rc;
            }
        }

        for ( CORBA::ULong iCnt4=0; iCnt4<eqpMonJobCnt; iCnt4++ )
        {
            PPT_METHODTRACE_V2("", "loop to eqpMonJobCnt", iCnt4);
            //Lock EqpMonitor job object
            objObject_LockForEqpMonitorJob_out strObject_LockForEqpMonitorJob_out;
            objObject_LockForEqpMonitorJob_in  strObject_LockForEqpMonitorJob_in;
            strObject_LockForEqpMonitorJob_in.eqpMonitorID    = strEqpMonitorJobInfoSeq[iCnt4].eqpMonitorID;
            strObject_LockForEqpMonitorJob_in.eqpMonitorJobID = strEqpMonitorJobInfoSeq[iCnt4].eqpMonitorJobID;
            rc = object_LockForEqpMonitorJob( strObject_LockForEqpMonitorJob_out,
                                              strObjCommonIn,
                                              strObject_LockForEqpMonitorJob_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_LockForEqpMonitorJob() != RC_OK", rc);
                strOpeStartForInternalBufferReqResult.strResult = strObject_LockForEqpMonitorJob_out.strResult;
                return rc;
            }
        }
    }
//DSN000081739 Add End

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   BRScript Execution Process                                          */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
//D51M0000    nILen = strStartCassette.length();
    nILen = tmpStartCassette.length();          //D51M0000
    PPT_METHODTRACE_V2("", "nILen", nILen);
    for (i=0 ; i<nILen; i++)
    {
        /*-------------------------*/
        /*   Omit Empty Cassette   */
        /*-------------------------*/
//D51M0000        if (CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
        if (CIMFWStrCmp(tmpStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)            //D51M0000
        {
            continue;
        }

        CORBA::Long j = 0;
//D51M0000        CORBA::Long nJLen = strStartCassette[i].strLotInCassette.length();
        CORBA::Long nJLen = tmpStartCassette[i].strLotInCassette.length();                                      //D51M0000
        for (j=0 ; j<nJLen; j++)
        {
            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
//D51M0000            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            if ( tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )                          //D51M0000
            {
                continue;
            }

            /*-------------------------*/
            /*   Execute Pre2 BRScript */
            /*-------------------------*/
            pptRunBRScriptReqResult strRunBRScriptReqResult;
            rc = txRunBRScriptReq( strRunBRScriptReqResult, strObjCommonIn,
                                   SP_BRScript_Pre2,
//D51M0000                                   strStartCassette[i].strLotInCassette[j].lotID,
                                   tmpStartCassette[i].strLotInCassette[j].lotID,                               //D51M0000
                                   equipmentID );
            if ( rc == RC_NOT_FOUND_SCRIPT )
            {
                rc = RC_OK;
            }
            else if ( rc != RC_OK ) 
            {
                PPT_METHODTRACE_V3("", "txRunBRScriptReq() rc != RC_OK", i, j);
                strOpeStartForInternalBufferReqResult.strResult = strRunBRScriptReqResult.strResult;
                return( rc );
            }
        }
    }

    //P5000247 Add Start
    //---------------------------------------------------------------------------------
    // ControlJob Checking
    // If Start Cassette had a Control Job whether InParameter of Control Job is blank,
    // Makes request fail.
    //---------------------------------------------------------------------------------
    if ( CIMFWStrLen(controlJobID.identifier) == 0 )
    {
        PPT_METHODTRACE_V1("","Inpara controlJoID is Blank");
        //-----------------------------------------------------------
        // ControlJob Check for first record of strStartCassette.
        // Because checking ControlJob whether All ControlJoj is same
        // at cassette_CheckConditionForOperation().
        //-----------------------------------------------------------
        objCassette_controlJobID_Get_out   strCassette_controlJobID_Get_out;
//D51M0000        rc = cassette_controlJobID_Get(strCassette_controlJobID_Get_out, strObjCommonIn, strStartCassette[0].cassetteID );
        rc = cassette_controlJobID_Get(strCassette_controlJobID_Get_out, strObjCommonIn, tmpStartCassette[0].cassetteID );              //D51M0000
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cassette_controlJobID_Get() rc != RC_OK")
            strOpeStartForInternalBufferReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
            return( rc );
        }

        if ( CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) > 0 )
        {
            //---------------------------------
            // Inpara ControlJob is not blank
            // but StartCassette has ControlJo.
            //---------------------------------
            PPT_METHODTRACE_V2("","cassette's controlJob is not nil",strCassette_controlJobID_Get_out.controlJobID.identifier);
            SET_MSG_RC( strOpeStartForInternalBufferReqResult, MSG_CAST_CTRLJOBID_FILLED, RC_CAST_CTRLJOBID_FILLED );
            return( RC_CAST_CTRLJOBID_FILLED );
        }
    }
    //P5000247 Add End

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Cassette                                          */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - controlJobID                                                      */
    /*   - multiLotType                                                      */
    /*   - transferState                                                     */
    /*   - transferReserved                                                  */
    /*   - dispatchState                                                     */
    /*   - maxBatchSize                                                      */
    /*   - minBatchSize                                                      */
    /*   - emptyCassetteCount                                                */
    /*   - cassette's loadingSequenceNumber                                  */
    /*   - eqp's multiRecipeCapability and recipeParameter                   */
    /*   - Upper/Lower Limit for RecipeParameterChange                       */
    /*   - MonitorLotCount or OperationStartLotCount                         */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
//D4000015    objCassette_CheckConditionForOperation_out strCassette_CheckConditionForOperation_out;
//D4000015    rc = cassette_CheckConditionForOperation( strCassette_CheckConditionForOperation_out, strObjCommonIn,
//D4000015                                              equipmentID, portGroupID, strStartCassette, SP_Operation_OpeStart );
//D4000015    if ( rc != RC_OK )
//D4000015    {
//D4000015        PPT_METHODTRACE_V1("", "cassette_CheckConditionForOperation() rc != RC_OK");
//D4000015        strOpeStartForInternalBufferReqResult.strResult = strCassette_CheckConditionForOperation_out.strResult;
//D4000015        return( rc );
//D4000015    }

//D4000015 add start
    objCassette_CheckConditionForOperationForInternalBuffer_out strCassette_CheckConditionForOperationForInternalBuffer_out;
    rc = cassette_CheckConditionForOperationForInternalBuffer( strCassette_CheckConditionForOperationForInternalBuffer_out, strObjCommonIn,
//D51M0000                                                               equipmentID, strStartCassette, SP_Operation_OpeStart );
                                                               equipmentID, tmpStartCassette, SP_Operation_OpeStart );              //D51M0000
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cassette_CheckConditionForOperationForInternalBuffer() rc != RC_OK");
        strOpeStartForInternalBufferReqResult.strResult = strCassette_CheckConditionForOperationForInternalBuffer_out.strResult;
        return( rc );
    }
//D4000015 add end

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Lot                                               */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - controlJobID                                                      */
    /*   - lot's equipmentID                                                 */
    /*   - lotHoldState                                                      */
    /*   - lotProcessState                                                   */
    /*   - lotInventoryState                                                 */
    /*   - entityInhibition                                                  */
    /*   - minWaferCount                                                     */
    /*   - equipment's availability for specified lot                        */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
//D4000015    objLot_CheckConditionForOperation_out strLot_CheckConditionForOperation_out;
//D4000015    rc = lot_CheckConditionForOperation( strLot_CheckConditionForOperation_out, strObjCommonIn,
//D4000015                                         equipmentID, portGroupID, strStartCassette, SP_Operation_OpeStart );
//D4000015    if ( rc != RC_OK )
//D4000015    {
//D4000015        PPT_METHODTRACE_V1("", "lot_CheckConditionForOperation() rc != RC_OK");
//D4000015        strOpeStartForInternalBufferReqResult.strResult = strLot_CheckConditionForOperation_out.strResult;
//D4000015        return( rc );
//D4000015    }

//D4000015 add start
    objLot_CheckConditionForOperationForInternalBuffer_out strLot_CheckConditionForOperationForInternalBuffer_out;
    rc = lot_CheckConditionForOperationForInternalBuffer( strLot_CheckConditionForOperationForInternalBuffer_out, strObjCommonIn,
//D51M0000                                                          equipmentID, strStartCassette, SP_Operation_OpeStart );
                                                          equipmentID, tmpStartCassette, SP_Operation_OpeStart );           //D51M0000
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_CheckConditionForOperationForInternalBuffer() rc != RC_OK");
        strOpeStartForInternalBufferReqResult.strResult = strLot_CheckConditionForOperationForInternalBuffer_out.strResult;
        return( rc );
    }
//D4000015 add end

    /*-----------------------------------------------------------------------------*/
    /*                                                                             */
    /*   Check Equipment Port for OpeStart                                         */
    /*                                                                             */
    /*   The following conditions are checked by this object                       */
    /*                                                                             */
    /*   1. All of ports' loadMode must be CIMFW_PortRsc_Input or _InputOutput.    */
    /*   2. All of port, which is registered as in-parm's portGroup, must be       */
    /*      _LoadComp when equipment is online.                                    */
    /*   3. All of port, which is registered as in-parm's portGroup, must have     */
    /*      loadedCassetteID. And each combination of cassetteID/portID must be    */
    /*      same as in-parm's startCassette perfectlly.                            */
//D4000015    /*   4. strStartCassette[].loadPortID's portGroupID must be same as in-parm's  */
//D4000015    /*      portGroupID.                                                           */
    /*   5. strStartCassette[].loadPurposeType must be match as specified port's   */
    /*      loadPutposeType.                                                       */
    /*   6. strStartCassette[].loadSequenceNumber must be same as specified port's */
    /*      loadSequenceNumber.                                                    */
    /*                                                                             */
    /*-----------------------------------------------------------------------------*/
//D4000015    objEquipment_portState_CheckForOpeStart_out strEquipment_portState_CheckForOpeStart_out;
//D4000015    rc = equipment_portState_CheckForOpeStart( strEquipment_portState_CheckForOpeStart_out, strObjCommonIn,
//D4000015                                               equipmentID, portGroupID, strStartCassette );
//D4000015    if ( rc != RC_OK ) 
//D4000015    {
//D4000015        PPT_METHODTRACE_V1("", "equipment_portState_CheckForOpeStart() rc != RC_OK");
//D4000015        strOpeStartForInternalBufferReqResult.strResult = strEquipment_portState_CheckForOpeStart_out.strResult;
//D4000015        return( rc );
//D4000015    }

//D4000015 add start
    objEquipment_portState_CheckForOpeStartForInternalBuffer_out strEquipment_portState_CheckForOpeStartForInternalBuffer_out;
    rc = equipment_portState_CheckForOpeStartForInternalBuffer( strEquipment_portState_CheckForOpeStartForInternalBuffer_out, strObjCommonIn,
//D51M0000                                                                equipmentID, strStartCassette );
                                                                equipmentID, tmpStartCassette );            //D51M0000
    if ( rc != RC_OK ) 
    {
        PPT_METHODTRACE_V1("", "equipment_portState_CheckForOpeStart() rc != RC_OK");
        strOpeStartForInternalBufferReqResult.strResult = strEquipment_portState_CheckForOpeStartForInternalBuffer_out.strResult;
        return( rc );
    }
//D4000015 add end

//D4000015 start end
    /*------------------------------------*/
    /*   Get and Check Cassette on Port   */
    /*------------------------------------*/
    objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
    rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out, strObjCommonIn, equipmentID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "equipment_portInfo_Get() != RC_OK");
        strEquipment_portState_CheckForOpeStartForInternalBuffer_out.strResult = strEquipment_portInfo_Get_out.strResult;
        return(rc);
    }
//D4000015 add end

    /*---------------------------------*/
    /*   Get Equipment's Online Mode   */
    /*---------------------------------*/
    objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
//D4000015    rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out, strObjCommonIn,
//D4000015                                                equipmentID, strStartCassette[0].loadPortID );
    //P4100536 add start
    // Check length of Equipment Port
    if(0 >= strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length())
    {
        PPT_SET_MSG_RC_KEY(strOpeStartForInternalBufferReqResult, MSG_NOT_FOUND_PORT, RC_NOT_FOUND_PORT, "(This equipment does not have any port.)"); //P4200025 add
        return RC_NOT_FOUND_PORT;
    }
    //P4100536 add end
    rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out, strObjCommonIn,
                                                equipmentID, 
                                                strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[0].portID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "portResource_currentOperationMode_Get() rc != RC_OK");
        strOpeStartForInternalBufferReqResult.strResult = strPortResource_currentOperationMode_Get_out.strResult;
        return( rc );
    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for FlowBatch                                         */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   1. whether in-parm's equipment has reserved flowBatchID or not      */
    /*      fill  -> all of flowBatch member and in-parm's lot must be       */
    /*               same perfectly.                                         */
    /*      blank -> no check                                                */
    /*                                                                       */
    /*   2. whether lot is in flowBatch section or not                       */
    /*      in    -> lot must have flowBatchID, and flowBatch must have      */
    /*               reserved equipmentID.                                   */
    /*               if lot is on target operation, flowBatch's reserved     */
    /*               equipmentID and in-parm's equipmentID must be same.     */
    /*      out   -> no check                                                */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
//D9000079    objEquipment_lot_CheckFlowBatchConditionForOpeStart_out strEquipment_lot_CheckFlowBatchConditionForOpeStart_out;
//D4000015    rc = equipment_lot_CheckFlowBatchConditionForOpeStart( strEquipment_lot_CheckFlowBatchConditionForOpeStart_out, strObjCommonIn,
//D4000015                                                           equipmentID, portGroupID, strStartCassette );
//D9000079//D4000015 add start
//D9000079    rc = equipment_lot_CheckFlowBatchConditionForOpeStart( strEquipment_lot_CheckFlowBatchConditionForOpeStart_out, strObjCommonIn,
//D9000079//D51M0000                                                           equipmentID, "", strStartCassette );
//D9000079                                                           equipmentID, "", tmpStartCassette );             //D51M0000
//D9000079//D4000015 add end
//D9000079 add start
    objEquipment_lot_CheckFlowBatchConditionForOpeStart_out__090 strEquipment_lot_CheckFlowBatchConditionForOpeStart_out;
    objEquipment_lot_CheckFlowBatchConditionForOpeStart_in__090  strEquipment_lot_CheckFlowBatchConditionForOpeStart_in;
    strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.equipmentID      = equipmentID;
    strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.portGroupID      = "";
    strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.strStartCassette = tmpStartCassette;
    rc = equipment_lot_CheckFlowBatchConditionForOpeStart__090( strEquipment_lot_CheckFlowBatchConditionForOpeStart_out,
                                                                strObjCommonIn,
                                                                strEquipment_lot_CheckFlowBatchConditionForOpeStart_in );
//D9000079 add end
    if ( rc != RC_OK ) 
    {
//D9000079        PPT_METHODTRACE_V1("", "equipment_lot_CheckFlowBatchConditionForOpeStart() rc != RC_OK");
        PPT_METHODTRACE_V1("", "equipment_lot_CheckFlowBatchConditionForOpeStart__090() rc != RC_OK");   //D9000079
        strOpeStartForInternalBufferReqResult.strResult = strEquipment_lot_CheckFlowBatchConditionForOpeStart_out.strResult;
        return( rc );
    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Process Durable                                   */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   1. Whether equipment requires process durable or not                */
    /*      If no-need, return OK;                                           */
    /*                                                                       */
    /*   2. All of specified reticles / fixtures must be in the equipment.   */
    /*      And, their state must be _Available or _InUse.                   */
    /*                                                                       */
    /*   3. Entity inhibition for all of specified reticles must not be      */
    /*      registered.                                                      */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/

    /*-----------------------------------------*/
    /*   Check Process Durable Required Flag   */
    /*-----------------------------------------*/
    objEquipment_processDurableRequiredFlag_Get_out strEquipment_processDurableRequiredFlag_Get_out;
    rc = equipment_processDurableRequiredFlag_Get( strEquipment_processDurableRequiredFlag_Get_out, strObjCommonIn,
                                                   equipmentID );
    CORBA::Long saveRC = rc;
    if ( rc == RC_EQP_PROCDRBL_RTCL_REQD ||
         rc == RC_EQP_PROCDRBL_FIXT_REQD )
    {
        PPT_METHODTRACE_V1("", "rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD");
        CORBA::Long i = 0;
//D51M0000        CORBA::Long nILen = strStartCassette.length();
        CORBA::Long nILen = tmpStartCassette.length();              //D51M0000
        PPT_METHODTRACE_V2("", "nILen", nILen);
        for (i=0 ; i<nILen; i++)
        {
//D51M0000            if (CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
            if (CIMFWStrCmp(tmpStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)            //D51M0000
            {
                continue;
            }

            CORBA::Long j = 0;
//D51M0000            CORBA::Long nJLen = strStartCassette[i].strLotInCassette.length();
            CORBA::Long nJLen = tmpStartCassette[i].strLotInCassette.length();                                      //D51M0000
            PPT_METHODTRACE_V3("", "nJLen", nJLen, i);
            for (j=0 ; j<nJLen; j++)
            {
//D51M0000                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                if ( tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )                          //D51M0000
                {
                    continue;
                }

//D4200031      if ( saveRC == RC_EQP_PROCDRBL_RTCL_REQD )
                if ( saveRC == RC_EQP_PROCDRBL_RTCL_REQD                                                  //D4200031
//D51M0000                  && strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle.length() > 0 )//D4200031
                  && tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle.length() > 0 )          //D51M0000
                {
                    PPT_METHODTRACE_V3("", "saveRC == RC_EQP_PROCDRBL_RTCL_REQD", i, j);

                    /*---------------------------------*/
                    /*   Get and Check Reticle State   */
                    /*     - state                     */
                    /*     - transferState             */
                    /*---------------------------------*/
                    objReticle_state_Check_out strReticle_state_Check_out;
//DSN000101569                     rc = reticle_state_Check( strReticle_state_Check_out,  strObjCommonIn,
//DSN000101569                                               equipmentID, 
//DSN000101569 //D51M0000                                              strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle );
//DSN000101569                                               tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle );         //D51M0000
//DSN000101569 add start
                    rc = reticle_state_Check__170( strReticle_state_Check_out,
                                                   strObjCommonIn,
                                                   equipmentID, 
                                                   tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle,
                                                   tmpStartCassette[i].strLotInCassette[j].lotID );
//DSN000101569 add end
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V3("", "reticle_state_Check() rc != RC_OK", i, j);
                        strOpeStartForInternalBufferReqResult.strResult = strReticle_state_Check_out.strResult;
                        return( rc );
                    }

                    /*------------------------------*/
                    /*   Check Reticle Inhibition   */
                    /*------------------------------*/
//D51M0000                    CORBA::Long rtclLen = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle.length();
                    CORBA::Long rtclLen = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle.length();      //D51M0000

                    pptEntityInhibitAttributes entityInhibitAttributes;
                    entityInhibitAttributes.entities.length(rtclLen);
                    CORBA::Long k = 0;
                    PPT_METHODTRACE_V4("", "rtclLen", rtclLen, i, j);
                    for ( k=0 ; k<rtclLen ; k++ )
                    {
                        entityInhibitAttributes.entities[k].className = CIMFWStrDup( SP_InhibitClassID_Reticle );
//D51M0000                        entityInhibitAttributes.entities[k].objectID  = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID;
                        entityInhibitAttributes.entities[k].objectID  = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID;            //D51M0000
                        entityInhibitAttributes.entities[k].attrib    = CIMFWStrDup( "" );

                        PPT_METHODTRACE_V2("", "entityInhibitAttributes.entities[k].objectID ---> ", entityInhibitAttributes.entities[k].objectID.identifier);
                    }

                    objEntityInhibit_CheckForEntities_out strEntityInhibit_CheckForEntities_out;
                    rc = entityInhibit_CheckForEntities( strEntityInhibit_CheckForEntities_out, strObjCommonIn,
                                                         entityInhibitAttributes );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V3("", "entityInhibit_CheckForEntities() rc != RC_OK", i, j);
                        strOpeStartForInternalBufferReqResult.strResult = strEntityInhibit_CheckForEntities_out.strResult;
                        return( rc );
                    }

                    CORBA::Long lenInhibit = strEntityInhibit_CheckForEntities_out.entityInhibitInfo.length() ;
//DSN000085791 add start
                    objEntityInhibit_FilterExceptionLot_out strEntityInhibit_FilterExceptionLot_out;
                    if ( lenInhibit > 0 )
                    {
                        // filter exception for entity inhibit
                        objEntityInhibit_FilterExceptionLot_in strEntityInhibit_FilterExceptionLot_in;
                        strEntityInhibit_FilterExceptionLot_in.strEntityInhibitInfos = strEntityInhibit_CheckForEntities_out.entityInhibitInfo;
                        strEntityInhibit_FilterExceptionLot_in.lotID = tmpStartCassette[i].strLotInCassette[j].lotID;

                        rc = entityInhibit_FilterExceptionLot(strEntityInhibit_FilterExceptionLot_out,
                                                              strObjCommonIn,
                                                              strEntityInhibit_FilterExceptionLot_in);
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2( ""," #### entityInhibit_FilterExceptionLot() != RC_OK : rc = ", rc );
                            strOpeStartForInternalBufferReqResult.strResult = strEntityInhibit_FilterExceptionLot_out.strResult;
                            return rc;
                        }

                        lenInhibit = strEntityInhibit_FilterExceptionLot_out.strEntityInhibitInfos.length();
                        PPT_METHODTRACE_V2("","number of Inhibits filtered exception",lenInhibit);
                    }
//DSN000085791 add end
                    if( lenInhibit > 0 )                                                                       
                    {                                                                                          
                        //P4100570 add start
                        // Check length of Entity Inhibit
//DSN000085791                        if(0 >= strEntityInhibit_CheckForEntities_out.entityInhibitInfo[0].entityInhibitAttributes.entities.length())
                        if(0 >= strEntityInhibit_FilterExceptionLot_out.strEntityInhibitInfos[0].entityInhibitAttributes.entities.length()) //DSN000085791
                        {
                            SET_MSG_RC(strOpeStartForInternalBufferReqResult, MSG_NOT_FOUND_ENTITYINHIBIT, RC_NOT_FOUND_ENTITYINHIBIT); //P4200025 add
                            return RC_NOT_FOUND_ENTITYINHIBIT;
                        }
                        //P4100570 add end
                        PPT_METHODTRACE_V2("", "Inhibit record for reticle is found", lenInhibit );       
                        PPT_SET_MSG_RC_KEY2 ( strOpeStartForInternalBufferReqResult,                      
                                              MSG_INHIBIT_ENTITY ,                                        
                                              RC_INHIBIT_ENTITY ,                                        
//DSN000085791                                              strEntityInhibit_CheckForEntities_out.entityInhibitInfo[0].entityInhibitAttributes.entities[0].objectID.identifier,
                                              strEntityInhibit_FilterExceptionLot_out.strEntityInhibitInfos[0].entityInhibitAttributes.entities[0].objectID.identifier, //DSN000085791
                                              SP_InhibitClassID_Reticle );
                        return( RC_INHIBIT_ENTITY ); 
                    }                                
//D9000084 add start
                    rtclLen = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle.length();
                    for ( k = 0; k < rtclLen; k++ )
                    {
                        /*--------------------------------------*/
                        /*  Check ReticleDispatchJob existence  */
                        /*--------------------------------------*/
                        objectIdentifier dummyID;
                        objReticle_dispatchJob_CheckExistenceDR_out strReticle_dispatchJob_CheckExistenceDR_out;
                        rc = reticle_dispatchJob_CheckExistenceDR( strReticle_dispatchJob_CheckExistenceDR_out,
                                                                   strObjCommonIn,
                                                                   tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID,
                                                                   dummyID,    //reticlePodID
                                                                   dummyID );  //toEquipmentID
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "reticle_dispatchJob_CheckExistenceDR() != RC_OK", rc);
                            strOpeStartForInternalBufferReqResult.strResult = strReticle_dispatchJob_CheckExistenceDR_out.strResult;
                            return( rc );
                        }

                        /*--------------------------------*/
                        /*  Check Reticle Pod relation.   */
                        /*--------------------------------*/
//DSN000096126                        objReticle_detailInfo_GetDR_in__090 strReticle_detailInfo_GetDR_in__090;
//DSN000096126                        strReticle_detailInfo_GetDR_in__090.reticleID = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID;
//DSN000096126
//DSN000096126                        objReticle_detailInfo_GetDR_out__090 strReticle_detailInfo_GetDR_out__090;
//DSN000096126                        rc = reticle_detailInfo_GetDR__090( strReticle_detailInfo_GetDR_out__090,
//DSN000096126                                                            strObjCommonIn,
//DSN000096126                                                            strReticle_detailInfo_GetDR_in__090 );
//DSN000096126                        if( rc != RC_OK )
//DSN000096126                        {
//DSN000096126                            PPT_METHODTRACE_V2("", "reticle_detailInfo_GetDR__090() != RC_OK", rc);
//DSN000096126                            strOpeStartForInternalBufferReqResult.strResult = strReticle_detailInfo_GetDR_out__090.strResult;
//DSN000096126                            return( rc );
//DSN000096126                        }
//DSN000096126 Add Start
//DSN000101569                        objReticle_detailInfo_GetDR_out__160 strReticle_detailInfo_GetDR_out;
                        objReticle_detailInfo_GetDR_out__170 strReticle_detailInfo_GetDR_out;                                   //DSN000101569
                        objReticle_detailInfo_GetDR_in__160  strReticle_detailInfo_GetDR_in;
                        strReticle_detailInfo_GetDR_in.reticleID                   = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID;
                        strReticle_detailInfo_GetDR_in.durableOperationInfoFlag    = FALSE;
                        strReticle_detailInfo_GetDR_in.durableWipOperationInfoFlag = FALSE;
//DSN000101569                        rc = reticle_detailInfo_GetDR__160(strReticle_detailInfo_GetDR_out, strObjCommonIn, strReticle_detailInfo_GetDR_in);
                        rc = reticle_detailInfo_GetDR__170(strReticle_detailInfo_GetDR_out, strObjCommonIn, strReticle_detailInfo_GetDR_in); //DSN000101569
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "reticle_detailInfo_GetDR__170() != RC_OK", rc);
                            strOpeStartForInternalBufferReqResult.strResult = strReticle_detailInfo_GetDR_out.strResult;
                            return( rc );
                        }
//DSN000096126 Add End

//DSN000096126                        if( 0 != CIMFWStrLen( strReticle_detailInfo_GetDR_out__090.strReticleStatusInqResult.reticleStatusInfo.reticlePodID.identifier ) )
                        if( 0 != CIMFWStrLen( strReticle_detailInfo_GetDR_out.strReticleStatusInqResult.reticleStatusInfo.reticlePodID.identifier ) ) //DSN000096126
                        {
                            PPT_METHODTRACE_V3("","Required reticle relates with reticlePod.",
                                                  tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID.identifier,
//DSN000096126                                                  strReticle_detailInfo_GetDR_out__090.strReticleStatusInqResult.reticleStatusInfo.reticlePodID.identifier );
                                                  strReticle_detailInfo_GetDR_out.strReticleStatusInqResult.reticleStatusInfo.reticlePodID.identifier ); //DSN000096126
                            SET_MSG_RC(strOpeStartForInternalBufferReqResult, MSG_NOT_AVAILABLE_RETICLE, RC_NOT_AVAILABLE_RETICLE);
                            return( RC_NOT_AVAILABLE_RETICLE );
                        }
                    }
//D9000084 add end
                }
                else if ( saveRC == RC_EQP_PROCDRBL_FIXT_REQD )
                {
                    PPT_METHODTRACE_V3("", "saveRC == RC_EQP_PROCDRBL_FIXT_REQD", i, j);
                    /*---------------------------------*/
                    /*   Get and Check Fixture State   */
                    /*     - state                     */
                    /*     - transferState             */
                    /*---------------------------------*/
                    objFixture_state_Check_out strFixture_state_Check_out;
                    rc = fixture_state_Check( strFixture_state_Check_out, strObjCommonIn,
//D51M0000                                              equipmentID, strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture );
                                              equipmentID, tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture );                //D51M0000
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V3("", "entitfixture_state_CheckyInhibit_CheckForEntities() rc != RC_OK", i, j);
                        strOpeStartForInternalBufferReqResult.strResult = strFixture_state_Check_out.strResult;
                        return( rc );
                    }
                }
            }
        }
    }
    else if ( rc == RC_EQP_PROCDRBL_NOT_REQD )
    {
         rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1("", "equipment_processDurableRequiredFlag_Get() rc != RC_OK");
        strOpeStartForInternalBufferReqResult.strResult = strEquipment_processDurableRequiredFlag_Get_out.strResult;
        return( rc );
    }
//D4000016 Add Start
//    /*---------------------------------------------------------------------------*/
//    /*                                                                           */
//    /*   Check Category for Copper/Non Copper                                    */
//    /*                                                                           */
//    /*   It is checked in the following method whether it is the condition       */
//    /*   that Lot of the object is made of OpeStart.                             */
//    /*                                                                           */
//    /*   1. It is checked whether CassetteCategory of RequiredCassetteCategory   */
//    /*      of PosLot and PosCassette is the same.                               */
//    /*                                                                           */
//    /*   2. It is checked whether CassetteCategoryCapability of CassetteCategory */
//    /*      of PosCassette and PosPortResource is the same.                      */
//    /*                                                                           */
//    /*   3. It is proper condition if CassetteCategoryCapability is the same     */
//    /*      as RequiredCassetteCategory and CassetteCategory.                    */
//    /*                                                                           */
//    /*---------------------------------------------------------------------------*/
//
//    CORBA::Long ii;
//    CORBA::Long jj;
//    CORBA::Long nCastLen = strStartCassette.length();
//    CORBA::Long nLotInCastLen;
//
//    for ( ii = 0; ii < nCastLen; ii++ )
//    {
//        nLotInCastLen = strStartCassette[ii].strLotInCassette.length();
//        for ( jj = 0; jj < nLotInCastLen; jj++ )
//        {
//            objLot_CassetteCategory_CheckForContaminationControl_out strLot_CassetteCategory_CheckForContaminationControl_out;
//            rc = lot_CassetteCategory_CheckForContaminationControl( strLot_CassetteCategory_CheckForContaminationControl_out,
//                                                      strObjCommonIn,
//                                                      strStartCassette[ii].strLotInCassette[jj].lotID,
//                                                      strStartCassette[ii].cassetteID,
//                                                      equipmentID,
//                                                      strStartCassette[ii].loadPortID);
//            if ( rc != RC_OK )
//            {
//                PPT_METHODTRACE_V1( "CS_PPTManager_i:: txOpeStartReq", "lot_CassetteCategory_CheckForContaminationControl() != RC_OK");
//                strOpeStartForInternalBufferReqResult.strResult = strLot_CassetteCategory_CheckForContaminationControl_out.strResult;
//                return( rc );
//            }
//        }
//    }
////D4000016 Add End       
//

//D7000041 start
    /*---------------------------------------------------------------------------*/
    /*                                                                           */
    /*   Check Carrier Category for next operation of Empty carrier.             */
    /*                                                                           */
    /*---------------------------------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call emptyCassette_CheckCategoryForOperation()");
    objEmptyCassette_CheckCategoryForOperation_out strEmptyCassette_CheckCategoryForOperation_out;
    rc = emptyCassette_CheckCategoryForOperation( strEmptyCassette_CheckCategoryForOperation_out, strObjCommonIn, tmpStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "emptyCassette_CheckCategoryForOperation() != RC_OK", rc);
        strOpeStartForInternalBufferReqResult.strResult = strEmptyCassette_CheckCategoryForOperation_out.strResult;
        return( rc );
    }
//D7000041 end
//INN-R170002 add start
    //------------------------------------------------------------------------
    //   Check contamination information for newly created lot
    //------------------------------------------------------------------------
    nILen = tmpStartCassette.length();
    PPT_METHODTRACE_V2("", "nILen", nILen);
    for (i=0 ; i<nILen; i++)
    {
        /*-------------------------*/
        /*   Omit Empty Cassette   */
        /*-------------------------*/
        if (CIMFWStrCmp(tmpStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
        {
            //continue;
        }
        else
        {
            PPT_METHODTRACE_V1( "", "call cs_lot_ContaminationInfo_CheckForProcess()");

            csObjLot_ContaminationInfo_CheckForProcess_in  strLot_ContaminationInfo_CheckForProcess_in;
            strLot_ContaminationInfo_CheckForProcess_in.equipmentID = equipmentID;
            strLot_ContaminationInfo_CheckForProcess_in.carrierID   = tmpStartCassette[i].cassetteID;
            strLot_ContaminationInfo_CheckForProcess_in.strLotInCassette = tmpStartCassette[i].strLotInCassette;

            csObjLot_ContaminationInfo_CheckForProcess_out strLot_ContaminationInfo_CheckForProcess_out;
            rc = cs_lot_ContaminationInfo_CheckForProcess( strLot_ContaminationInfo_CheckForProcess_out,
                                                           strObjCommonIn,
                                                           strLot_ContaminationInfo_CheckForProcess_in);

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "cs_lot_ContaminationInfo_CheckForProcess() != RC_OK");
                strOpeStartForInternalBufferReqResult.strResult = strLot_ContaminationInfo_CheckForProcess_out.strResult;
                return( rc );
            }
            if ( FALSE == strLot_ContaminationInfo_CheckForProcess_out.matchFlag )
            {
                PPT_METHODTRACE_V1( "", "strLot_ContaminationInfo_CheckForProcess_out.matchFlag=FALSE");
                CS_PPT_SET_MSG_RC_KEY1( strOpeStartForInternalBufferReqResult,
                                     CS_MSG_CARRIER_CONTAMINATION_MISMATCH,
                                     CS_RC_CARRIER_CONTAMINATION_MISMATCH,
                                     tmpStartCassette[i].cassetteID.identifier );
                return CS_RC_CARRIER_CONTAMINATION_MISMATCH;
            }
        }
    }
//INN-R170002 add end

//P4100018 Add End
    //-------------------------------------------------
    //  Check Scrap Wafer Exsit In Carrier
    //-------------------------------------------------
//DSN000049350    objectIdentifierSequence cassetteIDs ;
//D51M0000    CORBA::Long castLen = strStartCassette.length();
    CORBA::Long castLen = tmpStartCassette.length();                //D51M0000
    CORBA::Long cnt = 0;
    cassetteIDs.length( castLen ) ;

    for(cnt = 0 ; cnt < castLen; cnt++ )
    {
//D51M0000        cassetteIDs[cnt] = strStartCassette[cnt].cassetteID;
        cassetteIDs[cnt] = tmpStartCassette[cnt].cassetteID;        //D51M0000
    }

    objCassette_scrapWafer_SelectDR_out  strCassette_scrapWafer_SelectDR_out;
    rc = cassette_scrapWafer_SelectDR( strCassette_scrapWafer_SelectDR_out,
                                       strObjCommonIn,
                                       cassetteIDs);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cassette_scrapWafer_SelectDR() != RC_OK",rc);
        strOpeStartForInternalBufferReqResult.strResult = strCassette_scrapWafer_SelectDR_out.strResult;
        return (rc);
    }

    CORBA::Long scrapCount = strCassette_scrapWafer_SelectDR_out.strLotWaferMap.length();
    if( scrapCount > 0 )
    {
        PPT_METHODTRACE_V2("", "ScrapWafer Found ",scrapCount);
        SET_MSG_RC(strOpeStartForInternalBufferReqResult, MSG_FOUND_SCRAP, RC_FOUND_SCRAP) ;
        return (RC_FOUND_SCRAP);
    }

//P4100018 Add End

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Main Process                                                        */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

    /*--------------------------------------------------------*/
    /*     Control Job Related Information Update Procedure   */
    /*--------------------------------------------------------*/
    objectIdentifier saveControlJobID;

    if ( CIMFWStrLen(controlJobID.identifier) == 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) == 0");

        /*-------------------------------------------------------------*/
        /*   Create Control Job and Assign to Each Cassettes / Lots    */
        /*                                                             */
        /*   - Create new controlJob                                   */
        /*   - Set created controlJobID to each cassettes / lots       */
        /*   - Set created controlJobID to equipment                   */
        /*-------------------------------------------------------------*/
//D7000006        objControlJob_Create_out strControlJob_Create_out;
//D7000006//D4000015        rc = controlJob_Create( strControlJob_Create_out, strObjCommonIn,
//D7000006//D4000015                                equipmentID, portGroupID, strStartCassette );
//D7000006//D4000015 add start
//D7000006        rc = controlJob_Create( strControlJob_Create_out, strObjCommonIn,
//D7000006//D51M0000                                equipmentID, "", strStartCassette );
//D7000006                                equipmentID, "", tmpStartCassette );               //D51M0000
//D7000006//D4000015 add end
//D7000006        if ( rc != RC_OK )
//D7000006        {
//D7000006            PPT_METHODTRACE_V1("", "controlJob_Create() rc != RC_OK");
//D7000006            strOpeStartForInternalBufferReqResult.strResult = strControlJob_Create_out.strResult;
//D7000006            return( rc );
//D7000006        }
//D7000006        saveControlJobID = strControlJob_Create_out.controlJobID;
        //D7000006 Add Start
        pptControlJobManageReqResult strControlJobManageReqResult;
        pptControlJobCreateRequest   strControlJobCreateRequest;
        objectIdentifier             dummyControlJobID;
        strControlJobCreateRequest.equipmentID = equipmentID;
        strControlJobCreateRequest.portGroupID = CIMFWStrDup("");
        strControlJobCreateRequest.strStartCassette = tmpStartCassette;
        rc = txControlJobManageReq( strControlJobManageReqResult,
                                    strObjCommonIn,
                                    dummyControlJobID,
                                    SP_ControlJobAction_Type_create,
                                    strControlJobCreateRequest,
                                    claimMemo );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "txControlJobManageReq() != RC_OK");
            strOpeStartForInternalBufferReqResult.strResult = strControlJobManageReqResult.strResult;
            return( rc );
        }
        saveControlJobID = strControlJobManageReqResult.controlJobID;
        //D7000006 Add End

        /*----------------------------------------------------*/
        /*   Set Start Reservation Info to Each Lots' PO      */
        /*                                                    */
        /*   - Set created controlJobID into each cassette.   */
        /*   - Set created controlJobID into each lot.        */
        /*   - Set control job info (StartRecipe, DCDefs,     */
        /*     DCSpecs, Parameters, ...) into each lot's      */
        /*     cunrrent PO.                                   */
        /*----------------------------------------------------*/
//D9000003 delete start
//        objProcess_startReserveInformation_Set_out strProcess_startReserveInformation_Set_out;
////D4000015        rc = process_startReserveInformation_Set( strProcess_startReserveInformation_Set_out, strObjCommonIn,
////D4000015                                                  equipmentID, portGroupID, saveControlJobID, strStartCassette );
////D4000015 add start
//        rc = process_startReserveInformation_Set( strProcess_startReserveInformation_Set_out, strObjCommonIn,
////D51M0000                                                  equipmentID, "", saveControlJobID, strStartCassette );
//                                                  equipmentID, "", saveControlJobID, tmpStartCassette );            //D51M0000
////D4000015 add end
//        if ( rc != RC_OK )
//        {
//            PPT_METHODTRACE_V1("", "process_startReserveInformation_Set() rc != RC_OK");
//            strOpeStartForInternalBufferReqResult.strResult = strProcess_startReserveInformation_Set_out.strResult;
//            return( rc );
//        }
//D9000003 delete end
//D9000003 add start
        objProcess_startReserveInformation_Set_out__090 strProcess_startReserveInformation_Set_out__090;
        objProcess_startReserveInformation_Set_in__090 strProcess_startReserveInformation_Set_in__090;
        strProcess_startReserveInformation_Set_in__090.equipmentID = equipmentID;
        strProcess_startReserveInformation_Set_in__090.portGroupID = CIMFWStrDup("");
        strProcess_startReserveInformation_Set_in__090.controlJobID = saveControlJobID;
        strProcess_startReserveInformation_Set_in__090.strStartCassette = tmpStartCassette;
        strProcess_startReserveInformation_Set_in__090.processJobPauseFlag = processJobPauseFlag;

        rc = process_startReserveInformation_Set__090( strProcess_startReserveInformation_Set_out__090, strObjCommonIn, strProcess_startReserveInformation_Set_in__090);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "process_startReserveInformation_Set__090() rc != RC_OK");
            strOpeStartForInternalBufferReqResult.strResult = strProcess_startReserveInformation_Set_out__090.strResult;
            return( rc );
        }
//D9000003 add end


//D8000024 add start
//D9000001        CORBA::Long  tmpFPCAdoptFlag = atol( getenv(SP_FPC_Adaptation_Flag) );
        CORBA::Long  tmpFPCAdoptFlag = atoi( getenv(SP_FPC_Adaptation_Flag) );    //D9000001
        if( 1 == tmpFPCAdoptFlag )
        {
            CORBA::Long casLen = tmpStartCassette.length();
            for( CORBA::Long casCnt=0; casCnt<casLen; casCnt++ )
            {
                CORBA::Long lotLen = tmpStartCassette[casCnt].strLotInCassette.length();
                for( CORBA::Long lotCnt=0; lotCnt<lotLen; lotCnt++ )
                {
                    if( tmpStartCassette[casCnt].strLotInCassette[lotCnt].operationStartFlag == FALSE ) //PSIV00002149
                    {                                                                                   //PSIV00002149
                        PPT_METHODTRACE_V1("", "operationStartFlag == FALSE" );                         //PSIV00002149
                        continue;                                                                       //PSIV00002149
                    }                                                                                   //PSIV00002149
                    PPT_METHODTRACE_V2("", "Check lot's FPC definition.",
                                       tmpStartCassette[casCnt].strLotInCassette[lotCnt].lotID.identifier);
                    objLot_currentFPCInfo_Get_out strLot_currentFPCInfo_Get_out;
                    rc = lot_currentFPCInfo_Get( strLot_currentFPCInfo_Get_out, strObjCommonIn,
                                                 tmpStartCassette[casCnt].strLotInCassette[lotCnt].lotID,
                                                 equipmentID, FALSE, FALSE, FALSE, FALSE );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_currentFPCInfo_Get() != RC_OK", rc);
                        strOpeStartForInternalBufferReqResult.strResult = strLot_currentFPCInfo_Get_out.strResult;
                        return( rc );
                    }

                    CORBA::Long fpcLen = strLot_currentFPCInfo_Get_out.strFPCInfoList.length();
                    if( fpcLen > 0 )
                    {
                        PPT_METHODTRACE_V2("", "This lot is influenced by FPC.", fpcLen);
                        PPT_SET_MSG_RC_KEY( strOpeStartForInternalBufferReqResult,
                                            MSG_FPC_REQUIRE_START_RESERVE, RC_FPC_REQUIRE_START_RESERVE,
                                            tmpStartCassette[casCnt].strLotInCassette[lotCnt].lotID.identifier );
                        return RC_FPC_REQUIRE_START_RESERVE;
                    }
                }
            }
        }
//D8000024 add end
    }
    else
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) != 0");

        /*----------------------------------------------------*/
        /*   Clear Start Reserved Control Job in Equipment    */
        /*----------------------------------------------------*/
        saveControlJobID = controlJobID;
        objectIdentifier nullControlJobID;
        objEquipment_reservedControlJobID_Clear_out strEquipment_reservedControlJobID_Clear_out;
        rc = equipment_reservedControlJobID_Clear( strEquipment_reservedControlJobID_Clear_out, strObjCommonIn,
                                                   equipmentID, controlJobID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "equipment_reservedControlJobID_Clear() rc != RC_OK");
            strOpeStartForInternalBufferReqResult.strResult = strEquipment_reservedControlJobID_Clear_out.strResult;
            return( rc );
        }

        /*----------------------------------------------------*/
        /*   Update Start Reservation Info                    */
        /*                                                    */
        /*   - To update recipe parameters, this process is   */
        /*     required.                                      */
        /*----------------------------------------------------*/
//D9000003 delete start
//        objProcess_startReserveInformation_Set_out   strProcess_startReserveInformation_Set_out;
////D4000015        rc = process_startReserveInformation_Set( strProcess_startReserveInformation_Set_out,
////D4000015                                                  strObjCommonIn,
////D4000015                                                  equipmentID,
////D4000015                                                  portGroupID,
////D4000015                                                  controlJobID,
////D4000015                                                  strStartCassette );
////D4000015 add start
//        rc = process_startReserveInformation_Set( strProcess_startReserveInformation_Set_out,
//                                                  strObjCommonIn,
//                                                  equipmentID,
//                                                  "",
//                                                  controlJobID,
////D51M0000                                                  strStartCassette );
//                                                  tmpStartCassette );               //D51M0000
////D4000015 add end
//        if ( rc != RC_OK )
//       {
//            PPT_METHODTRACE_V1("", "process_startReserveInformation_Set() != RC_OK");
//            strOpeStartForInternalBufferReqResult.strResult = strProcess_startReserveInformation_Set_out.strResult;
//            return( rc );
//        }
//D9000003 delete end
//D9000003 add start
        objProcess_startReserveInformation_Set_out__090 strProcess_startReserveInformation_Set_out__090;
        objProcess_startReserveInformation_Set_in__090 strProcess_startReserveInformation_Set_in__090;
        strProcess_startReserveInformation_Set_in__090.equipmentID = equipmentID;
        strProcess_startReserveInformation_Set_in__090.portGroupID = CIMFWStrDup("");
        strProcess_startReserveInformation_Set_in__090.controlJobID = controlJobID;
        strProcess_startReserveInformation_Set_in__090.strStartCassette = tmpStartCassette;
        strProcess_startReserveInformation_Set_in__090.processJobPauseFlag = processJobPauseFlag;

        rc = process_startReserveInformation_Set__090( strProcess_startReserveInformation_Set_out__090, strObjCommonIn, strProcess_startReserveInformation_Set_in__090);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "process_startReserveInformation_Set__090() rc != RC_OK");
            strOpeStartForInternalBufferReqResult.strResult = strProcess_startReserveInformation_Set_out__090.strResult;
            return( rc );
        }
//D9000003 add end

}

//D8000024 add start
    PPT_METHODTRACE_V1("","Now check whiteFlag.");
    objFPC_startCassette_processCondition_Check_out  strFPC_startCassette_processCondition_Check_out;
    rc = FPC_startCassette_processCondition_Check( strFPC_startCassette_processCondition_Check_out,
                                                   strObjCommonIn,
                                                   equipmentID,
                                                   tmpStartCassette,
                                                   FALSE,     // FPC category check
                                                   TRUE );    // FPC whiteFlag check
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","FPC_startCassette_processCondition_Check() != RC_OK", rc);
        strOpeStartForInternalBufferReqResult.strResult = strFPC_startCassette_processCondition_Check_out.strResult;
        return rc;
    }
//D8000024 add end

    /*------------------------------------------------------*/
    /*                                                      */
    /*     Equipment Related Information Update Procedure   */
    /*                                                      */
    /*------------------------------------------------------*/

    /*------------------------------------------------------*/
    /*   Add StartLot to EqpInfo's ProcessingLot Sequence   */
    /*------------------------------------------------------*/
//D4000015    objEquipment_processingLot_Add_out strEquipment_processingLot_Add_out;
//D4000015    rc = equipment_processingLot_Add( strEquipment_processingLot_Add_out, strObjCommonIn,
//D4000015                                      equipmentID, saveControlJobID, strStartCassette );
//D4000015    if ( rc != RC_OK )
//D4000015    {
//D4000015        PPT_METHODTRACE_V1("", "equipment_processingLot_Add() rc != RC_OK");
//D4000015        strOpeStartForInternalBufferReqResult.strResult = strEquipment_processingLot_Add_out.strResult;
//D4000015        return( rc );
//D4000015    }

//D4000015 add start
    objEquipment_processingLot_AddForInternalBuffer_out strEquipment_processingLot_AddForInternalBuffer_out;
    rc = equipment_processingLot_AddForInternalBuffer( strEquipment_processingLot_AddForInternalBuffer_out, 
                                      strObjCommonIn,
//D51M0000                                      equipmentID, saveControlJobID, strStartCassette );
                                      equipmentID, saveControlJobID, tmpStartCassette );                //D51M0000
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "equipment_processingLot_AddForInternalBuffer() rc != RC_OK");
        strOpeStartForInternalBufferReqResult.strResult = strEquipment_processingLot_AddForInternalBuffer_out.strResult;
        return( rc );
    }
//D4000015 add end

//DSN000081739 Add Start
    if ( 1 == eqpMonitorSwitch )
    {
        PPT_METHODTRACE_V1("", "1 == SP_EQPMONITOR_SWITCH");
        CORBA::Boolean getEqpStateAtStart = TRUE;
        objectIdentifier eqpStateAtStart;
        objectIdentifier chamberID;
        CORBA::Boolean eqpStatusChg = TRUE;
        CORBA::ULong castLen = tmpStartCassette.length();
        for ( i=0; i<castLen; i++ )
        {
            PPT_METHODTRACE_V2("", "loop to castLen", i);
            CORBA::ULong lotLen = tmpStartCassette[i].strLotInCassette.length();
            for ( CORBA::ULong j=0; j<lotLen; j++ )
            {
                PPT_METHODTRACE_V2("", "loop to lotLen", j);
                /*---------------------------*/
                /*   Omit Not-OpeStart Lot   */
                /*---------------------------*/
                if ( FALSE == tmpStartCassette[i].strLotInCassette[j].operationStartFlag )
                {
                    PPT_METHODTRACE_V1("", "tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE, continue");
                    continue;
                }

                if ( 0 != CIMFWStrCmp(tmpStartCassette[i].strLotInCassette[j].lotType, SP_Lot_Type_EquipmentMonitorLot)
                  && 0 != CIMFWStrCmp(tmpStartCassette[i].strLotInCassette[j].lotType, SP_Lot_Type_DummyLot) )
                {
                    PPT_METHODTRACE_V1("", "tmpStartCassette[i].strLotInCassette[j].lotType is not Equipment Monitor and Dummy, continue");
                    continue;
                }

                objLot_eqpMonitorSectionInfo_GetForJob_out strLot_eqpMonitorSectionInfo_GetForJob_out;
                objLot_eqpMonitorSectionInfo_GetForJob_in  strLot_eqpMonitorSectionInfo_GetForJob_in;
                strLot_eqpMonitorSectionInfo_GetForJob_in.lotID  = tmpStartCassette[i].strLotInCassette[j].lotID;
                rc = lot_eqpMonitorSectionInfo_GetForJob( strLot_eqpMonitorSectionInfo_GetForJob_out,
                                                          strObjCommonIn,
                                                          strLot_eqpMonitorSectionInfo_GetForJob_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_eqpMonitorSectionInfo_GetForJob() != RC_OK", rc);
                    strOpeStartForInternalBufferReqResult.strResult = strLot_eqpMonitorSectionInfo_GetForJob_out.strResult;
                    return rc;
                }

                if ( 0 < CIMFWStrLen( strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier ) )
                {
                    PPT_METHODTRACE_V1("", "0 < CIMFWStrLen( strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier )");
                    if( 0 == CIMFWStrCmp(strLot_eqpMonitorSectionInfo_GetForJob_out.operationLabel, SP_EqpMonitor_OpeLabel_Monitor) )
                    {
                        PPT_METHODTRACE_V1("", "strLot_eqpMonitorSectionInfo_GetForJob_out.operationLabel is Monitor");
                        //Get EqpMonitorJob Information
                        objEqpMonitorJob_info_Get_out strEqpMonitorJob_info_Get_out;
                        objEqpMonitorJob_info_Get_in  strEqpMonitorJob_info_Get_in;
                        strEqpMonitorJob_info_Get_in.eqpMonitorID    = strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID;
                        strEqpMonitorJob_info_Get_in.eqpMonitorJobID = strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID;
                        rc = eqpMonitorJob_info_Get( strEqpMonitorJob_info_Get_out,
                                                     strObjCommonIn,
                                                     strEqpMonitorJob_info_Get_in );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "eqpMonitorJob_info_Get() != RC_OK", rc);
                            strOpeStartForInternalBufferReqResult.strResult = strEqpMonitorJob_info_Get_out.strResult;
                            return rc;
                        }

                        CORBA::Boolean eqpMonitorJobStatusChg = TRUE;
                        if ( 0 != CIMFWStrCmp(strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].monitorJobStatus, SP_EqpMonitorJob_Status_Ready) )
                        {
                            PPT_METHODTRACE_V1("", "strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].monitorJobStatus is not Ready");
                            eqpStatusChg = FALSE;
                            eqpMonitorJobStatusChg = FALSE;
                        }

                        if ( TRUE == eqpStatusChg )
                        {
                            PPT_METHODTRACE_V1("", "TRUE == eqpStatusChg");
                            if ( 0 < CIMFWStrLen( strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID.identifier ) && TRUE == getEqpStateAtStart )
                            {
                                PPT_METHODTRACE_V1("", "0 < CIMFWStrLen(strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID.identifier) && TRUE==getEqpStateAtStart");
                                //Get EqpMonitor information
                                objEqpMonitor_info_Get_out strEqpMonitor_info_Get_out;
                                objEqpMonitor_info_Get_in  strEqpMonitor_info_Get_in;
                                strEqpMonitor_info_Get_in.eqpMonitorID = strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID;
                                rc = eqpMonitor_info_Get( strEqpMonitor_info_Get_out,
                                                          strObjCommonIn,
                                                          strEqpMonitor_info_Get_in );
                                if ( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V2("", "eqpMonitor_info_Get() != RC_OK", rc);
                                    strOpeStartForInternalBufferReqResult.strResult = strEqpMonitor_info_Get_out.strResult;
                                    return rc;
                                }

                                if ( 0 < CIMFWStrLen( strEqpMonitor_info_Get_out.strEqpMonitorDetailInfos[0].eqpStateAtStart.equipmentStatusCode.identifier ) )
                                {
                                    PPT_METHODTRACE_V1("", "0 < CIMFWStrLen(strEqpMonitor_info_Get_out.strEqpMonitorDetailInfos[0].eqpStateAtStart.equipmentStatusCode.identifier)");
                                    eqpStateAtStart = strEqpMonitor_info_Get_out.strEqpMonitorDetailInfos[0].eqpStateAtStart.equipmentStatusCode;
                                    chamberID       = strEqpMonitor_info_Get_out.strEqpMonitorDetailInfos[0].chamberID;
                                    getEqpStateAtStart = FALSE;
                                }
                            }
                        }

                        if ( TRUE == eqpMonitorJobStatusChg )
                        {
                            PPT_METHODTRACE_V1("", "TRUE == eqpMonitorJobStatusChg");
                            //Status of EqpMonitor job is updated to "Executing"
                            pptEqpMonitorJobStatusChangeRptResult strEqpMonitorJobStatusChangeRptResult;
                            pptEqpMonitorJobStatusChangeRptInParm strEqpMonitorJobStatusChangeRptInParm;
                            strEqpMonitorJobStatusChangeRptInParm.equipmentID      = strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].equipmentID;
                            strEqpMonitorJobStatusChangeRptInParm.eqpMonitorID     = strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].eqpMonitorID;
                            strEqpMonitorJobStatusChangeRptInParm.eqpMonitorJobID  = strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].eqpMonitorJobID;
                            strEqpMonitorJobStatusChangeRptInParm.monitorJobStatus = CIMFWStrDup(SP_EqpMonitorJob_Status_Executing);
                            rc = txEqpMonitorJobStatusChangeRpt( strEqpMonitorJobStatusChangeRptResult,
                                                                 strObjCommonIn,
                                                                 strEqpMonitorJobStatusChangeRptInParm,
                                                                 claimMemo );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "txEqpMonitorJobStatusChangeRpt() != RC_OK", rc);
                                strOpeStartForInternalBufferReqResult.strResult = strEqpMonitorJobStatusChangeRptResult.strResult;
                                return rc;
                            }
                        }
                    }

                    //Update information of EqpMonitor job lot
                    objEqpMonitorJob_lot_Update_out strEqpMonitorJob_lot_Update_out;
                    objEqpMonitorJob_lot_Update_in  strEqpMonitorJob_lot_Update_in;
                    strEqpMonitorJob_lot_Update_in.lotID     = tmpStartCassette[i].strLotInCassette[j].lotID;
                    strEqpMonitorJob_lot_Update_in.operation = CIMFWStrDup(SP_EqpMonitorJob_OpeCategory_OpeStart);
                    rc = eqpMonitorJob_lot_Update( strEqpMonitorJob_lot_Update_out,
                                                   strObjCommonIn,
                                                   strEqpMonitorJob_lot_Update_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "eqpMonitorJob_lot_Update() != RC_OK", rc);
                        strOpeStartForInternalBufferReqResult.strResult = strEqpMonitorJob_lot_Update_out.strResult;
                        return rc;
                    }
                }
            }
        }

        if ( 0 < CIMFWStrLen( eqpStateAtStart.identifier ) )
        {
            PPT_METHODTRACE_V1("", "0 < CIMFWStrLen( eqpStateAtStart.identifier )");
            if ( 0 < CIMFWStrLen( chamberID.identifier ) )
            {
                //Update Chamber's Status
                PPT_METHODTRACE_V1("", "call txChamberStatusChangeReq");

                pptEqpChamberStatusSequence strEqpChamberStatus;
                strEqpChamberStatus.length(1);

                strEqpChamberStatus[0].chamberID         = chamberID;
                strEqpChamberStatus[0].chamberStatusCode = eqpStateAtStart;

                //-------------------------------------------------------
                //   Call txChamberStatusChangeReq
                //-------------------------------------------------------
                pptChamberStatusChangeReqResult strChamberStatusChangeReqResult;
                rc = txChamberStatusChangeReq( strChamberStatusChangeReqResult,
                                               strObjCommonIn,
                                               equipmentID,
                                               strEqpChamberStatus,
                                               claimMemo );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "txChamberStatusChangeReq() != RC_OK", rc);
                    strOpeStartForInternalBufferReqResult.strResult = strChamberStatusChangeReqResult.strResult;
                    return rc;
                }
            }
            else
            {
                //Update Eqp's Status
                PPT_METHODTRACE_V1("", "call txEqpStatusChangeReq");

                objectIdentifier statusCode;
                statusCode = eqpStateAtStart;

                //-------------------------------------------------------
                //   Call txEqpStatusChangeReq
                //-------------------------------------------------------
                pptEqpStatusChangeReqResult strEqpStatusChangeReqResult;
                rc = txEqpStatusChangeReq( strEqpStatusChangeReqResult,
                                           strObjCommonIn,
                                           equipmentID,
                                           statusCode,
                                           claimMemo );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "txEqpStatusChangeReq() != RC_OK", rc);
                    strOpeStartForInternalBufferReqResult.strResult = strEqpStatusChangeReqResult.strResult;
                    return rc;
                }
            }
        }
    }
//DSN000081739 Add End

    /*---------------------------------------------*/
    /*   Maintain Eqp's Status for OFF-LINE Mode   */
    /*---------------------------------------------*/
    if ( CIMFWStrCmp( strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode, SP_Eqp_OnlineMode_Offline ) == 0 )
    {
        PPT_METHODTRACE_V1("", "onlineMode == SP_Eqp_OnlineMode_Offline");

        /*-----------------------------------------------*/
        /*   Change Equipment's Status to 'PRODUCTIVE'   */
        /*-----------------------------------------------*/

        /*===== get StateChageableFlag ===*/
        objEquipment_currentState_CheckToManufacturing_out strEquipment_currentState_CheckToManufacturing_out;
        strEquipment_currentState_CheckToManufacturing_out.ManufacturingStateChangeableFlag = FALSE;
        rc = equipment_currentState_CheckToManufacturing( strEquipment_currentState_CheckToManufacturing_out, strObjCommonIn,
                                                          equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "equipment_currentState_GetManufacturing() rc != RC_OK");
            strOpeStartForInternalBufferReqResult.strResult = strEquipment_currentState_CheckToManufacturing_out.strResult;
            return( rc );
        }

        if ( strEquipment_currentState_CheckToManufacturing_out.ManufacturingStateChangeableFlag == TRUE )
        {
            PPT_METHODTRACE_V1("", "ManufacturingStateChangeableFlag == TRUE");

            /*===== get Defaclt Status Code for Productive / Standby ===*/
            objEquipment_recoverState_GetManufacturing_out strEquipment_recoverState_GetManufacturing_out;
            rc = equipment_recoverState_GetManufacturing( strEquipment_recoverState_GetManufacturing_out, strObjCommonIn,
                                                          equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "equipment_recoverState_GetManufacturing() rc != RC_OK");
                strOpeStartForInternalBufferReqResult.strResult = strEquipment_recoverState_GetManufacturing_out.strResult;
                return( rc );
            }

            /*---------------------------------*/
            /*   Call txEqpStatusChangeReq()   */
            /*---------------------------------*/
            pptEqpStatusChangeReqResult strEqpStatusChangeReqResult;
            rc = txEqpStatusChangeReq( strEqpStatusChangeReqResult, strObjCommonIn,
                                       equipmentID, 
                                       strEquipment_recoverState_GetManufacturing_out.equipmentStatusCode, 
                                       claimMemo );
            if ( rc != RC_OK && rc != RC_CURRSTATE_SAME )
            {
                PPT_METHODTRACE_V1("", "txEqpStatusChangeReq() rc != RC_OK");
                strOpeStartForInternalBufferReqResult.strResult = strEqpStatusChangeReqResult.strResult;
                return( rc );
            }
        }
    }

    /*------------------------------------------*/
    /*   Update Equipment's Usage Information   */
    /*------------------------------------------*/
    objEquipment_usageCount_Increment_out strEquipment_usageCount_Increment_out;
    rc = equipment_usageCount_Increment( strEquipment_usageCount_Increment_out, strObjCommonIn,
//D51M0000                                         equipmentID, strStartCassette );
                                         equipmentID, tmpStartCassette );               //D51M0000
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "equipment_usageCount_Increment() rc != RC_OK");
        strOpeStartForInternalBufferReqResult.strResult = strEquipment_usageCount_Increment_out.strResult;
        return( rc );
    }

    /*------------------------------------------------------*/
    /*                                                      */
    /*     FlowBatch Related Information Update Procedure   */
    /*                                                      */
    /*------------------------------------------------------*/

//D9000079    /*------------------------------------------*/
//D9000079    /*   Update FlowBatch Information           */
//D9000079    /*                                          */
//D9000079    /*   If equipment has reservedFlowBatchID,  */
//D9000079    /*   it is cleared. And Flowbatch's         */
//D9000079    /*   reservedEquipmentID is cleared, too.   */
//D9000079    /*------------------------------------------*/
//D9000079    objFlowBatch_Information_UpdateByOpeStart_out strFlowBatch_Information_UpdateByOpeStart_out;
//D9000079    rc = flowBatch_Information_UpdateByOpeStart( strFlowBatch_Information_UpdateByOpeStart_out, strObjCommonIn,
//D9000079                                                 equipmentID );
//D9000079    if ( rc != RC_OK )
//D9000079    {
//D9000079        PPT_METHODTRACE_V1("", "flowBatch_information_UpdateByOpeStart() rc != RC_OK");
//D9000079        strOpeStartForInternalBufferReqResult.strResult = strFlowBatch_Information_UpdateByOpeStart_out.strResult;
//D9000079        return( rc );
//D9000079    }
//D9000079 add start
    //-----------------------------------------------------------
    //  Update Flow Batch Information
    //
    //  envValue SP_FLOWBATCH_CLEARED_BY_OPERSTART is "1"
    //     Equipment's researvedFlowBatchID is cleared.
    //     FlowBatch's reservedEquipmentID is also cleared.
    //  envValue SP_FLOWBATCH_CLEARED_BY_OPERSTART is "0".
    //     Nothing is cleared.
    //-----------------------------------------------------------
    if( 0 != CIMFWStrLen(strEquipment_lot_CheckFlowBatchConditionForOpeStart_out.flowBatchID.identifier) )
    {
        objFlowBatch_Information_UpdateByOpeStart_out__090 strFlowBatch_Information_UpdateByOpeStart_out;
        objFlowBatch_Information_UpdateByOpeStart_in__090  strFlowBatch_Information_UpdateByOpeStart_in;
        strFlowBatch_Information_UpdateByOpeStart_in.equipmentID = equipmentID;
        strFlowBatch_Information_UpdateByOpeStart_in.flowBatchID = strEquipment_lot_CheckFlowBatchConditionForOpeStart_out.flowBatchID;
        rc = flowBatch_Information_UpdateByOpeStart__090( strFlowBatch_Information_UpdateByOpeStart_out,
                                                     strObjCommonIn,
                                                     strFlowBatch_Information_UpdateByOpeStart_in);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "flowBatch_information_UpdateByOpeStart() rc != RC_OK"); 
            strOpeStartForInternalBufferReqResult.strResult = strFlowBatch_Information_UpdateByOpeStart_out.strResult;
            return( rc );
        }
    }
//D9000079 add end
    /*-----------------------------------------------------*/
    /*                                                     */
    /*     Cassette Related Information Update Procedure   */
    /*                                                     */
    /*-----------------------------------------------------*/
//D51M0000    nILen = strStartCassette.length();
    nILen = tmpStartCassette.length();              //D51M0000
    PPT_METHODTRACE_V2("", "nILen", nILen);
    for ( i=0 ; i<nILen; i++ )
    {
        /*-----------------------------------------------*/
        /*   Change Cassette's Dispatch State to FALSE   */
        /*-----------------------------------------------*/
        PPT_METHODTRACE_V2("", "Change Cassette's Dispatch State to FALSE", i);

        objCassette_dispatchState_Change_out strCassette_dispatchState_Change_out;
        rc = cassette_dispatchState_Change( strCassette_dispatchState_Change_out, strObjCommonIn,
//D51M0000                                            strStartCassette[i].cassetteID, FALSE );
                                            tmpStartCassette[i].cassetteID, FALSE );                //D51M0000
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cassette_dispatchState_Change() rc != RC_OK", i);
            strOpeStartForInternalBufferReqResult.strResult = strCassette_dispatchState_Change_out.strResult;
            return( rc );
        }

        /*------------------------------------------*/
        /*   Update Casssette's Usage Information   */
        /*------------------------------------------*/
        objCassette_usageCount_Increment_out strCassette_usageCount_Increment_out;
        rc = cassette_usageCount_Increment( strCassette_usageCount_Increment_out, strObjCommonIn,
//D51M0000                                            strStartCassette[i].cassetteID );
                                            tmpStartCassette[i].cassetteID );                       //D51M0000
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cassette_usageCount_Increment() rc != RC_OK", i);
            strOpeStartForInternalBufferReqResult.strResult = strCassette_usageCount_Increment_out.strResult;
            return( rc );
        }
    }

    /*------------------------------------------------*/
    /*                                                */
    /*     Lot Related Information Update Procedure   */
    /*                                                */
    /*------------------------------------------------*/

    /*----------------------------------------------------------------*/
    /*   Make Monitor Relation for ProcessMonitorLot and ProcessLot   */
    /*----------------------------------------------------------------*/

    /*-----------------------------------*/
    /*   Get LotID's for Each Purpose    */
    /*-----------------------------------*/
    objOperationStartLot_lotCount_GetByLoadPurposeType_out strOperationStartLot_lotCount_GetByLoadPurposeType_out;
    rc = operationStartLot_lotCount_GetByLoadPurposeType( strOperationStartLot_lotCount_GetByLoadPurposeType_out, strObjCommonIn,
//D51M0000                                                          strStartCassette );
                                                          tmpStartCassette );               //D51M0000
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "operationStartLot_lotCount_GetByLoadPurposeType() rc != RC_OK");
        strOpeStartForInternalBufferReqResult.strResult = strOperationStartLot_lotCount_GetByLoadPurposeType_out.strResult;
        return( rc );
    }

    if ( CIMFWStrLen(strOperationStartLot_lotCount_GetByLoadPurposeType_out.processMonitorLotID.identifier) != 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(strOperationStartLot_lotCount_GetByLoadPurposeType_out.processMonitorLotID.identifier) != 0");

        /*------------------------*/
        /*    Prepare Structure   */
        /*------------------------*/
        CORBA::Long plCnt = strOperationStartLot_lotCount_GetByLoadPurposeType_out.processLotIDs.length();

        pptMonRelatedProdLotsSequence strMonRelatedProdLots(plCnt);
        strMonRelatedProdLots.length(plCnt);

        CORBA::Long i = 0;
        PPT_METHODTRACE_V2("", "plCnt", plCnt);
        for ( i=0 ; i<plCnt ; i++ )
        {
            strMonRelatedProdLots[i].productLotID = strOperationStartLot_lotCount_GetByLoadPurposeType_out.processLotIDs[i];
        }

        /*----------------------------------------------*/
        /*    Call txMakeRelationMonitorProdLotsReq()   */
        /*----------------------------------------------*/
        pptMakeRelationMonitorProdLotsReqResult strMakeRelationMonitorProdLotsReqResult;
        rc = txMakeRelationMonitorProdLotsReq( strMakeRelationMonitorProdLotsReqResult, strObjCommonIn,
                                               strOperationStartLot_lotCount_GetByLoadPurposeType_out.processMonitorLotID,
                                               strMonRelatedProdLots );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "txMakeRelationMonitorProdLotsReq() rc != RC_OK");
            strOpeStartForInternalBufferReqResult.strResult = strMakeRelationMonitorProdLotsReqResult.strResult;
            return( rc );
        }
    }

    /*--------------------------------------------*/
    /*   Change Lot Process State to Processing   */
    /*--------------------------------------------*/
    objLot_processState_MakeProcessing_out strLot_processState_MakeProcessing_out;
    rc = lot_processState_MakeProcessing( strLot_processState_MakeProcessing_out, strObjCommonIn,
//D51M0000                                          strStartCassette );
                                          tmpStartCassette );               //D51M0000
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_processState_MakeProcessing() rc != RC_OK");
        strOpeStartForInternalBufferReqResult.strResult = strLot_processState_MakeProcessing_out.strResult;
        return( rc );
    }

    /*----------------------------*/
    /*   Stop Q-Time Management   */
    /*----------------------------*/
    objQtime_StopByOpeStart_out strQtime_StopByOpeStart_out;
    rc = qtime_StopByOpeStart( strQtime_StopByOpeStart_out, strObjCommonIn,
//D51M0000                               strStartCassette );
                               tmpStartCassette );                          //D51M0000
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "qtime_StopByOpeStart() rc != RC_OK");
        strOpeStartForInternalBufferReqResult.strResult = strQtime_StopByOpeStart_out.strResult;
        return( rc );
    }

    /*------------------------------------------------------------*/
    /*                                                            */
    /*   Reticle / Fixture Related Information Update Procedure   */
    /*                                                            */
    /*------------------------------------------------------------*/
    if ( saveRC == RC_EQP_PROCDRBL_RTCL_REQD ||
         saveRC == RC_EQP_PROCDRBL_FIXT_REQD )
    {
        PPT_METHODTRACE_V1("", "saveRC == RC_EQP_PROCDRBL_RTCL_REQD || saveRC == RC_EQP_PROCDRBL_FIXT_REQD");

        CORBA::Long i = 0;
//D51M0000        CORBA::Long nILen = strStartCassette.length();
        CORBA::Long nILen = tmpStartCassette.length();                      //D51M0000
        PPT_METHODTRACE_V2("", "nILen", nILen);
        for ( i=0; i<nILen; i++ )
        {

//D51M0000            if (CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette ) == 0)
            if (CIMFWStrCmp(tmpStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette ) == 0)               //D51M0000
            {
                continue;
            }

            CORBA::Long j = 0;
//D51M0000            CORBA::Long nJLen = strStartCassette[i].strLotInCassette.length();
            CORBA::Long nJLen = tmpStartCassette[i].strLotInCassette.length();                                          //D51M0000
            PPT_METHODTRACE_V3("", "nJLen", nJLen, i);
            for ( j=0; j<nJLen; j++ )
            {

//D51M0000                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                if ( tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )                              //D51M0000
                {
                    continue;
                }

                if ( saveRC == RC_EQP_PROCDRBL_RTCL_REQD )
                {
                    PPT_METHODTRACE_V3("", "saveRC == RC_EQP_PROCDRBL_RTCL_REQD", i, j);

                    /*--------------------------------------*/
                    /*   Update Reticle Usage Information   */
                    /*--------------------------------------*/
                    CORBA::Long k = 0;
                    //INN-R170003
                    CORBA::Long lngWfrCnt = tmpStartCassette[i].strLotInCassette[j].strLotWafer.length();
                    //D51M0000                    CORBA::Long nKLen = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle.length();
                    CORBA::Long nKLen = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle.length();//D51M0000
                    PPT_METHODTRACE_V4("", "nKLen", nKLen, i, j);
                    for (k = 0; k<nKLen; k++)
                    {
                        //INN-R170003 Start
                        //objReticle_UsageCount_Increment_out strReticle_UsageCount_Increment_out;
                        //rc = reticle_UsageCount_Increment(strReticle_UsageCount_Increment_out, strObjCommonIn,
                        //    //D51M0000                                                           strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID );
                        //    tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID);           //D51M0000
                        //if (rc != RC_OK)
                        //{
                        //    PPT_METHODTRACE_V1("", "reticle_UsageCount_Increment() rc != RC_OK");
                        //    strOpeStartForInternalBufferReqResult.strResult = strReticle_UsageCount_Increment_out.strResult;
                        //    return(rc);
                        //}

                        csObjReticle_WaferCount_Increment_out      strReticle_WaferCount_Increment_out;
                        csObjReticle_WaferCount_Increment_in       strReticle_WaferCount_Increment_in;
                        strReticle_WaferCount_Increment_in.waferCount = lngWfrCnt;
                        strReticle_WaferCount_Increment_in.reticleID = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID;
                        PPT_METHODTRACE_V2("", "cs_txOpeStartForInternalBufferReqOR start cs_reticle_WaferCount_Increment----------------->",strReticle_WaferCount_Increment_in.reticleID.identifier);
                        rc = cs_reticle_WaferCount_Increment(strReticle_WaferCount_Increment_out, strObjCommonIn, strReticle_WaferCount_Increment_in);
                        if (rc != RC_OK)
                        {
                            PPT_METHODTRACE_V1("", "cs_reticle_WaferCount_Increment() != RC_OK ");
                            strOpeStartForInternalBufferReqResult.strResult = strReticle_WaferCount_Increment_out.strResult;
                            return rc;
                        }                        
                        //INN-R170003 End

                    }
                }
                else
                {
                    PPT_METHODTRACE_V3("", "saveRC != RC_EQP_PROCDRBL_RTCL_REQD", i, j);

                    /*--------------------------------------*/
                    /*   Update Fixture Usage Information   */
                    /*--------------------------------------*/
                    CORBA::Long k = 0;
//D51M0000                    CORBA::Long nKLen = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture.length();
                    CORBA::Long nKLen = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture.length();            //D51M0000
                    PPT_METHODTRACE_V4("", "nKLen", nKLen, i, j);
                    for ( k=0; k<nKLen; k++ )
                    {
                        objFixture_UsageCount_Increment_out strFixture_UsageCount_Increment_out;
                        rc = fixture_UsageCount_Increment( strFixture_UsageCount_Increment_out, strObjCommonIn,
//D51M0000                                                           strStartCassette[i].strLotInCassette[j].lotID,
                                                           tmpStartCassette[i].strLotInCassette[j].lotID,                           //D51M0000
//D51M0000                                                           strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture[k].fixtureID );
                                                           tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture[k].fixtureID );   //D51M0000
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "fixture_UsageCount_Increment() rc != RC_OK");
                            strOpeStartForInternalBufferReqResult.strResult = strFixture_UsageCount_Increment_out.strResult;
                            return( rc );
                        }
                    }
                }
            }
        }
    }

    /*---------------------------------*/
    /*                                 */
    /*    CP Test Function Procedure   */
    /*                                 */
    /*---------------------------------*/
//D51M0000    nILen = strStartCassette.length();
    nILen = tmpStartCassette.length();              //D51M0000
    PPT_METHODTRACE_V2("", "nILen", nILen);
    for ( i=0; i<nILen; i++ )
    {

        /*-------------------------*/
        /*   Omit Empty Cassette   */
        /*-------------------------*/
//D51M0000        if (CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
        if (CIMFWStrCmp(tmpStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)        //D51M0000
        {
            continue;
        }

        CORBA::Long j = 0;
//D51M0000        CORBA::Long nJLen = strStartCassette[i].strLotInCassette.length();
        CORBA::Long nJLen = tmpStartCassette[i].strLotInCassette.length();                                  //D51M0000
        PPT_METHODTRACE_V3("", "nJLen", nJLen, i);
        for ( j=0; j<nJLen; j++ )
        {

            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
///D51M0000            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            if ( tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )                      //D51M0000
            {
                continue;
            }

            /*-----------------------------------------*/
            /*   Check Test Type of Current Process    */
            /*-----------------------------------------*/
            objLot_testTypeID_Get_out strLot_testTypeID_Get_out;
            rc = lot_testTypeID_Get( strLot_testTypeID_Get_out, strObjCommonIn,
//D51M0000                                     strStartCassette[i].strLotInCassette[j].lotID );
                                     tmpStartCassette[i].strLotInCassette[j].lotID );                       //D51M0000
            if ( rc != RC_OK && rc != RC_NOT_FOUND_TESTTYPE )
            {
                PPT_METHODTRACE_V1("", "lot_testTypeID_Get() rc != RC_OK");
                strOpeStartForInternalBufferReqResult.strResult = strLot_testTypeID_Get_out.strResult;
                return( rc );
            }

            if (CIMFWStrLen(strLot_testTypeID_Get_out.testTypeID.identifier) != 0)
            {
                PPT_METHODTRACE_V3("", "CIMFWStrLen(strLot_testTypeID_Get_out.testTypeID.identifier) != 0", i, j);

                /*------------------------------------------*/
                /*   Update binReportCount of Bin Summary   */
                /*------------------------------------------*/
                objBinSummary_binRptCount_SetDR_out strBinSummary_binRptCount_SetDR_out;
                rc = binSummary_binRptCount_SetDR( strBinSummary_binRptCount_SetDR_out, strObjCommonIn,
//D51M0000                                                   strStartCassette[i].strLotInCassette[j].lotID,
                                                   tmpStartCassette[i].strLotInCassette[j].lotID,           //D51M0000
                                                   strLot_testTypeID_Get_out.testTypeID.identifier,
                                                   "1" );
                if ( rc != RC_OK && rc != RC_NOT_FOUND_BINSUM )
                {
                    PPT_METHODTRACE_V1("", "binSummary_binRptCount_SetDR() rc != RC_OK");
                    strOpeStartForInternalBufferReqResult.strResult = strBinSummary_binRptCount_SetDR_out.strResult;
                    return( rc );
                }
            }
        }
    }

    /*--------------------------*/
    /*                          */
    /*   Event Make Procedure   */
    /*                          */
    /*--------------------------*/
//D51M0000    nILen = strStartCassette.length();
    nILen = tmpStartCassette.length();              //D51M0000
    PPT_METHODTRACE_V2("", "nILen", nILen);
    for ( i=0; i<nILen; i++ )
    {

        /*-------------------------*/
        /*   Omit Empty Cassette   */
        /*-------------------------*/
//D51M0000        if (CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
        if (CIMFWStrCmp(tmpStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)            //D51M0000
        {
            continue;
        }

        CORBA::Long j = 0;
//D51M0000        CORBA::Long nJLen = strStartCassette[i].strLotInCassette.length();
        CORBA::Long nJLen = tmpStartCassette[i].strLotInCassette.length();                                      //D51M0000
        PPT_METHODTRACE_V3("", "nJLen", nJLen, i);
        for ( j=0; j<nJLen; j++ )
        {
            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            PPT_METHODTRACE_V3("", "Omit Not-OpeStart Lot", i, j);

//D51M0000            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            if ( tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )                          //D51M00000
            {
                continue;
            }

            /*--------------------------------------------------------------*/
            /*   Make OperationMoveEvent for Operation History - OpeStart   */
            /*--------------------------------------------------------------*/
            objLotOperationMoveEvent_MakeOpeStart_out strLotOperationMoveEvent_MakeOpeStart_out;
            rc = lotOperationMoveEvent_MakeOpeStart( strLotOperationMoveEvent_MakeOpeStart_out, strObjCommonIn,
//D4000015 0.02                                      "TXTRC002",
                                                     "TXTRC054", //D4000015 0.02
                                                     equipmentID,
                                                     strPortResource_currentOperationMode_Get_out.strOperationMode.operationMode.identifier,
                                                     saveControlJobID,
//D51M0000                                                     strStartCassette[i].cassetteID,
                                                     tmpStartCassette[i].cassetteID,                            //D51M0000
//D51M0000                                                     strStartCassette[i].strLotInCassette[j],
                                                     tmpStartCassette[i].strLotInCassette[j],                   //D51M0000
                                                     claimMemo );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lotOperationMoveEvent_MakeOpeStart() rc != RC_OK");
                strOpeStartForInternalBufferReqResult.strResult = strLotOperationMoveEvent_MakeOpeStart_out.strResult;
                return( rc );
            }
        }
    }

//D5100232 start
    /*------------------------------------------------------------------------*/
    /*                                                                        */
    /*   Send OpeComp Report to DCS Procedure                                 */
    /*                                                                        */
    /*------------------------------------------------------------------------*/
    CORBA::Boolean bDCSAvailable = FALSE;
    CORBA::String_var DCSAvailable = CIMFWStrDup(getenv(SP_DCS_Available));
    PPT_METHODTRACE_V2("", "DCSAvailable", DCSAvailable);
    if (CIMFWStrCmp(DCSAvailable, "1") == 0 )
    {
        PPT_METHODTRACE_V1("", "DCS Interface Available");
        bDCSAvailable = TRUE;
    }

//DSN000102497 add start
    CORBA::Long DCSReport = atoi( getenv(SP_DCS_REPORT) );
    PPT_METHODTRACE_V2("","DCSReport", DCSReport);
//DSN000102497 add end

    if ( 0 != CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode, SP_Eqp_OnlineMode_Offline)
      && TRUE == bDCSAvailable && 0 == DCSReport ) //DSN000102497
//DSN000102497      && TRUE == bDCSAvailable )
    {
        PPT_METHODTRACE_V1("", "Send OpeComp Report to DCS");

        CORBA::String_var IgnoreErr = CIMFWStrDup(getenv(SP_DCS_Ignore_OpeStart_Result));
        PPT_METHODTRACE_V2("", "SP_DCS_IGNORE_OPESTART_RESULT", IgnoreErr);

        DCSControlJobInfo controlJobInfo;
        controlJobInfo.equipmentID = equipmentID;
        controlJobInfo.portGroupID = "";
        controlJobInfo.controlJobID = saveControlJobID;
//D51M0000        controlJobInfo.strStartCassette = strStartCassette;
        controlJobInfo.strStartCassette = tmpStartCassette;             //D51M0000

        objDCSMgr_SendOperationStartRpt_out strDCSMgr_SendOperationStartRpt_out;
        rc = DCSMgr_SendOperationStartRpt( strDCSMgr_SendOperationStartRpt_out, strObjCommonIn, controlJobInfo );

        if ( rc != RC_OK && 0 != CIMFWStrCmp(IgnoreErr, "1") )
        {
            PPT_METHODTRACE_V2("", "##### DCSMgr_SendOperationStartRpt() != RC_OK", rc);
            strOpeStartForInternalBufferReqResult.strResult = strDCSMgr_SendOperationStartRpt_out.strResult;
            return( rc );
        }
//D7000228 add start
        else if ( rc == RC_OK )
        {
            //Set CJ to DCSIFControlStatus
            PPT_METHODTRACE_V1("","DCS interface is successful.");
            CORBA::String_var tmpStringForDCS = DCSIFControlStatus;
            DCSIFControlStatus                = CIMFWStrDup(controlJobInfo.controlJobID.identifier);
        }
//D7000228 add end
    }
//D5100232 end

    /*------------------------------------------------------------------------*/
    /*                                                                        */
    /*   Send OpeStart Request to TCS Procedure                               */
    /*                                                                        */
    /*   - If specified portGroup's startMode is Auto, OpeStartReq itself is  */
    /*     come from TCS, so OpeStartReq sending procedure is required for    */
    /*     startMode=Manu case only.                                          */
    /*                                                                        */
    /*------------------------------------------------------------------------*/
    if (CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.operationStartMode, SP_Eqp_StartMode_Manual) == 0)
    {
        PPT_METHODTRACE_V1("", "operationStartMode == SP_Eqp_StartMode_Manual");

        /*--------------------------*/
        /*    Send Request to TCS   */
        /*--------------------------*/
//D4000015 0.01        objTCSMgr_SendOpeStartReq_out strTCSMgr_SendOpeStartReq_out;
//D4000015 0.01//D4000015        rc = TCSMgr_SendOpeStartReq( strTCSMgr_SendOpeStartReq_out, strObjCommonIn,
//D4000015 0.01//D4000015                                     strObjCommonIn.strUser,
//D4000015 0.01//D4000015                                     equipmentID,
//D4000015 0.01//D4000015                                     portGroupID,
//D4000015 0.01//D4000015                                     saveControlJobID,
//D4000015 0.01//D4000015                                     strStartCassette,
//D4000015 0.01//D4000015                                     claimMemo );
//D4000015 0.01//D4000015 add start
//D4000015 0.01        rc = TCSMgr_SendOpeStartReq( strTCSMgr_SendOpeStartReq_out, strObjCommonIn,
//D4000015 0.01                                     strObjCommonIn.strUser,
//D4000015 0.01                                     equipmentID,
//D4000015 0.01                                     "",
//D4000015 0.01                                     saveControlJobID,
//D4000015 0.01                                     strStartCassette,
//D4000015 0.01                                     claimMemo );
//D4000015 0.01//D4000015 add end
//D4000015 0.01        if ( rc != RC_OK )
//D4000015 0.01        {
//D4000015 0.01            PPT_METHODTRACE_V1("", "TCSMgr_SendOpeStartReq() rc != RC_OK");
//D4000015 0.01            strOpeStartForInternalBufferReqResult.strResult = strTCSMgr_SendOpeStartReq_out.strResult;
//D4000015 0.01            return( rc );
//D4000015 0.01        }

//D4000015 0.01 add start
//D4000060        objTCSMgr_SendOpeStartForInternalBufferReq_out strTCSMgr_SendOpeStartForInternalBufferReq_out;
//D4000060        rc = TCSMgr_SendOpeStartForInternalBufferReq( strTCSMgr_SendOpeStartForInternalBufferReq_out, strObjCommonIn,
//D4000060                                                      strObjCommonIn.strUser,
//D4000060                                                      equipmentID,
//D4000060                                                      saveControlJobID,
//D4000060                                                      strStartCassette,
//D4000060                                                      claimMemo );
//D4000060        if ( rc != RC_OK )
//D4000060        {
//D4000060            PPT_METHODTRACE_V1("", "TCSMgr_SendOpeStartForInternalBufferReq() rc != RC_OK");
//D4000060            strOpeStartForInternalBufferReqResult.strResult = strTCSMgr_SendOpeStartForInternalBufferReq_out.strResult;
//D4000060            return( rc );
//D4000060        }
//D4000060 add start
        CORBA::String_var tmpSleepTimeValue = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
        CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));
        CORBA::Long sleepTimeValue;
        CORBA::Long retryCountValue;
   
        if (CIMFWStrLen(tmpSleepTimeValue) == 0)
        {
            sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
        }
        else
        {
//D9000001            sleepTimeValue = atol(tmpSleepTimeValue) ;
            sleepTimeValue = atoi(tmpSleepTimeValue) ;    //D9000001
        }
   
        if (CIMFWStrLen(tmpRetryCountValue) == 0)
        {
            retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
        }
        else
        {
//D9000001            retryCountValue = atol(tmpRetryCountValue);
            retryCountValue = atoi(tmpRetryCountValue);    //D9000001
        }
   
        PPT_METHODTRACE_V2("","env value of SP_BIND_SLEEP_TIME_TCS  = ",sleepTimeValue);
        PPT_METHODTRACE_V2("","env value of SP_BIND_RETRY_COUNT_TCS = ",retryCountValue);
   
        objTCSMgr_SendOpeStartForInternalBufferReq_out strTCSMgr_SendOpeStartForInternalBufferReq_out;
   
        //'retryCountValue + 1' means first try plus retry count
        for( i = 0 ; i < (retryCountValue + 1) ; i++)
        {
            /*--------------------------*/
            /*    Send Request to TCS   */
            /*--------------------------*/
            rc = TCSMgr_SendOpeStartForInternalBufferReq( strTCSMgr_SendOpeStartForInternalBufferReq_out, strObjCommonIn,
                                                          strObjCommonIn.strUser,
                                                          equipmentID,
                                                          saveControlJobID,
//D51M0000                                                          strStartCassette,
                                                          tmpStartCassette,     //D51M0000
                                                          processJobPauseFlag,  //D5000001
                                                          claimMemo );
            PPT_METHODTRACE_V2("","rc = ",rc);
   
            if(rc == RC_OK)
            {
                PPT_METHODTRACE_V1("","Now TCS subSystem is alive!! Go ahead");
                break;
            }
            else if ( rc == RC_EXT_SERVER_BIND_FAIL ||
                      rc == RC_EXT_SERVER_NIL_OBJ   ||
                      rc == RC_TCS_NO_RESPONSE )
            {
                PPT_METHODTRACE_V2("","TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...",i);
                PPT_METHODTRACE_V2("","now sleeping... ",sleepTimeValue);
                sleep(sleepTimeValue);
                continue;
            }
            else
            {
                PPT_METHODTRACE_V1("", "TCSMgr_SendOpeStartForInternalBufferReq() rc != RC_OK");
                strOpeStartForInternalBufferReqResult.strResult = strTCSMgr_SendOpeStartForInternalBufferReq_out.strResult;
                return( rc );
            }
   
         }
   
         if ( rc != RC_OK )
         {
             PPT_METHODTRACE_V1("", "TCSMgr_SendOpeStartForInternalBufferReq() rc != RC_OK");
             strOpeStartForInternalBufferReqResult.strResult = strTCSMgr_SendOpeStartForInternalBufferReq_out.strResult;
             return( rc );
         }
//D4000060 add end
//D4000015 0.01 add end
    }

//D51M0000 add start
    /*----------------------------------------*/
    /*   call controlJob_status_Change        */
    /*----------------------------------------*/
    PPT_METHODTRACE_V1("", "call controlJob_status_Change");
//D7000006    objControlJob_status_Change_out strControlJob_status_Change_out;
//D7000006    rc = controlJob_status_Change(strControlJob_status_Change_out,
//D7000006                                  strObjCommonIn,
//D7000006                                  saveControlJobID,
//D7000006                                  SP_APC_ControlJobStatus_Executing);
//D7000006    if( rc != RC_OK )
//D7000006    {
//D7000006        PPT_METHODTRACE_V1("", "controlJob_status_Change() != RC_OK");
//D7000006        strOpeStartForInternalBufferReqResult.strResult = strControlJob_status_Change_out.strResult;
//D7000006        return( rc );
//D7000006    }
    //D7000006 Add Start
    pptControlJobManageReqResult strControlJobManageReqResult;
    pptControlJobCreateRequest   dummyControlJobCreateRequest;
    rc = txControlJobManageReq( strControlJobManageReqResult,
                                strObjCommonIn,
                                saveControlJobID,
                                SP_ControlJobAction_Type_queue,
                                dummyControlJobCreateRequest,
                                claimMemo );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "txControlJobManageReq() != RC_OK");
        strOpeStartForInternalBufferReqResult.strResult = strControlJobManageReqResult.strResult;
        return( rc );
    }
    //D7000006 Add End

//strAPCRunTimeCapabilityInqResult is not initialized when sendTxFlag == FALSE.
//Be careful not to use strAPCRunTimeCapabilityInqResult when sendTxFlag == FALSE.
    if( sendTxFlag == TRUE )
    {
        PPT_METHODTRACE_V2("", "sendTxFlag == TRUE", sendTxFlag);
        /*---------------------------------------------------*/
        /*   call APCRuntimeCapability_RegistDR              */
        /*---------------------------------------------------*/
        PPT_METHODTRACE_V1("", "call APCRuntimeCapability_RegistDR");
        objAPCRuntimeCapability_RegistDR_out strAPCRuntimeCapability_RegistDR_out;
        rc = APCRuntimeCapability_RegistDR(  strAPCRuntimeCapability_RegistDR_out,
                                             strObjCommonIn,
                                             saveControlJobID,
                                             strAPCRunTimeCapabilityInqResult.strAPCRunTimeCapabilityResponse);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "APCRuntimeCapability_RegistDR() != RC_OK");
            strOpeStartForInternalBufferReqResult.strResult = strAPCRuntimeCapability_RegistDR_out.strResult;
            return( rc );
        }
    }

    /*-------------------------------------------------*/
    /*   call cassette_APCInformation_GetDR            */
    /*-------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call cassette_APCInformation_GetDR");
    objCassette_APCInformation_GetDR_out strCassette_APCInformation_GetDR_out;
    rc = cassette_APCInformation_GetDR ( strCassette_APCInformation_GetDR_out,
                                      strObjCommonIn,
                                      equipmentID,
                                      tmpStartCassette );
    if ( rc == RC_SYSTEM_ERROR )
    {
        PPT_METHODTRACE_V1("", "cassette_APCInformation_GetDR() == RC_SYSTEM_ERROR");
        strOpeStartForInternalBufferReqResult.strResult = strCassette_APCInformation_GetDR_out.strResult;
        return ( rc ) ;
    }
    else if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cassette_APCInformation_GetDR() != RC_OK");
        strOpeStartForInternalBufferReqResult.strResult = strCassette_APCInformation_GetDR_out.strResult;
    }

    /*--------------------------------------------------*/
    /*   call APCMgr_SendControlJobInformationDR        */
    /*--------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call APCMgr_SendControlJobInformationDR");
    objAPCMgr_SendControlJobInformationDR_out strAPCMgr_SendControlJobInformationDR_out;
    rc = APCMgr_SendControlJobInformationDR(strAPCMgr_SendControlJobInformationDR_out,
                                            strObjCommonIn,
                                            equipmentID,
                                            saveControlJobID,
                                            SP_APC_ControlJobStatus_Executing,
                                            strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList);
//D7000182    if( rc != RC_OK )
    if( rc != RC_OK && rc != RC_OK_NO_IF )    //D7000182
    {
        PPT_METHODTRACE_V1("", "APCMgr_SendControlJobInformationDR != RC_OK");
        strOpeStartForInternalBufferReqResult.strResult = strAPCMgr_SendControlJobInformationDR_out.strResult;
        return( rc );
    }

//D7000182 add start
    if( rc == RC_OK )
    {
        PPT_METHODTRACE_V1("", "APCControlJobInformation was sent normally.");
        if(CIMFWStrLen(controlJobID.identifier) == 0)
        {
            PPT_METHODTRACE_V1("", "OpeStart with no StartReservation");
            CORBA::String_var tmpString = APCIFControlStatus;
            APCIFControlStatus = CIMFWStrDup(SP_APC_ControlJobStatus_Canceled);
        }
        else
        {
            PPT_METHODTRACE_V1("", "OpeStart with StartReservation");
            CORBA::String_var tmpString = APCIFControlStatus;
            APCIFControlStatus = CIMFWStrDup(SP_APC_ControlJobStatus_Created);
        }
    }
//D7000182 add end
//D51M0000 add end

    traceSampledStartCassette( strOpeStartForInternalBufferReqResult.strStartCassette );  //D9000003

    /*------------------------------------------*/
    /*                                          */
    /*   Set ControlJobID to Return Structure   */
    /*                                          */
    /*------------------------------------------*/
    strOpeStartForInternalBufferReqResult.controlJobID = saveControlJobID;

    /*----------------------*/
    /*                      */
    /*   Return to Caller   */
    /*                      */
    /*----------------------*/
    SET_MSG_RC ( strOpeStartForInternalBufferReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txOpeStartForInternalBufferReq");
    return( RC_OK );
}
