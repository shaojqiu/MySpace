#ifndef lint
static char *sccsid =  "@(#) 1.4 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txCassetteListInq__170OR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/22/07 17:30:25 [ 11/22/07 17:30:27 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cs_txCassetteListInq__170OR.cpp
//

#include "cs_pptmgr.hpp"


// Class: CS_PPTManager
//
// Service: txCassetteListInq__170()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 04/10/97                           Started with 0.00
// 2000/09/12 P3000139 O.Sugiyama     add SET_MSG_RC
// 2000/09/18 P3000139 T.Yamano       add SET_MSG_RC
// 2001/07/03 D4000043 Y.Iwasaki      add cassetteStatus, maxRetrieveCount
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// ------------------------------------------------------------------------------
// 2007/06/21 D9000005 K.Kido         Wafer Sorter automation support (for AAS)
// -------------------------------------------------------------------------------
// 2008/06/23 DSIV00000099  M.Murata  SLM(Small Lot Manufacturing) Support.
// 2008-10-10 DSIV00000214  K.Matsuei Add for Multi Fab Transfer Support.
// 2014/12/18 DSN000085770  C.Mo      Durable Control Job Management support.
// 2015/06/25 DSN000096126  C.Mo      Durable Process Flow Control Support.
// 2016/06/29 DSN000101569  C.Mo      Durable Sub Status Control Support.
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/08/28 INN-R170002  Yangxiaojun Overide txCassetteListInq__170
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptCassetteListInqResult__170& strCassetteListInqResult
//     const pptObjCommonIn&          strObjCommonIn
//     const char *                   cassetteCategory
//     CORBA::Boolean                 emptyFlag
//     const objectIdentifier&        stockerID
//     const objectIdentifier&        cassetteID
//     const char *                   cassetteStatus           //D4000043 added
//     const objectIdentifier&        durableSubStatus,                                                                         //DSN000101569
//     const char *                   flowStatus,                                                                               //DSN000101569
//     CORBA::Long                    maxRetrieveCount          //D4000043 added (<=0 means no-limitation)
//     CORBA::Boolean                 sorterJobCreationCheckFlag    //D9000005
//     const char *                   interFabXferState //DSIV00000214
//     const objectIdentifier&        bankID            //DSN000096126
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//DSN000085770 CORBA::Long CS_PPTManager_i::txCassetteListInq__100 (
//DSN000085770         pptCassetteListInqResult__100&   strCassetteListInqResult,
//DSN000101569 CORBA::Long CS_PPTManager_i::txCassetteListInq__160 (                  //DSN000085770
//DSN000101569         pptCassetteListInqResult__160&   strCassetteListInqResult,  //DSN000085770
CORBA::Long CS_PPTManager_i::txCassetteListInq__170 (                                                                              //DSN000101569
        pptCassetteListInqResult__170&   strCassetteListInqResult,                                                              //DSN000101569
        const pptObjCommonIn&            strObjCommonIn,
        const char *                     cassetteCategory,
        CORBA::Boolean                   emptyFlag,
        const objectIdentifier&          stockerID,
        const objectIdentifier&          cassetteID,
        const char *                     cassetteStatus,
        const objectIdentifier&          durableSubStatus,                                                                      //DSN000101569
        const char *                     flowStatus,                                                                            //DSN000101569
        CORBA::Long                      maxRetrieveCount,
        CORBA::Boolean                   sorterJobCreationCheckFlag, //D9000005
        const char*                      interFabXferState,          //DSIV00000214
        const objectIdentifier&          bankID                      //DSN000096126
        CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txCassetteListInq__170")
    CORBA::Long rc = RC_OK ;

//D9000005    objCassette_FillInTxPDQ007DR_out strCassette_FillInTxPDQ007DR_out ;
//D9000005//  rc = cassette_FillInTxPDQ007DR(strCassette_FillInTxPDQ007DR_out,strObjCommonIn,cassetteCategory,emptyFlag,stockerID,cassetteID);
//D9000005    rc = cassette_FillInTxPDQ007DR(strCassette_FillInTxPDQ007DR_out,strObjCommonIn,cassetteCategory,emptyFlag,stockerID,cassetteID,cassetteStatus,maxRetrieveCount); //D4000043
//D9000005    if ( rc != RC_OK )
//D9000005    {
//D9000005        PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteListInq", "rc != RC_OK")
//D9000005        strCassetteListInqResult.strResult = strCassette_FillInTxPDQ007DR_out.strResult ;
//D9000005        return( rc );
//D9000005    }
//D9000005
//D9000005    strCassetteListInqResult = strCassette_FillInTxPDQ007DR_out.strCassetteListInqResult ;
//P3000139    strCassetteListInqResult.strResult = strCassette_FillInTxPDQ007DR_out.strResult ;
//D9000005 add start
//DSIV00000099    objCassette_ListGetDR_in__090  strCassette_ListGetDR_in;
//DSN000096126    objCassette_ListGetDR_in__100  strCassette_ListGetDR_in;        //DSIV00000099
//DSN000101569    objCassette_ListGetDR_in__160  strCassette_ListGetDR_in;  //DSN000096126
    objCassette_ListGetDR_in__170  strCassette_ListGetDR_in;                                                                    //DSN000101569
    strCassette_ListGetDR_in.cassetteCategory           = CIMFWStrDup(cassetteCategory);
    strCassette_ListGetDR_in.emptyFlag                  = emptyFlag;
    strCassette_ListGetDR_in.stockerID                  = stockerID;
    strCassette_ListGetDR_in.cassetteID                 = cassetteID;
    strCassette_ListGetDR_in.cassetteStatus             = CIMFWStrDup(cassetteStatus);
    strCassette_ListGetDR_in.durableSubStatus           = durableSubStatus;                                                     //DSN000101569
    strCassette_ListGetDR_in.flowStatus                 = CIMFWStrDup(flowStatus);                                              //DSN000101569
    strCassette_ListGetDR_in.maxRetrieveCount           = maxRetrieveCount;
    strCassette_ListGetDR_in.sorterJobCreationCheckFlag = sorterJobCreationCheckFlag;
    strCassette_ListGetDR_in.interFabXferState          = interFabXferState; //DSIV00000214
    strCassette_ListGetDR_in.bankID                     = bankID;            //DSN000096126

//DSIV00000099    objCassette_ListGetDR_out__090 strCassette_ListGetDR_out;
//DSIV00000099    rc = cassette_ListGetDR__090( strCassette_ListGetDR_out,

//DSN000085770    objCassette_ListGetDR_out__100 strCassette_ListGetDR_out;   //DSIV00000099
//DSN000085770    rc = cassette_ListGetDR__100( strCassette_ListGetDR_out,    //DSIV00000099
//DSN000101569    objCassette_ListGetDR_out__160 strCassette_ListGetDR_out;   //DSN000085770
//DSN000101569    rc = cassette_ListGetDR__160( strCassette_ListGetDR_out,    //DSN000085770
    objCassette_ListGetDR_out__170 strCassette_ListGetDR_out;                                                                   //DSN000101569
    rc = cassette_ListGetDR__170( strCassette_ListGetDR_out,                                                                    //DSN000101569
                                  strObjCommonIn,
                                  strCassette_ListGetDR_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cassette_ListGetDR__170() rc != RC_OK");
        strCassetteListInqResult.strResult = strCassette_ListGetDR_out.strResult ;
        return( rc );
    }

    strCassetteListInqResult = strCassette_ListGetDR_out.strCassetteListInqResult ;
    strCassetteListInqResult.strResult = strCassette_ListGetDR_out.strResult ;
//D9000005 add end

    SET_MSG_RC(strCassetteListInqResult, MSG_OK, RC_OK); //P3000139

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txCassetteListInq__170")
    return( RC_OK );
}

