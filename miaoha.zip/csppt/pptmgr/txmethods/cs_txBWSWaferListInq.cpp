// (c) Copyright: IBM  Company Ltd, 2017, 2027. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017, 2027. All rights reserved.
//
// SiView
// Name: cs_txBWSWaferListInq.cpp
//
// Modeficaiton History:
// Date       Defect        Name          Description
// ---------- ------------- ------------- ----------------------------------------------
// 2017/10/19 INN-R170017   LiHejing      BWS WaferListInquery
// 2017/10/19 INN-R170017-1 LiHejing      Remove check lSearch = 1 or 0

// Class: PPTServiceManager
//
// Service: cs_txBWSWaferListInq()

// Description: 
//<Method Summary>

//</Method Summary>

// Return:
//     long
//
// Parameter:
//
//     csUserCertifyCheckInqResult&          strUserCertifyCheckInqResult
//     const pptObjCommonIn&                 strObjCommonIn
//     const csUserCertifyCheckInqInParm&    strUserCertifyCheckInqInParm

//<Method Start>
#include "cs_pptmgr.hpp"

CORBA::Long CS_PPTManager_i::cs_txBWSWaferListInq (
    csBWSWaferListInqResult&          strBWSWaferListInqResult,
    const pptObjCommonIn&             strObjCommonIn,
    const csBWSWaferListInqInParm&    strBWSWaferListInqInParm
    CORBAENV_LAST_CPP )
{
    PPT_METHODTRACE_ENTRY("PPTManager_i::cs_txBWSWaferListInq");

    PPT_METHODTRACE_V2("", "in para BWSID = ", strBWSWaferListInqInParm.BWSID.identifier );
    PPT_METHODTRACE_V2("", "in para lSearchType = ", strBWSWaferListInqInParm.lSearchType );
    PPT_METHODTRACE_V2("", "in para zoneID = ", strBWSWaferListInqInParm.zoneID );
    PPT_METHODTRACE_V2("", "in para waferID = ", strBWSWaferListInqInParm.strBWSWaferData.waferID.identifier );
    PPT_METHODTRACE_V2("", "in para waferGradeID = ", strBWSWaferListInqInParm.strBWSWaferData.waferGradeID );
    PPT_METHODTRACE_V2("", "in para lotID = ", strBWSWaferListInqInParm.strBWSWaferData.lotID.identifier );
    PPT_METHODTRACE_V2("", "in para bankID = ", strBWSWaferListInqInParm.strBWSWaferData.bankID.identifier );
    PPT_METHODTRACE_V2("", "in para productID = ", strBWSWaferListInqInParm.strBWSWaferData.productID.identifier );
    PPT_METHODTRACE_V2("", "in para subLotType = ", strBWSWaferListInqInParm.strBWSWaferData.subLotType );

    CORBA::Long rc = RC_OK;
    
    //----------------------------------------------------------------
    //
    //  Check lSearch Condition at least one value not null
    //
    //----------------------------------------------------------------
    
//INN-R170017-1    if (  0 != strBWSWaferListInqInParm.lSearchType && 1 != strBWSWaferListInqInParm.lSearchType )
//INN-R170017-1    {
//INN-R170017-1        PPT_METHODTRACE_V1("", "##### lSearchType is not 1 or 0 ");
//INN-R170017-1        CS_SET_MSG_RC( strBWSWaferListInqResult,
//INN-R170017-1                   CS_MSG_BWS_WAFERLIST_SEARCHKEY_BLANK,
//INN-R170017-1                   CS_RC_BWS_WAFERLIST_SEARCHKEY_BLANK );
//INN-R170017-1    
//INN-R170017-1        return CS_RC_BWS_WAFERLIST_SEARCHKEY_BLANK;
//INN-R170017-1    }
    
    //check lSearchType==1
    if ( 1 == strBWSWaferListInqInParm.lSearchType )
    {
        if ( 0 == CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.waferID.identifier ) &&
            0 == CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.waferGradeID ) &&
            0 == CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.lotID.identifier ) &&
            0 == CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.bankID.identifier ) &&
            0 == CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.subLotType ) &&
            0 == CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.productID.identifier ) )
            {
                 PPT_METHODTRACE_V1("", "##### lSearchType = 1, But All Items Have No Value ");
                 CS_SET_MSG_RC( strBWSWaferListInqResult,
                            CS_MSG_BWS_WAFERLIST_SEARCHKEY_BLANK,
                            CS_RC_BWS_WAFERLIST_SEARCHKEY_BLANK );
    
                 return CS_RC_BWS_WAFERLIST_SEARCHKEY_BLANK;
            }
    }
    
    //check lSearchType==0
    if ( 0 == strBWSWaferListInqInParm.lSearchType )
    {
        if ( 0 == CIMFWStrLen( strBWSWaferListInqInParm.zoneID ) )
            {
                 PPT_METHODTRACE_V1("", "##### lSearchType = 0, zoneID is NULL ");
                 CS_SET_MSG_RC( strBWSWaferListInqResult,
                            CS_MSG_BWS_WAFERLIST_SEARCHKEY_BLANK,
                            CS_RC_BWS_WAFERLIST_SEARCHKEY_BLANK );
    
                 return CS_RC_BWS_WAFERLIST_SEARCHKEY_BLANK;
            }
    }
    
    //----------------------------------------------------------------------
    //
    //  Main Process
    //
    //----------------------------------------------------------------------
    
    // get WaferList Info by calling csObjBWS_WaferList_GetDR
    csObjBWS_WaferList_GetDR_out strObjBWS_WaferList_GetDR_out;
    csObjBWS_WaferList_GetDR_in  strObjBWS_WaferList_GetDR_in;
    
    strObjBWS_WaferList_GetDR_in.BWSID = strBWSWaferListInqInParm.BWSID;
    strObjBWS_WaferList_GetDR_in.lSearchType = strBWSWaferListInqInParm.lSearchType;
    strObjBWS_WaferList_GetDR_in.zoneID = strBWSWaferListInqInParm.zoneID;
    strObjBWS_WaferList_GetDR_in.strBWSWaferData = strBWSWaferListInqInParm.strBWSWaferData;
    rc = cs_BWS_WaferList_GetDR( strObjBWS_WaferList_GetDR_out,
                                    strObjCommonIn,
                                    strObjBWS_WaferList_GetDR_in );
                                    
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "cs_BWS_WaferList_GetDR() rc != RC_OK. ", rc);
        strBWSWaferListInqResult.strResult = strObjBWS_WaferList_GetDR_out.strResult;
        return(rc);
    }
    
    //------------------------------------------------------
    // Set productID and subLotType to strObjBWS_WaferList_GetDR_out
    //------------------------------------------------------
    CORBA::Boolean lotBasicInfoFlag        = TRUE;
    CORBA::Boolean lotControlUseInfoFlag   = FALSE;
    CORBA::Boolean lotFlowBatchInfoFlag    = FALSE;
    CORBA::Boolean lotNoteFlagInfoFlag     = FALSE;
    CORBA::Boolean lotOperationInfoFlag    = FALSE;
    CORBA::Boolean lotOrderInfoFlag        = FALSE;
    CORBA::Boolean lotControlJobInfoFlag   = FALSE;
    CORBA::Boolean lotProductInfoFlag      = TRUE;
    CORBA::Boolean lotRecipeInfoFlag       = FALSE;
    CORBA::Boolean lotLocationInfoFlag     = FALSE;
    CORBA::Boolean lotWipOperationInfoFlag = FALSE;
    CORBA::Boolean lotWaferAttributesFlag  = FALSE;
    CORBA::Boolean lotBackupInfoFlag       = FALSE;
    
    CORBA::Long lnLenBWS = strObjBWS_WaferList_GetDR_out.strBWSDataSeq.length();
    PPT_METHODTRACE_V2( "", "lnLenBWS", lnLenBWS );
    for( CORBA::Long ix=0; ix<lnLenBWS; ix++ )
    {
        PPT_METHODTRACE_V3( "", ix, "BWSID", strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].BWSID.identifier );
        CORBA::Long lnLenZone = strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq.length();
        PPT_METHODTRACE_V3( "", ix, "lnLenZone", lnLenZone );
    
        for( CORBA::Long jx=0; jx<lnLenZone; jx++ ) 
        {
            PPT_METHODTRACE_V4( "", ix, jx, "zoneID", strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].zoneID );                  
            CORBA::Long lnLenWafer = strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq.length();
            PPT_METHODTRACE_V4( "", ix, jx, "lnLenWafer", lnLenWafer );
    
            for( CORBA::Long kx=0; kx<lnLenWafer; kx++ ) 
            {
                PPT_METHODTRACE_V2("", "#### For-Loop of lot_DBInfo_GetDR__160() : ", kx);
    
                objLot_DBInfo_GetDR_out__160 strLot_DBInfo_GetDR_out;
    
                rc = lot_DBInfo_GetDR__160( strLot_DBInfo_GetDR_out,
                                            strObjCommonIn,
                                            strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].lotID,
                                            lotBasicInfoFlag,
                                            lotControlUseInfoFlag,
                                            lotFlowBatchInfoFlag,
                                            lotNoteFlagInfoFlag,
                                            lotOperationInfoFlag,
                                            lotOrderInfoFlag,
                                            lotControlJobInfoFlag,
                                            lotProductInfoFlag,
                                            lotRecipeInfoFlag,
                                            lotLocationInfoFlag,
                                            lotWipOperationInfoFlag,
                                            lotWaferAttributesFlag,
                                            lotBackupInfoFlag );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_DBInfo_GetDR__160() != RC_OK"); 
                    strBWSWaferListInqResult.strResult = strLot_DBInfo_GetDR_out.strResult; 
                    return rc;
                }
                PPT_METHODTRACE_V2("", "####strLot_DBInfo_GetDR_out productID ", strLot_DBInfo_GetDR_out.strLotInfo.strLotProductInfo.productID.identifier);
                PPT_METHODTRACE_V2("", "####strLot_DBInfo_GetDR_out subLotType ", strLot_DBInfo_GetDR_out.strLotInfo.strLotBasicInfo.subLotType);
                strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].productID.identifier = strLot_DBInfo_GetDR_out.strLotInfo.strLotProductInfo.productID.identifier;
                strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].productID.stringifiedObjectReference = CIMFWStrDup("");
                strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].subLotType = strLot_DBInfo_GetDR_out.strLotInfo.strLotBasicInfo.subLotType;
    
                PPT_METHODTRACE_V5( "", ix, jx, kx, "waferID",      strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].waferID.identifier   );
                PPT_METHODTRACE_V5( "", ix, jx, kx, "waferGradeID", strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].waferGradeID         );
                PPT_METHODTRACE_V5( "", ix, jx, kx, "lotID",        strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].lotID.identifier     );
                PPT_METHODTRACE_V5( "", ix, jx, kx, "bankID",       strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].bankID.identifier    );
                PPT_METHODTRACE_V5( "", ix, jx, kx, "productID",    strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].productID.identifier );
                PPT_METHODTRACE_V5( "", ix, jx, kx, "subLotType",   strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].subLotType           );
            }
        }
    }
    
    
    //------------------------------------------------------
    //Filter productID and subLotType and set return value
    //------------------------------------------------------
    if ( ( 1 == strBWSWaferListInqInParm.lSearchType )
         && (( CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.productID.identifier )) >0 
         || ( CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.subLotType )) >0 ))
    {
        PPT_METHODTRACE_V2("", "in para productID ", strBWSWaferListInqInParm.strBWSWaferData.productID.identifier );
        PPT_METHODTRACE_V2("", "in para subLotType ", strBWSWaferListInqInParm.strBWSWaferData.subLotType );
        strBWSWaferListInqResult.strBWSDataSeq.length(lnLenBWS);//set BWSDataSeq max length
        CORBA::Long nResultBWSLen = 0;//BWSDataSeq acture length
        CORBA::Long nBoolBWS = 0;
    
        PPT_METHODTRACE_V2( "", "==> lnLenBWS", lnLenBWS );
        for( CORBA::Long ix=0; ix<lnLenBWS; ix++ )
        {
            PPT_METHODTRACE_V3( "", ix, "##--- BWSID", strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].BWSID.identifier );
    
            CORBA::Long lnLenZone = strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq.length();
            PPT_METHODTRACE_V3( "", ix, "==> lnLenZone", lnLenZone );
    
            strBWSWaferListInqResult.strBWSDataSeq[nResultBWSLen].BWSID = strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].BWSID;//set value
            strBWSWaferListInqResult.strBWSDataSeq[ix].strBWSZoneDataSeq.length(lnLenZone);//set BWSZoneDataSeq max length
            CORBA::Long nResultZoneLen = 0;//BWSZoneDataSeq acture length
            CORBA::Long nBoolZone = 0;
    
            for( CORBA::Long jx=0; jx<lnLenZone; jx++ ) 
            {
                PPT_METHODTRACE_V4( "", ix, jx, "##--- zoneID", strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].zoneID );                  
                CORBA::Long lnLenWafer = strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq.length();
                PPT_METHODTRACE_V4( "", ix, jx, "==> lnLenWafer", lnLenWafer );
    
                strBWSWaferListInqResult.strBWSDataSeq[nResultBWSLen].strBWSZoneDataSeq[nResultZoneLen].zoneID
                    = strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].zoneID;//set value
                strBWSWaferListInqResult.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq.length(lnLenWafer);//set BWSZoneWaferDataSeq max length
                CORBA::Long nResultWaferLen = 0;//BWSZoneWaferDataSeq acture length
    
                for( CORBA::Long kx=0; kx<lnLenWafer; kx++ ) 
                {
                    PPT_METHODTRACE_V1("", "##### Filter Ready");

                    //Filter subLotType
                    if ( 0 == CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.productID.identifier )
                          && 0 < CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.subLotType ))
                        {
                            PPT_METHODTRACE_V1("", "##### Filter subLotType Ready");
                            if (( CIMFWStrCmp( strBWSWaferListInqInParm.strBWSWaferData.subLotType, 
                                    strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].subLotType)) == 0 )
                                    {
                                        PPT_METHODTRACE_V1("", "##### Filter subLotType start");
                                        strBWSWaferListInqResult.strBWSDataSeq[nResultBWSLen].strBWSZoneDataSeq[nResultZoneLen].strBWSWaferDataSeq[nResultWaferLen]
                                            = strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx];//set value
                                        nResultWaferLen++ ;
                                        nBoolZone = 1;
                                    }
                        }

                    //Filter productID
                    if ( 0 < CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.productID.identifier )
                          && 0 == CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.subLotType ))
                        {
                            PPT_METHODTRACE_V1("", "##### Filter productID Ready");
                            if (( CIMFWStrCmp( strBWSWaferListInqInParm.strBWSWaferData.productID.identifier,
                                    strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].productID.identifier)) == 0 )
                                    {
                                        PPT_METHODTRACE_V1("", "##### Filter productID start");
                                        strBWSWaferListInqResult.strBWSDataSeq[nResultBWSLen].strBWSZoneDataSeq[nResultZoneLen].strBWSWaferDataSeq[nResultWaferLen]
                                            = strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx];//set value
                                        nResultWaferLen++ ;
                                        nBoolZone = 1;
                                    }
                        }

                    //Filter productID and subLotType
                    if ( 0 < CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.productID.identifier )
                          && 0 < CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.subLotType ))
                        {
                            PPT_METHODTRACE_V1("", "##### Filter productID and subLotType Ready");
                            if (( CIMFWStrCmp( strBWSWaferListInqInParm.strBWSWaferData.productID.identifier,
                                    strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].productID.identifier)) == 0
                                 && (CIMFWStrCmp( strBWSWaferListInqInParm.strBWSWaferData.subLotType, 
                                    strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].subLotType)) == 0 )
                                    {
                                        PPT_METHODTRACE_V1("", "##### Filter productID and subLotType start");
                                        strBWSWaferListInqResult.strBWSDataSeq[nResultBWSLen].strBWSZoneDataSeq[nResultZoneLen].strBWSWaferDataSeq[nResultWaferLen]
                                            = strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx];//set value
                                        nResultWaferLen++ ;
                                        nBoolZone = 1;
                                    }
                        }
                }
                strBWSWaferListInqResult.strBWSDataSeq[nResultBWSLen].strBWSZoneDataSeq[nResultZoneLen].strBWSWaferDataSeq.length(nResultWaferLen);
    
                if( nBoolZone == 1 )
                {
                    nResultZoneLen++;
                    nBoolBWS = 1;
                }
            }

            strBWSWaferListInqResult.strBWSDataSeq[nResultBWSLen].strBWSZoneDataSeq.length(nResultZoneLen);//set BWSZoneDataSeq max length
            if( nBoolBWS == 1 )
            {
                nResultBWSLen++;
            }
        }
    
        strBWSWaferListInqResult.strBWSDataSeq.length(nResultBWSLen);
    }
    
    //------------------------------------------------------
    // No Need Filter productID and subLotType
    //------------------------------------------------------
    else
    {
        strBWSWaferListInqResult.strBWSDataSeq.length(lnLenBWS);//set BWSDataSeq max length
        for( ix=0; ix<lnLenBWS; ix++ )
        {
            strBWSWaferListInqResult.strBWSDataSeq[ix].BWSID = strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix].BWSID;
            strBWSWaferListInqResult.strBWSDataSeq[ix] = strObjBWS_WaferList_GetDR_out.strBWSDataSeq[ix];
        }
    }
    
    //----------------------------------
    //   Display
    //----------------------------------
    PPT_METHODTRACE_V1( "", "##------- Display -------##" );
    
    CORBA::Long lnLenBWSResult = strBWSWaferListInqResult.strBWSDataSeq.length();
    PPT_METHODTRACE_V2( "", "==> lnLenBWSResult", lnLenBWSResult );
    for( ix=0; ix<lnLenBWSResult; ix++ )
    {
        PPT_METHODTRACE_V3( "", ix, "##--- BWSID", strBWSWaferListInqResult.strBWSDataSeq[ix].BWSID.identifier );
        
        CORBA::Long lnLenZone = strBWSWaferListInqResult.strBWSDataSeq[ix].strBWSZoneDataSeq.length();
        PPT_METHODTRACE_V3( "", ix, "==> lnLenZone", lnLenZone );
        for( CORBA::Long jx=0; jx<lnLenZone; jx++ ) 
        {
            PPT_METHODTRACE_V4( "", ix, jx, "##--- zoneID", strBWSWaferListInqResult.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].zoneID );                  
            CORBA::Long lnLenWafer = strBWSWaferListInqResult.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq.length();
            PPT_METHODTRACE_V4( "", ix, jx, "==> lnLenWafer", lnLenWafer );
            for( CORBA::Long kx=0; kx<lnLenWafer; kx++ ) 
            {
                PPT_METHODTRACE_V5( "", ix, jx, kx, "##--- waferID",      strBWSWaferListInqResult.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].waferID.identifier   );                
                PPT_METHODTRACE_V5( "", ix, jx, kx, "##--- waferGradeID", strBWSWaferListInqResult.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].waferGradeID         );              
                PPT_METHODTRACE_V5( "", ix, jx, kx, "##--- lotID",        strBWSWaferListInqResult.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].lotID.identifier     ); 
                PPT_METHODTRACE_V5( "", ix, jx, kx, "##--- bankID",       strBWSWaferListInqResult.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].bankID.identifier    );   
                PPT_METHODTRACE_V5( "", ix, jx, kx, "##--- productID",    strBWSWaferListInqResult.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].productID.identifier ); 
                PPT_METHODTRACE_V5( "", ix, jx, kx, "##--- subLotType",   strBWSWaferListInqResult.strBWSDataSeq[ix].strBWSZoneDataSeq[jx].strBWSWaferDataSeq[kx].subLotType           );                        
            }
        }
    }
    
    //----------
    //   Return
    //----------
    SET_MSG_RC(strBWSWaferListInqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("PPTManager_i::cs_txBWSWaferListInq");
    return RC_OK;
}