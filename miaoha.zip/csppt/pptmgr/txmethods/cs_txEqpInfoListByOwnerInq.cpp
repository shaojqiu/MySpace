//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2003. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2003. All rights reserved.
//
// SiView
// Name: cs_txEqpInfoListByOwnerInq.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: cs_txEqpInfoListByOwnerInq()
//
// Change history:
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
//
// Description:
//
// Return:
//     long
//
// Parameter:
//      csEqpInfoListByOwnerInqResult&     strCsEqpInfoListByOwnerInqResult,
//      const pptObjCommonIn&              strObjCommonIn,
//      const objectIdentifier&            equipmentOwnerID
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_txEqpInfoListByOwnerInq(
    csEqpInfoListByOwnerInqResult&     strCsEqpInfoListByOwnerInqResult,
    const pptObjCommonIn&              strObjCommonIn,
    const objectIdentifier&            equipmentOwnerID
    CORBAENV_LAST_CPP)
{
    /*------------------------------------------------------------------------*/
    /*   Return Code Initialization                                           */
    /*------------------------------------------------------------------------*/

    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txEqpInfoListByOwnerInq")
    CORBA::Long rc = RC_OK ;

    /*----------------------------*/
    /*   Get EquipmentInfo_List   */
    /*----------------------------*/
    csObjEquipmentInfo_ListByOwnerDR_out strCsObjEquipmentInfo_ListByOwnerDR_out;
    rc = cs_equipmentInfo_ListByOwnerDR (strCsObjEquipmentInfo_ListByOwnerDR_out, strObjCommonIn, equipmentOwnerID);

    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cs_txEqpInfoListByOwnerInq() != RC_OK");
        strCsEqpInfoListByOwnerInqResult.strResult = strCsObjEquipmentInfo_ListByOwnerDR_out.strResult;
        return( rc );
    }
    strCsEqpInfoListByOwnerInqResult.strEqpInfosByOwners = strCsObjEquipmentInfo_ListByOwnerDR_out.strEqpInfosByOwners;

    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
    SET_MSG_RC(strCsEqpInfoListByOwnerInqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: cs_txEqpInfoListByOwnerInq ") ;
    return(RC_OK);
}
