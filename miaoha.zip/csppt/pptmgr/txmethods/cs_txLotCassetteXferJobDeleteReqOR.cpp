#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/txLotCassetteXferJobDeleteReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:23:19 [ 7/13/07 21:23:19 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2014. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2014. All rights reserved.
//
// SiView
// Name: txLotCassetteXferJobDeleteReq.cpp
//

#include "cs_pptmgr.hpp"

// Class: PPTManager
//
// Service: txLotCassetteXferJobDeleteReq()
//
// Change history:
// Date     Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/17          S.Kawabe       Initial Release (R30)
// 2000/10/23 P3000280 S.Kawabe       Boolean variable initialize 
// 2000/11/16 P3000337 S.Tokumasu     Ignore Dispatch Reserve
// 2001/01/11 D3000093 M.Mori         Add change "Required" logic
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2005/10/24 D6000479 K.Kido         Lock Port Object.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2014/05/18 PSN000087448 C.Mo           Equipment port dispatched status is not update correctly during TxLotCassetteXferJobDeleteReq
//
//
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptLotCassetteXferJobDeleteReqResult&  strLotCassetteXferJobDeleteReqResult,
//     const pptObjCommonIn&                  strObjCommonIn,
//     const char *                           jobID
//     const pptDelCarrierJobSequence&        strDelCarrierJob,
//     const char *                           claimMemo,
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::txLotCassetteXferJobDeleteReq(pptLotCassetteXferJobDeleteReqResult&  strLotCassetteXferJobDeleteReqResult,
                                                        const pptObjCommonIn&                  strObjCommonIn,
                                                        const char *                           jobID,
                                                        const pptDelCarrierJobSequence&        strDelCarrierJob,
//D6000025                                                         const char *                           claimMemo,
//D6000025                                                         CORBA::Environment&                    IT_env)
                                                        const char *                           claimMemo //D6000025
                                                        CORBAENV_LAST_CPP)                               //D6000025
{
    PPT_METHODTRACE_ENTRY("PPTManager_i:: txLotCassetteXferJobDeleteReq") ;
    CORBA::Long rc = RC_OK ;

//D6000479 add start
    CORBA::Long castLen = strDelCarrierJob.length();
    for( CORBA::Long k = 0 ; k < castLen ; k++ )
    {
        objCassette_transferState_Get_out strCassette_transferState_Get_out;
        rc = cassette_transferState_Get( strCassette_transferState_Get_out,
                                         strObjCommonIn,
                                         strDelCarrierJob[k].carrierID );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("PPTManager_i::txLotCassetteXferJobDeleteReq", "cassette_transferState_Get() != RC_OK");
            strLotCassetteXferJobDeleteReqResult.strResult = strCassette_transferState_Get_out.strResult;
            return( rc );
        }
        if ( 0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn ) )
        {
            objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
            rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                           strObjCommonIn,
                                           strDelCarrierJob[k].carrierID );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("PPTManager_i::txLotCassetteXferJobDeleteReq", "cassette_equipmentID_Get != RC_OK");
                strLotCassetteXferJobDeleteReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
                return( rc );
            }

            PPT_METHODTRACE_V2("", "equipmentID", strCassette_equipmentID_Get_out.equipmentID.identifier);

            /**********************************************************/
            /*  Lock All Port Object for internal Buffer Equipment.   */
            /**********************************************************/
            objEquipment_portInfo_GetDR_out strEquipment_portInfo_GetDR_out;
            rc = equipment_portInfo_GetDR( strEquipment_portInfo_GetDR_out,
                                           strObjCommonIn,
                                           strCassette_equipmentID_Get_out.equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "equipment_portInfo_GetDR != RC_OK")
                strLotCassetteXferJobDeleteReqResult.strResult = strEquipment_portInfo_GetDR_out.strResult;
                return( rc );
            }

            CORBA::Long lenPortInfo = strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
            for( CORBA::Long j = 0 ; j < lenPortInfo ; j++ )
            {
                objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
                rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                      strObjCommonIn,
                                                      strCassette_equipmentID_Get_out.equipmentID,
                                                      strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID,
                                                      SP_ClassName_PosPortResource );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "object_LockForEquipmentResource () rc != RC_OK", rc);
                    strLotCassetteXferJobDeleteReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
                    return( rc );
                }
                PPT_METHODTRACE_V2("", "Locked port object : ", strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID.identifier);
            }
        }
    }
//D6000479 add end

    /*----------------------------------------------------*/
    /*   Request to XM to Request Transfer Job Deletion   */
    /*----------------------------------------------------*/
    pptTranJobCancelReq   tranJobCancelReq;
    
    CORBA::Long nLen = strDelCarrierJob.length();
    PPT_METHODTRACE_V2("PPTManager_i:: txLotCassetteXferJobDeleteReq",
                       "strDelCarrierJob.length()", nLen);

    tranJobCancelReq.carrierJobData.length( nLen );

    tranJobCancelReq.jobID = jobID;
    for (CORBA::Long i=0; i<nLen; i++)
    {
        tranJobCancelReq.carrierJobData[i].carrierJobID = strDelCarrierJob[i].carrierJobID;
        tranJobCancelReq.carrierJobData[i].carrierID    = strDelCarrierJob[i].carrierID;
    }
    objXMSMgr_SendTransportJobCancelReq_out   strXMSMgr_SendTransportJobCancelReq_out;
    rc = XMSMgr_SendTransportJobCancelReq(strXMSMgr_SendTransportJobCancelReq_out,
                                          strObjCommonIn,
                                          strObjCommonIn.strUser,
                                          tranJobCancelReq) ;
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txLotCassetteXferJobDeleteReq", "XMSMgr_SendTransportJobCancelReq() != RC_OK");
        strLotCassetteXferJobDeleteReqResult.strResult = strXMSMgr_SendTransportJobCancelReq_out.strResult;
        return( rc );
    }

    /*---------------------------------*/
    /*   Get Cassette Reserve Status   */
    /*---------------------------------*/
    objCassette_reservedState_Get_out strCassette_reservedState_Get_out;
    strCassette_reservedState_Get_out.transferReserved = FALSE; //P3000280
    for (i=0; i<nLen; i++)
    {
        rc = cassette_reservedState_Get(strCassette_reservedState_Get_out, strObjCommonIn, strDelCarrierJob[i].carrierID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("PPTManager_i:: txLotCassetteXferJobDeleteReq", "cassette_reservedState_Get() rc!=RC_OK", i);
            strLotCassetteXferJobDeleteReqResult.strResult = strCassette_reservedState_Get_out.strResult;
            return( rc );
        }
    }
    
    if ( strCassette_reservedState_Get_out.transferReserved == TRUE )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txLotCassetteXferJobDeleteReq",
                           "strCassette_reservedState_Get_out.transferReserved == TRUE");

        /*------------------------------------------*/  
        /*   Call txLotCassetteReserveCancelReq()   */
        /*------------------------------------------*/
        pptRsvCanLotCarrierSequence strRsvCanLotCarrier;
        strRsvCanLotCarrier.length( nLen );
        
        for (i=0; i<nLen; i++)
        {
            strRsvCanLotCarrier[i].carrierID = strDelCarrierJob[i].carrierID;
        }
        pptLotCassetteReserveCancelReqResult strLotCassetteReserveCancelReqResult;
        rc = txLotCassetteReserveCancelReq(strLotCassetteReserveCancelReqResult,
                                           strObjCommonIn,
                                           strRsvCanLotCarrier,
                                           claimMemo);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txLotCassetteXferJobDeleteReq","txLotCassetteReserveCancelReq() != RC_OK");
            strLotCassetteXferJobDeleteReqResult.strResult = strLotCassetteReserveCancelReqResult.strResult;
            return( rc );
        }
    }

    /*---------------------------------*/
    /*   Get Cassette Reserve Status   */
    /*---------------------------------*/
    objCassette_dispatchState_Get_out strCassette_dispatchState_Get_out;
    strCassette_dispatchState_Get_out.dispatchReservedFlag = FALSE; //P3000280
    for (i=0; i<nLen; i++)
    {
        rc = cassette_dispatchState_Get(strCassette_dispatchState_Get_out, strObjCommonIn, strDelCarrierJob[i].carrierID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("PPTManager_i:: txLotCassetteXferJobDeleteReq","cassette_dispatchState_Get() != RC_OK", i);
            strLotCassetteXferJobDeleteReqResult.strResult = strCassette_dispatchState_Get_out.strResult;
            return( rc );
        }
    }

    if ( strCassette_dispatchState_Get_out.dispatchReservedFlag == TRUE )
    {
        /*-------------------------------------------------------*/
        /*  StartLotsReservationCancelReq for next equipment     */
        /*-------------------------------------------------------*/
        PPT_METHODTRACE_V1("PPTManager_i:: txLotCassetteXferJobDeleteReq", "strCassette_dispatchState_Get_out.dispatchReservedFlag == TRUE");
//P3000337        SET_MSG_RC(strLotCassetteXferJobDeleteReqResult, MSG_ALREADY_DISPATCH_RESVED_CST, RC_ALREADY_DISPATCH_RESVED_CST) ;
//P3000337        return( rc );
//D3000093    }

//D3000093 add start
        for (i=0; i<nLen; i++)
        {
            PPT_METHODTRACE_V3("PPTManager_i::txLotCassetteXferJobDeleteReq", "strDelCarrierJob[i].carrierID", strDelCarrierJob[i].carrierID.identifier, i);

            /*-----------------------------------*/
            /*  Check cassette transfer status   */
            /*-----------------------------------*/
            PPT_METHODTRACE_V1("PPTManager_i::txLotCassetteXferJobDeleteReq", "Check cassette transfer status");

            objCassette_transferState_Get_out strCassette_transferState_Get_out;
            rc = cassette_transferState_Get( strCassette_transferState_Get_out,
                                             strObjCommonIn,
                                             strDelCarrierJob[i].carrierID );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("PPTManager_i::txLotCassetteXferJobDeleteReq", "cassette_transferState_Get() != RC_OK");
                strLotCassetteXferJobDeleteReqResult.strResult = strCassette_transferState_Get_out.strResult;
                return( rc );
            }
            if ( 0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn ) )
            {
                PPT_METHODTRACE_V1("PPTManager_i::txLotCassetteXferJobDeleteReq", "transferState == EI");

                /*------------------------------------*/
                /*   Get Cassette Info in Equipment   */
                /*------------------------------------*/
                PPT_METHODTRACE_V1("PPTManager_i::txLotCassetteXferJobDeleteReq","Get Cassette Info in Equipment");

                objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
                rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                               strObjCommonIn,
                                               strDelCarrierJob[i].carrierID );

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("PPTManager_i::txLotCassetteXferJobDeleteReq", "cassette_equipmentID_Get != RC_OK");
                    strLotCassetteXferJobDeleteReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
                    return( rc );
                }

                PPT_METHODTRACE_V2("PPTManager_i::txLotCassetteXferJobDeleteReq", "equipmentID", strCassette_equipmentID_Get_out.equipmentID.identifier);
//PSN000087448 Add Start
                /*-------------------------*/
                /*   Get Equipment Object  */
                /*-------------------------*/
                CORBA::String_var equipmentCategory = CIMFWStrDup("");
                objEquipment_brInfo_GetDR_out__120 strEquipment_brInfo_GetDR_out;
                objEquipment_brInfo_GetDR_in__100  strEquipment_brInfo_GetDR_in;
                strEquipment_brInfo_GetDR_in.equipmentID = strCassette_equipmentID_Get_out.equipmentID;
                rc = equipment_brInfo_GetDR__120( strEquipment_brInfo_GetDR_out,
                                                  strObjCommonIn,
                                                  strEquipment_brInfo_GetDR_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("PPTManager_i::txLotCassetteXferJobDeleteReq", "equipment_brInfo_GetDR__120() rc != RC_OK", rc);
                    strLotCassetteXferJobDeleteReqResult.strResult = strEquipment_brInfo_GetDR_out.strResult;
                    return( rc );
                }

                equipmentCategory = CIMFWStrDup(strEquipment_brInfo_GetDR_out.equipmentBRInfo.equipmentCategory);
                PPT_METHODTRACE_V2("PPTManager_i::txLotCassetteXferJobDeleteReq", "EQP Category is ", equipmentCategory);

                /*-----------------------*/
                /*   Get Equipment Port  */
                /*-----------------------*/
                pptEqpPortInfo equipmentPortInfo;
                if ( 0 == CIMFWStrCmp(equipmentCategory, SP_Mc_Category_InternalBuffer) )
                {
                    objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
                    rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out,
                                                                    strObjCommonIn,
                                                                    strCassette_equipmentID_Get_out.equipmentID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("PPTManager_i::txLotCassetteXferJobDeleteReq", "equipment_portInfoForInternalBuffer_GetDR != RC_OK")
                        strLotCassetteXferJobDeleteReqResult.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
                        return( rc );
                    }
                    equipmentPortInfo = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo;
                }
                else
                {
                    objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
                    rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                                 strObjCommonIn,
                                                 strCassette_equipmentID_Get_out.equipmentID );

                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("PPTManager_i::txLotCassetteXferJobDeleteReq", "equipment_portInfo_Get != RC_OK");
                        strLotCassetteXferJobDeleteReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
                        return rc;
                    }
                    equipmentPortInfo = strEquipment_portInfo_Get_out.strEqpPortInfo;
                }
//PSN000087448 Add End
//PSN000087448                objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
//PSN000087448                rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
//PSN000087448                                             strObjCommonIn,
//PSN000087448                                             strCassette_equipmentID_Get_out.equipmentID );

//PSN000087448                if ( rc != RC_OK )
//PSN000087448                {
//PSN000087448                    PPT_METHODTRACE_V1("PPTManager_i::txLotCassetteXferJobDeleteReq", "equipment_portInfo_Get != RC_OK");
//PSN000087448                    strLotCassetteXferJobDeleteReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
//PSN000087448                    return( rc );
//PSN000087448                }

//PSN000087448                CORBA::Long lenEqpPort = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
                CORBA::Long lenEqpPort = equipmentPortInfo.strEqpPortStatus.length(); //PSN000087448
                for ( CORBA::Long j=0; j < lenEqpPort; j++ )
                {
                    PPT_METHODTRACE_V3("PPTManager_i::txLotCassetteXferJobDeleteReq", "strEqpPortStatus[j].loadedCassetteID",
//PSN000087448                                          strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier, j);
                                          equipmentPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier, j); //PSN000087448

                    if ( 0 == CIMFWStrCmp( strDelCarrierJob[i].carrierID.identifier,
//PSN000087448                                           strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier) )
                                           equipmentPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier) )
                    {
                        PPT_METHODTRACE_V1("PPTManager_i::txLotCassetteXferJobDeleteReq", "cassetteID == loadedCassetteID");
                        PPT_METHODTRACE_V2("PPTManager_i::txLotCassetteXferJobDeleteReq", "strEqpPortStatus[j].portState", 
//PSN000087448                                            strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState);
                                            equipmentPortInfo.strEqpPortStatus[j].portState);
                        PPT_METHODTRACE_V2("PPTManager_i::txLotCassetteXferJobDeleteReq", "strEqpPortStatus[j].dispatchState", 
//PSN000087448                                            strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchState);
                                            equipmentPortInfo.strEqpPortStatus[j].dispatchState);
//PSN000087448                        if ( 0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_UnloadReq) &&
//PSN000087448                             0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchState, SP_PortRsc_DispatchState_Dispatched) )
                        if ( 0 == CIMFWStrCmp( equipmentPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_UnloadReq) && 
                             0 == CIMFWStrCmp( equipmentPortInfo.strEqpPortStatus[j].dispatchState, SP_PortRsc_DispatchState_Dispatched) ) //PSN000087448
                        {
                            PPT_METHODTRACE_V1("PPTManager_i::txLotCassetteXferJobDeleteReq", "(portState == UnloadReq) && (dispatchState == Dispatched)");

                            /*------------------------*/
                            /*   change to Required   */
                            /*------------------------*/
                            objectIdentifier dummyOI;
                            objEquipment_dispatchState_Change_out strEquipment_dispatchState_Change_out;
                            rc = equipment_dispatchState_Change( strEquipment_dispatchState_Change_out,
                                                                 strObjCommonIn,
                                                                 strCassette_equipmentID_Get_out.equipmentID,
//PSN000087448                                                                 strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portID,
                                                                 equipmentPortInfo.strEqpPortStatus[j].portID, // PSN000087448
                                                                 SP_PortRsc_DispatchState_Required,
                                                                 dummyOI,
                                                                 dummyOI,
                                                                 dummyOI,
                                                                 dummyOI );

                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("PPTManager_i::txLotCassetteXferJobDeleteReq", "equipment_dispatchState_Change() != RC_OK");
                                strLotCassetteXferJobDeleteReqResult.strResult = strEquipment_dispatchState_Change_out.strResult ;
                                return( rc );
                            }
                        }
                    }
                }
            }
        }
    }
//D3000093 add end

    /*----------------------------*/
    /*   Set Returned Structure   */
    /*----------------------------*/
    SET_MSG_RC(strLotCassetteXferJobDeleteReqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("PPTManager_i:: txLotCassetteXferJobDeleteReq") ;
    return( RC_OK );
}
