#ifndef lint
static char *sccsid =  "@(#) 1.3 superpos/src/spppt/source/posppt/pptmgr/txmethods/txLotsInfoForStartReservationInq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/9/07 13:25:48 [ 11/9/07 13:25:49 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: txLotsInfoForStartReservationInq.cpp
//

#include "cs_pptmgr.hpp"

void traceSampledStartCassette( const pptStartCassetteSequence& strStartCassette );    //D9000003 for Cassette trace

// Class: PPTManager
//
// Service: txLotsInfoForStartReservationInq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/09/10          Y.Iwasaki      Initial Release
// 2001/06/06 D4000014 K.Kido         APC Interface
// 2001/07/05 D4000015 H.Katoh        Add Equipment Category Check Logic because of
//                                    Internal Buffer Support
// 2001/09/19 D4000014 K.Kido         Change APC I/F place
// 2001/10/29 P4000394 K.Kido         Rollback from "Change APC I/F place"
// 2002/05/13 P4100425 K.Matsuei      The number of Parameters to assemble Message in PPT_SET_MSG_RC_KEY*** mistakes it.
// 2002/06/11 P4100536 T.Nishimura    Source Check : Wrong reference to dimension.
// 2002/07/04 P4200025 T.Nishimura    Source Check : return without message.
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2006/11/16 D8000024 Y.Kadowaki     Flexible Process Condition Change (R80)
// 2007/04/02 D8000207 M.Murata       Add changing logic processJobExecFlag.
// 2007/04/20 D9000001 H.Murakami     64bit support.
// 2007/06/01 D9000003 M.Nakano       Modify changing logic processJobExecFlag for wafer sampling operation.

//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009-11-11 PSIV00001581 R.Iriguchi     Fix memory leak
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/27 INN-R170009  Liu Xinxin     Litho APC Enahncement


// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptLotsInfoForStartReservationInqResult& strLotsInfoForStartReservationInqResult
//     const pptObjCommonIn&                strObjCommonIn
//     const objectIdentifier&              equipmentID
//     const pptStartCassetteSequence&      strStartCassette
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::txLotsInfoForStartReservationInq (
    pptLotsInfoForStartReservationInqResult&    strLotsInfoForStartReservationInqResult,
    const pptObjCommonIn&                       strObjCommonIn,
    const objectIdentifier&                     equipmentID,
//D6000025     const pptStartCassetteSequence&             strStartCassette,
//D6000025     CORBA::Environment &                        IT_env)
    const pptStartCassetteSequence&             strStartCassette //D6000025
    CORBAENV_LAST_CPP)                                           //D6000025
{
    PPT_METHODTRACE_ENTRY("PPTManager_i::txLotsInfoForStartReservationInq ");

    CORBA::Long rc = RC_OK;

//P4100536 add start
    // Check length of In-Parameter
    if ( 0 >= strStartCassette.length() )
    {
        SET_MSG_RC(strLotsInfoForStartReservationInqResult, MSG_INVALID_PARAMETER, RC_INVALID_PARAMETER); //P4200025 add
        return RC_INVALID_PARAMETER;
    }
//P4100536 add end

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Object Lock Process                                                 */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Check Process                                                       */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
//D4000015 Start
    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","equipment_categoryVsTxID_CheckCombination() returned error.");

        strLotsInfoForStartReservationInqResult.strResult
            = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return (rc);
    }
//D4000015 End

//D8000207 add start
    //----------------------------------------
    // Change processJobExecFlag to True.
    //----------------------------------------
    strLotsInfoForStartReservationInqResult.strStartCassette = strStartCassette;
//D9000003 delete start
//    PPT_METHODTRACE_V2("","SP_OPER_START_WAFER_FLAG_CONTROL is ", atol(getenv(SP_OPER_START_WAFER_FLAG_CONTROL)));
//    if( 1 == atol(getenv(SP_OPER_START_WAFER_FLAG_CONTROL)) )
//    {
//        objStartCassette_processJobExecFlag_Set_out   strStartCassette_processJobExecFlag_Set_out;
//        rc = startCassette_processJobExecFlag_Set(strStartCassette_processJobExecFlag_Set_out, strObjCommonIn, strStartCassette );
//        if( rc != RC_OK )
//        {
//            PPT_METHODTRACE_V1("","objStartCassette_processJobExecFlag_Set() != RC_OK ");
//            strLotsInfoForStartReservationInqResult.strResult = strStartCassette_processJobExecFlag_Set_out.strResult;
//            return rc ;
//        }
//        strLotsInfoForStartReservationInqResult.strStartCassette = strStartCassette_processJobExecFlag_Set_out.strStartCassette;
//    }
//D9000003 delete end
//D8000207 add start

//D9000003 add start
    PPT_METHODTRACE_V1("","Set processJobExecFlag based on wafer sampling setting. ");
    objStartCassette_processJobExecFlag_Set_out__090 strStartCassette_processJobExecFlag_Set_out__090;
    objStartCassette_processJobExecFlag_Set_in__090 strStartCassette_processJobExecFlag_Set_in__090;
    strStartCassette_processJobExecFlag_Set_in__090.strStartCassette = strStartCassette;
    strStartCassette_processJobExecFlag_Set_in__090.equipmentID = equipmentID;

    rc = startCassette_processJobExecFlag_Set__090( strStartCassette_processJobExecFlag_Set_out__090, strObjCommonIn, strStartCassette_processJobExecFlag_Set_in__090 );
    if ( rc != RC_SMPL_SLOTMAP_CONFLICT_WARN && rc != RC_OK )
    {
        // Return error when input parameter or sampling setting is invalid format.
        PPT_METHODTRACE_V1("","startCassette_processJobExecFlag_Set__090() != RC_OK ");
        strLotsInfoForStartReservationInqResult.strResult = strStartCassette_processJobExecFlag_Set_out__090.strResult;
        return rc;
    }
    //-------------------------------------------------------
    // When RC_SMPL_SLOTMAP_CONFLICT_WARN is returned,
    // return RC_SMPL_SLOTMAP_CONFLICT_WARN at the last of TX process.
    //-------------------------------------------------------
    CORBA::Boolean slotmapConflictWarnFlag = FALSE;    //Switch RC: when sampling logic below finished with warning.
    if( rc == RC_SMPL_SLOTMAP_CONFLICT_WARN)
    {
        PPT_METHODTRACE_V1("", "rc == RC_SMPL_SLOTMAP_CONFLICT_WARN");
        slotmapConflictWarnFlag = TRUE;
    }
    //-------------------------------------------------------
    // create return message or e-mail text.
    //-------------------------------------------------------
    ostrstream smplMessage;
    PPT_METHODTRACE_V2("", "strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage.length()", strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage.length());
    for ( CORBA::Long msgCnt = 0; msgCnt < strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage.length(); msgCnt++ )
    {
        if ( strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].messageType == SP_Sampling_warn_mail )
        {
            PPT_METHODTRACE_V1("", "strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].messageType == SP_Sampling_warn_mail");
            // create return message;
            if ( smplMessage.pcount() > 0 )
            {
                smplMessage << "," << endl;
            }
            smplMessage << strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].messageText;
        }
        else if ( strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].messageType == SP_Sampling_ignored_mail )
        {
            PPT_METHODTRACE_V1("", "strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].messageType == SP_Sampling_ignored_mail");
            // Send E-mail when recycle sampling setting is ignored.
            pptSystemMsgRptResult strSystemMsgRptResult;
            objectIdentifier dummyID;
            rc = txSystemMsgRpt(strSystemMsgRptResult,
                                strObjCommonIn,
                                SP_SubSystemID_MM,
                                SP_SystemMsgCode_SMPLERR,
                                strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].messageText,
                                TRUE,
                                dummyID,
                                "",
                                dummyID,
                                "",
                                dummyID,
                                "",
                                strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].lotID,
                                "",
                                dummyID,
                                dummyID,
                                "",
                                strObjCommonIn.strTimeStamp.reportTimeStamp,
                                "" );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "txSystemMsgRpt != RC_OK");
                strLotsInfoForStartReservationInqResult.strResult = strSystemMsgRptResult.strResult;
                return( rc );
            }
        }
    } //end for-loop
    smplMessage << ends;

    PPT_METHODTRACE_V2("", "smplMessage = ", smplMessage.str());
    smplMessage.rdbuf()->freeze(0);             //PSIV00001581
    strLotsInfoForStartReservationInqResult.strStartCassette = strStartCassette_processJobExecFlag_Set_out__090.strStartCassette;


//D9000003 add end

//P4000394//D4000014 start
//P4000394    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
//P4000394    /*                                                                       */
//P4000394    /*   APC I/F                                                             */
//P4000394    /*                                                                       */
//P4000394    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
//P4000394    /*------------------------------------------------------*/
//P4000394    /*   Get Info for StartReservation use APC I/F or not   */
//P4000394    /*------------------------------------------------------*/
//P4000394    PPT_METHODTRACE_V1("","Enter the APC_interfaceFlag_Check !!");
//P4000394    objAPC_interfaceFlag_Check_out strAPC_interfaceFlag_Check_out;
//P4000394    rc = APC_interfaceFlag_Check( strAPC_interfaceFlag_Check_out,
//P4000394                                  strObjCommonIn,
//P4000394                                  strStartCassette );
//P4000394
//P4000394    if ( rc != RC_OK )
//P4000394    {
//P4000394        PPT_METHODTRACE_V1("","APC_interfaceFlag_Check() != RC_OK");
//P4000394        strLotsInfoForStartReservationInqResult.strResult = strAPC_interfaceFlag_Check_out.strResult;
//P4000394        return ( rc );
//P4000394    }
//P4000394
//P4000394    if( strAPC_interfaceFlag_Check_out.APCInterFaceFlag )
//P4000394    {
//P4000394        PPT_METHODTRACE_V1("", "APCInterFaceFlag is TRUE!!!");
//P4000394
//P4000394        /*--------------------------------------------------*/
//P4000394        /*                                                  */
//P4000394        /*   Get Equipment's Start Reserved ControlJob ID   */
//P4000394        /*                                                  */
//P4000394        /*--------------------------------------------------*/
//P4000394        PPT_METHODTRACE_V1("", "Get Equipment's Start Reserved ControlJob ID");
//P4000394
//P4000394        objEquipment_reservedControlJobID_Get_out strEquipment_reservedControlJobID_Get_out;
//P4000394        rc = equipment_reservedControlJobID_Get( strEquipment_reservedControlJobID_Get_out,
//P4000394                                                 strObjCommonIn,
//P4000394                                                 equipmentID );
//P4000394
//P4000394        if ( rc != RC_OK )
//P4000394        {
//P4000394            PPT_METHODTRACE_V1("", "equipment_reservedControlJobID_Get() rc != RC_OK");
//P4000394            strLotsInfoForStartReservationInqResult.strResult = strEquipment_reservedControlJobID_Get_out.strResult;
//P4000394            return (rc);
//P4000394        }
//P4000394
//P4000394        /*-------------------------------------------------*/
//P4000394        /*                                                 */
//P4000394        /*   Get Cassette's Start Reserved ControlJob ID   */
//P4000394        /*                                                 */
//P4000394        /*-------------------------------------------------*/
//P4000394        PPT_METHODTRACE_V1("", "Get Cassette's Start Reserved ControlJob ID");
//P4000394
//P4000394        objectIdentifier saveControlJobID;
//P4000394        CORBA::Long i = 0;
//P4000394        CORBA::Long nIMax = strStartCassette.length();
//P4000394
//P4000394        PPT_METHODTRACE_V2("", "nIMax = ", nIMax);
//P4000394
//P4000394        for ( i=0 ; i < nIMax; i++ )
//P4000394        {
//P4000394            objCassette_controlJobID_Get_out   strCassette_controlJobID_Get_out;
//P4000394            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out, strObjCommonIn, strStartCassette[i].cassetteID );
//P4000394            if ( rc != RC_OK )
//P4000394            {
//P4000394                PPT_METHODTRACE_V1("", "cassette_controlJobID_Get() rc != RC_OK")
//P4000394                strLotsInfoForStartReservationInqResult.strResult = strCassette_controlJobID_Get_out.strResult;
//P4000394                return( rc );
//P4000394            }
//P4000394
//P4000394            CORBA::Boolean findFlag = FALSE;
//P4000394            CORBA::Long j = 0;
//P4000394            CORBA::Long nJMax = strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo.length();
//P4000394            PPT_METHODTRACE_V2("", "nJMax = ", nJMax);
//P4000394            for ( j=0 ; j < nJMax; j++ )
//P4000394            {
//P4000394                if ( 0 == CIMFWStrCmp(strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[j].controlJobID.identifier,
//P4000394                                      strCassette_controlJobID_Get_out.controlJobID.identifier) )
//P4000394                {
//P4000394                    findFlag = TRUE;
//P4000394                    break;
//P4000394                }
//P4000394            }
//P4000394
//P4000394            if (CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) != 0 )
//P4000394            {
//P4000394                PPT_METHODTRACE_V1("", "CIMFWStrLen(strCassette_controlJobID_Get_out.contorolJobID.identifier) != 0");
//P4000394                saveControlJobID = strCassette_controlJobID_Get_out.controlJobID;
//P4000394
//P4000394                if ( findFlag == FALSE )
//P4000394                {
//P4000394                    PPT_METHODTRACE_V1( "", "findFlag == FALSE" );
//P4000394                    SET_MSG_RC( strLotsInfoForStartReservationInqResult,
//P4000394                                MSG_NOT_RESVED_PORTGRP,
//P4000394                                RC_NOT_RESVED_PORTGRP );
//P4000394                    return( RC_NOT_RESVED_PORTGRP );
//P4000394                }
//P4000394            }
//P4000394            else
//P4000394            {
//P4000394                PPT_METHODTRACE_V1("", "CIMFWStrLen(strCassette_controlJobID_Get_out.contorolJobID.identifier) == 0");
//P4000394                if ( findFlag == TRUE )
//P4000394                {
//P4000394                    PPT_METHODTRACE_V1( "", "findFlag == FALSE" );
//P4000394                    PPT_SET_MSG_RC_KEY( strLotsInfoForStartReservationInqResult,
//P4000394                                        MSG_ALREADY_RESERVED_PORTGRP,
//P4000394                                        RC_ALREADY_RESERVED_PORTGRP,
//P4000394                                        strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[j].controlJobID.identifier );
//P4000394                    return( RC_ALREADY_RESERVED_PORTGRP );
//P4000394                }
//P4000394            }
//P4000394        }
//P4000394
//P4000394        /*---------------------*/  // This implementation is not good from
//P4000394        /*   Get PortGroupID   */  // responce point of view. In the near
//P4000394        /*---------------------*/  // future, this logic must be replaced.
//P4000394        objectIdentifier savePortGroupID;
//P4000394        objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
//P4000394        rc = equipment_portInfo_Get(strEquipment_portInfo_Get_out, strObjCommonIn, equipmentID);
//P4000394        if (rc != RC_OK)
//P4000394        {
//P4000394            PPT_METHODTRACE_V1("", "equipment_portInfo_Get() != RC_OK");
//P4000394            strLotsInfoForStartReservationInqResult.strResult = strEquipment_portInfo_Get_out.strResult;
//P4000394            return(rc);
//P4000394        }
//P4000394        CORBA::Long EPSLength = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
//P4000394        for (i=0 ; i<EPSLength ; i++ )
//P4000394        {
//P4000394            PPT_METHODTRACE_V3("", "loop to strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length()",EPSLength,i);
//P4000394            CORBA::String_var EPSIdent;
//P4000394            CORBA::String_var InCIDIdent;
//P4000394            EPSIdent = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].loadedCassetteID.identifier;
//P4000394
//P4000394//*******************************
//P4000394// Is 0 really all right?
//P4000394            InCIDIdent = strStartCassette[0].cassetteID.identifier;
//P4000394//*******************************
//P4000394            if (CIMFWStrCmp(EPSIdent,InCIDIdent) == 0)
//P4000394            {
//P4000394                PPT_METHODTRACE_V1("", "strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].loadedCassetteID == in-parm' scassetteID[0]");
//P4000394                savePortGroupID.identifier = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].portGroup;
//P4000394                break;
//P4000394            }
//P4000394        }
//P4000394
//P4000394        /*-------------------------------------------------*/
//P4000394        /*   Get from APCInterface AdjustRecipeParameter   */
//P4000394        /*-------------------------------------------------*/
//P4000394        PPT_METHODTRACE_V1("", "Get from APCMgr_SendRecipeParamInq");
//P4000394        objAPCMgr_SendRecipeParamInq_out strAPCMgr_SendRecipeParamInq_out;
//P4000394        rc = APCMgr_SendRecipeParamInq( strAPCMgr_SendRecipeParamInq_out,
//P4000394                                             strObjCommonIn,
//P4000394                                             equipmentID,
//P4000394                                             savePortGroupID.identifier,
//P4000394                                             saveControlJobID,
//P4000394                                             strStartCassette );
//P4000394
//P4000394        if (rc != RC_OK)
//P4000394        {
//P4000394            PPT_METHODTRACE_V1("", "APCMgr_SendRecipeParamInq() != RC_OK");
//P4000394            strLotsInfoForStartReservationInqResult.strResult = strAPCMgr_SendRecipeParamInq_out.strResult;
//P4000394            return ( rc );
//P4000394        }
//P4000394
//P4000394        strLotsInfoForStartReservationInqResult.strStartCassette = strAPCMgr_SendRecipeParamInq_out.strStartCassette;
//P4000394    }
//P4000394//D4000014 end

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Main Process                                                        */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

    /*-------------------------------------------*/
    /*   Get Information for Start Reservation   */
    /*-------------------------------------------*/
    objProcess_startReserveInformation_GetBaseInfoForClient_out strProcess_startReserveInformation_GetBaseInfoForClient_out;
//D8000207    rc = process_startReserveInformation_GetBaseInfoForClient(strProcess_startReserveInformation_GetBaseInfoForClient_out, strObjCommonIn, equipmentID, strStartCassette );
    rc = process_startReserveInformation_GetBaseInfoForClient(strProcess_startReserveInformation_GetBaseInfoForClient_out, strObjCommonIn, equipmentID, strLotsInfoForStartReservationInqResult.strStartCassette );    //D8000207
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i::txLotsInfoForStartReservationInq", "process_startReserveInformation_GetBaseInfoForClient() != RC_OK");
        strLotsInfoForStartReservationInqResult.strResult = strProcess_startReserveInformation_GetBaseInfoForClient_out.strResult;
        return( rc );
    }
    strLotsInfoForStartReservationInqResult.equipmentID      = strProcess_startReserveInformation_GetBaseInfoForClient_out.equipmentID;
    strLotsInfoForStartReservationInqResult.strStartCassette = strProcess_startReserveInformation_GetBaseInfoForClient_out.strStartCassette;

//D8000024 add start
//D9000001    CORBA::Long  tmpFPCAdoptFlag = atol( getenv(SP_FPC_Adaptation_Flag) );
    CORBA::Long  tmpFPCAdoptFlag = atoi( getenv(SP_FPC_Adaptation_Flag) );    //D9000001
    if ( 1 == tmpFPCAdoptFlag )
    {
        PPT_METHODTRACE_V1("","FPC Adopt Flag is ON. Now apply FPCInfo.");
        objFPCStartCassetteInfo_Exchange_out  strFPCStartCassetteInfo_Exchange_out;
        rc = FPCStartCassetteInfo_Exchange( strFPCStartCassetteInfo_Exchange_out,
                                            strObjCommonIn,
                                            SP_FPC_ExchangeType_StartReserveInfo,
                                            strLotsInfoForStartReservationInqResult.equipmentID,
                                            strLotsInfoForStartReservationInqResult.strStartCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("","FPCStartCassetteInfo_Exchange() != RC_OK", rc);
            strLotsInfoForStartReservationInqResult.strResult = strFPCStartCassetteInfo_Exchange_out.strResult;

            return rc;
        }
        strLotsInfoForStartReservationInqResult.strStartCassette = strFPCStartCassetteInfo_Exchange_out.strStartCassette;
    }
    else
    {
        PPT_METHODTRACE_V1("","FPC Adopt Flag is OFF.");
    }
//D8000024 add end

//D4000014 start
//P4000394 rollback from "Change APC I/F place" start
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   APC I/F                                                             */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
     PPT_METHODTRACE_V1("","Get Info for StartReservation use APC I/F or not");

    /*------------------------------------------------------*/
    /*   Get Info for StartReservation use APC I/F or not   */
    /*------------------------------------------------------*/
    PPT_METHODTRACE_V1("","Enter the APC_interfaceFlag_Check !!");
//INN-R-170009    objAPC_interfaceFlag_Check_out strAPC_interfaceFlag_Check_out;
//INN-R-170009   rc = APC_interfaceFlag_Check( strAPC_interfaceFlag_Check_out,
//INN-R-170009                                  strObjCommonIn,
//INN-R-170009                                  strLotsInfoForStartReservationInqResult.strStartCassette );

//INN-R-170009    if ( rc != RC_OK )
//INN-R-170009    {
//INN-R-170009        PPT_METHODTRACE_V1("","APC_interfaceFlag_Check() != RC_OK");
//INN-R-170009        strLotsInfoForStartReservationInqResult.strResult = strAPC_interfaceFlag_Check_out.strResult;
//INN-R-170009       return ( rc );
//INN-R-170009    }
//INN-R-170009
//INN-R-170009    if ( strAPC_interfaceFlag_Check_out.APCInterFaceFlag )
    //INN-R-170009 Start//
    CORBA::String_var APCFlag = CIMFWStrDup(getenv(SP_APC_Available));
    PPT_METHODTRACE_V2("", "APCAvailable", APCFlag);

    if (CIMFWStrCmp(APCFlag,SP_CheckFlag_On) == 0 )
    {
    //INN-R-170009 end//
        PPT_METHODTRACE_V1("", "APCInterFaceFlag is TRUE!!!");

        /*--------------------------------------------------*/
        /*                                                  */
        /*   Get Equipment's Start Reserved ControlJob ID   */
        /*                                                  */
        /*--------------------------------------------------*/
        PPT_METHODTRACE_V1("", "Get Equipment's Start Reserved ControlJob ID");

        objEquipment_reservedControlJobID_Get_out strEquipment_reservedControlJobID_Get_out;
        rc = equipment_reservedControlJobID_Get( strEquipment_reservedControlJobID_Get_out,
                                                 strObjCommonIn,
                                                 equipmentID );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "equipment_reservedControlJobID_Get() rc != RC_OK");
            strLotsInfoForStartReservationInqResult.strResult = strEquipment_reservedControlJobID_Get_out.strResult;
            return (rc);
        }

        /*-------------------------------------------------*/
        /*                                                 */
        /*   Get Cassette's Start Reserved ControlJob ID   */
        /*                                                 */
        /*-------------------------------------------------*/
        PPT_METHODTRACE_V1("", "Get Cassette's Start Reserved ControlJob ID");

        objectIdentifier saveControlJobID;
        CORBA::Long i = 0;
        CORBA::Long nIMax = strStartCassette.length();

        PPT_METHODTRACE_V2("", "nIMax = ", nIMax);

        for ( i = 0; i < nIMax; i++ )
        {
            objCassette_controlJobID_Get_out   strCassette_controlJobID_Get_out;
            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out, strObjCommonIn, strLotsInfoForStartReservationInqResult.strStartCassette[i].cassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "cassette_controlJobID_Get() rc != RC_OK")
                strLotsInfoForStartReservationInqResult.strResult = strCassette_controlJobID_Get_out.strResult;
                return( rc );
            }

            CORBA::Boolean findFlag = FALSE;
            CORBA::Long j = 0;
            CORBA::Long nJMax = strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo.length();
            PPT_METHODTRACE_V2("", "nJMax = ", nJMax);
            for ( j = 0; j < nJMax; j++ )
            {
                if ( 0 == CIMFWStrCmp(strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[j].controlJobID.identifier,
                                      strCassette_controlJobID_Get_out.controlJobID.identifier) )
                {
                    findFlag = TRUE;
                    break;
                }
            }

            if ( CIMFWStrLen( strCassette_controlJobID_Get_out.controlJobID.identifier ) != 0 )
            {
                PPT_METHODTRACE_V1("", "CIMFWStrLen(strCassette_controlJobID_Get_out.contorolJobID.identifier) != 0");
                saveControlJobID = strCassette_controlJobID_Get_out.controlJobID;

                if ( findFlag == FALSE )
                {
                    PPT_METHODTRACE_V1( "", "findFlag == FALSE" );
                    SET_MSG_RC( strLotsInfoForStartReservationInqResult,
                                MSG_NOT_RESVED_PORTGRP,
                                RC_NOT_RESVED_PORTGRP );
                    return( RC_NOT_RESVED_PORTGRP );
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "CIMFWStrLen(strCassette_controlJobID_Get_out.contorolJobID.identifier) == 0");
                if ( findFlag == TRUE )
                {
                    PPT_METHODTRACE_V1( "", "findFlag == FALSE" );
//P4100425 start
                    PPT_SET_MSG_RC_KEY2( strLotsInfoForStartReservationInqResult,
                                         MSG_ALREADY_RESERVED_PORTGRP, RC_ALREADY_RESERVED_PORTGRP,
                                         strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[j].portGroupID,
                                         strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[j].controlJobID.identifier );
//P4100425 end
//P4100425                    PPT_SET_MSG_RC_KEY( strLotsInfoForStartReservationInqResult,
//P4100425                                        MSG_ALREADY_RESERVED_PORTGRP,
//P4100425                                        RC_ALREADY_RESERVED_PORTGRP,
//P4100425                                        strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[j].controlJobID.identifier );
                    return( RC_ALREADY_RESERVED_PORTGRP );
                }
            }
        }

//INN-R-170009        /*---------------------*/  // This implementation is not good from
//INN-R-170009        /*   Get PortGroupID   */  // responce point of view. In the near
//INN-R-170009        /*---------------------*/  // future, this logic must be replaced.
//INN-R-170009        objectIdentifier savePortGroupID;
//INN-R-170009        objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
//INN-R-170009        rc = equipment_portInfo_Get(strEquipment_portInfo_Get_out, strObjCommonIn, equipmentID);
//INN-R-170009        if ( rc != RC_OK )
//INN-R-170009        {
//INN-R-170009            PPT_METHODTRACE_V1("", "equipment_portInfo_Get() != RC_OK");
//INN-R-170009            strLotsInfoForStartReservationInqResult.strResult = strEquipment_portInfo_Get_out.strResult;
//INN-R-170009            return(rc);
//INN-R-170009        }
//INN-R-170009        CORBA::Long EPSLength = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
//INN-R-170009        for ( i = 0; i < EPSLength; i++ )
//INN-R-170009        {
//INN-R-170009            PPT_METHODTRACE_V3("", "loop to strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length()",EPSLength,i);
//INN-R-170009            CORBA::String_var EPSIdent;
//INN-R-170009            CORBA::String_var InCIDIdent;
//INN-R-170009            EPSIdent = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].loadedCassetteID.identifier;
//INN-R-170009//*******************************
//INN-R-170009// Is 0 really all right?
//INN-R-170009            InCIDIdent = strStartCassette[0].cassetteID.identifier;
//INN-R-170009//*******************************
//INN-R-170009            if ( CIMFWStrCmp( EPSIdent, InCIDIdent ) == 0 )
//INN-R-170009            {
//INN-R-170009                PPT_METHODTRACE_V1("", "strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].loadedCassetteID == in-parm' scassetteID[0]");
//INN-R-170009                savePortGroupID.identifier = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].portGroup;
//INN-R-170009                break;
//INN-R-170009            }
//INN-R-170009        }

//INN-R-170009        /*-------------------------------------------------*/
//INN-R-170009        /*   Get from APCInterface AdjustRecipeParameter   */
//INN-R-170009        /*-------------------------------------------------*/
//INN-R-170009        PPT_METHODTRACE_V1("", "Get from APCMgr_SendRecipeParamInq");
//INN-R-170009        objAPCMgr_SendRecipeParamInq_out strAPCMgr_SendRecipeParamInq_out;
//INN-R-170009        rc = APCMgr_SendRecipeParamInq( strAPCMgr_SendRecipeParamInq_out,
//INN-R-170009                                             strObjCommonIn,
//INN-R-170009                                             equipmentID,
//INN-R-170009                                             savePortGroupID.identifier,
//INN-R-170009                                             saveControlJobID,
//INN-R-170009                                             strLotsInfoForStartReservationInqResult.strStartCassette );

//INN-R-170009        if ( rc != RC_OK )
//INN-R-170009        {
//INN-R-170009            PPT_METHODTRACE_V1("", "APCMgr_SendRecipeParamInq() != RC_OK");
//INN-R-170009            strLotsInfoForStartReservationInqResult.strResult = strAPCMgr_SendRecipeParamInq_out.strResult;
//INN-R-170009            return ( rc );
//INN-R-170009        }

//INN-R-170009        strLotsInfoForStartReservationInqResult.strStartCassette = strAPCMgr_SendRecipeParamInq_out.strStartCassette;
        // INN-R-170009 Add Start//
        csObjAPCMgr_SendLithoRecommendInfoInq_in  strObjAPCMgr_SendLithoRecommendInfoInq_in;
        csObjAPCMgr_SendLithoRecommendInfoInq_out strObjAPCMgr_SendLithoRecommendInfoInq_out;
        strObjAPCMgr_SendLithoRecommendInfoInq_in.equipmentID      = equipmentID;
        strObjAPCMgr_SendLithoRecommendInfoInq_in.action           = CIMFWStrDup ( CS_APC_COMBINE_FLAG_ACTION_RESV_RECOMMEND );
        strObjAPCMgr_SendLithoRecommendInfoInq_in.strStartCassette = strLotsInfoForStartReservationInqResult.strStartCassette;
        rc = cs_APCMgr_SendLithoRecommendInfoInq( strObjAPCMgr_SendLithoRecommendInfoInq_out,
                                        strObjCommonIn,
                                        strObjAPCMgr_SendLithoRecommendInfoInq_in );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cs_APCMgr_SendLithoRecommendInfoInq() != RC_OK");
            strLotsInfoForStartReservationInqResult.strResult = strObjAPCMgr_SendLithoRecommendInfoInq_out.strResult;
            return ( rc );
        }
        //INN-R-170009 Add End//

    }
//P4000394 rollback from "Change APC I/F place" end
//D4000014 end

    traceSampledStartCassette( strLotsInfoForStartReservationInqResult.strStartCassette );  //D9000003

    /*-----------------------*/
    /*   Set out structure   */
    /*-----------------------*/
//D9000003 add start
    if ( slotmapConflictWarnFlag == TRUE )
    {
        PPT_SET_MSG_RC_KEY( strLotsInfoForStartReservationInqResult, MSG_SMPL_SLOTMAP_CONFLICT_WARN, RC_SMPL_SLOTMAP_CONFLICT_WARN, smplMessage.str());
        smplMessage.rdbuf()->freeze(0);
        PPT_METHODTRACE_V2("","txLotsInfoForStartReservationInq MSG", strLotsInfoForStartReservationInqResult.strResult.messageText);
        PPT_METHODTRACE_EXIT("PPTManager_i::txLotsInfoForStartReservationInq ");
        return RC_SMPL_SLOTMAP_CONFLICT_WARN;
    }
    else
    {
//D9000003 add end
        SET_MSG_RC( strLotsInfoForStartReservationInqResult, MSG_OK, RC_OK );  //D9000003 Indentation is adjusted.
    }  //D9000003
    PPT_METHODTRACE_EXIT("PPTManager_i::txLotsInfoForStartReservationInq ");
    return( rc );

}

//D9000003 add start
//************************************************************************************
// traceSampledStartCassette
//************************************************************************************
void traceSampledStartCassette( const pptStartCassetteSequence& strStartCassette )
{
    PPT_METHODTRACE_ENTRY( "PPTManager_i::txLotsInfoForStartReservationInq:traceSampledStartCassette" );
    PPT_METHODTRACE_V1( "", "debug StartCassette ********************************************************" );

    CORBA::Long i, j, k;
    CORBA::Long len1, len2, len3;

    len1 = strStartCassette.length();
    PPT_METHODTRACE_V2( "", "strStartCassette.length----->", len1 );
    for ( i = 0; i < len1; i++ )
    {
        PPT_METHODTRACE_V2( "", "loadSequenceNumber_________________________________", strStartCassette[i].loadSequenceNumber );
        PPT_METHODTRACE_V2( "", "cassetteID_________________________________________", strStartCassette[i].cassetteID.identifier );
        PPT_METHODTRACE_V2( "", "loadPurposeType____________________________________", strStartCassette[i].loadPurposeType );
        PPT_METHODTRACE_V2( "", "loadPortID_________________________________________", strStartCassette[i].loadPortID.identifier );
        PPT_METHODTRACE_V2( "", "unloadPortID_______________________________________", strStartCassette[i].unloadPortID.identifier );

        len2 = strStartCassette[i].strLotInCassette.length();
        PPT_METHODTRACE_V2( "", "strStartCassette[i].strLotInCassette.length----->", len2 );
        for ( j = 0; j < len2; j++ )
        {
//D9000001PPT_METHODTRACE_V2("", "  operationStartFlag_______________________________", (long)strStartCassette[i].strLotInCassette[j].operationStartFlag);
//D9000001PPT_METHODTRACE_V2("", "  monitorLotFlag___________________________________", (long)strStartCassette[i].strLotInCassette[j].monitorLotFlag);
            PPT_METHODTRACE_V2( "", "  operationStartFlag_______________________________", (CORBA::Long) strStartCassette[i].strLotInCassette[j].operationStartFlag ); //D9000001
            PPT_METHODTRACE_V2( "", "  monitorLotFlag___________________________________", (CORBA::Long) strStartCassette[i].strLotInCassette[j].monitorLotFlag ); //D9000001
            PPT_METHODTRACE_V2( "", "  lotID____________________________________________", strStartCassette[i].strLotInCassette[j].lotID.identifier );
            PPT_METHODTRACE_V2( "", "  lotType__________________________________________", strStartCassette[i].strLotInCassette[j].lotType );
            PPT_METHODTRACE_V2( "", "  subLotType_______________________________________", strStartCassette[i].strLotInCassette[j].subLotType );
            PPT_METHODTRACE_V2( "", "    logicalRecipeID________________________________", strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID.identifier );
            PPT_METHODTRACE_V2( "", "    machineRecipeID________________________________", strStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID.identifier );
            PPT_METHODTRACE_V2( "", "    physicalRecipeID_______________________________", strStartCassette[i].strLotInCassette[j].strStartRecipe.physicalRecipeID );

            len3 = strStartCassette[i].strLotInCassette[j].strLotWafer.length();
            PPT_METHODTRACE_V2( "", "strStartCassette[i].strLotInCassette[j].strLotWafer.length----->", len3 );
            for ( k = 0; k < len3; k++ )
            {
                PPT_METHODTRACE_V2( "", "    waferID________________________________________", strStartCassette[i].strLotInCassette[j].strLotWafer[k].waferID.identifier );
                PPT_METHODTRACE_V2( "", "    slotNumber_____________________________________", strStartCassette[i].strLotInCassette[j].strLotWafer[k].slotNumber );
//D9000001PPT_METHODTRACE_V2("", "    controlWaferFlag_______________________________", (long)strStartCassette[i].strLotInCassette[j].strLotWafer[k].controlWaferFlag);
//D9000001PPT_METHODTRACE_V2("", "    processJobExecFlag_____________________________", (long)strStartCassette[i].strLotInCassette[j].strLotWafer[k].processJobExecFlag);
                PPT_METHODTRACE_V2( "", "    controlWaferFlag_______________________________", (CORBA::Long) strStartCassette[i].strLotInCassette[j].strLotWafer[k].controlWaferFlag ); //D9000001
                PPT_METHODTRACE_V2( "", "    processJobExecFlag_____________________________", (CORBA::Long) strStartCassette[i].strLotInCassette[j].strLotWafer[k].processJobExecFlag ); //D9000001
            }
            PPT_METHODTRACE_V2( "", "  productID________________________________________", strStartCassette[i].strLotInCassette[j].productID.identifier );
            PPT_METHODTRACE_V2( "", "    routeID________________________________________", strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID.identifier );
            PPT_METHODTRACE_V2( "", "    operationID____________________________________", strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationID.identifier );
            PPT_METHODTRACE_V2( "", "    operationNumber________________________________", strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber );
            PPT_METHODTRACE_V2( "", "    passCount______________________________________", strStartCassette[i].strLotInCassette[j].strStartOperationInfo.passCount );
        }
    }

    PPT_METHODTRACE_V1( "", "****************************************************************************" );
}

//D9000003 add end


