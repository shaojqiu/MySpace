#ifndef lint
static char *sccsid =  "@(#) 1.2 superpos/src/spppt/source/posppt/pptmgr/txmethods/txLotMfgOrderChangeReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 8/23/07 14:30:39 [ 8/23/07 14:30:40 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// SiView
// Name: txLotMfgOrderChangeReq.cpp
//

//INN-R170003#include "pptmgr.hpp"
#include "cs_pptmgr.hpp"  //INN-R170003


#include "pcas.hh"     //P3100315
#include "pctrlj.hh"   //P3100315

// Class: PPTManager
//
// Service: txLotMfgOrderChangeReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2001/05/08 P3100315 K.Matsuei      Add Check Logic for LotSchdlChangeReq,
//                                    LotMfgOrderChangeReq, txCassetteUsageCountResetReq
// 2001/08/13 P4000090 K.Kido         Set return structure in sequence
// 2002/06/11 P4100536 T.Nishimura    Source Check : Wrong reference to dimension.
// 2002/07/04 P4200025 T.Nishimura    Source Check : return without message.
// 2002/10/08 D4200039 H.Adachi       Replace Direct FW Calling.
// 2003/09/09 P5000145 H.Adachi       Fix Message and Message Macro mismatch.
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2007/08/23 D9000056 H.Hotta        Add check logic for InPostProcessFlag.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
// 2008/11/02 DSIV00000214 S.Miyata       Multi Fab Transfer Support
// 2010/10/13 DSIV00002435 M.Ogawa        Support SubLotType change by Schedule Change Reservation
// 2011/05/26 PSIV00003236 Li.Seal        Object Lock mechanism is lack, and it caused production Lot issue.
// 2012/11/19 PSN000058951 M.Ogawa        Result isn't set for a lot in error case
// 2013/05/09 DSN000071674 C.Mo           Remove part of the EI state limitation
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/27 INN-R170003  SF.Peng        Add new transfer state PI/PO to control FOUP location
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptLotMfgOrderChangeReqResult& strLotMfgOrderChangeReqResult
//     const pptObjCommonIn& strObjCommonIn
//     CORBA::Long seqIx
//     const pptChangedLotAttributesSequence& strChangedLotAttributes
//     const char * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

//INN-R170003 CORBA::Long PPTManager_i::txLotMfgOrderChangeReq (pptLotMfgOrderChangeReqResult& strLotMfgOrderChangeReqResult,
CORBA::Long CS_PPTManager_i::txLotMfgOrderChangeReq (pptLotMfgOrderChangeReqResult& strLotMfgOrderChangeReqResult,  //INN-R170003
                                                  const pptObjCommonIn& strObjCommonIn,
                                                  CORBA::Long seqIx,
                                                  const pptChangedLotAttributesSequence& strChangedLotAttributes,
//D6000025                                                   const char * claimMemo,
//D6000025                                                   CORBA::Environment &IT_env )
                                                  const char * claimMemo //D6000025
                                                  CORBAENV_LAST_CPP )    //D6000025
{
//INN-R170003    PPT_METHODTRACE_ENTRY("PPTManager_i:: txLotMfgOrderChangeReq ")
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txLotMfgOrderChangeReq ") //INN-R170003
    CORBA::Long rc = RC_OK;

    //P4100536 add start
    // Check length of In-Parameter
    if(seqIx >= strChangedLotAttributes.length() || seqIx >= strLotMfgOrderChangeReqResult.strChangeLotReturn.length())
    {
        SET_MSG_RC(strLotMfgOrderChangeReqResult, MSG_INVALID_PARAMETER, RC_INVALID_PARAMETER); //P4200025 add
        strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].lotID = strChangedLotAttributes[seqIx].lotID;           //PSN000058951
        strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].returnCode = ConvertLongtoString(RC_INVALID_PARAMETER); //PSN000058951
        return RC_INVALID_PARAMETER;
    }
    //P4100536 add end
    
//PSIV00003236 add start
    //--------------------------------
    //   Lock objects to be updated
    //--------------------------------
    objObject_Lock_out strObject_Lock_out;
    rc = object_Lock( strObject_Lock_out, strObjCommonIn,strChangedLotAttributes[seqIx].lotID, SP_ClassName_PosLot );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK ", rc);
        strLotMfgOrderChangeReqResult.strResult = strObject_Lock_out.strResult;
        strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].lotID = strChangedLotAttributes[seqIx].lotID;   //PSN000058951
        strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].returnCode = ConvertLongtoString(rc);           //PSN000058951
        return( rc );
    }
//PSIV00003236 add end
//P3100315 start
    char * methodName = NULL;
    PPT_METHODTRACE_V1("", "P3100315 start ##################################################");

//DSIV00002435 add start
    CORBA::Boolean  bUpdateSubLotType = FALSE;
    if( 0 < CIMFWStrLen(strChangedLotAttributes[seqIx].subLotType) )
    {
        PPT_METHODTRACE_V1("", "subLotType is null");
        bUpdateSubLotType = TRUE;
    }
    //---------------------------------
    //   SubLotType is updated.
    //   Check for Control job existence and 
    //   cassette transfer status is needed.
    //---------------------------------
    if( TRUE == bUpdateSubLotType )
    {
//DSIV00002435 add end
//DSN000071674 add start
        CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );
        if ( 0 == lotOperationEIcheck )
        {
            //----------------------------------
            //   Check Lot's Control Job ID
            //----------------------------------
            objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
            rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, strChangedLotAttributes[seqIx].lotID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "lot_controlJobID_Get() != RC_OK", rc);
                strLotMfgOrderChangeReqResult.strResult = strLot_controlJobID_Get_out.strResult;
                return( rc );
            }
            if ( 0 == CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) )
            {
                PPT_METHODTRACE_V1("", "strLot_controlJobID_Get_out.controlJobID.identifier == 0");
            }
            else
            {
                PPT_METHODTRACE_V1("", "strLot_controlJobID_Get_out.controlJobID.identifier != 0");
                PPT_SET_MSG_RC_KEY2( strLotMfgOrderChangeReqResult,
                                     MSG_LOT_CTLJOBID_FILLED,
                                     RC_LOT_CTLJOBID_FILLED,
                                     strChangedLotAttributes[seqIx].lotID.identifier,
                                     strLot_controlJobID_Get_out.controlJobID.identifier );
                return RC_LOT_CTLJOBID_FILLED;
            }
        }
        else
        {
//DSN000071674 add end
            /*--------------------*/
            /*   get cassetteID   */
            /*--------------------*/
            PPT_METHODTRACE_V1("", "get cassetteID");
            objLot_cassette_Get_out strLot_cassette_Get_out;
            rc = lot_cassette_Get( strLot_cassette_Get_out, strObjCommonIn, strChangedLotAttributes[seqIx].lotID );

            if (rc == RC_OK)
            {
                objectIdentifier cassetteID = strLot_cassette_Get_out.cassetteID;

                //D4200039 Add Start
                //------------------------------
                // Check Cassette Xfer Stat
                //------------------------------
                CORBA::String_var strCassetteXferState;
                objCassette_transferState_Get_out strCassette_transferState_Get_out;

                rc = cassette_transferState_Get(strCassette_transferState_Get_out,strObjCommonIn ,cassetteID);

                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "rc != RC_OK")
                    strLotMfgOrderChangeReqResult.strResult = strCassette_transferState_Get_out.strResult;
                    strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].lotID = strChangedLotAttributes[seqIx].lotID;   //PSN000058951
                    strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].returnCode = ConvertLongtoString(rc);           //PSN000058951
                    return(rc);
                }
                strCassetteXferState = strCassette_transferState_Get_out.transferState;

                PPT_METHODTRACE_V2("", "CassetteXferStatus id", strCassetteXferState );


//INN-R170003                if( 0 == CIMFWStrCmp(strCassetteXferState, SP_TransState_EquipmentIn) )
//INN-R170003 Add Start
                if( CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 ||
                    CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentOut) == 0 ||
                    CIMFWStrCmp(strCassette_transferState_Get_out.transferState, CS_TRANS_STATE_PORT_IN) == 0 )
//INN-R170003 Add End
                {
//INN-R170003                    PPT_METHODTRACE_V1("", "##### strCassetteXferState == SP_TransState_EquipmentIn");
                    PPT_METHODTRACE_V2("", "##### strCassetteXferState == ", strCassette_transferState_Get_out.transferState); //INN-R170003
                    PPT_SET_MSG_RC_KEY2( strLotMfgOrderChangeReqResult,
                                         MSG_INVALID_CAST_XFERSTAT,
                                         RC_INVALID_CAST_XFERSTAT,
                                         strCassetteXferState,
                                         cassetteID.identifier );
                    strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].lotID = strChangedLotAttributes[seqIx].lotID;               //PSN000058951
                    strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].returnCode = ConvertLongtoString(RC_INVALID_CAST_XFERSTAT); //PSN000058951
                    return RC_INVALID_CAST_XFERSTAT;
                }

                //---------------------------------
                //   Get Cassette's ControlJobID
                //---------------------------------
                objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

                rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                                strObjCommonIn,
                                                cassetteID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
                    strLotMfgOrderChangeReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
                    strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].lotID = strChangedLotAttributes[seqIx].lotID;   //PSN000058951
                    strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].returnCode = ConvertLongtoString(rc);           //PSN000058951
                    return( rc );
                }

                if ( CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) > 0 )
                {
                    PPT_METHODTRACE_V1( "", "len(controlJobID) > 0" );
                    SET_MSG_RC( strLotMfgOrderChangeReqResult,
                                MSG_CAST_CTRLJOBID_FILLED,
                                RC_CAST_CTRLJOBID_FILLED );
                    strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].lotID = strChangedLotAttributes[seqIx].lotID;               //PSN000058951
                    strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].returnCode = ConvertLongtoString(RC_CAST_CTRLJOBID_FILLED); //PSN000058951
                    return RC_CAST_CTRLJOBID_FILLED;
                }
                else
                {
                    PPT_METHODTRACE_V1("", "strCassette_controlJobID_Get_out.controlJobID.identifier is nil") ;
                }
                //D4200039 Add End

//D4200039        PosCassette_var aPosCassette;
//D4200039        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aPosCassette, cassetteID,
//D4200039                                               strLotMfgOrderChangeReqResult, txLotMfgOrderChangeReq );
//D4200039
//D4200039        if ( ! CORBA::is_nil( aPosCassette ) )
//D4200039        {
//D4200039          PPT_METHODTRACE_V1("", "aPosCassette is not nil");
//D4200039            /*----------------------*/
//D4200039            /*   check XferStetus   */
//D4200039            /*----------------------*/
//D4200039          PPT_METHODTRACE_V1("", "-----------check XferStetus-----------");
//D4200039            CORBA::String_var strCassetteXferState;
//D4200039            try
//D4200039            {
//D4200039                strCassetteXferState = aPosCassette->getTransportState();
//D4200039            }
//D4200039            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)
//D4200039
//D4200039          PPT_METHODTRACE_V2("", "strCassetteXferState--->", strCassetteXferState);
//D4200039            if( 0 == CIMFWStrCmp(strCassetteXferState, SP_TransState_EquipmentIn) )
//D4200039            {
//D4200039              PPT_METHODTRACE_V1("", "##### strCassetteXferState == SP_TransState_EquipmentIn");
//D4200039                strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].returnCode = ConvertLongtoString(RC_INVALID_CAST_XFERSTAT);        //P4000090
//D4200039                strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].lotID = strChangedLotAttributes[seqIx].lotID;                      //P4000090
//D4200039                PPT_SET_MSG_RC_KEY2( strLotMfgOrderChangeReqResult,
//D4200039                                     MSG_INVALID_CAST_XFERSTAT,
//D4200039                                     RC_INVALID_CAST_XFERSTAT,
//D4200039                                     strCassetteXferState,
//D4200039                                     cassetteID.identifier );
//D4200039
//D4200039                return RC_INVALID_CAST_XFERSTAT;
//D4200039            }
//D4200039
//D4200039            /*------------------------*/
//D4200039            /*   check controlJobID   */
//D4200039            /*------------------------*/
//D4200039          PPT_METHODTRACE_V1("", "-----------check controlJobID-----------");
//D4200039            PosControlJob_var aPosControlJob;
//D4200039            try
//D4200039            {
//D4200039                aPosControlJob = aPosCassette->getControlJob();
//D4200039            }
//D4200039            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)
//D4200039
//D4200039            if ( ! CORBA::is_nil(aPosControlJob) )
//D4200039            {
//D4200039              PPT_METHODTRACE_V1("", "##### aPosControlJob is not nil");
//D4200039
//D4200039                SET_MSG_RC( strLotMfgOrderChangeReqResult,
//D4200039                            MSG_CAST_CTRLJOBID_FILLED,
//D4200039                            RC_CAST_CTRLJOBID_FILLED );
//D4200039
//D4200039                strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].returnCode = ConvertLongtoString(RC_CAST_CTRLJOBID_FILLED);        //P4000090
//D4200039                strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].lotID = strChangedLotAttributes[seqIx].lotID;                      //P4000090
//D4200039                return RC_CAST_CTRLJOBID_FILLED;
//D4200039            }
//D4200039            else
//D4200039            {
//D4200039              PPT_METHODTRACE_V1("", "aPosControlJob is nil");
//D4200039            }
//D4200039        }
//D4200039        else
//D4200039        {
//D4200039          PPT_METHODTRACE_V1("", "aPosCassette is nil") ;
//D4200039        }
            }
        } //DSN000071674
        PPT_METHODTRACE_V1("", "P3100315 end ####################################################");
//P3100315 end
    }// if( TRUE == bUpdateSubLotType )                 //DSIV00002435
//D9000056 add start
    PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
    //----------------------------------
    //  Get InPostProcessFlag of Lot
    //----------------------------------
    objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
    objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
    strLot_inPostProcessFlag_Get_in.lotID = strChangedLotAttributes[seqIx].lotID;

    rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                    strObjCommonIn,
                                    strLot_inPostProcessFlag_Get_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
        strLotMfgOrderChangeReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
        strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].lotID = strChangedLotAttributes[seqIx].lotID;   //PSN000058951
        strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].returnCode = ConvertLongtoString(rc);           //PSN000058951
        return( rc );
    }

//DSIV00000214 add start
    //-----------------------------------------------------------
    // Check lot interFabXferState
    //-----------------------------------------------------------
    objLot_interFabXferState_Get_out strLot_interFabXferState_Get_out;
    objLot_interFabXferState_Get_in  strLot_interFabXferState_Get_in;
    strLot_interFabXferState_Get_in.lotID = strChangedLotAttributes[seqIx].lotID;
    rc = lot_interFabXferState_Get( strLot_interFabXferState_Get_out,    
                                    strObjCommonIn,
                                    strLot_interFabXferState_Get_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_interFabXferState_Get() != RC_OK");
        strLotMfgOrderChangeReqResult.strResult = strLot_interFabXferState_Get_out.strResult;
        strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].lotID = strChangedLotAttributes[seqIx].lotID;   //PSN000058951
        strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].returnCode = ConvertLongtoString(rc);           //PSN000058951
        return( rc );
    }

    //-----------------------------------------------------------
    // "Transferring"
    //-----------------------------------------------------------
    if( CIMFWStrCmp(strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Transferring) == 0 )
    {
         PPT_METHODTRACE_V1("", "interFabXferState == Transferring");
         PPT_SET_MSG_RC_KEY2( strLotMfgOrderChangeReqResult,
                              MSG_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ,
                              RC_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ,
                              strChangedLotAttributes[seqIx].lotID.identifier,
                              strLot_interFabXferState_Get_out.interFabXferState );
         strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].lotID = strChangedLotAttributes[seqIx].lotID;                                  //PSN000058951
         strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].returnCode = ConvertLongtoString(RC_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ);   //PSN000058951
         return( RC_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ );
    }
//DSIV00000214 add end

    //----------------------------------------------
    //  If Lot is in post process, returns error
    //----------------------------------------------
    if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
    {
        PPT_METHODTRACE_V1("", "Lot is in post process.");

        if ( CIMFWStrCmp(strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Required) != 0 )    //DSIV00000214
        {    //DSIV00000214
            PPT_METHODTRACE_V1("", "interFabXferState != Required");    //DSIV00000214
//DSIV00000201 Add Start
            /*---------------------------*/
            /* Get UserGroupID By UserID */
            /*---------------------------*/
            objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
            rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                             strObjCommonIn,
                                             strObjCommonIn.strUser.userID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
                strLotMfgOrderChangeReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
                strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].lotID = strChangedLotAttributes[seqIx].lotID;   //PSN000058951
                strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].returnCode = ConvertLongtoString(rc);           //PSN000058951
                return( rc );
            }
            objectIdentifierSequence userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
            CORBA::ULong userGroupIDsLen = userGroupIDs.length();
            PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);
            
            CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
            PPT_METHODTRACE_V2("", "extPostProc", extPostProc);
            
            CORBA::ULong nCnt = 0;
            for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
            {
                PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
                if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
                {
                    PPT_METHODTRACE_V1("", "# External Post Process User!");
                    break;
                }
                
            }
            if (nCnt == userGroupIDsLen)
            {
                PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
                PPT_SET_MSG_RC_KEY( strLotMfgOrderChangeReqResult,
                                    MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                    strChangedLotAttributes[seqIx].lotID.identifier );
                strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].lotID = strChangedLotAttributes[seqIx].lotID;           //PSN000058951
                strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].returnCode = ConvertLongtoString(RC_LOT_INPOSTPROCESS); //PSN000058951
                return( RC_LOT_INPOSTPROCESS );
            }   //DSIV00000201
        }    //DSIV00000214
    }
//D9000056 add end

    /*------------------------------------------------------------------------*/
    /*   Register Product Request                                             */
    /*------------------------------------------------------------------------*/

    objLot_ChangeOrder_out  strLot_ChangeOrder_out;
    rc = lot_ChangeOrder(strLot_ChangeOrder_out,strObjCommonIn,strChangedLotAttributes[seqIx]);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "rc != RC_OK")
        strLotMfgOrderChangeReqResult.strResult = strLot_ChangeOrder_out.strResult;
        strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].lotID = strChangedLotAttributes[seqIx].lotID;
        strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].returnCode = ConvertLongtoString(rc);
        return(rc);
    }

    objLotChangeEvent_Make_out strLotChangeEvent_Make_out;
//DSIV00002435    rc = lotChangeEvent_Make(strLotChangeEvent_Make_out, strObjCommonIn, "TXOMC003", strChangedLotAttributes[seqIx].lotID.identifier,"0", strChangedLotAttributes[seqIx].lotOwner.identifier,
//DSIV00002435                             strChangedLotAttributes[seqIx].manufacturingOrderNumber, strChangedLotAttributes[seqIx].customerCode, strChangedLotAttributes[seqIx].lotComment, "0", "", "", "", "", claimMemo );
    rc = lotChangeEvent_Make(strLotChangeEvent_Make_out, strObjCommonIn, "TXOMC003", strChangedLotAttributes[seqIx].lotID.identifier, strChangedLotAttributes[seqIx].externalPriority, strChangedLotAttributes[seqIx].lotOwner.identifier,  //DSIV00002435
                             strChangedLotAttributes[seqIx].manufacturingOrderNumber, strChangedLotAttributes[seqIx].customerCode, strChangedLotAttributes[seqIx].lotComment, "0", "", "", "", "", claimMemo );                             //DSIV00002435
    //DSIV00002435 add strChangedLotAttributes[seqIx].externalPriority

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "rc != RC_OK")
//P5000145        PPT_SET_MSG_RC_KEY(strLotMfgOrderChangeReqResult, MSG_FAIL_MAKE_HISTORY, rc, strChangedLotAttributes[seqIx].lotID.identifier);
        SET_MSG_RC( strLotMfgOrderChangeReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145
        strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].lotID = strChangedLotAttributes[seqIx].lotID;
        strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].returnCode = ConvertLongtoString(rc);
        return(rc);
    }

    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/

    strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].lotID = strChangedLotAttributes[seqIx].lotID;
    strLotMfgOrderChangeReqResult.strChangeLotReturn[seqIx].returnCode = ConvertLongtoString(RC_OK);

    SET_MSG_RC(strLotMfgOrderChangeReqResult, MSG_OK, RC_OK);


//INN-R170003    PPT_METHODTRACE_EXIT("PPTManager_i:: txLotMfgOrderChangeReq ")
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txLotMfgOrderChangeReq ") //INN-R170003
    return(RC_OK);
}

