#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/txLotsInfoForOpeStartForInternalBufferInq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:26:11 [ 7/13/07 21:26:12 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: txLotsInfoForOpeStartForInternalBufferInq.cpp
//

#include "cs_pptmgr.hpp"

extern void traceSampledStartCassette( const pptStartCassetteSequence& strStartCassette );    //D9000003 for Cassette trace

// Class: PPTManager
//
// Service: txLotsInfoForOpeStartForInternalBufferInq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2001/07/02 D4000015 H.Katoh        Initial Release (R4.0)
// 2001/08/29 D4000015 O.Sugiyama     Add in-para log
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2006/12/01 D8000024 H.Mutoh        Flexible Process Condition Change (R80)
// 2007/01/23 P8000072 M.Murata       Fix handling logic. (FPC)
// 2007/04/02 D8000207 M.Murata       Add changing logic processJobExecFlag.
// 2007/04/20 D9000001 H.Murakami     64bit support.
// 2007/06/03 D9000003 M.Nakano       Modify changing logic processJobExecFlag for wafer sampling operation.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009-11-11 PSIV00001581 R.Iriguchi     Fix memory leak
// 2010/06/25 PSIV00002149 S.Kawabe       Start Lot Reservation fails when a lot in FOUP is not on a route.

//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/27 INN-R170009  Liu Xinxin     Litho APC Enahncement


// Description:
//
// Return:
//     long
//
// Parameter:
//    pptLotsInfoForOpeStartForInternalBufferInqResult&  strLotsInfoForOpeStartForInternalBufferInqResult
//    const pptObjCommonIn&                              strObjCommonIn
//    const objectIdentifier&                            equipmentID
//    const objectIdentifierSequence&                    cassetteID
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//      TXTRQ027

CORBA::Long CS_PPTManager_i::txLotsInfoForOpeStartForInternalBufferInq (
            pptLotsInfoForOpeStartForInternalBufferInqResult&  strLotsInfoForOpeStartForInternalBufferInqResult,
            const pptObjCommonIn&                              strObjCommonIn,
            const objectIdentifier&                            equipmentID,
//D6000025             const objectIdentifierSequence&                    cassetteID,
//D6000025             CORBA::Environment &                               IT_env )
            const objectIdentifierSequence&                    cassetteID //D6000025
            CORBAENV_LAST_CPP )                                           //D6000025
{
    PPT_METHODTRACE_ENTRY( "PPTManager_i::txLotsInfoForOpeStartForInternalBufferInq " );

    CORBA::Long rc = RC_OK;

    PPT_METHODTRACE_V2( "", "in para equipmentID        ", equipmentID.identifier );
    {
        CORBA::Long nLen = cassetteID.length();
        PPT_METHODTRACE_V2( "", "in para cassetteID.length()", nLen );
        for ( CORBA::Long i = 0; i < nLen; i++ )
        {
            PPT_METHODTRACE_V3( "", "in para   cassetteID       ", i, cassetteID[i].identifier );
        }
    }

    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    //   Object Lock Process
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    //   Check Process
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","equipment_categoryVsTxID_CheckCombination() returned error.");

        strLotsInfoForOpeStartForInternalBufferInqResult.strResult
            = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return (rc);
    }

    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    //   Main Process
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

    //--------------------------------------------------
    //   Get Equipment's Start Reserved ControlJob IDs
    //--------------------------------------------------
    PPT_METHODTRACE_V1("","Get Equipment's Start Reserved ControlJob ID.");

    objEquipment_reservedControlJobID_Get_out strEquipment_reservedControlJobID_Get_out;
    rc = equipment_reservedControlJobID_Get(strEquipment_reservedControlJobID_Get_out,
                                            strObjCommonIn,
                                            equipmentID);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","equipment_reservedControlJobID_Get() returned error.");

        strLotsInfoForOpeStartForInternalBufferInqResult.strResult
            = strEquipment_reservedControlJobID_Get_out.strResult;
        return (rc);
    }

    //--------------------------------------------------
    //   Get Input Cassettes' Start Reserved ControlJob IDs
    //--------------------------------------------------
    PPT_METHODTRACE_V1("","Get Input Cassettes' Start Reserved ControlJob IDs.");

    CORBA::Long i = 0;
    CORBA::Long nLen = cassetteID.length();

    objectIdentifierSequence cassetteControlJobIDs;
    cassetteControlJobIDs.length( nLen );

    for ( i = 0; i < nLen; i++ )
    {
        objCassette_controlJobID_Get_out   strCassette_controlJobID_Get_out;
        rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out, strObjCommonIn, cassetteID[i] );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() returned error." );

            strLotsInfoForOpeStartForInternalBufferInqResult.strResult = strCassette_controlJobID_Get_out.strResult;
            return (rc);
        }
        else
        {
            cassetteControlJobIDs[i] = strCassette_controlJobID_Get_out.controlJobID;
        }
    }
    for ( i = 0; i < nLen; i++ )
    {
        PPT_METHODTRACE_V2( "", "Cassette ID   ", cassetteID[i].identifier );
        PPT_METHODTRACE_V2( "", "Control Job ID", cassetteControlJobIDs[i].identifier );
    }

    //--------------------------------------------------
    //   Check all control job of input cassette is the same or not
    //--------------------------------------------------
    for ( i = 1; i < nLen; i++ )
    {
        if ( CIMFWStrCmp( cassetteControlJobIDs[0].identifier, cassetteControlJobIDs[i].identifier ) )
        {
            PPT_METHODTRACE_V1( "", "Input Cassette has different control job IDs. Cannot start operation at the same timing." );

            SET_MSG_RC( strLotsInfoForOpeStartForInternalBufferInqResult,
                        MSG_UNMATCH_CASSETTE_COMBINATION,
                        RC_UNMATCH_CASSETTE_COMBINATION );
            return RC_UNMATCH_CASSETTE_COMBINATION;
        }
    }

    //--------------------------------------------------
    //   Check cassette's control job id is also assigned for equipment or not.
    //--------------------------------------------------
    if ( CIMFWStrLen( cassetteControlJobIDs[0].identifier ) )
    {
        PPT_METHODTRACE_V1( "", "Cassette has Control Job ID. check that ID is assigned to equipment or not." );

        CORBA::Boolean bControlJobFound = FALSE;
        CORBA::Long nEqpControlJobIDLen = strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo.length();
        for ( i = 0; i < nEqpControlJobIDLen; i++ )
        {
            if ( 0 == CIMFWStrCmp( cassetteControlJobIDs[0].identifier, strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[i].controlJobID.identifier ) )
            {
                PPT_METHODTRACE_V1( "", "Cassette's Control Job ID is also assigned to equipment. OK" );
                bControlJobFound = TRUE;
                break;
            }
        }
        if ( bControlJobFound == FALSE )
        {
            PPT_METHODTRACE_V1( "", "NG! NG! NG! Cassette's Control Job ID is not assigned to equipment. NG! NG! NG!" );

            SET_MSG_RC( strLotsInfoForOpeStartForInternalBufferInqResult,
                        MSG_UNMATCH_CONTROLJOB_EQP_VS_CAST,
                        RC_UNMATCH_CONTROLJOB_EQP_VS_CAST );
            return RC_UNMATCH_CONTROLJOB_EQP_VS_CAST;
        }
    }

    objectIdentifier saveControlJobID = cassetteControlJobIDs[0];

//Comment Out by Katoh    //-------------------------------------------------
//Comment Out by Katoh    //
//Comment Out by Katoh    //   Get Cassette's Start Reserved ControlJob ID
//Comment Out by Katoh    //   And check that the same control job id is
//Comment Out by Katoh    //   assigned for the equipment or not.
//Comment Out by Katoh    //   And check whether all control job of input
//Comment Out by Katoh    //   cassette is same or not.
//Comment Out by Katoh    //
//Comment Out by Katoh    //-------------------------------------------------
//Comment Out by Katoh    PPT_METHODTRACE_V1("","Get Cassette's Start Reserved ControlJob ID.");
//Comment Out by Katoh
//Comment Out by Katoh    objectIdentifier saveControlJobID;
//Comment Out by Katoh    CORBA::Long i = 0;
//Comment Out by Katoh    CORBA::Long nIMax = cassetteID.length();
//Comment Out by Katoh    for ( i=0 ; i<nIMax; i++ )
//Comment Out by Katoh    {
//Comment Out by Katoh        objCassette_controlJobID_Get_out   strCassette_controlJobID_Get_out;
//Comment Out by Katoh        rc = cassette_controlJobID_Get(strCassette_controlJobID_Get_out, strObjCommonIn, cassetteID[i] );
//Comment Out by Katoh        if ( rc != RC_OK )
//Comment Out by Katoh        {
//Comment Out by Katoh            PPT_METHODTRACE_V1("","cassette_controlJobID_Get() returned error.");
//Comment Out by Katoh
//Comment Out by Katoh            strLotsInfoForOpeStartForInternalBufferInqResult.strResult = strCassette_controlJobID_Get_out.strResult;
//Comment Out by Katoh            return( rc );
//Comment Out by Katoh        }
//Comment Out by Katoh
//Comment Out by Katoh        CORBA::Boolean findFlag = FALSE;
//Comment Out by Katoh        CORBA::Long j = 0;
//Comment Out by Katoh        CORBA::Long nJMax = strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo.length();
//Comment Out by Katoh        for ( j=0 ; j<nJMax; j++ )
//Comment Out by Katoh        {
//Comment Out by Katoh            if ( CIMFWStrCmp(strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[j].controlJobID.identifier,strCassette_controlJobID_Get_out.controlJobID.identifier) == 0)
//Comment Out by Katoh            {
//Comment Out by Katoh                PPT_METHODTRACE_V1("","Carrier's Control Job is found in Equipment's Reserved Control Job List.");
//Comment Out by Katoh
//Comment Out by Katoh                findFlag = TRUE;
//Comment Out by Katoh                break;
//Comment Out by Katoh            }
//Comment Out by Katoh        }
//Comment Out by Katoh
//Comment Out by Katoh        //----------------------------------------------
//Comment Out by Katoh        // If carrier's control job id is NOT blank...
//Comment Out by Katoh        //----------------------------------------------
//Comment Out by Katoh        if (CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) != 0 )
//Comment Out by Katoh        {
//Comment Out by Katoh            //---------------------------------------------
//Comment Out by Katoh            // If saveControlJobID is blank,
//Comment Out by Katoh            // keep first carrier's control job id
//Comment Out by Katoh            //---------------------------------------------
//Comment Out by Katoh            if(0 == CIMFWStrLen(saveControlJobID.identifier))
//Comment Out by Katoh            {
//Comment Out by Katoh                if ( findFlag == FALSE )
//Comment Out by Katoh                {
//Comment Out by Katoh                    PPT_METHODTRACE_V1("","Control Job of input carriers is not found in equipment control Job List.");
//Comment Out by Katoh                    SET_MSG_RC( strLotsInfoForOpeStartForInternalBufferInqResult,
//Comment Out by Katoh                                MSG_NOT_RESVED_PORTGRP,
//Comment Out by Katoh                                RC_NOT_RESVED_PORTGRP);
//Comment Out by Katoh                    return( RC_NOT_RESVED_PORTGRP );
//Comment Out by Katoh                }
//Comment Out by Katoh
//Comment Out by Katoh                saveControlJobID = strCassette_controlJobID_Get_out.controlJobID;
//Comment Out by Katoh            }
//Comment Out by Katoh            //---------------------------------------------
//Comment Out by Katoh            // If saveControlJobID is NOT blank,
//Comment Out by Katoh            // compare saveControlJobID and carrier's Control Job
//Comment Out by Katoh            //---------------------------------------------
//Comment Out by Katoh            else
//Comment Out by Katoh            {
//Comment Out by Katoh                if(0 != CIMFWStrCmp(saveControlJobID.identifier,
//Comment Out by Katoh                                    strCassette_controlJobID_Get_out.controlJobID.identifier))
//Comment Out by Katoh                {
//Comment Out by Katoh                    PPT_METHODTRACE_V1("","Carrier Control Job IDs are not same.");
//Comment Out by Katoh
//Comment Out by Katoh                    SET_MSG_RC( strLotsInfoForOpeStartForInternalBufferInqResult,
//Comment Out by Katoh                                MSG_LOT_PORT_CTRLJOB_UNMATCH,
//Comment Out by Katoh                                RC_LOT_PORT_CTRLJOB_UNMATCH);
//Comment Out by Katoh                    return RC_NOT_RESVED_PORTGRP ;
//Comment Out by Katoh                }
//Comment Out by Katoh            }
//Comment Out by Katoh        }
//Comment Out by Katoh        //----------------------------------------------
//Comment Out by Katoh        // If carrier's control job id is blank...
//Comment Out by Katoh        //----------------------------------------------
//Comment Out by Katoh        else
//Comment Out by Katoh        {
//Comment Out by Katoh            if ( findFlag == TRUE )
//Comment Out by Katoh            {
//Comment Out by Katoh                PPT_SET_MSG_RC_KEY2( strLotsInfoForOpeStartForInternalBufferInqResult,
//Comment Out by Katoh                                     MSG_ALREADY_RESERVED_PORTGRP,
//Comment Out by Katoh                                     RC_ALREADY_RESERVED_PORTGRP,
//Comment Out by Katoh                                     "",
//Comment Out by Katoh                                     strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[j].controlJobID.identifier );
//Comment Out by Katoh                return( RC_ALREADY_RESERVED_PORTGRP );
//Comment Out by Katoh            }
//Comment Out by Katoh        }
//Comment Out by Katoh    }

    //----------------------------------------------------
    //
    //   Get Start Information for each Cassette / Lot
    //
    //----------------------------------------------------
//D9000003 add start
    CORBA::Boolean slotmapConflictWarnFlag = FALSE;   //Switch RC and MSG: when sampling logic below finished with warning.
    ostrstream smplMessage;
//D9000003 add end
    if ( CIMFWStrLen( saveControlJobID.identifier ) != 0 )
    {
        PPT_METHODTRACE_V1( "", "Carrier control job id is not blank." );

        objControlJob_startReserveInformation_Get_out strControlJob_startReserveInformation_Get_out;
        rc = controlJob_startReserveInformation_Get( strControlJob_startReserveInformation_Get_out,
                                                     strObjCommonIn, saveControlJobID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "controlJob_startReserveInformation_Get() returned error." );

            strLotsInfoForOpeStartForInternalBufferInqResult.strResult
                = strControlJob_startReserveInformation_Get_out.strResult;
            return( rc );
        }
        strLotsInfoForOpeStartForInternalBufferInqResult.strStartCassette
            = strControlJob_startReserveInformation_Get_out.strStartCassette;
    }
    else
    {
        PPT_METHODTRACE_V1( "", "Carrier control job id is blank." );

        objProcess_startReserveInformation_GetByCassetteForInternalBuffer_out strProcess_startReserveInformation_GetByCassetteForInternalBuffer_out; //PSIV00002149
        rc = process_startReserveInformation_GetByCassetteForInternalBuffer(                                                                         //PSIV00002149
                                        strProcess_startReserveInformation_GetByCassetteForInternalBuffer_out,                                       //PSIV00002149
                                        strObjCommonIn,                                                                                              //PSIV00002149
                                        equipmentID,                                                                                                 //PSIV00002149
                                        cassetteID );                                                                                                //PSIV00002149
        if ( rc != RC_OK )                                                                                                                           //PSIV00002149
        {                                                                                                                                            //PSIV00002149
            PPT_METHODTRACE_V1( "", "process_startReserveInformation_GetByCassetteForInternalBuffer() returned error." );                            //PSIV00002149
                                                                                                                                                     //PSIV00002149
            strLotsInfoForOpeStartForInternalBufferInqResult.strResult                                                                               //PSIV00002149
                = strProcess_startReserveInformation_GetByCassetteForInternalBuffer_out.strResult;                                                   //PSIV00002149
            return (rc);                                                                                                                             //PSIV00002149
        }                                                                                                                                            //PSIV00002149
        strLotsInfoForOpeStartForInternalBufferInqResult.strStartCassette                                                                            //PSIV00002149
            = strProcess_startReserveInformation_GetByCassetteForInternalBuffer_out.strStartCassette;                                                //PSIV00002149

//D8000024 add start
//D9000001        CORBA::Long  tmpFPCAdoptFlag = atol( getenv(SP_FPC_Adaptation_Flag) );
        CORBA::Long  tmpFPCAdoptFlag = atoi( getenv(SP_FPC_Adaptation_Flag) );    //D9000001
        if ( 1 == tmpFPCAdoptFlag )
        {
//PSIV00002149            CORBA::Long castLen = cassetteID.length();
            CORBA::Long castLen = strLotsInfoForOpeStartForInternalBufferInqResult.strStartCassette.length();                                        //PSIV00002149
            for ( CORBA::Long castCnt = 0; castCnt < castLen; castCnt++ )
            {
//PSIV00002149                objCassette_GetLotList_out strCassette_GetLotList_out;
//PSIV00002149                rc = cassette_GetLotList( strCassette_GetLotList_out, strObjCommonIn, cassetteID[castCnt] );
//PSIV00002149//P8000072                if( rc != RC_OK )
//PSIV00002149                if ( rc != RC_OK && rc != RC_NOT_FOUND_LOT ) //P8000072
//PSIV00002149                {
//PSIV00002149                    PPT_METHODTRACE_V2( "", "cassette_GetLotList() != RC_OK", rc );
//PSIV00002149                    strLotsInfoForOpeStartForInternalBufferInqResult.strResult = strCassette_GetLotList_out.strResult;
//PSIV00002149                    return (rc);
//PSIV00002149                }

//PSIV00002149                CORBA::Long lotLen = strCassette_GetLotList_out.strLotListInCassetteInfo.lotID.length();
                CORBA::Long lotLen = strLotsInfoForOpeStartForInternalBufferInqResult.strStartCassette[castCnt].strLotInCassette.length();                //PSIV00002149
                for ( CORBA::Long lotCnt = 0; lotCnt < lotLen; lotCnt++ )
                {
                    if( strLotsInfoForOpeStartForInternalBufferInqResult.strStartCassette[castCnt].strLotInCassette[lotCnt].operationStartFlag == FALSE ) //PSIV00002149
                    {                                                                                                                                     //PSIV00002149
                        PPT_METHODTRACE_V1("", "operationStartFlag == FALSE" );                                                                           //PSIV00002149
                        continue;                                                                                                                         //PSIV00002149
                    }                                                                                                                                     //PSIV00002149
                    objectIdentifier lotID = strLotsInfoForOpeStartForInternalBufferInqResult.strStartCassette[castCnt].strLotInCassette[lotCnt].lotID;   //PSIV00002149
//PSIV00002149                    PPT_METHODTRACE_V2("", "Check lot's FPC definition.",
//PSIV00002149                                       strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[lotCnt].identifier);
                    PPT_METHODTRACE_V2("", "Check lot's FPC definition.", lotID.identifier);                                                              //PSIV00002149
                    objLot_currentFPCInfo_Get_out strLot_currentFPCInfo_Get_out;
                    rc = lot_currentFPCInfo_Get( strLot_currentFPCInfo_Get_out, strObjCommonIn,
//PSIV00002149                                                 strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[lotCnt],
                                                 lotID,                                                                                                   //PSIV00002149
                                                 equipmentID, FALSE, FALSE, FALSE, FALSE );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2( "", "lot_currentFPCInfo_Get() != RC_OK", rc );
                        strLotsInfoForOpeStartForInternalBufferInqResult.strResult = strLot_currentFPCInfo_Get_out.strResult;
                        return (rc);
                    }

                    CORBA::Long fpcLen = strLot_currentFPCInfo_Get_out.strFPCInfoList.length();
                    if ( fpcLen > 0 )
                    {
                        PPT_METHODTRACE_V2( "", "This lot is influenced by FPC.", fpcLen );
                        PPT_SET_MSG_RC_KEY( strLotsInfoForOpeStartForInternalBufferInqResult,
                                            MSG_FPC_REQUIRE_START_RESERVE, RC_FPC_REQUIRE_START_RESERVE,
//PSIV00002149                                            strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[lotCnt].identifier );
                                            lotID.identifier );                                                                                           //PSIV00002149
                        return RC_FPC_REQUIRE_START_RESERVE;
                    }
                }
            }
        }
//D8000024 add end

//PSIV00002149        objProcess_startReserveInformation_GetByCassetteForInternalBuffer_out strProcess_startReserveInformation_GetByCassetteForInternalBuffer_out;
//PSIV00002149        rc = process_startReserveInformation_GetByCassetteForInternalBuffer(
//PSIV00002149                                        strProcess_startReserveInformation_GetByCassetteForInternalBuffer_out,
//PSIV00002149                                        strObjCommonIn,
//PSIV00002149                                        equipmentID,
//PSIV00002149                                        cassetteID );
//PSIV00002149        if ( rc != RC_OK )
//PSIV00002149        {
//PSIV00002149            PPT_METHODTRACE_V1( "", "process_startReserveInformation_GetByCassetteForInternalBuffer() returned error." );
//PSIV00002149
//PSIV00002149            strLotsInfoForOpeStartForInternalBufferInqResult.strResult
//PSIV00002149                = strProcess_startReserveInformation_GetByCassetteForInternalBuffer_out.strResult;
//PSIV00002149            return (rc);
//PSIV00002149        }
//PSIV00002149        strLotsInfoForOpeStartForInternalBufferInqResult.strStartCassette
//PSIV00002149            = strProcess_startReserveInformation_GetByCassetteForInternalBuffer_out.strStartCassette;


//D9000003 add start
        PPT_METHODTRACE_V1( "", "Set processJobExecFlag based on wafer sampling setting. " );
        objStartCassette_processJobExecFlag_Set_out__090 strStartCassette_processJobExecFlag_Set_out__090;
        objStartCassette_processJobExecFlag_Set_in__090 strStartCassette_processJobExecFlag_Set_in__090;
        strStartCassette_processJobExecFlag_Set_in__090.strStartCassette = strLotsInfoForOpeStartForInternalBufferInqResult.strStartCassette;
        strStartCassette_processJobExecFlag_Set_in__090.equipmentID = equipmentID;

        rc = startCassette_processJobExecFlag_Set__090( strStartCassette_processJobExecFlag_Set_out__090, strObjCommonIn, strStartCassette_processJobExecFlag_Set_in__090 );
        if ( rc != RC_SMPL_SLOTMAP_CONFLICT_WARN && rc != RC_OK )
        {
            // Return error when input parameter or sampling setting is invalid format.
            PPT_METHODTRACE_V1( "", "startCassette_processJobExecFlag_Set__090() != RC_OK " );
            strLotsInfoForOpeStartForInternalBufferInqResult.strResult = strStartCassette_processJobExecFlag_Set_out__090.strResult;
            return rc;
        }
        //-------------------------------------------------------
        // When RC_SMPL_SLOTMAP_CONFLICT_WARN is returned,
        // return RC_SMPL_SLOTMAP_CONFLICT_WARN at the last of TX process.
        //-------------------------------------------------------
        if ( rc == RC_SMPL_SLOTMAP_CONFLICT_WARN )
        {
            PPT_METHODTRACE_V1( "", "rc == RC_SMPL_SLOTMAP_CONFLICT_WARN" );
            slotmapConflictWarnFlag = TRUE;
        }
        //-------------------------------------------------------
        // create return message or e-mail text.
        //-------------------------------------------------------
        PPT_METHODTRACE_V2( "", "strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage.length()", strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage.length() );
        for ( CORBA::Long msgCnt = 0; msgCnt < strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage.length(); msgCnt++ )
        {
            if ( strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].messageType == SP_Sampling_warn_mail )
            {
                PPT_METHODTRACE_V1( "", "strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].messageType == SP_Sampling_warn_mail" );
                // create return message;
                if ( smplMessage.pcount() > 0 )
                {
                    smplMessage << "," << endl;
                }
                smplMessage << strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].messageText;
            }
            else if ( strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].messageType == SP_Sampling_ignored_mail )
            {
                PPT_METHODTRACE_V1( "", "strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].messageType == SP_Sampling_ignored_mail" );
                // Send E-mail when recycle sampling setting is ignored.
                pptSystemMsgRptResult strSystemMsgRptResult;
                objectIdentifier dummyID;
                rc = txSystemMsgRpt(strSystemMsgRptResult,
                                    strObjCommonIn,
                                    SP_SubSystemID_MM,
                                    SP_SystemMsgCode_SMPLERR,
                                    strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].messageText,
                                    TRUE,
                                    dummyID,
                                    "",
                                    dummyID,
                                    "",
                                    dummyID,
                                    "",
                                    strStartCassette_processJobExecFlag_Set_out__090.strSamplingMessage[msgCnt].lotID,
                                    "",
                                    dummyID,
                                    dummyID,
                                    "",
                                    strObjCommonIn.strTimeStamp.reportTimeStamp,
                                    "" );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "", "txSystemMsgRpt != RC_OK" );
                    strLotsInfoForOpeStartForInternalBufferInqResult.strResult = strSystemMsgRptResult.strResult;
                    return (rc);
                }
            }
        } //end for-loop
        smplMessage << ends ;

        PPT_METHODTRACE_V2("", "smplMessage = ", smplMessage.str());
        smplMessage.rdbuf()->freeze(0);             //PSIV00001581
        strLotsInfoForOpeStartForInternalBufferInqResult.strStartCassette = strStartCassette_processJobExecFlag_Set_out__090.strStartCassette;
//D9000003 add end
    }

//D8000207 add start
    //----------------------------------------
    // Change processJobExecFlag to True.
    //----------------------------------------
//D9000003 delete start
//    PPT_METHODTRACE_V2("","SP_OPER_START_WAFER_FLAG_CONTROL is ", atol(getenv(SP_OPER_START_WAFER_FLAG_CONTROL)));
//    if( 1 == atol(getenv(SP_OPER_START_WAFER_FLAG_CONTROL)) )
//    {
//        objStartCassette_processJobExecFlag_Set_out   strStartCassette_processJobExecFlag_Set_out;
//        rc = startCassette_processJobExecFlag_Set(strStartCassette_processJobExecFlag_Set_out, strObjCommonIn, strLotsInfoForOpeStartForInternalBufferInqResult.strStartCassette );
//        if( rc != RC_OK )
//        {
//            PPT_METHODTRACE_V1("","objStartCassette_processJobExecFlag_Set() != RC_OK ");
//            strLotsInfoForOpeStartForInternalBufferInqResult.strResult = strStartCassette_processJobExecFlag_Set_out.strResult;
//            return rc;
//        }
//        strLotsInfoForOpeStartForInternalBufferInqResult.strStartCassette = strStartCassette_processJobExecFlag_Set_out.strStartCassette;
//    }
//D9000003 delete end
//D8000207 add start


    //------------------------------------------
    //   Check all carrier of control job is input or not
    //------------------------------------------
    CORBA::Long nControlJobCassetteLen = strLotsInfoForOpeStartForInternalBufferInqResult.strStartCassette.length();
    CORBA::Long nInputCassetteLen = cassetteID.length();
    for ( i = 0; i < nControlJobCassetteLen; i++ )
    {
        CORBA::Boolean bFound = FALSE;
        for ( CORBA::Long j = 0; j < nInputCassetteLen; j++ )
        {
            if ( 0 == CIMFWStrCmp( strLotsInfoForOpeStartForInternalBufferInqResult.strStartCassette[i].cassetteID.identifier,
                                   cassetteID[j].identifier ) )
            {
                bFound = TRUE;
                break;
            }
        }
        if ( bFound == FALSE )
        {
            PPT_METHODTRACE_V1( "", "all of cassette in control job is not input." );

            SET_MSG_RC( strLotsInfoForOpeStartForInternalBufferInqResult,
                        MSG_MISSING_CASSETTE_OF_CONTROLJOB,
                        RC_MISSING_CASSETTE_OF_CONTROLJOB );
            return RC_MISSING_CASSETTE_OF_CONTROLJOB;
        }
    }

    //------------------------------------------
    //   Set EqpID, ControlJobID, PortGroupID
    //------------------------------------------
    strLotsInfoForOpeStartForInternalBufferInqResult.equipmentID = equipmentID;
    strLotsInfoForOpeStartForInternalBufferInqResult.controlJobID = saveControlJobID;

//INN-R-170009#if 1
//INN-R-170009    //------------------------------------------------------
//INN-R-170009    //   Get Info for StartReservation use APC I/F or not
//INN-R-170009    //------------------------------------------------------
//INN-R-170009    objAPC_interfaceFlag_Check_out strAPC_interfaceFlag_Check_out;
//INN-R-170009    rc = APC_interfaceFlag_Check( strAPC_interfaceFlag_Check_out,
//INN-R-170009                                  strObjCommonIn,
 //INN-R-170009                                 strLotsInfoForOpeStartForInternalBufferInqResult.strStartCassette );

//INN-R-170009    if ( rc != RC_OK )
//INN-R-170009    {
//INN-R-170009        PPT_METHODTRACE_V1( "", "APC_interfaceFlag_Check() != RC_OK" );
//INN-R-170009        strLotsInfoForOpeStartForInternalBufferInqResult.strResult = strAPC_interfaceFlag_Check_out.strResult;
//INN-R-170009        return (rc);
//INN-R-170009    }

//INN-R-170009    if ( strAPC_interfaceFlag_Check_out.APCInterFaceFlag )
//INN-R-170009    {
//INN-R-170009        PPT_METHODTRACE_V1( "", "APCinterFaceFlag is TRUE!!!" );

//INN-R-170009        //-------------------------------------------------
//INN-R-170009        //   Get from APCInterface AdjustRecipeParameter
//INN-R-170009        //-------------------------------------------------
//INN-R-170009        PPT_METHODTRACE_V1( "", "Get from APCInterface AdjustRecipeParameter" );
//INN-R-170009        objAPCMgr_SendRecipeParamInq_out strAPCMgr_SendRecipeParamInq_out;
//INN-R-170009        rc = APCMgr_SendRecipeParamInq( strAPCMgr_SendRecipeParamInq_out,
//INN-R-170009                                             strObjCommonIn,
//INN-R-170009                                             strLotsInfoForOpeStartForInternalBufferInqResult.equipmentID,
//INN-R-170009                                             strLotsInfoForOpeStartForInternalBufferInqResult.portGroupID,
//INN-R-170009                                             strLotsInfoForOpeStartForInternalBufferInqResult.controlJobID,
//INN-R-170009                                             strLotsInfoForOpeStartForInternalBufferInqResult.strStartCassette );
//INN-R-170009
//INN-R-170009        if ( rc != RC_OK )
//INN-R-170009        {
//INN-R-170009            PPT_METHODTRACE_V1( "", "APCMgr_SendRecipeParamInq() != RC_OK" );
//INN-R-170009            strLotsInfoForOpeStartForInternalBufferInqResult.strResult = strAPCMgr_SendRecipeParamInq_out.strResult;
//INN-R-170009            return (rc);
//INN-R-170009        }
//INN-R-170009        strLotsInfoForOpeStartForInternalBufferInqResult.strStartCassette = strAPCMgr_SendRecipeParamInq_out.strStartCassette;
//INN-R-170009    }
//INN-R-170009#endif

    //INN-R-170009 Start//
    CORBA::String_var APCFlag = CIMFWStrDup(getenv(SP_APC_Available));
    PPT_METHODTRACE_V2("", "APCAvailable", APCFlag);

    if (CIMFWStrCmp(APCFlag,SP_CheckFlag_On) == 0)
    {
        csObjAPCMgr_SendLithoRecommendInfoInq_in  strObjAPCMgr_SendLithoRecommendInfoInq_in;
        csObjAPCMgr_SendLithoRecommendInfoInq_out strObjAPCMgr_SendLithoRecommendInfoInq_out;
        strObjAPCMgr_SendLithoRecommendInfoInq_in.equipmentID      = equipmentID;
        strObjAPCMgr_SendLithoRecommendInfoInq_in.action           = CIMFWStrDup ( CS_APC_COMBINE_FLAG_ACTION_OPST_RECOMMEND );
        strObjAPCMgr_SendLithoRecommendInfoInq_in.strStartCassette = strLotsInfoForOpeStartForInternalBufferInqResult.strStartCassette;
        rc = cs_APCMgr_SendLithoRecommendInfoInq( strObjAPCMgr_SendLithoRecommendInfoInq_out,
                                          strObjCommonIn,
                                          strObjAPCMgr_SendLithoRecommendInfoInq_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cs_APCMgr_SendLithoRecommendInfoInq() != RC_OK");
            strLotsInfoForOpeStartForInternalBufferInqResult.strResult = strObjAPCMgr_SendLithoRecommendInfoInq_out.strResult;
            return ( rc );
        }
    }
    //INN-R-170009 Add End//

    traceSampledStartCassette( strLotsInfoForOpeStartForInternalBufferInqResult.strStartCassette );  //D9000003

    //-----------------------
    //   Set out structure
    //-----------------------
//D9000003 add start
    if ( slotmapConflictWarnFlag == TRUE )
    {
        PPT_SET_MSG_RC_KEY( strLotsInfoForOpeStartForInternalBufferInqResult, MSG_SMPL_SLOTMAP_CONFLICT_WARN, RC_SMPL_SLOTMAP_CONFLICT_WARN, smplMessage.str() );
        smplMessage.rdbuf()->freeze( 0 );
        PPT_METHODTRACE_V2( "", "txLotsInfoForOpeStartForInternalBufferInq MSG", strLotsInfoForOpeStartForInternalBufferInqResult.strResult.messageText );
        PPT_METHODTRACE_EXIT( "PPTManager_i::txLotsInfoForOpeStartForInternalBufferInq " );
        return RC_SMPL_SLOTMAP_CONFLICT_WARN;
    }
    else
    {
//D9000003 add end
        SET_MSG_RC( strLotsInfoForOpeStartForInternalBufferInqResult, MSG_OK, RC_OK );    //D9000003 Indentation is adjusted.
    }  //D9000003
    PPT_METHODTRACE_EXIT( "PPTManager_i::txLotsInfoForOpeStartForInternalBufferInq " );
    return (rc);
}
