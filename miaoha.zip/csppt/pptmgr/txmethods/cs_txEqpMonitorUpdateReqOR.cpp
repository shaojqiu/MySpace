//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// SiView
// Name: txEqpMonitorUpdateReq.cpp
//

#include "cs_pptmgr.hpp"

// Class: PPTManager
//
// Service: txEqpMonitorUpdateReq()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------------------
// 2013/07/10 DSN000081739 Sa Guo         Equipment Monitor Automation Support
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/23 INN-R170016  JJ.Zhang       Equipment Monitor customization
//
// Description:
//    This function registers an equipment monitor definition for specified equipment.
//    This function also update and delete a registered equipment monitor definition.
//
// Return:
//    long
//
// Parameter:
//
//  [Input Parameters]:
//    const pptObjCommonIn&                              strObjCommonIn
//    const pptEqpMonitorUpdateReqInParm&                strEqpMonitorUpdateReqInParm
//    const char *                                       claimMemo
//
//  [Output Parameters]:
//    pptEqpMonitorUpdateReqResult&                      strEqpMonitorUpdateReqResult
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

//INN-R170016 CORBA::Long PPTManager_i::txEqpMonitorUpdateReq(
CORBA::Long CS_PPTManager_i::cs_txEqpMonitorUpdateReq( //INN-R170016
    pptEqpMonitorUpdateReqResult&                      strEqpMonitorUpdateReqResult,
    const pptObjCommonIn&                              strObjCommonIn,
//INN-R170016    const pptEqpMonitorUpdateReqInParm&   strEqpMonitorUpdateReqInParm,
    const csEqpMonitorUpdateReqInParm&                 strEqpMonitorUpdateReqInParm, //INN-R170016
    const char *                                       claimMemo
    CORBAENV_LAST_CPP )
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txEqpMonitorUpdateReq");
    //----------------------------------------------------------------
    //
    //  Pre Process
    //
    //----------------------------------------------------------------

    // Initialize
    CORBA::Long rc = RC_OK;

//INN-R170016    const pptEqpMonitorUpdateReqInParm& strInParm = strEqpMonitorUpdateReqInParm;
//INN-R170016 Add Start
    //reconstruct strEqpMonitorProductInfoSeq from strEqpMonitorSubInfoSeq
    csEqpMonitorUpdateReqInParm strInParm = strEqpMonitorUpdateReqInParm;
    CORBA::Long nSubLen = strInParm.strEqpMonitorSubInfoSeq.length();
    if ( 0 == nSubLen )
    {
        PPT_METHODTRACE_V1("", "Input parameter strEqpMonitorSubInfoSeq is invalid");
        SET_MSG_RC( strEqpMonitorUpdateReqResult,
                    MSG_INVALID_INPUT_PARM,
                    RC_INVALID_INPUT_PARM );
        return RC_INVALID_INPUT_PARM;
    }

    strInParm.strEqpMonitorProductInfoSeq.length(nSubLen);

    CORBA::Long i=0, j=0, count=0;
    for( i=0; i<nSubLen; i++ )
    {
        if( 0 == CIMFWStrLen(strInParm.strEqpMonitorSubInfoSeq[j].productID.identifier) )
        {
            //no product defined in this slot
            continue;
        }
        CORBA::Boolean bExist = FALSE;
        for( j=0; j<count; j++ )
        {
            if( CIMFWStrCmp(strInParm.strEqpMonitorSubInfoSeq[i].productID.identifier, strInParm.strEqpMonitorProductInfoSeq[j].productID.identifier) == 0 )
            {
                bExist = TRUE;
                strInParm.strEqpMonitorProductInfoSeq[j].waferCount++; 
                break;
            }
        }
        if( !bExist)
        {
            strInParm.strEqpMonitorProductInfoSeq[count].startSeqNo = 1; //only support 1 carrier
            strInParm.strEqpMonitorProductInfoSeq[count].waferCount = 1; 
            strInParm.strEqpMonitorProductInfoSeq[count].productID = strInParm.strEqpMonitorSubInfoSeq[i].productID;
            count++;
        }
    }
    PPT_METHODTRACE_V2("", "strEqpMonitorProductInfoSeq.length", count);
    strInParm.strEqpMonitorProductInfoSeq.length(count);
    if ( 0 == count )
    {
        PPT_METHODTRACE_V1("", "collected strEqpMonitorProductInfoSeq is invalid");
        SET_MSG_RC( strEqpMonitorUpdateReqResult,
                    MSG_INVALID_INPUT_PARM,
                    RC_INVALID_INPUT_PARM );
        return RC_INVALID_INPUT_PARM;
    }
//INN-R170016 Add End

    //----------------------------------------------------------------
    //  In-Parameter Trace
    //----------------------------------------------------------------
    //Trace InParameters
    PPT_METHODTRACE_V2("", "in-parm actionType      ", strInParm.actionType);
    PPT_METHODTRACE_V2("", "in-parm equipmentID     ", strInParm.equipmentID.identifier);
    PPT_METHODTRACE_V2("", "in-parm eqpMonitorID    ", strInParm.eqpMonitorID.identifier);
    PPT_METHODTRACE_V2("", "in-parm chamberID       ", strInParm.chamberID.identifier);
    PPT_METHODTRACE_V2("", "in-parm monitorType     ", strInParm.monitorType);

    //----------------------------------------------------------------
    //  In parameters check
    //----------------------------------------------------------------
    //Blank input check for in-parameter "equipmentID"
    if ( 0 == CIMFWStrLen( strInParm.equipmentID.identifier ) )
    {
        PPT_METHODTRACE_V1("", "Input parameter equipmentID is blank");
        PPT_SET_MSG_RC_KEY( strEqpMonitorUpdateReqResult,
                            MSG_BLANK_INPUT_PARAMETER,
                            RC_BLANK_INPUT_PARAMETER,
                            "equipmentID" );
        return RC_BLANK_INPUT_PARAMETER;
    }

    //Blank input check for in-parameter "eqpMonitorID"
    if ( 0 == CIMFWStrLen( strInParm.eqpMonitorID.identifier ) )
    {
        PPT_METHODTRACE_V1("", "Input parameter eqpMonitorID is blank");
        PPT_SET_MSG_RC_KEY( strEqpMonitorUpdateReqResult,
                            MSG_BLANK_INPUT_PARAMETER,
                            RC_BLANK_INPUT_PARAMETER,
                            "eqpMonitorID" );
        return RC_BLANK_INPUT_PARAMETER;
    }

    //Create, Update, or Delete must be specified as actionType
    if ( 0 != CIMFWStrCmp(strInParm.actionType, SP_EqpMonitor_OpeCategory_Create)
      && 0 != CIMFWStrCmp(strInParm.actionType, SP_EqpMonitor_OpeCategory_Update)
      && 0 != CIMFWStrCmp(strInParm.actionType, SP_EqpMonitor_OpeCategory_Delete) )
    {
        PPT_METHODTRACE_V1("", "Input parameter actionType is invalid");
        SET_MSG_RC( strEqpMonitorUpdateReqResult,
                    MSG_INVALID_INPUT_PARM,
                    RC_INVALID_INPUT_PARM );
        return RC_INVALID_INPUT_PARM;
    }

    if ( 0 == CIMFWStrCmp(strInParm.actionType, SP_EqpMonitor_OpeCategory_Create)
      || 0 == CIMFWStrCmp(strInParm.actionType, SP_EqpMonitor_OpeCategory_Update) )
    {
        PPT_METHODTRACE_V1("", "actionType is Create or Update");

        //Routine or Manual must be specified as monitorType
        if ( 0 != CIMFWStrCmp(strInParm.monitorType, SP_EqpMonitor_Type_Routine)
          && 0 != CIMFWStrCmp(strInParm.monitorType, SP_EqpMonitor_Type_Manual) )
        {
            PPT_METHODTRACE_V1("", "Input parameter monitorType is invalid");
            SET_MSG_RC( strEqpMonitorUpdateReqResult,
                        MSG_INVALID_INPUT_PARM,
                        RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        //It is Error Return if length of strEqpMonitorProductInfoSeq is 0
        if ( 0 == strInParm.strEqpMonitorProductInfoSeq.length() )
        {
            PPT_METHODTRACE_V1("", "Input parameter strEqpMonitorProductInfoSeq is invalid");
            SET_MSG_RC( strEqpMonitorUpdateReqResult,
                        MSG_INVALID_INPUT_PARM,
                        RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        //It is Error Return if strEqpMonitorProductInfoSeq[ ].productID is blank and wafer count is 0
        for ( CORBA::ULong iCnt1=0; iCnt1<strInParm.strEqpMonitorProductInfoSeq.length(); iCnt1++ )
        {
            PPT_METHODTRACE_V2("", "loop to strInParm.strEqpMonitorProductInfoSeq.length()", iCnt1);
            if ( 0 == CIMFWStrLen(strInParm.strEqpMonitorProductInfoSeq[iCnt1].productID.identifier) )
            {
                PPT_METHODTRACE_V2("", "Input parameter strEqpMonitorProductInfoSeq[iCnt1].productID is blank", iCnt1);
                PPT_SET_MSG_RC_KEY( strEqpMonitorUpdateReqResult,
                                    MSG_BLANK_INPUT_PARAMETER,
                                    RC_BLANK_INPUT_PARAMETER,
                                    "strEqpMonitorProductInfoSeq[].productID" );
                return RC_BLANK_INPUT_PARAMETER;
            }
            if ( 0 == strInParm.strEqpMonitorProductInfoSeq[iCnt1].waferCount )
            {
                PPT_METHODTRACE_V2("", "Input parameter strEqpMonitorProductInfoSeq[iCnt1].waferCount is 0", iCnt1);
                PPT_SET_MSG_RC_KEY( strEqpMonitorUpdateReqResult,
                                    MSG_BLANK_INPUT_PARAMETER,
                                    RC_BLANK_INPUT_PARAMETER,
                                    "strEqpMonitorProductInfoSeq[].waferCount" );
                return RC_BLANK_INPUT_PARAMETER;
            }
            if ( 0 == strInParm.strEqpMonitorProductInfoSeq[iCnt1].startSeqNo )
            {
                PPT_METHODTRACE_V2("", "Input parameter strEqpMonitorProductInfoSeq[iCnt1].startSeqNo is 0", iCnt1);
                PPT_SET_MSG_RC_KEY( strEqpMonitorUpdateReqResult,
                                    MSG_BLANK_INPUT_PARAMETER,
                                    RC_BLANK_INPUT_PARAMETER,
                                    "strEqpMonitorProductInfoSeq[].startSeqNo" );
                return RC_BLANK_INPUT_PARAMETER;
            }
        }

        if ( 0 == CIMFWStrCmp(strInParm.monitorType, SP_EqpMonitor_Type_Routine) )
        {
            PPT_METHODTRACE_V1("", "monitorType is Routine");

            //Time must be specified as scheduleType
            if ( 0 != CIMFWStrCmp(strInParm.scheduleType, SP_EqpMonitor_Schedule_Type_Time) )
            {
                PPT_METHODTRACE_V1("", "Input parameter scheduleType is invalid");
                SET_MSG_RC( strEqpMonitorUpdateReqResult,
                            MSG_INVALID_INPUT_PARM,
                            RC_INVALID_INPUT_PARM );
                return RC_INVALID_INPUT_PARM;
            }

            //startTimeStamp must be specified
            if ( 0 == CIMFWStrLen(strInParm.startTimeStamp) )
            {
                PPT_METHODTRACE_V1("", "Input parameter startTimeStamp is blank");
                PPT_SET_MSG_RC_KEY( strEqpMonitorUpdateReqResult,
                                    MSG_BLANK_INPUT_PARAMETER,
                                    RC_BLANK_INPUT_PARAMETER,
                                    "startTimeStamp" );
                return RC_BLANK_INPUT_PARAMETER;
            }

            //executionInterval must be specified(One or more)
            if ( 0 >= strInParm.executionInterval )
            {
                PPT_METHODTRACE_V1("", "executionInterval must be larger than 0");
                PPT_SET_MSG_RC_KEY( strEqpMonitorUpdateReqResult,
                                    MSG_INVALID_PARAMETER_WITH_MSG,
                                    RC_INVALID_PARAMETER_WITH_MSG,
                                    "executionInterval must be larger than 0" );
                return RC_INVALID_PARAMETER_WITH_MSG;
            }

            //expirationInterval must be specified(More than executionInterval)
            if ( strInParm.expirationInterval <= strInParm.executionInterval )
            {
                PPT_METHODTRACE_V1("", "expirationInterval must be larger than executionInterval");
                PPT_SET_MSG_RC_KEY( strEqpMonitorUpdateReqResult,
                                    MSG_INVALID_PARAMETER_WITH_MSG,
                                    RC_INVALID_PARAMETER_WITH_MSG,
                                    "Inhibit Timer must be larger than Execution Interval" );
                return RC_INVALID_PARAMETER_WITH_MSG;
            }
        }

        if ( 0 < strInParm.strEqpMonitorActionInfoSeq.length() )
        {
            PPT_METHODTRACE_V1("", "strInParm.strEqpMonitorActionInfoSeq.length() > 0");
            for ( CORBA::ULong iCnt2=0; iCnt2<strInParm.strEqpMonitorActionInfoSeq.length(); iCnt2++ )
            {
                PPT_METHODTRACE_V2("", "loop to strInParm.strEqpMonitorActionInfoSeq.length()", iCnt2);
                //action must be specified
                if ( 0 == CIMFWStrLen(strInParm.strEqpMonitorActionInfoSeq[iCnt2].action) )
                {
                    PPT_METHODTRACE_V2("", "Input parameter strEqpMonitorActionInfoSeq[iCnt2].action is blank", iCnt2);
                    PPT_SET_MSG_RC_KEY( strEqpMonitorUpdateReqResult,
                                        MSG_BLANK_INPUT_PARAMETER,
                                        RC_BLANK_INPUT_PARAMETER,
                                        "strEqpMonitorActionInfoSeq[].action" );
                    return RC_BLANK_INPUT_PARAMETER;
                }

                //eventType must be specified
                if ( 0 == CIMFWStrLen(strInParm.strEqpMonitorActionInfoSeq[iCnt2].eventType) )
                {
                    PPT_METHODTRACE_V2("", "Input parameter strEqpMonitorActionInfoSeq[iCnt2].eventType is blank", iCnt2);
                    PPT_SET_MSG_RC_KEY( strEqpMonitorUpdateReqResult,
                                        MSG_BLANK_INPUT_PARAMETER,
                                        RC_BLANK_INPUT_PARAMETER,
                                        "strEqpMonitorActionInfoSeq[].eventType" );
                    return RC_BLANK_INPUT_PARAMETER;
                }

                if ( 0 == CIMFWStrCmp(strInParm.strEqpMonitorActionInfoSeq[iCnt2].action, SP_EqpMonitor_Action_Mail) )
                {
                    PPT_METHODTRACE_V2("", "strInParm.strEqpMonitorActionInfoSeq[iCnt2].action is Mail", iCnt2);
                    //sysMessageCodeID must be specified
                    if ( 0 == CIMFWStrLen(strInParm.strEqpMonitorActionInfoSeq[iCnt2].sysMessageCodeID.identifier) )
                    {
                        PPT_METHODTRACE_V2("", "Input parameter strEqpMonitorActionInfoSeq[iCnt2].sysMessageCodeID is blank", iCnt2);
                        PPT_SET_MSG_RC_KEY( strEqpMonitorUpdateReqResult,
                                            MSG_BLANK_INPUT_PARAMETER,
                                            RC_BLANK_INPUT_PARAMETER,
                                            "strEqpMonitorActionInfoSeq[].sysMessageCodeID" );
                        return RC_BLANK_INPUT_PARAMETER;
                    }
                }

                if ( 0 == CIMFWStrCmp(strInParm.strEqpMonitorActionInfoSeq[iCnt2].action, SP_EqpMonitor_Action_Inhibit) )
                {
                    PPT_METHODTRACE_V2("", "strInParm.strEqpMonitorActionInfoSeq[iCnt2].action is Inhibit", iCnt2);
                    //reasonCodeID must be specified
                    if ( 0 == CIMFWStrLen(strInParm.strEqpMonitorActionInfoSeq[iCnt2].reasonCodeID.identifier) )
                    {
                        PPT_METHODTRACE_V2("", "Input parameter strEqpMonitorActionInfoSeq[iCnt2].reasonCodeID is blank", iCnt2);
                        PPT_SET_MSG_RC_KEY( strEqpMonitorUpdateReqResult,
                                            MSG_BLANK_INPUT_PARAMETER,
                                            RC_BLANK_INPUT_PARAMETER,
                                            "strEqpMonitorActionInfoSeq[].reasonCodeID" );
                        return RC_BLANK_INPUT_PARAMETER;
                    }
                }
            }
        }
    }

    if ( 0 == CIMFWStrCmp(strInParm.actionType, SP_EqpMonitor_OpeCategory_Update)
      || 0 == CIMFWStrCmp(strInParm.actionType, SP_EqpMonitor_OpeCategory_Delete) )
    {
        PPT_METHODTRACE_V1("", "actionType is Update or Delete");
        //Lock EqpMonitor object
        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, strInParm.eqpMonitorID, SP_ClassName_PosEqpMonitor );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
            strEqpMonitorUpdateReqResult.strResult = strObject_Lock_out.strResult;
            return rc;
        }
    }

//INN-R170016    pptEqpMonitorDetailInfo strEqpMonitorDetailInfo;
    csEqpMonitorDetailInfo strEqpMonitorDetailInfo; //INN-R170016

    if ( 0 == CIMFWStrCmp(strInParm.actionType, SP_EqpMonitor_OpeCategory_Create) )
    {
        PPT_METHODTRACE_V1("", "actionType is Create");
        //Set input parameters to strEqpMonitorDetailInfo
        strEqpMonitorDetailInfo.equipmentID                 = strInParm.equipmentID;
        strEqpMonitorDetailInfo.eqpMonitorID                = strInParm.eqpMonitorID;
        strEqpMonitorDetailInfo.chamberID                   = strInParm.chamberID;
        strEqpMonitorDetailInfo.description                 = strInParm.description;
        strEqpMonitorDetailInfo.monitorType                 = strInParm.monitorType;
        strEqpMonitorDetailInfo.scheduleType                = strInParm.scheduleType;
        strEqpMonitorDetailInfo.strEqpMonitorProductInfoSeq = strInParm.strEqpMonitorProductInfoSeq;
        strEqpMonitorDetailInfo.startTimeStamp              = strInParm.startTimeStamp;
        strEqpMonitorDetailInfo.executionInterval           = strInParm.executionInterval;
        strEqpMonitorDetailInfo.warningInterval             = strInParm.warningInterval;
        strEqpMonitorDetailInfo.expirationInterval          = strInParm.expirationInterval;
        strEqpMonitorDetailInfo.standAloneFlag              = strInParm.standAloneFlag;
        strEqpMonitorDetailInfo.kitFlag                     = strInParm.kitFlag;
        strEqpMonitorDetailInfo.maxRetryCount               = strInParm.maxRetryCount;
        strEqpMonitorDetailInfo.eqpStateAtStart             = strInParm.eqpStateAtStart;
        strEqpMonitorDetailInfo.eqpStateAtPassed            = strInParm.eqpStateAtPassed;
        strEqpMonitorDetailInfo.eqpStateAtFailed            = strInParm.eqpStateAtFailed;
        strEqpMonitorDetailInfo.strEqpMonitorActionInfoSeq  = strInParm.strEqpMonitorActionInfoSeq;
        strEqpMonitorDetailInfo.strEqpMonitorSubInfoSeq     = strInParm.strEqpMonitorSubInfoSeq; //INN-R170016

        //Set default warningTime
        strEqpMonitorDetailInfo.warningTime = CIMFWStrDup("");

        //Set default lastMonitorTimeStamp
        strEqpMonitorDetailInfo.lastMonitorTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

        //Set default lastMonitorResult
        strEqpMonitorDetailInfo.lastMonitorResult = CIMFWStrDup("");

        //Set default scheduleAdjustment
        strEqpMonitorDetailInfo.scheduleAdjustment = 0;

        if ( 0 == CIMFWStrCmp(strInParm.monitorType, SP_EqpMonitor_Type_Routine) )
        {
            PPT_METHODTRACE_V1("", "monitorType is Routine");

            //Calculate and set scheduleBaseTimeStamp
            CORBA::Long minutes;
            minutes = 0 - strInParm.executionInterval;
            objTimeStamp_DoCalculation_out strTimeStamp_DoCalculation_out;
            rc = timeStamp_DoCalculation( strTimeStamp_DoCalculation_out,
                                          strObjCommonIn,
                                          strInParm.startTimeStamp,
                                          0,0,
                                          minutes,
                                          0,0 );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "timeStamp_DoCalculation() != RC_OK", rc);
                strEqpMonitorUpdateReqResult.strResult = strTimeStamp_DoCalculation_out.strResult;
                return rc;
            }
            strEqpMonitorDetailInfo.scheduleBaseTimeStamp = strTimeStamp_DoCalculation_out.targetTimeStamp;

            //Set InParm.startTimeStamp to lastMonitorPassedTimeStamp
            strEqpMonitorDetailInfo.lastMonitorPassedTimeStamp = strInParm.startTimeStamp;
        }
        else
        {
            PPT_METHODTRACE_V1("", "monitorType is Manual");

            //Set default scheduleBaseTimeStamp
            strEqpMonitorDetailInfo.scheduleBaseTimeStamp = CIMFWStrDup(SP_TIMESTAMP_NIL_OBJECT_STRING);

            //Set present time to lastMonitorPassedTimeStamp
            objTimeStamp_GetDR_out strTimeStamp_GetDR_out;
            rc = timeStamp_GetDR(strTimeStamp_GetDR_out, strObjCommonIn);
            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V2("", "timeStamp_GetDR() != RC_OK", rc);
                strEqpMonitorUpdateReqResult.strResult = strTimeStamp_GetDR_out.strResult;
                return rc;
            }
            strEqpMonitorDetailInfo.lastMonitorPassedTimeStamp = strTimeStamp_GetDR_out.currentTimeStamp;
        }
    }
    else if ( 0 == CIMFWStrCmp(strInParm.actionType, SP_EqpMonitor_OpeCategory_Update) )
    {
        PPT_METHODTRACE_V1("", "actionType is Update");
        //Get EqpMonitor information
//INN-R170016        objEqpMonitor_info_Get_out strEqpMonitor_info_Get_out;
        csObjEqpMonitor_info_Get_out strEqpMonitor_info_Get_out; //INN-R170016
        objEqpMonitor_info_Get_in  strEqpMonitor_info_Get_in;
        strEqpMonitor_info_Get_in.eqpMonitorID = strInParm.eqpMonitorID;
//INN-R170016        rc = eqpMonitor_info_Get( strEqpMonitor_info_Get_out,
        rc = cs_eqpMonitor_info_GetDR( strEqpMonitor_info_Get_out, //INN-R170016
                                  strObjCommonIn,
                                  strEqpMonitor_info_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cs_eqpMonitor_info_GetDR() != RC_OK", rc);
            strEqpMonitorUpdateReqResult.strResult = strEqpMonitor_info_Get_out.strResult;
            return rc;
        }

        strEqpMonitorDetailInfo = strEqpMonitor_info_Get_out.strEqpMonitorDetailInfos[0];

        if ( 0 == CIMFWStrCmp(strInParm.monitorType, SP_EqpMonitor_Type_Routine) )
        {
            PPT_METHODTRACE_V1("", "monitorType is Routine");
            if ( 0 != CIMFWStrCmp(strInParm.startTimeStamp, strEqpMonitorDetailInfo.startTimeStamp) )
            {
                PPT_METHODTRACE_V1("", "strInParm.startTimeStamp != strEqpMonitorDetailInfo.startTimeStamp");
                //startTimeStamp changed, recalculate scheduleBaseTimeStamp
                CORBA::Long minutes;
                minutes = 0 - strInParm.executionInterval;
                objTimeStamp_DoCalculation_out strTimeStamp_DoCalculation_out;
                rc = timeStamp_DoCalculation( strTimeStamp_DoCalculation_out,
                                              strObjCommonIn,
                                              strInParm.startTimeStamp,
                                              0,0,
                                              minutes,
                                              0,0 );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "timeStamp_DoCalculation() != RC_OK", rc);
                    strEqpMonitorUpdateReqResult.strResult = strTimeStamp_DoCalculation_out.strResult;
                    return rc;
                }
                strEqpMonitorDetailInfo.scheduleBaseTimeStamp = strTimeStamp_DoCalculation_out.targetTimeStamp;
            }
            else if ( strInParm.executionInterval != strEqpMonitorDetailInfo.executionInterval )
            {
                PPT_METHODTRACE_V1("", "strInParm.executionInterval != strEqpMonitorDetailInfo.executionInterval");
                //executionInterval changed, recalculate scheduleBaseTimeStamp
                CORBA::Long minutes;
                minutes = 0 - strInParm.executionInterval;
                objTimeStamp_DoCalculation_out strTimeStamp_DoCalculation_out;
                rc = timeStamp_DoCalculation( strTimeStamp_DoCalculation_out,
                                              strObjCommonIn,
                                              strEqpMonitorDetailInfo.nextExecutionTime,
                                              0,0,
                                              minutes,
                                              0,0 );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "timeStamp_DoCalculation() != RC_OK", rc);
                    strEqpMonitorUpdateReqResult.strResult = strTimeStamp_DoCalculation_out.strResult;
                    return rc;
                }
                strEqpMonitorDetailInfo.scheduleBaseTimeStamp = strTimeStamp_DoCalculation_out.targetTimeStamp;
            }

            if ( 0 != CIMFWStrCmp(strInParm.startTimeStamp, strEqpMonitorDetailInfo.startTimeStamp)
              || strInParm.executionInterval != strEqpMonitorDetailInfo.executionInterval )
            {
                PPT_METHODTRACE_V1("", "strInParm.startTimeStamp != strEqpMonitorDetailInfo.startTimeStamp or strInParm.executionInterval != strEqpMonitorDetailInfo.executionInterval");
                //Set scheduleAdjustment
                strEqpMonitorDetailInfo.scheduleAdjustment = 0;
            }

            if ( 0 != CIMFWStrCmp(strInParm.startTimeStamp, strEqpMonitorDetailInfo.startTimeStamp)
              || strInParm.expirationInterval != strEqpMonitorDetailInfo.expirationInterval )
            {
                PPT_METHODTRACE_V1("", "strInParm.startTimeStamp != strEqpMonitorDetailInfo.startTimeStamp or strInParm.expirationInterval != strEqpMonitorDetailInfo.expirationInterval");
                //Recalculate nextExecutionTime
                objEqpMonitor_nextExecutionTime_Calculate_out strEqpMonitor_nextExecutionTime_Calculate_out;
                objEqpMonitor_nextExecutionTime_Calculate_in  strEqpMonitor_nextExecutionTime_Calculate_in;
                strEqpMonitor_nextExecutionTime_Calculate_in.currentScheduleBaseTime = strEqpMonitorDetailInfo.scheduleBaseTimeStamp;
                strEqpMonitor_nextExecutionTime_Calculate_in.executionInterval       = strInParm.executionInterval;
                strEqpMonitor_nextExecutionTime_Calculate_in.scheduleAdjustment      = strEqpMonitorDetailInfo.scheduleAdjustment;
                strEqpMonitor_nextExecutionTime_Calculate_in.lastMonitorPassedTime   = strEqpMonitorDetailInfo.lastMonitorPassedTimeStamp;
                strEqpMonitor_nextExecutionTime_Calculate_in.expirationInterval      = strInParm.expirationInterval;
                strEqpMonitor_nextExecutionTime_Calculate_in.futureTimeRequireFlag   = FALSE;
                rc = eqpMonitor_nextExecutionTime_Calculate( strEqpMonitor_nextExecutionTime_Calculate_out,
                                                             strObjCommonIn,
                                                             strEqpMonitor_nextExecutionTime_Calculate_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "eqpMonitor_nextExecutionTime_Calculate() != RC_OK", rc);
                    strEqpMonitorUpdateReqResult.strResult = strEqpMonitor_nextExecutionTime_Calculate_out.strResult;
                    return rc;
                }
            }
        }

        //Set input parameters to strEqpMonitorDetailInfo
        strEqpMonitorDetailInfo.equipmentID                 = strInParm.equipmentID;
        strEqpMonitorDetailInfo.eqpMonitorID                = strInParm.eqpMonitorID;
        strEqpMonitorDetailInfo.chamberID                   = strInParm.chamberID;
        strEqpMonitorDetailInfo.description                 = strInParm.description;
        strEqpMonitorDetailInfo.monitorType                 = strInParm.monitorType;
        strEqpMonitorDetailInfo.scheduleType                = strInParm.scheduleType;
        strEqpMonitorDetailInfo.strEqpMonitorProductInfoSeq = strInParm.strEqpMonitorProductInfoSeq;
        strEqpMonitorDetailInfo.startTimeStamp              = strInParm.startTimeStamp;
        strEqpMonitorDetailInfo.executionInterval           = strInParm.executionInterval;
        strEqpMonitorDetailInfo.warningInterval             = strInParm.warningInterval;
        strEqpMonitorDetailInfo.expirationInterval          = strInParm.expirationInterval;
        strEqpMonitorDetailInfo.standAloneFlag              = strInParm.standAloneFlag;
        strEqpMonitorDetailInfo.kitFlag                     = strInParm.kitFlag;
        strEqpMonitorDetailInfo.maxRetryCount               = strInParm.maxRetryCount;
        strEqpMonitorDetailInfo.eqpStateAtStart             = strInParm.eqpStateAtStart;
        strEqpMonitorDetailInfo.eqpStateAtPassed            = strInParm.eqpStateAtPassed;
        strEqpMonitorDetailInfo.eqpStateAtFailed            = strInParm.eqpStateAtFailed;
        strEqpMonitorDetailInfo.strEqpMonitorActionInfoSeq  = strInParm.strEqpMonitorActionInfoSeq;
        strEqpMonitorDetailInfo.strEqpMonitorSubInfoSeq     = strInParm.strEqpMonitorSubInfoSeq; //INN-R170016
    }
    else if ( 0 == CIMFWStrCmp(strInParm.actionType, SP_EqpMonitor_OpeCategory_Delete) )
    {
        PPT_METHODTRACE_V1("", "actionType is Delete");

        //Make event
        objEqpMonitorChangeEvent_Make_out strEqpMonitorChangeEvent_Make_out;
        objEqpMonitorChangeEvent_Make_in  strEqpMonitorChangeEvent_Make_in;
        strEqpMonitorChangeEvent_Make_in.opeCategory               = CIMFWStrDup(SP_EqpMonitor_OpeCategory_Delete);
        strEqpMonitorChangeEvent_Make_in.eqpMonitorID              = strInParm.eqpMonitorID;
        strEqpMonitorChangeEvent_Make_in.transactionID             = strObjCommonIn.transactionID;
        strEqpMonitorChangeEvent_Make_in.previousMonitorStatus     = CIMFWStrDup("");
        strEqpMonitorChangeEvent_Make_in.previousNextExecutionTime = CIMFWStrDup("");
        strEqpMonitorChangeEvent_Make_in.claimMemo                 = claimMemo;
        rc = eqpMonitorChangeEvent_Make( strEqpMonitorChangeEvent_Make_out,
                                         strObjCommonIn,
                                         strEqpMonitorChangeEvent_Make_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "eqpMonitorChangeEvent_Make() != RC_OK", rc);
            strEqpMonitorUpdateReqResult.strResult = strEqpMonitorChangeEvent_Make_out.strResult;
            return rc;
        }

        //Change equipment monitor's Status into Deleted
        pptEqpMonitorStatusChangeRptResult strEqpMonitorStatusChangeRptResult;
        pptEqpMonitorStatusChangeRptInParm strEqpMonitorStatusChangeRptInParm;
        strEqpMonitorStatusChangeRptInParm.equipmentID       = strInParm.equipmentID;
        strEqpMonitorStatusChangeRptInParm.eqpMonitorID      = strInParm.eqpMonitorID;
        strEqpMonitorStatusChangeRptInParm.monitorStatus     = CIMFWStrDup(SP_EqpMonitor_Status_Deleted);
        strEqpMonitorStatusChangeRptInParm.forceRunFlag      = FALSE;
        strEqpMonitorStatusChangeRptInParm.warningActionFlag = FALSE;
        rc = txEqpMonitorStatusChangeRpt( strEqpMonitorStatusChangeRptResult,
                                          strObjCommonIn,
                                          strEqpMonitorStatusChangeRptInParm,
                                          claimMemo );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "txEqpMonitorStatusChangeRpt() != RC_OK", rc);
            strEqpMonitorUpdateReqResult.strResult = strEqpMonitorStatusChangeRptResult.strResult;
            return rc;
        }
        strEqpMonitorDetailInfo.equipmentID  = strInParm.equipmentID;
        strEqpMonitorDetailInfo.eqpMonitorID = strInParm.eqpMonitorID;
    }
    strEqpMonitorDetailInfo.lastClaimedTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
    strEqpMonitorDetailInfo.lastClaimedUser      = strObjCommonIn.strUser.userID;

    //Perform eqpMonitor update
    objEqpMonitor_info_Update_out strEqpMonitor_info_Update_out;
//INN-R170016    objEqpMonitor_info_Update_in  strEqpMonitor_info_Update_in;
    csObjEqpMonitor_info_Update_in  strEqpMonitor_info_Update_in; //INN-R170016
    strEqpMonitor_info_Update_in.strEqpMonitorDetailInfo = strEqpMonitorDetailInfo;
    strEqpMonitor_info_Update_in.actionType              = strInParm.actionType;
//INN-R170016    rc = eqpMonitor_info_Update( strEqpMonitor_info_Update_out,
    rc = cs_eqpMonitor_info_UpdateDR( strEqpMonitor_info_Update_out, //INN-R170016
                                 strObjCommonIn,
                                 strEqpMonitor_info_Update_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_eqpMonitor_info_Update() != RC_OK", rc);
        strEqpMonitorUpdateReqResult.strResult = strEqpMonitor_info_Update_out.strResult;
        return rc;
    }

    if ( 0 == CIMFWStrCmp(strInParm.actionType, SP_EqpMonitor_OpeCategory_Create) )
    {
        PPT_METHODTRACE_V1("", "actionType is Create");
        //Change equipment monitor's Status into Waiting
        pptEqpMonitorStatusChangeRptResult strEqpMonitorStatusChangeRptResult;
        pptEqpMonitorStatusChangeRptInParm strEqpMonitorStatusChangeRptInParm;
        strEqpMonitorStatusChangeRptInParm.equipmentID       = strInParm.equipmentID;
        strEqpMonitorStatusChangeRptInParm.eqpMonitorID      = strEqpMonitor_info_Update_out.eqpMonitorID;
        strEqpMonitorStatusChangeRptInParm.monitorStatus     = CIMFWStrDup(SP_EqpMonitor_Status_Waiting);
        strEqpMonitorStatusChangeRptInParm.forceRunFlag      = FALSE;
        strEqpMonitorStatusChangeRptInParm.warningActionFlag = FALSE;
        rc = txEqpMonitorStatusChangeRpt( strEqpMonitorStatusChangeRptResult,
                                          strObjCommonIn,
                                          strEqpMonitorStatusChangeRptInParm,
                                          claimMemo );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "txEqpMonitorStatusChangeRpt() != RC_OK", rc);
            strEqpMonitorUpdateReqResult.strResult = strEqpMonitorStatusChangeRptResult.strResult;
            return rc;
        }
    }

    if ( 0 == CIMFWStrCmp(strInParm.actionType, SP_EqpMonitor_OpeCategory_Create)
      || 0 == CIMFWStrCmp(strInParm.actionType, SP_EqpMonitor_OpeCategory_Update) )
    {
        //Make event
        objEqpMonitorChangeEvent_Make_out strEqpMonitorChangeEvent_Make_out;
        objEqpMonitorChangeEvent_Make_in  strEqpMonitorChangeEvent_Make_in;
        if ( 0 == CIMFWStrCmp(strInParm.actionType, SP_EqpMonitor_OpeCategory_Create) )
        {
            PPT_METHODTRACE_V1("", "actionType is Create");
            strEqpMonitorChangeEvent_Make_in.opeCategory = CIMFWStrDup(SP_EqpMonitor_OpeCategory_Create);
        }
        if ( 0 == CIMFWStrCmp(strInParm.actionType, SP_EqpMonitor_OpeCategory_Update) )
        {
            PPT_METHODTRACE_V1("", "actionType is Update");
            strEqpMonitorChangeEvent_Make_in.opeCategory = CIMFWStrDup(SP_EqpMonitor_OpeCategory_Update);
        }
        strEqpMonitorChangeEvent_Make_in.eqpMonitorID              = strEqpMonitor_info_Update_out.eqpMonitorID;
        strEqpMonitorChangeEvent_Make_in.transactionID             = strObjCommonIn.transactionID;
        strEqpMonitorChangeEvent_Make_in.previousMonitorStatus     = CIMFWStrDup("");
        strEqpMonitorChangeEvent_Make_in.previousNextExecutionTime = CIMFWStrDup("");
        strEqpMonitorChangeEvent_Make_in.claimMemo                 = claimMemo;
        rc = eqpMonitorChangeEvent_Make( strEqpMonitorChangeEvent_Make_out,
                                         strObjCommonIn,
                                         strEqpMonitorChangeEvent_Make_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "eqpMonitorChangeEvent_Make() != RC_OK", rc);
            strEqpMonitorUpdateReqResult.strResult = strEqpMonitorChangeEvent_Make_out.strResult;
            return rc;
        }
    }

    // Return to caller
    SET_MSG_RC( strEqpMonitorUpdateReqResult, MSG_OK, RC_OK );
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txEqpMonitorUpdateReq");
    return RC_OK;
}