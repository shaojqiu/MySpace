//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txDowngradeItemListInq.cpp
//
#include "cs_pptmgr.hpp"
//
// Class: PPTManager
//
// Service: txDowngradeItemListInq()
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------- -------------- -------------------------------------------
// 2017-10-18 INN-R170016   Yangxiaojun    NPW Monitor Customization 
//
// Description:
//
// Return:
//     long
//
// Parameter:
//     csDowngradeItemListInqResult&            strDowngradeItemListInqResult
//     const pptObjCommonIn&                    strObjCommonIn
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//
CORBA::Long CS_PPTManager_i::cs_txDowngradeItemListInq(
    csDowngradeItemListInqResult&            strDowngradeItemListInqResult,
    const pptObjCommonIn&                    strObjCommonIn
  	CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txDowngradeItemListInq")
    CORBA::Long rc = RC_OK;
        
    //---------------------------
    //  Get Downgrade Item list
    //---------------------------
    csObjDowngradeItemList_GetDR_out strCsObjDowngradeItemList_GetDR_out;
    csObjDowngradeItemList_GetDR_in strCsObjDowngradeItemList_GetDR_in;
    strCsObjDowngradeItemList_GetDR_in.dcDefID = strDowngradeItemListInqResult.dcDefID;
    strCsObjDowngradeItemList_GetDR_in.candidateFlag = TRUE;
    PPT_METHODTRACE_V2("", "strCsObjDowngradeItemList_GetDR_in.dcDefID", strCsObjDowngradeItemList_GetDR_in.dcDefID.identifier);
    PPT_METHODTRACE_V2("", "strCsObjDowngradeItemList_GetDR_in.candidateFlag", strCsObjDowngradeItemList_GetDR_in.candidateFlag);
    rc = cs_downgradeItemList_GetDR (strCsObjDowngradeItemList_GetDR_out, strObjCommonIn, strCsObjDowngradeItemList_GetDR_in);

    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cs_txDowngradeItemListInq() != RC_OK");
        strDowngradeItemListInqResult.strResult = strCsObjDowngradeItemList_GetDR_out.strResult;
        return( rc );
    }
    strDowngradeItemListInqResult.dcDefID = strCsObjDowngradeItemList_GetDR_out.dcDefID;
    PPT_METHODTRACE_V2("", "strCsObjDowngradeItemList_GetDR_out.dcDefID", strCsObjDowngradeItemList_GetDR_out.dcDefID.identifier);
    strDowngradeItemListInqResult.selectedDCItems = strCsObjDowngradeItemList_GetDR_out.selectedDCItems;
    strDowngradeItemListInqResult.candidateDCItems = strCsObjDowngradeItemList_GetDR_out.candidateDCItems;
    
    //---------------------------
    //  Set out structure
    //---------------------------
    SET_MSG_RC(strDowngradeItemListInqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txDowngradeItemListInq")
    return( RC_OK );

}