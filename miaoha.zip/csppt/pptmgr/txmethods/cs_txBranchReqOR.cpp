#ifndef lint
static char *sccsid =  "@(#) 1.9 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txBranchReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/20/07 19:55:59 [ 11/20/07 19:56:00 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2014. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2014. All rights reserved.
//
// SiView
// Name: cs_txBranchReqOR.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: txBranchReq()
//
// Change history:
// Date       Defect#     Person        Comments
// ---------- ----------  ------------- -------------------------------------------
// 2002/01/01 D4100021    Y.Nagamine     Initial Release
// 2002/01/21 D4100020    N.Maeda        Change oldCurrentPOS to oldcCurrentPOData
// 2002/02/05 D4100036    S.Tokumasu     Add limitaion for flowbatch
// 2002/02/19 D4100021-1  Y.Nagamine     TRUE -> 0
// 2002/02/21 D4100021-2  Y.Nagamine     Add transction ID logic
// 2002/02/28 D4100120    N.Minami       Future Action
// 2002/03/03 D4100021-3  Y.Nagamine     Change logic
// 2002/03/07 D4100021-4  T.Michii       Change & Add check logic
// 2002/03/12 D4100021-5  Y.Nagamine     Change message
// 2002/03/25 D4100210    H.Adachi       Add InParameter CurrentRouteID & CurrentOperationNum For Check Condition
// 2002/07/29 D4200029    K.Kimura       Process Hold Control
// 2002/10/17 P4200235    H.Adachi       Add Cassette Xfer Status Check Logic
// 2002/11/13 P4200351    K.Matsuei      Add check return operation with Rework/Branch.
// 2003/01/16 P4200491    H.Adachi       Change Transaction ID for Operation History.
// 2003/06/03 P5000060    K.Matsuei      TxReworkReq and TxBranchReq could not work correctly when These are called from Script.
// 2003/09/09 P5000145    H.Adachi       Fix Message and Message Macro mismatch.
// 10/22/04   D6000025    K.Murakami     eBroker Migration.
// 2006/04/25 D7000213    Y.Kadowaki     Add TxID for carrier Xfer State check.
// 2006/05/18 D7000092    Y.Kadowaki     Add object lock for cassette.
// 2007/08/03 D9000056    H.Hotta        Add check logic for InPostProcessFlag.
// 2007/09/20 D9000079    D.Tamura       FlowBatch Enhancement.
// 2007/11/05 D9000001    K.Matsuei      64bit support.
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
// 2008/10/31 DSIV00000214 S.Miyata       Multi Fab Transfer Support
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2010/03/19 DSIV00001830 S.Kawabe       Wafer Stacking Operation Support
// 2011/10/19 DSN000015229 M.Ogawa        Advanced Wafer Level Control
// 2013/01/23 DSN000050720 M.Ogawa        Skip cassette lock in Post Process parallel execution
// 2013/05/09 DSN000071674 C.Mo           Remove part of the EI state limitation
// 2014/07/28 DSN000085792 Sa Guo         Q-Time Improvements.
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/08/28 INN-R170002  Yangxiaojun    Overide txBranchReq
// 2017/09/08 INN-R170002  JQ.Shao        Contamination Control

// Description:
//
// Return:
//     long
//
// Parameter:
//
//      pptBranchReqResult& strBranchReqResult,
//      const pptObjCommonIn& strObjCommonIn,
//      const pptBranchReq& strBranchReq,
//      const char * claimMemo,
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::txBranchReq ( pptBranchReqResult& strBranchReqResult,
                                        const pptObjCommonIn& strObjCommonIn,
                                        const pptBranchReq& strBranchReq,
//D6000025                                         const char * claimMemo,
//D6000025                                         CORBA::Environment &IT_env)
                                        const char * claimMemo //D6000025
                                        CORBAENV_LAST_CPP)     //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::txBranchReq") ;
    CORBA::Long rc = RC_OK ;

    PPT_METHODTRACE_V2("", "in-param  lotID                 ", strBranchReq.lotID.identifier) ;
    PPT_METHODTRACE_V2("", "in-param  CurrentRouteID        ", strBranchReq.currentRouteID.identifier) ;  //D4100210
    PPT_METHODTRACE_V2("", "in-param  CurrentOperationNum   ", strBranchReq.currentOperationNumber) ;     //D4100210
    PPT_METHODTRACE_V2("", "in-param  subRouteID            ", strBranchReq.subRouteID.identifier) ;
    PPT_METHODTRACE_V2("", "in-param  returnOperationNumber ", strBranchReq.returnOperationNumber) ;

//D4100021-2 add
    //--------------------------------
    //   Decide TX_ID
    //--------------------------------

    CORBA::String_var  txID;
    if ( CIMFWStrLen(strBranchReq.eventTxId) > 0 )
    {
        txID = strBranchReq.eventTxId;
        PPT_METHODTRACE_V2("", "TX ID (Use Input TX ID )   : ", txID ) ;
    }
    else
    {
        if ( strBranchReq.bDynamicRoute == TRUE )
        {
            txID = CIMFWStrDup("TXEWC008");
            PPT_METHODTRACE_V2("", "TX ID (Dynamic Branch) : ", txID ) ;
        }
        else
        {
            txID = CIMFWStrDup("TXTRC034");
            PPT_METHODTRACE_V2("", "TX ID (Branch) : ", txID ) ;
        }
    }
//D4100021-2 end


    objectIdentifier aCassetteID ;

    //------------------------------------------------------------------------
    //   Get cassette / lot connection
    //------------------------------------------------------------------------
    objLot_cassette_Get_out strLot_cassette_Get_out ;
    rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, strBranchReq.lotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_cassette_Get() != RC_OK") ;
        strBranchReqResult.strResult = strLot_cassette_Get_out.strResult ;
        return(rc);
    }
    aCassetteID = strLot_cassette_Get_out.cassetteID ;

    //--------------------------------
    //   Lock objects to be updated
    //--------------------------------
    objObject_Lock_out strObject_Lock_out;
//D7000092 add start
//DSN000050720 Add Start
    // Get PostProcForLotFlag from thread specific data
    char* methodName = NULL;
    CORBA::String_var strParallelPostProcFlag;
    try
    {
        methodName = CIMFWStrDup("getThreadSpecificDataString");
        strParallelPostProcFlag = getThreadSpecificDataString(SP_ThreadSpecificData_Key_PostProcParallelFlag);
        CORBA::string_free(methodName);
        methodName = NULL;
    }
    CATCH_GLOBAL_EXCEPTIONS(strBranchReqResult, txBranchReq, methodName);

    PPT_METHODTRACE_V2("", "strParallelPostProcFlag", strParallelPostProcFlag);

    //----------------------------------------------------------//
    //   Skip cassette lock to increase parallel availability   //
    //   under PostProcess parallel execution                   //
    //----------------------------------------------------------//
    if ( 0 != CIMFWStrCmp(strParallelPostProcFlag, SP_PostProcess_ParallelExecution_ON) )
    {
        //PostProcess sequential execution
        PPT_METHODTRACE_V1("", "Lock cassette object.");
//DSN000050720 Add End
//DSN000050720 Indent Start
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, aCassetteID, SP_ClassName_PosCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() rc != RC_OK", rc);
            strBranchReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
//DSN000050720 Indent End
    }   //DSN000050720
//D7000092 add end

    rc = object_Lock( strObject_Lock_out, strObjCommonIn, strBranchReq.lotID, SP_ClassName_PosLot );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "object_Lock() rc != RC_OK" ) ;
        strBranchReqResult.strResult = strObject_Lock_out.strResult ;
        return( rc );
    }

    //D4100210 add start
    //--------------------------------------------------------------------------
    //   Check whether Lot is on the specified Route/Operation or Not
    //--------------------------------------------------------------------------
    PPT_METHODTRACE_V1("","Check whether Lot is on the specified Route/Operation or Not...");

    objectIdentifier  tmpCurrentRouteID         = strBranchReq.currentRouteID;
    CORBA::String_var tmpCurrentOperationNumber = CIMFWStrDup(strBranchReq.currentOperationNumber);
    objectIdentifier aLotID = strBranchReq.lotID;

    if ((CIMFWStrLen(tmpCurrentRouteID.identifier) != 0)&&
        (CIMFWStrLen(tmpCurrentOperationNumber) != 0))
    {
        PPT_METHODTRACE_V1("","InPara Current Info is Not Null. Begin to Check!!");

        objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
        rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out, strObjCommonIn, aLotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_currentOperationInfo_Get() != RC_OK");
            strBranchReqResult.strResult  = strLot_currentOperationInfo_Get_out.strResult;
            return( rc );
        }

        PPT_METHODTRACE_V2("","In-parm's routeID            :", tmpCurrentRouteID.identifier );
        PPT_METHODTRACE_V2("","In-Parm's operationNumber    :", tmpCurrentOperationNumber    );

        PPT_METHODTRACE_V2("","Lot's currentRouteID         :", strLot_currentOperationInfo_Get_out.routeID.identifier );
        PPT_METHODTRACE_V2("","Lot's currentOperationNumber :", strLot_currentOperationInfo_Get_out.operationNumber    );

        if ( CIMFWStrCmp(tmpCurrentRouteID.identifier, strLot_currentOperationInfo_Get_out.routeID.identifier) == 0 &&
             CIMFWStrCmp(tmpCurrentOperationNumber   , strLot_currentOperationInfo_Get_out.operationNumber   ) == 0 )
        {
            PPT_METHODTRACE_V1("","Route/Operation check OK. Go ahead...");
        }
        else
        {
            PPT_METHODTRACE_V1("","Route/Operation check NG.");
            PPT_SET_MSG_RC_KEY2(strBranchReqResult,
                                MSG_NOT_SAME_ROUTE,
                                RC_NOT_SAME_ROUTE,
                                "Input parameter's currentRouteID/currentOperationNumber",
                                "lot's current currentRouteID/currentOperationNumber");
            return( RC_NOT_SAME_ROUTE );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("","InPara Current Info is Null. No Check!!");
    }
    //D4100210 add end
    //------------------------------------------------------------------------
    //   Check Condition
    //------------------------------------------------------------------------
    objLot_holdState_Get_out strLot_holdState_Get_out ;
    rc = lot_holdState_Get(strLot_holdState_Get_out,strObjCommonIn,strBranchReq.lotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_holdState_Get() != RC_OK") ;
        strBranchReqResult.strResult = strLot_holdState_Get_out.strResult ;
        return(rc);
    }
    else if( (CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState,CIMFW_Lot_HoldState_OnHold)) == 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState,CIMFW_Lot_HoldState_OnHold)) == 0" ) ;
        PPT_SET_MSG_RC_KEY2(strBranchReqResult,
                            MSG_INVALID_LOT_HOLDSTAT,
                            RC_INVALID_LOT_HOLDSTAT,
                            strBranchReq.lotID.identifier,
                            strLot_holdState_Get_out.lotHoldState) ;
        return(RC_INVALID_LOT_HOLDSTAT);
    }

    objLot_state_Get_out strLot_state_Get_out ;
    rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn , strBranchReq.lotID ) ;
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_state_Get() != RC_OK");
        strBranchReqResult.strResult = strLot_state_Get_out.strResult ;
        return(rc);
    }
    else if( CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Active) != 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Active) != 0") ;
        PPT_SET_MSG_RC_KEY( strBranchReqResult,
                            MSG_INVALID_LOT_STAT,
                            RC_INVALID_LOT_STAT,
                            strLot_state_Get_out.lotState ) ;
        return(RC_INVALID_LOT_STAT);
    }

    objLot_processState_Get_out strLot_processState_Get_out ;
    rc = lot_processState_Get( strLot_processState_Get_out , strObjCommonIn , strBranchReq.lotID ) ;
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_processState_Get() != RC_OK") ;
        strBranchReqResult.strResult = strLot_processState_Get_out.strResult ;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Waiting) != 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Waiting) != 0 ") ;
        PPT_SET_MSG_RC_KEY2(strBranchReqResult,
                            MSG_INVALID_LOT_PROCSTAT,
                            RC_INVALID_LOT_PROCSTAT,
                            strBranchReq.lotID.identifier,
                            strLot_processState_Get_out.theLotProcessState) ;
        return(RC_INVALID_LOT_PROCSTAT);
    }

    objLot_inventoryState_Get_out strLot_inventoryState_Get_out ;
    rc = lot_inventoryState_Get( strLot_inventoryState_Get_out , strObjCommonIn , strBranchReq.lotID ) ;
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_inventoryState_Get() != RC_OK");
        strBranchReqResult.strResult = strLot_inventoryState_Get_out.strResult ;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState,SP_Lot_InventoryState_OnFloor) != 0)
    {
        PPT_METHODTRACE_V1("", "CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState,SP_Lot_InventoryState_OnFloor) != 0") ;
        PPT_SET_MSG_RC_KEY2( strBranchReqResult,
                             MSG_INVALID_LOT_INVENTORYSTAT,
                             RC_INVALID_LOT_INVENTORYSTAT,
                             strBranchReq.lotID.identifier,
                             strLot_inventoryState_Get_out.lotInventoryState ) ;
        return(RC_INVALID_LOT_INVENTORYSTAT);
    }

//D9000056 add start
    PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
    //----------------------------------
    //  Get InPostProcessFlag of Lot
    //----------------------------------
    objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
    objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
    strLot_inPostProcessFlag_Get_in.lotID = strBranchReq.lotID;

    rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                    strObjCommonIn,
                                    strLot_inPostProcessFlag_Get_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
        strBranchReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
        return( rc );
    }

    //----------------------------------------------
    //  If Lot is in post process, returns error
    //----------------------------------------------
    if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
    {
        PPT_METHODTRACE_V1("", "Lot is in post process.");
//DSIV00000201 Add Start
        /*---------------------------*/
        /* Get UserGroupID By UserID */
        /*---------------------------*/
        objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
        rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                         strObjCommonIn,
                                         strObjCommonIn.strUser.userID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
            strBranchReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
            return( rc );
        }
        objectIdentifierSequence userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
        CORBA::ULong userGroupIDsLen = userGroupIDs.length();
        PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);
        
        CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
        PPT_METHODTRACE_V2("", "extPostProc", extPostProc);
        
        CORBA::ULong nCnt = 0;
        for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
        {
            PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
            if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
            {
                PPT_METHODTRACE_V1("", "# External Post Process User!");
                break;
            }
            
        }
        if (nCnt == userGroupIDsLen)
        {
            PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
            PPT_SET_MSG_RC_KEY( strBranchReqResult,
                                MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                strBranchReq.lotID.identifier );
            return( RC_LOT_INPOSTPROCESS );
        }   //DSIV00000201
    }
//D9000056 add end

//DSIV00000214 add start
    //---------------------------------------
    // Check interFabXferPlan existence
    //---------------------------------------
    objProcess_CheckInterFabXferPlanSkip_in strProcess_CheckInterFabXferPlanSkip_in;
    strProcess_CheckInterFabXferPlanSkip_in.lotID = strBranchReq.lotID;
    strProcess_CheckInterFabXferPlanSkip_in.currentRouteID = strBranchReq.currentRouteID;
    strProcess_CheckInterFabXferPlanSkip_in.currentOpeNo = strBranchReq.currentOperationNumber;
    strProcess_CheckInterFabXferPlanSkip_in.jumpingRouteID = strBranchReq.currentRouteID;
    strProcess_CheckInterFabXferPlanSkip_in.jumpingOpeNo = strBranchReq.returnOperationNumber;

    objProcess_CheckInterFabXferPlanSkip_out strProcess_CheckInterFabXferPlanSkip_out;
    rc = process_CheckInterFabXferPlanSkip( strProcess_CheckInterFabXferPlanSkip_out,
                                            strObjCommonIn,
                                            strProcess_CheckInterFabXferPlanSkip_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "process_CheckInterFabXferPlanSkip() != RC_OK");
        strBranchReqResult.strResult = strProcess_CheckInterFabXferPlanSkip_out.strResult;
        return( rc );
    }
//DSIV00000214 add end

    //----------------------------------
    //   Check Lot's Control Job ID
    //----------------------------------
    objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, strBranchReq.lotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_controlJobID_Get() != RC_OK");
        strBranchReqResult.strResult = strLot_controlJobID_Get_out.strResult ;
        return(rc);
    }
    if (CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) == 0)
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) = 0") ;
        rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) > 0") ;
        PPT_SET_MSG_RC_KEY2( strBranchReqResult,
                             MSG_LOT_CTLJOBID_FILLED,
                             RC_LOT_CTLJOBID_FILLED,
                             strBranchReq.lotID.identifier,
                             strLot_controlJobID_Get_out.controlJobID.identifier ) ;
        return( RC_LOT_CTLJOBID_FILLED );
    }

    //----------------------------------------------------------
    //   Convers input subrouteID if it has the version ##
    //----------------------------------------------------------
    objectIdentifier aSubRouteID ;

    objProcess_activeID_Get_out strProcess_activeID_Get_out ;
    rc = process_activeID_Get(strProcess_activeID_Get_out, strObjCommonIn, strBranchReq.subRouteID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "process_activeID_Get() != RC_OK") ;
        strBranchReqResult.strResult = strProcess_activeID_Get_out.strResult ;
        return(rc);
    }
    aSubRouteID = strProcess_activeID_Get_out.activeID;
    PPT_METHODTRACE_V2("", "active subRouteID = ", aSubRouteID.identifier) ;

    //-----------------------------------
    //   Check Route is Dynamic or Not
    //-----------------------------------
    if ( strBranchReq.bDynamicRoute == TRUE )
    {
        objProcess_checkForDynamicRoute_out strProcess_checkForDynamicRoute_out;

        rc = process_checkForDynamicRoute( strProcess_checkForDynamicRoute_out, strObjCommonIn, aSubRouteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "process_checkForDynamicRoute() rc != RC_OK" ) ;
            strBranchReqResult.strResult = strProcess_checkForDynamicRoute_out.strResult ;
            return( rc );
        }

        if ( strProcess_checkForDynamicRoute_out.bDynamicRoute == FALSE )
        {
            PPT_METHODTRACE_V1("", "strProcess_checkForDynamicRoute_out.bDynamicRoute != strBranchReq.bDynamicRoute" ) ;
            SET_MSG_RC( strBranchReqResult, MSG_NOT_DYNAMIC_ROUTE ,RC_NOT_DYNAMIC_ROUTE);
            return( RC_NOT_DYNAMIC_ROUTE );
        }
    }


    //-------------------------------------------------
    //   Check Input return operation number
    //-------------------------------------------------
    CORBA::Boolean inputReturnOperationFlag = FALSE;
    CORBA::String_var returnOperationNumberVar;

    if( ( strBranchReq.returnOperationNumber != NULL ) && ( CIMFWStrLen(strBranchReq.returnOperationNumber)!=0 ) )
    {
        PPT_METHODTRACE_V1("", "Set inputReturnOperationFlag = TRUE" ) ;
        inputReturnOperationFlag = TRUE ;
    }

    //------------------------------------------------------------------------
    //   Check Input return operation number is exist in connected route list
    //------------------------------------------------------------------------
    CORBA::Boolean connectedRouteReturnOperationFlag = FALSE;
    CORBA::Boolean sameReturnOperationExistFlag = FALSE;

//P4200351 start
    objProcess_checkForDynamicRoute_out strProcess_checkForDynamicRoute_out;
    rc = process_checkForDynamicRoute( strProcess_checkForDynamicRoute_out, strObjCommonIn, aSubRouteID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("CS_PPTManager_i:: txBranchReq", "process_checkForDynamicRoute() != RC_OK", rc);
        strBranchReqResult.strResult = strProcess_checkForDynamicRoute_out.strResult;
        return(rc);
    }
//D9000001    PPT_METHODTRACE_V2("CS_PPTManager_i:: txBranchReq", "bDynamicRoute", (long)strProcess_checkForDynamicRoute_out.bDynamicRoute);
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txBranchReq", "bDynamicRoute", (CORBA::Long)strProcess_checkForDynamicRoute_out.bDynamicRoute); //D9000001
//P4200351 end

    objProcess_GetReturnOperation_out strProcess_GetReturnOperation_out;
    rc = process_GetReturnOperation( strProcess_GetReturnOperation_out, strObjCommonIn, strBranchReq.lotID, aSubRouteID );

    if (rc == RC_NOT_FOUND_SUBROUTE )
    {
        PPT_METHODTRACE_V1("", "process_GetReturnOperation() == RC_NOT_FOUND_SUBROUTE") ;
    }
    else if (rc == RC_OK)
    {
        PPT_METHODTRACE_V1("", "Set connectedRouteReturnOperationFlag = TRUE") ;
        connectedRouteReturnOperationFlag = TRUE;

//D4100021-1        if ( CIMFWStrCmp( strProcess_GetReturnOperation_out.operationNumber, strBranchReq.returnOperationNumber) ==TRUE )
        if ( CIMFWStrCmp( strProcess_GetReturnOperation_out.operationNumber, strBranchReq.returnOperationNumber) == 0 ) //D4100021-1
        {
            PPT_METHODTRACE_V1("", "Set sameReturnOperationExistFlag = TRUE") ;
            sameReturnOperationExistFlag = TRUE;
        }
//P4200351 start
//P5000060        else if ( TRUE != strProcess_checkForDynamicRoute_out.bDynamicRoute )
        else if ( TRUE != strProcess_checkForDynamicRoute_out.bDynamicRoute && 0 < CIMFWStrLen(strBranchReq.returnOperationNumber) ) //P5000060
        {
            PPT_METHODTRACE_V1("","return RC_INVALID_INPUT_PARM");
            SET_MSG_RC( strBranchReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }
//P4200351 end
    }
    else   // Error case
    {
        PPT_METHODTRACE_V2("", "process_GetReturnOperation() != RC_OK : ", rc) ;
        strBranchReqResult.strResult = strProcess_GetReturnOperation_out.strResult ;
        return(rc);
    }

    //----------------------------------------------
    // Get Currrent Route ID and Operation Number
    //----------------------------------------------
    objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
    rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out, strObjCommonIn, strBranchReq.lotID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","lot_currentOperationInfo_Get() != RC_OK : ", rc) ;
        strBranchReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult;
        return( rc );
    }
    PPT_METHODTRACE_V2("","currentRouteID         : ", strLot_currentOperationInfo_Get_out.routeID.identifier ) ;
    PPT_METHODTRACE_V2("","currentOperationNumber : ", strLot_currentOperationInfo_Get_out.operationNumber) ;

    //-------------------------------------------------
    // Decide return operation number using all flags
    //-------------------------------------------------
    if ( strBranchReq.bDynamicRoute == TRUE )
    {
        PPT_METHODTRACE_V1("", "strBranchReq.bDynamicRoute == TRUE") ;
        if ( inputReturnOperationFlag == TRUE )
        {
            PPT_METHODTRACE_V1("", "inputReturnOperationFlag == TRUE") ;
            returnOperationNumberVar = strBranchReq.returnOperationNumber;
        }
        else  // inputReturnOperationFlag == FALSE
        {
            PPT_METHODTRACE_V1("", "inputReturnOperationFlag == FALSE") ;
            if ( connectedRouteReturnOperationFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "connectedRouteReturnOperationFlag == TRUE") ;
                returnOperationNumberVar = strProcess_GetReturnOperation_out.operationNumber;
            }
            else
            {
                PPT_METHODTRACE_V1("", "connectedRouteReturnOperationFlag == TRUE") ;
                returnOperationNumberVar = strLot_currentOperationInfo_Get_out.operationNumber;
            }
        }
    }
    else  // strBranchReq.bDynamicRoute == FALSE
    {
        PPT_METHODTRACE_V1("", "strBranchReq.bDynamicRoute == FALSE") ;
//D4100021-4 Add Start
        if ( connectedRouteReturnOperationFlag == TRUE )
        {
            PPT_METHODTRACE_V1("", "connectedRouteReturnOperationFlag == TRUE") ;

            if ( inputReturnOperationFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "inputReturnOperationFlag == TRUE") ;
                returnOperationNumberVar = strBranchReq.returnOperationNumber;
            }
            else
            {
                PPT_METHODTRACE_V1("", "inputReturnOperationFlag ==FALSE" ) ;
                returnOperationNumberVar = strProcess_GetReturnOperation_out.operationNumber;
            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "connectedRouteReturnOperationFlag ==FALSE" ) ;
//D4100021-5            SET_MSG_RC( strBranchReqResult, MSG_INVALID_BRANCH_ROUTEID,RC_INVALID_BRANCH_ROUTEID);
//D4100021-5            return( RC_INVALID_BRANCH_ROUTEID );
            SET_MSG_RC( strBranchReqResult, MSG_INVALID_ROUTE_ID,RC_INVALID_ROUTE_ID);      //D4100021-5
            return( RC_INVALID_ROUTE_ID );                                                  //D4100021-5
        }
    }

    //----------------------------------------------------
    //   Check ProcessDefinitionType is 'BRANCH' or not
    //----------------------------------------------------
    PPT_METHODTRACE_V1("", "Check ProcessDefinitionType is 'BRANCH' or not") ;

    if( CIMFWStrCmp( strProcess_GetReturnOperation_out.processDefinitionType, SP_MAINPDTYPE_BRANCH ) != 0 )
    {
        PPT_METHODTRACE_V1("", "processDefinitionType != SP_MAINPDTYPE_REWORK") ;
//D4100021-5        SET_MSG_RC( strBranchReqResult, MSG_INVALID_BRANCH_ROUTEID,RC_INVALID_BRANCH_ROUTEID);
//D4100021-5        return( RC_INVALID_BRANCH_ROUTEID );
        SET_MSG_RC( strBranchReqResult, MSG_INVALID_ROUTE_TYPE, RC_INVALID_ROUTE_TYPE);     //D4100021-5
        return( RC_INVALID_ROUTE_TYPE );                                                    //D4100021-5
    }

    //-----------------------------------------------------------
    //   Check decided return operation is exist on current route
    //-----------------------------------------------------------
    PPT_METHODTRACE_V1("", "Check decided return operation is exist on current route") ;

    pptRouteOperationListForLotInqResult strRouteOperationListForLotInqResult;
    rc = txRouteOperationListForLotInq( strRouteOperationListForLotInqResult,
                                        strObjCommonIn,
                                        strBranchReq.lotID);
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "txRouteOperationListForLotInq() != RC_OK" ) ;
        strBranchReqResult.strResult = strRouteOperationListForLotInqResult.strResult ;
        return(rc);
    }

    PPT_METHODTRACE_V2("","returnOperationNumberVar : ", returnOperationNumberVar ) ;

    CORBA::Long opeLen = strRouteOperationListForLotInqResult.strOperationNameAttributes.length();

    for (CORBA::Long opeCnt=0; opeCnt < opeLen; opeCnt++ )
    {
        PPT_METHODTRACE_V2("","opeCnt : ", opeCnt ) ;
        PPT_METHODTRACE_V2("","strRouteOperationListForLotInqResult.strOperationNameAttributes[opeCnt].operationNumber : ", strRouteOperationListForLotInqResult.strOperationNameAttributes[opeCnt].operationNumber ) ;

        if( CIMFWStrCmp( strRouteOperationListForLotInqResult.strOperationNameAttributes[opeCnt].operationNumber,
                         returnOperationNumberVar ) == 0 )
        {
            PPT_METHODTRACE_V1("", "return operation is exist on current route") ;
            break;
        }
        else if ( opeCnt == opeLen - 1 )
        {

            PPT_METHODTRACE_V1("", "opeCnt == opeLen - 1") ;
            PPT_SET_MSG_RC_KEY(strBranchReqResult, MSG_NOT_FOUND_OPERATION, RC_NOT_FOUND_OPERATION, returnOperationNumberVar);
            return( RC_NOT_FOUND_OPERATION );
        }
    }
//D4100021-4 Add End
//D4100021-4 Del Start
//      if ( inputReturnOperationFlag ==TRUE )                                                                     //D4100021-3
//      {
//            PPT_METHODTRACE_V1("", "inputReturnOperationFlag ==TRUE") ;                  //D4100021-3
//          returnOperationNumberVar = strBranchReq.returnOperationNumber;                                         //D4100021-3
//      }
//      else
//      {
//          if ( connectedRouteReturnOperationFlag == TRUE )                                                       //D4100021-3
//          {                                                                                                      //D4100021-3
//                  PPT_METHODTRACE_V1("", "connectedRouteReturnOperationFlag == TRUE") ;    //D4100021-3
//              returnOperationNumberVar = strProcess_GetReturnOperation_out.operationNumber;                      //D4100021-3
//          }                                                                                                      //D4100021-3
//            else                                                                                                   //D4100021-3
//          {
//              PPT_METHODTRACE_V1("", "connectedRouteReturnOperationFlag ==FALSE" ) ;
//              SET_MSG_RC( strBranchReqResult, MSG_INVALID_BRANCH_ROUTEID,RC_INVALID_BRANCH_ROUTEID);
//              return( RC_INVALID_BRANCH_ROUTEID );
//          }
//      }
//
//  }
//
//  //-----------------------------------------------------------
//  //   Check decided return operation is exist on current route
//  //-----------------------------------------------------------
//  CORBA::Long searchCount = 1 ;
//  objProcess_operationListForRoute_out strProcess_operationListForRoute_out;
//  rc = process_operationListForRoute( strProcess_operationListForRoute_out,
//                                      strObjCommonIn,
//                                      strLot_currentOperationInfo_Get_out.routeID,
//                                      returnOperationNumberVar,
//                                      searchCount );
//  if( rc != RC_OK )
//  {
//      PPT_METHODTRACE_V1("", "process_operationListForRoute() != RC_OK" ) ;
//      strBranchReqResult.strResult = strProcess_operationListForRoute_out.strResult ;
//      return(rc);
//  }
//D4100021-4 Del End

    // ------------------------------------------------------------
    // Check routeID confliction
    //   return RC_INVALID_BRANCH_ROUTEID,
    //   when the same routeID is used in the following case
    //       ex) Subroute --> The same SubRoute in the course
    // ------------------------------------------------------------
    PPT_METHODTRACE_V1("", "lot_originalRouteList_Get IN ");
    objLot_originalRouteList_Get_out  strLot_originalRouteList_Get_out;
    rc = lot_originalRouteList_Get( strLot_originalRouteList_Get_out,
                                    strObjCommonIn,strBranchReq.lotID);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "lot_originalRouteList_Get() != RC_OK", rc);
        strBranchReqResult.strResult = strLot_originalRouteList_Get_out.strResult ;
        return( rc );
    }

    CORBA::Long kLen = strLot_originalRouteList_Get_out.originalRouteID.length();
    PPT_METHODTRACE_V2("", "strLot_originalRouteList_Get_out.originalRouteID.length=", kLen);

    //Check CurrentRoute VS SubRoute
    if(CIMFWStrCmp(strLot_currentOperationInfo_Get_out.routeID.identifier,aSubRouteID.identifier ) == 0) //P40A0012
    {
        PPT_METHODTRACE_V2("", "currentRouteID = subRouteID len =: ", kLen);
        SET_MSG_RC( strBranchReqResult, MSG_INVALID_BRANCH_ROUTEID,RC_INVALID_BRANCH_ROUTEID);
        return( RC_INVALID_BRANCH_ROUTEID );
    }

    //Check Afetr Route VS SubRoute
    for(CORBA::Long iLoop = 0;iLoop < kLen ;iLoop++)
    {
        PPT_METHODTRACE_V2("",
                           "strLot_originalRouteList_Get_out.originalRouteID = ", strLot_originalRouteList_Get_out.originalRouteID[iLoop].identifier);

        if(CIMFWStrCmp(strLot_originalRouteList_Get_out.originalRouteID[iLoop].identifier,aSubRouteID.identifier ) == 0) //P40A0012
        {
            PPT_METHODTRACE_V2("", "OriginalRouteID[iLoop].identifier == subRouteID iLoop = ", iLoop);
            SET_MSG_RC( strBranchReqResult, MSG_INVALID_BRANCH_ROUTEID,RC_INVALID_BRANCH_ROUTEID);
            return( RC_INVALID_BRANCH_ROUTEID );
        }
    }

    //---------------------------------
    //   Check Future Hold
    //---------------------------------
    PPT_METHODTRACE_V1("", "lot_futureHoldRequests_CheckBranch");
    objLot_futureHoldRequests_CheckBranch_out strLot_futureHoldRequests_CheckBranch_out;
    rc = lot_futureHoldRequests_CheckBranch( strLot_futureHoldRequests_CheckBranch_out ,
                                             strObjCommonIn ,
                                             strBranchReq.lotID ,
                                             returnOperationNumberVar ) ;
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_futureHoldRequests_CheckBranch()  RC") ;
        strBranchReqResult.strResult = strLot_futureHoldRequests_CheckBranch_out.strResult ;
        return(rc);
    }

//D4100120 Add Start
    /*-----------------------------------*/
    /*   Check Future Action Procedure   */
    /*-----------------------------------*/
    PPT_METHODTRACE_V1("", "schdlChangeReservation_CheckForFutureOperation");
    CORBA::String_var tmpRouteID = strLot_currentOperationInfo_Get_out.routeID.identifier;
    PPT_METHODTRACE_V2("","tmpRouteID",tmpRouteID);
    PPT_METHODTRACE_V2("","returnOperationNumberVar",returnOperationNumberVar);

    objSchdlChangeReservation_CheckForFutureOperation_out strSchdlChangeReservation_CheckForFutureOperation_out;
    rc = schdlChangeReservation_CheckForFutureOperation(strSchdlChangeReservation_CheckForFutureOperation_out,
                                                        strObjCommonIn,
                                                        strBranchReq.lotID,
                                                        tmpRouteID,
                                                        returnOperationNumberVar);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "schdlChangeReservation_CheckForFutureOperation() != RC_OK") ;
        strBranchReqResult.strResult = strSchdlChangeReservation_CheckForFutureOperation_out.strResult;
        return(rc);
    }
//D4100120 Add End

//DSN000071674 add start
    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );
    if ( 1 == lotOperationEIcheck )
    {
        PPT_METHODTRACE_V1("", "lotOperationEIcheck = 1") ;
//DSN000071674 add end
        //P4200235 Add Start
        //-------------------------------------
        // Check Cassette Xfer Stat
        // Does not Check OpeComp, ForceOpeComp
        //  and OpeStartCancel -- D7000213
        //-------------------------------------
        if ( CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC004") != 0 &&
             CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC010") != 0 &&
             CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC011") != 0 &&
             CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC055") != 0 &&
             CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC015") != 0 &&  //TxPartialOpeCompWithDataReq           //DSN000015229
             CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC016") != 0 &&  //TxPartialOpeCompForInternalBufferReq  //DSN000015229
             CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC003") != 0 &&  //D7000213
             CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC061") != 0 )   //D7000213
        {
            PPT_METHODTRACE_V2("","Cassette Xfer Status Check Start For Transaction:",strObjCommonIn.transactionID);

            objCassette_transferState_Get_out  strCassette_transferState_Get_out;
            rc = cassette_transferState_Get( strCassette_transferState_Get_out, strObjCommonIn, aCassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "cassette_transferState_Get() != RC_OK") ;
                strBranchReqResult.strResult = strCassette_transferState_Get_out.strResult;
                return( rc );
            }

            if ( CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn ) == 0 )

            {
                PPT_METHODTRACE_V2("", "Csssette Xfer Status is", strCassette_transferState_Get_out.transferState) ;
                PPT_SET_MSG_RC_KEY2( strBranchReqResult,
                                     MSG_INVALID_CAST_XFERSTAT,
                                     RC_INVALID_CAST_XFERSTAT,
                                     strCassette_transferState_Get_out.transferState,
                                     aCassetteID.identifier ) ;
                return( RC_INVALID_CAST_XFERSTAT );
            }
        }
        //P4200235 Add End
    } //DSN000071674
//D9000079 add start
    //--------------------------------------------------------------------------------------------------
    // Check Flow Batch Condition.
    //
    // FlowBatched Lot :
    //   Can NOT Branch on a Branch Route which returns outside the flow batch section.
    //   Can NOT Branch on a Branch Route which returns to the operation beyond a target process.
    // Not FlowBatched Lot :
    //   Can NOT Branch on a Branch Route which returns to the flow batch section.
    //--------------------------------------------------------------------------------------------------
    objLot_CheckFlowBatchConditionForBranch_out strLot_CheckFlowBatchConditionForBranch_out;
    objLot_CheckFlowBatchConditionForBranch_in  strLot_CheckFlowBatchConditionForBranch_in;
    strLot_CheckFlowBatchConditionForBranch_in.strBranchReq = strBranchReq;

        /* ------------------------------------------ */
        /*  Check input parameters are empty or not.  */
        /* ------------------------------------------ */
    if ( 0 == CIMFWStrLen( strBranchReq.currentRouteID.identifier ))
    {
        PPT_METHODTRACE_V1("", "strBranchReq.currentRouteID is empty.") ;
        strLot_CheckFlowBatchConditionForBranch_in.strBranchReq.currentRouteID = strLot_currentOperationInfo_Get_out.routeID ;
    }
    if ( 0 == CIMFWStrLen( strBranchReq.currentOperationNumber ))
    {
        PPT_METHODTRACE_V1("", "strBranchReq.currentOperationNumber is empty.") ;
        strLot_CheckFlowBatchConditionForBranch_in.strBranchReq.currentOperationNumber = strLot_currentOperationInfo_Get_out.operationNumber ;
    }
    if ( 0 == CIMFWStrLen( strBranchReq.returnOperationNumber ))
    {
        PPT_METHODTRACE_V1("", "strBranchReq.returnOperationNumber is empty.") ;
        strLot_CheckFlowBatchConditionForBranch_in.strBranchReq.returnOperationNumber = strProcess_GetReturnOperation_out.operationNumber ;
    }

    rc = lot_CheckFlowBatchConditionForBranch( strLot_CheckFlowBatchConditionForBranch_out,
                                               strObjCommonIn,
                                               strLot_CheckFlowBatchConditionForBranch_in);

    if ( rc == RC_NOT_LOCATETO_BATCHOPE || rc == RC_LOT_REMOVE_FROM_BATCH || rc == RC_NOT_LOCATETO_OVERTARGET )
    {
        PPT_METHODTRACE_V2("", "lot_flowBatch_CheckLocate() != RC_OK", rc) ;
        ostrstream  errorMsg;
        if ( rc == RC_NOT_LOCATETO_BATCHOPE )
        {
            errorMsg << "Return point of the branch route is in a FlowBatch Section.";
        }
        else if ( rc == RC_LOT_REMOVE_FROM_BATCH )
        {
            errorMsg << "FlowBatched lots cannot go out of the FlowBatch Section.";
        }
        else if ( rc == RC_NOT_LOCATETO_OVERTARGET )
        {
            errorMsg << "FlowBatched lots cannot jump over the target operation in the FlowBatch Section. ";
        }
        errorMsg << ends;

        PPT_SET_MSG_RC_KEY( strLot_CheckFlowBatchConditionForBranch_out, MSG_NOT_BRANCH_BATCHOPE, RC_NOT_BRANCH_BATCHOPE, errorMsg.str());
        strBranchReqResult.strResult = strLot_CheckFlowBatchConditionForBranch_out.strResult ;
        errorMsg.rdbuf()->freeze(0);
        return RC_NOT_BRANCH_BATCHOPE ;
    }
    else if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_CheckFlowBatchConditionForBranch() != RC_OK") ;
        strBranchReqResult.strResult = strLot_CheckFlowBatchConditionForBranch_out.strResult ;
        return(rc);
    }
//D9000079 add end

//DSIV00001830 add start
    //--------------------------------------------------------------------------------------------------
    // Check Bonding Flow Condition.
    //--------------------------------------------------------------------------------------------------
    objLot_CheckBondingFlowSectionForBranch_out strLot_CheckBondingFlowSectionForBranch_out;
    objLot_CheckBondingFlowSectionForBranch_in  strLot_CheckBondingFlowSectionForBranch_in;
    strLot_CheckBondingFlowSectionForBranch_in.strBranchReq = strBranchReq;

    /* ------------------------------------------ */
    /*  Check input parameters are empty or not.  */
    /* ------------------------------------------ */
    if( 0 == CIMFWStrLen( strBranchReq.currentRouteID.identifier ) )
    {
        PPT_METHODTRACE_V1("", "strBranchReq.currentRouteID is empty.");
        strLot_CheckBondingFlowSectionForBranch_in.strBranchReq.currentRouteID = strLot_currentOperationInfo_Get_out.routeID;
    }
    if( 0 == CIMFWStrLen( strBranchReq.currentOperationNumber ) )
    {
        PPT_METHODTRACE_V1("", "strBranchReq.currentOperationNumber is empty.");
        strLot_CheckBondingFlowSectionForBranch_in.strBranchReq.currentOperationNumber = CIMFWStrDup(strLot_currentOperationInfo_Get_out.operationNumber);
    }
    if( 0 == CIMFWStrLen( strBranchReq.returnOperationNumber ) )
    {
        PPT_METHODTRACE_V1("", "strBranchReq.returnOperationNumber is empty.");
        strLot_CheckBondingFlowSectionForBranch_in.strBranchReq.returnOperationNumber = CIMFWStrDup(strProcess_GetReturnOperation_out.operationNumber);
    }

    rc = lot_CheckBondingFlowSectionForBranch( strLot_CheckBondingFlowSectionForBranch_out, strObjCommonIn, strLot_CheckBondingFlowSectionForBranch_in);

    if( rc == RC_NOT_LOCATETO_BONDINGFLOWSECTION )
    {
        PPT_METHODTRACE_V2("", "lot_CheckBondingFlowSectionForBranch() != RC_OK", rc);
        ostrstream  errorMsg;
        errorMsg << "Return point of the branch route is in a Bonding Flow Section.";
        errorMsg << ends;

        PPT_SET_MSG_RC_KEY( strLot_CheckFlowBatchConditionForBranch_out, MSG_NOT_BRANCH_BONDINGFLOW, RC_NOT_BRANCH_BONDINGFLOW, errorMsg.str());
        strBranchReqResult.strResult = strLot_CheckBondingFlowSectionForBranch_out.strResult;
        errorMsg.rdbuf()->freeze(0);
        return RC_NOT_BRANCH_BONDINGFLOW;
    }
    else if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_CheckBondingFlowSectionForBranch() != RC_OK");
        strBranchReqResult.strResult = strLot_CheckBondingFlowSectionForBranch_out.strResult;
        return rc;
    }
//DSIV00001830 add end
//DSN000085792 Add start
    objQTime_CheckConditionForReplaceTarget_in strQTime_CheckConditionForReplaceTarget_in;
    objQTime_CheckConditionForReplaceTarget_out strQTime_CheckConditionForReplaceTarget_out;
    strQTime_CheckConditionForReplaceTarget_in.lotID = strBranchReq.lotID;
    rc = qTime_CheckConditionForReplaceTarget(strQTime_CheckConditionForReplaceTarget_out,strObjCommonIn,strQTime_CheckConditionForReplaceTarget_in);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "qTime_CheckConditionForReplaceTarget() != RC_OK") ;
        strBranchReqResult.strResult = strQTime_CheckConditionForReplaceTarget_out.strResult ;
        return rc ;
    }
//DSN000085792 Add end
    //-----------------------------------------------------------
    // Route change request
    //-----------------------------------------------------------
    objProcess_BranchRoute_out strProcess_BranchRoute_out ;
    rc = process_BranchRoute( strProcess_BranchRoute_out,
                              strObjCommonIn,
                              strBranchReq.lotID,
                              aSubRouteID,
                              returnOperationNumberVar) ;
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "process_BranchRoute() != RC_OK") ;
        strBranchReqResult.strResult = strProcess_BranchRoute_out.strResult ;
        return rc ;
    }

//D9000079    //-------------------------------
//D9000079    //   Remove Lot from FlowBatch
//D9000079    //-------------------------------
//D9000079    objLot_flowBatchID_Get_out strLot_flowBatchID_Get_out;
//D9000079    rc = lot_flowBatchID_Get( strLot_flowBatchID_Get_out, strObjCommonIn, strBranchReq.lotID );
//D9000079
//D9000079    if ( rc == RC_LOT_FLOW_BATCH_ID_FILLED )
//D9000079    {
//D9000079        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get == RC_LOT_BATCH_ID_FILLED") ;
//D9000079        //D4100036 Start
//D9000079//P5000145        PPT_SET_MSG_RC_KEY( strBranchReqResult,
//D9000079//P5000145                            MSG_FLOW_BATCH_LIMITATION,
//D9000079//P5000145                            RC_FLOW_BATCH_LIMITATION,
//D9000079//P5000145                            "");
//D9000079        SET_MSG_RC( strBranchReqResult,                //P5000145
//D9000079                    MSG_FLOW_BATCH_LIMITATION,         //P5000145
//D9000079                    RC_FLOW_BATCH_LIMITATION );        //P5000145
//D9000079        return RC_FLOW_BATCH_LIMITATION;
//D9000079        //D4100036 End
//D9000079//D4100036        pptLotRemoveFromFlowBatchReqResult  strLotRemoveFromFlowBatchReqResult ;
//D9000079//D4100036
//D9000079//D4100036        pptRemoveCassetteSequence strRemoveCassette;
//D9000079//D4100036        strRemoveCassette.length(1);
//D9000079//D4100036        strRemoveCassette[0].lotID.length(1);
//D9000079//D4100036
//D9000079//D4100036        strRemoveCassette[0].lotID[0]   = strBranchReq.lotID;
//D9000079//D4100036        strRemoveCassette[0].cassetteID = aCassetteID;
//D9000079//D4100036
//D9000079//D4100036        rc = txLotRemoveFromFlowBatchReq( strLotRemoveFromFlowBatchReqResult,
//D9000079//D4100036                                          strObjCommonIn,
//D9000079//D4100036                                          strLot_flowBatchID_Get_out.flowBatchID,
//D9000079//D4100036                                          strRemoveCassette,
//D9000079//D4100036                                          "" ) ;
//D9000079//D4100036        if ( rc != RC_OK )
//D9000079//D4100036        {
//D9000079//D4100036            PPT_METHODTRACE_V1("", "txLotRemoveFromFlowBatchReq() != RC_OK") ;
//D9000079//D4100036            strBranchReqResult.strResult = strLotRemoveFromFlowBatchReqResult.strResult ;
//D9000079//D4100036            return( rc );
//D9000079//D4100036        }
//D9000079    }
//D9000079    else if ( rc != RC_LOT_FLOW_BATCH_ID_BLANK )
//D9000079    {
//D9000079        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get != RC_LOT_BATCH_ID_BLANK") ;
//D9000079        strBranchReqResult.strResult = strLot_flowBatchID_Get_out.strResult ;
//D9000079        return( rc );
//D9000079    }

    //---------------------------------------
    //   Update Cassette's MultiLotType
    //---------------------------------------
    objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
    rc = cassette_multiLotType_Update(strCassette_multiLotType_Update_out, strObjCommonIn, aCassetteID);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cassette_multiLotType_Update() != RC_OK") ;
        strBranchReqResult.strResult = strCassette_multiLotType_Update_out.strResult ;
        return(rc);
    }

    //--------------------------------------------------------------------------------------------------
    // UpDate RequiredCassetteCategory
    //--------------------------------------------------------------------------------------------------
    objLot_CassetteCategory_UpdateForContaminationControl_out   strLot_CassetteCategory_UpdateForContaminationControl_out;
    rc = lot_CassetteCategory_UpdateForContaminationControl( strLot_CassetteCategory_UpdateForContaminationControl_out,
                                                             strObjCommonIn,
                                                             strBranchReq.lotID );

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","lot_CassetteCategory_UpdateForContaminationControl != RC_OK");
        strBranchReqResult.strResult = strLot_CassetteCategory_UpdateForContaminationControl_out.strResult;
        return rc;
    }

//INN-R170002 Add Start
    //--------------------------------------------------------------------------------------------------
    // Check Contamination Level
    //--------------------------------------------------------------------------------------------------
    csObjLot_ContaminationInfo_CheckForMove_in strLot_ContaminationInfo_CheckForMove_in;
    strLot_ContaminationInfo_CheckForMove_in.lotID = strBranchReq.lotID;
    strLot_ContaminationInfo_CheckForMove_in.carrierID = strLot_cassette_Get_out.cassetteID;
    csObjLot_ContaminationInfo_CheckForMove_out strLot_ContaminationInfo_CheckForMove_out;
    rc = cs_lot_ContaminationInfo_CheckForMove( strLot_ContaminationInfo_CheckForMove_out,
                                                strObjCommonIn,
                                                strLot_ContaminationInfo_CheckForMove_in );

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","cs_lot_ContaminationInfo_CheckForMove != RC_OK");
        strBranchReqResult.strResult = strLot_ContaminationInfo_CheckForMove_out.strResult;
        return rc;
    }

    if(strLot_ContaminationInfo_CheckForMove_out.holdReqFlag == TRUE)
    {
        pptHoldLotReqResult strHoldLotReqResult;
        pptHoldListSequence strLotHoldReqList( 1 );
        strLotHoldReqList.length( 1 );

        strLotHoldReqList[0].holdType                    = CIMFWStrDup( SP_HoldType_LotHold );
        strLotHoldReqList[0].holdReasonCodeID.identifier = CIMFWStrDup( CS_SP_Reason_ContaminationMismatchHold );
        strLotHoldReqList[0].holdUserID                  = strObjCommonIn.strUser.userID;
        strLotHoldReqList[0].responsibleOperationMark    = CIMFWStrDup( SP_ResponsibleOperation_Current );
        strLotHoldReqList[0].claimMemo                   = claimMemo;

        rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn,
                           strBranchReq.lotID,
                           strLotHoldReqList );

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
            strBranchReqResult.strResult = strHoldLotReqResult.strResult ;
            return rc ;
        }
        else
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() == RC_OK For LotHold") ;
        }
    }
//INN-R170002 Add End

//D4200029 Add Start
    //-----------------------//
    //     Process Hold      //
    //-----------------------//
    PPT_METHODTRACE_V1("","Call txProcessHoldExecReq()");
    pptProcessHoldExecReqResult strProcessHoldExecReqResult;

    rc = txProcessHoldExecReq( strProcessHoldExecReqResult,
                               strObjCommonIn,
                               strBranchReq.lotID,
                               claimMemo );

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","txProcessHoldExecReq() != RC_OK", rc );
        strBranchReqResult.strResult = strProcessHoldExecReqResult.strResult ;
        return( rc );
    }

//D4200029 Add End

//DSN000085792 Add Start
    //--------------------------------------------------------------------------------------------------
    // Replace Target Operation for sub route
    //--------------------------------------------------------------------------------------------------
    objQTime_targetOpe_Replace_out strQTime_targetOpe_Replace_out;
    objQTime_targetOpe_Replace_in  strQTime_targetOpe_Replace_in;
    strQTime_targetOpe_Replace_in.lotID               = strBranchReq.lotID;
    strQTime_targetOpe_Replace_in.specificControlFlag = FALSE;
    rc = qTime_targetOpe_Replace( strQTime_targetOpe_Replace_out,
                                  strObjCommonIn,
                                  strQTime_targetOpe_Replace_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "qTime_targetOpe_Replace() != RC_OK", rc);
        strBranchReqResult.strResult = strQTime_targetOpe_Replace_out.strResult;
        return rc;
    }
//DSN000085792 Add End

    //-----------------------------------------------------------
    //   Make History
    //-----------------------------------------------------------
    objLotOperationMoveEvent_MakeBranch_out strLotOperationMoveEvent_MakeBranch_out;
    rc = lotOperationMoveEvent_MakeBranch(strLotOperationMoveEvent_MakeBranch_out,
                                          strObjCommonIn,
//D4100021-2                                          "TXTRC034",
//P4200491                                          txID,                                             //D4100021-2
                                          "TXEWC008",                                                 //P4200491
                                          strBranchReq.lotID,
//                                        strProcess_BranchRoute_out.oldCurrentPOS,                   //D4100020 delete
                                          strProcess_BranchRoute_out.oldCurrentPOData,                //D4120020 add
                                          claimMemo);
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lotOperationMoveEvent_MakeBranch() != RC_OK") ;
//P5000145        PPT_SET_MSG_RC_KEY(strBranchReqResult, MSG_FAIL_MAKE_HISTORY, rc, strBranchReq.lotID.identifier) ;
        SET_MSG_RC( strBranchReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145
        return(rc);
    }

    //------------------------------------------------------------------------
    //   Return
    //------------------------------------------------------------------------
    SET_MSG_RC(strBranchReqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txBranchReq") ;
    return(RC_OK);
}
