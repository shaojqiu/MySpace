#ifndef lint
static char *sccsid =  "@(#) 1.3 superpos/src/spppt/source/posppt/pptmgr/txmethods/txMergeWaferLotReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/16/07 18:56:04 [ 11/16/07 18:56:05 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2014. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2014. All rights reserved.
//
// SiView
// Name: txMergeWaferLotReq.cpp
//

#include "cs_pptmgr.hpp"
#include "penin.hh"

// Class: PPTManager
//
// Service: txMergeWaferLotReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/11          O.Sugiyama     Initial Release
// 2000/09/26 Q3000147 S.Kawabe       Add Check Lot's Control Job ID
// 2000/10/23 P3000280 S.Kawabe       Boolean variable initialize
// 2001-01-11 D3000118 S.NAKATA       Lot Customization and Flexible Rework
// 2001-01-11 D3000119 S.NAKATA       Lot Customization and Flexible Rework
// 2001-03-15 P3100053 M.Shimizu      add process_CheckMergeForLCFR() call
// 2001/07/02 P4000037 K.Kido         Add XferState Check
// 2001/08/01 P4000079 K.Kido         Change XferState check logic
// 2002/01/16 D4100069 C.Tsuhciya     Drop LCFR logic
// 2002/01/16 P4100078 K.Matsuei      Mistake of Structure to set in SmallTx.
// 2002/02/28 D4100120 N.Minami       Future Action
// 2002/03/02 D4100036 K.Matsuei      FlowBatch Control.
// 2003/09/09 P5000145 H.Adachi       Fix Message and Message Macro mismatch.
// 2004/05/17 P5100296 H.Hasegawa     Call lot_RemoveFromMonitorGroup() for Child Lot
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2004/11/08 P6000017 S.Yamamoto     Fix : Object Lock missing or delay.
// 2005/05/13 D6000259 H.Hasegawa     Change the requirement for Hold State.
// 2005/11/18 D7000021 M.Murata       Add : Check lot's hold state. (LOCK)
// 2007/06/08 D9000038 D.Tamura       Remove In-Cassette Limitation.
// 2007/06/12 D9000005 H.Hotta        WaferSorter automation support.
// 2007/08/03 D9000056 H.Hotta        Add check logic for InPostProcessFlag.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/08 DSIV00000099 M.Ogawa        Add check logic for MachineContainerPosition.
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
// 2008/10/30 DSIV00000214 K.Kido         Multi Fab Transfer Support
// 2010/03/15 DSIV00001830 S.Kawabe       Wafer Stacking Operation Support
// 2012/02/15 DSN000033655 K.Yamaoku      Q-Time Lot Merge Improvement
// 2013/05/13 DSN000071674 Liuya          Remove part of the EI state limitation
// 2013/09/18 PSN000064684 T.Fujikawa     Fix for check lot state in different NonProBank
// 2014/01/21 PSN000083176 C.Mo           Data inconsistency might occur when start lot reservation is called together with lot operation transactions for the same cassette
// 2014/06/05 DSN000085791 C.Mo           Entity Inhibit Exception Lot Support. (R150)
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    pptMergeWaferLotReqResult&          strMergeWaferLotReqResult
//    const pptObjCommonIn&               strObjCommonIn
//    const objectIdentifier&             parentLotID
//    const objectIdentifier&             childLotID
//    const char *                        claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i:: txMergeWaferLotReq (
    pptMergeWaferLotReqResult&          strMergeWaferLotReqResult,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             parentLotID,
    const objectIdentifier&             childLotID,
//D6000025     const char *                        claimMemo,
//D6000025     CORBA::Environment &                IT_env)
    const char *                        claimMemo //D6000025
    CORBAENV_LAST_CPP)                            //D6000025
{
    PPT_METHODTRACE_ENTRY("PPTManager_i:: txMergeWaferLotReq ");
    CORBA::Long rc = RC_OK;

    //------------------------------------------------------------------------
    //   Get cassette / lot connection
    //------------------------------------------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "Get cassette / lot connection");

    objectIdentifier aParentLotID( parentLotID );
    objLot_cassette_Get_out strLot_cassette_Get1_out;
    rc = lot_cassette_Get(strLot_cassette_Get1_out, strObjCommonIn,
                          aParentLotID);
//D9000038    if (rc)
    if ( rc != RC_OK && rc != RC_NOT_FOUND_CST ) //D9000038
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "lot_cassette_Get(parentLotID) rc != RC_OK");
        strMergeWaferLotReqResult.strResult = strLot_cassette_Get1_out.strResult;
        return(rc);
    }

    objectIdentifier aChildLotID( childLotID );
    objLot_cassette_Get_out strLot_cassette_Get2_out;
    rc = lot_cassette_Get(strLot_cassette_Get2_out, strObjCommonIn,
                          aChildLotID);
//D9000038    if (rc)
    if ( rc != RC_OK && rc != RC_NOT_FOUND_CST ) //D9000038
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "lot_cassette_Get(childLotID) rc != RC_OK");
        strMergeWaferLotReqResult.strResult = strLot_cassette_Get2_out.strResult;
        return(rc);
    }

    //--------------------------------
    //   CassetteID should be same!
    //--------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "CassetteID should be same!");

    if (CIMFWStrCmp(strLot_cassette_Get1_out.cassetteID.identifier,
                    strLot_cassette_Get2_out.cassetteID.identifier) != 0)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "strLot_cassette_Get1_out.cassetteID != strLot_cassette_Get2_out.cassetteID");
        SET_MSG_RC(strMergeWaferLotReqResult, MSG_CAST_NOTSAME, RC_CAST_NOTSAME);
        return( RC_CAST_NOTSAME );
    }

    objectIdentifier aParentCassetteID( strLot_cassette_Get1_out.cassetteID );
    objectIdentifier aChildCassetteID( strLot_cassette_Get2_out.cassetteID );

    //P6000017 start
    //--------------------------------
    //   Lock objects to be updated
    //--------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "Lock objects to be updated");

    objObject_Lock_out strObject_Lock_out;
//DSN000071674 add start
    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );

    CORBA::Boolean updateControlJobFlag = FALSE;
    CORBA::Long lockMode = 0; //PSN000083176

    objCassette_transferState_Get_out strCassetteTransferState;
    objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;

    if ( 0 == lotOperationEIcheck && 0 < CIMFWStrLen( aParentCassetteID.identifier ) )
    {
        //-------------------------------
        // Get carrier transfer status
        //-------------------------------
        rc = cassette_transferState_Get(strCassetteTransferState, strObjCommonIn,
                                        aParentCassetteID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "rc != RC_OK");
            strMergeWaferLotReqResult.strResult = strCassetteTransferState.strResult ;
            return( rc );
        }

        /*------------------------------------*/
        /*   Get equipment ID in Cassette     */
        /*------------------------------------*/
        rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                       strObjCommonIn,
                                       aParentCassetteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "cassette_equipmentID_Get != RC_OK", rc);
            strMergeWaferLotReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
            return( rc );
        }

        //-------------------------------
        // Get required equipment lock mode
        //-------------------------------
        objObject_lockMode_Get_out strObject_lockMode_Get_out;
        objObject_lockMode_Get_in  strObject_lockMode_Get_in;
        strObject_lockMode_Get_in.objectID           = strCassette_equipmentID_Get_out.equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXTRC023" ); // TxMergeWaferLotReq
        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strMergeWaferLotReqResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }

//PSN000083176        CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
        lockMode = strObject_lockMode_Get_out.lockMode; //PSN000083176
        PPT_METHODTRACE_V2( "", "lockMode", lockMode );

        if ( 0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) )
        {
            updateControlJobFlag = TRUE;

            if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
            {
                objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
                objAdvanced_object_Lock_in strAdvanced_object_Lock_in;

                // Lock Equipment Main Object
                stringSequence dummySeq;
                dummySeq.length(0);
                strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
                strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
                strAdvanced_object_Lock_in.keySeq     = dummySeq;

                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strMergeWaferLotReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }

                // Lock Equipment LoadCassette Element (Write)
                stringSequence loadCastSeq;
                loadCastSeq.length(1);
                loadCastSeq[0] = aParentCassetteID.identifier;
                strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
                strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
                strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strMergeWaferLotReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }
            }
            else
            {
                /*--------------------------------*/
                /*   Lock Macihne object          */
                /*--------------------------------*/
                rc = object_Lock( strObject_Lock_out, strObjCommonIn, strCassette_equipmentID_Get_out.equipmentID, SP_ClassName_PosMachine );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc) ;
                    strMergeWaferLotReqResult.strResult = strObject_Lock_out.strResult ;
                    return( rc );
                }
            }
        }
//PSN000083176        if( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176        {
//PSN000083176            //---------------------------------
//PSN000083176            //   Get Cassette's ControlJobID
//PSN000083176            //---------------------------------
//PSN000083176            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;
//PSN000083176            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
//PSN000083176                                            strObjCommonIn,
//PSN000083176                                            aParentCassetteID );
//PSN000083176            if ( rc != RC_OK )
//PSN000083176            {
//PSN000083176                PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
//PSN000083176                strMergeWaferLotReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
//PSN000083176                return( rc );
//PSN000083176            }
//PSN000083176            if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
//PSN000083176            {
//PSN000083176                PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
//PSN000083176                updateControlJobFlag = TRUE;
//PSN000083176                if( lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176                {
//PSN000083176                    /*------------------------------*/
//PSN000083176                    /*   Lock ControlJob Object     */
//PSN000083176                    /*------------------------------*/
//PSN000083176                    rc = object_Lock( strObject_Lock_out,
//PSN000083176                                      strObjCommonIn, 
//PSN000083176                                      strCassette_controlJobID_Get_out.controlJobID, 
//PSN000083176                                      SP_ClassName_PosControlJob );
//PSN000083176                    if ( rc != RC_OK )
//PSN000083176                    {
//PSN000083176                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
//PSN000083176                        strMergeWaferLotReqResult.strResult = strObject_Lock_out.strResult;
//PSN000083176                        return( rc );
//PSN000083176                    }
//PSN000083176                }
//PSN000083176            }
//PSN000083176        }
    }
//DSN000071674 add end

    rc = object_Lock(strObject_Lock_out, strObjCommonIn,
                     aParentCassetteID, SP_ClassName_PosCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "object_Lock(aParentCassetteID) rc != RC_OK");
        strMergeWaferLotReqResult.strResult = strObject_Lock_out.strResult;
        return(rc);
    }

//PSN000083176 add start
    if ( 0 == lotOperationEIcheck && 0 < CIMFWStrLen( aParentCassetteID.identifier ) )
    {
        if( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
        {
            //---------------------------------
            //   Get Cassette's ControlJobID
            //---------------------------------
            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;
            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                            strObjCommonIn,
                                            aParentCassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
                strMergeWaferLotReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
                return( rc );
            }
            if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
            {
                PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
                updateControlJobFlag = TRUE;
                if( lockMode != SP_EQP_LOCK_MODE_WRITE )
                {
                    /*------------------------------*/
                    /*   Lock ControlJob Object     */
                    /*------------------------------*/
                    rc = object_Lock( strObject_Lock_out,
                                      strObjCommonIn, 
                                      strCassette_controlJobID_Get_out.controlJobID, 
                                      SP_ClassName_PosControlJob );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                        strMergeWaferLotReqResult.strResult = strObject_Lock_out.strResult;
                        return( rc );
                    }
                }
            }
        }
    }
//PSN000083176 add end

    rc = object_Lock(strObject_Lock_out, strObjCommonIn,
                     aChildCassetteID, SP_ClassName_PosCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "object_Lock(aChildCassetteID) rc != RC_OK");
        strMergeWaferLotReqResult.strResult = strObject_Lock_out.strResult;
        return(rc);
    }

    rc = object_Lock(strObject_Lock_out, strObjCommonIn,
                     parentLotID, SP_ClassName_PosLot );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "object_Lock(parentLotID) rc != RC_OK");
        strMergeWaferLotReqResult.strResult = strObject_Lock_out.strResult;
        return(rc);
    }

    rc = object_Lock(strObject_Lock_out, strObjCommonIn,
                     childLotID, SP_ClassName_PosLot );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "object_Lock(childLotID) rc != RC_OK");
        strMergeWaferLotReqResult.strResult = strObject_Lock_out.strResult;
        return(rc);
    }
    //P6000017 end

//DSIV00000214//D7000021 add start
//DSIV00000214    //------------------------------------
//DSIV00000214    // Check LOCK Hold.
//DSIV00000214    //------------------------------------
//DSIV00000214    PPT_METHODTRACE_V1("", "Check LOCK Hold. ");
//DSIV00000214    objectIdentifierSequence lotIDSeq;
//DSIV00000214    lotIDSeq.length(2);
//DSIV00000214    lotIDSeq[0] = parentLotID;
//DSIV00000214    lotIDSeq[1] = childLotID;
//DSIV00000214    objLot_CheckLockHoldConditionForOperation_out  strLot_CheckLockHoldConditionForOperation_out;
//DSIV00000214    rc = lot_CheckLockHoldConditionForOperation( strLot_CheckLockHoldConditionForOperation_out, strObjCommonIn, lotIDSeq );
//DSIV00000214    if( rc != RC_OK )
//DSIV00000214    {
//DSIV00000214        PPT_METHODTRACE_V1("", "lot_CheckLockHoldConditionForOperation rc != RC_OK");
//DSIV00000214        strMergeWaferLotReqResult.strResult = strLot_CheckLockHoldConditionForOperation_out.strResult;
//DSIV00000214        return ( rc );
//DSIV00000214    }
//DSIV00000214//D7000021 add end
//DSIV00000214 add start
    objectIdentifierSequence lotIDSeq;
    lotIDSeq.length(2);
    lotIDSeq[0] = parentLotID;
    lotIDSeq[1] = childLotID;

    //------------------------------------
    // Check LOCK Hold.
    //------------------------------------
    PPT_METHODTRACE_V1("", "Check LOCK Hold. ");
    CORBA::ULong nLen = lotIDSeq.length();
    for( CORBA::ULong count = 0 ; count < nLen ; count++ )
    {
        //----------------------------------
        //  Check lot InterFabXfer state
        //----------------------------------
        objLot_interFabXferState_Get_out strLot_interFabXferState_Get_out;

        objLot_interFabXferState_Get_in  strLot_interFabXferState_Get_in;
        strLot_interFabXferState_Get_in.lotID = lotIDSeq[count];

        rc = lot_interFabXferState_Get( strLot_interFabXferState_Get_out,
                                        strObjCommonIn,
                                        strLot_interFabXferState_Get_in );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", " #### lot_interFabXferState_Get() != RC_OK");
            strMergeWaferLotReqResult.strResult = strLot_interFabXferState_Get_out.strResult;
            return (rc);
        }

        if( 0 == CIMFWStrCmp(strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Required ))
        {
            PPT_METHODTRACE_V1("", " #### The Lot interFabXfer state is required... No need to check LOCK Hold. ");
            continue;
        }

        objectIdentifierSequence ckLotIDSeq;
        ckLotIDSeq.length(1);
        ckLotIDSeq[0] = lotIDSeq[count];

        objLot_CheckLockHoldConditionForOperation_out  strLot_CheckLockHoldConditionForOperation_out;
        rc = lot_CheckLockHoldConditionForOperation( strLot_CheckLockHoldConditionForOperation_out, strObjCommonIn, ckLotIDSeq );

        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_CheckLockHoldConditionForOperation rc != RC_OK", ckLotIDSeq[0].identifier );
            strMergeWaferLotReqResult.strResult = strLot_CheckLockHoldConditionForOperation_out.strResult;
            return ( rc );
        }
    }
//DSIV00000214 add end

//D9000056 add start
    //-----------------------------
    //  Check InPostProcessFlag
    //-----------------------------
    PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
//DSIV00000201 Add Start
    objectIdentifierSequence userGroupIDs;
    userGroupIDs.length(0);
    CORBA::ULong userGroupIDsLen = userGroupIDs.length();

//DSIV00000201 Add End

    for( CORBA::Long loopCnt = 0; loopCnt < lotIDSeq.length(); loopCnt++ )
    {
        //----------------------------------
        //  Get InPostProcessFlag of Lot
        //----------------------------------
        objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
        objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
        strLot_inPostProcessFlag_Get_in.lotID = lotIDSeq[loopCnt];

        rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                        strObjCommonIn,
                                        strLot_inPostProcessFlag_Get_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
            strMergeWaferLotReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
            return( rc );
        }

//DSIV00000214 add start
        //----------------------------------
        //  Check lot InterFabXfer state
        //----------------------------------
        objLot_interFabXferState_Get_out strLot_interFabXferState_Get_out;

        objLot_interFabXferState_Get_in  strLot_interFabXferState_Get_in;
        strLot_interFabXferState_Get_in.lotID = lotIDSeq[loopCnt];

        rc = lot_interFabXferState_Get( strLot_interFabXferState_Get_out,
                                        strObjCommonIn,
                                        strLot_interFabXferState_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", " #### lot_interFabXferState_Get() != RC_OK");
            strMergeWaferLotReqResult.strResult = strLot_interFabXferState_Get_out.strResult;
            return (rc);
        }
//DSIV00000214 add end

        //----------------------------------------------
        //  If Lot is in post process, returns error
        //----------------------------------------------
        if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
        {
            PPT_METHODTRACE_V1("", "Lot is in post process.");
//DSIV00000214 add start
            if( 0 == CIMFWStrCmp(strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Required ))
            {
                PPT_METHODTRACE_V1("", " #### The Lot interFabXfer state is required... No need to check post process flag. ");
                continue;
            }
//DSIV00000214 add end
//DSIV00000201 Add Start
            if (userGroupIDsLen == 0)
            {
                /*---------------------------*/
                /* Get UserGroupID By UserID */
                /*---------------------------*/
                objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
                rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                                 strObjCommonIn,
                                                 strObjCommonIn.strUser.userID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
                    strMergeWaferLotReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
                    return( rc );
                }
                userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
                userGroupIDsLen = userGroupIDs.length();
                PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);
            }
            CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
            PPT_METHODTRACE_V2("", "extPostProc", extPostProc);
            
            CORBA::ULong nCnt = 0;
            for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
            {
                PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
                if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
                {
                    PPT_METHODTRACE_V1("", "# External Post Process User!");
                    break;
                }
                
            }
            if (nCnt == userGroupIDsLen)
            {
                PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
                PPT_SET_MSG_RC_KEY( strMergeWaferLotReqResult,
                                    MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                    lotIDSeq[loopCnt].identifier );
                return( RC_LOT_INPOSTPROCESS );
            }   //DSIV00000201
        }
    }
//D9000056 add end

//D9000005 add start
    /*-------------------------------*/
    /*   Check SorterJob existence   */
    /*-------------------------------*/
    pptEquipmentLoadPortAttribute dummyEquipmentPortAttribute;
    objectIdentifierSequence dummyCastIDs;

    objWaferSorter_sorterJob_CheckForOperation_out strWaferSorter_sorterJob_CheckForOperation_out;
    objWaferSorter_sorterJob_CheckForOperation_in  strWaferSorter_sorterJob_CheckForOperation_in;
    strWaferSorter_sorterJob_CheckForOperation_in.strEquipmentLoadPortAttribute = dummyEquipmentPortAttribute;
    strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs                   = dummyCastIDs;
    strWaferSorter_sorterJob_CheckForOperation_in.lotIDs                        = lotIDSeq;
    strWaferSorter_sorterJob_CheckForOperation_in.operation                     = CIMFWStrDup(SP_Operation_For_Lot);

    rc = waferSorter_sorterJob_CheckForOperation( strWaferSorter_sorterJob_CheckForOperation_out,
                                                  strObjCommonIn,
                                                  strWaferSorter_sorterJob_CheckForOperation_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "waferSorter_sorterJob_CheckForOperation() != RC_OK" );
        strMergeWaferLotReqResult.strResult = strWaferSorter_sorterJob_CheckForOperation_out.strResult;
        return( rc );
    }
//D9000005 add end

    objCassette_transferState_Get_out strCassette_transferState_Get_out;  //DSN000071674

    //---------------------------------
    // Check carrier dispatch status
    //---------------------------------
//D9000038 add start
    if( CIMFWStrLen( aParentCassetteID.identifier ) > 0)
    {
//D9000038 add end
//DSN000071674 add start
        if ( 1 == lotOperationEIcheck )
        {
            PPT_METHODTRACE_V1("", "lotOperationEIcheck = 1");
//DSN000071674 add end
            PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "Check carrier dispatch status");

            objCassette_dispatchState_Get_out strCassette_dispatchState_Get_out;
            strCassette_dispatchState_Get_out.dispatchReservedFlag = FALSE; //P3000280
            rc = cassette_dispatchState_Get(strCassette_dispatchState_Get_out, strObjCommonIn,
                                            aParentCassetteID);
            if (strCassette_dispatchState_Get_out.dispatchReservedFlag == TRUE)
            {
                PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "strCassette_dispatchState_Get_out.dispatchReservedFlag == TRUE");
                SET_MSG_RC(strMergeWaferLotReqResult, MSG_ALREADY_DISPATCH_RESVED_CST, RC_NOT_RESERVED_CST);
                return( RC_NOT_RESERVED_CST );
            }
        } //DSN000071674

        //---------------------------------
        // Check carrier transfer status
        //---------------------------------
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "Check carrier transfer status");

//DSN000071674        objCassette_transferState_Get_out strCassette_transferState_Get_out;
//DSN000071674 add start
        if ( 1 == lotOperationEIcheck
        || ( 0 == lotOperationEIcheck && 0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) ) )
        {
//DSN000071674 add end
            rc = cassette_transferState_Get(strCassette_transferState_Get_out, strObjCommonIn,
                                            aParentCassetteID);
//P4000037    if (CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_BayOut)      == 0 ||
//P4000037        CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0)
//P4000037    {
//P4000037        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "strCassette_dispatchState_Get_out.dispatchReservedFlag == TRUE");
//P4000037        PPT_SET_MSG_RC_KEY2(strMergeWaferLotReqResult, MSG_INVALID_CAST_XFERSTAT, RC_INVALID_CAST_XFERSTAT,
//P4000037                            strCassette_transferState_Get_out.transferState,
//P4000037                            aParentCassetteID.identifier);
//P4000037        return( RC_INVALID_CAST_XFERSTAT );
//P4000037    }

//P4000037 add start
            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "rc != RC_OK");
                strMergeWaferLotReqResult.strResult = strCassette_transferState_Get_out.strResult ;
                return(rc);
            }
//DSN000071674 add start
            if ( 0 == lotOperationEIcheck )
            {
                PPT_METHODTRACE_V1("", "lotOperationEIcheck = 0");
                if ( 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) )                                                     //D4100091
                {
                    PPT_METHODTRACE_V1("","Changed to EI by other operation");
                    strMergeWaferLotReqResult.strResult = strCassette_transferState_Get_out.strResult ;
                    PPT_SET_MSG_RC_KEY(strMergeWaferLotReqResult, MSG_CHANGED_TO_EI_BY_OTHER_OPERATION, RC_CHANGED_TO_EI_BY_OTHER_OPERATION,
                                       aParentCassetteID.identifier);
                    return( RC_CHANGED_TO_EI_BY_OTHER_OPERATION );
                }
            }
//DSN000071674 add end
//P4000079    else if(!(CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_EquipmentOut)    == 0  ||
//P4000079              CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_ManualOut)       == 0  ||
//P4000079              CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_IntermediateOut) == 0  ||
//P4000079              CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_ShelfOut)        == 0  ||
//P4000079              CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_UNDEFINED_STATE)            == 0  ||
//P4000079              CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_AbnormalOut)     == 0  ||
//P4000079              CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_StationOut)      == 0) )
            else if (CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_BayOut    ) == 0 ||
                     CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0)         //P4000079
            {
                PPT_METHODTRACE_V1("","XferState is invalid...");
                strMergeWaferLotReqResult.strResult = strCassette_transferState_Get_out.strResult ;
                PPT_SET_MSG_RC_KEY2(strMergeWaferLotReqResult, MSG_INVALID_CAST_XFERSTAT, RC_INVALID_CAST_XFERSTAT,
                                    strCassette_transferState_Get_out.transferState,
                                    aParentCassetteID.identifier);
                return( RC_INVALID_CAST_XFERSTAT );
            }
//DSN000071674 add start
        }
        if ( 0 == lotOperationEIcheck )
        {
            strCassette_transferState_Get_out = strCassetteTransferState;
        }
//DSN000071674 add end
//P4000037 add end
//D9000038 add start
    }
    else
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "The parent cassetteID is empty. Skip to call cassette's obj-methods.");
    }
//D9000038 add end

//P6000017    //--------------------------------
//P6000017    //   Lock objects to be updated
//P6000017    //--------------------------------
//P6000017    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "Lock objects to be updated");
//P6000017
//P6000017    objObject_Lock_out strObject_Lock_out;
//P6000017    rc = object_Lock(strObject_Lock_out, strObjCommonIn,
//P6000017                     aParentCassetteID, SP_ClassName_PosCassette );
//P6000017    if ( rc != RC_OK )
//P6000017    {
//P6000017        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "object_Lock(aParentCassetteID) rc != RC_OK");
//P6000017        strMergeWaferLotReqResult.strResult = strObject_Lock_out.strResult;
//P6000017        return(rc);
//P6000017    }
//P6000017
//P6000017    rc = object_Lock(strObject_Lock_out, strObjCommonIn,
//P6000017                     aChildCassetteID, SP_ClassName_PosCassette );
//P6000017    if ( rc != RC_OK )
//P6000017    {
//P6000017        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "object_Lock(aChildCassetteID) rc != RC_OK");
//P6000017        strMergeWaferLotReqResult.strResult = strObject_Lock_out.strResult;
//P6000017        return(rc);
//P6000017    }
//P6000017
//P6000017    rc = object_Lock(strObject_Lock_out, strObjCommonIn,
//P6000017                     parentLotID, SP_ClassName_PosLot );
//P6000017    if ( rc != RC_OK )
//P6000017    {
//P6000017        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "object_Lock(parentLotID) rc != RC_OK");
//P6000017        strMergeWaferLotReqResult.strResult = strObject_Lock_out.strResult;
//P6000017        return(rc);
//P6000017    }
//P6000017
//P6000017    rc = object_Lock(strObject_Lock_out, strObjCommonIn,
//P6000017                     childLotID, SP_ClassName_PosLot );
//P6000017    if ( rc != RC_OK )
//P6000017    {
//P6000017        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "object_Lock(childLotID) rc != RC_OK");
//P6000017        strMergeWaferLotReqResult.strResult = strObject_Lock_out.strResult;
//P6000017        return(rc);
//P6000017    }

    //------------------------------------------------------------------------
    //   Check Condition
    //------------------------------------------------------------------------
    //---------------------------------
    // Check Contents for parent lot
    //---------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "Check Contents for parent lot");

    objLot_contents_Get_out strLot_contents_Get_out;
    rc = lot_contents_Get(strLot_contents_Get_out, strObjCommonIn,
                          parentLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "lot_contents_Get(parentLotID) rc != RC_OK");
        strMergeWaferLotReqResult.strResult = strLot_contents_Get_out.strResult;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_contents_Get_out.theLotContents, SP_ProdType_Wafer) != 0 &&
             CIMFWStrCmp(strLot_contents_Get_out.theLotContents, SP_ProdType_Die) != 0)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "!SP_ProdType_Wafer && !SP_ProdType_Die");
        PPT_SET_MSG_RC_KEY(strMergeWaferLotReqResult, MSG_INVALID_LOT_CONTENTS, RC_INVALID_LOT_CONTENTS,
                           parentLotID.identifier);
        return( RC_INVALID_LOT_CONTENTS );
    }

    //---------------------------------
    // Check Contents for child lot
    //---------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "Check Contents for child lot");

    rc = lot_contents_Get(strLot_contents_Get_out, strObjCommonIn,
                          childLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "lot_contents_Get(childLotID) rc != RC_OK");
        strMergeWaferLotReqResult.strResult = strLot_contents_Get_out.strResult;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_contents_Get_out.theLotContents, SP_ProdType_Wafer) != 0 &&
             CIMFWStrCmp(strLot_contents_Get_out.theLotContents, SP_ProdType_Die) != 0)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "!SP_ProdType_Wafer && !SP_ProdType_Die");
        PPT_SET_MSG_RC_KEY(strMergeWaferLotReqResult, MSG_INVALID_LOT_CONTENTS, RC_INVALID_LOT_CONTENTS,
                           childLotID.identifier);
        return( RC_INVALID_LOT_CONTENTS );
    }

//DSIV00001830 add start
    //---------------------------------------
    // Check Finished State for parent lot
    //---------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "Check Finished State for parent lot");

    objLot_finishedState_Get_out strLot_finishedState_Get_out;
    rc = lot_finishedState_Get(strLot_finishedState_Get_out, strObjCommonIn, parentLotID);
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_finishedState_Get() != RC_OK" );
        strMergeWaferLotReqResult.strResult = strLot_finishedState_Get_out.strResult;
        return rc;
    }
    else if( CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,SP_LOT_FINISHED_STATE_STACKED) == 0 ) 
    {
        PPT_METHODTRACE_V1("", "CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,SP_LOT_FINISHED_STATE_STACKED) == 0");
        PPT_SET_MSG_RC_KEY( strMergeWaferLotReqResult,
                            MSG_INVALID_LOT_FINISHSTAT,
                            RC_INVALID_LOT_FINISHSTAT,
                            strLot_finishedState_Get_out.lotFinishedState );
    
        return RC_INVALID_LOT_FINISHSTAT;
    }

    //---------------------------------------
    // Check Finished State for child lot
    //---------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "Check Finished State for child lot");

    rc = lot_finishedState_Get(strLot_finishedState_Get_out, strObjCommonIn, childLotID);
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_finishedState_Get() != RC_OK" );
        strMergeWaferLotReqResult.strResult = strLot_finishedState_Get_out.strResult;
        return rc;
    }
    else if( CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,SP_LOT_FINISHED_STATE_STACKED) == 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,SP_LOT_FINISHED_STATE_STACKED) == 0");
        PPT_SET_MSG_RC_KEY( strMergeWaferLotReqResult,
                            MSG_INVALID_LOT_FINISHSTAT,
                            RC_INVALID_LOT_FINISHSTAT,
                            strLot_finishedState_Get_out.lotFinishedState );
    
        return RC_INVALID_LOT_FINISHSTAT;
    }

    //---------------------------------------
    // Check Bonding Group for parent lot
    //---------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "Check Bonding Group for parent lot");

    objLot_bondingGroupID_GetDR_in  strLot_bondingGroupID_GetDR_in;
    strLot_bondingGroupID_GetDR_in.lotID = parentLotID;

    objLot_bondingGroupID_GetDR_out strLot_bondingGroupID_GetDR_out;
    rc = lot_bondingGroupID_GetDR( strLot_bondingGroupID_GetDR_out, strObjCommonIn, strLot_bondingGroupID_GetDR_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_bondingGroupID_GetDR() rc != RC_OK");
        strMergeWaferLotReqResult.strResult = strLot_bondingGroupID_GetDR_out.strResult;
        return rc;
    }
    if( CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0");
        PPT_SET_MSG_RC_KEY2( strMergeWaferLotReqResult,
                             MSG_LOT_HAS_BONDINGGROUP,
                             RC_LOT_HAS_BONDINGGROUP,
                             strLot_bondingGroupID_GetDR_in.lotID.identifier,
                             strLot_bondingGroupID_GetDR_out.bondingGroupID );
        return RC_LOT_HAS_BONDINGGROUP;
    }

    //---------------------------------------
    // Check Bonding Group for child lot
    //---------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "Check Bonding Group for child lot");

    strLot_bondingGroupID_GetDR_in.lotID = childLotID;
    rc = lot_bondingGroupID_GetDR( strLot_bondingGroupID_GetDR_out, strObjCommonIn, strLot_bondingGroupID_GetDR_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_bondingGroupID_GetDR() rc != RC_OK");
        strMergeWaferLotReqResult.strResult = strLot_bondingGroupID_GetDR_out.strResult;
        return rc;
    }
    if( CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0");
        PPT_SET_MSG_RC_KEY2( strMergeWaferLotReqResult,
                             MSG_LOT_HAS_BONDINGGROUP,
                             RC_LOT_HAS_BONDINGGROUP,
                             strLot_bondingGroupID_GetDR_in.lotID.identifier,
                             strLot_bondingGroupID_GetDR_out.bondingGroupID );
        return RC_LOT_HAS_BONDINGGROUP;
    }
//DSIV00001830 add end

    //------------------------------------------------------
    // Check parent lot and child lot is same state or not
    //------------------------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "Check parent lot and child lot is same state or not");

    objLot_allState_CheckSame_out strLot_allState_CheckSame_out;
    rc = lot_allState_CheckSame(strLot_allState_CheckSame_out, strObjCommonIn,
                                parentLotID, childLotID);
//D6000259    if (rc)
    // If only Hold State is different, childLot's Hold Record is checked at lot_holdList_CheckMerge().     //D6000259
    if( rc != RC_OK && CIMFWStrCmp( strLot_allState_CheckSame_out.lotHoldState, "HOLDSTATE" ) != 0 )        //D6000259
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "lot_allState_CheckSame() rc != RC_OK");
        strMergeWaferLotReqResult.strResult = strLot_allState_CheckSame_out.strResult;
        return(rc);
    }
    //------------------------------------------------------
    // Check lot state
    //------------------------------------------------------
//PSN000064684    else if (CIMFWStrCmp(strLot_allState_CheckSame_out.lotInventoryState, SP_Lot_InventoryState_InBank) == 0)
    else if( 0 == CIMFWStrCmp(strLot_allState_CheckSame_out.lotInventoryState, SP_Lot_InventoryState_InBank)          //PSN000064684
             || 0 == CIMFWStrCmp(strLot_allState_CheckSame_out.lotInventoryState, SP_Lot_InventoryState_NonProBank) ) //PSN000064684
    {
        //------------------------------------------------------
        // Check BankID.
        //------------------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "Check BankID.");

        objLot_bank_CheckSame_out strLot_bank_CheckSame_out;
        rc = lot_bank_CheckSame(strLot_bank_CheckSame_out, strObjCommonIn,
                                parentLotID, childLotID);
        if (rc)
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "lot_bank_CheckSame() rc != RC_OK");
            strMergeWaferLotReqResult.strResult = strLot_bank_CheckSame_out.strResult;
            return(rc);
        }
    }
    //--- Check for Lot State -----//                                                                       //D6000259
    if( CIMFWStrCmp( strLot_allState_CheckSame_out.lotState, CIMFW_Lot_State_Shipped ) == 0 )               //D6000259
//D6000259    objLot_state_Get_out strLot_state_Get_out;
//D6000259    rc = lot_state_Get(strLot_state_Get_out, strObjCommonIn,
//D6000259                      parentLotID);
//D6000259    if (rc)
//D6000259    {
//D6000259        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "lot_state_Get(parentLotID) rc != RC_OK");
//D6000259        strMergeWaferLotReqResult.strResult = strLot_state_Get_out.strResult;
//D6000259        return(rc);
//D6000259    }
//D6000259    else if (CIMFWStrCmp(strLot_state_Get_out.lotState, CIMFW_Lot_State_Shipped) == 0)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "CIMFW_Lot_State_Shipped");
//D6000259        strMergeWaferLotReqResult.strResult = strLot_state_Get_out.strResult;
        PPT_SET_MSG_RC_KEY(strMergeWaferLotReqResult, MSG_INVALID_LOT_STAT, RC_INVALID_LOT_STAT,
                           strLot_allState_CheckSame_out.lotState );                                        //D6000259
//D6000259                           strLot_state_Get_out.lotState);
        return( RC_INVALID_LOT_STAT );
    }
    //--- Check for Lot Process State -----//                                                               //D6000259
    if( CIMFWStrCmp( strLot_allState_CheckSame_out.lotProcessState, SP_Lot_ProcState_Processing ) == 0 )    //D6000259
//D6000259    objLot_processState_Get_out strLot_processState_Get_out;
//D6000259    rc = lot_processState_Get(strLot_processState_Get_out, strObjCommonIn,
//D6000259                              parentLotID);
//D6000259    if (rc)
//D6000259    {
//D6000259        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "lot_processState_Get() rc != RC_OK");
//D6000259        strMergeWaferLotReqResult.strResult = strLot_processState_Get_out.strResult;
//D6000259        return(rc);
//D6000259    }
//D6000259    else if (CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState, SP_Lot_ProcState_Processing) == 0)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "SP_Lot_ProcState_Processing");
//D6000259        strMergeWaferLotReqResult.strResult = strLot_processState_Get_out.strResult;
        PPT_SET_MSG_RC_KEY2(strMergeWaferLotReqResult, MSG_INVALID_LOT_PROCSTAT, RC_INVALID_LOT_PROCSTAT,
                            parentLotID.identifier,
                            strLot_allState_CheckSame_out.lotProcessState );                                //D6000259
//D6000259                            strLot_processState_Get_out.theLotProcessState);
        return( RC_INVALID_LOT_PROCSTAT );
    }

//D4100036 start
    /*-------------------------------*/
    /*   Check FlowBatch Condition   */
    /*-------------------------------*/
    PPT_METHODTRACE_V1("", "Check FlowBatch Condition  [ParentLot]") ;
    objLot_flowBatchID_Get_out strLot_flowBatchID_Get_out;
    rc = lot_flowBatchID_Get( strLot_flowBatchID_Get_out, strObjCommonIn, parentLotID );

    if ( rc == RC_LOT_FLOW_BATCH_ID_FILLED )
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() == RC_LOT_BATCH_ID_BLANK") ;
//P5000145        PPT_SET_MSG_RC_KEY( strMergeWaferLotReqResult, MSG_FLOW_BATCH_LIMITATION, RC_FLOW_BATCH_LIMITATION, "");
        SET_MSG_RC( strMergeWaferLotReqResult, MSG_FLOW_BATCH_LIMITATION, RC_FLOW_BATCH_LIMITATION );        //P5000145
        return RC_FLOW_BATCH_LIMITATION;
    }
    else if ( rc == RC_LOT_FLOW_BATCH_ID_BLANK )
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() == RC_LOT_BATCH_ID_BLANK") ;
    }
    else
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() != RC_OK") ;
        strMergeWaferLotReqResult.strResult = strLot_flowBatchID_Get_out.strResult ;
        return( rc );
    }

    PPT_METHODTRACE_V1("", "Check FlowBatch Condition  [ChildLot]") ;
    rc = lot_flowBatchID_Get( strLot_flowBatchID_Get_out, strObjCommonIn, childLotID );

    if ( rc == RC_LOT_FLOW_BATCH_ID_FILLED )
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() == RC_LOT_BATCH_ID_BLANK") ;
//P5000145        PPT_SET_MSG_RC_KEY( strMergeWaferLotReqResult, MSG_FLOW_BATCH_LIMITATION, RC_FLOW_BATCH_LIMITATION, "");
        SET_MSG_RC( strMergeWaferLotReqResult, MSG_FLOW_BATCH_LIMITATION, RC_FLOW_BATCH_LIMITATION );        //P5000145
        return RC_FLOW_BATCH_LIMITATION;
    }
    else if ( rc == RC_LOT_FLOW_BATCH_ID_BLANK )
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() == RC_LOT_BATCH_ID_BLANK") ;
    }
    else
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() != RC_OK") ;
        strMergeWaferLotReqResult.strResult = strLot_flowBatchID_Get_out.strResult ;
        return( rc );
    }
//D4100036 end

//DSIV00000099 add start
    /*------------------------------------------------------------------------*/
    /*   Check if the wafers in lot don't have machine container position     */
    /*------------------------------------------------------------------------*/
    // for parentLot
    PPT_METHODTRACE_V1("", "call equipmentContainerPosition_info_GetByLotDR( parentLot )");
    objEquipmentContainerPosition_info_GetByLotDR_out strEquipmentContainerPosition_info_GetByLotDR_out_parent;
    objEquipmentContainerPosition_info_GetByLotDR_in  strEquipmentContainerPosition_info_GetByLotDR_in_parent;
    strEquipmentContainerPosition_info_GetByLotDR_in_parent.lotID = parentLotID;
    rc = equipmentContainerPosition_info_GetByLotDR( strEquipmentContainerPosition_info_GetByLotDR_out_parent,
                                                     strObjCommonIn,
                                                     strEquipmentContainerPosition_info_GetByLotDR_in_parent );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipmentContainerPosition_info_GetByLotDR() != RC_OK", rc);
        strMergeWaferLotReqResult.strResult = strEquipmentContainerPosition_info_GetByLotDR_out_parent.strResult;
        return ( rc );
    }

    CORBA::Long lenEqpContPos = strEquipmentContainerPosition_info_GetByLotDR_out_parent.strEqpContainerPositionSeq.length();
    PPT_METHODTRACE_V2("", "lenEqpContPos", lenEqpContPos);
    if ( 0 < lenEqpContPos )
    {
        PPT_METHODTRACE_V1("", "Some wafers contained in this lot have equipment container positions.");
        PPT_SET_MSG_RC_KEY( strMergeWaferLotReqResult,
                            MSG_WAFER_IN_LOT_HAVE_CONTAINER_POSITION, RC_WAFER_IN_LOT_HAVE_CONTAINER_POSITION,
                            parentLotID.identifier );
        return( RC_WAFER_IN_LOT_HAVE_CONTAINER_POSITION );
    }

    // for childLotID
    PPT_METHODTRACE_V1("", "call equipmentContainerPosition_info_GetByLotDR( childLot )");
    objEquipmentContainerPosition_info_GetByLotDR_out strEquipmentContainerPosition_info_GetByLotDR_out_child;
    objEquipmentContainerPosition_info_GetByLotDR_in  strEquipmentContainerPosition_info_GetByLotDR_in_child;
    strEquipmentContainerPosition_info_GetByLotDR_in_child.lotID = childLotID;
    rc = equipmentContainerPosition_info_GetByLotDR( strEquipmentContainerPosition_info_GetByLotDR_out_child,
                                                  strObjCommonIn,
                                                  strEquipmentContainerPosition_info_GetByLotDR_in_child );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipmentContainerPosition_info_GetByLotDR() != RC_OK", rc);
        strMergeWaferLotReqResult.strResult = strEquipmentContainerPosition_info_GetByLotDR_out_child.strResult;
        return ( rc );
    }

    lenEqpContPos = strEquipmentContainerPosition_info_GetByLotDR_out_child.strEqpContainerPositionSeq.length();
    PPT_METHODTRACE_V2("", "lenEqpContPos", lenEqpContPos);
    if ( 0 < lenEqpContPos )
    {
        PPT_METHODTRACE_V1("", "Some wafers contained in this lot have equipment container positions.");
        PPT_SET_MSG_RC_KEY( strMergeWaferLotReqResult,
                            MSG_WAFER_IN_LOT_HAVE_CONTAINER_POSITION, RC_WAFER_IN_LOT_HAVE_CONTAINER_POSITION,
                            childLotID.identifier );
        return( RC_WAFER_IN_LOT_HAVE_CONTAINER_POSITION );
    }
//DSIV00000099 add end

//Q3000147 add start
    //----------------------------------
    //   Check Lot's Control Job ID
    //----------------------------------

    // for parentLot
    objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, parentLotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "lot_controlJobID_Get() != RC_OK");
        strMergeWaferLotReqResult.strResult = strLot_controlJobID_Get_out.strResult ;
        return(rc);
    }
    if (CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) == 0)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "CIMFWStrLen(controlJobID.identifier) = 0") ;
        rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "CIMFWStrLen(controlJobID.identifier) > 0") ;
//P4100078        PPT_SET_MSG_RC_KEY2( strLot_controlJobID_Get_out,
        PPT_SET_MSG_RC_KEY2( strMergeWaferLotReqResult,           //P4100078
                             MSG_LOT_CTLJOBID_FILLED,
                             RC_LOT_CTLJOBID_FILLED,
                             parentLotID.identifier,
                             strLot_controlJobID_Get_out.controlJobID.identifier ) ;
        return( RC_LOT_CTLJOBID_FILLED );
    }

    // for childLotID
    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, childLotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "lot_controlJobID_Get() != RC_OK");
        strMergeWaferLotReqResult.strResult = strLot_controlJobID_Get_out.strResult ;
        return(rc);
    }
    if (CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) == 0)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "CIMFWStrLen(controlJobID.identifier) = 0") ;
        rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "CIMFWStrLen(controlJobID.identifier) > 0") ;
//P4100078        PPT_SET_MSG_RC_KEY2( strLot_controlJobID_Get_out,
        PPT_SET_MSG_RC_KEY2( strMergeWaferLotReqResult,            //P4100078
                             MSG_LOT_CTLJOBID_FILLED,
                             RC_LOT_CTLJOBID_FILLED,
                             childLotID.identifier,
                             strLot_controlJobID_Get_out.controlJobID.identifier ) ;
        return( RC_LOT_CTLJOBID_FILLED );
    }
//Q3000147 add end

//DSN000071674 add start
    if( CIMFWStrLen( aParentCassetteID.identifier ) > 0)
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen( aParentCassetteID.identifier ) > 0") ;
        if ( 0 == lotOperationEIcheck )
        {
            PPT_METHODTRACE_V1("", "lotOperationEIcheck = 0") ;
            if ( 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) )
            {
                /*------------------------------------*/
                /*   Get Equipment Port Info          */
                /*------------------------------------*/
                objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
                rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                             strObjCommonIn,
                                             strCassette_equipmentID_Get_out.equipmentID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2( "", "equipment_portInfo_Get != RC_OK", rc);
                    strMergeWaferLotReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
                    return( rc );
                }

                CORBA::ULong portLen = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
                for ( CORBA::ULong portNum = 0; portNum < portLen; portNum++ )
                {
                    PPT_METHODTRACE_V2("", "portNum", portNum);
                    if ( 0 == CIMFWStrCmp( aParentCassetteID.identifier, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portNum].loadedCassetteID.identifier) )
                    {
                        PPT_METHODTRACE_V1("", "parentCassetteID == loadedCassetteID");
                        break;
                    }
                }

                //-----------------------------------------------------------------
                // Check parent lot and child lot is same operationStartFlag or not
                //-----------------------------------------------------------------
                CORBA::Boolean bParentLotOpeStartFlg = FALSE;
                CORBA::Boolean bChildLotOpeStartFlg  = FALSE;

                if (portNum < portLen)
                {
                    PPT_METHODTRACE_V1("", "portNum < portLen");
                    CORBA::ULong lotLen = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portNum].strLotOnPort.length();
                    for ( CORBA::ULong lotNum = 0; lotNum < lotLen; lotNum++ )
                    {
                        PPT_METHODTRACE_V2("", "lotNum", lotNum);
                        const pptLotOnPort& strLotOnPort = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portNum].strLotOnPort[lotNum];
                        if ( 0 == CIMFWStrCmp( parentLotID.identifier, strLotOnPort.lotID.identifier) )
                        {
                            PPT_METHODTRACE_V1("", "parentLotID == lotID");
                            bParentLotOpeStartFlg = strLotOnPort.operationStartFlag;
                        }
                        else if ( 0 == CIMFWStrCmp( childLotID.identifier, strLotOnPort.lotID.identifier) )
                        {
                            PPT_METHODTRACE_V1("", "childLotID == lotID");
                            bChildLotOpeStartFlg = strLotOnPort.operationStartFlag;
                        }
                    }
                }
                if ( bParentLotOpeStartFlg != bChildLotOpeStartFlg )
                {
                    PPT_METHODTRACE_V1("", "bParentLotOpeStartFlg != bChildLotOpeStartFlg");
                    PPT_SET_MSG_RC_KEY3( strMergeWaferLotReqResult,
                                         MSG_ATTRIBUTE_DIFFERENT_FOR_MERGE,
                                         RC_ATTRIBUTE_DIFFERENT_FOR_MERGE,
                                         "operationStartFlag",
                                         (bParentLotOpeStartFlg?"True":"False"),
                                         (bChildLotOpeStartFlg?"True":"False") );
                    return( RC_ATTRIBUTE_DIFFERENT_FOR_MERGE );
                }
            }
        }
    }
//DSN000071674 add end

    objLot_family_CheckMerge_out strLot_family_CheckMerge_out;
    rc = lot_family_CheckMerge(strLot_family_CheckMerge_out, strObjCommonIn,
                               parentLotID, childLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "lot_family_CheckMerge() rc != RC_OK");
        strMergeWaferLotReqResult.strResult = strLot_family_CheckMerge_out.strResult;
        return(rc);
    }

    objProcess_CheckMerge_out strProcess_CheckMerge_out;
    rc = process_CheckMerge(strProcess_CheckMerge_out, strObjCommonIn,
                            parentLotID, childLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "process_CheckMerge() rc != RC_OK");
        strMergeWaferLotReqResult.strResult = strProcess_CheckMerge_out.strResult;
        return(rc);
    }

//D4100069//P3100053 add start
//D4100069
//D4100069    CORBA::Long  rcParent = RC_OK;
//D4100069    CORBA::Long  rcChild  = RC_OK;
//D4100069    {
//D4100069        objLot_CheckForLCFR_out  strLot_CheckForLCFR_out;
//D4100069        rcParent = lot_CheckForLCFR( strLot_CheckForLCFR_out, strObjCommonIn, parentLotID, SP_LotCustomize_DBRECORD );
//D4100069
//D4100069        {
//D4100069            objLot_CheckForLCFR_out  strLot_CheckForLCFR_out;
//D4100069            rcChild = lot_CheckForLCFR( strLot_CheckForLCFR_out, strObjCommonIn, childLotID, SP_LotCustomize_DBRECORD );
//D4100069        }
//D4100069
//D4100069    }
//D4100069
//D4100069    if ( ( rcParent == RC_OK) || ( rcChild == RC_OK) )
//D4100069    {
//D4100069        PPT_METHODTRACE_V3("PPTManager_i:: txMergeWaferLotReq",
//D4100069                           "(rcParent == RC_OK) || (rcChild == RC_OK)", rcParent, rcChild);
//D4100069
//D4100069        objProcess_CheckMergeForLCFR_out   strProcess_CheckMergeForLCFR_out;
//D4100069        rc = process_CheckMergeForLCFR( strProcess_CheckMergeForLCFR_out, strObjCommonIn, parentLotID, childLotID );
//D4100069        if ( rc != RC_OK )
//D4100069        {
//D4100069            PPT_METHODTRACE_V2("PPTManager_i:: txMergeWaferLotReq",
//D4100069                               "process_CheckMergeForLCFR() != RC_OK ", rc);
//D4100069            strMergeWaferLotReqResult.strResult = strProcess_CheckMergeForLCFR_out.strResult;
//D4100069            return( rc );
//D4100069        }
//D4100069    }
//D4100069    else
//D4100069    {
//D4100069        PPT_METHODTRACE_V3("PPTManager_i:: txMergeWaferLotReq",
//D4100069                           "*** !( (rcParent == RC_OK) || (rcChild == RC_OK) )", rcParent, rcChild);
//D4100069    }
//D4100069
//D4100069//P3100053 add end

    objLot_holdList_CheckMerge_out strLot_holdList_CheckMerge_out;
    rc = lot_holdList_CheckMerge(strLot_holdList_CheckMerge_out, strObjCommonIn,
                                 parentLotID, childLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "lot_holdList_CheckMerge() rc != RC_OK");
        strMergeWaferLotReqResult.strResult = strLot_holdList_CheckMerge_out.strResult;
        return(rc);
    }

//    Keep returned holdCategory and other Output for later logic flow control to make history

    objLot_futureHoldRequests_CheckMerge_out strLot_futureHoldRequests_CheckMerge_out;
    rc = lot_futureHoldRequests_CheckMerge(strLot_futureHoldRequests_CheckMerge_out, strObjCommonIn,
                                           childLotID, parentLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "lot_futureHoldRequests_CheckMerge() rc != RC_OK");
        strMergeWaferLotReqResult.strResult = strLot_futureHoldRequests_CheckMerge_out.strResult;
        return(rc);
    }

//    Keep returned strLotHoldReleaseReqList for next logic.

    objectIdentifier aReasonCodeID ;
    aReasonCodeID.identifier = CIMFWStrDup( SP_Reason_Merge ) ;

    // for child lot
    if (strLot_futureHoldRequests_CheckMerge_out.strHoldReqList.length() != 0)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "strLot_futureHoldRequests_CheckMerge_out.strHoldReqList.length() != 0");

        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "*** for child lot  start ***");
        pptHoldLotReleaseReqResult strHoldLotReleaseReqResult;
        rc = txHoldLotReleaseReq(strHoldLotReleaseReqResult, strObjCommonIn,
                                 childLotID, aReasonCodeID,
                                 strLot_futureHoldRequests_CheckMerge_out.strHoldReqList);
                            // lotID                    = childLotID
                            // releaseReasonCodeID      = SP_Reason_Merge
                            // strLotHoldReleaseReqList = strHoldReqList
        if (rc)
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "txHoldLotReleaseReq() rc != RC_OK");
            strMergeWaferLotReqResult.strResult = strHoldLotReleaseReqResult.strResult;
            return(rc);
        }
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "*** for child lot  end  ***");

        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "*** for parent lot  start ***");
        // for parent lot
        CORBA::Long nLen = strLot_futureHoldRequests_CheckMerge_out.strHoldReqList.length();
        for (CORBA::Long i=0; i<nLen; i++)
        {
            strLot_futureHoldRequests_CheckMerge_out.strHoldReqList[i].relatedLotID = childLotID;
        }
        rc = txHoldLotReleaseReq(strHoldLotReleaseReqResult, strObjCommonIn,
                                 parentLotID, aReasonCodeID,
                                 strLot_futureHoldRequests_CheckMerge_out.strHoldReqList);
                            // lotID                    = parentLotID
                            // releaseReasonCodeID      = SP_Reason_Merge
                            // strLotHoldReleaseReqList = strHoldReqList

        if (rc)
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "txHoldLotReleaseReq() rc != RC_OK");
            strMergeWaferLotReqResult.strResult = strHoldLotReleaseReqResult.strResult;
            return(rc);
        }
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "*** for parent lot  end  ***");
    }

//D4100120 Add Start
    /*-----------------------------------*/
    /*   Check Future Action Procedure   */
    /*-----------------------------------*/
    objSchdlChangeReservation_CheckForMerge_out strSchdlChangeReservation_CheckForMerge_out;
    rc = schdlChangeReservation_CheckForMerge(strSchdlChangeReservation_CheckForMerge_out,
                                              strObjCommonIn,
                                              parentLotID,
                                              childLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "schdlChangeReservation_CheckForMerge() != RC_OK") ;
        strMergeWaferLotReqResult.strResult = strSchdlChangeReservation_CheckForMerge_out.strResult;
        return(rc);
    }
//D4100120 Add End

//DSN000033655 Add Start
    /*----------------------------------------*/
    /*   Check Q-Time information condition   */
    /*----------------------------------------*/
    objQTime_CheckForMerge_out strQTime_CheckForMerge_out;
    objQTime_CheckForMerge_in  strQTime_CheckForMerge_in;
    strQTime_CheckForMerge_in.parentLotID = parentLotID;
    strQTime_CheckForMerge_in.childLotID  = childLotID;
    rc = qTime_CheckForMerge(strQTime_CheckForMerge_out,
                             strObjCommonIn,
                             strQTime_CheckForMerge_in);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "qTime_CheckForMerge() != RC_OK") ;
        strMergeWaferLotReqResult.strResult = strQTime_CheckForMerge_out.strResult;
        return(rc);
    }
//DSN000033655 Add End

    //------------------------------------------------------------------------
    //   //DCR4000125 Create History Event before child lot's wafer become parent lot's wafer
    //   lotWaferMoveEvent_MakeMerge() only prepare merge event information.
    //------------------------------------------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "Create History Event before child lot's wafer become parent lot's wafer");

    objLotWaferMoveEvent_MakeMerge_out strLotWaferMoveEvent_MakeMerge_out;
    //DCR4000125 rc = lotWaferMoveEvent_MakeMerge( strLotWaferMoveEvent_MakeMerge_out, strObjCommonIn,
    //DCR4000125                                   "TXTRC023", childLotID, parentLotID, claimMemo );
    rc = lotWaferMoveEvent_MakeMerge( strLotWaferMoveEvent_MakeMerge_out, strObjCommonIn,
                                      strObjCommonIn.transactionID, childLotID, parentLotID );

    if (rc)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "lotWaferMoveEvent_MakeMerge() rc != RC_OK");
        strMergeWaferLotReqResult.strResult = strLotWaferMoveEvent_MakeMerge_out.strResult;
        return(rc);
    }

    //------------------------------------------------------------------------
    //   Change State
    //------------------------------------------------------------------------
    //P5100296 Add Start
    //---------------------------------------------------------------------------------
    //  If Child Lot is member of Monitor Group,
    //  the following action is performed according to the rule.
    //
    //           |                | Child Lot is Monitored Lot
    //           | Child Lot is   +----------------------+---------------------------
    //    Rule   | Monitoring Lot | only 1 Monitored Lot | more than 2 Monitored Lot
    //   --------+----------------+----------------------+---------------------------
    //    Action | return ERROR   | return ERROR         | remove from Monitor Group
    //---------------------------------------------------------------------------------
    PPT_METHODTRACE_V1("", "call lot_RemoveFromMonitorGroup()");
    objLot_RemoveFromMonitorGroup_out  strLot_RemoveFromMonitorGroup_out;
    rc = lot_RemoveFromMonitorGroup( strLot_RemoveFromMonitorGroup_out, strObjCommonIn, childLotID );

    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "##### lot_RemoveFromMonitorGroup() != RC_OK", rc);
        strMergeWaferLotReqResult.strResult = strLot_RemoveFromMonitorGroup_out.strResult;
        return rc;
    }
    //P5100296 Add End

    objLot_MergeWaferLot_out strLot_MergeWaferLot_out;
    rc = lot_MergeWaferLot(strLot_MergeWaferLot_out, strObjCommonIn,
                           parentLotID, childLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "lot_MergeWaferLot() rc != RC_OK");
        strMergeWaferLotReqResult.strResult = strLot_MergeWaferLot_out.strResult;
        return(rc);
    }
//D4100069//(D3000118,D3000119) add start
//D4100069    objLot_CheckForLCFR_out strLot_CheckForLCFR_out;
//D4100069    rc = lot_CheckForLCFR(strLot_CheckForLCFR_out, strObjCommonIn, childLotID, SP_LotCustomize_DBRECORD);
//D4100069    if ( rc == RC_OK)
//D4100069    {
//D4100069        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "Lot_CheckForLCFR() rc = RC_OK");
//D4100069        objLot_MergeWaferLotForLCFR_out strLot_MergeWaferLotForLCFR_out;
//D4100069        rc = lot_MergeWaferLotForLCFR(strLot_MergeWaferLotForLCFR_out,
//D4100069                                      strObjCommonIn,
//D4100069                                      childLotID);
//D4100069        if ( rc != RC_OK)
//D4100069        {
//D4100069             PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "lot_MergeWaferLotForLCFR() rc != RC_OK");
//D4100069            // set returned strResult to strResult of out parameter
//D4100069            strMergeWaferLotReqResult.strResult = strLot_MergeWaferLotForLCFR_out.strResult;
//D4100069            return(rc);
//D4100069        }
//D4100069    }
//D4100069//(D3000118,D3000119) add end

//DSN000033655 Add Start
    /*----------------------------------------*/
    /*   Merge Q-Time information             */
    /*----------------------------------------*/
    objQTime_infoMerge_out strQTime_infoMerge_out;
    objQTime_infoMerge_in  strQTime_infoMerge_in;
    strQTime_infoMerge_in.parentLotID = parentLotID;
    strQTime_infoMerge_in.childLotID  = childLotID;
    rc = qTime_infoMerge(strQTime_infoMerge_out,
                         strObjCommonIn,
                         strQTime_infoMerge_in);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "qTime_infoMerge() != RC_OK") ;
        strMergeWaferLotReqResult.strResult = strQTime_infoMerge_out.strResult;
        return(rc);
    }
//DSN000033655 Add End

    //---------------------------------------
    //   Update Cassette's MultiLotType
    //---------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "Update Cassette's MultiLotType");
//D9000038 add start
    if( CIMFWStrLen( aParentCassetteID.identifier ) > 0)
    {
//D9000038 add end
//DSN000071674 add start
        if ( TRUE == updateControlJobFlag )
        {
            //----------------------
            // Update control Job Info and
            // Machine Cassette info if information exist
            //----------------------
            objectIdentifierSequence tmpCassetteIDSeq;
            tmpCassetteIDSeq.length(1);
            tmpCassetteIDSeq[0] = aParentCassetteID;
            objControlJob_relatedInfo_Update_out strControlJob_relatedInfo_Update_out;
            rc = controlJob_relatedInfo_Update(strControlJob_relatedInfo_Update_out, strObjCommonIn,
                                               tmpCassetteIDSeq);
            if (rc)
            {
                PPT_METHODTRACE_V2("", "controlJob_relatedInfo_Update() != RC_OK", rc);
                strMergeWaferLotReqResult.strResult = strControlJob_relatedInfo_Update_out.strResult;
                return(rc);
            }
        }
//DSN000071674 add end

        objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
        rc = cassette_multiLotType_Update(strCassette_multiLotType_Update_out, strObjCommonIn,
                                          aParentCassetteID);
        if (rc)
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "cassette_multiLotType_Update() rc != RC_OK");
            strMergeWaferLotReqResult.strResult = strCassette_multiLotType_Update_out.strResult;
            return(rc);
        }
//D9000038 add start
    }
    else
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "The parent cassetteID is empty. Skip cassette_multiLotType_Update().");
    }
//D9000038 add end

    //------------------------------------------------------------------------
    //   Make History
    //------------------------------------------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "Make History");

    objLot_waferLotHistoryPointer_Update_out strLot_waferLotHistoryPointer_Update_out;
    rc = lot_waferLotHistoryPointer_Update(strLot_waferLotHistoryPointer_Update_out, strObjCommonIn,
                                           parentLotID);
    //for Parent lot, for later generating OPEHS
    if (rc)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "lot_waferLotHistoryPointer_Update() rc != RC_OK");
        strMergeWaferLotReqResult.strResult = strLot_waferLotHistoryPointer_Update_out.strResult;
//P5000145        PPT_SET_MSG_RC_KEY(strMergeWaferLotReqResult, MSG_FAIL_MAKE_HISTORY, rc,
//P5000145                           parentLotID.identifier);
        SET_MSG_RC( strMergeWaferLotReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145
        return(rc);
    }

    //DCR4000125 Start
    objLotWaferMoveEvent_Make_out strLotWaferMoveEvent_Make_out;

    rc = lotWaferMoveEvent_Make( strLotWaferMoveEvent_Make_out,
                                 strObjCommonIn,
                                 strObjCommonIn.transactionID,
                                 strLotWaferMoveEvent_MakeMerge_out.strNewLotAttributes,
                                 claimMemo );

    if(rc)
    {
        PPT_METHODTRACE_V1( "", "lotWaferMoveEvent_Make() rc != RC_OK" );
        strMergeWaferLotReqResult.strResult = strLotWaferMoveEvent_Make_out.strResult ;
        return rc;
    }
    //DCR4000125 End

//DSN000085791 add start
    //-- Entity Inhibit Exception Lot Data --//
    // Get Entity Inhibition Info
    PosEntityInhibitSequence_var entityInhibitSeq = theEntityInhibitManager->getEntityInhibitsWithExceptionLotByLot(childLotID);
    CORBA::ULong numOfInhibit = entityInhibitSeq->length();
    PPT_METHODTRACE_V2( "", "numOfInhibit", numOfInhibit );

    // Make Exception Lot Cancel Data
    if( numOfInhibit > 0 )
    {
        pptEntityInhibitExceptionLotCancelReqInParm cancelReqData;
        cancelReqData.strEntityInhibitExceptionLots.length(numOfInhibit);

        for( CORBA::ULong nInhibit = 0; nInhibit < numOfInhibit; nInhibit++ )
        {
            posEntityInhibitRecord_var entityInhibitRecord = (*entityInhibitSeq)[nInhibit]->getInhibitRecord();

            cancelReqData.strEntityInhibitExceptionLots[nInhibit].entityInhibitID.identifier                 = CIMFWStrDup(entityInhibitRecord->identifier);
            cancelReqData.strEntityInhibitExceptionLots[nInhibit].entityInhibitID.stringifiedObjectReference = CIMFWStrDup(entityInhibitRecord->stringifiedObjectReference);
            cancelReqData.strEntityInhibitExceptionLots[nInhibit].lotID = childLotID;
        }

        PPT_METHODTRACE_V1("", "call txEntityInhibitExceptionLotCancelReq");
        CORBA::String_var claimMemo = CIMFWStrDup("Delete for MergeWaferLot");
        pptEntityInhibitExceptionLotCancelReqResult strExceptionLotCancelReqResult;
        rc = txEntityInhibitExceptionLotCancelReq(strExceptionLotCancelReqResult, strObjCommonIn, cancelReqData, claimMemo);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "txEntityInhibitExceptionLotCancelReq() != RC_OK");
            strMergeWaferLotReqResult.strResult = strExceptionLotCancelReqResult.strResult;
            return( rc );
        }
    }
//DSN000085791 add end

    //------------------------------------------------------------------------
    //   Return
    //------------------------------------------------------------------------
    SET_MSG_RC(strMergeWaferLotReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("PPTManager_i:: txMergeWaferLotReq ");
    return RC_OK;
}