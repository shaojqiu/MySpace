//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// SiView
// Name: cs_txEqpMonitorListInqOR.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: cs_txEqpMonitorListInq()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------------------
// 2013/07/10 DSN000081739 Sa Guo         Equipment Monitor Automation Support
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/23 INN-R170016  JJ.Zhang       Equipment Monitor customization
//
// Description:
//   This function returns equipment monitor information for specified equipment or a specified equipment monitor.
//
//
// Return:
//    long
//
// Parameter:
//  [Input Parameters]:
//    const pptObjCommonIn&                           strObjCommonIn
//    const pptEqpMonitorListInqInParm&               strEqpMonitorListInqInParm
//
//    typedef struct pptEqpMonitorListInqInParm_struct {
//        objectIdentifier   equipmentID;
//        objectIdentifier   eqpMonitorID;
//        any                siInfo;
//    } pptEqpMonitorListInqInParm;
//
//  [Output Parameters]:
//    pptEqpMonitorListInqResult&                     strEqpMonitorListInqResult
//
//    typedef struct pptEqpMonitorListInqResult_struct {
//        pptRetCode                        strResult;
//        pptEqpMonitorDetailInfoSequence   strEqpMonitorDetailInfoSeq;
//        any                               siInfo;
//    } pptEqpMonitorListInqResult;
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

//CORBA::Long PPTManager_i::txEqpMonitorListInq(
//    pptEqpMonitorListInqResult&                     strEqpMonitorListInqResult,
CORBA::Long CS_PPTManager_i::cs_txEqpMonitorListInq(
    csEqpMonitorListInqResult&                      strEqpMonitorListInqResult, //INN-R170016
    const pptObjCommonIn&                           strObjCommonIn,
    const pptEqpMonitorListInqInParm&               strEqpMonitorListInqInParm
    CORBAENV_LAST_CPP )
{
    PPT_METHODTRACE_ENTRY("PPTManager_i::txEqpMonitorListInq");
    //----------------------------------------------------------------
    //
    //  Pre Process
    //
    //----------------------------------------------------------------

    // Initialize
    CORBA::Long rc = RC_OK;

    //----------------------------------------------------------------
    //  In-Parameter Trace
    //----------------------------------------------------------------

    //Trace InParameters
    PPT_METHODTRACE_V2("", "in-parm equipmentID     ", strEqpMonitorListInqInParm.equipmentID.identifier);
    PPT_METHODTRACE_V2("", "in-parm eqpMonitorID    ", strEqpMonitorListInqInParm.eqpMonitorID.identifier);

    //Blank input check for in-parameter "equipmentID"
    if ( 0 == CIMFWStrLen( strEqpMonitorListInqInParm.equipmentID.identifier ) )
    {
        PPT_METHODTRACE_V1("", "Input parameter equipmentID is blank");
        PPT_SET_MSG_RC_KEY( strEqpMonitorListInqResult,
                            MSG_BLANK_INPUT_PARAMETER,
                            RC_BLANK_INPUT_PARAMETER,
                            "equipmentID" );
        return RC_BLANK_INPUT_PARAMETER;
    }

    //----------------------------------------------------------------
    //  Get EqpMonitor information from DB
    //----------------------------------------------------------------
//INN-R170016    objEqpMonitor_list_GetDR_out strEqpMonitor_list_GetDR_out;
    csObjEqpMonitor_list_GetDR_out strEqpMonitor_list_GetDR_out; //INN-R170016
    objEqpMonitor_list_GetDR_in  strEqpMonitor_list_GetDR_in;
    strEqpMonitor_list_GetDR_in.equipmentID  = strEqpMonitorListInqInParm.equipmentID;
    strEqpMonitor_list_GetDR_in.eqpMonitorID = strEqpMonitorListInqInParm.eqpMonitorID;
//INN-R170016    rc = eqpMonitor_list_GetDR( strEqpMonitor_list_GetDR_out,
    rc = cs_eqpMonitor_list_GetDR( strEqpMonitor_list_GetDR_out, //INN-R170016
                                strObjCommonIn,
                                strEqpMonitor_list_GetDR_in );

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "eqpMonitor_list_GetDR() != RC_OK", rc);
        strEqpMonitorListInqResult.strResult = strEqpMonitor_list_GetDR_out.strResult;
        return rc;
    }

    //----------------------------------------------------------------
    //  Calculate nextExecutionTime by collected EqpMonitor
    //----------------------------------------------------------------
//INN-R170016    pptEqpMonitorDetailInfoSequence strEqpMonitorDetailInfoSeq;
    csEqpMonitorDetailInfoSequence strEqpMonitorDetailInfoSeq; //INN-R170016
    strEqpMonitorDetailInfoSeq = strEqpMonitor_list_GetDR_out.strEqpMonitorDetailInfoSeq;
    for ( CORBA::ULong iCnt = 0; iCnt < strEqpMonitorDetailInfoSeq.length(); iCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strEqpMonitorDetailInfoSeq.length()", iCnt);
        if ( 0 == CIMFWStrCmp(strEqpMonitorDetailInfoSeq[iCnt].monitorType, SP_EqpMonitor_Type_Routine) )
        {
            PPT_METHODTRACE_V1("", "monitorType is Routine, calling eqpMonitor_nextExecutionTime_Calculate()");
            objEqpMonitor_nextExecutionTime_Calculate_out strEqpMonitor_nextExecutionTime_Calculate_out;
            objEqpMonitor_nextExecutionTime_Calculate_in  strEqpMonitor_nextExecutionTime_Calculate_in;
            strEqpMonitor_nextExecutionTime_Calculate_in.currentScheduleBaseTime = strEqpMonitorDetailInfoSeq[iCnt].scheduleBaseTimeStamp;
            strEqpMonitor_nextExecutionTime_Calculate_in.executionInterval       = strEqpMonitorDetailInfoSeq[iCnt].executionInterval;
            strEqpMonitor_nextExecutionTime_Calculate_in.scheduleAdjustment      = strEqpMonitorDetailInfoSeq[iCnt].scheduleAdjustment;
            strEqpMonitor_nextExecutionTime_Calculate_in.lastMonitorPassedTime   = strEqpMonitorDetailInfoSeq[iCnt].lastMonitorPassedTimeStamp;
            strEqpMonitor_nextExecutionTime_Calculate_in.expirationInterval      = strEqpMonitorDetailInfoSeq[iCnt].expirationInterval;
            strEqpMonitor_nextExecutionTime_Calculate_in.futureTimeRequireFlag   = FALSE;
            rc = eqpMonitor_nextExecutionTime_Calculate( strEqpMonitor_nextExecutionTime_Calculate_out,
                                                         strObjCommonIn,
                                                         strEqpMonitor_nextExecutionTime_Calculate_in );

            if ( rc != RC_OK && rc != RC_EXCEED_EXPIRATION_TIME )
            {
                PPT_METHODTRACE_V2("", "eqpMonitor_nextExecutionTime_Calculate() != RC_OK && RC_EXCEED_EXPIRATION_TIME", rc);
                strEqpMonitorListInqResult.strResult = strEqpMonitor_nextExecutionTime_Calculate_out.strResult;
                return rc;
            }

            strEqpMonitorDetailInfoSeq[iCnt].nextExecutionTime = strEqpMonitor_nextExecutionTime_Calculate_out.nextExecutionTime;
            strEqpMonitorDetailInfoSeq[iCnt].expirationTime    = strEqpMonitor_nextExecutionTime_Calculate_out.expirationTime;
        }
    }

    //------------------------------------------------------
    //  Set output result
    //------------------------------------------------------
    strEqpMonitorListInqResult.strEqpMonitorDetailInfoSeq = strEqpMonitorDetailInfoSeq;

    // Return to caller
    SET_MSG_RC( strEqpMonitorListInqResult, MSG_OK, RC_OK );
    PPT_METHODTRACE_EXIT("PPTManager_i::txEqpMonitorListInq");
    return RC_OK;
}