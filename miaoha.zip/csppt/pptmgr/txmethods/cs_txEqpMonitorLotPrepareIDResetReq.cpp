//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txEqpMonitorLotPrepareIDResetReq.cpp
//
#include "cs_pptmgr.hpp"
//
// Class: CS_PPTManager
//
// Service: cs_txEqpMonitorLotPrepareIDResetReq()
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------- -------------- -------------------------------------------
// 2017/10/27 INN-R170016   JJ.Zhang       NPW Monitor Customization
//
// Description:
//
// Return:
//     long
//
// Parameter:
//      csEqpMonitorLotPrepareIDResetReqResult&         strEqpMonitorLotPrepareIDResetReqResult
//      const pptObjCommonIn&                           strObjCommonIn
//      const csEqpMonitorLotPrepareIDResetReqInParm&   strEqpMonitorLotPrepareIDResetReqInParm
//      const char*                                     claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//

CORBA::Long CS_PPTManager_i::cs_txEqpMonitorLotPrepareIDResetReq(
    csEqpMonitorLotPrepareIDResetReqResult&         strEqpMonitorLotPrepareIDResetReqResult,
    const pptObjCommonIn&                           strObjCommonIn,
    const csEqpMonitorLotPrepareIDResetReqInParm&   strEqpMonitorLotPrepareIDResetReqInParm,
    const char*                                     claimMemo
    CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txEqpMonitorLotPrepareIDResetReq")
    CORBA::Long rc = RC_OK;

    PPT_METHODTRACE_V2("","in para eqpMonitorID",strEqpMonitorLotPrepareIDResetReqInParm.eqpMonitorID.identifier );
    PPT_METHODTRACE_V2("","in para carrierID   ",strEqpMonitorLotPrepareIDResetReqInParm.carrierID.identifier );

    CORBA::ULong i = 0, j = 0;
    CORBA::ULong nSeqLen = 0;

    objectIdentifier carrierID = strEqpMonitorLotPrepareIDResetReqInParm.carrierID;
    //--------------------------------
    //   Object Lock for Cassette
    //--------------------------------
    objObject_Lock_out  strObject_Lock_out;
    rc = object_Lock(strObject_Lock_out, strObjCommonIn, carrierID, SP_ClassName_PosCassette);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
        strEqpMonitorLotPrepareIDResetReqResult.strResult = strObject_Lock_out.strResult;
        return(rc);
    }

    //--------------------------------
    //  Get cassette lot list.
    //--------------------------------
    objCassette_GetLotList_out strCassette_GetLotList_out;
    rc = cassette_GetLotList( strCassette_GetLotList_out, strObjCommonIn, carrierID );

    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cassette_GetLotList() != RC_OK", rc);
        strEqpMonitorLotPrepareIDResetReqResult.strResult = strCassette_GetLotList_out.strResult;
        return( rc );
    }

    objectIdentifierSequence lotIDs;
    lotIDs = strCassette_GetLotList_out.strLotListInCassetteInfo.lotID;
    CORBA::ULong nLotLen = lotIDs.length();

    for( i =0; i<nLotLen; i++)
    {
        //------------------------------
        // Lock lot for update
        //------------------------------
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, lotIDs[i], SP_ClassName_PosLot );
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
            strEqpMonitorLotPrepareIDResetReqResult.strResult = strObject_Lock_out.strResult;
            return(rc);
        }
    }

    //----------------------------------------------
    // Check slot map matched the monitor definiton
    //----------------------------------------------
    objCassette_GetWaferMapDR_out strCassette_GetWaferMapDR_out;
    rc = cassette_GetWaferMapDR(strCassette_GetWaferMapDR_out, strObjCommonIn, carrierID);
    if(rc!= RC_OK)
    {
        PPT_METHODTRACE_V2("", "cassette_GetWaferMapDR() != RC_OK ", carrierID.identifier );
        strEqpMonitorLotPrepareIDResetReqResult.strResult = strCassette_GetWaferMapDR_out.strResult;
        return( rc );
    }
    CORBA::ULong mapLen = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo.length();
    pptWaferMapInCassetteInfoSequence strWaferMapInCassetteInfoSeq;
    strWaferMapInCassetteInfoSeq.length(mapLen);
    CORBA::Long waferCount = 0;

    for( i =0; i<mapLen; i++)
    {
        PPT_METHODTRACE_V2("", "waferID", strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].waferID.identifier );
        if( 0 < CIMFWStrLen(strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i].waferID.identifier) )
        {
            strWaferMapInCassetteInfoSeq[waferCount] = strCassette_GetWaferMapDR_out.strWaferMapInCassetteInfo[i];
            waferCount++ ;
        }
    }
    strWaferMapInCassetteInfoSeq.length(waferCount);
    PPT_METHODTRACE_V2("", "waferCount", waferCount );

    objEqpMonitor_info_Get_in strEqpMonitor_info_Get_in;
    strEqpMonitor_info_Get_in.eqpMonitorID = strEqpMonitorLotPrepareIDResetReqInParm.eqpMonitorID;

    csObjEqpMonitor_info_Get_out strEqpMonitor_info_Get_out;
    rc = cs_eqpMonitor_info_GetDR( strEqpMonitor_info_Get_out,
                              strObjCommonIn,
                              strEqpMonitor_info_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_eqpMonitor_info_GetDR() != RC_OK", rc);
        strEqpMonitorLotPrepareIDResetReqResult.strResult = strEqpMonitor_info_Get_out.strResult;
        return rc;
    }

    csEqpMonitorSubInfoSequence& strEqpMonitorSubInfoSeq = strEqpMonitor_info_Get_out.strEqpMonitorDetailInfos[0].strEqpMonitorSubInfoSeq;
    nSeqLen = strEqpMonitorSubInfoSeq.length();
    PPT_METHODTRACE_V2("", "nSeqLen", nSeqLen );

    if( waferCount != nSeqLen )
    {
        //slot map not matched the monitor definiton
        PPT_METHODTRACE_V2("", "waferCount!= nSeqLen", waferCount );
        CS_PPT_SET_MSG_RC_KEY2( strEqpMonitorLotPrepareIDResetReqResult,
                                CS_MSG_WAFER_SLOTMAP_UNMATCH,
                                CS_RC_WAFER_SLOTMAP_UNMATCH,
                                carrierID.identifier,
                                strEqpMonitorLotPrepareIDResetReqInParm.eqpMonitorID.identifier );
        return CS_RC_WAFER_SLOTMAP_UNMATCH;
    }

    for( i =0; i<nSeqLen; i++)
    {
        //wafer in slot should have same attribute as what defined in EQPMON_SUB
        PPT_METHODTRACE_V2("", " check slotNumber", strEqpMonitorSubInfoSeq[i].slotNumber);
        if(strWaferMapInCassetteInfoSeq[i].slotNumber != strEqpMonitorSubInfoSeq[i].slotNumber)
        {
            PPT_METHODTRACE_V2("", "WaferID", strWaferMapInCassetteInfoSeq[i].waferID.identifier);
            char slotNumber[64];
            sprintf(slotNumber, "%ld", strWaferMapInCassetteInfoSeq[i].slotNumber);
            PPT_SET_MSG_RC_KEY3( strEqpMonitorLotPrepareIDResetReqResult,
                                 MSG_NOT_USE_SLOT, RC_NOT_USE_SLOT,
                                 strWaferMapInCassetteInfoSeq[i].waferID.identifier,
                                 slotNumber,
                                 carrierID.identifier );
            return RC_NOT_USE_SLOT;
        }

        //----------------------------------------------
        // Get product ID for wafer
        //----------------------------------------------
        objLot_productID_Get_out strLot_productID_Get_out;
        rc = lot_productID_Get( strLot_productID_Get_out,
                                strObjCommonIn,
                                strWaferMapInCassetteInfoSeq[i].lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "","lot_productID_Get != RC_OK", rc );
            strEqpMonitorLotPrepareIDResetReqResult.strResult = strLot_productID_Get_out.strResult;
            return rc;
        }
        PPT_METHODTRACE_V2("", "productID", strLot_productID_Get_out.productID.identifier);

        if ( 0 != CIMFWStrCmp(strLot_productID_Get_out.productID.identifier, strEqpMonitorSubInfoSeq[i].productID.identifier) )
        {
            PPT_METHODTRACE_V2("", "Product doesn't match", strWaferMapInCassetteInfoSeq[i].waferID.identifier);
            char slotNumber[64];
            sprintf(slotNumber, "%ld", strWaferMapInCassetteInfoSeq[i].slotNumber);
            PPT_SET_MSG_RC_KEY3( strEqpMonitorLotPrepareIDResetReqResult,
                                 MSG_NOT_USE_SLOT, RC_NOT_USE_SLOT,
                                 strWaferMapInCassetteInfoSeq[i].waferID.identifier,
                                 slotNumber,
                                 carrierID.identifier );
            return RC_NOT_USE_SLOT;
        }
    }

    //----------------------------------------------
    // Reset lot-udata for all lots
    //----------------------------------------------
    PPT_METHODTRACE_V1("", "call cs_eqpMonitorLot_prepareIDReset");

    csObjEqpMonitorLot_prepareIDSet_in strEqpMonitorLot_prepareIDSet_in;
    strEqpMonitorLot_prepareIDSet_in.eqpMonitorID = strEqpMonitorLotPrepareIDResetReqInParm.eqpMonitorID;
    strEqpMonitorLot_prepareIDSet_in.carrierID = strEqpMonitorLotPrepareIDResetReqInParm.carrierID;
    strEqpMonitorLot_prepareIDSet_in.lotIDs = lotIDs;

    csObjEqpMonitorLot_prepareIDSet_out strEqpMonitorLot_prepareIDSet_out;
    rc = cs_eqpMonitorLot_prepareIDSet( strEqpMonitorLot_prepareIDSet_out,
                                 strObjCommonIn,
                                 strEqpMonitorLot_prepareIDSet_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_EqpMonitorLot_prepareIDSet != RC_OK", rc);
        strEqpMonitorLotPrepareIDResetReqResult.strResult = strEqpMonitorLot_prepareIDSet_out.strResult;
        return( rc );
    }

    //---------------------------------------------
    //   Return
    //---------------------------------------------
    SET_MSG_RC(strEqpMonitorLotPrepareIDResetReqResult, MSG_OK, RC_OK) ;
        
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txEqpMonitorLotPrepareIDResetReq")
    return( RC_OK );
}
