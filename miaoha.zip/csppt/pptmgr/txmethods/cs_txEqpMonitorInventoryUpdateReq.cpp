//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txEqpMonitorInventoryUpdateReq.cpp
//
#include "cs_pptmgr.hpp"
//
// Class: PPTManager
//
// Service: txEqpMonitorInventoryUpdateReq()
//
// Innotron Modification history:
// Date       DCR/PCR No   Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/23 INN-R170016  JQ.Shao        NPW Management Initial Release
//
// Description:
//
// Return:
//     long
//
// Parameter:
//     csEqpMonitorInventoryUpdateReqResult&            strEqpMonitorInventoryUpdateReqResult
//     const pptObjCommonIn&                            strObjCommonIn
//     const csEqpMonitorInventoryUpdateReqInParm&      strEqpMonitorInventoryUpdateReqInParm
//     const char *                                     claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//
CORBA::Long CS_PPTManager_i::cs_txEqpMonitorInventoryUpdateReq(
    csEqpMonitorInventoryUpdateReqResult&            strEqpMonitorInventoryUpdateReqResult,
    const pptObjCommonIn&                            strObjCommonIn,
    const csEqpMonitorInventoryUpdateReqInParm&      strEqpMonitorInventoryUpdateReqInParm,
    const char*                                      claimMemo
    CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txEqpMonitorInventoryUpdateReq")

    //--------------
    // Initialize
    //--------------
    CORBA::Long rc = RC_OK;
    const csEqpMonitorInventoryInfo& strEqpMonitorInventoryInfo = strEqpMonitorInventoryUpdateReqInParm.strEqpMonitorInventoryInfo;
    PPT_METHODTRACE_V2("", "in para actionCode ",   strEqpMonitorInventoryUpdateReqInParm.actionCode);
    PPT_METHODTRACE_V2("", "in para productID ",    strEqpMonitorInventoryInfo.productID);
    PPT_METHODTRACE_V2("", "in para subLotType",    strEqpMonitorInventoryInfo.subLotType);
    PPT_METHODTRACE_V2("", "in para npwType",       strEqpMonitorInventoryInfo.npwType);
    PPT_METHODTRACE_V2("", "in para targetQty",     strEqpMonitorInventoryInfo.targetQty);
    PPT_METHODTRACE_V2("", "in para useCountLimit", strEqpMonitorInventoryInfo.useCountLimit);
    PPT_METHODTRACE_V2("", "in para autoSTB",       strEqpMonitorInventoryInfo.autoSTB);
    PPT_METHODTRACE_V2("", "in para userID",        strObjCommonIn.strUser.userID.identifier);
    
    //----------------------------------------------------------------
    //  In parameters check
    //----------------------------------------------------------------
    //Blank input check for in-parameter "actionCode"
    if ( 0 == CIMFWStrLen( strEqpMonitorInventoryUpdateReqInParm.actionCode ) )
    {
        PPT_METHODTRACE_V1("", "Input parameter actionCode is blank");
        PPT_SET_MSG_RC_KEY( strEqpMonitorInventoryUpdateReqResult,
                            MSG_BLANK_INPUT_PARAMETER,
                            RC_BLANK_INPUT_PARAMETER,
                            "actionCode" );
        return RC_BLANK_INPUT_PARAMETER;
    }

    //Blank input check for in-parameter "productID"
    if ( 0 == CIMFWStrLen( strEqpMonitorInventoryInfo.productID ) )
    {
        PPT_METHODTRACE_V1("", "Input parameter productID is blank");
        PPT_SET_MSG_RC_KEY( strEqpMonitorInventoryUpdateReqResult,
                            MSG_BLANK_INPUT_PARAMETER,
                            RC_BLANK_INPUT_PARAMETER,
                            "productID" );
        return RC_BLANK_INPUT_PARAMETER;
    }

    //Blank input check for in-parameter "npwType"
    if ( 0 == CIMFWStrLen( strEqpMonitorInventoryInfo.npwType ) )
    {
        PPT_METHODTRACE_V1("", "Input parameter npwType is blank");
        PPT_SET_MSG_RC_KEY( strEqpMonitorInventoryUpdateReqResult,
                            MSG_BLANK_INPUT_PARAMETER,
                            RC_BLANK_INPUT_PARAMETER,
                            "npwType" );
        return RC_BLANK_INPUT_PARAMETER;
    }

    //Create, Update, or Delete must be specified as actionCode
    if ( 0 != CIMFWStrCmp(strEqpMonitorInventoryUpdateReqInParm.actionCode, SP_EqpMonitor_OpeCategory_Create)
      && 0 != CIMFWStrCmp(strEqpMonitorInventoryUpdateReqInParm.actionCode, SP_EqpMonitor_OpeCategory_Update)
      && 0 != CIMFWStrCmp(strEqpMonitorInventoryUpdateReqInParm.actionCode, SP_EqpMonitor_OpeCategory_Delete) )
    {
        PPT_METHODTRACE_V1("", "Input parameter actionCode is invalid");
        SET_MSG_RC( strEqpMonitorInventoryUpdateReqResult,
                    MSG_INVALID_INPUT_PARM,
                    RC_INVALID_INPUT_PARM );
        return RC_INVALID_INPUT_PARM;
    }

    //Perform eqpMonitor update
    csObjEqpMonitorInventory_info_Update_out strObjEqpMonitorInventory_info_Update_out;
    csObjEqpMonitorInventory_info_Update_in  strObjEqpMonitorInventory_info_Update_in;
    strObjEqpMonitorInventory_info_Update_in.strEqpMonitorInventoryInfo = strEqpMonitorInventoryUpdateReqInParm.strEqpMonitorInventoryInfo;
    strObjEqpMonitorInventory_info_Update_in.actionCode                 = strEqpMonitorInventoryUpdateReqInParm.actionCode;
    rc = cs_eqpMonitorInventory_info_UpdateDR( strObjEqpMonitorInventory_info_Update_out,
                                               strObjCommonIn,
                                               strObjEqpMonitorInventory_info_Update_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "eqpMonitorInventory_info_Update() != RC_OK", rc);
        strEqpMonitorInventoryUpdateReqResult.strResult = strObjEqpMonitorInventory_info_Update_out.strResult;
        return rc;
    }

    //---------------------------
    //  Set out structure
    //---------------------------
    SET_MSG_RC(strEqpMonitorInventoryUpdateReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txEqpMonitorInventoryUpdateReq")
    return( RC_OK );
}
