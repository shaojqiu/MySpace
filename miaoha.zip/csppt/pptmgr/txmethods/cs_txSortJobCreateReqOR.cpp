#ifndef lint
static char *sccsid =  "@(#) 1.4 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txSortJobCreateReqOR.cpp, mm_srv_120e_ppt, mm_srv_120e_ppt 10/29/07 10:29:05 [ 10/29/07 10:29:06 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cs_txSortJobCreateReqOR.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: txSortJobCreateReq()
//
// Change history:
// Date       Defect#    Person         Comments
// ----------- ---------- -------------- -------------------------------------------
// 2007/06/29  D9000005   M.Murata       Initial (R9.0) 
// 2007/10/23  D9000098   M.Murata       Divided Library
// ---------- ------------ -------------- -------------------------------------------
// 2008/08/15 DSIV00000099 F.Chen        SLM(Small Lot Manufacturing) Support.
// 2011/09/27 DSN000020767 T.Ishida      Auto Dispatch Control Support
// 2012/12/03 DSN000049350 K.Yamaoku     Equipment parallel processing support (P2)
// 2013/06/19 PSN000078594 W.Zhang       add retry for TCSMgr_SendSortJobNotificationReq
// 2015/11/16 DSN000096126 C.Mo          txCassetteStatusInq__120 ==> txCassetteStatusInq__160
// 2016/07/27 DSN000101569 C.Mo          txCassetteStatusInq__160 ==> txCassetteStatusInq__170
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/08/28 INN-R170002  Yangxiaojun   Overide txSortJobCreateReq
// 2017/11/01 INN-R170017  Evie Su       add BWS logic
// 
// Description:
// This fuction creates Sorter Job information.
//
// Return:
//   long
//
// Parameter:
//   pptSortJobCreateReqResult&                          strSortJobCreateReqResult
//   const pptObjCommonIn&                               strObjCommonIn,
//   const pptSorterComponentJobListAttributesSequence&  strSorterComponentJobListAttributesSequence,
//   const objectIdentifier&                             equipmentID,
//   const char *                                        portGroupID,
//   CORBA::Boolean                                      waferIDReadFlag
//   const char *                                        claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::txSortJobCreateReq( 
        pptSortJobCreateReqResult&                           strSortJobCreateReqResult,
        const pptObjCommonIn&                                strObjCommonIn,
        const pptSorterComponentJobListAttributesSequence&   strSorterComponentJobListAttributesSequence,
        const objectIdentifier&                              equipmentID,
        const char *                                         portGroupID,
        CORBA::Boolean                                       waferIDReadFlag,
        const char *                                         claimMemo
        CORBAENV_LAST_CPP )
//D9000098 add start
#ifndef PPT_OPTIONS
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::txSortJobCreateReq");
    CORBA::Long rc = RC_OK ;

    PPT_METHODTRACE_V1("", "This function is currently disabled.")
    SET_MSG_RC(strSortJobCreateReqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txSortJobCreateReq") ;
    return( rc );
}
#else
//D9000098 add end
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::txSortJobCreateReq");
    CORBA::Long  rc = RC_OK;

    PPT_METHODTRACE_V2("", "in para userID          ", strObjCommonIn.strUser.userID.identifier   );
    PPT_METHODTRACE_V2("", "in para reportTimeStamp ", strObjCommonIn.strTimeStamp.reportTimeStamp);
    PPT_METHODTRACE_V2("", "in para equipmentID     ", equipmentID.identifier                     );
    PPT_METHODTRACE_V2("", "in para portGroupID     ", portGroupID                                );
    PPT_METHODTRACE_V2("", "in para waferIDReadFlag ", ((waferIDReadFlag ==TRUE)?"TRUE":"FALSE" ) );

    //------------------------------------------------------------------
    //                                                                  
    //  Object Lock                                                     
    //                                                                  
    //------------------------------------------------------------------
//DSN000049350 Add Start
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;

    CORBA::Long sorterJobLockFlag = atoi( getenv(SP_SORTERJOB_LOCK_FLAG) );
    PPT_METHODTRACE_V2("","sorterJobLockFlag", sorterJobLockFlag);
    CORBA::Long lockMode = SP_EQP_LOCK_MODE_WRITE;

    if ( 1 == sorterJobLockFlag )
    {
        PPT_METHODTRACE_V1("","sorterJobLockFlag = 1");

        // Get required equipment lock mode
        strObject_lockMode_Get_in.objectID           = equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( SP_FunctionCategory_SorterTxID ); // SorterTxID
        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strSortJobCreateReqResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }
        lockMode = strObject_lockMode_Get_out.lockMode;
    }
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );

    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;

    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strSortJobCreateReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
        //--------------------------------------------------------
        //  Object Lock for Equipment                             
        //--------------------------------------------------------
        PPT_METHODTRACE_V2("", "object_Lock EqpID ",equipmentID.identifier );
//DSN000049350        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, equipmentID, SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK  object_Lock failed. EqpID ",equipmentID.identifier );
            strSortJobCreateReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    } //DSN000049350

    //-------------------------------------------------------------------
    // Call equipment_portInfo_Get
    //-------------------------------------------------------------------
    objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
    rc = equipment_portInfo_Get(strEquipment_portInfo_Get_out, strObjCommonIn, equipmentID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "equipment_portInfo_Get() rc != RC_OK");
        strSortJobCreateReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
        return rc;
    }

    CORBA::Long portLen = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
    CORBA::Long portCnt = 0;
    for (portCnt = 0; portCnt < portLen; portCnt++)
    {
        PPT_METHODTRACE_V3("", "Loop (PortLength)", portCnt+1, portLen);
        PPT_METHODTRACE_V2("", "portGroup        ", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portGroup);
        if ( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portGroup, portGroupID))
        {
            objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
            rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out, strObjCommonIn, equipmentID,
                                                  strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID,
                                                  SP_ClassName_PosPortResource);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK  object_Lock failed. PortID ",
                                       strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID.identifier );
                strSortJobCreateReqResult.strResult = strObject_LockForEquipmentResource_out.strResult;
                return ( rc );
            }
        }
    }
    
    //INN-R170017 add start
    //--------------------------------------------------------
    //   Check if Eqp specialControl is BWS
    //--------------------------------------------------------   
    CORBA::Boolean bBWSFlag = FALSE;
    CORBA::String_var BWS_memo;

    PPT_METHODTRACE_V1( "", "##----- call txEqpInfoInq__160() -----##" );
        
    pptEqpInfoInqResult__160 strEqpInfoInqResult;
    rc = txEqpInfoInq__160( strEqpInfoInqResult,
                            strObjCommonIn,
                            equipmentID,
                            TRUE,       //requestFlagForBRInfo
                            FALSE,      //requestFlagForStatusInfo
                            FALSE,      //requestFlagForPMInfo
                            FALSE,      //requestFlagForPortInfo
                            FALSE,      //requestFlagForChamberInfo
                            FALSE,      //requestFlagForStockerInfo
                            FALSE,      //requestFlagForInprocessingLotInfo
                            FALSE,      //requestFlagForReservedControlJobInfo
                            FALSE,      //requestFlagForRSPortInfo
                            FALSE );    //requestFlagForEqpContainerInfo
    if( rc != RC_OK ) 
    {
        PPT_METHODTRACE_V2( "", "txEqpInfoInq__160() != RC_OK, rc=", rc );
        strSortJobCreateReqResult.strResult = strEqpInfoInqResult.strResult;
        return(rc);
    }   
    
    // check specialControl
    CORBA::Long lnLenCtrl = strEqpInfoInqResult.equipmentBRInfo.specialControl.length();
    for( CORBA::Long ix=0; ix<lnLenCtrl; ix++ )
    {
        if( 0 == CIMFWStrCmp( CS_EQP_SpecialEquipmentControl_BareWaferStocker,
                              strEqpInfoInqResult.equipmentBRInfo.specialControl[ix] ) )
        {
            PPT_METHODTRACE_V2( "", "equipment specialControl", strEqpInfoInqResult.equipmentBRInfo.specialControl[ix] );
            bBWSFlag = TRUE;
            BWS_memo = CIMFWStrDup( "The equipmentID has specialControl [Bare Wafter Stocker]. " );
            break;
        }
    }
    PPT_METHODTRACE_V2( "", "(Eqp specialControl) bBWSFlag = ", (bBWSFlag ? "TRUE":"FALSE") );

    //--------------------------------------------------------
    //   Check if equipmentID is defined in CSFSBWSCFG/CSFSBWSCFG_ZONE (BWS Config data)
    //--------------------------------------------------------    
    if( bBWSFlag == FALSE )
    {
        csObjBWS_Config_GetDR_in strBWS_Config_GetDR_in;
        strBWS_Config_GetDR_in.BWSID  = equipmentID;
        strBWS_Config_GetDR_in.zoneID = CIMFWStrDup("");
        
        csObjBWS_Config_GetDR_out strBWS_Config_GetDR_out;
        rc = cs_BWS_Config_GetDR( strBWS_Config_GetDR_out,
                                  strObjCommonIn,
                                  strBWS_Config_GetDR_in );
                                  
        if( rc != RC_OK && rc != CS_RC_BWS_CONFIG_NOT_FOUND_BWS )
        {
            PPT_METHODTRACE_V2( "", "cs_BWS_Config_GetDR() != RC_OK, rc=", rc );
            strSortJobCreateReqResult.strResult = strBWS_Config_GetDR_out.strResult;
            return(rc);
        }
        
        if( 0 <  strBWS_Config_GetDR_out.strBWSConfigInfoSeq.length() &&
            0 == CIMFWStrCmp( equipmentID.identifier, strBWS_Config_GetDR_out.strBWSConfigInfoSeq[0].BWSID.identifier ) )
        {
            bBWSFlag = TRUE;
            BWS_memo = CIMFWStrDup( "The equipmentID is defined in [BWS Configuration]. " );
        }
    }
    PPT_METHODTRACE_V2( "", "(Is in BWS Inventory uploaded data ? ) bBWSFlag = ", (bBWSFlag ? "TRUE":"FALSE") );
        
    //--------------------------------------------------------
    //   Check if equipmentID is defined in CSFSBWS/CSFSBWS_ZONE (BWS Inventory uploaded data)
    //--------------------------------------------------------    
    if( bBWSFlag == FALSE )
    {
        csObjBWS_WaferCount_GetDR_in strBWS_WaferCount_GetDR_in;
        strBWS_WaferCount_GetDR_in.BWSID  = equipmentID;
        strBWS_WaferCount_GetDR_in.zoneID = CIMFWStrDup("");
        
        csObjBWS_WaferCount_GetDR_out strBWS_WaferCount_GetDR_out;
        rc = cs_BWS_WaferCount_GetDR( strBWS_WaferCount_GetDR_out,
                                      strObjCommonIn,
                                      strBWS_WaferCount_GetDR_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "txEqpInfoInq__160() != RC_OK, rc=", rc );
            strSortJobCreateReqResult.strResult = strEqpInfoInqResult.strResult;
            return(rc);
        }
        
        if( 0 == CIMFWStrCmp( equipmentID.identifier, strBWS_WaferCount_GetDR_out.strBWSWaferCount.BWSID.identifier ) )
        {
            bBWSFlag = TRUE;
            BWS_memo = CIMFWStrDup( "The equipmentID has data in [BWS Information List]. " );
        }
    }
    PPT_METHODTRACE_V2( "", "(Is in BWS Config data ? ) bBWSFlag = ", (bBWSFlag ? "TRUE":"FALSE") );

    //--------------------------------------------------------
    // Get ActionJob for BWS
    //--------------------------------------------------------
    CORBA::Boolean bBWSInFlag       = FALSE;
    CORBA::Boolean bBWSOutFlag      = FALSE;
    CORBA::Boolean bOtherActionFlag = FALSE;
    
    if( bBWSFlag == TRUE )
    {
        PPT_METHODTRACE_V1( "", "bBWSFlag is TRUE ==> The Eqp is for BWS only !!!" );
        
        CORBA::Long lnAttr = strSorterComponentJobListAttributesSequence.length();
        for( CORBA::Long ix=0; ix<lnAttr; ix++ )
        {
            CORBA::Long lnLenSlotMap = strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence.length();
            for( CORBA::Long jx=0; jx<lnLenSlotMap; jx++ )
            {
                if( 0 == CIMFWStrCmp( CS_WaferTransfer_BWSIn, strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].actionCode ) )
                {
                    PPT_METHODTRACE_V1( "", "Found actionCode = BWSIn !!!" );
                    bBWSInFlag = TRUE;
                }                
                else if( 0 == CIMFWStrCmp( CS_WaferTransfer_BWSOut, strSorterComponentJobListAttributesSequence[ix].strWaferSorterSlotMapSequence[jx].actionCode ) )
                {
                    PPT_METHODTRACE_V1( "", "Found actionCode = BWSOut !!!" );
                    bBWSOutFlag = TRUE;
                }
                else
                {
                    bOtherActionFlag = TRUE;
                }
            }
        }
    }
    PPT_METHODTRACE_V2( "", "bBWSInFlag       = ", (bBWSInFlag ? "TRUE":"FALSE") );
    PPT_METHODTRACE_V2( "", "bBWSOutFlag      = ", (bBWSOutFlag ? "TRUE":"FALSE") );    
    PPT_METHODTRACE_V2( "", "bOtherActionFlag = ", (bOtherActionFlag ? "TRUE":"FALSE") );    
    
    // check ActionCode ==> for BWS eqp, only BWSIn or BWSOut is allowed
    if( bBWSFlag == TRUE )
    {
        if( bOtherActionFlag == TRUE )
        {
            PPT_METHODTRACE_V1( "", "For BWS : SorterAction should be BWSIn or BWSOut. " );
            
            CS_PPT_SET_MSG_RC_KEY1( strSortJobCreateReqResult,
                                    CS_MSG_BWS_NOT_ALLOWED_SORTER_ACTION,
                                    CS_RC_BWS_NOT_ALLOWED_SORTER_ACTION,
                                    equipmentID.identifier );
                                
            return( CS_RC_BWS_NOT_ALLOWED_SORTER_ACTION );
        }
        
        if( ( bBWSInFlag == TRUE && bBWSOutFlag == TRUE ) || ( bBWSInFlag == FALSE && bBWSOutFlag == FALSE ) )
        {
            PPT_METHODTRACE_V1( "", "For BWS : SorterAction (BWSIn or BWSOut) should be consistency" );
            
            CS_PPT_SET_MSG_RC_KEY1( strSortJobCreateReqResult,
                                    CS_MSG_BWS_NOT_ALLOWED_SORTER_ACTION_INCONSISTENCY,
                                    CS_RC_BWS_NOT_ALLOWED_SORTER_ACTION_INCONSISTENCY,
                                    equipmentID.identifier );
                                
            return ( CS_RC_BWS_NOT_ALLOWED_SORTER_ACTION_INCONSISTENCY );
        }
    }
    //INN-R170017 add end

    //--------------------------------------------------------
    //  Object Lock for Cassette                              
    //--------------------------------------------------------
    objectIdentifierSequence sortCassetteIDs;
    CORBA::Long castCnt                = 0;
    CORBA::Long castCntAll             = 0;
    CORBA::Long sortCompoJobLen        = strSorterComponentJobListAttributesSequence.length();
    CORBA::Boolean origCastCheckedFlag = FALSE;
    CORBA::Boolean destCastCheckedFlag = FALSE;
    CORBA::Long srtCompCnt    = 0;

    CORBA::ULong EXPAND_RECORDLEN = 50;
    CORBA::ULong tempCnt          = EXPAND_RECORDLEN;
    sortCassetteIDs.length(tempCnt);

//INN-R170002 Add Start
    objectIdentifierSequence moveToCassetteIDSeq;
    objectIdentifierSequence lotIDs;
    CORBA::Long lenDesCasIDSeq   = 0;
    CORBA::Long lenLotIDSeq      = 0;
    CORBA::Long i_cas            = 0;
    CORBA::Long j_lot            = 0;
    CORBA::Boolean bCassetteFind = FALSE;
    CORBA::Boolean bLotFind      = FALSE;
    moveToCassetteIDSeq.length(0);
    lotIDs.length(0);
//INN_R170002 Add End

    PPT_METHODTRACE_V2("", "SorterComponentJob length =", sortCompoJobLen);

    for( srtCompCnt = 0; srtCompCnt < sortCompoJobLen; srtCompCnt++ )
    {
        origCastCheckedFlag = FALSE;
        destCastCheckedFlag = FALSE;

        for( castCnt = 0; castCnt < castCntAll; castCnt++ )
        {
            //INN-R170017 add start
            if( bBWSInFlag == TRUE )
            {   
                if( CIMFWStrCmp( strSorterComponentJobListAttributesSequence[srtCompCnt].originalCarrierID.identifier, sortCassetteIDs[castCnt].identifier ) == 0 )
                {
                    PPT_METHODTRACE_V2("", "original cassette is already checked. cassetteID =", strSorterComponentJobListAttributesSequence[srtCompCnt].originalCarrierID.identifier);
                    origCastCheckedFlag = TRUE;
                }
                
                PPT_METHODTRACE_V2("", "for BWSIn : destination cassette is NO need to check. cassetteID(zoneID) =", strSorterComponentJobListAttributesSequence[srtCompCnt].destinationCarrierID.identifier);
                destCastCheckedFlag = TRUE;               
            }
            else if( bBWSOutFlag == TRUE )
            {
                PPT_METHODTRACE_V2("", "for BWSOut : original cassette is NO need to check. cassetteID(zoneID) =", strSorterComponentJobListAttributesSequence[srtCompCnt].originalCarrierID.identifier);
                origCastCheckedFlag = TRUE;
                
                if( CIMFWStrCmp( strSorterComponentJobListAttributesSequence[srtCompCnt].destinationCarrierID.identifier, sortCassetteIDs[castCnt].identifier ) == 0 )
                {
                    PPT_METHODTRACE_V2("", "destination cassette is already checked. cassetteID =", strSorterComponentJobListAttributesSequence[srtCompCnt].destinationCarrierID.identifier);
                    destCastCheckedFlag = TRUE;
                }   
            }
            else
            {
            //INN-R170017 add end
            if( CIMFWStrCmp( strSorterComponentJobListAttributesSequence[srtCompCnt].originalCarrierID.identifier, sortCassetteIDs[castCnt].identifier ) == 0 )
            {
                PPT_METHODTRACE_V2("", "original cassette is already checked. cassetteID =", strSorterComponentJobListAttributesSequence[srtCompCnt].originalCarrierID.identifier);
                origCastCheckedFlag = TRUE;
            }

            if( CIMFWStrCmp( strSorterComponentJobListAttributesSequence[srtCompCnt].destinationCarrierID.identifier, sortCassetteIDs[castCnt].identifier ) == 0 )
            {
                PPT_METHODTRACE_V2("", "destination cassette is already checked. cassetteID =", strSorterComponentJobListAttributesSequence[srtCompCnt].destinationCarrierID.identifier);
                destCastCheckedFlag = TRUE;
            }
            }//INN-R170017
        }
        
        PPT_METHODTRACE_V2( "", "##--- origCastCheckedFlag = ", (origCastCheckedFlag?"True":"Flase") ) //INN-R170017
        PPT_METHODTRACE_V2( "", "##--- destCastCheckedFlag = ", (destCastCheckedFlag?"True":"Flase") ) //INN-R170017

        if( origCastCheckedFlag == FALSE )
        {
            PPT_METHODTRACE_V3("", "check originalCassetteID for object_lock target, cassetteID =", srtCompCnt, strSorterComponentJobListAttributesSequence[srtCompCnt].originalCarrierID.identifier);

            if (castCntAll >= tempCnt)
            {
                PPT_METHODTRACE_V3("", "#### castCntAll >= tempCnt", castCntAll, tempCnt);
                tempCnt += EXPAND_RECORDLEN;
                sortCassetteIDs.length(tempCnt);
            }
            sortCassetteIDs[castCntAll] = strSorterComponentJobListAttributesSequence[srtCompCnt].originalCarrierID;
            castCntAll++;
        }

        if( destCastCheckedFlag == FALSE )
        {
            PPT_METHODTRACE_V3("", "check destinationCassetteID for object_lock target, cassetteID =", srtCompCnt, strSorterComponentJobListAttributesSequence[srtCompCnt].destinationCarrierID.identifier);

            if (castCntAll >= tempCnt)
            {
                PPT_METHODTRACE_V3("", "#### castCntAll >= tempCnt", castCntAll, tempCnt);
                tempCnt += EXPAND_RECORDLEN;
                sortCassetteIDs.length(tempCnt);
            }
            sortCassetteIDs[castCntAll] = strSorterComponentJobListAttributesSequence[srtCompCnt].destinationCarrierID;
            castCntAll++;
        }

        //INN-R170017 add start
        // display
        if( castCntAll > 0 )
        {
            PPT_METHODTRACE_V2( "", "##--- sortCassetteIDs = ", sortCassetteIDs[castCntAll-1].identifier );
        }
        //INN-R170017 add end

//INN-R170002 Add Start
        //---------------------------------------
        // Collect CassetteID of MoveToCassette
        //---------------------------------------
        if( 0 <  CIMFWStrLen(strSorterComponentJobListAttributesSequence[srtCompCnt].originalCarrierID.identifier)
         && 0 <  CIMFWStrLen(strSorterComponentJobListAttributesSequence[srtCompCnt].destinationCarrierID.identifier)
         && 0 != CIMFWStrCmp(strSorterComponentJobListAttributesSequence[srtCompCnt].originalCarrierID.identifier, strSorterComponentJobListAttributesSequence[srtCompCnt].destinationCarrierID.identifier) )
        {
            bCassetteFind = FALSE;

            lenDesCasIDSeq = moveToCassetteIDSeq.length();
            PPT_METHODTRACE_V2("", "lenDesCasIDSeq-->", lenDesCasIDSeq);

            for ( i_cas = 0; i_cas < lenDesCasIDSeq; i_cas++ )
            {
                if ( 0 == CIMFWStrCmp(strSorterComponentJobListAttributesSequence[srtCompCnt].destinationCarrierID.identifier, moveToCassetteIDSeq[i_cas].identifier) )
                {
                    PPT_METHODTRACE_V2("", "set bCassetteFind = TRUE", i_cas);
                    bCassetteFind = TRUE;
                    break;
                }
            }
            
            //INN-R170017 add start
            // for BWSIn : no need to check destCast(zone)
            if( bBWSInFlag == TRUE )
            {
                bCassetteFind = TRUE;
                PPT_METHODTRACE_V1( "", "##--- BWSIn is TRUE ==> NOT collect dest. cassett for moveToCassetteIDSeq, set bCassetteFind = TRUE. ");
            }
            //INN-R170017 add end
            
            if ( bCassetteFind == FALSE )
            {
                PPT_METHODTRACE_V1("", "bCassetteFind == FALSE");
                lenDesCasIDSeq++;
                moveToCassetteIDSeq.length(lenDesCasIDSeq);
                moveToCassetteIDSeq[lenDesCasIDSeq-1] = strSorterComponentJobListAttributesSequence[srtCompCnt].destinationCarrierID;
            }
        }
//INN-R170002 Add End
    }
    sortCassetteIDs.length(castCntAll); 

    PPT_METHODTRACE_V2("", "object_lock target cassetteID length =", castCntAll);

    for( castCnt = 0; castCnt < castCntAll; castCnt++ )
    {
        PPT_METHODTRACE_V2("", "object_lock for cassette.", sortCassetteIDs[castCnt].identifier);
//DSN000049350        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, sortCassetteIDs[castCnt], SP_ClassName_PosCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK  object_Lock failed. CarrierID ",sortCassetteIDs[castCnt].identifier );
            strSortJobCreateReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    }

    //--------------------------------------------------------
    //  Object Lock for Lot                                   
    //--------------------------------------------------------
    objectIdentifierSequence sortLotIDs;
    CORBA::Long lotCnt                = 0;
    CORBA::Long lotCntAll             = 0;
    CORBA::Boolean lotCheckedFlag = FALSE;

    tempCnt          = EXPAND_RECORDLEN;
    sortLotIDs.length(tempCnt);

    PPT_METHODTRACE_V2("", "SorterComponentJob length =", sortCompoJobLen);

    for( srtCompCnt = 0; srtCompCnt < sortCompoJobLen; srtCompCnt++ )
    {
        CORBA::Long slotMapLen  = strSorterComponentJobListAttributesSequence[srtCompCnt].strWaferSorterSlotMapSequence.length();
        CORBA::Long slotMapCnt  = 0;
        PPT_METHODTRACE_V2("", "Slot Map  length =", slotMapLen );

        for( slotMapCnt=0; slotMapCnt<slotMapLen; slotMapCnt++)
        {
            lotCheckedFlag = FALSE;
            for( lotCnt = 0; lotCnt < lotCntAll; lotCnt++ )
            {
                if( 0 == CIMFWStrCmp( strSorterComponentJobListAttributesSequence[srtCompCnt].strWaferSorterSlotMapSequence[slotMapCnt].lotID.identifier, sortLotIDs[lotCnt].identifier ))
                {
                    PPT_METHODTRACE_V2("", "lotID is already checked. lotID =", strSorterComponentJobListAttributesSequence[srtCompCnt].strWaferSorterSlotMapSequence[slotMapCnt].lotID.identifier);
                    lotCheckedFlag = TRUE;
                    break;
                }
            }

            if( lotCheckedFlag == FALSE )
            {
                PPT_METHODTRACE_V3("", "check lotID for object_lock target, lotID =", slotMapCnt, strSorterComponentJobListAttributesSequence[srtCompCnt].strWaferSorterSlotMapSequence[slotMapCnt].lotID.identifier);
                if (lotCntAll >= tempCnt)
                {
                    PPT_METHODTRACE_V3("", "#### lotCntAll >= tempCnt", lotCntAll, tempCnt);
                    tempCnt += EXPAND_RECORDLEN;
                    sortLotIDs.length(tempCnt);
                }
                sortLotIDs[lotCntAll] = strSorterComponentJobListAttributesSequence[srtCompCnt].strWaferSorterSlotMapSequence[slotMapCnt].lotID;
                lotCntAll++;
            }
        }//loop of Slot Map 
    }//loop of Component Job Attributes
    sortLotIDs.length(lotCntAll); 

    PPT_METHODTRACE_V2("", "object_lock target lotID length =", lotCntAll);

    for( lotCnt = 0; lotCnt < lotCntAll; lotCnt++ )
    {
        PPT_METHODTRACE_V2("", "object_lock for Lot.", sortLotIDs[lotCnt].identifier);
//DSN000049350        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, sortLotIDs[lotCnt], SP_ClassName_PosLot );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK  object_Lock failed. lotID ",sortLotIDs[lotCnt].identifier );
            strSortJobCreateReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    }

    //------------------------------------------------------------------
    //                                                                  
    //  Check the validity of Sorter Job Information.                   
    //                                                                  
    //------------------------------------------------------------------

    if (strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length() == 0)
    {
        PPT_METHODTRACE_V1("", "eqpPortStatus.length() == 0.");
        PPT_SET_MSG_RC_KEY( strSortJobCreateReqResult, MSG_NOT_FOUND_PORT, RC_NOT_FOUND_PORT, portGroupID );
        return ( RC_NOT_FOUND_PORT );
    }

    CORBA::Boolean bArrivalCallFlag = FALSE;
    CORBA::String_var operationMode;
    portLen = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
    for (portCnt = 0; portCnt < portLen; portCnt++)
    {
        PPT_METHODTRACE_V3("", "Loop (PortLength)", portCnt+1, portLen);
        PPT_METHODTRACE_V2("", "portGroup        ", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portGroup);

        if ( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portGroup, portGroupID))
        {
            //------------------------------------------------------------------
            // Check Port Operation Mode
            //------------------------------------------------------------------
            PPT_METHODTRACE_V2("", "operationModeID ", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].operationModeID.identifier );
            if ( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].operationModeID.identifier, SP_Eqp_Port_OperationMode_Auto_1 ))
            {
                PPT_METHODTRACE_V1("", "operationModeID is Auto-1...Call txArrivalCarrierNotificationReq");
                bArrivalCallFlag = TRUE;
                operationMode = CIMFWStrDup(SP_Eqp_Port_OperationMode_Auto_1);
                break;
            }
            else if ( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].operationModeID.identifier, SP_Eqp_Port_OperationMode_Auto_2 ))
            {
                operationMode = CIMFWStrDup(SP_Eqp_Port_OperationMode_Auto_2);
            }
        }
    }

    //------------------------------------------------------------------
    // Call sorter_CheckConditionForJobCreate
    //------------------------------------------------------------------
    PPT_METHODTRACE_V1("", "### Check Process for Sorter Job Create.");
    // typedef struct objSorter_CheckConditionForJobCreate_in_struct{
    //     pptSorterComponetJobListAttributesSequence   strSorterComponetJobListAttributesSequence;
    //     objectIdentifier                             equipmentID;
    //     string                                       portGroupID;
    //     any                                          siInfo;
    // }objSorter_CheckConditionForJobCreate_in;
    
    //INN-R170017 add start
    if( bBWSInFlag == TRUE || bBWSOutFlag == TRUE )
    {
        csObjBWSSorter_CheckConditionForJobCreate_in strBWSSorter_CheckConditionForJobCreate_in;
        strBWSSorter_CheckConditionForJobCreate_in.strSorterComponentJobListAttributesSequence = strSorterComponentJobListAttributesSequence;
        strBWSSorter_CheckConditionForJobCreate_in.equipmentID                                 = equipmentID;
        strBWSSorter_CheckConditionForJobCreate_in.portGroupID                                 = CIMFWStrDup(portGroupID); 
               
        csObjBWSSorter_CheckConditionForJobCreate_out strBWSSorter_CheckConditionForJobCreate_out;
        rc = cs_BWS_sorter_CheckConditionForJobCreate( strBWSSorter_CheckConditionForJobCreate_out,
                                                       strObjCommonIn,
                                                       strBWSSorter_CheckConditionForJobCreate_in );
                                                       
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "cs_BWS_sorter_CheckConditionForJobCreate() != RC_OK, rc=", rc );
            strSortJobCreateReqResult.strResult = strBWSSorter_CheckConditionForJobCreate_out.strResult;
            return rc;
        }                                           
    }
    else
    {
    //INN-R170017 add end    
    objSorter_CheckConditionForJobCreate_out strSorter_CheckConditionForJobCreate_out;
    objSorter_CheckConditionForJobCreate_in  strSorter_CheckConditionForJobCreate_in;
    strSorter_CheckConditionForJobCreate_in.strSorterComponentJobListAttributesSequence = strSorterComponentJobListAttributesSequence;
    strSorter_CheckConditionForJobCreate_in.equipmentID                                 = equipmentID;
    strSorter_CheckConditionForJobCreate_in.portGroupID                                 = CIMFWStrDup(portGroupID);

    rc = sorter_CheckConditionForJobCreate( strSorter_CheckConditionForJobCreate_out, strObjCommonIn, strSorter_CheckConditionForJobCreate_in );
    
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "sorter_CheckConditionForJobCreate() rc != RC_OK");
        strSortJobCreateReqResult.strResult = strSorter_CheckConditionForJobCreate_out.strResult;
        return rc;
    }
    }//INN-R170017

    //------------------------------------------------------------------
    //                                                                  
    //  Create Sorter Job Information                                   
    //                                                                  
    //------------------------------------------------------------------
    // typedef struct objSorter_sorterJobCreate_in_struct {
    //     pptSortJobListAttributes   strSortJobListAttributes; 
    //     objectIdentifier           equipmentID;
    //     string                     portGroupID;
    //     boolean                    waferIDReadFlag;
    //     string                     operationMode;
    //     any                        siInfo;
    // }objSorter_sorterJobCreate_in;

//R170002 Add Start
    //------------------------------------------------
    // Check Lot Contamination for Wafer Sorter
    //------------------------------------------------
    for ( i_cas = 0; i_cas < lenDesCasIDSeq; i_cas++ )
    {
        lenLotIDSeq = 0;
        for( srtCompCnt = 0; srtCompCnt < sortCompoJobLen; srtCompCnt++ )
        {
            CORBA::Long slotMapLen  = strSorterComponentJobListAttributesSequence[srtCompCnt].strWaferSorterSlotMapSequence.length();
            CORBA::Long slotMapCnt  = 0;
            PPT_METHODTRACE_V2("", "Slot Map  length =", slotMapLen );

            for( slotMapCnt=0; slotMapCnt<slotMapLen; slotMapCnt++)
            {
                if( 0 <  CIMFWStrLen(strSorterComponentJobListAttributesSequence[srtCompCnt].originalCarrierID.identifier)
                 && 0 <  CIMFWStrLen(strSorterComponentJobListAttributesSequence[srtCompCnt].destinationCarrierID.identifier)
                 && 0 != CIMFWStrCmp(strSorterComponentJobListAttributesSequence[srtCompCnt].originalCarrierID.identifier, strSorterComponentJobListAttributesSequence[srtCompCnt].destinationCarrierID.identifier) )
                {
                    if( 0 == CIMFWStrCmp(moveToCassetteIDSeq[i_cas].identifier, strSorterComponentJobListAttributesSequence[srtCompCnt].strWaferSorterSlotMapSequence[slotMapCnt].destinationCassetteID.identifier) )
                    {
                        bLotFind = FALSE;

                        lenLotIDSeq = lotIDs.length();
                        PPT_METHODTRACE_V2("", "lenDesCasIDSeq-->", lenDesCasIDSeq);

                        for ( j_lot = 0; j_lot < lenLotIDSeq; j_lot++ )
                        {
                            if ( 0 == CIMFWStrCmp(strSorterComponentJobListAttributesSequence[srtCompCnt].strWaferSorterSlotMapSequence[slotMapCnt].lotID.identifier, lotIDs[j_lot].identifier) )
                            {
                                PPT_METHODTRACE_V2("", "set bLotFind = TRUE", j_lot);
                                bLotFind = TRUE;
                                break;
                            }
                        }
                        if ( bLotFind == FALSE )
                        {
                            PPT_METHODTRACE_V1("", "bLotFind == FALSE");
                            lenLotIDSeq++;
                            lotIDs.length(lenLotIDSeq);
                            lotIDs[lenLotIDSeq-1] = strSorterComponentJobListAttributesSequence[srtCompCnt].strWaferSorterSlotMapSequence[slotMapCnt].lotID;
                        }
                    }
                }
            }
        }

        csObjLot_ContaminationInfo_CheckForCarrierExchange_out strLot_ContaminationInfo_CheckForCarrierExchange_out; 
        csObjLot_ContaminationInfo_CheckForCarrierExchange_in  strLot_ContaminationInfo_CheckForCarrierExchange_in;
        strLot_ContaminationInfo_CheckForCarrierExchange_in.carrierID = moveToCassetteIDSeq[i_cas];
        strLot_ContaminationInfo_CheckForCarrierExchange_in.lotIDs    = lotIDs;
        rc = cs_lot_ContaminationInfo_CheckForCarrierExchange(strLot_ContaminationInfo_CheckForCarrierExchange_out,
                                                              strObjCommonIn,
                                                              strLot_ContaminationInfo_CheckForCarrierExchange_in);
        if(rc!= RC_OK)
        {
            PPT_METHODTRACE_V2("", "cs_lot_ContaminationInfo_CheckForCarrierExchange() != RC_OK", moveToCassetteIDSeq[i_cas].identifier);
            strSortJobCreateReqResult.strResult = strLot_ContaminationInfo_CheckForCarrierExchange_out.strResult;
            return( rc );
        }
    }
//R170002 Add End

    PPT_METHODTRACE_V1("", "### Create Soter Job Information.");

    objSorter_sorterJobCreate_out  strSorter_sorterJobCreate_out;
    objSorter_sorterJobCreate_in   strSorter_sorterJobCreate_in;
    strSorter_sorterJobCreate_in.strSorterComponentJobListAttributesSeq  = strSorterComponentJobListAttributesSequence;
    strSorter_sorterJobCreate_in.equipmentID               = equipmentID;
    strSorter_sorterJobCreate_in.portGroupID               = CIMFWStrDup( portGroupID );
    strSorter_sorterJobCreate_in.waferIDReadFlag           = waferIDReadFlag;
    strSorter_sorterJobCreate_in.operationMode             = CIMFWStrDup( operationMode );

    rc = sorter_sorterJobCreate(strSorter_sorterJobCreate_out, strObjCommonIn, strSorter_sorterJobCreate_in);

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "sorter_sorterJobCreate() rc != RC_OK");
        strSortJobCreateReqResult.strResult = strSorter_sorterJobCreate_out.strResult;
        return rc;
    }

    //------------------------------------------------------------------
    //                                                                  
    //  Notify Sorter Job ID to TCS.                                    
    //    if operation Mode is Auto-1, call TCSMgr_SendSortJobNotificationReq
    //                                                                  
    //------------------------------------------------------------------
    //typedef struct objTCSMgr_SendSortJobNotificationReq_in_struct{
    //    pptUser              requestUserID;
    //    objectIdentifier     equipmentID;
    //    objectIdentifier     sorterJobID;
    //    string               portGroupID;
    //    string               claimMemo;
    //    any                  siInfo;
    //}objTCSMgr_SendSortJobNotificationReq_in;
    //PSN000078594 PPT_METHODTRACE_V1("", "### Notify Sort Job to TCS.");
    //PSN000078594 
    //PSN000078594 objTCSMgr_SendSortJobNotificationReq_out strTCSMgr_SendSortJobNotificationReq_out;
    //PSN000078594 objTCSMgr_SendSortJobNotificationReq_in  strTCSMgr_SendSortJobNotificationReq_in;
    //PSN000078594 strTCSMgr_SendSortJobNotificationReq_in.requestUserID = strObjCommonIn.strUser;
    //PSN000078594 strTCSMgr_SendSortJobNotificationReq_in.equipmentID   = equipmentID;
    //PSN000078594 strTCSMgr_SendSortJobNotificationReq_in.sorterJobID   = strSorter_sorterJobCreate_out.strSortJobListAttributes.sorterJobID;
    //PSN000078594 strTCSMgr_SendSortJobNotificationReq_in.portGroupID   = CIMFWStrDup(portGroupID);
    //PSN000078594 strTCSMgr_SendSortJobNotificationReq_in.claimMemo     = CIMFWStrDup( claimMemo );
    //PSN000078594 
    //PSN000078594 rc = TCSMgr_SendSortJobNotificationReq( strTCSMgr_SendSortJobNotificationReq_out, strObjCommonIn, strTCSMgr_SendSortJobNotificationReq_in );
    //PSN000078594 add start
    CORBA::String_var tmpSleepTimeValue  = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
    CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));
    CORBA::Long sleepTimeValue = 0;
    CORBA::Long retryCountValue = 0;

    if (CIMFWStrLen(tmpSleepTimeValue) == 0)
    {
        sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
    }
    else
    {
        sleepTimeValue = atoi(tmpSleepTimeValue) ;
    }

    if (CIMFWStrLen(tmpRetryCountValue) == 0)
    {
        retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
    }
    else
    {
        retryCountValue = atoi(tmpRetryCountValue);
    }

    PPT_METHODTRACE_V2("","env value of SP_BIND_SLEEP_TIME_TCS  = ",sleepTimeValue);
    PPT_METHODTRACE_V2("","env value of SP_BIND_RETRY_COUNT_TCS = ",retryCountValue);

    PPT_METHODTRACE_V1("", "### Notify Sort Job to TCS.");

    objTCSMgr_SendSortJobNotificationReq_out strTCSMgr_SendSortJobNotificationReq_out;
    objTCSMgr_SendSortJobNotificationReq_in  strTCSMgr_SendSortJobNotificationReq_in;
    strTCSMgr_SendSortJobNotificationReq_in.requestUserID = strObjCommonIn.strUser;
    strTCSMgr_SendSortJobNotificationReq_in.equipmentID   = equipmentID;
    strTCSMgr_SendSortJobNotificationReq_in.sorterJobID   = strSorter_sorterJobCreate_out.strSortJobListAttributes.sorterJobID;
    strTCSMgr_SendSortJobNotificationReq_in.portGroupID   = CIMFWStrDup(portGroupID);
    strTCSMgr_SendSortJobNotificationReq_in.claimMemo     = CIMFWStrDup( claimMemo );

    //'retryCountValue + 1' means first try plus retry count
    for( CORBA::ULong retryNum = 0 ; retryNum < (retryCountValue + 1) ; retryNum++ )
    {
        /*--------------------------*/
        /*    Send Request to TCS   */
        /*--------------------------*/
        PPT_METHODTRACE_V1("", "call TCSMgr_SendSortJobNotificationReq()");
        rc = TCSMgr_SendSortJobNotificationReq( strTCSMgr_SendSortJobNotificationReq_out, strObjCommonIn, strTCSMgr_SendSortJobNotificationReq_in );

        PPT_METHODTRACE_V2("","rc = ",rc);

        if(rc == RC_OK)
        {
            PPT_METHODTRACE_V1("","Now TCS subSystem is alive!! Go ahead");
            break;
        }
        else if ( rc == RC_EXT_SERVER_BIND_FAIL ||
                  rc == RC_EXT_SERVER_NIL_OBJ   ||
                  rc == RC_TCS_NO_RESPONSE )
        {
            PPT_METHODTRACE_V2("","TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...",retryNum);
            PPT_METHODTRACE_V2("","now sleeping... ",sleepTimeValue);
            sleep(sleepTimeValue);
            continue;
        }
        else
        {
            PPT_METHODTRACE_V1("", "TCSMgr_SendSortJobNotificationReq() rc != RC_OK");
            strSortJobCreateReqResult.strResult = strTCSMgr_SendSortJobNotificationReq_out.strResult;
            return rc;
        }
    }
    //PSN000078594 add end

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "TCSMgr_SendSortJobNotificationReq() rc != RC_OK");
        strSortJobCreateReqResult.strResult = strTCSMgr_SendSortJobNotificationReq_out.strResult;
        return rc;
    }


    if( TRUE == bArrivalCallFlag )
    {
        //----------------------------------------------------------
        //  Case operation mode 'Auto-1'                            
        //----------------------------------------------------------
        pptStartCassette strStartCassette_Src;
        pptStartCassette strStartCassette_Dst;

        strStartCassette_Src.cassetteID   = strSorterComponentJobListAttributesSequence[0].originalCarrierID;
        strStartCassette_Src.loadPortID   = strSorterComponentJobListAttributesSequence[0].originalPortID;
        strStartCassette_Src.unloadPortID = strSorterComponentJobListAttributesSequence[0].originalPortID;
        PPT_METHODTRACE_V2("", "  src cassetteID   ", strStartCassette_Src.cassetteID.identifier);
        PPT_METHODTRACE_V2("", "  src loadPortID   ", strStartCassette_Src.loadPortID.identifier);
        PPT_METHODTRACE_V2("", "  src unloadPortID ", strStartCassette_Src.unloadPortID.identifier);

        strStartCassette_Dst.cassetteID   = strSorterComponentJobListAttributesSequence[0].destinationCarrierID;
        strStartCassette_Dst.loadPortID   = strSorterComponentJobListAttributesSequence[0].destinationPortID;
        strStartCassette_Dst.unloadPortID = strSorterComponentJobListAttributesSequence[0].destinationPortID;
        PPT_METHODTRACE_V2("", "  dest cassetteID   ", strStartCassette_Dst.cassetteID.identifier);
        PPT_METHODTRACE_V2("", "  dest loadPortID   ", strStartCassette_Dst.loadPortID.identifier);
        PPT_METHODTRACE_V2("", "  dest unloadPortID ", strStartCassette_Dst.unloadPortID.identifier);

        //Set Load Port Sequence Number.
        for(CORBA::Long nPortIndex = 0; nPortIndex < portLen; nPortIndex++)
        {
            PPT_METHODTRACE_V2("", "  Loop ", nPortIndex);
            if( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[nPortIndex].portGroup,         portGroupID)  &&
                0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[nPortIndex].portID.identifier, strStartCassette_Src.loadPortID.identifier))
            {
                strStartCassette_Src.loadSequenceNumber = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[nPortIndex].loadSequenceNumber;
                PPT_METHODTRACE_V2("", "  src loadSequenceNumber  ", strStartCassette_Src.loadSequenceNumber);
            }

            if( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[nPortIndex].portGroup,         portGroupID) &&
                0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[nPortIndex].portID.identifier, strStartCassette_Dst.loadPortID.identifier))
            {
                strStartCassette_Dst.loadSequenceNumber = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[nPortIndex].loadSequenceNumber;
                PPT_METHODTRACE_V2("", "  dest loadSequenceNumber ", strStartCassette_Dst.loadSequenceNumber);
            }
        }

        // Set Cassette to strStartCassette Sequence.
        pptStartCassetteSequence strStartCassetteSequence;

        //INN-R170017 add start
        if( bBWSInFlag == TRUE )
        {
            PPT_METHODTRACE_V1( "", "for BWSIn : set sourceCassettte only" );
            strStartCassetteSequence.length(1);
            strStartCassetteSequence[0] = strStartCassette_Src;
        }
        else if( bBWSOutFlag == TRUE )
        {
            PPT_METHODTRACE_V1( "", "for BWSIn : set destinationCassette only" );
            strStartCassetteSequence.length(1);
            strStartCassetteSequence[0] = strStartCassette_Dst;
        }
        else
        {
        //INN-R170017 add end
        if( 0 == CIMFWStrCmp(strStartCassette_Src.cassetteID.identifier,   strStartCassette_Dst.cassetteID.identifier) )
        {
            PPT_METHODTRACE_V1("", "sourceCassettte == destinationCassette");
            strStartCassetteSequence.length(1);
            strStartCassetteSequence[0] = strStartCassette_Src;
        }
        else
        {
            PPT_METHODTRACE_V1("", "sourceCassettte != destinationCassette");
            strStartCassetteSequence.length(2);
            strStartCassetteSequence[0] = strStartCassette_Src;
            strStartCassetteSequence[1] = strStartCassette_Dst;
        }
        } //INN-R170017

        CORBA::Long nCassetteLen = strStartCassetteSequence.length();
        for(CORBA::Long nCassetteCnt = 0; nCassetteCnt < nCassetteLen; nCassetteCnt++)
        {
//DSIV00000099             //----------------------------------
//DSIV00000099             // Call txCassetteStatusInq__090    
//DSIV00000099             //----------------------------------
//DSIV00000099             PPT_METHODTRACE_V1("", "Call txCassetteStatusInq__090");
//DSIV00000099             pptCassetteStatusInqResult__090  strCassetteStatusInqResult;
//DSIV00000099             rc = txCassetteStatusInq__090(strCassetteStatusInqResult, strObjCommonIn, strStartCassetteSequence[nCassetteCnt].cassetteID);
//DSIV00000099             if (rc != RC_OK)
//DSIV00000099             {
//DSIV00000099                 PPT_METHODTRACE_V1("", "txCassetteStatusInq__090() rc != RC_OK");
//DSIV00000099                 strSortJobCreateReqResult.strResult = strCassetteStatusInqResult.strResult;
//DSIV00000099                 return rc;
//DSIV00000099             }
//DSN000020767//DSIV00000099 Add Start
//DSN000020767            //----------------------------------
//DSN000020767            // Call txCassetteStatusInq__100    
//DSN000020767            //----------------------------------
//DSN000020767            PPT_METHODTRACE_V1("", "Call txCassetteStatusInq__100");
//DSN000020767            pptCassetteStatusInqResult__100  strCassetteStatusInqResult;
//DSN000020767            rc = txCassetteStatusInq__100(strCassetteStatusInqResult, strObjCommonIn, strStartCassetteSequence[nCassetteCnt].cassetteID);
//DSN000020767            if (rc != RC_OK)
//DSN000020767            {
//DSN000020767                PPT_METHODTRACE_V1("", "txCassetteStatusInq__100() rc != RC_OK");
//DSN000020767                strSortJobCreateReqResult.strResult = strCassetteStatusInqResult.strResult;
//DSN000020767                return rc;
//DSN000020767            }
//DSN000020767//DSIV00000099 Add End

//DSN000096126//DSN000020767 Add Start
//DSN000096126            //----------------------------------
//DSN000096126            // Call txCassetteStatusInq__120    
//DSN000096126            //----------------------------------
//DSN000096126            PPT_METHODTRACE_V1("", "Call txCassetteStatusInq__120");
//DSN000096126            pptCassetteStatusInqResult__120  strCassetteStatusInqResult;
//DSN000096126            rc = txCassetteStatusInq__120(strCassetteStatusInqResult, strObjCommonIn, strStartCassetteSequence[nCassetteCnt].cassetteID);
//DSN000096126            if (rc != RC_OK)
//DSN000096126            {
//DSN000096126                PPT_METHODTRACE_V1("", "txCassetteStatusInq__120() rc != RC_OK");
//DSN000096126                strSortJobCreateReqResult.strResult = strCassetteStatusInqResult.strResult;
//DSN000096126                return rc;
//DSN000096126            }
//DSN000096126//DSN000020767 Add End
//DSN000096126 Add Start
            //----------------------------------
            // Call txCassetteStatusInq__170    
            //----------------------------------
            PPT_METHODTRACE_V1("", "Call txCassetteStatusInq__170");
//DSN000101569            pptCassetteStatusInqResult__160 strCassetteStatusInqResult;
            pptCassetteStatusInqResult__170 strCassetteStatusInqResult;                                                         //DSN000101569
            CORBA::Boolean durableOperationInfoFlag    = FALSE;
            CORBA::Boolean durableWipOperationInfoFlag = FALSE;
//DSN000101569            rc = txCassetteStatusInq__160(strCassetteStatusInqResult, strObjCommonIn, strStartCassetteSequence[nCassetteCnt].cassetteID, durableOperationInfoFlag, durableWipOperationInfoFlag);
            rc = txCassetteStatusInq__170(strCassetteStatusInqResult, strObjCommonIn, strStartCassetteSequence[nCassetteCnt].cassetteID, durableOperationInfoFlag, durableWipOperationInfoFlag); //DSN000101569
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "txCassetteStatusInq__170() rc != RC_OK");
                strSortJobCreateReqResult.strResult = strCassetteStatusInqResult.strResult;
                return rc;
            }
//DSN000096126 Add End


            if( TRUE == strCassetteStatusInqResult.cassetteStatusInfo.emptyFlag )
            {
                PPT_METHODTRACE_V1("", "emptyFlag == TRUE");
                strStartCassetteSequence[nCassetteCnt].loadPurposeType = SP_LoadPurposeType_EmptyCassette;
            }
            else
            {
                PPT_METHODTRACE_V1("", "emptyFlag == FALSE");
                strStartCassetteSequence[nCassetteCnt].loadPurposeType = SP_LoadPurposeType_Other;
            }
        }

        objectIdentifier dummyControlJobID;
        //--------------------------------------
        // Call txArrivalCarrierNotificationReq 
        //--------------------------------------
        PPT_METHODTRACE_V1("", "Call txArrivalCarrierNotificationReq");
        pptArrivalCarrierNotificationReqResult strArrivalCarrierNotificationReqResult;
        rc = txArrivalCarrierNotificationReq(strArrivalCarrierNotificationReqResult, strObjCommonIn,
                                             equipmentID,  portGroupID,  dummyControlJobID, strStartCassetteSequence, claimMemo);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "txArrivalCarrierNotificationReq() rc != RC_OK");
            strSortJobCreateReqResult.strResult = strArrivalCarrierNotificationReqResult.strResult;
            return rc;
        }
    } //bArrivalCallFlag

    //------------------------------------------------------------------
    // Create Event                                                     
    //------------------------------------------------------------------
    //Sort Job Create 
    // typedef struct objSorter_sorterJobEvent_Make_in_struct{
    //     string                    transactoinID;
    //     string                    action;
    //     string                    transactionID;
    //     pptSortJobListAttributes  strSortJobListAttributes;
    //     string                    claimMemo;
    //     any                       siInfo;
    // }objSorter_sorterJobEvent_Make_in;

    PPT_METHODTRACE_V2("", "Call sorter_sorterJobEvent_Make", SP_Sorter_Job_Action_SortJobCreate);
    objSorter_sorterJobEvent_Make_out  strSorter_sorterJobEvent_Make_out;
    objSorter_sorterJobEvent_Make_in   strSorter_sorterJobEvent_Make_in;

    strSorter_sorterJobEvent_Make_in.transactionID             = CIMFWStrDup(strObjCommonIn.transactionID);
    strSorter_sorterJobEvent_Make_in.strSortJobListAttributes  = strSorter_sorterJobCreate_out.strSortJobListAttributes;
    strSorter_sorterJobEvent_Make_in.claimMemo                 = CIMFWStrDup(claimMemo);
    strSorter_sorterJobEvent_Make_in.action                    = CIMFWStrDup(SP_Sorter_Job_Action_SortJobCreate);

    rc = sorter_sorterJobEvent_Make( strSorter_sorterJobEvent_Make_out, strObjCommonIn, strSorter_sorterJobEvent_Make_in );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "sorter_sorterJobEvent_Make() rc != RC_OK");
        strSortJobCreateReqResult.strResult = strSorter_sorterJobEvent_Make_out.strResult;
        return rc;
    }

    if( 0 == CIMFWStrCmp( operationMode, SP_Eqp_Port_OperationMode_Auto_1 ) )
    {
        //Sort Job Start    
        PPT_METHODTRACE_V2("", "Call sorter_sorterJobEvent_Make", SP_Sorter_Job_Action_SortJobStart);
        strSorter_sorterJobEvent_Make_in.action  = CIMFWStrDup(SP_Sorter_Job_Action_SortJobStart);

        rc = sorter_sorterJobEvent_Make( strSorter_sorterJobEvent_Make_out, strObjCommonIn, strSorter_sorterJobEvent_Make_in );
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "sorter_sorterJobEvent_Make() rc != RC_OK");
            strSortJobCreateReqResult.strResult = strSorter_sorterJobEvent_Make_out.strResult;
            return rc;
        }

        //Component Job Xfer
        PPT_METHODTRACE_V2("", "Call sorter_sorterJobEvent_Make", SP_Sorter_Job_Action_ComponentJobStart);
        strSorter_sorterJobEvent_Make_in.action  = CIMFWStrDup(SP_Sorter_Job_Action_ComponentJobStart);

        rc = sorter_sorterJobEvent_Make( strSorter_sorterJobEvent_Make_out, strObjCommonIn, strSorter_sorterJobEvent_Make_in );
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "sorter_sorterJobEvent_Make() rc != RC_OK");
            strSortJobCreateReqResult.strResult = strSorter_sorterJobEvent_Make_out.strResult;
            return rc;
        }
    }
    // Set out parameter
    PPT_METHODTRACE_V2("", "Created sorter job ID is ", strSorter_sorterJobCreate_out.strSortJobListAttributes.sorterJobID.identifier );
    strSortJobCreateReqResult.sorterJobID = strSorter_sorterJobCreate_out.strSortJobListAttributes.sorterJobID;

    SET_MSG_RC( strSortJobCreateReqResult, MSG_OK, RC_OK );
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txSortJobCreateReq");
    return RC_OK;
}
//D9000098 add start
#endif
//D9000098 add end
