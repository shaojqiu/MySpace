#ifndef lint
static char *sccsid =  "@(#) 1.6 superpos/src/spppt/source/posppt/pptmgr/txmethods/txSortJobStartReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 12/3/07 16:49:17 [ 12/3/07 16:49:18 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: txSortJobStartReq.cpp
//

//INN-R17001 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp" //INN-R17001

// Class: PPTManager
//
// Service: txSortJobStartReq()
//
// Change history:
// Date       Defect#    Person         Comments
// ---------- ---------- -------------- -------------------------------------------
// 2007/06/13 D9000005   K.Kido         Wafer Sorter Function Development.
// 2007/09/20 D9000084   K.Kido         txEqpInfoInq ==> txEqpInfoInq__090
// 2007/09/20 D9000079   M.Murata       txEqpInfoInq ==> txEqpInfoInq__090 (Modified by D9000084)
// 2007/10/23 D9000098   M.Murata       Divided Library
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/03 DSIV00000099 M.Ogawa        txEqpInfoInq__090 ==> txEqpInfoInq__100
// 2010/05/06 DSIV00001830 K.Yamaoku      txEqpInfoInq__100 ==> txEqpInfoInq__101
// 2012/12/03 DSN000049350 K.Yamaoku      Equipment parallel processing support (P2)
// 2015/11/10 DSN000096126 C.Mo           txEqpInfoInq__101 ==> txEqpInfoInq__160
//
// 
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/31 INN-R170017  Evie Su        Add BWSIn/BWSOut logic
//
// Description:
//
// Return:
//   long
//
// Parameter:
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//INN-R170017 CORBA::Long PPTManager_i::txSortJobStartReq(
CORBA::Long CS_PPTManager_i::txSortJobStartReq( //INN-R170017
        pptSortJobStartReqResult&           strSortJobStartReqResult,
        const pptObjCommonIn&               strObjCommonIn,
        const pptSortJobStartReqInParm&     strSortJobStartReqInParm,
        const char *                        claimMemo
        CORBAENV_LAST_CPP )
//D9000098 add start
#ifndef PPT_OPTIONS
{
    PPT_METHODTRACE_ENTRY("PPTManager_i::txSortJobStartReq");
    CORBA::Long rc = RC_OK ;

    PPT_METHODTRACE_V1("", "This function is currently disabled.")
    SET_MSG_RC(strSortJobStartReqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("PPTManager_i:: txSortJobStartReq") ;
    return( rc );
}
#else
//D9000098 add end
{
    PPT_METHODTRACE_ENTRY("PPTManager_i::txSortJobStartReq");
    CORBA::Long  rc = RC_OK;

    PPT_METHODTRACE_V1("", "***** InParameter *****");
    PPT_METHODTRACE_V2("", "  equipmentID____________________", strSortJobStartReqInParm.equipmentID.identifier);
    PPT_METHODTRACE_V2("", "  portGroupID____________________", strSortJobStartReqInParm.portGroupID.identifier);
    PPT_METHODTRACE_V2("", "  strStartCassette.length________", strSortJobStartReqInParm.strStartCassette.length());
    PPT_METHODTRACE_V2("", "  transportType__________________", strSortJobStartReqInParm.transportType);
    PPT_METHODTRACE_V2("", "  sorterJobID____________________", strSortJobStartReqInParm.sorterJobID.identifier);
    PPT_METHODTRACE_V2("", "  componentJobID_________________", strSortJobStartReqInParm.componentJobID.identifier);
    PPT_METHODTRACE_V2("", "  strCarrierXferReq.length_______", strSortJobStartReqInParm.strCarrierXferReq.length());
    for ( CORBA::Long I=0; I < strSortJobStartReqInParm.strCarrierXferReq.length(); I++ )
    {
        PPT_METHODTRACE_V2("", "    carrierID____________________", strSortJobStartReqInParm.strCarrierXferReq[I].carrierID.identifier);
        PPT_METHODTRACE_V2("", "    lotID________________________", strSortJobStartReqInParm.strCarrierXferReq[I].lotID.identifier);
        PPT_METHODTRACE_V2("", "    fromMachineID________________", strSortJobStartReqInParm.strCarrierXferReq[I].fromMachineID.identifier);
        PPT_METHODTRACE_V2("", "    fromPortID___________________", strSortJobStartReqInParm.strCarrierXferReq[I].fromPortID.identifier);
        PPT_METHODTRACE_V2("", "    strToMachine.length__________", strSortJobStartReqInParm.strCarrierXferReq[I].strToMachine.length());
        if ( 0 < strSortJobStartReqInParm.strCarrierXferReq[I].strToMachine.length() )
        {
            PPT_METHODTRACE_V2("", "    toMachineID__________________", strSortJobStartReqInParm.strCarrierXferReq[I].strToMachine[0].toMachineID.identifier);
            PPT_METHODTRACE_V2("", "    toPortID_____________________", strSortJobStartReqInParm.strCarrierXferReq[I].strToMachine[0].toPortID.identifier);
        }
    }
    PPT_METHODTRACE_V1("", "");

    //--------------------------------------------
    // Get equipment information
    //--------------------------------------------
//D9000084    PPT_METHODTRACE_V1("", "txEqpInfoInq()");
//D9000084    pptEqpInfoInqResult strEqpInfoInqResult;
//D9000084    rc = txEqpInfoInq( strEqpInfoInqResult,
//D9000084                       strObjCommonIn,
//D9000084                       strSortJobStartReqInParm.equipmentID,
//D9000084                       TRUE,    // BRInfo
//D9000084                       FALSE,   // StatusInfo
//D9000084                       FALSE,   // PMInfo
//D9000084                       TRUE,    // PortInfo
//D9000084                       FALSE,   // ChamberInfo
//D9000084                       FALSE,   // StockerInfo
//D9000084                       FALSE,   // InprocessingLotInfo
//D9000084                       FALSE ); // ReservedControlJobInfo
//D9000084    if ( rc != RC_OK )
//D9000084    {
//D9000084        PPT_METHODTRACE_V2( "", "txEqpInfoInq() != RC_OK", rc );
//D9000084        strSortJobStartReqResult.strResult = strEqpInfoInqResult.strResult;
//D9000084        return( rc );
//D9000084    }
//D9000084 add start
//DSIV00000099    PPT_METHODTRACE_V1("", "txEqpInfoInq__090()");
//DSIV00000099    pptEqpInfoInqResult__090 strEqpInfoInqResult;
//DSIV00000099    rc = txEqpInfoInq__090( strEqpInfoInqResult,
//DSIV00000099                            strObjCommonIn,
//DSIV00000099                            strSortJobStartReqInParm.equipmentID,
//DSIV00000099                            TRUE,    // BRInfo
//DSIV00000099                            FALSE,   // StatusInfo
//DSIV00000099                            FALSE,   // PMInfo
//DSIV00000099                            TRUE,    // PortInfo
//DSIV00000099                            FALSE,   // ChamberInfo
//DSIV00000099                            FALSE,   // StockerInfo
//DSIV00000099                            FALSE,   // InprocessingLotInfo
//DSIV00000099                            FALSE,   // ReservedControlJobInfo
//DSIV00000099                            FALSE ); // requestFlagForRSPPortInfo
//DSIV00000099    if ( rc != RC_OK )
//DSIV00000099    {
//DSIV00000099        PPT_METHODTRACE_V2( "", "txEqpInfoInq__090() != RC_OK", rc );
//DSIV00000099        strSortJobStartReqResult.strResult = strEqpInfoInqResult.strResult;
//DSIV00000099        return( rc );
//DSIV00000099    }
//DSIV00000099//D9000084 add end
//DSIV00000099 add start
//DSIV00001830        PPT_METHODTRACE_V1("", "txEqpInfoInq__100()");
//DSIV00001830        pptEqpInfoInqResult__100 strEqpInfoInqResult ;
//DSIV00001830        rc = txEqpInfoInq__100( strEqpInfoInqResult, strObjCommonIn,
//DSN000096126        PPT_METHODTRACE_V1("", "txEqpInfoInq__101()");                //DSIV00001830
//DSN000096126        pptEqpInfoInqResult__101 strEqpInfoInqResult ;                //DSIV00001830
//DSN000096126        rc = txEqpInfoInq__101( strEqpInfoInqResult, strObjCommonIn,  //DSIV00001830
//DSN000096126                                strSortJobStartReqInParm.equipmentID,
//DSN000096126                                TRUE,    //requestFlagForBRInfo
//DSN000096126                                FALSE,   //requestFlagForStatusInfo
//DSN000096126                                FALSE,   //requestFlagForPMInfo
//DSN000096126                                TRUE,    //requestFlagForPortInfo
//DSN000096126                                FALSE,   //requestFlagForChamberInfo
//DSN000096126                                FALSE,   //requestFlagForStockerInfo
//DSN000096126                                FALSE,   //requestFlagForInprocessingLotInfo
//DSN000096126                                FALSE,   //requestFlagForReservedControlJobInfo
//DSN000096126                                FALSE,   //requestFlagForRSPPortInfo
//DSN000096126                                FALSE ); //requestFlagEqpContainerInfo
//DSN000096126
//DSN000096126        if(rc != RC_OK)
//DSN000096126        {
//DSN000096126//DSIV00001830            PPT_METHODTRACE_V2( "", "txEqpInfoInq__100() != RC_OK", rc );
//DSN000096126            PPT_METHODTRACE_V2( "", "txEqpInfoInq__101() != RC_OK", rc );  //DSIV00001830
//DSN000096126            strSortJobStartReqResult.strResult = strEqpInfoInqResult.strResult ;
//DSN000096126            return (rc);
//DSN000096126        }
//DSN000096126//DSIV00000099 add end
//DSN000096126 Add Start
        PPT_METHODTRACE_V1("", "txEqpInfoInq__160()");
        pptEqpInfoInqResult__160 strEqpInfoInqResult;
        rc = txEqpInfoInq__160( strEqpInfoInqResult, strObjCommonIn,
                                strSortJobStartReqInParm.equipmentID,
                                TRUE,    //requestFlagForBRInfo
                                FALSE,   //requestFlagForStatusInfo
                                FALSE,   //requestFlagForPMInfo
                                TRUE,    //requestFlagForPortInfo
                                FALSE,   //requestFlagForChamberInfo
                                FALSE,   //requestFlagForStockerInfo
                                FALSE,   //requestFlagForInprocessingLotInfo
                                FALSE,   //requestFlagForReservedControlJobInfo
                                FALSE,   //requestFlagForRSPPortInfo
                                FALSE ); //requestFlagEqpContainerInfo

        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V2( "", "txEqpInfoInq__160() != RC_OK", rc );
            strSortJobStartReqResult.strResult = strEqpInfoInqResult.strResult;
            return (rc);
        }
//DSN000096126 Add End

    //--------------------------------------------
    // Check machine type
    //--------------------------------------------
    if ( 0 != CIMFWStrCmp(strEqpInfoInqResult.equipmentBRInfo.equipmentCategory, SP_Mc_Category_WaferSorter) )
    {
        PPT_METHODTRACE_V2("", "Machine Category is not WaferSorter ", strEqpInfoInqResult.equipmentBRInfo.equipmentCategory);
        PPT_SET_MSG_RC_KEY( strSortJobStartReqResult,
                            MSG_MACHINE_TYPE_NOT_SORTER,
                            RC_MACHINE_TYPE_NOT_SORTER,
                            strSortJobStartReqInParm.equipmentID.identifier );
        return( RC_MACHINE_TYPE_NOT_SORTER );
    }

//DSN000049350 Add Start
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;

    CORBA::Long sorterJobLockFlag = atoi( getenv(SP_SORTERJOB_LOCK_FLAG) );
    PPT_METHODTRACE_V2("","sorterJobLockFlag", sorterJobLockFlag);
    CORBA::Long lockMode = SP_EQP_LOCK_MODE_WRITE;

    if ( 1 == sorterJobLockFlag )
    {
        PPT_METHODTRACE_V1("","sorterJobLockFlag = 1");

        //---------------------------------
        // Lock Sort Jobs
        //---------------------------------
        objectIdentifier dummyID;
        objSorter_sorterJob_LockDR_out strSorter_sorterJob_LockDR_out;
        objSorter_sorterJob_LockDR_in strSorter_sorterJob_LockDR_in;
        strSorter_sorterJob_LockDR_in.sorterJobID          = strSortJobStartReqInParm.sorterJobID;
        strSorter_sorterJob_LockDR_in.sorterComponentJobID = dummyID;
        strSorter_sorterJob_LockDR_in.cassetteID           = dummyID;
        strSorter_sorterJob_LockDR_in.lockType             = SP_ObjectLock_LockType_WRITE;

        PPT_METHODTRACE_V1( "", "calling sorter_sorterJob_LockDR()" );
        rc = sorter_sorterJob_LockDR ( strSorter_sorterJob_LockDR_out,
                                       strObjCommonIn,
                                       strSorter_sorterJob_LockDR_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "sorter_sorterJob_LockDR() != RC_OK", rc);
            strSortJobStartReqResult.strResult = strSorter_sorterJob_LockDR_out.strResult;
            return( rc );
        }

        // Get required equipment lock mode
        strObject_lockMode_Get_in.objectID           = strSortJobStartReqInParm.equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( SP_FunctionCategory_SorterTxID ); // SorterTxID
        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", strSortJobStartReqInParm.equipmentID.identifier );
        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strSortJobStartReqResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }
        lockMode = strObject_lockMode_Get_out.lockMode;
    }
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );

    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;

    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = strSortJobStartReqInParm.equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strSortJobStartReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
        //--------------------------------------------
        // Machine Object Lock
        //--------------------------------------------
        PPT_METHODTRACE_V1("", "Machine Object Lock ");
//DSN000049350        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, strSortJobStartReqInParm.equipmentID, SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "object_Lock() != RC_OK", rc );
            strSortJobStartReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    } //DSN000049350

    //--------------------------------------------
    // Port Object Lock
    //--------------------------------------------
    PPT_METHODTRACE_V1("", "Port Object Lock");
    CORBA::Long lenPort = strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus.length();
    PPT_METHODTRACE_V2("", "lenPort", lenPort);
    for ( CORBA::Long i=0 ; i < lenPort; i++ )
    {
        PPT_METHODTRACE_V2("", "PortID", strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].portID.identifier);

        if ( 0 != CIMFWStrCmp(strSortJobStartReqInParm.portGroupID.identifier,
                              strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].portGroup) )
        {
            // Different PortGroup ignores.
            continue; //[i]
        }

        PPT_METHODTRACE_V1("", "object_LockForEquipmentResource()");
        objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
        rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                              strObjCommonIn,
                                              strSortJobStartReqInParm.equipmentID,
                                              strEqpInfoInqResult.equipmentPortInfo.strEqpPortStatus[i].portID,
                                              SP_ClassName_PosPortResource );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", rc);
            strSortJobStartReqResult.strResult = strObject_LockForEquipmentResource_out.strResult;
            return( rc );
        }
    } //[i]

    //--------------------------------------------
    // Cassette Object Lock
    //--------------------------------------------
    PPT_METHODTRACE_V1("", "Cassette Object Lock");
    CORBA::Long lenCast = strSortJobStartReqInParm.strStartCassette.length();
    PPT_METHODTRACE_V2("", "lenCast", lenCast);
    for ( i=0 ; i < lenCast; i++ )
    {
        rc = object_Lock( strObject_Lock_out, strObjCommonIn,
                          strSortJobStartReqInParm.strStartCassette[i].cassetteID,
                          SP_ClassName_PosCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
            strSortJobStartReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    } //[i]

    //--------------------------------------------
    // Get status of parent Job info
    //--------------------------------------------
    PPT_METHODTRACE_V1("", "txSortJobListInq()");
    objectIdentifier dummyID;
    objectIdentifier sorterJobID;
    sorterJobID = strSortJobStartReqInParm.sorterJobID;

    pptSortJobListInqResult strSortJobListInqResult;
    rc = txSortJobListInq( strSortJobListInqResult,
                           strObjCommonIn,
                           dummyID,         //equipmentID
                           dummyID,         //carrierID
                           dummyID,         //lotID
                           dummyID,         //createUser
                           sorterJobID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "txSortJobListInq() != RC_OK", rc);
        strSortJobStartReqResult.strResult = strSortJobListInqResult.strResult;
        return( rc );
    }

    if ( 0 == strSortJobListInqResult.strSortJobListAttributesSequence.length() )
    {
        PPT_METHODTRACE_V1("", "Sorter Job length was 0");
        PPT_SET_MSG_RC_KEY( strSortJobStartReqResult,
                            MSG_NOT_FOUND_FSSORTJOB, RC_NOT_FOUND_FSSORTJOB,
                            sorterJobID.identifier );
        return( RC_NOT_FOUND_FSSORTJOB );
    }
    CORBA::String_var parentSorterJobStatus = strSortJobListInqResult.strSortJobListAttributesSequence[0].sorterJobStatus;
    PPT_METHODTRACE_V2("", "parentSorterJobStatus", parentSorterJobStatus);

    // process check flags
    CORBA::Boolean bAllProcessOK = TRUE;
    CORBA::Boolean bNPWReserveResult = TRUE;
    CORBA::Boolean bJobStatusChangeResult = TRUE;
    CORBA::Boolean bMultiCarrierXfer = TRUE;

    // for system message
    ostrstream mailMsgStream;
    CORBA::String_var  systemMsgCode = CIMFWStrDup( SP_SystemMsgCode_SORTERR );
    mailMsgStream << "Auto Wafer Sorting Execution Error.\n";

    //--------------------------------------------
    // txArrivalCarrierNotificationReq
    //--------------------------------------------
    PPT_METHODTRACE_V1("", "txArrivalCarrierNotificationReq()");
    CORBA::String_var resultReasonTextStr;
    objectIdentifier controlJobID; // empty
    pptArrivalCarrierNotificationReqResult strArrivalCarrierNotificationReqResult;
    rc = txArrivalCarrierNotificationReq( strArrivalCarrierNotificationReqResult,
                                          strObjCommonIn,
                                          strSortJobStartReqInParm.equipmentID,
                                          strSortJobStartReqInParm.portGroupID.identifier,
                                          controlJobID,
                                          strSortJobStartReqInParm.strStartCassette,
                                          claimMemo );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "txArrivalCarrierNotificationReq() != RC_OK", rc);
        strSortJobStartReqResult.strResult = strArrivalCarrierNotificationReqResult.strResult;
        bAllProcessOK = FALSE;
        bNPWReserveResult = FALSE;

        // set message for system message
        mailMsgStream << "txArrivalCarrierNotificationReq failed.\n";
        mailMsgStream << strArrivalCarrierNotificationReqResult.strResult.messageText << "\n";
        mailMsgStream << strArrivalCarrierNotificationReqResult.strResult.reasonText << "\n";
        resultReasonTextStr = CIMFWStrDup(strArrivalCarrierNotificationReqResult.strResult.messageText);
    }

    // if SorterJobStatus of parent is already 'Executing', Don't change it twice.
    pptSortJobStatusChangeRptResult strSortJobStatusChangeRptResult;
    if ( 0 == CIMFWStrCmp(parentSorterJobStatus, SP_SorterJobStatus_Wait_To_Executing) && bAllProcessOK )
    {
        //--------------------------------------------
        // txSortJobStatusChangeRpt (Parent) --> 'Executing'
        //--------------------------------------------
        PPT_METHODTRACE_V1("", "txSortJobStatusChangeRpt (Parent -> 'Executing')");

        rc = txSortJobStatusChangeRpt( strSortJobStatusChangeRptResult,
                                       strObjCommonIn,
                                       strSortJobStartReqInParm.equipmentID,
                                       strSortJobStartReqInParm.portGroupID,
                                       sorterJobID,
                                       SP_Sorter_Job_Type_SorterJob,
                                       SP_SorterJobStatus_Executing,
                                       claimMemo );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "txSortJobStatusChangeRpt() != RC_OK", rc);
            strSortJobStartReqResult.strResult = strSortJobStatusChangeRptResult.strResult;
            bAllProcessOK = FALSE;
            bJobStatusChangeResult = FALSE;

            // set message for system message
            mailMsgStream << "txSortJobStatusChangeRpt (Parent ->'Executing') failed.\n";
            mailMsgStream << strSortJobStatusChangeRptResult.strResult.messageText << "\n";
            mailMsgStream << strSortJobStatusChangeRptResult.strResult.reasonText << "\n";
            resultReasonTextStr = CIMFWStrDup(strSortJobStatusChangeRptResult.strResult.messageText);
        }
    }

    objectIdentifier componentJobID;
    componentJobID = strSortJobStartReqInParm.componentJobID;

    if ( bAllProcessOK )
    {
        //--------------------------------------------
        // txSortJobStatusChangeRpt (Child) --> 'Executing'
        //--------------------------------------------
        PPT_METHODTRACE_V1("", "txSortJobStatusChangeRpt (Child -> 'Executing')");
        rc = txSortJobStatusChangeRpt( strSortJobStatusChangeRptResult,
                                       strObjCommonIn,
                                       strSortJobStartReqInParm.equipmentID,
                                       strSortJobStartReqInParm.portGroupID,
                                       componentJobID,
                                       SP_Sorter_Job_Type_ComponentJob,
                                       SP_SorterComponentJobStatus_Xfer,
                                       claimMemo );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "txSortJobStatusChangeRpt() != RC_OK", rc);
            strSortJobStartReqResult.strResult = strSortJobStatusChangeRptResult.strResult;
            bAllProcessOK = FALSE;
            bJobStatusChangeResult = FALSE;

            // set message for system message
            mailMsgStream << "txSortJobStatusChangeRpt (Child -> 'Executing') failed.\n";
            mailMsgStream << strSortJobStatusChangeRptResult.strResult.messageText << "\n";
            mailMsgStream << strSortJobStatusChangeRptResult.strResult.reasonText << "\n";
            resultReasonTextStr = CIMFWStrDup(strSortJobStatusChangeRptResult.strResult.messageText);
        }
    }

    if ( bAllProcessOK )
    {
        //--------------------------------------------
        // txMultiCarrierXferReq
        //--------------------------------------------
        PPT_METHODTRACE_V1("", "txMultiCarrierXferReq()");
        pptMultiCarrierXferReqResult strMultiCarrierXferReqResult;
        rc = txMultiCarrierXferReq( strMultiCarrierXferReqResult,
                                    strObjCommonIn,
                                    FALSE, //rerouteFlag
                                    strSortJobStartReqInParm.transportType,
                                    strSortJobStartReqInParm.strCarrierXferReq );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "txMultiCarrierXferReq() != RC_OK", rc);
            strSortJobStartReqResult.strResult = strMultiCarrierXferReqResult.strResult;
            bAllProcessOK = FALSE;
            bMultiCarrierXfer = FALSE;

            // set message for system message
            mailMsgStream << "txMultiCarrierXferReq failed.\n";
            mailMsgStream << strMultiCarrierXferReqResult.strResult.messageText << "\n";
            mailMsgStream << strMultiCarrierXferReqResult.strResult.reasonText << "\n";
            resultReasonTextStr = CIMFWStrDup(strMultiCarrierXferReqResult.strResult.messageText);
            PPT_METHODTRACE_V2("","### messageText = ", strMultiCarrierXferReqResult.strResult.messageText );
            PPT_METHODTRACE_V2("","### reasonText  = ", strMultiCarrierXferReqResult.strResult.reasonText );
        }
    }

    // Post-processing
    if ( !bAllProcessOK )
    {
        PPT_METHODTRACE_V1("", "bAllProcessOK is FALSE ---> Post-processing");

        if ( bNPWReserveResult )
        {
            //--------------------------------------------
            // Arrival Carrier Cancel
            //--------------------------------------------
            PPT_METHODTRACE_V1("", "txArrivalCarrierCancelReq()");
            pptNPWXferCassetteSequence strNPWXferCassette;

            CORBA::Long lenCast = strSortJobStartReqInParm.strStartCassette.length();
            PPT_METHODTRACE_V2("", "lenCast", lenCast);
            strNPWXferCassette.length( lenCast );
            for ( i=0 ; i < lenCast; i++ )
            {
                strNPWXferCassette[i].loadSequenceNumber = strSortJobStartReqInParm.strStartCassette[i].loadSequenceNumber;
                strNPWXferCassette[i].cassetteID         = strSortJobStartReqInParm.strStartCassette[i].cassetteID;
                strNPWXferCassette[i].loadPurposeType    = strSortJobStartReqInParm.strStartCassette[i].loadPurposeType;
                strNPWXferCassette[i].loadPortID         = strSortJobStartReqInParm.strStartCassette[i].loadPortID;
                strNPWXferCassette[i].unloadPortID       = strSortJobStartReqInParm.strStartCassette[i].unloadPortID;
            } //[i]

            CORBA::Boolean notifyToTCSFlag = TRUE;
            pptArrivalCarrierCancelReqResult strArrivalCarrierCancelReqResult;
            rc = txArrivalCarrierCancelReq__090( strArrivalCarrierCancelReqResult,
                                                 strObjCommonIn,
                                                 strSortJobStartReqInParm.equipmentID,
                                                 strSortJobStartReqInParm.portGroupID.identifier,
                                                 strNPWXferCassette,
                                                 notifyToTCSFlag,
                                                 "" ); //claimMemo
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "txArrivalCarrierCancelReq() != RC_OK", rc);

                // set message for system message
                mailMsgStream << "txArrivalCarrierCancelReq failed.\n";
                mailMsgStream << strArrivalCarrierCancelReqResult.strResult.messageText << "\n";
                mailMsgStream << strArrivalCarrierCancelReqResult.strResult.reasonText << "\n";
            }
        }

        //--------------------------------------------
        // txSortJobStatusChangeRpt (Child) --> 'Error'
        //--------------------------------------------
        PPT_METHODTRACE_V1("", "txSortJobStatusChangeRpt (Child) --> 'Error'");
        rc = txSortJobStatusChangeRpt( strSortJobStatusChangeRptResult,
                                       strObjCommonIn,
                                       strSortJobStartReqInParm.equipmentID,
                                       strSortJobStartReqInParm.portGroupID,
                                       componentJobID,
                                       SP_Sorter_Job_Type_ComponentJob,
                                       SP_SorterJobStatus_Error,
                                       "" ); //claimMemo
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "txSortJobStatusChangeRpt() != RC_OK", rc);

            // set message for system message
            mailMsgStream << "txSortJobStatusChangeRpt (Child) -> 'Error' failed.\n";
            mailMsgStream << strSortJobStatusChangeRptResult.strResult.messageText << "\n";
            mailMsgStream << strSortJobStatusChangeRptResult.strResult.reasonText << "\n";
        }

        //--------------------------------------------
        // txSystemMsgRpt
        //--------------------------------------------
        PPT_METHODTRACE_V1("", "txSystemMsgRpt()");
        mailMsgStream << ends;

        pptSystemMsgRptResult  strSystemMsgRptResult;
        rc = txSystemMsgRpt( strSystemMsgRptResult,
                             strObjCommonIn,
                             SP_SubSystemID_MM,                     // subSystemID
                             systemMsgCode,                         // systemMessageCode
                             mailMsgStream.str(),                   // systemMessageText
                             TRUE,                                  // notifyFlag
                             strSortJobStartReqInParm.equipmentID,  // equipmentID
                             "",                                    // equipmentStatus
                             dummyID,                               // stockerID
                             "",                                    // stockerStatus
                             dummyID,                               // AGVID
                             "",                                    // AGVStatus
                             dummyID,                               // lotID
                             "",                                    // lotStatus
                             dummyID,                               // routeID
                             dummyID,                               // operationID
                             "",                                    // operationNumber
                             strObjCommonIn.strTimeStamp.reportTimeStamp,
                             "" );                                  // claimMemo
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("","txSystemMsgRpt() != RC_OK", rc);
        }

        PPT_METHODTRACE_V1("","rc = RC_SORTJOB_START_FAIL");
        rc = RC_SORTJOB_START_FAIL;
        SET_MSG_RC(strSortJobStartReqResult, MSG_SORTJOB_START_FAIL, RC_SORTJOB_START_FAIL);
        PPT_METHODTRACE_V2("","### reason text... ",resultReasonTextStr);
        strSortJobStartReqResult.strResult.reasonText = resultReasonTextStr;
    }
    else
    {
        PPT_METHODTRACE_V1("","bAllProcessOK is TRUE");
        rc = RC_OK;
        SET_MSG_RC(strSortJobStartReqResult, MSG_OK, RC_OK);
    }

    mailMsgStream.rdbuf()->freeze(0);

    PPT_METHODTRACE_EXIT("PPTManager_i::txSortJobStartReq");
    return rc;
}
//D9000098 add start
#endif
//D9000098 add end
