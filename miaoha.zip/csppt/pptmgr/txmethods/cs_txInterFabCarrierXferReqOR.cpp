//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txInterFabCarrierXferReqOR.cpp
//

#include "cs_pptmgr.hpp"

// Class: PPTManager
//
// Service: txInterFabCarrierXferReq()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/28 DSIV00000214 K.Kido         Multi Fab Transfer Support.
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/10 INN-R170003  YangXigang     Durable Management Enhancement
//
// Description:
//
//
// Return:
//    long
//
// Parameter:
//    pptInterFabCarrierXferReqResult&        strInterFabCarrierXferReqResult
//    const pptObjCommonIn&                   strObjCommonIn
//    const pptInterFabCarrierXferReqInParm&  strInterFabCarrierXferReqInParm
//    const char*                             claimMemo
//
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::txInterFabCarrierXferReq(
    pptInterFabCarrierXferReqResult&        strInterFabCarrierXferReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const pptInterFabCarrierXferReqInParm&  strInterFabCarrierXferReqInParm,
    const char*                             claimMemo
    CORBAENV_LAST_CPP )
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::txInterFabCarrierXferReq");

    CORBA::Long rc = RC_OK;
    const objectIdentifier& cassetteID = strInterFabCarrierXferReqInParm.cassetteID;
    const char* destinationFabID = strInterFabCarrierXferReqInParm.destinationFabID;

    //----------------------------------------------------------------
    //  Lock object
    //----------------------------------------------------------------
    PPT_METHODTRACE_V2("", " #### lock cassette object = ", cassetteID.identifier) ;
    objObject_Lock_out strObject_Lock_out;
    rc = object_Lock( strObject_Lock_out, strObjCommonIn, cassetteID, SP_ClassName_PosCassette );

    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "object_Lock() != RC_OK") ;
        strInterFabCarrierXferReqResult.strResult = strObject_Lock_out.strResult ;
        return(rc);
    }

    //----------------------------------------------------------------
    //  Check cassette InterFabXfer state
    //----------------------------------------------------------------
    objCassette_interFabXferState_Get_out  strCassette_interFabXferState_Get_out;

    objCassette_interFabXferState_Get_in  strCassette_interFabXferState_Get_in;
    strCassette_interFabXferState_Get_in.cassetteID = cassetteID;

    rc = cassette_interFabXferState_Get( strCassette_interFabXferState_Get_out, strObjCommonIn,
                                         strCassette_interFabXferState_Get_in );

    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cassette_interFabXferState_Get() != RC_OK") ;
        strInterFabCarrierXferReqResult.strResult = strCassette_interFabXferState_Get_out.strResult ;
        return(rc);
    }

    if(0 != CIMFWStrCmp(strCassette_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Transferring ) )
    {
        PPT_METHODTRACE_V1("", " #### Invalid InterFabXfer state.") ;
        PPT_SET_MSG_RC_KEY3( strInterFabCarrierXferReqResult,
                             MSG_INTERFAB_INVALID_CAST_XFERSTATE,
                             RC_INTERFAB_INVALID_CAST_XFERSTATE,
                             strCassette_interFabXferState_Get_out.interFabXferState,
                             cassetteID.identifier,
                             SP_InterFab_XferState_Transferring );
        return RC_INTERFAB_INVALID_CAST_XFERSTATE;
    }

    //----------------------------------------------------------------
    //  Check cassette transfer state
    //----------------------------------------------------------------
    objCassette_transferInfo_GetDR_out strCassette_transferInfo_GetDR_out;

    objCassette_transferInfo_GetDR_in strCassette_transferInfo_GetDR_in;
    strCassette_transferInfo_GetDR_in.cassetteID = cassetteID;

    rc = cassette_transferInfo_GetDR( strCassette_transferInfo_GetDR_out,
                                      strObjCommonIn,
                                      strCassette_transferInfo_GetDR_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cassette_transferInfo_GetDR() rc != RC_OK");
        strInterFabCarrierXferReqResult.strResult = strCassette_transferInfo_GetDR_out.strResult;
        return rc;
    }

    if(  0 != CIMFWStrCmp(strCassette_transferInfo_GetDR_out.transferStatus, SP_TransState_StationIn )
      && 0 != CIMFWStrCmp(strCassette_transferInfo_GetDR_out.transferStatus, SP_TransState_StationOut )
      && 0 != CIMFWStrCmp(strCassette_transferInfo_GetDR_out.transferStatus, SP_TransState_ManualIn )
      // INN-R170003 && 0 != CIMFWStrCmp(strCassette_transferInfo_GetDR_out.transferStatus, SP_TransState_EquipmentOut ) 
      && 0 != CIMFWStrCmp(strCassette_transferInfo_GetDR_out.transferStatus, CS_TRANS_STATE_PORT_OUT )// INN-R170003
      )
    {
        PPT_METHODTRACE_V2("", "strCassette_transferInfo_GetDR_out.transferStatus = ", strCassette_transferInfo_GetDR_out.transferStatus);
        PPT_METHODTRACE_V1("", " #### Invalid xfer state.") ;
        PPT_SET_MSG_RC_KEY( strInterFabCarrierXferReqResult,
                            MSG_INTERFAB_INVALID_XFERSTATE,
                            RC_INTERFAB_INVALID_XFERSTATE,
                            strCassette_transferInfo_GetDR_out.transferStatus );
        return RC_INTERFAB_INVALID_XFERSTATE;
    }

    //----------------------------------------------------------------
    //  Check cassette transfer job existence 
    //----------------------------------------------------------------
    objCassette_transferJobRecord_GetDR_out strCassette_transferJobRecord_GetDR_out;
    rc = cassette_transferJobRecord_GetDR( strCassette_transferJobRecord_GetDR_out,
                                           strObjCommonIn,
                                           cassetteID );

    if( rc != RC_OK && rc != RC_CARRIER_NOT_TRANSFERING )
    {
        PPT_METHODTRACE_V1("", "cassette_transferJobRecord_GetDR() rc != RC_OK");
        strInterFabCarrierXferReqResult.strResult = strCassette_transferJobRecord_GetDR_out.strResult;
        return rc;
    }

    // INN-R170003 if( 0 == CIMFWStrCmp(strCassette_transferInfo_GetDR_out.transferStatus, SP_TransState_EquipmentOut) )
    if( 0 == CIMFWStrCmp(strCassette_transferInfo_GetDR_out.transferStatus, CS_TRANS_STATE_PORT_OUT) )// INN-R170003
    {
        PPT_METHODTRACE_V2("", "strCassette_transferInfo_GetDR_out.transferStatus = ", strCassette_transferInfo_GetDR_out.transferStatus);
        if( rc == RC_CARRIER_NOT_TRANSFERING )
        {
            PPT_METHODTRACE_V1("", "The Carrier is not transfering. Return...");
            PPT_SET_MSG_RC_KEY( strInterFabCarrierXferReqResult,
                                MSG_INTERFAB_INVALID_XFERSTATE,
                                RC_INTERFAB_INVALID_XFERSTATE,
                                strCassette_transferInfo_GetDR_out.transferStatus );
            return RC_INTERFAB_INVALID_XFERSTATE;
        }
    }

    CORBA::Boolean rerouteFlag = TRUE;
    const char* rerouteStr = getenv(SP_REROUTE_XFER_FLAG);
    if( 0 != CIMFWStrCmp(rerouteStr, "1") )
    {
        rerouteFlag = FALSE;
    }
    if( rc != RC_CARRIER_NOT_TRANSFERING )
    {
        if( FALSE == rerouteFlag )
        {
            PPT_METHODTRACE_V1("", "Reroute is not allowed. Return error...");
            SET_MSG_RC(strInterFabCarrierXferReqResult, MSG_NOT_ALLOWED_REROUTE_XFER, RC_NOT_ALLOWED_REROUTE_XFER);
            return RC_NOT_ALLOWED_REROUTE_XFER;
        }
    }

    //----------------------------------------------------------------
    //  Make Transfer Job (Request to XMS)
    //----------------------------------------------------------------
    objInterFab_carrierXferRequest_Create_out strInterFab_carrierXferRequest_Create_out;

    objInterFab_carrierXferRequest_Create_in  strInterFab_carrierXferRequest_Create_in;
    strInterFab_carrierXferRequest_Create_in.carrierID = cassetteID;
    strInterFab_carrierXferRequest_Create_in.destinationFabID = CIMFWStrDup(destinationFabID);

    rc = interFab_carrierXferRequest_Create( strInterFab_carrierXferRequest_Create_out, strObjCommonIn,
                                             strInterFab_carrierXferRequest_Create_in);

    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "interFab_carrierXferRequest_Create() rc != RC_OK");
        strInterFabCarrierXferReqResult.strResult = strInterFab_carrierXferRequest_Create_out.strResult;
        return rc;
    }

    pptSingleCarrierXferReqResult strSingleCarrierXferReqResult;
    rc = txSingleCarrierXferReq( strSingleCarrierXferReqResult,
                                 strObjCommonIn,
                                 rerouteFlag,
                                 strInterFab_carrierXferRequest_Create_out.strCarrierXferReq.carrierID,
                                 strInterFab_carrierXferRequest_Create_out.strCarrierXferReq.lotID,
                                 strInterFab_carrierXferRequest_Create_out.strCarrierXferReq.zoneType,
                                 strInterFab_carrierXferRequest_Create_out.strCarrierXferReq.n2PurgeFlag,
                                 strInterFab_carrierXferRequest_Create_out.strCarrierXferReq.fromMachineID,
                                 strInterFab_carrierXferRequest_Create_out.strCarrierXferReq.fromPortID,
                                 strInterFab_carrierXferRequest_Create_out.strCarrierXferReq.toStockerGroup,
                                 strInterFab_carrierXferRequest_Create_out.strCarrierXferReq.strToMachine,
                                 strInterFab_carrierXferRequest_Create_out.strCarrierXferReq.expectedStartTime,
                                 strInterFab_carrierXferRequest_Create_out.strCarrierXferReq.expectedEndTime,
                                 strInterFab_carrierXferRequest_Create_out.strCarrierXferReq.mandatoryFlag,
                                 strInterFab_carrierXferRequest_Create_out.strCarrierXferReq.priority );

    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "txSingleCarrierXferReq() rc != RC_OK");
        strInterFabCarrierXferReqResult.strResult = strSingleCarrierXferReqResult.strResult;
        return rc;
    }

    //----------------------------------------------------------------
    // Return to caller
    //----------------------------------------------------------------
    SET_MSG_RC( strInterFabCarrierXferReqResult, MSG_OK, RC_OK );
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txInterFabCarrierXferReq");
    return RC_OK;
}
