//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: .cpp
//

#include "cs_pptmgr.hpp"

//
//
// Class: CS_PPTManager
//
//
// Innotron Modification history :
// Date       Defect#       Person               Comments
// ---------- ------------- -------------------- -------------------------------------------
// 2017/09/11 INN-R170006   YangXigang           For fixture
// 2017/09/28 INN-R17000601 Sam Hsueh            TCS report total number of touch count at once, not support -1 to increase touch count
//
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    csFixtureTouchCountRptResult&       strFixtureTouchCountRptResult,
//    const pptObjCommonIn&               strObjCommonIn,
//    const csFixtureTouchCountRptInParm&   strFixtureTouchCountRptInParm,
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_txFixtureTouchCountRpt(
    csFixtureTouchCountRptResult&         strFixtureTouchCountRptResult,
    const pptObjCommonIn&                 strObjCommonIn,
    const csFixtureTouchCountRptInParm&   strFixtureTouchCountRptInParm
    CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txFixtureTouchCountRpt");
    CORBA::Long rc = RC_OK ;


    //------------------------------
    // Object Lock for Reticle
    //------------------------------
    /*objObject_Lock_out  strObject_Lock_out;
    rc = object_Lock(strObject_Lock_out, strObjCommonIn, strFixtureTouchCountRptInParm.fixtureID, SP_ClassName_PosFixture);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
        strFixtureTouchCountRptResult.strResult = strObject_Lock_out.strResult;
        return( rc );
    }*/

    //INN-R17000601 add start
    //---------------------------------------//
    // Get current value prior to update
    //---------------------------------------//
    PPT_METHODTRACE_V2("", "input touchCount", strFixtureTouchCountRptInParm.strFixtureTouchCountInfo.touchCount);
    if ( 0 > strFixtureTouchCountRptInParm.strFixtureTouchCountInfo.touchCount )
    {
        SET_MSG_RC(strFixtureTouchCountRptResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM);
        return RC_INVALID_INPUT_PARM;
    }

    csObjFixture_touchCount_Get_out    strFixture_touchCount_Get_out;
    csObjFixture_touchCount_Get_in     strFixture_touchCount_Get_in;
    strFixture_touchCount_Get_in.fixtureID = strFixtureTouchCountRptInParm.fixtureID;
    PPT_METHODTRACE_V2("", "fixtureID", strFixture_touchCount_Get_in.fixtureID.identifier);
    
    rc = cs_fixture_touchCount_Get( strFixture_touchCount_Get_out,
                                    strObjCommonIn,
                                    strFixture_touchCount_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_fixture_touchCount_Get() rc != RC_OK", rc);
        strFixtureTouchCountRptResult.strResult = strFixture_touchCount_Get_out.strResult;
        return( rc );
    }
    
    PPT_METHODTRACE_V2("", "touchCount      (before) ", strFixture_touchCount_Get_out.strFixtureTouchCountInfo.touchCount);
    PPT_METHODTRACE_V2("", "accumTouchCount (before) ", strFixture_touchCount_Get_out.strFixtureTouchCountInfo.accumTouchCount);
    //INN-R17000601 add end
    /*------------------------------------------------*/
    /*   Reset fixture touch count information        */
    /*------------------------------------------------*/
    
    csObjFixture_touchCount_Set_in  strFixture_touchCount_Set_in;
    csObjFixture_touchCount_Set_out strFixture_touchCount_Set_out;
    
    strFixture_touchCount_Set_in.fixtureID                 = strFixtureTouchCountRptInParm.fixtureID;
    //INN-R17000601 strFixture_touchCount_Set_in.strFixtureTouchCountInfo  = strFixtureTouchCountRptInParm.strFixtureTouchCountInfo;
    strFixture_touchCount_Set_in.claimMemo                 = strFixtureTouchCountRptInParm.claimMemo;
    
    //INN-R17000601 add start
    strFixture_touchCount_Set_in.strFixtureTouchCountInfo.touchCount      = strFixture_touchCount_Get_out.strFixtureTouchCountInfo.touchCount + strFixtureTouchCountRptInParm.strFixtureTouchCountInfo.touchCount;
    strFixture_touchCount_Set_in.strFixtureTouchCountInfo.accumTouchCount = strFixture_touchCount_Get_out.strFixtureTouchCountInfo.accumTouchCount + strFixtureTouchCountRptInParm.strFixtureTouchCountInfo.touchCount;
    PPT_METHODTRACE_V2("", "touchCount      (after) ", strFixture_touchCount_Set_in.strFixtureTouchCountInfo.touchCount);
    PPT_METHODTRACE_V2("", "accumTouchCount (after) ", strFixture_touchCount_Set_in.strFixtureTouchCountInfo.accumTouchCount);
    //INN-R17000601 add end
    
    rc = cs_fixture_touchCount_Set(strFixture_touchCount_Set_out,strObjCommonIn,strFixture_touchCount_Set_in);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_fixture_touchCount_Set() rc != RC_OK", rc)
        strFixtureTouchCountRptResult.strResult = strFixture_touchCount_Set_out.strResult ;
        return( rc );
    }

    /*---------------------------------------------*/
    /*   Create Durable Change Event  change history ???? */
    /*---------------------------------------------*/
    /*
    objDurableChangeEvent_Make_out strDurableChangeEvent_Make_out;
    rc = durableChangeEvent_Make(strDurableChangeEvent_Make_out,
                                 strObjCommonIn,
                                 "TXPDC007",
                                 reticleID,
                                 SP_DurableCat_Reticle,
                                 CS_SP_DurableEvent_Action_WaferCountReset,
                                 claimMemo) ;

    if( rc )
    {
        PPT_METHODTRACE_V2("", "durableChangeEvent_Make() rc != RC_OK",rc)
        strReticleWaferCountResetReqResult.strResult = strDurableChangeEvent_Make_out.strResult ;
        SET_MSG_RC( strReticleWaferCountResetReqResult, MSG_FAIL_MAKE_HISTORY, rc );
        return rc ;
    }
    */
    /*-----------------------*/
    /*   Set out structure   */
    /*-----------------------*/
    strFixtureTouchCountRptResult.strFixtureTouchCountInfo = strFixture_touchCount_Set_out.strFixtureTouchCountInfo;

    SET_MSG_RC(strFixtureTouchCountRptResult, MSG_OK, RC_OK); 

    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txFixtureTouchCountRpt");
    return( RC_OK );
    
}