//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2003. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2003. All rights reserved.
//
// SiView
// Name: cs_txPrivilegeCheckForRMSReq.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: cs_txPrivilegeCheckForRMSReq()
//
// Change history:
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
//
// Description:
//
// Return:
//     long
//
// Parameter:
//      csPrivilegeCheckForRMSReqResult&      strCsPrivilegeCheckForRMSReqResult,
//      const pptObjCommonIn&                 strObjCommonIn,
//      const objectIdentifier&               equipmentID,
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_txPrivilegeCheckForRMSReq(
    csPrivilegeCheckForRMSReqResult&      strCsPrivilegeCheckForRMSReqResult,
    const pptObjCommonIn&                 strObjCommonIn,
    const objectIdentifier&               equipmentID,
    CORBA::Environment&                   IT_env)
{
    /*------------------------------------------------------------------------*/
    /*   Return Code Initialization                                           */
    /*------------------------------------------------------------------------*/
    
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txPrivilegeCheckForRMSReq")
    CORBA::Long rc = RC_OK ;
    
    /*-------------------*/
    /*   Get area list   */
    /*-------------------*/
    csObjPerson_PrivilegeCheckForRMS_out strCsObjPerson_PrivilegeCheckForRMS;
    rc = cs_person_PrivilegeCheckForRMS (strCsObjPerson_PrivilegeCheckForRMS, strObjCommonIn, equipmentID);
    
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cs_bank_srcProdList_GetDR() != RC_OK");
        strCsPrivilegeCheckForRMSReqResult.strResult = strCsObjPerson_PrivilegeCheckForRMS.strResult;
        return( rc );
    }
    
    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
    SET_MSG_RC(strCsPrivilegeCheckForRMSReqResult, MSG_OK, RC_OK) ;    
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: cs_txPrivilegeCheckForRMSReq ") ;
    return(RC_OK);
}
    