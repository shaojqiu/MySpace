#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txCassetteExchangeReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:14:36 [ 7/13/07 21:14:37 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txCassetteExchangeReqOR.cpp
//

#include "cs_pptmgr.hpp"

#include "pmc.hh"

// Class: CS_PPTManager
//
// Service: txCassetteExchangeReq()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2000/08/17              O.Sugiyama     Initial Release
// 2000/08/22  0.01        O.Sugiyama     Add Logic to retrieve equipment onlineMode
//                                        and add if-else statement for it
// 2000/09/14  PTR3000173  H.Katoh        Add Method call
// 2000/09/14  PTR3000182  S.Kawabe       remove bNotifyToTCS
// 2000/09/15  PTR3000181  H.Katoh        Add Logic to maintenance Control Job Information
// 2000/09/15  PTR3000183  H.Katoh        Change Input parameter
// 2001/09/06  D4000135    Y.Yoshihara    Change parameter of sorter_waferTransferInfo_Verify
// 2002/10/25  P4200277    K.Kido         Add : Check for backupOperation. (Reject backupWafer)
// 2004/10/22  D6000025    K.Murakami     eBroker Migration.    //D6000478
// 2005/10/19  D6000479    K.Kido         Lock Port Object.
// 2005/10/18  D6000478    M.Kase         Add logic to update WaferLotHistoryPointer of lot
//                                        Change history format for D6000025
// 2006/05/22  D7000092    Y.Kadowaki     Add object lock for cassette.
// 2007/06/12  D9000005    H.Hotta        WaferSorter automation support.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/03 DSIV00000099 M.Ogawa        equipment_brInfo_GetDR ==> equipment_brInfo_GetDR__100
// 2008/11/02 DSIV00000214 K.Kido         Multi Fab support.
// 2011/08/08 DSN000015229 Sa Guo         equipment_brInfo_GetDR__100 ==> equipment_brInfo_GetDR__120
// 2012/12/04 DSN000049350 K.Yamaoku      Equipment parallel processing support (P2)
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/14 INN-R170002  JQ.Shao        Contamination Control
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    pptCassetteExchangeReqResult&       strCassetteExchangeReqResult
//    const pptObjCommonIn&               strObjCommonIn
//    const objectIdentifier&             equipmentID
//    const pptWaferTransferSequence&     strWaferXferSeq
//    const char *                        claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i:: txCassetteExchangeReq (
    pptCassetteExchangeReqResult&       strCassetteExchangeReqResult,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             equipmentID,
    const pptWaferTransferSequence&     strWaferXferSeq,
//PTR3000182    CORBA::Boolean                      bNotifyToTCS,
//D6000025     const char *                        claimMemo,
//D6000025     CORBA::Environment &                IT_env)
    const char *                        claimMemo  //D6000025
    CORBAENV_LAST_CPP)                             //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txCassetteExchangeReq");
    CORBA::Long rc;

#if 0
//debug start
{
  CORBA::Long leng = strWaferXferSeq.length();
  PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "strWaferXferSeq.length", leng);
  CORBA::Long ii;
  for(ii=0; ii < leng; ii++) {
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "---->strWaferXferSeq[i].waferID              ", strWaferXferSeq[ii].waferID.identifier);
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "---->strWaferXferSeq[i].destinationSlotNumber", strWaferXferSeq[ii].destinationSlotNumber);
  }
}
//debug end
#endif

//DSN000049350 Add Start
    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;

    CORBA::Long lockMode = SP_EQP_LOCK_MODE_WRITE;
    if ( 0 < CIMFWStrLen(equipmentID.identifier) )
    {
        PPT_METHODTRACE_V2("", "0 > equipmentID.length", equipmentID.identifier);

        // Get required equipment lock mode
        objObject_lockMode_Get_out strObject_lockMode_Get_out;
        objObject_lockMode_Get_in  strObject_lockMode_Get_in;
        strObject_lockMode_Get_in.objectID           = equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXPCC001" ); // TxCassetteExchangeReq
        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strCassetteExchangeReqResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }
        lockMode = strObject_lockMode_Get_out.lockMode;

        if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
        {
            PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

            // Lock Equipment Main Object
            stringSequence dummySeq;
            dummySeq.length(0);
            strAdvanced_object_Lock_in.objectID   = equipmentID;
            strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
            strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
            strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
            strAdvanced_object_Lock_in.keySeq     = dummySeq;

            PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
            rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                        strObjCommonIn,
                                        strAdvanced_object_Lock_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                strCassetteExchangeReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                return( rc );
            }
        }
    }
//DSN000049350 Add End

//D6000479 add start
    //---------------------------------------
    // Check equipment allow early carrier out or not
    //---------------------------------------
    PPT_METHODTRACE_V1("", "Check equipment allow early carrier out or not");

    objEquipment_CheckConditionForEmptyCassetteEarlyOut_out strEquipment_CheckConditionForEmptyCassetteEarlyOut_out;
    CORBA::Long tmpRc = equipment_CheckConditionForEmptyCassetteEarlyOut( strEquipment_CheckConditionForEmptyCassetteEarlyOut_out,
                                                                          strObjCommonIn,
                                                                          equipmentID );

    if( RC_OK == tmpRc )
    {
        PPT_METHODTRACE_V1("", " #### Check whether equipment is Internal Buffer or not.");
        CORBA::String_var equipmentCategory ;

//DSIV00000099        objEquipment_brInfo_GetDR_out strEquipment_brInfo_GetDR_out;
//DSIV00000099        rc = equipment_brInfo_GetDR( strEquipment_brInfo_GetDR_out,
//DSIV00000099                                     strObjCommonIn,
//DSIV00000099                                     equipmentID );
//DSIV00000099        if ( rc != RC_OK )
//DSIV00000099        {
//DSIV00000099            PPT_METHODTRACE_V2("", "equipment_brInfo_GetDR() rc != RC_OK", rc);
//DSIV00000099            strCassetteExchangeReqResult.strResult = strEquipment_brInfo_GetDR_out.strResult;
//DSIV00000099            return( rc );
//DSIV00000099        }
//DSIV00000099        equipmentCategory = strEquipment_brInfo_GetDR_out.equipmentBRInfo.equipmentCategory ;
//DSIV00000099 add start
//DSN000015229        objEquipment_brInfo_GetDR_out__100 strEquipment_brInfo_GetDR_out;
//DSN000015229        objEquipment_brInfo_GetDR_in__100  strEquipment_brInfo_GetDR_in;
//DSN000015229        strEquipment_brInfo_GetDR_in.equipmentID = equipmentID;
//DSN000015229        rc = equipment_brInfo_GetDR__100( strEquipment_brInfo_GetDR_out,
//DSN000015229                                          strObjCommonIn,
//DSN000015229                                          strEquipment_brInfo_GetDR_in );
//DSN000015229        if ( rc != RC_OK )
//DSN000015229        {
//DSN000015229            PPT_METHODTRACE_V2("", "equipment_brInfo_GetDR__100() rc != RC_OK", rc);
//DSN000015229            strCassetteExchangeReqResult.strResult = strEquipment_brInfo_GetDR_out.strResult;
//DSN000015229            return( rc );
//DSN000015229        }
//DSN000015229 Add Start
//DSN000049350 Add Start
        if ( lockMode == SP_EQP_LOCK_MODE_WRITE )
        {
            PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
            objEquipment_brInfo_GetDR_out__120 strEquipment_brInfo_GetDR_out;
            objEquipment_brInfo_GetDR_in__100  strEquipment_brInfo_GetDR_in;
            strEquipment_brInfo_GetDR_in.equipmentID = equipmentID;
            rc = equipment_brInfo_GetDR__120( strEquipment_brInfo_GetDR_out,
                                              strObjCommonIn,
                                              strEquipment_brInfo_GetDR_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "equipment_brInfo_GetDR__120() rc != RC_OK", rc);
                strCassetteExchangeReqResult.strResult = strEquipment_brInfo_GetDR_out.strResult;
                return( rc );
            }
//DSN000015229 Add End

            equipmentCategory = strEquipment_brInfo_GetDR_out.equipmentBRInfo.equipmentCategory ;
//DSIV00000099 add end

            if ( CIMFWStrCmp( equipmentCategory, SP_Mc_Category_InternalBuffer ) == 0 )
            {
                /**********************************************************/
                /*  Lock Port Object for internal Buffer Equipment only.  */
                /**********************************************************/
                objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
                rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out,
                                                                strObjCommonIn,
                                                                equipmentID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "equipment_portInfoForInternalBuffer_GetDR != RC_OK")
                    strCassetteExchangeReqResult.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
                    return( rc );
                }

                CORBA::Long lenPortInfo = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
                for( CORBA::Long i = 0 ; i < lenPortInfo ; i++ )
                {
                    objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
                    rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                          strObjCommonIn,
                                                          equipmentID,
                                                          strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[i].portID,
                                                          SP_ClassName_PosPortResource );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "object_LockForEquipmentResource () rc != RC_OK", rc);
                        strCassetteExchangeReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
                        return( rc );
                    }
                    PPT_METHODTRACE_V2("", "Locked port object : ", strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[i].portID.identifier);
                }
            }
        } //DSN000049350
    }
//D6000479 add end

//D7000092 add start
    //---------------------------------------------------------------------------------
    // Collect participant cassettes (original/destination) from WaferTransferSequence.
    //---------------------------------------------------------------------------------
    CORBA::Long  waferMapLen = strWaferXferSeq.length();
    CORBA::Long  casLen = 0;
    objectIdentifierSequence  cassetteIDs;
    cassetteIDs.length(waferMapLen * 2);

//INN-R170002 Add Start
    objectIdentifierSequence moveToCassetteIDSeq;
    objectIdentifierSequence lotIDs;
    CORBA::Long lenDesCasIDSeq   = 0;
    CORBA::Long lenLotIDSeq      = 0;
    CORBA::Long i_wfr            = 0;
    CORBA::Long j_cas            = 0;
    CORBA::Long k_lot            = 0;
    CORBA::Boolean bCassetteFind = FALSE;
    CORBA::Boolean bLotFind      = FALSE;
    moveToCassetteIDSeq.length(0);
    lotIDs.length(0);
//INN-R170002 Add End

    CORBA::Long  i=0;
    for( i=0; i<waferMapLen; i++ )
    {
        // interested in SiView managed casettes only.
        if( strWaferXferSeq[i].bOriginalCassetteManagedBySiView == TRUE )
        {
            cassetteIDs[casLen] = strWaferXferSeq[i].originalCassetteID;
            PPT_METHODTRACE_V2("","SiView managed original cassette found.", cassetteIDs[casLen].identifier);
            casLen++;
        }
        if( strWaferXferSeq[i].bDestinationCassetteManagedBySiView == TRUE )
        {
            cassetteIDs[casLen] = strWaferXferSeq[i].destinationCassetteID;
            PPT_METHODTRACE_V2("","SiView managed destination cassette found.", cassetteIDs[casLen].identifier);
            casLen++;
        }

//INN-R170002 Add Start
        //---------------------------------------
        // Collect CassetteID of MoveToCassette
        //---------------------------------------
        if ( TRUE == strWaferXferSeq[i].bDestinationCassetteManagedBySiView )
        {
            if( 0 <  CIMFWStrLen(strWaferXferSeq[i].originalCassetteID.identifier)
             && 0 <  CIMFWStrLen(strWaferXferSeq[i].destinationCassetteID.identifier)
             && 0 != CIMFWStrCmp(strWaferXferSeq[i].originalCassetteID.identifier, strWaferXferSeq[i].destinationCassetteID.identifier) )
            {
                bCassetteFind = FALSE;

                lenDesCasIDSeq = moveToCassetteIDSeq.length();
                PPT_METHODTRACE_V2("", "lenDesCasIDSeq-->", lenDesCasIDSeq);

                for ( j_cas = 0; j_cas < lenDesCasIDSeq; j_cas++ )
                {
                    if ( 0 == CIMFWStrCmp(strWaferXferSeq[i].destinationCassetteID.identifier, moveToCassetteIDSeq[j_cas].identifier) )
                    {
                        PPT_METHODTRACE_V2("", "set bCassetteFind = TRUE", j_cas);
                        bCassetteFind = TRUE;
                        break;
                    }
                }
                if ( bCassetteFind == FALSE )
                {
                    PPT_METHODTRACE_V1("", "bCassetteFind == FALSE");
                    lenDesCasIDSeq++;
                    moveToCassetteIDSeq.length(lenDesCasIDSeq);
                    moveToCassetteIDSeq[lenDesCasIDSeq-1] = strWaferXferSeq[i].destinationCassetteID;
                }
            }
        }
//INN-R170002 Add End
    }
    cassetteIDs.length(casLen);

//DSN000049350 Add Start
    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

        /*---------------------------------*/
        /*   Get Cassette's ControlJobID   */
        /*---------------------------------*/
        PPT_METHODTRACE_V1( "", "Get Cassette's ControlJobID");
        objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;
        rc = cassette_controlJobID_Get(strCassette_controlJobID_Get_out, strObjCommonIn, cassetteIDs[0]);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK");
            strCassetteExchangeReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
            return( rc );
        }

        if ( CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) > 0 )
        {
            PPT_METHODTRACE_V1( "", "len(controlJobID) > 0" );

            /*-------------------------*/
            /*   Get ControlJob Info   */
            /*-------------------------*/
            PPT_METHODTRACE_V1( "", "Get ControlJob Info" );

            objControlJob_containedLot_Get_out strControlJob_containedLot_Get_out;

            rc = controlJob_containedLot_Get( strControlJob_containedLot_Get_out,
                                              strObjCommonIn,
                                              strCassette_controlJobID_Get_out.controlJobID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "controlJob_containedLot_Get() != RC_OK" );
                strCassetteExchangeReqResult.strResult = strControlJob_containedLot_Get_out.strResult;
                return( rc );
            }

            stringSequence procLotSeq;
            CORBA::ULong extendLen  = 25;
            CORBA::ULong t_lotIDLen = extendLen;
            CORBA::ULong procLotCnt = 0;
            procLotSeq.length(t_lotIDLen);

            pptControlJobCassetteSequence& strControlJobCassette = strControlJob_containedLot_Get_out.strControlJobCassette;
            CORBA::ULong lenCtrlJobCassette = strControlJobCassette.length();
            PPT_METHODTRACE_V2( "", "lenCtrlJobCassette", lenCtrlJobCassette );
            for ( i = 0; i < lenCtrlJobCassette; i++ )
            {
                CORBA::ULong lenCtrlJobLot = strControlJobCassette[i].strControlJobLot.length();
                PPT_METHODTRACE_V2( "", "lenCtrlJobLot", lenCtrlJobLot );
                for ( CORBA::Long j = 0; j < lenCtrlJobLot; j++ )
                {
                    PPT_METHODTRACE_V2( "", "lotID", strControlJobCassette[i].strControlJobLot[j].lotID.identifier );
                    if ( TRUE == strControlJobCassette[i].strControlJobLot[j].operationStartFlag )
                    {
                        PPT_METHODTRACE_V1( "", "operationStartFlag = TRUE" );

                        if( procLotCnt >= t_lotIDLen )
                        {
                            PPT_METHODTRACE_V1("", "procLotCnt >= t_lotIDLen");
                            t_lotIDLen += extendLen;
                            procLotSeq.length( t_lotIDLen );
                        }
                        procLotSeq[procLotCnt++] = strControlJobCassette[i].strControlJobLot[j].lotID.identifier;
                    }
                }
            }
            procLotSeq.length(procLotCnt);
            PPT_METHODTRACE_V2( "", "procLotCnt", procLotCnt);

            if ( 0 < procLotSeq.length() )
            {
                PPT_METHODTRACE_V1( "", "procLotSeq.length > 0" );

                // Lock Equipment ProcLot Element (Write)
                strAdvanced_object_Lock_in.objectID   = equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_InProcessingLot );
                strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
                strAdvanced_object_Lock_in.keySeq     = procLotSeq;

                PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_InProcessingLot );
                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strCassetteExchangeReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }
            }

            // Lock Equipment LoadCassette Element (Write)
            stringSequence loadCastSeq;
            loadCastSeq.length(casLen);
            for ( CORBA::ULong loadCastNo = 0; loadCastNo < casLen; loadCastNo++ )
            {
                loadCastSeq[loadCastNo] = cassetteIDs[loadCastNo].identifier;
            }
            strAdvanced_object_Lock_in.objectID   = equipmentID;
            strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
            strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
            strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
            strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

            PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_LoadCassette );
            rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                        strObjCommonIn,
                                        strAdvanced_object_Lock_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                strCassetteExchangeReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                return( rc );
            }

            /*------------------------------*/
            /*   Lock ControlJob Object     */
            /*------------------------------*/
            objObject_Lock_out strObject_Lock_out;

            PPT_METHODTRACE_V2( "", "calling object_Lock()", SP_ClassName_PosControlJob );
            rc = object_Lock( strObject_Lock_out,
                              strObjCommonIn,
                              strCassette_controlJobID_Get_out.controlJobID,
                              SP_ClassName_PosControlJob );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                strCassetteExchangeReqResult.strResult = strObject_Lock_out.strResult;
                return( rc );
            }
        }
    }
//DSN000049350 Add End

    //---------------------------------------
    // Lock cassette objects for update.
    //---------------------------------------
    objObjectSequence_Lock_out  strObjectSequence_Lock_out;
    rc = objectSequence_Lock( strObjectSequence_Lock_out, strObjCommonIn, cassetteIDs, SP_ClassName_PosCassette );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","objectSequence_Lock() rc != RC_OK", rc);
        strCassetteExchangeReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }
//D7000092 add end

//D9000005 add start
    /*-------------------------------*/
    /*   Check SorterJob existence   */
    /*-------------------------------*/
    pptEquipmentLoadPortAttribute dummyEquipmentPortAttribute;
    objectIdentifierSequence dummyLotIDs;

    objWaferSorter_sorterJob_CheckForOperation_out strWaferSorter_sorterJob_CheckForOperation_out;
    objWaferSorter_sorterJob_CheckForOperation_in  strWaferSorter_sorterJob_CheckForOperation_in;
    strWaferSorter_sorterJob_CheckForOperation_in.strEquipmentLoadPortAttribute = dummyEquipmentPortAttribute;
    strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs                   = cassetteIDs;
    strWaferSorter_sorterJob_CheckForOperation_in.lotIDs                        = dummyLotIDs;
    strWaferSorter_sorterJob_CheckForOperation_in.operation                     = CIMFWStrDup(SP_Operation_For_Cast);

    rc = waferSorter_sorterJob_CheckForOperation( strWaferSorter_sorterJob_CheckForOperation_out,
                                                  strObjCommonIn,
                                                  strWaferSorter_sorterJob_CheckForOperation_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "waferSorter_sorterJob_CheckForOperation() != RC_OK" );
        strCassetteExchangeReqResult.strResult = strWaferSorter_sorterJob_CheckForOperation_out.strResult;
        return( rc );
    }
//D9000005 add end

//INN-R170002 Add Start
    //------------------------------------------------
    // Check Lot Contamination for Carrier Exchange
    //------------------------------------------------
    for ( j_cas = 0; j_cas < lenDesCasIDSeq; j_cas++ )
    {
        lenLotIDSeq = 0;
        for ( i_wfr = 0; i_wfr < waferMapLen; i_wfr++ )
        {
            if ( TRUE == strWaferXferSeq[i_wfr].bDestinationCassetteManagedBySiView )
            {
                if( 0 <  CIMFWStrLen(strWaferXferSeq[i_wfr].originalCassetteID.identifier)
                 && 0 <  CIMFWStrLen(strWaferXferSeq[i_wfr].destinationCassetteID.identifier)
                 && 0 != CIMFWStrCmp(strWaferXferSeq[i_wfr].originalCassetteID.identifier, strWaferXferSeq[i_wfr].destinationCassetteID.identifier) )
                {
                    if( 0 == CIMFWStrCmp(moveToCassetteIDSeq[j_cas].identifier, strWaferXferSeq[i_wfr].destinationCassetteID.identifier) )
                    {
                        objWafer_lot_Get_out strWafer_lot_Get_out;
                        rc = wafer_lot_Get(strWafer_lot_Get_out, strObjCommonIn, strWaferXferSeq[i_wfr].waferID);
                        if(rc!= RC_OK)
                        {
                            PPT_METHODTRACE_V2("", "wafer_lot_Get() != RC_OK", strWaferXferSeq[i_wfr].waferID.identifier);
                            strCassetteExchangeReqResult.strResult = strWafer_lot_Get_out.strResult;
                            return( rc );
                        }

                        bLotFind = FALSE;

                        lenLotIDSeq = lotIDs.length();
                        PPT_METHODTRACE_V2("", "lenDesCasIDSeq-->", lenDesCasIDSeq);

                        for ( k_lot = 0; k_lot < lenLotIDSeq; k_lot++ )
                        {
                            if ( 0 == CIMFWStrCmp(strWafer_lot_Get_out.lotID.identifier, lotIDs[k_lot].identifier) )
                            {
                                PPT_METHODTRACE_V2("", "set bLotFind = TRUE", k_lot);
                                bLotFind = TRUE;
                                break;
                            }
                        }
                        if ( bLotFind == FALSE )
                        {
                            PPT_METHODTRACE_V1("", "bLotFind == FALSE");
                            lenLotIDSeq++;
                            lotIDs.length(lenLotIDSeq);
                            lotIDs[lenLotIDSeq-1] = strWafer_lot_Get_out.lotID;
                        }
                    }
                }
            }
        }

        csObjLot_ContaminationInfo_CheckForCarrierExchange_out strLot_ContaminationInfo_CheckForCarrierExchange_out; 
        csObjLot_ContaminationInfo_CheckForCarrierExchange_in  strLot_ContaminationInfo_CheckForCarrierExchange_in;
        strLot_ContaminationInfo_CheckForCarrierExchange_in.carrierID = moveToCassetteIDSeq[j_cas];
        strLot_ContaminationInfo_CheckForCarrierExchange_in.lotIDs    = lotIDs;
        rc = cs_lot_ContaminationInfo_CheckForCarrierExchange(strLot_ContaminationInfo_CheckForCarrierExchange_out,
                                                              strObjCommonIn,
                                                              strLot_ContaminationInfo_CheckForCarrierExchange_in);
        if(rc!= RC_OK)
        {
            PPT_METHODTRACE_V2("", "cs_lot_ContaminationInfo_CheckForCarrierExchange() != RC_OK", moveToCassetteIDSeq[j_cas].identifier);
            strCassetteExchangeReqResult.strResult = strLot_ContaminationInfo_CheckForCarrierExchange_out.strResult;
            return( rc );
        }
    }
//INN-R170002 Add End

    //---------------------------------------
    // Check input parameter for
    // wafer transfer (Sorter operation)
    //---------------------------------------
    objSorter_waferTransferInfo_Verify_out strSorter_waferTransferInfo_Verify_out;
    //D4000135 rc = sorter_waferTransferInfo_Verify(strSorter_waferTransferInfo_Verify_out, strObjCommonIn,
    //D4000135                                     strWaferXferSeq);
    //D4000135 Start
    rc = sorter_waferTransferInfo_Verify(strSorter_waferTransferInfo_Verify_out, strObjCommonIn,
                                         strWaferXferSeq,
                                         SP_Sorter_Location_CheckBy_SlotMap);
    //D4000135 End
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq", "sorter_waferTransferInfo_Verify() rc != RC_OK");
        strCassetteExchangeReqResult.strResult = strSorter_waferTransferInfo_Verify_out.strResult;
        return( rc );
    }

//PTR3000173 Start
    //---------------------------------------
    // Check input parameter and
    // Server data condition
    //---------------------------------------
    objCassette_CheckConditionForExchange_out strCassette_CheckConditionForExchange_out;
    rc = cassette_CheckConditionForExchange( strCassette_CheckConditionForExchange_out,
                                             strObjCommonIn,
                                             equipmentID,
                                             strWaferXferSeq );
    if(rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq", "cassette_CheckConditionForExchange() rc != RC_OK");
        strCassetteExchangeReqResult.strResult = strCassette_CheckConditionForExchange_out.strResult;
        return( rc );
    }
//PTR3000173 End
//DSIV00000214 add start
    cassetteIDs.length(casLen);
    for( CORBA::ULong casCnt = 0 ; casCnt < casLen ; casCnt++ )
    {
        //---------------------------------------
        // Check cassette InterFabXfer State
        //---------------------------------------
        objCassette_interFabXferState_Get_out strCassette_interFabXferState_Get_out;
        objCassette_interFabXferState_Get_in strCassette_interFabXferState_Get_in;
        strCassette_interFabXferState_Get_in.cassetteID = cassetteIDs[casCnt];

        rc = cassette_interFabXferState_Get( strCassette_interFabXferState_Get_out,
                                             strObjCommonIn,
                                             strCassette_interFabXferState_Get_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cassette_interFabXferState_Get() != RC_OK");
            strCassetteExchangeReqResult.strResult = strCassette_interFabXferState_Get_out.strResult;
            return( rc );
        }

        if( CIMFWStrCmp( strCassette_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Transferring ) == 0 )
        {
            PPT_METHODTRACE_V1("", "interFabXferState == Transferring");
            PPT_SET_MSG_RC_KEY2( strCassetteExchangeReqResult,
                                 MSG_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                 RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                 cassetteIDs[casCnt].identifier,
                                 strCassette_interFabXferState_Get_out.interFabXferState );
            return( RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ );
        }

        //---------------------------------------
        // Check lot InterFabXfer State
        //---------------------------------------
        /*-------------------------------*/
        /*  Get Lot list in carrier      */
        /*-------------------------------*/
        objCassette_lotList_GetDR_out strCassette_lotList_GetDR_out;
        rc = cassette_lotList_GetDR( strCassette_lotList_GetDR_out,
                                     strObjCommonIn,
                                     cassetteIDs[casCnt] );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cassette_lotList_GetDR() rc != RC_OK");
            strCassetteExchangeReqResult.strResult = strCassette_lotList_GetDR_out.strResult ;
            return( rc );
        }

        CORBA::ULong lotLen = strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID.length();
        for( CORBA::ULong lotCnt = 0 ; lotCnt < lotLen ; lotCnt++ )
        {
            objLot_interFabXferState_Get_out strLot_interFabXferState_Get_out;

            objLot_interFabXferState_Get_in  strLot_interFabXferState_Get_in;
            strLot_interFabXferState_Get_in.lotID = strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID[lotCnt];

            rc = lot_interFabXferState_Get( strLot_interFabXferState_Get_out,
                                            strObjCommonIn,
                                            strLot_interFabXferState_Get_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_interFabXferState_Get() != RC_OK");
                strCassetteExchangeReqResult.strResult = strLot_interFabXferState_Get_out.strResult ;
                return rc;
            }

            if( 0 == CIMFWStrCmp(strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_OriginDeleting) )
            {
                PPT_METHODTRACE_V1(""," #### Lot State is 'OriginDeleting' Return error!");
                PPT_SET_MSG_RC_KEY( strCassetteExchangeReqResult,
                                    MSG_INTERFAB_INVALID_XFERSTATE_DELETING,
                                    RC_INTERFAB_INVALID_XFERSTATE_DELETING,
                                    strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID[lotCnt].identifier );
                return RC_INTERFAB_INVALID_XFERSTATE_DELETING;
            }
        }
    }
//DSIV00000214 add end

//PTR3000182     // 0.01 start
//PTR3000182     //------------------------------------------------------------
//PTR3000182     // Retrieve Equipment's onlineMode
//PTR3000182     //------------------------------------------------------------
//PTR3000182     objEquipment_onlineMode_Get_out strEquipment_onlineMode_Get_out;
//PTR3000182     strEquipment_onlineMode_Get_out.onlineMode =  CIMFWStrDup(SP_Eqp_OnlineMode_Offline);  //Initialize
//PTR3000182     if (CIMFWStrLen(equipmentID.identifier) != 0)
//PTR3000182     {
//PTR3000182         PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq", "CIMFWStrLen(equipmentID.identifier) != 0");
//PTR3000182         rc = equipment_onlineMode_Get( strEquipment_onlineMode_Get_out, strObjCommonIn,
//PTR3000182                                        equipmentID);
//PTR3000182         if (rc)
//PTR3000182         {
//PTR3000182             PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq", "equipment_onlineMode_Get() rc != RC_OK");
//PTR3000182             strCassetteExchangeReqResult.strResult = strEquipment_onlineMode_Get_out.strResult;
//PTR3000182             return( rc );
//PTR3000182         }
//PTR3000182     }
//PTR3000182     // 0.01 end
//PTR3000182
//PTR3000182     //------------------------------------------------------------
//PTR3000182     // If bNotifyToTCSFlag is true, Verify request inside of MM
//PTR3000182     // and notify to TCS
//PTR3000182     //------------------------------------------------------------
//PTR3000182 //0.01 if ( bNotifyToTCS == TRUE )
//PTR3000182 #if 0 //PTR3000182
//PTR3000182     if ( bNotifyToTCS == TRUE  &&                                                                       //0.01
//PTR3000182         CIMFWStrCmp(strEquipment_onlineMode_Get_out.onlineMode, SP_Eqp_OnlineMode_OnlineRemote) == 0)   //0.01
//PTR3000182     {
//PTR3000182         PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq", "bNotifyToTCS == TRUE  && onlineMode == SP_Eqp_OnlineMode_OnlineRemote");
//PTR3000182         objTCSMgr_SendCassetteExchangeReq_out strTCSMgr_SendCassetteExchangeReq_out;
//PTR3000182         rc = TCSMgr_SendCassetteExchangeReq(strTCSMgr_SendCassetteExchangeReq_out, strObjCommonIn,
//PTR3000182                                             strObjCommonIn.strUser, equipmentID,
//PTR3000182                                             strWaferXferSeq, claimMemo);
//PTR3000182
//PTR3000182         if (rc == RC_OK)
//PTR3000182         {
//PTR3000182             SET_MSG_RC(strCassetteExchangeReqResult, MSG_OK, RC_OK);
//PTR3000182             return( RC_OK );
//PTR3000182         }
//PTR3000182         else
//PTR3000182         {
//PTR3000182             PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq", "TCSMgr_SendCassetteExchangeReq() rc != RC_OK");
//PTR3000182             strCassetteExchangeReqResult.strResult = strTCSMgr_SendCassetteExchangeReq_out.strResult;
//PTR3000182             return( rc );
//PTR3000182         }
//PTR3000182     }
//PTR3000182     //------------------------------------------------------------
//PTR3000182     // If bNotifyToTCSFlag is false, Update MM Data and
//PTR3000182     // does not notify to TCS
//PTR3000182     //------------------------------------------------------------
//PTR3000182 //0.01 else
//PTR3000182     else if ( bNotifyToTCS != TRUE )   //0.01
//PTR3000182     {
//PTR3000182 #endif //PTR3000182

    PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq",
                       "bNotifyToTCS != TRUE  && onlineMode == SP_Eqp_OnlineMode_OnlineRemote");

    objSorter_waferTransferInfo_Restructure_out strSorter_waferTransferInfo_Restructure_out;
    rc = sorter_waferTransferInfo_Restructure(strSorter_waferTransferInfo_Restructure_out, strObjCommonIn,
                                              strWaferXferSeq);
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq",
                           "sorter_waferTransferInfo_Restructure() rc != RC_OK");
        strCassetteExchangeReqResult.strResult = strSorter_waferTransferInfo_Restructure_out.strResult;
        return( rc );
    }

    //------------------------------------------------------------
    // Check output parameter of sorter_waferTransferInfo_Restructure()
    //------------------------------------------------------------
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq",
                           "Check output parameter of sorter_waferTransferInfo_Restructure()");

        CORBA::Long nOutputLotLen = strSorter_waferTransferInfo_Restructure_out.strLotInventoryStateSeq.length();
        for(CORBA::Long i=0; i<nOutputLotLen; i++)
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "Lot ID     : ",
                               strSorter_waferTransferInfo_Restructure_out.strLotSeq[i].lotID.identifier);

            CORBA::Long nOutputWaferLen = strSorter_waferTransferInfo_Restructure_out.strLotSeq[i].strWafer.length();
            for(CORBA::Long j=0; j<nOutputWaferLen; j++)
            {
                PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "Wafer ID    : ",
                                   strSorter_waferTransferInfo_Restructure_out.strLotSeq[i].strWafer[j].waferID.identifier );
                PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "Slot Number : ",
                                   strSorter_waferTransferInfo_Restructure_out.strLotSeq[i].strWafer[j].slotNumber );
            }
        }
    }

//P4200277 add start
    //------------------------------------------------------------
    //   Reject if request lot is backup processing.
    //------------------------------------------------------------
    PPT_METHODTRACE_V1("", " ##### Reject if request lot is backup processing.");
    CORBA::Long lotLen = strSorter_waferTransferInfo_Restructure_out.strLotSeq.length();
    for(CORBA::Long count = 0 ; count < lotLen ; count++)
    {
        PPT_METHODTRACE_V2("", " ##### Check lotID = ",strSorter_waferTransferInfo_Restructure_out.strLotSeq[count].lotID.identifier);
        /*-----------------------------------*/
        /*   Check Backup Info               */
        /*-----------------------------------*/
        objLot_backupInfo_Get_out strLot_backupInfo_Get_out;
        rc = lot_backupInfo_Get( strLot_backupInfo_Get_out, strObjCommonIn,
                                 strSorter_waferTransferInfo_Restructure_out.strLotSeq[count].lotID);
        if (rc != RC_OK)
        {
            strCassetteExchangeReqResult.strResult = strLot_backupInfo_Get_out.strResult;
            return( rc );
        }
        else if( strLot_backupInfo_Get_out.strLotBackupInfo.currentLocationFlag == FALSE ||
                 strLot_backupInfo_Get_out.strLotBackupInfo.transferFlag        == TRUE )
        {
            PPT_SET_MSG_RC_KEY( strCassetteExchangeReqResult,
                                MSG_LOT_IN_OTHERSITE,
                                RC_LOT_IN_OTHERSITE,
                                strSorter_waferTransferInfo_Restructure_out.strLotSeq[count].lotID.identifier );
            return( RC_LOT_IN_OTHERSITE );
        }

    }
//P4200277 add end

    //---------------------------------------
    // At first, all relation between
    // carrier-wafer should be canceled
    // If bNotifyToTCS is true, Only Check Logic
    // works inside of wafer_materialContainer_Change()
    // or lot_materialContainer_Change()
    //---------------------------------------
    objectIdentifier newCassetteID;
//D7000092    CORBA::Long i = 0;
    CORBA::Long nILen = strSorter_waferTransferInfo_Restructure_out.strLotInventoryStateSeq.length();
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "nILen = ", nILen);
    for (i=0; i<nILen; i++)
    {
        if (CIMFWStrCmp(strSorter_waferTransferInfo_Restructure_out.strLotInventoryStateSeq[i],
                        SP_Lot_InventoryState_InBank) == 0)
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "strLotInventoryStateSeq == SP_Lot_InventoryState_InBank", i);
            CORBA::Long j = 0;
            CORBA::Long nJLen = strSorter_waferTransferInfo_Restructure_out.strLotSeq[i].strWafer.length();
            PPT_METHODTRACE_V3("CS_PPTManager_i:: txCassetteExchangeReq", "nJLen = ", nJLen, i);
            for (j=0; j<nJLen; j++)
            {
                objWafer_materialContainer_Change_out strWafer_materialContainer_Change_out;
                rc = wafer_materialContainer_Change(strWafer_materialContainer_Change_out, strObjCommonIn,
                                                    newCassetteID,
                                                    strSorter_waferTransferInfo_Restructure_out.strLotSeq[i].strWafer[j]);
                    // Input parameter
                    //  - equipmentID = input equipmentID
                    //  - newCassetteID = null
                    //  - strWafer = strSorter_waferTransferInfo_Restructure_out.strLotSeq[i].strWafer[j]
                    //  - bNotifyToTCS = input bNotifyToTCS
                if (rc)
                {
                    PPT_METHODTRACE_V3("CS_PPTManager_i:: txCassetteExchangeReq", "wafer_materialContainer_Change() rc != RC_OK", i, j);
                    strCassetteExchangeReqResult.strResult = strWafer_materialContainer_Change_out.strResult;
                    return( rc );
                }
            }
        }
        else
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "strLotInventoryStateSeq != SP_Lot_InventoryState_InBank", i);
            objLot_materialContainer_Change_out strLot_materialContainer_Change_out;
            rc = lot_materialContainer_Change(strLot_materialContainer_Change_out, strObjCommonIn,
                                              newCassetteID,
                                              strSorter_waferTransferInfo_Restructure_out.strLotSeq[i]);
                // Input parameter
                //  - equipmentID = input equipmentID
                //  - newCassetteID = null
                //  - strLot = strSorter_waferTransferInfo_Restructure_out.strLotSeq[i]
                //  - bNotifyToTCS = input bNotifyToTCS
            if (rc)
            {
                PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "lot_materialContainer_Change() rc != RC_OK", i);
                strCassetteExchangeReqResult.strResult = strLot_materialContainer_Change_out.strResult;
                return( rc );
            }
        }
    }

    //---------------------------------------
    // Next, new relation between
    // carrier-wafer should be created
    //---------------------------------------
    nILen = strSorter_waferTransferInfo_Restructure_out.strLotInventoryStateSeq.length();
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "nILen = ", nILen);
    for (i=0; i<nILen; i++)
    {
        if (CIMFWStrCmp(strSorter_waferTransferInfo_Restructure_out.strLotInventoryStateSeq[i],
                        SP_Lot_InventoryState_InBank) == 0)
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "strLotInventoryStateSeq == SP_Lot_InventoryState_InBank = ", i);
            CORBA::Long j = 0;
            CORBA::Long nJLen = strSorter_waferTransferInfo_Restructure_out.strLotSeq[i].strWafer.length();
            PPT_METHODTRACE_V3("CS_PPTManager_i:: txCassetteExchangeReq", "nJLen = ", nJLen, i);
            for (j=0; j<nJLen; j++)
            {
                objWafer_materialContainer_Change_out strWafer_materialContainer_Change_out;
                rc = wafer_materialContainer_Change(strWafer_materialContainer_Change_out, strObjCommonIn,
                                                    strSorter_waferTransferInfo_Restructure_out.cassetteIDSeq[i],
                                                    strSorter_waferTransferInfo_Restructure_out.strLotSeq[i].strWafer[j]);
                    // Input parameter
                    //  - equipmentID = input equipmentID
                    //  - newCassetteID = strSorter_waferTransferInfo_Restructure_out.cassetteIDSeq[i]
                    //  - strWafer = strSorter_waferTransferInfo_Restructure_out.strLotSeq[i].strWafer[j]
                if (rc)
                {
                    PPT_METHODTRACE_V3("CS_PPTManager_i:: txCassetteExchangeReq", "wafer_materialContainer_Change() rc != RC_OK", i, j);
                    strCassetteExchangeReqResult.strResult = strWafer_materialContainer_Change_out.strResult;
                    return( rc );
                }
            }
        }
        else
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "strLotInventoryStateSeq != SP_Lot_InventoryState_InBank = ", i);
            objLot_materialContainer_Change_out strLot_materialContainer_Change_out;
            rc = lot_materialContainer_Change(strLot_materialContainer_Change_out, strObjCommonIn,
                                              strSorter_waferTransferInfo_Restructure_out.cassetteIDSeq[i],
                                              strSorter_waferTransferInfo_Restructure_out.strLotSeq[i]);
                // Input parameter
                //  - equipmentID = input equipmentID
                //  - newCassetteID = strSorter_waferTransferInfo_Restructure_out.cassetteIDSeq[i]
                //  - strLot = strSorter_waferTransferInfo_Restructure_out.strLotSeq[i]
            if (rc)
            {
                PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "lot_materialContainer_Change() rc != RC_OK", i);
                strCassetteExchangeReqResult.strResult = strLot_materialContainer_Change_out.strResult;
                return( rc );
            }
        }
    }

    //---------------------------------------
    // Collect Cassette IDs of input parameter
    //---------------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq", "Collect Cassette IDs of input parameter");
    objectIdentifierSequence cassetteIDSeq;
    CORBA::Long lastEntity = 0;
    nILen = strWaferXferSeq.length();
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "nILen = ", nILen);
    for (i=0; i<nILen; i++)
    {
        CORBA::Boolean bCassetteAdded = FALSE;
        CORBA::Long j = 0;
        CORBA::Long nJLen = cassetteIDSeq.length();
        PPT_METHODTRACE_V3("CS_PPTManager_i:: txCassetteExchangeReq", "nJLen = ", nJLen, i);
        for (j=0; j<nJLen; j++)
        {
            if (CIMFWStrCmp(strWaferXferSeq[i].destinationCassetteID.identifier,
                            cassetteIDSeq[j].identifier) == 0)
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq", "braek!!");
                bCassetteAdded = TRUE;
                break;
            }
        }
        if (bCassetteAdded == FALSE)
        {
            PPT_METHODTRACE_V3("CS_PPTManager_i:: txCassetteExchangeReq",
                               "bCassetteAdded == FALSE",
                               lastEntity, strWaferXferSeq[i].destinationCassetteID.identifier);
            lastEntity = cassetteIDSeq.length();
            lastEntity++;
            cassetteIDSeq.length(lastEntity);
            cassetteIDSeq[lastEntity - 1] = strWaferXferSeq[i].destinationCassetteID;
        }

        bCassetteAdded = FALSE;
        nJLen = cassetteIDSeq.length();
        for (j=0; j<nJLen; j++)
        {
            if (CIMFWStrCmp(strWaferXferSeq[i].originalCassetteID.identifier,
                            cassetteIDSeq[j].identifier) == 0)
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq", "break!!");
                bCassetteAdded = TRUE;
                break;
            }
        }
        if (bCassetteAdded == FALSE)
        {
            PPT_METHODTRACE_V3("CS_PPTManager_i:: txCassetteExchangeReq",
                               "bCassetteAdded == FALSE",
                               lastEntity, strWaferXferSeq[i].originalCassetteID.identifier);
            lastEntity = cassetteIDSeq.length();
            lastEntity++;
            cassetteIDSeq.length(lastEntity);
            cassetteIDSeq[lastEntity - 1] = strWaferXferSeq[i].originalCassetteID;
        }
    }

    //PTR3000181 Start
    //---------------------------------------
    // Update Machine/ControlJob information
    //---------------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq", "Call controlJob_relatedInfo_Update");
    objControlJob_relatedInfo_Update_out strControlJob_relatedInfo_Update_out;
    rc = controlJob_relatedInfo_Update( strControlJob_relatedInfo_Update_out,
                                        strObjCommonIn,
                                        cassetteIDSeq );
    if (rc)
    {
        PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "controlJob_relatedInfo_Update() rc != RC_OK", i);
        strCassetteExchangeReqResult.strResult = strControlJob_relatedInfo_Update_out.strResult;
        return( rc );
    }
    //PTR3000181 End

    //DCR4000015 Start
    //---------------------------------------
    // Check equipment allow early carrier out or not
    //---------------------------------------
//D6000479 move to the top of the objmethod.
//D6000479    PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq", "Check equipment allow early carrier out or not");
//D6000479
//D6000479    objEquipment_CheckConditionForEmptyCassetteEarlyOut_out strEquipment_CheckConditionForEmptyCassetteEarlyOut_out;
//D6000479    CORBA::Long tmpRc = equipment_CheckConditionForEmptyCassetteEarlyOut(
//D6000479                              strEquipment_CheckConditionForEmptyCassetteEarlyOut_out,
//D6000479                              strObjCommonIn,
//D6000479                              equipmentID );

    if( tmpRc == RC_OK )
    {
        //---------------------------------------
        // Remove empty cassette from Control Job if equipment configuration allow
        //---------------------------------------
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq", "Remove empty cassette from Control Job if equipment configuration allow");

        objControlJob_emptyCassetteInfo_Delete_out strControlJob_emptyCassetteInfo_Delete_out;
        rc = controlJob_emptyCassetteInfo_Delete( strControlJob_emptyCassetteInfo_Delete_out,
                                                  strObjCommonIn,
                                                  cassetteIDSeq );

        if (rc)
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "controlJob_emptyCassetteInfo_Delete() rc != RC_OK", i);
            strCassetteExchangeReqResult.strResult = strControlJob_emptyCassetteInfo_Delete_out.strResult;
            return( rc );
        }
    }
    //DCR4000015 End

    //---------------------------------------
    // Update MultiLotType of Carrier
    //---------------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq", "Update MultiLotType of Carrier");

    nILen = cassetteIDSeq.length();
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "nILen = ", nILen);
    for (i=0; i<nILen; i++)
    {
        objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
        rc = cassette_multiLotType_Update( strCassette_multiLotType_Update_out,
                                           strObjCommonIn,
                                           cassetteIDSeq[i] );

        if (rc != RC_OK && rc != RC_NOT_FOUND_CASSETTE)
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "cassette_multiLotType_Update() rc != RC_OK and rc != RC_NOT_FOUND_CASSETTE", i);
            strCassetteExchangeReqResult.strResult = strCassette_multiLotType_Update_out.strResult;
            return( rc );
        }
    }

//D6000478 add start
    //---------------------------------------
    // Update WaferLotHistoryPointer of Lot
    //---------------------------------------
    PPT_METHODTRACE_V1("", "Update WaferLotHistoryPointer of Lot");

    for (i=0; i<lotLen; i++)
    {
        PPT_METHODTRACE_V2("", " ##### Update lotID = ",strSorter_waferTransferInfo_Restructure_out.strLotSeq[i].lotID.identifier);

        objLot_waferLotHistoryPointer_Update_out strLot_waferLotHistoryPointer_Update_out;
        rc = lot_waferLotHistoryPointer_Update( strLot_waferLotHistoryPointer_Update_out,
                                                strObjCommonIn,
                                                strSorter_waferTransferInfo_Restructure_out.strLotSeq[i].lotID );
        if (rc)
        {
            PPT_METHODTRACE_V1("", "lot_waferLotHistoryPointer_Update() rc != RC_OK");
            strCassetteExchangeReqResult.strResult = strLot_waferLotHistoryPointer_Update_out.strResult;
            return( rc );
        }
    }
//D6000478 add end

    //---------------------------------------
    // Prepare input parameter of lotWaferSortEvent_Make()
    //---------------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq", "Prepare input parameter of lotWaferSortEvent_Make()");
    pptWaferTransferSequence tmpWaferXferSeq;
    tmpWaferXferSeq = strWaferXferSeq;
    nILen = tmpWaferXferSeq.length();
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txCassetteExchangeReq", "nILen = ", nILen);
    for (i=0; i<nILen; i++)
    {
        CORBA::Boolean bStringifiedObjRefFilled = FALSE;
        CORBA::Long j = 0;
        CORBA::Long nJLen = strSorter_waferTransferInfo_Restructure_out.strLotSeq.length();
        PPT_METHODTRACE_V3("CS_PPTManager_i:: txCassetteExchangeReq", "nJLen = ", nJLen, i);
        for (j=0; j<nJLen; j++)
        {
            CORBA::Long k = 0;
            CORBA::Long nKLen = strSorter_waferTransferInfo_Restructure_out.strLotSeq[j].strWafer.length();
            PPT_METHODTRACE_V4("CS_PPTManager_i:: txCassetteExchangeReq", "nKLen = ", nKLen, i, j);
            for (k=0; k<nKLen; k++)
            {
                if (CIMFWStrCmp(tmpWaferXferSeq[i].waferID.identifier,
                                strSorter_waferTransferInfo_Restructure_out.strLotSeq[j].strWafer[k].waferID.identifier) == 0)
                {
                    tmpWaferXferSeq[i].waferID.stringifiedObjectReference
                        = strSorter_waferTransferInfo_Restructure_out.strLotSeq[j].strWafer[k].waferID.stringifiedObjectReference;
                    bStringifiedObjRefFilled = TRUE;
                    break;
                }
            }
            if (bStringifiedObjRefFilled == TRUE)
            {
                break;
            }
        }
    }

    //---------------------------------------
    // Create Wafer Sort Event
    //---------------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq", "Create Wafer Sort Event");
    objLotWaferSortEvent_Make_out strLotWaferSortEvent_Make_out;
    rc = lotWaferSortEvent_Make(strLotWaferSortEvent_Make_out, strObjCommonIn,
                                         "TXPCC001", tmpWaferXferSeq, claimMemo);
        // Use tmpWaferXferSeq for input parameter
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq", "lotWaferSortEvent_Make() rc != RC_OK");
        strCassetteExchangeReqResult.strResult = strLotWaferSortEvent_Make_out.strResult;
        return( rc );
    }

//PTR3000182 #if 0 //PTR3000182
//PTR3000182     }
//PTR3000182     //0.01 Start
//PTR3000182     else
//PTR3000182     {
//PTR3000182         PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteExchangeReq", "onlineMode is not SP_Eqp_OnlineMode_OnlineRemote");
//PTR3000182         PPT_SET_MSG_RC_KEY2(strCassetteExchangeReqResult, MSG_INVALID_SORTER_OPERATION, RC_INVALID_SORTER_OPERATION,
//PTR3000182                             strEquipment_onlineMode_Get_out.onlineMode,
//PTR3000182                             equipmentID.identifier);
//PTR3000182         return( RC_INVALID_SORTER_OPERATION );
//PTR3000182     }
//PTR3000182     //0.01 End
//PTR3000182 #endif //PTR3000182

    SET_MSG_RC(strCassetteExchangeReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txCassetteExchangeReq");
    return(RC_OK);
}

