#ifndef lint
static char *sccsid =  "@(#) 1.4 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txCassetteStatusInq__170OR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/22/07 17:30:25 [ 11/22/07 17:30:27 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cs_txCassetteStatusInq__170OR.cpp
//

#include "cs_pptmgr.hpp"
#include "pptconvert.h"

// Class: CS_PPTManager
//
// Service: txCassetteStatusInq__170()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/09/12 P3000139 O.Sugiyama     add SET_MSG_RC
// 2000/09/18 P3000139 T.Yamano       add SET_MSG_RC
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// ------------------------------------------------------------------------------
// 2007/06/20 D9000005 K.Kido         Intitial release for Wafer Sorter automation (AAS support).
// 2007/08/03 D9000056 H.Hotta        PostProcess performance improvement.
// -------------------------------------------------------------------------------
// 2008/06/23 DSIV00000099  M.Murata  SLM(Small Lot Manufacturing) Support.
// 2011/09/21 DSN000020767  T.Ishida  Auto Dispatch Control Support
// 2014/12/18 DSN000085770  C.Mo      Durable Control Job Management support.
// 2015/06/16 DSN000096126  C.Mo      Durable Process Flow Control Support.
// 2016/06/29 DSN000101569  C.Mo      Durable Sub Status Control Support.
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/08/28 INN-R170002  Yangxiaojun    Overide txCassetteStatusInq__170
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptCassetteStatusInqResult__170& strCassetteStatusInqResult
//     const pptObjCommonIn&   strObjCommonIn
//     const objectIdentifier& cassetteID
//     CORBA::Boolean          durableOperationInfoFlag
//     CORBA::Boolean          durableWipOperationInfoFlag
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

//D6000025 CORBA::Long CS_PPTManager_i::txCassetteStatusInq__090 (pptCassetteStatusInqResult& strCassetteStatusInqResult, const pptObjCommonIn& strObjCommonIn,  const objectIdentifier& cassetteID,  CORBA::Environment &IT_env)
//DSN000085770 CORBA::Long CS_PPTManager_i::txCassetteStatusInq__120 (
//DSN000085770        pptCassetteStatusInqResult__120&  strCassetteStatusInqResult,
//DSN000101569 CORBA::Long CS_PPTManager_i::txCassetteStatusInq__160 (                   //DSN000085770
//DSN000101569         pptCassetteStatusInqResult__160&  strCassetteStatusInqResult,  //DSN000085770
CORBA::Long CS_PPTManager_i::txCassetteStatusInq__170 (                                                                            //DSN000101569
        pptCassetteStatusInqResult__170&  strCassetteStatusInqResult,                                                           //DSN000101569
        const pptObjCommonIn&             strObjCommonIn,
//DSN000096126        const objectIdentifier&           cassetteID
        const objectIdentifier& cassetteID,        //DSN000096126
        CORBA::Boolean durableOperationInfoFlag,   //DSN000096126
        CORBA::Boolean durableWipOperationInfoFlag //DSN000096126
        CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txCassetteStatusInq__170");
    CORBA::Long rc = RC_OK ;

//DSIV00000099    objCassette_FillInTxPDQ008DR_out strCassette_FillInTxPDQ008DR_out ;
//DSIV00000099    rc = cassette_FillInTxPDQ008DR(strCassette_FillInTxPDQ008DR_out,strObjCommonIn,cassetteID) ;
//DSIV00000099
//DSIV00000099    if ( rc != RC_OK )
//DSIV00000099    {
//DSIV00000099        PPT_METHODTRACE_V1("CS_PPTManager_i:: txCassetteStatusInq__100", "rc != RC_OK")
//DSIV00000099        strCassetteStatusInqResult.strResult = strCassette_FillInTxPDQ008DR_out.strResult ;
//DSIV00000099        return( rc );
//DSIV00000099    }
//DSN000020767//DSIV00000099 add start
//DSN000020767    //-----------------------------------------------------------------------
//DSN000020767    // cassette_FillInTxPDQ008DR() --->>> cassette_DBInfo_GetDR__100()
//DSN000020767    //-----------------------------------------------------------------------
//DSN000020767    objCassette_DBInfo_GetDR_out__100 strCassette_DBInfo_GetDR_out;
//DSN000020767    objCassette_DBInfo_GetDR_in__100  strCassette_DBInfo_GetDR_in;
//DSN000020767    strCassette_DBInfo_GetDR_in.cassetteID = cassetteID;

//DSN000020767    rc = cassette_DBInfo_GetDR__100(strCassette_DBInfo_GetDR_out, strObjCommonIn, strCassette_DBInfo_GetDR_in);
//DSN000020767    if ( rc != RC_OK )
//DSN000020767    {
//DSN000020767        PPT_METHODTRACE_V2("", "cassette_DBInfo_GetDR__100() != RC_OK",rc);
//DSN000020767        strCassetteStatusInqResult.strResult = strCassette_DBInfo_GetDR_out.strResult ;
//DSN000020767        return( rc );
//DSN000020767    }
//DSN000020767    strCassetteStatusInqResult = strCassette_DBInfo_GetDR_out.strCassetteStatusInqResult;
//DSN000020767//DSIV00000099 add end

    //DSN000020767 Add Start
    //-----------------------------------------------------------------------
    // cassette_DBInfo_GetDR__100() --->>> cassette_DBInfo_GetDR__120()
    //-----------------------------------------------------------------------
//DSN000085770    objCassette_DBInfo_GetDR_out__120 strCassette_DBInfo_GetDR_out;
//DSN000101569    objCassette_DBInfo_GetDR_out__160 strCassette_DBInfo_GetDR_out; //DSN000085770
    objCassette_DBInfo_GetDR_out__170 strCassette_DBInfo_GetDR_out;                                                             //DSN000101569
//DSN000096126    objCassette_DBInfo_GetDR_in__100  strCassette_DBInfo_GetDR_in;
    objCassette_DBInfo_GetDR_in__160  strCassette_DBInfo_GetDR_in;                         //DSN000096126
    strCassette_DBInfo_GetDR_in.cassetteID = cassetteID;
    strCassette_DBInfo_GetDR_in.durableOperationInfoFlag = durableOperationInfoFlag;       //DSN000096126
    strCassette_DBInfo_GetDR_in.durableWipOperationInfoFlag = durableWipOperationInfoFlag; //DSN000096126

//DSN000085770    rc = cassette_DBInfo_GetDR__120(strCassette_DBInfo_GetDR_out, strObjCommonIn, strCassette_DBInfo_GetDR_in);
//DSN000101569    rc = cassette_DBInfo_GetDR__160(strCassette_DBInfo_GetDR_out, strObjCommonIn, strCassette_DBInfo_GetDR_in); //DSN000085770
    rc = cassette_DBInfo_GetDR__170(strCassette_DBInfo_GetDR_out, strObjCommonIn, strCassette_DBInfo_GetDR_in);                 //DSN000101569
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cassette_DBInfo_GetDR__170() != RC_OK",rc);
        strCassetteStatusInqResult.strResult = strCassette_DBInfo_GetDR_out.strResult ;
        return( rc );
    }
    strCassetteStatusInqResult = strCassette_DBInfo_GetDR_out.strCassetteStatusInqResult;
//DSN000020767 Add End

//D9000005    strCassetteStatusInqResult = strCassette_FillInTxPDQ008DR_out.strCassetteStatusInqResult ;
//P3000139    strCassetteStatusInqResult.strResult = strCassette_FillInTxPDQ008DR_out.strResult ;
//D9000005 add start
//DSIV00000099     PPTConvert conv(strCassette_FillInTxPDQ008DR_out.strCassetteStatusInqResult);
//DSIV00000099     strCassetteStatusInqResult = conv;

    /*********************************************/
    /* Get sorter information for the Cassette.  */
    /*********************************************/
    objSorter_jobList_GetDR_in strSorter_jobList_GetDR_in;
    objSorter_jobList_GetDR_out strSorter_jobList_GetDR_out;

    strSorter_jobList_GetDR_in.carrierID = cassetteID;
    rc = sorter_jobList_GetDR( strSorter_jobList_GetDR_out,
                               strObjCommonIn,
                               strSorter_jobList_GetDR_in );

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "sorter_jobList_GetDR() != RC_OK");
        strCassetteStatusInqResult.strResult = strSorter_jobList_GetDR_out.strResult ;
        return rc;
    }

    if( 0 != strSorter_jobList_GetDR_out.strSortJobListAttributesSeq.length() )
    {
        strCassetteStatusInqResult.cassetteStatusInfo.sorterJobExistFlag = TRUE;
    }
    else
    {
        strCassetteStatusInqResult.cassetteStatusInfo.sorterJobExistFlag = FALSE;
    }
//D9000005 add end

//D9000056 add start
    //---------------------------------------
    //  Get InPostProcessFlag of Cassette
    //---------------------------------------
    objCassette_inPostProcessFlag_Get_out  strCassette_inPostProcessFlag_Get_out;
    objCassette_inPostProcessFlag_Get_in   strCassette_inPostProcessFlag_Get_in;
    strCassette_inPostProcessFlag_Get_in.cassetteID = cassetteID;

    rc = cassette_inPostProcessFlag_Get( strCassette_inPostProcessFlag_Get_out,
                                         strObjCommonIn,
                                         strCassette_inPostProcessFlag_Get_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cassette_inPostProcessFlag_Get() != RC_OK");
        strCassetteStatusInqResult.strResult = strCassette_inPostProcessFlag_Get_out.strResult;
        return( rc );
    }

    strCassetteStatusInqResult.cassetteStatusInfo.inPostProcessFlagOfCassette= strCassette_inPostProcessFlag_Get_out.inPostProcessFlagOfCassette;
    PPT_METHODTRACE_V2("", "inPostProcessFlagOfCassette", strCassetteStatusInqResult.cassetteStatusInfo.inPostProcessFlagOfCassette);
//D9000056 add end


    SET_MSG_RC(strCassetteStatusInqResult, MSG_OK, RC_OK); //P3000139

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txCassetteStatusInq__170")
    return( RC_OK );
}
