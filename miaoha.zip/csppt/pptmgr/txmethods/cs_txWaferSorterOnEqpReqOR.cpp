#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txWaferSorterOnEqpReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:41:01 [ 7/13/07 21:41:02 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2012. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2012. All rights reserved.
//
// SiView Standard
// Name:txWaferSorterOnEqpReq.cpp
//

//INN-R17001 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp" //INN-R17001


#include <unistd.h>

// PPT Service Manager - Transaction Method Design
//
//
// Subsystem Name      : PPT Service Manager
// TX Method ID        : TXTRC059
// TX Method Name      : txWaferSorterOnEqpReq
// Process Description : send WaferSort Request to TCS
//
// TX Generates Return Code and Message :
//
// Return Code                             Message
// --------------------------------------- ---------------------------------------
//
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2001-07/12  D4000056  Y.Yoshihara    Initial Release
// 2001-08-08  D4000056  Y.Yoshihara    Change Inparameter
// 2001-08-20  P4000099  Y.Yoshihara    Change objectName
// 2001-08-21  D4000056  Y.Yoshihara    Add check TX Combination
// 2001-08-22  D4000056  Y.Yoshihara    Add return code output routine
// 2001-08-23  D4000056  Y.Yoshihara    Change parameter of waferSorter_slotMap_SelectDR
// 2001-08-24  D4000056  Y.Yoshihara    Change logic
// 2001-08-27  D4000056  Y.Yoshihara    Change structure send to TCS
//                                      Temporary Change ( If TCS Resource is blank, then continue)
// 2001-08-28  D4000056  Y.Yoshihara    Add physicalRecipeID to inpara
// 2001/09/07  D4000060  K.Kido         Add retry TCS request logic 
// 2001/10/02  P4000302  M.Shimizu      Add Logic to Check Cassette Status 
// 2001/10/02  P4000309  M.Shimizu      Add Logic to initialization
// 2001/10/11  P4000346  M.Shimizu      Add Logic to Check Cassette Status for AdjustToMM. 
// 2001/10/23  D4000234  M.Shimizu      Add a Action Code 'AdjustToSorter. 
// 2002/01/16  P4100078  K.Matsuei      Mistake of Structure to set in SmallTx.
// 2003/09/08  P5000145  H.Adachi       Fix Message and Message Macro mismatch.
// 2004/10/22  D6000025  K.Murakami     eBroker Migration.
// 2007/04/20  D9000001  H.Murakami     64bit support.
// 2007/06/20  D9000005  K.Kido         Wafer Sort automation support.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/11/02 DSIV00000214 K.Kido         Multi Fab support.
// 2012/12/04 DSN000049350 K.Yamaoku      Equipment parallel processing support (P2)
//
// 
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/26 INN-R170017  Evie Su        Add BWSIn/BWSOut logic
//

//===========================================================
//
//        Private Method : txWaferSorterOnEqpReq
//
//===========================================================
//INN-R170017 CORBA::Long PPTManager_i::txWaferSorterOnEqpReq ( 
CORBA::Long CS_PPTManager_i::txWaferSorterOnEqpReq ( //INN-R170017
    pptWaferSorterOnEqpReqResult&        strWaferSorterOnEqpReqResult,
    const pptObjCommonIn&                strObjCommonIn,
    const pptUser&                       requestUserID,
    const char *                         actionCode,
    const objectIdentifier&              equipmentID,
    const pptWaferSorterSlotMapSequence& strWaferSorterSlotMapSequence,
    const char *                         portGroup,
    const char *                         physicalRecipeID,
//D6000025     const char *                         claimMemo,
//D6000025     CORBA::Environment &                 IT_env)
    const char *                         claimMemo //D6000025
    CORBAENV_LAST_CPP)                             //D6000025
{
    PPT_METHODTRACE_ENTRY("PPTManager_i:: txWaferSorterOnEqpReq") ;

    PPT_METHODTRACE_V2("", "in para equipmentID ",equipmentID.identifier );
    PPT_METHODTRACE_V2("", "in para actionCode",  actionCode);
    PPT_METHODTRACE_V2("", "in para portGroupID", portGroup);
    PPT_METHODTRACE_V2("", "in para physicalRecipeID", physicalRecipeID);
    PPT_METHODTRACE_V2("", "in para userID",      strObjCommonIn.strUser.userID.identifier);

    CORBA::Long i = 0;
    CORBA::Long len = strWaferSorterSlotMapSequence.length();

    // --------------------------------------------------------------
    // Check All Data in Structure Sequence
    // --------------------------------------------------------------
    for( i = 0; i < len ; i++)
    {
        PPT_METHODTRACE_V1("LOOP START","-----------------------------------------------------------------------");
        PPT_METHODTRACE_V1("Loop Count is ",i);
        PPT_METHODTRACE_V1("portGroup",strWaferSorterSlotMapSequence[i].portGroup);
        PPT_METHODTRACE_V1("equipmentID",strWaferSorterSlotMapSequence[i].equipmentID.identifier);
        PPT_METHODTRACE_V1("actionCode",strWaferSorterSlotMapSequence[i].actionCode);
        PPT_METHODTRACE_V1("requestTime",strWaferSorterSlotMapSequence[i].requestTime);
        PPT_METHODTRACE_V1("direction",strWaferSorterSlotMapSequence[i].direction);
        PPT_METHODTRACE_V1("waferID",strWaferSorterSlotMapSequence[i].waferID.identifier);
        PPT_METHODTRACE_V1("lotID",strWaferSorterSlotMapSequence[i].lotID.identifier);
        PPT_METHODTRACE_V1("destinationCassetteID",strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier);
        PPT_METHODTRACE_V1("destinationPortID",strWaferSorterSlotMapSequence[i].destinationPortID.identifier);
        if(strWaferSorterSlotMapSequence[i].bDestinationCassetteManagedBySiView==TRUE)
        {
            PPT_METHODTRACE_V1("bDestinationCassetteManagedBySiView:","TRUE");
        }
        else if(strWaferSorterSlotMapSequence[i].bDestinationCassetteManagedBySiView==FALSE)
        {
            PPT_METHODTRACE_V1("bDestinationCassetteManagedBySiView:","FALSE");
        }
        else
        {
            PPT_METHODTRACE_V1("bDestinationCassetteManagedBySiView:","???");
        }
        PPT_METHODTRACE_V1("destinationSlotNumber",strWaferSorterSlotMapSequence[i].destinationSlotNumber);
        PPT_METHODTRACE_V1("originalCassetteID",strWaferSorterSlotMapSequence[i].originalCassetteID.identifier);
        PPT_METHODTRACE_V1("originalPortID",strWaferSorterSlotMapSequence[i].originalPortID.identifier);
        if(strWaferSorterSlotMapSequence[i].bOriginalCassetteManagedBySiView==TRUE)
        {
            PPT_METHODTRACE_V1("bOriginalCassetteManagedBySiView:","TRUE");
        }
        else if(strWaferSorterSlotMapSequence[i].bOriginalCassetteManagedBySiView==FALSE)
        {
            PPT_METHODTRACE_V1("bOriginalCassetteManagedBySiView:","FALSE");
        }
        else
        {
            PPT_METHODTRACE_V1("bOriginalCassetteManagedBySiView:","???"); 
        }
        PPT_METHODTRACE_V1("originalSlotNumber",strWaferSorterSlotMapSequence[i].originalSlotNumber);
        PPT_METHODTRACE_V1("requestUserID",strWaferSorterSlotMapSequence[i].requestUserID.identifier);
        PPT_METHODTRACE_V1("replyTime",strWaferSorterSlotMapSequence[i].replyTime);
        PPT_METHODTRACE_V1("sorterStatus",strWaferSorterSlotMapSequence[i].sorterStatus);
        PPT_METHODTRACE_V1("slotMapCompareStatus",strWaferSorterSlotMapSequence[i].slotMapCompareStatus);
        PPT_METHODTRACE_V1("mmCompareStatus",strWaferSorterSlotMapSequence[i].mmCompareStatus);
        PPT_METHODTRACE_V1("LOOP END","-----------------------------------------------------------------------");
    }
 
    //--------------
    // Initialize
    //--------------
    CORBA::Long rc = RC_OK;
    objectIdentifierSequence     cassetteIDs;
    pptWaferSorterSlotMap        strWaferSorterSlotMap;

//DSIV00000214 add start
    //-----------------------------------------
    // collect SiView managed casettes only.
    //-----------------------------------------
    CORBA::Long  waferMapLen = strWaferSorterSlotMapSequence.length();
    CORBA::Long  casLen = 0;
    cassetteIDs.length(waferMapLen * 2);

    for( i=0; i<waferMapLen; i++ )
    {
        // collect SiView managed casettes only.
        if( strWaferSorterSlotMapSequence[i].bOriginalCassetteManagedBySiView == TRUE )
        {
            CORBA::Boolean dupCastFlag = FALSE ;
            for(CORBA::ULong j= 0 ; j < casLen ; j++ )
            {
                if(0 == CIMFWStrCmp( cassetteIDs[j].identifier, strWaferSorterSlotMapSequence[i].originalCassetteID.identifier))
                {
                    dupCastFlag = TRUE;
                    break;
                }
            }
            if( FALSE == dupCastFlag )
            {
                cassetteIDs[casLen] = strWaferSorterSlotMapSequence[i].originalCassetteID;
                PPT_METHODTRACE_V2("","SiView managed original cassette found.", cassetteIDs[casLen].identifier);
                casLen++;
            }
        }
        if( strWaferSorterSlotMapSequence[i].bDestinationCassetteManagedBySiView == TRUE )
        {
            CORBA::Boolean dupCastFlag = FALSE ;
            for(CORBA::ULong j= 0 ; j < casLen ; j++ )
            {
                if(0 == CIMFWStrCmp( cassetteIDs[j].identifier, strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier))
                {
                    dupCastFlag = TRUE;
                    break;
                }
            }
            if( FALSE == dupCastFlag )
            {
                cassetteIDs[casLen] = strWaferSorterSlotMapSequence[i].destinationCassetteID;
                PPT_METHODTRACE_V2("","SiView managed destination cassette found.", cassetteIDs[casLen].identifier);
                casLen++;
            }
        }
    }
    cassetteIDs.length(casLen);
//DSIV00000214 add end

//DSN000049350 Add Start
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;

    CORBA::Long sorterJobLockFlag = atoi( getenv(SP_SORTERJOB_LOCK_FLAG) );
    PPT_METHODTRACE_V2("","sorterJobLockFlag", sorterJobLockFlag);
    CORBA::Long lockMode = SP_EQP_LOCK_MODE_WRITE;

    if ( 1 == sorterJobLockFlag )
    {
        PPT_METHODTRACE_V1("","sorterJobLockFlag = 1");

        // Get required equipment lock mode
        strObject_lockMode_Get_in.objectID           = equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( SP_FunctionCategory_SorterTxID ); // SorterTxID
        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strWaferSorterOnEqpReqResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }
        lockMode = strObject_lockMode_Get_out.lockMode;
    }
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
//DSN000049350 Add End

//D9000005 add start
    if( 0 == CIMFWStrCmp( actionCode, SP_Sorter_AutoSorting ) )
    {
        //--------------------------------------------------------------
        //  Check inpurt parameters length
        //--------------------------------------------------------------
        if( len == 0 )
        {
            SET_MSG_RC( strWaferSorterOnEqpReqResult,
                        MSG_INVALID_INPUT_PARM,
                        RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

//DSN000049350 Add Start
        if ( 1 == sorterJobLockFlag )
        {
            PPT_METHODTRACE_V1("","sorterJobLockFlag = 1");

            //---------------------------------
            // Lock Sort Jobs
            //---------------------------------
            objectIdentifier dummyID;
            objSorter_sorterJob_LockDR_out strSorter_sorterJob_LockDR_out;
            objSorter_sorterJob_LockDR_in strSorter_sorterJob_LockDR_in;
            strSorter_sorterJob_LockDR_in.sorterJobID          = dummyID;
            strSorter_sorterJob_LockDR_in.sorterComponentJobID = dummyID;
            strSorter_sorterJob_LockDR_in.cassetteID           = cassetteIDs[0];
            strSorter_sorterJob_LockDR_in.lockType             = SP_ObjectLock_LockType_WRITE;

            PPT_METHODTRACE_V1( "", "calling sorter_sorterJob_LockDR()" );
            rc = sorter_sorterJob_LockDR ( strSorter_sorterJob_LockDR_out,
                                           strObjCommonIn,
                                           strSorter_sorterJob_LockDR_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "sorter_sorterJob_LockDR() != RC_OK", rc);
                strWaferSorterOnEqpReqResult.strResult = strSorter_sorterJob_LockDR_out.strResult;
                return( rc );
            }
        }
        if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
        {
            PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

            // Lock Equipment Main Object
            stringSequence dummySeq;
            dummySeq.length(0);
            strAdvanced_object_Lock_in.objectID   = equipmentID;
            strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
            strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
            strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
            strAdvanced_object_Lock_in.keySeq     = dummySeq;

            PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
            rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                        strObjCommonIn,
                                        strAdvanced_object_Lock_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                strWaferSorterOnEqpReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                return( rc );
            }
            
            if (0 < cassetteIDs.length())
            {
                // Lock Equipment LoadCassette Element (Read)
                CORBA::ULong cassetteIDsLen = cassetteIDs.length();
                stringSequence loadCastSeq;
                loadCastSeq.length(cassetteIDsLen);
                for ( CORBA::ULong loadCastNo = 0; loadCastNo < cassetteIDsLen; loadCastNo++ )
                {
                    loadCastSeq[loadCastNo] = cassetteIDs[loadCastNo].identifier;
                }
                strAdvanced_object_Lock_in.objectID   = equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
                strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_READ;
                strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

                PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_LoadCassette );
                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strWaferSorterOnEqpReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }
            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
            /*---------------------------------------------------*/
            /*   Lock Macihne object for check condition         */
            /*---------------------------------------------------*/
            objObject_Lock_out  strObject_Lock_out;
            rc = object_Lock( strObject_Lock_out, strObjCommonIn, equipmentID, SP_ClassName_PosMachine );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "object_Lock() != RC_OK") ;
                strWaferSorterOnEqpReqResult.strResult = strObject_Lock_out.strResult ;
                return( rc );
            }
        } //DSN000049350

//DSIV00000214        //-----------------------------------------
//DSIV00000214        // collect SiView managed casettes only.
//DSIV00000214        //-----------------------------------------
//DSIV00000214        CORBA::Long  waferMapLen = strWaferSorterSlotMapSequence.length();
//DSIV00000214        CORBA::Long  casLen = 0;
//DSIV00000214        cassetteIDs.length(waferMapLen * 2);
//DSIV00000214
//DSIV00000214        for( i=0; i<waferMapLen; i++ )
//DSIV00000214        {
//DSIV00000214            // collect SiView managed casettes only.
//DSIV00000214            if( strWaferSorterSlotMapSequence[i].bOriginalCassetteManagedBySiView == TRUE )
//DSIV00000214            {
//DSIV00000214                CORBA::Boolean dupCastFlag = FALSE ;
//DSIV00000214                for(CORBA::ULong j= 0 ; j < casLen ; j++ )
//DSIV00000214                {
//DSIV00000214                    if(0 == CIMFWStrCmp( cassetteIDs[j].identifier, strWaferSorterSlotMapSequence[i].originalCassetteID.identifier))
//DSIV00000214                    {
//DSIV00000214                        dupCastFlag = TRUE;
//DSIV00000214                        break;
//DSIV00000214                    }
//DSIV00000214                }
//DSIV00000214                if( FALSE == dupCastFlag )
//DSIV00000214                {
//DSIV00000214                    cassetteIDs[casLen] = strWaferSorterSlotMapSequence[i].originalCassetteID;
//DSIV00000214                    PPT_METHODTRACE_V2("","SiView managed original cassette found.", cassetteIDs[casLen].identifier);
//DSIV00000214                    casLen++;
//DSIV00000214                }
//DSIV00000214            }
//DSIV00000214            if( strWaferSorterSlotMapSequence[i].bDestinationCassetteManagedBySiView == TRUE )
//DSIV00000214            {
//DSIV00000214                CORBA::Boolean dupCastFlag = FALSE ;
//DSIV00000214                for(CORBA::ULong j= 0 ; j < casLen ; j++ )
//DSIV00000214                {
//DSIV00000214                    if(0 == CIMFWStrCmp( cassetteIDs[j].identifier, strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier))
//DSIV00000214                    {
//DSIV00000214                        dupCastFlag = TRUE;
//DSIV00000214                        break;
//DSIV00000214                    }
//DSIV00000214                }
//DSIV00000214                if( FALSE == dupCastFlag )
//DSIV00000214                {
//DSIV00000214                    cassetteIDs[casLen] = strWaferSorterSlotMapSequence[i].destinationCassetteID;
//DSIV00000214                    PPT_METHODTRACE_V2("","SiView managed destination cassette found.", cassetteIDs[casLen].identifier);
//DSIV00000214                    casLen++;
//DSIV00000214                }
//DSIV00000214            }
//DSIV00000214        }
//DSIV00000214        cassetteIDs.length(casLen);

        //----------------------------------------------
        // Lock cassette objects for check condition.
        //----------------------------------------------
        objObjectSequence_Lock_out  strObjectSequence_Lock_out;
        rc = objectSequence_Lock( strObjectSequence_Lock_out, strObjCommonIn, cassetteIDs, SP_ClassName_PosCassette );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("","objectSequence_Lock() rc != RC_OK", rc);
            strWaferSorterOnEqpReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return( rc );
        }
    }
//D9000005 add end
//DSN000049350 Add Start
    else if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strWaferSorterOnEqpReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }

        // Lock Equipment LoadCassette Element (Read)
        stringSequence loadCastSeq;
        loadCastSeq.length(casLen);
        for ( CORBA::ULong loadCastNo = 0; loadCastNo < casLen; loadCastNo++ )
        {
            loadCastSeq[loadCastNo] = cassetteIDs[loadCastNo].identifier;
        }
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
        strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_READ;
        strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_LoadCassette );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strWaferSorterOnEqpReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
    }
//DSN000049350 Add End

// D4000056 Start
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    //   Check Process
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","equipment_categoryVsTxID_CheckCombination() returned error. RC = ",rc);

        strWaferSorterOnEqpReqResult.strResult
            = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return (rc);
    }
// D4000056 End
//DSIV00000214 add start
    for( CORBA::ULong casCnt = 0 ; casCnt < casLen ; casCnt++ )
    {
        //---------------------------------------
        // Check lot InterFabXfer State
        //---------------------------------------
        /*-------------------------------*/
        /*  Get Lot list in carrier      */
        /*-------------------------------*/
        objCassette_lotList_GetDR_out strCassette_lotList_GetDR_out;
        rc = cassette_lotList_GetDR( strCassette_lotList_GetDR_out,
                                     strObjCommonIn,
                                     cassetteIDs[casCnt] );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cassette_lotList_GetDR() rc != RC_OK");
            strWaferSorterOnEqpReqResult.strResult = strCassette_lotList_GetDR_out.strResult ;
            return( rc );
        }

        CORBA::ULong lotLen = strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID.length();
        for( CORBA::ULong lotCnt = 0 ; lotCnt < lotLen ; lotCnt++ )
        {
            objLot_interFabXferState_Get_out strLot_interFabXferState_Get_out;

            objLot_interFabXferState_Get_in  strLot_interFabXferState_Get_in;
            strLot_interFabXferState_Get_in.lotID = strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID[lotCnt];

            rc = lot_interFabXferState_Get( strLot_interFabXferState_Get_out,
                                            strObjCommonIn,
                                            strLot_interFabXferState_Get_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_interFabXferState_Get() != RC_OK");
                strWaferSorterOnEqpReqResult.strResult = strLot_interFabXferState_Get_out.strResult ;
                return rc;
            }

            if( 0 == CIMFWStrCmp(strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_OriginDeleting) )
            {
                PPT_METHODTRACE_V1(""," #### Lot State is 'OriginDeleting' Return error!");
                PPT_SET_MSG_RC_KEY( strWaferSorterOnEqpReqResult,
                                    MSG_INTERFAB_INVALID_XFERSTATE_DELETING,
                                    RC_INTERFAB_INVALID_XFERSTATE_DELETING,
                                    strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID[lotCnt].identifier );
                return RC_INTERFAB_INVALID_XFERSTATE_DELETING;
            }
        }
    }
//DSIV00000214 add end
    //================================================================
    // Checking Previous Job is running or not
    //================================================================
    objWaferSorter_CheckRunningJobs_out strWaferSorter_CheckRunningJobs_out;
    rc = waferSorter_CheckRunningJobs(strWaferSorter_CheckRunningJobs_out,
                                       strObjCommonIn,
                                       requestUserID,
                                       equipmentID,
                                       portGroup);

    //------------------------------------------------------
    // If there are running Jobs, then return
    //------------------------------------------------------
    if ( rc == RC_WAFERSORT_ALREADY_RUNNING )
    {
        PPT_METHODTRACE_V1("","SorterJob is already running");
        strWaferSorterOnEqpReqResult.strResult = strWaferSorter_CheckRunningJobs_out.strResult ;
        return(rc);
    }
    else if ( rc != RC_WAFERSORT_PREVIOUSJOB_NOTFOUND )
    {
        PPT_METHODTRACE_V2("","Error Occured RC is ",rc)
        strWaferSorterOnEqpReqResult.strResult = strWaferSorter_CheckRunningJobs_out.strResult ;
        return(rc);
    }
                                       
//P4000302 Add Start
    //================================================================
    // Checking Cassette Status 
    //================================================================
    if(CIMFWStrCmp(actionCode,SP_Sorter_PositionChange     ) == 0 ||
       CIMFWStrCmp(actionCode,SP_Sorter_JustIn             ) == 0 ||
       CIMFWStrCmp(actionCode,SP_Sorter_Scrap              ) == 0 ||
       CIMFWStrCmp(actionCode,SP_Sorter_AdjustToMM         ) == 0 ||   //P4000346
       CIMFWStrCmp(actionCode,SP_Sorter_AutoSorting        ) == 0 ||   //D9000005
       CIMFWStrCmp(actionCode,SP_Sorter_AdjustToSorter     ) == 0)     //D4000234
    {
        CORBA::Long slotMapLen = strWaferSorterSlotMapSequence.length();
        CORBA::Long i = 0;
        
        for(i = 0;i < slotMapLen;i++)
        {
            objCassette_getStatusDR_out strCassette_getStatusDR_out;
            rc = cassette_getStatusDR( strCassette_getStatusDR_out,
                                       strObjCommonIn,
                                       strWaferSorterSlotMapSequence[i].destinationCassetteID );

            if(rc == RC_NOT_FOUND_CASSETTE)
            {
                PPT_METHODTRACE_V1( "","cassette_getStatusDR() == RC_NOT_FOUND_CASSETTE");
                continue;
            }

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "","cassette_getStatusDR() != RC_OK", rc);
                strWaferSorterOnEqpReqResult.strResult = strCassette_getStatusDR_out.strResult;
                return rc;
            }
            PPT_METHODTRACE_V2( "","strCassette_getStatusDR_out.drbl_state--->", strCassette_getStatusDR_out.drbl_state);

            if( CIMFWStrCmp(strCassette_getStatusDR_out.drbl_state, CIMFW_Durable_NotAvailable) == 0 )
            {
                PPT_METHODTRACE_V1( "","Cassette Status == Not Available");
                PPT_SET_MSG_RC_KEY( strWaferSorterOnEqpReqResult,
                                    MSG_CASSETTE_NOT_AVAILABLE,
                                    RC_CASSETTE_NOT_AVAILABLE,
                                    strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier);

                return(RC_CASSETTE_NOT_AVAILABLE);
            }
        }
    }
//P4000302 Add End

    //--------------------------------------------------------------------------
    // If ActionCode is SP_Sorter_End , check any data is existed on SLOTMAP DB
    //--------------------------------------------------------------------------
    if ( CIMFWStrCmp(actionCode,SP_Sorter_End)==0)
    {
        
//P4000309        strWaferSorterSlotMap.equipmentID      = equipmentID;
//P4000309        strWaferSorterSlotMap.portGroup        = CIMFWStrDup(portGroup);
//P4000309        strWaferSorterSlotMap.sorterStatus     = CIMFWStrDup("");
//P4000309        strWaferSorterSlotMap.direction        = CIMFWStrDup("");
//P4000309        strWaferSorterSlotMap.requestTime      = CIMFWStrDup("");
//P4000309 Add Start
        strWaferSorterSlotMap.portGroup                           = CIMFWStrDup(portGroup);
        strWaferSorterSlotMap.equipmentID                         = equipmentID;
        strWaferSorterSlotMap.actionCode                          = CIMFWStrDup("");
        strWaferSorterSlotMap.requestTime                         = CIMFWStrDup("");
        strWaferSorterSlotMap.direction                           = CIMFWStrDup("");
        strWaferSorterSlotMap.waferID.identifier                  = CIMFWStrDup("");
        strWaferSorterSlotMap.lotID.identifier                    = CIMFWStrDup("");
        strWaferSorterSlotMap.destinationCassetteID.identifier    = CIMFWStrDup("");
        strWaferSorterSlotMap.destinationPortID.identifier        = CIMFWStrDup("");
        strWaferSorterSlotMap.bDestinationCassetteManagedBySiView = FALSE;
        strWaferSorterSlotMap.destinationSlotNumber               = 0;
        strWaferSorterSlotMap.originalCassetteID.identifier       = CIMFWStrDup("");
        strWaferSorterSlotMap.originalPortID.identifier           = CIMFWStrDup("");
        strWaferSorterSlotMap.bOriginalCassetteManagedBySiView    = FALSE;
        strWaferSorterSlotMap.originalSlotNumber                  = 0;
        strWaferSorterSlotMap.requestUserID.identifier            = CIMFWStrDup("");
        strWaferSorterSlotMap.replyTime                           = CIMFWStrDup("");
        strWaferSorterSlotMap.sorterStatus                        = CIMFWStrDup("");
        strWaferSorterSlotMap.slotMapCompareStatus                = CIMFWStrDup("");
        strWaferSorterSlotMap.mmCompareStatus                     = CIMFWStrDup("");
//P4000309 Add Start

        //------------------------------------------------------
        //   Search From Flotmap DB
        //------------------------------------------------------
        objWaferSorter_slotMap_SelectDR_out    strWaferSorter_slotMap_SelectDR_out;
        rc = waferSorter_slotMap_SelectDR(strWaferSorter_slotMap_SelectDR_out ,
                                      strObjCommonIn,
                                      SP_Sorter_SlotMap_AllData,
                                      "",
                                      SP_Sorter_Ignore_SiViewFlag, //D4000056
                                      SP_Sorter_Ignore_SiViewFlag, //D4000056
                                      strWaferSorterSlotMap); 

        //------------------------------------------------------
        // When there's no data
        //------------------------------------------------------
        if ( rc == RC_NOT_FOUND_SLOTMAP_RECORD )
        {
            PPT_METHODTRACE_V1("","There are not Runing job records ");
            strWaferSorterOnEqpReqResult.strResult = strWaferSorter_slotMap_SelectDR_out.strResult ;
            PPT_SET_MSG_RC_KEY2( strWaferSorterOnEqpReqResult,
                                MSG_WAFERSORT_PREVIOUSJOB_NOTFOUND,
                                RC_WAFERSORT_PREVIOUSJOB_NOTFOUND,
                                equipmentID.identifier,
                                portGroup);
            return(RC_WAFERSORT_PREVIOUSJOB_NOTFOUND);
        }
        //------------------------------------------------------
        // When Error Occures.
        //------------------------------------------------------
        else if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("","waferSorter_slotMap_SelectDR() returned error RC = ",rc);
            strWaferSorterOnEqpReqResult.strResult = strWaferSorter_slotMap_SelectDR_out.strResult ;
            return(rc);
        }
        PPT_METHODTRACE_V1("","Found previously running jobs");
    }

    //======================================================
    //   Check WaferSorter Operation Data Readiness
    //======================================================
    // P4000099 change name objWaferSorter_CheckConditionForAction_out to objWaferSorter_CheckConditionForAction_out
    PPT_METHODTRACE_V1("","Try to waferSorter_CheckConditionForAction");
    objWaferSorter_CheckConditionForAction_out  strWaferSorter_CheckConditionForAction_out;
    rc = waferSorter_CheckConditionForAction(strWaferSorter_CheckConditionForAction_out,
                                                strObjCommonIn,
                                                requestUserID,
                                                equipmentID,
                                                actionCode,
                                                strWaferSorterSlotMapSequence,
                                                portGroup, 
                                                physicalRecipeID);

    //------------------------------------------------------
    // When Error Occures.
    //------------------------------------------------------
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","waferSorter_CheckConditionForAction() returned error RC = ",rc);
        strWaferSorterOnEqpReqResult.strResult = strWaferSorter_CheckConditionForAction_out.strResult ;
        return(rc); 
    }

    //------------------------------------------------------
    // Verified Condition Structure Condition Structure
    //------------------------------------------------------
    pptWaferSorterSlotMapSequence   strModWaferSorterSlotMapSequence;
    strModWaferSorterSlotMapSequence = strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence;
    

    //======================================================
    //   Send Request to TCS
    //======================================================
//D4000060    PPT_METHODTRACE_V1("","Try to TCSMgr_SendWaferSortOnEqpReq");
//D4000060    objTCSMgr_SendWaferSortOnEqpReq_out strTCSMgr_SendWaferSortOnEqpReq_out;
//D4000060    rc = TCSMgr_SendWaferSortOnEqpReq ( strTCSMgr_SendWaferSortOnEqpReq_out,
//D4000060                                        strObjCommonIn,
//D4000060                                        requestUserID,
//D4000060                                        actionCode,
//D4000060                                        equipmentID,
//D4000060                                        strModWaferSorterSlotMapSequence,
//D4000060                                        portGroup,
//D4000060                                        physicalRecipeID);
//D4000060
//D4000060    //------------------------------------------------------
//D4000060    // When Error Occures.
//D4000060    //------------------------------------------------------
//D4000060    if ( rc != RC_OK )
//D4000060    {
//D4000060        PPT_METHODTRACE_V2("","TCSMgr_SendWaferSortOnEqpReq() returned error RC = ",rc);
//D4000060        if(rc == RC_NOT_FOUND_TCS )
//D4000060        {
//D4000060            PPT_SET_MSG_RC_KEY(strTCSMgr_SendWaferSortOnEqpReq_out,MSG_NOT_FOUND_TCS,RC_NOT_FOUND_TCS,"");
//D4000060        }
//D4000060        // Temporary Logic 2001/08/27 
//D4000060        else
//D4000060        {
//D4000060            strWaferSorterOnEqpReqResult.strResult = strTCSMgr_SendWaferSortOnEqpReq_out.strResult ;
//D4000060            PPT_METHODTRACE_V2("PPTManager_i::txWaferSorterOnEqpReq result  msgID/msgText",
//D4000060                                   strWaferSorterOnEqpReqResult.strResult.messageID,
//D4000060                                   strWaferSorterOnEqpReqResult.strResult.messageText);
//D4000060            return(rc); 
//D4000060        }
//D4000060    }
//D9000005 add start
    if ( 0 == CIMFWStrCmp( actionCode, SP_Sorter_AutoSorting ) )
    {
        PPT_METHODTRACE_V1("","actionCode == SP_Sorter_AutoSorting");
        PPT_METHODTRACE_V1("","No need to call TCSMgr_SendWaferSortOnEqpReq.");
    }
    else
    {
//D9000005 add end
//D4000060 add start
        CORBA::String_var tmpSleepTimeValue = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
        CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));
        CORBA::Long sleepTimeValue;
        CORBA::Long retryCountValue;

        if (CIMFWStrLen(tmpSleepTimeValue) == 0)
        {
            sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
        }
        else
        {
//D9000001         sleepTimeValue = atol(tmpSleepTimeValue) ;
            sleepTimeValue = atoi(tmpSleepTimeValue) ;    //D9000001
        }

        if (CIMFWStrLen(tmpRetryCountValue) == 0)
        {
            retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
        }
        else
        {
//D9000001         retryCountValue = atol(tmpRetryCountValue);
            retryCountValue = atoi(tmpRetryCountValue);    //D9000001
        }

        PPT_METHODTRACE_V2("","env value of SP_BIND_SLEEP_TIME_TCS  = ",sleepTimeValue);
        PPT_METHODTRACE_V2("","env value of SP_BIND_RETRY_COUNT_TCS = ",retryCountValue);

        objTCSMgr_SendWaferSortOnEqpReq_out strTCSMgr_SendWaferSortOnEqpReq_out;

        //'retryCountValue + 1' means first try plus retry count
        for(i = 0 ; i < (retryCountValue + 1) ; i++)
        {
//D9000005 add start
            if( CIMFWStrCmp(actionCode, SP_Sorter_End) == 0 )
            {
                PPT_METHODTRACE_V1("", "actionCode == SP_Sorter_End, Send PortInfo for TCS");

                objEquipment_portInfo_GetDR_out strEquipment_portInfo_GetDR_out;
                rc = equipment_portInfo_GetDR(strEquipment_portInfo_GetDR_out, strObjCommonIn, equipmentID);

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "equipment_portInfo_GetDR() rc != RC_OK");
                    strWaferSorterOnEqpReqResult.strResult = strEquipment_portInfo_GetDR_out.strResult;
                    return( rc );
                }
                CORBA::ULong portLen = strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
                PPT_METHODTRACE_V2("", "portLen = ",portLen);

                CORBA::Long portIndex = 0;
                strModWaferSorterSlotMapSequence.length(portLen);

                for ( CORBA::Long j = 0; j < portLen; j++ )
                {
                    PPT_METHODTRACE_V2("", "strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portGroup = ",strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portGroup);
                    PPT_METHODTRACE_V2("", "strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID    = ",strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID.identifier);

                    if( CIMFWStrCmp( portGroup, strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portGroup ) == 0 )
                    {
                        strModWaferSorterSlotMapSequence[portIndex].portGroup                        = portGroup;
                        strModWaferSorterSlotMapSequence[portIndex].equipmentID                      = equipmentID;
                        strModWaferSorterSlotMapSequence[portIndex].actionCode                       = SP_Sorter_End;
                        strModWaferSorterSlotMapSequence[portIndex].requestTime                      = CIMFWStrDup("");
                        strModWaferSorterSlotMapSequence[portIndex].direction                        = SP_Sorter_Direction_MM;
                        strModWaferSorterSlotMapSequence[portIndex].waferID.identifier               = CIMFWStrDup("");
                        strModWaferSorterSlotMapSequence[portIndex].lotID.identifier                 = CIMFWStrDup("");
                        strModWaferSorterSlotMapSequence[portIndex].destinationCassetteID            = strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID;
                        strModWaferSorterSlotMapSequence[portIndex].destinationPortID                = strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID;

                        if( CIMFWStrLen(strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier) == 0 )
                        {
                            strModWaferSorterSlotMapSequence[portIndex].bDestinationCassetteManagedBySiView = FALSE;
                        }
                        else
                        {
                            strModWaferSorterSlotMapSequence[portIndex].bDestinationCassetteManagedBySiView = TRUE;
                        }

                        strModWaferSorterSlotMapSequence[portIndex].destinationSlotNumber            = 0;
                        strModWaferSorterSlotMapSequence[portIndex].originalCassetteID               = strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID;
                        strModWaferSorterSlotMapSequence[portIndex].originalPortID                   = strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID;
                        strModWaferSorterSlotMapSequence[portIndex].bOriginalCassetteManagedBySiView = strModWaferSorterSlotMapSequence[portIndex].bDestinationCassetteManagedBySiView;
                        strModWaferSorterSlotMapSequence[portIndex].originalSlotNumber               = 0;
                        strModWaferSorterSlotMapSequence[portIndex].requestUserID                    = requestUserID.userID;
                        strModWaferSorterSlotMapSequence[portIndex].replyTime                        = CIMFWStrDup("");
                        strModWaferSorterSlotMapSequence[portIndex].sorterStatus                     = SP_Sorter_Requested;
                        strModWaferSorterSlotMapSequence[portIndex].slotMapCompareStatus             = CIMFWStrDup("");
                        strModWaferSorterSlotMapSequence[portIndex].mmCompareStatus                  = CIMFWStrDup("");

                        portIndex++;
                    }
                }
                strModWaferSorterSlotMapSequence.length(portIndex);
            }

            if ( CIMFWStrCmp( actionCode, SP_Sorter_AdjustToSorter ) == 0 )
            {
                PPT_METHODTRACE_V1("","actionCode == AdjustToSorter, No Need to send Request to TCS.");
                break;
            }
            else
            {
                PPT_METHODTRACE_V1("","actionCode != AdjustToSorter, Need to send Request to TCS.");
//D9000005 add end

                /*--------------------------*/
                /*    Send Request to TCS   */
                /*--------------------------*/
                rc = TCSMgr_SendWaferSortOnEqpReq ( strTCSMgr_SendWaferSortOnEqpReq_out,
                                                    strObjCommonIn,
                                                    requestUserID,
                                                    actionCode,
                                                    equipmentID,
                                                    strModWaferSorterSlotMapSequence,
                                                    portGroup,
                                                    physicalRecipeID);
                PPT_METHODTRACE_V2("","rc = ",rc);

                if(rc == RC_OK)
                {
                    PPT_METHODTRACE_V1("","Now TCS subSystem is alive!! Go ahead");
                    break;
                }
                else if ( rc == RC_EXT_SERVER_BIND_FAIL ||
                          rc == RC_EXT_SERVER_NIL_OBJ   ||
                          rc == RC_TCS_NO_RESPONSE )
                {
                    PPT_METHODTRACE_V2("","TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...",i);
                    PPT_METHODTRACE_V2("","now sleeping... ",sleepTimeValue);
                    sleep(sleepTimeValue);
                    continue;
                }
                else
                {
                    PPT_METHODTRACE_V2("","TCSMgr_SendWaferSortOnEqpReq() returned error RC = ",rc);
                    if(rc == RC_NOT_FOUND_TCS )
                    {
//P4100078                 PPT_SET_MSG_RC_KEY(strTCSMgr_SendWaferSortOnEqpReq_out,MSG_NOT_FOUND_TCS,RC_NOT_FOUND_TCS,"");
//P5000145                 PPT_SET_MSG_RC_KEY(strWaferSorterOnEqpReqResult,MSG_NOT_FOUND_TCS,RC_NOT_FOUND_TCS,"");    //P4100078
                        SET_MSG_RC( strWaferSorterOnEqpReqResult, MSG_NOT_FOUND_TCS, RC_NOT_FOUND_TCS );        //P5000145
                    }
                    // Temporary Logic 2001/08/27
                    else
                    {
                        strWaferSorterOnEqpReqResult.strResult = strTCSMgr_SendWaferSortOnEqpReq_out.strResult ;
                        PPT_METHODTRACE_V2("PPTManager_i::txWaferSorterOnEqpReq result  msgID/msgText",
                                               strWaferSorterOnEqpReqResult.strResult.messageID,
                                               strWaferSorterOnEqpReqResult.strResult.messageText);
                        return(rc);
                    }
                }
            }    //D9000005
        }

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("","TCSMgr_SendWaferSortOnEqpReq() returned error RC = ",rc);
            if(rc == RC_NOT_FOUND_TCS )
            {
//P4100078              PPT_SET_MSG_RC_KEY(strTCSMgr_SendWaferSortOnEqpReq_out,MSG_NOT_FOUND_TCS,RC_NOT_FOUND_TCS,"");
//P5000145              PPT_SET_MSG_RC_KEY(strWaferSorterOnEqpReqResult,MSG_NOT_FOUND_TCS,RC_NOT_FOUND_TCS,"");    //P4100078
                SET_MSG_RC( strWaferSorterOnEqpReqResult, MSG_NOT_FOUND_TCS, RC_NOT_FOUND_TCS );        //P5000145
            }
            // Temporary Logic 2001/08/27
            else
            {
                strWaferSorterOnEqpReqResult.strResult = strTCSMgr_SendWaferSortOnEqpReq_out.strResult ;
                PPT_METHODTRACE_V2("PPTManager_i::txWaferSorterOnEqpReq result  msgID/msgText",
                                       strWaferSorterOnEqpReqResult.strResult.messageID,
                                       strWaferSorterOnEqpReqResult.strResult.messageText);
                return(rc);
            }
        }
//D4000060 add end
    }    //D9000005

    //====================================================================
    // Delete FOSB's Slotmap information when SP_Sorter_End 
    //====================================================================
    if ( CIMFWStrCmp(actionCode,SP_Sorter_End)==0)
    {
        //--------------------------------------------------------------------
        // Delete All SlotMap information
        //--------------------------------------------------------------------
        PPT_METHODTRACE_V1("","Try to waferSorter_slotMap_DeleteDR for FOSB");
        objectIdentifierSequence     cassetteIDs;    //D9000005
        objWaferSorter_slotMap_DeleteDR_out strWaferSorter_slotMap_DeleteDR_out; 
        rc = waferSorter_slotMap_DeleteDR( strWaferSorter_slotMap_DeleteDR_out,
                                               strObjCommonIn,
                                               portGroup,
                                               equipmentID,
                                               cassetteIDs, 
                                               "",                  
                                               SP_Sorter_AllDelete,
                                               "");               
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("waferSorter_slotMap_DeleteDR", "rc != RC_OK : " , rc);
            strWaferSorterOnEqpReqResult.strResult = strWaferSorter_slotMap_DeleteDR_out.strResult ;
            return( rc );
        }
        else
        {
            PPT_METHODTRACE_V2("", "FOSB Slotmap data was not found : will be returned OK " , rc);
            SET_MSG_RC(strWaferSorterOnEqpReqResult,MSG_OK,RC_OK);
            return( RC_OK );
        }
    }
    //--------------------------------------------------------------------
    // Other Case(Except End Operation), Insert SlotMap Information with 
    // status SP_Sorter_Requested.
    //--------------------------------------------------------------------
    else
    {
        PPT_METHODTRACE_V1("","Try to waferSorter_slotMap_InsertDR ");

//D4000234 Add start
        //-----------------------------------------------------------------------------------------------------------------
        // [sorterStatus]
        // When Request is done in TCS at the time of AdjustToSorter, sorterStatus is written in the record as Succeeded.
        // TCS is because Report can't be returned.
        //
        // [Direction]
        // direction is changed to "TCS". 
        // It is because AdjustToSorter Operation can't be indicated on the Action Result List screen. 
        //-----------------------------------------------------------------------------------------------------------------
        if(CIMFWStrCmp(actionCode,SP_Sorter_AdjustToSorter) == 0)
        {
            CORBA::Long len = strModWaferSorterSlotMapSequence.length();
            for( i = 0; i < len ; i++)
            {
                strModWaferSorterSlotMapSequence[i].sorterStatus = CIMFWStrDup(SP_Sorter_Succeeded);
                strModWaferSorterSlotMapSequence[i].direction = CIMFWStrDup(SP_Sorter_Direction_TCS);
            }
        }
//D4000234 Add end

        objWaferSorter_slotMap_InsertDR_out strWaferSorter_slotMap_InsertDR_out; 
        rc = waferSorter_slotMap_InsertDR( strWaferSorter_slotMap_InsertDR_out,
                                           strObjCommonIn,
                                           strModWaferSorterSlotMapSequence);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("waferSorter_slotMap_InsertDR", "rc != RC_OK:",rc);
            strWaferSorterOnEqpReqResult.strResult = strWaferSorter_slotMap_InsertDR_out.strResult ;
            return( rc );
        }
    }

//D9000005 add start
    //----------------------------------------------------------------------
    //  Sorter component Job Status Update (Xfer -> Executing)
    //----------------------------------------------------------------------
    if ( 0 == CIMFWStrCmp( actionCode, SP_Sorter_AutoSorting ) )
    {
        PPT_METHODTRACE_V1("","actionCode == SP_Sorter_AutoSorting ");
        objSorter_sorterJob_status_GetDR_in strSorter_sorterJob_status_GetDR_in ;
        strSorter_sorterJob_status_GetDR_in.equipmentID = equipmentID ;
        strSorter_sorterJob_status_GetDR_in.originalCassetteID = strWaferSorterSlotMapSequence[0].originalCassetteID;
        strSorter_sorterJob_status_GetDR_in.destinationCassetteID = strWaferSorterSlotMapSequence[0].destinationCassetteID;
        strSorter_sorterJob_status_GetDR_in.portGroupID = portGroup;

        objSorter_sorterJob_status_GetDR_out strSorter_sorterJob_status_GetDR_out;
        rc = sorter_sorterJob_status_GetDR( strSorter_sorterJob_status_GetDR_out,
                                            strObjCommonIn,
                                            strSorter_sorterJob_status_GetDR_in );

        if ( rc != RC_OK )
        {
            strWaferSorterOnEqpReqResult.strResult = strSorter_sorterJob_status_GetDR_out.strResult;
            return( rc );
        }

        objectIdentifier portGrp ;
        portGrp.identifier = portGroup;
        pptSortJobStatusChangeRptResult strSortJobStatusChangeRptResult;
        rc = txSortJobStatusChangeRpt( strSortJobStatusChangeRptResult, 
                                       strObjCommonIn,
                                       equipmentID,
                                       portGrp,
                                       strSorter_sorterJob_status_GetDR_out.sorterComponentJobID,
                                       SP_Sorter_Job_Type_ComponentJob,
                                       SP_SorterComponentJobStatus_Executing,
                                       claimMemo );

        if ( rc != RC_OK )
        {
            strWaferSorterOnEqpReqResult.strResult = strSortJobStatusChangeRptResult.strResult;
            return( rc );
        }
    }
//D9000005 add end

    // End of operation
    SET_MSG_RC(strWaferSorterOnEqpReqResult, MSG_OK, RC_OK) ;   
    PPT_METHODTRACE_EXIT("PPTManager_i:: txWaferSorterOnEqpReq")
    return(RC_OK);
}
