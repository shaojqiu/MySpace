// (c) Copyright: IBM  Company Ltd, 2017, 2027. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017, 2027. All rights reserved.
//
// SiView
// Name: cs_txUserCertifyCheckInq.cpp
//
// Modeficaiton History:
// Date       Defect            Name             Description
// ---------- --------------    ---------------- ----------------------------------------------
// 2017/09/04 INN-R170008       Menghua Yin      TA Certify
// 2017/11/01 INN-R170008-01    Vera Chen        Modify expire date
// Class: PPTServiceManager
//
// Service: cs_txUserCertifyCheckInq()
// Description:
//<Method Summary>
//</Method Summary>
// Return:
//     long
//
// Parameter:
//
//     csUserCertifyCheckInqResult&          strUserCertifyCheckInqResult
//     const pptObjCommonIn&                 strObjCommonIn
//     const csUserCertifyCheckInqInParm&    strUserCertifyCheckInqInParm

//<Method Start>
#include "cs_pptmgr.hpp"

CORBA::Long CS_PPTManager_i::cs_txUserCertifyCheckInq (
    csUserCertifyCheckInqResult&          strUserCertifyCheckInqResult,
    const pptObjCommonIn&                 strObjCommonIn,
    const csUserCertifyCheckInqInParm&    strUserCertifyCheckInqInParm CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("PPTManager_i::cs_txUserCertifyCheckInq");
    CORBA::Long rc = RC_OK;

    //----------------------------------------------------------------
    //
    //  Pre Process
    //
    //----------------------------------------------------------------
    // get the env variables : 
    CORBA::String_var tmpTACertifySkillExpDuration = CIMFWStrDup(getenv(CS_TACERTIFY_SKILL_EXP_DURATION));
    CORBA::String_var tmpTACertifyPreAlarmDuration = CIMFWStrDup(getenv(CS_TACERTIFY_PRE_ALARM_DURATION));
    
    //----------------------------------------------------------------------
    //
    //  Main Process
    //
    //----------------------------------------------------------------------

    // get user's skillinfo by calling cs_person_SkillList_GetDR
    csObjPerson_SkillList_GetDR_out strObjPerson_SkillList_GetDR_out;
    csObjPerson_SkillList_GetDR_in strObjPerson_SkillList_GetDR_in;

    strObjPerson_SkillList_GetDR_in.userID = strUserCertifyCheckInqInParm.userID;
    rc = cs_person_SkillList_GetDR( strObjPerson_SkillList_GetDR_out,
                                    strObjCommonIn,
                                    strObjPerson_SkillList_GetDR_in );
                                    
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "cs_person_SkillList_GetDR() rc != RC_OK. ", rc);
        strUserCertifyCheckInqResult.strResult = strObjPerson_SkillList_GetDR_out.strResult;
        return(rc);
    }
    
        // loop this user's skillinfo to check
    CORBA::Long nSkillInfoCnt = strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo.length();
    PPT_METHODTRACE_V2("","nSkillInfoCnt",nSkillInfoCnt);
    for (CORBA::Long i = 0; i < nSkillInfoCnt; i++)
    {
        char *tCertifiedDate = strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo[i].certifiedDate;
        CORBA::Long nLen = CIMFWStrLen(tCertifiedDate);
        PPT_METHODTRACE_V2("","tCertifiedDate",tCertifiedDate);
        PPT_METHODTRACE_V2("","skill_ID",strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo[i].skillID);
        
        char cYear[5] = { 0 };
        char cMouth[3] = { 0 };
        char cDays[3] = { 0 };
        
        char *pos = strchr(tCertifiedDate, '-');
        char *pos1 = strchr(tCertifiedDate + 5, '-');

        CIMFWStrnCpy(cYear, tCertifiedDate, 4);
        cYear[4] = '\0';
        if ((pos1 - pos) == 2)
        {
            CIMFWStrnCpy(cMouth, tCertifiedDate + 5, 1);
            cMouth[1] = '\0';
            CIMFWStrnCpy(cDays, tCertifiedDate + 7, nLen-7);
            cDays[nLen - 1] = '\0';
        }
        else if ((pos1 - pos) == 3)
        {
            CIMFWStrnCpy(cMouth, tCertifiedDate + 5, 2);
            cMouth[2] = '\0';
            CIMFWStrnCpy(cDays, tCertifiedDate + 8, nLen-8);
            cDays[nLen - 1] = '\0';
        }
        
        CORBA::Long lCertifiedYear = atoi(cYear);
        CORBA::Long lCertifiedMouth = atoi(cMouth);
        CORBA::Long lCertifiedDay = atoi(cDays);
        
        PPT_METHODTRACE_V2("","lCertifiedYear",lCertifiedYear);
        PPT_METHODTRACE_V2("","lCertifiedMouth",lCertifiedMouth);
        PPT_METHODTRACE_V2("","lCertifiedDay",lCertifiedDay);

        CORBA::Long lExpiredDay = lCertifiedDay + atoi(tmpTACertifySkillExpDuration);
        CORBA::Long lPreAlarmDay = lExpiredDay - atoi(tmpTACertifyPreAlarmDuration);
        
        PPT_METHODTRACE_V2("","atoi(tmpTACertifySkillExpDuration)",atoi(tmpTACertifySkillExpDuration));
        PPT_METHODTRACE_V2("","atoi(tmpTACertifyPreAlarmDuration)",atoi(tmpTACertifyPreAlarmDuration));
        
        PPT_METHODTRACE_V2("","lExpiredDay",lExpiredDay);
        PPT_METHODTRACE_V2("","lPreAlarmDay",lPreAlarmDay);
        
        // calculate the Certified Days from 0001-01-01
        CORBA::Long mouth_day[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        CORBA::Long year = lCertifiedYear - 1;
        CORBA::Long days = year * 365 + year / 4 - year / 100 + year / 400;
        PPT_METHODTRACE_V2("","days line 123",days);
        
        if (lCertifiedYear % 4 == 0 && lCertifiedYear % 100 != 0 || lCertifiedYear % 400 == 0)
        {//INN-R170008-01
            mouth_day[1]++;
        }//INN-R170008-01
        CORBA::Long k = 0;
        for (k = 0; k < lCertifiedMouth - 1; k++)
        {
            days += mouth_day[k];
            PPT_METHODTRACE_V2("","mouth_day[k]",mouth_day[k]);
            PPT_METHODTRACE_V2("","days",days);
        }

        days += lPreAlarmDay - 1;
        
        PPT_METHODTRACE_V2("","days",days);

        // calculate the Report days from 0001-01-01
        CORBA::String_var strReportTime = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);
        char cReportYear[5] = { 0 };
        char cReportMouth[3] = { 0 };
        char cReportDays[3] = { 0 };

        CIMFWStrnCpy(cReportYear, strReportTime, 4);
        cReportYear[4] = '\0';
        CIMFWStrnCpy(cReportMouth, strReportTime + 5, 2);
        cReportMouth[2] = '\0';
        CIMFWStrnCpy(cReportDays, strReportTime + 8, 2);
        cReportDays[2] = '\0';

        CORBA::Long lReportYear = atoi(cReportYear);
        CORBA::Long lReportMouth = atoi(cReportMouth);
        CORBA::Long lReportDay = atoi(cReportDays);
        
        PPT_METHODTRACE_V2("","lReportYear",lReportYear);
        PPT_METHODTRACE_V2("","lReportMouth",lReportMouth);
        PPT_METHODTRACE_V2("","lReportDay",lReportDay);

        CORBA::Long report_mouth_day[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
        CORBA::Long reportYear = lReportYear - 1;
        CORBA::Long reportDyas = reportYear * 365 + reportYear / 4 - reportYear / 100 + reportYear / 400;
        PPT_METHODTRACE_V2("","reportDyas line 159",reportDyas);
        
        if (lReportYear % 4 == 0 && lReportYear % 100 != 0 || lReportYear % 400 == 0)
        {//INN-R170008-01
            report_mouth_day[1]++;
        }//INN-R170008-01
        CORBA::Long j = 0;
        for (j = 0; j < lReportMouth - 1; j++)
        {
            reportDyas += report_mouth_day[j];
            PPT_METHODTRACE_V2("","report_mouth_day[j]",report_mouth_day[j]);
            PPT_METHODTRACE_V2("","reportDyas",reportDyas);
        }

        reportDyas = reportDyas + lReportDay - 1;
        PPT_METHODTRACE_V2("","reportDyas",reportDyas);

        //INN-R170008-01 Add start
        
        objTimeStamp_DoCalculation_out  strTimeStamp_DoCalculation_out;
        
        rc = timeStamp_DoCalculation(   strTimeStamp_DoCalculation_out,
                                        strObjCommonIn,
                                        strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo[i].certifiedDate,
                                        lExpiredDay,
                                        0,
                                        0,
                                        0,
                                        0);
        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V2("timeStamp_DoCalculation()", "rc != RC_OK",rc);
            strUserCertifyCheckInqResult.strResult = strTimeStamp_DoCalculation_out.strResult;
            return rc;
        }
        PPT_METHODTRACE_V2("","strTimeStamp_DoCalculation_out.targetTimeStamp",strTimeStamp_DoCalculation_out.targetTimeStamp);
        //INN-R170008-01 Add end
        
        if (reportDyas > days)
        {
            CORBA::String_var varSkillID = CIMFWStrDup(strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo[i].skillID);
            PPT_METHODTRACE_V2("","tCertifiedDate_185",varSkillID);
            CS_PPT_SET_MSG_RC_KEY2( strUserCertifyCheckInqResult,
                                    CS_MSG_USER_SKILL_EXPIRED_DATE,
                                    CS_RC_USER_SKILL_EXPIRED_DATE,
                                    varSkillID,
                                    strTimeStamp_DoCalculation_out.targetTimeStamp);//INN-R170008-01
//INN-R170008-01                                    tCertifiedDate );
            return CS_RC_USER_SKILL_EXPIRED_DATE;
        }
    }
    
    // Return to caller
    // SET_MSG_RC(cs_txUserCertifyCheckInq, MSG_OK, RC_OK);
    PPT_METHODTRACE_EXIT("PPTManager_i::cs_txUserCertifyCheckInq");                    
    return RC_OK;
}