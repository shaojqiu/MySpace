#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txWaferSortReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:40:31 [ 7/13/07 21:40:32 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txWaferSortReqOR.cpp
//

#include "cs_pptmgr.hpp"

#include <unistd.h>

//#include "pmc.hh"

// Class: CS_PPTManager
//
// Service: txWaferSortReq()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2000/09/15 P3000182     S.Kawabe       Initial Release
// 2001/09/06 D4000135     Y.Yoshihara    Add inparameter ( 
//                                        Change parameter of sorter_waferTransferInfo_Verify
// 2001/09/07 D4000060     K.Kido         Add retry TCS request logic
// 2001/09/07 D4000056     Y.Yoshihara    Add Parameter for originalLocationVerify 
// 2001/09/14 D4000056     Y.Yoshihara    delete Parameter  originalLocationVerify 
// 2003/04/07 P5000019     H.Adachi       Add control job check for cassette
// 2007/04/20 D9000001     H.Murakami     64bit support.
// 2007/06/12 D9000005     H.Hotta        WaferSorter automation support.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2012/12/04 DSN000049350 K.Yamaoku      Equipment parallel processing support (P2)
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/13 INN-R170002  JQ.Shao        Contamination Control
//
// Description:
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
//
// Return:
//     long
//
// Parameter:
//
//    pptWaferSortReqResult&              strWaferSortReqResult
//    const pptObjCommonIn&               strObjCommonIn
//    const objectIdentifier&             equipmentID
//    const pptWaferTransferSequence&     strWaferXferSeq
//    CORBA::Boolean                      bNotifyToTCS
//    const char *                        originalLocationVerify
//    const char *                        claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i:: txWaferSortReq (pptWaferSortReqResult& strWaferSortReqResult,
                                           const pptObjCommonIn&  strObjCommonIn, 
                                           const objectIdentifier& equipmentID, 
                                           const pptWaferTransferSequence& strWaferXferSeq, 
                                           CORBA::Boolean bNotifyToTCS,
                                           //2001-09-14 D4000056 const char * originalLocationVerify,   // D4000135
//D6000025                                            const char * claimMemo, 
//D6000025                                            CORBA::Environment & IT_env)
                                           const char * claimMemo  //D6000025
                                           CORBAENV_LAST_CPP)      //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txWaferSortReq");
    CORBA::Long rc = RC_OK;

    //2001-09-14 PPT_METHODTRACE_V2("CS_PPTManager_i:: txWaferSortReq", "originalLocationVerify is ",originalLocationVerify);

//DSN000049350 Add Start
    CORBA::Long lockMode = SP_EQP_LOCK_MODE_WRITE;
    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
//DSN000049350 Add End

    //------------------------------------------------------------
    // Retrieve Equipment's onlineMode
    //------------------------------------------------------------
    objEquipment_onlineMode_Get_out strEquipment_onlineMode_Get_out;
    strEquipment_onlineMode_Get_out.onlineMode =  CIMFWStrDup(SP_Eqp_OnlineMode_Offline);  //Initialize
    if (CIMFWStrLen(equipmentID.identifier) != 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txWaferSortReq", "CIMFWStrLen(equipmentID.identifier) != 0");

//DSN000049350 Add Start
        // Get required equipment lock mode
        objObject_lockMode_Get_out strObject_lockMode_Get_out;
        objObject_lockMode_Get_in  strObject_lockMode_Get_in;
        strObject_lockMode_Get_in.objectID           = equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXPCC039" ); // TxWaferSortReq
        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strWaferSortReqResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }

        lockMode = strObject_lockMode_Get_out.lockMode;
        PPT_METHODTRACE_V2( "", "lockMode", lockMode );
        if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
        {
            PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

            // Lock Equipment Main Object
            stringSequence dummySeq;
            dummySeq.length(0);
            strAdvanced_object_Lock_in.objectID   = equipmentID;
            strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
            strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
            strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
            strAdvanced_object_Lock_in.keySeq     = dummySeq;

            PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
            rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                        strObjCommonIn,
                                        strAdvanced_object_Lock_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                strWaferSortReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                return( rc );
            }
        }
//DSN000049350 Add End

        rc = equipment_onlineMode_Get( strEquipment_onlineMode_Get_out, strObjCommonIn,
                                       equipmentID);
        if (rc)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txWaferSortReq", "equipment_onlineMode_Get() rc != RC_OK");
            strWaferSortReqResult.strResult = strEquipment_onlineMode_Get_out.strResult;
            return( rc );
        }
    }

    //P5000019 Add Start
    objectIdentifierSequence cassetteIDSeq;
    CORBA::Long    i_wfr, j_cas;
    CORBA::Boolean bCassetteFind = FALSE;
    CORBA::Long    lenWaferXferSeq = strWaferXferSeq.length();
    CORBA::Long    lenCasIDSeq=0;

//DSN000049350 Add Start
    stringSequence castIDSeq;    //FOUPs
    CORBA::ULong extendLen     = 25;
    CORBA::ULong t_castIDLen   = lenWaferXferSeq;
    CORBA::ULong cassetteIDCnt = 0;
    castIDSeq.length(t_castIDLen);
//DSN000049350 Add End

//INN-R170002 Add Start
    objectIdentifierSequence moveToCassetteIDSeq;
    objectIdentifierSequence lotIDs;
    CORBA::Long lenDesCasIDSeq = 0;
    CORBA::Long lenLotIDSeq    = 0;
    CORBA::Long k_cas          = 0;
    CORBA::Long h_lot          = 0;
    CORBA::Boolean bLotFind    = FALSE;
    moveToCassetteIDSeq.length(0);
    lotIDs.length(0);
//INN-R170002 Add End

    PPT_METHODTRACE_V2("", "lenWaferXferSeq-->", lenWaferXferSeq);
    //-----------------------
    // Cassette ID Collection
    //-----------------------
    for ( i_wfr = 0; i_wfr < lenWaferXferSeq; i_wfr++ )
    {
        //------------------------------------------
        // Collect CassetteID of DestinationCassette
        //------------------------------------------
        bCassetteFind = FALSE;

        lenCasIDSeq = cassetteIDSeq.length();
        PPT_METHODTRACE_V2("", "lenCasIDSeq-->", lenCasIDSeq);

        for ( j_cas = 0; j_cas < lenCasIDSeq; j_cas++ )
        {
            if ( 0 == CIMFWStrCmp(strWaferXferSeq[i_wfr].destinationCassetteID.identifier, cassetteIDSeq[j_cas].identifier) )
            {
                PPT_METHODTRACE_V2("", "set bCassetteFind = TRUE", j_cas);
                bCassetteFind = TRUE;
                break;
            }
        }
        if ( bCassetteFind == FALSE )
        {
            PPT_METHODTRACE_V1("", "bCassetteFind == FALSE");

            lenCasIDSeq++;
            cassetteIDSeq.length(lenCasIDSeq);
            cassetteIDSeq[lenCasIDSeq-1] = strWaferXferSeq[i_wfr].destinationCassetteID;
//DSN000049350 Add Start
            if ( TRUE == strWaferXferSeq[i_wfr].bDestinationCassetteManagedBySiView )
            {
                PPT_METHODTRACE_V1("", "strWaferXferSeq[i_wfr].bDestinationCassetteManagedBySiView == TRUE");
                // This is a FOUP
                if( cassetteIDCnt >= t_castIDLen )
                {
                    PPT_METHODTRACE_V1("", "cassetteIDCnt >= t_castIDLen");
                    t_castIDLen += extendLen;
                    castIDSeq.length( t_castIDLen );
                }
                castIDSeq[cassetteIDCnt++] = strWaferXferSeq[i_wfr].destinationCassetteID.identifier;
            }
//DSN000049350 Add End
        }

        //---------------------------------------
        // Collect CassetteID of OriginalCassette
        //---------------------------------------
        bCassetteFind = FALSE;

        lenCasIDSeq = cassetteIDSeq.length();
        PPT_METHODTRACE_V2("", "lenCasIDSeq-->", lenCasIDSeq);

        for ( j_cas = 0; j_cas < lenCasIDSeq; j_cas++ )
        {
            if ( 0 == CIMFWStrCmp(strWaferXferSeq[i_wfr].originalCassetteID.identifier, cassetteIDSeq[j_cas].identifier) )
            {
                PPT_METHODTRACE_V2("", "set bCassetteFind = TRUE", j_cas);
                bCassetteFind = TRUE;
                break;
            }
        }
        if ( bCassetteFind == FALSE )
        {
            PPT_METHODTRACE_V1("", "bCassetteFind == FALSE");

            lenCasIDSeq++;
            cassetteIDSeq.length(lenCasIDSeq);
            cassetteIDSeq[lenCasIDSeq-1] = strWaferXferSeq[i_wfr].originalCassetteID;
//DSN000049350 Add Start
            if ( TRUE == strWaferXferSeq[i_wfr].bOriginalCassetteManagedBySiView )
            {
                PPT_METHODTRACE_V1("", "strWaferXferSeq[i_wfr].bOriginalCassetteManagedBySiView == TRUE");
                // This is a FOUP
                if( cassetteIDCnt >= t_castIDLen )
                {
                    PPT_METHODTRACE_V1("", "cassetteIDCnt >= t_castIDLen");
                    t_castIDLen += extendLen;
                    castIDSeq.length( t_castIDLen );
                }
                castIDSeq[cassetteIDCnt++] = strWaferXferSeq[i_wfr].originalCassetteID.identifier;
            }
//DSN000049350 Add End
        }

//INN-R170002 Add Start
        //---------------------------------------
        // Collect CassetteID of MoveToCassette
        //---------------------------------------
        if ( TRUE == strWaferXferSeq[i_wfr].bDestinationCassetteManagedBySiView )
        {
            if( 0 <  CIMFWStrLen(strWaferXferSeq[i_wfr].originalCassetteID.identifier)
             && 0 <  CIMFWStrLen(strWaferXferSeq[i_wfr].destinationCassetteID.identifier)
             && 0 != CIMFWStrCmp(strWaferXferSeq[i_wfr].originalCassetteID.identifier, strWaferXferSeq[i_wfr].destinationCassetteID.identifier) )
            {
                bCassetteFind = FALSE;

                lenDesCasIDSeq = moveToCassetteIDSeq.length();
                PPT_METHODTRACE_V2("", "lenDesCasIDSeq-->", lenDesCasIDSeq);

                for ( k_cas = 0; k_cas < lenDesCasIDSeq; k_cas++ )
                {
                    if ( 0 == CIMFWStrCmp(strWaferXferSeq[i_wfr].destinationCassetteID.identifier, moveToCassetteIDSeq[k_cas].identifier) )
                    {
                        PPT_METHODTRACE_V2("", "set bCassetteFind = TRUE", k_cas);
                        bCassetteFind = TRUE;
                        break;
                    }
                }
                if ( bCassetteFind == FALSE )
                {
                    PPT_METHODTRACE_V1("", "bCassetteFind == FALSE");
                    lenDesCasIDSeq++;
                    moveToCassetteIDSeq.length(lenDesCasIDSeq);
                    moveToCassetteIDSeq[lenDesCasIDSeq-1] = strWaferXferSeq[i_wfr].destinationCassetteID;
                }
            }
        }
//INN-R170002 Add End
    }
    castIDSeq.length(cassetteIDCnt);                        //DSN000049350
    PPT_METHODTRACE_V2( "", "cassetteIDCnt", cassetteIDCnt);  //DSN000049350
    
//INN-R170002 Add Start
    //------------------------------------------------
    // Check Lot Contamination for Carrier Exchange
    //------------------------------------------------
    for ( k_cas = 0; k_cas < lenDesCasIDSeq; k_cas++ )
    {
        lenLotIDSeq = 0;
        for ( i_wfr = 0; i_wfr < lenWaferXferSeq; i_wfr++ )
        {
            if ( TRUE == strWaferXferSeq[i_wfr].bDestinationCassetteManagedBySiView )
            {
                if( 0 <  CIMFWStrLen(strWaferXferSeq[i_wfr].originalCassetteID.identifier)
                 && 0 <  CIMFWStrLen(strWaferXferSeq[i_wfr].destinationCassetteID.identifier)
                 && 0 != CIMFWStrCmp(strWaferXferSeq[i_wfr].originalCassetteID.identifier, strWaferXferSeq[i_wfr].destinationCassetteID.identifier) )
                {
                    if( 0 == CIMFWStrCmp(moveToCassetteIDSeq[k_cas].identifier, strWaferXferSeq[i_wfr].destinationCassetteID.identifier) )
                    {
                        objWafer_lot_Get_out strWafer_lot_Get_out;
                        rc = wafer_lot_Get(strWafer_lot_Get_out, strObjCommonIn, strWaferXferSeq[i_wfr].waferID);
                        if(rc!= RC_OK)
                        {
                            PPT_METHODTRACE_V2("", "wafer_lot_Get() != RC_OK", strWaferXferSeq[i_wfr].waferID.identifier);
                            strWaferSortReqResult.strResult = strWafer_lot_Get_out.strResult;
                            return( rc );
                        }

                        bLotFind = FALSE;

                        lenLotIDSeq = lotIDs.length();
                        PPT_METHODTRACE_V2("", "lenDesCasIDSeq-->", lenDesCasIDSeq);

                        for ( h_lot = 0; h_lot < lenLotIDSeq; h_lot++ )
                        {
                            if ( 0 == CIMFWStrCmp(strWafer_lot_Get_out.lotID.identifier, lotIDs[h_lot].identifier) )
                            {
                                PPT_METHODTRACE_V2("", "set bLotFind = TRUE", h_lot);
                                bLotFind = TRUE;
                                break;
                            }
                        }
                        if ( bLotFind == FALSE )
                        {
                            PPT_METHODTRACE_V1("", "bLotFind == FALSE");
                            lenLotIDSeq++;
                            lotIDs.length(lenLotIDSeq);
                            lotIDs[lenLotIDSeq-1] = strWafer_lot_Get_out.lotID;
                        }
                    }
                }
            }
        }

        csObjLot_ContaminationInfo_CheckForCarrierExchange_out strLot_ContaminationInfo_CheckForCarrierExchange_out; 
        csObjLot_ContaminationInfo_CheckForCarrierExchange_in  strLot_ContaminationInfo_CheckForCarrierExchange_in;
        strLot_ContaminationInfo_CheckForCarrierExchange_in.carrierID = moveToCassetteIDSeq[k_cas];
        strLot_ContaminationInfo_CheckForCarrierExchange_in.lotIDs    = lotIDs;
        rc = cs_lot_ContaminationInfo_CheckForCarrierExchange(strLot_ContaminationInfo_CheckForCarrierExchange_out,
                                                              strObjCommonIn,
                                                              strLot_ContaminationInfo_CheckForCarrierExchange_in);
        if(rc!= RC_OK)
        {
            PPT_METHODTRACE_V2("", "cs_lot_ContaminationInfo_CheckForCarrierExchange() != RC_OK", moveToCassetteIDSeq[k_cas].identifier);
            strWaferSortReqResult.strResult = strLot_ContaminationInfo_CheckForCarrierExchange_out.strResult;
            return( rc );
        }
    }
//INN-R170002 Add End

//DSN000049350 Add Start
    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

        // Lock Equipment LoadCassette Element (Write)
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
        strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
        strAdvanced_object_Lock_in.keySeq     = castIDSeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_LoadCassette );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strWaferSortReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
    }
//DSN000049350 Add End

    //--------------------------------------------------
    // Collect cassette's equipment ID / Cassette ObjRef
    //--------------------------------------------------
    lenCasIDSeq = cassetteIDSeq.length();
    PPT_METHODTRACE_V2("", "Collect cassette's equipment ID / Cassette ObjRef", lenCasIDSeq);

    for ( j_cas = 0; j_cas < lenCasIDSeq; j_cas++ )
    {
        PPT_METHODTRACE_V2( "", "Collected CassetteID is", cassetteIDSeq[j_cas].identifier );

        objCassette_controlJobID_Get_out   strCassette_controlJobID_Get_out;
        rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out, strObjCommonIn, cassetteIDSeq[j_cas] );
        //---------------------------------------------------
        // Error Judgement
        // If rc was RC_NOT_FOUND_CASSETTE, It is OK for FOSB
        //---------------------------------------------------
        if ( (rc != RC_OK ) && ( rc != RC_NOT_FOUND_CASSETTE ) )
        {
            PPT_METHODTRACE_V1("", "cassette_controlJobID_Get() rc != RC_OK");
            strWaferSortReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
            return( rc );
        }
        if ( CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) > 0 )
        {
            PPT_METHODTRACE_V1( "", "len(controlJobID) > 0" );
            SET_MSG_RC( strWaferSortReqResult,
                        MSG_NOT_CLEARED_CONTROLJOB,
                        RC_NOT_CLEARED_CONTROLJOB );
            return (RC_NOT_CLEARED_CONTROLJOB) ;
        }
//D9000005 add start
        if( rc == RC_OK )
        {
            PPT_METHODTRACE_V1( "", "rc == RC_OK" );

            /*-------------------------------*/
            /*   Check SorterJob existence   */
            /*-------------------------------*/
            pptEquipmentLoadPortAttribute dummyEquipmentPortAttribute;
            objectIdentifierSequence dummyLotIDs, cassetteIDs;
            cassetteIDs.length(1);
            cassetteIDs[0] = cassetteIDSeq[j_cas];

            objWaferSorter_sorterJob_CheckForOperation_out strWaferSorter_sorterJob_CheckForOperation_out;
            objWaferSorter_sorterJob_CheckForOperation_in  strWaferSorter_sorterJob_CheckForOperation_in;
            strWaferSorter_sorterJob_CheckForOperation_in.strEquipmentLoadPortAttribute = dummyEquipmentPortAttribute;
            strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs                   = cassetteIDs;
            strWaferSorter_sorterJob_CheckForOperation_in.lotIDs                        = dummyLotIDs;
            strWaferSorter_sorterJob_CheckForOperation_in.operation                     = CIMFWStrDup(SP_Operation_For_Cast);


            rc = waferSorter_sorterJob_CheckForOperation( strWaferSorter_sorterJob_CheckForOperation_out,
                                                          strObjCommonIn,
                                                          strWaferSorter_sorterJob_CheckForOperation_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "waferSorter_sorterJob_CheckForOperation() != RC_OK" );
                strWaferSortReqResult.strResult = strWaferSorter_sorterJob_CheckForOperation_out.strResult;
                return( rc );
            }
        }
//D9000005 add end
    }
    //P5000019 Add End

    //------------------------------------------------------------
    // If bNotifyToTCSFlag is true, Verify request inside of MM
    // and notify to TCS
    //------------------------------------------------------------
    if ( bNotifyToTCS == TRUE  &&
        CIMFWStrCmp(strEquipment_onlineMode_Get_out.onlineMode, SP_Eqp_OnlineMode_Offline) != 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txWaferSortReq", "bNotifyToTCS == TRUE  && onlineMode == SP_Eqp_OnlineMode_OnlineRemote");

        //---------------------------------------
        // Check input parameter for
        // wafer transfer (Sorter operation)
        //---------------------------------------
        objSorter_waferTransferInfo_Verify_out strSorter_waferTransferInfo_Verify_out;
        //D4000135 rc = sorter_waferTransferInfo_Verify(strSorter_waferTransferInfo_Verify_out, strObjCommonIn,
        //D4000135                                      strWaferXferSeq);
        //D4000135 Start
        //D4000056 rc = sorter_waferTransferInfo_Verify(strSorter_waferTransferInfo_Verify_out, strObjCommonIn,
        //D4000056                                     strWaferXferSeq,originalLocationVerify);
        //2001-9-14 Start
        // If there are any slotmap information,check original location by slotmap 
        rc = sorter_waferTransferInfo_Verify(strSorter_waferTransferInfo_Verify_out, strObjCommonIn,
                                             strWaferXferSeq,SP_Sorter_Location_CheckBy_SlotMap);
        //2001-9-14 End
        //D4000135 End
        if (rc)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txWaferSortReq", "sorter_waferTransferInfo_Verify() rc != RC_OK");
            strWaferSortReqResult.strResult = strSorter_waferTransferInfo_Verify_out.strResult;
            return( rc );
        }
 
        //---------------------------------------
        // Check input parameter and
        // Server data condition
        //---------------------------------------
        objCassette_CheckConditionForWaferSort_out strCassette_CheckConditionForWaferSort_out;
        rc = cassette_CheckConditionForWaferSort( strCassette_CheckConditionForWaferSort_out,
                                                  strObjCommonIn,
                                                  equipmentID,
                                                  strWaferXferSeq );
        if(rc)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txWaferSortReq", "cassette_CheckConditionForWaferSort() rc != RC_OK");
            strWaferSortReqResult.strResult = strCassette_CheckConditionForWaferSort_out.strResult;
            return( rc );
        }


//D4000060        objTCSMgr_SendWaferSortReq_out strTCSMgr_SendWaferSortReq_out;
//D4000060        rc = TCSMgr_SendWaferSortReq(strTCSMgr_SendWaferSortReq_out, strObjCommonIn,
//D4000060                                     strObjCommonIn.strUser, equipmentID, 
//D4000060                                     strWaferXferSeq, claimMemo);
//D4000060
//D4000060        if (rc == RC_OK)
//D4000060        {
//D4000060            SET_MSG_RC(strWaferSortReqResult, MSG_OK, RC_OK);
//D4000060            return( RC_OK );
//D4000060        }
//D4000060        else
//D4000060        {
//D4000060            PPT_METHODTRACE_V1("CS_PPTManager_i:: txWaferSortReq", "TCSMgr_SendWaferSortReq() rc != RC_OK");
//D4000060            strWaferSortReqResult.strResult = strTCSMgr_SendWaferSortReq_out.strResult;
//D4000060            return( rc );
//D4000060        }
//D4000060 add start
        CORBA::String_var tmpSleepTimeValue = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
        CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));
        CORBA::Long sleepTimeValue;
        CORBA::Long retryCountValue;

        if (CIMFWStrLen(tmpSleepTimeValue) == 0)
        {
            sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
        }
        else
        {
//D9000001            sleepTimeValue = atol(tmpSleepTimeValue) ;
            sleepTimeValue = atoi(tmpSleepTimeValue) ;    //D9000001
        }

        if (CIMFWStrLen(tmpRetryCountValue) == 0)
        {
            retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
        }
        else
        {
//D9000001            retryCountValue = atol(tmpRetryCountValue);
            retryCountValue = atoi(tmpRetryCountValue);    //D9000001
        }

        PPT_METHODTRACE_V2("","env value of SP_BIND_SLEEP_TIME_TCS  = ",sleepTimeValue);
        PPT_METHODTRACE_V2("","env value of SP_BIND_RETRY_COUNT_TCS = ",retryCountValue);

        objTCSMgr_SendWaferSortReq_out strTCSMgr_SendWaferSortReq_out;

        //'retryCountValue + 1' means first try plus retry count
        for(CORBA::Long i = 0 ; i < (retryCountValue + 1) ; i++)
        {
            /*--------------------------*/
            /*    Send Request to TCS   */
            /*--------------------------*/
            rc = TCSMgr_SendWaferSortReq( strTCSMgr_SendWaferSortReq_out,
                                          strObjCommonIn,
                                          strObjCommonIn.strUser,
                                          equipmentID,
                                          strWaferXferSeq,
                                          claimMemo );
            PPT_METHODTRACE_V2("","rc = ",rc);

            if(rc == RC_OK)
            {
                PPT_METHODTRACE_V1("","Now TCS subSystem is alive!! Go ahead");
                SET_MSG_RC(strWaferSortReqResult, MSG_OK, RC_OK);
                return( RC_OK );
            }
            else if ( rc == RC_EXT_SERVER_BIND_FAIL ||
                      rc == RC_EXT_SERVER_NIL_OBJ   ||
                      rc == RC_TCS_NO_RESPONSE )
            {
                PPT_METHODTRACE_V2("","TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...",i);
                PPT_METHODTRACE_V2("","now sleeping... ",sleepTimeValue);
                sleep(sleepTimeValue);
                continue;
            }
            else
            {
                PPT_METHODTRACE_V1("", "TCSMgr_SendWaferSortReq() != RC_OK");
                strWaferSortReqResult.strResult = strTCSMgr_SendWaferSortReq_out.strResult;
                return( rc );
            }
        }

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "TCSMgr_SendWaferSortReq() != RC_OK");
            strWaferSortReqResult.strResult = strTCSMgr_SendWaferSortReq_out.strResult;
            return( rc );
        }
//D4000060 add end
    }
    //------------------------------------------------------------
    // If bNotifyToTCSFlag is false, Update MM Data and
    // does not notify to TCS
    //------------------------------------------------------------
    else if ( bNotifyToTCS != TRUE )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txWaferSortReq",
                           "bNotifyToTCS != TRUE  && onlineMode == SP_Eqp_OnlineMode_OnlineRemote");

        pptWaferSortRptResult strWaferSortRptResult;
        rc = txWaferSortRpt (strWaferSortRptResult, strObjCommonIn, 
                             equipmentID,  strWaferXferSeq, claimMemo ) ;

        if (rc)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txWaferSortReq",
                               "txWaferSortRpt() rc != RC_OK");
            strWaferSortReqResult.strResult = strWaferSortRptResult.strResult;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txWaferSortReq", "onlineMode is not SP_Eqp_OnlineMode_OnlineRemote");
        PPT_SET_MSG_RC_KEY2(strWaferSortReqResult, MSG_INVALID_SORTER_OPERATION, RC_INVALID_SORTER_OPERATION,
                            strEquipment_onlineMode_Get_out.onlineMode,
                            equipmentID.identifier);
        return( RC_INVALID_SORTER_OPERATION );
    }

    SET_MSG_RC(strWaferSortReqResult, MSG_OK, RC_OK);
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txWaferSortReq");
    return(RC_OK);
}
