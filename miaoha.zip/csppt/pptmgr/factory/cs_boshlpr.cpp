#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/csppt/source/posppt/pptmgr/factory/cs_boshlpr.cpp, mm_srv_90e_cspp, mm_srv_90e_cspp 4/20/07 15:23:03 [ 7/13/07 19:55:53 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// Siview
// File : cs_boshlpr.cpp
// Description : Implementatoin of Customized global function
//
// ** Notice **
//   This is a sample code for customizing a PPT Manager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT Manager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//
//
// Modeficaiton History:
// Date       Defect   Name             Description
// ---------- -------- ---------------- ----------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya      Initial Release for R5.0
//

//#ifdef IMIZED

#include "bospatmg.hpp"
#include "bospcdmg.hpp"
#include "bospdcmg.hpp"
//#include "bospdomg.hpp"
#include "bospdrmg.hpp"
#include "bospmcmg.hpp"
#include "bospmsds.hpp"
#include "bosppcdf.hpp"
#include "bospprmg.hpp"
#include "bospprsp.hpp"
#include "bosppsmg.hpp"
#include "bosprcmg.hpp"
#include "bosppl.hpp"
#include "bospdp.hpp"
#include "bospfa.hpp"
#include "bospevmg.hpp"
#include "bospabcl.hpp"
#include "bospenmg.hpp"
#include "bospptsmg.hpp"
#include "bospabcl.hpp"  //

#include "cs_bosfwpptmgr.hpp"

#include "boshlprvarinfomgr.hpp"
#include "boshlprbrsmanager.hpp"

GlobalComposedObjectTable* cs_global_func()
{
  GlobalComposedObjectTable *GCOT = NULL ;
  GCOT = new GlobalComposedObjectTable() ;

  if( GCOT != NULL )
  {
      global_func_BOSPAtMg( GCOT ) ;
      global_func_BOSPCdMg( GCOT ) ;
      global_func_BOSPDcMg( GCOT ) ;
      // global_func_BOSPDoMg( GCOT ) ;
      global_func_BOSPDp( GCOT ) ;
      global_func_BOSPDrMg( GCOT ) ;
      global_func_BOSPFa( GCOT ) ;
      global_func_BOSPMcMg( GCOT ) ;
      global_func_BOSPMsDs( GCOT ) ;
      global_func_BOSPPcDf( GCOT ) ;
      global_func_BOSPPl( GCOT ) ;
      global_func_BOSPPrMg( GCOT ) ;
      global_func_BOSPPrSp( GCOT ) ;
      global_func_BOSPPsMg( GCOT ) ;
      global_func_BOSPRcMg( GCOT ) ;
      global_func_BOSPEvMg( GCOT ) ;
      global_func_BOSPAbCl( GCOT ) ;
      global_func_BOSPEnMg( GCOT ) ;
      global_func_BOSPPtsMg( GCOT ) ;

      global_func_CS_BOSPPTMgr( GCOT ) ;

      global_func_VarInfoMgr(GCOT) ;
      global_func_BRSManager(GCOT) ;

  }
  return GCOT ;
}


//#endif

