// SCCS ID: @(#) 1.1 superpos/src/csppt/source/posppt/pptmgr/factory/cs_bosfwpptmgr.hpp, mm_srv_90e_cspp, mm_srv_90e_cspp 4/20/07 15:25:18 [ 7/13/07 19:55:05 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView - PPT Manager
// Name: cd_bosfwpptmgr.hpp
// Description : Definition of Global Function for Customized PPTManager
//
// ** Notice **
//   This is a sample code for customizing a PPT Manager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT Manager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//
// Change history:
//
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya      Initial Release for R5.0
//

#include "IMProt.h"

void global_func_CS_BOSPPTMgr( GlobalComposedObjectTable *GCOT ) ;
