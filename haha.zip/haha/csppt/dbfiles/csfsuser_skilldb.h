//
// (c) Copyright: IBM Services Company Ltd, 2017, 2027. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017, 2027. All rights reserved.
//
// SiView
// Name: csfsuser_skilldb.h
//
// Modification history :
// Date       Defect#       Person           Comments
// ---------- ------------  -------------- -------------------------------------------
// 2017/09/01 INN-R170008   Menghua Yin      for User_skill table
//

char hCSFSUSER_SKILLUSER_ID[65];                         // Host Variable for USER_ID.
char hCSFSUSER_SKILLSKILL_ID[129];                       // Host Variable for SKILL_ID.
char hCSFSUSER_SKILLCERTIED_DATE[27];                    // Host Variable for CERTIED_DATE.
char HV_BUFFER[4096];
