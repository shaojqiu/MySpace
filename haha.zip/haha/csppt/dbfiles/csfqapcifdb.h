//
// (c) Copyright: IBM Taiwan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: csfqapcifdb.h
//
// Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------  -------------- -------------------------------------------
// 2017/10/17 INN-R170009   Qufd           Add APC Queue 
//

char hCSFQAPCIFEVENT_ID[65];
char hCSFQAPCIFLOT_ID[65];
char hCSFQAPCIFCTRLJOB_ID[65];
char hCSFQAPCIFEVENT_TIME[27];
