//
// Modification History :
// Date       Version        Author         Request No.          Comment
// ---------- -------------  -------------- -------------------- -------------------------------
// 2017/10/17 INN-R17001701  LiHejing       INN-R170017          Initial Release
//
char             hCSFSBWS_WAFERBWS_ID[65];
char             hCSFSBWS_WAFERZONE_ID[65];
char             hCSFSBWS_WAFERWAFER_ID[65];
char             hCSFSBWS_WAFERWAFERGRADE_ID[65];
char             hCSFSBWS_WAFERLOT_ID[65];
char             hCSFSBWS_WAFERBANK_ID[65];
