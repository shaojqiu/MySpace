//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txBWSWaferOutAndSTBReq.cpp
//
#include "cs_pptmgr.hpp"
//
// Class: PPTManager
//
// Service: txBWSWaferOutAndSTBReq()
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------- -------------- -------------------------------------------
// 2017-10-18 INN-R170016   Thomas Song    NPW Monitor Customization 
//
// Description:
//
// Return:
//     long
//
// Parameter:
//     csBWSWaferOutAndSTBReqResult&            strBWSWaferOutAndSTBReqResult
//     const pptObjCommonIn&                    strObjCommonIn
//     const csBWSWaferOutAndSTBReqInParm&      strBWSWaferOutAndSTBReqInParm
//     const char *                             claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//
CORBA::Long CS_PPTManager_i::cs_txBWSWaferOutAndSTBReq(
    csBWSWaferOutAndSTBReqResult&            strBWSWaferOutAndSTBReqResult,
    const pptObjCommonIn&                    strObjCommonIn,
    const csBWSWaferOutAndSTBReqInParm&      strBWSWaferOutAndSTBReqInParm,
    const char*                                      claimMemo
  	CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txBWSWaferOutAndSTBReq")
    CORBA::Long rc = RC_OK ;

    
    //---------------------------
    //  Set out structure
    //---------------------------
    SET_MSG_RC(strBWSWaferOutAndSTBReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txBWSWaferOutAndSTBReq")
    return( RC_OK );

}