//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txDowngradeItemListInq.cpp
//
#include "cs_pptmgr.hpp"
//
// Class: PPTManager
//
// Service: txDowngradeItemListInq()
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------- -------------- -------------------------------------------
// 2017-10-18 INN-R170016   Thomas Song    NPW Monitor Customization 
//
// Description:
//
// Return:
//     long
//
// Parameter:
//     csDowngradeItemListInqResult&            strDowngradeItemListInqResult
//     const pptObjCommonIn&                    strObjCommonIn
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//
CORBA::Long CS_PPTManager_i::cs_txDowngradeItemListInq(
    csDowngradeItemListInqResult&            strDowngradeItemListInqResult,
    const pptObjCommonIn&                    strObjCommonIn
  	CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txDowngradeItemListInq")
    CORBA::Long rc = RC_OK ;

    
    //---------------------------
    //  Set out structure
    //---------------------------
    SET_MSG_RC(strDowngradeItemListInqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txDowngradeItemListInq")
    return( RC_OK );

}