#ifndef lint
static char *sccsid =  "@(#) 1.3 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txWIPLotResetReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/16/07 18:57:58 [ 11/16/07 18:57:59 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2014. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2014. All rights reserved.
//
// SiView
// Name: cs_txWIPLotResetReqOR.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: txWIPLotResetReq()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2014/10/13 DSN000085793 JJ.Zhang       WIP Lot Reset Function
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/08/28 INN-R170002  Yangxiaojun    Overide txWIPLotResetReq
// 2017/09/12 INN-R170002  Thomas Song    Contamination Control
//
// [Function Description]:
//   update PD contents for the lot by default (update level = 0),
//   or if user specifies (update level =1), the PD ID can be updated together.
//
// [Input Parameters]:
//  pptWIPLotResetReqResult&        strWIPLotResetReqResult,
//  const pptObjCommonIn&           strObjCommonIn
//  const pptWIPLotResetReqInParm&  strWIPLotResetReqInParm
//  const char *                    claimMemo
//
//
// [Return Value]:
//   Return Code                 Message ID
//   --------------------------- -------------------------------------
//   RC_OK                       MSG_OK
//
// [Pseudo code]:
//

CORBA::Long CS_PPTManager_i::txWIPLotResetReq (pptWIPLotResetReqResult&       strWIPLotResetReqResult,
                                           const pptObjCommonIn&           strObjCommonIn,
                                           const pptWIPLotResetReqInParm&  strWIPLotResetReqInParm,
                                           const char *                    claimMemo
                                           CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txWIPLotResetReq") ;
    CORBA::Long rc = RC_OK ;

    CORBA::Long nLen = strWIPLotResetReqInParm.strWIPLotResetAttributes.length();
    PPT_METHODTRACE_V2("", "strWIPLotResetAttributes.length()",nLen) ;

    CORBA::Long i=0;
    //--------------------------------
    // get updateLevel
    //--------------------------------
    CORBA::Long updateLevel = strWIPLotResetReqInParm.updateLevel;
    if( -1 == updateLevel )
    {
        PPT_METHODTRACE_V1("", "strWIPLotResetReqInParm.updateLevel==-1") ;
        updateLevel = atol(getenv(SP_WIP_LOT_RESET_UPDATE_LEVEL));
    }
    if( (0 != updateLevel) && (1 != updateLevel ) )
    {
        PPT_METHODTRACE_V2( "", "updateLevel is not correct.", updateLevel );
        SET_MSG_RC( strWIPLotResetReqResult, MSG_INVALID_PARAMETER, RC_INVALID_PARAMETER );
        return RC_INVALID_PARAMETER;
    }

    //--------------------------------
    // Lock objects to be updated
    //--------------------------------
    for (i=0; i < nLen; i++)
    {
        objectIdentifier aLotID = strWIPLotResetReqInParm.strWIPLotResetAttributes[i].lotID;
        //--------------------------------
        // Get cassette / lot connection
        //--------------------------------
        objObject_Lock_out strObject_Lock_out;
        objLot_cassette_Get_out strLot_cassette_Get_out ;
        rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, aLotID);
        if ( rc == RC_NOT_FOUND_CST )
        {
            PPT_METHODTRACE_V1("", "lot_cassette_Get() == RC_NOT_FOUND_CST") ;
        }
        else if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_cassette_Get() != RC_OK") ;
            strWIPLotResetReqResult.strResult = strLot_cassette_Get_out.strResult ;
            return(rc);
        }
        else
        {
            //Lock cassette
            rc = object_Lock( strObject_Lock_out, strObjCommonIn, strLot_cassette_Get_out.cassetteID, SP_ClassName_PosCassette );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "For Cassette, object_Lock() != RC_OK" ) ;
                strWIPLotResetReqResult.strResult = strObject_Lock_out.strResult ;
                return( rc );
            }
        }

        //Lock Lot
        rc = object_Lock( strObject_Lock_out, strObjCommonIn,aLotID, SP_ClassName_PosLot );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() rc != RC_OK", rc);
            strWIPLotResetReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    }

    //--------------------------------
    // Check Lot/Cassette conditions
    //--------------------------------
    for (i=0; i < nLen; i++)
    {
        objectIdentifier aLotID = strWIPLotResetReqInParm.strWIPLotResetAttributes[i].lotID;
        //----------------------------------
        // candidate lot should have CJ
        //----------------------------------
        objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
        rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, aLotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_controlJobID_Get() != RC_OK", rc);
            strWIPLotResetReqResult.strResult = strLot_controlJobID_Get_out.strResult;
            return( rc );
        }
        if ( 0 == CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) )
        {
            PPT_METHODTRACE_V1("", "strLot_controlJobID_Get_out.controlJobID.identifier == 0");
        }
        else
        {
            PPT_METHODTRACE_V1("", "strLot_controlJobID_Get_out.controlJobID.identifier != 0");
            PPT_SET_MSG_RC_KEY2( strWIPLotResetReqResult,
                                 MSG_LOT_CTLJOBID_FILLED,
                                 RC_LOT_CTLJOBID_FILLED,
                                 aLotID.identifier,
                                 strLot_controlJobID_Get_out.controlJobID.identifier );
            return RC_LOT_CTLJOBID_FILLED;
        }

        //------------------------------------
        // Check LOCK Hold.
        //------------------------------------
        objectIdentifierSequence lotIDSeq;
        lotIDSeq.length(1);
        lotIDSeq[0] = aLotID;
        objLot_CheckLockHoldConditionForOperation_out  strLot_CheckLockHoldConditionForOperation_out;
        rc = lot_CheckLockHoldConditionForOperation( strLot_CheckLockHoldConditionForOperation_out, strObjCommonIn, lotIDSeq );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_CheckLockHoldConditionForOperation rc != RC_OK", lotIDSeq[0].identifier );
            strWIPLotResetReqResult.strResult = strLot_CheckLockHoldConditionForOperation_out.strResult;
            return ( rc );
        }

        //----------------------------------
        //  Get InPostProcessFlag of Lot
        //----------------------------------
        objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
        strLot_inPostProcessFlag_Get_in.lotID = aLotID;

        objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
        rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                        strObjCommonIn,
                                        strLot_inPostProcessFlag_Get_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
            strWIPLotResetReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
            return( rc );
        }
        //----------------------------------------------
        //  If Lot is in post process, returns error
        //----------------------------------------------
        if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
        {
            PPT_METHODTRACE_V1("", "Lot is in post process.");
            PPT_SET_MSG_RC_KEY( strWIPLotResetReqResult,
                                MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                aLotID.identifier );
            return( RC_LOT_INPOSTPROCESS );
        }

        //----------------------------------------------
        //  Check Lot Process State
        //----------------------------------------------
        objLot_processState_Get_out strLot_processState_Get_out;
        rc = lot_processState_Get(strLot_processState_Get_out,strObjCommonIn, aLotID );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_processState_Get() != RC_OK", i) ;
            strWIPLotResetReqResult.strResult =  strLot_processState_Get_out.strResult ;
            return(rc);
        }
        else if (CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Waiting) != 0 )
        {
            PPT_METHODTRACE_V2("", "CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Waiting) != 0", i) ;
            PPT_SET_MSG_RC_KEY2( strWIPLotResetReqResult,
                                 MSG_INVALID_LOT_PROCSTAT,
                                 RC_INVALID_LOT_PROCSTAT,
                                 aLotID.identifier,
                                 strLot_processState_Get_out.theLotProcessState ) ;
            return(RC_INVALID_LOT_PROCSTAT);
        }
        //----------------------------------------------
        //  Check Finished State of lot
        //----------------------------------------------
        objLot_finishedState_Get_out strLot_finishedState_Get_out;
        rc = lot_finishedState_Get(strLot_finishedState_Get_out, strObjCommonIn, aLotID);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_finishedState_Get() != RC_OK" );
            strWIPLotResetReqResult.strResult = strLot_finishedState_Get_out.strResult;
            return rc;
        }
        else if (CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,CIMFW_Lot_FinishedState_Scrapped) == 0 ||
                 CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,CIMFW_Lot_FinishedState_Emptied)  == 0 ||
                 CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,CIMFW_Lot_FinishedState_Completed)== 0 ||
                 CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,SP_LOT_FINISHED_STATE_STACKED)    == 0)
        {
            PPT_METHODTRACE_V2("", "lotFinishedState", strLot_finishedState_Get_out.lotFinishedState);
            PPT_SET_MSG_RC_KEY(strWIPLotResetReqResult,
                               MSG_INVALID_LOT_FINISHSTAT,
                               RC_INVALID_LOT_FINISHSTAT,
                               strLot_finishedState_Get_out.lotFinishedState) ;
            return(RC_INVALID_LOT_FINISHSTAT);
        }

        //----------------------------------------------
        //  Check inventory State of lot
        //----------------------------------------------
        objLot_inventoryState_Get_out strLot_inventoryState_Get_out ;
        rc = lot_inventoryState_Get(strLot_inventoryState_Get_out,strObjCommonIn,aLotID);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeLocateReq", "lot_inventoryState_Get() != RC_OK") ;
            strWIPLotResetReqResult.strResult = strLot_inventoryState_Get_out.strResult ;
            return(rc);
        }
        else if ( 0 == CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState,SP_Lot_InventoryState_InBank))
        {
            PPT_METHODTRACE_V1("", "CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState,SP_Lot_InventoryState_InBank) == 0") ;
            PPT_SET_MSG_RC_KEY2(strWIPLotResetReqResult,
                                MSG_INVALID_LOT_INVENTORYSTAT,
                                RC_INVALID_LOT_INVENTORYSTAT,
                                aLotID.identifier,
                                strLot_inventoryState_Get_out.lotInventoryState) ;
            return(RC_INVALID_LOT_INVENTORYSTAT);
        }

        //----------------------------------------------
        //  Check backup State of lot
        //----------------------------------------------
        objLot_backupInfo_Get_out strLot_backupInfo_Get_out;
        rc = lot_backupInfo_Get(strLot_backupInfo_Get_out, strObjCommonIn,aLotID);
        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "lot_backupInfo_Get() != RC_OK" );
            strWIPLotResetReqResult.strResult = strLot_backupInfo_Get_out.strResult;
            return( rc );
        }

        if( strLot_backupInfo_Get_out.strLotBackupInfo.currentLocationFlag == FALSE ||
            strLot_backupInfo_Get_out.strLotBackupInfo.transferFlag == TRUE )
        {
            PPT_METHODTRACE_V1("", "Lot is on backup process(site).");
            PPT_SET_MSG_RC_KEY( strWIPLotResetReqResult,
                                MSG_LOT_IN_OTHERSITE,
                                RC_LOT_IN_OTHERSITE,
                                aLotID.identifier );
            return( RC_LOT_IN_OTHERSITE );
        }

        //-------------------------------
        // Check Lot interFabXferState
        //-------------------------------
        objLot_interFabXferState_Get_out strLot_interFabXferState_Get_out;
        objLot_interFabXferState_Get_in  strLot_interFabXferState_Get_in;
        strLot_interFabXferState_Get_in.lotID = aLotID;
        rc = lot_interFabXferState_Get( strLot_interFabXferState_Get_out, strObjCommonIn,
                                        strLot_interFabXferState_Get_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_interFabXferState_Get() != RC_OK", rc);
            strWIPLotResetReqResult.strResult = strLot_interFabXferState_Get_out.strResult;
            return rc;
        }

        if( 0 == CIMFWStrCmp(strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Transferring)
         || 0 == CIMFWStrCmp(strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Required) )
        {
            PPT_METHODTRACE_V2("", "interFabXferState is Transferring or Required",
                               strLot_interFabXferState_Get_out.interFabXferState );
            PPT_SET_MSG_RC_KEY2( strWIPLotResetReqResult,
                                 MSG_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ,
                                 RC_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ,
                                 aLotID.identifier, strLot_interFabXferState_Get_out.interFabXferState );
            return RC_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ;
        }

        //-------------------------------
        //  Check FlowBatch Condition
        //-------------------------------
        objLot_flowBatchID_Get_out strLot_flowBatchID_Get_out;
        rc = lot_flowBatchID_Get( strLot_flowBatchID_Get_out, strObjCommonIn, aLotID );

        if ( rc == RC_LOT_FLOW_BATCH_ID_FILLED )
        {
            PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() == RC_LOT_FLOW_BATCH_ID_FILLED") ;
            SET_MSG_RC( strWIPLotResetReqResult, MSG_FLOW_BATCH_LIMITATION, RC_FLOW_BATCH_LIMITATION );
            return RC_FLOW_BATCH_LIMITATION;
        }
        else if ( rc == RC_LOT_FLOW_BATCH_ID_BLANK )
        {
            PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() == RC_LOT_BATCH_ID_BLANK") ;
        }
        else
        {
            PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() != RC_OK") ;
            strWIPLotResetReqResult.strResult = strLot_flowBatchID_Get_out.strResult ;
            return( rc );
        }

        //---------------------------------------------------------
        //   Check whether Lot is on the specified Route/Operation
        //---------------------------------------------------------
        objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
        rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out, strObjCommonIn, aLotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_currentOperationInfo_Get() != RC_OK");
            strWIPLotResetReqResult.strResult  = strLot_currentOperationInfo_Get_out.strResult;
            return( rc );
        }

        PPT_METHODTRACE_V2("","Lot's currentRouteID         :", strLot_currentOperationInfo_Get_out.routeID.identifier );
        PPT_METHODTRACE_V2("","Lot's currentOperationNumber :", strLot_currentOperationInfo_Get_out.operationNumber    );

        if ( CIMFWStrCmp(strWIPLotResetReqInParm.strWIPLotResetAttributes[i].routeID.identifier, strLot_currentOperationInfo_Get_out.routeID.identifier) == 0 &&
             CIMFWStrCmp(strWIPLotResetReqInParm.strWIPLotResetAttributes[i].operationNumber,    strLot_currentOperationInfo_Get_out.operationNumber   ) == 0 )
        {
            PPT_METHODTRACE_V1("","Route/Operation check OK. Go ahead...");
        }
        else
        {
            PPT_METHODTRACE_V1("","Route/Operation check NG.");
            PPT_SET_MSG_RC_KEY2(strWIPLotResetReqResult,
                                MSG_NOT_SAME_ROUTE,
                                RC_NOT_SAME_ROUTE,
                                "Input parameter's currentRouteID/currentOperationNumber",
                                "lot's current currentRouteID/currentOperationNumber");
            return( RC_NOT_SAME_ROUTE );
        } 

        //-------------------------------
        //  call lot_WIPInfoReset
        //-------------------------------
        objLot_WIPInfoReset_in  strLot_WIPInfoReset_in;
        strLot_WIPInfoReset_in.updateLevel = updateLevel;
        strLot_WIPInfoReset_in.lotID       = strWIPLotResetReqInParm.strWIPLotResetAttributes[i].lotID;
        strLot_WIPInfoReset_in.routeID     = strWIPLotResetReqInParm.strWIPLotResetAttributes[i].routeID;
        strLot_WIPInfoReset_in.operationNumber = strWIPLotResetReqInParm.strWIPLotResetAttributes[i].operationNumber;

        objLot_WIPInfoReset_out strLot_WIPInfoReset_out;
        rc = lot_WIPInfoReset( strLot_WIPInfoReset_out, strObjCommonIn, strLot_WIPInfoReset_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_WIPInfoReset() != RC_OK", rc);
            strWIPLotResetReqResult.strResult = strLot_WIPInfoReset_out.strResult;
            return rc;
        }
        //---------------------------------
        // UpDate RequiredCassetteCategory
        //---------------------------------
        if( 1 == updateLevel )
        {
            PPT_METHODTRACE_V1("","updateLevel=1, call lot_CassetteCategory_UpdateForContaminationControl");
            objLot_CassetteCategory_UpdateForContaminationControl_out strLot_CassetteCategory_UpdateForContaminationControl_out;
            rc = lot_CassetteCategory_UpdateForContaminationControl( strLot_CassetteCategory_UpdateForContaminationControl_out,
                                                       strObjCommonIn,
                                                       aLotID );

            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V1("","lot_CassetteCategory_UpdateForContaminationControl != RC_OK");
                strWIPLotResetReqResult.strResult = strLot_CassetteCategory_UpdateForContaminationControl_out.strResult;
                return rc;
            }
        }        
       
        //---------------------------------
        //  Update Cassette's MultiLotType
        //---------------------------------
        objLot_cassette_Get_out strLot_cassette_Get_out ;
        rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, aLotID);
        if ( rc == RC_NOT_FOUND_CST )
        {
            PPT_METHODTRACE_V1("", "lot_cassette_Get() == RC_NOT_FOUND_CST") ;
        }
        else if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "lot_cassette_Get() != RC_OK") ;
            strWIPLotResetReqResult.strResult = strLot_cassette_Get_out.strResult ;
            return(rc);
        }
        else
        {
            objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
            rc = cassette_multiLotType_Update(strCassette_multiLotType_Update_out, strObjCommonIn, strLot_cassette_Get_out.cassetteID);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "cassette_multiLotType_Update() != RC_OK") ;
                strWIPLotResetReqResult.strResult = strCassette_multiLotType_Update_out.strResult ;
                return(rc);
            }
        }
        
        //INN-R170002 Add Start
        //--------------------------------------------------------------------------------------------------
        // Check Contamination Level
        //--------------------------------------------------------------------------------------------------     
        csObjLot_ContaminationInfo_CheckForMove_in strLot_ContaminationInfo_CheckForMove_in;
        strLot_ContaminationInfo_CheckForMove_in.lotID = aLotID;
        strLot_ContaminationInfo_CheckForMove_in.carrierID = strLot_cassette_Get_out.cassetteID;                                                            
        csObjLot_ContaminationInfo_CheckForMove_out strLot_ContaminationInfo_CheckForMove_out;
        rc = cs_lot_ContaminationInfo_CheckForMove( strLot_ContaminationInfo_CheckForMove_out,
                                                    strObjCommonIn,
                                                    strLot_ContaminationInfo_CheckForMove_in );

        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V1("","cs_lot_ContaminationInfo_CheckForMove != RC_OK");
            strWIPLotResetReqResult.strResult = strLot_ContaminationInfo_CheckForMove_out.strResult;
            return rc;
        }

        if(strLot_ContaminationInfo_CheckForMove_out.holdReqFlag == TRUE)
        {
            pptHoldLotReqResult strHoldLotReqResult;
            pptHoldListSequence strLotHoldReqList( 1 );
            strLotHoldReqList.length( 1 );

            strLotHoldReqList[0].holdType                    = CIMFWStrDup( SP_HoldType_LotHold );
            strLotHoldReqList[0].holdReasonCodeID.identifier = CIMFWStrDup( CS_SP_Reason_ContaminationMismatchHold );
            strLotHoldReqList[0].holdUserID                  = strObjCommonIn.strUser.userID;
            strLotHoldReqList[0].responsibleOperationMark    = CIMFWStrDup( SP_ResponsibleOperation_Current );
            strLotHoldReqList[0].claimMemo                   = claimMemo;

            rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn,
                               aLotID,
                               strLotHoldReqList );

            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
                strWIPLotResetReqResult.strResult = strHoldLotReqResult.strResult ;
                return rc ;
            }
            else
            {
                PPT_METHODTRACE_V1("", "txHoldLotReq() == RC_OK For LotHold") ;
            }
        }
//INN-R170002 Add End        

        //---------------------------------
        // Make History
        //---------------------------------
        if( TRUE == strLot_WIPInfoReset_out.opehsAddFlag )
        {
            PPT_METHODTRACE_V1("", "call lotOperationMoveEvent_MakeChangeRoute" ) ;

            objLotOperationMoveEvent_MakeChangeRoute_out strLotOperationMoveEvent_MakeChangeRoute_out;
            rc = lotOperationMoveEvent_MakeChangeRoute(strLotOperationMoveEvent_MakeChangeRoute_out,
                                                       strObjCommonIn,
                                                       strObjCommonIn.transactionID,
                                                       aLotID,
                                                       strLot_WIPInfoReset_out.oldCurrentPOData,
                                                       claimMemo);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "lotChangeEvent_Make() != RC_OK") ;
                strWIPLotResetReqResult.strResult = strLotOperationMoveEvent_MakeChangeRoute_out.strResult;
            }
        }
    }

    SET_MSG_RC(strWIPLotResetReqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txWIPLotResetReq") ;
    return(RC_OK);
}
