//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txDowngradeItemUpdateReq.cpp
//
#include "cs_pptmgr.hpp"
//
// Class: PPTManager
//
// Service: cs_txDowngradeItemUpdateReq()
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------- -------------- -------------------------------------------
// 2017/10/18 INN-R170016   Yangxiaojun    NPW Monitor Customization
//
// Description:
//
// Return:
//     long
//
// Parameter:
//      csDowngradeItemUpdateReqResult&                 strDowngradeItemUpdateReqResult
//      const pptObjCommonIn&                           strObjCommonIn
//      const csDowngradeItemUpdateReqInParm&           strDowngradeItemUpdateReqInParm
//      const char*                                     claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//

CORBA::Long CS_PPTManager_i::cs_txDowngradeItemUpdateReq(
    csDowngradeItemUpdateReqResult&                 strDowngradeItemUpdateReqResult,
    const pptObjCommonIn&                           strObjCommonIn,
    const csDowngradeItemUpdateReqInParm&           strDowngradeItemUpdateReqInParm,
    const char*                                     claimMemo
    CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txDowngradeItemUpdateReq")
    CORBA::Long rc = RC_OK;
        
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txDowngradeItemUpdateReq")
    return( RC_OK );
}
