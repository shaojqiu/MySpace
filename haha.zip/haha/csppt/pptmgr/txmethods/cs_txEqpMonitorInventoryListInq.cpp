//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txEqpMonitorInventoryListInq.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: cs_txEqpMonitorInventoryListInq()
//
// Change history:
// Date       Defect#       Person         Comments
// ---------- ------------- -------------- -------------------------------------------
// 2017-10-17 INN-R170016   JQ.Shao        NPW Management Initial Release
//
// Description:
//
// Return:
//     long
//
// Parameter:
//      csEqpMonitorInventoryListInqResult&       strEqpMonitorInventoryListInqResult,
//      const pptObjCommonIn&                     strObjCommonIn,
//      csEqpMonitorInventoryListInqInParm        strEqpMonitorInventoryListInqInParm
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_txEqpMonitorInventoryListInq(
    csEqpMonitorInventoryListInqResult&    strEqpMonitorInventoryListInqResult,
    const pptObjCommonIn&                  strObjCommonIn,
    csEqpMonitorInventoryListInqInParm     strEqpMonitorInventoryListInqInParm
    CORBAENV_LAST_CPP)        
{
    /*------------------------------------------------------------------------*/
    /*   Return Code Initialization                                           */
    /*------------------------------------------------------------------------*/
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txEqpMonitorInventoryListInq")
    PPT_METHODTRACE_V2("", "in para npwType ", strEqpMonitorInventoryListInqInParm.npwType);
    PPT_METHODTRACE_V2("", "in para productID ", strEqpMonitorInventoryListInqInParm.productID);
    
    CORBA::Long rc = RC_OK ;
    
    csObjEqpMonitorInventory_ListGetDR_in_struct strEqpMonitorInventory_ListGetDR_in;
    strEqpMonitorInventory_ListGetDR_in.npwType    = CIMFWStrDup(strEqpMonitorInventoryListInqInParm.npwType);
    strEqpMonitorInventory_ListGetDR_in.productID  = CIMFWStrDup(strEqpMonitorInventoryListInqInParm.productID);

    csObjEqpMonitorInventory_ListGetDR_out strEqpMonitorInventory_ListGetDR_out;
    rc = cs_eqpMonitorInventory_list_GetDR( strEqpMonitorInventory_ListGetDR_out,
                                            strObjCommonIn,
                                            strEqpMonitorInventory_ListGetDR_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cs_eqpMonitorInventory_list_GetDR.dr() rc != RC_OK");
        strEqpMonitorInventoryListInqResult.strResult = strEqpMonitorInventory_ListGetDR_out.strResult;
        return( rc );
    }

    strEqpMonitorInventoryListInqResult.strEqpMonitorInventoryInfoSeq = strEqpMonitorInventory_ListGetDR_out.strEqpMonitorInventoryInfoSeq;
    strEqpMonitorInventoryListInqResult.npwType = strEqpMonitorInventoryListInqInParm.npwType;
    strEqpMonitorInventoryListInqResult.strResult = strEqpMonitorInventory_ListGetDR_out.strResult;

    SET_MSG_RC(strEqpMonitorInventoryListInqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: cs_txEqpMonitorInventoryListInq")
    return( RC_OK );
}
