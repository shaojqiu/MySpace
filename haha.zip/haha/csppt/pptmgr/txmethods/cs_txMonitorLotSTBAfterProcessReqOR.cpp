#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txMonitorLotSTBAfterProcessReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:27:16 [ 7/13/07 21:27:17 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cs_txMonitorLotSTBAfterProcessReqOR.cpp
//

#include "cs_pptmgr.hpp"

#include "pmc.hh"

// Class: CS_PPTManager
//
// Service: txMonitorLotSTBAfterProcessReq()
//
// Change history:
// Date       Defect#    Person         Comments
// ---------- ---------- -------------- -------------------------------------------
// 2000/08/17            O.Sugiyama     Initial Release
// 2000/10/23 P3000280   S.Kawabe       Boolean variable initialize 
// 2001/07/12 D4000016   M.Shimizu      Contamination Control(Copper/Non Copper [R40 Core])
// 2002/01/28 P4100088   K.Matsuei      Mistaked set of Coding.
// 2002/07/30 D4200029   K.Kimura       Process Hold Control
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2007/06/12 D9000005   H.Hotta        WaferSorter automation support.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2012/12/04 DSN000049350 K.Yamaoku      Equipment parallel processing support (P2)
// 2016/05/17 PSN000102296 C.Mo           STB doesn't check sorter job as source cassette
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/07 INN-R170002  JJ.Zhang       Contamination Control
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    pptMonitorLotSTBAfterProcessReqResult&  strMonitorLotSTBAfterProcessReqResult
//    const pptObjCommonIn&                   strObjCommonIn
//    const objectIdentifier&                 processEquipmentID
//    const char *                            stbLotSubLotType
//    const pptNewLotAttributes&              strNewLotAttributes
//    const objectIdentifierSequence&         productLotIDs
//    const char *                            claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::txMonitorLotSTBAfterProcessReq (
    pptMonitorLotSTBAfterProcessReqResult&  strMonitorLotSTBAfterProcessReqResult, 
    const pptObjCommonIn&                   strObjCommonIn,  
    const objectIdentifier&                 processEquipmentID, 
    const char *                            stbLotSubLotType, 
    const pptNewLotAttributes&              strNewLotAttributes, 
    const objectIdentifierSequence&         productLotIDs, 
//D6000025     const char *                            claimMemo, 
//D6000025     CORBA::Environment &                    IT_env)
    const char *                            claimMemo  //D6000025
    CORBAENV_LAST_CPP)                                 //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq");
    CORBA::Long rc = 0;

    //--------------------------------
    // Prepare Temporary local structure of tmpNewLotAttributes
    //--------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "Prepare Temporary local structure of tmpNewLotAttributes");
    pptNewLotAttributes tmpNewLotAttributes;
    tmpNewLotAttributes = strNewLotAttributes;

    //--------------------------------
    // Check input productionLot Sequence length
    //--------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "Check input productionLot Sequence length");

    if (productLotIDs.length() == 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "length of productLotIDs == 0");
        SET_MSG_RC(strMonitorLotSTBAfterProcessReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM);
        return( RC_INVALID_INPUT_PARM );
    }

//DSN000049350 Add Start
    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = processEquipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXPCC013" ); // TxMonitorLotSTBAfterProcessReq
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

    PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", processEquipmentID.identifier );
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strMonitorLotSTBAfterProcessReqResult.strResult = strObject_lockMode_Get_out.strResult;
        return( rc );
    }

    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;

    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = processEquipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strMonitorLotSTBAfterProcessReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }

        // Lock Equipment LoadCassette Element (Write)
        stringSequence loadCastSeq;
        loadCastSeq.length(1);
        loadCastSeq[0] = tmpNewLotAttributes.cassetteID.identifier;
        strAdvanced_object_Lock_in.objectID   = processEquipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
        strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
        strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_LoadCassette );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strMonitorLotSTBAfterProcessReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }

        /*---------------------------------*/
        /*   Get Cassette's ControlJobID   */
        /*---------------------------------*/
        PPT_METHODTRACE_V1( "", "Get Cassette's ControlJobID");
        objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;
        rc = cassette_controlJobID_Get(strCassette_controlJobID_Get_out, strObjCommonIn, tmpNewLotAttributes.cassetteID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK");
            strMonitorLotSTBAfterProcessReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
            return( rc );
        }

        if ( CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) > 0 )
        {
            PPT_METHODTRACE_V1( "", "len(controlJobID) > 0" );

            /*------------------------------*/
            /*   Lock ControlJob Object     */
            /*------------------------------*/

            PPT_METHODTRACE_V2( "", "calling object_Lock()", SP_ClassName_PosControlJob );
            rc = object_Lock( strObject_Lock_out,
                              strObjCommonIn,
                              strCassette_controlJobID_Get_out.controlJobID,
                              SP_ClassName_PosControlJob );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                strMonitorLotSTBAfterProcessReqResult.strResult = strObject_Lock_out.strResult;
                return( rc );
            }
        }
    }
//DSN000049350 Add End

    //--------------------------------
    //   Lock objects of cassette to be updated
    //--------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "Lock objects of cassette to be updated");

//DSN000049350    objObject_Lock_out strObject_Lock_out;
    rc = object_Lock(strObject_Lock_out, strObjCommonIn,
                     tmpNewLotAttributes.cassetteID,
                     SP_ClassName_PosCassette); // for tmpNewLotAttributes.cassetteID
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "object_Lock() rc != RC_OK");
        strMonitorLotSTBAfterProcessReqResult.strResult = strObject_Lock_out.strResult;
        return(rc);
    }

    //--------------------------------
    //   Lock objects of lot to be updated
    //--------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "Lock objects of lot to be updated");

    CORBA::Long i = 0;
    CORBA::Long nLen = tmpNewLotAttributes.strNewWaferAttributes.length();
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "nLen = ", nLen);
    for (i=0; i<nLen; i++)
    {
        if (i>0 &&
            CIMFWStrCmp(tmpNewLotAttributes.strNewWaferAttributes[i-1].sourceLotID.identifier,
                        tmpNewLotAttributes.strNewWaferAttributes[i  ].sourceLotID.identifier) == 0)
        {
            continue;
        }

//DSN000049350        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock(strObject_Lock_out, strObjCommonIn,
                         tmpNewLotAttributes.strNewWaferAttributes[i].sourceLotID,
                         SP_ClassName_PosLot);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq",
                               "object_Lock(tmpNewLotAttributes.strNewWaferAttributes[i].newLotID) rc != RC_OK", i);
            strMonitorLotSTBAfterProcessReqResult.strResult = strObject_Lock_out.strResult;
            return(rc);
        }
    }

//D9000005 add start
    /*-------------------------------*/
    /*   Check SorterJob existence   */
    /*-------------------------------*/
    pptEquipmentLoadPortAttribute dummyEquipmentPortAttribute;
    objectIdentifierSequence dummyLotIDs, cassetteIDs;
    cassetteIDs.length(1);
    cassetteIDs[0] = tmpNewLotAttributes.cassetteID;

    objWaferSorter_sorterJob_CheckForOperation_out strWaferSorter_sorterJob_CheckForOperation_out;
    objWaferSorter_sorterJob_CheckForOperation_in  strWaferSorter_sorterJob_CheckForOperation_in;
    strWaferSorter_sorterJob_CheckForOperation_in.strEquipmentLoadPortAttribute = dummyEquipmentPortAttribute;
    strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs                   = cassetteIDs;
    strWaferSorter_sorterJob_CheckForOperation_in.lotIDs                        = dummyLotIDs;
//PSN000102296    strWaferSorter_sorterJob_CheckForOperation_in.operation                     = CIMFWStrDup(SP_Operation_For_DestCast);
    strWaferSorter_sorterJob_CheckForOperation_in.operation                     = CIMFWStrDup(SP_Operation_For_Cast);    //PSN000102296

    rc = waferSorter_sorterJob_CheckForOperation( strWaferSorter_sorterJob_CheckForOperation_out,
                                                  strObjCommonIn,
                                                  strWaferSorter_sorterJob_CheckForOperation_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "waferSorter_sorterJob_CheckForOperation() != RC_OK" );
        strMonitorLotSTBAfterProcessReqResult.strResult = strWaferSorter_sorterJob_CheckForOperation_out.strResult;
        return( rc );
    }
//D9000005 add end

    // 0.01 Start
    //----------------------
    // Get information in order to create ProductRequest
    //----------------------
    objMonitorLot_STBInfo_Get_out strMonitorLot_STBInfo_Get_out;
    rc = monitorLot_STBInfo_Get(strMonitorLot_STBInfo_Get_out, strObjCommonIn,
                                productLotIDs[0]);
    // Use productLotIDs[0] for input parameter

    //----------------------
    // Get Bank ID for Lot Generation function
    //----------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "Get Bank ID for Lot Generation function");

    objProductSpecification_startBank_Get_out strProductSpecification_startBank_Get_out;
    rc = productSpecification_startBank_Get(strProductSpecification_startBank_Get_out, strObjCommonIn,
                                            strMonitorLot_STBInfo_Get_out.monitorLotProductID);
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: TxCtrlLotSTBReq ", "productSpecification_startBank_Get() rc != RC_OK");
        strMonitorLotSTBAfterProcessReqResult.strResult = strProductSpecification_startBank_Get_out.strResult;
        return(rc);
    }
    // 0.01 End

    //----------------------
    // Prepare input parameter of productRequest_forControlLot_Release()
    //----------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq",
                       "Prepare input parameter of productRequest_forControlLot_Release()");

    objectIdentifier productID = strMonitorLot_STBInfo_Get_out.monitorLotProductID;
    CORBA::Long waferCount = tmpNewLotAttributes.strNewWaferAttributes.length();
    CORBA::String_var lotType = strMonitorLot_STBInfo_Get_out.lotType;
    CORBA::String_var subLotType;
//    if (stbLotSubLotType is not NULL)
    if (stbLotSubLotType != NULL && CIMFWStrLen(stbLotSubLotType) != 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "stbLotSubLotType != NULL && CIMFWStrLen(stbLotSubLotType) != 0");
        subLotType = stbLotSubLotType;
    }
    else
    {
        subLotType = strMonitorLot_STBInfo_Get_out.subLotType;
    }

    //----------------------
    // Create Product request here
    //----------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "Create Product request here");

    objProductRequest_forControlLot_Release_out strProductRequest_forControlLot_Release_out;
    rc = productRequest_forControlLot_Release(strProductRequest_forControlLot_Release_out, strObjCommonIn,
                                              productID, waferCount, lotType, subLotType);

    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: TxCtrlLotSTBReq ", "productRequest_forControlLot_Release() rc != RC_OK");
        strMonitorLotSTBAfterProcessReqResult.strResult = strProductRequest_forControlLot_Release_out.strResult;
        return(rc);
    }
    for (i=0; i<waferCount; i++)
    {
        if(0 == CIMFWStrLen(tmpNewLotAttributes.strNewWaferAttributes[i].newLotID.identifier))
        {
            tmpNewLotAttributes.strNewWaferAttributes[i].newLotID.identifier
             = strProductRequest_forControlLot_Release_out.createdProductRequest.identifier;
        }
    }

    //-------------------------------
    //   Check Condition             
    //-------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "Check Condition");

    objEquipment_lotSTB_Check_out strEquipment_lotSTB_Check_out;
    rc = equipment_lotSTB_Check(strEquipment_lotSTB_Check_out, strObjCommonIn,
                                processEquipmentID,
                                productLotIDs,
                                strProductRequest_forControlLot_Release_out.createdProductRequest, 
                                tmpNewLotAttributes);

    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: TxCtrlLotSTBReq ", "equipment_lotSTB_Check() rc != RC_OK");
        strMonitorLotSTBAfterProcessReqResult.strResult = strEquipment_lotSTB_Check_out.strResult;
        return(rc);
    }

    //--------------------------------
    //   Get monitor wafer current carrier
    //--------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq",
                       "Get monitor wafer current carrier");

    CORBA::Long monWaferSrcCasLen = 0;
    objectIdentifierSequence monitorWaferSourceCassettes;
    for (i=0; i<nLen; i++)
    {
        objWafer_lot_Get_out strWafer_lot_Get_out;
        rc = wafer_lot_Get( strWafer_lot_Get_out, strObjCommonIn,
                            tmpNewLotAttributes.strNewWaferAttributes[i].sourceWaferID );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq",
                               "wafer_lot_Get() rc != RC_OK.  Round", i);
            strMonitorLotSTBAfterProcessReqResult.strResult = strWafer_lot_Get_out.strResult;
            return(rc);
        }

        objLot_cassette_Get_out strLot_cassette_Get_out;
        rc = lot_cassette_Get( strLot_cassette_Get_out, strObjCommonIn,
                               strWafer_lot_Get_out.lotID);

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq",
                               "lot_cassette_Get() rc != RC_OK.  Round", i);
            strMonitorLotSTBAfterProcessReqResult.strResult = strLot_cassette_Get_out.strResult;
            return(rc);
        }

        CORBA::Boolean bCasFound = FALSE;
        monWaferSrcCasLen = monitorWaferSourceCassettes.length();
        for(CORBA::Long j=0; j<monWaferSrcCasLen; j++)
        {
            if( 0 == CIMFWStrCmp(monitorWaferSourceCassettes[j].identifier, strLot_cassette_Get_out.cassetteID.identifier) )
            {
//P4100088                bCasFound == TRUE;
                bCasFound = TRUE;  //P4100088
                break;
            }
        }
        if(bCasFound == FALSE)
        {
            monitorWaferSourceCassettes.length( monWaferSrcCasLen+1 );
            monitorWaferSourceCassettes[monWaferSrcCasLen] = strLot_cassette_Get_out.cassetteID;
            monWaferSrcCasLen++ ;
        }
    }

    //--------------------------------
    //   Move wafer position
    //--------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "Move wafer position");

    objWafer_materialContainer_Change_out strWafer_materialContainer_Change_out;
    for (i=0; i<nLen; i++)
    {
        objectIdentifier newCassetteID = tmpNewLotAttributes.cassetteID;
        pptWafer strWafer;
        strWafer.waferID = tmpNewLotAttributes.strNewWaferAttributes[i].sourceWaferID;
        strWafer.slotNumber = tmpNewLotAttributes.strNewWaferAttributes[i].newSlotNumber;

        rc = wafer_materialContainer_Change( strWafer_materialContainer_Change_out,
                                             strObjCommonIn,
                                             newCassetteID,
                                             strWafer );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq",
                               "wafer_materialContainer_Change() rc != RC_OK.  Round", i);
            strMonitorLotSTBAfterProcessReqResult.strResult = strWafer_materialContainer_Change_out.strResult;
            return(rc);
        }
    }

    //----------------------
    // Check input parameter (Wafer ID)
    //----------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "Check input parameter");

    objLot_parameterForLotGeneration_Check_out strLot_parameterForLotGeneration_Check_out;
    strLot_parameterForLotGeneration_Check_out.bWaferIDAssignRequred = FALSE; //P3000280
    rc = lot_parameterForLotGeneration_Check(strLot_parameterForLotGeneration_Check_out, strObjCommonIn,
                                             strProductSpecification_startBank_Get_out.bankID, tmpNewLotAttributes);
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "lot_parameterForLotGeneration_Check() rc != RC_OK");
        strMonitorLotSTBAfterProcessReqResult.strResult = strLot_parameterForLotGeneration_Check_out.strResult;
        return(rc);
    }
    if (strLot_parameterForLotGeneration_Check_out.bWaferIDAssignRequred == TRUE)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "returned bWaferIDAssignRequred is true");
        //PTR3000234 SET_MSG_RC(strMonitorLotSTBAfterProcessReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM);
        //PTR3000234 return( RC_INVALID_INPUT_PARM );

        //PYT3000234 Start
        objLot_waferID_Generate_out strLot_waferID_Generate_out;
        rc = lot_waferID_Generate(strLot_waferID_Generate_out, strObjCommonIn,
                                  tmpNewLotAttributes);
        if (rc)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "lot_waferID_Generate() != RC_OK");
            strMonitorLotSTBAfterProcessReqResult.strResult = strLot_waferID_Generate_out.strResult;
            return(rc);
        }
        tmpNewLotAttributes = strLot_waferID_Generate_out.strNewLotAttributes;
        //PYT3000234 End
    }
    //PTR3000273 Start
    nLen = tmpNewLotAttributes.strNewWaferAttributes.length();
    for (i=0; i<nLen; i++)
    {
        if( 0 == CIMFWStrLen(tmpNewLotAttributes.strNewWaferAttributes[i].newWaferID.identifier)
         && 0 <  CIMFWStrLen(tmpNewLotAttributes.strNewWaferAttributes[i].sourceWaferID.identifier))
        {
            tmpNewLotAttributes.strNewWaferAttributes[i].newWaferID
             = tmpNewLotAttributes.strNewWaferAttributes[i].sourceWaferID;
        }
    }
    //PTR3000273 End

    //------------------------------------------------------------------------
    //   Lot STB
    //------------------------------------------------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "Lot STB");

    objLot_STB_out strLot_STB_out;
    rc = lot_STB(strLot_STB_out, strObjCommonIn,
                 strProductRequest_forControlLot_Release_out.createdProductRequest, 
                 tmpNewLotAttributes);
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "lot_STB() rc != RC_OK");
        strMonitorLotSTBAfterProcessReqResult.strResult = strLot_STB_out.strResult;
        return(rc);
    }
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "@@@@@ Set createdLotID @@@@@", strLot_STB_out.createdLotID.identifier);
    strMonitorLotSTBAfterProcessReqResult.monitorLotID = strLot_STB_out.createdLotID;

    //------------------------------------------------------
    // Copy stringified object reference of created lot
    //------------------------------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "Copy stringified object reference of created lot");

    PPT_METHODTRACE_V2("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq",
                       "Created Lot ID                ",
                       strLot_STB_out.createdLotID.identifier);
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq",
                       "Created Lot Stringified ObjRef",
                       strLot_STB_out.createdLotID.stringifiedObjectReference);

    nLen = tmpNewLotAttributes.strNewWaferAttributes.length();
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "nLen", nLen);
    for(i=0; i<nLen; i++)
    {
        tmpNewLotAttributes.strNewWaferAttributes[i].newLotID = strLot_STB_out.createdLotID;
    }

    //------------------------------------------------------------------------
    //   Create Monitor Group
    //------------------------------------------------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "Create Monitor Group");

    objMonitorGroup_MakeByAuto_out strMonitorGroup_MakeByAuto_out;
    rc = monitorGroup_MakeByAuto(strMonitorGroup_MakeByAuto_out, strObjCommonIn,
                                 strLot_STB_out.createdLotID, productLotIDs); 
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "monitorGroup_MakeByAuto() rc != RC_OK");
        strMonitorLotSTBAfterProcessReqResult.strResult = strMonitorGroup_MakeByAuto_out.strResult;
        return(rc);
    }

    //----------------------
    // Update control Job Info and
    // Machine Cassette info if information exist
    //----------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq",
                       "Update control Job Info and Machine Cassette info if information exist");

    monitorWaferSourceCassettes.length( monWaferSrcCasLen+1 );
    monitorWaferSourceCassettes[monWaferSrcCasLen] = tmpNewLotAttributes.cassetteID;

    objControlJob_relatedInfo_Update_out strControlJob_relatedInfo_Update_out;
    rc = controlJob_relatedInfo_Update(strControlJob_relatedInfo_Update_out, strObjCommonIn,
                                      monitorWaferSourceCassettes);
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "controlJob_relatedInfo_Update() != RC_OK");
        strMonitorLotSTBAfterProcessReqResult.strResult = strControlJob_relatedInfo_Update_out.strResult;
        return(rc);
    }

    //----------------------
    // Update cassette multi lot type
    //----------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "Update cassette multi lot type");

    for(i=0; i<(monWaferSrcCasLen+1); i++)
    {
        objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
        rc = cassette_multiLotType_Update(strCassette_multiLotType_Update_out, strObjCommonIn,
                                          monitorWaferSourceCassettes[i]);

        if (rc)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq",
                               "cassette_multiLotType_Update() rc != RC_OK");
            strMonitorLotSTBAfterProcessReqResult.strResult = strCassette_multiLotType_Update_out.strResult;
            return(rc);
        }
    }

#if 1
        //D4000016 Add Start
        //--------------------------------------------------------------------------------------------------
        // UpDate RequiredCassetteCategory 
        //--------------------------------------------------------------------------------------------------
        objLot_CassetteCategory_UpdateForContaminationControl_out   strLot_CassetteCategory_UpdateForContaminationControl_out;
        rc = lot_CassetteCategory_UpdateForContaminationControl( strLot_CassetteCategory_UpdateForContaminationControl_out,
                                                   strObjCommonIn,
                                                   strLot_STB_out.createdLotID );

        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V1("","lot_CassetteCategory_UpdateForContaminationControl != RC_OK");
            strMonitorLotSTBAfterProcessReqResult.strResult = strLot_CassetteCategory_UpdateForContaminationControl_out.strResult;
            return rc;
        }
        //D4000016 Add end
#endif

//INN-R170002 add start
    //------------------------------------------------------------------------
    //   Check contamination information for newly created lot
    //------------------------------------------------------------------------
    PPT_METHODTRACE_V1("", "Check contamination information");

    csObjLot_ContaminationInfo_CheckForMove_out strLot_ContaminationInfo_CheckForMove_out;
    csObjLot_ContaminationInfo_CheckForMove_in  strLot_ContaminationInfo_CheckForMove_in;
    strLot_ContaminationInfo_CheckForMove_in.lotID = strLot_STB_out.createdLotID;
    strLot_ContaminationInfo_CheckForMove_in.carrierID = tmpNewLotAttributes.cassetteID;

    rc = cs_lot_ContaminationInfo_CheckForMove(strLot_ContaminationInfo_CheckForMove_out, strObjCommonIn,
                                 strLot_ContaminationInfo_CheckForMove_in); 
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "cs_lot_ContaminationInfo_CheckForMove() rc != RC_OK",rc);
        strMonitorLotSTBAfterProcessReqResult.strResult = strLot_ContaminationInfo_CheckForMove_out.strResult;
        return(rc);
    }
    if (TRUE == strLot_ContaminationInfo_CheckForMove_out.holdReqFlag)
    {
        PPT_METHODTRACE_V1("", "strLot_ContaminationInfo_CheckForMove_out.holdReqFlag= TRUE");
        CS_PPT_SET_MSG_RC_KEY2( strMonitorLotSTBAfterProcessReqResult,
                                CS_MSG_LOT_CONTAMINATION_MISMATCH,
                                CS_RC_LOT_CONTAMINATION_MISMATCH,
                                strLot_STB_out.createdLotID.identifier,
                                tmpNewLotAttributes.cassetteID.identifier );
        return CS_RC_LOT_CONTAMINATION_MISMATCH;
    }
//INN-R170002 add end

//D4200029 Add Start
    //-----------------------//
    //     Process Hold      //
    //-----------------------//
    PPT_METHODTRACE_V1("","Call txProcessHoldExecReq()");
    pptProcessHoldExecReqResult strProcessHoldExecReqResult;

    rc = txProcessHoldExecReq( strProcessHoldExecReqResult,
                               strObjCommonIn,
                               strLot_STB_out.createdLotID,
                               claimMemo );

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","txProcessHoldExecReq() != RC_OK", rc );
        strMonitorLotSTBAfterProcessReqResult.strResult = strProcessHoldExecReqResult.strResult ;
        return( rc );
    }
//D4200029 Add End

    //------------------------------------------------------------------------
    //   Make History                                                         
    //------------------------------------------------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "Make History");

    objLot_waferLotHistoryPointer_Update_out strLot_waferLotHistoryPointer_Update_out;
    rc = lot_waferLotHistoryPointer_Update(strLot_waferLotHistoryPointer_Update_out, strObjCommonIn,
                                           strLot_STB_out.createdLotID);  //for output lot of lot_STB()
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "lot_waferLotHistoryPointer_Update() rc != RC_OK");
        strMonitorLotSTBAfterProcessReqResult.strResult = strLot_waferLotHistoryPointer_Update_out.strResult;
        SET_MSG_RC(strMonitorLotSTBAfterProcessReqResult, MSG_FAIL_MAKE_HISTORY, rc);
        return( rc );
    }

    objLotWaferMoveEvent_Make_out strLotWaferMoveEvent_Make_out;
    rc = lotWaferMoveEvent_Make(strLotWaferMoveEvent_Make_out, strObjCommonIn,
                                "TXPCC013", tmpNewLotAttributes, claimMemo);
        // transactionID          = "TXPCC013"
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq ", "lotWaferMoveEvent_Make() rc != RC_OK");
        SET_MSG_RC(strMonitorLotSTBAfterProcessReqResult, MSG_FAIL_MAKE_HISTORY, rc);
        return(rc);
    }

    nLen = tmpNewLotAttributes.strNewWaferAttributes.length();
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq", "nLen = ", nLen);
    for (i=0; i<nLen; i++)
    {
        if (i>0 &&
            CIMFWStrCmp(tmpNewLotAttributes.strNewWaferAttributes[i  ].sourceLotID.identifier,
                        tmpNewLotAttributes.strNewWaferAttributes[i-1].sourceLotID.identifier) == 0)
        {
            continue;
        }
        objLot_waferLotHistoryPointer_Update_out strLot_waferLotHistoryPointer_Update_out;
        rc = lot_waferLotHistoryPointer_Update(strLot_waferLotHistoryPointer_Update_out, strObjCommonIn,
                                               tmpNewLotAttributes.strNewWaferAttributes[i].sourceLotID); 
                                               //lotID = strMoveWaferLots.lotID 0.01
        if (rc)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq ", "lot_waferLotHistoryPointer_Update() rc != RC_OK");
            SET_MSG_RC(strMonitorLotSTBAfterProcessReqResult, MSG_FAIL_MAKE_HISTORY, rc);
            return(rc);
        }
    }

    SET_MSG_RC(strMonitorLotSTBAfterProcessReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txMonitorLotSTBAfterProcessReq");
    return RC_OK;
}

