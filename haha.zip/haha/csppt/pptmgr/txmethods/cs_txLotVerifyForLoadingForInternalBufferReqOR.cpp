#ifndef lint
static char *sccsid =  "@(#) 1.2 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txLotVerifyForLoadingForInternalBufferReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/18/07 14:03:59 [ 7/18/07 14:04:01 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: cs_txLotVerifyForLoadingForInternalBufferReqOR.cpp
//

//INN-A170001 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp" //INN-A170001
#include "penin.hh"

//=============================================================================
// For TXTRC011 : txLotVerifyForLoadingForInternalBufferReq
//=============================================================================
// Class: CS_PPTManager
//
// Service: txLotVerifyForLoadingForInternalBufferReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2001-08-09 D4000048 M.Ameshita     Reticle set support (Rel4.0).
// 2001-08-20 P4000099 K.Matsuei      Invalid obj-method filename.
// 2001-08-29 D4000016 M.Shimizu      Add Contamination Control(Copper/Non Copper [R40 Core])
// 2001-09-03 D4000138 S.Tokumasu     Add to return error code for un-candidate lot.
// 2001-09-03 D4000136 S.Tokumasu     Add to check lot count of batch operation..
// 2001-09-07 D4000148 S.Tokumasu     Add lot_recipeCombination_CheckForLoading
// 2001-09-27 P4000269 S.Tokumasu     return RC_INVALID_CATEGORY_CHECK
// 2001/12/05 P4100018 M.Shimizu      Add LogicalScrap Check(Except loadPurposeType=Other carrier)
// 2002/06/11 P4100536 T.Nishimura    Source Check : Wrong reference to dimension.
// 2002/08/26 P4200126 H.Adachi       Add Cassette and Port Category Check for Load Purpose Type is Other Case.
// 2002/09/20 D4200031 H.Adachi       Chg not to check reticle for the case a lot is in a operation with no photo layer.
// 2003/02/10 P4200534 H.Adachi       Add ProcessMonitorLot Quantity Check
// 2003/10/17 D5100053 T.Hikari       ProcessMonitoring By ProductionLot.
// 2004/02/23 P5100157 T.Hikari       Change set monitorLotFlag.
// 10/22/04  D6000025  K.Murakami     eBroker Migration.
// 2005/10/03 D7000009 K.Matsuei      Take-out Xfer for LoadVerifyNG Carrier by CassetteDelivery.
// 2005/12/07 D7000042 K.Kido         Check Recipe conbination only if the Lot doesn't have CJ.
// 2005/12/12 D7000135 K.Matsuei      Show the reason of ForceLoad.
// 2006/07/26 P7000118 K.Kido         Obtains recipe information only if CJ is not found.
// 2007/07/10 P9000022 M.Murata       Fix logic for Recipe Body Management.
// 2007/07/18 P9000027 H.Hotta        Add return code for force loading.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2014/05/27 DSN000085791 C.Mo           Entity Inhibit Exception Lot Support. (R150)
// 2016/07/13 DSN000101569 K.Yamaoku      Durable Sub Status Control
//
// Innotron Modification history :
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    pptLotVerifyForLoadingForInternalBufferReqResult&    strLotVerifyForLoadingForInternalBufferReqResult
//    const pptObjCommonIn&               strObjCommonIn
//    const objectIdentifier&             equipmentID
//    const objectIdentifier&             portID
//    const objectIdentifier&             cassetteID
//    const char *                        loadPurposeType
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:

CORBA::Long PPTManager_i:: txLotVerifyForLoadingForInternalBufferReq (
    pptLotVerifyForLoadingForInternalBufferReqResult&    strLotVerifyForLoadingForInternalBufferReqResult,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             equipmentID,
    const objectIdentifier&             portID,
    const objectIdentifier&             cassetteID,
//D6000025     const char *                        loadPurposeType,
//D6000025     CORBA::Environment &                IT_env)
    const char *                        loadPurposeType  //D6000025
    CORBAENV_LAST_CPP)                                   //D6000025
{
    PPT_METHODTRACE_ENTRY("PPTManager_i:: txLotVerifyForLoadingForInternalBufferReq");
    CORBA::Long rc = RC_OK ;

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check LoadPurposeType of Cassette with inparm's LoadPurposeType     */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/

    /* get loadPurposeType */
//dbeug    objCassette_GetNPWLoadPurposeType_out strCassette_GetNPWLoadPurposeType_out;

//dbeug    rc = cassette_GetNPWLoadPurposeType( strCassette_GetNPWLoadPurposeType_out,
//dbeug                                         strObjCommonIn,
//dbeug                                         cassetteID        );

//dbeug    if ( rc != RC_OK )
//dbeug    {
//dbeug        PPT_METHODTRACE_V1( "", "cassette_GetNPWLoadPurposeType rc != RC_OK");
//dbeug        strLotVerifyForLoadingForInternalBufferReqResult.strResult = strCassette_GetNPWLoadPurposeType_out.strResult;
//dbeug        return( rc );
//dbeug    }

//dbeug    if(CIMFWStrLen(loadPurposeType) > 0)
//dbeug    {
//dbeug        if ( CIMFWStrCmp(loadPurposeType,
//dbeug                         strCassette_SetNPWLoadPurposeType_out.loadPurposeType) != 0 )
//dbeug        {
//dbeug            PPT_METHODTRACE_V1( "", "loadPurposeType is unmatch with Casstte's one.");
//dbeug            strLotVerifyForLoadingForInternalBufferReqResult.strResult = strCassette_SetNPWLoadPurposeType_out.strResult;
//dbeug            return( rc );
//dbeug        }
//dbeug    }

//P4100018 Add Start
    //-------------------------------------------------
    //  Check Scrap Wafer Exsit In Carrier
    //-------------------------------------------------
    if(CIMFWStrCmp(loadPurposeType,SP_LoadPurposeType_Other) != 0)
    {
        objectIdentifierSequence cassetteIDs ;
        cassetteIDs.length( 1 ) ;
        cassetteIDs[0] = cassetteID;

        objCassette_scrapWafer_SelectDR_out  strCassette_scrapWafer_SelectDR_out;
        rc = cassette_scrapWafer_SelectDR( strCassette_scrapWafer_SelectDR_out,
                                           strObjCommonIn,
                                           cassetteIDs);

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cassette_scrapWafer_SelectDR() != RC_OK",rc);
            strLotVerifyForLoadingForInternalBufferReqResult.strResult = strCassette_scrapWafer_SelectDR_out.strResult;
            return (rc);
        }

        CORBA::Long scrapCount = strCassette_scrapWafer_SelectDR_out.strLotWaferMap.length();
        if( scrapCount > 0 )
        {
            PPT_METHODTRACE_V2("", "ScrapWafer Found ",scrapCount);
            SET_MSG_RC(strLotVerifyForLoadingForInternalBufferReqResult, MSG_FOUND_SCRAP, RC_FOUND_SCRAP) ;
            return (RC_FOUND_SCRAP);
        }
    }
//P4100018 Add End

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process For Empty Cassette                                    */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    if (CIMFWStrCmp(loadPurposeType, SP_LoadPurposeType_EmptyCassette ) == 0)
    {
        PPT_METHODTRACE_V1( "", "loadPurposeType == SP_LoadPurposeType_EmptyCassette");

        /*------------------------------------*/
        /*                                    */
        /*   Check Cassette is Empty or Not   */
        /*                                    */
        /*------------------------------------*/
        objCassette_CheckEmpty_out  strCassette_CheckEmpty_out;
        rc = cassette_CheckEmpty( strCassette_CheckEmpty_out, strObjCommonIn, cassetteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "cassette_CheckEmpty() != RC_OK");
            strLotVerifyForLoadingForInternalBufferReqResult.strResult = strCassette_CheckEmpty_out.strResult;
            return( rc );
        }
        PPT_METHODTRACE_V1( "", "Cassette is Empty.");

        /*--------------------------------------------------------*/
        /*                                                        */
        /*   Check Cassette Condition for Loading                 */
        /*                                                        */
        /*   The following conditions are checked for Loading.    */
        /*                                                        */
        /*   - controlJobID                                       */
        /*   - multiLotType                                       */
        /*   - transferState                                      */
        /*   - cassetteState                                      */
        /*                                                        */
        /*--------------------------------------------------------*/
        objCassette_CheckConditionForLoading_out   strCassette_CheckConditionForLoading_out;
        rc = cassette_CheckConditionForLoading( strCassette_CheckConditionForLoading_out, strObjCommonIn, equipmentID, portID, cassetteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "cassette_CheckConditionForLoading() != RC_OK");
            strLotVerifyForLoadingForInternalBufferReqResult.strResult = strCassette_CheckConditionForLoading_out.strResult;
            return( rc );
        }

        /*--------------------------------------------------------*/
        /*                                                        */
        /*   Check Equipment and Port Condition for Loading       */
        /*                                                        */
        /*   The following conditions are checked for Loading.    */
        /*                                                        */
        /*   - controlJobID                                       */
        /*   - loadPort's reservedControlJob VS cassette's one    */
        /*   - loadPort's portUsage (Input or InOut)              */
        /*   - loadPurposeType                                    */
        /*   - portState                                          */
        /*   - allocatedMaterial                                  */
        /*                                                        */
        /*--------------------------------------------------------*/
        objEquipment_CheckConditionForLoadingForInternalBuffer_out  strEquipment_CheckConditionForLoadingForInternalBuffer_out;
        PPT_METHODTRACE_V3( "", "equipmentID    ", equipmentID.identifier, "<");
        PPT_METHODTRACE_V3( "", "portID         ", portID.identifier, "<");
        PPT_METHODTRACE_V3( "", "cassetteID     ", cassetteID.identifier, "<");
        PPT_METHODTRACE_V3( "", "loadPurposeType", loadPurposeType, "<");

        rc = equipment_CheckConditionForLoadingForInternalBuffer( strEquipment_CheckConditionForLoadingForInternalBuffer_out,
                                                 strObjCommonIn,
                                                 equipmentID,
                                                 portID,
                                                 cassetteID,
                                                 loadPurposeType );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "equipment_CheckConditionForLoadingForInternalBuffer() != RC_OK");
            strLotVerifyForLoadingForInternalBufferReqResult.strResult = strEquipment_CheckConditionForLoadingForInternalBuffer_out.strResult;
            return( rc );
        }

//D4000016 start
        /*---------------------------------------------------------------------------*/
        /*                                                                           */
        /*   Check Category for process contamination control (Copper/Non Copper)    */
        /*                                                                           */
        /*   It is checked in the following method whether it is the condition       */
        /*   that Lot of the object is made of OpeStart.                             */
        /*                                                                           */
        /*   1. It is checked whether the CassetteCategory of PosCassette and        */
        /*      the CassetteCategoryCapability of PosPortResource are the same.      */
        /*                                                                           */
        /*   2. It is proper condition if CassetteCategoryCapability is the same     */
        /*      as RequiredCassetteCategory and CassetteCategory.                    */
        /*                                                                           */
        /*---------------------------------------------------------------------------*/

        objectIdentifier dummy;
        objLot_CassetteCategory_CheckForContaminationControl_out strLot_CassetteCategory_CheckForContaminationControl_out;
        rc = lot_CassetteCategory_CheckForContaminationControl( strLot_CassetteCategory_CheckForContaminationControl_out,
                                                                strObjCommonIn,
                                                                dummy,
                                                                cassetteID,
                                                                equipmentID,
                                                                portID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "PPTManager_i:: txLotVerifyForLoadingForInternalBufferReq", "lot_CassetteCategory_CheckForContaminationControl() != RC_OK");
            strLotVerifyForLoadingForInternalBufferReqResult.strResult = strLot_CassetteCategory_CheckForContaminationControl_out.strResult;
            return( rc );
        }
//D4000016 end

        /*--------------------------------------------*/
        /*                                            */
        /*   Return to Caller (Empty Cassette case)   */
        /*                                            */
        /*--------------------------------------------*/
        SET_MSG_RC(strLotVerifyForLoadingForInternalBufferReqResult, MSG_OK, RC_OK);

        PPT_METHODTRACE_EXIT("");
        return ( RC_OK );
    }


    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process For Lot                                               */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    pptStartCassette strStartCassette;


    /*----------------------------------------------*/
    /*   Set Input Parameters to strStartCassette   */
    /*----------------------------------------------*/
    strStartCassette.cassetteID      = cassetteID;
    strStartCassette.loadPurposeType = loadPurposeType;
    strStartCassette.loadPortID      = portID;

    strStartCassette.loadSequenceNumber = 0;

    /*---------------------------------*/
    /*   Get Cassette's ControlJobID   */
    /*---------------------------------*/
    PPT_METHODTRACE_V1( "", "Get Cassette's ControlJobID");
    objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;
    rc = cassette_controlJobID_Get(strCassette_controlJobID_Get_out, strObjCommonIn,
                                   cassetteID);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK");
        strLotVerifyForLoadingForInternalBufferReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
        return( rc );
    }

    CORBA::Long i = 0;
    CORBA::Long lotLen = 0;
    if (CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) == 0)
    {
        PPT_METHODTRACE_V1( "", "CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) == 0");

        /*-----------------------------------*/
        /*   Get Contained Lot in Cassette   */
        /*-----------------------------------*/
        PPT_METHODTRACE_V1( "", "Get Contained Lot in Cassette");
        objCassette_GetLotList_out strCassette_GetLotList_out;
        rc = cassette_GetLotList(strCassette_GetLotList_out, strObjCommonIn,
                                 cassetteID );
        if ( rc != RC_OK && rc !=RC_NOT_FOUND_LOT)
        {
            PPT_METHODTRACE_V1( "", "cassette_GetLotList() != RC_OK");
            strLotVerifyForLoadingForInternalBufferReqResult.strResult = strCassette_GetLotList_out.strResult;
            return( rc );
        }

        lotLen = strCassette_GetLotList_out.strLotListInCassetteInfo.lotID.length();
        strStartCassette.strLotInCassette.length(lotLen);

        PPT_METHODTRACE_V2( "", "lotLen = ", lotLen);
        for ( i=0 ; i<lotLen ; i++ )
        {
            strStartCassette.strLotInCassette[i].operationStartFlag = TRUE;
            strStartCassette.strLotInCassette[i].lotID = strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[i];
            if (CIMFWStrCmp(loadPurposeType, SP_LoadPurposeType_ProcessMonitorLot) == 0)
            {
                /*------------------*/
                /*   Get Lot Type   */
                /*------------------*/
                objLot_type_Get_out strLot_type_Get_out;
                rc = lot_type_Get( strLot_type_Get_out, strObjCommonIn, strStartCassette.strLotInCassette[i].lotID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "", "lot_type_Get() != RC_OK");
                    strLotVerifyForLoadingForInternalBufferReqResult.strResult = strLot_type_Get_out.strResult;
                    return( rc );
                }
                if (CIMFWStrCmp(strLot_type_Get_out.theLotType, SP_Lot_Type_ProductionMonitorLot ) == 0)
                {
                    PPT_METHODTRACE_V1("","theLotType == SP_Lot_Type_ProductionMonitorLot");
                    strStartCassette.strLotInCassette[i].monitorLotFlag = TRUE;
                }
                else
                {
//D5100053 Add Start
                    objLot_monitorRouteFlag_Get_out strLot_monitorRouteFlag_Get_out;

                    rc = lot_monitorRouteFlag_Get(strLot_monitorRouteFlag_Get_out,
                                                  strObjCommonIn,
                                                  strStartCassette.strLotInCassette[i].lotID);
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("","lot_monitorRouteFlag_Get() != RC_OK");
                        strLotVerifyForLoadingForInternalBufferReqResult.strResult = strLot_monitorRouteFlag_Get_out.strResult;
                        return ( rc );
                    }

                    PPT_METHODTRACE_V2( "", "monitorRoute_Flag =", strLot_monitorRouteFlag_Get_out.monitorRoute_Flag );

                    if ( strLot_monitorRouteFlag_Get_out.monitorRoute_Flag == TRUE )
                    {
                        strStartCassette.strLotInCassette[i].monitorLotFlag = TRUE;
                        PPT_METHODTRACE_V1("","strStartCassette.strLotInCassette[i].monitorLotFlag = TRUE");
                    }
                    else
                    {
                        strStartCassette.strLotInCassette[i].monitorLotFlag = FALSE;
                        PPT_METHODTRACE_V1("","strStartCassette.strLotInCassette[i].monitorLotFlag = FALSE");
                    }
//D5100053 Add End
//D5100053                    PPT_METHODTRACE_V1("","theLotType != SP_Lot_Type_ProductionMonitorLot");
//D5100053                    strStartCassette.strLotInCassette[i].monitorLotFlag = FALSE;
                }
                strStartCassette.strLotInCassette[i].lotType = strLot_type_Get_out.theLotType;    //P4200534
            }
            else
            {
                strStartCassette.strLotInCassette[i].monitorLotFlag = FALSE;
            }
        }
    }
    else
    {
        PPT_METHODTRACE_V1( "", "CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) != 0");
        /*-------------------------------------*/
        /*   Get Contained Lot in ControlJob   */
        /*-------------------------------------*/
        PPT_METHODTRACE_V1( "", "Get Contained Lot in ControlJob");
        objControlJob_containedLot_Get_out strControlJob_containedLot_Get_out;
        rc = controlJob_containedLot_Get(strControlJob_containedLot_Get_out, strObjCommonIn,
                                         strCassette_controlJobID_Get_out.controlJobID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "controlJob_containedLot_Get() != RC_OK");
            strLotVerifyForLoadingForInternalBufferReqResult.strResult = strControlJob_containedLot_Get_out.strResult;
            return( rc );
        }

        CORBA::Long nLen = strControlJob_containedLot_Get_out.strControlJobCassette.length();
        PPT_METHODTRACE_V2( "", "nLen = ", nLen);
        for ( i=0 ; i<nLen; i++ )
        {
            if (CIMFWStrCmp(strControlJob_containedLot_Get_out.strControlJobCassette[i].cassetteID.identifier,
                            cassetteID.identifier) == 0)
            {
                lotLen = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot.length();
                strStartCassette.strLotInCassette.length(lotLen);
                CORBA::Long j = 0;
                PPT_METHODTRACE_V3( "", "lotLen = ", lotLen, i);
                for ( j=0 ; j<lotLen ; j++ )
                {
                    strStartCassette.strLotInCassette[j].operationStartFlag = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].operationStartFlag;
//P5100157//D5100053 Add Start
//P5100157                    objLot_monitorRouteFlag_Get_out strLot_monitorRouteFlag_Get_out;
//P5100157                    rc = lot_monitorRouteFlag_Get(strLot_monitorRouteFlag_Get_out,
//P5100157                                                  strObjCommonIn,
//P5100157                                                  strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].lotID);
//P5100157                    if ( rc != RC_OK )
//P5100157                    {
//P5100157                        PPT_METHODTRACE_V1( "","lot_monitorRouteFlag_Get() != RC_OK");
//P5100157                        strLotVerifyForLoadingForInternalBufferReqResult.strResult = strLot_monitorRouteFlag_Get_out.strResult;
//P5100157                        return ( rc );
//P5100157                    }
//P5100157
//P5100157                    PPT_METHODTRACE_V2( "", "monitorRoute_Flag =", strLot_monitorRouteFlag_Get_out.monitorRoute_Flag );
//P5100157
//P5100157                    if ( strLot_monitorRouteFlag_Get_out.monitorRoute_Flag == TRUE )
//P5100157                    {
//P5100157                        strStartCassette.strLotInCassette[j].monitorLotFlag = TRUE;
//P5100157                        PPT_METHODTRACE_V1( "","strStartCassette.strLotInCassette[j].monitorLotFlag = TRUE");
//P5100157                    }
//P5100157                    else
//P5100157                    {
//P5100157                        strStartCassette.strLotInCassette[j].monitorLotFlag = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].monitorLotFlag;
//P5100157                        PPT_METHODTRACE_V2( "", "strStartCassette.strLotInCassette[j].monitorLotFlag =", strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].monitorLotFlag );
//P5100157                    }
//P5100157//D5100053 Add End
//D5100053                    strStartCassette.strLotInCassette[j].monitorLotFlag     = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].monitorLotFlag;
                    strStartCassette.strLotInCassette[j].monitorLotFlag     = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].monitorLotFlag;    //P5100157
                    strStartCassette.strLotInCassette[j].lotID              = strControlJob_containedLot_Get_out.strControlJobCassette[i].strControlJobLot[j].lotID;

                    //P4200534 Add Start
                    objLot_type_Get_out strLot_type_Get_out;
                    rc = lot_type_Get( strLot_type_Get_out, strObjCommonIn, strStartCassette.strLotInCassette[j].lotID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1( "", "lot_type_Get() != RC_OK");
                        strLotVerifyForLoadingForInternalBufferReqResult.strResult = strLot_type_Get_out.strResult;
                        return( rc );
                    }
                    strStartCassette.strLotInCassette[j].lotType = strLot_type_Get_out.theLotType;

                    PPT_METHODTRACE_V3( "", "LotID & LotType", strStartCassette.strLotInCassette[j].lotID.identifier,
                                                               strStartCassette.strLotInCassette[j].lotType );
                    //P4200534 Add End
                }
                break;
            }
        }
    }

    /*-------------------------------------------------------*/
    /*                                                       */
    /*   Check Lot Condition for Loading                     */
    /*                                                       */
    /*   The following conditions are checked for each lot.  */
    /*                                                       */
    /*   - lot's equipmentID                                 */
    /*   - lotHoldState                                      */
    /*   - lotProcessState                                   */
    /*   - lotInventoryState                                 */
    /*   - entityInhibition                                  */
    /*   - equipment's availability for specified lot        */
    /*                                                       */
    /*   (*)                                                 */
    /*   About for reticle/fixture, whether these are        */
    /*   inhibitted or not itself is checked at later.       */
    /*   (by processDurable_CheckConditionForOpeStart)       */
    /*-------------------------------------------------------*/
    PPT_METHODTRACE_V1( "", "Check Lot Condition for Loading");
    PPT_METHODTRACE_V2( "", "lotLen = ", lotLen);
//D7000135 add start
    stringSequence verifyNGReasons;
    verifyNGReasons.length( lotLen );
//D7000135 add end
    for ( i=0 ; i<lotLen ; i++ )
    {
        if ( strStartCassette.strLotInCassette[i].operationStartFlag == FALSE )
        {
            continue;
        }

        objLot_CheckConditionForLoading_out strLot_CheckConditionForLoading_out;
        rc = lot_CheckConditionForLoading(strLot_CheckConditionForLoading_out, strObjCommonIn,
                                          equipmentID,
                                          strStartCassette.strLotInCassette[i].lotID );
        if ( rc == RC_OK )
        {
            strStartCassette.strLotInCassette[i].operationStartFlag = TRUE;
        }
        else if ( rc == RC_NOT_CANDIDATE_LOT_FOR_OPE_START )
        {
            strStartCassette.strLotInCassette[i].operationStartFlag = FALSE;
//D7000135 add start
            verifyNGReasons[i] = strLot_CheckConditionForLoading_out.strResult.messageText;
            PPT_METHODTRACE_V3( "", "verifyNGReasons[i]", i, verifyNGReasons[i]);
//D7000135 add end
        }
        else
        {
            PPT_METHODTRACE_V1( "", "lot_CheckConditionForLoading() != RC_OK");
            strLotVerifyForLoadingForInternalBufferReqResult.strResult = strLot_CheckConditionForLoading_out.strResult;
            return( rc );
        }
    }
//P4100536    PPT_METHODTRACE_V2( "", "Check Lot Condition for Loading after strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));
    /*--------------------------------------------------------*/
    /*                                                        */
    /*   Check Cassette Condition for Loading                 */
    /*                                                        */
    /*   The following conditions are checked for Loading.    */
    /*                                                        */
    /*   - controlJobID                                       */
    /*   - multiLotType                                       */
    /*   - transferState                                      */
    /*   - cassetteState                                      */
    /*                                                        */
    /*--------------------------------------------------------*/
//P4100536    PPT_METHODTRACE_V1( "", "Check Cassette Condition for Loading");
//P4100536    PPT_METHODTRACE_V2( "", "Check Cassette Condition for Loading befor strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));

    objCassette_CheckConditionForLoading_out strCassette_CheckConditionForLoading_out;
    rc = cassette_CheckConditionForLoading(strCassette_CheckConditionForLoading_out, strObjCommonIn,
                                           equipmentID, portID, cassetteID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "cassette_CheckConditionForLoading() != RC_OK");
        strLotVerifyForLoadingForInternalBufferReqResult.strResult = strCassette_CheckConditionForLoading_out.strResult;

//D7000009 start
        // strLoadingVerifiedLot information must be set for ForceLoad process.
        if ( rc == RC_INVALID_CAST_XFERSTAT )
        {
            PPT_METHODTRACE_V1("", "rc == RC_INVALID_CAST_XFERSTAT");
            PPT_METHODTRACE_V2("", "lotLen", lotLen);
            strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot.length( lotLen );
            for ( CORBA::Long j=0; j < lotLen; j++ )
            {
                strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[j].operationStartFlag = FALSE;
                strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[j].monitorLotFlag     = FALSE;
                strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[j].lotID              = strStartCassette.strLotInCassette[j].lotID;
//D7000135 start
                strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[j].verifyNGReason     = strCassette_CheckConditionForLoading_out.strResult.messageText;
                PPT_METHODTRACE_V2( "", "verifyNGReason", strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[j].verifyNGReason);
//D7000135 end
            }
        }
//D7000009 end

        return( rc );
    }
//P4100536    PPT_METHODTRACE_V2( "", "Check Cassette Condition for Loading after strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));

    /*--------------------------------------------------------*/
    /*                                                        */
    /*   Check Equipment and Port Condition for Loading       */
    /*                                                        */
    /*   The following conditions are checked for Loading.    */
    /*                                                        */
    /*   - controlJobID                                       */
    /*   - loadPort's reservedControlJob VS cassette's one    */
    /*   - loadPort's portUsage (Input or InOut)              */
    /*   - loadPurposeType                                    */
    /*   - portState                                          */
    /*                                                        */
    /*--------------------------------------------------------*/
//P4100536    PPT_METHODTRACE_V1( "", "Check Equipment and Port Condition for Loading");
//P4100536    PPT_METHODTRACE_V2( "", "Check Equipment and Port Condition for Loading befor strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));

    objEquipment_CheckConditionForLoadingForInternalBuffer_out strEquipment_CheckConditionForLoadingForInternalBuffer_out;
    rc = equipment_CheckConditionForLoadingForInternalBuffer(strEquipment_CheckConditionForLoadingForInternalBuffer_out, strObjCommonIn,
                                            equipmentID, portID, cassetteID, loadPurposeType );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "equipment_CheckConditionForLoadingForInternalBuffer() != RC_OK");
        strLotVerifyForLoadingForInternalBufferReqResult.strResult = strEquipment_CheckConditionForLoadingForInternalBuffer_out.strResult;

//D7000009 start
        // strLoadingVerifiedLot information must be set for ForceLoad process.
        if ( rc == RC_CAST_CTRLJOBID_BLANK
          || rc == RC_LOAD_NOT_MATCH_NPW_RSV    //P9000027
           )
        {
            PPT_METHODTRACE_V1("", "rc == RC_CAST_CTRLJOBID_BLANK");
            PPT_METHODTRACE_V2("", "lotLen", lotLen);
            strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot.length( lotLen );
            for ( CORBA::Long j=0; j < lotLen; j++ )
            {
                strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[j].operationStartFlag = FALSE;
                strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[j].monitorLotFlag     = FALSE;
                strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[j].lotID              = strStartCassette.strLotInCassette[j].lotID;
//D7000135 start
                strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[j].verifyNGReason     = strEquipment_CheckConditionForLoadingForInternalBuffer_out.strResult.messageText;
                PPT_METHODTRACE_V2( "", "verifyNGReason", strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[j].verifyNGReason);
//D7000135 end
            }
        }
//D7000009 end

        return( rc );
    }
//P4100536    PPT_METHODTRACE_V2( "", "Check Equipment and Port Condition for Loading after strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check FlowBatch Condition for Loading                               */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   1. whether in-parm's equipment has reserved flowBatchID or not      */
    /*      fill  -> in-parm's lot must have same flowBatchID                */
    /*      blank -> no check                                                */
    /*                                                                       */
    /*   2. whether lot is in flowBatch section or not                       */
    /*      in    -> lot must have flowBatchID, and flowBatch must have      */
    /*               reserved equipmentID.                                   */
    /*               if lot is on target operation, flowBatch's reserved     */
    /*               equipmentID and in-parm's equipmentID must be same.     */
    /*      out   -> no check                                                */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
//P4100536    PPT_METHODTRACE_V1( "", "Check FlowBatch Condition for Loading");
//P4100536    PPT_METHODTRACE_V2( "", "Check FlowBatch Condition for Loading befor strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));

    objEquipment_lot_CheckFlowBatchConditionForLoading_out strEquipment_lot_CheckFlowBatchConditionForLoading_out;
    rc = equipment_lot_CheckFlowBatchConditionForLoading(strEquipment_lot_CheckFlowBatchConditionForLoading_out,
                                                         strObjCommonIn,
                                                         equipmentID, strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "equipment_lot_CheckFlowBatchConditionForLoading() != RC_OK");
        strLotVerifyForLoadingForInternalBufferReqResult.strResult = strEquipment_lot_CheckFlowBatchConditionForLoading_out.strResult;
        return( rc );
    }
//P4100536    PPT_METHODTRACE_V2( "", "Check FlowBatch Condition for Loading after strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process Durable Condition for Loading                         */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   1. Whether equipment requires process durable or not                */
    /*      If no-need, return OK;                                           */
    /*                                                                       */
    /*   2. At least one of reticle / fixture for each reticleGroup /        */
    /*      fixtureGroup is in the equipment or not.                         */
    /*      Even if required reticle is in the equipment, its status must    */
    /*      be _Available or _InUse.                                         */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
//P4100536    PPT_METHODTRACE_V1( "", "Check Process Durable Condition for Loading");
//P4100536    PPT_METHODTRACE_V2( "", "Check Process Durable Condition for Loading befor strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));

    if (CIMFWStrCmp(loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
    {
        //no-need to check for process durable
        ;
    }
    else
    {
        /*-----------------------------------------*/
        /*   Check Process Durable Required Flag   */
        /*-----------------------------------------*/
        PPT_METHODTRACE_V1( "", "Check Process Durable Required Flag");

        objEquipment_processDurableRequiredFlag_Get_out strEquipment_processDurableRequiredFlag_Get_out;
        rc = equipment_processDurableRequiredFlag_Get( strEquipment_processDurableRequiredFlag_Get_out,
                                                       strObjCommonIn,
                                                       equipmentID );

        CORBA::Long saveRC = rc;    //P3100077

        if ( rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD )
        {
            PPT_METHODTRACE_V1( "", "rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD");
            CORBA::Long j = 0;
            CORBA::Long nLen = strStartCassette.strLotInCassette.length();
            PPT_METHODTRACE_V2( "", "nLen = ", nLen);
            for ( j=0 ; j<nLen; j++ )
            {
                if ( strStartCassette.strLotInCassette[j].operationStartFlag == FALSE )
                {
                    PPT_METHODTRACE_V1( "", "strStartCassette.strLotInCassette[j].operationStartFlag == FALSE");
                    continue;
                }

//P7000118      /*-------------------------------------------------*/
//P7000118      /*   Get Lot's LogicalRecipeID / MachineRecipeID   */
//P7000118      /*-------------------------------------------------*/
//P7000118      PPT_METHODTRACE_V1( "", "Get Lot's LogicalRecipeID / MachineRecipeID");
//P7000118
//P7000118      objLot_recipe_Get_out strLot_recipe_Get_out;
//P7000118      rc = lot_recipe_Get(strLot_recipe_Get_out, strObjCommonIn,
//P7000118                          equipmentID, strStartCassette.strLotInCassette[j].lotID );
//P7000118      if ( rc != RC_OK )
//P7000118      {
//P7000118          PPT_METHODTRACE_V1( "", "lot_recipe_Get() != RC_OK");
//P7000118          strLotVerifyForLoadingForInternalBufferReqResult.strResult = strLot_recipe_Get_out.strResult;
//P7000118          return( rc );
//P7000118      }
//P7000118      strStartCassette.strLotInCassette[j].strStartRecipe.logicalRecipeID = strLot_recipe_Get_out.logicalRecipeID; //0.01
//P7000118      strStartCassette.strLotInCassette[j].strStartRecipe.machineRecipeID = strLot_recipe_Get_out.machineRecipeID; //0.01

                /*--------------------------------*/
                /*   check reserve reticle info   */
                /*--------------------------------*/
                PPT_METHODTRACE_V1( "", "/*--------------------------------*/");
                PPT_METHODTRACE_V1( "", "/*   check reserve reticle info   */");
                PPT_METHODTRACE_V1( "", "/*--------------------------------*/");

                if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier ) )
                {
                    PPT_METHODTRACE_V1("", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ P3100077 start @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
                    PPT_METHODTRACE_V1("", "Exist controlJobID !!");

                    objControlJob_startReserveInformation_Get_out strControlJob_startReserveInformation_Get_out;
                    rc = controlJob_startReserveInformation_Get( strControlJob_startReserveInformation_Get_out,
                                                                 strObjCommonIn,
                                                                 strCassette_controlJobID_Get_out.controlJobID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "controlJob_startReserveInformation_Get() rc != RC_OK");
                        strLotVerifyForLoadingForInternalBufferReqResult.strResult = strControlJob_startReserveInformation_Get_out.strResult;
                        return( rc );
                    }

                    CORBA::Long lenStartCassette = strControlJob_startReserveInformation_Get_out.strStartCassette.length();
                    PPT_METHODTRACE_V2("", "lenStartCassette", lenStartCassette);
                    CORBA::Long k, l, m;

                    for ( k=0; k < lenStartCassette; k++ )
                    {
                        PPT_METHODTRACE_V2("", "StartCassette-------------------------------round [K]", k);

                        if ( 0 == CIMFWStrCmp(strControlJob_startReserveInformation_Get_out.strStartCassette[k].cassetteID.identifier,
                                              cassetteID.identifier) )
                        {
                            PPT_METHODTRACE_V2("", "found same cassette!!", cassetteID.identifier);

                            CORBA::Long lenLotInCassette = strControlJob_startReserveInformation_Get_out.strStartCassette[k].strLotInCassette.length();
                            PPT_METHODTRACE_V2("", "lenLotInCassette", lenLotInCassette);

                            for ( l=0; l < lenLotInCassette; l++ )
                            {
                                PPT_METHODTRACE_V2("", "LotInCassette-----------------------------------round [l]", l);

                                if ( FALSE == strControlJob_startReserveInformation_Get_out.strStartCassette[k].strLotInCassette[l].operationStartFlag )
                                {
                                    PPT_METHODTRACE_V1("", "FALSE == operationStartFlag ---> continue!!");
                                    continue;
                                }

//D4200031                      if ( saveRC == RC_EQP_PROCDRBL_RTCL_REQD )
                                if ( saveRC == RC_EQP_PROCDRBL_RTCL_REQD                           //D4200031
                                  && strControlJob_startReserveInformation_Get_out.strStartCassette[k].strLotInCassette[l].strStartRecipe.strStartReticle.length() > 0)  //D4200031
                                {
                                    PPT_METHODTRACE_V1("", "saveRC == RC_EQP_PROCDRBL_RTCL_REQD");

                                    /*---------------------------------*/
                                    /*   Get and Check Reticle State   */
                                    /*     - state                     */
                                    /*     - transferState             */
                                    /*---------------------------------*/
                                    PPT_METHODTRACE_V1("", "/*---------------------------------*/");
                                    PPT_METHODTRACE_V1("", "/*   Get and Check Reticle State   */");
                                    PPT_METHODTRACE_V1("", "/*---------------------------------*/");

                                    objReticle_state_Check_out strReticle_state_Check_out;
//DSN000101569                                    rc = reticle_state_Check( strReticle_state_Check_out,
//DSN000101569                                                              strObjCommonIn,
//DSN000101569                                                              equipmentID,
//DSN000101569                                                              strControlJob_startReserveInformation_Get_out.strStartCassette[k].strLotInCassette[l].strStartRecipe.strStartReticle );
//DSN000101569 add start
                                    rc = reticle_state_Check__170( strReticle_state_Check_out,
                                                                   strObjCommonIn,
                                                                   equipmentID,
                                                                   strControlJob_startReserveInformation_Get_out.strStartCassette[k].strLotInCassette[l].strStartRecipe.strStartReticle,
                                                                   strControlJob_startReserveInformation_Get_out.strStartCassette[k].strLotInCassette[l].lotID );
//DSN000101569 add end
                                    if ( rc != RC_OK )
                                    {
                                        PPT_METHODTRACE_V1("", "reticle_state_Check() rc != RC_OK");
                                        strLotVerifyForLoadingForInternalBufferReqResult.strResult = strReticle_state_Check_out.strResult;
                                        return( rc );
                                    }

                                    /*------------------------------*/
                                    /*   Check Reticle Inhibition   */
                                    /*------------------------------*/
                                    PPT_METHODTRACE_V1("", "/*------------------------------*/");
                                    PPT_METHODTRACE_V1("", "/*   Check Reticle Inhibition   */");
                                    PPT_METHODTRACE_V1("", "/*------------------------------*/");

                                    CORBA::Long lenStartReticle = strControlJob_startReserveInformation_Get_out.strStartCassette[k].strLotInCassette[l].strStartRecipe.strStartReticle.length();
                                    PPT_METHODTRACE_V2("", "lenStartReticle", lenStartReticle);

                                    pptEntityInhibitAttributes entityInhibitAttributes;
                                    entityInhibitAttributes.entities.length(lenStartReticle);

                                    for ( m=0 ; m < lenStartReticle ; m++ )
                                    {
                                        entityInhibitAttributes.entities[m].className = CIMFWStrDup( SP_InhibitClassID_Reticle );
                                        entityInhibitAttributes.entities[m].objectID  = strControlJob_startReserveInformation_Get_out.strStartCassette[k].strLotInCassette[l].strStartRecipe.strStartReticle[m].reticleID;
                                        entityInhibitAttributes.entities[m].attrib    = CIMFWStrDup( "" );

                                        PPT_METHODTRACE_V2("", "entityInhibitAttributes.entities[k].objectID ---> ", entityInhibitAttributes.entities[m].objectID.identifier);
                                    }

                                    objEntityInhibit_CheckForEntities_out strEntityInhibit_CheckForEntities_out;
                                    rc = entityInhibit_CheckForEntities( strEntityInhibit_CheckForEntities_out,
                                                                         strObjCommonIn,
                                                                         entityInhibitAttributes );
                                    if ( rc != RC_OK )
                                    {
                                        PPT_METHODTRACE_V1("", "entityInhibit_CheckForEntities() rc != RC_OK");
                                        strLotVerifyForLoadingForInternalBufferReqResult.strResult = strEntityInhibit_CheckForEntities_out.strResult;
                                        return( rc );
                                    }

                                    CORBA::Long lenInhibit = strEntityInhibit_CheckForEntities_out.entityInhibitInfo.length();
                                    PPT_METHODTRACE_V2("", "lenInhibit", lenInhibit );
//DSN000085791 add start
                                    objEntityInhibit_FilterExceptionLot_out strEntityInhibit_FilterExceptionLot_out;
                                    if ( lenInhibit > 0 )
                                    {
                                        // filter exception for entity inhibit
                                        objEntityInhibit_FilterExceptionLot_in strEntityInhibit_FilterExceptionLot_in;
                                        strEntityInhibit_FilterExceptionLot_in.strEntityInhibitInfos = strEntityInhibit_CheckForEntities_out.entityInhibitInfo;
                                        strEntityInhibit_FilterExceptionLot_in.lotID = strControlJob_startReserveInformation_Get_out.strStartCassette[k].strLotInCassette[l].lotID;

                                        rc = entityInhibit_FilterExceptionLot(strEntityInhibit_FilterExceptionLot_out,
                                                                              strObjCommonIn,
                                                                              strEntityInhibit_FilterExceptionLot_in);
                                        if ( rc != RC_OK )
                                        {
                                            PPT_METHODTRACE_V2( ""," #### entityInhibit_FilterExceptionLot() != RC_OK : rc = ", rc );
                                            strLotVerifyForLoadingForInternalBufferReqResult.strResult = strEntityInhibit_FilterExceptionLot_out.strResult;
                                            return rc;
                                        }

                                        lenInhibit = strEntityInhibit_FilterExceptionLot_out.strEntityInhibitInfos.length();
                                        PPT_METHODTRACE_V2("","number of Inhibits filtered exception",lenInhibit);
                                    }
//DSN000085791 add end
                                    if( lenInhibit > 0 )
                                    {
                                        PPT_METHODTRACE_V2("", "Inhibit record for reticle is found", lenInhibit );
                                        PPT_SET_MSG_RC_KEY2 ( strLotVerifyForLoadingForInternalBufferReqResult,
                                                              MSG_INHIBIT_ENTITY,
                                                              RC_INHIBIT_ENTITY,
//DSN000085791                                                              strEntityInhibit_CheckForEntities_out.entityInhibitInfo[0].entityInhibitAttributes.entities[0].objectID.identifier,
                                                              strEntityInhibit_FilterExceptionLot_out.strEntityInhibitInfos[0].entityInhibitAttributes.entities[0].objectID.identifier, //DSN000085791 
                                                              SP_InhibitClassID_Reticle );
                                        return( RC_INHIBIT_ENTITY );
                                    }
                                }
                                else if ( saveRC == RC_EQP_PROCDRBL_FIXT_REQD )
                                {
                                    PPT_METHODTRACE_V1("", "saveRC == RC_EQP_PROCDRBL_FIXT_REQD");
                                    /*---------------------------------*/
                                    /*   Get and Check Fixture State   */
                                    /*     - state                     */
                                    /*     - transferState             */
                                    /*---------------------------------*/
                                    PPT_METHODTRACE_V1("", "/*---------------------------------*/");
                                    PPT_METHODTRACE_V1("", "/*   Get and Check Fixture State   */");
                                    PPT_METHODTRACE_V1("", "/*---------------------------------*/");

                                    objFixture_state_Check_out strFixture_state_Check_out;
                                    rc = fixture_state_Check( strFixture_state_Check_out,
                                                              strObjCommonIn,
                                                              equipmentID,
                                                              strControlJob_startReserveInformation_Get_out.strStartCassette[k].strLotInCassette[l].strStartRecipe.strStartFixture );
                                    if ( rc != RC_OK )
                                    {
                                        PPT_METHODTRACE_V1("", "entitfixture_state_CheckyInhibit_CheckForEntities() rc != RC_OK");
                                        strLotVerifyForLoadingForInternalBufferReqResult.strResult = strFixture_state_Check_out.strResult;
                                        return( rc );
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {
//P7000118 add start
                    /*-------------------------------------------------*/
                    /*   Get Lot's LogicalRecipeID / MachineRecipeID   */
                    /*-------------------------------------------------*/
                    PPT_METHODTRACE_V1( "", "Get Lot's LogicalRecipeID / MachineRecipeID");

                    objLot_recipe_Get_out strLot_recipe_Get_out;
                    rc = lot_recipe_Get(strLot_recipe_Get_out, strObjCommonIn,
                                        equipmentID, strStartCassette.strLotInCassette[j].lotID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1( "", "lot_recipe_Get() != RC_OK");
                        strLotVerifyForLoadingForInternalBufferReqResult.strResult = strLot_recipe_Get_out.strResult;
                        return( rc );
                    }

                    strStartCassette.strLotInCassette[j].strStartRecipe.logicalRecipeID = strLot_recipe_Get_out.logicalRecipeID;
                    strStartCassette.strLotInCassette[j].strStartRecipe.machineRecipeID = strLot_recipe_Get_out.machineRecipeID;
//P7000118 add end
                    /*--------------------------------------------------*/
                    /*   Check Process Durable Condition for OpeStart   */
                    /*    - At least one of reticle / fixture for each  */
                    /*      reticleGroup / fixtureGroup is in the       */
                    /*      equipment or not. Even if required reticle  */
                    /*      is in the equipment, its status must be     */
                    /*      _Available or _InUse.                       */
                    /*    - Found reticles must not be inhibitted.      */
                    /*--------------------------------------------------*/
                    PPT_METHODTRACE_V1( "", "/*--------------------------------------------------*/");
                    PPT_METHODTRACE_V1( "", "/*   Check Process Durable Condition for OpeStart   */");
                    PPT_METHODTRACE_V1( "", "/*--------------------------------------------------*/");

                    objProcessDurable_CheckConditionForOpeStart_out strProcessDurable_CheckConditionForOpeStart_out;
                    rc = processDurable_CheckConditionForOpeStart(strProcessDurable_CheckConditionForOpeStart_out,
                                                                  strObjCommonIn,
                                                                  equipmentID,
                                                                  strStartCassette.strLotInCassette[j].strStartRecipe.logicalRecipeID,   //0.01
//D4000048                                                        strStartCassette.strLotInCassette[j].strStartRecipe.machineRecipeID ); //0.01
                                                                  strStartCassette.strLotInCassette[j].strStartRecipe.machineRecipeID,   //D4000048
                                                                  strStartCassette.strLotInCassette[j].lotID );                          //D4000048
                    if ( rc == RC_OK )
                    {
                        //check OK
                        ;
                        PPT_METHODTRACE_V1( "", "check OK");
                    }
                    else if ( rc == RC_NOT_AVAILABLE_RETICLE || rc == RC_NOT_AVAILABLE_FIXTURE )
                    {
                        PPT_METHODTRACE_V1( "", "rc == RC_NOT_AVAILABLE_RETICLE || rc == RC_NOT_AVAILABLE_FIXTURE");
                        strStartCassette.strLotInCassette[j].operationStartFlag = FALSE; //0.01
//D7000135 add start
                        verifyNGReasons[j] = strProcessDurable_CheckConditionForOpeStart_out.strResult.messageText;
                        PPT_METHODTRACE_V3( "", "verifyNGReasons[j]", j, verifyNGReasons[j]);
//D7000135 add end
                    }
                    else
                    {
                        PPT_METHODTRACE_V1( "", "processDurable_CheckConditionForOpeStart() != RC_OK");
                        strLotVerifyForLoadingForInternalBufferReqResult.strResult = strProcessDurable_CheckConditionForOpeStart_out.strResult;
                        return( rc );
                    }
                }
            }
            rc = RC_OK;
        }
        else if ( rc == RC_EQP_PROCDRBL_NOT_REQD )
        {
            PPT_METHODTRACE_V1( "", "rc == RC_EQP_PROCDRBL_NOT_REQD");
            rc = RC_OK;
        }
        else
        {
            PPT_METHODTRACE_V1( "", "equipment_processDurableRequiredFlag_Get() != RC_OK");
            strLotVerifyForLoadingForInternalBufferReqResult.strResult = strEquipment_processDurableRequiredFlag_Get_out.strResult;
            return( rc );
        }
    }
//P4100536    PPT_METHODTRACE_V2( "", "Check Process Durable Condition for Loading after strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));

//P9000022    /*----------------------------------------------------------------------*/
//P9000022    /*                                                                      */
//P9000022    /*   Confirmation for Uploaded Recipe Body and Eqp's Recipe Body        */
//P9000022    /*                                                                      */
//P9000022    /*   When the following conditions are all matched, recipe body         */
//P9000022    /*   confirmation request is sent to TCS.                               */
//P9000022    /*                                                                      */
//P9000022    /*   1. Equipment's onlineMode is Online                                */
//P9000022    /*   2. Equipment's recipe body manage flag is TRUE.                    */
//P9000022    /*   3. Machine recipe's recipe body confirm flag is TRUE.              */
//P9000022    /*                                                                      */
//P9000022    /*----------------------------------------------------------------------*/
//P9000022    PPT_METHODTRACE_V1( "", "Confirmation for Uploaded Recipe Body and Eqp's Recipe Body");
//P9000022
//P9000022    /*---------------------------------------------*/
//P9000022    /*   Get Machine Recipe List to be Confirmed   */
//P9000022    /*---------------------------------------------*/
//P9000022//P4100536    PPT_METHODTRACE_V1( "", "Get Machine Recipe List to be Confirmed");
//P9000022//P4100536    PPT_METHODTRACE_V2( "", "Get Machine Recipe List to be Confirmed befor strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));
//P9000022
//P9000022    pptStartCassetteSequence tmpStartCassetteSeq(1);
//P9000022    tmpStartCassetteSeq.length(1);
//P9000022    tmpStartCassetteSeq[0] = strStartCassette;
//P9000022
//P9000022    objMachineRecipe_GetListForConfirmation_out strMachineRecipe_GetListForConfirmation_out;
//P9000022    rc = machineRecipe_GetListForConfirmation(strMachineRecipe_GetListForConfirmation_out,
//P9000022                                              strObjCommonIn,
//P9000022                                              equipmentID, tmpStartCassetteSeq );
//P9000022    if ( rc != RC_OK )
//P9000022    {
//P9000022        PPT_METHODTRACE_V1( "", "machineRecipe_GetListForConfirmation() != RC_OK");
//P9000022        strLotVerifyForLoadingForInternalBufferReqResult.strResult = strMachineRecipe_GetListForConfirmation_out.strResult;
//P9000022        return( rc );
//P9000022    }
//P9000022
//P9000022    CORBA::Long nLen = strMachineRecipe_GetListForConfirmation_out.machineRecipeID.length();
//P9000022    PPT_METHODTRACE_V2( "", "nLen = ", nLen);
//P9000022    for ( i=0 ; i<nLen; i++ )
//P9000022    {
//P9000022        /*-------------------------------------------*/
//P9000022        /*   Send Recipe Body Confirmation Request   */
//P9000022        /*-------------------------------------------*/
//P9000022        PPT_METHODTRACE_V2( "", "Send Recipe Body Confirmation Request", i);
//P9000022
//P9000022        pptRecipeConfirmationReqResult strRecipeConfirmationReqResult;
//P9000022        rc = txRecipeConfirmationReq(strRecipeConfirmationReqResult, strObjCommonIn,
//P9000022                                     equipmentID, strMachineRecipe_GetListForConfirmation_out.machineRecipeID[i],
//P9000022                                     "", "", "", FALSE, "");
//P9000022        if ( rc != RC_OK )
//P9000022        {
//P9000022            PPT_METHODTRACE_V1( "", "txRecipeConfirmReq() != RC_OK");
//P9000022            strLotVerifyForLoadingForInternalBufferReqResult.strResult = strRecipeConfirmationReqResult.strResult;
//P9000022            return( rc );
//P9000022        }
//P9000022    }
//P9000022//P4100536    PPT_METHODTRACE_V2( "", "Get Machine Recipe List to be Confirmed after strStartCassette.strLotInCassette[i].operationStartFlag", ((strStartCassette.strLotInCassette[0].operationStartFlag == TRUE)?"TRUE":"FALSE"));

//P9000022 add start
    //-----------------------------------------------------------------------------------------
    //                                                                                         
    //                                                                                         
    //   Check confirmation request setting for Uploaded Recipe Body and Eqp's Recipe Body     
    //                                                                                         
    //   Recipe Body Confirmation/DownLoad cannot be performed without StartLotsReserve.       
    //                                                                                         
    //                                                                                         
    //-----------------------------------------------------------------------------------------
    //---------------------------------------------------
    // Get Machine Recipe List for Recipe Body Mangement
    //---------------------------------------------------
    PPT_METHODTRACE_V2( "", "Control Job exists ??? ", strCassette_controlJobID_Get_out.controlJobID.identifier);
    if ( 0 == CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier ) )
    {
        objMachineRecipe_GetListForRecipeBodyManagement_in  strMachineRecipe_GetListForRecipeBodyManagement_in;
        strMachineRecipe_GetListForRecipeBodyManagement_in.strStartCassette.length(1);
        strMachineRecipe_GetListForRecipeBodyManagement_in.strStartCassette[0] = strStartCassette;
        strMachineRecipe_GetListForRecipeBodyManagement_in.equipmentID         = equipmentID;

        CORBA::Long lotInCstLen = strMachineRecipe_GetListForRecipeBodyManagement_in.strStartCassette[0].strLotInCassette.length();
        for(CORBA::Long lotInCstCnt = 0; lotInCstCnt < lotInCstLen; lotInCstCnt++)
        {
            if ( FALSE == strStartCassette.strLotInCassette[lotInCstCnt].operationStartFlag )
            {
                PPT_METHODTRACE_V1("","FALSE == strStartCassette.strLotInCassette[lotInCstCnt].operationStartFlag");
                continue;
            }
            //----------------------------------------------------------------------------
            //   Get Lot's LogicalRecipeID / MachineRecipeID from standard definition.    
            //----------------------------------------------------------------------------
            PPT_METHODTRACE_V2( "", "Get Lot's LogicalRecipeID / MachineRecipeID from standard definition.", strMachineRecipe_GetListForRecipeBodyManagement_in.strStartCassette[0].strLotInCassette[lotInCstCnt].lotID.identifier);
            objLot_recipe_Get_out strLot_recipe_Get_out;
            rc = lot_recipe_Get(strLot_recipe_Get_out, strObjCommonIn, equipmentID, strMachineRecipe_GetListForRecipeBodyManagement_in.strStartCassette[0].strLotInCassette[lotInCstCnt].lotID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "lot_recipe_Get() != RC_OK");
                strLotVerifyForLoadingForInternalBufferReqResult.strResult = strLot_recipe_Get_out.strResult;
                return( rc );
            }
            PPT_METHODTRACE_V3( "", "Get Lot's LogicalRecipeID / MachineRecipeID", strLot_recipe_Get_out.logicalRecipeID.identifier, strLot_recipe_Get_out.machineRecipeID.identifier);
            strMachineRecipe_GetListForRecipeBodyManagement_in.strStartCassette[0].strLotInCassette[lotInCstCnt].strStartRecipe.logicalRecipeID = strLot_recipe_Get_out.logicalRecipeID;
            strMachineRecipe_GetListForRecipeBodyManagement_in.strStartCassette[0].strLotInCassette[lotInCstCnt].strStartRecipe.machineRecipeID = strLot_recipe_Get_out.machineRecipeID;
        }

        PPT_METHODTRACE_V1( "", "Get Machine Recipe List for Recipe Body Mangement." );
        objMachineRecipe_GetListForRecipeBodyManagement_out strMachineRecipe_GetListForRecipeBodyManagement_out;
        rc = machineRecipe_GetListForRecipeBodyManagement( strMachineRecipe_GetListForRecipeBodyManagement_out, strObjCommonIn, strMachineRecipe_GetListForRecipeBodyManagement_in);
        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V1( "", "machineRecipe_GetListForRecipeBodyManagement() != RC_OK" );
            strLotVerifyForLoadingForInternalBufferReqResult.strResult = strMachineRecipe_GetListForRecipeBodyManagement_out.strResult;
            return( rc );
        }
  
        CORBA::Long targetRecipeLen = strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq.length();
        PPT_METHODTRACE_V2( "", "Recipe for Recipe Body Management ...", targetRecipeLen );
        // Check
        if( 0 == targetRecipeLen )
        {
            //ok. no action.
            PPT_METHODTRACE_V1( "", "Recipe for Recipe Body Management does not exist. And controljob does not exist. OK." );
        }
        else if( 0 != targetRecipeLen )
        {
            PPT_METHODTRACE_V1( "", "Bypass Cannot perform Recipe Confirmation/Download without Lot Reservation. " ); //INN-A170001
            //error.
//INN-A170001            PPT_METHODTRACE_V1( "", "Cannot perform Recipe Confirmation/Download without Lot Reservation. Please retry after Lot Reservation." );
//INN-A170001            SET_MSG_RC( strLotVerifyForLoadingForInternalBufferReqResult, MSG_CANNOT_LOAD_WITHOUT_CJ, RC_CANNOT_LOAD_WITHOUT_CJ );
//INN-A170001            return ( RC_CANNOT_LOAD_WITHOUT_CJ );
        }
    }
//P9000022 add end

    //P4200126 Add Start
    //-----------------------------------------------------------------
    // Load Purpose Type is Other Case:
    //   Execute Cassette Category and Port Category Combination Check.
    //-----------------------------------------------------------------
    if(CIMFWStrCmp(loadPurposeType,SP_LoadPurposeType_Other) == 0)
    {
        PPT_METHODTRACE_V1("","Load Purpose Type is OTHER case, Checking Category");
        objectIdentifier dummy;
        objLot_CassetteCategory_CheckForContaminationControl_out strLot_CassetteCategory_CheckForContaminationControl_out;
        rc = lot_CassetteCategory_CheckForContaminationControl( strLot_CassetteCategory_CheckForContaminationControl_out,
                                                                strObjCommonIn,
                                                                dummy,
                                                                cassetteID,
                                                                equipmentID,
                                                                portID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "loadPurposeType is Other Case: lot_CassetteCategory_CheckForContaminationControl() != RC_OK");
            strLotVerifyForLoadingForInternalBufferReqResult.strResult = strLot_CassetteCategory_CheckForContaminationControl_out.strResult;
            return( rc );
        }

    }
    //P4200126 Add End

//D4000016 Add Start
    /*---------------------------------------------------------------------------*/
    /*                                                                           */
    /*   Check Category for Copper/Non Copper                                    */
    /*                                                                           */
    /*   It is checked in the following method whether it is the condition       */
    /*   that Lot of the object is made of OpeStart.                             */
    /*                                                                           */
    /*   1. It is checked whether CassetteCategory of RequiredCassetteCategory   */
    /*      of PosLot and PosCassette is the same.                               */
    /*                                                                           */
    /*   2. It is checked whether CassetteCategoryCapability of CassetteCategory */
    /*      of PosCassette and PosPortResource is the same.                      */
    /*                                                                           */
    /*   3. It is proper condition if CassetteCategoryCapability is the same     */
    /*      as RequiredCassetteCategory and CassetteCategory.                    */
    /*                                                                           */
    /*---------------------------------------------------------------------------*/
    CORBA::Long ii;
    CORBA::Long nLotInCastLen = strStartCassette.strLotInCassette.length();

    for ( ii = 0; ii < nLotInCastLen; ii++ )
    {
        objLot_CassetteCategory_CheckForContaminationControl_out strLot_CassetteCategory_CheckForContaminationControl_out;
        rc = lot_CassetteCategory_CheckForContaminationControl( strLot_CassetteCategory_CheckForContaminationControl_out,
                                                                strObjCommonIn,
                                                                strStartCassette.strLotInCassette[ii].lotID,
                                                                strStartCassette.cassetteID,
                                                                equipmentID,
                                                                strStartCassette.loadPortID);
//D4000046 add start 2001/08/23

        if ( rc == RC_OK )
        {
//D4000138  strStartCassette.strLotInCassette[ii].operationStartFlag = TRUE;
            PPT_METHODTRACE_V2( "", "lot_CassetteCategory_CheckForContaminationControl", "operationStartFlag = TRUE!"); //D4000138
        }
//P4000269        else if ( rc == RC_INVALID_CATEGORY_CHECK )
//P4000269        {
//P4000269            strStartCassette.strLotInCassette[ii].operationStartFlag = FALSE;
//P4000269        }
        else
        {
            PPT_METHODTRACE_V1( "", "lot_CassetteCategory_CheckForContaminationControl() != RC_OK");
            strLotVerifyForLoadingForInternalBufferReqResult.strResult = strLot_CassetteCategory_CheckForContaminationControl_out.strResult;
            return( rc );
        }

//D4000046 add end 2001/08/23

//D4000046 remove        if ( rc != RC_OK )
//D4000046 remove        {
//D4000046 remove            PPT_METHODTRACE_V1( "", "lot_CassetteCategory_CheckForContaminationControl() != RC_OK");
//D4000046 remove            strLotVerifyForLoadingForInternalBufferReqResult.strResult = strLot_CassetteCategory_CheckForContaminationControl_out.strResult;
//D4000046 remove            return( rc );
//D4000046 remove        }

    }

//D4000016 Add End

    /*--------------------------*/
    /*                          */
    /*   Set Return Structure   */
    /*                          */
    /*--------------------------*/
    CORBA::Long startLotCount   = 0;
    CORBA::Long monitorLotCount = 0;

    strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot.length(lotLen);
    PPT_METHODTRACE_V2( "", "lotLen = ", lotLen);
    for ( i=0 ; i<lotLen ; i++ )
    {
        strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[i].operationStartFlag = strStartCassette.strLotInCassette[i].operationStartFlag;
        strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[i].monitorLotFlag     = strStartCassette.strLotInCassette[i].monitorLotFlag;
        strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[i].lotID              = strStartCassette.strLotInCassette[i].lotID;
//D7000135 add start
        strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[i].verifyNGReason     = verifyNGReasons[i];
        PPT_METHODTRACE_V3( "", "# operationStartFlag ", i, (int)strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[i].operationStartFlag);
        PPT_METHODTRACE_V3( "", "# lotID              ", i, strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[i].lotID.identifier);
        PPT_METHODTRACE_V3( "", "# verifyNGReason     ", i, strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[i].verifyNGReason);
//D7000135 add end

        //P3000051 add start
        CORBA::Boolean operationStartFlag;
        operationStartFlag = strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[i].operationStartFlag;
        if (operationStartFlag == TRUE)
        {
            PPT_METHODTRACE_V1( "", "strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[i].operationStartFlag == TRUE");
            startLotCount++;
            if ( strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[i].monitorLotFlag == TRUE )
            {
                PPT_METHODTRACE_V1( "",
                                    "strLotVerifyForLoadingForInternalBufferReqResult.strLoadingVerifiedLot[i].monitorLotFlag == TRUE");
                monitorLotCount++;
            }
        }
    }

    /*-----------------------------------------------------------*/
    /*                                                           */
    /*   Final Check for Start Lot Count and Monitor Lot Count   */
    /*                                                           */
    /*-----------------------------------------------------------*/
    PPT_METHODTRACE_V2( "", "in-parm's loadPurposeType", loadPurposeType);   //D4000138
    PPT_METHODTRACE_V2( "", "startLotCount            ", startLotCount);     //D4000138
    PPT_METHODTRACE_V2( "", "monitorLotCount          ", monitorLotCount);   //D4000138

    if (CIMFWStrCmp(loadPurposeType,SP_LoadPurposeType_ProcessLot) == 0 ||
        CIMFWStrCmp(loadPurposeType,SP_LoadPurposeType_ProcessMonitorLot) == 0 )
    {
        PPT_METHODTRACE_V1( "", "in-parm's loadPurposeType == (SP_LoadPurposeType_ProcessLot,SP_LoadPurposeType_ProcessProcessMonitorLot)");

        //--D4000148 start
        if( 0 == CIMFWStrLen( strCassette_controlJobID_Get_out.controlJobID.identifier) )    //D7000042
        {                                                                                    //D7000042
            pptStartCassetteSequence strStartCassetteSeq;
            strStartCassetteSeq.length(1);
            strStartCassetteSeq[0] = strStartCassette;

            objLot_recipeCombination_CheckForLoading_out  strLot_recipeCombination_CheckForLoading_out;
            rc = lot_recipeCombination_CheckForLoading(
                                               strLot_recipeCombination_CheckForLoading_out,
                                               strObjCommonIn,
                                               equipmentID,
                                               strStartCassetteSeq,
                                               loadPurposeType) ;
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("PPTManager_i:: txLotVerifyForLoadingForInternalBufferReq", "lot_recipeCombination_CheckForLoading() != RC_OK") ;
                strLotVerifyForLoadingForInternalBufferReqResult.strResult = strLot_recipeCombination_CheckForLoading_out.strResult ;
                return rc ;
            }
        }    //D7000042
        //--D4000148 end

        //--D4000136 start
        /*-----------------------------------*/
        /*   Verify BufferResource           */
        /*-----------------------------------*/
        objEquipment_multiRecipeCapability_Get_out strEquipment_multiRecipeCapability_Get_out ;
        rc = equipment_multiRecipeCapability_Get(strEquipment_multiRecipeCapability_Get_out, strObjCommonIn, equipmentID) ;
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txLotVerifyForLoadingForInternalBufferReq", "equipment_multiRecipeCapability_Get() != RC_OK") ;
            strLotVerifyForLoadingForInternalBufferReqResult.strResult = strEquipment_multiRecipeCapability_Get_out.strResult ;
            return rc ;
        }
        if(CIMFWStrCmp(SP_Eqp_MultiRecipeCapability_Batch,
                       strEquipment_multiRecipeCapability_Get_out.multiRecipeCapability)==0)
        {
            if(startLotCount != lotLen)
            {
                PPT_METHODTRACE_V1( "", "startLotCount != lotLen");
                SET_MSG_RC(strLotVerifyForLoadingForInternalBufferReqResult,MSG_NEED_TO_SPECIFY_ALL_LOT_IN_CAST,RC_NEED_TO_SPECIFY_ALL_LOT_IN_CAST);
                return(RC_NEED_TO_SPECIFY_ALL_LOT_IN_CAST);
            }
        }
        //--D4000136 end

        if ( startLotCount == 0 )
        {
            PPT_METHODTRACE_V1( "", "startLotCount == 0");
            SET_MSG_RC(strLotVerifyForLoadingForInternalBufferReqResult,MSG_NOT_CANDIDATE_LOT_FOR_OPE_START,RC_NOT_CANDIDATE_LOT_FOR_OPE_START);
            return(RC_NOT_CANDIDATE_LOT_FOR_OPE_START);
        }
        if ( monitorLotCount > 1 )
        {
            PPT_METHODTRACE_V1( "", "monitorLotCount > 0");
            SET_MSG_RC(strLotVerifyForLoadingForInternalBufferReqResult,MSG_INVALID_PROCMONITOR_COUNT,RC_INVALID_PROCMONITOR_COUNT);
            return(RC_INVALID_PROCMONITOR_COUNT);
        }

        //P4200534 add start
        //-----------------------------------------------------------//
        //                                                           //
        //   Final Check for LoadPurposeType:ProcessMonitorLot       //
        //                                                           //
        //   The lot, which meets fhe following conditions must be   //
        //   exist, and its lot count must be 1.                     //
        //      - OpeStartFlag   : TRUE                              //
        //      - LotType        : ProcessMonitor                    //
        //      - MonitorLotFlag : TRUE                              //
        //                                                           //
        //-----------------------------------------------------------//
        PPT_METHODTRACE_V3("", "strStartCassette Info", strStartCassette.cassetteID.identifier,
                            strStartCassette.loadPurposeType );

        if (CIMFWStrCmp( strStartCassette.loadPurposeType,
                         SP_LoadPurposeType_ProcessMonitorLot ) ==0 )
        {
            PPT_METHODTRACE_V1( "", "loadPurposeType is ProcessMonitorLot" )

            if ( monitorLotCount != 1 )
            {
                PPT_METHODTRACE_V2( "", "nMonitorLotCnt != 1", monitorLotCount );
                SET_MSG_RC( strLotVerifyForLoadingForInternalBufferReqResult, MSG_INVALID_PROCMONITOR_COUNT, RC_INVALID_PROCMONITOR_COUNT );
                return( RC_INVALID_PROCMONITOR_COUNT );
            }

            CORBA::Long    i_lot = 0;
            CORBA::Long    lotLen = strStartCassette.strLotInCassette.length();

            for ( i_lot = 0 ; i_lot < lotLen ; i_lot++ )
            {
                if (( strStartCassette.strLotInCassette[i_lot].monitorLotFlag     == TRUE )&&
                    ( strStartCassette.strLotInCassette[i_lot].operationStartFlag == TRUE ))
                {
                    PPT_METHODTRACE_V3( "", "LotID & LotType", strStartCassette.strLotInCassette[i_lot].lotID.identifier,
                                                               strStartCassette.strLotInCassette[i_lot].lotType );

                    if ( CIMFWStrCmp(strStartCassette.strLotInCassette[i_lot].lotType,
                                     SP_Lot_Type_ProductionMonitorLot ) != 0 )
                    {
//D5100053 Add Start
                        objLot_monitorRouteFlag_Get_out strLot_monitorRouteFlag_Get_out;
                        rc = lot_monitorRouteFlag_Get(strLot_monitorRouteFlag_Get_out,
                                                      strObjCommonIn,
                                                      strStartCassette.strLotInCassette[i_lot].lotID);
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("","lot_monitorRouteFlag_Get() != RC_OK");
                            strLotVerifyForLoadingForInternalBufferReqResult.strResult = strLot_monitorRouteFlag_Get_out.strResult;
                            return ( rc );
                        }

                        PPT_METHODTRACE_V2( "", "monitorRoute_Flag =", strLot_monitorRouteFlag_Get_out.monitorRoute_Flag );

                        if ( strLot_monitorRouteFlag_Get_out.monitorRoute_Flag == FALSE )
                        {
                            PPT_METHODTRACE_V1( "", "Specified Lot Type is not ProductionMonitorLot" );
                            PPT_SET_MSG_RC_KEY2( strLotVerifyForLoadingForInternalBufferReqResult, MSG_INVALID_LOT_TYPE, RC_INVALID_LOT_TYPE,
                                                 strStartCassette.strLotInCassette[i_lot].lotType,
                                                 strStartCassette.strLotInCassette[i_lot].lotID.identifier );
                            return( RC_INVALID_LOT_TYPE );
                        }
//D5100053 Add End
//D5100053                        PPT_METHODTRACE_V1( "", "Specified Lot Type is not ProductionMonitorLot" );
//D5100053                        PPT_SET_MSG_RC_KEY2( strLotVerifyForLoadingForInternalBufferReqResult, MSG_INVALID_LOT_TYPE, RC_INVALID_LOT_TYPE,
//D5100053                                             strStartCassette.strLotInCassette[i_lot].lotType,
//D5100053                                             strStartCassette.strLotInCassette[i_lot].lotID.identifier );
//D5100053                        return( RC_INVALID_LOT_TYPE );
                    }

                    break;

                }
            }
        }
        //P4200534 add end
    }

    /*----------------------*/
    /*                      */
    /*   Return to Caller   */
    /*                      */
    /*----------------------*/
    SET_MSG_RC(strLotVerifyForLoadingForInternalBufferReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("PPTManager_i:: txLotVerifyForLoadingForInternalBufferReq");
    return ( RC_OK );
}
