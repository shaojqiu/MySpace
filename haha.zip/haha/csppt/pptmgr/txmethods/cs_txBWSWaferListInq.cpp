// (c) Copyright: IBM  Company Ltd, 2017, 2027. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017, 2027. All rights reserved.
//
// SiView
// Name: cs_txUserCertifyCheckInq.cpp
//
// Modeficaiton History:
// Date       Defect        Name          Description
// ---------- ------------- ------------- ----------------------------------------------
// 2017/10/19 INN-R170017   LiHejing      BWS WaferListInquery

// Class: PPTServiceManager
//
// Service: cs_txBWSWaferListInq()

// Description:
//<Method Summary>

//</Method Summary>

// Return:
//     long
//
// Parameter:
//
//     csUserCertifyCheckInqResult&          strUserCertifyCheckInqResult
//     const pptObjCommonIn&                 strObjCommonIn
//     const csUserCertifyCheckInqInParm&    strUserCertifyCheckInqInParm

//<Method Start>
#include "cs_pptmgr.hpp"

CORBA::Long CS_PPTManager_i::cs_txBWSWaferListInq (
    csBWSWaferListInqResult&          strBWSWaferListInqResult,
    const pptObjCommonIn&             strObjCommonIn,
    const csBWSWaferListInqInParm&    strBWSWaferListInqInParm,
    CORBAENV_LAST_CPP )
{
    PPT_METHODTRACE_ENTRY("PPTManager_i::cs_txBWSWaferListInq");
    CORBA::Long rc = RC_OK;

    //----------------------------------------------------------------
    //
    //  Check lSearch Condition at least one value not null
    //
    //----------------------------------------------------------------
    if ( ! CORBA::is_nil( strBWSWaferListInqInParm.lSearchType ) )
	{
		if ( 0 == strBWSWaferListInqInParm.lSearchType )
		{
			if ( 0 == CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.waferID.identifier ) &&
				0 == CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.waferGradeID ) &&
				0 == CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.lotID.identifier ) &&
				0 == CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.bankID.identifier ) &&
				0 == CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.productID.identifier ) &&
				0 == CIMFWStrLen( strBWSWaferListInqInParm.strBWSWaferData.subLotType ) )
				{
					return error;//Wait
				}
		}
	}
    
    
    //----------------------------------------------------------------------
    //
    //  Main Process
    //
    //----------------------------------------------------------------------

    // get WaferList Info by calling csObjBWS_WaferList_GetDR
    csObjBWS_WaferList_GetDR_out strObjBWS_WaferList_GetDR_out;
    csObjBWS_WaferList_GetDR_in  strObjBWS_WaferList_GetDR_in;

    strObjBWS_WaferList_GetDR_in.userID = strBWSWaferListInqInParm.userID;
    rc = cs_person_SkillList_GetDR( strObjBWS_WaferList_GetDR_out,
                                    strObjCommonIn,
                                    strObjBWS_WaferList_GetDR_in );
                                    
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "cs_person_SkillList_GetDR() rc != RC_OK. ", rc);
        strUserCertifyCheckInqResult.strResult = strObjBWS_WaferList_GetDR_out.strResult;
        return(rc);
    }
    
        // loop this user's skillinfo to check
    CORBA::Long nSkillInfoCnt = strObjBWS_WaferList_GetDR_out.strUserSkillInfo.strSkillInfo.length();
    PPT_METHODTRACE_V2("","nSkillInfoCnt",nSkillInfoCnt);
    for (CORBA::Long i = 0; i < nSkillInfoCnt; i++)
    {
        char *tCertifiedDate = strObjBWS_WaferList_GetDR_out.strUserSkillInfo.strSkillInfo[i].certifiedDate;
        CORBA::Long nLen = CIMFWStrLen(tCertifiedDate);
        PPT_METHODTRACE_V2("","tCertifiedDate",tCertifiedDate);
        PPT_METHODTRACE_V2("","skill_ID",strObjBWS_WaferList_GetDR_out.strUserSkillInfo.strSkillInfo[i].skillID);
        
        if (reportDyas > days)
        {
            CORBA::String_var varSkillID = CIMFWStrDup(strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo[i].skillID);
            PPT_METHODTRACE_V2("","tCertifiedDate_185",varSkillID);
            CS_PPT_SET_MSG_RC_KEY2( strUserCertifyCheckInqResult,
                                    CS_MSG_USER_SKILL_EXPIRED_DATE,
                                    CS_RC_USER_SKILL_EXPIRED_DATE,
                                    varSkillID,
                                    tCertifiedDate );
            // CS_SET_MSG_RC(strUserCertifyCheckInqResult,CS_MSG_USER_SKILL_EXPIRED_DATE,CS_RC_USER_SKILL_EXPIRED_DATE);
            return CS_RC_USER_SKILL_EXPIRED_DATE;
        }
    }
    
    // Return to caller
    // SET_MSG_RC(cs_txBWSWaferListInq, MSG_OK, RC_OK);
    PPT_METHODTRACE_EXIT("PPTManager_i::cs_txBWSWaferListInq");                    
    return RC_OK;
}