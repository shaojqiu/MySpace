#ifndef lint
static char *sccsid =  "@(#) 1.5 superpos/src/spppt/source/posppt/pptmgr/txmethods/txMergeWaferLotNotOnRouteReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/15/07 12:21:42 [ 11/15/07 12:21:43 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: txMergeWaferLotNotOnRouteReq.cpp
//

#include "cs_pptmgr.hpp"
#include "penin.hh"

// Class: CS_PPTManager
//
// Service: txMergeWaferLotNotOnRouteReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/16          O.Sugiyama     Initial Release
// 2000/09/26 Q3000147 S.Kawabe       Add Check Lot's Control Job ID
// 2000/10/16 0.01     S.Kawabe       Bug Fix  Check lot hold state
// 2000/10/23 P3000280 S.Kawabe       Boolean variable initialize
// 2001-03-02 P3100069 O.Sugiyama     Add LotWaferMoveEvent
// 2001-06-26 P4000033 K.Kido         Add CheckLogic for ParentCassetteID(ChildCassetteID) is there
// 2001/07/02 P4000037 K.Kido         Add XferState Check
// 2001-08-01 P4000079 K.Kido         Change XferState check logic
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2007/06/12 D9000005 H.Hotta        WaferSorter automation support.
// 2007/06/14 D9000038 H.Murakami     Remove In-Cassette Limitation.
// 2007/06/15 P9000011 H.Murakami     Bug Fix.
// 2007/08/03 D9000056 H.Hotta        Add check logic for InPostProcessFlag.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/08 DSIV00000099 M.Ogawa        Add check logic for MachineContainerPosition.
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
// 2010/03/15 DSIV00001830 S.Kawabe       Wafer Stacking Operation Support
// 2013/05/09 DSN000071674 Liuya          Remove part of the EI state limitation
// 2014/01/21 PSN000083176 C.Mo           Data inconsistency might occur when start lot reservation is called together with lot operation transactions for the same cassette
// 2014/05/13 DSN000085698 S.Wang         Support equipment monitor used count function
// 2017/02/13 DSN000104277 K.Yamaoku      Performance improvement(reference:lot_wafers_GetDR)
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/27 INN-R170003  XL.Cong        Durable Management Enhancement
//
//
//
// Description:
//
// Return:
//     long
//
//
// Parameter:
//    pptMergeWaferLotNotOnRouteReqResult&    strMergeWaferLotNotOnRouteReqResult
//    const pptObjCommonIn&                   strObjCommonIn
//    const pptUser&                          requestUserID
//    const objectIdentifier&                 parentLotID
//    const objectIdentifier&                 childLotID
//    const char *                            claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i:: txMergeWaferLotNotOnRouteReq (
    pptMergeWaferLotNotOnRouteReqResult&    strMergeWaferLotNotOnRouteReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const pptUser&                          requestUserID,
    const objectIdentifier&                 parentLotID,
    const objectIdentifier&                 childLotID,
//D6000025     const char *                            claimMemo,
//D6000025     CORBA::Environment &                    IT_env)
    const char *                            claimMemo  //D6000025
    CORBAENV_LAST_CPP)                                 //D6000025
{
    PPT_METHODTRACE_ENTRY("PPTManager_i:: txMergeWaferLotNotOnRouteReq");
    CORBA::Long rc = RC_OK ;

    CORBA::Boolean bParentLotHasWaferID = TRUE;        //D9000038
    CORBA::Boolean bChildLotHasWaferID  = TRUE;        //D9000038
    CORBA::Boolean bHasWaferID          = TRUE;        //D9000038

    //-------------------------------------------------------------
    // Get cassetteID which parentLot is in for object_Lock().
    //-------------------------------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Get cassetteID which parentLot is in for object_Lock().");

    PPT_METHODTRACE_V2("", "in para parentLotID ", parentLotID.identifier );
    PPT_METHODTRACE_V2("", "in para childLotID  ", childLotID.identifier );

    objLot_cassette_Get_out strLot_cassette_Get_out;

//DSN000071674 add start
    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );

    CORBA::Boolean updateControlJobFlag = FALSE;
    CORBA::Long lockMode = 0; //PSN000083176

    objCassette_transferState_Get_out strCassetteTransferState;
    objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
    objObject_Lock_out strObject_Lock_out;
//DSN000071674 add end

    //-----------------------------
    // set parentLotID of in-parm.
    //-----------------------------
//P9000011    lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn,
//P9000011                     parentLotID);   // set parentLotID of in-parm.

    rc = lot_cassette_Get( strLot_cassette_Get_out, strObjCommonIn, parentLotID);    //P9000011

    if ( rc != RC_OK && rc != RC_NOT_FOUND_CST )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_cassette_Get(parentLotID) rc != RC_OK");
        strMergeWaferLotNotOnRouteReqResult.strResult = strLot_cassette_Get_out.strResult ;
        return(rc);
    }
    // When parentLot is in parentCassetteID.
    objectIdentifier aParentCassetteID;
//D9000038    aParentCassetteID = strLot_cassette_Get_out.cassetteID;
    if ( rc == RC_OK )
    {
        aParentCassetteID = strLot_cassette_Get_out.cassetteID;//D9000038
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_cassette_Get(parentLotID) rc == RC_OK");
//DSN000071674        objObject_Lock_out strObject_Lock_out;
//DSN000071674 add start
        if ( 0 == lotOperationEIcheck )
        {
            //-------------------------------
            // Get carrier transfer status
            //-------------------------------
            rc = cassette_transferState_Get(strCassetteTransferState, strObjCommonIn,
                                            aParentCassetteID);
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "rc != RC_OK");
                strMergeWaferLotNotOnRouteReqResult.strResult = strCassetteTransferState.strResult ;
                return( rc );
            }

            /*------------------------------------*/
            /*   Get equipment ID in Cassette     */
            /*------------------------------------*/
            rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                           strObjCommonIn,
                                           aParentCassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "", "cassette_equipmentID_Get != RC_OK", rc);
                strMergeWaferLotNotOnRouteReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
                return( rc );
            }

            //-------------------------------
            // Get required equipment lock mode
            //-------------------------------
            objObject_lockMode_Get_out strObject_lockMode_Get_out;
            objObject_lockMode_Get_in  strObject_lockMode_Get_in;
            strObject_lockMode_Get_in.objectID           = strCassette_equipmentID_Get_out.equipmentID;
            strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
            strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXTRC049" ); // TxMergeWaferLotNotOnRouteReq
            strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

            rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                      strObjCommonIn,
                                      strObject_lockMode_Get_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
                strMergeWaferLotNotOnRouteReqResult.strResult = strObject_lockMode_Get_out.strResult;
                return( rc );
            }

//PSN000083176            CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
            lockMode = strObject_lockMode_Get_out.lockMode; //PSN000083176
            PPT_METHODTRACE_V2( "", "lockMode", lockMode );
//INN-R170003 if ( 0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) 
//INN-R170003 add start
            if ( 0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) ||
                 0 == CIMFWStrCmp( strCassetteTransferState.transferState, SP_TransState_EquipmentOut ) || 
                 0 == CIMFWStrCmp( strCassetteTransferState.transferState, CS_TRANS_STATE_PORT_IN ) )
//INN-R170003 add end 
            {                PPT_METHODTRACE_V1("PPTManager_i::cs_txMergeWaferLotNotOnRouteReq", "transferState == EO/PI");
                updateControlJobFlag = TRUE;
                if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
                {
                    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
                    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;

                    // Lock Equipment Main Object
                    stringSequence dummySeq;
                    dummySeq.length(0);
                    strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                    strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                    strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
                    strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
                    strAdvanced_object_Lock_in.keySeq     = dummySeq;

                    rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                                strObjCommonIn,
                                                strAdvanced_object_Lock_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                        strMergeWaferLotNotOnRouteReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                        return( rc );
                    }

                    // Lock Equipment LoadCassette Element (Write)
                    stringSequence loadCastSeq;
                    loadCastSeq.length(1);
                    loadCastSeq[0] = aParentCassetteID.identifier;
                    strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                    strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                    strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
                    strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
                    strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

                    rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                                strObjCommonIn,
                                                strAdvanced_object_Lock_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                        strMergeWaferLotNotOnRouteReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                        return( rc );
                    }
                }
                else
                {
                    /*--------------------------------*/
                    /*   Lock Macihne object          */
                    /*--------------------------------*/
                    rc = object_Lock( strObject_Lock_out, strObjCommonIn, strCassette_equipmentID_Get_out.equipmentID, SP_ClassName_PosMachine );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc) ;
                        strMergeWaferLotNotOnRouteReqResult.strResult = strObject_Lock_out.strResult ;
                        return( rc );
                    }
                }
            }
//PSN000083176            if( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176            {
//PSN000083176                //---------------------------------
//PSN000083176                //   Get Cassette's ControlJobID
//PSN000083176                //---------------------------------
//PSN000083176                objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;
//PSN000083176                rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
//PSN000083176                                                strObjCommonIn,
//PSN000083176                                                aParentCassetteID );
//PSN000083176                if ( rc != RC_OK )
//PSN000083176                {
//PSN000083176                    PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
//PSN000083176                    strMergeWaferLotNotOnRouteReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
//PSN000083176                    return( rc );
//PSN000083176                }
//PSN000083176                if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
//PSN000083176                {
//PSN000083176                    PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
//PSN000083176                    updateControlJobFlag = TRUE;
//PSN000083176                    if( lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176                    {
//PSN000083176                        /*------------------------------*/
//PSN000083176                        /*   Lock ControlJob Object     */
//PSN000083176                        /*------------------------------*/
//PSN000083176                        rc = object_Lock( strObject_Lock_out,
//PSN000083176                                          strObjCommonIn, 
//PSN000083176                                          strCassette_controlJobID_Get_out.controlJobID, 
//PSN000083176                                          SP_ClassName_PosControlJob );
//PSN000083176                        if ( rc != RC_OK )
//PSN000083176                        {
//PSN000083176                            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
//PSN000083176                            strMergeWaferLotNotOnRouteReqResult.strResult = strObject_Lock_out.strResult;
//PSN000083176                            return( rc );
//PSN000083176                        }
//PSN000083176                    }
//PSN000083176                }
//PSN000083176            }
        }
//DSN000071674 add end

        rc = object_Lock(strObject_Lock_out, strObjCommonIn,
                         aParentCassetteID, SP_ClassName_PosCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "object_Lock(aParentCassetteID) rc != RC_OK");
            strMergeWaferLotNotOnRouteReqResult.strResult = strObject_Lock_out.strResult ;
            return(rc);
        }

//PSN000083176 add start
        if ( 0 == lotOperationEIcheck )
        {
            if( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
            {
                //---------------------------------
                //   Get Cassette's ControlJobID
                //---------------------------------
                objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;
                rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                                strObjCommonIn,
                                                aParentCassetteID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
                    strMergeWaferLotNotOnRouteReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
                    return( rc );
                }
                if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
                {
                    PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
                    updateControlJobFlag = TRUE;
                    if( lockMode != SP_EQP_LOCK_MODE_WRITE )
                    {
                        /*------------------------------*/
                        /*   Lock ControlJob Object     */
                        /*------------------------------*/
                        rc = object_Lock( strObject_Lock_out,
                                          strObjCommonIn, 
                                          strCassette_controlJobID_Get_out.controlJobID, 
                                          SP_ClassName_PosControlJob );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                            strMergeWaferLotNotOnRouteReqResult.strResult = strObject_Lock_out.strResult;
                            return( rc );
                        }
                    }
                }
            }
        }
//PSN000083176 add end
    }

    //-------------------------------------------------------------
    // Get cassetteID which childLot is in for object_Lock().
    //-------------------------------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Get cassetteID which childLot is in for object_Lock().");

//P9000011    lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn,
//P9000011                     childLotID);   // set childLotID of in-parm.

    //---------------------------
    // set childLotID of in-parm.
    //---------------------------
    rc = lot_cassette_Get( strLot_cassette_Get_out, strObjCommonIn, childLotID);    //P9000011

    if ( rc != RC_OK && rc != RC_NOT_FOUND_CST )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_cassette_Get(childLotID) rc != RC_OK");
        strMergeWaferLotNotOnRouteReqResult.strResult = strLot_cassette_Get_out.strResult ;
        return(rc);
    }
    // When parentLot is in childCassetteID.
    objectIdentifier aChildCassetteID;
//D9000038   aChildCassetteID = strLot_cassette_Get_out.cassetteID;
    if ( rc == RC_OK )
    {
        aChildCassetteID = strLot_cassette_Get_out.cassetteID;//D9000038
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_cassette_Get(childLotID) rc == RC_OK");
//DSN000071674        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock(strObject_Lock_out, strObjCommonIn,
                         aChildCassetteID, SP_ClassName_PosCassette);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "object_Lock(aChildCassetteID) rc != RC_OK");
            strMergeWaferLotNotOnRouteReqResult.strResult = strObject_Lock_out.strResult ;
            return(rc);
        }
    }

//D9000038 add start
    //---------------------------------------------------------//
    //   Check CassetteIDs of the Parent Lot and the Child Lot //
    //---------------------------------------------------------//
    PPT_METHODTRACE_V1("", "CassetteIDs should be same!");
    PPT_METHODTRACE_V2("", " aParentCassetteID = ", aParentCassetteID.identifier);
    PPT_METHODTRACE_V2("", " aChildCassetteID = ", aChildCassetteID.identifier);
    if ( 0 != CIMFWStrCmp( aParentCassetteID.identifier, aChildCassetteID.identifier) )
    {
        PPT_METHODTRACE_V1("", " aParentCassetteID != aChildCassetteID");
        SET_MSG_RC(strMergeWaferLotNotOnRouteReqResult, MSG_CAST_NOTSAME, RC_CAST_NOTSAME);
        return( RC_CAST_NOTSAME );
    }
    else
    {
        PPT_METHODTRACE_V1("", " aParentCassetteID == aChildCassetteID");
    }
//D9000038 add end

    /*--------------------------------*/
    /*   Lock objects to be updated   */
    /*--------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Lock objects to be updated");

//DSN000071674    objObject_Lock_out strObject_Lock_out;
    rc = object_Lock(strObject_Lock_out, strObjCommonIn,
                     parentLotID, SP_ClassName_PosLot);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "object_Lock(parentLotID) rc != RC_OK");
        strMergeWaferLotNotOnRouteReqResult.strResult = strObject_Lock_out.strResult ;
        return(rc);
    }

    rc = object_Lock(strObject_Lock_out, strObjCommonIn,
                     childLotID, SP_ClassName_PosLot);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "object_Lock(childLotID) rc != RC_OK");
        strMergeWaferLotNotOnRouteReqResult.strResult = strObject_Lock_out.strResult ;
        return(rc);
    }

//D9000005 add start
    /*-------------------------------*/
    /*   Check SorterJob existence   */
    /*-------------------------------*/
    pptEquipmentLoadPortAttribute dummyEquipmentPortAttribute;
    objectIdentifierSequence dummyCastIDs, lotIDs;
    lotIDs.length(2);
    lotIDs[0] = parentLotID;
    lotIDs[1] = childLotID;

    objWaferSorter_sorterJob_CheckForOperation_out strWaferSorter_sorterJob_CheckForOperation_out;
    objWaferSorter_sorterJob_CheckForOperation_in  strWaferSorter_sorterJob_CheckForOperation_in;
    strWaferSorter_sorterJob_CheckForOperation_in.strEquipmentLoadPortAttribute = dummyEquipmentPortAttribute;
    strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs                   = dummyCastIDs;
    strWaferSorter_sorterJob_CheckForOperation_in.lotIDs                        = lotIDs;
    strWaferSorter_sorterJob_CheckForOperation_in.operation                     = CIMFWStrDup(SP_Operation_For_Lot);

    rc = waferSorter_sorterJob_CheckForOperation( strWaferSorter_sorterJob_CheckForOperation_out,
                                                  strObjCommonIn,
                                                  strWaferSorter_sorterJob_CheckForOperation_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "waferSorter_sorterJob_CheckForOperation() != RC_OK" );
        strMergeWaferLotNotOnRouteReqResult.strResult = strWaferSorter_sorterJob_CheckForOperation_out.strResult;
        return( rc );
    }
//D9000005 add end

    //---------------------------------
    // Check Contents for parent lot
    //---------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Check Contents for parent lot");

    objLot_contents_Get_out strLot_contents_Get_out;
    rc = lot_contents_Get(strLot_contents_Get_out, strObjCommonIn,
                          parentLotID);  //for parentLot
    if (rc)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_contents_Get(parentLotID) rc != RC_OK");
        strMergeWaferLotNotOnRouteReqResult.strResult = strLot_contents_Get_out.strResult ;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_contents_Get_out.theLotContents, SP_ProdType_Wafer) != 0 &&
             CIMFWStrCmp(strLot_contents_Get_out.theLotContents, SP_ProdType_Die  ) != 0)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_contents_Get(parentLotID) returned lotContent is not SP_ProdType_Wafer nor SP_ProdType_Die");
        PPT_SET_MSG_RC_KEY(strMergeWaferLotNotOnRouteReqResult, MSG_INVALID_LOT_CONTENTS, RC_INVALID_LOT_CONTENTS,
                           parentLotID.identifier);
        return( RC_INVALID_LOT_CONTENTS );
    }

    //---------------------------------
    // Check Contents for child lot
    //---------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Check Contents for child lot");

    rc = lot_contents_Get(strLot_contents_Get_out, strObjCommonIn,
                          childLotID);  //for childLot
    if (rc)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_contents_Get(childLotID) rc != RC_OK");
        strMergeWaferLotNotOnRouteReqResult.strResult = strLot_contents_Get_out.strResult ;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_contents_Get_out.theLotContents, SP_ProdType_Wafer) != 0 &&
             CIMFWStrCmp(strLot_contents_Get_out.theLotContents, SP_ProdType_Die  ) != 0)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_contents_Get(childLotID) returned lotContent is not SP_ProdType_Wafer nor SP_ProdType_Die");
        PPT_SET_MSG_RC_KEY(strMergeWaferLotNotOnRouteReqResult, MSG_INVALID_LOT_CONTENTS, RC_INVALID_LOT_CONTENTS,
                           childLotID.identifier);
        return( RC_INVALID_LOT_CONTENTS );
    }

//DSIV00001830 add start
    //------------------------------------
    // Check Bonding Group for parent lot
    //------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Check Bonding Group for parent lot");

    objLot_bondingGroupID_GetDR_in  strLot_bondingGroupID_GetDR_in;
    strLot_bondingGroupID_GetDR_in.lotID = parentLotID;

    objLot_bondingGroupID_GetDR_out strLot_bondingGroupID_GetDR_out;
    rc = lot_bondingGroupID_GetDR( strLot_bondingGroupID_GetDR_out, strObjCommonIn, strLot_bondingGroupID_GetDR_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_bondingGroupID_GetDR() rc != RC_OK");
        strMergeWaferLotNotOnRouteReqResult.strResult = strLot_bondingGroupID_GetDR_out.strResult;
        return rc;
    }
    if( CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0");
        PPT_SET_MSG_RC_KEY2( strMergeWaferLotNotOnRouteReqResult,
                             MSG_LOT_HAS_BONDINGGROUP,
                             RC_LOT_HAS_BONDINGGROUP,
                             strLot_bondingGroupID_GetDR_in.lotID.identifier,
                             strLot_bondingGroupID_GetDR_out.bondingGroupID );
        return RC_LOT_HAS_BONDINGGROUP;
    }

    //------------------------------------
    // Check Bonding Group for child lot
    //------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Check Bonding Group for child lot");

    strLot_bondingGroupID_GetDR_in.lotID = childLotID;
    rc = lot_bondingGroupID_GetDR( strLot_bondingGroupID_GetDR_out, strObjCommonIn, strLot_bondingGroupID_GetDR_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_bondingGroupID_GetDR() rc != RC_OK");
        strMergeWaferLotNotOnRouteReqResult.strResult = strLot_bondingGroupID_GetDR_out.strResult;
        return rc;
    }
    if( CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(strLot_bondingGroupID_GetDR_out.lotID.identifier) > 0");
        PPT_SET_MSG_RC_KEY2( strMergeWaferLotNotOnRouteReqResult,
                             MSG_LOT_HAS_BONDINGGROUP,
                             RC_LOT_HAS_BONDINGGROUP,
                             strLot_bondingGroupID_GetDR_in.lotID.identifier,
                             strLot_bondingGroupID_GetDR_out.bondingGroupID );
        return RC_LOT_HAS_BONDINGGROUP;
    }
//DSIV00001830 add end

    //------------------------------------------------------
    // Check parent lot and child lot is same state or not
    //------------------------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Check parent lot and child lot is same state or not");

    objLot_allState_CheckSame_out strLot_allState_CheckSame_out;
    rc = lot_allState_CheckSame(strLot_allState_CheckSame_out, strObjCommonIn,
                                parentLotID, childLotID);  //for parentLot and childLot
    if (rc)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_allState_CheckSame() rc != RC_OK");
        strMergeWaferLotNotOnRouteReqResult.strResult = strLot_allState_CheckSame_out.strResult ;
        return(rc);
    }

    //------------------------------------------------------
    // Check lot state
    //------------------------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Check lot state");

    if (CIMFWStrCmp(strLot_allState_CheckSame_out.lotState, CIMFW_Lot_State_Finished) != 0)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_allState_CheckSame() returned lotState is not CIMFW_Lot_State_Finished");
        PPT_SET_MSG_RC_KEY(strMergeWaferLotNotOnRouteReqResult, MSG_INVALID_LOT_STAT, RC_INVALID_LOT_STAT,
                           strLot_allState_CheckSame_out.lotState);
        return( RC_INVALID_LOT_STAT );
    }

    //------------------------------------------------------
    // Check lot hold state
    //------------------------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Check lot hold state");

//0.01    if (CIMFWStrCmp(strLot_allState_CheckSame_out.lotHoldState, CIMFW_Lot_State_Finished) != 0)
    if (CIMFWStrCmp(strLot_allState_CheckSame_out.lotHoldState, CIMFW_Lot_HoldState_NotOnHold) != 0)  //0.01
    {
//        ------------------------------------------------------------
//            New message     : MSG_CANNOT_MERGE_HELDLOT_INBANK
//            New return code : RC_CANNOT_MERGE_HELDLOT_INBANK
//        ------------------------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_allState_CheckSame() returned lotHoldState is not CIMFW_Lot_HoldState_NotOnHold");
        SET_MSG_RC(strMergeWaferLotNotOnRouteReqResult, MSG_CANNOT_MERGE_HELDLOT_INBANK, RC_CANNOT_MERGE_HELDLOT_INBANK);
        return( RC_CANNOT_MERGE_HELDLOT_INBANK );
    }

    //------------------------------------------------------
    // Check lot finished state
    //------------------------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Check lot finished state");

    if (CIMFWStrCmp(strLot_allState_CheckSame_out.lotFinishedState, CIMFW_Lot_FinishedState_Completed) != 0)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_allState_CheckSame() returned lotFinishedState is not CIMFW_Lot_FinishedState_Completed");
        PPT_SET_MSG_RC_KEY(strMergeWaferLotNotOnRouteReqResult, MSG_INVALID_LOT_FINISHSTAT, RC_INVALID_LOT_FINISHSTAT,
                           strLot_allState_CheckSame_out.lotFinishedState);
        return( RC_INVALID_LOT_FINISHSTAT );
    }

    //------------------------------------------------------
    // Check lot process state
    //------------------------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Check lot process state");

    if (CIMFWStrCmp(strLot_allState_CheckSame_out.lotProcessState, SP_Lot_ProcState_Processed) != 0)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_allState_CheckSame() returned lotProcessState is not SP_Lot_ProcState_Processed");
        PPT_SET_MSG_RC_KEY2(strMergeWaferLotNotOnRouteReqResult, MSG_INVALID_LOT_PROCSTAT, RC_INVALID_LOT_PROCSTAT,
                            parentLotID.identifier,
                            strLot_allState_CheckSame_out.lotProcessState);
        return( RC_INVALID_LOT_PROCSTAT );
    }

    //------------------------------------------------------
    // Check lot inventory state
    //------------------------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Check lot inventory state");

    if (CIMFWStrCmp(strLot_allState_CheckSame_out.lotInventoryState, SP_Lot_InventoryState_InBank) != 0)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_allState_CheckSame() returned lotInventoryState is not SP_Lot_InventoryState_InBank");
        PPT_SET_MSG_RC_KEY2(strMergeWaferLotNotOnRouteReqResult, MSG_INVALID_LOT_INVENTORYSTAT, RC_INVALID_LOT_INVENTORYSTAT,
                            parentLotID.identifier,
                            strLot_allState_CheckSame_out.lotProcessState);
        return( RC_INVALID_LOT_INVENTORYSTAT );
    }
    else
    {
        objLot_bank_CheckSame_out strLot_bank_CheckSame_out;
        rc = lot_bank_CheckSame(strLot_bank_CheckSame_out, strObjCommonIn,
                                parentLotID, childLotID);  //for parentLot and childLot
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_bank_CheckSame() rc != RC_OK");
            strMergeWaferLotNotOnRouteReqResult.strResult = strLot_bank_CheckSame_out.strResult ;
            return(rc);
        }
    }

//D9000056 add start
    //-----------------------------
    //  Check InPostProcessFlag
    //-----------------------------
    PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
//DSIV00000201 Add Start
    objectIdentifierSequence userGroupIDs;
    userGroupIDs.length(0);
    CORBA::ULong userGroupIDsLen = userGroupIDs.length();

//DSIV00000201 Add End

    for( CORBA::Long loopCnt = 0; loopCnt < lotIDs.length(); loopCnt++ )
    {
        //----------------------------------
        //  Get InPostProcessFlag of Lot
        //----------------------------------
        objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
        objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
        strLot_inPostProcessFlag_Get_in.lotID = lotIDs[loopCnt];

        rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                        strObjCommonIn,
                                        strLot_inPostProcessFlag_Get_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
            strMergeWaferLotNotOnRouteReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
            return( rc );
        }

        //----------------------------------------------
        //  If Lot is in post process, returns error
        //----------------------------------------------
        if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
        {
            PPT_METHODTRACE_V1("", "Lot is in post process.");
//DSIV00000201 Add Start
            if (userGroupIDsLen == 0)
            {
                /*---------------------------*/
                /* Get UserGroupID By UserID */
                /*---------------------------*/
                objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
                rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                                 strObjCommonIn,
                                                 strObjCommonIn.strUser.userID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
                    strMergeWaferLotNotOnRouteReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
                    return( rc );
                }
                userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
                userGroupIDsLen = userGroupIDs.length();
                PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);
            }
            CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
            PPT_METHODTRACE_V2("", "extPostProc", extPostProc);
            
            CORBA::ULong nCnt = 0;
            for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
            {
                PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
                if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
                {
                    PPT_METHODTRACE_V1("", "# External Post Process User!");
                    break;
                }
                
            }
            if (nCnt == userGroupIDsLen)
            {
                PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
                PPT_SET_MSG_RC_KEY( strMergeWaferLotNotOnRouteReqResult,
                                    MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                    lotIDs[loopCnt].identifier );
                return( RC_LOT_INPOSTPROCESS );
            }   //DSIV00000201

        }
    }
//D9000056 add end

//DSIV00000099 add start
    /*------------------------------------------------------------------------*/
    /*   Check if the wafers in lot don't have machine container position     */
    /*------------------------------------------------------------------------*/
    // for parentLot
    PPT_METHODTRACE_V1("", "call equipmentContainerPosition_info_GetByLotDR( parentLot )");
    objEquipmentContainerPosition_info_GetByLotDR_out strEquipmentContainerPosition_info_GetByLotDR_out_parent;
    objEquipmentContainerPosition_info_GetByLotDR_in  strEquipmentContainerPosition_info_GetByLotDR_in_parent;
    strEquipmentContainerPosition_info_GetByLotDR_in_parent.lotID = parentLotID;
    rc = equipmentContainerPosition_info_GetByLotDR( strEquipmentContainerPosition_info_GetByLotDR_out_parent,
                                                  strObjCommonIn,
                                                  strEquipmentContainerPosition_info_GetByLotDR_in_parent );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipmentContainerPosition_info_GetByLotDR() != RC_OK", rc);
        strMergeWaferLotNotOnRouteReqResult.strResult = strEquipmentContainerPosition_info_GetByLotDR_out_parent.strResult;
        return ( rc );
    }

    CORBA::Long lenEqpContPos = strEquipmentContainerPosition_info_GetByLotDR_out_parent.strEqpContainerPositionSeq.length();
    PPT_METHODTRACE_V2("", "lenEqpContPos", lenEqpContPos);
    if ( 0 < lenEqpContPos )
    {
        PPT_METHODTRACE_V1("", "Some wafers contained in this lot have equipment container positions.");
        PPT_SET_MSG_RC_KEY( strMergeWaferLotNotOnRouteReqResult,
                            MSG_WAFER_IN_LOT_HAVE_CONTAINER_POSITION, RC_WAFER_IN_LOT_HAVE_CONTAINER_POSITION,
                            parentLotID.identifier );
        return( RC_WAFER_IN_LOT_HAVE_CONTAINER_POSITION );
    }

    // for childLotID
    PPT_METHODTRACE_V1("", "call equipmentContainerPosition_info_GetByLotDR( childLot )");
    objEquipmentContainerPosition_info_GetByLotDR_out strEquipmentContainerPosition_info_GetByLotDR_out_child;
    objEquipmentContainerPosition_info_GetByLotDR_in  strEquipmentContainerPosition_info_GetByLotDR_in_child;
    strEquipmentContainerPosition_info_GetByLotDR_in_child.lotID = childLotID;
    rc = equipmentContainerPosition_info_GetByLotDR( strEquipmentContainerPosition_info_GetByLotDR_out_child,
                                                     strObjCommonIn,
                                                     strEquipmentContainerPosition_info_GetByLotDR_in_child );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipmentContainerPosition_info_GetByLotDR() != RC_OK", rc);
        strMergeWaferLotNotOnRouteReqResult.strResult = strEquipmentContainerPosition_info_GetByLotDR_out_child.strResult;
        return ( rc );
    }

    lenEqpContPos = strEquipmentContainerPosition_info_GetByLotDR_out_child.strEqpContainerPositionSeq.length();
    PPT_METHODTRACE_V2("", "lenEqpContPos", lenEqpContPos);
    if ( 0 < lenEqpContPos )
    {
        PPT_METHODTRACE_V1("", "Some wafers contained in this lot have equipment container positions.");
        PPT_SET_MSG_RC_KEY( strMergeWaferLotNotOnRouteReqResult,
                            MSG_WAFER_IN_LOT_HAVE_CONTAINER_POSITION, RC_WAFER_IN_LOT_HAVE_CONTAINER_POSITION,
                            childLotID.identifier );
        return( RC_WAFER_IN_LOT_HAVE_CONTAINER_POSITION );
    }
//DSIV00000099 add end

//Q3000147 add start
    /*----------------------------------*/
    /*   Check Lot's Control Job ID     */
    /*----------------------------------*/

    // for parentLot
    objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, parentLotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_controlJobID_Get() != RC_OK");
        strMergeWaferLotNotOnRouteReqResult.strResult = strLot_controlJobID_Get_out.strResult ;
        return(rc);
    }
    if (CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) == 0)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "CIMFWStrLen(controlJobID.identifier) = 0") ;
        rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "CIMFWStrLen(controlJobID.identifier) > 0") ;
        PPT_SET_MSG_RC_KEY2( strMergeWaferLotNotOnRouteReqResult,
                             MSG_LOT_CTLJOBID_FILLED,
                             RC_LOT_CTLJOBID_FILLED,
                             parentLotID.identifier,
                             strLot_controlJobID_Get_out.controlJobID.identifier ) ;
        return( RC_LOT_CTLJOBID_FILLED );
    }

    // for childLot
    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, childLotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_controlJobID_Get() != RC_OK");
        strMergeWaferLotNotOnRouteReqResult.strResult = strLot_controlJobID_Get_out.strResult ;
        return(rc);
    }
    if (CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) == 0)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "CIMFWStrLen(controlJobID.identifier) = 0") ;
        rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "CIMFWStrLen(controlJobID.identifier) > 0") ;
        PPT_SET_MSG_RC_KEY2( strMergeWaferLotNotOnRouteReqResult,
                             MSG_LOT_CTLJOBID_FILLED,
                             RC_LOT_CTLJOBID_FILLED,
                             childLotID.identifier,
                             strLot_controlJobID_Get_out.controlJobID.identifier ) ;
        return( RC_LOT_CTLJOBID_FILLED );
    }
//Q3000147 add end

    objCassette_transferState_Get_out strCassette_transferState_Get_out;  //DSN000071674

    if (CIMFWStrLen(aParentCassetteID.identifier) != 0)
    {
//DSN000071674 add start
        if ( 1 == lotOperationEIcheck )
        {
            PPT_METHODTRACE_V1("", "lotOperationEIcheck = 1");
//DSN000071674 add end
            //-------------------------
            // Check carrier dispatch status
            //-------------------------
            PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Check carrier dispatch status");

            objCassette_dispatchState_Get_out strCassette_dispatchState_Get_out;
            strCassette_dispatchState_Get_out.dispatchReservedFlag = FALSE; //P3000280
            rc = cassette_dispatchState_Get(strCassette_dispatchState_Get_out, strObjCommonIn,
                                            aParentCassetteID);  // for parent cassette
            if (strCassette_dispatchState_Get_out.dispatchReservedFlag == TRUE)
            {
                PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "cassette_dispatchState_Get(aParentCassetteID) parent cassette is reserved");
                SET_MSG_RC(strMergeWaferLotNotOnRouteReqResult, MSG_ALREADY_DISPATCH_RESVED_CST, RC_ALREADY_DISPATCH_RESVED_CST);
                return( RC_NOT_RESERVED_CST );
            }
        } //DSN000071674

//DSN000071674 add start
//INN-R170003 if ( 1 == lotOperationEIcheck|| ( 0 == lotOperationEIcheck && (0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) 
//INN-R170003 add start
        if ( 1 == lotOperationEIcheck
        || ( 0 == lotOperationEIcheck && 
           (0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) &&
            0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentOut) &&
            0 != CIMFWStrCmp(strCassetteTransferState.transferState, CS_TRANS_STATE_PORT_IN ) ) ) )
//INN-R170003 add end
        {
//DSN000071674 add end
            //-------------------------
            // Check carrier transfer status
            //-------------------------
            PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Check carrier transfer status");

//DSN000071674            objCassette_transferState_Get_out strCassette_transferState_Get_out;
            rc = cassette_transferState_Get(strCassette_transferState_Get_out, strObjCommonIn,
                                            aParentCassetteID);  // for parent cassette
//P4000037        if (CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_BayOut    ) == 0 ||
//P4000037            CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0)
//P4000037        {
//P4000037            PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "cassette_transferState_Get(aParentCassetteID) xfer status of cassette is SP_TransState_BayOut || SP_TransState_EquipmentIn");
//P4000037            PPT_SET_MSG_RC_KEY2(strMergeWaferLotNotOnRouteReqResult, MSG_INVALID_CAST_XFERSTAT, RC_INVALID_CAST_XFERSTAT,
//P4000037                                strCassette_transferState_Get_out.transferState,
//P4000037                                aParentCassetteID.identifier);
//P4000037            return( RC_INVALID_CAST_XFERSTAT );
//P4000037        }

//P4000037 add start
            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "rc != RC_OK");
                strMergeWaferLotNotOnRouteReqResult.strResult = strCassette_transferState_Get_out.strResult ;
                return(rc);
            }

//DSN000071674 add start
            if ( 0 == lotOperationEIcheck )
            {
                PPT_METHODTRACE_V1("", "lotOperationEIcheck = 0");
//INN-R170003 if ( 0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn ) )
//INN-R170003 add start
                if ( 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) ||
                     0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentOut ) || 
                     0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, CS_TRANS_STATE_PORT_IN ) )
//INN-R170003 add end                                                      //D4100091
                {
                    PPT_METHODTRACE_V1("","Changed to EI by other operation");
                    strMergeWaferLotNotOnRouteReqResult.strResult = strCassette_transferState_Get_out.strResult ;
                    PPT_SET_MSG_RC_KEY(strMergeWaferLotNotOnRouteReqResult, MSG_CHANGED_TO_EI_BY_OTHER_OPERATION, RC_CHANGED_TO_EI_BY_OTHER_OPERATION,
                                       aParentCassetteID.identifier);
//INN-R170003 return( RC_CHANGED_TO_EI_BY_OTHER_OPERATION );
//INN-R170003 add start
                    return( CS_RC_CAST_XFERSTATE_BE_CHANGED_BY_OTHER_OPERATION );
//INN-R170003 add end
                }
            }
//DSN000071674 add end
//P4000079        else if(!(CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_EquipmentOut)    == 0  ||
//P4000079                  CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_ManualOut)       == 0  ||
//P4000079                  CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_IntermediateOut) == 0  ||
//P4000079                  CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_ShelfOut)        == 0  ||
//P4000079                  CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_UNDEFINED_STATE)            == 0  ||
//P4000079                  CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_AbnormalOut)     == 0  ||
//P4000079                  CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_StationOut)      == 0) )
//INN-R170003 else if (CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_BayOut    ) == 0 ||CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0)    
//INN-R170003 add start
            else if (CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_BayOut    ) == 0 ||
                     CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 ||
                     CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentOut) == 0 ||
                     CIMFWStrCmp(strCassette_transferState_Get_out.transferState, CS_TRANS_STATE_PORT_IN) == 0 )
//INN-R170003 add end          //P4000079
            {
                PPT_METHODTRACE_V1("","XferState is invalid...");
                strMergeWaferLotNotOnRouteReqResult.strResult = strCassette_transferState_Get_out.strResult ;
                PPT_SET_MSG_RC_KEY2(strMergeWaferLotNotOnRouteReqResult, MSG_INVALID_CAST_XFERSTAT, RC_INVALID_CAST_XFERSTAT,
                                    strCassette_transferState_Get_out.transferState,
                                    aParentCassetteID.identifier);
                return( RC_INVALID_CAST_XFERSTAT );
            }
//DSN000071674 add start
        }
        if ( 0 == lotOperationEIcheck )
        {
            PPT_METHODTRACE_V1("", "lotOperationEIcheck = 0") ;
            strCassette_transferState_Get_out = strCassetteTransferState;
//INN-R170003 add start if ( 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn))
//INN-R170003 add start 
            if ( 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) ||
                 0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentOut ) || 
                 0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, CS_TRANS_STATE_PORT_IN ) )
//INN-R170003 add end
            {
                /*------------------------------------*/
                /*   Get Equipment Port Info          */
                /*------------------------------------*/                PPT_METHODTRACE_V1("PPTManager_i::cs_txMergeWaferLotNotOnRouteReq", "strCassette_transferState_Get_out.transferState == EO/PI");
                objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
                rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                             strObjCommonIn,
                                             strCassette_equipmentID_Get_out.equipmentID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2( "", "equipment_portInfo_Get != RC_OK", rc);
                    strMergeWaferLotNotOnRouteReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
                    return( rc );
                }

                CORBA::ULong portLen = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
                for ( CORBA::ULong portNum = 0; portNum < portLen; portNum++ )
                {
                    PPT_METHODTRACE_V2("", "portNum", portNum);
                    if ( 0 == CIMFWStrCmp( aParentCassetteID.identifier, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portNum].loadedCassetteID.identifier) )
                    {
                        PPT_METHODTRACE_V1("", "parentCassetteID == loadedCassetteID");
                        break;
                    }
                }

                //-----------------------------------------------------------------
                // Check parent lot and child lot is same operationStartFlag or not
                //-----------------------------------------------------------------
                CORBA::Boolean bParentLotOpeStartFlg = FALSE;
                CORBA::Boolean bChildLotOpeStartFlg  = FALSE;

                if (portNum < portLen)
                {
                    PPT_METHODTRACE_V1("", "portNum < portLen");
                    CORBA::ULong lotLen = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portNum].strLotOnPort.length();
                    for ( CORBA::ULong lotNum = 0; lotNum < lotLen; lotNum++ )
                    {
                        PPT_METHODTRACE_V2("", "lotNum", lotNum);
                        const pptLotOnPort& strLotOnPort = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[portNum].strLotOnPort[lotNum];
                        if ( 0 == CIMFWStrCmp( parentLotID.identifier, strLotOnPort.lotID.identifier) )
                        {
                            PPT_METHODTRACE_V1("", "parentLotID == lotID");
                            bParentLotOpeStartFlg = strLotOnPort.operationStartFlag;
                        }
                        else if ( 0 == CIMFWStrCmp( childLotID.identifier, strLotOnPort.lotID.identifier) )
                        {
                            PPT_METHODTRACE_V1("", "childLotID == lotID");
                            bChildLotOpeStartFlg = strLotOnPort.operationStartFlag;
                        }
                    }
                }
                if ( bParentLotOpeStartFlg != bChildLotOpeStartFlg )
                {
                    PPT_METHODTRACE_V1("", "bParentLotOpeStartFlg != bChildLotOpeStartFlg");
                    PPT_SET_MSG_RC_KEY3( strMergeWaferLotNotOnRouteReqResult,
                                         MSG_ATTRIBUTE_DIFFERENT_FOR_MERGE,
                                         RC_ATTRIBUTE_DIFFERENT_FOR_MERGE,
                                         "operationStartFlag",
                                         (bParentLotOpeStartFlg?"True":"False"),
                                         (bChildLotOpeStartFlg?"True":"False") );
                    return( RC_ATTRIBUTE_DIFFERENT_FOR_MERGE );
                }
            }
        }
//DSN000071674 add end
//P4000037 add end

    }

    if (CIMFWStrLen(aChildCassetteID.identifier) != 0)
    {
//DSN000071674 add start
        if ( 1 == lotOperationEIcheck )
        {
            PPT_METHODTRACE_V1("", "lotOperationEIcheck = 1") ;
//DSN000071674 add end
        //-------------------------
        // Check carrier dispatch status
        //-------------------------
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Check carrier dispatch status");

        objCassette_dispatchState_Get_out strCassette_dispatchState_Get_out;
        strCassette_dispatchState_Get_out.dispatchReservedFlag = FALSE; //P3000280
        rc = cassette_dispatchState_Get(strCassette_dispatchState_Get_out, strObjCommonIn,
                                        aChildCassetteID);  // for child cassette
        if (strCassette_dispatchState_Get_out.dispatchReservedFlag == TRUE)
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "cassette_dispatchState_Get(aChildCassetteID) child cassette is reserved");
            SET_MSG_RC(strMergeWaferLotNotOnRouteReqResult, MSG_ALREADY_DISPATCH_RESVED_CST, RC_ALREADY_DISPATCH_RESVED_CST);
            return( RC_NOT_RESERVED_CST );
        }

        //-------------------------
        // Check carrier transfer status
        //-------------------------
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Check carrier transfer status");

        objCassette_transferState_Get_out strCassette_transferState_Get_out;
        rc = cassette_transferState_Get(strCassette_transferState_Get_out, strObjCommonIn,
                                        aChildCassetteID);  // for child cassette
//INN-R170003 add start  if (CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_BayOut    ) == 0 ||CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 )
//INN-R170003 add start                                        
        if (CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_BayOut    ) == 0 ||
            CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 ||
            CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentOut) == 0 ||
            CIMFWStrCmp(strCassette_transferState_Get_out.transferState, CS_TRANS_STATE_PORT_IN) == 0 )
//INN-R170003 add end
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "cassette_transferState_Get(aChildCassetteID) xfer status of cassette is SP_TransState_BayOut || SP_TransState_EquipmentIn");
            PPT_SET_MSG_RC_KEY2(strMergeWaferLotNotOnRouteReqResult, MSG_INVALID_CAST_XFERSTAT, RC_INVALID_CAST_XFERSTAT,
                                strCassette_transferState_Get_out.transferState,
                                aChildCassetteID.identifier);
            return( RC_INVALID_CAST_XFERSTAT );
            }
        } //DSN000071674
    }

    //-------------------------
    // Check allocated quantities for parent lot
    //-------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Check allocated quantities for parent lot");

//DSN000104277//DSN000085698    objLot_wafers_GetDR_out strLot_wafers_GetDR_out;
//DSN000104277    objLot_wafers_GetDR_out__150 strLot_wafers_GetDR_out;   //DSN000085698
//DSN000104277    objLot_wafers_GetDR_in  strInParm;
//DSN000104277    strInParm.lotID          = parentLotID;
//DSN000104277    strInParm.scrapCheckFlag = TRUE;
//DSN000104277//DSN000085698    rc = lot_wafers_GetDR(strLot_wafers_GetDR_out, strObjCommonIn,
//DSN000104277    rc = lot_wafers_GetDR__150(strLot_wafers_GetDR_out, strObjCommonIn,     //DSN000085698
//DSN000104277                          strInParm);
//DSN000104277 add start
    objLot_waferInfoList_GetDR_out strLot_waferInfoList_GetDR_out;
    objLot_waferInfoList_GetDR_in  strLot_waferInfoList_GetDR_in;
    strLot_waferInfoList_GetDR_in.lotID          = parentLotID;
    strLot_waferInfoList_GetDR_in.scrapCheckFlag = TRUE;
    rc = lot_waferInfoList_GetDR( strLot_waferInfoList_GetDR_out, strObjCommonIn, strLot_waferInfoList_GetDR_in );
//DSN000104277 add end

    CORBA::Long i = 0;
//DSN000104277    CORBA::Long nLen = strLot_wafers_GetDR_out.strLotWaferAttributes.length();
    CORBA::Long nLen = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes.length(); //DSN000104277
    CORBA::Boolean bSTBAllocatedFlag = FALSE;
    objectIdentifier aWaferID;
    PPT_METHODTRACE_V2("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "nLen = ", nLen);
    for (i=0; i<nLen; i++)
    {
//DSN000104277        if (strLot_wafers_GetDR_out.strLotWaferAttributes[i].STBAllocFlag == TRUE)
        if (strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[i].STBAllocFlag == TRUE) //DSN000104277
        {
            bSTBAllocatedFlag = TRUE;
//DSN000104277            aWaferID = strLot_wafers_GetDR_out.strLotWaferAttributes[i].waferID;
            aWaferID = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[i].waferID; //DSN000104277
            break;
        }
    }

    if (bSTBAllocatedFlag == TRUE)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_wafers_GetDR(parentLotID) one of returned wafer's STBAllocatedFlag is TRUE");
        PPT_SET_MSG_RC_KEY(strMergeWaferLotNotOnRouteReqResult, MSG_WAFER_ALLOCATED, RC_WAFER_ALLOCATED,
                           aWaferID.identifier);
        return( RC_WAFER_ALLOCATED );
    }

//D9000038 Add Start

    //--------------------------------
    // Check hasWafer for parent lot  //D9000038
    //--------------------------------

//DSN000104277    if ( CIMFWStrLen ( strLot_wafers_GetDR_out.strLotWaferAttributes[0].waferID.identifier ) == 0 )
    if ( CIMFWStrLen ( strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[0].waferID.identifier ) == 0 ) //DSN000104277
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "bParentLotHasWaferID = FALSE");
        bParentLotHasWaferID = FALSE;
    }
    else
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "bParentLotHasWaferID = TRUE");
    }
//D9000038 Add End


    //-------------------------
    // Check allocated quantities for child lot
    //-------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Check allocated quantities for child lot");

//DSN000104277    strInParm.lotID          = childLotID;
//DSN000104277    strInParm.scrapCheckFlag = TRUE;
//DSN000104277//DSN000085698    rc = lot_wafers_GetDR(strLot_wafers_GetDR_out, strObjCommonIn,
//DSN000104277    rc = lot_wafers_GetDR__150(strLot_wafers_GetDR_out, strObjCommonIn,     //DSN000085698
//DSN000104277                          strInParm);
//DSN000104277    nLen = strLot_wafers_GetDR_out.strLotWaferAttributes.length();
//DSN000104277 add start
    strLot_waferInfoList_GetDR_in.lotID          = childLotID;
    strLot_waferInfoList_GetDR_in.scrapCheckFlag = TRUE;
    rc = lot_waferInfoList_GetDR( strLot_waferInfoList_GetDR_out, strObjCommonIn, strLot_waferInfoList_GetDR_in );
    nLen = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes.length();
//DSN000104277 add end
    bSTBAllocatedFlag = FALSE;
    PPT_METHODTRACE_V2("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "nLen = ", nLen);
    for (i=0; i<nLen; i++)
    {
//DSN000104277        if (strLot_wafers_GetDR_out.strLotWaferAttributes[i].STBAllocFlag == TRUE)
        if (strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[i].STBAllocFlag == TRUE) //DSN000104277
        {
            bSTBAllocatedFlag = TRUE;
//DSN000104277            aWaferID = strLot_wafers_GetDR_out.strLotWaferAttributes[i].waferID;
            aWaferID = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[i].waferID; //DSN000104277
            break;
        }
    }
    if (bSTBAllocatedFlag == TRUE)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_wafers_GetDR(childLotID) one of returned wafer's STBAllocatedFlag is TRUE");
        PPT_SET_MSG_RC_KEY(strMergeWaferLotNotOnRouteReqResult, MSG_WAFER_ALLOCATED, RC_WAFER_ALLOCATED,
                           aWaferID.identifier);
        return( RC_WAFER_ALLOCATED );
    }

//D9000038 Add Start

    //--------------------------------
    // Check hasWafer for child lot  //D9000038
    //--------------------------------

//DSN000104277    if ( CIMFWStrLen ( strLot_wafers_GetDR_out.strLotWaferAttributes[0].waferID.identifier ) == 0 )
    if ( CIMFWStrLen ( strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[0].waferID.identifier ) == 0 ) //DSN000104277
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "bChildLotHasWaferID = FALSE");
        bChildLotHasWaferID = FALSE;
    }
    else
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "bParentLotHasWaferID = TRUE");
    }

    //----------------------------------------------------------------------------------------
    // Check whether both ChildLot and ParentLot are in the cassette or not in the cassette.  //D9000038
    //----------------------------------------------------------------------------------------

    if ( bParentLotHasWaferID == TRUE && bChildLotHasWaferID == TRUE )
    {
        PPT_METHODTRACE_V1 ( "PPTManager_i:: txMergeWaferLotNotOnRouteReq",
                             "Both ParentLot and ChildLot are in the cassette. bHasWaferID = TRUE");
    }
    else if ( bParentLotHasWaferID == FALSE && bChildLotHasWaferID == FALSE )
    {
        PPT_METHODTRACE_V1 ( "PPTManager_i:: txMergeWaferLotNotOnRouteReq",
                             "Both ParentLot and ChildLot are not in the cassette. bHasWaferID = FALSE");

        bHasWaferID = FALSE;
    }
    else
    {
        PPT_METHODTRACE_V1 ( "PPTManager_i:: txMergeWaferLotNotOnRouteReq",
                             "Either ParentLot or ChildLot is not in the cassette and another lot is in the cassette.");

        SET_MSG_RC( strMergeWaferLotNotOnRouteReqResult,
                    MSG_MEARGE_LOT_IN_AND_NOT_IN_CAST,
                    RC_MEARGE_LOT_IN_AND_NOT_IN_CAST )

        return RC_MEARGE_LOT_IN_AND_NOT_IN_CAST;
    }
//D9000038 Add End

    //---------------------------------
    // Get Parent Lot's Route ID (Main PD ID)
    //---------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Get Parent Lot's Route ID (Main PD ID)");

    objLot_routeID_Get_out strLot_routeID_Get_out;
    rc = lot_routeID_Get(strLot_routeID_Get_out, strObjCommonIn,
                         parentLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_routeID_Get(parentLotID) rc != RC_OK");
        strMergeWaferLotNotOnRouteReqResult.strResult = strLot_routeID_Get_out.strResult ;
        return(rc);
    }
    else if (CIMFWStrLen(strLot_routeID_Get_out.routeID.identifier) != 0)
    {
//        -----------------------------------------------------------------------------
//          -- New Message --
//          MSG_LOT_ONROUTE "Lot is on a %s Route process flow."
//        -----------------------------------------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_routeID_Get(parentLotID) lot is on route");
        SET_MSG_RC(strMergeWaferLotNotOnRouteReqResult, MSG_LOT_ONROUTE, RC_LOT_ONROUTE);
        return( RC_LOT_ONROUTE );
    }

    //---------------------------------
    // Get Child Lot's Route ID (Main PD ID)
    //---------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Get Child Lot's Route ID (Main PD ID)");

    rc = lot_routeID_Get(strLot_routeID_Get_out, strObjCommonIn,
                         childLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_routeID_Get(childLotID) rc != RC_OK");
        strMergeWaferLotNotOnRouteReqResult.strResult = strLot_routeID_Get_out.strResult ;
        return(rc);
    }
    else if (CIMFWStrLen(strLot_routeID_Get_out.routeID.identifier) != 0)
    {
//        -----------------------------------------------------------------------------
//          -- New Message --
//          MSG_LOT_ONROUTE "Lot is on a %s Route process flow."
//        -----------------------------------------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_routeID_Get(childLotID) lot is on route");
        SET_MSG_RC(strMergeWaferLotNotOnRouteReqResult, MSG_LOT_ONROUTE, RC_LOT_ONROUTE);
        return( RC_LOT_ONROUTE );
    }

    //--------------------------------------------------------
    // Check input parent lot and child lot is family or not.
    //--------------------------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Check input parent lot and child lot is family or not.");

    objLot_family_CheckMerge_out strLot_family_CheckMerge_out;
    rc = lot_family_CheckMerge(strLot_family_CheckMerge_out, strObjCommonIn,
                               parentLotID, childLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_family_CheckMerge() rc != RC_OK");
        strMergeWaferLotNotOnRouteReqResult.strResult = strLot_family_CheckMerge_out.strResult ;
        return(rc);
    }

//TEMPORARY COMMENT    if(child cassette is filled)
//TEMPORARY COMMENT    {
//TEMPORARY COMMENT        rc = lot_materials_GetWafers();  //for childLot
//TEMPORARY COMMENT        if (rc)
//TEMPORARY COMMENT        {
//TEMPORARY COMMENT           set returned strResult to strResult of out parameter
//TEMPORARY COMMENT           return(rc);
//TEMPORARY COMMENT        }
//TEMPORARY COMMENT        Keep got wafer information for later making history
//TEMPORARY COMMENT    }

    objLotWaferMoveEvent_MakeMerge_out strLotWaferMoveEvent_MakeMerge_out; //DCR4000125

//P3100069 add start
//D9000038    if(CIMFWStrLen(aParentCassetteID.identifier) > 0 &&
//D9000038       CIMFWStrLen( aChildCassetteID.identifier) > 0)            //P4000033
//D9000038    {

        //------------------------------------------------------------------------
        //   Create History Event before child lot's wafer become parent lot's wafer
        //------------------------------------------------------------------------

//D9000038 add start
    if ( bHasWaferID )
    {
//D9000038 add end
        PPT_METHODTRACE_V1("", "Create History Event before child lot's wafer become parent lot's wafer");

        //DCR4000125 objLotWaferMoveEvent_MakeMerge_out strLotWaferMoveEvent_MakeMerge_out;
        //DCR4000125 rc = lotWaferMoveEvent_MakeMerge( strLotWaferMoveEvent_MakeMerge_out, strObjCommonIn,
        //DCR4000125                                   "TXTRC049", childLotID, parentLotID, claimMemo );
        rc = lotWaferMoveEvent_MakeMerge( strLotWaferMoveEvent_MakeMerge_out, strObjCommonIn,
                                          strObjCommonIn.transactionID, childLotID, parentLotID );

        if (rc)
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "lotWaferMoveEvent_MakeMerge() rc != RC_OK");
            strMergeWaferLotNotOnRouteReqResult.strResult = strLotWaferMoveEvent_MakeMerge_out.strResult;
            return(rc);
        }
    }                                                             //P4000033
//P3100069 add end

    //--------------------
    //   Change State
    //--------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Change State");

    objLot_MergeWaferLotNotOnRoute_out strLot_MergeWaferLotNotOnRoute_out;
    rc = lot_MergeWaferLotNotOnRoute(strLot_MergeWaferLotNotOnRoute_out, strObjCommonIn,
                                     parentLotID, childLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "lot_MergeWaferLotNotOnRoute() rc != RC_OK");
        strMergeWaferLotNotOnRouteReqResult.strResult = strLot_MergeWaferLotNotOnRoute_out.strResult ;
        return(rc);
    }

    if(CIMFWStrLen(aParentCassetteID.identifier) > 0 &&
       CIMFWStrLen( aChildCassetteID.identifier) > 0)            //P4000033
    {
//DSN000071674 add start
        if ( TRUE == updateControlJobFlag )
        {
            //----------------------
            // Update control Job Info and
            // Machine Cassette info if information exist
            //----------------------
            objectIdentifierSequence tmpCassetteIDSeq;
            tmpCassetteIDSeq.length(1);
            tmpCassetteIDSeq[0] = aParentCassetteID;
            objControlJob_relatedInfo_Update_out strControlJob_relatedInfo_Update_out;
            rc = controlJob_relatedInfo_Update(strControlJob_relatedInfo_Update_out, strObjCommonIn,
                                               tmpCassetteIDSeq);
            if (rc)
            {
                PPT_METHODTRACE_V2("", "controlJob_relatedInfo_Update() != RC_OK", rc);
                strMergeWaferLotNotOnRouteReqResult.strResult = strControlJob_relatedInfo_Update_out.strResult;
                return(rc);
            }
        }
//DSN000071674 add end

        /*---------------------------------------*/
        /*   Update Cassette's MultiLotType      */
        /*---------------------------------------*/

        PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "Update Cassette's MultiLotType");
        objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
        rc = cassette_multiLotType_Update(strCassette_multiLotType_Update_out, strObjCommonIn,
                                          aParentCassetteID);
        if (rc)
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotNotOnRouteReq", "cassette_multiLotType_Update() rc != RC_OK");
            strMergeWaferLotNotOnRouteReqResult.strResult = strCassette_multiLotType_Update_out.strResult ;
            return(rc);
        }
    }                                                            //P4000033
    //TEMPORARY COMMENT //-------------------
    //TEMPORARY COMMENT //   Make History
    //TEMPORARY COMMENT //-------------------
    //TEMPORARY COMMENT rc = lotWaferMoveEvent_MakeMerge()
    //TEMPORARY COMMENT    // transactionID          = "TXTRC049"
    //TEMPORARY COMMENT    // sourceLotID            = childLotID ;
    //TEMPORARY COMMENT    // sourceCassetteID       = childCassetteID ;
    //TEMPORARY COMMENT    // destinationLotID       = parentLotID;
    //TEMPORARY COMMENT    // destinationCassetteID  = cassetteID;
    //TEMPORARY COMMENT    // strMoveWaferAttributes = strLot_materials_GetWafers_out.strLotWaferAttributes
    //TEMPORARY COMMENT if (rc)
    //TEMPORARY COMMENT {
    //TEMPORARY COMMENT    set returned strResult to strResult of out parameter
    //TEMPORARY COMMENT    set MSG_FAIL_MAKE_HISTORY to message in strResult of out parameter
    //TEMPORARY COMMENT    return(rc);
    //TEMPORARY COMMENT }

    //DCR4000125 Start
//D9000038    if(CIMFWStrLen(aParentCassetteID.identifier) > 0 &&
//D9000038       CIMFWStrLen( aChildCassetteID.identifier) > 0)
//D9000038    {

//D9000038 add start
    if ( bHasWaferID )
    {
//D9000038 add end
        objLotWaferMoveEvent_Make_out strLotWaferMoveEvent_Make_out;

        rc = lotWaferMoveEvent_Make( strLotWaferMoveEvent_Make_out,
                                     strObjCommonIn,
                                     strObjCommonIn.transactionID,
                                     strLotWaferMoveEvent_MakeMerge_out.strNewLotAttributes,
                                     claimMemo );

        if(rc)
        {
            PPT_METHODTRACE_V1( "", "lotWaferMoveEvent_Make() rc != RC_OK" );
            strMergeWaferLotNotOnRouteReqResult.strResult = strLotWaferMoveEvent_Make_out.strResult ;
            return rc;
        }
    }
    //DCR4000125 End

    //---------------
    //   Return
    //---------------
    SET_MSG_RC( strMergeWaferLotNotOnRouteReqResult, MSG_OK, RC_OK );

    PPT_METHODTRACE_EXIT("PPTManager_i:: txMergeWaferLotNotOnRouteReq");
    return(RC_OK);

}
