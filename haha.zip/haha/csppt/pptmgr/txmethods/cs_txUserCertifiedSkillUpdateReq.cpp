// (c) Copyright: IBM  Company Ltd, 2017, 2027. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017, 2027. All rights reserved.
//
// SiView
// Name: cs_txUserCertifiedSkillUpdateReq.cpp
//
// Modeficaiton History:
// Date       Defect           Name             Description
// ---------- -------- ---------------- ----------------------------------------------
// 2017/09/04 INN-R170008      Menghua Yin      TA Certify

// Class: PPTServiceManager
//
// Service: cs_txUserCertifiedSkillUpdateReq()

// Description:
//<Method Summary>

//</Method Summary>

// Return:
//     long
//
// Parameter:
//
//     csUserCertifiedSkillUpdateReqResult&          strUserCertifiedSkillUpdateReqResult
//     const pptObjCommonIn&                         strObjCommonIn
//     const csUserCertifiedSkillUpdateReqInParm&    strUserCertifiedSkillUpdateReqInParm

//<Method Start>
#include "cs_pptmgr.hpp"

CORBA::Long CS_PPTManager_i::cs_txUserCertifiedSkillUpdateReq(
    csUserCertifiedSkillUpdateReqResult&          strUserCertifiedSkillUpdateReqResult,
    const pptObjCommonIn&                         strObjCommonIn,
    const csUserCertifiedSkillUpdateReqInParm&    strUserCertifiedSkillUpdateReqInParm CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("PPTManager_i::cs_txUserCertifiedSkillUpdateReq");
    CORBA::Long rc = RC_OK;

    //----------------------------------------------------------------
    //
    //  Pre Process
    //
    //----------------------------------------------------------------
    // check date format and user_id
    CORBA::Long nLen = strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq.length();

    // SetDr struct define
    csObjPerson_SkillList_SetDR_out strObjPerson_SkillList_SetDR_out;
    csObjPerson_SkillList_SetDR_in strObjPerson_SkillList_SetDR_in;

    // AddDr struct define
    csObjPerson_SkillList_AddDR_out strObjPerson_SkillList_AddDR_out;
    csObjPerson_SkillList_AddDR_in strObjPerson_SkillList_AddDR_in;

    CORBA::Long updateIndex = 0;
    CORBA::Long addIndex = 0;
    CORBA::Long i = 0;
    
    for (i = 0; i < nLen; i++)
    {   
        //---------------------------------------------
        // User ID existence check
        //---------------------------------------------
        objPerson_existence_Check_out strPerson_existence_Check_out;
        objPerson_existence_Check_in strPerson_existence_Check_in;
        strPerson_existence_Check_in.userID = strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].userID;
     
        rc = person_existence_Check( strPerson_existence_Check_out,
                                     strObjCommonIn,
                                     strPerson_existence_Check_in );

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("PPTServiceManager_i:: cs_txUserCertifiedSkillUpdateReq", "rc != RC_OK");
            strUserCertifiedSkillUpdateReqResult.strResult = strPerson_existence_Check_out.strResult;
            return rc;
        }
        
        //----------------------------------
        //  Get List of Code information
        //----------------------------------
        PPT_METHODTRACE_V1("", "Call code_ListGetDR");
        objCode_ListGetDR_out strCode_ListGetDR_out;
        objCode_ListGetDR_in  strCode_ListGetDR_in;
        objectIdentifier strobjectIdentifiercategory;
        strobjectIdentifiercategory.identifier = CS_USER_DEFINED_CATEGORY_SKILL;
        strCode_ListGetDR_in.category = strobjectIdentifiercategory;

        rc = code_ListGetDR( strCode_ListGetDR_out,
                             strObjCommonIn,
                             strCode_ListGetDR_in );

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "cs_txUserCertifiedSkillUpdateReq() != RC_OK");
            strUserCertifiedSkillUpdateReqResult.strResult = strCode_ListGetDR_out.strResult;
            return (rc);
        }
        
        // loop the skillinfo
        PPT_METHODTRACE_V1("", "enter for loop");
        CORBA::Long nSkillInfoLen = strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].strSkillInfo.length();
        PPT_METHODTRACE_V2("", "nSkillInfoLen", nSkillInfoLen)
        CORBA::Long j = 0;
        for (j = 0; j < nSkillInfoLen; j++)
        {
            CORBA::Boolean findFlag = FALSE;
            // loop the code_List
            PPT_METHODTRACE_V2("", "strCode_ListGetDR_out.strCodeInfoList.length()", strCode_ListGetDR_out.strCodeInfoList.length())
            CORBA::Long k = 0;
            for (k = 0; k < strCode_ListGetDR_out.strCodeInfoList.length(); k++)
            {
                objectIdentifier code = strCode_ListGetDR_out.strCodeInfoList[k].code;
                PPT_METHODTRACE_V2("", "code", code.identifier)
                PPT_METHODTRACE_V2("", "strSkillInfo[j].skillID", strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].strSkillInfo[j].skillID)
                if (CIMFWStrCmp(strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].strSkillInfo[j].skillID, code.identifier) == 0)
                {
                    // Found skill in strCodeInfoList
                    PPT_METHODTRACE_V1("","Found skill in strCodeInfoList")
                    findFlag = TRUE;
                    break;
                }
            }
            
            if (findFlag == FALSE)
            {
                PPT_METHODTRACE_V1("PPTManager_i:: cs_txUserCertifiedSkillUpdateReq ", "rc == RC_NOT_FOUND_CODE")
                CS_PPT_SET_MSG_RC_KEY1( strUserCertifiedSkillUpdateReqResult,
                                        MSG_NOT_FOUND_CODE,
                                        RC_NOT_FOUND_CODE,
                                        strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].strSkillInfo[j].skillID);
                return RC_NOT_FOUND_CODE;
            }

            // check the certify date format
            CORBA::String_var certifiedDate = CIMFWStrDup(strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].strSkillInfo[j].certifiedDate);
            char cMouth[3] = { 0 };
            char cDays[3] = { 0 };
            CORBA::Long nLen = CIMFWStrLen(certifiedDate);

            char *pos = strchr(certifiedDate, '-');
            if (pos == NULL||(pos - certifiedDate) != 4)
            {
                PPT_METHODTRACE_V1("PPTManager_i:: cs_txUserCertifiedSkillUpdateReq ", "rc == CS_RC_INVALID_FORMAT")
                CS_PPT_SET_MSG_RC_KEY2( strUserCertifiedSkillUpdateReqResult,
                                        CS_MSG_INVALID_FORMAT,
                                        CS_RC_INVALID_FORMAT,
                                        "yyyy-mm-dd",
                                        certifiedDate );
                return CS_RC_INVALID_FORMAT;
            }

            char *pos1 = strchr(pos + 1, '-');
            if (pos1 == NULL || (pos1 - pos) > 3)
            {
                PPT_METHODTRACE_V1("PPTManager_i:: cs_txUserCertifiedSkillUpdateReq ", "rc == CS_RC_INVALID_FORMAT")
                CS_PPT_SET_MSG_RC_KEY2( strUserCertifiedSkillUpdateReqResult,
                                        CS_MSG_INVALID_FORMAT,
                                        CS_RC_INVALID_FORMAT,
                                        "yyyy-mm-dd",
                                        certifiedDate );
                return CS_RC_INVALID_FORMAT;
            }

            if ((pos1 - pos) == 2)
            {
                CIMFWStrnCpy(cMouth, certifiedDate + 5, 1);
                cMouth[1] = '\0';
                CIMFWStrnCpy(cDays, certifiedDate + 7, nLen - 7);
                cDays[nLen - 1] = '\0';
            }
            else if ((pos1 - pos) == 3)
            {
                CIMFWStrnCpy(cMouth, certifiedDate + 5, 2);
                cMouth[2] = '\0';
                CIMFWStrnCpy(cDays, certifiedDate + 8, nLen - 8);
                cDays[nLen - 1] = '\0';
            }

            CORBA::Long lCertifiedMouth = atoi(cMouth);
            CORBA::Long lCertifiedDay = atoi(cDays);

            if (lCertifiedMouth > 12 || lCertifiedDay > 31)
            {  
                PPT_METHODTRACE_V1("PPTManager_i:: cs_txUserCertifiedSkillUpdateReq ", "rc == CS_RC_INVALID_FORMAT")
                CS_PPT_SET_MSG_RC_KEY2( strUserCertifiedSkillUpdateReqResult,
                                        CS_MSG_INVALID_FORMAT,
                                        CS_RC_INVALID_FORMAT,
                                        "yyyy-mm-dd",
                                        certifiedDate );
                return CS_RC_INVALID_FORMAT;
            }
        }
        
        PPT_METHODTRACE_V1("", "exit for loop");
        PPT_METHODTRACE_V2("", "strUserSkillInfoSeq[i].userID",strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].userID.identifier);
        // query record by calling cs_person_SkillList_GetDR
        csObjPerson_SkillList_GetDR_out strObjPerson_SkillList_GetDR_out;
        csObjPerson_SkillList_GetDR_in strObjPerson_SkillList_GetDR_in;

        strObjPerson_SkillList_GetDR_in.userID = strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].userID;
        PPT_METHODTRACE_V2("", "strObjPerson_SkillList_GetDR_in.userID",strObjPerson_SkillList_GetDR_in.userID.identifier);
        
        rc = cs_person_SkillList_GetDR( strObjPerson_SkillList_GetDR_out,
                                        strObjCommonIn,
                                        strObjPerson_SkillList_GetDR_in );

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V2("", "cs_person_SkillList_GetDR() rc != RC_OK. ", rc);
            strUserCertifiedSkillUpdateReqResult.strResult = strObjPerson_SkillList_GetDR_out.strResult;
            return(rc);
        }
        
        // if found recode then call cs_person_SkillList_SetDR to Update
        // otherwise call cs_person_SkillList_AddDR to Add
        CORBA::Long nSkillOutCnt = strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo.length();
        
        PPT_METHODTRACE_V2("", "nSkillOutCnt", nSkillOutCnt);
        /*
        if (nSkillOutCnt >= 1)
        {
            // Update

            // add the Updatedata to Sequence
            strObjPerson_SkillList_SetDR_in.strUserSkillInfoSeq.length(updateIndex + 1);
            strObjPerson_SkillList_SetDR_in.strUserSkillInfoSeq[updateIndex].userID = strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].userID;
            strObjPerson_SkillList_SetDR_in.strUserSkillInfoSeq[updateIndex].strSkillInfo = strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].strSkillInfo;
            updateIndex++;
        }
        else
        {
            // Add

            // add the Adddata to Sequence
            strObjPerson_SkillList_AddDR_in.strUserSkillInfoSeq.length(addIndex + 1);
            strObjPerson_SkillList_AddDR_in.strUserSkillInfoSeq[addIndex].userID = strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].userID;
            strObjPerson_SkillList_AddDR_in.strUserSkillInfoSeq[addIndex].strSkillInfo = strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].strSkillInfo;
            addIndex++;
        }
        */
        if (nSkillOutCnt <= 0)
        {
            // add

            strObjPerson_SkillList_AddDR_in.strUserSkillInfoSeq.length(addIndex + 1);
            strObjPerson_SkillList_AddDR_in.strUserSkillInfoSeq[addIndex].userID = strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].userID;
            strObjPerson_SkillList_AddDR_in.strUserSkillInfoSeq[addIndex].strSkillInfo = strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].strSkillInfo;
            addIndex++;
            continue;
        }
        
        BOOL bInitSetFlag = FALSE;
        BOOL bInitAddFlag = FALSE;
        int iUptSkillCnt = 0;
        int iAddSkillCnt = 0;
        for (int k = 0; k < strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].strSkillInfo.length(); k++)
        {
            BOOL bFindSkill = FALSE;
            for (int t = 0; t < nSkillOutCnt; t++)
            {
                if (CIMFWStrCmp(strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].strSkillInfo[k].skillID,
                                 strObjPerson_SkillList_GetDR_out.strUserSkillInfo.strSkillInfo[t].skillID) == 0)
                {
                    // update
                    if (bInitSetFlag == FALSE)
                    {
                        strObjPerson_SkillList_SetDR_in.strUserSkillInfoSeq.length(updateIndex + 1);
                        strObjPerson_SkillList_SetDR_in.strUserSkillInfoSeq[updateIndex].userID = strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].userID;
                        //updateIndex++;
                        bInitSetFlag = TRUE;
                    }
                    strObjPerson_SkillList_SetDR_in.strUserSkillInfoSeq[updateIndex].strSkillInfo.length(iUptSkillCnt + 1);
                    strObjPerson_SkillList_SetDR_in.strUserSkillInfoSeq[updateIndex].strSkillInfo[iUptSkillCnt].skillID =
                        strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].strSkillInfo[k].skillID;
                    strObjPerson_SkillList_SetDR_in.strUserSkillInfoSeq[updateIndex].strSkillInfo[iUptSkillCnt].skillDesc =
                        strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].strSkillInfo[k].skillDesc;
                    strObjPerson_SkillList_SetDR_in.strUserSkillInfoSeq[updateIndex].strSkillInfo[iUptSkillCnt].certifiedDate =
                        strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].strSkillInfo[k].certifiedDate;
                    iUptSkillCnt++;
                    bFindSkill = TRUE;
                    break;
                }
            }
            
            if (!bFindSkill)
            {
                // add   
                if (bInitAddFlag == FALSE)
                {
                    strObjPerson_SkillList_AddDR_in.strUserSkillInfoSeq.length(addIndex + 1);
                    strObjPerson_SkillList_AddDR_in.strUserSkillInfoSeq[addIndex].userID = strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].userID;
                    // addIndex++;
                    bInitAddFlag = TRUE;
                    PPT_METHODTRACE_V2("","bInitAddFlag",bInitAddFlag);
                }
                PPT_METHODTRACE_V2("","addIndex",addIndex);
                PPT_METHODTRACE_V2("","value",strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].strSkillInfo[k].skillID);
                strObjPerson_SkillList_AddDR_in.strUserSkillInfoSeq[addIndex].strSkillInfo.length(iAddSkillCnt + 1);
                strObjPerson_SkillList_AddDR_in.strUserSkillInfoSeq[addIndex].strSkillInfo[iAddSkillCnt].skillID =
                    strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].strSkillInfo[k].skillID;
                strObjPerson_SkillList_AddDR_in.strUserSkillInfoSeq[addIndex].strSkillInfo[iAddSkillCnt].skillDesc =
                    strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].strSkillInfo[k].skillDesc;
                //CIMFWStrCpy(strObjPerson_SkillList_AddDR_in.strUserSkillInfoSeq[addIndex].strSkillInfo[iAddSkillCnt].skillID,"test1");
                //CIMFWStrCpy(strObjPerson_SkillList_AddDR_in.strUserSkillInfoSeq[addIndex].strSkillInfo[iAddSkillCnt].skillDesc,"desc1");
                strObjPerson_SkillList_AddDR_in.strUserSkillInfoSeq[addIndex].strSkillInfo[iAddSkillCnt].certifiedDate =
                    strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].strSkillInfo[k].certifiedDate;
                PPT_METHODTRACE_V2("","strUserCertifiedSkillUpdateReqInParm.date",strUserCertifiedSkillUpdateReqInParm.strUserSkillInfoSeq[i].strSkillInfo[k].certifiedDate);
                PPT_METHODTRACE_V2("","strObjPerson_SkillList_AddDR_in.date",strObjPerson_SkillList_AddDR_in.strUserSkillInfoSeq[addIndex].strSkillInfo[iAddSkillCnt].certifiedDate);
                iAddSkillCnt++;
            }
        }
        
        if (bInitSetFlag)
            updateIndex++;    
        
        if (bInitAddFlag)
            addIndex++;
    }
    
    PPT_METHODTRACE_V2("", "updateIndex", updateIndex);
    if (updateIndex > 0)
    {
        // call cs_person_SkillList_SetDR to update data
        rc = cs_person_SkillList_SetDR( strObjPerson_SkillList_SetDR_out,
                                        strObjCommonIn,
                                        strObjPerson_SkillList_SetDR_in );

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V2("", "strObjPerson_SkillList_SetDR_out() rc != RC_OK. ", rc);
            strUserCertifiedSkillUpdateReqResult.strResult = strObjPerson_SkillList_SetDR_out.strResult;
            return(rc);
        }
    }
    
    if (addIndex > 0)
    {
        // call cs_person_SkillList_AddDR to add data
        rc = cs_person_SkillList_AddDR( strObjPerson_SkillList_AddDR_out,
                                        strObjCommonIn,
                                        strObjPerson_SkillList_AddDR_in );

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V2("", "cs_person_SkillList_AddDR() rc != RC_OK. ", rc);
            strUserCertifiedSkillUpdateReqResult.strResult = strObjPerson_SkillList_AddDR_out.strResult;
            return(rc);
        }
    }
    PPT_METHODTRACE_V1("", "exit cs_txUserCertifiedSkillUpdateReq,byebye")
    
    // Return to caller
    PPT_METHODTRACE_EXIT("PPTManager_i::cs_txUserCertifiedSkillUpdateReq");
    return RC_OK;
}