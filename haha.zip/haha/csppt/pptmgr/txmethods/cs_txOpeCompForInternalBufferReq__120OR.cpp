#ifndef lint
static char *sccsid =  "@(#) 1.5 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txOpeCompForInternalBufferReq__120OR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 10/29/07 18:28:59 [ 10/29/07 18:29:02 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cs_txOpeCompForInternalBufferReq__120OR.cpp
//

#include "cs_pptmgr.hpp"

#include <unistd.h>

void DebugOutStartCassette(pptDataSpecCheckReqResult& tg);  //DSIV00000201

// Class: CS_PPTManager
//
// Service: txOpeCompForInternalBufferReq__120()
//
// Change history:
// Date       Level    Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2001/07/06 D4000015 O.Sugiyama     Initial Release (R4.0)
// 2001/08/27 D4000015 O.Sugiyama     Modify Get Equipment's Online Mode
// 2001/08/28 D4000016 N.Maeda        add Process Contamination Contorl update logic (Copper/NonCopper) (R4.0)
// 2001/08/30 D4000015 O.Sugiyama     Modify TCSMgr function "0.01"
// 2001/09/05 D4000015 O.Sugiyama     Change TX_ID TXTRC004 -> TXTRC055 "0.02"
// 2001/09/07 D4000060 K.Kido         Add retry TCS request logic
// 2001/11/30 D40A0027 Y.Iwasaki      Add for ProcessLagTime function.
// 2002/01/16 D4100069 C.Tsuchiya     Drop LCFR logic
// 2002/02/01 P4100104 H.Adachi       Fix Can not Ope Comp When Inhibit is Already existed case
// 2002/02/08 D4100083 T.Michii       Enhancement Future Hold
// 2002/02/14 D4100134 C.Tsuchiya     Use getenv() instead of Mgr class member 'theSP_xxx'
// 2002/02/28 D4100120 N.Minami       Future Action
// 2002/03/07 D4100083 T.Michii       Fix length of structure
// 2002/06/11 P4100536 T.Nishimura    Source Check : Wrong reference to dimension.
// 2002/07/04 P4200025 T.Nishimura    Source Check : return without message.
// 2002/07/30 D4200029 K.Kimura       Process Hold Control
// 2002/09/27 D4200115 C.Tsuchiya     New Action by SPC Check result
// 2002/09/30 P4200204 H.Adachi       Add Parameter of holdReleasedLotIDs for txOpeCompForInternalBufferReq
// 2003/01/16 P4200492 Y.Iwasaki      Rollback D4000015 (Restore strStartCassette re-creation logic)
// 2003/09/08 D5000225 T.Hikari       When "AddToQueue" failes, continuation of processing is enabled.
// 2004/04/07 D5100232 K.Matsuei      Initial Release. Add DCS Interfact to MM.
// 2004/04/19 D5100184 H.Hasegawa     Add the logic which repeats Gate Pass for Monitored Lot
// 2004/07/14 P5100398 K.Kido         Check Return Structure of "txDataSpecCheckReq" for SPCCheckRequiredFlag.
// 2004/08/03 P5100473 H.Adachi       Add logic of setting parameter for txSchdlChangeReservationExecuteReq().
// 2004/08/11 D51M0000 M.Mori         APC I/F Enhance for Interface Spec-B
// 2004/09/16 P51M0012 M.Mori         Check Code review result (No return code)
// 2004/09/24 P51M0018 M.Mori         Change Set Return Structure after APC.
// 2004/10/22 D6000025 K.Murakami     eBroker Migration.
// 2004/11/11 P6000053 M.Mori         Add logic of SpecError after Derived Error.
// 2004/11/16 P6000062 M.Mori         Drop Derived Error logic.
// 2005/01/17 P6000204 K.Kido         Set Calculated Data for Derived DCDef even if Spec Check hasn't been done.
// 2005/10/24 D6000479 K.Kido         Lock Port Object.
// 2005/10/31 D7000006 T.Ohsaki       exchange "controlJob_Delete()" to "txControlJobManageReq()"
// 2005/11/10 D7000021 M.Murata       Delete logic for APC Disposition.("APCH" Hold, registration to queue table)
// 2005/12/12 D7000096 Y.Kadowaki     Delete environment variable "SP_DELIVERY_REQ_EXIST".
// 2006/01/19 D7000180 S.Kano         Move "Send to DCS" logic after "Send TCS" logic
// 2006/01/20 D7000182 H.Mutoh        Enhancement of re-sending APCControlJobInformation.
// 2006/02/14 D7000178 S.Kano         SPEC Check and SPC Check are separated, these are bundled to the new transaction of CollectedDataAction.
// 2006/10/26 D7000354 H.Hasegawa     Add the logic which resets Q-Time actions
// 2007/04/20 D9000001 H.Murakami     64bit support.
// 2007/08/06 P9000028 H.Hotta        Modify logic after calling lot_holdState_Get().
// 2007/09/18 D9000084 K.Kido         Set last used time of used reticle.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/07 DSIV00000201 M.Ishino       Improvement of Post-Processing.
// 2009/04/10 PSIV00000888 R.Okano        Change logic not to create CollectedDataEvent when CollectedDataAction is performed in PostProcess.
// 2009-07-28 PSIV00001188 R.Iriguchi     Fix auto bank-in handling.
// 2009/11/13 DSIV00001471 F.Chen         Collected data validation enhancement.
// 2010/10/14 DSIV00002435 M.Ogawa        Support SubLotType change by Schedule Change Reservation
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2011/08/23 DSN000015229 Sa Guo         New Release for R12
//                                        Do not delete controlJob object if it is called from partial operation completion
//                                        Do not send report to APC if it is called from partial operation completion
// 2012/07/24 DSN000043340 M.Ogawa        Post process migration mode
// 2012/11/30 DSN000049350 K.Yamaoku      Equipment parallel processing support (P2)
// 2014/06/04 DSN000085791 C.Mo           Entity Inhibit Exception Lot Support. (R150)
// 2016/06/06 DSN000102497 K.Yamaoku      Support tMSP
// 2016/11/10 PSN000103621 Q.Li           Add Lock Material Location.
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/08/28 INN-R170002  Yangxiaojun    Overide txOpeCompForInternalBufferReq__120
// 2017/09/07 INN-R170002  JQ.Shao        Contamination Control
// 2017/09/12 INN-R170002  Thomas.Song    Contamination Control
// 2017/10/18 INN-R170085  liu Xinxin     Equipment status for PM
// 2017/10/19 INN-R170009  Qufd           Add APC Queue

// Description:
//
// Return:
//     long
//
// Parameter:
//    pptOpeCompForInternalBufferReqResult&  strOpeCompForInternalBufferReqResult
//    const pptObjCommonIn&                  strObjCommonIn
//    const objectIdentifier&                equipmentID
//    const objectIdentifier&                controlJobID
//    CORBA::Boolean                         spcResultRequiredFlag
//    const char *                           claimMemo
//    objectIdentifierSequence               holdReleasedLotIDs        //P4200204
//    pptAPCBaseCassetteSequence&            strAPCBaseCassetteListForOpeComp  //DSN000015229
//    char *&                                APCIFControlStatus  //D7000182    //DSN000015229
//    char *&                                DCSIFControlStatus  //D7000182    //DSN000015229
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//      TXTRC055
//P4200204 Delete Start
//CORBA::Long CS_PPTManager_i::txOpeCompForInternalBufferReq (
//            pptOpeCompForInternalBufferReqResult&  strOpeCompForInternalBufferReqResult,
//            const pptObjCommonIn&                  strObjCommonIn,
//            const objectIdentifier&                equipmentID,
//            const objectIdentifier&                controlJobID,
//            CORBA::Boolean                         spcResultRequiredFlag,
//            const char *                           claimMemo,
//            CORBA::Environment &                   IT_env )
//P4200204 Delete End

//P4200204 Add
CORBA::Long CS_PPTManager_i::txOpeCompForInternalBufferReq__120 (
            pptOpeCompForInternalBufferReqResult&  strOpeCompForInternalBufferReqResult,
            const pptObjCommonIn&                  strObjCommonIn,
            const objectIdentifier&                equipmentID,
            const objectIdentifier&                controlJobID,
            CORBA::Boolean                         spcResultRequiredFlag,
            const char *                           claimMemo,
//D6000025             objectIdentifierSequence&              holdReleasedLotIDs,
//D6000025             CORBA::Environment &                   IT_env )
//D7000182            objectIdentifierSequence&              holdReleasedLotIDs //D6000025
            objectIdentifierSequence&              holdReleasedLotIDs, //D7000182
            pptAPCBaseCassetteSequence&            strAPCBaseCassetteListForOpeComp, //DSN000015229
            char *&                                APCIFControlStatus, //D7000182
            char *&                                DCSIFControlStatus  //D7000182
            CORBAENV_LAST_CPP )                                       //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txOpeCompForInternalBufferReq__120") ;
    CORBA::Long rc = RC_OK ;
    CORBA::Long PostProcForLotFlag = atoi(getenv(SP_POSTPROC_FOR_LOT_FLAG));    //DSIV00000201

//D4000015 Start
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    //   Check Process
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","equipment_categoryVsTxID_CheckCombination() returned error.");

        strOpeCompForInternalBufferReqResult.strResult
            = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return (rc);
    }
//D4000015 End

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Object Lock Process                                                 */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

//D4000015     CORBA::Boolean  EmptyPortFlag = FALSE;
//D4000015    /*-----------------------------------------------------------------------*/
//D4000015    /*   Get unload information which is sepcified with ControlJob ID        */
//D4000015    /*-----------------------------------------------------------------------*/
//D4000015 //D4000011    CORBA::String_var deliveryReqExist = CIMFWStrDup(getenv("SP_DELIVERY_REQ_EXIST"));
//D4000015    CORBA::String_var deliveryReqExist = theSP_DELIVERY_REQ_EXIST;   //D4000011
//D4000015
//D4000015    PPT_METHODTRACE_V2("","deliveryReqExist=",deliveryReqExist);
//D4000015
//D4000015    objEquipment_inprocessingControlJobInfo_Get_out strEquipment_inprocessingControlJobInfo_Get_out;
//D4000015    if ( 0 != CIMFWStrCmp(deliveryReqExist, "YES") )
//D4000015    {
//D4000015        rc = equipment_inprocessingControlJobInfo_Get( strEquipment_inprocessingControlJobInfo_Get_out,
//D4000015                                                       strObjCommonIn,
//D4000015                                                       equipmentID);
//D4000015        if( rc != RC_OK )
//D4000015        {
//D4000015            PPT_METHODTRACE_V1("", "equipment_inprocessingControlJobInfo_Get() != RC_OK") ;
//D4000015            strOpeCompForInternalBufferReqResult.strResult = strEquipment_inprocessingControlJobInfo_Get_out.strResult ;
//D4000015            return( rc );
//D4000015        }
//D4000015    }

    /*-----------------------------------------------------------------------*/
    /*   Get Started Lot information which is sepcified with ControlJob ID   */
    /*-----------------------------------------------------------------------*/
    objControlJob_startReserveInformation_Get_out   strControlJob_startReserveInformation_Get_out;
    rc = controlJob_startReserveInformation_Get( strControlJob_startReserveInformation_Get_out,
                                                 strObjCommonIn,
                                                 controlJobID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "controlJob_startReserveInformation_Get() != RC_OK") ;
        strOpeCompForInternalBufferReqResult.strResult = strControlJob_startReserveInformation_Get_out.strResult ;
        return( rc );
    }

    CORBA::Long scLen = 0;
    scLen = strControlJob_startReserveInformation_Get_out.strStartCassette.length();
    PPT_METHODTRACE_V2("", "strControlJob_startReserveInformation_Get_out.strStartCassette.length()", scLen) ;

    CORBA::Long totalStartLotCount = 0;    //D4100083 (03/07)

    {   // debug trace
        CORBA::Long ii, jj, kk, ll;
        CORBA::Long leng1, leng2, leng3;
        for (ii=0; ii < scLen; ii++)
        {
            leng1 = strControlJob_startReserveInformation_Get_out.strStartCassette[ii].strLotInCassette.length();
            PPT_METHODTRACE_V2("","strLotInCassette.length--->", leng1);
            for (jj=0; jj < leng1; jj++)
            {
//D4100083 (03/07)  add
                if ( strControlJob_startReserveInformation_Get_out.strStartCassette[ii].strLotInCassette[jj].operationStartFlag == TRUE )
                {
                    totalStartLotCount ++ ;
                }
//D4100083 (03/07)  end
                leng2 = strControlJob_startReserveInformation_Get_out.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef.length();
                PPT_METHODTRACE_V2("","strStartRecipe.strDCDef.length--->", leng2);
                for (kk=0; kk < leng2; kk++)
                {
                    leng3 = strControlJob_startReserveInformation_Get_out.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem.length();
                    PPT_METHODTRACE_V2("","strDCDef.strDCItem.length--->", leng3);
                    for (ll=0; ll < leng3; ll++)
                    {
                        PPT_METHODTRACE_V2("","specCheckResult--->", strControlJob_startReserveInformation_Get_out.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].specCheckResult);
//D4000015                        strControlJob_startReserveInformation_Get_out.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].specCheckResult;
                    }
                }
            }
        }
    }

//DSN000049350 Add Start
    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = equipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXTRC055" ); // TxOpeCompForInternalBufferReq
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

    PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strOpeCompForInternalBufferReqResult.strResult = strObject_lockMode_Get_out.strResult;
        return( rc );
    }

    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;

    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strOpeCompForInternalBufferReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
        /*--------------------------------*/
        /*   Lock Macihne object          */
        /*--------------------------------*/
//DSN000049350        objObject_Lock_out  strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, equipmentID, SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "object_Lock() != RC_OK") ;
            strOpeCompForInternalBufferReqResult.strResult = strObject_Lock_out.strResult ;
            return( rc );
        }
    } //DSN000049350

//DSN000049350 Move to later session
//DSN000049350 //D6000479 add start
//DSN000049350     /**********************************************************/
//DSN000049350     /*  Lock All Port Object for internal Buffer Equipment.   */
//DSN000049350     /**********************************************************/
//DSN000049350     objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
//DSN000049350     rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out,
//DSN000049350                                                     strObjCommonIn,
//DSN000049350                                                     equipmentID );
//DSN000049350     if ( rc != RC_OK )
//DSN000049350     {
//DSN000049350         PPT_METHODTRACE_V1("", "equipment_portInfoForInternalBuffer_GetDR != RC_OK")
//DSN000049350         strOpeCompForInternalBufferReqResult.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
//DSN000049350         return( rc );
//DSN000049350     }
//DSN000049350 
//DSN000049350     CORBA::Long lenPortInfo = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
//DSN000049350     for( CORBA::Long j = 0 ; j < lenPortInfo ; j++ )
//DSN000049350     {
//DSN000049350         objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
//DSN000049350         rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
//DSN000049350                                               strObjCommonIn,
//DSN000049350                                               equipmentID,
//DSN000049350                                               strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID,
//DSN000049350                                               SP_ClassName_PosPortResource );
//DSN000049350         if ( rc != RC_OK )
//DSN000049350         {
//DSN000049350             PPT_METHODTRACE_V2("", "object_LockForEquipmentResource () rc != RC_OK", rc);
//DSN000049350             strOpeCompForInternalBufferReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
//DSN000049350             return( rc );
//DSN000049350         }
//DSN000049350         PPT_METHODTRACE_V2("", "Locked port object : ", strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID.identifier);
//DSN000049350     }
//DSN000049350 //D6000479 add end

    /*--------------------------------*/
    /*   Lock Cassette / Lot Object   */
    /*--------------------------------*/
    pptStartCassetteSequence  strStartCassette(scLen);
    strStartCassette.length(scLen);

//DSN000049350 Add Start
    objectIdentifierSequence lotIDs;
    objectIdentifierSequence cassetteIDs;
    CORBA::ULong extendLen     = 25;
    CORBA::ULong t_lotIDLen    = extendLen;
    CORBA::ULong lotIDCnt      = 0;
    CORBA::ULong cassetteIDCnt = 0;
    lotIDs.length(t_lotIDLen);
    cassetteIDs.length(scLen);
//DSN000049350 Add End

    for (CORBA::Long i=0; i<scLen; i++)
    {
        strStartCassette[i] = strControlJob_startReserveInformation_Get_out.strStartCassette[i];

        CORBA::Long nLen = 0;
        nLen =  strStartCassette[i].strLotInCassette.length();
        PPT_METHODTRACE_V2("","strStartCassette[i].strLotInCassette.length()", nLen) ;

        /*--------------------------*/
        /*   Lock Cassette Object   */
        /*--------------------------*/
        if (CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette ) == 0)
        {
            PPT_METHODTRACE_V2("","CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette ) == 0", i);

//D4000015            EmptyPortFlag = TRUE;

            objEquipment_monitorCreationFlag_Get_out   strEquipment_monitorCreationFlag_Get_out;
            rc = equipment_monitorCreationFlag_Get( strEquipment_monitorCreationFlag_Get_out,
                                                    strObjCommonIn,
                                                    equipmentID);

            //---------------------------------------------------------------------------------------------
            //    if monitor creationflag was TRUE, at least one Lot should be existed in Empty Cassete.
            //---------------------------------------------------------------------------------------------
            if ( rc == RC_MONITOR_CREAT_REQD )
            {
                if ( nLen == 0 )
                {
                    PPT_METHODTRACE_V1("", "object_Lock() == RC_MONITOR_CREAT_REQD") ;
                    SET_MSG_RC(strOpeCompForInternalBufferReqResult, MSG_MONITOR_CREAT_REQD, rc) ;
                    return( rc );
                }
            }

//DSN000049350            objObject_Lock_out  strObject_Lock_out;
//DSN000049350            rc = object_Lock( strObject_Lock_out, strObjCommonIn, strStartCassette[i].cassetteID, SP_ClassName_PosCassette );
//DSN000049350            if ( rc != RC_OK )
//DSN000049350            {
//DSN000049350                PPT_METHODTRACE_V1("", "object_Lock() != RC_OK") ;
//DSN000049350                strOpeCompForInternalBufferReqResult.strResult = strObject_Lock_out.strResult ;
//DSN000049350                return( rc );
//DSN000049350            }
            cassetteIDs[cassetteIDCnt++] = strStartCassette[i].cassetteID;  //DSN000049350

            continue;
        }

//DSN000049350        objObject_Lock_out  strObject_Lock_out;
//DSN000049350        rc = object_Lock( strObject_Lock_out, strObjCommonIn, strStartCassette[i].cassetteID, SP_ClassName_PosCassette );
//DSN000049350        if ( rc != RC_OK )
//DSN000049350        {
//DSN000049350            PPT_METHODTRACE_V1("", "object_Lock() != RC_OK") ;
//DSN000049350            strOpeCompForInternalBufferReqResult.strResult = strObject_Lock_out.strResult ;
//DSN000049350            return( rc );
//DSN000049350        }
        cassetteIDs[cassetteIDCnt++] = strStartCassette[i].cassetteID;  //DSN000049350

        for (CORBA::Long j=0; j<nLen; j++)
        {
            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                PPT_METHODTRACE_V1("", "strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE") ;
                continue;
            }

            /*---------------------*/
            /*   Lock Lot Object   */
            /*---------------------*/
//DSN000049350            objObject_Lock_out  strObject_Lock_out;
//DSN000049350            rc = object_Lock( strObject_Lock_out, strObjCommonIn, strStartCassette[i].strLotInCassette[j].lotID, SP_ClassName_PosLot );
//DSN000049350            if ( rc != RC_OK )
//DSN000049350            {
//DSN000049350                PPT_METHODTRACE_V1("", "object_Lock() != RC_OK") ;
//DSN000049350                strOpeCompForInternalBufferReqResult.strResult = strObject_Lock_out.strResult ;
//DSN000049350                return( rc );
//DSN000049350            }

//DSN000049350 Add Start
            if( lotIDCnt >= t_lotIDLen )
            {
                PPT_METHODTRACE_V1("", "lotIDCnt >= t_lotIDLen");
                t_lotIDLen += extendLen;
                lotIDs.length( t_lotIDLen );
            }
            lotIDs[lotIDCnt++] = strStartCassette[i].strLotInCassette[j].lotID;
//DSN000049350 Add End
        }
    }
    cassetteIDs.length(cassetteIDCnt);  //DSN000049350
    lotIDs.length(lotIDCnt);            //DSN000049350

    PPT_METHODTRACE_V2( "", "cassetteIDCnt", cassetteIDCnt);    //DSN000049350
    PPT_METHODTRACE_V2( "", "lotIDCnt", lotIDCnt);              //DSN000049350

//DSN000049350 Add Start
    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
        objEquipment_onlineMode_Get_out strEquipment_onlineMode_Get_out;
        rc = equipment_onlineMode_Get( strEquipment_onlineMode_Get_out, strObjCommonIn, equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_onlineMode_Get() rc != RC_OK", rc);
            strOpeCompForInternalBufferReqResult.strResult = strEquipment_onlineMode_Get_out.strResult;
            return rc;
        }
        
        if ( 0 == CIMFWStrCmp( strEquipment_onlineMode_Get_out.onlineMode, SP_Eqp_OnlineMode_Offline ) )
        {
            // Lock Equipment ProcLot Element (Count)
            stringSequence dummySeq;
            dummySeq.length(0);
            strAdvanced_object_Lock_in.objectID   = equipmentID;
            strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
            strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_InProcessingLot );
            strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_COUNT;
            strAdvanced_object_Lock_in.keySeq     = dummySeq;

            PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_InProcessingLot );
            rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                       strObjCommonIn,
                                       strAdvanced_object_Lock_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                strOpeCompForInternalBufferReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                return( rc );
            }
        }

        // Lock Equipment ProcLot Element (Write)
        stringSequence procLotSeq;
        procLotSeq.length(lotIDCnt);
        for ( CORBA::ULong procLotNo = 0; procLotNo < lotIDCnt; procLotNo++ )
        {
            procLotSeq[procLotNo] = lotIDs[procLotNo].identifier;
        }
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_InProcessingLot );
        strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
        strAdvanced_object_Lock_in.keySeq     = procLotSeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_InProcessingLot );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strOpeCompForInternalBufferReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Move from earlier session
//D6000479 add start
        /**********************************************************/
        /*  Lock All Port Object for internal Buffer Equipment.   */
        /**********************************************************/
        objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
        rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out,
                                                        strObjCommonIn,
                                                        equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "equipment_portInfoForInternalBuffer_GetDR != RC_OK")
            strOpeCompForInternalBufferReqResult.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
            return( rc );
        }

        CORBA::Long lenPortInfo = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
        for( CORBA::Long j = 0 ; j < lenPortInfo ; j++ )
        {
            objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
            rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                  strObjCommonIn,
                                                  equipmentID,
                                                  strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID,
                                                  SP_ClassName_PosPortResource );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_LockForEquipmentResource () rc != RC_OK", rc);
                strOpeCompForInternalBufferReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
                return( rc );
            }
            PPT_METHODTRACE_V2("", "Locked port object : ", strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID.identifier);
        }
//D6000479 add end
//DSN000049350 Move End
    }
    if (lockMode != SP_EQP_LOCK_MODE_WRITE)
    {
//PSN000103621 Add Start
        /*------------------------------*/
        /*   Lock Material Location     */
        /*------------------------------*/
        for ( CORBA::Long ij = 0 ; ij < scLen ; ij++ )
        {
            objAdvanced_object_LockForEquipmentResource_out strAdvanced_object_LockForEquipmentResource_out;
            objAdvanced_object_LockForEquipmentResource_in strAdvanced_object_LockForEquipmentResource_in;
            strAdvanced_object_LockForEquipmentResource_in.equipmentID              = equipmentID;
            strAdvanced_object_LockForEquipmentResource_in.className                = CIMFWStrDup( SP_ClassName_PosMaterialLocation_ByCJ );
            strAdvanced_object_LockForEquipmentResource_in.objectID                 = controlJobID;
            strAdvanced_object_LockForEquipmentResource_in.objectLockType           = SP_ObjectLock_LockType_WRITE;
            strAdvanced_object_LockForEquipmentResource_in.bufferResourceName       = strStartCassette[ij].loadPurposeType;
            strAdvanced_object_LockForEquipmentResource_in.bufferResourceLockType   = SP_ObjectLock_LockType_READ;
            
            PPT_METHODTRACE_V2( "", "calling advanced_object_LockForEquipmentResource()", SP_ClassName_PosMaterialLocation_ByCJ );
            rc =  advanced_object_LockForEquipmentResource( strAdvanced_object_LockForEquipmentResource_out,
                                                            strObjCommonIn,
                                                            strAdvanced_object_LockForEquipmentResource_in );
    
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_LockForEquipmentResource() != RC_OK", rc);
                strOpeCompForInternalBufferReqResult.strResult = strAdvanced_object_LockForEquipmentResource_out.strResult ;
                return( rc );
            }
        }
//PSN000103621 Add End
        /*------------------------------*/
        /*   Lock ControlJob Object     */
        /*------------------------------*/
        PPT_METHODTRACE_V2( "", "calling object_Lock()", SP_ClassName_PosControlJob );
        rc = object_Lock( strObject_Lock_out,
                          strObjCommonIn,
                          controlJobID,
                          SP_ClassName_PosControlJob );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
            strOpeCompForInternalBufferReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    }
    /*------------------------------*/
    /*   Lock Cassette/Lot Object   */
    /*-------------------------------*/
    objObjectSequence_Lock_out strObjectSequence_Lock_out;

    PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosCassette );
    rc = objectSequence_Lock( strObjectSequence_Lock_out,
                              strObjCommonIn,
                              cassetteIDs,
                              SP_ClassName_PosCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
        strOpeCompForInternalBufferReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }

    PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosLot );
    rc = objectSequence_Lock( strObjectSequence_Lock_out,
                              strObjCommonIn,
                              lotIDs,
                              SP_ClassName_PosLot );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
        strOpeCompForInternalBufferReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }
//DSN000049350 Add End

//D51M0000 Add Start
    /*-------------------------------------------------*/
    /*   call cassette_APCInformation_GetDR            */
    /*-------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call cassette_APCInformation_GetDR") ;

    objCassette_APCInformation_GetDR_out strCassette_APCInformation_GetDR_out;
    rc = cassette_APCInformation_GetDR ( strCassette_APCInformation_GetDR_out,
                                         strObjCommonIn,
                                         equipmentID,
                                         strStartCassette );
    if ( rc == RC_SYSTEM_ERROR )
    {
        PPT_METHODTRACE_V1("", "cassette_APCInformation_GetDR() == RC_SYSTEM_ERROR");
        strOpeCompForInternalBufferReqResult.strResult = strCassette_APCInformation_GetDR_out.strResult;
        return ( rc );
    }
    else if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cassette_APCInformation_GetDR() != RC_OK");
        strOpeCompForInternalBufferReqResult.strResult = strCassette_APCInformation_GetDR_out.strResult;
    }
//D51M0000 Add End

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Check Process                                                       */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

//D4000015 start end
    /*------------------------------------*/
    /*   Get and Check Cassette on Port   */
    /*------------------------------------*/
    objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
    rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out, strObjCommonIn, equipmentID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "equipment_portInfo_Get() != RC_OK");
        strOpeCompForInternalBufferReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
        return(rc);
    }
//D4000015 add end

    /*---------------------------------*/
    /*   Get Equipment's Online Mode   */
    /*---------------------------------*/
    objPortResource_currentOperationMode_Get_out  strPortResource_currentOperationMode_Get_out;
//D4000015    rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
//D4000015                                                strObjCommonIn,
//D4000015                                                equipmentID,

//P4100536 add start
    // Check length of Equipment Port
    if(0 >= strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length())
    {
        PPT_SET_MSG_RC_KEY(strOpeCompForInternalBufferReqResult, MSG_NOT_FOUND_PORT, RC_NOT_FOUND_PORT, "(This equipment does not have any port.)"); //P4200025 add
        return RC_NOT_FOUND_PORT;
    }
//P4100536 add end

//D4000015 add start
    rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
                                                strObjCommonIn,
                                                equipmentID,
                                                strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[0].portID );
//D4000015 add end
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "portResource_currentOperationMode_Get() != RC_OK") ;
        strOpeCompForInternalBufferReqResult.strResult = strPortResource_currentOperationMode_Get_out.strResult ;
        return( rc );
    }


    /*----------------------------------------------------------------------------*/
    /*                                                                            */
    /*   If AccessMode is Auto or OnlineMode is Offline, do the following check.  */
    /*                                                                            */
    /*----------------------------------------------------------------------------*/
    if ( CIMFWStrCmp( strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode, SP_Eqp_OnlineMode_Offline) == 0 ||
         CIMFWStrCmp( strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode, SP_Eqp_AccessMode_Auto   ) == 0 )
    {

        /*-----------------------------------------------------------------------*/
        /*                                                                       */
        /*   Check Process for Cassette                                          */
        /*                                                                       */
        /*   The following conditions are checked by this object                 */
        /*                                                                       */
        /*   - transferState                                                     */
        /*                                                                       */
        /*-----------------------------------------------------------------------*/
        objCassette_CheckConditionForOpeComp_out   strCassette_CheckConditionForOpeComp_out;
        rc = cassette_CheckConditionForOpeComp( strCassette_CheckConditionForOpeComp_out,
                                                strObjCommonIn,
                                                strStartCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cassette_CheckConditionForOpeComp() != RC_OK") ;
            strOpeCompForInternalBufferReqResult.strResult = strCassette_CheckConditionForOpeComp_out.strResult ;
            return( rc );
        }

        /*-----------------------------------------------------------------------*/
        /*                                                                       */
        /*   Check Equipment Port for OpeComp                                    */
        /*                                                                       */
        /*   The following conditions are checked by this object                 */
        /*                                                                       */
        /*   - All of Cassette, which is contained in controlJob, must be on     */
        /*     the equipment's unloadingPort.                                    */
        /*                                                                       */
        /*-----------------------------------------------------------------------*/
//D4000015        objEquipment_portState_CheckForOpeComp_out   strEquipment_portState_CheckForOpeComp_out;
//D4000015        rc = equipment_portState_CheckForOpeComp( strEquipment_portState_CheckForOpeComp_out,
//D4000015                                                  strObjCommonIn,
//D4000015                                                  equipmentID,
//D4000015                                                  strStartCassette );
//D4000015        if ( rc != RC_OK )
//D4000015        {
//D4000015            PPT_METHODTRACE_V1("", "equipment_portState_CheckForOpeComp() != RC_OK") ;
//D4000015            strOpeCompForInternalBufferReqResult.strResult = strEquipment_portState_CheckForOpeComp_out.strResult ;
//D4000015            return( rc );
//D4000015        }

//D4000015 add start
        objEquipment_portState_CheckForOpeCompForInternalBuffer_out   strEquipment_portState_CheckForOpeCompForInternalBuffer_out;
        rc = equipment_portState_CheckForOpeCompForInternalBuffer( strEquipment_portState_CheckForOpeCompForInternalBuffer_out,
                                                                   strObjCommonIn,
                                                                   equipmentID,
                                                                   strStartCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "equipment_portState_CheckForOpeComp() != RC_OK") ;
            strOpeCompForInternalBufferReqResult.strResult = strEquipment_portState_CheckForOpeCompForInternalBuffer_out.strResult ;
            return( rc );
        }
//D4000015 add end
    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Lot                                               */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - lotProcessState                                                   */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    objLot_CheckConditionForOpeComp_out   strLot_CheckConditionForOpeComp_out;
    rc = lot_CheckConditionForOpeComp( strLot_CheckConditionForOpeComp_out, strObjCommonIn, strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_CheckConditionForOpeComp() != RC_OK") ;
        strOpeCompForInternalBufferReqResult.strResult = strLot_CheckConditionForOpeComp_out.strResult ;
        return( rc );
    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Equipment                                         */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - All lof lot, which is contained in controlJob, must be existing   */
    /*     in the equipment's processing information.                        */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    objEquipment_CheckConditionForOpeComp_out   strEquipment_CheckConditionForOpeComp_out;
    rc = equipment_CheckConditionForOpeComp( strEquipment_CheckConditionForOpeComp_out,
                                             strObjCommonIn,
                                             equipmentID,
                                             strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "equipment_CheckConditionForOpeComp() != RC_OK") ;
        strOpeCompForInternalBufferReqResult.strResult = strEquipment_CheckConditionForOpeComp_out.strResult ;
        return( rc );
    }

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Main Process (Reverse Order of OpeStart Procedure)                  */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
//D7000178    /*----------------------------------------------*/
//D7000178    /*                                              */
//D7000178    /*   Data Collection Procedure                  */
//D7000178    /*                                              */
//D7000178    /*----------------------------------------------*/
//D7000178    CORBA::Boolean spcCheckRequiredFlag = FALSE ;
//D7000178
//D7000178    pptSpcCheckReqResult strSpcCheckReqResult;
//D7000178
//D7000178    /*----------------------------------------------*/
//D7000178    /*   If Eqp's CompetionMode is Auto Mode        */
//D7000178    /*   Call txSpecCheckDataReq                    */
//D7000178    /*----------------------------------------------*/
//D7000178    if (CIMFWStrCmp( strPortResource_currentOperationMode_Get_out.strOperationMode.operationCompMode ,
//D7000178                     SP_Eqp_CompMode_Auto ) == 0)
//D7000178    {
//D7000178        PPT_METHODTRACE_V1("","CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.operationCompMode, SP_Eqp_CompMode_Auto ) == 0") ;
//D7000178
//D7000178        /*-------------------------------------------------------------------------------------------*/
//D7000178        /*   Do Spec Check                                                                           */
//D7000178        /*      - Calculate the derived value and Set them to PO if calculationRequiredFlag is TRUE  */
//D7000178        /*      - Set speck check result to PO if speckCheckRequiredFlag is TRUE.                    */
//D7000178        /*-------------------------------------------------------------------------------------------*/
//D7000178        pptDataSpecCheckReqResult strDataSpecCheckReqResult;
//D7000178        rc = txDataSpecCheckReq( strDataSpecCheckReqResult,
//D7000178                                 strObjCommonIn,
//D7000178                                 equipmentID,
//D7000178                                 controlJobID,
//D7000178                                 strStartCassette );
//D7000178
//D7000178//P5100398 add start
//D7000178        /*----------------------------------------------*/
//D7000178        /*  Replace ReturnCode for SPCCheckRequired.    */
//D7000178        /*----------------------------------------------*/
//D7000178        if ( rc == RC_OK )
//D7000178        {
//D7000178            rc = RC_NO_NEED_SPEC_CHECK;
//D7000178            CORBA::Long casLen = strDataSpecCheckReqResult.strStartCassette.length();
//D7000178            for( CORBA::Long i1 = 0 ; i1 < casLen ; i1++ )
//D7000178            {
//D7000178                CORBA::Long lotLen = strDataSpecCheckReqResult.strStartCassette[i1].strLotInCassette.length();
//D7000178                for( CORBA::Long j1 = 0 ; j1 < lotLen ; j1++ )
//D7000178                {
//D7000178                    if ( strDataSpecCheckReqResult.strStartCassette[i1].strLotInCassette[j1].operationStartFlag == FALSE )
//D7000178                    {
//D7000178                        continue;
//D7000178                    }
//D7000178                    CORBA::Long DCDefLen = strDataSpecCheckReqResult.strStartCassette[i1].strLotInCassette[j1].strStartRecipe.strDCDef.length();
//D7000178                    for( CORBA::Long k1 = 0 ; k1 < DCDefLen ; k1++ )
//D7000178                    {
//D7000178                        if ( 0 == CIMFWStrCmp( strDataSpecCheckReqResult.strStartCassette[i1].strLotInCassette[j1].strStartRecipe.strDCDef[k1].dataCollectionSpecificationID.identifier, "" ) )
//D7000178                        {
//D7000178                            continue ;
//D7000178                        }
//D7000178                        CORBA::Long DCitemLen = strDataSpecCheckReqResult.strStartCassette[i1].strLotInCassette[j1].strStartRecipe.strDCDef[k1].strDCItem.length();
//D7000178                        for( CORBA::Long l1 = 0 ; l1 < DCitemLen ; l1++ )
//D7000178                        {
//D7000178                            if( 0 != CIMFWStrCmp(strDataSpecCheckReqResult.strStartCassette[i1].strLotInCassette[j1].strStartRecipe.strDCDef[k1].strDCItem[l1].specCheckResult, "*") &&
//D7000178                                0 != CIMFWStrCmp(strDataSpecCheckReqResult.strStartCassette[i1].strLotInCassette[j1].strStartRecipe.strDCDef[k1].strDCItem[l1].specCheckResult, "") )
//D7000178                            {
//D7000178                                rc = RC_OK;
//D7000178                                break;
//D7000178                            }
//D7000178                        }
//D7000178                        if( rc == RC_OK )
//D7000178                        {
//D7000178                            break;
//D7000178                        }
//D7000178                    }
//D7000178                    if( rc == RC_OK )
//D7000178                    {
//D7000178                        break;
//D7000178                    }
//D7000178                }
//D7000178                if( rc == RC_OK )
//D7000178                {
//D7000178                    break;
//D7000178                }
//D7000178            }
//D7000178        }
//D7000178//P5100398 add end
//D7000178
//D7000178        if ( rc == RC_OK )
//D7000178        {
//D7000178            PPT_METHODTRACE_V1("", "txDataSpecCheckReq() == RC_OK") ;
//D7000178
//D7000178//D4000015 unnecessary start
//D7000178//D4000015            /*-------------------------------------------------------------------------------*/
//D7000178//D4000015            /*   Get Started Lot information in order to get the derived / delta datavalues  */
//D7000178//D4000015            /*   and also specCheckResult in case that CompletionMode is Auto.               */
//D7000178//D4000015            /*-------------------------------------------------------------------------------*/
//D7000178//D4000015            objControlJob_startReserveInformation_Get_out   strControlJob_startReserveInformation_Get_out;
//D7000178//D4000015            rc = controlJob_startReserveInformation_Get( strControlJob_startReserveInformation_Get_out,
//D7000178//D4000015                                                         strObjCommonIn,
//D7000178//D4000015                                                         controlJobID );
//D7000178//D4000015            if ( rc != RC_OK )
//D7000178//D4000015            {
//D7000178//D4000015                PPT_METHODTRACE_V1("", "controlJob_startReserveInformation_Get() != RC_OK") ;
//D7000178//D4000015                strOpeCompForInternalBufferReqResult.strResult = strControlJob_startReserveInformation_Get_out.strResult ;
//D7000178//D4000015                return( rc );
//D7000178//D4000015            }
//D7000178//D4000015 unnecessary end
//D7000178            //P4200492 add start
//D7000178            /*-------------------------------------------------------------------------------*/
//D7000178            /*   Get Started Lot information in order to get the derived / delta datavalues  */
//D7000178            /*   and also specCheckResult in case that CompletionMode is Auto.               */
//D7000178            /*-------------------------------------------------------------------------------*/
//D7000178            objControlJob_startReserveInformation_Get_out   strControlJob_startReserveInformation_Get_out;
//D7000178            rc = controlJob_startReserveInformation_Get( strControlJob_startReserveInformation_Get_out,
//D7000178                                                         strObjCommonIn,
//D7000178                                                         controlJobID );
//D7000178            if ( rc != RC_OK )
//D7000178            {
//D7000178                PPT_METHODTRACE_V1("", "controlJob_startReserveInformation_Get() != RC_OK") ;
//D7000178                strOpeCompForInternalBufferReqResult.strResult = strControlJob_startReserveInformation_Get_out.strResult ;
//D7000178                return( rc );
//D7000178            }
//D7000178            //P4200492 add end
//D7000178
//D7000178            strStartCassette = strControlJob_startReserveInformation_Get_out.strStartCassette;
//D7000178            spcCheckRequiredFlag = TRUE;
//D7000178
//D7000178        }
//D7000178        else if ( rc == RC_NO_NEED_SPEC_CHECK )
//D7000178        {
//D7000178            PPT_METHODTRACE_V1("", "txDataSpecCheckReq() == RC_NO_NEED_TO_SPECCHECK") ;
//D7000178            rc = RC_OK;
//D7000178
//D7000178//P6000204 add start
//D7000178            /*-------------------------------------------------------------------------------*/
//D7000178            /*   Get Started Lot information in order to get the derived / delta datavalues  */
//D7000178            /*   and also specCheckResult in case that CompletionMode is Auto.               */
//D7000178            /*-------------------------------------------------------------------------------*/
//D7000178            objControlJob_startReserveInformation_Get_out   strControlJob_startReserveInformation_Get_out;
//D7000178            rc = controlJob_startReserveInformation_Get( strControlJob_startReserveInformation_Get_out,
//D7000178                                                         strObjCommonIn,
//D7000178                                                         controlJobID);
//D7000178            if ( rc != RC_OK )
//D7000178            {
//D7000178                PPT_METHODTRACE_V1("", "controlJob_startReserveInformation_Get() != RC_OK") ;
//D7000178                strOpeCompForInternalBufferReqResult.strResult = strControlJob_startReserveInformation_Get_out.strResult ;
//D7000178                return( rc );
//D7000178            }
//D7000178            strStartCassette = strControlJob_startReserveInformation_Get_out.strStartCassette;
//D7000178//P6000204 add end
//D7000178
//D7000178        }
//D7000178//P6000062//P6000053 add start
//D7000178//P6000062        else if( rc == RC_NO_RESPONSE_APC       ||
//D7000178//P6000062                 rc == RC_APC_SERVER_BIND_FAIL  ||
//D7000178//P6000062                 rc == RC_APC_DERIVEDDATA_ERROR )
//D7000178//P6000062        {
//D7000178//P6000062            PPT_METHODTRACE_V1("", "txDataSpecCheckReq() == APC Error") ;
//D7000178//P6000062            strStartCassette = strDataSpecCheckReqResult.strStartCassette;
//D7000178//P6000062        }
//D7000178//P6000062//P6000053 add end
//D7000178        else
//D7000178        {
//D7000178            PPT_METHODTRACE_V1("", "txDataSpecCheckReq() != RC_OK") ;
//D7000178            strOpeCompForInternalBufferReqResult.strResult = strDataSpecCheckReqResult.strResult ;
//D7000178            return( rc );
//D7000178        }
//D7000178    }
//D7000178    else
//D7000178    {
//D7000178        /*----------------------------------------*/
//D7000178        /*   Judge SPC-Check is Required or Not   */
//D7000178        /*----------------------------------------*/
//D7000178        CORBA::Long nILen = strStartCassette.length();
//D7000178        for (CORBA::Long i=0 ; i<nILen; i++ )
//D7000178        {
//D7000178            CORBA::Long nJLen = strStartCassette[i].strLotInCassette.length();
//D7000178            for (CORBA::Long j=0 ; j<nJLen; j++ )
//D7000178            {
//D7000178                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
//D7000178                {
//D7000178                    continue;
//D7000178                }
//D7000178
//D7000178                CORBA::Long nKLen = strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef.length();
//D7000178                for (CORBA::Long k=0 ; k<nKLen ; k++ )
//D7000178                {
//D7000178                    if ( strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].specCheckRequiredFlag == TRUE )
//D7000178                    {
//D7000178                        spcCheckRequiredFlag = TRUE;
//D7000178                        break;
//D7000178                    }
//D7000178                }
//D7000178
//D7000178                /*===== quit [j] Loop =====*/
//D7000178                if ( spcCheckRequiredFlag == TRUE )
//D7000178                {
//D7000178                    break;
//D7000178                }
//D7000178            }
//D7000178
//D7000178            /*===== quit [i] Loop =====*/
//D7000178            if ( spcCheckRequiredFlag == TRUE )
//D7000178            {
//D7000178                break;
//D7000178            }
//D7000178        }
//D7000178
//D7000178    }
//D7000178
//D7000178    /*-------------------------*/
//D7000178    /*   SPC Check Procedure   */
//D7000178    /*-------------------------*/
//D7000178    if ( spcCheckRequiredFlag == TRUE )
//D7000178    {
//D7000178        /*----------------------------*/
//D7000178        /*   Send SPC Check Request   */
//D7000178        /*----------------------------*/
//D7000178        rc = txSpcCheckReq( strSpcCheckReqResult, strObjCommonIn, equipmentID, controlJobID, strStartCassette );
//D7000178        if ( rc == RC_OK || rc == RC_NO_NEED_TO_SPCCHECK )
//D7000178        {
//D7000178            PPT_METHODTRACE_V1("", "txSpcCheckReq() == RC_OK || RC_NO_NEED_TO_SPCCHECK") ;
//D7000178            rc = RC_OK;
//D7000178        }
//D7000178        else
//D7000178        {
//D7000178            PPT_METHODTRACE_V1("", "txSpcCheckReq() != RC_OK") ;
//D7000178            strOpeCompForInternalBufferReqResult.strResult = strSpcCheckReqResult.strResult ;
//D7000178            return( rc );
//D7000178        }
//D7000178    }
//D7000178
//D7000178
//D7000178    /*-----------------------------------------------------------------*/
//D7000178    /*   Summary Action Items to Lot based on the Spec Check Result    */
//D7000178    /*-----------------------------------------------------------------*/
//D7000178    objStartLot_actionList_EffectSpecCheck_out   strStartLot_actionList_EffectSpecCheck_out;
//D7000178    rc = startLot_actionList_EffectSpecCheck( strStartLot_actionList_EffectSpecCheck_out,
//D7000178                                              strObjCommonIn,
//D7000178                                              strStartCassette,
//D7000178                                              equipmentID );
//D7000178    if ( rc != RC_OK )
//D7000178    {
//D7000178        PPT_METHODTRACE_V1("", "startLot_actionList_EffectSpecCheck() != RC_OK") ;
//D7000178        strOpeCompForInternalBufferReqResult.strResult = strStartLot_actionList_EffectSpecCheck_out.strResult ;
//D7000178        return( rc );
//D7000178    }
//D7000178    /*-----------------------------------------------------------------------*/
//D7000178    /*   Register Entity Inhibition as the result of SPEC Check              */
//D7000178    /*-----------------------------------------------------------------------*/
//D7000178    CORBA::Long nLen = strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions.length();
//D7000178    PPT_METHODTRACE_V2("", "strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions.length()", nLen);
//D7000178    pptEntityInhibitReqResult strEntityInhibitReqResult;
//D7000178
//D7000178    for(i=0; i<nLen; i++)
//D7000178    {
//D7000178        rc = txEntityInhibitReq( strEntityInhibitReqResult,
//D7000178                                 strObjCommonIn,
//D7000178                                 strStartLot_actionList_EffectSpecCheck_out.strEntityInhibitions[i],
//D7000178                                 claimMemo );
//D7000178//P4100104        if ( rc != RC_OK)
//D7000178        if (( rc != RC_OK ) && ( rc != RC_DUPLICATE_INHIBIT ))    //P4100104
//D7000178        {
//D7000178            PPT_METHODTRACE_V1("", "txEntityInhibitReq() != RC_OK") ;
//D7000178            strOpeCompForInternalBufferReqResult.strResult = strEntityInhibitReqResult.strResult ;
//D7000178            return( rc );
//D7000178        }
//D7000178        PPT_METHODTRACE_V2("", "txEntityInhibitReq() rc = ", rc) ;//P4100104
//D7000178    }
//D7000178    /*-----------------------------------------------*/
//D7000178    /*   Send a message as the result of SPEC Check  */
//D7000178    /*-----------------------------------------------*/
//D7000178    nLen = strStartLot_actionList_EffectSpecCheck_out.strMessageList.length();
//D7000178    PPT_METHODTRACE_V2("", "strStartLot_actionList_EffectSpecCheck_out.strMessageList.length()",nLen) ;
//D7000178    objMessageDistributionMgr_PutMessage_out   strMessageDistributionMgr_PutMessage_out;
//D7000178
//D7000178    for(i=0; i<nLen; i++)
//D7000178    {
//D7000178        rc = MessageDistributionMgr_PutMessage( strMessageDistributionMgr_PutMessage_out,
//D7000178                                                strObjCommonIn,
//D7000178                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].messageID,
//D7000178                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].lotID,
//D7000178                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].lotStatus,
//D7000178                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].equipmentID,
//D7000178                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].routeID,
//D7000178                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].operationNumber,
//D7000178                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].reasonCode,
//D7000178                                                strStartLot_actionList_EffectSpecCheck_out.strMessageList[i].messageText );
//D7000178        if ( rc != RC_OK )
//D7000178        {
//D7000178            PPT_METHODTRACE_V1("", "MessageDistributionMgr_PutMessage() != RC_OK") ;
//D7000178            strOpeCompForInternalBufferReqResult.strResult = strMessageDistributionMgr_PutMessage_out.strResult ;
//D7000178            return( rc );
//D7000178        }
//D7000178    }
//D7000178    /*-----------------------------------------------------------------*/
//D7000178    /*   Summary Action Items to Lot based on the SPC Check Result     */
//D7000178    /*-----------------------------------------------------------------*/
//D7000178    objStartLot_actionList_EffectSPCCheck_out   strStartLot_actionList_EffectSPCCheck_out;
//D7000178    rc = startLot_actionList_EffectSPCCheck( strStartLot_actionList_EffectSPCCheck_out,
//D7000178                                             strObjCommonIn,
//D7000178                                             strSpcCheckReqResult.strSpcCheckLot,
//D7000178                                             equipmentID );
//D7000178    if ( rc != RC_OK )
//D7000178    {
//D7000178        PPT_METHODTRACE_V1("", "strStartLot_actionList_EffectSPCCheck_out() != RC_OK") ;
//D7000178        strOpeCompForInternalBufferReqResult.strResult = strStartLot_actionList_EffectSPCCheck_out.strResult ;
//D7000178        return( rc );
//D7000178    }
//D7000178
//D7000178    /*-----------------------------------------------------------------------*/
//D7000178    /*   Register Entity Inhibition as the result of SPC Check               */
//D7000178    /*-----------------------------------------------------------------------*/
//D7000178    CORBA::Long nSpcLen = strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length();
//D7000178    PPT_METHODTRACE_V2("","strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions.length()",nLen) ;
//D7000178    pptEntityInhibitReqResult strSpcEntityInhibitReqResult;
//D7000178
//D7000178    for(i=0; i<nSpcLen; i++)
//D7000178    {
//D7000178        rc = txEntityInhibitReq( strSpcEntityInhibitReqResult,
//D7000178                                 strObjCommonIn,
//D7000178                                 strStartLot_actionList_EffectSPCCheck_out.strEntityInhibitions[i],
//D7000178                                 claimMemo );
//D7000178
//D7000178//P4100104        if ( rc != RC_OK)
//D7000178        if (( rc != RC_OK ) && ( rc != RC_DUPLICATE_INHIBIT ))    //P4100104
//D7000178        {
//D7000178            PPT_METHODTRACE_V1("", "txEntityInhibitReq() != RC_OK") ;
//D7000178            strOpeCompForInternalBufferReqResult.strResult = strSpcEntityInhibitReqResult.strResult ;
//D7000178            return( rc );
//D7000178        }
//D7000178        PPT_METHODTRACE_V2("", "txEntityInhibitReq() rc = ", rc) ;//P4100104
//D7000178    }
//D7000178
//D7000178    /*-----------------------------------------------*/
//D7000178    /*   Send a message as the result of SPC Check   */
//D7000178    /*-----------------------------------------------*/
//D7000178    nLen = strStartLot_actionList_EffectSPCCheck_out.strMessageList.length();
//D7000178    PPT_METHODTRACE_V2("", "strStartLot_actionList_EffectSPCCheck_out.strMessageList.length()",nLen) ;
//D7000178
//D7000178    for(i=0; i<nLen; i++)
//D7000178    {
//D7000178        rc = MessageDistributionMgr_PutMessage( strMessageDistributionMgr_PutMessage_out,
//D7000178                                                strObjCommonIn,
//D7000178                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].messageID,
//D7000178                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].lotID,
//D7000178                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].lotStatus,
//D7000178                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].equipmentID,
//D7000178                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].routeID,
//D7000178                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].operationNumber,
//D7000178                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].reasonCode,
//D7000178                                                strStartLot_actionList_EffectSPCCheck_out.strMessageList[i].messageText );
//D7000178        if ( rc != RC_OK )
//D7000178        {
//D7000178            PPT_METHODTRACE_V1("", "MessageDistributionMgr_PutMessage() != RC_OK") ;
//D7000178            strOpeCompForInternalBufferReqResult.strResult = strMessageDistributionMgr_PutMessage_out.strResult ;
//D7000178            return( rc );
//D7000178        }
//D7000178    }
//DSN000043340 Add Start
    /*---------------------------------------------------------------------*/
    /*   In case of post process migration mode, fix PostProcForLotFlag    */
    /*---------------------------------------------------------------------*/
    if ( -1 == PostProcForLotFlag )
    {
        PPT_METHODTRACE_V1("", "Post Process Migration Mode");
        /*----------------------------------------------------------------------*/
        /*   In case of post process migration mode, check value in FSCONFIG    */
        /*----------------------------------------------------------------------*/
        objConfigurationInformation_GetDR_out strConfigurationInformation_GetDR_out;
        objConfigurationInformation_GetDR_in  strConfigurationInformation_GetDR_in;
        strConfigurationInformation_GetDR_in.objectKey = equipmentID.identifier;
        strConfigurationInformation_GetDR_in.category  = CIMFWStrDup(SP_ConfigurationCategory_EquipmentPostProcDecoupleMode);
        rc = configurationInformation_GetDR( strConfigurationInformation_GetDR_out,
                                             strObjCommonIn,
                                             strConfigurationInformation_GetDR_in );
        if( rc != RC_OK && rc != RC_NOT_FOUND_ENTRY )
        {
            PPT_METHODTRACE_V2("", "configurationInformation_GetDR() != RC_OK, RC_NOT_FOUND_ENTRY", rc);
            strOpeCompForInternalBufferReqResult.strResult = strConfigurationInformation_GetDR_out.strResult;
            return( rc );
        }

        if ( rc == RC_NOT_FOUND_ENTRY )
        {
            // rc == RC_NOT_FOUND_ENTRY
            PPT_METHODTRACE_V1("","Entry isn't found in FSCONFIG");
            PostProcForLotFlag = 0;
        }
        else
        {
            // rc == RC_OK
            // Check FSCONFIG.VALUE
            if ( 0 == CIMFWStrCmp(strConfigurationInformation_GetDR_out.strConfigInfo.value, "1") )
            {
                PPT_METHODTRACE_V1("","EquipmentPostProcActionDecoupleMode = 1");
                PostProcForLotFlag = 1;
            }
            else
            {
                PPT_METHODTRACE_V1("","EquipmentPostProcActionDecoupleMode != 1");
                PostProcForLotFlag = 0;
            }
        }

        // Store PostProcForLotFlag as thread specific data
        char* methodName = NULL;
        try
        {
            char strPostProcForLotFlag[4];
            memset( strPostProcForLotFlag, '\0', sizeof(strPostProcForLotFlag) );
            sprintf( strPostProcForLotFlag, "%d", PostProcForLotFlag );
            methodName = CIMFWStrDup("setThreadSpecificDataString");
            setThreadSpecificDataString (SP_ThreadSpecificData_Key_PostProcForLotFlag, strPostProcForLotFlag);
            CORBA::string_free(methodName);
            methodName = NULL;
        }
        CATCH_GLOBAL_EXCEPTIONS(strOpeCompForInternalBufferReqResult, txOpeCompForInternalBufferReq__120, methodName);
    }
//DSN000043340 Add End
    /*--------------------------------*/
    /*                                */
    /*   CP Test Function Procedure   */
    /*                                */
    /*--------------------------------*/
    CORBA::Long nLen = 0;    //D7000178
    for ( i=0 ; i<scLen ; i++ )
    {
        nLen = strStartCassette[i].strLotInCassette.length();
        for (CORBA::Long j=0; j<nLen; j++)
        {
            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                continue;
            }
            /*-----------------------------------------*/
            /*   Check Test Type of Current Process    */
            /*-----------------------------------------*/
            objLot_testTypeID_Get_out   strLot_testTypeID_Get_out;
            rc = lot_testTypeID_Get( strLot_testTypeID_Get_out,
                                     strObjCommonIn,
                                     strStartCassette[i].strLotInCassette[j].lotID );
            if ( rc != RC_OK && rc != RC_NOT_FOUND_TESTTYPE )
            {
                PPT_METHODTRACE_V1("", "lot_testTypeID_Get() != RC_OK") ;
                strOpeCompForInternalBufferReqResult.strResult = strLot_testTypeID_Get_out.strResult ;
                return( rc );
            }
            if ( CIMFWStrLen(strLot_testTypeID_Get_out.testTypeID.identifier) > 0 )
            {
                /*---------------------------------------------------------------*/
                /*   Gather Bin Summary Information based on lotID & testTypeID  */
                /*---------------------------------------------------------------*/
                objBinSummary_GetByTestTypeDR_out   strBinSummary_GetByTestTypeDR_out;
                rc = binSummary_GetByTestTypeDR( strBinSummary_GetByTestTypeDR_out,
                                                 strObjCommonIn,
                                                 strStartCassette[i].strLotInCassette[j].lotID,
                                                 strLot_testTypeID_Get_out.testTypeID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "binSummary_GetByTestTypeDR() != RC_OK") ;
                    strOpeCompForInternalBufferReqResult.strResult = strBinSummary_GetByTestTypeDR_out.strResult ;
                    return( rc );
                }
                /*----------------------------------------------------------*/
                /*   Update Wafer Die quantity based on the input parameter  */
                /*-----------------------------------------------------------*/
                CORBA::Long bsLen = 0;
                bsLen = strBinSummary_GetByTestTypeDR_out.strWaferBinSummary.length();
                PPT_METHODTRACE_V2("", "strBinSummary_GetByTestTypeDR_out.strWaferBinSummary.length()", bsLen);

                pptLotWaferAttributesSequence strLotWaferAttributes ;
                strLotWaferAttributes.length(bsLen) ;

                for(CORBA::Long k=0; k<bsLen; k++)
                {
                    if(strBinSummary_GetByTestTypeDR_out.strWaferBinSummary[k].binReportCount)
                    {
                        strLotWaferAttributes[k].waferID         = strBinSummary_GetByTestTypeDR_out.strWaferBinSummary[k].waferID ;
                        strLotWaferAttributes[k].goodUnitCount   = strBinSummary_GetByTestTypeDR_out.strWaferBinSummary[k].goodUnitCount ;
                        strLotWaferAttributes[k].repairUnitCount = strBinSummary_GetByTestTypeDR_out.strWaferBinSummary[k].repairUnitCount ;
                        strLotWaferAttributes[k].failUnitCount   = strBinSummary_GetByTestTypeDR_out.strWaferBinSummary[k].failUnitCount ;
                    }
                }
                objLot_wafer_ChangeDie_out   strLot_wafer_ChangeDie_out;
                rc = lot_wafer_ChangeDie( strLot_wafer_ChangeDie_out,
                                          strObjCommonIn,
                                          strStartCassette[i].strLotInCassette[j].lotID,
                                          strLotWaferAttributes );
                if ( rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "lot_wafer_ChangeDie() != RC_OK") ;
                    strOpeCompForInternalBufferReqResult.strResult = strLot_wafer_ChangeDie_out.strResult ;
                    return( rc );
                }
            }
        }
    }

    /*------------------------------------------------------*/
    /*                                                      */
    /*     FlowBatch Related Information Update Procedure   */
    /*                                                      */
    /*------------------------------------------------------*/
    /*----------------------------------------------------------*/
    /*   Update FlowBatch Information of Equipment              */
    /*----------------------------------------------------------*/
    objFlowBatch_Information_UpdateByOpeComp_out   strFlowBatch_Information_UpdateByOpeComp_out;
    rc = flowBatch_Information_UpdateByOpeComp( strFlowBatch_Information_UpdateByOpeComp_out,
                                                strObjCommonIn,
                                                equipmentID,
                                                strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "flowBatch_information_UpdateByOpeComp() != RC_OK") ;
        strOpeCompForInternalBufferReqResult.strResult = strFlowBatch_Information_UpdateByOpeComp_out.strResult ;
        return( rc );
    }
    /*----------------------------------------------*/
    /*                                              */
    /*   Process Operation Update Procedure         */
    /*                                              */
    /*----------------------------------------------*/
    /*-------------------------------------------------*/
    /*   Update Process Operation (actual comp xxxx)   */
    /*-------------------------------------------------*/
    objProcess_actualCompInformation_Set_out   strProcess_actualCompInformation_Set_out;
    rc = process_actualCompInformation_Set( strProcess_actualCompInformation_Set_out,
                                            strObjCommonIn,
                                            strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "process_actualCompInformation_Set() != RC_OK") ;
        strOpeCompForInternalBufferReqResult.strResult = strProcess_actualCompInformation_Set_out.strResult ;
        return( rc );
    }

//INN-R170009 Add start
    if ( CIMFWStrCmp(getenv("APC_AVAILABLE"),"1" ) == 0 )
    {
        PPT_METHODTRACE_V1("", "if ( CIMFWStrCmp(getenv(APC_AVAILABLE),\"1\" ) == 0 )");

        csObjAPC_LotEventQueue_Make_out  strObjAPC_LotEventQueue_Make_out;
        csObjAPC_LotEventQueue_Make_in   strObjAPC_LotEventQueue_Make_in;

        strObjAPC_LotEventQueue_Make_in.equipmentID = equipmentID;
        strObjAPC_LotEventQueue_Make_in.controlJobID = controlJobID;
        strObjAPC_LotEventQueue_Make_in.strStartCassette = strControlJob_startReserveInformation_Get_out.strStartCassette;

        rc = cs_APC_LotEventQueue_Make( strObjAPC_LotEventQueue_Make_out,
                                        strObjCommonIn,
                                        strObjAPC_LotEventQueue_Make_in);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cs_APC_LotEventQueue_Make() != RC_OK");
            strOpeCompForInternalBufferReqResult.strResult = strObjAPC_LotEventQueue_Make_out.strResult;
            return( rc );
        }
    }
//INN-R170009 Add end

//PSIV00000888 add start
    if( PostProcForLotFlag != 1 )
    {
//PSIV00000888 add end
        /*-------------------------------------------------*/
        /*   Make Measurement & Process Data History       */
        /*-------------------------------------------------*/
        objCollectedDataEvent_Make_out  strCollectedDataEvent_Make_out;
        rc = collectedDataEvent_Make( strCollectedDataEvent_Make_out,
                                      strObjCommonIn,
//D4000015 0.02                   "TXTRC004",
//INN-R170085                                      "TXTRC055", //D4000015 0.02
//INN-R170085 Start
                                      "TXTRC055P",
//INN-R170085 End
                                      strStartCassette,
                                      controlJobID,
                                      equipmentID,
                                      claimMemo );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "collectedDataEvent_Make() != RC_OK") ;
            strOpeCompForInternalBufferReqResult.strResult = strCollectedDataEvent_Make_out.strResult ;
             return( rc );
        }
//PSIV00000888 add start
    }
//PSIV00000888 add end

//DSIV00000201 add start
    objLot_futureHoldRequests_EffectByCondition_outSequence strLot_futureHoldRequests_EffectByCondition_outSequence;
    CORBA::Long fHCnt = 0;
    objectIdentifier releaseReasonCodeID ;
    releaseReasonCodeID.identifier = CIMFWStrDup( SP_Reason_GatePass ) ;

    if( PostProcForLotFlag != 1 )
    {
//DSIV00000201 add end
        /*-------------------------------------------*/
        /*   Delete Effected Future Hold Direction   */
        /*-------------------------------------------*/
//DSIV00000201        objectIdentifier releaseReasonCodeID ;
//DSIV00000201        releaseReasonCodeID.identifier = CIMFWStrDup( SP_Reason_GatePass ) ;

//DSIV00000201        CORBA::Long fHCnt = 0;  //D4100083
//DSIV00000201        objLot_futureHoldRequests_EffectByCondition_outSequence strLot_futureHoldRequests_EffectByCondition_outSequence;  //D4100083
//D4100083 (03/07)    strLot_futureHoldRequests_EffectByCondition_outSequence.length( scLen );  //D4100083
        strLot_futureHoldRequests_EffectByCondition_outSequence.length( totalStartLotCount );  //D4100083 (03/07)

        for ( i=0 ; i<scLen ; i++ )
        {
            nLen = strStartCassette[i].strLotInCassette.length();
            for (CORBA::Long j=0 ; j<nLen; j++)
            {
                /*---------------------------*/
                /*   Omit Not-OpeStart Lot   */
                /*---------------------------*/
                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    continue;
                }
//D4100083 Add Start
                PPT_METHODTRACE_V2("", "i",i);
                PPT_METHODTRACE_V2("", "j",j);
                PPT_METHODTRACE_V2("", "strStartCassette[i].strLotInCassette[j].lotID",strStartCassette[i].strLotInCassette[j].lotID.identifier);

                /*-------------------------------*/
                /*   Get Effected Future Hold    */
                /*-------------------------------*/
                PPT_METHODTRACE_V1("", "Get Effected Future Hold") ;
                pptEffectCondition strEffectCondition;
                strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_POST );
                strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_ALL );

                rc = lot_futureHoldRequests_EffectByCondition( strLot_futureHoldRequests_EffectByCondition_outSequence[fHCnt],
                                                               strObjCommonIn,
                                                               strStartCassette[i].strLotInCassette[j].lotID,
                                                               strEffectCondition);
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_futureHoldRequests_EffectByCondition() != RC_OK") ;
                    strOpeCompForInternalBufferReqResult.strResult = strLot_futureHoldRequests_EffectByCondition_outSequence[fHCnt].strResult ;
                    return( rc );
                }

                fHCnt++;

                /*-------------------------------------------*/
                /*   Delete Effected Future Hold Direction   */
                /*-------------------------------------------*/
                strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_ALL );
                strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_ALL );

                objLot_futureHoldRequests_DeleteEffectedByCondition_out strLot_futureHoldRequests_DeleteEffectedByCondition_out;
                rc = lot_futureHoldRequests_DeleteEffectedByCondition( strLot_futureHoldRequests_DeleteEffectedByCondition_out,
                                                                       strObjCommonIn,
                                                                       strStartCassette[i].strLotInCassette[j].lotID,
                                                                       strEffectCondition );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_futureHoldRequests_DeleteEffectedByCondition() != RC_OK") ;
                    strOpeCompForInternalBufferReqResult.strResult = strLot_futureHoldRequests_DeleteEffectedByCondition_out.strResult ;
                    return( rc );
                }

//D4100083 Add End

                /*-------------------------------------------*/
                /*   Delete Effected Future Hold Direction   */
                /*-------------------------------------------*/
//D4100083            objLot_futureHoldRequests_DeleteEffected_out    strLot_futureHoldRequests_DeleteEffected_out;

//D4100069            objLot_CheckForLCFR_out strLot_CheckForLCFR_out;
//D4100069            rc = lot_CheckForLCFR( strLot_CheckForLCFR_out,
//D4100069                                   strObjCommonIn,
//D4100069                                   strStartCassette[i].strLotInCassette[j].lotID,
//D4100069                                   SP_LotCustomize_DBRECORD );
//D4100069            if ( rc != RC_OK )
//D4100069            {
//D4100069                PPT_METHODTRACE_V2("", "lot_CheckForLCFR() != RC_OK", rc);
//D4100083                rc = lot_futureHoldRequests_DeleteEffected(strLot_futureHoldRequests_DeleteEffected_out, strObjCommonIn, strStartCassette[i].strLotInCassette[j].lotID) ;
//D4100083                if(rc != RC_OK)
//D4100083                {
//D4100083                    PPT_METHODTRACE_V1("", "lot_futureHoldRequests_DeleteEffected() != RC_OK") ;
//D4100083                    strOpeCompForInternalBufferReqResult.strResult = strLot_futureHoldRequests_DeleteEffected_out.strResult ;
//D4100083                    return(rc);
//D4100083                }

//D4100069            }
//D4100069            else
//D4100069            {
//D4100069                PPT_METHODTRACE_V1("", "lot_CheckForLCFR() == RC_OK");
//D4100069
//D4100069                objLot_futureHoldRequests_DeleteEffectedForLCFR_out  strLot_futureHoldRequests_DeleteEffectedForLCFR_out;
//D4100069                rc = lot_futureHoldRequests_DeleteEffectedForLCFR( strLot_futureHoldRequests_DeleteEffectedForLCFR_out, strObjCommonIn, strStartCassette[i].strLotInCassette[j].lotID );
//D4100069                if ( rc == RC_OK )
//D4100069                {
//D4100069                    PPT_METHODTRACE_V1("", "lot_futureHoldRequests_DeleteEffectedForLCFR() == RC_OK");
//D4100069                    strLot_futureHoldRequests_DeleteEffected_out.strFutureHoldReleaseReqList = strLot_futureHoldRequests_DeleteEffectedForLCFR_out.strFutureHoldReleaseReqList;
//D4100069                }
//D4100069                else if ( rc != RC_OPENO_DELETED && rc != RC_ROUTEID_DELETED )
//D4100069                {
//D4100069                    PPT_METHODTRACE_V2("", "lot_futureHoldRequests_DeleteEffectedForLCFR() != RC_OK", rc);
//D4100069                    strOpeCompForInternalBufferReqResult.strResult = strLot_futureHoldRequests_DeleteEffectedForLCFR_out.strResult;
//D4100069                    return( rc );
//D4100069                }
//D4100069                PPT_METHODTRACE_V2("", "lot_futureHoldRequests_DeleteEffectedForLCFR() = ", rc);
//D4100069
//D4100069            }

                // Pass hold cancel record list
                if ( strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList.length() > 0 )  //D4100083
    ////D4100083            if ( strLot_futureHoldRequests_DeleteEffected_out.strFutureHoldReleaseReqList.length() > 0 )
                {
                    pptFutureHoldCancelReqResult strFutureHoldCancelReqResult ;
                    rc = txFutureHoldCancelReq( strFutureHoldCancelReqResult,
                                                strObjCommonIn,
                                                strStartCassette[i].strLotInCassette[j].lotID,
                                                releaseReasonCodeID,
                                                SP_EntryType_Remove,
                                                strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList);  //D4100083
//D4100083                                            strLot_futureHoldRequests_DeleteEffected_out.strFutureHoldReleaseReqList );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "txFutureHoldCancelReq() != RC_OK") ;
                        strOpeCompForInternalBufferReqResult.strResult = strFutureHoldCancelReqResult.strResult ;
                        return( rc );
                    }
                }
            }
        }

        strLot_futureHoldRequests_EffectByCondition_outSequence.length( fHCnt );  //D4100083
//DSIV00000201 add start
    }
//DSIV00000201 add end

    /*------------------------------------------------------------*/
    /*                                                            */
    /*   Reticle / Fixture Related Information Update Procedure   */
    /*                                                            */
    /*------------------------------------------------------------*/

    CORBA::Long usedReticleSeqLen = 0;
    CORBA::Long usedFixtureSeqLen = 0;
    /*--------------------------------------------------------*/
    /*   Check ProcessDurable was Used for Operation or Not   */
    /*--------------------------------------------------------*/
    objEquipment_processDurableRequiredFlag_Get_out   strEquipment_processDurableRequiredFlag_Get_out;
    rc = equipment_processDurableRequiredFlag_Get( strEquipment_processDurableRequiredFlag_Get_out,
                                                   strObjCommonIn,
                                                   equipmentID );
    CORBA::Long saveRC = rc;
    if ( rc == RC_EQP_PROCDRBL_NOT_REQD )
    {
        PPT_METHODTRACE_V1("", "equipment_processDurableRequiredFlag_Get() == RC_EQP_PROCDRBL_NOT_REQD") ;
        rc = RC_OK;
    }
    else if ( rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD )
    {
        PPT_METHODTRACE_V1("", "equipment_processDurableRequiredFlag_Get() == RC_EQP_PROCDRBL_RTCL_REQD || RC_EQP_PROCDRBL_FIXT_REQD") ;
        for ( i=0 ; i<scLen ; i++ )
        {
            nLen = strStartCassette[i].strLotInCassette.length();
            for (CORBA::Long j=0; j<nLen; j++)
            {
                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    continue;
                }

                if ( saveRC == RC_EQP_PROCDRBL_RTCL_REQD )
                {
                    /*-------------------------------*/
                    /*   Get Used Reticles for Lot   */
                    /*-------------------------------*/
                    objProcess_assignedReticle_Get_out   strProcess_assignedReticle_Get_out;
                    rc = process_assignedReticle_Get( strProcess_assignedReticle_Get_out,
                                                      strObjCommonIn,
                                                      strStartCassette[i].strLotInCassette[j].lotID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "process_assignedReticle_Get() != RC_OK") ;
                        strOpeCompForInternalBufferReqResult.strResult = strProcess_assignedReticle_Get_out.strResult ;
                        return( rc );
                    }

                    usedReticleSeqLen = strProcess_assignedReticle_Get_out.strStartReticle.length();
                    PPT_METHODTRACE_V2("", "strProcess_assignedReticle_Get_out.strStartReticle.length()", usedReticleSeqLen );

                    for (CORBA::Long k=0; k<usedReticleSeqLen; k++)
                    {
//INN-R170003 Add Start
                        //objReticle_usageLimitation_Check_out   strReticle_usageLimitation_Check_out;
                        //rc = reticle_usageLimitation_Check( strReticle_usageLimitation_Check_out,
                        //                                    strObjCommonIn,
                        //                                    strProcess_assignedReticle_Get_out.strStartReticle[k].reticleID );
                        //if ( rc != RC_OK )
                        //{
                        //    PPT_METHODTRACE_V1("", "reticle_usageLimitation_Check() != RC_OK") ;
                        //    strOpeCompForInternalBufferReqResult.strResult = strReticle_usageLimitation_Check_out.strResult ;
                        //    return( rc );
                        //}
                        //
                        //if ( strReticle_usageLimitation_Check_out.usageLimitOverFlag == TRUE )
                        //{
                        //    PPT_METHODTRACE_V1("", "strReticle_usageLimitation_Check_out.usageLimitOverFlag == TRUE") ;
                        //
                        //    /*-------------------------*/
                        //    /*   Call System Message   */
                        //    /*-------------------------*/
                        //    pptSystemMsgRptResult strSystemMsgRptResult;
                        //    objectIdentifier      dummy;
                        //
                        //    rc = txSystemMsgRpt( strSystemMsgRptResult,
                        //                         strObjCommonIn,
                        //                         SP_SubSystemID_MM,
                        //                         SP_SystemMsgCode_RtclUsageLimitOver,
                        //                         strReticle_usageLimitation_Check_out.messageText,
                        //                         TRUE,
                        //                         dummy,
                        //                         "",
                        //                         dummy,
                        //                         "",
                        //                         dummy,
                        //                         "",
                        //                         dummy,
                        //                         "",
                        //                         dummy,
                        //                         dummy,
                        //                         "",
                        //                         strObjCommonIn.strTimeStamp.reportTimeStamp,
                        //                         "" );
                        //    if ( rc != RC_OK )
                        //    {
                        //        PPT_METHODTRACE_V1("", "txSystemMsgRpt() != RC_OK") ;
                        //        strOpeCompForInternalBufferReqResult.strResult = strSystemMsgRptResult.strResult ;
                        //        return( rc );
                        //    }
                        //}
//INN-R170003 Add End 
//D9000084 add start
                        /*---------------------------------------------*/
                        /*  Set last used time stamp for used reticle  */
                        /*---------------------------------------------*/
                        objReticle_lastUsedTime_Set_out strReticle_lastUsedTime_Set_out;
                        objReticle_lastUsedTime_Set_in  strReticle_lastUsedTime_Set_in;
                        strReticle_lastUsedTime_Set_in.reticleID = strProcess_assignedReticle_Get_out.strStartReticle[k].reticleID;
                        strReticle_lastUsedTime_Set_in.lastUsedTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);
                        rc = reticle_lastUsedTime_Set( strReticle_lastUsedTime_Set_out, strObjCommonIn,
                                                       strReticle_lastUsedTime_Set_in );
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "reticle_lastUsedTime_Set() != RC_OK") ;
                            strOpeCompForInternalBufferReqResult.strResult = strReticle_lastUsedTime_Set_out.strResult ;
                            return( rc );
                        }
//D9000084 add end
                    }
                }
                else
                {
                    /*------------------------------*/
                    /*   Get Used Fixture for Lot   */
                    /*------------------------------*/
                    objProcess_assignedFixture_Get_out   strProcess_assignedFixture_Get_out;
                    rc = process_assignedFixture_Get( strProcess_assignedFixture_Get_out,
                                                      strObjCommonIn,
                                                      strStartCassette[i].strLotInCassette[j].lotID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "process_assignedFixture_Get() != RC_OK") ;
                        strOpeCompForInternalBufferReqResult.strResult = strProcess_assignedFixture_Get_out.strResult ;
                        return( rc );
                    }

                    usedFixtureSeqLen = strProcess_assignedFixture_Get_out.strStartFixture.length();
                    PPT_METHODTRACE_V2("", "strProcess_assignedFixture_Get_out.strStartFixture.length()", usedFixtureSeqLen );

                    /*------------------------------------*/
                    /*   Fixture Usage Limitation Check   */
                    /*------------------------------------*/
                    for (CORBA::Long k=0; k<usedFixtureSeqLen; k++)
                    {
                        objFixture_usageLimitation_Check_out   strFixture_usageLimitation_Check_out;
                        strFixture_usageLimitation_Check_out.usageLimitOverFlag = FALSE;
                        rc = fixture_usageLimitation_Check( strFixture_usageLimitation_Check_out,
                                                            strObjCommonIn,
                                                            strProcess_assignedFixture_Get_out.strStartFixture[k].fixtureID );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "fixture_usageLimitation_Check() != RC_OK") ;
                            strOpeCompForInternalBufferReqResult.strResult = strFixture_usageLimitation_Check_out.strResult ;
                            return( rc );
                        }

                        if ( strFixture_usageLimitation_Check_out.usageLimitOverFlag == TRUE )
                        {
                            PPT_METHODTRACE_V1("", "strFixture_usageLimitation_Check_out.usageLimitOverFlag == TRUE");

                            /*-------------------------*/
                            /*   Call System Message   */
                            /*-------------------------*/
                            pptSystemMsgRptResult strSystemMsgRptResult;
                            objectIdentifier      dummy;

                            rc = txSystemMsgRpt( strSystemMsgRptResult,
                                                 strObjCommonIn,
                                                 SP_SubSystemID_MM,
                                                 SP_SystemMsgCode_FixtUsageLimitOver,
                                                 strFixture_usageLimitation_Check_out.messageText,
                                                 TRUE,
                                                 dummy,
                                                 "",
                                                 dummy,
                                                 "",
                                                 dummy,
                                                 "",
                                                 dummy,
                                                 "",
                                                 dummy,
                                                 dummy,
                                                 "",
                                                 strObjCommonIn.strTimeStamp.reportTimeStamp,
                                                 "" );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("", "txSystemMsgRpt() != RC_OK") ;
                                strOpeCompForInternalBufferReqResult.strResult = strSystemMsgRptResult.strResult ;
                                return( rc );
                            }
                        }
                    }
                }
            }
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "equipment_processDurableRequiredFlag_Get() != RC_OK") ;
        strOpeCompForInternalBufferReqResult.strResult = strEquipment_processDurableRequiredFlag_Get_out.strResult ;
        return( rc );
    }

    /*----------------------------------------------*/
    /*                                              */
    /*   Lot Related Information Update Procedure   */
    /*                                              */
    /*----------------------------------------------*/
//DSIV00000201 add start
    if( PostProcForLotFlag != 1 )
    {
//DSIV00000201 add end
        /*---------------------------------*/
        /*   Set/Clear Q-Time Management   */
        /*---------------------------------*/
        objQtime_SetClearByOpeComp_out   strQtime_SetClearByOpeComp_out;
        rc = qtime_SetClearByOpeComp( strQtime_SetClearByOpeComp_out, strObjCommonIn, strStartCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "qtime_SetClearByOpeComp() != RC_OK") ;
            strOpeCompForInternalBufferReqResult.strResult = strQtime_SetClearByOpeComp_out.strResult ;
            return( rc );
        }

//D7000354 Add Start
        //--------------------------------------------------
        // Reset Q-Time actions
        //--------------------------------------------------
        objectIdentifier  resetReasonCodeID;
        resetReasonCodeID.identifier = CIMFWStrDup( SP_Reason_QTimeClear );

        CORBA::Long  resetLen = strQtime_SetClearByOpeComp_out.strActionResetList.length();
        for( CORBA::Long  resetCnt = 0; resetCnt < resetLen; resetCnt++ )
        {
            pptQTimeActionRegistInfo  strResetAction = strQtime_SetClearByOpeComp_out.strActionResetList[resetCnt];

            //----- Lot Hold Actions -------//
            if( strResetAction.strLotHoldList.length() > 0 )
            {
                PPT_METHODTRACE_V1("", "The lot hold actions to reset was found.");

                pptHoldLotReleaseReqResult  strHoldLotReleaseReqResult;
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, strResetAction.lotID, resetReasonCodeID, strResetAction.strLotHoldList );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "txHoldLotReleaseReq() != RC_OK");
                    strOpeCompForInternalBufferReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return rc;
                }
            }

            //----- Future Hold Actions -------//
            if( strResetAction.strFutureHoldList.length() > 0 )
            {
                PPT_METHODTRACE_V1("", "The future hold actions to cancel was found.");

                pptFutureHoldCancelReqResult  strFutureHoldCancelReqResult;
                rc = txFutureHoldCancelReq( strFutureHoldCancelReqResult, strObjCommonIn, strResetAction.lotID, resetReasonCodeID,
                                            SP_EntryType_Cancel, strResetAction.strFutureHoldList );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "txFutureHoldCancelReq() != RC_OK");
                    strOpeCompForInternalBufferReqResult.strResult = strFutureHoldCancelReqResult.strResult;
                    return rc;
                }
            }

            //----- Future Rework Actions -------//
            CORBA::Long  cancelLen = strResetAction.strFutureReworkList.length();
            if( cancelLen > 0 )
            {
                PPT_METHODTRACE_V2("", "The future rework actions to cancel was found.", cancelLen);

                for( CORBA::Long  cancelCnt = 0; cancelCnt < cancelLen; cancelCnt++ )
                {
                    pptFutureReworkInfo  strFutureRework = strResetAction.strFutureReworkList[cancelCnt];

                    pptFutureReworkCancelReqResult  strFutureReworkCancelReqResult;
                    rc = txFutureReworkCancelReq( strFutureReworkCancelReqResult, strObjCommonIn, strFutureRework.lotID, strFutureRework.routeID,
                                                  strFutureRework.operationNumber, strFutureRework.strFutureReworkDetailInfoSeq, "" );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "txFutureReworkCancelReq() != RC_OK");
                        strOpeCompForInternalBufferReqResult.strResult = strFutureReworkCancelReqResult.strResult;
                        return rc;
                    }
                }
            }
        }
//D7000354 Add End
//DSIV00000201 add start
    }
//DSIV00000201 add end

    /*-----------------------------------------*/
    /*   Change Lot Process State to Waiting   */
    /*-----------------------------------------*/
    objLot_processState_MakeWaiting_out   strLot_processState_MakeWaiting_out;
    rc = lot_processState_MakeWaiting( strLot_processState_MakeWaiting_out,
                                       strObjCommonIn,
                                       strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_processState_MakeWaiting() != RC_OK") ;
        strOpeCompForInternalBufferReqResult.strResult = strLot_processState_MakeWaiting_out.strResult ;
        return( rc );
    }

    /*-----------------------------------------------------------------------*/
    /*   Procedure for PO Moving                                             */
    /*-----------------------------------------------------------------------*/
    CORBA::Long lotcount = 0;
    for ( i=0 ; i<scLen ; i++ )
    {
        nLen = strStartCassette[i].strLotInCassette.length();
        PPT_METHODTRACE_V2("", "strStartCassette[i].strLotInCassette.length()",nLen) ;
        lotcount = lotcount + nLen;
    }
    PPT_METHODTRACE_V2("","lotcount", lotcount );
//PSIV00001188    objectIdentifierSequence autoBankInLotIDs;
//PSIV00001188    autoBankInLotIDs.length(lotcount);

//DSIV00000201 add start
    objectIdentifierSequence opeStartLotIDs;
    opeStartLotIDs.length(lotcount);
    CORBA::Long opeStartLotCount = 0;
//DSIV00000201 add end

    lotcount = 0;
    for ( i=0 ; i<scLen ; i++ )
    {
        nLen = strStartCassette[i].strLotInCassette.length();
        for (CORBA::Long j=0 ; j<nLen; j++ )
        {
            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                continue;
            }

//INN-R170002 Add Start
            csObjLot_ContaminationInfo_Set_in  strLot_ContaminationInfo_Set_in;
            strLot_ContaminationInfo_Set_in.lotID = strStartCassette[i].strLotInCassette[j].lotID;
            
            csObjLot_ContaminationInfo_Set_out strLot_ContaminationInfo_Set_out;
            rc = cs_lot_ContaminationInfo_Set( strLot_ContaminationInfo_Set_out,
                                               strObjCommonIn,
                                               strLot_ContaminationInfo_Set_in );
            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V2("", "lot_currentOperationInfo_Get() != RC_OK", rc);
                strOpeCompForInternalBufferReqResult.strResult = strLot_ContaminationInfo_Set_out.strResult ;
                return (rc) ;
            }
//INN-R170002 Add End
//INN-R170003 Start
            csObjUserData_GetByLotOperation_in strUserData_GetByLotOperation_in;
            strUserData_GetByLotOperation_in.lotID = strStartCassette[i].strLotInCassette[j].lotID;
            strUserData_GetByLotOperation_in.userDataNameSeq[0] =  CIMFWStrDup(CS_S_MAINPD_OPE_FOUP_CLEAN_FLAG);
            csObjUserData_GetByLotOperation_out strUserData_GetByLotOperation_out;
            rc = cs_userData_GetByLotOperation(strUserData_GetByLotOperation_out, strObjCommonIn,
                strUserData_GetByLotOperation_in);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V2("", "cs_userData_GetByLotOperation() rc != RC_OK", rc);
                strOpeCompForInternalBufferReqResult.strResult = strUserData_GetByLotOperation_out.strResult;
                return(rc);
            }
            //for each UserData
            CORBA::Long userDataSeqLen = strUserData_GetByLotOperation_out.strUserDataSeq.length();
            for (CORBA::Long i1 = 0; i1 < userDataSeqLen; i1++)
            {
                CORBA::String_var strtmp = CS_S_MAINPD_OPE_FOUP_CLEAN_FLAG;
                if(CIMFWStrCmp(strUserData_GetByLotOperation_out.strUserDataSeq[i1].name, strtmp) == 0 &&
                   CIMFWStrCmp(strUserData_GetByLotOperation_out.strUserDataSeq[i1].value, "Yes") == 0 )
                {
                    CORBA::String_var strtmpNOTAVAILABLE = CS_SP_DRBL_STATE_NOTAVAILABLE;
                    objDurable_currentState_Change_out         strDurable_currentState_Change_out;
                    objDurable_currentState_Change_in           strDurable_currentState_Change_in;
                    strDurable_currentState_Change_in.durableCategory = CIMFWStrDup(SP_Durable_Category_Cassette);
                    strDurable_currentState_Change_in.durableStatus = CIMFWStrDup(CS_SP_DRBL_STATE_NOTAVAILABLE);
                    strDurable_currentState_Change_in.durableSubStatus.identifier = CIMFWStrDup(CS_SP_DRBL_STATE_NOTAVAILABLE);
                    strDurable_currentState_Change_in.durableID = strStartCassette[i].cassetteID;
                    rc = durable_currentState_Change(strDurable_currentState_Change_out, strObjCommonIn,
                        strDurable_currentState_Change_in);
                    if (rc != RC_OK)
                    {
                            PPT_METHODTRACE_V2("", "durable_currentState_Change() rc != RC_OK", rc);
                            strOpeCompForInternalBufferReqResult.strResult = strDurable_currentState_Change_out.strResult;
                            return(rc);
                    }
                }

            }
//INN-R170003 End

            /*-----------------------------------*/
            /*   Move Process Operation of Lot   */
            /*-----------------------------------*/
            objProcess_Move_out  strProcess_Move_out;
            strProcess_Move_out.autoBankInFlag = FALSE;
            rc = process_Move( strProcess_Move_out, strObjCommonIn, strStartCassette[i].strLotInCassette[j].lotID );
//D5000225 Insert Start
            if ( rc == RC_ADDTOQUEUE_FAIL )
            {
                PPT_METHODTRACE_V1("", "process_Move() == RC_ADDTOQUEUE_FAIL") ;

                objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
                rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out,
                                                   strObjCommonIn,
                                                   strStartCassette[i].strLotInCassette[j].lotID ) ;

                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V2("", "lot_currentOperationInfo_Get() != RC_OK", rc);
                    strOpeCompForInternalBufferReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult ;
                    return (rc) ;
                }

                pptHoldLotReqResult strHoldLotReqResult ;
                pptHoldListSequence strLotHoldReqList( 1 ) ;
                strLotHoldReqList.length( 1 ) ;

                strLotHoldReqList[0].holdType                 = CIMFWStrDup( SP_HoldType_AddToQueueErrHold ) ;
                strLotHoldReqList[0].holdReasonCodeID.identifier          = CIMFWStrDup( SP_Reason_AddToQueueErrHold );
                strLotHoldReqList[0].holdUserID               = strObjCommonIn.strUser.userID;
                strLotHoldReqList[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Current );
                strLotHoldReqList[0].routeID                  = strLot_currentOperationInfo_Get_out.routeID ;
                strLotHoldReqList[0].operationNumber          = strLot_currentOperationInfo_Get_out.operationNumber ;
                strLotHoldReqList[0].claimMemo                = CIMFWStrDup( "");

                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn,
                                   strStartCassette[i].strLotInCassette[j].lotID,
                                   strLotHoldReqList );

                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
                    strOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult ;
                    return rc ;
                }
                else
                {
                    PPT_METHODTRACE_V1("", "txHoldLotReq() == RC_OK For AddToQueue") ;
                }
            }
            else
            {
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "process_Move() != RC_OK") ;
                    strOpeCompForInternalBufferReqResult.strResult = strProcess_Move_out.strResult ;
                    return( rc );
                }
                else
                {
                    PPT_METHODTRACE_V1("", "process_Move() == RC_OK") ;
                }
            }
//D5000225 Insert End
//D5000225            if ( rc != RC_OK )
//D5000225            {
//D5000225                PPT_METHODTRACE_V1("", "process_Move() != RC_OK") ;
//D5000225                strOpeCompForInternalBufferReqResult.strResult = strProcess_Move_out.strResult ;
//D5000225                return( rc );
//D5000225            }

//D4100069            objLot_CheckForLCFR_out strLot_CheckForLCFR_out;
//D4100069            rc = lot_CheckForLCFR(  strLot_CheckForLCFR_out,
//D4100069                                    strObjCommonIn,
//D4100069                                    strStartCassette[i].strLotInCassette[j].lotID,
//D4100069                                    SP_LotCustomize_DBRECORD );
//D4100069            if ( rc == RC_OK )
//D4100069            {
//D4100069                PPT_METHODTRACE_V1("", "lot_CheckForLCFR(SP_LotCustomize_DBRECORD) == RC_OK") ;
//D4100069
//D4100069                objProcess_MoveForLCFR_out strProcess_MoveForLCFR_out;
//D4100069                strProcess_MoveForLCFR_out.autoBankInFlag = FALSE;
//D4100069                rc = process_MoveForLCFR(   strProcess_MoveForLCFR_out,
//D4100069                                            strObjCommonIn,
//D4100069                                            strStartCassette[i].strLotInCassette[j].lotID );
//D4100069                switch ( rc )
//D4100069                {
//D4100069                    case RC_OK:
//D4100069                    {
//D4100069                        PPT_METHODTRACE_V1("", "process_MoveForLCFR() == RC_OK") ;
//D4100069                        if(strProcess_MoveForLCFR_out.autoBankInFlag == TRUE)
//D4100069                        {
//D4100069                            PPT_METHODTRACE_V1("", "strProcess_MoveForLCFR_out.autoBankInFlag == FALSE") ;
//D4100069                            strProcess_Move_out.autoBankInFlag = TRUE;
//D4100069                        }
//D4100069                    }
//D4100069                    break;
//D4100069                    default:
//D4100069                    {
//D4100069                        PPT_METHODTRACE_V2("", "process_MoveForLCFR() != RC_OK : ", rc);
//D4100069                        strOpeCompForInternalBufferReqResult.strResult = strProcess_MoveForLCFR_out.strResult ;
//D4100069
//D4100069
//D4100069                        pptHoldListSequence strLotHoldReqList ;
//D4100069                        pptHoldLotReqResult strHoldLotReqResult ;
//D4100069                        /*------------------------------------------------------------------------------------*/
//D4100069                        /* parameter set                                                                         */
//D4100069                        /*---------------------------------------------------------------------------------------*/
//D4100069                        objectIdentifier aReasonCodeID ;
//D4100069                        aReasonCodeID.identifier = CIMFWStrDup( SP_Reason_LCFR_Hold ) ;
//D4100069
//D4100069                        /*-------------------*/
//D4100069                        /* get main route id */
//D4100069                        /*-------------------*/
//D4100069                        objLot_mainRouteID_Get_out strLot_mainRouteID_Get_out;
//D4100069                        rc = lot_mainRouteID_Get( strLot_mainRouteID_Get_out, strObjCommonIn, strStartCassette[i].strLotInCassette[j].lotID );
//D4100069                        if (rc != RC_OK)
//D4100069                        {
//D4100069                            PPT_METHODTRACE_V2("", "lot_mainRouteID_Get() != RC_OK", rc);
//D4100069                            strOpeCompForInternalBufferReqResult.strResult = strLot_mainRouteID_Get_out.strResult;
//D4100069                            return(rc);
//D4100069                        }
//D4100069                        objectIdentifier routeID = strLot_mainRouteID_Get_out.mainRouteID;
//D4100069
//D4100069
//D4100069                        strLotHoldReqList.length( 1 ) ;
//D4100069                        strLotHoldReqList[0].holdType                 = CIMFWStrDup( SP_HoldType_LCFR_Route_Deleted ) ;
//D4100069                        strLotHoldReqList[0].holdReasonCodeID         = aReasonCodeID;
//D4100069                        strLotHoldReqList[0].holdUserID               = strObjCommonIn.strUser.userID;
//D4100069                        strLotHoldReqList[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Current );
//D4100069                        strLotHoldReqList[0].routeID                  = routeID;
//D4100069                        strLotHoldReqList[0].operationNumber          = CIMFWStrDup( SP_LotCustomize_Dummy_OperationNumber );
//D4100069                        strLotHoldReqList[0].relatedLotID             = strStartCassette[i].strLotInCassette[j].lotID;
//D4100069                        strLotHoldReqList[0].claimMemo                = CIMFWStrDup( "");
//D4100069                        /*------------------------------------------------------------------------------------*/
//D4100069                        /* parameter set                                                                         */
//D4100069                        /*---------------------------------------------------------------------------------------*/
//D4100069                        rc = txHoldLotReq( strHoldLotReqResult,strObjCommonIn, strStartCassette[i].strLotInCassette[j].lotID, strLotHoldReqList) ;
//D4100069                        if (rc != RC_OK)
//D4100069                        {
//D4100069                            PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
//D4100069                            strOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult ;
//D4100069                            return rc ;
//D4100069                        }
//D4100069                    }
//D4100069                    break;
//D4100069                }
//D4100069            }
//D4100069            else
//D4100069            {
//D4100069                CORBA::Long retCode = RC_OK;
//D4100069
//D4100069                /*----------------------------------------------------*/
//D4100069                /* Check Environment Variable (SP_LCFR_USE_FLAG == 1) */
//D4100069                /*----------------------------------------------------*/
//D4100069                CORBA::String_var   UseFlagOn;
//D4100069                CORBA::String_var   UseFlagValue;
//D4100069
//D4100069                if ( CIMFWStrLen( theSP_LCFR_Use_Flag ) > 0 )
//D4100069                {
//D4100069                    PPT_METHODTRACE_V2("", "theSP_LCFR_Use_Flag", theSP_LCFR_Use_Flag);
//D4100069                    UseFlagOn    = CIMFWStrDup(SP_LCFR_Use_Flag_On);
//D4100069                    UseFlagValue = theSP_LCFR_Use_Flag;
//D4100069
//D4100069                    if (CIMFWStrCmp(UseFlagValue, UseFlagOn) != 0)
//D4100069                    {
//D4100069                        PPT_METHODTRACE_V1("", "theSP_LCFR_Use_Flag env is invalid(1)");
//D4100069                    }
//D4100069                }
//D4100069                else
//D4100069                {
//D4100069                    PPT_METHODTRACE_V1("", "theSP_LCFR_Use_Flag is not env");
//D4100069                }
//D4100069
//D4100069                /*----------------------------*/
//D4100069                /* Get currentOperationNumber */
//D4100069                /*----------------------------*/
//D4100069                CORBA::String_var currentOperationNumber;
//D4100069
//D4100069                objLot_currentOpeNo_Get_out     strLot_currentOpeNo_Get_out;
//D4100069                retCode = lot_currentOpeNo_Get( strLot_currentOpeNo_Get_out,
//D4100069                                                strObjCommonIn,
//D4100069                                                strStartCassette[i].strLotInCassette[j].lotID );
//D4100069                if ( retCode != RC_OK )
//D4100069                {
//D4100069                    PPT_METHODTRACE_V2("", "lot_currentOpeNo_Get() != RC_OK : ", retCode) ;
//D4100069                    /* set returned strResult to strResult of out parameter */
//D4100069                    strOpeCompForInternalBufferReqResult.strResult = strLot_currentOpeNo_Get_out.strResult;
//D4100069                    return( retCode );
//D4100069                }
//D4100069                currentOperationNumber = strLot_currentOpeNo_Get_out.currentOperationNumber;
//D4100069
//D4100069                PPT_METHODTRACE_V2("", "currentOperationNumber = ", currentOperationNumber) ;
//D4100069                PPT_METHODTRACE_V3("", "UseFlagValue&UseFlagOn = ", UseFlagValue, UseFlagOn) ;
//D4100069                PPT_METHODTRACE_V2("", "rc = ", rc) ;
//D4100069
//D4100069                if((CIMFWStrCmp( currentOperationNumber,SP_LotCustomize_Dummy_OperationNumber ) == 0) &&
//D4100069                   (CIMFWStrCmp( UseFlagValue, UseFlagOn) == 0) &&
//D4100069                   (rc == RC_NOT_LCFR_LOT))
//D4100069                {
//D4100069                    PPT_METHODTRACE_V1("", "lot_CheckForLCFR() == RC_NOT_LCFR_LOT") ;
//D4100069                    PPT_METHODTRACE_V1("", "currentOperationNumber == SP_LotCustomize_Dummy_OperationNumber") ;
//D4100069                    PPT_METHODTRACE_V1("", "UseFlagValue == UseFlagOn") ;
//D4100069
//D4100069                    pptHoldListSequence strLotHoldReqList ;
//D4100069                    pptHoldLotReqResult strHoldLotReqResult ;
//D4100069                    /*---------------------------------------------------------------------------------------*/
//D4100069                    /* parameter set                                                                         */
//D4100069                    /*---------------------------------------------------------------------------------------*/
//D4100069                    objectIdentifier aReasonCodeID ;
//D4100069                    aReasonCodeID.identifier = CIMFWStrDup( SP_Reason_LCFR_Hold ) ;
//D4100069
//D4100069                    /*-------------------*/
//D4100069                    /* get main route id */
//D4100069                    /*-------------------*/
//D4100069                    objLot_mainRouteID_Get_out strLot_mainRouteID_Get_out;
//D4100069                    rc = lot_mainRouteID_Get( strLot_mainRouteID_Get_out, strObjCommonIn, strStartCassette[i].strLotInCassette[j].lotID);
//D4100069                    if (rc != RC_OK)
//D4100069                    {
//D4100069                        PPT_METHODTRACE_V2("", "lot_mainRouteID_Get() != RC_OK", rc);
//D4100069                        strOpeCompForInternalBufferReqResult.strResult = strLot_mainRouteID_Get_out.strResult;
//D4100069                        return(rc);
//D4100069                    }
//D4100069                    objectIdentifier routeID = strLot_mainRouteID_Get_out.mainRouteID;
//D4100069                    PPT_METHODTRACE_V2("", "mainRouteID = ", routeID.identifier);
//D4100069
//D4100069                    strLotHoldReqList.length( 1 ) ;
//D4100069                    strLotHoldReqList[0].holdType                 = CIMFWStrDup( SP_HoldType_LCFR_Route_Deleted ) ;
//D4100069                    strLotHoldReqList[0].holdReasonCodeID         = aReasonCodeID;
//D4100069                    strLotHoldReqList[0].holdUserID               = strObjCommonIn.strUser.userID;
//D4100069                    strLotHoldReqList[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Current );
//D4100069                    strLotHoldReqList[0].routeID                  = routeID;
//D4100069                    strLotHoldReqList[0].operationNumber          = CIMFWStrDup( SP_LotCustomize_Dummy_OperationNumber );
//D4100069                    strLotHoldReqList[0].relatedLotID             = strStartCassette[i].strLotInCassette[j].lotID;
//D4100069                    strLotHoldReqList[0].claimMemo                = CIMFWStrDup( "");
//D4100069                    /*---------------------------------------------------------------------------------------*/
//D4100069                    /* parameter set                                                                         */
//D4100069                    /*---------------------------------------------------------------------------------------*/
//D4100069                    rc = txHoldLotReq( strHoldLotReqResult,strObjCommonIn, strStartCassette[i].strLotInCassette[j].lotID, strLotHoldReqList) ;
//D4100069                    if (rc != RC_OK)
//D4100069                    {
//D4100069                        PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
//D4100069                        strOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult ;
//D4100069                        return rc ;
//D4100069                    }
//D4100069                }
//D4100069            }

//PSIV00001188            // save the returned lotID as objectIdentifier type for last txBankInReq() if autoBankInFlag is TRUE;
//PSIV00001188            if ( strProcess_Move_out.autoBankInFlag == TRUE )
//PSIV00001188            {
//PSIV00001188                autoBankInLotIDs[lotcount] = strStartCassette[i].strLotInCassette[j].lotID;
//PSIV00001188                lotcount++;
//PSIV00001188            }

//DSIV00000201 add start
            // set operation start lot
            opeStartLotIDs[opeStartLotCount] = strStartCassette[i].strLotInCassette[j].lotID;
            opeStartLotCount++;
//DSIV00000201 add end

//D4000016 Add Start
            //--------------------------------------------------------------------------------------------------
            // UpDate RequiredCassetteCategory
            //--------------------------------------------------------------------------------------------------
            objLot_CassetteCategory_UpdateForContaminationControl_out   strLot_CassetteCategory_UpdateForContaminationControl_out;
            rc = lot_CassetteCategory_UpdateForContaminationControl( strLot_CassetteCategory_UpdateForContaminationControl_out,
                                                                     strObjCommonIn,
                                                                     strStartCassette[i].strLotInCassette[j].lotID );

            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V1("","lot_CassetteCategory_UpdateForContaminationControl != RC_OK");
                strOpeCompForInternalBufferReqResult.strResult = strLot_CassetteCategory_UpdateForContaminationControl_out.strResult;
                return rc;
            }
//D4000016 Add end

//INN-R170002 Add Start
            //--------------------------------------------------------------------------------------------------
            // Check Contamination Level
            //--------------------------------------------------------------------------------------------------
            csObjLot_ContaminationInfo_CheckForMove_in strLot_ContaminationInfo_CheckForMove_in;
            strLot_ContaminationInfo_CheckForMove_in.lotID = strStartCassette[i].strLotInCassette[j].lotID;
            strLot_ContaminationInfo_CheckForMove_in.carrierID = strStartCassette[i].cassetteID;
            csObjLot_ContaminationInfo_CheckForMove_out strLot_ContaminationInfo_CheckForMove_out;
            rc = cs_lot_ContaminationInfo_CheckForMove(strLot_ContaminationInfo_CheckForMove_out,
                                                       strObjCommonIn,
                                                       strLot_ContaminationInfo_CheckForMove_in);

            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V1("","cs_lot_ContaminationInfo_CheckForMove != RC_OK");
                strOpeCompForInternalBufferReqResult.strResult = strLot_ContaminationInfo_CheckForMove_out.strResult;
                return rc;
            }

            if(strLot_ContaminationInfo_CheckForMove_out.holdReqFlag == TRUE)
            {
                pptHoldLotReqResult strHoldLotReqResult;
                pptHoldListSequence strLotHoldReqList( 1 );
                strLotHoldReqList.length( 1 );

                strLotHoldReqList[0].holdType                    = CIMFWStrDup( SP_HoldType_LotHold );
                strLotHoldReqList[0].holdReasonCodeID.identifier = CIMFWStrDup( CS_SP_Reason_ContaminationMismatchHold );
                strLotHoldReqList[0].holdUserID                  = strObjCommonIn.strUser.userID;
                strLotHoldReqList[0].responsibleOperationMark    = CIMFWStrDup( SP_ResponsibleOperation_Current );
                strLotHoldReqList[0].claimMemo                   = claimMemo;

                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn,
                                       strStartCassette[i].strLotInCassette[j].lotID,
                                       strLotHoldReqList );

                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
                    strOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult ;
                    return rc ;
                }
                else
                {
                    PPT_METHODTRACE_V1("", "txHoldLotReq() == RC_OK For LotHold") ;
                }
            }
//INN-R170002 Add End
        }
    }
//PSIV00001188    autoBankInLotIDs.length(lotcount);
    opeStartLotIDs.length(opeStartLotCount);    //DSIV00000201

//DSIV00000201 add start
    if( PostProcForLotFlag != 1 )
    {
//DSIV00000201 add end
//D4100083 Add Start
        /*----------------------------------------------------------------------------*/
        /*   Lot FutureHold Post By Previous Operation Effect after Operation Move    */
        /*----------------------------------------------------------------------------*/
        PPT_METHODTRACE_V1("", "Lot FutureHold Post By Previous Operation Effect after Operation Move  ") ;

        CORBA::Long fhLen = strLot_futureHoldRequests_EffectByCondition_outSequence.length();

        for ( fHCnt = 0 ; fHCnt < fhLen ; fHCnt++ )
        {
            PPT_METHODTRACE_V2("", "fHCnt",fHCnt);

            if (strLot_futureHoldRequests_EffectByCondition_outSequence[fHCnt].strLotHoldReqList.length() > 0)
            {

                PPT_METHODTRACE_V1("", "strLotHoldReqList.length() > 0") ;

                /*-----------------------------------------------------*/
                /*   Convert OpeNo, RouteID from previous to current   */
                /*-----------------------------------------------------*/
                PPT_METHODTRACE_V1("", "Convert OpeNo from previous to current") ;

                objLot_futureHold_EffectedProcessConversion_out strLot_futureHold_EffectedProcessConversion_out;
                rc = lot_futureHold_EffectedProcessConversion( strLot_futureHold_EffectedProcessConversion_out,
                                                               strObjCommonIn,
                                                               strLot_futureHoldRequests_EffectByCondition_outSequence[fHCnt].lotID,
                                                               strLot_futureHoldRequests_EffectByCondition_outSequence[fHCnt].strLotHoldReqList );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_futureHold_EffectedProcessConversion() != RC_OK") ;
                    strOpeCompForInternalBufferReqResult.strResult = strLot_futureHold_EffectedProcessConversion_out.strResult ;
                    return( rc );
                }

                pptHoldLotReqResult strHoldLotReqResult ;

                rc = txHoldLotReq( strHoldLotReqResult,
                                   strObjCommonIn ,
                                   strLot_futureHoldRequests_EffectByCondition_outSequence[fHCnt].lotID ,
                                   strLot_futureHold_EffectedProcessConversion_out.strLotHoldReqList ) ;

                if ( rc != RC_OK && rc != RC_EXIST_SAME_HOLD )
                {
                    PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
                    strOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult ;
                    return( rc );
                }

            }
        }

//D4100083 Add End
//DSIV00000201 add start
    }
//DSIV00000201 add end

//D7000178    //---------------------------------------------------------------------------
//D7000178    //   Execute Lot Hold Action based on SpecCheck and also SPC Check result.
//D7000178    //
//D7000178    //---------------------------------------------------------------------------
//D7000178
//D7000178    /*-------------------------------------*/
//D7000178    /*   Effect The Result of SPEC Check   */
//D7000178    /*-------------------------------------*/
//D7000178
//D7000178//D4100069    /*----------------------------------------------------*/
//D7000178//D4100069    /* Check Environment Variable (SP_LCFR_USE_FLAG == 1) */
//D7000178//D4100069    /* When LCFR function is enable, call method for LCFR.*/
//D7000178//D4100069    /* When disable, call conventional method.            */
//D7000178//D4100069    /*----------------------------------------------------*/
//D7000178//D4100069    CORBA::String_var   UseFlagOn;
//D7000178//D4100069    CORBA::String_var   UseFlagValue;
//D7000178//D4100069//D4000011    char *LCFRUseFlag = NULL;
//D7000178//D4100069    UseFlagOn    = CIMFWStrDup(SP_LCFR_Use_Flag_On);
//D7000178//D4100069
//D7000178//D4100069//D4000011    LCFRUseFlag = getenv(SP_LCFR_Use_Flag);
//D7000178//D4100069//D4000011    UseFlagValue = CIMFWStrDup(LCFRUseFlag);
//D7000178//D4100069    UseFlagValue = theSP_LCFR_Use_Flag;
//D7000178
//D7000178    objLot_holdRecord_EffectSpecCheckResult_out   strLot_holdRecord_EffectSpecCheckResult_out;
//D7000178
//D7000178//D4100069//D4000011    if (LCFRUseFlag == NULL || CIMFWStrCmp(UseFlagValue, UseFlagOn) != 0)
//D7000178//D4100069//D4000011    {
//D7000178//D4100069//D4000011        PPT_METHODTRACE_V1("", "getenv(SP_LCFR_USE_FLAG) is not env");
//D7000178//D4100069    if ( CIMFWStrLen( theSP_LCFR_Use_Flag ) == 0 || CIMFWStrCmp(UseFlagValue, UseFlagOn) != 0)       //D4000011
//D7000178//D4100069    {                                                                                                //D4000011
//D7000178//D4100069        PPT_METHODTRACE_V1("", "theSP_LCFR_Use_Flag is not env");  //D4000011
//D7000178        rc = lot_holdRecord_EffectSpecCheckResult( strLot_holdRecord_EffectSpecCheckResult_out, strObjCommonIn, strStartCassette );
//D7000178        if ( rc != RC_OK )
//D7000178        {
//D7000178            PPT_METHODTRACE_V1("", "lot_holdRecord_EffectSpecCheckResult() != RC_OK" );
//D7000178            strOpeCompForInternalBufferReqResult.strResult = strLot_holdRecord_EffectSpecCheckResult_out.strResult;
//D7000178            return( rc );
//D7000178        }
//D7000178
//D7000178//D4100069    }
//D7000178//D4100069    else
//D7000178//D4100069    {
//D7000178//D4100069//D4000011        PPT_METHODTRACE_V1("", "getenv(SP_LCFR_USE_FLAG) is env");
//D7000178//D4100069        PPT_METHODTRACE_V1("", "theSP_LCFR_Use_Flag is env");  //D4000011
//D7000178//D4100069        objLot_holdRecord_EffectSpecCheckResultForLCFR_out   strLot_holdRecord_EffectSpecCheckResultForLCFR_out;
//D7000178//D4100069        rc = lot_holdRecord_EffectSpecCheckResultForLCFR( strLot_holdRecord_EffectSpecCheckResultForLCFR_out, strObjCommonIn, strStartCassette );
//D7000178//D4100069        if ( rc == RC_OK )
//D7000178//D4100069        {
//D7000178//D4100069            PPT_METHODTRACE_V1("", "lot_holdRecord_EffectSpecCheckResultForLCFR() == RC_OK");
//D7000178//D4100069            CORBA::Long  strLotHoldEffectListLen = strLot_holdRecord_EffectSpecCheckResultForLCFR_out.strLotHoldEffectList.length();
//D7000178//D4100069            CORBA::Long  strFutureHoldEffectListLen = strLot_holdRecord_EffectSpecCheckResultForLCFR_out.strFutureHoldEffectList.length();
//D7000178//D4100069
//D7000178//D4100069            strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList.length( strLotHoldEffectListLen );
//D7000178//D4100069            strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList = strLot_holdRecord_EffectSpecCheckResultForLCFR_out.strLotHoldEffectList;
//D7000178//D4100069            strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList.length( strFutureHoldEffectListLen );
//D7000178//D4100069            strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList = strLot_holdRecord_EffectSpecCheckResultForLCFR_out.strFutureHoldEffectList;
//D7000178//D4100069        }
//D7000178//D4100069        else
//D7000178//D4100069        {
//D7000178//D4100069            PPT_METHODTRACE_V2("", "lot_holdRecord_EffectSpecCheckResultForLCFR() != RC_OK", rc );
//D7000178//D4100069            strOpeCompForInternalBufferReqResult.strResult = strLot_holdRecord_EffectSpecCheckResultForLCFR_out.strResult;
//D7000178//D4100069            return( rc );
//D7000178//D4100069        }
//D7000178//D4100069    }
//D7000178
//D7000178    CORBA::Long nSpecLotHoldEffectListLen = 0;
//D7000178    nSpecLotHoldEffectListLen = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList.length();
//D7000178    if ( nSpecLotHoldEffectListLen  > 0 )
//D7000178    {
//D7000178        PPT_METHODTRACE_V2("",
//D7000178                           "strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList.length()", nSpecLotHoldEffectListLen) ;
//D7000178
//D7000178        pptHoldLotReqResult strHoldLotReqResult ;
//D7000178
//D7000178        pptHoldListSequence strLotHoldReqList;
//D7000178        strLotHoldReqList.length( 1 ) ;
//D7000178
//D7000178        for( i = 0 ; i< nSpecLotHoldEffectListLen ; i++ )
//D7000178        {
//D7000178            strLotHoldReqList[0].holdType                 = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].holdType ;
//D7000178            strLotHoldReqList[0].holdReasonCodeID         = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].reasonCodeID ;
//D7000178            strLotHoldReqList[0].holdUserID               = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].userID ;
//D7000178            strLotHoldReqList[0].responsibleOperationMark = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].responsibleOperationMark ;
//D7000178            strLotHoldReqList[0].routeID                  = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].routeID ;
//D7000178            strLotHoldReqList[0].operationNumber          = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].operationNumber ;
//D7000178            strLotHoldReqList[0].relatedLotID             = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].relatedLotID ;
//D7000178            strLotHoldReqList[0].claimMemo                = strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].claimMemo ;
//D7000178
//D7000178            rc = txHoldLotReq( strHoldLotReqResult,
//D7000178                               strObjCommonIn ,
//D7000178                               strLot_holdRecord_EffectSpecCheckResult_out.strLotHoldEffectList[i].lotID ,
//D7000178                               strLotHoldReqList ) ;
//D7000178
//D7000178            if ( rc != RC_OK && rc != RC_EXIST_SAME_HOLD )
//D7000178            {
//D7000178                PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
//D7000178                strOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult ;
//D7000178                return( rc );
//D7000178            }
//D7000178        }
//D7000178    }
//D7000178
//D7000178    CORBA::Long nSpecFutureHoldEffectLen = 0;
//D7000178    nSpecFutureHoldEffectLen = strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList.length() ;
//D7000178    if ( nSpecFutureHoldEffectLen  > 0 )
//D7000178    {
//D7000178        PPT_METHODTRACE_V2("", "strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList.length()", nSpecFutureHoldEffectLen) ;
//D7000178
//D7000178//D4100083        pptFutureHoldReqResult strFutureHoldReqResult ;
//D7000178        for( i=0 ; i<nSpecFutureHoldEffectLen; i++ )
//D7000178        {
//D7000178//D4100083 Add Start
//D7000178            pptEnhancedFutureHoldReqResult strEnhancedFutureHoldReqResult;
//D7000178            rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult,
//D7000178                                          strObjCommonIn ,
//D7000178                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].holdType ,
//D7000178                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].lotID,
//D7000178                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].routeID,
//D7000178                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].operationNumber,
//D7000178                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].reasonCodeID,
//D7000178                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].relatedLotID,
//D7000178                                          TRUE,
//D7000178                                          TRUE,
//D7000178                                          strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].claimMemo ) ;
//D7000178            if ( rc != RC_OK && rc != RC_DUPLICATE_FTHOLD_ENTRY )
//D7000178            {
//D7000178                PPT_METHODTRACE_V1("", "txEnhancedFutureHoldReq() != RC_OK && RC_DUPLICATE_FTHOLD_ENTRY") ;
//D7000178                strOpeCompForInternalBufferReqResult.strResult = strEnhancedFutureHoldReqResult.strResult ;
//D7000178                return( rc );
//D7000178            }
//D7000178//D4100083 Add End
//D7000178//D4100083            rc = txFutureHoldReq( strFutureHoldReqResult,
//D7000178//D4100083                                  strObjCommonIn ,
//D7000178//D4100083                                  strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].holdType ,
//D7000178//D4100083                                  strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].lotID,
//D7000178//D4100083                                  strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].routeID,
//D7000178//D4100083                                  strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].operationNumber,
//D7000178//D4100083                                  strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].reasonCodeID,
//D7000178//D4100083                                  strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].relatedLotID,
//D7000178//D4100083                                  strLot_holdRecord_EffectSpecCheckResult_out.strFutureHoldEffectList[i].claimMemo ) ;
//D7000178//D4100083            if ( rc != RC_OK)
//D7000178//D4100083            {
//D7000178//D4100083                PPT_METHODTRACE_V1("", "txFutureHoldReq() != RC_OK") ;
//D7000178//D4100083                strOpeCompForInternalBufferReqResult.strResult = strFutureHoldReqResult.strResult ;
//D7000178//D4100083                return( rc );
//D7000178//D4100083            }
//D7000178        }
//D7000178    }
//D7000178
//D7000178    /*------------------------------------*/
//D7000178    /*   Effect The Result of SPC Check   */
//D7000178    /*------------------------------------*/
//D7000178    objLot_holdRecord_EffectSPCCheckResult_out   strLot_holdRecord_EffectSPCCheckResult_out;
//D7000178//D4100069//D4000011    if (LCFRUseFlag == NULL || CIMFWStrCmp(UseFlagValue, UseFlagOn) != 0)
//D7000178//D4100069//D4000011    {
//D7000178//D4100069//D4000011        PPT_METHODTRACE_V1("", "getenv(SP_LCFR_USE_FLAG) is not env");
//D7000178//D4100069    if ( CIMFWStrLen( theSP_LCFR_Use_Flag ) == 0 || CIMFWStrCmp(UseFlagValue, UseFlagOn) != 0)       //D4000011
//D7000178//D4100069    {                                                                                                //D4000011
//D7000178//D4100069        PPT_METHODTRACE_V1("", "theSP_LCFR_Use_Flag is not env");  //D4000011
//D7000178        rc = lot_holdRecord_EffectSPCCheckResult( strLot_holdRecord_EffectSPCCheckResult_out,
//D7000178                                                  strObjCommonIn,
//D7000178                                                  strSpcCheckReqResult.strSpcCheckLot );
//D7000178        if ( rc != RC_OK )
//D7000178        {
//D7000178            PPT_METHODTRACE_V1("", "lot_holdRecord_EffectSPCCheckResult() != RC_OK");
//D7000178            strOpeCompForInternalBufferReqResult.strResult = strLot_holdRecord_EffectSPCCheckResult_out.strResult ;
//D7000178            return( rc );
//D7000178        }
//D7000178//D4100069    }
//D7000178//D4100069    else
//D7000178//D4100069    {
//D7000178//D4100069//D4000011        PPT_METHODTRACE_V1("", "getenv(SP_LCFR_USE_FLAG) is env");
//D7000178//D4100069        PPT_METHODTRACE_V1("", "theSP_LCFR_Use_Flag is env");  //D4000011
//D7000178//D4100069        objLot_holdRecord_EffectSPCCheckResultForLCFR_out   strLot_holdRecord_EffectSPCCheckResultForLCFR_out;
//D7000178//D4100069        rc = lot_holdRecord_EffectSPCCheckResultForLCFR( strLot_holdRecord_EffectSPCCheckResultForLCFR_out,
//D7000178//D4100069                                                         strObjCommonIn,
//D7000178//D4100069                                                         strSpcCheckReqResult.strSpcCheckLot );
//D7000178//D4100069        if ( rc == RC_OK )
//D7000178//D4100069        {
//D7000178//D4100069            PPT_METHODTRACE_V1("", "lot_holdRecord_EffectSpecCheckResultForLCFR() == RC_OK");
//D7000178//D4100069            CORBA::Long  strLotHoldEffectListLen = strLot_holdRecord_EffectSPCCheckResultForLCFR_out.strLotHoldEffectList.length();
//D7000178//D4100069            CORBA::Long  strFutureHoldEffectListLen = strLot_holdRecord_EffectSPCCheckResultForLCFR_out.strFutureHoldEffectList.length();
//D7000178//D4100069
//D7000178//D4100069            strLot_holdRecord_EffectSPCCheckResultForLCFR_out.strLotHoldEffectList.length( strLotHoldEffectListLen );
//D7000178//D4100069            strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList = strLot_holdRecord_EffectSPCCheckResultForLCFR_out.strLotHoldEffectList;
//D7000178//D4100069            strLot_holdRecord_EffectSPCCheckResultForLCFR_out.strFutureHoldEffectList.length( strFutureHoldEffectListLen );
//D7000178//D4100069            strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList = strLot_holdRecord_EffectSPCCheckResultForLCFR_out.strFutureHoldEffectList;
//D7000178//D4100069        }
//D7000178//D4100069        else
//D7000178//D4100069        {
//D7000178//D4100069            PPT_METHODTRACE_V2("", "lot_holdRecord_EffectSPCCheckResultForLCFR() != RC_OK", rc );
//D7000178//D4100069            strOpeCompForInternalBufferReqResult.strResult = strLot_holdRecord_EffectSPCCheckResultForLCFR_out.strResult;
//D7000178//D4100069            return( rc );
//D7000178//D4100069        }
//D7000178//D4100069    }
//D7000178
//D7000178    CORBA::Long nSPCLotHoldEffectListLen = 0;
//D7000178    nSPCLotHoldEffectListLen = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList.length();
//D7000178    if ( nSPCLotHoldEffectListLen  > 0 )
//D7000178    {
//D7000178        PPT_METHODTRACE_V2("","strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList.length()", nSPCLotHoldEffectListLen) ;
//D7000178
//D7000178        pptHoldLotReqResult strHoldLotReqResult ;
//D7000178
//D7000178        pptHoldListSequence strLotHoldReqList;
//D7000178        strLotHoldReqList.length( 1 ) ;
//D7000178
//D7000178        for( i = 0 ; i< nSPCLotHoldEffectListLen ; i++ )
//D7000178        {
//D7000178            strLotHoldReqList[0].holdType                 = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].holdType ;
//D7000178            strLotHoldReqList[0].holdReasonCodeID         = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].reasonCodeID ;
//D7000178            strLotHoldReqList[0].holdUserID               = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].userID ;
//D7000178            strLotHoldReqList[0].responsibleOperationMark = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].responsibleOperationMark ;
//D7000178            strLotHoldReqList[0].routeID                  = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].routeID ;
//D7000178            strLotHoldReqList[0].operationNumber          = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].operationNumber ;
//D7000178            strLotHoldReqList[0].relatedLotID             = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].relatedLotID ;
//D7000178            strLotHoldReqList[0].claimMemo                = strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].claimMemo ;
//D7000178
//D7000178            rc = txHoldLotReq( strHoldLotReqResult,
//D7000178                               strObjCommonIn ,
//D7000178                               strLot_holdRecord_EffectSPCCheckResult_out.strLotHoldEffectList[i].lotID ,
//D7000178                               strLotHoldReqList ) ;
//D7000178
//D7000178            if ( rc != RC_OK && rc != RC_EXIST_SAME_HOLD )
//D7000178            {
//D7000178                PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
//D7000178                strOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult ;
//D7000178                return( rc );
//D7000178            }
//D7000178        }
//D7000178    }
//D7000178
//D7000178    CORBA::Long nSPCFutureHoldEffectLen = 0;
//D7000178    nSPCFutureHoldEffectLen = strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList.length() ;
//D7000178    if ( nSPCFutureHoldEffectLen  > 0 )
//D7000178    {
//D7000178        PPT_METHODTRACE_V2("","strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList.length()", nSPCFutureHoldEffectLen) ;
//D7000178
//D7000178//D4100083        pptFutureHoldReqResult strFutureHoldReqResult ;
//D7000178        for( i=0 ; i<nSPCFutureHoldEffectLen; i++ )
//D7000178        {
//D7000178//D4100083 Add Start
//D7000178            pptEnhancedFutureHoldReqResult strEnhancedFutureHoldReqResult;
//D7000178            rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult,
//D7000178                                          strObjCommonIn ,
//D7000178                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].holdType ,
//D7000178                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].lotID,
//D7000178                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].routeID,
//D7000178                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].operationNumber,
//D7000178                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].reasonCodeID,
//D7000178                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].relatedLotID,
//D7000178                                          TRUE,
//D7000178                                          TRUE,
//D7000178                                          strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].claimMemo ) ;
//D7000178            if ( rc != RC_OK && rc != RC_DUPLICATE_FTHOLD_ENTRY )
//D7000178            {
//D7000178                PPT_METHODTRACE_V1("", "txEnhancedFutureHoldReq() != RC_OK && RC_DUPLICATE_FTHOLD_ENTRY") ;
//D7000178                strOpeCompForInternalBufferReqResult.strResult = strEnhancedFutureHoldReqResult.strResult ;
//D7000178                return( rc );
//D7000178            }
//D7000178//D4100083 Add End
//D7000178//D4100083            rc = txFutureHoldReq( strFutureHoldReqResult,
//D7000178//D4100083                                  strObjCommonIn ,
//D7000178//D4100083                                  strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].holdType ,
//D7000178//D4100083                                  strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].lotID,
//D7000178//D4100083                                  strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].routeID,
//D7000178//D4100083                                  strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].operationNumber,
//D7000178//D4100083                                  strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].reasonCodeID,
//D7000178//D4100083                                  strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].relatedLotID,
//D7000178//D4100083                                  strLot_holdRecord_EffectSPCCheckResult_out.strFutureHoldEffectList[i].claimMemo ) ;
//D7000178//D4100083            if ( rc != RC_OK )
//D7000178//D4100083            {
//D7000178//D4100083                PPT_METHODTRACE_V1("", "txFutureHoldReq() != RC_OK") ;
//D7000178//D4100083                strOpeCompForInternalBufferReqResult.strResult = strFutureHoldReqResult.strResult ;
//D7000178//D4100083                return( rc );
//D7000178//D4100083            }
//D7000178        }
//D7000178    }
//D7000178
//D7000178    /*---------------------------------------------------------------*/
//D7000178    /*   Cut Monitor Relation for ProcessMonitorLot and ProcessLot   */
//D7000178    /*---------------------------------------------------------------*/
//D7000178    CORBA::Long holdReleasedLotCount = 0;                        //P4200204
//D7000178    objectIdentifier monitorLotID;
//D7000178    for ( i=0 ; i<scLen ; i++ )
//D7000178    {
//D7000178        nLen = strStartCassette[i].strLotInCassette.length();
//D7000178        for (CORBA::Long j=0 ; j<nLen ; j++ )
//D7000178        {
//D7000178            /*---------------------------*/
//D7000178            /*   Omit Not-OpeStart Lot   */
//D7000178            /*---------------------------*/
//D7000178            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
//D7000178            {
//D7000178                continue;
//D7000178            }
//D7000178
//D7000178            /*-----------------------------*/
//D7000178            /*   Delete Monitor Grouping   */
//D7000178            /*-----------------------------*/
//D7000178            objMonitorGroup_DeleteComp_out  strMonitorGroup_DeleteComp_out;
//D7000178            rc = monitorGroup_DeleteComp( strMonitorGroup_DeleteComp_out,
//D7000178                                          strObjCommonIn,
//D7000178                                          strStartCassette[i].strLotInCassette[j].lotID );
//D7000178            if ( rc != RC_OK )
//D7000178            {
//D7000178                PPT_METHODTRACE_V1("", "monitorGroup_DeleteComp() != RC_OK") ;
//D7000178                strOpeCompForInternalBufferReqResult.strResult = strMonitorGroup_DeleteComp_out.strResult ;
//D7000178                return( rc );
//D7000178            }
//D7000178
//D7000178            CORBA::Long nMonitorCompLotsLen = strMonitorGroup_DeleteComp_out.strMonitoredCompLots.length() ;
//D7000178
//D7000178            if( nMonitorCompLotsLen != 0 )
//D7000178            {
//D7000178                pptHoldLotReleaseReqResult strHoldLotReleaseReqResult ;
//D7000178                objectIdentifier aReasonCodeID ;
//D7000178                aReasonCodeID.identifier = CIMFWStrDup( SP_Reason_WaitingMonitorHoldRelease ) ;
//D7000178
//D7000178                holdReleasedLotIDs.length(holdReleasedLotCount + nMonitorCompLotsLen);              //P4200204
//D7000178
//D7000178//D5100184                for(CORBA::Long j=0; j<nMonitorCompLotsLen; j++ )
//D7000178                for( CORBA::Long k = 0; k < nMonitorCompLotsLen; k++ )    //D5100184
//D7000178                {
//D7000178                    CORBA::Long nLotHoldLen = strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].strLotHoldReleaseReqList.length();    //D5100184
//D7000178//D5100184                    CORBA::Long nLotHoldLen = strMonitorGroup_DeleteComp_out.strMonitoredCompLots[j].strLotHoldReleaseReqList.length() ;
//D7000178                    if ( nLotHoldLen > 0 )
//D7000178                    {
//D7000178                        rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult,
//D7000178                                                  strObjCommonIn,
//D7000178                                                  strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID,                     //D5100184
//D7000178//D5100184                                                  strMonitorGroup_DeleteComp_out.strMonitoredCompLots[j].productLotID,
//D7000178                                                  aReasonCodeID,
//D7000178                                                  strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].strLotHoldReleaseReqList );       //D5100184
//D7000178//D5100184                                                  strMonitorGroup_DeleteComp_out.strMonitoredCompLots[j].strLotHoldReleaseReqList ) ;
//D7000178                        if( rc != RC_OK)
//D7000178                        {
//D7000178                            PPT_METHODTRACE_V1("", "txHoldLotReleaseReq() != RC_OK") ;
//D7000178                            strOpeCompForInternalBufferReqResult.strResult = strHoldLotReleaseReqResult.strResult ;
//D7000178                            return (rc) ;
//D7000178                        }
//D7000178
//D7000178                        //P4200204 Add Start
//D7000178                        //-------------------------------------
//D7000178                        //Return Hold Released LotID for Caller
//D7000178                        //-------------------------------------
//D7000178                        holdReleasedLotIDs[holdReleasedLotCount] = strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID;    //D5100184
//D7000178//D5100184                        holdReleasedLotIDs[holdReleasedLotCount] = strMonitorGroup_DeleteComp_out.strMonitoredCompLots[j].productLotID;
//D7000178
//D7000178                        PPT_METHODTRACE_V3("","Hold Released LotID",holdReleasedLotCount,  holdReleasedLotIDs[holdReleasedLotCount].identifier );
//D7000178                        holdReleasedLotCount++;
//D7000178                        //P4200204 Add End
//D7000178
//D7000178                        //D5100184 Add Start
//D7000178                        //------------------------------------------
//D7000178                        //  Check Lot Type of Monitoring Lot
//D7000178                        //------------------------------------------
//D7000178                        if( CIMFWStrCmp( SP_Lot_Type_ProductionLot, strStartCassette[i].strLotInCassette[j].lotType ) == 0 )
//D7000178                        {
//D7000178                            while( 1 )
//D7000178                            {
//D7000178                                //------------------------------------------
//D7000178                                //  Check whether GatePass is required
//D7000178                                //------------------------------------------
//D7000178                                PPT_METHODTRACE_V2("", "===== repeatGatePass_CheckCondition() ========",
//D7000178                                                       strStartCassette[i].strLotInCassette[j].lotID.identifier);
//D7000178
//D7000178                                objRepeatGatePass_CheckCondition_out  strRepeatGatePass_CheckCondition_out;
//D7000178                                strRepeatGatePass_CheckCondition_out.gatePassRequiredFlag = TRUE;
//D7000178                                rc = repeatGatePass_CheckCondition( strRepeatGatePass_CheckCondition_out,
//D7000178                                                                    strObjCommonIn,
//D7000178                                                                    strStartCassette[i].strLotInCassette[j].lotID,
//D7000178                                                                    strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID );
//D7000178                                if( rc != RC_OK )
//D7000178                                {
//D7000178                                    PPT_METHODTRACE_V2("", "repeatGatePass_CheckCondition() != RC_OK", rc);
//D7000178                                    strOpeCompForInternalBufferReqResult.strResult = strRepeatGatePass_CheckCondition_out.strResult;
//D7000178                                    return( rc );
//D7000178                                }
//D7000178                                if( strRepeatGatePass_CheckCondition_out.gatePassRequiredFlag == FALSE )
//D7000178                                {
//D7000178                                    PPT_METHODTRACE_V1("", "gatePassRequiredFlag == FALSE");
//D7000178                                    break;
//D7000178                                }
//D7000178
//D7000178                                //--------------------------------
//D7000178                                //  Get Monitored Lot's Info
//D7000178                                //--------------------------------
//D7000178                                objLot_currentOperationInfo_Get_out  strLot_currentOperationInfo_Get_out;
//D7000178                                rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out,
//D7000178                                                                   strObjCommonIn,
//D7000178                                                                   strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID );
//D7000178                                if( rc != RC_OK )
//D7000178                                {
//D7000178                                    PPT_METHODTRACE_V2("","lot_currentOperationInfo_Get() != RC_OK", rc);
//D7000178                                    strOpeCompForInternalBufferReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult;
//D7000178                                    return( rc );
//D7000178                                }
//D7000178
//D7000178                                //------------------------------------------
//D7000178                                //  Call txGatePassReq()
//D7000178                                //------------------------------------------
//D7000178                                pptGatePassReqResult        strGatePassReqResult;
//D7000178                                CORBA::Long                 seqIndex = 0;
//D7000178                                pptGatePassLotInfoSequence  strGatePassLotInfo;
//D7000178                                objectIdentifierSequence    dummyLotIDs;            //for Return, but it's dummy.
//D7000178
//D7000178                                strGatePassReqResult.strGatePassLotsResult.length( 1 );
//D7000178                                strGatePassLotInfo.length( 1 );
//D7000178                                strGatePassLotInfo[0].lotID =
//D7000178                                                      strMonitorGroup_DeleteComp_out.strMonitoredCompLots[k].productLotID;
//D7000178                                strGatePassLotInfo[0].currentRouteID =
//D7000178                                                      strLot_currentOperationInfo_Get_out.routeID;
//D7000178                                strGatePassLotInfo[0].currentOperationNumber =
//D7000178                                                      CIMFWStrDup( strLot_currentOperationInfo_Get_out.operationNumber );
//D7000178
//D7000178                                rc = txGatePassReq( strGatePassReqResult,
//D7000178                                                    strObjCommonIn,
//D7000178                                                    seqIndex,
//D7000178                                                    strGatePassLotInfo,
//D7000178                                                    claimMemo,
//D7000178                                                    dummyLotIDs );
//D7000178                                if( rc != RC_OK )
//D7000178                                {
//D7000178                                    PPT_METHODTRACE_V2("", "txGatePassReq() != RC_OK", rc);
//D7000178                                    strOpeCompForInternalBufferReqResult.strResult = strGatePassReqResult.strResult;
//D7000178                                    return( rc );
//D7000178                                }
//D7000178                            }
//D7000178                        }
//D7000178                        else
//D7000178                        {
//D7000178                            continue;
//D7000178                        }
//D7000178                        //D5100184 Add End
//D7000178                    }
//D7000178                }
//D7000178            }
//D7000178        }
//D7000178    }
//D7000178    holdReleasedLotIDs.length(holdReleasedLotCount);                              //P4200204
//D7000178    PPT_METHODTRACE_V2("","HoldReleased Lot Count is", holdReleasedLotCount );    //P4200204

//DSIV00000201 add start
    if( PostProcForLotFlag != 1 )
    {
//DSIV00000201 add end
        /*-------------------------------------------*/
        /*   Effect PO's Direction for TEL Furnace   */
        /*-------------------------------------------*/
        objLot_holdRecord_EffectMonitorIssue_out   strLot_holdRecord_EffectMonitorIssue_out;
        rc = lot_holdRecord_EffectMonitorIssue( strLot_holdRecord_EffectMonitorIssue_out,
                                                strObjCommonIn,
                                                strStartCassette );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_holdRecord_EffectMonitorIssue() != RC_OK") ;
            strOpeCompForInternalBufferReqResult.strResult = strLot_holdRecord_EffectMonitorIssue_out.strResult ;
            return( rc );
        }

        CORBA::Long nMonitorHoldEffectLen = 0;
        nMonitorHoldEffectLen = strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList.length() ;
        PPT_METHODTRACE_V2("", "strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList.length()", nMonitorHoldEffectLen) ;

        if( nMonitorHoldEffectLen > 0 )
        {
            pptHoldLotReqResult strHoldLotReqResult ;
            pptHoldListSequence strLotHoldReqList( 1 ) ;
            strLotHoldReqList.length( 1 ) ;

            for( i = 0 ; i< nMonitorHoldEffectLen ; i++ )
            {
                strLotHoldReqList[0].holdType                 = strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList[i].holdType ;
                strLotHoldReqList[0].holdReasonCodeID         = strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList[i].reasonCodeID ;
                strLotHoldReqList[0].holdUserID               = strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList[i].userID ;
                strLotHoldReqList[0].responsibleOperationMark = strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList[i].responsibleOperationMark ;
                strLotHoldReqList[0].routeID                  = strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList[i].routeID ;
                strLotHoldReqList[0].operationNumber          = strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList[i].operationNumber ;
                strLotHoldReqList[0].relatedLotID             = strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList[i].relatedLotID ;
                strLotHoldReqList[0].claimMemo                = strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList[i].claimMemo ;

                rc = txHoldLotReq( strHoldLotReqResult,
                                   strObjCommonIn ,
                                   strLot_holdRecord_EffectMonitorIssue_out.strLotHoldEffectList[i].lotID ,
                                   strLotHoldReqList ) ;

                if ( rc != RC_OK && rc != RC_EXIST_SAME_HOLD )
                {
                    PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
                    strOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult ;
                    return( rc );
                }
            }
        }
//DSIV00000201 add start
    }
//DSIV00000201 add end

//DSIV00000201 add start
    if( PostProcForLotFlag != 1 )
    {
//DSIV00000201 add end
        /*------------------------------------------*/
        /*   Effect Future Hold Direction if Exist  */
        /*------------------------------------------*/
//D4100083    objLot_futureHoldRequests_Effect_out strLot_futureHoldRequests_Effect_out ;

        for( i=0 ; i<scLen; i++ )
        {
            CORBA::Long nLen = strStartCassette[i].strLotInCassette.length();
            for (CORBA::Long j=0; j<nLen; j++)
            {
                 /*---------------------------*/
                 /*   Omit Not-OpeStart Lot   */
                 /*---------------------------*/
                 if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                 {
                     continue;
                 }

                /*------------------------------------------*/
                /*   Effect Future Hold Direction if Exist  */
                /*------------------------------------------*/
//D4100069            objLot_CheckForLCFR_out strLot_CheckForLCFR_out;
//D4100069            rc = lot_CheckForLCFR( strLot_CheckForLCFR_out,
//D4100069                                   strObjCommonIn,
//D4100069                                   strStartCassette[i].strLotInCassette[j].lotID,
//D4100069                                   SP_LotCustomize_DBRECORD );
//D4100069            if ( rc != RC_OK )
//D4100069            {
//D4100069                PPT_METHODTRACE_V2("", "lot_CheckForLCFR() != RC_OK", rc);
//D4100083                rc = lot_futureHoldRequests_Effect(strLot_futureHoldRequests_Effect_out, strObjCommonIn, strStartCassette[i].strLotInCassette[j].lotID) ;
//D4100083                if(rc != RC_OK)
//D4100083                {
//D4100083                    PPT_METHODTRACE_V1("", "lot_futureHoldRequests_Effect() != RC_OK") ;
//D4100083                    strOpeCompForInternalBufferReqResult.strResult = strLot_futureHoldRequests_Effect_out.strResult ;
//D4100083                    return(rc);
//D4100083                }

//D4100069            }
//D4100069            else
//D4100069            {
//D4100069                PPT_METHODTRACE_V1("", "lot_CheckForLCFR() == RC_OK");
//D4100069
//D4100069                objLot_futureHoldRequests_EffectForLCFR_out  strLot_futureHoldRequests_EffectForLCFR_out;
//D4100069                rc = lot_futureHoldRequests_EffectForLCFR( strLot_futureHoldRequests_EffectForLCFR_out, strObjCommonIn, strStartCassette[i].strLotInCassette[j].lotID );
//D4100069                if ( rc == RC_OK )
//D4100069                {
//D4100069                    PPT_METHODTRACE_V1("", "lot_futureHoldRequests_EffectForLCFR() == RC_OK");
//D4100069                    strLot_futureHoldRequests_Effect_out.strLotHoldReqList = strLot_futureHoldRequests_EffectForLCFR_out.strLotHoldReqList;
//D4100069                }
//D4100069                else if ( rc != RC_OPENO_DELETED && rc != RC_ROUTEID_DELETED )
//D4100069                {
//D4100069                    PPT_METHODTRACE_V2("", "lot_futureHoldRequests_EffectForLCFR() != RC_OK", rc);
//D4100069                    strOpeCompForInternalBufferReqResult.strResult = strLot_futureHoldRequests_EffectForLCFR_out.strResult;
//D4100069                    return( rc );
//D4100069                }
//D4100069
//D4100069                PPT_METHODTRACE_V2("", "lot_futureHoldRequests_EffectForLCFR() = ", rc);
//D4100069            }

//D4100083            if( strLot_futureHoldRequests_Effect_out.strLotHoldReqList.length() > 0 )
//D4100083            {
//D4100083 Add Start

                PPT_METHODTRACE_V2("", "i",i);
                PPT_METHODTRACE_V2("", "j",j);
                PPT_METHODTRACE_V2("", "strStartCassette[i].strLotInCassette[j].lotID",strStartCassette[i].strLotInCassette[j].lotID.identifier);

                /*------------------------------------------------------------------*/
                /*   Get Effected Future Hold PRE of Current after Operation Move   */
                /*------------------------------------------------------------------*/
                PPT_METHODTRACE_V1("", "Get Effected Future Hold PRE of Current after Operation Move") ;

                pptEffectCondition strEffectCondition;
                strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_PRE );
                strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_ALL );

                objLot_futureHoldRequests_EffectByCondition_out strLot_futureHoldRequests_EffectByCondition_out;
                rc = lot_futureHoldRequests_EffectByCondition( strLot_futureHoldRequests_EffectByCondition_out,
                                                               strObjCommonIn,
                                                               strStartCassette[i].strLotInCassette[j].lotID,
                                                               strEffectCondition);
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_futureHoldRequests_EffectByCondition() != RC_OK") ;
                    strOpeCompForInternalBufferReqResult.strResult = strLot_futureHoldRequests_EffectByCondition_out.strResult ;
                    return( rc );
                }

                if( strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList.length() > 0 )
                {
                    PPT_METHODTRACE_V1("", "strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList.length() > 0") ;

//D4100083 Add End

                    pptHoldLotReqResult strHoldLotReqResult ;
                    rc = txHoldLotReq( strHoldLotReqResult,
                                       strObjCommonIn,
                                       strStartCassette[i].strLotInCassette[j].lotID,
                                       strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList ) ;  //D4100083
//D4100083                                   strLot_futureHoldRequests_Effect_out.strLotHoldReqList ) ;

                    if ( rc != RC_OK && rc != RC_EXIST_SAME_HOLD )
                    {
                        PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
                        strOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult ;
                        return(rc);
                    }
                }

//D4100083 Add Start
                /*------------------------------------------------------------------------------------*/
                /*   Get Effected Future Hold Cancel PRE and SINGLE of Current after Operation Move   */
                /*------------------------------------------------------------------------------------*/
                PPT_METHODTRACE_V1("", "Get Effected Future Hold Cancel PRE and SINGLE of Current after Operation Move") ;

                strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_PRE );
                strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_SINGLE );

                objLot_futureHoldRequests_DeleteEffectedByCondition_out strLot_futureHoldRequests_DeleteEffectedByCondition_out;
                rc = lot_futureHoldRequests_DeleteEffectedByCondition( strLot_futureHoldRequests_DeleteEffectedByCondition_out,
                                                                       strObjCommonIn,
                                                                       strStartCassette[i].strLotInCassette[j].lotID,
                                                                       strEffectCondition );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_futureHoldRequests_DeleteEffectedByCondition() != RC_OK") ;
                    strOpeCompForInternalBufferReqResult.strResult = strLot_futureHoldRequests_DeleteEffectedByCondition_out.strResult ;
                    return( rc );
                }

                if ( strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList.length() > 0 )
                {
                    PPT_METHODTRACE_V1("", "strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList.length() > 0") ;
                    pptFutureHoldCancelReqResult strFutureHoldCancelReqResult ;
                    rc = txFutureHoldCancelReq( strFutureHoldCancelReqResult,
                                                strObjCommonIn,
                                                strStartCassette[i].strLotInCassette[j].lotID,
                                                releaseReasonCodeID,
                                                SP_EntryType_Remove,
                                                strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList);
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "txFutureHoldCancelReq() != RC_OK") ;
                        strOpeCompForInternalBufferReqResult.strResult = strFutureHoldCancelReqResult.strResult ;
                        return( rc );
                    }
                }

//D4100083 Add End

            }
        }
//DSIV00000201 add start
    }
//DSIV00000201 add end


    /*----------------------------------------------------*/
    /*                                                    */
    /*   Equipment Related Information Update Procedure   */
    /*                                                    */
    /*----------------------------------------------------*/

    /*----------------------------------------------------------------*/
    /*   Remove ControlJobLot from EqpInfo's ProcessingLot Sequence   */
    /*----------------------------------------------------------------*/
    objEquipment_processingLot_Delete_out   strEquipment_processingLot_Delete_out;
    rc = equipment_processingLot_Delete( strEquipment_processingLot_Delete_out,
                                         strObjCommonIn,
                                         equipmentID,
                                         strStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "equipment_processingLot_Delete() != RC_OK") ;
        strOpeCompForInternalBufferReqResult.strResult = strEquipment_processingLot_Delete_out.strResult ;
        return(rc);
    }

    /*---------------------------------------------*/
    /*   Maintain Eqp's Status when OFF-LINE Mode  */
    /*---------------------------------------------*/
    if (CIMFWStrCmp( strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode,
                     SP_Eqp_OnlineMode_Offline ) == 0)
    {
        PPT_METHODTRACE_V1("", "strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode == SP_Eqp_OnlineMode_Offline") ;

        /*--------------------------------------------------------*/
        /*   Change Equipment's Status to 'STANDBY' if necessary  */
        /*--------------------------------------------------------*/

        /*===== get StateChangeableFlag ===*/
        objEquipment_currentState_CheckToManufacturing_out   strEquipment_currentState_CheckToManufacturing_out;
        strEquipment_currentState_CheckToManufacturing_out.ManufacturingStateChangeableFlag = FALSE;
        rc = equipment_currentState_CheckToManufacturing( strEquipment_currentState_CheckToManufacturing_out,
                                                          strObjCommonIn,
                                                          equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "equipment_currentState_CheckToManufacturing() != RC_OK") ;
            strOpeCompForInternalBufferReqResult.strResult = strEquipment_currentState_CheckToManufacturing_out.strResult ;
            return(rc);
        }

        if ( strEquipment_currentState_CheckToManufacturing_out.ManufacturingStateChangeableFlag == TRUE )
        {
            PPT_METHODTRACE_V1("", "strEquipment_currentState_CheckToManufacturing_out.ManufacturingStateChangeableFlag == TRUE") ;

            /*===== get Defaclt Status Code for Productive / Standby ===*/
            objEquipment_recoverState_GetManufacturing_out   strEquipment_currentState_CheckToManufacturing_out;
            rc = equipment_recoverState_GetManufacturing( strEquipment_currentState_CheckToManufacturing_out,
                                                          strObjCommonIn,
                                                          equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "equipment_recoverState_GetManufacturing() != RC_OK") ;
                strOpeCompForInternalBufferReqResult.strResult = strEquipment_currentState_CheckToManufacturing_out.strResult ;
                return(rc);
            }

            /*---------------------------------*/
            /*   Call txEqpStatusChangeReq()   */
            /*---------------------------------*/
            pptEqpStatusChangeReqResult strEqpStatusChangeReqResult ;
            objectIdentifier equipmentStatus = strEquipment_currentState_CheckToManufacturing_out.equipmentStatusCode;

            rc = txEqpStatusChangeReq( strEqpStatusChangeReqResult, strObjCommonIn, equipmentID, equipmentStatus, claimMemo );
            if ( rc != RC_OK && rc != RC_INVALID_STATE_TRANSITION )
            {
                PPT_METHODTRACE_V1("", "txEqpStatusChangeReq() != RC_OK") ;
                strOpeCompForInternalBufferReqResult.strResult = strEqpStatusChangeReqResult.strResult ;
                return(rc);
            }
        }
    }

    /*--------------------------------------*/
    /*   Equipment Usage Limitation Check   */
    /*--------------------------------------*/
    objEquipment_usageLimitation_Check_out   strEquipment_usageLimitation_Check_out;
    strEquipment_usageLimitation_Check_out.usageLimitOverFlag = FALSE;
    rc = equipment_usageLimitation_Check( strEquipment_usageLimitation_Check_out, strObjCommonIn, equipmentID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "equipment_usageLimitation_Check() != RC_OK") ;
        strOpeCompForInternalBufferReqResult.strResult = strEquipment_usageLimitation_Check_out.strResult ;
        return(rc);
    }

    if ( strEquipment_usageLimitation_Check_out.usageLimitOverFlag == TRUE )
    {
        PPT_METHODTRACE_V1("", "strEquipment_usageLimitation_Check_out.usageLimitOverFlag == TRUE") ;

        /*-------------------------*/
        /*   Call System Message   */
        /*-------------------------*/
        pptSystemMsgRptResult strSystemMsgRptResult;
        objectIdentifier      dummy;

        rc = txSystemMsgRpt( strSystemMsgRptResult,
                             strObjCommonIn,
                             SP_SubSystemID_MM,
                             SP_SystemMsgCode_EqpUsageLimitOver,
                             strEquipment_usageLimitation_Check_out.messageText,
                             TRUE,
                             equipmentID,
                             "",
                             dummy,
                             "",
                             dummy,
                             "",
                             dummy,
                             "",
                             dummy,
                             dummy,
                             "",
                             strObjCommonIn.strTimeStamp.reportTimeStamp,
                             "" );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "txSystemMsgRpt() != RC_OK") ;
            strOpeCompForInternalBufferReqResult.strResult = strSystemMsgRptResult.strResult ;
            return(rc);
        }
    }


    /*----------------------------------------------------*/
    /*                                                    */
    /*   ControlJob Related Information Update Proceure   */
    /*                                                    */
    /*----------------------------------------------------*/

    /*------------------------*/
    /*   Delete Control Job   */
    /*------------------------*/
//D7000006    objControlJob_Delete_out   strControlJob_Delete_out;
//D7000006    rc = controlJob_Delete( strControlJob_Delete_out, strObjCommonIn, controlJobID );
//D7000006    if ( rc != RC_OK )
//D7000006    {
//D7000006        PPT_METHODTRACE_V1("", "controlJob_Delete() != RC_OK") ;
//D7000006        strOpeCompForInternalBufferReqResult.strResult = strControlJob_Delete_out.strResult ;
//D7000006        return(rc);
//D7000006    }
//D7000006 Add Start
//DSN000015229 Add Start
    if ( 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC015" )    //TxPartialOpeCompWithDataReq
      && 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC016" ) )  //TxPartialOpeCompForInternalBufferReq
    {
        PPT_METHODTRACE_V1("", "strObjCommonIn.transactionID != TXEWC015 && TXEWC016");
//DSN000015229 Add End
        pptControlJobManageReqResult strControlJobManageReqResult;
        pptControlJobCreateRequest   dummyControlJobCreateRequest;
//D7000178    rc = txControlJobManageReq( strControlJobManageReqResult,
//D7000178                                strObjCommonIn,
//D7000178                                controlJobID,
//D7000178                                SP_ControlJobAction_Type_delete,
//D7000178                                dummyControlJobCreateRequest,
//D7000178                                claimMemo );
//D7000178    if ( rc != RC_OK )
//D7000178    {
//D7000178        PPT_METHODTRACE_V1( "", "txControlJobManageReq() != RC_OK");
//D7000178        strOpeCompForInternalBufferReqResult.strResult = strControlJobManageReqResult.strResult;
//D7000178        return( rc );
//D7000178    }

//D7000178 Add Start

        //----------------------------------------------------------------------------------
        // Delete ControlJob from EQP.
        // The relation of it with Lot and Cassette is deleted in txCollectedDataActionReq.
        //----------------------------------------------------------------------------------
        rc = txControlJobManageReq( strControlJobManageReqResult,
                                    strObjCommonIn,
                                    controlJobID,
                                    SP_ControlJobAction_Type_delete_From_EQP,
                                    dummyControlJobCreateRequest,
                                    claimMemo );
//DSN000015229 Add Start
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "txControlJobManageReq() != RC_OK", rc);
            strOpeCompForInternalBufferReqResult.strResult = strControlJobManageReqResult.strResult;
            return( rc );
        }
    }
//DSN000015229 Add End

//D7000178 Add End
//D7000006 Add End


    /*---------------------------------------------------*/
    /*                                                   */
    /*   Cassette Related Information Update Procedure   */
    /*                                                   */
    /*---------------------------------------------------*/
//INN-R170003 Add Start
    objEquipment_onlineMode_Get_out strEquipment_onlineMode_Get_out;
    rc = equipment_onlineMode_Get( strEquipment_onlineMode_Get_out, strObjCommonIn, equipmentID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipment_onlineMode_Get() rc != RC_OK", rc);
        strOpeCompForInternalBufferReqResult.strResult = strEquipment_onlineMode_Get_out.strResult;
        return rc;
    }
//INN-R170003 Add End
    for ( i=0; i<scLen; i++ )
    {
//INN-R170003 Add Start
        /*-------------------------------------*/
        /*   Cassette Usage Limitation Check   */
        /*-------------------------------------*/
        //objCassette_usageLimitation_Check_out   strCassette_usageLimitation_Check_out;
        //strCassette_usageLimitation_Check_out.usageLimitOverFlag = FALSE;
        //rc = cassette_usageLimitation_Check( strCassette_usageLimitation_Check_out, strObjCommonIn, strStartCassette[i].cassetteID );
        //if ( rc != RC_OK )
        //{
        //    PPT_METHODTRACE_V1("", "cassette_usageLimitation_Check() != RC_OK") ;
        //    strOpeCompForInternalBufferReqResult.strResult = strCassette_usageLimitation_Check_out.strResult ;
        //    return(rc);
        //}
        //
        //if ( strCassette_usageLimitation_Check_out.usageLimitOverFlag == TRUE )
        //{
        //    PPT_METHODTRACE_V1("", "strCassette_usageLimitation_Check_out.usageLimitOverFlag == TRUE") ;
        //
        //    /*-------------------------*/
        //    /*   Call System Message   */
        //    /*-------------------------*/
        //    pptSystemMsgRptResult strSystemMsgRptResult;
        //    objectIdentifier      dummy;
        //
        //    rc = txSystemMsgRpt( strSystemMsgRptResult,
        //                         strObjCommonIn,
        //                         SP_SubSystemID_MM,
        //                         SP_SystemMsgCode_CastUsageLimitOver,
        //                         strCassette_usageLimitation_Check_out.messageText,
        //                         TRUE,
        //                         dummy,
        //                         "",
        //                         dummy,
        //                         "",
        //                         dummy,
        //                         "",
        //                         dummy,
        //                         "",
        //                         dummy,
        //                         dummy,
        //                         "",
        //                         strObjCommonIn.strTimeStamp.reportTimeStamp,
        //                         "" );
        //    if ( rc != RC_OK )
        //    {
        //        PPT_METHODTRACE_V1("", "txSystemMsgRpt() != RC_OK") ;
        //        strOpeCompForInternalBufferReqResult.strResult = strSystemMsgRptResult.strResult ;
        //        return(rc);
        //    }
        //}
        if( 0 == CIMFWStrCmp(strEquipment_onlineMode_Get_out.onlineMode, SP_Eqp_OnlineMode_Offline))
        {
            pptLotCassetteXferStatusChangeRptResult strLotCassetteXferStatusChangeRptResult;
            rc= txLotCassetteXferStatusChangeRpt__160( strLotCassetteXferStatusChangeRptResult, strObjCommonIn, 
                                         strStartCassette[i].cassetteID, SP_TransState_EquipmentOut, FALSE,
                                         equipmentID, strStartCassette[i].unloadPortID, "", "",
                                         strObjCommonIn.strTimeStamp.reportTimeStamp,
                                         claimMemo);
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "CS_PPTManager_i:: cs_txOpeCompWithDataReq__120OR", "txLotCassetteXferStatusChangeRpt__160() != RC_OK" );
                strOpeCompForInternalBufferReqResult.strResult = strLotCassetteXferStatusChangeRptResult.strResult;
                return( rc );
            }
        }
//INN-R170003 Add End 
        /*---------------------------------------*/
        /*   Update Cassette's MultiLotType      */
        /*---------------------------------------*/
        objCassette_multiLotType_Update_out   strCassette_multiLotType_Update_out;
        rc = cassette_multiLotType_Update( strCassette_multiLotType_Update_out, strObjCommonIn, strStartCassette[i].cassetteID );
        if ( rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "cassette_multiLotType_Update() != RC_OK") ;
            strOpeCompForInternalBufferReqResult.strResult = strCassette_multiLotType_Update_out.strResult ;
            return(rc);
        }
    }

//DSIV00000201 add start
    if( PostProcForLotFlag != 1 )
    {
//DSIV00000201 add end
//D40A0027 add start
        //-------------------------------------------------// //D40A0027
        //                                                 // //D40A0027
        //   ProcessLagTime Information Update Procedure   // //D40A0027
        //                                                 // //D40A0027
        //-------------------------------------------------// //D40A0027
        PPT_METHODTRACE_V1("", "ProcessLagTime Information Update Procedure...") ;
        for ( i=0 ; i<scLen ; i++ )
        {

            PPT_METHODTRACE_V2("", "strStartCassette[i].strLotInCassette.length()=>", nLen) ;
            CORBA::Long nLen = strStartCassette[i].strLotInCassette.length();
            for (CORBA::Long j=0; j<nLen; j++ )
            {

                //---------------------------//
                //   Omit Not-OpeStart Lot   //
                //---------------------------//
                PPT_METHODTRACE_V1("", "Omit Not-OpeStart Lot...") ;
                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    continue;
                }

                //--------------------------------------//
                //   Call txProcessLagTimeUpdateReq()   //
                //--------------------------------------//
                PPT_METHODTRACE_V1("", "Call txProcessLagTimeUpdateReq()...") ;
                pptProcessLagTimeUpdateReqResult strProcessLagTimeUpdateReqResult;
                rc = txProcessLagTimeUpdateReq( strProcessLagTimeUpdateReqResult,
                                                strObjCommonIn,
                                                strStartCassette[i].strLotInCassette[j].lotID,
                                                SP_ProcessLagTime_Action_Set,
                                                claimMemo );
                if ( rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "txProcessLagTimeUpdateReq() != RC_OK") ;
                    strOpeCompForInternalBufferReqResult.strResult = strProcessLagTimeUpdateReqResult.strResult ;
                    return( rc );
                }

            }

        }
//D40A0027 add end
//DSIV00000201 add start
    }
//DSIV00000201 add end

//DSIV00000201 add start
    if( PostProcForLotFlag != 1 )
    {
//DSIV00000201 add end
//D4200029 Add Start
        for ( i=0 ; i<scLen ; i++ )
        {
            CORBA::Long lcLen=0;
            lcLen = strStartCassette[i].strLotInCassette.length();

            for ( CORBA::Long j = 0; j<lcLen ; j++ )
            {
                PPT_METHODTRACE_V1("","Call txProcessHoldExecReq()");
                pptProcessHoldExecReqResult strProcessHoldExecReqResult;

                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == TRUE )
                {
                    rc = txProcessHoldExecReq( strProcessHoldExecReqResult,
                                               strObjCommonIn,
                                               strStartCassette[i].strLotInCassette[j].lotID,
                                               claimMemo );

                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("","txProcessHoldExecReq() != RC_OK", rc );
                        strOpeCompForInternalBufferReqResult.strResult = strProcessHoldExecReqResult.strResult ;
                        return( rc );
                    }
                }
            }
        }
//D4200029 Add End
//DSIV00000201 add start
    }
//DSIV00000201 add end

//DSN000015229 Add Start
    CORBA::String_var eventTxID;
    if ( 0 == CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC015" )    //TxPartialOpeCompWithDataReq
      || 0 == CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC016" ) )  //TxPartialOpeCompForInternalBufferReq
    {
        PPT_METHODTRACE_V1("", "strObjCommonIn.transactionID == TXEWC015 || TXEWC016");
        eventTxID = strObjCommonIn.transactionID;
    }
    else
    {
        PPT_METHODTRACE_V1("", "strObjCommonIn.transactionID != TXEWC015 && TXEWC016");
        eventTxID = CIMFWStrDup("TXTRC055");
    }
//DSN000015229 Add End

    /*--------------------------*/
    /*                          */
    /*   Event Make Procedure   */
    /*                          */
    /*--------------------------*/
    for ( i=0 ; i<scLen ; i++ )
    {
        PPT_METHODTRACE_V2("", "strStartCassette[i].strLotInCassette.length()=>", nLen) ;
        CORBA::Long nLen = strStartCassette[i].strLotInCassette.length();
        for (CORBA::Long j=0; j<nLen; j++ )
        {

            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                continue;
            }

            PPT_METHODTRACE_V2("", "counter j for lotOperationMoveEvent_MakeOpeComp=", j) ;
            /*--------------------------------------------------------------------*/
            /*   Make OperationMoveEvent for Operation History - OpeComp          */
            /*--------------------------------------------------------------------*/
            objLotOperationMoveEvent_MakeOpeComp_out strLotOperationMoveEvent_MakeOpeComp_out;
            rc = lotOperationMoveEvent_MakeOpeComp( strLotOperationMoveEvent_MakeOpeComp_out,
                                                    strObjCommonIn,
//D4000015 0.02                                     "TXTRC004",
//DSN000015229                                                    "TXTRC055", //D4000015 0.02
//INN-R170085                                                    eventTxID,    //DSN000015229
//INN-R-170085 Start
                                                    "TXTRCO55P",
//INN-R-170085 End                                                   
                                                    equipmentID,
                                                    strPortResource_currentOperationMode_Get_out.strOperationMode.operationMode.identifier,
                                                    controlJobID,
                                                    strStartCassette[i].cassetteID,
                                                    strStartCassette[i].strLotInCassette[j],
                                                    claimMemo );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lotOperationMoveEvent_MakeOpeComp() != RC_OK") ;
                strOpeCompForInternalBufferReqResult.strResult = strLotOperationMoveEvent_MakeOpeComp_out.strResult ;
                return(rc);
            }
        }
    }

//DSIV00000201 add start
    pptCollectedDataActionReqResult    strCollectedDataActionReqResult;

    if( PostProcForLotFlag != 1 )
    {
//DSIV00000201 add end
//D7000178 Add Start
        //-------------------------------------------------//
        //                                                 //
        //     Invoking Action for Collected Data.         //
        //                                                 //
        //-------------------------------------------------//
//DSIV00000201        pptCollectedDataActionReqResult    strCollectedDataActionReqResult;
        pptCollectedDataActionReqInParm    strCollectedDataActionReqInParm;

        strCollectedDataActionReqInParm.controlJobID     = controlJobID;
        strCollectedDataActionReqInParm.equipmentID      = equipmentID;
        strCollectedDataActionReqInParm.strStartCassette = strStartCassette;

        rc = txCollectedDataActionReq ( strCollectedDataActionReqResult,
                                        strObjCommonIn,
                                        strCollectedDataActionReqInParm,
                                        claimMemo );

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "txCollectedDataActionReq() != RC_OK") ;
            strOpeCompForInternalBufferReqResult.strResult = strCollectedDataActionReqResult.strResult;
            return(rc);
        }

        holdReleasedLotIDs                   = strCollectedDataActionReqResult.holdReleasedLotIDs;
        strOpeCompForInternalBufferReqResult = strCollectedDataActionReqResult.strOpeCompWithDataReqResult;
//D7000178 Add End
//DSIV00000201 add start
    }
    else
    {
        pptDataSpecCheckReqResult tg;
        tg.strStartCassette = strStartCassette;
        DebugOutStartCassette( tg );

        //-------------------------------------------------//
        //                                                 //
        //     DataValue CheckValidity for SpeckCheck      //
        //                                                 //
        //-------------------------------------------------//
        objDataValue_CheckValidityForSpecCheckDR_out strDataValue_CheckValidityForSpecCheckDR_out;
        strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.equipmentID      = equipmentID;
        strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.controlJobID     = controlJobID;
        strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette = strStartCassette;

        /*----------------------*/
        /*   Initialize Logic   */
        /*----------------------*/
        PPT_METHODTRACE_V1("", "Initialize Logic...") ;

        /*-------------------------------*/
        /*   Loop for strStartCassette   */
        /*-------------------------------*/
        PPT_METHODTRACE_V1("", "Loop for strStartCassette...") ;
        for ( i=0 ; i<scLen ; i++ )
        {
            /*-------------------------------*/
            /*   Loop for strLotInCassette   */
            /*-------------------------------*/
            PPT_METHODTRACE_V3("", "scLen / i", scLen, i);
            PPT_METHODTRACE_V1("", "Loop for strLotInCassette...") ;

            CORBA::Long lcLen = strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette.length();
            for ( CORBA::Long j=0 ; j<lcLen ; j++ )
            {
                PPT_METHODTRACE_V3("", "lcLen / j", lcLen, j);
                /*------------------------*/
                /*   Omit Not-Start Lot   */
                /*------------------------*/
                PPT_METHODTRACE_V1("", "Omit Not-Start Lot...");

                if ( strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    PPT_METHODTRACE_V1("", "Not-Start Lot. continue...");
                    continue;
                }

                /*---------------------------------*/
                /*   Omit Non-DataClooection Lot   */
                /*---------------------------------*/
                PPT_METHODTRACE_V1("", "Omit Non-DataClooection Lot...");

                if ( strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.dataCollectionFlag == FALSE )
                {
                    PPT_METHODTRACE_V1("", "Non-DCDef Lot. continue...");
                    continue;
                }

                /*-----------*/
                /*   Clear   */
                /*-----------*/
                PPT_METHODTRACE_V1("", "Clear...");
                CORBA::Long dcLen = strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef.length();
                for ( CORBA::Long n=0 ; n<dcLen ; n++ )
                {
                    PPT_METHODTRACE_V3("", "dcLen / n", dcLen, n);
                    CORBA::Long itLen = strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem.length();
                    for ( CORBA::Long l=0 ; l<itLen ; l++ )
                    {
                        PPT_METHODTRACE_V3("", "itLen / l", itLen, l);
//DSN000015229 Add Start
                        CORBA::Boolean bClearFlag = TRUE;
                        if ( 0 == CIMFWStrCmp( SP_DCDef_Meas_PJ , strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].measurementType )
                          || 0 == CIMFWStrCmp( SP_DCDef_Meas_PJWafer , strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].measurementType )
                          || 0 == CIMFWStrCmp( SP_DCDef_Meas_PJWaferSite , strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].measurementType ) )
                        {
                            PPT_METHODTRACE_V5("", "strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].measurementType == SP_DCDef_Meas_PJ||SP_DCDef_Meas_PJWafer||SP_DCDef_Meas_PJWaferSite", i, j, n, l);
                            if ( 0 < CIMFWStrLen(strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult) )
                            {
                                PPT_METHODTRACE_V5("", "CIMFWStrLen(strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult) > 0", i, j, n, l);
                                if ( 0 == CIMFWStrCmp( SP_SpecCheckResult_1X_OK , strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult )
                                  || 0 == CIMFWStrCmp( SP_SpecCheckResult_1X_UpperControlLimit , strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult )
                                  || 0 == CIMFWStrCmp( SP_SpecCheckResult_1X_LowerControlLimit , strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult )
                                  || 0 == CIMFWStrCmp( SP_SpecCheckResult_1X_UpperSpecLimit , strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult )
                                  || 0 == CIMFWStrCmp( SP_SpecCheckResult_1X_LowerSpecLimit , strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult )
                                  || 0 == CIMFWStrCmp( SP_SpecCheckResult_1X_UpperScreenLimit , strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult )
                                  || 0 == CIMFWStrCmp( SP_SpecCheckResult_1X_LowerScreenLimit , strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult )
                                  || 0 == CIMFWStrCmp( SP_SpecCheckResult_1X_Asterisk , strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult )
                                  || 0 == CIMFWStrCmp( SP_SpecCheckResult_1X_APCError , strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult )
                                  || 0 == CIMFWStrCmp( SP_SpecCheckResult_1X_Pound , strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult )
                                  || 0 == CIMFWStrCmp( SP_SpecCheckResult_Error , strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult ) )
                                {
                                    //Do Nothing
                                    PPT_METHODTRACE_V1("", "Do Nothing");
                                }
                                else
                                {
                                    PPT_METHODTRACE_V1("", "Set bClearFlag = false");
                                    bClearFlag = false;
                                }
                            }
                        }
                        if (True == bClearFlag)
                        {
//DSN000015229 Add End
//DSN000015229 Indent Start
                            /*===== Clear specCheckResult / actionCode =====*/
                            PPT_METHODTRACE_V1("", "Clear specCheckResult / actionCode...");
                            strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].specCheckResult = (const char *)"";
                            strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].actionCode.length(0);

                            /*===== Clear dataValue =====*/
                            PPT_METHODTRACE_V1("", "Clear dataValue...");
                            if ( CIMFWStrCmp(strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].itemType, SP_DCDef_Item_Raw) == 0 )
                            {
                                PPT_METHODTRACE_V1("", "Raw Item. continue...");
                                continue;
                            }
                            strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[n].strDCItem[l].dataValue = (const char *)"";
//DSN000015229 Indent End
                        }           //DSN000015229
                    }   // Loop for DCItem
                }   // Loop for DCDef
            }   // Loop for strLotInCassette
        }   // Loop for strStartCassette

        /*----------------------------------*/
        /*   Set Initialized Data into PO   */
        /*----------------------------------*/
        PPT_METHODTRACE_V1("", "Set Initialized Data into PO...");
        objProcessOperation_tempData_Set_out strProcessOperation_tempData_Set_out;
        rc = processOperation_tempData_Set( strProcessOperation_tempData_Set_out,
                                            strObjCommonIn,
                                            controlJobID,
                                            strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "processOperation_tempData_Set() != RC_OK");
            strOpeCompForInternalBufferReqResult.strResult = strProcessOperation_tempData_Set_out.strResult;
            return( rc );
        }
//DSIV00001471 Add Start
        /*------------------------------------------------*/
        /*   Set DC Spec's detailed information into PO   */
        /*------------------------------------------------*/
        objProcess_dataCollectionSpecification_Set_out strProcess_dataCollectionSpecification_Set_out;

        rc = process_dataCollectionSpecification_Set( strProcess_dataCollectionSpecification_Set_out,
                                                      strObjCommonIn,
                                                      strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "process_dataCollectionSpecification_Set() != RC_OK");
            strOpeCompForInternalBufferReqResult.strResult = strProcess_dataCollectionSpecification_Set_out.strResult;
            return( rc );
        }
        strDataValue_CheckValidityForSpecCheckDR_out.strDataSpecCheckReqResult.strStartCassette = strProcess_dataCollectionSpecification_Set_out.strStartCassette;
        PPT_METHODTRACE_V1("", "Do dataValue_CheckValidityForSpecCheck");
//DSIV00001471 Add End
        /*--------------------*/
        /*   Validity Check   */
        /*--------------------*/
        rc = dataValue_CheckValidityForSpecCheckDR(strDataValue_CheckValidityForSpecCheckDR_out, strObjCommonIn);
        switch ( rc )
        {
            case RC_OK:
                PPT_METHODTRACE_V1("", "dataValue_CheckValidityForSpecCheckDR() == RC_OK") ;
                break;
            case RC_ALL_DATAVAL_ASTERISK:
                PPT_METHODTRACE_V1("", "dataValue_CheckValidityForSpecCheckDR() == RC_ALL_DATAVAL_ASTERISK") ;
                rc = RC_OK;
                break;
            default:
                PPT_METHODTRACE_V1("", "dataValue_CheckValidityForSpecCheckDR() != RC_OK") ;
                strOpeCompForInternalBufferReqResult.strResult = strDataValue_CheckValidityForSpecCheckDR_out.strResult;
                return(rc);
        }
//DSN000015229 Add Start
        if ( 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC015" )    //TxPartialOpeCompWithDataReq
          && 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC016" ) )  //TxPartialOpeCompForInternalBufferReq
        {
//DSN000015229 Add End

            //---------------------------------------------//
            //   Delete Control Job From Lot and Cassette  //
            //---------------------------------------------//
            PPT_METHODTRACE_V1( "", "Delete controlJob from Lot and Cassette.");
            pptControlJobManageReqResult strControlJobManageReqResult2;
            pptControlJobCreateRequest   dummyControlJobCreateRequest2;
            rc = txControlJobManageReq( strControlJobManageReqResult2,
                                        strObjCommonIn,
                                        controlJobID,
                                        SP_ControlJobAction_Type_delete_From_LotAndCassette,
                                        dummyControlJobCreateRequest2,
                                        claimMemo );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "txControlJobManageReq() != RC_OK");
                strOpeCompForInternalBufferReqResult.strResult = strControlJobManageReqResult2.strResult;
                return( rc );
            }
        }   //DSN000015229
    }
//DSIV00000201 add end

//DSIV00000201 add start
    if( PostProcForLotFlag != 1 )
    {
//DSIV00000201 add end
//D4100120 Add Start
        /*-----------------------------*/
        /*   Future Action Procedure   */
        /*-----------------------------*/
        for (i=0;i<scLen;i++)
        {
            CORBA::Long nLen = strStartCassette[i].strLotInCassette.length();
            for (CORBA::Long j=0;j<nLen;j++)
            {
                /*---------------------------*/
                /*   Omit Not-OpeStart Lot   */
                /*---------------------------*/
                if (strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE)
                {
                    continue;
                }

                CORBA::String_var tmpRouteID = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID.identifier;
//DSIV00002435                objSchdlChangeReservation_CheckForAction_out strSchdlChangeReservation_CheckForAction_out;
//DSIV00002435                rc = schdlChangeReservation_CheckForActionDR(strSchdlChangeReservation_CheckForAction_out,
//DSIV00002435                                                             strObjCommonIn,
//DSIV00002435                                                             strStartCassette[i].strLotInCassette[j].lotID,
//DSIV00002435                                                             tmpRouteID,
//DSIV00002435                                                             strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber);
//DSIV00002435 add start
                objSchdlChangeReservation_CheckForActionDR_out__110 strSchdlChangeReservation_CheckForAction_out;
                objSchdlChangeReservation_CheckForActionDR_in__110  strSchdlChangeReservation_CheckForActionDR_in;
                strSchdlChangeReservation_CheckForActionDR_in.lotID           = strStartCassette[i].strLotInCassette[j].lotID;
                strSchdlChangeReservation_CheckForActionDR_in.routeID         = tmpRouteID;
                strSchdlChangeReservation_CheckForActionDR_in.operationNumber = strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber;
                rc = schdlChangeReservation_CheckForActionDR__110( strSchdlChangeReservation_CheckForAction_out,
                                                                   strObjCommonIn,
                                                                   strSchdlChangeReservation_CheckForActionDR_in );
//DSIV00002435 add end
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "schdlChangeReservation_CheckForActionDR() != RC_OK") ;
                    strOpeCompForInternalBufferReqResult.strResult = strSchdlChangeReservation_CheckForAction_out.strResult;
                    return(rc);
                }

                if (strSchdlChangeReservation_CheckForAction_out.existFlag == True)
                {
                    pptSchdlChangeReservationExecuteReqResult strSchdlChangeReservationExecuteReqResult;
//DSIV00002435                    pptRescheduledLotAttributesSequence strRescheduledLotAttributes;
                    pptRescheduledLotAttributesSequence__110 strRescheduledLotAttributes;        //DSIV00002435
                    strRescheduledLotAttributes.length(1);
                    strRescheduledLotAttributes[0].lotID                  = strStartCassette[i].strLotInCassette[j].lotID;
                    strRescheduledLotAttributes[0].productID              = strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation.productID;
                    strRescheduledLotAttributes[0].routeID                = strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation.routeID;
                    strRescheduledLotAttributes[0].currentOperationNumber = strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation.operationNumber;
                    strRescheduledLotAttributes[0].subLotType             = strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation.subLotType;          //DSIV00002435

//P5100473 Add Start
                    //------------------------------------------------------------------------//
                    // Get current RouteID by lotID                                           //
                    //------------------------------------------------------------------------//
                    objLot_currentRouteID_Get_out       strLot_currentRouteID_Get_out;
                    rc = lot_currentRouteID_Get( strLot_currentRouteID_Get_out,
                                                 strObjCommonIn,
                                                 strStartCassette[i].strLotInCassette[j].lotID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_currentRouteID_Get() != RC_OK :", rc);
                        strOpeCompForInternalBufferReqResult.strResult = strLot_currentRouteID_Get_out.strResult;
                        return( rc );
                    }

                    strRescheduledLotAttributes[0].originalRouteID = strLot_currentRouteID_Get_out.currentRouteID.identifier;
                    PPT_METHODTRACE_V2( "", "OriginalRouteID", strRescheduledLotAttributes[0].originalRouteID );

                    //------------------------------------------------------------------------//
                    // Get current oparation No. by lotID                                     //
                    //------------------------------------------------------------------------//
                    objLot_currentOpeNo_Get_out strLot_currentOpeNo_Get_out;
                    rc = lot_currentOpeNo_Get(strLot_currentOpeNo_Get_out,
                                              strObjCommonIn,
                                              strStartCassette[i].strLotInCassette[j].lotID);
                    if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V2("", "lot_currentOpeNo_Get() != RC_OK",rc);
                        strOpeCompForInternalBufferReqResult.strResult = strLot_currentOpeNo_Get_out.strResult;
                        return(rc);
                    }

                    strRescheduledLotAttributes[0].originalOperationNumber = CIMFWStrDup( strLot_currentOpeNo_Get_out.currentOperationNumber );
                    PPT_METHODTRACE_V2("","OroginalOperationNumber",strRescheduledLotAttributes[0].originalOperationNumber);
//P5100473 Add End

//DSIV00002435                    rc = txSchdlChangeReservationExecuteReq(strSchdlChangeReservationExecuteReqResult,
                    rc = txSchdlChangeReservationExecuteReq__110(strSchdlChangeReservationExecuteReqResult,     //DSIV00002435
                                                            strObjCommonIn,
                                                            strRescheduledLotAttributes,
                                                            strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation.eventID);

                    if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "txSchdlChangeReservationExecuteReq() != RC_OK") ;
                        strOpeCompForInternalBufferReqResult.strResult = strSchdlChangeReservationExecuteReqResult.strResult;
                        return(rc);
                    }

//DSIV00002435                    objSchdlChangeReservation_applyCount_Increase_out strSchdlChangeReservation_applyCount_Increase_out;
//DSIV00002435                    rc = schdlChangeReservation_applyCount_IncreaseDR(strSchdlChangeReservation_applyCount_Increase_out,
//DSIV00002435                                                                      strObjCommonIn,
//DSIV00002435                                                                      strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation);
//DSIV00002435 add start
                    objSchdlChangeReservation_applyCount_Increase_out       strSchdlChangeReservation_applyCount_Increase_out;
                    objSchdlChangeReservation_applyCount_IncreaseDR_in__110 strSchdlChangeReservation_applyCount_IncreaseDR_in;
                    strSchdlChangeReservation_applyCount_IncreaseDR_in.strSchdlChangeReservation = strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation;
                    rc = schdlChangeReservation_applyCount_IncreaseDR__110( strSchdlChangeReservation_applyCount_Increase_out,
                                                                            strObjCommonIn,
                                                                            strSchdlChangeReservation_applyCount_IncreaseDR_in );
//DSIV00002435 add end
                    if (rc != RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "schdlChangeReservation_applyCount_IncreaseDR() != RC_OK") ;
                        strOpeCompForInternalBufferReqResult.strResult = strSchdlChangeReservation_applyCount_Increase_out.strResult;
                        return(rc);
                    }
                }
            }
        }
//D4100120 Add End
//DSIV00000201 add start
    }
//DSIV00000201 add end

    /*------------------------------------------------------------------------*/
    /*                                                                        */
    /*   BR Script Procedure                                                  */
    /*                                                                        */
    /*------------------------------------------------------------------------*/

    /*-----------------------*/
    /*   Execute BRScript    */
    /*-----------------------*/
    for ( i=0 ; i<scLen ; i++ )
    {
        CORBA::Long nLen = strStartCassette[i].strLotInCassette.length();
        for (CORBA::Long j=0; j<nLen; j++ )
        {
            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                continue;
            }

            /*-------------------------*/
            /*   Execute Post BRScript */
            /*-------------------------*/
            pptRunBRScriptReqResult strRunBRScriptReqResult;
            rc = txRunBRScriptReq( strRunBRScriptReqResult,
                                   strObjCommonIn,
                                   SP_BRScript_Post,
                                   strStartCassette[i].strLotInCassette[j].lotID,
                                   equipmentID );
            if ( rc == RC_NOT_FOUND_SCRIPT )
            {
                PPT_METHODTRACE_V1("", "txRunBRScriptReq() == RC_NOT_FOUND_SCRIPT") ;
            }
            else if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "txRunBRScriptReq() != RC_OK") ;
                strOpeCompForInternalBufferReqResult.strResult = strRunBRScriptReqResult.strResult ;
                return(rc);
            }
        }
    }

//DSIV00000201 add start
    if( PostProcForLotFlag != 1 )
    {
//DSIV00000201 add end
        /*---------------------------------------------------------------*/
        /*   Auto-Bank-In Procedure                                      */
        /*---------------------------------------------------------------*/

//PSIV00001188        CORBA::Long biLen = autoBankInLotIDs.length();
//PSIV00001188
//PSIV00001188        pptBankInReqResult strBankInReqResult;
//PSIV00001188        strBankInReqResult.strBankInLotResult.length(biLen);
//PSIV00001188
//PSIV00001188        PPT_METHODTRACE_V2("", "autoBankInLotIDs.length()", biLen) ;
//PSIV00001188
//PSIV00001188        for ( i=0 ; i<biLen ; i++ )
//PSIV00001188        {
//PSIV00001188            objLot_holdState_Get_out  strLot_holdState_Get_out;
//PSIV00001188            rc = lot_holdState_Get( strLot_holdState_Get_out, strObjCommonIn, autoBankInLotIDs[i]);

//PSIV00001188 Add Start
        pptBankInReqResult strBankInReqResult;
        strBankInReqResult.strBankInLotResult.length(opeStartLotCount);

        for (i = 0; i < opeStartLotCount; i++)
        {
            objLot_CheckConditionForAutoBankIn_out  strLot_CheckConditionForAutoBankIn_out;
            objLot_CheckConditionForAutoBankIn_in   strLot_CheckConditionForAutoBankIn_in;
            strLot_CheckConditionForAutoBankIn_in.lotID = opeStartLotIDs[i];

            rc = lot_CheckConditionForAutoBankIn( strLot_CheckConditionForAutoBankIn_out,
                                                  strObjCommonIn,
                                                  strLot_CheckConditionForAutoBankIn_in  );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("","lot_CheckConditionForAutoBankIn() != RC_OK", rc);
                strOpeCompForInternalBufferReqResult.strResult = strLot_CheckConditionForAutoBankIn_out.strResult;
                return rc;
            }

            if (!strLot_CheckConditionForAutoBankIn_out.autoBankInFlag)
            {
                continue;
            }

            objLot_holdState_Get_out  strLot_holdState_Get_out;
            rc = lot_holdState_Get( strLot_holdState_Get_out, strObjCommonIn, opeStartLotIDs[i]);
//PSIV00001188 Add End

//P9000028 add start
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_holdState_Get() != RC_OK") ;
                strOpeCompForInternalBufferReqResult.strResult = strLot_holdState_Get_out.strResult ;
                return(rc);
            }

            if (CIMFWStrCmp( strLot_holdState_Get_out.lotHoldState, CIMFW_Lot_HoldState_OnHold ) == 0)
            {
                PPT_METHODTRACE_V1("", "CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState, CIMFW_Lot_HoldState_OnHold ) == 0") ;
                strOpeCompForInternalBufferReqResult.strResult = strLot_holdState_Get_out.strResult ;
                continue ;
            }
//P9000028 add end

//P9000028 delete start
//P9000028        if (CIMFWStrCmp( strLot_holdState_Get_out.lotHoldState, CIMFW_Lot_HoldState_OnHold ) == 0)
//P9000028        {
//P9000028            PPT_METHODTRACE_V1("", "CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState, CIMFW_Lot_HoldState_OnHold ) == 0") ;
//P9000028            strOpeCompForInternalBufferReqResult.strResult = strLot_holdState_Get_out.strResult ;
//P9000028            continue ;
//P9000028        }
//P9000028        else if ( rc != RC_OK )
//P9000028        {
//P9000028            PPT_METHODTRACE_V1("", "lot_holdState_Get() != RC_OK") ;
//P9000028            strOpeCompForInternalBufferReqResult.strResult = strLot_holdState_Get_out.strResult ;
//P9000028            return(rc);
//P9000028        }
//P9000028 delete end

            /*-----------------------------------------*/
            /*   Call txBankInReq() for Auto-Bank-In   */
            /*-----------------------------------------*/
//PSIV00001188            rc = txBankInReq( strBankInReqResult, strObjCommonIn, i, autoBankInLotIDs, claimMemo );
            rc = txBankInReq( strBankInReqResult, strObjCommonIn, i, opeStartLotIDs, claimMemo);      //PSIV00001188
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "txBankInReq() != RC_OK") ;
                strOpeCompForInternalBufferReqResult.strResult = strBankInReqResult.strResult ;
                return(rc);
            }

        }
//DSIV00000201 add start
    }
//DSIV00000201 add end

//D7000178//D4200115 add start
//D7000178    /*---------------------------------------------------------------*/
//D7000178    /*   New Action by SPC Check result                              */
//D7000178    /*---------------------------------------------------------------*/
//D7000178    pptSpcActionExecuteReqResult strSpcActionExecuteReqResult;
//D7000178    rc = txSpcActionExecuteReq( strSpcActionExecuteReqResult,
//D7000178                                strObjCommonIn,
//D7000178                                strStartLot_actionList_EffectSPCCheck_out.strBankMoveList,
//D7000178                                strStartLot_actionList_EffectSPCCheck_out.strMailSendList,
//D7000178                                strStartLot_actionList_EffectSPCCheck_out.strReworkBranchList,
//D7000178                                claimMemo );
//D7000178    if ( rc != RC_OK )
//D7000178    {
//D7000178        PPT_METHODTRACE_V1("", "txSpcActionExecuteReq() != RC_OK") ;
//D7000178        strOpeCompForInternalBufferReqResult.strResult = strSpcActionExecuteReqResult.strResult ;
//D7000178        return(rc);
//D7000178    }
//D7000178//D4200115 add end

//D7000180 start (move to lower)
//D7000180//D5100232 start
//D7000180    /*------------------------------------------------------------------------*/
//D7000180    /*                                                                        */
//D7000180    /*   Send OpeComp Report to DCS Procedure                                 */
//D7000180    /*                                                                        */
//D7000180    /*------------------------------------------------------------------------*/
//D7000180    CORBA::Boolean bDCSAvailable = FALSE;
//D7000180    CORBA::String_var DCSAvailable = CIMFWStrDup(getenv(SP_DCS_Available));
//D7000180    PPT_METHODTRACE_V2("", "DCSAvailable", DCSAvailable);
//D7000180    if (CIMFWStrCmp(DCSAvailable, "1") == 0 )
//D7000180    {
//D7000180        PPT_METHODTRACE_V1("", "DCS Interface Available");
//D7000180        bDCSAvailable = TRUE;
//D7000180    }
//D7000180
//D7000180    if ( 0 != CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode, SP_Eqp_OnlineMode_Offline)
//D7000180      && TRUE == bDCSAvailable )
//D7000180    {
//D7000180        PPT_METHODTRACE_V1("", "Send OpeComp Report to DCS");
//D7000180
//D7000180        CORBA::String_var IgnoreErr = CIMFWStrDup(getenv(SP_DCS_Ignore_OpeComp_Result));
//D7000180        PPT_METHODTRACE_V2("", "SP_DCS_IGNORE_OPECOMP_RESULT", IgnoreErr);
//D7000180
//D7000180        objDCSMgr_SendOperationCompletedRpt_out strDCSMgr_SendOperationCompletedRpt_out;
//D7000180        rc = DCSMgr_SendOperationCompletedRpt( strDCSMgr_SendOperationCompletedRpt_out, strObjCommonIn, controlJobID );
//D7000180
//D7000180        if ( rc != RC_OK && 0 != CIMFWStrCmp(IgnoreErr, "1") )
//D7000180        {
//D7000180            PPT_METHODTRACE_V2("", "##### DCSMgr_SendOperationCompletedRpt() != RC_OK", rc);
//D7000180            strOpeCompForInternalBufferReqResult.strResult = strDCSMgr_SendOperationCompletedRpt_out.strResult;
//D7000180            return( rc );
//D7000180        }
//D7000180    }
//D7000180//D5100232 end
//D7000180 end (move to lower)

    /*------------------------------------------------------------------------*/
    /*                                                                        */
    /*   Send OpeComp Request to TCS Procedure                                */
    /*                                                                        */
    /*   - If specified portGroup's operationCompMode is Manual, OpeComp trx  */
    /*     must be sent to TCS. In TCS, if "ProcessEnd" report is not come    */
    /*     from eqp yet, OpeComp trx from MM is rejected by TCS.              */
    /*                                                                        */
    /*------------------------------------------------------------------------*/
    if ( 0 == CIMFWStrCmp( strPortResource_currentOperationMode_Get_out.strOperationMode.operationCompMode, SP_Eqp_CompMode_Manual) )
    {
        /*--------------------------*/
        /*    Send Request to TCS   */
        /*--------------------------*/
//D4000015 0.01        objTCSMgr_SendOpeCompWithDataReq_out strTCSMgr_SendOpeCompWithDataReq_out;
//D4000015 0.01        rc = TCSMgr_SendOpeCompWithDataReq( strTCSMgr_SendOpeCompWithDataReq_out,
//D4000015 0.01                                            strObjCommonIn,
//D4000015 0.01                                            strObjCommonIn.strUser,
//D4000015 0.01                                            equipmentID,
//D4000015 0.01                                            controlJobID,
//D4000015 0.01                                            spcResultRequiredFlag,
//D4000015 0.01                                            claimMemo );
//D4000015 0.01        if ( rc != RC_OK )
//D4000015 0.01        {
//D4000015 0.01            PPT_METHODTRACE_V1("", "TCSMgr_SendOpeCompWithDataReq() != RC_OK") ;
//D4000015 0.01            strOpeCompForInternalBufferReqResult.strResult = strTCSMgr_SendOpeCompWithDataReq_out.strResult ;
//D4000015 0.01            return( rc );
//D4000015 0.01        }

//D4000015 0.01 add start
//D4000060        objTCSMgr_SendOpeCompForInternalBufferReq_out strTCSMgr_SendOpeCompForInternalBufferReq_out;
//D4000060        rc = TCSMgr_SendOpeCompForInternalBufferReq( strTCSMgr_SendOpeCompForInternalBufferReq_out,
//D4000060                                                     strObjCommonIn,
//D4000060                                                     strObjCommonIn.strUser,
//D4000060                                                     equipmentID,
//D4000060                                                     controlJobID,
//D4000060                                                     spcResultRequiredFlag,
//D4000060                                                     claimMemo );
//D4000060        if ( rc != RC_OK )
//D4000060        {
//D4000060            PPT_METHODTRACE_V1("", "TCSMgr_SendOpeCompForInternalBufferReq() != RC_OK") ;
//D4000060            strOpeCompForInternalBufferReqResult.strResult = strTCSMgr_SendOpeCompForInternalBufferReq_out.strResult ;
//D4000060            return( rc );
//D4000060        }
//DSN000015229 Add Start
        if ( 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC015" )    //TxPartialOpeCompWithDataReq
          && 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC016" ) )  //TxPartialOpeCompForInternalBufferReq
        {
            PPT_METHODTRACE_V1("", "strObjCommonIn.transactionID != TXEWC015 && TXEWC016");
//DSN000015229 Add End
    //D4000060 add start
            CORBA::String_var tmpSleepTimeValue = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
            CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));
            CORBA::Long sleepTimeValue;
            CORBA::Long retryCountValue;

            if (CIMFWStrLen(tmpSleepTimeValue) == 0)
            {
                sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
            }
            else
            {
    //D9000001            sleepTimeValue = atol(tmpSleepTimeValue) ;
                sleepTimeValue = atoi(tmpSleepTimeValue) ;    //D9000001
            }

            if (CIMFWStrLen(tmpRetryCountValue) == 0)
            {
                retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
            }
            else
            {
    //D9000001            retryCountValue = atol(tmpRetryCountValue);
                retryCountValue = atoi(tmpRetryCountValue);    //D9000001
            }

            PPT_METHODTRACE_V2("","env value of SP_BIND_SLEEP_TIME_TCS  = ",sleepTimeValue);
            PPT_METHODTRACE_V2("","env value of SP_BIND_RETRY_COUNT_TCS = ",retryCountValue);

            objTCSMgr_SendOpeCompForInternalBufferReq_out strTCSMgr_SendOpeCompForInternalBufferReq_out;

            //'retryCountValue + 1' means first try plus retry count
            for( i = 0 ; i < (retryCountValue + 1) ; i++)
            {
                /*--------------------------*/
                /*    Send Request to TCS   */
                /*--------------------------*/
                rc = TCSMgr_SendOpeCompForInternalBufferReq( strTCSMgr_SendOpeCompForInternalBufferReq_out,
                                                             strObjCommonIn,
                                                             strObjCommonIn.strUser,
                                                             equipmentID,
                                                             controlJobID,
                                                             spcResultRequiredFlag,
                                                             claimMemo );
                PPT_METHODTRACE_V2("","rc = ",rc);

                if(rc == RC_OK)
                {
                    PPT_METHODTRACE_V1("","Now TCS subSystem is alive!! Go ahead");
                    break;
                }
                else if ( rc == RC_TCS_MM_FETCH_CJ_ERROR        ||      //D7000180
                          rc == RC_TCS_MM_ALREADY_OPE_COMPLETED ||      //D7000180
                          rc == RC_TCS_MM_ALREADY_OPE_CANCELED )        //D7000180
                {                                                       //D7000180
                    PPT_METHODTRACE_V2("","TCS returns -> RC_OK", rc);  //D7000180
                    rc = RC_OK;                                         //D7000180
                    break;                                              //D7000180
                }                                                       //D7000180
                else if ( rc == RC_EXT_SERVER_BIND_FAIL ||
                          rc == RC_EXT_SERVER_NIL_OBJ   ||
                          rc == RC_TCS_NO_RESPONSE )
                {
                    PPT_METHODTRACE_V2("","TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...",i);
                    PPT_METHODTRACE_V2("","now sleeping... ",sleepTimeValue);
                    sleep(sleepTimeValue);
                    continue;
                }
                else
                {
                    PPT_METHODTRACE_V1("", "TCSMgr_SendOpeCompForInternalBufferReq() != RC_OK") ;
                    strOpeCompForInternalBufferReqResult.strResult = strTCSMgr_SendOpeCompForInternalBufferReq_out.strResult ;
                    return( rc );
                }

             }

             if ( rc != RC_OK )
             {
                 PPT_METHODTRACE_V1("", "TCSMgr_SendOpeCompForInternalBufferReq() != RC_OK") ;
                 strOpeCompForInternalBufferReqResult.strResult = strTCSMgr_SendOpeCompForInternalBufferReq_out.strResult ;
                 return( rc );
             }
    //D4000060 add end
        } //DSN000015229
//D4000015 0.01 add end
    }
//DSN000015229 Add Start
    if ( 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC015" )    //TxPartialOpeCompWithDataReq
      && 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC016" ) )  //TxPartialOpeCompForInternalBufferReq
    {
        PPT_METHODTRACE_V1("", "strObjCommonIn.transactionID != TXEWC015 && TXEWC016");
//DSN000015229 Add End

    //D7000180 start (move from upper)
        /*------------------------------------------------------------------------*/
        /*                                                                        */
        /*   Send OpeComp Report to DCS Procedure                                 */
        /*                                                                        */
        /*------------------------------------------------------------------------*/
        CORBA::Boolean bDCSAvailable = FALSE;
        CORBA::String_var DCSAvailable = CIMFWStrDup(getenv(SP_DCS_Available));
        PPT_METHODTRACE_V2("", "DCSAvailable", DCSAvailable);
        if (CIMFWStrCmp(DCSAvailable, "1") == 0 )
        {
            PPT_METHODTRACE_V1("", "DCS Interface Available");
            bDCSAvailable = TRUE;
        }

//DSN000102497 add start
        CORBA::Long DCSReport = atoi( getenv(SP_DCS_REPORT) );
        PPT_METHODTRACE_V2("","DCSReport", DCSReport);
//DSN000102497 add end

        if ( 0 != CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode, SP_Eqp_OnlineMode_Offline)
          && TRUE == bDCSAvailable && 0 == DCSReport ) //DSN000102497
//DSN000102497          && TRUE == bDCSAvailable )
        {
            PPT_METHODTRACE_V1("", "Send OpeComp Report to DCS");

            CORBA::String_var IgnoreErr = CIMFWStrDup(getenv(SP_DCS_Ignore_OpeComp_Result));
            PPT_METHODTRACE_V2("", "SP_DCS_IGNORE_OPECOMP_RESULT", IgnoreErr);

            objDCSMgr_SendOperationCompletedRpt_out strDCSMgr_SendOperationCompletedRpt_out;
            rc = DCSMgr_SendOperationCompletedRpt( strDCSMgr_SendOperationCompletedRpt_out, strObjCommonIn, controlJobID );

            if ( rc != RC_OK && 0 != CIMFWStrCmp(IgnoreErr, "1") )
            {
                PPT_METHODTRACE_V2("", "##### DCSMgr_SendOperationCompletedRpt() != RC_OK", rc);
                strOpeCompForInternalBufferReqResult.strResult = strDCSMgr_SendOperationCompletedRpt_out.strResult;
                return( rc );
            }
        }
    //D7000180 end (move from upper)
    } //DSN000015229

//D7000096//D4100134    PPT_METHODTRACE_V2("", "theSP_DELIVERY_REQ_EXIST", theSP_DELIVERY_REQ_EXIST );
//D7000096    PPT_METHODTRACE_V2("", "SP_DELIVERY_REQ_EXIST", getenv(SP_DELIVERY_REQ_EXIST) );         //D4100134
//D7000096
//D7000096//D4000011    if ( 0 != CIMFWStrCmp(deliveryReqExist, "YES") )
//D7000096//D4100134    if ( 0 != CIMFWStrCmp(theSP_DELIVERY_REQ_EXIST, "YES") )  //D4000011
//D7000096    if ( 0 != CIMFWStrCmp(getenv(SP_DELIVERY_REQ_EXIST), "YES") )       //D4100134
//D7000096    {
//D7000096//D4000015        /*-------------------------------------*/
//D7000096//D4000015        /*   Get Port Information              */
//D7000096//D4000015        /*-------------------------------------*/
//D7000096//D4000015        PPT_METHODTRACE_V1("", "call equipment_portInfo_Get()...");
//D7000096//D4000015
//D7000096//D4000015        objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
//D7000096//D4000015        rc = equipment_portInfo_Get(strEquipment_portInfo_Get_out, strObjCommonIn, equipmentID);
//D7000096//D4000015        if ( rc != RC_OK )
//D7000096//D4000015        {
//D7000096//D4000015           PPT_METHODTRACE_V1("", "equipment_portInfo_Get() rc != RC_OK");
//D7000096//D4000015           strOpeCompForInternalBufferReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
//D7000096//D4000015           return( rc );
//D7000096//D4000015        }
//D7000096//D4000015
//D7000096//D4000015        CORBA::Long portLen = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
//D7000096//D4000015        PPT_METHODTRACE_V2("", "strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length()", portLen);
//D7000096//D4000015
//D7000096//D4000015        objectIdentifierSequence strPortID;
//D7000096//D4000015        strPortID.length(portLen);
//D7000096//D4000015        CORBA::Long portCnt = 0;
//D7000096//D4000015
//D7000096//D4000015        /*-------------------------------------*/
//D7000096//D4000015        /*   Find Target Port                  */
//D7000096//D4000015        /*   Condition:                        */
//D7000096//D4000015        /*    Access Mode ==  Auto             */
//D7000096//D4000015        /*    PortState   ==  UnloadReq        */
//D7000096//D4000015        /*    onlineMode  !=  OffLine          */
//D7000096//D4000015        /*-------------------------------------*/
//D7000096//D4000015        for (i = 0; i < portLen ; i++)
//D7000096//D4000015        {
//D7000096//D4000015            PPT_METHODTRACE_V2("", "PortID             is ",strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].portID.identifier);
//D7000096//D4000015            PPT_METHODTRACE_V2("", "Port State         is ",strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].portState);
//D7000096//D4000015            PPT_METHODTRACE_V2("", "Port Access Mode   is ",strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].accessMode);
//D7000096//D4000015            PPT_METHODTRACE_V2("", "OnlineMode  Mode   is ",strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].onlineMode);
//D7000096//D4000015            /* onlineMode check */
//D7000096//D4000015            if (CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].accessMode, SP_Eqp_AccessMode_Auto) == 0 &&
//D7000096//D4000015                CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].portState,  SP_PortRsc_PortState_UnloadReq) == 0 &&
//D7000096//D4000015                CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].onlineMode, SP_Eqp_OnlineMode_Offline) != 0 )
//D7000096//D4000015            {
//D7000096//D4000015                strPortID[portCnt] = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].portID;
//D7000096//D4000015                portCnt++;
//D7000096//D4000015            }
//D7000096//D4000015        }
//D7000096//D4000015        strPortID.length(portCnt);
//D7000096//D4000015
//D7000096//D4000015        /*-------------------------------------*/
//D7000096//D4000015        /*   Get Unload Port Information       */
//D7000096//D4000015        /*-------------------------------------*/
//D7000096//D4000015        pptEqpInprocessingControlJobSequence strControlJob;
//D7000096//D4000015        CORBA::Long jobCnt = strEquipment_inprocessingControlJobInfo_Get_out.strEqpInprocessingControlJobInfo.strEqpInprocessingControlJob.length();
//D7000096//D4000015        PPT_METHODTRACE_V2("", "strEquipment_inprocessingControlJobInfo_Get_out.strEqpInprocessingControlJobInfo.strEqpInprocessingControlJob.length()", jobCnt);
//D7000096//D4000015
//D7000096//D4000015        strControlJob.length(jobCnt);
//D7000096//D4000015        strControlJob = strEquipment_inprocessingControlJobInfo_Get_out.strEqpInprocessingControlJobInfo.strEqpInprocessingControlJob;
//D7000096//D4000015
//D7000096//D4000015        pptEqpInprocessingLotSequence strEqpInprocess;
//D7000096//D4000015        CORBA::Long LotCnt = 0;
//D7000096//D4000015
//D7000096//D4000015        PPT_METHODTRACE_V2("", "jobCnt is ",jobCnt);
//D7000096//D4000015
//D7000096//D4000015        for (i = 0; i < jobCnt; i++ )
//D7000096//D4000015        {
//D7000096//D4000015            if ( CIMFWStrCmp(strControlJob[i].controlJobID.identifier, controlJobID.identifier) == 0 )
//D7000096//D4000015            {
//D7000096//D4000015                LotCnt = strControlJob[i].strEqpInprocessingLot.length();
//D7000096//D4000015                strEqpInprocess.length(LotCnt);
//D7000096//D4000015                strEqpInprocess = strControlJob[i].strEqpInprocessingLot;
//D7000096//D4000015                break;
//D7000096//D4000015            }
//D7000096//D4000015        }
//D7000096//D4000015
//D7000096//D4000015        CORBA::Long         UnLoadSeq =9999;
//D7000096//D4000015        objectIdentifier    targetCassetteID;
//D7000096//D4000015        objectIdentifier    targetPortID;
//D7000096//D4000015
//D7000096//D4000015        PPT_METHODTRACE_V2("", "portCnt is ",portCnt);
//D7000096//D4000015
//D7000096//D4000015        for (CORBA::Long i = 0; i < portCnt ; i++)
//D7000096//D4000015        {
//D7000096//D4000015            CORBA::Boolean  targetExitFlag = FALSE;
//D7000096//D4000015
//D7000096//D4000015            PPT_METHODTRACE_V2("", "LotCnt is ",LotCnt);
//D7000096//D4000015
//D7000096//D4000015            for (CORBA::Long j = 0; j < LotCnt ; j++)
//D7000096//D4000015            {
//D7000096//D4000015                if ( CIMFWStrCmp( strPortID[i].identifier, strEqpInprocess[j].unloadPortID.identifier) == 0 )
//D7000096//D4000015                {
//D7000096//D4000015                    targetExitFlag = TRUE ;
//D7000096//D4000015                    UnLoadSeq = strEqpInprocess[j].unloadSequenceNumber;
//D7000096//D4000015                    targetCassetteID = strEqpInprocess[j].cassetteID;
//D7000096//D4000015                    targetPortID     = strEqpInprocess[j].unloadPortID;
//D7000096//D4000015
//D7000096//D4000015                    PPT_METHODTRACE_V2("", "UnLoadSeq        is ",UnLoadSeq);
//D7000096//D4000015                    PPT_METHODTRACE_V2("", "targetCassetteID is ",targetCassetteID.identifier);
//D7000096//D4000015                    PPT_METHODTRACE_V2("", "targetPortID     is ",targetPortID.identifier);
//D7000096//D4000015                    break;
//D7000096//D4000015                }
//D7000096//D4000015            }
//D7000096//D4000015            if (targetExitFlag == FALSE && EmptyPortFlag == TRUE)
//D7000096//D4000015            {
//D7000096//D4000015                CORBA::Long chkLen = strControlJob_startReserveInformation_Get_out.strStartCassette.length();
//D7000096//D4000015                for (CORBA::Long pp = 0; pp < chkLen ; pp++)
//D7000096//D4000015                {
//D7000096//D4000015                    if ( CIMFWStrCmp( strPortID[i].identifier, strControlJob_startReserveInformation_Get_out.strStartCassette[pp].unloadPortID.identifier) == 0 &&
//D7000096//D4000015                         CIMFWStrCmp( strControlJob_startReserveInformation_Get_out.strStartCassette[pp].loadPurposeType, SP_LoadPurposeType_EmptyCassette ) == 0)
//D7000096//D4000015                    {
//D7000096//D4000015                        targetExitFlag = TRUE ;
//D7000096//D4000015                        targetCassetteID = strControlJob_startReserveInformation_Get_out.strStartCassette[pp].cassetteID;
//D7000096//D4000015                        targetPortID     = strControlJob_startReserveInformation_Get_out.strStartCassette[pp].unloadPortID;
//D7000096//D4000015
//D7000096//D4000015                        PPT_METHODTRACE_V2("", "targetCassetteID is ",targetCassetteID.identifier);
//D7000096//D4000015                        PPT_METHODTRACE_V2("", "targetPortID     is ",targetPortID.identifier);
//D7000096//D4000015                        break;
//D7000096//D4000015                    }
//D7000096//D4000015                }
//D7000096//D4000015            }
//D7000096//D4000015            if (targetExitFlag == TRUE)
//D7000096//D4000015            {
//D7000096//D4000015                /* Where Next   */
//D7000096//D4000015                /*----------------------------------------------*/
//D7000096//D4000015                /*   Check the representative lotID             */
//D7000096//D4000015                /*----------------------------------------------*/
//D7000096//D4000015                CORBA::Boolean  EmptyCastFlag = TRUE;
//D7000096//D4000015                objLot_GetNextStockerDR_out strLot_GetNextStockerDR_out;
//D7000096//D4000015                objectIdentifier aLotID;
//D7000096//D4000015                objCassette_representLot_Get_out  strCassette_representLot_Get_out;
//D7000096//D4000015                rc = cassette_representLot_Get( strCassette_representLot_Get_out, strObjCommonIn, targetCassetteID );
//D7000096//D4000015                if (rc != RC_OK && rc != RC_NOT_FOUND_LOT)
//D7000096//D4000015                {
//D7000096//D4000015                   PPT_METHODTRACE_V1("", "cassette_representLot_Get() != RC_OK") ;
//D7000096//D4000015                   strOpeCompForInternalBufferReqResult.strResult = strCassette_representLot_Get_out.strResult;
//D7000096//D4000015                   return ( rc );
//D7000096//D4000015                }
//D7000096//D4000015                if(rc == RC_OK)
//D7000096//D4000015                {
//D7000096//D4000015                    EmptyCastFlag = FALSE;
//D7000096//D4000015                    aLotID = strCassette_representLot_Get_out.lotID;
//D7000096//D4000015                    PPT_METHODTRACE_V2("","representative lotID", aLotID.identifier) ;
//D7000096//D4000015
//D7000096//D4000015                    /*--------------------------------------------------*/
//D7000096//D4000015                    /*   Get and set the destination to be transferred  */
//D7000096//D4000015                    /*--------------------------------------------------*/
//D7000096//D4000015                    rc = lot_GetNextStockerDR( strLot_GetNextStockerDR_out, strObjCommonIn, aLotID );
//D7000096//D4000015                    if (rc != RC_OK)
//D7000096//D4000015                    {
//D7000096//D4000015                       PPT_METHODTRACE_V1("", "lot_GetNextStockerDR() != RC_OK") ;
//D7000096//D4000015                       strOpeCompForInternalBufferReqResult.strResult = strLot_GetNextStockerDR_out.strResult;
//D7000096//D4000015                       return ( rc );
//D7000096//D4000015                    }
//D7000096//D4000015
//D7000096//D4000015                }
//D7000096//D4000015
//D7000096//D4000015                /* Xfer Request */
//D7000096//D4000015
//D7000096//D4000015                pptTranJobCreateReq   tranJobCreateReq;
//D7000096//D4000015
//D7000096//D4000015                tranJobCreateReq.jobCreateData.length(1);
//D7000096//D4000015
//D7000096//D4000015                tranJobCreateReq.jobCreateData[0].fromMachineID  = equipmentID;
//D7000096//D4000015                tranJobCreateReq.jobCreateData[0].fromPortID     = targetPortID;
//D7000096//D4000015                tranJobCreateReq.jobCreateData[0].carrierID      = targetCassetteID;
//D7000096//D4000015
//D7000096//D4000015                objCassette_zoneType_Get_out strCassette_zoneType_Get_out;
//D7000096//D4000015
//D7000096//D4000015                /* targetCassetteID is in-parameter */
//D7000096//D4000015                rc = cassette_zoneType_Get( strCassette_zoneType_Get_out, strObjCommonIn, targetCassetteID );
//D7000096//D4000015                if (rc != RC_OK)
//D7000096//D4000015                {
//D7000096//D4000015                   PPT_METHODTRACE_V1("", "cassette_zoneType_Get() != RC_OK") ;
//D7000096//D4000015                   strOpeCompForInternalBufferReqResult.strResult = strCassette_zoneType_Get_out.strResult;
//D7000096//D4000015                   return ( rc );
//D7000096//D4000015                }
//D7000096//D4000015
//D7000096//D4000015                tranJobCreateReq.transportType                   = CIMFWStrDup("S");
//D7000096//D4000015                tranJobCreateReq.jobCreateData[0].zoneType       = strCassette_zoneType_Get_out.zoneType;
//D7000096//D4000015                tranJobCreateReq.jobCreateData[0].priority       = strCassette_zoneType_Get_out.priority;
//D7000096//D4000015
//D7000096//D4000015                CORBA::Long mLen = 0;
//D7000096//D4000015                if(EmptyCastFlag == FALSE)
//D7000096//D4000015                {
//D7000096//D4000015                    mLen = strLot_GetNextStockerDR_out.strWhereNext.strWhereNextEqpStatus.length();
//D7000096//D4000015                }
//D7000096//D4000015
//D7000096//D4000015                PPT_METHODTRACE_V2("", "strWhereNextEqpStatus.length", mLen);
//D7000096//D4000015
//D7000096//D4000015                objectIdentifierSequence machines;
//D7000096//D4000015                CORBA::Long stkLen = 0;
//D7000096//D4000015
//D7000096//D4000015                for (CORBA::Long j = 0; j < mLen; j++)
//D7000096//D4000015                {
//D7000096//D4000015                    CORBA::Long nLen = strLot_GetNextStockerDR_out.strWhereNext.strWhereNextEqpStatus[j].strEqpStockerStatus.length();
//D7000096//D4000015                    for (CORBA::Long k = 0; k < nLen; k++)
//D7000096//D4000015                    {
//D7000096//D4000015                        if(strLot_GetNextStockerDR_out.strWhereNext.strWhereNextEqpStatus[j].strEqpStockerStatus[k].stockerID.identifier != NULL)
//D7000096//D4000015                        {
//D7000096//D4000015                            stkLen++;
//D7000096//D4000015                            machines.length(stkLen);
//D7000096//D4000015                            machines[stkLen-1] = strLot_GetNextStockerDR_out.strWhereNext.strWhereNextEqpStatus[j].strEqpStockerStatus[k].stockerID;
//D7000096//D4000015                        }
//D7000096//D4000015                    }
//D7000096//D4000015                }
//D7000096//D4000015                if(mLen==0 || stkLen == 0)
//D7000096//D4000015                {
//D7000096//D4000015                    objEquipment_stockerInfo_Get_out strEquipment_stockerInfo_Get_out;
//D7000096//D4000015                    pptEqpStockerInfo    equipmentStockerInfo;
//D7000096//D4000015
//D7000096//D4000015                    PPT_METHODTRACE_V1("", "call equipment_stockerInfo_Get()...");
//D7000096//D4000015                    rc = equipment_stockerInfo_Get( strEquipment_stockerInfo_Get_out, strObjCommonIn, equipmentID );
//D7000096//D4000015                    if ( rc != RC_OK )
//D7000096//D4000015                    {
//D7000096//D4000015                        PPT_METHODTRACE_V1("", "equipment_stockerInfo_Get() rc != RC_OK");
//D7000096//D4000015                        strOpeCompForInternalBufferReqResult.strResult = strEquipment_stockerInfo_Get_out.strResult;
//D7000096//D4000015                        return( rc );
//D7000096//D4000015                    }
//D7000096//D4000015                    equipmentStockerInfo = strEquipment_stockerInfo_Get_out.equipmentStockerInfo;
//D7000096//D4000015
//D7000096//D4000015                    stkLen = equipmentStockerInfo.strEqpStockerStatus.length();
//D7000096//D4000015                    machines.length(stkLen);
//D7000096//D4000015                    for (CORBA::Long jj = 0; jj < stkLen; jj++)
//D7000096//D4000015                    {
//D7000096//D4000015                        machines[jj] = equipmentStockerInfo.strEqpStockerStatus[jj].stockerID;
//D7000096//D4000015                    }
//D7000096//D4000015                }
//D7000096//D4000015
//D7000096//D4000015                /* re-create toMachineID,if found same stocker,then delete 2nd data*/
//D7000096//D4000015
//D7000096//D4000015                objectIdentifierSequence toMachines;
//D7000096//D4000015                toMachines = machines;
//D7000096//D4000015
//D7000096//D4000015                CORBA::Long Cnt = 0;
//D7000096//D4000015                tranJobCreateReq.jobCreateData[0].toMachine.length(stkLen);
//D7000096//D4000015
//D7000096//D4000015                for (j = 0; j < stkLen; j++)
//D7000096//D4000015                {
//D7000096//D4000015                    CORBA::Boolean existFlag = FALSE;
//D7000096//D4000015                    for (CORBA::Long k = 0; k < j; k++)
//D7000096//D4000015                    {
//D7000096//D4000015                        if ( 0 == CIMFWStrCmp( machines[j].identifier, toMachines[k].identifier ))
//D7000096//D4000015                        {
//D7000096//D4000015                            existFlag = TRUE;
//D7000096//D4000015                        }
//D7000096//D4000015                    }
//D7000096//D4000015                    if ( existFlag == FALSE || j == 0 )
//D7000096//D4000015                    {
//D7000096//D4000015                        tranJobCreateReq.jobCreateData[0].toMachine[Cnt].toMachineID = machines[j];
//D7000096//D4000015                        Cnt++;
//D7000096//D4000015                    }
//D7000096//D4000015                }
//D7000096//D4000015                tranJobCreateReq.jobCreateData[0].toMachine.length(Cnt);
//D7000096//D4000015
//D7000096//D4000015                /*-----------------------------------------------------------*/
//D7000096//D4000015                /* Trans            fer Request to XMSMgr                    */
//D7000096//D4000015                /*-----------------------------------------------------------*/
//D7000096//D4000015                PPT_METHODTRACE_V2("", "Send XMSMgr_SendTransportJobCreateReq",i);
//D7000096//D4000015
//D7000096//D4000015                objXMSMgr_SendTransportJobCreateReq_out   strXMSMgr_SendTransportJobCreateReq_out;
//D7000096//D4000015                rc = XMSMgr_SendTransportJobCreateReq( strXMSMgr_SendTransportJobCreateReq_out,
//D7000096//D4000015                                                       strObjCommonIn,
//D7000096//D4000015                                                       strObjCommonIn.strUser,
//D7000096//D4000015                                                       tranJobCreateReq );
//D7000096//D4000015                if ( rc != RC_OK )
//D7000096//D4000015                {
//D7000096//D4000015                    PPT_METHODTRACE_V1("", "XMSMgr_SendTransportJobCreateReq != RC_OK");
//D7000096//D4000015                    pptSystemMsgRptResult strSystemMsgRptResult;
//D7000096//D4000015                    objectIdentifier dummy;
//D7000096//D4000015                    CORBA::String    reason;
//D7000096//D4000015
//D7000096//D4000015                    rc = txSystemMsgRpt( strSystemMsgRptResult,
//D7000096//D4000015                                         strObjCommonIn,
//D7000096//D4000015                                         SP_SubSystemID_MM,
//D7000096//D4000015                                         SP_SystemMsgCode_DeliveryError,
//D7000096//D4000015                                         "",
//D7000096//D4000015                                         TRUE,
//D7000096//D4000015                                         equipmentID,
//D7000096//D4000015                                         "",
//D7000096//D4000015                                         dummy,
//D7000096//D4000015                                         "",
//D7000096//D4000015                                         dummy,
//D7000096//D4000015                                         "",
//D7000096//D4000015                                         dummy,
//D7000096//D4000015                                         "",
//D7000096//D4000015                                         dummy,
//D7000096//D4000015                                         dummy,
//D7000096//D4000015                                         "",
//D7000096//D4000015                                         strObjCommonIn.strTimeStamp.reportTimeStamp,
//D7000096//D4000015                                         "" );
//D7000096//D4000015                    if (rc != RC_OK)
//D7000096//D4000015                    {
//D7000096//D4000015                        PPT_METHODTRACE_V1("", "XMSMgr_SendTransportJobCreateReq() != RC_OK");
//D7000096//D4000015                    }
//D7000096//D4000015                }
//D7000096//D4000015            }
//D7000096//D4000015        }
//D7000096
//D7000096//D4000015 add start
//D7000096        /*-------------------------------------*/
//D7000096        /*   Get Port Information              */
//D7000096        /*-------------------------------------*/
//D7000096        objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
//D7000096        rc = equipment_portInfo_Get(strEquipment_portInfo_Get_out, strObjCommonIn, equipmentID);
//D7000096        if ( rc != RC_OK )
//D7000096        {
//D7000096           PPT_METHODTRACE_V1("", "equipment_portInfo_Get() rc != RC_OK");
//D7000096           strOpeCompForInternalBufferReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
//D7000096           return( rc );
//D7000096        }
//D7000096
//D7000096        CORBA::Long portLen = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
//D7000096        PPT_METHODTRACE_V2("", "strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length()", portLen);
//D7000096
//D7000096        for ( i=0 ; i<scLen ; i++ )
//D7000096        {
//D7000096            PPT_METHODTRACE_V3("", "cassetteID ", i, strStartCassette[i].cassetteID.identifier );
//D7000096            /*--------------------------------------------------*/
//D7000096            /*   Find Target Cassette                           */
//D7000096            /*   Condition:                                     */
//D7000096            /*    loadedCassetteID         ==  cassetteID       */
//D7000096            /*    Access Mode              ==  Auto             */
//D7000096            /*    PortState                ==  UnloadReq        */
//D7000096            /*    onlineMode               !=  OffLine          */
//D7000096            /*    dispatchState            ==  Required         */
//D7000096            /*    dispatchUnloadCassetteID ==  null             */
//D7000096            /*--------------------------------------------------*/
//D7000096            CORBA::Boolean  bFindCassetteFlag = FALSE;
//D7000096            for (CORBA::Long j = 0; j < portLen ; j++)
//D7000096            {
//D7000096                PPT_METHODTRACE_V3("", "loadedCassetteID         ", j, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier );
//D7000096                PPT_METHODTRACE_V3("", "PortID                   ", j, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portID.identifier );
//D7000096                PPT_METHODTRACE_V3("", "Port State               ", j, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState );
//D7000096                PPT_METHODTRACE_V3("", "Port Access Mode         ", j, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].accessMode );
//D7000096                PPT_METHODTRACE_V3("", "OnlineMode  Mode         ", j, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].onlineMode );
//D7000096                PPT_METHODTRACE_V3("", "dispatchState            ", j, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchState );
//D7000096                PPT_METHODTRACE_V3("", "dispatchUnloadCassetteID ", j, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchUnloadCassetteID.identifier );
//D7000096
//D7000096                // Find Same Cassette from Equipment
//D7000096                if (CIMFWStrCmp( strStartCassette[i].cassetteID.identifier,
//D7000096                                 strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier) == 0)
//D7000096                {
//D7000096                    // onlineMode check:
//D7000096                    //   1. accessMode is auto
//D7000096                    //   2. portState is UnloadReq
//D7000096                    //   3. onlineMode is Online
//D7000096                    //   4. dispatchState is Required
//D7000096                    //   5. dispatchUnloadCassetteID is null
//D7000096                    if (CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].accessMode, SP_Eqp_AccessMode_Auto               ) == 0 &&
//D7000096                        CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState,  SP_PortRsc_PortState_UnloadReq       ) == 0 &&
//D7000096                        CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].onlineMode, SP_Eqp_OnlineMode_Offline            ) != 0 &&
//D7000096                        CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchState, SP_PortRsc_DispatchState_Required ) == 0 &&
//D7000096                        CIMFWStrLen( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchUnloadCassetteID.identifier              ) == 0 )
//D7000096                    {
//D7000096                        bFindCassetteFlag = TRUE;
//D7000096                        break;
//D7000096                    }
//D7000096                }
//D7000096            }
//D7000096            // If it isn't found, it isn't made the target.
//D7000096            if (bFindCassetteFlag == FALSE)
//D7000096                continue;
//D7000096
//D7000096            PPT_METHODTRACE_V2("", "Call txWhereNextInterBayInq: cassetteID", strStartCassette[i].cassetteID.identifier );
//D7000096            /*----------------------------*/
//D7000096            /*   Get Where Next Stocker   */
//D7000096            /*----------------------------*/
//D7000096            objectIdentifier dummy;
//D7000096            pptWhereNextInterBayInqResult strWhereNextInterBayInqResult;
//D7000096            rc = txWhereNextInterBayInq( strWhereNextInterBayInqResult,
//D7000096                                         strObjCommonIn,
//D7000096                                         dummy,
//D7000096                                         strStartCassette[i].cassetteID );
//D7000096
//D7000096            if ( rc != RC_OK )
//D7000096            {
//D7000096                PPT_METHODTRACE_V1("", "txWhereNextInterBayInq() rc != RC_OK");
//D7000096                strOpeCompForInternalBufferReqResult.strResult = strWhereNextInterBayInqResult.strResult;
//D7000096                return( rc );
//D7000096            }
//D7000096            PPT_METHODTRACE_V1("", "Make txSingleCarrierXferReq parameter");
//D7000096            /*-------------------------------------------*/
//D7000096            /*   Make txSingleCarrierXferReq parameter   */
//D7000096            /*-------------------------------------------*/
//D7000096            objSingleCarrierXferFillInTXLGC013InParm_out strSingleCarrierXferFillInTXLGC013InParm_out;
//D7000096            rc = singleCarrierXferFillInTXLGC013InParm(
//D7000096                        strSingleCarrierXferFillInTXLGC013InParm_out,
//D7000096                        strObjCommonIn,
//D7000096                        equipmentID,
//D7000096                        strStartCassette[i].unloadPortID,
//D7000096                        strStartCassette[i].cassetteID,
//D7000096                        strWhereNextInterBayInqResult );
//D7000096            if ( rc != RC_OK )
//D7000096            {
//D7000096                PPT_METHODTRACE_V1("", "singleCarrierXferFillInTXLGC013InParm() rc != RC_OK");
//D7000096                strOpeCompForInternalBufferReqResult.strResult = strSingleCarrierXferFillInTXLGC013InParm_out.strResult;
//D7000096                return( rc );
//D7000096            }
//D7000096
//D7000096            PPT_METHODTRACE_V1("", "Send Request to XM. (EQP -> Stocker)");
//D7000096            /*------------------------------------------*/
//D7000096            /*   Send Request to XM. (EQP -> Stocker)   */
//D7000096            /*------------------------------------------*/
//D7000096            pptSingleCarrierXferReqResult strSingleCarrierXferReqResult;
//D7000096            rc = txSingleCarrierXferReq( strSingleCarrierXferReqResult,
//D7000096                                         strObjCommonIn,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.rerouteFlag,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.carrierID,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.lotID,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.zoneType,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.n2PurgeFlag,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromMachineID,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.fromPortID,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.toStockerGroup,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.strToMachine,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.expectedStartTime,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.expectedEndTime,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.mandatoryFlag,
//D7000096                                         strSingleCarrierXferFillInTXLGC013InParm_out.strCarrierXferReq.priority );
//D7000096
//D7000096            if ( rc != RC_OK )
//D7000096            {
//D7000096                PPT_METHODTRACE_V1("", "txSingleCarrierXferReq() rc != RC_OK");
//D7000096                strOpeCompForInternalBufferReqResult.strResult = strSingleCarrierXferReqResult.strResult;
//D7000096                return( rc );
//D7000096            }
//D7000096        }
//D7000096//D4000015 add end
//D7000096    }

//P51M0018 move start
//P51M0018    /*--------------------------*/
//P51M0018    /*                          */
//P51M0018    /*   Set Return Structure   */
//P51M0018    /*                          */
//P51M0018    /*--------------------------*/
//P51M0018    objEquipment_FillInTxTRC004_out   strEquipment_FillInTxTRC004_out;
//P51M0018    rc = equipment_FillInTxTRC004( strEquipment_FillInTxTRC004_out,
//P51M0018                                   strObjCommonIn,
//P51M0018                                   strStartCassette,
//P51M0018                                   strSpcCheckReqResult.strSpcCheckLot );
//P51M0018    if ( rc != RC_OK )
//P51M0018    {
//P51M0018        PPT_METHODTRACE_V1("", "equipment_FillInTxTRC004() != RC_OK") ;
//P51M0018        strOpeCompForInternalBufferReqResult.strResult = strEquipment_FillInTxTRC004_out.strResult ;
//P51M0018        return(rc);
//P51M0018    }
//P51M0018
//P51M0018    /*----------------------*/
//P51M0018    /*                      */
//P51M0018    /*   Return to Caller   */
//P51M0018    /*                      */
//P51M0018    /*----------------------*/
//P51M0018    strOpeCompForInternalBufferReqResult = strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult ;
//P51M0018 move end

//D51M0000 Add Start
    CORBA::Boolean bActionTriggerFlag = FALSE;

    /*-----------------------------------------------------*/
    /*   Call controlJob_APCRunTimeCapability_GetDR        */
    /*-----------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call controlJob_APCRunTimeCapability_GetDR");
    objControlJob_APCRunTimeCapability_GetDR_out strControlJob_APCRunTimeCapability_GetDR_out;
    rc = controlJob_APCRunTimeCapability_GetDR ( strControlJob_APCRunTimeCapability_GetDR_out,
                                                 strObjCommonIn,
                                                 controlJobID);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "controlJob_APCRunTimeCapability_GetDR() != RC_OK");
        strOpeCompForInternalBufferReqResult.strResult = strControlJob_APCRunTimeCapability_GetDR_out.strResult;
        return( rc );
    }

    PPT_METHODTRACE_V1("", "controlJob_APCRunTimeCapability_GetDR() == RC_OK");

    CORBA::Long response_cnt = strControlJob_APCRunTimeCapability_GetDR_out.strAPCRunTimeCapabilityResponse.length();
    PPT_METHODTRACE_V2("", "strAPCRunTimeCapabilityResponse.length()", response_cnt);

    for ( CORBA::Long loop_response_cnt = 0; loop_response_cnt < response_cnt; loop_response_cnt++ )
    {
        CORBA::Long capability_cnt = strControlJob_APCRunTimeCapability_GetDR_out.
                                       strAPCRunTimeCapabilityResponse[loop_response_cnt].
                                         strAPCRunTimeCapability.length();

        for ( CORBA::Long loop_capability_cnt = 0; loop_capability_cnt < capability_cnt; loop_capability_cnt++ )
        {
//D7000021            CORBA::Boolean bHoldFlag = FALSE;

            pptAPCRunTimeCapability strAPCRunTimeCapability;
            strAPCRunTimeCapability = strControlJob_APCRunTimeCapability_GetDR_out.
                                        strAPCRunTimeCapabilityResponse[loop_response_cnt].
                                          strAPCRunTimeCapability[loop_capability_cnt];

            CORBA::Long function_cnt = strAPCRunTimeCapability.strAPCBaseAPCSystemFunction.length();

            for ( CORBA::Long loop_function_cnt = 0; loop_function_cnt < function_cnt; loop_function_cnt++ )
            {
                PPT_METHODTRACE_V5("", "SystemFunction_Type", strAPCRunTimeCapability.strAPCBaseAPCSystemFunction[loop_function_cnt].type, loop_response_cnt, loop_capability_cnt, loop_function_cnt);

                if ( CIMFWStrCmp( strAPCRunTimeCapability.strAPCBaseAPCSystemFunction[loop_function_cnt].type, SP_APCFunctionType_productDisposition ) == 0 )
                {
                    PPT_METHODTRACE_V1("", "APCSystemFunction_Type == ProductDisposition");
//D7000021                    bHoldFlag = TRUE;
                    bActionTriggerFlag = TRUE;
                    break;
                }
            } //for strAPCBaseAPCSystemFunction

//D7000021 Delete start
//D7000021            if ( bHoldFlag == TRUE )
//D7000021            {
//D7000021                CORBA::Long lotwafer_cnt = strAPCRunTimeCapability.strAPCLotWaferCollection.length();
//D7000021                PPT_METHODTRACE_V4("", "APCSystemFunction_Type == ProductDisposition", loop_response_cnt, loop_capability_cnt, lotwafer_cnt);
//D7000021
//D7000021                for ( CORBA::Long loop_lotwafer_cnt = 0; loop_lotwafer_cnt < lotwafer_cnt; loop_lotwafer_cnt++ )
//D7000021                {
//D7000021                    objectIdentifier lotID;
//D7000021                    lotID.identifier = CIMFWStrDup( strAPCRunTimeCapability.strAPCLotWaferCollection[loop_lotwafer_cnt].lotID );
//D7000021
//D7000021                    PPT_METHODTRACE_V3("", "lotID", lotID.identifier, loop_lotwafer_cnt);
//D7000021
//D7000021                    /*--------------------------*/
//D7000021                    /*   Call txHoldLotReq      */
//D7000021                    /*--------------------------*/
//D7000021                    pptHoldListSequence strLotHoldReqList;
//D7000021                    strLotHoldReqList.length( 1 ) ;
//D7000021
//D7000021                    objectIdentifier dummyOI;
//D7000021                    objectIdentifier holdReasonCodeID;
//D7000021                    objectIdentifier holdUserID;
//D7000021                    pptObjCommonIn   tmpObjCommonIn;
//D7000021
//D7000021                    holdReasonCodeID.identifier = CIMFWStrDup( SP_Reason_WaitAPCResultHold );
//D7000021                    holdUserID.identifier       = CIMFWStrDup( SP_PPTSvcMgr_Person         );
//D7000021
//D7000021                    strLotHoldReqList[0].holdType                 = CIMFWStrDup( SP_HoldType_LotHold );
//D7000021                    strLotHoldReqList[0].holdReasonCodeID         = holdReasonCodeID;
//D7000021                    strLotHoldReqList[0].holdUserID               = holdUserID;
//D7000021                    strLotHoldReqList[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Current );
//D7000021                    strLotHoldReqList[0].routeID                  = dummyOI;
//D7000021                    strLotHoldReqList[0].operationNumber          = CIMFWStrDup( "" );
//D7000021                    strLotHoldReqList[0].relatedLotID             = dummyOI;
//D7000021                    strLotHoldReqList[0].claimMemo                = claimMemo;
//D7000021
//D7000021                    tmpObjCommonIn = strObjCommonIn;
//D7000021                    tmpObjCommonIn.strUser.userID = holdUserID;
//D7000021
//D7000021                    PPT_METHODTRACE_V1("", "Call txHoldLotReq()");
//D7000021
//D7000021                    pptHoldLotReqResult strHoldLotReqResult ;
//D7000021                    rc = txHoldLotReq( strHoldLotReqResult,
//D7000021                                       tmpObjCommonIn,
//D7000021                                       lotID,
//D7000021                                       strLotHoldReqList ) ;
//D7000021
//D7000021//P51M0012 change
//D7000021                    if ( rc != RC_OK )
//D7000021                    {
//D7000021                        PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK");
//D7000021                        strOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult;
//D7000021                        return ( rc );
//D7000021                    }
//D7000021//P51M0012 end
//P51M0012                    if ( rc == RC_SYSTEM_ERROR )
//P51M0012                    {
//P51M0012                        PPT_METHODTRACE_V1("", "txHoldLotReq() == RC_SYSTEM_ERROR");
//P51M0012                        strOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult;
//P51M0012                        return ( rc );
//P51M0012                    }
//P51M0012                    else if( rc != RC_OK )
//P51M0012                    {
//P51M0012                        PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK");
//P51M0012                        strOpeCompForInternalBufferReqResult.strResult = strHoldLotReqResult.strResult;
//P51M0012                    }
//D7000021                } //for strAPCLotWaferCollection
//D7000021            } // APCSystemFunction_Type == ProductDisposition
//D7000021 Delete end
        } //for strAPCRunTimeCapability
    } //for strAPCRunTimeCapabilityResponse


    if ( bActionTriggerFlag == TRUE )
    {
//D7000021        /*-----------------------------------------------------*/
//D7000021        /*   Call APC_productDispositionActionTrigger_Put      */
//D7000021        /*-----------------------------------------------------*/
//D7000021        PPT_METHODTRACE_V1("", "call APC_productDispositionActionTrigger_Put");
//D7000021        objAPC_productDispositionActionTrigger_Put_out strAPC_productDispositionActionTrigger_Put_out;
//D7000021        rc = APC_productDispositionActionTrigger_Put ( strAPC_productDispositionActionTrigger_Put_out,
//D7000021                                                       strObjCommonIn,
//D7000021                                                       equipmentID,
//D7000021                                                       controlJobID );
//D7000021        if ( rc != RC_OK )
//D7000021        {
//D7000021            PPT_METHODTRACE_V1("", "APC_productDispositionActionTrigger_Put != RC_OK");
//D7000021            strOpeCompForInternalBufferReqResult.strResult = strAPC_productDispositionActionTrigger_Put_out.strResult;
//D7000021            return( rc );
//D7000021        }
        PPT_METHODTRACE_V1("", "Leave the record for APCDisposition in FSRUNCAPAxx .");    //D7000021
    }
    else    //bHoldFlag == FALSE
    {
        /*-----------------------------------------------------*/
        /*   Call APCRuntimeCapability_DeleteDR                */
        /*-----------------------------------------------------*/
        PPT_METHODTRACE_V1("", "call APCRuntimeCapability_DeleteDR");
        objAPCRuntimeCapability_DeleteDR_out strAPCRuntimeCapability_DeleteDR_out;
        rc = APCRuntimeCapability_DeleteDR ( strAPCRuntimeCapability_DeleteDR_out,
                                             strObjCommonIn,
                                             controlJobID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "APCRuntimeCapability_DeleteDR != RC_OK");
            strOpeCompForInternalBufferReqResult.strResult = strAPCRuntimeCapability_DeleteDR_out.strResult;
            return( rc );
        }
    }
//DSN000015229 Add Start
    if ( 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC015" )    //TxPartialOpeCompWithDataReq
      && 0 != CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC016" ) )  //TxPartialOpeCompForInternalBufferReq
    {
//DSN000015229 Add End

        /*-------------------------------------------------*/
        /*   Call APCMgr_SendControlJobInformationDR       */
        /*-------------------------------------------------*/
        PPT_METHODTRACE_V1("", "call APCMgr_SendControlJobInformationDR()");
        objAPCMgr_SendControlJobInformationDR_out strAPCMgr_SendControlJobInformationDR_out;
        rc = APCMgr_SendControlJobInformationDR ( strAPCMgr_SendControlJobInformationDR_out,
                                                  strObjCommonIn,
                                                  equipmentID,
                                                  controlJobID,
                                                  SP_APC_ControlJobStatus_Completed,
                                                  strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList );
    //D7000182    if ( rc != RC_OK )
        if ( rc != RC_OK && rc != RC_OK_NO_IF )    //D7000182
        {
            PPT_METHODTRACE_V1("", "APCMgr_SendControlJobInformationDR != RC_OK");
            strOpeCompForInternalBufferReqResult.strResult = strAPCMgr_SendControlJobInformationDR_out.strResult;
            return( rc );
        }

    //D7000182 add start
        if( rc == RC_OK )
        {
            PPT_METHODTRACE_V1("", "APCControlJobInformation was sent normally.");
            CORBA::String_var tmpString = APCIFControlStatus;
            APCIFControlStatus = CIMFWStrDup(SP_APC_ControlJobStatus_Executing);
        }
    //D7000182 add end
//DSN000015229 Add Start
    }
    else
    {
        PPT_METHODTRACE_V1("", "strObjCommonIn.transactionID == TXEWC015 || TXEWC016");
        // set the strAPCBaseCassetteList as return
        strAPCBaseCassetteListForOpeComp = strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList;
    }
//DSN000015229 Add End
//D51M0000 Add End

//D9000084 add start
    /*--------------------------------------*/
    /*  Update Reticle's LastUsedTimestamp  */
    /*--------------------------------------*/
    objReticle_lastUsedTimeStamp_Update_in strReticle_lastUsedTimeStamp_Update_in;
    strReticle_lastUsedTimeStamp_Update_in.strStartCassette = strControlJob_startReserveInformation_Get_out.strStartCassette;

    objReticle_lastUsedTimeStamp_Update_out strReticle_lastUsedTimeStamp_Update_out;
    rc = reticle_lastUsedTimeStamp_Update( strReticle_lastUsedTimeStamp_Update_out,
                                           strObjCommonIn,
                                           strReticle_lastUsedTimeStamp_Update_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "reticle_lastUsedTimeStamp_Update() != RC_OK");
        strOpeCompForInternalBufferReqResult.strResult = strReticle_lastUsedTimeStamp_Update_out.strResult;
        return( rc );
    }
//D9000084 add end

//DSN000085791 Add Start
    objEntityInhibitExceptionLot_ChangeForOpeComp_in strExceptionLot_ChangeForOpeComp_in;
    strExceptionLot_ChangeForOpeComp_in.lotIDs = opeStartLotIDs;
    strExceptionLot_ChangeForOpeComp_in.controlJobID = controlJobID;

    objEntityInhibitExceptionLot_ChangeForOpeComp_out strExceptionLot_ChangeForOpeComp_out;
    rc = entityInhibitExceptionLot_ChangeForOpeComp(strExceptionLot_ChangeForOpeComp_out, strObjCommonIn, strExceptionLot_ChangeForOpeComp_in);
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "entityInhibitExceptionLot_ChangeForOpeComp() != RC_OK");
        strOpeCompForInternalBufferReqResult.strResult = strExceptionLot_ChangeForOpeComp_out.strResult;
        return( rc );
    }
//DSN000085791 Add End

//D7000178//P51M0018 move start
//D7000178    /*--------------------------*/
//D7000178    /*                          */
//D7000178    /*   Set Return Structure   */
//D7000178    /*                          */
//D7000178    /*--------------------------*/
//D7000178    objEquipment_FillInTxTRC004_out   strEquipment_FillInTxTRC004_out;
//D7000178    rc = equipment_FillInTxTRC004( strEquipment_FillInTxTRC004_out,
//D7000178                                   strObjCommonIn,
//D7000178                                   strStartCassette,
//D7000178                                   strSpcCheckReqResult.strSpcCheckLot );
//D7000178    if ( rc != RC_OK )
//D7000178    {
//D7000178        PPT_METHODTRACE_V1("", "equipment_FillInTxTRC004() != RC_OK") ;
//D7000178        strOpeCompForInternalBufferReqResult.strResult = strEquipment_FillInTxTRC004_out.strResult ;
//D7000178        return(rc);
//D7000178    }

    /*----------------------*/
    /*                      */
    /*   Return to Caller   */
    /*                      */
    /*----------------------*/
//D7000178    strOpeCompForInternalBufferReqResult = strEquipment_FillInTxTRC004_out.strOpeCompWithDataReqResult ;
//D7000178//P51M0018 move end

//DSIV00000201 add start
    if( PostProcForLotFlag != 1 )
    {
//DSIV00000201 add end
        strOpeCompForInternalBufferReqResult = strCollectedDataActionReqResult.strOpeCompWithDataReqResult;    //D7000178
//DSIV00000201 add start
    }
    else
    {
        strOpeCompForInternalBufferReqResult.strResult     = strReticle_lastUsedTimeStamp_Update_out.strResult;
        nLen = opeStartLotIDs.length();
        strOpeCompForInternalBufferReqResult.strOpeCompLot.length(nLen);
        for( i=0 ; i<nLen ; i++ )
        {
            strOpeCompForInternalBufferReqResult.strOpeCompLot[i].lotID = opeStartLotIDs[i];
        }
    }
//DSIV00000201 add end

    SET_MSG_RC(strOpeCompForInternalBufferReqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txOpeCompForInternalBufferReq__120") ;
    return( RC_OK );
}

//DSIV00000201 add start
void DebugOutStartCassette(pptDataSpecCheckReqResult& tg)   //P3100372 add
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txOpeCompForInternalBufferReq__120::DebugOutStartCassette ") ; //D4100092
    PPT_METHODTRACE_V1("", "P3100372 log start ******************************************");
    CORBA::Long ii, jj, kk, ll, mm;
    CORBA::Long len1, len2, len3, len4, len5;
    len1 = tg.strStartCassette.length();
    PPT_METHODTRACE_V2("", "tg.strStartCassette.length**********>", len1);
    for(ii=0; ii < len1; ii++)
    {
        PPT_METHODTRACE_V2("", "loadSequenceNumber------------------------", tg.strStartCassette[ii].loadSequenceNumber);
        PPT_METHODTRACE_V2("", "cassetteID--------------------------------", tg.strStartCassette[ii].cassetteID.identifier);
        PPT_METHODTRACE_V2("", "loadPurposeType---------------------------", tg.strStartCassette[ii].loadPurposeType);
        PPT_METHODTRACE_V2("", "loadPortID--------------------------------", tg.strStartCassette[ii].loadPortID.identifier);
        PPT_METHODTRACE_V2("", "unloadPortID------------------------------", tg.strStartCassette[ii].unloadPortID.identifier);

        len2 = tg.strStartCassette[ii].strLotInCassette.length();
        PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette.length**********>", len2);
        for(jj=0; jj < len2; jj++)
        {
            PPT_METHODTRACE_V2("", "  operationStartFlag----------------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].operationStartFlag); //D9000001
            PPT_METHODTRACE_V2("", "  monitorLotFlag--------------------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].monitorLotFlag); //D9000001
            PPT_METHODTRACE_V2("", "  lotID-----------------------------------", tg.strStartCassette[ii].strLotInCassette[jj].lotID.identifier);
            PPT_METHODTRACE_V2("", "  lotType---------------------------------", tg.strStartCassette[ii].strLotInCassette[jj].lotType);
            PPT_METHODTRACE_V2("", "  subLotType------------------------------", tg.strStartCassette[ii].strLotInCassette[jj].subLotType);
            PPT_METHODTRACE_V2("", "    logicalRecipeID-----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.logicalRecipeID.identifier);
            PPT_METHODTRACE_V2("", "    machineRecipeID-----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.machineRecipeID.identifier);
            PPT_METHODTRACE_V2("", "    physicalRecipeID----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.physicalRecipeID);

            len3 = tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartReticle.length();
            PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartReticle.length**********>", len3);
            for(kk=0; kk < len3; kk++)
            {
                PPT_METHODTRACE_V2("", "      sequenceNumber----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartReticle[kk].sequenceNumber);
                PPT_METHODTRACE_V2("", "      reticleID---------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartReticle[kk].reticleID.identifier);
            }
            len3 = tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartFixture.length();
            PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartFixture.length**********>", len3);
            for(kk=0; kk < len3; kk++)
            {
                PPT_METHODTRACE_V2("", "      fixtureID---------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartFixture[kk].fixtureID.identifier);
                PPT_METHODTRACE_V2("", "      fixtureCategory---------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strStartFixture[kk].fixtureCategory);
                PPT_METHODTRACE_V2("", "    dataCollectionFlag--------------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.dataCollectionFlag); //D9000001
            }
            len3 = tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef.length();
            PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef.length**********>", len3);
            for(kk=0; kk < len3; kk++)
            {
                PPT_METHODTRACE_V2("", "      dataCollectionDefinitionID----------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].dataCollectionDefinitionID.identifier);
                PPT_METHODTRACE_V2("", "      description-------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].description);
                PPT_METHODTRACE_V2("", "      dataCollectionType------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].dataCollectionType);

                len4 = tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem.length();
                PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem.length**********>", len4);
                for(ll=0; ll < len4; ll++)
                {
                    PPT_METHODTRACE_V2("", "        dataCollectionItemName------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].dataCollectionItemName);
                    PPT_METHODTRACE_V2("", "        dataCollectionMode----------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].dataCollectionMode);
                    PPT_METHODTRACE_V2("", "        dataCollectionUnit----------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].dataCollectionUnit);
                    PPT_METHODTRACE_V2("", "        dataType--------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].dataType);
                    PPT_METHODTRACE_V2("", "        itemType--------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].itemType);
                    PPT_METHODTRACE_V2("", "        measurementType-------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].measurementType);
                    PPT_METHODTRACE_V2("", "        waferID---------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].waferID.identifier);
                    PPT_METHODTRACE_V2("", "        waferPosition---------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].waferPosition);
                    PPT_METHODTRACE_V2("", "        sitePosition----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].sitePosition);
                    PPT_METHODTRACE_V2("", "        historyRequiredFlag---------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].historyRequiredFlag); //D9000001
                    PPT_METHODTRACE_V2("", "        calculationType-------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].calculationType);
                    PPT_METHODTRACE_V2("", "        calculationExpression-------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].calculationExpression);
                    PPT_METHODTRACE_V2("", "        dataValue-------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].dataValue);
                    PPT_METHODTRACE_V2("", "        targetValue-----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].targetValue);
                    PPT_METHODTRACE_V2("", "        specCheckResult-------------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].strDCItem[ll].specCheckResult);
                }
                PPT_METHODTRACE_V2("", "      calculationRequiredFlag-------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].calculationRequiredFlag); //D9000001
                PPT_METHODTRACE_V2("", "      specCheckRequiredFlag---------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].specCheckRequiredFlag); //D9000001
                PPT_METHODTRACE_V2("", "      dataCollectionSpecificationID-------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].dataCollectionSpecificationID.identifier);
                PPT_METHODTRACE_V2("", "      previousDataCollectionDefinitionID--", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].previousDataCollectionDefinitionID.identifier);
                PPT_METHODTRACE_V2("", "      previousOperationID-----------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].previousOperationID.identifier);
                PPT_METHODTRACE_V2("", "      previousOperationNumber-------------", tg.strStartCassette[ii].strLotInCassette[jj].strStartRecipe.strDCDef[kk].previousOperationNumber);
                PPT_METHODTRACE_V2("", "  recipeParameterChangeType---------------", tg.strStartCassette[ii].strLotInCassette[jj].recipeParameterChangeType);
            }
            len3 = tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer.length();
            PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer.length**********>", len3);
            for(kk=0; kk < len3; kk++)
            {
                PPT_METHODTRACE_V2("", "    waferID-------------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].waferID.identifier);
                PPT_METHODTRACE_V2("", "    slotNumber----------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].slotNumber);
                PPT_METHODTRACE_V2("", "    controlWaferFlag----------------------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].controlWaferFlag); //D9000001

                len4 = tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].strStartRecipeParameter.length();
                PPT_METHODTRACE_V2("", "tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].strStartRecipeParameter.length**********>", len4);
                for(ll=0; ll < len4; ll++)
                {
                    PPT_METHODTRACE_V2("", "      parameterName-----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].strStartRecipeParameter[ll].parameterName);
                    PPT_METHODTRACE_V2("", "      parameterValue----------------------", tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].strStartRecipeParameter[ll].parameterValue);
                    PPT_METHODTRACE_V2("", "      targetValue-------------------------", tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].strStartRecipeParameter[ll].targetValue);
                    PPT_METHODTRACE_V2("", "      useCurrentSettingValueFlag----------", (CORBA::Long)tg.strStartCassette[ii].strLotInCassette[jj].strLotWafer[kk].strStartRecipeParameter[ll].useCurrentSettingValueFlag); //D9000001
                }
            }
            PPT_METHODTRACE_V2("", "  productID-------------------------------", tg.strStartCassette[ii].strLotInCassette[jj].productID.identifier);
        }
    }
    PPT_METHODTRACE_V1("", "P3100372 log end ******************************************");
}
//DSIV00000201 add end
