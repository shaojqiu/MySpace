#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/txPrivilegeCheckReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:29:38 [ 7/13/07 21:29:39 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: txPrivilegeCheckReq.cpp
//

#include "cs_pptmgr.hpp"

// Class: PPTManager
//
// Service: txPrivilegeCheckReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2001/06/12 D4000013 Y.Kadowaki     Unified Security Control
// 2003/07/07 D5000123 H.Adachi       Add switch to call person_PrivilegeCheck and person_PrivilegeCheckDR
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/28 INN-R170008  Menghua Yin    TA Certify Support

// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptPrivilegeCheckReqResult& strPrivilegeCheckReqResult
//     const pptObjCommonIn& strObjCommonIn
//     const objectIdentifier& equipmentID
//     const objectIdentifier& stockerID
//     const objectIdentifierSequence& productIDs
//     const objectIdentifierSequence& routeIDs
//     const objectIdentifierSequence& lotIDs
//     const objectIdentifierSequence& machineRecipeIDs
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

//D4000013 CORBA::Long PPTManager_i::txPrivilegeCheckReq (pptPrivilegeCheckReqResult& strPrivilegeCheckReqResult, pptObjCommonIn& strObjCommonIn,  const objectIdentifier& equipmentID,  const objectIdentifier& stockerID, CORBA::Environment &IT_env)
//D6000025 CORBA::Long PPTManager_i::txPrivilegeCheckReq (pptPrivilegeCheckReqResult& strPrivilegeCheckReqResult, pptObjCommonIn& strObjCommonIn,  const objectIdentifier& equipmentID,  const objectIdentifier& stockerID,  const objectIdentifierSequence& productIDs,  const objectIdentifierSequence& routeIDs,  const objectIdentifierSequence& lotIDs,  const objectIdentifierSequence& machineRecipeIDs,  CORBA::Environment &IT_env)
CORBA::Long CS_PPTManager_i::txPrivilegeCheckReq (pptPrivilegeCheckReqResult& strPrivilegeCheckReqResult, pptObjCommonIn& strObjCommonIn,  const objectIdentifier& equipmentID,  const objectIdentifier& stockerID,  const objectIdentifierSequence& productIDs,  const objectIdentifierSequence& routeIDs,  const objectIdentifierSequence& lotIDs,  const objectIdentifierSequence& machineRecipeIDs CORBAENV_LAST_CPP) //D6000025
{
    PPT_METHODTRACE_ENTRY("PPTManager_i:: txPrivilegeCheckReq")
    CORBA::Long rc ;

    PPT_METHODTRACE_V1("PPTManager_i:: txPrivilegeCheckReq", "strObjCommonIn.strUser.privilegeFlag == TRUE")
//D5000123    //-------------------------
//D5000123    //   Check the privilege
//D5000123    //-------------------------
//D5000123    objPerson_PrivilegeCheck_out strPerson_PrivilegeCheck_out;
//D5000123    //D4000013 rc = person_PrivilegeCheck(strPerson_PrivilegeCheck_out,strObjCommonIn,strObjCommonIn.strUser,equipmentID,stockerID) ;
//D5000123    rc = person_PrivilegeCheck(strPerson_PrivilegeCheck_out,strObjCommonIn,strObjCommonIn.strUser,equipmentID,stockerID,productIDs,routeIDs,lotIDs,machineRecipeIDs) ; //D4000013
//D5000123    if( rc )
//D5000123    {
//D5000123        PPT_METHODTRACE_V1("PPTManager_i:: txPrivilegeCheckReq", "rc != RC_OK")
//D5000123        strPrivilegeCheckReqResult.strResult = strPerson_PrivilegeCheck_out.strResult ;
//D5000123        return( rc );
//D5000123    }

    //D5000123 Add Start
    //-------------------------------------------------
    // Getting Privilege Check By DR Flag and judgement
    //-------------------------------------------------
    CORBA::String_var privilegeCheck_By_DR_FLAG = CIMFWStrDup(getenv(SP_PrivilegeCheck_BY_DR_FLAG));

    if ( CIMFWStrCmp( privilegeCheck_By_DR_FLAG, "1" ) == 0 )
    {
        PPT_METHODTRACE_V1( "", "Privilege Check By DR Flag == 1" );
        //----------------------------
        // Check the provilege By DR
        //----------------------------
        objPerson_PrivilegeCheckDR_out    strPerson_PrivilegeCheckDR_out;
        rc = person_PrivilegeCheckDR( strPerson_PrivilegeCheckDR_out,
                                      strObjCommonIn,
                                      strObjCommonIn.strUser,
                                      equipmentID,
                                      stockerID,
                                      productIDs,
                                      routeIDs,lotIDs,
                                      machineRecipeIDs);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "### person_PrivilegeCheckDR rc != RC_OK ##")
            strPrivilegeCheckReqResult.strResult = strPerson_PrivilegeCheckDR_out.strResult ;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1( "", "Privilege Check By DR Flag != 1" );
        //----------------------------
        // Check the provilege By FW 
        //----------------------------
        objPerson_PrivilegeCheck_out strPerson_PrivilegeCheck_out;
        rc = person_PrivilegeCheck(strPerson_PrivilegeCheck_out,
                                   strObjCommonIn,
                                   strObjCommonIn.strUser,equipmentID,
                                   stockerID,
                                   productIDs,
                                   routeIDs,
                                   lotIDs,
                                   machineRecipeIDs);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("PPTManager_i:: txPrivilegeCheckReq", "rc != RC_OK")
            strPrivilegeCheckReqResult.strResult = strPerson_PrivilegeCheck_out.strResult ;
            return( rc );
        }
    }
    //D5000123 Add End
    
    //INN-R170008 Add Start
    csObjPerson_PrivilegeCheckForTACertify_out strObjPerson_PrivilegeCheckForTACertify_out;
    csObjPerson_PrivilegeCheckForTACertify_in strObjPerson_PrivilegeCheckForTACertify_in;

    strObjPerson_PrivilegeCheckForTACertify_in.userID = strObjCommonIn.strUser.userID;
    strObjPerson_PrivilegeCheckForTACertify_in.equipmentID = equipmentID;

    rc = cs_person_PrivilegeCheckForTACertify(strObjPerson_PrivilegeCheckForTACertify_out, strObjCommonIn, strObjPerson_PrivilegeCheckForTACertify_in);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("PPTManager_i:: txPrivilegeCheckReq", "rc != RC_OK")
        strPrivilegeCheckReqResult.strResult = strObjPerson_PrivilegeCheckForTACertify_out.strResult;
        return(rc);
    }
    //INN-R170008 Add End

    //-----------------------
    //   Set out structure
    //-----------------------
    SET_MSG_RC(strPrivilegeCheckReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("PPTManager_i:: txPrivilegeCheckReq")
    return( RC_OK );
}
