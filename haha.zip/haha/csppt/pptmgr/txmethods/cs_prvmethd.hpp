// @(#) 1.3 superpos/src/csppt/source/posppt/pptmgr/txmethods/cs_prvmethd.hpp, mm_srv_5_0_cspp, mm_srv_5_0_cspp 6/9/03 14:15:42 [ 6/9/03 14:15:43 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView         : MMS
// File Name      : cs_prvmethd.hpp
// Description    : Declaration Customized tx Method
//
// ** Notice **
//   This is a sample code for customizing a PPT Manager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT Manager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//
// Change history:
//
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya      Initial Release for R5.0
// 2004/10/26 D6000025 K.Murakami      eBrokerMigration.
//
// Innotron Modification history :
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
// 2017/08/28 INN-R170002 Yangxiaojun    Contamination Control
// 2017/08/28 INN-R170003 Helios Zhen    INN-R170003:Durable Management Enhancement
// 2017/07/25 INN-R170084 Jacky Yeh      170084: Automatic Vendor Lot Receive and Prepare
// 2017/09/11 INN-R170006 YangXigang     For fixture
// 2017/09/13 INN-R170008 Menghua Yin    TA Certify Support
// 2017/09/15 INN-R170003 LiHejing       Durable Management Enhancement
// 2017/09/18 INN-R170014 shenql         Durable Management Enhancement
// 2017/09/19 INN-R170003 LiHejing       Durable Management Enhancement
// 2017/09/24 INN-R170003 LiuXinxin      Durable Management Enhancement
// 2017/09/25 INN-R170003 XL.Cong        Durable Management Enhancement
// 2017/09/26 INN-R170003 SF.Peng        Durable Management Enhancement
// 2017/09/26 INN-R170003 Joan Zhou      INN-R170003:Durable Management Enhancement
// 2017/09/26 INN-R170003 XL.Cong        Durable Management Enhancement
// 2017/09/25 INN-R170009 liuXinxin      Litho APC Enhancement
// 2017/09/27 INN-R170003 SF.Peng        Durable Management Enhancement
// 2017/09/28 INN-R170003 XL.Cong        Durable Management Enhancement
// 2017/10/10 INN-R170003 YangXigang     Durable Management Enhancement
// 2017/10/11 INN-R170003 XL.Cong        Durable Management Enhancement
// 2017/10/16 INN-R170009 Nick Tsai      add lot complicated hold
// 2017/10/18 INN-R170009 Qufd           Add APC Queue
// 2017/10/18 INN-R170016 Yangxiaojun    NPW Monitor Customization
// 2017/10/19 INN-R170027 Vera Chen      NPW Product Change

#ifndef CS_Prvmethd_hpp
#define CS_Prvmethd_hpp

// Declare Customized tx Method here.

//INN-A170001 Add Start
virtual CORBA::Long cs_txEqpListByOwnerInq(
    csEqpListByOwnerInqResult&         strCsEqpListByOwnerInqResult,
    const pptObjCommonIn&              strObjCommonIn,
    const objectIdentifier&            equipmentOwnerID
    CORBAENV_LAST_HPP
);

virtual CORBA::Long cs_txEqpInAuditListInq(
    csEqpInAuditListInqResult&              strCsEqpInAuditListInqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    CORBA::Boolean                          bodyFlag,
    CORBA::Boolean                          constFlag
    CORBAENV_LAST_HPP
);

virtual CORBA::Long cs_txEqpRMSFlgInq(
    csEqpRMSFlgInqResult&         strEqpRMSFlgInqResult,
    const pptObjCommonIn&         strObjCommonIn,
    const objectIdentifier&       equipmentID
    CORBAENV_LAST_HPP
);

virtual CORBA::Long cs_txRecipeAuditReq
(
    csRecipeAuditReqResult&          strRecipeAuditReqResult,
    const pptObjCommonIn&            strObjCommonIn,
    const objectIdentifier&          equipmentID,
    const objectIdentifier&          machineRecipeID,
    CORBA::Boolean                   bolEqpConstFlag,
    CORBA::Boolean                   bolBodyFlag
    CORBAENV_LAST_HPP
);

virtual CORBA::Long cs_txPrivilegeCheckForRMSReq
(
    csPrivilegeCheckForRMSReqResult&      strCsPrivilegeCheckForRMSReqResult,
    const pptObjCommonIn&                 strObjCommonIn,
    const objectIdentifier&               equipmentID
    CORBAENV_LAST_HPP
);

virtual CORBA::Long cs_txEqpInfoListByOwnerInq(
    csEqpInfoListByOwnerInqResult&     strCsEqpInfoListByOwnerInqResult,
    const pptObjCommonIn&              strObjCommonIn,
    const objectIdentifier&            equipmentOwnerID
    CORBAENV_LAST_HPP
);

virtual CORBA::Long txLotVerifyForLoadingReq
(
    pptLotVerifyForLoadingReqResult& strLotVerifyForLoadingReqResult,
    const pptObjCommonIn&            strObjCommonIn,
    const objectIdentifier&          equipmentID,
    const objectIdentifier&          portID,
    const objectIdentifier&          cassetteID,
    const char *                     lotPurposeType
    CORBAENV_LAST_HPP
) ;

virtual CORBA::Long cs_txEqpRelatedRecipeIDAuditFlagListInq
(
    csEqpRelatedRecipeIDAuditFlagListInqResult& strEqpRelatedRecipeIDAuditFlagListInqResult,
    const pptObjCommonIn& strObjCommonIn,
    const objectIdentifier& equipmentID,
    CORBA::Boolean getAuditFlag
    CORBAENV_LAST_HPP
) ;
//INN-R170014 Add Start
virtual CORBA::Long cs_txStartLotsReservationForInternalBufferReq
(
        pptStartLotsReservationForInternalBufferReqResult&  strStartLotsReservationForInternalBufferReqResult,
        const pptObjCommonIn&                               strObjCommonIn,
        const objectIdentifier&                             equipmentID,
        const objectIdentifier&                             controlJobID,
        const pptStartCassetteSequence&                     strStartCassette,
		CORBA::Boolean                                      skipBatchSizeFlag,
        CORBA::Boolean                                      skipWaferCountFlag,
        const char*                                         claimMemo,
        char *&                                             APCIFControlStatus
        CORBAENV_LAST_HPP
);
//INN-R170014 Add End
virtual CORBA::Long txStartLotsReservationReq
(
    pptStartLotsReservationReqResult&   strStartLotsReservationReqResult,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             equipmentID,
    const char *                        portGroupID,
    const objectIdentifier&             controlJobID,
    const pptStartCassetteSequence&     strStartCassette,
    const char *                        claimMemo,
    char *&                             APCIFControlStatus
    CORBAENV_LAST_HPP
);
//INN-A170001 Add End

//INN-R170002 Add Start
virtual CORBA::Long txBranchReq(
    pptBranchReqResult& strBranchReqResult,
    const pptObjCommonIn& strObjCommonIn,
    const pptBranchReq& strBranchReq,
    const char * claimMemo
    CORBAENV_LAST_HPP
);

virtual CORBA::Long txGatePassReq(
    pptGatePassReqResult& strGatePassReqResult,
    const pptObjCommonIn& strObjCommonIn,
    CORBA::Long seqIndex,
    const pptGatePassLotInfoSequence& strGatePassLotInfo,
    const char * claimMemo,
    objectIdentifierSequence& holdReleasedLotIDs
    CORBAENV_LAST_HPP);

virtual CORBA::Long txLotReQueueReq(
    pptLotReQueueReqResult& strLotReQueueReqResult,
    const pptObjCommonIn& strObjCommonIn,
    const pptLotReQueueAttributeSequence& strLotReQueueAttributes,
    const char *claimMemo
    CORBAENV_LAST_HPP);

virtual	CORBA::Long txLotSchdlChangeReq__110(
    pptLotSchdlChangeReqResult& strLotSchdlChangeReqResult,
    const pptObjCommonIn& strObjCommonIn,
    const pptRescheduledLotAttributesSequence__110& strRescheduledLotAttributes,
    const char *claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long txOpeCompForInternalBufferReq__120(
    pptOpeCompForInternalBufferReqResult&  strOpeCompForInternalBufferReqResult,
    const pptObjCommonIn&                  strObjCommonIn,
    const objectIdentifier&                equipmentID,
    const objectIdentifier&                controlJobID,
    CORBA::Boolean                         spcResultRequiredFlag,
    const char *                           claimMemo,
    objectIdentifierSequence&              holdReleasedLotIDs,
    pptAPCBaseCassetteSequence&            strAPCBaseCassetteListForOpeComp,
    char *&                                APCIFControlStatus,
    char *&                                DCSIFControlStatus
    CORBAENV_LAST_HPP);

virtual CORBA::Long txOpeCompWithDataReq__120(
    pptOpeCompWithDataReqResult&      strOpeCompWithDataReqResult,
    const pptObjCommonIn&             strObjCommonIn,
    const objectIdentifier&           equipmentID,
    const objectIdentifier&           controlJobID,
    CORBA::Boolean                    spcResultRequiredFlag,
    const char*                       claimMemo,
    objectIdentifierSequence&         holdReleasedLotIDs,
    pptAPCBaseCassetteSequence&       strAPCBaseCassetteListForOpeComp,
    char *&                           APCIFControlStatus,
    char *&                           DCSIFControlStatus
    CORBAENV_LAST_HPP);

virtual CORBA::Long txOpeLocateReq(
    pptOpeLocateReqResult& strOpeLocateReqResult,
    const pptObjCommonIn& strObjCommonIn,
    CORBA::Boolean locateDirection,
    const objectIdentifier& lotID,
    const objectIdentifier& currentRouteID,
    const char * currentOperationNumber,
    const objectIdentifier& routeID,
    const objectIdentifier& operationID,
    const char * operationNumber,
    const pptProcessRef& processRef,
    CORBA::Long  seqno,
    const char * claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long txPartialReworkReq(
    pptPartialReworkReqResult&      strPartialReworkReqResult,
    const pptObjCommonIn&           strObjCommonIn,
    const pptPartialReworkReq&      strPartialReworkReq,
    const char *                    claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long txPartialReworkWithoutHoldReleaseReq(
    pptPartialReworkWithoutHoldReleaseReqResult&  strPartialReworkWithoutHoldReleaseReqResult,
    const pptObjCommonIn&                         strObjCommonIn,
    const pptPartialReworkReq&                    strPartialReworkReq,
    const char*                                   claimMemo,
    const pptHoldListSequence&                    strLotHoldRequests CORBAENV_LAST_HPP);

virtual CORBA::Long txReworkReq(
    pptReworkReqResult& strReworkReqResult,
    const pptObjCommonIn& strObjCommonIn,
    const pptReworkReq& strReworkReq,
    const char * claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long txReworkWholeLotCancelReq(
    pptReworkWholeLotCancelReqResult& strReworkWholeLotCancelReqResult,
    const pptObjCommonIn& strObjCommonIn,
    const objectIdentifier& lotID,
    const objectIdentifier& currentRouteID,
    const char * currentOperationNumber,
    const objectIdentifier& reasonCodeID,
    const char * claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long txSchdlChangeReservationExecuteReq__110(
    pptSchdlChangeReservationExecuteReqResult&      strSchdlChangeReservationExecuteReqResult,
    const pptObjCommonIn&                           strObjCommonIn,
    const pptRescheduledLotAttributesSequence__110& strRescheduledLotAttributes,
    const char *                                    claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long txSplitWaferLotReq(
    pptSplitWaferLotReqResult&              strSplitWaferLotReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&                 parentLotID,
    const objectIdentifierSequence&         childWaferID,
    CORBA::Boolean                          futureMergeFlag,
    const objectIdentifier&                 mergedRouteID,
    const char *                            mergedOperationNumber,
    CORBA::Boolean                          branchingRouteSpecifyFlag,
    const objectIdentifier&                 subRouteID,
    const char *                            returnOperationNumber,
    const char *                            claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long txSubRouteBranchCancelReq(
    pptSubRouteBranchCancelReqResult& strSubRouteBranchCancelReqResult,
    const pptObjCommonIn& strObjCommonIn,
    const objectIdentifier& lotID,
    const objectIdentifier& currentRouteID,
    const char * currentOperationNumber,
    const char * claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long txWIPLotResetReq(
    pptWIPLotResetReqResult&       strWIPLotResetReqResult,
    const pptObjCommonIn&           strObjCommonIn,
    const pptWIPLotResetReqInParm&  strWIPLotResetReqInParm,
    const char *                    claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long txHoldLotReleaseReq(
    pptHoldLotReleaseReqResult& strHoldLotReleaseReqResult,
    const pptObjCommonIn& strObjCommonIn,
    const objectIdentifier& lotID,
    const objectIdentifier& releaseReasonCodeID,
    const pptHoldListSequence& strLotHoldReqList
    CORBAENV_LAST_HPP);

virtual CORBA::Long txMonitorLotSTBAfterProcessReq(
    pptMonitorLotSTBAfterProcessReqResult&  strMonitorLotSTBAfterProcessReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&                 processEquipmentID,
    const char *                            stbLotSubLotType,
    const pptNewLotAttributes&              strNewLotAttributes,
    const objectIdentifierSequence&         productLotIDs,
    const char *                            claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long txCtrlLotSTBReq(
    pptCtrlLotSTBReqResult&     strCtrlLotSTBReqResult,
    const pptObjCommonIn&       strObjCommonIn,
    const objectIdentifier&     productID,
    CORBA::Long                 waferCount,
    const char *                lotType,
    const char *                subLotType,
    const pptNewLotAttributes&  strNewLotAttributes,
    const char *                claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long txSTBReleasedLotReq(
    pptSTBReleasedLotReqResult&     strSTBReleasedLotReqResult,
    const pptObjCommonIn&           strObjCommonIn,
    const objectIdentifier&         productRequestID,
    const pptNewLotAttributes&      strNewLotAttributes,
    const char *                    claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long txStartLotsReservationForTakeOutInReq(
    pptStartLotsReservationForTakeOutInReqResult&       strStartLotsReservationForTakeOutInReqResult,
    const pptObjCommonIn&                               strObjCommonIn,
    const pptStartLotsReservationForTakeOutInReqInParm& strStartLotsReservationForTakeOutInReqInParm,
    const char *                                        claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long txOpeStartReq(
    pptOpeStartReqResult&               strOpeStartReqResult,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             equipmentID,
    const char *                        portGroupID,
    const objectIdentifier&             controlJobID,
    const pptStartCassetteSequence&     strStartCassette,
    CORBA::Boolean                      processJobPauseFlag,
    const char*                         claimMemo,
    char *&                             APCIFControlStatus,
    char *&                             DCSIFControlStatus
    CORBAENV_LAST_HPP);

virtual CORBA::Long txOpeStartForInternalBufferReq(
    pptOpeStartForInternalBufferReqResult&  strOpeStartForInternalBufferReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&                 equipmentID,
    const objectIdentifier&                 controlJobID,
    const pptStartCassetteSequence&         strStartCassette,
    CORBA::Boolean                          processJobPauseFlag,
    const char*                             claimMemo,
    char *&                                 APCIFControlStatus,
    char *&                                 DCSIFControlStatus
    CORBAENV_LAST_HPP);

virtual CORBA::Long txCassetteDeliveryReq(
    pptCassetteDeliveryReqResult& strCassetteDeliveryReqResult,
    const pptObjCommonIn& strObjCommonIn,
    const objectIdentifier& equipmentID
    CORBAENV_LAST_HPP);

virtual CORBA::Long txCassetteDeliveryForInternalBufferReq(
    pptCassetteDeliveryForInternalBufferReqResult& strCassetteDeliveryForInternalBufferReqResult,
    const pptObjCommonIn&                          strObjCommonIn,
    const objectIdentifier&                        equipmentID
    CORBAENV_LAST_HPP);

virtual CORBA::Long txWaferSortReq(
    pptWaferSortReqResult& strWaferSortReqResult,
    const pptObjCommonIn&  strObjCommonIn,
    const objectIdentifier& equipmentID,
    const pptWaferTransferSequence& strWaferXferSeq,
    CORBA::Boolean bNotifyToTCS,
    const char * claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long txCassetteExchangeReq(
    pptCassetteExchangeReqResult&       strCassetteExchangeReqResult,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             equipmentID,
    const pptWaferTransferSequence&     strWaferXferSeq,
    const char *                        claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long txSortJobCreateReq(
    pptSortJobCreateReqResult&                           strSortJobCreateReqResult,
    const pptObjCommonIn&                                strObjCommonIn,
    const pptSorterComponentJobListAttributesSequence&   strSorterComponentJobListAttributesSequence,
    const objectIdentifier&                              equipmentID,
    const char *                                         portGroupID,
    CORBA::Boolean                                       waferIDReadFlag,
    const char *                                         claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long txVendorLotPreparationReq(
    pptVendorLotPreparationReqResult&   strVendorLotPreparationReqResult,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             bankID,
    const char *                        lotType,
    const char *                        subLotType,
    const pptNewLotAttributes&          strNewLotAttributes,
    const char *                        claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long txVendorLotReceiveAndPrepareReq(
    pptVendorLotReceiveAndPrepareReqResult& strVendorLotReceiveAndPrepareReqResult,
    const pptObjCommonIn&   strObjCommonIn,
    const objectIdentifier& equipmentID,
    const char *            portGroup,
    const objectIdentifier& cassetteID,
    const char *            lotType,
    const char *            subLotType,
    const objectIdentifier& creatingLotID,
    const objectIdentifier& vendorLotID,
    const objectIdentifier& vendorID,
    const objectIdentifier& productID,
    const objectIdentifier& bankID,
    const char *            claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long txLotInfoInq__160(
    pptLotInfoInqResult__160& strLotInfoInqResult,
    const pptObjCommonIn& strObjCommonIn,
    const objectIdentifierSequence& lotID,
    const CORBA::Boolean lotBasicInfoFlag,
    const CORBA::Boolean lotControlUseInfoFlag,
    const CORBA::Boolean lotFlowBatchInfoFlag,
    const CORBA::Boolean lotNoteFlagInfoFlag,
    const CORBA::Boolean lotOperationInfoFlag,
    const CORBA::Boolean lotOrderInfoFlag,
    const CORBA::Boolean lotControlJobInfoFlag,
    const CORBA::Boolean lotProductInfoFlag,
    const CORBA::Boolean lotRecipeInfoFlag,
    const CORBA::Boolean lotLocationInfoFlag,
    const CORBA::Boolean lotWipOperationInfoFlag,
    const CORBA::Boolean lotWaferAttributesFlag,
    const CORBA::Boolean lotListInCassetteInfoFlag,
    const CORBA::Boolean waferMapInCassetteInfoFlag,
    const CORBA::Boolean lotBackupInfoFlag
    CORBAENV_LAST_HPP);

virtual CORBA::Long txCassetteListInq__170(
    pptCassetteListInqResult__170&   strCassetteListInqResult,
    const pptObjCommonIn&            strObjCommonIn,
    const char *                     cassetteCategory,
    CORBA::Boolean                   emptyFlag,
    const objectIdentifier&          stockerID,
    const objectIdentifier&          cassetteID,
    const char *                     cassetteStatus,
    const objectIdentifier&          durableSubStatus,
    const char *                     flowStatus,
    CORBA::Long                      maxRetrieveCount,
    CORBA::Boolean                   sorterJobCreationCheckFlag,
    const char*                      interFabXferState,
    const objectIdentifier&          bankID
    CORBAENV_LAST_HPP);

virtual CORBA::Long txCassetteStatusInq__170(
    pptCassetteStatusInqResult__170&  strCassetteStatusInqResult,
    const pptObjCommonIn&             strObjCommonIn,
    const objectIdentifier& cassetteID,
    CORBA::Boolean durableOperationInfoFlag,
    CORBA::Boolean durableWipOperationInfoFlag
    CORBAENV_LAST_HPP);

virtual CORBA::Long txForceOpeCompReq(
    pptForceOpeCompReqResult&  strForceOpeCompReqResult,
    const pptObjCommonIn&      strObjCommonIn,
    const objectIdentifier&    equipmentID,
    const objectIdentifier&    controlJobID,
    CORBA::Boolean             spcResultRequiredFlag,
    const char*                claimMemo,
    objectIdentifierSequence&  holdReleasedLotIDs,
    char *&                    APCIFControlStatus
    CORBAENV_LAST_CPP);

virtual CORBA::Long txForceOpeCompForInternalBufferReq(
  pptForceOpeCompForInternalBufferReqResult& strForceOpeCompForInternalBufferReqResult,
  const pptObjCommonIn&       strObjCommonIn,
  const objectIdentifier&     equipmentID,
  const objectIdentifier&     controlJobID,
  CORBA::Boolean              spcResultRequiredFlag,
  const char*                 claimMemo,
  objectIdentifierSequence&   holdReleasedLotIDs,
  char *&                     APCIFControlStatus
  CORBAENV_LAST_CPP);

virtual CORBA::Long cs_txCarrierUsageTypeChangeReq(
  csCarrierUsageTypeChangeReqResult&        strCarrierUsageTypeChangeReqResult,
  const pptObjCommonIn&                     strObjCommonIn,
  const csCarrierUsageTypeChangeReqInParm&  strCarrierUsageTypeChangeReqInParm,
  const char *                              claimMemo
  CORBAENV_LAST_CPP);

virtual CORBA::Long txSLMStartLotsReservationReq(
    pptSLMStartLotsReservationReqResult&        strSLMStartLotsReservationReqResult,
    const pptObjCommonIn&                       strObjCommonIn,
    const pptSLMStartLotsReservationReqInParm&  strSLMStartLotsReservationReqInParm,
    const char *                                claimMemo,
    char *&                                     APCIFControlStatus
    CORBAENV_LAST_HPP );
//INN-R170002 Add End

virtual CORBA::Long cs_txTestFunction (
    csTestFunctionResult& strTestFunctionResult,
    const pptObjCommonIn& strObjCommonIn,
    const char * functionName,
    const objectIdentifier& lotID,
    const objectIdentifier& equipmentID,
    const objectIdentifier& routeID,
    const char *            operationNumber,
    const char *claimMemo  //D6000025
    CORBAENV_LAST_HPP );   //D6000025
//D6000025    const char *claimMemo,
//D6000025    CORBA::Environment &IT_env=CORBA::default_environment );

//D6000025virtual CORBA::Long txSubRouteBranchReq (pptSubRouteBranchReqResult& strSubRouteBranchReqResult, const pptObjCommonIn& strObjCommonIn, const objectIdentifier& lotID, const objectIdentifier& currentRouteID, const char* currentOperationNumber, const objectIdentifier& subRouteID, const char * returnOperationNumber, const char * claimMemo, CORBA::Environment &IT_env = CORBA::default_environment) ;
virtual CORBA::Long txSubRouteBranchReq (pptSubRouteBranchReqResult& strSubRouteBranchReqResult, const pptObjCommonIn& strObjCommonIn, const objectIdentifier& lotID, const objectIdentifier& currentRouteID, const char* currentOperationNumber, const objectIdentifier& subRouteID, const char * returnOperationNumber, const char * claimMemo CORBAENV_LAST_HPP) ;  //D6000025

//INN-R170003 Add Start
virtual CORBA::Long cs_txCassetteInspectionTimeResetReq
(
    csCassetteInspectionTimeResetReqResult&   strCassetteInspectionTimeResetReqResult,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             cassetteID,
    const char *                        claimMemo
    CORBAENV_LAST_HPP
);
virtual CORBA::Long cs_txCassettePMTimeResetReq
(
    csCassettePMTimeResetReqResult&   	strCassettePMTimeResetReqResult,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             cassetteID,
    const char *                        claimMemo
    CORBAENV_LAST_HPP
);
virtual CORBA::Long cs_txReticleWaferCountResetReq
(
    csReticleWaferCountResetReqResult&   	strReticleWaferCountResetReqResult,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             reticleID,
    const char *                        claimMemo
    CORBAENV_LAST_HPP
);
virtual CORBA::Long cs_txReticleUsedDurationResetReq
(
    csReticleUsedDurationResetReqResult&   	strReticleUsedDurationResetReqResult,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             reticleID,
    const char *                        claimMemo
    CORBAENV_LAST_HPP
);

virtual CORBA::Long txOpeStartCancelReq__120 (
    pptOpeStartCancelReqResult&     strOpeStartCancelReqResult,
    const pptObjCommonIn&           strObjCommonIn,
    const objectIdentifier&         equipmentID,
    const objectIdentifier&         controlJobID,
    const char *                    claimMemo,
    pptAPCBaseCassetteSequence&     strAPCBaseCassetteListForOpeStartCancel,
    char *&                         APCIFControlStatus,
    char *&                         DCSIFControlStatus
    CORBAENV_LAST_HPP );

virtual CORBA::Long txOpeStartCancelForInternalBufferReq__120 (
    pptOpeStartCancelForInternalBufferReqResult&  strOpeStartCancelForInternalBufferReqResult,
    const pptObjCommonIn&                         strObjCommonIn,
    const objectIdentifier&                       equipmentID,
    const objectIdentifier&                       controlJobID,
    const char *                                  claimMemo,
    pptAPCBaseCassetteSequence&                   strAPCBaseCassetteListForOpeStartCancel,
    char *&                                       APCIFControlStatus,
    char *&                                       DCSIFControlStatus
    CORBAENV_LAST_HPP );

virtual CORBA::Long txStartDurablesReservationReq(
    pptStartDurablesReservationReqResult&              strStartDurablesReservationReqResult,
    const pptObjCommonIn&                              strObjCommonIn,
    const pptStartDurablesReservationReqInParam&       strStartDurablesReservationReqInParam,
    const char *                                       claimMemo
    CORBAENV_LAST_HPP );

virtual CORBA::Long txReticleJustInOutRpt(
    pptReticleJustInOutRptResult&    strReticleJustInOutRptResult,
    const pptObjCommonIn&            strObjCommonIn,
    const pptUser&                   requestUserID,
    const char *                     moveDirection,
    const objectIdentifier&          reticlePodID,
    const pptMoveReticlesSequence&   strMoveReticles,
    const char *                     claimMemo
    CORBAENV_LAST_HPP );

virtual CORBA::Long  txDurableBankInByPostProcReq(
    pptDurableBankInByPostProcReqResult&               strDurableBankInByPostProcReqResult,
    const pptObjCommonIn&                              strObjCommonIn,
    const pptDurableBankInByPostProcReqInParam&        strDurableBankInByPostProcReqInParam,
    const char *                                       claimMemo
    CORBAENV_LAST_HPP );
virtual CORBA::Long txMergeWaferLotReq (
    pptMergeWaferLotReqResult&          strMergeWaferLotReqResult,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             parentLotID,
    const objectIdentifier&             childLotID,
    const char *                        claimMemo
    CORBAENV_LAST_HPP);
virtual CORBA::Long txMergeWaferLotNotOnRouteReq (
    pptMergeWaferLotNotOnRouteReqResult&    strMergeWaferLotNotOnRouteReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const pptUser&                          requestUserID,
    const objectIdentifier&                 parentLotID,
    const objectIdentifier&                 childLotID,
    const char *                            claimMemo
    CORBAENV_LAST_HPP);
//INN-R170003 Add End

//INN-R170084 Add start
virtual CORBA::Long cs_txVendorLotReserveReq
(
    csVendorLotReserveReqResult&            strVendorLotReserveReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&                 bankID,
    const char *                            lotType,
    const char *                            subLotType,
    const char *                            sourceProduct,
    const char *                            partNo,
    const pptNewLotAttributes&              strNewLotAttributes
    CORBAENV_LAST_HPP
);

virtual CORBA::Long cs_txVendorLotReserveCancelReq
(
    csVendorLotReserveCancelReqResult&      strVendorLotReserveCancelReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&                 cassetteID
    CORBAENV_LAST_HPP
);

virtual CORBA::Long cs_txVendorLotReserveListInq
(
    csVendorLotReserveListInqResult&        strVendorLotReserveListInqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&                 cassetteID
    CORBAENV_LAST_HPP
);
//INN-R170084 Add end
//INN-R170006 Add start
virtual CORBA::Long cs_txFixtureTouchCountRpt(
    csFixtureTouchCountRptResult&         strFixtureTouchCountRptResult,
    const pptObjCommonIn&                 strObjCommonIn,
    const csFixtureTouchCountRptInParm&   strFixtureTouchCountRptInParm
    CORBAENV_LAST_HPP
);
virtual CORBA::Long txFixtureUsageCountResetReq (
    pptFixtureUsageCountResetReqResult&   strFixtureUsageCountResetReqResult,
    const pptObjCommonIn&                 strObjCommonIn,
    const objectIdentifier&               fixtureID,
    const char *                          claimMemo
    CORBAENV_LAST_HPP
);
//INN-R170006 Add end

//INN-R170008 Add Start
virtual CORBA::Long cs_txUserCertifiedSkillDeleteReq(
    csUserCertifiedSkillDeleteReqResult&          strUserCertifiedSkillDeleteReqResult,
    const pptObjCommonIn&                         strObjCommonIn,
    const csUserCertifiedSkillDeleteReqInParm&    strUserCertifiedSkillDeleteReqInParm
    CORBAENV_LAST_HPP);

virtual CORBA::Long cs_txUserCertifiedSkillUpdateReq(
    csUserCertifiedSkillUpdateReqResult&          strUserCertifiedSkillUpdateReqResult,
    const pptObjCommonIn&                         strObjCommonIn,
    const csUserCertifiedSkillUpdateReqInParm&    strUserCertifiedSkillUpdateReqInParm
    CORBAENV_LAST_HPP);

virtual CORBA::Long cs_txUserCertifyCheckInq(
    csUserCertifyCheckInqResult&                  strUserCertifyCheckInqResult,
    const pptObjCommonIn&                         strObjCommonIn,
    const csUserCertifyCheckInqInParm&            strUserCertifyCheckInqInParm
    CORBAENV_LAST_HPP);

virtual CORBA::Long cs_txUserCertifiedEqpTypeSkillInq(
    csUserCertifiedEqpTypeSkillInqResult&         strUserCertifiedEqpTypeSkillInqResult,
    const pptObjCommonIn&                         strObjCommonIn,
    const csUserCertifiedEqpTypeSkillInqInParm&   strUserCertifiedEqpTypeSkillInqInParm
    CORBAENV_LAST_HPP);

virtual CORBA::Long txPrivilegeCheckReq(
    pptPrivilegeCheckReqResult&                   strPrivilegeCheckReqResult,
    pptObjCommonIn&                               strObjCommonIn,
    const objectIdentifier&                       equipmentID,
    const objectIdentifier&                       stockerID,
    const objectIdentifierSequence&               productIDs,
    const objectIdentifierSequence&               routeIDs,
    const objectIdentifierSequence&               lotIDs,
    const objectIdentifierSequence&               machineRecipeIDs
    CORBAENV_LAST_HPP);
//INN-R170008 Add End

//INN-R170003 Add start
virtual CORBA::Long txUnloadingLotRpt(
    pptUnloadingLotRptResult&         strUnloadingLotRptResult,
    const pptObjCommonIn&             strObjCommonIn,
    const objectIdentifier&           equipmentID,
    const objectIdentifier&           cassetteID,
    const objectIdentifier&           portID,
    const char *                      claimMemo
    CORBAENV_LAST_HPP
);
virtual CORBA::Long txUnloadingLotForInternalBufferRpt (
    pptUnloadingLotForInternalBufferRptResult& strUnloadingLotForInternalBufferRptResult,
    const pptObjCommonIn&                      strObjCommonIn,
    const objectIdentifier&                    equipmentID,
    const objectIdentifier&                    cassetteID,
    const objectIdentifier&                    portID,
    const char *                               claimMemo
    CORBAENV_LAST_HPP
);
virtual CORBA::Long txEqpPortStatusChangeRpt (
    pptEqpPortStatusChangeRptResult&    strEqpPortStatusChangeRptResult,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             equipmentID,
    const pptEqpPortEventOnTCSSequence& strEqpPortEventOnTCSconst,
    const char *                        claimMemo
    CORBAENV_LAST_HPP
);
//INN-R170003 Add end

//INN-R-17003 Add start
virtual CORBA::Long txWaferSorterOnEqpRpt (pptWaferSorterOnEqpRptResult& strWaferSorterOnEqpRptResult,
                                                 const pptObjCommonIn& strObjCommonIn,
                                                 const objectIdentifier& equipmentID,
                                                 const char * actionCode,
                                                 const pptWaferSorterSlotMapSequence& strWaferSorterSlotMapSequence,
                                                 CORBA::Long rcTCS CORBAENV_LAST_CPP);
//INN-R-17003 Add end
//INN-R-17003 Add start
virtual CORBA::Long txArrivalCarrierCancelReq__090 (
    pptArrivalCarrierCancelReqResult__090& strArrivalCarrierCancelReqResult,
    const pptObjCommonIn&                  strObjCommonIn,
    const objectIdentifier&                equipmentID,
    const char *                           portGroupID,
    const pptNPWXferCassetteSequence&      strNPWXferCassette,
    CORBA::Boolean                         notifyToTCSFlag,
    const char *                           claimMemo
    CORBAENV_LAST_HPP
);
virtual CORBA::Long txArrivalCarrierCancelForInternalBufferReq__090 (
    pptArrivalCarrierCancelForInternalBufferReqResult__090& strArrivalCarrierCancelForInternalBufferReqResult,
    const pptObjCommonIn&                                   strObjCommonIn,
    const objectIdentifier&                                 equipmentID,
    const char *                                            portGroupID,
    const pptNPWXferCassetteSequence&                       strNPWXferCassette,
    CORBA::Boolean                                          notifyToTCSFlag,
    const char *                                            claimMemo
    CORBAENV_LAST_HPP
);

virtual CORBA::Long txCassetteUsageCountResetReq (
    pptCassetteUsageCountResetReqResult&    strCassetteUsageCountResetReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&                 cassetteID,
    const char*                             claimMemo
    CORBAENV_LAST_HPP
);

//INN-R-17003 Add end
//INN-R-17003 Add start
virtual CORBA::Long txLotCassetteXferJobDeleteReq(pptLotCassetteXferJobDeleteReqResult&  strLotCassetteXferJobDeleteReqResult,
	const pptObjCommonIn&                  strObjCommonIn,
	const char *                           jobID,
	const pptDelCarrierJobSequence&        strDelCarrierJob,
	const char *                           claimMemo
	CORBAENV_LAST_HPP);
//INN-R-17003 Add end
//INN-R-17009 Add start
virtual CORBA::Long txLotsInfoForStartReservationInq (
    pptLotsInfoForStartReservationInqResult&    strLotsInfoForStartReservationInqResult,
    const pptObjCommonIn&                       strObjCommonIn,
    const objectIdentifier&                     equipmentID,
    const pptStartCassetteSequence&             strStartCassette
    CORBAENV_LAST_HPP
);
virtual CORBA::Long txLotsInfoForStartReservationForInternalBufferInq (
    pptLotsInfoForStartReservationForInternalBufferInqResult&   strLotsInfoForStartReservationForInternalBufferInqResult,
    const pptObjCommonIn&                                       strObjCommonIn,
    const objectIdentifier&                                     equipmentID,
    const pptStartCassetteSequence&                             strStartCassette
    CORBAENV_LAST_HPP
);
virtual CORBA::Long txLotsInfoForOpeStartInq (
    pptLotsInfoForOpeStartInqResult&    strLotsInfoForOpeStartInqResult,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             equipmentID,
    const objectIdentifierSequence&     cassetteID
    CORBAENV_LAST_HPP
);
virtual CORBA::Long txLotsInfoForOpeStartForInternalBufferInq (
    pptLotsInfoForOpeStartForInternalBufferInqResult&  strLotsInfoForOpeStartForInternalBufferInqResult,
    const pptObjCommonIn&                              strObjCommonIn,
    const objectIdentifier&                            equipmentID,
    const objectIdentifierSequence&                    cassetteID
    CORBAENV_LAST_HPP
);
//INN-R-17009 Add end
//INN-R-17003 Add start
virtual CORBA::Long txLotMfgOrderChangeReq(
    pptLotMfgOrderChangeReqResult& strLotMfgOrderChangeReqResult,
    const pptObjCommonIn& strObjCommonIn,
    CORBA::Long seqIx,
    const pptChangedLotAttributesSequence& strChangedLotAttributes,
    const char * claimMemo
    CORBAENV_LAST_HPP
);
//INN-R-17003 Add end
//INN-R-170003 Add start yangxigang
virtual CORBA::Long txInterFabCarrierXferReq(
    pptInterFabCarrierXferReqResult&        strInterFabCarrierXferReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const pptInterFabCarrierXferReqInParm&  strInterFabCarrierXferReqInParm,
    const char*                             claimMemo
    CORBAENV_LAST_HPP
);

virtual CORBA::Long txScrapWaferCancelReq (
    pptScrapWaferCancelReqResult&           strScrapWaferCancelReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&                 lotID,
    const objectIdentifier&                 inCassetteID,
    const pptScrapCancelWafersSequence&     strScrapCancelWafers,
    const char * claimMemo
    CORBAENV_LAST_HPP
);

virtual CORBA::Long txScrapWaferReq (
    pptScrapWaferReqResult&                 strScrapWaferReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&                 lotID,
    const objectIdentifier&                 inCassetteID,
    const objectIdentifier&                 reasonRouteID,
    const objectIdentifier&                 reasonOperationID,
    const char *                            reasonOperationNumber,
    const char *                            reasonOperationPass,
    const char *                            objrefPO,
    const pptScrapWafersSequence&           strScrapWafers,
    const char * claimMemo
    CORBAENV_LAST_HPP
);

virtual CORBA::Long txSTBCancelReq(
    pptSTBCancelReqResult&                 strSTBCancelReqResult,
    const pptObjCommonIn&                  strObjCommonIn,
    const pptSTBCancelReqInParm&           strSTBCancelReqInParm,
    const char*                            claimMemo
    CORBAENV_LAST_HPP
);

virtual CORBA::Long txStockerInventoryReq (
    pptStockerInventoryReqResult&          strStockerInventoryReqResult,
    const pptObjCommonIn&                  strObjCommonIn,
    const objectIdentifier&                machineID,
    const char *                           claimMemo
    CORBAENV_LAST_HPP
);

virtual CORBA::Long txStockerInventoryRpt (
    pptStockerInventoryRptResult& strStockerInventoryRptResult,
    const pptObjCommonIn& strObjCommonIn,
    const objectIdentifier& stockerID,
    const pptInventoryLotInfoSequence& strInventoryLotInfo,
    const char * claimMemo
    CORBAENV_LAST_HPP
);

//INN-R-170003 Add end yangxigang
//INN-R170009 add start
virtual CORBA::Long cs_txLotComplicatedHoldReq (
    csLotComplicatedHoldReqResult&          strLotComplicatedHoldReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const csLotComplicatedHoldReqInParam&   strLotComplicatedHoldReqInParam
    CORBAENV_LAST_HPP
);
//INN-R170009 add end
//INN-R-17003 Add start congxiaolin
virtual CORBA::Long txPostProcessExecReq__100 (
                    pptPostProcessExecReqResult__100&    strPostProcessExecReqResult,
                    const pptObjCommonIn&                strObjCommonIn,
                    const char*                          key,
                    CORBA::Long                          syncFlag,
                    CORBA::Long                          prevSeqNo,
                    const char*                          keyTimeStamp,
                    const char*                          claimMemo
                    CORBAENV_LAST_HPP );
virtual CORBA::Long txPostProcessExecWithSeqNoReq(
        pptPostProcessExecWithSeqNoReqResult&           strPostProcessExecWithSeqNoReqResult,
        const pptObjCommonIn&                           strObjCommonIn,
        const pptPostProcessExecWithSeqNoReqInParm&     strPostProcessExecWithSeqNoReqInParm,
        const char*                                     claimMemo
        CORBAENV_LAST_HPP );
virtual CORBA::Long txReworkPartialWaferLotCancelReq (
    pptReworkPartialWaferLotCancelReqResult&    strReworkPartialWaferLotCancelReqResult,
    const pptObjCommonIn&                       strObjCommonIn,
    const objectIdentifier&                     parentLotID,
    const objectIdentifier&                     childLotID,
    const objectIdentifier&                     reasonCodeID,
    const char *                                claimMemo
    CORBAENV_LAST_HPP);
virtual CORBA::Long txSplitWaferLotNotOnRouteReq(
    pptSplitWaferLotNotOnRouteReqResult&    strSplitWaferLotNotOnRouteReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const pptUser&                          requestUserID,
    const objectIdentifier&                 parentLotID,
    CORBA::Long                             parentLotWaferCount,
    CORBA::Long                             childLotWaferCount,
    const objectIdentifierSequence&         childWaferID,
    const char *                            claimMemo
    CORBAENV_LAST_HPP);
virtual CORBA::Long txSplitWaferLotWithoutHoldReleaseReq(
    pptSplitWaferLotWithoutHoldReleaseReqResult&  strSplitWaferLotWithoutHoldReleaseReqResult,
    const pptObjCommonIn&                         strObjCommonIn,
    const objectIdentifier&                       parentLotID,
    const objectIdentifierSequence&               childWaferIDs,
    CORBA::Boolean                                futureMergeFlag,
    const objectIdentifier&                       mergedRouteID,
    const char*                                   mergedOperationNumber,
    CORBA::Boolean                                branchingRouteSpecifyFlag,
    const objectIdentifier&                       subRouteID,
    const char*                                   returnOperationNumber,
    const char*                                   claimMemo,
    const pptHoldListSequence&                    strLotHoldRequests
	CORBAENV_LAST_HPP );
virtual CORBA::Long txStartDurablesReservationCancelReq(
    pptStartDurablesReservationCancelReqResult&          strStartDurablesReservationCancelReqResult,
    const pptObjCommonIn&                                strObjCommonIn,
    const pptStartDurablesReservationCancelReqInParam&   strStartDurablesReservationCancelReqInParam,
    const char *                                         claimMemo
    CORBAENV_LAST_HPP );
virtual CORBA::Long  txStartLotsReservationCancelReq (
    pptStartLotsReservationCancelReqResult& strStartLotsReservationCancelReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&                 equipmentID,
    const objectIdentifier&                 controlJobID,
    const char *                            claimMemo,
    char *&                                 APCIFControlStatus
    CORBAENV_LAST_HPP);
//INN-R-17003 Add end congxiaolin

//INN-R170009 Add Begin
virtual CORBA::Long txCollectedDataActionByPostProcReq (
    pptCollectedDataActionByPostProcReqResult&          strCollectedDataActionByPostProcReqResult,
    const pptObjCommonIn&                               strObjCommonIn,
    const pptCollectedDataActionByPostProcReqInParm&    strCollectedDataActionByPostProcReqInParm,
    const char*                                         claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long txCollectedDataActionReq ( 
    pptCollectedDataActionReqResult&       strCollectedDataActionReqResult,
    const pptObjCommonIn&                  strObjCommonIn,
    const pptCollectedDataActionReqInParm& strCollectedDataActionReqInParm,
    const char*                            claimMemo
    CORBAENV_LAST_HPP);
//INN-R170009 Add End

//INN-R170016 Add Start
virtual CORBA::Long cs_txEqpMonitorInventoryListInq(
    csEqpMonitorInventoryListInqResult&    strEqpMonitorInventoryListInqResult,
    const pptObjCommonIn&                  strObjCommonIn,
    csEqpMonitorInventoryListInqInParm     strEqpMonitorInventoryListInqInParm
    CORBAENV_LAST_HPP);
    
virtual CORBA::Long cs_txDowngradeItemListInq(
    csDowngradeItemListInqResult&            strDowngradeItemListInqResult,
    const pptObjCommonIn&                    strObjCommonIn
    CORBAENV_LAST_HPP);

virtual CORBA::Long cs_txDowngradeSettingListInq(
    csDowngradeSettingListInqResult&            strDowngradeSettingListInqResult,
    const pptObjCommonIn&                       strObjCommonIn,
    const csDowngradeSettingListInqInParm&      strDowngradeSettingListInqInParm
    CORBAENV_LAST_HPP);

virtual CORBA::Long cs_txEqpMonitorInventoryUpdateReq(
    csEqpMonitorInventoryUpdateReqResult&            strEqpMonitorInventoryUpdateReqResult,
    const pptObjCommonIn&                            strObjCommonIn,
    const csEqpMonitorInventoryUpdateReqInParm&      strEqpMonitorInventoryUpdateReqInParm,
    const char*                                      claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long cs_txBWSWaferOutAndSTBReq(
    csBWSWaferOutAndSTBReqResult&            strBWSWaferOutAndSTBReqResult,
    const pptObjCommonIn&                    strObjCommonIn,
    const csBWSWaferOutAndSTBReqInParm&      strBWSWaferOutAndSTBReqInParm,
    const char*                              claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long cs_txEqpMonitorLotSTBReq(
    csEqpMonitorLotSTBReqResult&            strEqpMonitorLotSTBReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const csEqpMonitorLotSTBReqInParm&      strEqpMonitorLotSTBReqInParm,
    const char*                             claimMemo
    CORBAENV_LAST_HPP);    

virtual CORBA::Long cs_txEqpMonitorLotAllBranchReq(
    csEqpMonitorLotAllBranchReqResult&              strEqpMonitorLotAllBranchReqResult,
    const pptObjCommonIn&                           strObjCommonIn,
    const csEqpMonitorLotAllBranchReqInParm&        strEqpMonitorLotAllBranchReqInParm,
    const char*                                     claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long cs_txEqpMonitorLotPrepareIDResetReq(
    csEqpMonitorLotPrepareIDResetReqResult&         strEqpMonitorLotPrepareIDResetReqResult,
    const pptObjCommonIn&                           strObjCommonIn,
    const csEqpMonitorLotPrepareIDResetReqInParm&   strEqpMonitorLotPrepareIDResetReqInParm,
    const char*                                     claimMemo
    CORBAENV_LAST_HPP);

virtual CORBA::Long cs_txDowngradeItemUpdateReq(
    csDowngradeItemUpdateReqResult&                 strDowngradeItemUpdateReqResult,
    const pptObjCommonIn&                           strObjCommonIn,
    const csDowngradeItemUpdateReqInParm&           strDowngradeItemUpdateReqInParm,
    const char*                                     claimMemo
    CORBAENV_LAST_HPP);
    
virtual CORBA::Long cs_txDowngradeSettingUpdateReq(
    csDowngradeSettingUpdateReqResult&              strDowngradeSettingUpdateReqResult,
    const pptObjCommonIn&                           strObjCommonIn,
    const csDowngradeSettingUpdateReqInParm&        strDowngradeSettingUpdateReqInParm,
    const char*                                     claimMemo
    CORBAENV_LAST_HPP);
//INN-R170016 Add End
//INN-R170027 Add start
virtual CORBA::Long cs_txNPWProductChangeReq(
    csNPWProductChangeReqResult&                    strNPWProductChangeReqResult,
    const pptObjCommonIn&                           strObjCommonIn,
    const csNPWProductChangeReqInParm&              strNPWProductChangeReqInParm,
    const char*                                     claimMemo
    CORBAENV_LAST_HPP);
//INN-R170027 Add end

#endif
