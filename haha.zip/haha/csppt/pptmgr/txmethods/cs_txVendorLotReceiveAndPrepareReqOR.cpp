#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txVendorLotReceiveAndPrepareReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:40:16 [ 7/13/07 21:40:17 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txVendorLotReceiveAndPrepareReqOR.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: txVendorLotReceiveAndPrepareReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2001/07/26 D4000056 H.Adachi       The first coding (WaferSorter R40 CORE)
// 2001-08-21 P4000099 H.Adachi       Change objectName(waferSorter_SlotMap_SelectDR to waferSorter_slotMap_SelectDR)
// 2001/08/21 0.0.5    M.Shimizu      Add Cassette is FOSB CASE
// 2001/08/23 D4000056 M.Shimizu      Add Param's destinationCassetteManagedBySiViewFlag
//                                                originalCassetteManagedBySiViewFlag
// 2001-08-28 0.0.6    H.Adachi       Mod by BUG fix on TEST 
// 2001-09-03 0.0.7    M.Shimizu      Add Logic To Casstette CheckLogic
// 2001-09-18 P4000188 M.Shimizu      Add Logic Checking Previous Job is running or not Wafer Sorter
// 2001-10-02 P4000303 M.Shimizu      Bug Fix No message on pop up screen
// 2001-10-09 P4000335 H.Adachi       System Error on Vendor Lot Receive and Prepare Operation
//                                    Add Check logic for LotType is Vendor or
// 2001-11-08 P4100005 M.Shimizu      Bug Fix It deals with it with VendorLotReceiveAndPrepare except for specified Cassette as well.
// 2002-01-17 P4100074 H.Adachi       Add WaferID Null Check and Wafer Assigne Flag Check Logic Call
// 2002-01-17 P4100075 H.Adachi       Add Maintain Loaded Cassette on Eqp Information Object Call
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2006/12/14 D7000239 H.Mutoh        Add equipment availability check.
// 2007/06/12 D9000005 H.Hotta        WaferSorter automation support.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/11/11 PSIV00000280 M.Ishino       Add check logic whether the same ID is in Wafer ID Read result or not.
// 2012/12/04 DSN000049350 K.Yamaoku      Equipment parallel processing support (P2)
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/14 INN-R170002  JQ.Shao        Contamination Control
//
// Description:
//    This transaction provides SlotMap regstration function to MM.
//    If waferID that is stored slotmap reported from WaferSorter
//    is not in MM , waferID can be created.
// 
//    1. Carrier that have SLOTMAP is known by MM
//          -- In this case, Wafers on SLOTMap and lotID will be
//             created . But Wafer/Lot is not located on Carrier
//    2. Carrier that have SLOTMAP is not known by MM
//          -- In this case, Wafers on SLOTMap and lotID will be
//             created . But Wafer/Lot is located on Carrier
//
// Return: pptVendorLotReceiveAndPrepareReqResult
//
//         typedef struct pptVendorLotReceiveAndPrepareReqResult_struct {
//            pptRetCode               strResult;
//            objectIdentifier         lotID;
//            any                      siInfo;
//         } pptVendorLotReceiveAndPrepareReqResult;
//
// Parameter:
//         in pptUser                    requestUserID,
//         in objectIdentifier           equipmentID,
//         in string                     portGroup,
//         in objectIdentifier           cassetteID;
//         in string                     lotType,
//         in string                     subLotType,
//         in objectIdentifier           creatingLotID,
//         in objectIdentifier           vendorLotID,
//         in objectIdentifier           vendorID,
//         in objectIdentifier           productID,
//         in objectIdentifier           bankID,
//         in string                     claimMemo);
//
// Require:
//      none (Condition)
//
// Ensure:
//      none (after)
//
// Exception:
//      none
//
// Pseudo code:
//      TXBKC013
CORBA::Long CS_PPTManager_i::txVendorLotReceiveAndPrepareReq ( pptVendorLotReceiveAndPrepareReqResult& strVendorLotReceiveAndPrepareReqResult,
                                                            const pptObjCommonIn&   strObjCommonIn,
                                                            const objectIdentifier& equipmentID,
                                                            const char *            portGroup,
                                                            const objectIdentifier& cassetteID,
                                                            const char *            lotType,
                                                            const char *            subLotType,
                                                            const objectIdentifier& creatingLotID,
                                                            const objectIdentifier& vendorLotID,
                                                            const objectIdentifier& vendorID,
                                                            const objectIdentifier& productID,
                                                            const objectIdentifier& bankID,
//D6000025                                                             const char *            claimMemo,
//D6000025                                                             CORBA::Environment &IT_env)
                                                            const char *            claimMemo //D6000025
                                                            CORBAENV_LAST_CPP)                //D6000025
{

    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::txVendorLotReceiveAndPrepareReq ")

    PPT_METHODTRACE_V2("", "In Param's equipmentID =   ",equipmentID.identifier);
    PPT_METHODTRACE_V2("", "In Param's portGroup =     ",portGroup );
    PPT_METHODTRACE_V2("", "In Param's cassetteID =    ",cassetteID.identifier);
    PPT_METHODTRACE_V2("", "In Param's lotType =       ",lotType);
    PPT_METHODTRACE_V2("", "In Param's subLotType =    ",subLotType);
    PPT_METHODTRACE_V2("", "In Param's creatingLotID = ",creatingLotID.identifier);
    PPT_METHODTRACE_V2("", "In Param's vendorLotID =   ",vendorLotID.identifier);
    PPT_METHODTRACE_V2("", "In Param's vendorID =      ",vendorID.identifier);
    PPT_METHODTRACE_V2("", "In Param's productID =     ",productID.identifier);
    PPT_METHODTRACE_V2("", "In Param's bankID =        ",bankID.identifier);
    PPT_METHODTRACE_V2("", "In Param's claimMemo =     ",claimMemo);

    CORBA::Long rc = RC_OK ;

    //----------------------------------------
    //  Check Equipment ID is SORTER or
    //----------------------------------------
    //P4000099 Start
    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","equipment_categoryVsTxID_CheckCombination() returned error.");

        strVendorLotReceiveAndPrepareReqResult.strResult
            = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return (rc);
    }
    //P4000099 End

//DSN000049350 Add Start
    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = equipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXBKC013" ); // TxVendorLotReceiveAndPrepareReq
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

    PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strVendorLotReceiveAndPrepareReqResult.strResult = strObject_lockMode_Get_out.strResult;
        return( rc );
    }

    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;

    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strVendorLotReceiveAndPrepareReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }

        // check if the cassetteID is a FOUP
        objCassette_getStatusDR_out strCassette_getStatusDR_out;

        PPT_METHODTRACE_V1( "", "calling cassette_getStatusDR()" );
        rc = cassette_getStatusDR( strCassette_getStatusDR_out,
                                   strObjCommonIn,
                                   cassetteID );

        if ( rc != RC_OK  && rc != RC_NOT_FOUND_CASSETTE )
        {
            PPT_METHODTRACE_V2( "","cassette_getStatusDR() != RC_OK and != RC_NOT_FOUND_CASSETTE", rc);
            strVendorLotReceiveAndPrepareReqResult.strResult = strCassette_getStatusDR_out.strResult;
            return( rc );
        }
        else if (rc == RC_OK) // FOUP
        {
            PPT_METHODTRACE_V2( "","cassette_getStatusDR() = RC_OK", rc);

            // Lock Equipment LoadCassette Element (Write)
            stringSequence loadCastSeq;
            loadCastSeq.length(1);
            loadCastSeq[0] = cassetteID.identifier;
            strAdvanced_object_Lock_in.objectID   = equipmentID;
            strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
            strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
            strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
            strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

            PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_LoadCassette );
            rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                        strObjCommonIn,
                                        strAdvanced_object_Lock_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                strVendorLotReceiveAndPrepareReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                return( rc );
            }
        }
        else
        {
            // FOSB, do nothing
            PPT_METHODTRACE_V2( "","cassette_getStatusDR() = RC_NOT_FOUND_CASSETTE", rc);
        }
    }
//DSN000049350 Add End

//P4000188 Add Start
    pptUser dummyUser;
    //================================================================
    // Checking Previous Job is running or not
    //================================================================
    objWaferSorter_CheckRunningJobs_out strWaferSorter_CheckRunningJobs_out;
    rc = waferSorter_CheckRunningJobs(strWaferSorter_CheckRunningJobs_out,
                                       strObjCommonIn,
                                       dummyUser,
                                       equipmentID,
                                       portGroup);

    //------------------------------------------------------
    // If there are running Jobs, then return
    //------------------------------------------------------
    if ( rc == RC_WAFERSORT_ALREADY_RUNNING )
    {
        PPT_METHODTRACE_V1("","SorterJob is already running");
        strVendorLotReceiveAndPrepareReqResult.strResult = strWaferSorter_CheckRunningJobs_out.strResult ;
        return(rc);
    }
    else if ( rc != RC_WAFERSORT_PREVIOUSJOB_NOTFOUND )
    {
        PPT_METHODTRACE_V2("","Error Occured RC is ",rc)
        strVendorLotReceiveAndPrepareReqResult.strResult = strWaferSorter_CheckRunningJobs_out.strResult ;
        return(rc);
    }
//P4000188 Add End

//P4000335 Add Start
    //------------------------------------------------------
    // Checking LotType is Vendor or not
    //------------------------------------------------------
    if ( CIMFWStrCmp( lotType, SP_Lot_Type_VendorLot ) != 0 )
    {
        PPT_METHODTRACE_V2("","Invalid Lot Type:Lot Type should be Vendor", lotType );
        PPT_SET_MSG_RC_KEY2(strVendorLotReceiveAndPrepareReqResult,
                            MSG_INVALID_LOT_TYPE,
                            RC_INVALID_LOT_TYPE,
                            lotType, "*****") ;
        return ( RC_INVALID_LOT_TYPE ); 
    }
//P4000335 Add End

    //----------------------------------------
    //  Get SLOTMAP DATA When Requested
    //----------------------------------------
    pptWaferSorterSlotMap strWaferSorterGetSlotMapReferenceCondition;
    CORBA::String_var requiredData;
    requiredData = CIMFWStrDup(SP_Sorter_SlotMap_LatestData);
    
    strWaferSorterGetSlotMapReferenceCondition.portGroup                           = CIMFWStrDup(portGroup);
    strWaferSorterGetSlotMapReferenceCondition.equipmentID.identifier              = equipmentID.identifier;
    strWaferSorterGetSlotMapReferenceCondition.actionCode                          = CIMFWStrDup(SP_Sorter_Read);
    strWaferSorterGetSlotMapReferenceCondition.requestTime                         = CIMFWStrDup("");
    strWaferSorterGetSlotMapReferenceCondition.direction                           = CIMFWStrDup(SP_Sorter_Direction_TCS);
    strWaferSorterGetSlotMapReferenceCondition.waferID.identifier                  = CIMFWStrDup("");
    strWaferSorterGetSlotMapReferenceCondition.lotID.identifier                    = CIMFWStrDup("");
//P4100005    strWaferSorterGetSlotMapReferenceCondition.destinationCassetteID.identifier    = CIMFWStrDup("");
    strWaferSorterGetSlotMapReferenceCondition.destinationCassetteID.identifier    = cassetteID.identifier;    //P4100005
    strWaferSorterGetSlotMapReferenceCondition.destinationPortID.identifier        = CIMFWStrDup("");
    strWaferSorterGetSlotMapReferenceCondition.bDestinationCassetteManagedBySiView = FALSE;
    strWaferSorterGetSlotMapReferenceCondition.destinationSlotNumber               = 0;
    strWaferSorterGetSlotMapReferenceCondition.originalCassetteID.identifier       = CIMFWStrDup("");
    strWaferSorterGetSlotMapReferenceCondition.originalPortID.identifier           = CIMFWStrDup("");
    strWaferSorterGetSlotMapReferenceCondition.bOriginalCassetteManagedBySiView    = FALSE;
    strWaferSorterGetSlotMapReferenceCondition.originalSlotNumber                  = 0;
    strWaferSorterGetSlotMapReferenceCondition.requestUserID.identifier            = CIMFWStrDup("");
    strWaferSorterGetSlotMapReferenceCondition.replyTime                           = CIMFWStrDup("");
    //2001-08-25 strWaferSorterGetSlotMapReferenceCondition.sorterStatus                        = CIMFWStrDup(SP_Sorter_OK);
    strWaferSorterGetSlotMapReferenceCondition.sorterStatus                        = CIMFWStrDup(SP_Sorter_Succeeded);
    strWaferSorterGetSlotMapReferenceCondition.slotMapCompareStatus                = CIMFWStrDup("");
    strWaferSorterGetSlotMapReferenceCondition.mmCompareStatus                     = CIMFWStrDup("");
    
//P4000099     objWaferSorter_SlotMap_SelectDR_out strWaferSorter_SlotMap_SelectDR_out;
//P4000099     rc = waferSorter_SlotMap_SelectDR( strWaferSorter_SlotMap_SelectDR_out,
//P4000099                                        strObjCommonIn,
//P4000099                                        requiredData,
//P4000099                                        "",
//P4000099                                        strWaferSorterGetSlotMapReferenceCondition );
    objWaferSorter_slotMap_SelectDR_out strWaferSorter_slotMap_SelectDR_out;         //P4000099
    rc = waferSorter_slotMap_SelectDR( strWaferSorter_slotMap_SelectDR_out,
                                       strObjCommonIn,
                                       requiredData,
                                       "",
                                       SP_Sorter_Ignore_SiViewFlag,
                                       SP_Sorter_Ignore_SiViewFlag,
                                       strWaferSorterGetSlotMapReferenceCondition ); //P4000099

    if(rc != RC_OK)
    {
//P4000099         PPT_METHODTRACE_V2("CS_PPTManager_i::txVendorLotReceiveAndPrepareReq", 
//P4000099                            "strWaferSorter_SlotMap_SelectDR_out() != RC_OK",rc);
//P4000099         strVendorLotReceiveAndPrepareReqResult.strResult = strWaferSorter_SlotMap_SelectDR_out.strResult;
        PPT_METHODTRACE_V2("", "strWaferSorter_slotMap_SelectDR_out() != RC_OK",rc);     //P4000099
        strVendorLotReceiveAndPrepareReqResult.strResult = strWaferSorter_slotMap_SelectDR_out.strResult; //P4000099
        return ( rc );
    }
//PSIV00000280 add start
    //------------------------------------------------
    //  Check whether the same wafer ID is
    //  cyclically reported from wafer sorter or not
    //------------------------------------------------
    CORBA::String_var wafID;
    CORBA::Boolean bSameWaferIDReported = FALSE;
    CORBA::ULong iCnt1 = 0;
    CORBA::ULong iCnt2 = 0;
    CORBA::ULong nReadWaferLen = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence.length();

    for( iCnt1 = 0 ; iCnt1 < nReadWaferLen-1 ; iCnt1++ )
    {
        for( iCnt2 = iCnt1+1 ; iCnt2<nReadWaferLen ; iCnt2++ )
        {
            if( 0 == CIMFWStrCmp( strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[iCnt1].waferID.identifier,
                                  strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[iCnt2].waferID.identifier) )
            {
                bSameWaferIDReported = TRUE;
                wafID = CIMFWStrDup(strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[iCnt1].waferID.identifier);
                break;
            }
        }
        if( bSameWaferIDReported )
        {
            break;
        }
    }
    if( bSameWaferIDReported )
    {
        PPT_SET_MSG_RC_KEY( strVendorLotReceiveAndPrepareReqResult,
                            MSG_DUPLICATE_WAFER_ID_REPORTED,
                            RC_DUPLICATE_WAFER_ID_REPORTED,
                            wafID );
        return RC_DUPLICATE_WAFER_ID_REPORTED;
    }
//PSIV00000280 add end

    //---------------------------------------
    //    Set Slot Map Return Data
    //---------------------------------------
    CORBA::Long i = 0;
    pptWaferTransferSequence     strWaferXferSeq;
//P4000099    CORBA::Long nLen = strWaferSorter_SlotMap_SelectDR_out.strWaferSorterSlotMapSequence.length();
    CORBA::Long nLen = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence.length(); //P4000099
    strWaferXferSeq.length(nLen); 

    PPT_METHODTRACE_V2("", "strWaferSorterSlotMapSequence.length = ",nLen);

    for ( i = 0; i < nLen ; i++ )
    {
        PPT_METHODTRACE_V2("", "strWaferSorterSlotMapSequence Loop Count = ",i);

//P4000099        strWaferXferSeq[i].waferID.identifier                  = strWaferSorter_SlotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].waferID.identifier;
//P4000099        strWaferXferSeq[i].destinationCassetteID.identifier    = strWaferSorter_SlotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier;
//P4000099        strWaferXferSeq[i].bDestinationCassetteManagedBySiView = strWaferSorter_SlotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].bDestinationCassetteManagedBySiView;
//P4000099        strWaferXferSeq[i].destinationSlotNumber               = strWaferSorter_SlotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].destinationSlotNumber;
//P4000099        strWaferXferSeq[i].originalCassetteID.identifier       = strWaferSorter_SlotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].originalCassetteID.identifier;
//P4000099        strWaferXferSeq[i].bOriginalCassetteManagedBySiView    = strWaferSorter_SlotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].bOriginalCassetteManagedBySiView;
//P4000099        strWaferXferSeq[i].originalSlotNumber                  = strWaferSorter_SlotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].originalSlotNumber;

        strWaferXferSeq[i].waferID.identifier                  = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].waferID.identifier;                  //P4000099
        strWaferXferSeq[i].destinationCassetteID.identifier    = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier;    //P4000099
        strWaferXferSeq[i].bDestinationCassetteManagedBySiView = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].bDestinationCassetteManagedBySiView; //P4000099
        strWaferXferSeq[i].destinationSlotNumber               = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].destinationSlotNumber;               //P4000099
        strWaferXferSeq[i].originalCassetteID.identifier       = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].originalCassetteID.identifier;       //P4000099
        strWaferXferSeq[i].bOriginalCassetteManagedBySiView    = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].bOriginalCassetteManagedBySiView;    //P4000099
        strWaferXferSeq[i].originalSlotNumber                  = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence[i].originalSlotNumber;                  //P4000099

        PPT_METHODTRACE_V2("", "WaferID                             = ",strWaferXferSeq[i].waferID.identifier);
        PPT_METHODTRACE_V2("", "destinationCassetteID               = ",strWaferXferSeq[i].destinationCassetteID.identifier);
        PPT_METHODTRACE_V2("", "bDestinationCassetteManagedBySiView = ",strWaferXferSeq[i].bDestinationCassetteManagedBySiView);
        PPT_METHODTRACE_V2("", "destinationSlotNumber               = ",strWaferXferSeq[i].destinationSlotNumber);
        PPT_METHODTRACE_V2("", "bDestinationCassetteManagedBySiView = ",strWaferXferSeq[i].originalCassetteID.identifier);
        PPT_METHODTRACE_V2("", "bOriginalCassetteManagedBySiView    = ",strWaferXferSeq[i].bOriginalCassetteManagedBySiView);
        PPT_METHODTRACE_V2("", "originalSlotNumber                  = ",strWaferXferSeq[i].originalSlotNumber);
    }

    //----------------------------------------------------
    // Copy input parameter and use tmpNewLotAttributes
    // inside of this method
    //----------------------------------------------------
    pptNewLotAttributes tmpNewLotAttributes;

//P4000099    nLen = strWaferSorter_SlotMap_SelectDR_out.strWaferSorterSlotMapSequence.length();
    nLen = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence.length();  //P4000099
    tmpNewLotAttributes.strNewWaferAttributes.length(nLen);
    tmpNewLotAttributes.cassetteID = cassetteID;

    CORBA::Long unknownWaferCnt = 0;
    //P4100074 Add Start
    CORBA::Boolean bFindWaferNull = FALSE;
    CORBA::Boolean bFindWaferFill = FALSE;
    //P4100074 Add End

    for ( i = 0; i < nLen; i++ )
    {
        //P4100074 Add Start
        //-------------------------------------------------------------
        // All Wafer is NULL or Filled Check
        //-------------------------------------------------------------
        if (CIMFWStrLen(strWaferXferSeq[i].waferID.identifier) == 0)
        {
            bFindWaferNull = TRUE;
        }
        else
        {
            bFindWaferFill = TRUE;
        }
        if (( bFindWaferFill == TRUE )&&(bFindWaferNull == TRUE ))
        {
            PPT_METHODTRACE_V1("", "NULL and filled WaferID are Mixed in Cassette") ;
            SET_MSG_RC(strVendorLotReceiveAndPrepareReqResult,
                       MSG_INVALID_WAFER_ID_READ_RESULT_FOR_VLRP,
                       RC_INVALID_WAFER_ID_READ_RESULT_FOR_VLRP)
            return (RC_INVALID_WAFER_ID_READ_RESULT_FOR_VLRP);
        }
        //P4100074 Add End

        /*-----------------------------------------------------------*/
        /*   Get Lot ID from Wafer ID  (0.0.6)                       */
        /*-----------------------------------------------------------*/
        objWafer_lot_Get_out strWafer_lot_Get_out;
        rc = wafer_lot_Get( strWafer_lot_Get_out, strObjCommonIn, strWaferXferSeq[i].waferID );
        if ( rc != RC_OK )
        {
            tmpNewLotAttributes.strNewWaferAttributes[unknownWaferCnt].newLotID      = creatingLotID;
            tmpNewLotAttributes.strNewWaferAttributes[unknownWaferCnt].newWaferID    = strWaferXferSeq[i].waferID;
            tmpNewLotAttributes.strNewWaferAttributes[unknownWaferCnt].newSlotNumber = strWaferXferSeq[i].destinationSlotNumber;//0.0.6 Org->Dest
            tmpNewLotAttributes.strNewWaferAttributes[unknownWaferCnt].sourceLotID   = creatingLotID;

            PPT_METHODTRACE_V2("", "wafer_lot_Get() != RC_OK", rc ) ;
            PPT_METHODTRACE_V2("", "Unknown Wafer Count = ", unknownWaferCnt+1);
            PPT_METHODTRACE_V2("", "creatingLotID       = ", tmpNewLotAttributes.strNewWaferAttributes[unknownWaferCnt].newLotID.identifier);
            PPT_METHODTRACE_V2("", "newWaferID          = ", tmpNewLotAttributes.strNewWaferAttributes[unknownWaferCnt].newWaferID.identifier);
            PPT_METHODTRACE_V2("", "newSlotNumber       = ", tmpNewLotAttributes.strNewWaferAttributes[unknownWaferCnt].newSlotNumber);
            PPT_METHODTRACE_V2("", "sourceLotID         = ", tmpNewLotAttributes.strNewWaferAttributes[unknownWaferCnt].sourceLotID.identifier);

            unknownWaferCnt++;
        }
    }
    //----------------------------------------------------------
    // Check Unknown Wafer Exist
    //----------------------------------------------------------
    if ( unknownWaferCnt == 0 )
    {
        PPT_METHODTRACE_V1("", "NO Wafer for Prepare") ;
//PSIV00000280        SET_MSG_RC(strVendorLotReceiveAndPrepareReqResult,MSG_WAFER_NOT_PREPARED,RC_WAFER_NOT_PREPARED) //P4000303
//PSIV00000280        return (RC_WAFER_NOT_PREPARED);
        SET_MSG_RC(strVendorLotReceiveAndPrepareReqResult,MSG_NO_NEED_WAFER_PREPARATION,RC_NO_NEED_WAFER_PREPARATION) //PSIV00000280
        return (RC_NO_NEED_WAFER_PREPARATION);                                                                        //PSIV00000280
    }
    else
    {
        tmpNewLotAttributes.strNewWaferAttributes.length(unknownWaferCnt); 
    }

//D7000239 add start
    //----------------------------------
    // Check equipment availability
    //----------------------------------
    objEquipment_CheckAvail_out strEquipment_CheckAvail_out;
    rc = equipment_CheckAvail( strEquipment_CheckAvail_out, strObjCommonIn, equipmentID );
    if ( rc == RC_OK )
    {
        PPT_METHODTRACE_V1("", "Equipment is now available. Go ahead!!");
    }
    else
    {
        PPT_METHODTRACE_V2("", "Equipment is not available. return to caller.", rc);
        strVendorLotReceiveAndPrepareReqResult.strResult = strEquipment_CheckAvail_out.strResult;
        return( rc );
    }
//D7000239 add end

    //------------------------------------------------------
    //    Create vendorLot's PosLot data
    //------------------------------------------------------
    objLot_MakeVendorLot_out strLot_MakeVendorLot_out ;
    rc = lot_MakeVendorLot(strLot_MakeVendorLot_out,
                           strObjCommonIn,
                           bankID,
                           productID,
                           creatingLotID.identifier,
                           subLotType,
                           unknownWaferCnt,
                           vendorLotID.identifier,
                           vendorID.identifier);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "lot_MakeVendorLot() != RC_OK",rc);

        if ( rc == RC_DUPLICATE_LOTID )
        {
            strLot_MakeVendorLot_out.createdLotID = creatingLotID;
        }
        else
        {
            strVendorLotReceiveAndPrepareReqResult.strResult =  strLot_MakeVendorLot_out.strResult ;
            return (rc);
        }
    }
    else
    {
        //--------------------------------------------------------
        //   History, Output data
        //--------------------------------------------------------
        objVendorLotEvent_Make_out  strVendorLotEvent_Make_out;
        rc = vendorLotEvent_Make(strVendorLotEvent_Make_out,
                                 strObjCommonIn,
                                 "TXBKC013",
                                 strLot_MakeVendorLot_out.createdLotID,
                                 vendorLotID.identifier,
                                 unknownWaferCnt,
                                 claimMemo);

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txVendorLotReceiveAndPrepareReq", "vendorLotEvent_Make() != RC_OK",rc);
            strVendorLotReceiveAndPrepareReqResult.strResult = strVendorLotEvent_Make_out.strResult ;
            return(rc);
        }
    }

    PPT_METHODTRACE_V2("", "lot_MakeVendorLot() lotID = ",strLot_MakeVendorLot_out.createdLotID.identifier);    //0.0.6

    for ( i=0; i<unknownWaferCnt; i++ )
    {
       tmpNewLotAttributes.strNewWaferAttributes[i].sourceLotID = strLot_MakeVendorLot_out.createdLotID;
    }

    //--------------------------
    // Object Lock for cassette
    //--------------------------
    CORBA::Boolean bCasstteIsFOSB = FALSE;                          //0.0.5

    PPT_METHODTRACE_V2("", "object_Lock START:cassetteID = ",tmpNewLotAttributes.cassetteID.identifier);    //0.0.6
    objObject_Lock_out strObject_Lock_out;
    rc = object_Lock(strObject_Lock_out, 
                     strObjCommonIn, 
                     tmpNewLotAttributes.cassetteID, 
                     SP_ClassName_PosCassette);
    if (rc != RC_OK)
    {
//0.0.5        PPT_METHODTRACE_V2("CS_PPTManager_i:: txVendorLotReceiveAndPrepareReq", "object_Lock() != RC_OK",rc);
//0.0.5        strVendorLotReceiveAndPrepareReqResult.strResult = strObject_Lock_out.strResult;
//0.0.5 Add Start
        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK",rc);    //0.0.6
        if ( rc == RC_NOT_FOUND_CASSETTE )
        {
            bCasstteIsFOSB = TRUE;
            PPT_METHODTRACE_V1("", "rc == RC_NOT_FOUND_CASSETTE:SET bCasstteIsFOSB = TRUE");

            //P4100074 Add Start
            //---------------------------------------------------
            // Check for Cassette is FOSB And All Wafer is NULL Or
            //---------------------------------------------------
            if(( bFindWaferNull == TRUE ) && ( bFindWaferFill == FALSE))
            {
                PPT_METHODTRACE_V1("", "Cassette is FOSB And All WaferID is NULL");
                SET_MSG_RC(strVendorLotReceiveAndPrepareReqResult,
                           MSG_INVALID_WAFER_ID_READ_RESULT_FOR_VLRP,
                           RC_INVALID_WAFER_ID_READ_RESULT_FOR_VLRP)
                return (RC_INVALID_WAFER_ID_READ_RESULT_FOR_VLRP);
            }
            //P4100074 Add End
        }
        else
        {
            PPT_METHODTRACE_V1("", "rc != RC_NOT_FOUND_CASSETTE:Should be Return");
            strVendorLotReceiveAndPrepareReqResult.strResult = strObject_Lock_out.strResult;
            return(rc);   //0.0.6 
        }
//0.0.5 Add End
//0.0.6        return(rc);
    }
//D9000005 add start
    else
    {
        PPT_METHODTRACE_V1("", "rc == RC_OK");

        /*-------------------------------*/
        /*   Check SorterJob existence   */
        /*-------------------------------*/
        pptEquipmentLoadPortAttribute dummyEquipmentPortAttribute;
        objectIdentifierSequence dummyLotIDs, cassetteIDs;
        cassetteIDs.length(1);
        cassetteIDs[0] = tmpNewLotAttributes.cassetteID;

        objWaferSorter_sorterJob_CheckForOperation_out strWaferSorter_sorterJob_CheckForOperation_out;
        objWaferSorter_sorterJob_CheckForOperation_in  strWaferSorter_sorterJob_CheckForOperation_in;
        strWaferSorter_sorterJob_CheckForOperation_in.strEquipmentLoadPortAttribute = dummyEquipmentPortAttribute;
        strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs                   = cassetteIDs;
        strWaferSorter_sorterJob_CheckForOperation_in.lotIDs                        = dummyLotIDs;
        strWaferSorter_sorterJob_CheckForOperation_in.operation                     = CIMFWStrDup(SP_Operation_For_DestCast);

        rc = waferSorter_sorterJob_CheckForOperation( strWaferSorter_sorterJob_CheckForOperation_out,
                                                      strObjCommonIn,
                                                      strWaferSorter_sorterJob_CheckForOperation_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "waferSorter_sorterJob_CheckForOperation() != RC_OK" );
            strVendorLotReceiveAndPrepareReqResult.strResult = strWaferSorter_sorterJob_CheckForOperation_out.strResult;
            return( rc );
        }
    }
//D9000005 add end

    //----------------------------
    // Object Lock for source lot
    //----------------------------
    for(i=0; i<unknownWaferCnt; i++)
    {
        PPT_METHODTRACE_V2("", "object_Lock START:sourceLotID = ",tmpNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier);    //0.0.6
        rc = object_Lock(strObject_Lock_out, 
                         strObjCommonIn, 
                         tmpNewLotAttributes.strNewWaferAttributes[i].sourceLotID, 
                         SP_ClassName_PosLot);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V3("", "object_Lock() != RC_OK",rc,i);
            strVendorLotReceiveAndPrepareReqResult.strResult = strObject_Lock_out.strResult;
        }
    }

    //--------------------------------------------
    // Prepare Product Request for New Vendor Lot
    //--------------------------------------------
    objProductRequest_forVendorLot_Release_out  strProductRequest_forVendorLot_Release_out;
    rc = productRequest_forVendorLot_Release(strProductRequest_forVendorLot_Release_out,
                                             strObjCommonIn,
                                             bankID,
                                             tmpNewLotAttributes.strNewWaferAttributes[0].sourceLotID,
                                             unknownWaferCnt,
                                             lotType,
                                             subLotType);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "productRequest_forVendorLot_Release() != RC_OK",rc);
        strVendorLotReceiveAndPrepareReqResult.strResult = strProductRequest_forVendorLot_Release_out.strResult;
    }

    //----------------------------------------
    // Copy generated New Lot ID to structure
    //----------------------------------------
    for(i=0; i<unknownWaferCnt; i++)
    {
        tmpNewLotAttributes.strNewWaferAttributes[i].newLotID.identifier
         = strProductRequest_forVendorLot_Release_out.createdProductRequestID.identifier;
 
       PPT_METHODTRACE_V2("", "newLotID = ",strProductRequest_forVendorLot_Release_out.createdProductRequestID.identifier);
    }

    //----------------------
    // Check input parameter
    //----------------------
    if(bCasstteIsFOSB == FALSE)                 //0.0.6
    {
        objLot_parameterForLotGeneration_Check_out strLot_parameterForLotGeneration_Check_out;
        strLot_parameterForLotGeneration_Check_out.bWaferIDAssignRequred = FALSE;
        rc = lot_parameterForLotGeneration_Check(strLot_parameterForLotGeneration_Check_out, 
                                                 strObjCommonIn,
                                                 bankID, 
                                                 tmpNewLotAttributes);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_parameterForLotGeneration_Check() != RC_OK",rc);
            strVendorLotReceiveAndPrepareReqResult.strResult = strLot_parameterForLotGeneration_Check_out.strResult;
            return(rc);
        }
    
        if (strLot_parameterForLotGeneration_Check_out.bWaferIDAssignRequred == TRUE)
        {
            PPT_METHODTRACE_V1("", "bWaferIDAssignRequred == TRUE");
            objLot_waferID_Generate_out strLot_waferID_Generate_out;
            rc = lot_waferID_Generate(strLot_waferID_Generate_out, 
                                      strObjCommonIn,
                                      tmpNewLotAttributes);
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txVendorLotReceiveAndPrepareReq", "lot_waferID_Generate() != RC_OK");
                strVendorLotReceiveAndPrepareReqResult.strResult = strLot_waferID_Generate_out.strResult;
                return(rc);
            }
            tmpNewLotAttributes = strLot_waferID_Generate_out.strNewLotAttributes;
        }
    }                                          //0.0.6

    //-----------------------------
    // Prepare wafer of source lot
    //-----------------------------
    PPT_METHODTRACE_V2("", "unknownWaferCnt",unknownWaferCnt );
    for (i = 0; i < unknownWaferCnt; i++)
    {
        PPT_METHODTRACE_V2("", "tmpNewLotAttributes.strNewWaferAttributes Loop Count", i);
        PPT_METHODTRACE_V2("", "tmpNewLotAttributes.strNewWaferAttributes sourceWaferID",
                                tmpNewLotAttributes.strNewWaferAttributes[i].sourceWaferID.identifier );//0.0.6
        if (CIMFWStrLen(tmpNewLotAttributes.strNewWaferAttributes[i].sourceWaferID.identifier) == 0)
        {
            PPT_METHODTRACE_V2("", "sourceWaferID is null", i);

            objLot_wafer_Create_out strLot_wafer_Create_out;
            rc = lot_wafer_Create(strLot_wafer_Create_out, 
                                  strObjCommonIn,
                                  tmpNewLotAttributes.strNewWaferAttributes[i].sourceLotID,
                                  tmpNewLotAttributes.strNewWaferAttributes[i].newWaferID.identifier);
            if ( rc != RC_OK )
            {
                if ( rc == RC_DUPLICATE_WAFER )    //0.0.6
                {
                    PPT_METHODTRACE_V2("", "lot_wafer_Create() rc != OK: Wafer Dupulicate", rc);
                    continue;
                }
                else
                {
                    PPT_METHODTRACE_V2("", "lot_wafer_Create() rc != OK", rc);
                    strVendorLotReceiveAndPrepareReqResult.strResult = strLot_wafer_Create_out.strResult;
                    return(rc);
                }
            }
            tmpNewLotAttributes.strNewWaferAttributes[i].sourceWaferID = strLot_wafer_Create_out.newWaferID;

            PPT_METHODTRACE_V3("", "newWaferID", strLot_wafer_Create_out.newWaferID.identifier, i);

            pptWafer strWafer;
            strWafer.waferID    = strLot_wafer_Create_out.newWaferID;
            strWafer.slotNumber =  tmpNewLotAttributes.strNewWaferAttributes[i].newSlotNumber;

//0.0.6            if(bCasstteIsFOSB == FALSE)                 //0.0.5
//0.0.6            {
            objWafer_materialContainer_Change_out strWafer_materialContainer_Change_out;
            rc = wafer_materialContainer_Change(strWafer_materialContainer_Change_out, 
                                                strObjCommonIn,
                                                tmpNewLotAttributes.cassetteID,
                                                strWafer);
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "wafer_materialContainer_Change() != RC_OK", rc);
                strVendorLotReceiveAndPrepareReqResult.strResult = strWafer_materialContainer_Change_out.strResult;
                return(rc);
            }
//0.0.6            }                                           //0.0.5
        }
    }

    //------------------------------
    //  Case of Cassette is not FOSB
    //------------------------------
    objectIdentifier tmpCreatedLotID;
    if(bCasstteIsFOSB == FALSE)    //0.0.6     2001-08-31
    {
        //------------------------------
        // Check source lot's condition
        //------------------------------
        objBank_lotPreparation_Check_out strBank_lotPreparation_Check_out;
        rc = bank_lotPreparation_Check(strBank_lotPreparation_Check_out, 
                                       strObjCommonIn,
                                       bankID, 
                                       lotType, 
                                       subLotType, 
                                       tmpNewLotAttributes);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "bank_lotPreparation_Check() != RC_OK",rc);
            strVendorLotReceiveAndPrepareReqResult.strResult = strBank_lotPreparation_Check_out.strResult;
            return(rc);
        }

        //----------------------
        // Lot Preparation      
        //----------------------
        objBank_LotPreparation_out strBank_LotPreparation_out;
        rc = bank_lotPreparation(strBank_LotPreparation_out, 
                                 strObjCommonIn,
                                 strProductRequest_forVendorLot_Release_out.createdProductRequestID, 
                                 bankID, 
                                 tmpNewLotAttributes);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "bank_lotPreparation() != RC_OK",rc);
            strVendorLotReceiveAndPrepareReqResult.strResult = strBank_LotPreparation_out.strResult;
            return(rc);
        }
        
        tmpCreatedLotID = strBank_LotPreparation_out.createdLotID;  //0.0.7     2001-09-04

//INN-R170002 Add Start
        csObjLot_ContaminationInfo_CheckForCarrierExchange_out strLot_ContaminationInfo_CheckForCarrierExchange_out; 
        csObjLot_ContaminationInfo_CheckForCarrierExchange_in  strLot_ContaminationInfo_CheckForCarrierExchange_in;
        strLot_ContaminationInfo_CheckForCarrierExchange_in.carrierID = cassetteID;
        strLot_ContaminationInfo_CheckForCarrierExchange_in.lotIDs.length(1);
        strLot_ContaminationInfo_CheckForCarrierExchange_in.lotIDs[0] = tmpCreatedLotID;
        rc = cs_lot_ContaminationInfo_CheckForCarrierExchange(strLot_ContaminationInfo_CheckForCarrierExchange_out,
                                                              strObjCommonIn,
                                                              strLot_ContaminationInfo_CheckForCarrierExchange_in);
        if(rc!= RC_OK)
        {
            PPT_METHODTRACE_V2("", "cs_lot_ContaminationInfo_CheckForCarrierExchange() != RC_OK", cassetteID.identifier);
            strVendorLotReceiveAndPrepareReqResult.strResult = strLot_ContaminationInfo_CheckForCarrierExchange_out.strResult;
            return( rc );
        }
//INN-R170002 Add End
    }                             //0.0.6     2001-08-31
    else                          //0.0.7     2001-09-03 Start
    {
        //------------------------------
        // Check source lot's condition
        //------------------------------
        objBank_lotPreparation_CheckForWaferSorter_out strBank_lotPreparation_CheckForWaferSorter_out;
        rc = bank_lotPreparation_CheckForWaferSorter(strBank_lotPreparation_CheckForWaferSorter_out, 
                                       strObjCommonIn,
                                       bankID, 
                                       lotType, 
                                       subLotType, 
                                       tmpNewLotAttributes);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "bank_lotPreparation_CheckForWaferSorter() != RC_OK",rc);
            strVendorLotReceiveAndPrepareReqResult.strResult = strBank_lotPreparation_CheckForWaferSorter_out.strResult;
            return(rc);
        }

        //----------------------
        // Lot Preparation      
        //----------------------
        objBank_LotPreparationForWaferSorter_out strBank_LotPreparationForWaferSorter_out;
        rc = bank_lotPreparationForWaferSorter(strBank_LotPreparationForWaferSorter_out, 
                                 strObjCommonIn,
                                 strProductRequest_forVendorLot_Release_out.createdProductRequestID, 
                                 bankID, 
                                 tmpNewLotAttributes);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "bank_lotPreparationForWaferSorter() != RC_OK",rc);
            strVendorLotReceiveAndPrepareReqResult.strResult = strBank_LotPreparationForWaferSorter_out.strResult;
            return(rc);
        }
        
        tmpCreatedLotID = strBank_LotPreparationForWaferSorter_out.createdLotID;        //0.0.7     2001-09-04
    }                              //0.0.7    2001-09-03 End

//0.0.7    //----------------------
//0.0.7    // Lot Preparation      
//0.0.7    //----------------------
//0.0.7    objBank_LotPreparation_out strBank_LotPreparation_out;
//0.0.7    rc = bank_lotPreparation(strBank_LotPreparation_out, 
//0.0.7                             strObjCommonIn,
//0.0.7                             strProductRequest_forVendorLot_Release_out.createdProductRequestID, 
//0.0.7                             bankID, 
//0.0.7                             tmpNewLotAttributes);
//0.0.7    if ( rc != RC_OK )
//0.0.7    {
//0.0.7        PPT_METHODTRACE_V2("", "bank_lotPreparation() != RC_OK",rc);
//0.0.7        strVendorLotReceiveAndPrepareReqResult.strResult = strBank_LotPreparation_out.strResult;
//0.0.7        return(rc);
//0.0.7    }

    //-----------------------------------------
    // Copy created Lot ID to output structure
    //-----------------------------------------
//0.0.7    PPT_METHODTRACE_V2("", "createdLotID", strBank_LotPreparation_out.createdLotID.identifier);
//0.0.7    strVendorLotReceiveAndPrepareReqResult.lotID = strBank_LotPreparation_out.createdLotID;
    PPT_METHODTRACE_V2("", "createdLotID", tmpCreatedLotID.identifier);
    strVendorLotReceiveAndPrepareReqResult.lotID = tmpCreatedLotID;         //0.0.7

    //----------------------
    // Copy Created New Lot Object Identifier
    //  in order to create History Data
    //----------------------
    for(i=0; i<unknownWaferCnt; i++)
    {
//0.0.7        tmpNewLotAttributes.strNewWaferAttributes[i].newLotID = strBank_LotPreparation_out.createdLotID;
        tmpNewLotAttributes.strNewWaferAttributes[i].newLotID = tmpCreatedLotID;    //0.0.7
    }

    if(bCasstteIsFOSB == FALSE)    //0.0.6     2001-08-31
    {
        //--------------------------------
        // Update cassette multi lot type
        //--------------------------------
        objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
        rc = cassette_multiLotType_Update(strCassette_multiLotType_Update_out, 
                                          strObjCommonIn,
                                          tmpNewLotAttributes.cassetteID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cassette_multiLotType_Update() != RC_OK",rc);
            strVendorLotReceiveAndPrepareReqResult.strResult = strCassette_multiLotType_Update_out.strResult;
            return(rc);
        }

        //P4100075 Add Start
        //--------------------------------------------------------
        //   Maintain Loaded Cassette on Eqp Information
        //--------------------------------------------------------
        PPT_METHODTRACE_V1("", "strCassette_transferState_Get_out.transferState is 'EI'...");

        objControlJob_relatedInfo_Update_out strControlJob_relatedInfo_Update_out;

        objectIdentifierSequence cassetteIDSeq(1);
        cassetteIDSeq.length(1);
        cassetteIDSeq[0] = tmpNewLotAttributes.cassetteID;

        rc = controlJob_relatedInfo_Update( strControlJob_relatedInfo_Update_out,
                                            strObjCommonIn,
                                            cassetteIDSeq );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "controlJob_relatedInfo_Update() rc != RC_OK");
            strVendorLotReceiveAndPrepareReqResult.strResult = strControlJob_relatedInfo_Update_out.strResult;
            return( rc );
        }
        //P4100075 Add End
    }                              //0.0.6

    //----------------------------------------------------------
    //   Make History                                           
    //----------------------------------------------------------
    objLot_waferLotHistoryPointer_Update_out  strLot_waferLotHistoryPointer_Update_out;
//0.0.7    rc = lot_waferLotHistoryPointer_Update(strLot_waferLotHistoryPointer_Update_out, 
//0.0.7                                           strObjCommonIn,
//0.0.7                                           strBank_LotPreparation_out.createdLotID);

    rc = lot_waferLotHistoryPointer_Update(strLot_waferLotHistoryPointer_Update_out,        //0.0.7
                                           strObjCommonIn,                                  //0.0.7
                                           tmpCreatedLotID);                                //0.0.7

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "lot_waferLotHistoryPointer_Update() != RC_OK",rc);
        strVendorLotReceiveAndPrepareReqResult.strResult = strLot_waferLotHistoryPointer_Update_out.strResult;
        return(rc);
    }

    objLotWaferMoveEvent_Make_out strLotWaferMoveEvent_Make_out;
    rc = lotWaferMoveEvent_Make(strLotWaferMoveEvent_Make_out, 
                                strObjCommonIn,
                                "TXBKC013", 
                                tmpNewLotAttributes,
                                claimMemo);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "lotWaferMoveEvent_Make() != RC_OK",rc);
        strVendorLotReceiveAndPrepareReqResult.strResult = strLotWaferMoveEvent_Make_out.strResult;
        return(rc);
    }

    /*----------------------------*/
    /*       Return to Caller     */
    /*----------------------------*/
    SET_MSG_RC(strVendorLotReceiveAndPrepareReqResult,MSG_OK,RC_OK)
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txVendorLotReceiveAndPrepareReq ")
//P4000303    return( rc );
    return( RC_OK );        //P4000303
}
