#ifndef lint
static char *sccsid =  "@(#) 1.19 superpos/src/spppt/source/posppt/pptmgr/txmethods/txPostProcessExecReq__100.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/14/07 15:33:34 [ 11/14/07 15:33:35 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: txPostProcessExecReq__100.cpp
//

#include "cs_pptmgr.hpp"

// Class: PPTManager
//
// Service: txPostProcessExecReq__100()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2005/12/01 D7000021 M.Murata       Initial Release (R70)
// 2005/12/20 P7000090 S.Yamamoto     Fix : messageQueuePut is not performed.
// 2006/02/02 D7000191 M.Kase         Add action (Invoke the FutureRework)
// 2006/02/10 D7000203 S.Yamamoto     Claim Timestamp is made the same as Original TX.
// 2006/02/22 D7000218 S.Yamamoto     Claim Shop Date is made the same as Original TX.
// 2006/09/15 D8000028 K.Kido         Add target type CAST_LOT.
// 2006/11/16 D8000024 H.Mutoh        Add action (Invoke the FPC)
// 2007/08/03 D9000056 H.Hotta        Add logic to set InPostProcessFlag.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/03 DSIV00000201 M.Ishino       Improvement of Post-Processing.
// 2008/10/22 DSIV00000214 K.Kido         MultiFab Support.
// 2008/12/04 PSIV00000507 K.Kido         PostProcessFlag handling failure.
// 2009/04/10 PSIV00000888 R.Okano        Add logic to create Collected Data Event in PostProcess
// 2009/05/15 DSIV00001007 R.Okano        Performance improvement for FOUP PostProcessFlag control
// 2010/04/19 DSIV00001830 R.Okano        Wafer Stacking Operation Support.
// 2010/10/14 DSIV00002270 K.Yamaoku      PO Maintenance Improvement
// 2011/08/24 DSN000015229 Xia Yang       Advanced Wafer Level Control support
// 2011/09/21 DSN000020767 T.Ishida       Auto Dispatch Control Support
// 2012/06/05 DSN000041641 F.Chen         Post Process Execution with additional parameters.
// 2012/06/05 DSN000041636 F.Chen         Support Equipment PM related attributes update in post process
// 2012/11/29 DSN000049350 F.Chen         Equipment parallel processing support (P2)
// 2013/01/23 DSN000050720 M.Ogawa        PostProcess parallel execution support
// 2013/07/29 DSN000081739 Shudi Wang     Equipment Monitor Automation Support
// 2013/09/05 DSN000075328 JJ.Zhang       Support post process on chained mode
// 2013/11/06 PSN000064681 JJ.Zhang       Set correct functionID for post process execution
// 2014/05/19 DSN000085698 S.Wang         Support equipment monitor used count function
// 2014/09/03 DSN000085792 K.Yamaoku      QTime enhancement between main route and branch route
// 2015/02/26 PSN000097781 VietNQ         Specify TransactionId parameter used to make eqpMonitorWaferUsedCountUpdate event
// 2015/03/05 DSN000085770 Sa Guo         Durable Management.
// 2015/03/25 DSN000096173 S.Yamamoto     XLC v13.1 Support.
// 2015/08/04 DSN000096126 C.Mo           Durable Process Flow Control Support.
// 2016/02/16 PSN000100936 S.Kawabe       Post Process may leave post process flag as On for a carrier
// 2016/02/17 PSN000101144 S.Kawabe       Lot fails in post process after returning from rework route whose connection point was deleted from sm
// 2016/07/26 DSN000101569 XF.Ming        Durable Sub Status Control Support
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/09 INN-R170003  XL.Cong        Durable Management Enhancement
//
//
//
//
//
//
// Description:
//The function executes Post Processing Actions in the order defined in the Queue Table.
//The queue of actions is first obtained from the Queue Table,
// and is executed accordingly to the contents specified by the information.
//
//The followings are the Post Processing Actions:
//-Invoke the Script
//-Invoke the PSM
//-Insert Message to the Queue Table
//-Perform requested actions by the APC System
//-Invoke the FutureRework    //D7000191
//
//On syncFlag:
//DSN000050720//  0 : Caller is PostProcess Watchdog or Operation user of OPI.
//DSN000050720//  1 : Caller is Large Tx.
//  0 or 2 : Caller is PostProcess Watchdog or Operation user of OPI.
//  1 or 3 : Caller is Large Tx.
// -1 : Caller is PostProcess Watchdog. (For the Recovery purpose)
// * When some error occurs and the operation fails, the Post Process Watchdog
// recovers the process even if the syncFlag of the queue is 1 or 0.
//
// Return:
//     long
//
// Parameter:
// pptPostProcessExecReqResult__100   & strPostProcessExecReqResult
// const pptObjCommonIn               & strObjCommonIn
// const char                         * key
// CORBA::Long                          syncFlag
// CORBA::Long                          prevSeqNo
// const char                         * keyTimeStamp
// const char                         * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::txPostProcessExecReq__100(
                    pptPostProcessExecReqResult__100   & strPostProcessExecReqResult,
                    const pptObjCommonIn               & strObjCommonIn,
                    const char                         * key,
                    CORBA::Long                          syncFlag,
                    CORBA::Long                          prevSeqNo,
                    const char                         * keyTimeStamp,
                    const char                         * claimMemo
                    CORBAENV_LAST_CPP )
{
    PPT_METHODTRACE_ENTRY("PPTManager_i:: txPostProcessExecReq__100") ;
    CORBA::Long rc = RC_OK ;
    CORBA::Long rc_extPostProc = RC_OK ;    //DSIV00000201
    CORBA::Long rc_interFabXfer = RC_OK ;   //DSIV00000214

    /*-------------------------------------------------------------------*/
    /*                                                                   */
    /*  Prepare For Executing Post Process.                              */
    /*                                                                   */
    /*-------------------------------------------------------------------*/
    //---------------------------------------------------------------------------
    //  Call postProcessQueue_GetDR__100
    //
    //        objPostProcessQueue_GetDR_out__100  & strPostProcessQueue_GetDR_out
    //        const pptObjCommonIn                & strObjCommonIn
    //        const char                          * key
    //        CORBA::Long                           prevSeqNo
    //        longSequence                          seqNoList
    //        const char                          * status
    //        CORBA::Long                           syncFlag
    //        const char                          * targetType
    //        const char                          * identifier
    //---------------------------------------------------------------------------
    // Get the next queue of specified seqNo.
    PPT_METHODTRACE_V3("", "Get the next queue... ", key, prevSeqNo );
//DSN000096173    char *strPostProcessQueueState = NULL;
    const char *strPostProcessQueueState = NULL;//DSN000096173
    if( syncFlag != -1 )
    {
        strPostProcessQueueState = SP_PostProcess_State_Reserved;
    }
    longSequence nullSeqNoList(0);
    nullSeqNoList.length(0);
    objectIdentifier          objDummy;
    strPostProcessExecReqResult.lastSeqNo = 0; // Initialize.
//DSN000075328 add start
    CORBA::ULong ppChainMode = 0;
    CORBA::Long rc_pp = RC_OK; //rc for PostProcess registration

    ppChainMode = atoi(getenv(SP_POSTPROC_CHAINED_MODE));
    PPT_METHODTRACE_V2("", "SP_POSTPROC_CHAINED_MODE", ppChainMode);
//DSN000075328 add end
//DSIV00000201    objPostProcessQueue_GetDR_out strPostProcessQueue_GetDR_out;
//DSIV00000201    rc = postProcessQueue_GetDR( strPostProcessQueue_GetDR_out, strObjCommonIn, key, prevSeqNo, nullSeqNoList, strPostProcessQueueState, syncFlag, NULL, objDummy);
//DSIV00000201 add start
    objPostProcessQueue_GetDR_out__100 strPostProcessQueue_GetDR_out;
    rc = postProcessQueue_GetDR__100( strPostProcessQueue_GetDR_out, strObjCommonIn, key, prevSeqNo, nullSeqNoList, strPostProcessQueueState, syncFlag, NULL, objDummy);
//DSIV00000201 add end
    switch( rc )
    {
    case RC_OK:
        // Found queue.
        PPT_METHODTRACE_V1("", "Found the queue... ");
        break;

    case RC_NOT_FOUND_ENTRY:
    { //DSN000041641
        // Not found queue.
        PPT_METHODTRACE_V1("", "Not found the queue... ");
//DSN000041641 Add Start
        // no more entry for this key, delete the additional info
        PPT_METHODTRACE_V1("","Call postProcessAdditionalInfoDeleteDR");
        objPostProcessAdditionalInfoDeleteDR_out strPostProcessAdditionalInfoDeleteDR_out;
        objPostProcessAdditionalInfoDeleteDR_in  strPostProcessAdditionalInfoDeleteDR_in;
        strPostProcessAdditionalInfoDeleteDR_in.dKey = key;

        rc = postProcessAdditionalInfoDeleteDR( strPostProcessAdditionalInfoDeleteDR_out,
                                                strObjCommonIn,
                                                strPostProcessAdditionalInfoDeleteDR_in );
        if( rc != RC_OK && rc != RC_POSTPROC_QUEUE_EXIST)
        {
            PPT_METHODTRACE_V1("","postProcessAdditionalInfoDeleteDR() != RC_OK");
            strPostProcessExecReqResult.strResult = strPostProcessAdditionalInfoDeleteDR_out.strResult;
            return( rc );
        }
//DSN000041641 Add End
        SET_MSG_RC(strPostProcessExecReqResult, MSG_OK, RC_OK);
        return( RC_OK );
        break;
    } //DSN000041641
    default:
        // Error.
        PPT_METHODTRACE_V1("", "Error search the queue...");
        strPostProcessExecReqResult.strResult = strPostProcessQueue_GetDR_out.strResult;
        return( rc );
        break;
    }

    if( 1 > strPostProcessQueue_GetDR_out.strActionInfoSeq.length() )
    {
        //Not found the queue... Return OK.
        PPT_METHODTRACE_V1("", "Not found the queue... ");
        SET_MSG_RC(strPostProcessExecReqResult, MSG_OK, RC_OK);
        return( RC_OK );
    }

    strPostProcessExecReqResult.strPostProcessActionInfoSeq.length(1);
    strPostProcessExecReqResult.strPostProcessActionInfoSeq[0] = strPostProcessQueue_GetDR_out.strActionInfoSeq[0];
    strPostProcessExecReqResult.lastSeqNo                      = strPostProcessQueue_GetDR_out.strActionInfoSeq[0].seqNo;

//DSIV00000201    const pptPostProcessActionInfo& info = strPostProcessQueue_GetDR_out.strActionInfoSeq[0];
    const pptPostProcessActionInfo__100& info = strPostProcessQueue_GetDR_out.strActionInfoSeq[0];  //DSIV00000201

    //----------------------------------------------------------------------------------------------------------
    // Check execCondition
    //
    // Example)
    //   seqNo   execCondition  targetType   postProcID      LotID
    //  ------------------------------------------------------------------
    //     1                      LOT        Split           LOT-A
    //     2          1           LOT        PlannedSplit    LOT-A     <-- seqNo 2 is dependent on seqNo 1.
    //     3                      EQP        MessageQueuePut LOT-A
    // seqNo 2 must be performed after seqNo 1 is performed.
    //----------------------------------------------------------------------------------------------------------
    if ( 0 != info.execConditionSeq.length() )
    {
        PPT_METHODTRACE_V3("", "Check execCondition... ", key, info.execCondition );
//DSIV00000201        objPostProcessQueue_GetDR_out strPostProcessQueue_GetDR_out2;
//DSIV00000201        rc = postProcessQueue_GetDR( strPostProcessQueue_GetDR_out2, strObjCommonIn, key, -1, info.execConditionSeq, NULL, -1, NULL, objDummy );
//DSIV00000201 add start
        objPostProcessQueue_GetDR_out__100 strPostProcessQueue_GetDR_out2;
        rc = postProcessQueue_GetDR__100( strPostProcessQueue_GetDR_out2, strObjCommonIn, key, -1, info.execConditionSeq, NULL, -1, NULL, objDummy );
//DSIV00000201 add end
        CORBA::Boolean bExecutable = FALSE;     //DSN000050720
        switch( rc )
        {
        case RC_OK:
            // The depending record remains yet.
            PPT_METHODTRACE_V1("", "The depending record remains yet. ");
//DSN000050720 Add Start
            if( 0 == CIMFWStrCmp( info.postProcID, SP_PostProcess_ActionID_ParallelExecFinalize ) )
            {
                // In case InterFabXfer is performed for partial lots in a cassette, PostProcExecFinalize action is executable
                // if all of head actions of each lots are "InterFabXfer" and its status is "Executing"
                //
                // Lot_A and Lot_B is in the same cassette
                //     Lot_A : InterFabXfer isn't defined
                //     Lot_B : InterFabXfer is    defined
                // => PostProcess should be completed for Lot_A, and PostProcess stops at "InterFabXfer" for Lot_B
                //
                // seqNo execCond PostProcID           TARGET_TYPE  LotID 
                // ----- -------- -------------------- ------------ -------
                // 1              InterFabXfer         LOT-ABSOLUTE Lot_A
                // 2              InterFabXfer         LOT-ABSOLUTE Lot_B
                // 3     1        Script               LOT-ABSOLUTE Lot_A
                // 4     2        Script               LOT-ABSOLUTE Lot_B
                // 5     3+4      ParallelExecFinalize CAST
                //
                // Procedure
                //     For Lot_A, PostProcess of seqNo 1 and 3 completes
                //     For Lot_B, PostProcess stops at seqMp 2. (status "Executing")
                //     => Exec condition of "ParallelExecFinalize" isn't met.
                // However if following condition is met, "ParallelExecFinalize" is executable
                //     - Head PostProcess actions of the lot which exec condition isn't met are "InteFabXfer"
                //     - The status of PostProcess is "Executing
                // (e.g.)
                // seqNo execCond PostProcID           TARGET_TYPE  LotID   Status
                // ----- -------- -------------------- ------------ ------- --------------
                // 1              InterFabXfer         LOT-ABSOLUTE Lot_A   Completed(Deleted)
                // 2              InterFabXfer         LOT-ABSOLUTE Lot_B   Executing
                // 3     1        Script               LOT-ABSOLUTE Lot_A   Completed(Deleted)
                // 4     2        Script               LOT-ABSOLUTE Lot_B   Reserved
                // 5     3+4      ParallelExecFinalize CAST
                //
                // Exec condition of "ParallelExecFinalize" is "3+4" and isn't met for now.
                // Head PostProcess for Lot_B(exec condition isn't met) is "InterFabXfer" and the status is "Executing"
                // => "ParallelExecFinalize" is executable
                //
                bExecutable = TRUE;
                CORBA::ULong nLen = 0;
                nLen = strPostProcessQueue_GetDR_out2.strActionInfoSeq.length();
                for( CORBA::ULong i = 0; i < nLen; i++ )
                {
                    if( 0 == CIMFWStrCmp(strPostProcessQueue_GetDR_out2.strActionInfoSeq[i].targetType, SP_PostProcess_TargetType_LOT)
                     || 0 == CIMFWStrCmp(strPostProcessQueue_GetDR_out2.strActionInfoSeq[i].targetType, SP_PostProcess_TargetType_LOT_ABSOLUTE) )
                    {
                        PPT_METHODTRACE_V2("", "TargetType is LOT or LOT_ABSOLUTE", strPostProcessQueue_GetDR_out2.strActionInfoSeq[i].strPostProcessTargetObject.lotID.identifier);
                        pptPostProcessTargetObject strPostProcessTargetObject;
                        strPostProcessTargetObject.lotID = strPostProcessQueue_GetDR_out2.strActionInfoSeq[i].strPostProcessTargetObject.lotID;
                        objPostProcessQueue_ListDR_out__100 strPostProcessQueue_ListDR_out;
                        rc = postProcessQueue_ListDR__130( strPostProcessQueue_ListDR_out,
                                                           strObjCommonIn,
                                                           key,         //key
                                                           -1,          //seqNo
                                                           "",          //watchdogName
                                                           SP_PostProcess_ActionID_InterFabXfer,    //postProcID
                                                           -1,          //syncFlag
                                                           "",          //txID
                                                           "",          //targetType
                                                           strPostProcessTargetObject,
                                                           SP_PostProcess_State_Executing,          //status
                                                           -1,          //passedTime
                                                           "",          //claimUserID
                                                           "",          //startCreateTimeStamp
                                                           "",          //endCreateTimeStamp
                                                           "",          //startUpdateTimeStamp
                                                           "",          //endUpdateTimeStamp
                                                           1,           //maxCount
                                                           TRUE         //committedReadFlag
                                                           );
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("","postProcessQueue_ListDR__130() != RC_OK", rc);
                            strPostProcessExecReqResult.strResult = strPostProcessQueue_ListDR_out.strResult;
                            return( rc );
                        }

                        CORBA::ULong procLen = strPostProcessQueue_ListDR_out.strActionInfoSeq.length();
                        if( procLen > 0 )
                        {
                            //OK
                            PPT_METHODTRACE_V1("", "InterFabXfer action is being executed for the lot.");
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", "Exec condition isn't met.");
                            bExecutable = FALSE;
                            break;
                        }
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "TargetType isn't LOT or LOT_ABSOLUTE. Exec condition isn't met.");
                        bExecutable = FALSE;
                        break;
                    }
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "Action isn't ParallelExecFinalize. Exec condition isn't met.");
            }

            if( FALSE == bExecutable )
            {
//DSN000050720 Add End
//DSN000050720 Indent Start
                //-------------------------------------------------------------------------------------
                // Check based on commitFlag whether performing with TX_COMMIT or without TX_COMMIT.
                //-------------------------------------------------------------------------------------
                PPT_METHODTRACE_V2("", "commitFlag is ...", info.commitFlag);
                if( info.commitFlag == TRUE )
                {
                    strPostProcessExecReqResult.strResult = strPostProcessQueue_GetDR_out.strResult;
                    SET_MSG_RC( strPostProcessExecReqResult, MSG_POSTPROC_NEXT_ENTRY_WITH_COMMIT, RC_POSTPROC_NEXT_ENTRY_WITH_COMMIT);
                    return ( RC_POSTPROC_NEXT_ENTRY_WITH_COMMIT );
                }
                else
                {
                    strPostProcessExecReqResult.strResult = strPostProcessQueue_GetDR_out.strResult;
                    SET_MSG_RC( strPostProcessExecReqResult, MSG_POSTPROC_NEXT_ENTRY_WITHOUT_COMMIT, RC_POSTPROC_NEXT_ENTRY_WITHOUT_COMMIT);
                    return ( RC_POSTPROC_NEXT_ENTRY_WITHOUT_COMMIT );
                }
//DSN000050720 Indent End
            }   //DSN000050720
            break;
        case RC_NOT_FOUND_ENTRY:
            // Can execute!
            PPT_METHODTRACE_V1("", "Can execute! ");
            break;
        default:
            // Error.
            PPT_METHODTRACE_V1("", "Error search the queue...");
            strPostProcessExecReqResult.strResult = strPostProcessQueue_GetDR_out.strResult;
            return( rc );
            break;
        }
    }

    /*-------------------------------------------------------------------*/
    /*                                                                   */
    /*  Post Process Execution!!                                         */
    /*                                                                   */
    /*-------------------------------------------------------------------*/

    PPT_METHODTRACE_V5("", "Executed queue information. [dkey] [seqNo] [postProcID] [targetType]", info.dKey, info.seqNo, info.postProcID, info.targetType);

    //--------------------------------------------------------
    // Copy TXID and claimUserID
    //--------------------------------------------------------
    pptObjCommonIn tmpStrObjCommonIn            = strObjCommonIn;
    tmpStrObjCommonIn.transactionID             = info.txID;
    tmpStrObjCommonIn.strUser.functionID        = info.txID;  //PSN000064681
    tmpStrObjCommonIn.strUser.userID.identifier = info.claimUserID;
    tmpStrObjCommonIn.strUser.userID.stringifiedObjectReference = CIMFWStrDup("");
    tmpStrObjCommonIn.strTimeStamp.reportTimeStamp = info.claimTime; //D7000203
    tmpStrObjCommonIn.strTimeStamp.reportShopdate  = info.claimShopDate; //D7000218

    //---------------------------------------------------------
    //  Prepare for changing Lot's Hold State. (Hold/Release)
    //---------------------------------------------------------
    pptHoldLotReleaseReqResult   strHoldLotReleaseReqResult;
    pptHoldLotReqResult          strHoldLotReqResult;
    objectIdentifier             dummyLot;
    objectIdentifier             holdReleaseCode;
    objectIdentifier             holdCode;
    holdReleaseCode.identifier = CIMFWStrDup( SP_Reason_LotLockRelease );    // LOCR
    pptHoldListSequence         strHoldListSeq(1);
    strHoldListSeq.length(1);
    strHoldListSeq[0].holdType                     = CIMFWStrDup( SP_HoldType_LotHold );
    strHoldListSeq[0].holdReasonCodeID.identifier  = CIMFWStrDup( SP_Reason_LotLock        );    // LOCK
    strHoldListSeq[0].holdUserID.identifier        = CIMFWStrDup( SP_PostProc_Person );
    strHoldListSeq[0].responsibleOperationMark     = CIMFWStrDup( SP_ResponsibleOperation_Current );
    strHoldListSeq[0].relatedLotID                 = dummyLot;
    strHoldListSeq[0].claimMemo                    = CIMFWStrDup("");

//DSN000096126 Add Start
    //---------------------------------------------------------
    //  Prepare for changing Durables' Hold State. (Hold/Release)
    //---------------------------------------------------------
    objectIdentifier dummyID;
    pptDurableHoldListSequence strDurableHoldList;
    strDurableHoldList.length(1);
    strDurableHoldList[0].holdType                     = CIMFWStrDup(SP_HoldType_DurableHold); 
    strDurableHoldList[0].holdReasonCodeID.identifier  = CIMFWStrDup(SP_Reason_DurableLock);
    strDurableHoldList[0].holdUserID.identifier        = CIMFWStrDup(SP_PostProc_Person);
    strDurableHoldList[0].responsibleOperationMark     = CIMFWStrDup(SP_ResponsibleOperation_Current);
    strDurableHoldList[0].routeID                      = dummyID;
    strDurableHoldList[0].operationNumber              = CIMFWStrDup("");
    strDurableHoldList[0].relatedDurableID             = dummyID;
    strDurableHoldList[0].relatedDurableCategory       = CIMFWStrDup("");
    strDurableHoldList[0].claimMemo                    = CIMFWStrDup("");
//DSN000096126 Add End

    CORBA::Boolean bHoldRelease = TRUE;

//D8000028 add start
    objectIdentifier lotID        = info.strPostProcessTargetObject.lotID;
    objectIdentifier cassetteID   = info.strPostProcessTargetObject.cassetteID;
    objectIdentifier equipmentID  = info.strPostProcessTargetObject.equipmentID;
    objectIdentifier controlJobID = info.strPostProcessTargetObject.controlJobID;
//D8000028 add end

//DSN000096126 Add Start
    CORBA::String_var durableCategory = CIMFWStrDup(SP_DurableCat_Cassette);
    if(0 < CIMFWStrLen(cassetteID.identifier))
    {
        objDurable_durableCategory_Get_in strDurable_durableCategory_Get_in;
        objDurable_durableCategory_Get_out strDurable_durableCategory_Get_out;
        strDurable_durableCategory_Get_in.durableID = cassetteID;
        rc = durable_durableCategory_Get(strDurable_durableCategory_Get_out, strObjCommonIn, strDurable_durableCategory_Get_in);
        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "durable_durableCategory_Get() returned error.");
            strPostProcessExecReqResult.strResult = strDurable_durableCategory_Get_out.strResult;
            return(rc);
        }
        else
        {
            PPT_METHODTRACE_V2("", "durableCategory =", durableCategory);
            durableCategory = strDurable_durableCategory_Get_out.durableCategory;
        }
    }
//DSN000096126 Add End

//D9000056 add start
    // Get environment variables
    CORBA::Long lockHoldUseFlag     = atoi( getenv(SP_LOCK_HOLD_USE_FLAG) );
    CORBA::Long postProcFlagUseFlag = atoi( getenv(SP_POSTPROC_FLAG_USE_FLAG) );
    PPT_METHODTRACE_V2("","lockHoldUseFlag     ", lockHoldUseFlag);
    PPT_METHODTRACE_V2("","postProcFlagUseFlag ", postProcFlagUseFlag);

    CORBA::Boolean bFindLockHoldFlag  = FALSE;
    CORBA::Boolean bInPostProcessFlag = FALSE;

    if( 0 == lockHoldUseFlag
     || 1 == lockHoldUseFlag
     || 1 == postProcFlagUseFlag )
    {
        PPT_METHODTRACE_V1("", "lockHoldUseFlag -> 0 or 1, postProcFlagUseFlag -> 1");

        if( 0 < CIMFWStrLen(lotID.identifier) )
        {
            //---------------------------
            // Get the lot's hold list.
            //---------------------------
            objectIdentifierSequence lotIDs;
            lotIDs.length(1);
            lotIDs[0] = lotID;
            PPT_METHODTRACE_V2("","Get the lot's hold list. ", lotIDs[0].identifier );

            objLot_FillInTxTRQ005DR_out strLot_FillInTxTRQ005DR_out;
            rc = lot_FillInTxTRQ005DR( strLot_FillInTxTRQ005DR_out,
                                       strObjCommonIn,
                                       lotIDs[0]);
            if( rc != RC_OK && rc != RC_NOT_FOUND_ENTRY )
            {
                PPT_METHODTRACE_V1("","lot_FillInTxTRQ005DR() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_FillInTxTRQ005DR_out.strResult;
                return ( rc ) ;
            }

            if( rc == RC_OK )
            {
                //---------------------------
                // Check LOCK Hold.
                //---------------------------
                CORBA::Long lotRsnCnt = strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes.length();
                PPT_METHODTRACE_V2("","strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes.length()", lotRsnCnt );

                for( CORBA::Long i = 0; i < lotRsnCnt; i++ )
                {
                    if( 0 == CIMFWStrCmp( strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes[i].reasonCodeID.identifier, SP_Reason_LotLock) )
                    {
                        PPT_METHODTRACE_V1("", "Find LOCK Hold.");
                        bFindLockHoldFlag = TRUE;
                        break;
                    }
                }
            }

            PPT_METHODTRACE_V1("", "Get InPostProcessFlag of Lot.");

            // Get InPostProcessFlag of Lot
            objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
            objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
            strLot_inPostProcessFlag_Get_in.lotID = lotID;

            rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Get_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
                return( rc );
            }

            bInPostProcessFlag = strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot;
            PPT_METHODTRACE_V2("","bInPostProcessFlag ", bInPostProcessFlag);
        }
//DSN000096126 Add Start
        else if( 0 < CIMFWStrLen(cassetteID.identifier) )
        {
            PPT_METHODTRACE_V1("", "cassetteID is not blank");

            objDurable_OnRoute_Check_out strDurable_OnRoute_Check_out;
            objDurable_OnRoute_Check_in  strDurable_OnRoute_Check_in;
            strDurable_OnRoute_Check_in.durableCategory = durableCategory;
            strDurable_OnRoute_Check_in.durableID       = cassetteID;
            rc = durable_OnRoute_Check(strDurable_OnRoute_Check_out, strObjCommonIn, strDurable_OnRoute_Check_in);
            if( rc == RC_DURABLE_ONROUTE)
            {
                PPT_METHODTRACE_V1("", "durable_OnRoute_Check() == RC_DURABLE_ONROUTE");

                objDurable_FillInTxPDQ025_out strDurable_FillInTxPDQ025_out;
                objDurable_FillInTxPDQ025_in  strDurable_FillInTxPDQ025_in;
                strDurable_FillInTxPDQ025_in.durableCategory = durableCategory;
                strDurable_FillInTxPDQ025_in.durableID       = cassetteID;
                rc = durable_FillInTxPDQ025(strDurable_FillInTxPDQ025_out, strObjCommonIn, strDurable_FillInTxPDQ025_in);
                if( rc != RC_OK && rc != RC_NOT_FOUND_ENTRY)
                {
                    PPT_METHODTRACE_V2("", "durable_FillInTxPDQ025() != RC_OK", rc);
                    strPostProcessExecReqResult.strResult = strDurable_FillInTxPDQ025_out.strResult;
                    return( rc );
                }

                if( rc == RC_OK )
                {
                    PPT_METHODTRACE_V1("", "durable_FillInTxPDQ025() == RC_OK");

                    //---------------------------
                    // Check LOCK Hold.
                    //---------------------------
                    CORBA::ULong durHoldCnt = strDurable_FillInTxPDQ025_out.strDurableHoldListAttributes.length();
                    PPT_METHODTRACE_V2("", "strDurable_FillInTxPDQ025_out.strDurableHoldListAttributes.length()", durHoldCnt);

                    for( CORBA::ULong nDurHold = 0; nDurHold < durHoldCnt; nDurHold++ )
                    {
                        if( 0 == CIMFWStrCmp( strDurable_FillInTxPDQ025_out.strDurableHoldListAttributes[nDurHold].reasonCodeID.identifier, SP_Reason_DurableLock) )
                        {
                            PPT_METHODTRACE_V1("", "Find LOCK Hold.");
                            bFindLockHoldFlag = TRUE;
                            break;
                        }
                    }
                }

                PPT_METHODTRACE_V1("", "Get InPostProcessFlag of Durable.");

                // Get InPostProcessFlag of Durable
                objDurable_inPostProcessFlag_Get_out strDurable_inPostProcessFlag_Get_out;
                objDurable_inPostProcessFlag_Get_in  strDurable_inPostProcessFlag_Get_in;
                strDurable_inPostProcessFlag_Get_in.durableCategory = durableCategory;
                strDurable_inPostProcessFlag_Get_in.durableID       = cassetteID;
                rc = durable_inPostProcessFlag_Get( strDurable_inPostProcessFlag_Get_out,
                                                    strObjCommonIn,
                                                    strDurable_inPostProcessFlag_Get_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "durable_inPostProcessFlag_Get() != RC_OK");
                    strPostProcessExecReqResult.strResult = strDurable_inPostProcessFlag_Get_out.strResult;
                    return( rc );
                }

                if(strDurable_inPostProcessFlag_Get_out.isPostProcessFlagOn == TRUE)
                {
                    PPT_METHODTRACE_V1("", "bInPostProcessFlag == TRUE");
                    bInPostProcessFlag = TRUE;
                }
                PPT_METHODTRACE_V2("","bInPostProcessFlag ", bInPostProcessFlag);
            }
        }
//DSN000096126 Add End
    }
//D9000056 add end

    //----------------------------------------
    // Call txRunBRScriptReq
    //----------------------------------------
    if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_Script) )
    {
        //Check lot state
        objLot_state_Get_out strLot_state_Get_out ;
//D8000028        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, info.lotID );
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );    //D8000028
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
        {
            // Active

//D9000056 add start
            if( 1 == lockHoldUseFlag
             || 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");

                if( FALSE == bFindLockHoldFlag
                 && FALSE == bInPostProcessFlag )
                {
                    PPT_METHODTRACE_V1("", "Lot is not in post process.");
                    PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                        MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                        lotID.identifier );
                    return( RC_POSTPROC_ERROR );
                }
            }

            // Set InPostProcessFlag of Lot to OFF
            objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
            objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;

            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Set_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }

            if( TRUE == bFindLockHoldFlag
            && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
            {
//D9000056 add end
                // Release Lot Hold.
                PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
//D8000028  rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, info.lotID, holdReleaseCode, strHoldListSeq );
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );    //D8000028
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return( RC_POSTPROC_ERROR );
                }
            }  //D9000056

            // Call txRunBRScriptReq
            PPT_METHODTRACE_V1("", " Call txRunBRScriptReq (TargetType:Script)");
            pptRunBRScriptReqResult  strRunBRScriptReqResult;
            objectIdentifier         dummyEqp;
//D8000028  rc = txRunBRScriptReq( strRunBRScriptReqResult, tmpStrObjCommonIn, SP_BRScript_Pre1, info.lotID, dummyEqp );
            rc = txRunBRScriptReq( strRunBRScriptReqResult, tmpStrObjCommonIn, SP_BRScript_Pre1, lotID, dummyEqp );    //D8000028
            if ( rc != RC_OK && rc != RC_NOT_FOUND_SCRIPT )
            {
                PPT_METHODTRACE_V1("","txRunBRScriptReq rc != RC_OK && rc != RC_NOT_FOUND_SCRIPT...");
                strPostProcessExecReqResult.strResult = strRunBRScriptReqResult.strResult ;
                return( RC_POSTPROC_ERROR );
            }

//D9000056 add start
            if( rc == RC_NOT_FOUND_SCRIPT )
            {
                PPT_METHODTRACE_V1("","rc == RC_NOT_FOUND_SCRIPT.");
                rc = RC_OK;
            }

            if( 1 == lockHoldUseFlag )
            {
//D9000056 add end
                // Hold Lot "LOCK".
                PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
//D8000028  rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, info.lotID, strHoldListSeq );
                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );    //D8000028
                if( rc != RC_OK )
                {
                    if( rc != RC_INVALID_LOT_STAT )
                    {
                        PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK returned error.");
                        strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","rc == RC_INVALID_LOT_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            } //D9000056

//D9000056 add start
            if( 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");

                //Check lot state
                rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
                    return( RC_POSTPROC_ERROR );
                }

                if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
                {
                    // Active
                    PPT_METHODTRACE_V1("","lot_state = Active.");

                    // Set InPostProcessFlag of Lot to ON
                    strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                    strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;

                    rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                    strObjCommonIn,
                                                    strLot_inPostProcessFlag_Set_in );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                        strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                        return( rc );
                    }
                }
            }
//D9000056 add end
        }
        else
        {
            //Inactive

            //N/A
            PPT_METHODTRACE_V1("","lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }
    //----------------------------------------
    // Call txExperimentalLotExecReq
    //----------------------------------------
    else if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_PSM) )
    {
        //Check lot state
        objLot_state_Get_out strLot_state_Get_out ;
//D8000028        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, info.lotID );
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );    //D8000028
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
        {
            // Active

//DSN000049350 Add Start
            /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
            /*                                                                       */
            /*   Object Lock Process                                                 */
            /*                                                                       */
            /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
            //Get lot cassette
            objLot_cassette_Get_out strLot_cassette_Get_out;
            PPT_METHODTRACE_V2( "", "calling lot_cassette_Get()", lotID.identifier );
            rc = lot_cassette_Get( strLot_cassette_Get_out,
                                   strObjCommonIn,
                                   lotID);
            if ( rc == RC_NOT_FOUND_CST )
            {
                //Do nothing..
            }
            else if ( rc != RC_OK  )
            {
                PPT_METHODTRACE_V2("", "lot_cassette_Get() != RC_OK", rc);
                strPostProcessExecReqResult.strResult = strLot_cassette_Get_out.strResult;
                return( rc );
            }
            else  //RC_OK
            {
                objCassette_LocationInfo_GetDR_out strCassette_LocationInfo_GetDR_out;
                PPT_METHODTRACE_V2( "", "calling cassette_LocationInfo_GetDR()", strLot_cassette_Get_out.cassetteID.identifier );
                rc = cassette_LocationInfo_GetDR(  strCassette_LocationInfo_GetDR_out,
                                                   strObjCommonIn,
                                                   strLot_cassette_Get_out.cassetteID);
                if ( rc != RC_OK  )
                {
                    PPT_METHODTRACE_V2("", "cassette_LocationInfo_GetDR() != RC_OK", rc);
                    strPostProcessExecReqResult.strResult = strCassette_LocationInfo_GetDR_out.strResult;
                    return( rc );
                }                
                // Transfer state is "EI"
//INN-R170003   if ( 0 == CIMFWStrCmp( strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus,SP_TransState_EquipmentIn ))
//INN-R170003 add start 
                if ( 0 == CIMFWStrCmp( strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus,SP_TransState_EquipmentIn ) ||
                     0 == CIMFWStrCmp( strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus, SP_TransState_EquipmentOut ) )
//INN-R170003 add end
                {
                    // Get required equipment lock mode
                    objObject_lockMode_Get_out strObject_lockMode_Get_out;
                    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
                    strObject_lockMode_Get_in.objectID           = strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.equipmentID;
                    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
                    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup(SP_PostProcess_ActionID_PSM); // PlannedSplit
                    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

                    PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.equipmentID.identifier );
                    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                              strObjCommonIn,
                                              strObject_lockMode_Get_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
                        strPostProcessExecReqResult.strResult = strObject_lockMode_Get_out.strResult;
                        return( rc );
                    }
                    
                    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
                    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
                    if (lockMode != SP_EQP_LOCK_MODE_WRITE)
                    {
                        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
                        // Lock Equipment LoadCassette Element (Write)
                        stringSequence loadCastSeq;
                        loadCastSeq.length(1);
                        loadCastSeq[0] = strLot_cassette_Get_out.cassetteID.identifier;
                        
                        objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
                        objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
                        
                        strAdvanced_object_Lock_in.objectID   = strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.equipmentID;
                        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
                        strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
                        strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

                        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_LoadCassette );
                        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                                    strObjCommonIn,
                                                    strAdvanced_object_Lock_in );
                        if ( rc != RC_OK && rc != RC_NOT_FOUND_SOME_OBJECT )
                        {
                            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                            strPostProcessExecReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                            return( rc );
                        }                        
                    }
                }
            }
//DSN000049350 Add End

//D9000056 add start
            if( 1 == lockHoldUseFlag
             || 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");

                if( FALSE == bFindLockHoldFlag
                 && FALSE == bInPostProcessFlag )
                {
                    PPT_METHODTRACE_V1("", "Lot is not in post process.");
                    PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                        MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                        lotID.identifier );
                    return( RC_POSTPROC_ERROR );
                }
            }

            // Set InPostProcessFlag of Lot to OFF
            objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
            objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;

            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Set_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }

            if( TRUE == bFindLockHoldFlag
            && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
            {
//D9000056 add end
                // Release Lot Hold.
                PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
//D8000028  rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, info.lotID, holdReleaseCode, strHoldListSeq );
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );    //D8000028
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return( RC_POSTPROC_ERROR );
                }
            }  //D9000056

//DSN000075328 add start
            // Store TriggerDKey as thread specific data
            if( 1 == ppChainMode )
            {
                PPT_METHODTRACE_V1("", "ppChainMode=1, Store TriggerDKey");
                char* methodName = NULL;
                try
                {
                    methodName = CIMFWStrDup("setThreadSpecificDataString");
                    setThreadSpecificDataString (SP_ThreadSpecificData_Key_TriggerDKey, info.dKey);
                    CORBA::string_free(methodName);
                    methodName = NULL;
                }
                CATCH_GLOBAL_EXCEPTIONS(strPostProcessExecReqResult, txPostProcessExecReq__100, methodName);
            }
//DSN000075328 add end

            // Call txExperimentalLotExecReq
            PPT_METHODTRACE_V1("", "Call txExperimentalLotExecReq (TargetType:PlannedSplit) ");
            pptExperimentalLotExecReqResult  strExperimentalLotExecReqResult;
//D8000028  rc = txExperimentalLotExecReq( strExperimentalLotExecReqResult, tmpStrObjCommonIn, info.lotID, "" );
            rc = txExperimentalLotExecReq( strExperimentalLotExecReqResult, tmpStrObjCommonIn, lotID, "" );    //D8000028
//DSN000075328 add start
            // remove TriggerDKey from thread specific data (set blank)
            if( 1 == ppChainMode )
            {
                PPT_METHODTRACE_V1("", "ppChainMode=1, clear TriggerDKey");
                char* methodName = NULL;
                try
                {
                    methodName = CIMFWStrDup("setThreadSpecificDataString");
                    setThreadSpecificDataString (SP_ThreadSpecificData_Key_TriggerDKey, "");
                    CORBA::string_free(methodName);
                    methodName = NULL;
                }
                CATCH_GLOBAL_EXCEPTIONS(strPostProcessExecReqResult, txPostProcessExecReq__100, methodName);
            }

            if( rc == RC_POSTRPOC_DKEY_RECREATE )
            {
                PPT_METHODTRACE_V1("","rc == RC_POSTRPOC_DKEY_RECREATE");
                rc_pp = rc;
                rc = RC_OK;
            }
//DSN000075328 add end
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("","txExperimentalLotExecReq rc != RC_OK");
                strPostProcessExecReqResult.strResult = strExperimentalLotExecReqResult.strResult;
                return( RC_POSTPROC_ERROR );
            }

//D9000056 add start
            if( 1 == lockHoldUseFlag )
            {
//D9000056 add end
                // Hold Lot "LOCK".
                PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
//D8000028  rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, info.lotID, strHoldListSeq );
                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );    //D8000028
                if( rc != RC_OK )
                {
                    if( rc != RC_INVALID_LOT_STAT )
                    {
                        PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK returned error.");
                        strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","rc == RC_INVALID_LOT_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            } //D9000056

//D9000056 add start
            if( 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");

                // Set InPostProcessFlag of Lot to ON
                strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;

                rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                strObjCommonIn,
                                                strLot_inPostProcessFlag_Set_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                    strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                    return( rc );
                }
            }
//D9000056 add end
        }
        else
        {
            //Inactive

            //N/A
            PPT_METHODTRACE_V1("","lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }
    //----------------------------------------
    // Call messageQueue_Put
    //----------------------------------------
    else if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_MessageQueuePut) ||
             0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_MessageQueuePutForLotRecovery) )
    {
        //------------------------------------------------------------------------------------------------------------------------------------------------
        // If the queue condition is "postProcID == MessageQueuePutForLotRecovery" and "syncFlag == 1 "(This is inparameter and is not info.syncFlag.),
        // the queue is deleted in synchronous execution normally end.
        // But, when some error occurs, the queue remains. And PostProcessWatchdog performs about the remaining execution queue, the queue is deleted.
        //------------------------------------------------------------------------------------------------------------------------------------------------
//DSN000050720        if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_MessageQueuePutForLotRecovery) && 1 == syncFlag )
        if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_MessageQueuePutForLotRecovery)                        //DSN000050720
         && ( SP_PostProcess_SyncFlag_Sync_Sequential == syncFlag || SP_PostProcess_SyncFlag_Sync_Parallel == syncFlag ) )  //DSN000050720
        {
            PPT_METHODTRACE_V3("", "MessageQueuePut ", info.postProcID, syncFlag);
            rc = RC_OK;
        }
        else
        {
            //--------------------------------------------------------------
            //   Put Message into Message Queue for Full-Auto
            //
            //     objMessageQueue_Put_out&  strMessageQueue_Put_out
            //     const pptObjCommonIn&     strObjCommonIn
            //     const objectIdentifier&   equipmentID
            //     const char *              equipmentMode
            //     const objectIdentifier&   equipmentStatusCode
            //     const objectIdentifier&   lotID
            //     const char *              lotProcessState
            //     const char *              lotHoldState
            //     const objectIdentifier&   cassetteID
            //     const char *              cassetteTransferState
            //     CORBA::Boolean            cassetteTransferReserveFlag
            //     CORBA::Boolean            cassetteDispatchReserveFlag
            //     const objectIdentifier&   durableID
            //     const char *              durableTransferState
            //--------------------------------------------------------------
            objMessageQueue_Put_out   strMessageQueue_Put_out;
            objectIdentifier          dummy;
            pptPortOperationModeSequence dmyPortOperationMode;

            PPT_METHODTRACE_V2("", "messageQueuePut TargetType is ", info.targetType);

            if( 0 == CIMFWStrCmp(info.targetType, SP_PostProcess_TargetType_EQP) )
            {
                // Call messageQueue_Put
                PPT_METHODTRACE_V1("", "Call messageQueue_Put (TargetType:EQP) ");
//P7000090                rc = messageQueue_Put( strMessageQueue_Put_out,  strObjCommonIn, info.equipmentID,
//D8000028      rc = messageQueue_Put( strMessageQueue_Put_out, tmpStrObjCommonIn, info.equipmentID, //P7000090
                rc = messageQueue_Put( strMessageQueue_Put_out, tmpStrObjCommonIn, equipmentID, //D8000028
                                       dmyPortOperationMode, dummy, dummy, "", "", dummy, "",
                                       FALSE, FALSE, dummy, "" );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "messageQueue_Put() != RC_OK");
                    strPostProcessExecReqResult.strResult = strMessageQueue_Put_out.strResult;
                    return( RC_POSTPROC_ERROR );
                }
            }
            else if( 0 == CIMFWStrCmp(info.targetType, SP_PostProcess_TargetType_LOT) )
            {
                //Check lot state
                objLot_state_Get_out strLot_state_Get_out ;
//D8000028      rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, info.lotID );
                rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );    //D8000028
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
                    return( RC_POSTPROC_ERROR );
                }

                if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ))
                {
//D9000056 add start
                    if( 1 == lockHoldUseFlag
                     || 1 == postProcFlagUseFlag )
                    {
                        PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");

                        if( FALSE == bFindLockHoldFlag
                         && FALSE == bInPostProcessFlag )
                        {
                            PPT_METHODTRACE_V1("", "Lot is not in post process.");
                            PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                                MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                                lotID.identifier );
                            return( RC_POSTPROC_ERROR );
                        }
                    }

                    // Set InPostProcessFlag of Lot to OFF
                    objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
                    objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
                    strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                    strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;

                    rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                    strObjCommonIn,
                                                    strLot_inPostProcessFlag_Set_in );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                        strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                        return( rc );
                    }

                    if( TRUE == bFindLockHoldFlag
                    && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
                    {
//D9000056 add end
                        // Release Lot Hold.
                        PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
//D8000028          rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, info.lotID, holdReleaseCode, strHoldListSeq );
                        rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );    //D8000028
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                            strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                            return( RC_POSTPROC_ERROR );
                        }
                    }  //D9000056

                    //Check lot Hold state
                    objLot_holdState_Get_out strLot_holdState_Get_out ;
//D8000028          rc = lot_holdState_Get(strLot_holdState_Get_out, strObjCommonIn, info.lotID );
                    rc = lot_holdState_Get(strLot_holdState_Get_out, strObjCommonIn, lotID );    //D8000028
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("","lot_holdState_Get() != RC_OK returned error.");
                        strPostProcessExecReqResult.strResult = strLot_holdState_Get_out.strResult;
                        return( RC_POSTPROC_ERROR );
                    }

                    // If Lot's Hold status is ONHOLD, messageQueuePut is not performed.
//P7000090          if( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_HoldState_NotOnHold ))
                    if( 0 == CIMFWStrCmp( strLot_holdState_Get_out.lotHoldState, CIMFW_Lot_HoldState_NotOnHold )) //P7000090
                    {
                        // NotOnHold
                        // Call messageQueue_Put
                        PPT_METHODTRACE_V1("", "Call messageQueue_Put (TargetType:LOT) ");
//P7000090                        rc = messageQueue_Put( strMessageQueue_Put_out,  strObjCommonIn, dummy,
                        rc = messageQueue_Put( strMessageQueue_Put_out, tmpStrObjCommonIn, dummy, //P7000090
//D8000028                                     dmyPortOperationMode, dummy, info.lotID, "", CIMFW_Lot_HoldState_NotOnHold, dummy, "",
                                               dmyPortOperationMode, dummy, lotID, "", CIMFW_Lot_HoldState_NotOnHold, dummy, "",    //D8000028
                                               FALSE, FALSE, dummy, "" );
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "messageQueue_Put() != RC_OK");
                            strPostProcessExecReqResult.strResult = strMessageQueue_Put_out.strResult;
                            return( RC_POSTPROC_ERROR );
                        }
                    }
//D9000056 add start
                    if( 1 == lockHoldUseFlag )
                    {
//D9000056 add end
                        // Hold Lot "LOCK".
                        PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
//D8000028          rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, info.lotID, strHoldListSeq );
                        rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );    //D8000028
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("","txHoldLotReq() ! = RC_OK returned error.");
                            strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                            return( RC_POSTPROC_ERROR );
                        }
                    } //D9000056

//D9000056 add start
                    if( 1 == postProcFlagUseFlag )
                    {
                        PPT_METHODTRACE_V1("","Post Proc Flag is usable.");

                        // Set InPostProcessFlag of Lot to ON
                        strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                        strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;

                        rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                        strObjCommonIn,
                                                        strLot_inPostProcessFlag_Set_in );
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                            strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                            return( rc );
                        }
                    }
//D9000056 add end
                }
                else
                {
                    //Inactive

                    //N/A
                    PPT_METHODTRACE_V1("","lot_state != Active. - N/A -");
                    bHoldRelease = FALSE;
                }
            }// Target Type : LOT ? or EQP ?
        }// messageQueuePut ? or messageQueuePutForLotRecovery ?
    }
    //-------------------------------------------------------------------
    // Call txAPCDispositionLotActionReq and txAPCProductDispositionRpt
    //-------------------------------------------------------------------
    else if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_APCDisposition) )
    {
        // Call txAPCDispositionLotActionReq
        pptAPCDispositionLotActionReqResult  strAPCDispositionLotActionReqResult;
//D8000028        rc = txAPCDispositionLotActionReq( strAPCDispositionLotActionReqResult, tmpStrObjCommonIn, info.equipmentID, info.controlJobID, "" );
        rc = txAPCDispositionLotActionReq( strAPCDispositionLotActionReqResult, tmpStrObjCommonIn, equipmentID, controlJobID, "" );    //D8000028
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "txAPCDispositionLotActionReq() != RC_OK");
            strPostProcessExecReqResult.strResult = strAPCDispositionLotActionReqResult.strResult;
            return( RC_POSTPROC_ERROR );
        }

        CORBA::Long dispositionSeq = 0;
        dispositionSeq = strAPCDispositionLotActionReqResult.strAPCProductDispositionResponseList.length();
        PPT_METHODTRACE_V2("", "strAPCProductDispositionResponseList.length()", dispositionSeq);

        for ( CORBA::Long dispResCnt = 0; dispResCnt < dispositionSeq; dispResCnt++ )
        {
            CORBA::Long lotActionSeq = strAPCDispositionLotActionReqResult.strAPCProductDispositionResponseList[dispResCnt].strAPCDispositionLotAction.length();
            PPT_METHODTRACE_V3("", "strAPCDispositionLotActionResult.length()", lotActionSeq, dispResCnt);

            pptAPCDispositionLotActionResultSequence strAPCDispositionLotActionResultList;
            strAPCDispositionLotActionResultList.length(lotActionSeq);

            for ( CORBA::Long lotCnt = 0; lotCnt < lotActionSeq; lotCnt++ )
            {
                PPT_METHODTRACE_V2("", "for strAPCDispositionLotAction", lotCnt);

                strAPCDispositionLotActionResultList[lotCnt].strAPCDispositionLotAction = strAPCDispositionLotActionReqResult.strAPCProductDispositionResponseList[dispResCnt].strAPCDispositionLotAction[lotCnt];
                strAPCDispositionLotActionResultList[lotCnt].strAPCBaseReturnCode.state = CIMFWStrDup(SP_APCReturnCode_OK);
            }

            // Call txAPCProductDispositionRpt
            pptAPCProductDispositionRptResult  strAPCProductDispositionRptResult;
            rc = txAPCProductDispositionRpt( strAPCProductDispositionRptResult,    tmpStrObjCommonIn,
                                             strAPCDispositionLotActionReqResult.strAPCProductDispositionResponseList[dispResCnt],
//D8000028                                   strAPCDispositionLotActionResultList, info.equipmentID, "" );
                                             strAPCDispositionLotActionResultList, equipmentID, "" );    //D8000028
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "txAPCProductDispositionRpt() != RC_OK");
                strPostProcessExecReqResult.strResult = strAPCProductDispositionRptResult.strResult;
                return( RC_POSTPROC_ERROR );
            }
        }
    }
//D7000191 add start
    //----------------------------------------
    // Call txFutureReworkExecReq
    //----------------------------------------
    else if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_FutureRework) )
    {
        // Check lot state
        objLot_state_Get_out strLot_state_Get_out;
//D8000028        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, info.lotID );
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );    //D8000028
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_state_Get() != RC_OK returned error.");
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if( 0 == CIMFWStrCmp(strLot_state_Get_out.lotState, CIMFW_Lot_State_Active) )
        {
            // Active

//D9000056 add start
            if( 1 == lockHoldUseFlag
             || 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");

                if( FALSE == bFindLockHoldFlag
                 && FALSE == bInPostProcessFlag )
                {
                    PPT_METHODTRACE_V1("", "Lot is not in post process.");
                    PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                        MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                        lotID.identifier );
                    return( RC_POSTPROC_ERROR );
                }
            }

            // Set InPostProcessFlag of Lot to OFF
            objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
            objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;

            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Set_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }

            if( TRUE == bFindLockHoldFlag
            && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
            {
//D9000056 add end
                // Release Lot's Hold "LOCK"
                PPT_METHODTRACE_V1("", "Release Lot's Hold (LOCK)");
//D8000028  rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, info.lotID, holdReleaseCode, strHoldListSeq );
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );    //D8000028
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "txHoldLotReleaseReq() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return( RC_POSTPROC_ERROR );
                }
            }  //D9000056

            // Call txFutureReworkExecReq
            PPT_METHODTRACE_V1("", "Call txFutureReworkExecReq (TargetType:FutureRework)");
            pptFutureReworkExecReqResult strFutureReworkExecReqResult;
//D8000028  rc = txFutureReworkExecReq( strFutureReworkExecReqResult, tmpStrObjCommonIn, info.lotID, "" );
            rc = txFutureReworkExecReq( strFutureReworkExecReqResult, tmpStrObjCommonIn, lotID, "" );    //D8000028
            if( rc != RC_OK && rc != RC_FTRWK_NOT_FOUND )
            {
                PPT_METHODTRACE_V1("", "txFutureReworkExecReq() != RC_OK returned error.");
                strPostProcessExecReqResult.strResult = strFutureReworkExecReqResult.strResult;
                return( RC_POSTPROC_ERROR );
            }

//D9000056 add start
            if( rc == RC_FTRWK_NOT_FOUND )
            {
                PPT_METHODTRACE_V1("","rc == RC_FTRWK_NOT_FOUND.");
                rc = RC_OK;
            }

            if( 1 == lockHoldUseFlag )
            {
//D9000056 add end
                // Hold Lot "LOCK"
                PPT_METHODTRACE_V1("", "Hold Lot (LOCK)");
//D8000028  rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, info.lotID, strHoldListSeq );
                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );    //D8000028
                if( rc != RC_OK )
                {
                    if( rc != RC_INVALID_LOT_STAT )
                    {
                        PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK returned error.");
                        strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "rc == RC_INVALID_LOT_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            } //D9000056

//D9000056 add start
            if( 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");

                // Set InPostProcessFlag of Lot to ON
                strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;

                rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                strObjCommonIn,
                                                strLot_inPostProcessFlag_Set_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                    strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                    return( rc );
                }
            }
//D9000056 add end
        }
        else
        {
            // Inactive

            // N/A
            PPT_METHODTRACE_V1("", "lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }
//D7000191 add end
//D8000028 add start
    //----------------------
    // Call UTSQueuePut
    //----------------------
    else if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_UTSQueuePut) )
    {
        //--------------------------------------------------------
        //   Put Message into UTS Queue for UTSeventWD
        //--------------------------------------------------------
        objUTS_messageQueue_Put_out   strUTS_messageQueue_Put_out;
        PPT_METHODTRACE_V1("", "Call UTS_messageQueue_Put()");
        rc = UTS_messageQueue_Put( strUTS_messageQueue_Put_out, tmpStrObjCommonIn, lotID, cassetteID );

        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "UTS_messageQueue_Put() != RC_OK");
            strPostProcessExecReqResult.strResult = strUTS_messageQueue_Put_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
    }
//D8000028 add end
//D8000024 add start
    //---------------------
    // Call txFPCExecReq
    //---------------------
    else if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_FPC) )
    {
        // Check lot state
        objLot_state_Get_out strLot_state_Get_out;
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_state_Get() != RC_OK", rc);
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
        {
            // Active

//DSN000049350 Add Start
            /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
            /*                                                                       */
            /*   Object Lock Process                                                 */
            /*                                                                       */
            /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

            //Get lot cassette
            objLot_cassette_Get_out strLot_cassette_Get_out;
            PPT_METHODTRACE_V2( "", "calling lot_cassette_Get()", lotID.identifier );
            rc = lot_cassette_Get( strLot_cassette_Get_out,
                                   strObjCommonIn,
                                   lotID);
            if ( rc == RC_NOT_FOUND_CST )
            {
                //Do nothing..
            }
            else if ( rc != RC_OK  )
            {
                PPT_METHODTRACE_V2("", "lot_cassette_Get() != RC_OK", rc);
                strPostProcessExecReqResult.strResult = strLot_cassette_Get_out.strResult;
                return( rc );
            }
            else  //RC_OK
            {
                objCassette_LocationInfo_GetDR_out strCassette_LocationInfo_GetDR_out;
                PPT_METHODTRACE_V2( "", "calling cassette_LocationInfo_GetDR()", strLot_cassette_Get_out.cassetteID.identifier );
                rc = cassette_LocationInfo_GetDR(  strCassette_LocationInfo_GetDR_out,
                                                   strObjCommonIn,
                                                   strLot_cassette_Get_out.cassetteID);
                if ( rc != RC_OK  )
                {
                    PPT_METHODTRACE_V2("", "cassette_LocationInfo_GetDR() != RC_OK", rc);
                    strPostProcessExecReqResult.strResult = strCassette_LocationInfo_GetDR_out.strResult;
                    return( rc );
                }                
                // Transfer state is "EI"
//INN-R170003   if ( 0 == CIMFWStrCmp( strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus,SP_TransState_EquipmentIn ))
//INN-R170003 add start 
                if ( 0 == CIMFWStrCmp( strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus,SP_TransState_EquipmentIn ) ||
                     0 == CIMFWStrCmp( strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus, SP_TransState_EquipmentOut ) )
//INN-R170003 add end
                {
                    // Get required equipment lock mode
                    objObject_lockMode_Get_out strObject_lockMode_Get_out;
                    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
                    strObject_lockMode_Get_in.objectID           = strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.equipmentID;
                    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
                    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup(SP_PostProcess_ActionID_FPC); // FPCExec
                    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

                    PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.equipmentID.identifier );
                    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                              strObjCommonIn,
                                              strObject_lockMode_Get_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
                        strPostProcessExecReqResult.strResult = strObject_lockMode_Get_out.strResult;
                        return( rc );
                    }
                    
                    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
                    PPT_METHODTRACE_V2( "", "lockMode", lockMode );

                    if (lockMode != SP_EQP_LOCK_MODE_WRITE)
                    {
                        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
                        // Lock Equipment LoadCassette Element (Write)
                        stringSequence loadCastSeq;
                        loadCastSeq.length(1);
                        loadCastSeq[0] = strLot_cassette_Get_out.cassetteID.identifier;
                        
                        objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
                        objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
                        
                        strAdvanced_object_Lock_in.objectID   = strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.equipmentID;
                        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
                        strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
                        strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

                        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_LoadCassette );
                        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                                    strObjCommonIn,
                                                    strAdvanced_object_Lock_in );
                        if ( rc != RC_OK && rc != RC_NOT_FOUND_SOME_OBJECT )
                        {
                            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                            strPostProcessExecReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                            return( rc );
                        }                        
                    }
                }
            }
//DSN000049350 Add End

//D9000056 add start
            if( 1 == lockHoldUseFlag
             || 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");

                if( FALSE == bFindLockHoldFlag
                 && FALSE == bInPostProcessFlag )
                {
                    PPT_METHODTRACE_V1("", "Lot is not in post process.");
                    PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                        MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                        lotID.identifier );
                    return( RC_POSTPROC_ERROR );
                }
            }

            // Set InPostProcessFlag of Lot to OFF
            objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
            objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;

            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Set_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }

            if( TRUE == bFindLockHoldFlag
            && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
            {
//D9000056 add end
                // Release Lot Hold.
                PPT_METHODTRACE_V1("", " Release Lot's Hold(LOCK) ");
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "txHoldLotReleaseReq() != RC_OK", rc);
                    strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return( RC_POSTPROC_ERROR );
                }
            }  //D9000056

//DSN000075328 add start
            // Store TriggerDKey as thread specific data
            if( 1 == ppChainMode )
            {
                PPT_METHODTRACE_V1("", "ppChainMode=1, Store TriggerDKey");
                char* methodName = NULL;
                try
                {
                    methodName = CIMFWStrDup("setThreadSpecificDataString");
                    setThreadSpecificDataString (SP_ThreadSpecificData_Key_TriggerDKey, info.dKey);
                    CORBA::string_free(methodName);
                    methodName = NULL;
                }
                CATCH_GLOBAL_EXCEPTIONS(strPostProcessExecReqResult, txPostProcessExecReq__100, methodName);
            }
//DSN000075328 add end

            // Call txFPCExecReq
            PPT_METHODTRACE_V1("", "Call txFPCExecReq (TargetType:FPC)");
            pptFPCExecReqResult strFPCExecReqResult;
            pptFPCExecReqInParm strFPCExecReqInParm;
            strFPCExecReqInParm.lotID = lotID;
            rc = txFPCExecReq(strFPCExecReqResult, tmpStrObjCommonIn, strFPCExecReqInParm, claimMemo );
//DSN000075328 add start
            // remove TriggerDKey from thread specific data (set blank)
            if( 1 == ppChainMode )
            {
                PPT_METHODTRACE_V1("", "ppChainMode=1, clear TriggerDKey");
                char* methodName = NULL;
                try
                {
                    methodName = CIMFWStrDup("setThreadSpecificDataString");
                    setThreadSpecificDataString (SP_ThreadSpecificData_Key_TriggerDKey, "");
                    CORBA::string_free(methodName);
                    methodName = NULL;
                }
                CATCH_GLOBAL_EXCEPTIONS(strPostProcessExecReqResult, txPostProcessExecReq__100, methodName);
            }

            if( rc == RC_POSTRPOC_DKEY_RECREATE )
            {
                PPT_METHODTRACE_V1("","rc == RC_POSTRPOC_DKEY_RECREATE");
                rc_pp = rc;
                rc = RC_OK;
            }
//DSN000075328 add end
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "txFPCExecReq() != RC_OK", rc);
                strPostProcessExecReqResult.strResult = strFPCExecReqResult.strResult;
                return( RC_POSTPROC_ERROR );
            }

//D9000056 add start
            if( 1 == lockHoldUseFlag )
            {
//D9000056 add end
                // Hold Lot "LOCK"
                PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );
                if( rc != RC_OK )
                {
                    if( rc != RC_INVALID_LOT_STAT )
                    {
                        PPT_METHODTRACE_V2("", "txHoldLotReq() != RC_OK", rc);
                        strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "rc == RC_INVALID_LOT_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            } //D9000056

//D9000056 add start
            if( 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");

                //Check lot state
                rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
                    return( RC_POSTPROC_ERROR );
                }

                if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
                {
                    // Active
                    PPT_METHODTRACE_V1("","lot_state = Active.");

                    // Set InPostProcessFlag of Lot to ON
                    strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                    strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;

                    rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                    strObjCommonIn,
                                                    strLot_inPostProcessFlag_Set_in );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                        strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                        return( rc );
                    }
                }
            }
//D9000056 add end
        }
        else
        {
            //Inactive

            //N/A
            PPT_METHODTRACE_V1("", "lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }
//D8000024 add end
//DSIV00000201 add start
    //------------------------------------------
    // Call txCollectedDataActionByPostProcReq
    //------------------------------------------
    else if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_CollectedDataAction) )
    {
//PSIV00000888 add start
        //-------------------------------------------------
        //   Make Event for Collected Data History
        //-------------------------------------------------
        pptStartCassetteSequence  tmpStartCassette;

        objLot_previousOperation_DataCollectionInformation_Get_out   strLot_previousOperation_DataCollectionInformation_Get_out;
        objLot_previousOperation_DataCollectionInformation_Get_in    strLot_previousOperation_DataCollectionInformation_Get_in ;
        // set input parameter
        strLot_previousOperation_DataCollectionInformation_Get_in.equipmentID  = equipmentID;
        strLot_previousOperation_DataCollectionInformation_Get_in.lotIDs.length(1);
        strLot_previousOperation_DataCollectionInformation_Get_in.lotIDs[0]    = lotID;

        rc = lot_previousOperation_DataCollectionInformation_Get( strLot_previousOperation_DataCollectionInformation_Get_out,
                                                                  strObjCommonIn,
                                                                  strLot_previousOperation_DataCollectionInformation_Get_in);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "lot_previousOperation_DataCollectionInformation_Get() != RC_OK" );
            strPostProcessExecReqResult.strResult = strLot_previousOperation_DataCollectionInformation_Get_out.strResult ;
            return( rc );
        }
        tmpStartCassette = strLot_previousOperation_DataCollectionInformation_Get_out.strStartCassette;

        if( 0 >= tmpStartCassette.length() )
        {
            PPT_SET_MSG_RC_KEY(strPostProcessExecReqResult, MSG_NOT_FOUND_CASSETTE, RC_NOT_FOUND_CASSETTE, "(There is no started cassette.)");
            return RC_NOT_FOUND_CASSETTE;
        }

        objCollectedDataEventForPreviousOperation_Make_out  strCollectedDataEventForPreviousOperation_Make_out;
        rc = collectedDataEventForPreviousOperation_Make( strCollectedDataEventForPreviousOperation_Make_out,
                                                          strObjCommonIn,
                                                          "TXTRC074",        //TXID for TxPostProcessExecReq__100
                                                          tmpStartCassette,
                                                          controlJobID,
                                                          equipmentID,
                                                          claimMemo);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "collectedDataEventForPreviousOperation_Make() != RC_OK") ;
            strPostProcessExecReqResult.strResult = strCollectedDataEventForPreviousOperation_Make_out.strResult ;
            return( rc );
        }
//PSIV00000888 add end
        //Check lot state
        objLot_state_Get_out strLot_state_Get_out ;
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
        {
            // Active
            if( 1 == lockHoldUseFlag
             || 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
                if( FALSE == bFindLockHoldFlag
                 && FALSE == bInPostProcessFlag )
                {
                    PPT_METHODTRACE_V1("", "Lot is not in post process.");
                    PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                        MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                        lotID.identifier );
                    return( RC_POSTPROC_ERROR );
                }
            }
            // Set InPostProcessFlag of Lot to OFF
            objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
            objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Set_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }

            if( TRUE == bFindLockHoldFlag
            && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
            {
                // Release Lot Hold.
                PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );    //D8000028
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return( RC_POSTPROC_ERROR );
                }
            }

            //-----------------------------------------------------------------
            // Call txCollectedDataActionByPostProcReq
            //-----------------------------------------------------------------
            PPT_METHODTRACE_V1("", "Call txCollectedDataActionByPostProcReq (TargetType:CollectedDataAction)");
            pptCollectedDataActionByPostProcReqResult   strCollectedDataActionByPostProcReqResult;
            pptCollectedDataActionByPostProcReqInParm   strCollectedDataActionByPostProcReqInParm;
            strCollectedDataActionByPostProcReqInParm.equipmentID  = equipmentID;
            strCollectedDataActionByPostProcReqInParm.controlJobID = controlJobID;
            strCollectedDataActionByPostProcReqInParm.lotID        = lotID;

            rc = txCollectedDataActionByPostProcReq( strCollectedDataActionByPostProcReqResult,
                                                     tmpStrObjCommonIn,
                                                     strCollectedDataActionByPostProcReqInParm,
                                                     claimMemo);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "txCollectedDataActionByPostProcReq() != RC_OK", rc);
                strPostProcessExecReqResult.strResult = strCollectedDataActionByPostProcReqResult.strResult;
                return( RC_POSTPROC_ERROR );
            }
            // set return structure
            strPostProcessExecReqResult.relatedQueuekey = strCollectedDataActionByPostProcReqResult.RelatedQueuekey;
            strPostProcessExecReqResult.strLotSpecSPCCheckResultSeq = strCollectedDataActionByPostProcReqResult.strOpeCompWithDataReqResult.strOpeCompLot;

            if( 1 == lockHoldUseFlag )
            {
                // Hold Lot "LOCK".
                PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );
                if( rc != RC_OK )
                {
                    if( rc != RC_INVALID_LOT_STAT )
                    {
                        PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK returned error.");
                        strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","rc == RC_INVALID_LOT_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            }
            if( 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");
                // Set InPostProcessFlag of Lot to ON
                strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
                rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                strObjCommonIn,
                                                strLot_inPostProcessFlag_Set_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                    strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                    return( rc );
                }
            }
        }
        else
        {
            //Inactive
            //N/A
            PPT_METHODTRACE_V1("","lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }

    //----------------------------------------
    // Call txQtimeActionResetByPostProcReq
    //----------------------------------------
    else if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_QTime) )
    {
//DSN000085792 add start
        // Get additional parameters
        objPostProcessAdditionalInfoGetDR_out strPostProcessAdditionalInfoGetDR_out;
        objPostProcessAdditionalInfoGetDR_in  strPostProcessAdditionalInfoGetDR_in;
        strPostProcessAdditionalInfoGetDR_in.dKey  = info.dKey;
        strPostProcessAdditionalInfoGetDR_in.seqNo = info.seqNo;

        rc = postProcessAdditionalInfoGetDR( strPostProcessAdditionalInfoGetDR_out,
                                             strObjCommonIn,
                                             strPostProcessAdditionalInfoGetDR_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","postProcessAdditionalInfoGetDR() != RC_OK");
            strPostProcessExecReqResult.strResult = strPostProcessAdditionalInfoGetDR_out.strResult;
            return( rc );
        }
        PPT_METHODTRACE_V2("","strPostProcessAdditionalInfoSeq.length = ", strPostProcessAdditionalInfoGetDR_out.strPostProcessAdditionalInfoSeq.length());
        CORBA::ULong i = 0;
        for( i = 0; i < strPostProcessAdditionalInfoGetDR_out.strPostProcessAdditionalInfoSeq.length(); i++ )
        {
            if (0 == CIMFWStrCmp (strPostProcessAdditionalInfoGetDR_out.strPostProcessAdditionalInfoSeq[i].name, SP_ThreadSpecificData_Key_PreviousBranchInfo))
            {
                PPT_METHODTRACE_V1("","found PreviousBranchInfo");
                // Store PreviousBranchInfo as thread specific data
                char* methodName = NULL;
                try
                {
                    methodName = CIMFWStrDup("setThreadSpecificDataString");
                    setThreadSpecificDataString (SP_ThreadSpecificData_Key_PreviousBranchInfo, strPostProcessAdditionalInfoGetDR_out.strPostProcessAdditionalInfoSeq[i].value);
                    CORBA::string_free(methodName);
                    methodName = NULL;
                }
                CATCH_GLOBAL_EXCEPTIONS(strPostProcessExecReqResult, txPostProcessExecReq__100, methodName);
            }
            else if (0 == CIMFWStrCmp (strPostProcessAdditionalInfoGetDR_out.strPostProcessAdditionalInfoSeq[i].name, SP_ThreadSpecificData_Key_PreviousReturnInfo))
            {
                PPT_METHODTRACE_V1("","found PreviousReturnInfo");
                // Store PreviousReturnInfo as thread specific data
                char* methodName = NULL;
                try
                {
                    methodName = CIMFWStrDup("setThreadSpecificDataString");
                    setThreadSpecificDataString (SP_ThreadSpecificData_Key_PreviousReturnInfo, strPostProcessAdditionalInfoGetDR_out.strPostProcessAdditionalInfoSeq[i].value);
                    CORBA::string_free(methodName);
                    methodName = NULL;
                }
                CATCH_GLOBAL_EXCEPTIONS(strPostProcessExecReqResult, txPostProcessExecReq__100, methodName);
            }
//PSN000101144 add start
            else if (0 == CIMFWStrCmp (strPostProcessAdditionalInfoGetDR_out.strPostProcessAdditionalInfoSeq[i].name, SP_ThreadSpecificData_Key_PreviousReworkOutKey))
            {
                PPT_METHODTRACE_V1("","found PreviousReworkOutKey");
                // Store PreviousReworkOutKey as thread specific data
                char* methodName = NULL;
                try
                {
                    methodName = CIMFWStrDup("setThreadSpecificDataString");
                    setThreadSpecificDataString (SP_ThreadSpecificData_Key_PreviousReworkOutKey, strPostProcessAdditionalInfoGetDR_out.strPostProcessAdditionalInfoSeq[i].value);
                    CORBA::string_free(methodName);
                    methodName = NULL;
                }
                CATCH_GLOBAL_EXCEPTIONS(strPostProcessExecReqResult, txPostProcessExecReq__100, methodName);
            }
//PSN000101144 add end
        }
//DSN000085792 add end

        //Check lot state
        objLot_state_Get_out strLot_state_Get_out ;
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
        {
            // Active
            if( 1 == lockHoldUseFlag
             || 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
                if( FALSE == bFindLockHoldFlag
                 && FALSE == bInPostProcessFlag )
                {
                    PPT_METHODTRACE_V1("", "Lot is not in post process.");
                    PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                        MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                        lotID.identifier );
                    return( RC_POSTPROC_ERROR );
                }
            }
            // Set InPostProcessFlag of Lot to OFF
            objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
            objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Set_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }

            if( TRUE == bFindLockHoldFlag
            && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
            {
                // Release Lot Hold.
                PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );    //D8000028
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return( RC_POSTPROC_ERROR );
                }
            }

            //-----------------------------------------------------------------
            // Call txQtimeActionResetByPostProcReq
            //-----------------------------------------------------------------
            PPT_METHODTRACE_V1("", "Call txQtimeActionResetByPostProcReq (TargetType:QTime)");
            pptQtimeActionResetByPostProcReqResult  strQtimeActionResetByPostProcReqResult;
            pptQtimeActionResetByPostProcReqInParm  strQtimeActionResetByPostProcReqInParm;
            strQtimeActionResetByPostProcReqInParm.lotID = lotID;

            rc = txQtimeActionResetByPostProcReq( strQtimeActionResetByPostProcReqResult,
                                                  tmpStrObjCommonIn,
                                                  strQtimeActionResetByPostProcReqInParm,
                                                  claimMemo);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "txQtimeActionResetByPostProcReq() != RC_OK", rc);
                strPostProcessExecReqResult.strResult = strQtimeActionResetByPostProcReqResult.strResult;
                return( RC_POSTPROC_ERROR );
            }

            if( 1 == lockHoldUseFlag )
            {
                // Hold Lot "LOCK".
                PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );
                if( rc != RC_OK )
                {
                    if( rc != RC_INVALID_LOT_STAT )
                    {
                        PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK returned error.");
                        strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","rc == RC_INVALID_LOT_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            }
            if( 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");
                // Set InPostProcessFlag of Lot to ON
                strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
                rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                strObjCommonIn,
                                                strLot_inPostProcessFlag_Set_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                    strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                    return( rc );
                }
            }
        }
        else
        {
            //Inactive
            //N/A
            PPT_METHODTRACE_V1("","lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }

    //----------------------------------------
    // Call txProcessLagTimeUpdateReq
    //----------------------------------------
    else if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_ProcessLagTime) )
    {
        //Check lot state
        objLot_state_Get_out strLot_state_Get_out ;
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
        {
            // Active
            if( 1 == lockHoldUseFlag
             || 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
                if( FALSE == bFindLockHoldFlag
                 && FALSE == bInPostProcessFlag )
                {
                    PPT_METHODTRACE_V1("", "Lot is not in post process.");
                    PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                        MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                        lotID.identifier );
                    return( RC_POSTPROC_ERROR );
                }
            }
            // Set InPostProcessFlag of Lot to OFF
            objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
            objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Set_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }

            if( TRUE == bFindLockHoldFlag
            && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
            {
                // Release Lot Hold.
                PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );    //D8000028
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return( RC_POSTPROC_ERROR );
                }
            }

            //-----------------------------------------------------------------
            // Call txProcessLagTimeUpdateReq
            //-----------------------------------------------------------------
            PPT_METHODTRACE_V1("", "Call txProcessLagTimeUpdateReq (TargetType:ProcessLagTime)");
            pptProcessLagTimeUpdateReqResult strProcessLagTimeUpdateReqResult;

            rc = txProcessLagTimeUpdateReq( strProcessLagTimeUpdateReqResult,
                                            strObjCommonIn,
                                            lotID,
                                            SP_ProcessLagTime_Action_Set,
                                            claimMemo );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "txProcessLagTimeUpdateReq() != RC_OK", rc);
                strPostProcessExecReqResult.strResult = strProcessLagTimeUpdateReqResult.strResult;
                return( RC_POSTPROC_ERROR );
            }

            if( 1 == lockHoldUseFlag )
            {
                // Hold Lot "LOCK".
                PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );
                if( rc != RC_OK )
                {
                    if( rc != RC_INVALID_LOT_STAT )
                    {
                        PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK returned error.");
                        strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","rc == RC_INVALID_LOT_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            }
            if( 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");
                // Set InPostProcessFlag of Lot to ON
                strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
                rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                strObjCommonIn,
                                                strLot_inPostProcessFlag_Set_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                    strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                    return( rc );
                }
            }
        }
        else
        {
            //Inactive
            //N/A
            PPT_METHODTRACE_V1("","lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }

    //----------------------------------------
    // Call txFutureHoldPostByPostProcReq
    //----------------------------------------
    else if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_FutureHoldPost) )
    {
        //Check lot state
        objLot_state_Get_out strLot_state_Get_out ;
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
        {
            // Active
            if( 1 == lockHoldUseFlag
             || 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
                if( FALSE == bFindLockHoldFlag
                 && FALSE == bInPostProcessFlag )
                {
                    PPT_METHODTRACE_V1("", "Lot is not in post process.");
                    PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                        MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                        lotID.identifier );
                    return( RC_POSTPROC_ERROR );
                }
            }
            // Set InPostProcessFlag of Lot to OFF
            objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
            objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Set_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }

            if( TRUE == bFindLockHoldFlag
            && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
            {
                // Release Lot Hold.
                PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );    //D8000028
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return( RC_POSTPROC_ERROR );
                }
            }

            //-----------------------------------------------------------------
            // Call txFutureHoldPostByPostProcReq
            //-----------------------------------------------------------------
            PPT_METHODTRACE_V1("", "Call txFutureHoldPostByPostProcReq (TargetType:FutureHoldPost)");
            pptFutureHoldPostByPostProcReqResult    strFutureHoldPostByPostProcReqResult;
            pptFutureHoldPostByPostProcReqInParm    strFutureHoldPostByPostProcReqInParm;
            strFutureHoldPostByPostProcReqInParm.lotID = lotID;

            rc = txFutureHoldPostByPostProcReq( strFutureHoldPostByPostProcReqResult,
                                                tmpStrObjCommonIn,
                                                strFutureHoldPostByPostProcReqInParm,
                                                claimMemo);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "txFutureHoldPostByPostProcReq() != RC_OK", rc);
                strPostProcessExecReqResult.strResult = strFutureHoldPostByPostProcReqResult.strResult;
                return( RC_POSTPROC_ERROR );
            }

            if( 1 == lockHoldUseFlag )
            {
                // Hold Lot "LOCK".
                PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );
                if( rc != RC_OK )
                {
                    if( rc != RC_INVALID_LOT_STAT )
                    {
                        PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK returned error.");
                        strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","rc == RC_INVALID_LOT_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            }
            if( 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");
                // Set InPostProcessFlag of Lot to ON
                strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
                rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                strObjCommonIn,
                                                strLot_inPostProcessFlag_Set_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                    strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                    return( rc );
                }
            }
        }
        else
        {
            //Inactive
            //N/A
            PPT_METHODTRACE_V1("","lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }

    //---------------------------------------------------
    // Call txSchdlChangeReservationExecuteByPostProcReq
    //---------------------------------------------------
    else if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_SCHExec) )
    {
        //Check lot state
        objLot_state_Get_out strLot_state_Get_out ;
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
        {
            // Active
            if( 1 == lockHoldUseFlag
             || 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
                if( FALSE == bFindLockHoldFlag
                 && FALSE == bInPostProcessFlag )
                {
                    PPT_METHODTRACE_V1("", "Lot is not in post process.");
                    PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                        MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                        lotID.identifier );
                    return( RC_POSTPROC_ERROR );
                }
            }
            // Set InPostProcessFlag of Lot to OFF
            objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
            objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Set_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }

            if( TRUE == bFindLockHoldFlag
            && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
            {
                // Release Lot Hold.
                PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );    //D8000028
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return( RC_POSTPROC_ERROR );
                }
            }

            //-----------------------------------------------------------------
            // Call txSchdlChangeReservationExecuteByPostProcReq
            //-----------------------------------------------------------------
            PPT_METHODTRACE_V1("", "Call txSchdlChangeReservationExecuteByPostProcReq (TargetType:SCHExec)");
            pptSchdlChangeReservationExecuteByPostProcReqResult    strSchdlChangeReservationExecuteByPostProcReqResult;
            pptSchdlChangeReservationExecuteByPostProcReqInParm    strSchdlChangeReservationExecuteByPostProcReqInParm;
            strSchdlChangeReservationExecuteByPostProcReqInParm.lotID = lotID;

            rc = txSchdlChangeReservationExecuteByPostProcReq( strSchdlChangeReservationExecuteByPostProcReqResult,
                                                               tmpStrObjCommonIn,
                                                               strSchdlChangeReservationExecuteByPostProcReqInParm,
                                                               claimMemo);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "txSchdlChangeReservationExecuteByPostProcReq() != RC_OK", rc);
                strPostProcessExecReqResult.strResult = strSchdlChangeReservationExecuteByPostProcReqResult.strResult;
                return( RC_POSTPROC_ERROR );
            }

            if( 1 == lockHoldUseFlag )
            {
                // Hold Lot "LOCK".
                PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );
                if( rc != RC_OK )
                {
                    if( rc != RC_INVALID_LOT_STAT )
                    {
                        PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK returned error.");
                        strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","rc == RC_INVALID_LOT_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            }
            if( 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");
                // Set InPostProcessFlag of Lot to ON
                strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
                rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                strObjCommonIn,
                                                strLot_inPostProcessFlag_Set_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                    strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                    return( rc );
                }
            }
        }
        else
        {
            //Inactive
            //N/A
            PPT_METHODTRACE_V1("","lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }

    //----------------------------------------
    // Call txMonitorHoldExecByPostProcReq
    //----------------------------------------
    else if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_MonitoredLotHold) )
    {
        //Check lot state
        objLot_state_Get_out strLot_state_Get_out ;
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
        {
            // Active
            if( 1 == lockHoldUseFlag
             || 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
                if( FALSE == bFindLockHoldFlag
                 && FALSE == bInPostProcessFlag )
                {
                    PPT_METHODTRACE_V1("", "Lot is not in post process.");
                    PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                        MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                        lotID.identifier );
                    return( RC_POSTPROC_ERROR );
                }
            }
            // Set InPostProcessFlag of Lot to OFF
            objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
            objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Set_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }

            if( TRUE == bFindLockHoldFlag
            && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
            {
                // Release Lot Hold.
                PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );    //D8000028
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return( RC_POSTPROC_ERROR );
                }
            }

            //-----------------------------------------------------------------
            // Call txMonitorHoldExecByPostProcReq
            //-----------------------------------------------------------------
            PPT_METHODTRACE_V1("", "Call txMonitorHoldExecByPostProcReq (TargetType:MonitoredLotHold)");
            pptMonitorHoldExecByPostProcReqResult    strMonitorHoldExecByPostProcReqResult;
            pptMonitorHoldExecByPostProcReqInParm    strMonitorHoldExecByPostProcReqInParm;
            strMonitorHoldExecByPostProcReqInParm.lotID = lotID;

            rc = txMonitorHoldExecByPostProcReq( strMonitorHoldExecByPostProcReqResult,
                                                 tmpStrObjCommonIn,
                                                 strMonitorHoldExecByPostProcReqInParm,
                                                 claimMemo);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "txMonitorHoldExecByPostProcReq() != RC_OK", rc);
                strPostProcessExecReqResult.strResult = strMonitorHoldExecByPostProcReqResult.strResult;
                return( RC_POSTPROC_ERROR );
            }

            if( 1 == lockHoldUseFlag )
            {
                // Hold Lot "LOCK".
                PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );
                if( rc != RC_OK )
                {
                    if( rc != RC_INVALID_LOT_STAT )
                    {
                        PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK returned error.");
                        strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","rc == RC_INVALID_LOT_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            }
            if( 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");
                // Set InPostProcessFlag of Lot to ON
                strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
                rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                strObjCommonIn,
                                                strLot_inPostProcessFlag_Set_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                    strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                    return( rc );
                }
            }
        }
        else
        {
            //Inactive
            //N/A
            PPT_METHODTRACE_V1("","lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }

    //----------------------------------------
    // Call txFutureHoldPreByPostProcReq
    //----------------------------------------
    else if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_FutureHoldPre) )
    {
        //Check lot state
        objLot_state_Get_out strLot_state_Get_out ;
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
        {
            // Active
            if( 1 == lockHoldUseFlag
             || 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
                if( FALSE == bFindLockHoldFlag
                 && FALSE == bInPostProcessFlag )
                {
                    PPT_METHODTRACE_V1("", "Lot is not in post process.");
                    PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                        MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                        lotID.identifier );
                    return( RC_POSTPROC_ERROR );
                }
            }
            // Set InPostProcessFlag of Lot to OFF
            objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
            objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Set_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }

            if( TRUE == bFindLockHoldFlag
            && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
            {
                // Release Lot Hold.
                PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );    //D8000028
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return( RC_POSTPROC_ERROR );
                }
            }

            //-----------------------------------------------------------------
            // Call txFutureHoldPreByPostProcReq
            //-----------------------------------------------------------------
            PPT_METHODTRACE_V1("", "Call txFutureHoldPreByPostProcReq (TargetType:FutureHoldPre)");
            pptFutureHoldPreByPostProcReqResult    strFutureHoldPreByPostProcReqResult;
            pptFutureHoldPreByPostProcReqInParm    strFutureHoldPreByPostProcReqInParm;
            strFutureHoldPreByPostProcReqInParm.lotID = lotID;

            rc = txFutureHoldPreByPostProcReq( strFutureHoldPreByPostProcReqResult,
                                               tmpStrObjCommonIn,
                                               strFutureHoldPreByPostProcReqInParm,
                                               claimMemo);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "txFutureHoldPreByPostProcReq() != RC_OK", rc);
                strPostProcessExecReqResult.strResult = strFutureHoldPreByPostProcReqResult.strResult;
                return( RC_POSTPROC_ERROR );
            }

            if( 1 == lockHoldUseFlag )
            {
                // Hold Lot "LOCK".
                PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );
                if( rc != RC_OK )
                {
                    if( rc != RC_INVALID_LOT_STAT )
                    {
                        PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK returned error.");
                        strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","rc == RC_INVALID_LOT_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            }
            if( 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");
                // Set InPostProcessFlag of Lot to ON
                strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
                rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                strObjCommonIn,
                                                strLot_inPostProcessFlag_Set_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                    strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                    return( rc );
                }
            }
        }
        else
        {
            //Inactive
            //N/A
            PPT_METHODTRACE_V1("","lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }

    //----------------------------------------
    // Call txProcessHoldExecReq
    //----------------------------------------
    else if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_ProcessHold) )
    {
        //Check lot state
        objLot_state_Get_out strLot_state_Get_out ;
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
        {
            // Active
            if( 1 == lockHoldUseFlag
             || 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
                if( FALSE == bFindLockHoldFlag
                 && FALSE == bInPostProcessFlag )
                {
                    PPT_METHODTRACE_V1("", "Lot is not in post process.");
                    PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                        MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                        lotID.identifier );
                    return( RC_POSTPROC_ERROR );
                }
            }
            // Set InPostProcessFlag of Lot to OFF
            objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
            objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Set_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }

            if( TRUE == bFindLockHoldFlag
            && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
            {
                // Release Lot Hold.
                PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );    //D8000028
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return( RC_POSTPROC_ERROR );
                }
            }

            //-----------------------------------------------------------------
            // Call txProcessHoldExecReq
            //-----------------------------------------------------------------
            PPT_METHODTRACE_V1("", "Call txProcessHoldExecReq (TargetType:ProcessHold)");
            pptProcessHoldExecReqResult    strProcessHoldExecReqResult;

            rc = txProcessHoldExecReq( strProcessHoldExecReqResult,
                                       tmpStrObjCommonIn,
                                       lotID,
                                       claimMemo);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "txProcessHoldExecReq() != RC_OK", rc);
                strPostProcessExecReqResult.strResult = strProcessHoldExecReqResult.strResult;
                return( RC_POSTPROC_ERROR );
            }

            if( 1 == lockHoldUseFlag )
            {
                // Hold Lot "LOCK".
                PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );
                if( rc != RC_OK )
                {
                    if( rc != RC_INVALID_LOT_STAT )
                    {
                        PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK returned error.");
                        strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","rc == RC_INVALID_LOT_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            }
            if( 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");
                // Set InPostProcessFlag of Lot to ON
                strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
                rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                strObjCommonIn,
                                                strLot_inPostProcessFlag_Set_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                    strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                    return( rc );
                }
            }
        }
        else
        {
            //Inactive
            //N/A
            PPT_METHODTRACE_V1("","lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }

    //----------------------------------------
    // Call txBankInByPostProcReq
    //----------------------------------------
    else if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_AutoBankIn) )
    {
        //Check lot state
        objLot_state_Get_out strLot_state_Get_out ;
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
        {
            // Active
            if( 1 == lockHoldUseFlag
             || 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
                if( FALSE == bFindLockHoldFlag
                 && FALSE == bInPostProcessFlag )
                {
                    PPT_METHODTRACE_V1("", "Lot is not in post process.");
                    PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                        MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                        lotID.identifier );
                    return( RC_POSTPROC_ERROR );
                }
            }
            // Set InPostProcessFlag of Lot to OFF
            objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
            objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Set_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }

            if( TRUE == bFindLockHoldFlag
            && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
            {
                // Release Lot Hold.
                PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );    //D8000028
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return( RC_POSTPROC_ERROR );
                }
            }

            //-----------------------------------------------------------------
            // Call txBankInByPostProcReq
            //-----------------------------------------------------------------
            PPT_METHODTRACE_V1("", "Call txBankInByPostProcReq (TargetType:AutoBankIn)");
            pptBankInByPostProcReqResult    strBankInByPostProcReqResult;
            pptBankInByPostProcReqInParm    strBankInByPostProcReqInParm;
            strBankInByPostProcReqInParm.lotID = lotID;

            rc = txBankInByPostProcReq( strBankInByPostProcReqResult,
                                        tmpStrObjCommonIn,
                                        strBankInByPostProcReqInParm,
                                        claimMemo);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "txBankInByPostProcReq() != RC_OK", rc);
                strPostProcessExecReqResult.strResult = strBankInByPostProcReqResult.strResult;
                return( RC_POSTPROC_ERROR );
            }

            if( 1 == lockHoldUseFlag )
            {
                // Hold Lot "LOCK".
                PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );
                if( rc != RC_OK )
                {
                    if( rc != RC_INVALID_LOT_STAT )
                    {
                        PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK returned error.");
                        strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","rc == RC_INVALID_LOT_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            }
            if( 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");
                // Set InPostProcessFlag of Lot to ON
                strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
                rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                strObjCommonIn,
                                                strLot_inPostProcessFlag_Set_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                    strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                    return( rc );
                }
            }
        }
        else
        {
            //Inactive
            //N/A
            PPT_METHODTRACE_V1("","lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }

    //----------------------------------------
    // Call txExternalPostProcessExecReq
    //----------------------------------------
    else if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_ExternalPostProcessExecReq) )
    {
        //Check lot state
        objLot_state_Get_out strLot_state_Get_out ;
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
        {
            // Active
            if( 1 == lockHoldUseFlag
             || 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
                if( FALSE == bFindLockHoldFlag
                 && FALSE == bInPostProcessFlag )
                {
                    PPT_METHODTRACE_V1("", "Lot is not in post process.");
                    PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                        MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                        lotID.identifier );
                    return( RC_POSTPROC_ERROR );
                }
            }
            // Set InPostProcessFlag of Lot to OFF
            objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
            objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Set_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }

            if( TRUE == bFindLockHoldFlag
            && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
            {
                // Release Lot Hold.
                PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );    //D8000028
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return( RC_POSTPROC_ERROR );
                }
            }

            //-----------------------------------------------------------------
            // Call txExternalPostProcessExecReq
            //-----------------------------------------------------------------
            PPT_METHODTRACE_V1("", "Call txExternalPostProcessExecReq (TargetType:ExternalPostProcessExecReq)");
            pptExternalPostProcessExecReqResult    strExternalPostProcessExecReqResult;
            pptExternalPostProcessExecReqInParm    strExternalPostProcessExecReqInParm;
            strExternalPostProcessExecReqInParm.lotID      = lotID;
            strExternalPostProcessExecReqInParm.key        = info.dKey;
            strExternalPostProcessExecReqInParm.seqNo      = info.seqNo;
            strExternalPostProcessExecReqInParm.status     = info.status;
            strExternalPostProcessExecReqInParm.extEventID = info.extEventID;

            rc = txExternalPostProcessExecReq( strExternalPostProcessExecReqResult,
                                               tmpStrObjCommonIn,
                                               strExternalPostProcessExecReqInParm,
                                               claimMemo);
            if( rc == RC_OK )
            {
                PPT_METHODTRACE_V2("", "txExternalPostProcessExecReq() == RC_OK", rc);
                rc_extPostProc = RC_EXTPOSTPROC_EXECUTED;
                rc             = RC_OK;
            }
            else if( rc == RC_EXTPOSTPROC_NOT_EXECUTED )
            {
                PPT_METHODTRACE_V2("", "txExternalPostProcessExecReq() == RC_EXTPOSTPROC_NOT_EXECUTED", rc);
                rc_extPostProc = RC_EXTPOSTPROC_NOT_EXECUTED;
                rc             = RC_OK;
            }
            else
            {
                PPT_METHODTRACE_V2("", "txExternalPostProcessExecReq() != RC_OK", rc);
                strPostProcessExecReqResult.strResult = strExternalPostProcessExecReqResult.strResult;
                return( RC_POSTPROC_ERROR );
            }

            if( 1 == lockHoldUseFlag )
            {
                // Hold Lot "LOCK".
                PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );
                if( rc != RC_OK )
                {
                    if( rc != RC_INVALID_LOT_STAT )
                    {
                        PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK returned error.");
                        strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","rc == RC_INVALID_LOT_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            }
            if( 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");
                // Set InPostProcessFlag of Lot to ON
                strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
                rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                strObjCommonIn,
                                                strLot_inPostProcessFlag_Set_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                    strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                    return( rc );
                }
            }
        }
        else
        {
            //Inactive
            //N/A
            PPT_METHODTRACE_V1("","lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }
//DSIV00000201 add end
//DSIV00000214 add start
    else if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_InterFabXfer ) )
    {
        //----------------------------------------
        //  PostProcess Hold(Flag) release
        //----------------------------------------
        // Active
        if( 1 == lockHoldUseFlag
         || 1 == postProcFlagUseFlag )
        {
            PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
            if( FALSE == bFindLockHoldFlag
             && FALSE == bInPostProcessFlag )
            {
                PPT_METHODTRACE_V1("", "Lot is not in post process.");
                PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                    MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                    lotID.identifier );
                return( RC_POSTPROC_ERROR );
            }
        }
        // Set InPostProcessFlag of Lot to OFF
        objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
        objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
        strLot_inPostProcessFlag_Set_in.lotID             = lotID;
        strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
        rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                        strObjCommonIn,
                                        strLot_inPostProcessFlag_Set_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
            strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
            return( rc );
        }

        if( TRUE == bFindLockHoldFlag
        && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
        {
            // Release Lot Hold.
            PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
            rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                return( RC_POSTPROC_ERROR );
            }
        }

        //-----------------------------------------------------------------
        // Call txInterFabXferReserveReq
        //-----------------------------------------------------------------
        PPT_METHODTRACE_V1("", " #### Call txInterFabXferReserveReq");
        pptInterFabXferReserveReqResult  strInterFabXferReserveReqResult;
        pptInterFabXferReserveReqInParm  strInterFabXferReserveReqInParm;
        strInterFabXferReserveReqInParm.category = CIMFWStrDup(SP_InterFab_objectCategory_LOT);
        strInterFabXferReserveReqInParm.objectID = lotID ;
        strInterFabXferReserveReqInParm.strPostProcessActionInfo = info ;

        rc = txInterFabXferReserveReq( strInterFabXferReserveReqResult,
                                       tmpStrObjCommonIn,
                                       strInterFabXferReserveReqInParm,
                                       claimMemo);

        if( rc == RC_INTERFAB_LOTXFER_EXECUTED )
        {
            PPT_METHODTRACE_V2("", "txInterFabXferReserveReq() == RC_INTERFAB_LOTXFER_EXECUTED ", rc);
            rc_interFabXfer = RC_INTERFAB_LOTXFER_EXECUTED;
            rc              = RC_OK;
        }
        else if( rc == RC_OK )
        {
            PPT_METHODTRACE_V2("", "txInterFabXferReserveReq() == RC_OK. ", rc);
            rc_interFabXfer = RC_INTERFAB_LOTXFER_NOT_EXECUTED;
            rc              = RC_OK;
        }
        else
        {
            PPT_METHODTRACE_V2("", "txInterFabXferReserveReq() != RC_OK", rc);
            strPostProcessExecReqResult.strResult = strInterFabXferReserveReqResult.strResult;
            return( RC_POSTPROC_ERROR );
        }

        //----------------------------------------
        //  Do PostProcess Hold(Flag)
        //----------------------------------------
        if( 1 == lockHoldUseFlag )
        {
            // Hold Lot "LOCK".
            PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
            rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );
            if( rc != RC_OK )
            {
                if( rc != RC_INVALID_LOT_STAT )
                {
                    PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                    return( RC_POSTPROC_ERROR );
                }
                else
                {
                    PPT_METHODTRACE_V1("","rc == RC_INVALID_LOT_STAT.");
                    rc = RC_OK;
                    bHoldRelease = FALSE;
                }
            }
        }
        if( 1 == postProcFlagUseFlag )
        {
            PPT_METHODTRACE_V1("","Post Proc Flag is usable.");
            // Set InPostProcessFlag of Lot to ON
            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Set_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }
        }
    }
//DSIV00000214 add end
//DSIV00001830 add start
    else if ( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_WaferStacking ) )
    {
        //--------------------------------------------------------
        //   Call txWaferStackingReq for each Bonding Group
        //--------------------------------------------------------
        objBondingGroup_infoByEqp_GetDR_out strBondingGroup_infoByEqp_GetDR_out;
        objBondingGroup_infoByEqp_GetDR_in strBondingGroup_infoByEqp_GetDR_in;
        strBondingGroup_infoByEqp_GetDR_in.equipmentID        = equipmentID;
        strBondingGroup_infoByEqp_GetDR_in.controlJobID       = controlJobID;
        strBondingGroup_infoByEqp_GetDR_in.bondingMapInfoFlag = FALSE;

        PPT_METHODTRACE_V1( "", "call bondingGroup_infoByEqp_GetDR()" );
        rc = bondingGroup_infoByEqp_GetDR( strBondingGroup_infoByEqp_GetDR_out, strObjCommonIn, strBondingGroup_infoByEqp_GetDR_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "bondingGroup_infoByEqp_GetDR() != RC_OK", rc );
            strPostProcessExecReqResult.strResult = strBondingGroup_infoByEqp_GetDR_out.strResult;
            return rc;
        }

        CORBA::Long bndGrpLen = strBondingGroup_infoByEqp_GetDR_out.strBondingGroupInfoSeq.length();
        for ( CORBA::Long nGrpCnt = 0; nGrpCnt < bndGrpLen; nGrpCnt++ )
        {
            PPT_METHODTRACE_V1("", " #### Call txWaferStackingReq");
            pptWaferStackingReqResult  strWaferStackingReqResult;
            pptWaferStackingReqInParm  strWaferStackingReqInParm;
            strWaferStackingReqInParm.bondingGroupID = strBondingGroup_infoByEqp_GetDR_out.strBondingGroupInfoSeq[nGrpCnt].bondingGroupID;

            rc = txWaferStackingReq( strWaferStackingReqResult,
                                     tmpStrObjCommonIn,
                                     strWaferStackingReqInParm,
                                     claimMemo );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "", "txWaferStackingReq() != RC_OK", rc );
                strPostProcessExecReqResult.strResult = strWaferStackingReqResult.strResult;
                return RC_POSTPROC_ERROR;
            }
        }
    }
//DSIV00001830 add end
//DSIV00002270 add start
    else if ( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_PODelQueuePut ) )
    {
        CORBA::Long envEventCreateType = atoi( getenv( SP_POMAINT_EVENT_CREATE_TYPE ) );
        if ( envEventCreateType == SP_POMaintEventCreateType_ActiveLotEnabled ||
             envEventCreateType == SP_POMaintEventCreateType_Enabled )
        {
            //--------------------------------------------------------
            //   Put Event Queue for PO Maintenance
            //--------------------------------------------------------
            objPoDelQueue_PutDR_out   strPoDelQueue_PutDR_out;
            objPoDelQueue_PutDR_in    strPoDelQueue_PutDR_in;
            strPoDelQueue_PutDR_in.lotID = lotID;
            PPT_METHODTRACE_V1("", "Call poDelQueue_PutDR()");
            rc = poDelQueue_PutDR( strPoDelQueue_PutDR_out, tmpStrObjCommonIn, strPoDelQueue_PutDR_in );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "poDelQueue_PutDR() != RC_OK");
                strPostProcessExecReqResult.strResult = strPoDelQueue_PutDR_out.strResult;
                return( RC_POSTPROC_ERROR );
            }
        }
        else
        {
            rc = RC_OK;
        }
    }
//DSIV00002270 add end
//DSN000015229 Add Start
    else if ( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_PartialCompLotHold ) )
    {
        //Check lot state
        PPT_METHODTRACE_V1("", "SP_PostProcess_ActionID_PartialCompLotHold");
        objLot_state_Get_out strLot_state_Get_out ;
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_state_Get() != RC_OK", rc);
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
        {
            PPT_METHODTRACE_V1("", "lot State is CIMFW_Lot_State_Active");
            // Active
            if( 1 == lockHoldUseFlag || 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
                if( FALSE == bFindLockHoldFlag && FALSE == bInPostProcessFlag )
                {
                    PPT_METHODTRACE_V1("", "Lot is not in post process.");
                    PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                        MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                        lotID.identifier );
                    return( RC_POSTPROC_ERROR );
                }
            }
            // Set InPostProcessFlag of Lot to OFF
            objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
            objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Set_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }

            if( TRUE == bFindLockHoldFlag && ( 1 == lockHoldUseFlag || 0 == lockHoldUseFlag ) )
            {
                // Release Lot Hold.
                PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );    //D8000028
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return( RC_POSTPROC_ERROR );
                }
            }

            //-----------------------------------------------------------------
            // Check if hold target lot is OpeComped lot or OpeStartCancelled lot
            //-----------------------------------------------------------------
            CORBA::Boolean previousPOFlag = FALSE;
            objectIdentifier dummyLotID;
            PPT_METHODTRACE_V1("", "Call lot_previousOperationInfo_Get__101");
            objControlJob_ProcessOperationList_GetDR_out strControlJob_ProcessOperationList_GetDR_out;
            objControlJob_ProcessOperationList_GetDR_in  strControlJob_ProcessOperationList_GetDR_in;
            strControlJob_ProcessOperationList_GetDR_in.lotID        = dummyLotID;
            strControlJob_ProcessOperationList_GetDR_in.controlJobID = controlJobID;
            rc = controlJob_ProcessOperationList_GetDR ( strControlJob_ProcessOperationList_GetDR_out,
                                                         strObjCommonIn,
                                                         strControlJob_ProcessOperationList_GetDR_in );
            if ( rc == RC_NOT_FOUND_LOT_IN_CONTROLJOB )
            {
                PPT_METHODTRACE_V1("", "rc == RC_NOT_FOUND_LOT_IN_CONTROLJOB");
                PPT_METHODTRACE_V1("", "This is OpeStartCancel lot");
                // There is no PO which have input control job -> lot is OpeStartCancelled
                // Get PO from Current PO
                previousPOFlag = FALSE;
            }
            else if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "controlJob_ProcessOperationList_GetDR() != RC_OK", rc);
                strPostProcessExecReqResult.strResult = strControlJob_ProcessOperationList_GetDR_out.strResult;
                return (rc);
            }

            CORBA::Long poLen = strControlJob_ProcessOperationList_GetDR_out.strProcessOperationLots.length();
            CORBA::Long poCnt = 0;
            PPT_METHODTRACE_V2("", "poLen", poLen);
            for ( poCnt = 0; poCnt < poLen; poCnt++ )
            {
                if( 0 == CIMFWStrCmp( lotID.identifier,
                                      strControlJob_ProcessOperationList_GetDR_out.strProcessOperationLots[poCnt].lotID.identifier) )
                {
                    PPT_METHODTRACE_V1("", "lotID = strControlJob_ProcessOperationList_GetDR_out.strProcessOperationLots[poCnt].lotID");
                    PPT_METHODTRACE_V1("", "This is OpeComp lot");
                    // PO which have input control job and lot ID is found
                    previousPOFlag = TRUE;
                }
            }

            //-----------------------------------------------------------------
            // Call txHoldLotReq
            //-----------------------------------------------------------------
            pptHoldLotReqResult strHoldLotReqResult2;
            pptHoldListSequence strHoldListSeq2;
            strHoldListSeq2.length( 1 );

            if ( TRUE == previousPOFlag )
            {
                PPT_METHODTRACE_V1("", "TRUE == previousPOFlag");
                PPT_METHODTRACE_V1("", "Call lot_previousOperationInfo_Get__101");
                objLot_previousOperationInfo_Get_out__101 strLot_previousOperationInfo_Get_out;
                objLot_previousOperationInfo_Get_in strLot_previousOperationInfo_Get_in;
                strLot_previousOperationInfo_Get_in.lotID = lotID;
                rc = lot_previousOperationInfo_Get__101 ( strLot_previousOperationInfo_Get_out,
                                                          strObjCommonIn,
                                                          strLot_previousOperationInfo_Get_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_previousOperationInfo_Get() != RC_OK", rc);
                    strPostProcessExecReqResult.strResult = strLot_previousOperationInfo_Get_out.strResult;
                    return (rc);
                }

                strHoldListSeq2[0].holdType                 = CIMFWStrDup( SP_HoldType_LotHold );
                strHoldListSeq2[0].holdReasonCodeID.identifier          = CIMFWStrDup( SP_Reason_PartialOpeCompHold );
                strHoldListSeq2[0].holdUserID               = tmpStrObjCommonIn.strUser.userID;
                strHoldListSeq2[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Previous );
                strHoldListSeq2[0].routeID                  = strLot_previousOperationInfo_Get_out.routeID;
                strHoldListSeq2[0].operationNumber          = strLot_previousOperationInfo_Get_out.operationNumber;
                strHoldListSeq2[0].claimMemo                = CIMFWStrDup("");
            }
            else
            {
                PPT_METHODTRACE_V1("", "FALSE == previousPOFlag");
                //-----------------------------------------------------------------
                // Call txHoldLotReq
                //-----------------------------------------------------------------
                PPT_METHODTRACE_V1("", "Call lot_currentOperationInfo_Get");
                objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
                rc = lot_currentOperationInfo_Get ( strLot_currentOperationInfo_Get_out,
                                                    strObjCommonIn,
                                                    lotID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_currentOperationInfo_Get() != RC_OK", rc);
                    strPostProcessExecReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult;
                    return (rc);
                }

                strHoldListSeq2[0].holdType                 = CIMFWStrDup( SP_HoldType_LotHold );
                strHoldListSeq2[0].holdReasonCodeID.identifier          = CIMFWStrDup( SP_Reason_PartialOpeCompHold );
                strHoldListSeq2[0].holdUserID               = tmpStrObjCommonIn.strUser.userID;
                strHoldListSeq2[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Current );
                strHoldListSeq2[0].routeID                  = strLot_currentOperationInfo_Get_out.routeID;
                strHoldListSeq2[0].operationNumber          = strLot_currentOperationInfo_Get_out.operationNumber;
                strHoldListSeq2[0].claimMemo                = CIMFWStrDup("");
            }

            PPT_METHODTRACE_V1("", "Call txHoldLotReq (TargetType:PartialCompLotHold)");
            rc = txHoldLotReq( strHoldLotReqResult2,
                               tmpStrObjCommonIn,
                               lotID,
                               strHoldListSeq2 );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "txHoldLotReq() != RC_OK", rc);
                strPostProcessExecReqResult.strResult = strHoldLotReqResult2.strResult;
                return( RC_POSTPROC_ERROR );
            }

            // set return structure
            strPostProcessExecReqResult.strResult = strHoldLotReqResult2.strResult;

            if( 1 == lockHoldUseFlag )
            {
                // Hold Lot "LOCK".
                PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );
                if( rc != RC_OK )
                {
                    if( rc != RC_INVALID_LOT_STAT )
                    {
                        PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK returned error.");
                        strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","rc == RC_INVALID_LOT_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            }
            if( 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");
                // Set InPostProcessFlag of Lot to ON
                strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
                rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                strObjCommonIn,
                                                strLot_inPostProcessFlag_Set_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                    strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                    return( rc );
                }
            }
        }
        else
        {
            //Inactive
            //N/A
            PPT_METHODTRACE_V1("","lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }
    else if ( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_CollectedDataActionByPJ ) )
    {
        //Check lot state
        PPT_METHODTRACE_V1("", "postProcID is SP_PostProcess_ActionID_CollectedDataActionByPJ");
        objLot_state_Get_out strLot_state_Get_out ;
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
        {
            PPT_METHODTRACE_V1("", "lotState is CIMFW_Lot_State_Active");
            // Active
            if( 1 == lockHoldUseFlag || 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
                if( FALSE == bFindLockHoldFlag && FALSE == bInPostProcessFlag )
                {
                    PPT_METHODTRACE_V1("", "Lot is not in post process.");
                    PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                        MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                        lotID.identifier );
                    return( RC_POSTPROC_ERROR );
                }
            }
            // Set InPostProcessFlag of Lot to OFF
            objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
            objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Set_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }

            if( TRUE == bFindLockHoldFlag && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
            {
                // Release Lot Hold.
                PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );    //D8000028
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return( RC_POSTPROC_ERROR );
                }
            }

            //-----------------------------------------------------------------
            // Call txCollectedDataActionByPostProcReq
            //-----------------------------------------------------------------
            PPT_METHODTRACE_V1("", "Call txCollectedDataActionByPJReq (TargetType:CollectedDataActionByPJ)");
            pptCollectedDataActionByPJReqResult   strCollectedDataActionByPJReqResult;
            pptCollectedDataActionByPJReqInParm   strCollectedDataActionByPJReqInParm;
            strCollectedDataActionByPJReqInParm.equipmentID  = equipmentID;
            strCollectedDataActionByPJReqInParm.controlJobID = controlJobID;
            strCollectedDataActionByPJReqInParm.lotID        = lotID;

            rc = txCollectedDataActionByPJReq( strCollectedDataActionByPJReqResult,
                                               tmpStrObjCommonIn,
                                               strCollectedDataActionByPJReqInParm,
                                               claimMemo);
            if( rc == RC_SPECCHECK_ERROR )
            {
                PPT_METHODTRACE_V1("", "rc == RC_SPECCHECK_ERROR");
                strPostProcessExecReqResult.strResult = strCollectedDataActionByPJReqResult.strResult;
                return( RC_OK );
            }
            else if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "txCollectedDataActionByPJReq() != RC_OK", rc);
                strPostProcessExecReqResult.strResult = strCollectedDataActionByPJReqResult.strResult;
                return( RC_POSTPROC_ERROR );
            }

            // set return structure
            strPostProcessExecReqResult.strResult =  strCollectedDataActionByPJReqResult.strResult;
            if( 1 == lockHoldUseFlag )
            {
                // Hold Lot "LOCK".
                PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );
                if( rc != RC_OK )
                {
                    if( rc != RC_INVALID_LOT_STAT )
                    {
                        PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK returned error.");
                        strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","rc == RC_INVALID_LOT_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            }
            if( 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");
                // Set InPostProcessFlag of Lot to ON
                strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
                rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                strObjCommonIn,
                                                strLot_inPostProcessFlag_Set_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                    strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                    return( rc );
                }
            }
        }
        else
        {
            //Inactive
            //N/A
            PPT_METHODTRACE_V1("","lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }
//DSN000015229 Add End
//DSN000020767 Add Start
    else if ( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_AutoDispatchControl ) )
    {
        //Check lot state
        PPT_METHODTRACE_V1("", "postProcID is SP_PostProcess_ActionID_AutoDispatchControl");
        objLot_state_Get_out strLot_state_Get_out ;
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
        {
            PPT_METHODTRACE_V1("", "lot State is CIMFW_Lot_State_Active");
            // Active
            if( 1 == lockHoldUseFlag || 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
                if( FALSE == bFindLockHoldFlag && FALSE == bInPostProcessFlag )
                {
                    PPT_METHODTRACE_V1("", "Lot is not in post process.");
                    PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                        MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                        lotID.identifier );
                    return( RC_POSTPROC_ERROR );
                }
            }
            // Set InPostProcessFlag of Lot to OFF
            objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
            objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Set_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }

            if( TRUE == bFindLockHoldFlag && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
            {
                // Release Lot Hold.
                PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );    //D8000028
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                    strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                    return( RC_POSTPROC_ERROR );
                }
            }

            PPT_METHODTRACE_V1( "", "Call lot_previousOperationInfo_Get__101" );
            objLot_previousOperationInfo_Get_out__101 strLot_previousOperationInfo_Get_out;
            objLot_previousOperationInfo_Get_in strLot_previousOperationInfo_Get_in;
            strLot_previousOperationInfo_Get_in.lotID = lotID;
            rc = lot_previousOperationInfo_Get__101 ( strLot_previousOperationInfo_Get_out,
                                                      strObjCommonIn,
                                                      strLot_previousOperationInfo_Get_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "", "lot_previousOperationInfo_Get() != RC_OK", rc );
                strPostProcessExecReqResult.strResult = strLot_previousOperationInfo_Get_out.strResult;
                return (rc);
            }

            //--------------------------------------------
            //  Get Auto Dispatch Control Information
            //--------------------------------------------
            PPT_METHODTRACE_V1( "", "Call autoDispatchControl_info_GetDR" );
            objAutoDispatchControl_info_GetDR_in strAutoDispatchControl_info_GetDR_in;
            strAutoDispatchControl_info_GetDR_in.lotID           = lotID;
            strAutoDispatchControl_info_GetDR_in.routeID         = strLot_previousOperationInfo_Get_out.routeID;
            strAutoDispatchControl_info_GetDR_in.operationNumber = strLot_previousOperationInfo_Get_out.operationNumber;

            objAutoDispatchControl_info_GetDR_out strAutoDispatchControl_info_GetDR_out;
            rc = autoDispatchControl_info_GetDR( strAutoDispatchControl_info_GetDR_out, strObjCommonIn, strAutoDispatchControl_info_GetDR_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "autoDispatchControl_info_GetDR() != RC_OK" );
                strPostProcessExecReqResult.strResult = strAutoDispatchControl_info_GetDR_out.strResult;
                return rc;
            }

            if( strAutoDispatchControl_info_GetDR_out.strLotAutoDispatchControlInfoSeq.length() > 0 )
            {
                if( ( CIMFWStrCmp( strAutoDispatchControl_info_GetDR_out.strLotAutoDispatchControlInfoSeq[0].routeID.identifier, strAutoDispatchControl_info_GetDR_in.routeID.identifier ) == 0 ) &&
                    ( CIMFWStrCmp( strAutoDispatchControl_info_GetDR_out.strLotAutoDispatchControlInfoSeq[0].operationNumber, strAutoDispatchControl_info_GetDR_in.operationNumber ) == 0 ) &&
                    ( strAutoDispatchControl_info_GetDR_out.strLotAutoDispatchControlInfoSeq[0].singleTriggerFlag == TRUE ) )
                {
                    PPT_METHODTRACE_V4( "", "Auto Dispatch Control Information Auto Delete", lotID.identifier, strAutoDispatchControl_info_GetDR_in.routeID.identifier, strAutoDispatchControl_info_GetDR_in.operationNumber );
                    pptAutoDispatchControlUpdateReqInParm strAutoDispatchControlUpdateReqInParm;
                    strAutoDispatchControlUpdateReqInParm.strLotAutoDispatchControlUpdateInfoSeq.length( 1 );

                    strAutoDispatchControlUpdateReqInParm.strLotAutoDispatchControlUpdateInfoSeq[0].lotID = lotID;
                    strAutoDispatchControlUpdateReqInParm.strLotAutoDispatchControlUpdateInfoSeq[0].strAutoDispatchControlUpdateInfoSeq.length( 1 );
                    strAutoDispatchControlUpdateReqInParm.strLotAutoDispatchControlUpdateInfoSeq[0].strAutoDispatchControlUpdateInfoSeq[0].updateMode        = CIMFWStrDup( SP_AutoDispatchControl_AutoDelete );
                    strAutoDispatchControlUpdateReqInParm.strLotAutoDispatchControlUpdateInfoSeq[0].strAutoDispatchControlUpdateInfoSeq[0].routeID           = strAutoDispatchControl_info_GetDR_out.strLotAutoDispatchControlInfoSeq[0].routeID;
                    strAutoDispatchControlUpdateReqInParm.strLotAutoDispatchControlUpdateInfoSeq[0].strAutoDispatchControlUpdateInfoSeq[0].operationNumber   = CIMFWStrDup( strAutoDispatchControl_info_GetDR_out.strLotAutoDispatchControlInfoSeq[0].operationNumber );
                    strAutoDispatchControlUpdateReqInParm.strLotAutoDispatchControlUpdateInfoSeq[0].strAutoDispatchControlUpdateInfoSeq[0].singleTriggerFlag = strAutoDispatchControl_info_GetDR_out.strLotAutoDispatchControlInfoSeq[0].singleTriggerFlag;
                    strAutoDispatchControlUpdateReqInParm.strLotAutoDispatchControlUpdateInfoSeq[0].strAutoDispatchControlUpdateInfoSeq[0].description       = CIMFWStrDup( strAutoDispatchControl_info_GetDR_out.strLotAutoDispatchControlInfoSeq[0].description );
    
                    pptAutoDispatchControlUpdateReqResult strAutoDispatchControlUpdateReqResult;
                    rc = txAutoDispatchControlUpdateReq( strAutoDispatchControlUpdateReqResult,
                                                         tmpStrObjCommonIn,
                                                         strAutoDispatchControlUpdateReqInParm,
                                                         claimMemo );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2( "", "txAutoDispatchControlUpdateReq() != RC_OK", rc );
                        strPostProcessExecReqResult.strResult = strAutoDispatchControlUpdateReqResult.strResult;
                        return RC_POSTPROC_ERROR;
                    }
                }
            }

            if( 1 == lockHoldUseFlag )
            {
                // Hold Lot "LOCK".
                PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
                rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );
                if( rc != RC_OK )
                {
                    if( rc != RC_INVALID_LOT_STAT )
                    {
                        PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK returned error.");
                        strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","rc == RC_INVALID_LOT_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            }
            if( 1 == postProcFlagUseFlag )
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");
                // Set InPostProcessFlag of Lot to ON
                strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
                rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                strObjCommonIn,
                                                strLot_inPostProcessFlag_Set_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                    strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                    return( rc );
                }
            }
        }
        else
        {
            //Inactive
            //N/A
            PPT_METHODTRACE_V1("","lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }
//DSN000020767 Add End
//DSN000041636 Add Start
    else if ( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_RunWaferInfoUpdate ) )
    {
        PPT_METHODTRACE_V1("", "postProcID is SP_PostProcess_ActionID_RunWaferInfoUpdate");
        // Get additional parameters
        PPT_METHODTRACE_V1("","Call postProcessAdditionalInfoGetDR");
        objPostProcessAdditionalInfoGetDR_out strPostProcessAdditionalInfoGetDR_out;
        objPostProcessAdditionalInfoGetDR_in  strPostProcessAdditionalInfoGetDR_in;
        strPostProcessAdditionalInfoGetDR_in.dKey = info.dKey;
        strPostProcessAdditionalInfoGetDR_in.seqNo = info.seqNo;

        rc = postProcessAdditionalInfoGetDR( strPostProcessAdditionalInfoGetDR_out,
                                             strObjCommonIn,
                                             strPostProcessAdditionalInfoGetDR_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","postProcessAdditionalInfoGetDR() != RC_OK");
            strPostProcessExecReqResult.strResult = strPostProcessAdditionalInfoGetDR_out.strResult;
            return( rc );
        }
        PPT_METHODTRACE_V2("","strPostProcessAdditionalInfoSeq.length = ", strPostProcessAdditionalInfoGetDR_out.strPostProcessAdditionalInfoSeq.length());
        CORBA::ULong i = 0;
        CORBA::ULong processWaferCnt =  0;
        CORBA::ULong opeStartCnt =  0;
        for (i = 0; i < strPostProcessAdditionalInfoGetDR_out.strPostProcessAdditionalInfoSeq.length(); i++)
        {
            if (0 == CIMFWStrCmp (strPostProcessAdditionalInfoGetDR_out.strPostProcessAdditionalInfoSeq[i].name, SP_ThreadSpecificData_Key_RunWaferCnt))
            {
                // get runWaferCnt
                PPT_METHODTRACE_V1("","found RunWaferCnt");
                processWaferCnt = atoi(strPostProcessAdditionalInfoGetDR_out.strPostProcessAdditionalInfoSeq[i].value);
            }
            else if (0 == CIMFWStrCmp (strPostProcessAdditionalInfoGetDR_out.strPostProcessAdditionalInfoSeq[i].name, SP_ThreadSpecificData_Key_OpeStartCnt))
            {
                // get opeStartCnt
                PPT_METHODTRACE_V1("","found OpeStartCnt");
                opeStartCnt = atoi(strPostProcessAdditionalInfoGetDR_out.strPostProcessAdditionalInfoSeq[i].value);
            }
        }
        
        if (processWaferCnt > 0 || opeStartCnt > 0)
        {
//DSN000049350 Add Start
            // Get required equipment lock mode
            objObject_lockMode_Get_out strObject_lockMode_Get_out;
            objObject_lockMode_Get_in  strObject_lockMode_Get_in;
            strObject_lockMode_Get_in.objectID           = equipmentID;
            strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
            strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup(SP_PostProcess_ActionID_RunWaferInfoUpdate); // RunWaferInfoUpdate
            strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

            PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
            rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                      strObjCommonIn,
                                      strObject_lockMode_Get_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
                strPostProcessExecReqResult.strResult = strObject_lockMode_Get_out.strResult;
                return( rc );
            }
            
            CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
            PPT_METHODTRACE_V2( "", "lockMode", lockMode );
            
            if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
            {
                PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
                // Lock Equipment Main Object
                stringSequence dummySeq;
                dummySeq.length(0);
                
                objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
                objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
                strAdvanced_object_Lock_in.objectID   = equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
                strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
                strAdvanced_object_Lock_in.keySeq     = dummySeq;

                PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strPostProcessExecReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
                /*--------------------------------*/
                /*   Lock Equipment object        */
                /*--------------------------------*/
                objObject_Lock_out strObject_Lock_out;
                rc = object_Lock( strObject_Lock_out, strObjCommonIn, equipmentID, SP_ClassName_PosMachine );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2(" ", "##### RC_OK != object_Lock()", rc);
                    strPostProcessExecReqResult.strResult = strObject_Lock_out.strResult;
                    return( rc );
                }
            } //DSN000049350
            
            PPT_METHODTRACE_V1("","Call equipment_usageCount_UpdateForPostProc");
            objEquipment_usageCount_UpdateForPostProc_out strEquipment_usageCount_UpdateForPostProc_out;
            objEquipment_usageCount_UpdateForPostProc_in  strEquipment_usageCount_UpdateForPostProc_in;
            strEquipment_usageCount_UpdateForPostProc_in.equipmentID = equipmentID;
            strEquipment_usageCount_UpdateForPostProc_in.waferCnt = processWaferCnt;
            strEquipment_usageCount_UpdateForPostProc_in.opeStartCnt = opeStartCnt;

            // set new equipment PM related attributes
            if (0 == CIMFWStrCmp(info.txID, "TXTRC002") ||    //TxOpeStartReq
//DSN000085770                0 == CIMFWStrCmp(info.txID, "TXTRC054"))      //TxOpeStartForInternalBufferReq
                0 == CIMFWStrCmp(info.txID, "TXTRC054") ||    //TxOpeStartForInternalBufferReq   //DSN000085770
                0 == CIMFWStrCmp(info.txID, "TXPDC042"))      //TxDurableOperationStartReq       //DSN000085770
            {
                PPT_METHODTRACE_V2("","Called from OpeStart", info.txID);
                strEquipment_usageCount_UpdateForPostProc_in.action = CIMFWStrDup(SP_EqpAttr_Update_Action_Increase);
            }
            else if (0 == CIMFWStrCmp(info.txID, "TXTRC003") ||      //TxOpeStartCancelReq
                     0 == CIMFWStrCmp(info.txID, "TXTRC061") ||      //TxOpeStartCancelForInternalBufferReq
                     0 == CIMFWStrCmp(info.txID, "TXEWC015") ||      //TxPartialOpeCompWithDataReq
//DSN000085770                     0 == CIMFWStrCmp(info.txID, "TXEWC016"))        //TxPartialOpeCompForInternalBufferReq
                     0 == CIMFWStrCmp(info.txID, "TXEWC016") ||      //TxPartialOpeCompForInternalBufferReq   //DSN000085770
                     0 == CIMFWStrCmp(info.txID, "TXPDC043"))        //TxDurableOperationStartCancelReq       //DSN000085770
            {
                PPT_METHODTRACE_V2("","Called from OpeStartCancel", info.txID);
                strEquipment_usageCount_UpdateForPostProc_in.action = CIMFWStrDup(SP_EqpAttr_Update_Action_Decrease);
            }
            rc = equipment_usageCount_UpdateForPostProc( strEquipment_usageCount_UpdateForPostProc_out,
                                                         strObjCommonIn,
                                                         strEquipment_usageCount_UpdateForPostProc_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("","equipment_usageCount_UpdateForPostProc() != RC_OK");
                strPostProcessExecReqResult.strResult = strEquipment_usageCount_UpdateForPostProc_out.strResult;
                return( rc );
            }
            
        }
    }
//DSN000050720 Add Start
    else if ( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_ParallelExecFinalize ) )
    {
        PPT_METHODTRACE_V1("", "postProcID is SP_PostProcess_ActionID_ParallelExecFinalize");
        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, cassetteID, SP_ClassName_PosCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() rc != RC_OK", rc);
            strPostProcessExecReqResult.strResult = strObject_Lock_out.strResult;
            return( RC_POSTPROC_ERROR );
        }

        //-------------------------------------------
        // Finalize action for cassette
        //-------------------------------------------
        PPT_METHODTRACE_V1("","Call cassette_status_FinalizeForPostProcess()");
        objCassette_status_FinalizeForPostProcess_out strCassette_status_FinalizeForPostProcess_out;
        objCassette_status_FinalizeForPostProcess_in  strCassette_status_FinalizeForPostProcess_in;
        strCassette_status_FinalizeForPostProcess_in.cassetteID = cassetteID;

        rc = cassette_status_FinalizeForPostProcess( strCassette_status_FinalizeForPostProcess_out,
                                                     strObjCommonIn,
                                                     strCassette_status_FinalizeForPostProcess_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("","cassette_status_FinalizeForPostProcess() != RC_OK", rc);
            strPostProcessExecReqResult.strResult = strCassette_status_FinalizeForPostProcess_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
    }
//DSN000050720 Add End
//DSN000081739 Add Start
    else if ( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_EqpMonitorEval ) )
    {
        PPT_METHODTRACE_V1("","postProcID is EqpMonitorEval");
        //Check lot state
        objLot_state_Get_out strLot_state_Get_out ;
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
        {
            // Active
            PPT_METHODTRACE_V1("","lot_state is Active.");

            if ( 0 == CIMFWStrCmp( getenv(SP_EQPMONITOR_SWITCH), "1" ) )
            {
                PPT_METHODTRACE_V1("","SP_EQPMONITOR_SWITCH is 1");
                //Check Lot type
                objLot_lotType_Get_out strLot_lotType_Get_out;
                objLot_lotType_Get_in  strLot_lotType_Get_in;
                strLot_lotType_Get_in.lotID = lotID;
                rc = lot_lotType_Get(strLot_lotType_Get_out,strObjCommonIn,strLot_lotType_Get_in);
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_lotType_Get() != RC_OK", rc);
                    strPostProcessExecReqResult.strResult = strLot_lotType_Get_out.strResult;
                    return (rc);
                }

                if ( 0 == CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_EquipmentMonitorLot)
                  || 0 == CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_DummyLot))
                {
                    PPT_METHODTRACE_V1("","lotType is Equipment Monitor or Dummy.");
                    objLot_eqpMonitorJob_Get_out strLot_eqpMonitorJob_Get_out;
                    objLot_eqpMonitorJob_Get_in  strLot_eqpMonitorJob_Get_in;
                    strLot_eqpMonitorJob_Get_in.lotID = lotID;
                    rc = lot_eqpMonitorJob_Get(strLot_eqpMonitorJob_Get_out,strObjCommonIn,strLot_eqpMonitorJob_Get_in);
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_eqpMonitorJob_Get() rc != RC_OK", rc);
                        strPostProcessExecReqResult.strResult = strLot_eqpMonitorJob_Get_out.strResult;
                        return( RC_POSTPROC_ERROR );
                    }

                    if( 0 == CIMFWStrLen(strLot_eqpMonitorJob_Get_out.strEqpMonitorJobLotInfo.eqpMonitorJobID.identifier)
                     || 0 == strLot_eqpMonitorJob_Get_out.strEqpMonitorJobLotInfo.result)
                    {
                        // Post process action "EqpMonitorEval" can be skipped
                        //  - Lot isn't involved in EqpMonitor job
                        //  - No violation in Spec/SPC check
                        PPT_METHODTRACE_V1("", "EqpMonitorEval can be skipped");
                        rc = RC_OK;
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "EqpMonitorEval can not be skipped");
                        if( 1 == lockHoldUseFlag
                         || 1 == postProcFlagUseFlag )
                        {
                            PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
                            if( FALSE == bFindLockHoldFlag
                             && FALSE == bInPostProcessFlag )
                            {
                                PPT_METHODTRACE_V1("", "Lot is not in post process.");
                                PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                                    MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                                    lotID.identifier );
                                return( RC_POSTPROC_ERROR );
                            }
                        }
                        // Set InPostProcessFlag of Lot to OFF
                        objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
                        objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
                        strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                        strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
                        rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                        strObjCommonIn,
                                                        strLot_inPostProcessFlag_Set_in );
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                            strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                            return( RC_POSTPROC_ERROR );
                        }

                        if( TRUE == bFindLockHoldFlag
                        && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
                        {
                            // Release Lot Hold.
                            PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
                            rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );
                            if( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                                strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                                return( RC_POSTPROC_ERROR );
                            }
                        }

                        //Call txEqpMonitorEvaluateReq to the object Lot.
                        pptEqpMonitorEvaluateReqResult strEqpMonitorEvaluateReqResult;
                        pptEqpMonitorEvaluateReqInParm strEqpMonitorEvaluateReqInParm;
                        strEqpMonitorEvaluateReqInParm.equipmentID  = equipmentID;
                        strEqpMonitorEvaluateReqInParm.controlJobID = controlJobID;
                        strEqpMonitorEvaluateReqInParm.lotID        = lotID;
                        rc = txEqpMonitorEvaluateReq(strEqpMonitorEvaluateReqResult,tmpStrObjCommonIn,strEqpMonitorEvaluateReqInParm,claimMemo);
                        if(rc != RC_OK)
                        {
                            PPT_METHODTRACE_V2("", "txEqpMonitorEvaluateReq() rc != RC_OK", rc);
                            strPostProcessExecReqResult.strResult = strEqpMonitorEvaluateReqResult.strResult;
                            return RC_POSTPROC_ERROR;
                        }
                        if( 1 == lockHoldUseFlag )
                        {
                            // Hold Lot "LOCK".
                            PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
                            rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );
                            if( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "txHoldLotReq() != RC_OK", rc);
                                if( rc != RC_INVALID_LOT_STAT )
                                {
                                    PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK returned error.");
                                    strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                                    return( RC_POSTPROC_ERROR );
                                }
                                else
                                {
                                    PPT_METHODTRACE_V1("","rc == RC_INVALID_LOT_STAT.");
                                    rc = RC_OK;
                                    bHoldRelease = FALSE;
                                }
                            }
                        }
                        if( 1 == postProcFlagUseFlag )
                        {
                            PPT_METHODTRACE_V1("","Post Proc Flag is usable.");
                            // Set InPostProcessFlag of Lot to ON
                            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
                            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                            strObjCommonIn,
                                                            strLot_inPostProcessFlag_Set_in );
                            if( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                                return( RC_POSTPROC_ERROR );
                            }
                        }
                    }
                }
            }
            else
            {
                //SP_EQPMONITOR_SWITCH=0
                PPT_METHODTRACE_V1("","SP_EQPMONITOR_SWITCH=0. EqpMonitorEval can be skipped.");
                rc = RC_OK;
            }
        }
        else
        {
            //Inactive
            //N/A
            PPT_METHODTRACE_V1("","lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }
    else if ( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_EqpMonitorJobLotRemove ) )
    {
        PPT_METHODTRACE_V1("","postProcID is EqpMonitorJobLotRemove");
        //Check lot state
        objLot_state_Get_out strLot_state_Get_out ;
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
        {
            PPT_METHODTRACE_V1("","lot state is Active.");
            // Active
            if ( 0 == CIMFWStrCmp( getenv(SP_EQPMONITOR_SWITCH), "1" ) )
            {
                PPT_METHODTRACE_V1("","SP_EQPMONITOR_SWITCH is 1.");
                //Check Lot type
                objLot_lotType_Get_out strLot_lotType_Get_out;
                objLot_lotType_Get_in  strLot_lotType_Get_in;
                strLot_lotType_Get_in.lotID = lotID;
                rc = lot_lotType_Get(strLot_lotType_Get_out,strObjCommonIn,strLot_lotType_Get_in);
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_lotType_Get() != RC_OK", rc);
                    strPostProcessExecReqResult.strResult = strLot_lotType_Get_out.strResult;
                    return (rc);
                }

                if ( 0 == CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_EquipmentMonitorLot)
                  || 0 == CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_DummyLot))
                {
                    PPT_METHODTRACE_V1("","lotType is Equipment Monitor or Dummy.");
                    objLot_eqpMonitorJob_Get_out strLot_eqpMonitorJob_Get_out;
                    objLot_eqpMonitorJob_Get_in  strLot_eqpMonitorJob_Get_in;
                    strLot_eqpMonitorJob_Get_in.lotID = lotID;
                    rc = lot_eqpMonitorJob_Get(strLot_eqpMonitorJob_Get_out,strObjCommonIn,strLot_eqpMonitorJob_Get_in);
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_eqpMonitorJob_Get() rc != RC_OK", rc);
                        strPostProcessExecReqResult.strResult = strLot_eqpMonitorJob_Get_out.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    if( 0 == CIMFWStrLen(strLot_eqpMonitorJob_Get_out.strEqpMonitorJobLotInfo.eqpMonitorJobID.identifier)
                     || FALSE == strLot_eqpMonitorJob_Get_out.strEqpMonitorJobLotInfo.exitFlag )
                    {
                        // Post process action "EqpMonitorJobLotRemove" can be skipped
                        //  - Lot isn't involved in EqpMonitor job
                        //  - Not Exit label operation
                        PPT_METHODTRACE_V1("", "EqpMonitorJobLotRemove can be skipped");
                        rc = RC_OK;
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "EqpMonitorJobLotRemove can not be skipped");
                        if( 1 == lockHoldUseFlag || 1 == postProcFlagUseFlag )
                        {
                            PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
                            if( FALSE == bFindLockHoldFlag && FALSE == bInPostProcessFlag )
                            {
                                PPT_METHODTRACE_V1("", "Lot is not in post process.");
                                PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                                    MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                                    lotID.identifier );
                                return( RC_POSTPROC_ERROR );
                            }
                        }
                        // Set InPostProcessFlag of Lot to OFF
                        objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
                        objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
                        strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                        strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
                        rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                        strObjCommonIn,
                                                        strLot_inPostProcessFlag_Set_in );
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                            strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                            return( rc );
                        }

                        if( TRUE == bFindLockHoldFlag && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
                        {
                            // Release Lot Hold.
                            PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
                            rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );
                            if( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                                strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                                return( RC_POSTPROC_ERROR );
                            }
                        }

                        //txEqpMonitorJobLotRemoveReq to the object Lot.
                        pptEqpMonitorJobLotRemoveReqResult strEqpMonitorJobLotRemoveReqResult;
                        pptEqpMonitorJobLotRemoveReqInParm strEqpMonitorJobLotRemoveReqInParm;
                        strEqpMonitorJobLotRemoveReqInParm.equipmentID  = equipmentID;
                        strEqpMonitorJobLotRemoveReqInParm.controlJobID = controlJobID;
                        strEqpMonitorJobLotRemoveReqInParm.lotID        = lotID;

                        rc = txEqpMonitorJobLotRemoveReq(strEqpMonitorJobLotRemoveReqResult,tmpStrObjCommonIn,strEqpMonitorJobLotRemoveReqInParm,claimMemo);
                        if(rc != RC_OK)
                        {
                            PPT_METHODTRACE_V2("", "txEqpMonitorJobLotRemoveReq() rc != RC_OK", rc);
                            strPostProcessExecReqResult.strResult = strEqpMonitorJobLotRemoveReqResult.strResult;
                            return RC_POSTPROC_ERROR;
                        }
                        if( 1 == lockHoldUseFlag )
                        {
                            // Hold Lot "LOCK".
                            PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
                            rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );
                            if( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "txHoldLotReq() != RC_OK", rc);
                                if( rc != RC_INVALID_LOT_STAT )
                                {
                                    PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK returned error.");
                                    strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                                    return( RC_POSTPROC_ERROR );
                                }
                                else
                                {
                                    PPT_METHODTRACE_V1("","rc == RC_INVALID_LOT_STAT.");
                                    rc = RC_OK;
                                    bHoldRelease = FALSE;
                                }
                            }
                        }
                        if( 1 == postProcFlagUseFlag )
                        {
                            PPT_METHODTRACE_V1("","Post Proc Flag is usable.");
                            objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
                            objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
                            // Set InPostProcessFlag of Lot to ON
                            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
                            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                            strObjCommonIn,
                                                            strLot_inPostProcessFlag_Set_in );
                            if( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                                return( RC_POSTPROC_ERROR );
                            }
                        }
                    }
                }
            }
        }
        else
        {
            //Inactive
            //N/A
            PPT_METHODTRACE_V1("","lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }
//DSN000081739 Add End
//DSN000085698 Add Start
    else if ( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_EqpMonitorUsedCountUp ) )
    {
        PPT_METHODTRACE_V1("","postProcID is EqpMonitorUsedCountUp");
        //Check lot state
        objLot_state_Get_out strLot_state_Get_out ;
        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK returned error.");
            strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
            return( RC_POSTPROC_ERROR );
        }
        if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ) )
        {
            // Active
            PPT_METHODTRACE_V1("","lot_state is Active.");

            if ( 0 == CIMFWStrCmp( getenv(SP_EQPMONITOR_SWITCH), "1" ) )
            {
                PPT_METHODTRACE_V1("","SP_EQPMONITOR_SWITCH is 1");
                //Check Lot type
                objLot_lotType_Get_out strLot_lotType_Get_out;
                objLot_lotType_Get_in  strLot_lotType_Get_in;
                strLot_lotType_Get_in.lotID = lotID;
                rc = lot_lotType_Get(strLot_lotType_Get_out,strObjCommonIn,strLot_lotType_Get_in);
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_lotType_Get() != RC_OK", rc);
                    strPostProcessExecReqResult.strResult = strLot_lotType_Get_out.strResult;
                    return (rc);
                }

                if ( 0 == CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_EquipmentMonitorLot)
                  || 0 == CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_DummyLot))
                {
                    PPT_METHODTRACE_V1("","lotType is Equipment Monitor or Dummy.");
                    objLot_eqpMonitorOperationLabel_Get_out strLot_eqpMonitorOperationLabel_Get_out;
                    objLot_eqpMonitorOperationLabel_Get_in  strLot_eqpMonitorOperationLabel_Get_in;
                    strLot_eqpMonitorOperationLabel_Get_in.lotID = lotID;
                    rc = lot_eqpMonitorOperationLabel_Get( strLot_eqpMonitorOperationLabel_Get_out,
                                                           tmpStrObjCommonIn,
                                                           strLot_eqpMonitorOperationLabel_Get_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_eqpMonitorOperationLabel_Get() != RC_OK", rc);
                        strPostProcessExecReqResult.strResult = strLot_eqpMonitorOperationLabel_Get_out.strResult;
                        return (rc);
                    }
                    CORBA::Boolean bMonitorLabel = FALSE;
                    for ( CORBA::ULong x=0; x<strLot_eqpMonitorOperationLabel_Get_out.strEqpMonitorLabelInfoSeq.length(); x++ )
                    {
                        PPT_METHODTRACE_V2("","Loop through strEqpMonitorLabelInfoSeq",x);
                        if( 0 == CIMFWStrCmp(strLot_eqpMonitorOperationLabel_Get_out.strEqpMonitorLabelInfoSeq[x].operationLabel,SP_EqpMonitor_OpeLabel_Monitor) )
                        {
                            PPT_METHODTRACE_V1("","Found Monitor label.");
                            bMonitorLabel = TRUE;
                            break;
                        }
                    }

                    if ( FALSE == bMonitorLabel )
                    {
                        // Post process action "EqpMonitorUsedCountUp" can be skipped
                        //  - Lot's label is not monitor
                        PPT_METHODTRACE_V1("", "EqpMonitorUsedCountUp can be skipped");
                        rc = RC_OK;
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "Update Equipmet Monitor count");
                        if( 1 == lockHoldUseFlag
                         || 1 == postProcFlagUseFlag )
                        {
                            PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
                            if( FALSE == bFindLockHoldFlag
                             && FALSE == bInPostProcessFlag )
                            {
                                PPT_METHODTRACE_V1("", "Lot is not in post process.");
                                PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                                    MSG_LOT_NOT_INPOSTPROCESS, RC_LOT_NOT_INPOSTPROCESS,
                                                    lotID.identifier );
                                return( RC_POSTPROC_ERROR );
                            }
                        }
                        // Set InPostProcessFlag of Lot to OFF
                        objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
                        objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
                        strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                        strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
                        rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                        strObjCommonIn,
                                                        strLot_inPostProcessFlag_Set_in );
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                            strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                            return( RC_POSTPROC_ERROR );
                        }

                        if( TRUE == bFindLockHoldFlag
                        && (1 == lockHoldUseFlag || 0 == lockHoldUseFlag) )
                        {
                            // Release Lot Hold.
                            PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
                            rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );
                            if( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("","txHoldLotReleaseReq() != RC_OK returned error.");
                                strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                                return( RC_POSTPROC_ERROR );
                            }
                        }
                        //Increment Equipment Monitor used count by 1 for all lot's wafers.
                        objEqpMonitorWaferUsedCountUpdate_out      strEqpMonitorWaferUsedCountUpdate_out;
                        objEqpMonitorWaferUsedCountUpdate_in       strEqpMonitorWaferUsedCountUpdate_in;
                        strEqpMonitorWaferUsedCountUpdate_in.lotID    = lotID;
                        strEqpMonitorWaferUsedCountUpdate_in.action   = CIMFWStrDup(SP_EQPMONUSEDCNT_ACTION_INCREMENT);
                        rc = eqpMonitorWaferUsedCountUpdate(strEqpMonitorWaferUsedCountUpdate_out,strObjCommonIn,strEqpMonitorWaferUsedCountUpdate_in);
                        if (rc != RC_OK)
                        {
                            PPT_METHODTRACE_V1("", "rc != RC_OK");
                            strPostProcessExecReqResult.strResult = strEqpMonitorWaferUsedCountUpdate_out.strResult ;
                            return(rc);
                        }
                        // Create Operation History
                        objEqpMonitorWaferUsedCountUpdateEvent_Make_out  strEqpMonitorWaferUsedCountUpdateEvent_Make_out;
                        objEqpMonitorWaferUsedCountUpdateEvent_Make_in   strEqpMonitorWaferUsedCountUpdateEvent_Make_in;
                        strEqpMonitorWaferUsedCountUpdateEvent_Make_in.lotID         = lotID;
//PSN000097781                        strEqpMonitorWaferUsedCountUpdateEvent_Make_in.transactionID = info.txID;
                        strEqpMonitorWaferUsedCountUpdateEvent_Make_in.transactionID = CIMFWStrDup("TXPCC060");                   //PSN000097781;
                        strEqpMonitorWaferUsedCountUpdateEvent_Make_in.equipmentID   = equipmentID;
                        strEqpMonitorWaferUsedCountUpdateEvent_Make_in.controlJobID  = controlJobID;
                        strEqpMonitorWaferUsedCountUpdateEvent_Make_in.strEqpMonitorWaferUsedCountSeq   = strEqpMonitorWaferUsedCountUpdate_out.strEqpMonitorWaferUsedCountSeq;
                        strEqpMonitorWaferUsedCountUpdateEvent_Make_in.claimMemo     = claimMemo;
                        rc = eqpMonitorWaferUsedCountUpdateEvent_Make(strEqpMonitorWaferUsedCountUpdateEvent_Make_out, strObjCommonIn,strEqpMonitorWaferUsedCountUpdateEvent_Make_in);
                        if (rc != RC_OK)
                        {
                            PPT_METHODTRACE_V1("PPTManager_i:: txPostProcessExecReq__100", "rc != RC_OK");
                            SET_MSG_RC( strPostProcessExecReqResult, MSG_FAIL_MAKE_HISTORY, rc );
                            return( rc );
                        }

                        if( 1 == lockHoldUseFlag )
                        {
                            // Hold Lot "LOCK".
                            PPT_METHODTRACE_V1("", " Hold Lot. (LOCK)");
                            rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn, lotID, strHoldListSeq );
                            if( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "txHoldLotReq() != RC_OK", rc);
                                if( rc != RC_INVALID_LOT_STAT )
                                {
                                    PPT_METHODTRACE_V1("","txHoldLotReq() != RC_OK returned error.");
                                    strPostProcessExecReqResult.strResult = strHoldLotReqResult.strResult;
                                    return( RC_POSTPROC_ERROR );
                                }
                                else
                                {
                                    PPT_METHODTRACE_V1("","rc == RC_INVALID_LOT_STAT.");
                                    rc = RC_OK;
                                    bHoldRelease = FALSE;
                                }
                            }
                        }
                        if( 1 == postProcFlagUseFlag )
                        {
                            PPT_METHODTRACE_V1("","Post Proc Flag is usable.");
                            // Set InPostProcessFlag of Lot to ON
                            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
                            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                            strObjCommonIn,
                                                            strLot_inPostProcessFlag_Set_in );
                            if( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                                return( RC_POSTPROC_ERROR );
                            }
                        }
                    }
                }
            }
            else
            {
                //SP_EQPMONITOR_SWITCH=0
                PPT_METHODTRACE_V1("","SP_EQPMONITOR_SWITCH=0. EqpMonitorEval can be skipped.");
                rc = RC_OK;
            }
        }
        else
        {
            //Inactive
            //N/A
            PPT_METHODTRACE_V1("","lot_state != Active. - N/A -");
            bHoldRelease = FALSE;
        }
    }
//DSN000085698 Add End
//DSN000096126 Add Start
    else if ( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_DScript) )
    {
        PPT_METHODTRACE_V1("", "postProcID is DScript");

//DSN000101569        objDurable_OnRoute_Check_out strDurable_OnRoute_Check_out;
//DSN000101569        objDurable_OnRoute_Check_in  strDurable_OnRoute_Check_in;
//DSN000101569        strDurable_OnRoute_Check_in.durableCategory = durableCategory;
//DSN000101569        strDurable_OnRoute_Check_in.durableID       = cassetteID;
//DSN000101569        rc = durable_OnRoute_Check(strDurable_OnRoute_Check_out, strObjCommonIn, strDurable_OnRoute_Check_in);
//DSN000101569        if( rc == RC_DURABLE_ONROUTE)
//DSN000101569        {
//DSN000101569            PPT_METHODTRACE_V1("", "durable_OnRoute_Check() == RC_DURABLE_ONROUTE");
//DSN000101569
//DSN000101569            //Check Durable State
//DSN000101569            objDurable_state_Get_out strDurable_state_Get_out;
//DSN000101569            objDurable_state_Get_in  strDurable_state_Get_in;
//DSN000101569            strDurable_state_Get_in.durableCategory = durableCategory;
//DSN000101569            strDurable_state_Get_in.durableID       = cassetteID;
//DSN000101569            rc = durable_state_Get(strDurable_state_Get_out, strObjCommonIn, strDurable_state_Get_in);
//DSN000101569            if( rc != RC_OK )
//DSN000101569            {
//DSN000101569                PPT_METHODTRACE_V1("", "durable_state_Get() != RC_OK");
//DSN000101569                strPostProcessExecReqResult.strResult = strDurable_state_Get_out.strResult;
//DSN000101569                return( rc );
//DSN000101569            }
//DSN000101569
//DSN000101569            if( 0 == CIMFWStrCmp(strDurable_state_Get_out.durableState, CIMFW_Durable_NotAvailable) )
//DSN000101569            {
//DSN000101569                PPT_METHODTRACE_V1("", "durableState is NotAvailable or Available");
//DSN000101569 add start
        objDurable_OnRouteState_Get_in  strDurable_OnRouteState_Get_in;
        strDurable_OnRouteState_Get_in.durableCategory = durableCategory;
        strDurable_OnRouteState_Get_in.durableID = cassetteID;
        objDurable_OnRouteState_Get_out strDurable_OnRouteState_Get_out;
        rc = durable_OnRouteState_Get(strDurable_OnRouteState_Get_out, strObjCommonIn, strDurable_OnRouteState_Get_in);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "durable_OnRouteState_Get() != RC_OK");
            strPostProcessExecReqResult.strResult = strDurable_OnRouteState_Get_out.strResult;
            return rc;
        }
        
        if (0 == CIMFWStrCmp(strDurable_OnRouteState_Get_out.durableOnRouteStatus, SP_Durable_OnRouteState_Active))
        {
//DSN000101569 add end
            if( lockHoldUseFlag == 1 || postProcFlagUseFlag == 1 )
            {
               PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
               if( FALSE == bFindLockHoldFlag && FALSE == bInPostProcessFlag )
               {
                   PPT_METHODTRACE_V1("", "Durable is not in post process.");
                   PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                       MSG_CAST_NOT_INPOSTPROCESS, RC_CAST_NOT_INPOSTPROCESS,
                                       cassetteID.identifier );
                   return( RC_POSTPROC_ERROR );
               }
            }

            // Set InPostProcessFlag of Durable to OFF
            objDurable_inPostProcessFlag_Set_out strDurable_inPostProcessFlag_Set_out;
            objDurable_inPostProcessFlag_Set_in  strDurable_inPostProcessFlag_Set_in;
            strDurable_inPostProcessFlag_Set_in.durableCategory   = durableCategory;
            strDurable_inPostProcessFlag_Set_in.durableID         = cassetteID;
            strDurable_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
            rc = durable_inPostProcessFlag_Set(strDurable_inPostProcessFlag_Set_out, strObjCommonIn, strDurable_inPostProcessFlag_Set_in);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "durable_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strDurable_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }
            
            if( bFindLockHoldFlag == TRUE && (lockHoldUseFlag == 1 || lockHoldUseFlag == 0) )
            {
                // Release Durable Hold.
                PPT_METHODTRACE_V1("", " Release Durables' Hold (LOCK) ");
                pptHoldDurableReleaseReqResult  strHoldDurableReleaseReqResult;
                pptHoldDurableReleaseReqInParam strHoldDurableReleaseReqInParam;
                strHoldDurableReleaseReqInParam.durableCategory     = durableCategory;
                strHoldDurableReleaseReqInParam.durableID           = cassetteID;
                strHoldDurableReleaseReqInParam.releaseReasonCodeID.identifier = CIMFWStrDup(SP_Reason_DurableLockRelease);
                strHoldDurableReleaseReqInParam.strDurableHoldList  = strDurableHoldList;
                rc = txHoldDurableReleaseReq(strHoldDurableReleaseReqResult, strObjCommonIn, strHoldDurableReleaseReqInParam, claimMemo);
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "txHoldDurableReleaseReq() != RC_OK");
                    strPostProcessExecReqResult.strResult = strHoldDurableReleaseReqResult.strResult;
                    return( rc );
                }
            }

            // Call txRunDurableBRScriptReq
            pptRunDurableBRScriptReqResult  strRunDurableBRScriptReqResult;
            pptRunDurableBRScriptReqInParam strRunDurableBRScriptReqInParam;
            strRunDurableBRScriptReqInParam.phase           = CIMFWStrDup(SP_BRScript_Pre1);
            strRunDurableBRScriptReqInParam.durableCategory = durableCategory;
            strRunDurableBRScriptReqInParam.durableID       = cassetteID;
            strRunDurableBRScriptReqInParam.equipmentID     = dummyID;
            rc = txRunDurableBRScriptReq(strRunDurableBRScriptReqResult, strObjCommonIn, strRunDurableBRScriptReqInParam, claimMemo);
            if( rc != RC_OK && rc != RC_NOT_FOUND_SCRIPT )
            {
                PPT_METHODTRACE_V1("","txRunDurableBRScriptReq rc != RC_OK && rc != RC_NOT_FOUND_SCRIPT...");
                strPostProcessExecReqResult.strResult = strRunDurableBRScriptReqResult.strResult ;
                return( RC_POSTPROC_ERROR );
            }

            if( rc == RC_NOT_FOUND_SCRIPT )
            {
                PPT_METHODTRACE_V1("", "rc == RC_NOT_FOUND_SCRIPT.");
                rc = RC_OK;
            }

            // Hold Durable "LOCK".
            if( lockHoldUseFlag == 1 )
            {
                PPT_METHODTRACE_V1("","lockHoldUseFlag is usable.");

                pptHoldDurableReqResult  strHoldDurableReqResult;
                pptHoldDurableReqInParam strHoldDurableReqInParam;
                strHoldDurableReqInParam.durableCategory    = durableCategory;
                strHoldDurableReqInParam.durableID          = cassetteID;
                strHoldDurableReqInParam.strDurableHoldList = strDurableHoldList;
                rc = txHoldDurableReq(strHoldDurableReqResult, strObjCommonIn, strHoldDurableReqInParam, claimMemo);
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "txHoldDurableReq() != RC_OK", rc);
                    if( rc != RC_INVALID_DURABLE_STAT )
                    {
                        PPT_METHODTRACE_V1("", "txHoldDurableReq() != RC_INVALID_DURABLE_STAT returned error.");
                        strPostProcessExecReqResult.strResult = strHoldDurableReqResult.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "rc == RC_INVALID_DURABLE_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            }

            if( postProcFlagUseFlag == 1 )
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");

//DSN000101569                    //Check durable state
//DSN000101569                    strDurable_state_Get_in.durableCategory = durableCategory;
//DSN000101569                    strDurable_state_Get_in.durableID       = cassetteID;
//DSN000101569                    rc = durable_state_Get(strDurable_state_Get_out, strObjCommonIn, strDurable_state_Get_in);
//DSN000101569                    if( rc != RC_OK )
//DSN000101569                    {
//DSN000101569                        PPT_METHODTRACE_V1("", "durable_state_Get() != RC_OK");
//DSN000101569                        strPostProcessExecReqResult.strResult = strDurable_state_Get_out.strResult;
//DSN000101569                        return( rc );
//DSN000101569                    }
//DSN000101569
//DSN000101569                    if( 0 == CIMFWStrCmp(strDurable_state_Get_out.durableState, CIMFW_Durable_NotAvailable) 
//DSN000101569                     || 0 == CIMFWStrCmp(strDurable_state_Get_out.durableState, CIMFW_Durable_Available) )
//DSN000101569                    {
//DSN000101569                        PPT_METHODTRACE_V1("", "durableState is NotAvailable or Available");
//DSN000101569
//DSN000101569                        // Set InPostProcessFlag of Durable to ON
//DSN000101569                        strDurable_inPostProcessFlag_Set_in.durableCategory   = durableCategory;
//DSN000101569                        strDurable_inPostProcessFlag_Set_in.durableID         = cassetteID;
//DSN000101569                        strDurable_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
//DSN000101569                        rc = durable_inPostProcessFlag_Set(strDurable_inPostProcessFlag_Set_out, strObjCommonIn, strDurable_inPostProcessFlag_Set_in);
//DSN000101569                        if( rc != RC_OK )
//DSN000101569                        {
//DSN000101569                            PPT_METHODTRACE_V1("", "durable_inPostProcessFlag_Set() != RC_OK");
//DSN000101569                            strPostProcessExecReqResult.strResult = strDurable_inPostProcessFlag_Set_out.strResult;
//DSN000101569                            return( rc );
//DSN000101569                        }
//DSN000101569                    }
//DSN000101569 add start
                objDurable_inPostProcessFlag_Set_out strDurable_inPostProcessFlag_Set_out;
                objDurable_inPostProcessFlag_Set_in  strDurable_inPostProcessFlag_Set_in;
                strDurable_inPostProcessFlag_Set_in.durableCategory   = durableCategory;
                strDurable_inPostProcessFlag_Set_in.durableID         = cassetteID;
                strDurable_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
                rc = durable_inPostProcessFlag_Set(strDurable_inPostProcessFlag_Set_out, strObjCommonIn, strDurable_inPostProcessFlag_Set_in);
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "durable_inPostProcessFlag_Set() != RC_OK");
                    strPostProcessExecReqResult.strResult = strDurable_inPostProcessFlag_Set_out.strResult;
                    return( rc );
                }
//DSN000101569 add end
            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "set bHoldRelease to FALSE");
            bHoldRelease = FALSE;
        }
//DSN000101569        }
//DSN000101569        else
//DSN000101569        {
//DSN000101569            PPT_METHODTRACE_V1("", "durable_OnRoute_Check() == RC_DURABLE_NOT_ONROUTE");
//DSN000101569            rc = RC_OK;
//DSN000101569        }
    }
    else if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_DAutoBankIn) )
    {
        PPT_METHODTRACE_V1("", "postProcID is DAutoBankIn");

//DSN000101569        objDurable_OnRoute_Check_out strDurable_OnRoute_Check_out;
//DSN000101569        objDurable_OnRoute_Check_in  strDurable_OnRoute_Check_in;
//DSN000101569        strDurable_OnRoute_Check_in.durableCategory = durableCategory;
//DSN000101569        strDurable_OnRoute_Check_in.durableID       = cassetteID;
//DSN000101569        rc = durable_OnRoute_Check(strDurable_OnRoute_Check_out, strObjCommonIn, strDurable_OnRoute_Check_in);
//DSN000101569        if( rc == RC_DURABLE_ONROUTE)
//DSN000101569        {
//DSN000101569            PPT_METHODTRACE_V1("", "durable_OnRoute_Check() == RC_DURABLE_ONROUTE");
//DSN000101569
//DSN000101569            //Check Durable State
//DSN000101569            objDurable_state_Get_out strDurable_state_Get_out;
//DSN000101569            objDurable_state_Get_in  strDurable_state_Get_in;
//DSN000101569            strDurable_state_Get_in.durableCategory = durableCategory;
//DSN000101569            strDurable_state_Get_in.durableID       = cassetteID;
//DSN000101569            rc = durable_state_Get(strDurable_state_Get_out, strObjCommonIn, strDurable_state_Get_in);
//DSN000101569            if( rc != RC_OK )
//DSN000101569            {
//DSN000101569                PPT_METHODTRACE_V1("", "durable_state_Get() != RC_OK");
//DSN000101569                strPostProcessExecReqResult.strResult = strDurable_state_Get_out.strResult;
//DSN000101569                return( rc );
//DSN000101569            }
//DSN000101569
//DSN000101569            if( 0 == CIMFWStrCmp(strDurable_state_Get_out.durableState, CIMFW_Durable_NotAvailable) )
//DSN000101569            {
//DSN000101569                PPT_METHODTRACE_V1("", "durableState is NotAvailable or Available");
//DSN000101569 add start
        objDurable_OnRouteState_Get_in  strDurable_OnRouteState_Get_in;
        strDurable_OnRouteState_Get_in.durableCategory = durableCategory;
        strDurable_OnRouteState_Get_in.durableID = cassetteID;
        objDurable_OnRouteState_Get_out strDurable_OnRouteState_Get_out;
        rc = durable_OnRouteState_Get(strDurable_OnRouteState_Get_out, strObjCommonIn, strDurable_OnRouteState_Get_in);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "durable_OnRouteState_Get() != RC_OK");
            strPostProcessExecReqResult.strResult = strDurable_OnRouteState_Get_out.strResult;
            return rc;
        }
        if (0 == CIMFWStrCmp(strDurable_OnRouteState_Get_out.durableOnRouteStatus, SP_Durable_OnRouteState_Active))
        {
//DSN000101569 add end 
            if( lockHoldUseFlag == 1 || postProcFlagUseFlag == 1 )
            {
               PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
               if( FALSE == bFindLockHoldFlag && FALSE == bInPostProcessFlag )
               {
                   PPT_METHODTRACE_V1("", "Durable is not in post process.");
                   PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                       MSG_CAST_NOT_INPOSTPROCESS, RC_CAST_NOT_INPOSTPROCESS,
                                       cassetteID.identifier );
                   return( RC_POSTPROC_ERROR );
               }
            }

            // Set InPostProcessFlag of Durable to OFF
            objDurable_inPostProcessFlag_Set_out strDurable_inPostProcessFlag_Set_out;
            objDurable_inPostProcessFlag_Set_in  strDurable_inPostProcessFlag_Set_in;
            strDurable_inPostProcessFlag_Set_in.durableCategory   = durableCategory;
            strDurable_inPostProcessFlag_Set_in.durableID         = cassetteID;
            strDurable_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
            rc = durable_inPostProcessFlag_Set(strDurable_inPostProcessFlag_Set_out, strObjCommonIn, strDurable_inPostProcessFlag_Set_in);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "durable_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strDurable_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }
            
            if( bFindLockHoldFlag == TRUE && (lockHoldUseFlag == 1 || lockHoldUseFlag == 0) )
            {
                // Release Durable Hold.
                PPT_METHODTRACE_V1("", " Release Durables' Hold (LOCK) ");
                pptHoldDurableReleaseReqResult  strHoldDurableReleaseReqResult;
                pptHoldDurableReleaseReqInParam strHoldDurableReleaseReqInParam;
                strHoldDurableReleaseReqInParam.durableCategory     = durableCategory;
                strHoldDurableReleaseReqInParam.durableID           = cassetteID;
                strHoldDurableReleaseReqInParam.releaseReasonCodeID.identifier = CIMFWStrDup(SP_Reason_DurableLockRelease);
                strHoldDurableReleaseReqInParam.strDurableHoldList  = strDurableHoldList;
                rc = txHoldDurableReleaseReq(strHoldDurableReleaseReqResult, strObjCommonIn, strHoldDurableReleaseReqInParam, claimMemo);
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "txHoldDurableReleaseReq() != RC_OK");
                    strPostProcessExecReqResult.strResult = strHoldDurableReleaseReqResult.strResult;
                    return( rc );
                }
            }

            // Call txDurableBankInByPostProcReq
            pptDurableBankInByPostProcReqResult  strDurableBankInByPostProcReqResult;
            pptDurableBankInByPostProcReqInParam strDurableBankInByPostProcReqInParam;
            strDurableBankInByPostProcReqInParam.durableCategory = durableCategory;
            strDurableBankInByPostProcReqInParam.durableID       = cassetteID;
            rc = txDurableBankInByPostProcReq(strDurableBankInByPostProcReqResult, strObjCommonIn, strDurableBankInByPostProcReqInParam, claimMemo);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "txDurableBankInByPostProcReq rc != RC_OK");
                strPostProcessExecReqResult.strResult = strDurableBankInByPostProcReqResult.strResult ;
                return( RC_POSTPROC_ERROR );
            }

            // Hold Durable "LOCK".
            if( lockHoldUseFlag == 1 )
            {
                PPT_METHODTRACE_V1("","lockHoldUseFlag is usable.");

                pptHoldDurableReqResult  strHoldDurableReqResult;
                pptHoldDurableReqInParam strHoldDurableReqInParam;
                strHoldDurableReqInParam.durableCategory    = durableCategory;
                strHoldDurableReqInParam.durableID          = cassetteID;
                strHoldDurableReqInParam.strDurableHoldList = strDurableHoldList;
                rc = txHoldDurableReq(strHoldDurableReqResult, strObjCommonIn, strHoldDurableReqInParam, claimMemo);
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "txHoldDurableReq() != RC_OK", rc);
                    if( rc != RC_INVALID_DURABLE_STAT )
                    {
                        PPT_METHODTRACE_V1("", "txHoldDurableReq() != RC_INVALID_DURABLE_STAT returned error.");
                        strPostProcessExecReqResult.strResult = strHoldDurableReqResult.strResult;
                        return( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "rc == RC_INVALID_DURABLE_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            }

            if( postProcFlagUseFlag == 1 )
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");

//DSN000101569                    //Check durable state
//DSN000101569                    strDurable_state_Get_in.durableCategory = durableCategory;
//DSN000101569                    strDurable_state_Get_in.durableID       = cassetteID;
//DSN000101569                    rc = durable_state_Get(strDurable_state_Get_out, strObjCommonIn, strDurable_state_Get_in);
//DSN000101569                    if( rc != RC_OK )
//DSN000101569                    {
//DSN000101569                        PPT_METHODTRACE_V1("", "durable_state_Get() != RC_OK");
//DSN000101569                        strPostProcessExecReqResult.strResult = strDurable_state_Get_out.strResult;
//DSN000101569                        return( rc );
//DSN000101569                    }
//DSN000101569
//DSN000101569                    if( 0 == CIMFWStrCmp(strDurable_state_Get_out.durableState, CIMFW_Durable_NotAvailable) 
//DSN000101569                     || 0 == CIMFWStrCmp(strDurable_state_Get_out.durableState, CIMFW_Durable_Available) )
//DSN000101569                    {
//DSN000101569                        PPT_METHODTRACE_V1("", "durableState is NotAvailable or Available");
//DSN000101569
//DSN000101569                        // Set InPostProcessFlag of Durable to ON
//DSN000101569                        strDurable_inPostProcessFlag_Set_in.durableCategory   = durableCategory;
//DSN000101569                        strDurable_inPostProcessFlag_Set_in.durableID         = cassetteID;
//DSN000101569                        strDurable_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
//DSN000101569                        rc = durable_inPostProcessFlag_Set(strDurable_inPostProcessFlag_Set_out, strObjCommonIn, strDurable_inPostProcessFlag_Set_in);
//DSN000101569                        if( rc != RC_OK )
//DSN000101569                        {
//DSN000101569                            PPT_METHODTRACE_V1("", "durable_inPostProcessFlag_Set() != RC_OK");
//DSN000101569                            strPostProcessExecReqResult.strResult = strDurable_inPostProcessFlag_Set_out.strResult;
//DSN000101569                            return( rc );
//DSN000101569                        }
//DSN000101569                    }
//DSN000101569 add start
                objDurable_inPostProcessFlag_Set_out strDurable_inPostProcessFlag_Set_out;
                objDurable_inPostProcessFlag_Set_in  strDurable_inPostProcessFlag_Set_in;
                strDurable_inPostProcessFlag_Set_in.durableCategory   = durableCategory;
                strDurable_inPostProcessFlag_Set_in.durableID         = cassetteID;
                strDurable_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
                rc = durable_inPostProcessFlag_Set(strDurable_inPostProcessFlag_Set_out, strObjCommonIn, strDurable_inPostProcessFlag_Set_in);
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "durable_inPostProcessFlag_Set() != RC_OK");
                    strPostProcessExecReqResult.strResult = strDurable_inPostProcessFlag_Set_out.strResult;
                    return( rc );
                }
//DSN000101569 add end
            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "set bHoldRelease to FALSE");
            bHoldRelease = FALSE;
        }
//DSN000101569        }
//DSN000101569        else
//DSN000101569        {
//DSN000101569            PPT_METHODTRACE_V1("", "durable_OnRoute_Check == RC_DURABLE_NOT_ONROUTE");
//DSN000101569            rc = RC_OK;
//DSN000101569        }
    }
//DSN000096126 Add End
//DSN000101569 add start
    else if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_DProcessLagTime) )
    {
        PPT_METHODTRACE_V1("", "postProcID is DProcessLagTime");
        objDurable_OnRouteState_Get_in  strDurable_OnRouteState_Get_in;
        strDurable_OnRouteState_Get_in.durableCategory = durableCategory;
        strDurable_OnRouteState_Get_in.durableID = cassetteID;
        objDurable_OnRouteState_Get_out strDurable_OnRouteState_Get_out;
        rc = durable_OnRouteState_Get(strDurable_OnRouteState_Get_out, strObjCommonIn, strDurable_OnRouteState_Get_in);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "durable_OnRouteState_Get() != RC_OK");
            strPostProcessExecReqResult.strResult = strDurable_OnRouteState_Get_out.strResult;
            return ( rc );
        }
        if (0 == CIMFWStrCmp(strDurable_OnRouteState_Get_out.durableOnRouteStatus, SP_Durable_OnRouteState_Active))
        {
            if (lockHoldUseFlag == 1 || postProcFlagUseFlag == 1)
            {
                PPT_METHODTRACE_V1("", "Check LockHold & InPostProcessFlag.");
                if (bFindLockHoldFlag == FALSE && bInPostProcessFlag == FALSE)
                {
                    PPT_METHODTRACE_V1("", "Durable is not in post process.");
                    PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult,
                                        MSG_CAST_NOT_INPOSTPROCESS, RC_CAST_NOT_INPOSTPROCESS,
                                        cassetteID.identifier );
                    return( RC_POSTPROC_ERROR );
                }
            }
            
            // Set InPostProcessFlag of Durable to OFF
            objDurable_inPostProcessFlag_Set_out strDurable_inPostProcessFlag_Set_out;
            objDurable_inPostProcessFlag_Set_in  strDurable_inPostProcessFlag_Set_in;
            strDurable_inPostProcessFlag_Set_in.durableCategory   = durableCategory;
            strDurable_inPostProcessFlag_Set_in.durableID         = cassetteID;
            strDurable_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
            rc = durable_inPostProcessFlag_Set(strDurable_inPostProcessFlag_Set_out, strObjCommonIn, strDurable_inPostProcessFlag_Set_in);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "durable_inPostProcessFlag_Set() != RC_OK");
                strPostProcessExecReqResult.strResult = strDurable_inPostProcessFlag_Set_out.strResult;
                return( rc );
            }
            
            if( bFindLockHoldFlag == TRUE && (lockHoldUseFlag == 1 || lockHoldUseFlag == 0) )
            {
                // Release Durable Hold.
                PPT_METHODTRACE_V1("", " Release Durables' Hold (LOCK) ");
                pptHoldDurableReleaseReqResult  strHoldDurableReleaseReqResult;
                pptHoldDurableReleaseReqInParam strHoldDurableReleaseReqInParam;
                strHoldDurableReleaseReqInParam.durableCategory     = durableCategory;
                strHoldDurableReleaseReqInParam.durableID           = cassetteID;
                strHoldDurableReleaseReqInParam.releaseReasonCodeID.identifier = CIMFWStrDup(SP_Reason_DurableLockRelease);
                strHoldDurableReleaseReqInParam.strDurableHoldList  = strDurableHoldList;
                rc = txHoldDurableReleaseReq(strHoldDurableReleaseReqResult, strObjCommonIn, strHoldDurableReleaseReqInParam, claimMemo);
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "txHoldDurableReleaseReq() != RC_OK");
                    strPostProcessExecReqResult.strResult = strHoldDurableReleaseReqResult.strResult;
                    return( rc );
                }
            }
            
            // Call txDurableProcessLagTimeUpdateReq
            pptDurableProcessLagTimeUpdateReqResult strDurableProcessLagTimeUpdateReqResult;
            pptDurableProcessLagTimeUpdateReqInParm strDurableProcessLagTimeUpdateReqInParm;
            strDurableProcessLagTimeUpdateReqInParm.durableCategory = durableCategory;
            strDurableProcessLagTimeUpdateReqInParm.durableID = cassetteID;
            strDurableProcessLagTimeUpdateReqInParm.action = CIMFWStrDup(SP_ProcessLagTime_Action_Set);
            rc = txDurableProcessLagTimeUpdateReq(strDurableProcessLagTimeUpdateReqResult, strObjCommonIn, strDurableProcessLagTimeUpdateReqInParm, claimMemo);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "txDurableProcessLagTimeUpdateReq() != RC_OK");
                strPostProcessExecReqResult.strResult = strDurableProcessLagTimeUpdateReqResult.strResult;
                return( RC_POSTPROC_ERROR );
            }
            
            //Hold durable "LOCK"
            if (lockHoldUseFlag == 1)
            {
                PPT_METHODTRACE_V1("","lockHoldUseFlag is usable.");
                pptHoldDurableReqResult  strHoldDurableReqResult;
                pptHoldDurableReqInParam strHoldDurableReqInParam;
                strHoldDurableReqInParam.durableCategory    = durableCategory;
                strHoldDurableReqInParam.durableID          = cassetteID;
                strHoldDurableReqInParam.strDurableHoldList = strDurableHoldList;
                rc = txHoldDurableReq(strHoldDurableReqResult, strObjCommonIn, strHoldDurableReqInParam, claimMemo);
                if( rc != RC_OK)
                {
                    PPT_METHODTRACE_V2("", "txHoldDurableReq() != RC_OK", rc);
                    if(rc != RC_INVALID_DURABLE_STAT)
                    {
                        PPT_METHODTRACE_V1("", "txHoldDurableReq() != RC_INVALID_DURABLE_STAT returned error.");
                        strPostProcessExecReqResult.strResult = strHoldDurableReqResult.strResult;
                        return ( RC_POSTPROC_ERROR );
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "rc == RC_INVALID_DURABLE_STAT.");
                        rc = RC_OK;
                        bHoldRelease = FALSE;
                    }
                }
            }
            if (postProcFlagUseFlag == 1)
            {
                PPT_METHODTRACE_V1("","Post Proc Flag is usable.");
                // Set InPostProcessFlag of Durable to OFF
                objDurable_inPostProcessFlag_Set_out strDurable_inPostProcessFlag_Set_out;
                objDurable_inPostProcessFlag_Set_in  strDurable_inPostProcessFlag_Set_in;
                strDurable_inPostProcessFlag_Set_in.durableCategory   = durableCategory;
                strDurable_inPostProcessFlag_Set_in.durableID         = cassetteID;
                strDurable_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE;
                rc = durable_inPostProcessFlag_Set(strDurable_inPostProcessFlag_Set_out, strObjCommonIn, strDurable_inPostProcessFlag_Set_in);
                if(rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "durable_inPostProcessFlag_Set() != RC_OK");
                    strPostProcessExecReqResult.strResult = strDurable_inPostProcessFlag_Set_out.strResult;
                    return ( rc );
                }
            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "set bHoldRelease to FALSE");
            bHoldRelease = FALSE;
        }
    }
//DSN000101569 add end
    else
    {
        PPT_METHODTRACE_V2("", "The specified postProcID does not exist for the Post Processing.", info.postProcID );
        PPT_SET_MSG_RC_KEY( strPostProcessExecReqResult, MSG_POSTPROC_UNKNOWN_PROC_ID, RC_POSTPROC_UNKNOWN_PROC_ID, info.postProcID );
        return( RC_POSTPROC_UNKNOWN_PROC_ID );
    }

    //--------------------------
    // Check Error again.
    //--------------------------
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "Something error occured.");
        rc = RC_POSTPROC_ERROR;
        return( rc );
    }

    CORBA::Boolean interFabXferFlag = FALSE ;    //DSIV00000214
    CORBA::Boolean bLastPostProc = FALSE ;       //DSIV00001007
    if( 0 == CIMFWStrCmp( info.targetType , SP_PostProcess_TargetType_LOT ) )
    {
//DSIV00000214 add start
        //------------------------------------------------------------------------------------------------------------------------
        //  If postProcID == SP_PostProcess_ActionID_InterFabXfer and interFabXfer is done, return RC_INTERFAB_LOTXFER_EXECUTED.
        //------------------------------------------------------------------------------------------------------------------------
        if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_InterFabXfer) && rc_interFabXfer == RC_INTERFAB_LOTXFER_EXECUTED )
        {
            // Post-processing is suspended for the MultiFab transfer.
            interFabXferFlag = TRUE;
        }
//DSN000075328 add start
        else if (rc_pp == RC_POSTRPOC_DKEY_RECREATE )
        {
            PPT_METHODTRACE_V1("", "rc_pp == RC_POSTRPOC_DKEY_RECREATE");
            // Store TriggerDKey as thread specific data
            char* methodName = NULL;
            try
            {
                methodName = CIMFWStrDup("setThreadSpecificDataString");
                setThreadSpecificDataString (SP_ThreadSpecificData_Key_TriggerDKey, info.dKey);
                CORBA::string_free(methodName);
                methodName = NULL;
            }
            CATCH_GLOBAL_EXCEPTIONS(strPostProcessExecReqResult, txPostProcessExecReq__100, methodName);

            //delete all remaining post processes related to the parent lot
            //release LockHold and set PPFlag to false for parent lot
            pptPostProcessActionUpdateReqResult__100  strPostProcessActionUpdateReqResult;
            pptPostProcessAdditionalInfoSequence dummyPostProcessAdditionalInfoSeq;
            rc = txPostProcessActionUpdateReq__130( strPostProcessActionUpdateReqResult,
                                                    strObjCommonIn,
                                                    SP_PostProcessActionInfo_DeleteWithLot, 
                                                    strPostProcessQueue_GetDR_out.strActionInfoSeq, 
                                                    dummyPostProcessAdditionalInfoSeq, 
                                                    "" );

            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "txPostProcessActionUpdateReq() != RC_OK");
                strPostProcessExecReqResult.strResult = strPostProcessActionUpdateReqResult.strResult;
                return( rc );
            }

            //-------------------------------------------
            // Register post process for parent lot again
            //-------------------------------------------
            PPT_METHODTRACE_V1("", "call txPostProcessActionRegistReq");
            pptPostProcessRegistrationParm strPostProcessRegistrationParm;
            strPostProcessRegistrationParm.lotIDs.length(1);
            strPostProcessRegistrationParm.lotIDs[0] = lotID;

            CORBA::String_var strTxId;
            if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_PSM) )
            {
                PPT_METHODTRACE_V1("", "info.postProcID==PSM, use P_BRANCH");
                strTxId = CIMFWStrDup(TX_ID_P_BRANCH);
            }
            else
            {
                PPT_METHODTRACE_V1("", "info.postProcID==FPC, use P_LOCATE");
                strTxId = CIMFWStrDup(TX_ID_P_LOCATE);
            }

            pptPostProcessActionRegistReqResult__100 strPostProcessActionRegistReqResult;
            rc = txPostProcessActionRegistReq__100( strPostProcessActionRegistReqResult,
                                                    tmpStrObjCommonIn,
                                                    strTxId,                        //txID
                                                    NULL,                           //patternID
                                                    NULL,                           //dkey
                                                    -1,                             //seqNo
                                                    strPostProcessRegistrationParm,
                                                    "" );                           //claimMemo
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "txPostProcessActionRegistReq__100() rc != RC_OK");
                strPostProcessExecReqResult.strResult = strPostProcessActionRegistReqResult.strResult ;
                return rc ;
            }
            PPT_METHODTRACE_V2("", "New dKey", strPostProcessActionRegistReqResult.dKey);

            // remove TriggerDKey from thread specific data (set blank)
            try
            {
                methodName = CIMFWStrDup("setThreadSpecificDataString");
                setThreadSpecificDataString (SP_ThreadSpecificData_Key_TriggerDKey, "");
                CORBA::string_free(methodName);
                methodName = NULL;
            }
            CATCH_GLOBAL_EXCEPTIONS(strPostProcessExecReqResult, txPostProcessExecReq__100, methodName);

            //set flag for FOUP PostProcessFlag control
            bLastPostProc = FALSE ;
        }
//DSN000075328 add end
        else
        {
//DSIV00000214 add end
            //----------------------------
            // Check lot state
            //----------------------------
            objLot_state_Get_out strLot_state_Get_out ;
//D8000028        rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, info.lotID );
            rc = lot_state_Get( strLot_state_Get_out, strObjCommonIn, lotID );    //D8000028
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("","lot_state_Get() != RC_OK ");
                strPostProcessExecReqResult.strResult = strLot_state_Get_out.strResult;
                return( rc );
            }

            if ( 0 == CIMFWStrCmp( strLot_state_Get_out.lotState, CIMFW_Lot_State_Active ))
            {
//D8000028  PPT_METHODTRACE_V2("", "The lot state is Active. ", info.lotID.identifier );
                PPT_METHODTRACE_V2("", "The lot state is Active. ", lotID.identifier );    //D8000028
                //--------------------------
                // Delete Queue
                //--------------------------
//DSIV00000201            pptPostProcessActionInfoSequence    actionInfoSeq(1);
                pptPostProcessActionInfoSequence__100    actionInfoSeq(1);  //DSIV00000201
                actionInfoSeq.length(1);
                actionInfoSeq[0].dKey  = info.dKey;
                actionInfoSeq[0].seqNo = info.seqNo;

//DSIV00000201            objPostProcessQueue_UpdateDR_out strPostProcessQueue_UpdateDR_out;
//DSIV00000201            rc = postProcessQueue_UpdateDR( strPostProcessQueue_UpdateDR_out, strObjCommonIn, SP_PostProcessActionInfo_Delete, actionInfoSeq );
//DSIV00000201 add start
                PPT_METHODTRACE_V3("", "(info.postProcID, rc_extPostProc) = ",info.postProcID, rc_extPostProc);
                if( 0 == CIMFWStrCmp(info.postProcID, SP_PostProcess_ActionID_ExternalPostProcessExecReq) && rc_extPostProc == RC_EXTPOSTPROC_EXECUTED)
                {
                    PPT_METHODTRACE_V1("", "return 'RC_EXTPOSTPROC_EXECUTED' without queue deletion  ");
                    // Post-processing is suspended for the external post-processing.
                    strPostProcessExecReqResult.strResult = strPostProcessQueue_GetDR_out.strResult;
                    SET_MSG_RC( strPostProcessExecReqResult, MSG_OK, RC_EXTPOSTPROC_EXECUTED);
                    return ( RC_EXTPOSTPROC_EXECUTED );
                }
                else
                {
                    objPostProcessQueue_UpdateDR_out__100 strPostProcessQueue_UpdateDR_out;
                    rc = postProcessQueue_UpdateDR__100( strPostProcessQueue_UpdateDR_out, strObjCommonIn, SP_PostProcessActionInfo_Delete, actionInfoSeq );
//DSIV00000201 add end
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "postProcessQueue_UpdateDR__100() != RC_OK");
                        strPostProcessExecReqResult.strResult = strPostProcessQueue_UpdateDR_out.strResult;
                        return rc ;
                    }
//DSIV00000201 add start
                }
//DSIV00000201 add end

                //------------------------------------------------------------------------------------------------------
                // If targetType is "LOT" and there are not some queues about the "LOT", the Lot's Hold is released.
                //------------------------------------------------------------------------------------------------------
                if( bHoldRelease == TRUE )
                {
                    //---------------------------------------------------
                    // Check whether Queue of the same Lot remains yet.
                    //---------------------------------------------------
//DSIV00000201                objPostProcessQueue_GetDR_out strPostProcessQueue_GetDR_out3;
//D8000028      rc = postProcessQueue_GetDR(  strPostProcessQueue_GetDR_out3, strObjCommonIn, key, -1, nullSeqNoList, NULL, -1, info.targetType, info.lotID );
//DSIV00000201                rc = postProcessQueue_GetDR(  strPostProcessQueue_GetDR_out3, strObjCommonIn, key, -1, nullSeqNoList, NULL, -1, info.targetType, lotID );    //D8000028
//DSIV00000201 add start
                    objPostProcessQueue_GetDR_out__100 strPostProcessQueue_GetDR_out3;
                    rc = postProcessQueue_GetDR__100(  strPostProcessQueue_GetDR_out3, strObjCommonIn, key, -1, nullSeqNoList, NULL, -1, info.targetType, lotID );
//DSIV00000201 add end
                    if( rc != RC_OK )
                    {
                        if( rc == RC_NOT_FOUND_ENTRY )
                        {
//D9000056 add start
                            PPT_METHODTRACE_V1("", "rc == RC_NOT_FOUND_ENTRY");

                            // Set InPostProcessFlag=OFF for the Lot.
                            // InPostProcessFlag of the cassette is also set to OFF when InPostProcessFlag of all the lot in the cassette are OFF.
                            objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
                            objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
                            strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                            strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;

                            rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                            strObjCommonIn,
                                                            strLot_inPostProcessFlag_Set_in );
                            if( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                                strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                                return( rc );
                            }

                            if( 1 == lockHoldUseFlag )
                            {
//D9000056 add end
                                // Release Lot Hold.
                                PPT_METHODTRACE_V1("", " Release Lot's Hold (LOCK) ");
//D8000028              rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, info.lotID, holdReleaseCode, strHoldListSeq );
                                rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, lotID, holdReleaseCode, strHoldListSeq );    //D8000028
                                if( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V1("","txHoldLotReleaseReq() returned error.");
                                    strPostProcessExecReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                                    return( RC_POSTPROC_ERROR );
                                }
                            }  //D9000056
                            //set flag for FOUP PostProcessFlag control  //DSIV00001007
                            bLastPostProc = TRUE ;                       //DSIV00001007
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", "postProcessQueue_GetDR__100() != RC_OK");
                            strPostProcessExecReqResult.strResult = strPostProcessQueue_GetDR_out3.strResult;
                            return rc;
                        }
                    }
                }
            }
            else
            {
//D8000028  PPT_METHODTRACE_V2("", "The lot state is not Active. ", info.lotID.identifier );
                PPT_METHODTRACE_V2("", "The lot state is not Active. ", lotID.identifier );    //D8000028
                // The lot is not Active, the remaining queue is deleted.
//DSIV00000201            pptPostProcessActionUpdateReqResult  strPostProcessActionUpdateReqResult;
//DSIV00000201            rc = txPostProcessActionUpdateReq( strPostProcessActionUpdateReqResult, strObjCommonIn,
//DSIV00000201                                               SP_PostProcessActionInfo_DeleteWithLot, strPostProcessQueue_GetDR_out.strActionInfoSeq, "" );
//DSIV00000201 add start
                pptPostProcessActionUpdateReqResult__100  strPostProcessActionUpdateReqResult;
//DSN000041641                 rc = txPostProcessActionUpdateReq__100( strPostProcessActionUpdateReqResult, strObjCommonIn,
//DSN000041641                                                         SP_PostProcessActionInfo_DeleteWithLot, strPostProcessQueue_GetDR_out.strActionInfoSeq, "" );
//DSN000041641 Add Start
                pptPostProcessAdditionalInfoSequence dummyPostProcessAdditionalInfoSeq;
                rc = txPostProcessActionUpdateReq__130( strPostProcessActionUpdateReqResult, strObjCommonIn,
                                                        SP_PostProcessActionInfo_DeleteWithLot, 
                                                        strPostProcessQueue_GetDR_out.strActionInfoSeq, 
                                                        dummyPostProcessAdditionalInfoSeq, 
                                                        "" );
//DSN000041641 Add End

//DSIV00000201 add end
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "txPostProcessActionUpdateReq() != RC_OK");
                    strPostProcessExecReqResult.strResult = strPostProcessActionUpdateReqResult.strResult;
                    return( rc );
                }
//DSIV00000201 add start
                // Set InPostProcessFlag of Lot to OFF
                PPT_METHODTRACE_V1("","Set InPostProcessFlag of Lot to OFF");
                objLot_inPostProcessFlag_Set_out strLot_inPostProcessFlag_Set_out;
                objLot_inPostProcessFlag_Set_in  strLot_inPostProcessFlag_Set_in;
                strLot_inPostProcessFlag_Set_in.lotID             = lotID;
                strLot_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;

                rc = lot_inPostProcessFlag_Set( strLot_inPostProcessFlag_Set_out,
                                                strObjCommonIn,
                                                strLot_inPostProcessFlag_Set_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Set() != RC_OK");
                    strPostProcessExecReqResult.strResult = strLot_inPostProcessFlag_Set_out.strResult;
                    return( rc );
                }
                //set flag for FOUP PostProcessFlag control  //DSIV00001007
                bLastPostProc = TRUE ;                       //DSIV00001007
//DSIV00000201 add end
            }
//DSIV00000214 add start
        }

        if( (TRUE == interFabXferFlag || TRUE == bLastPostProc) &&  (1 == postProcFlagUseFlag) )     //DSIV00001007
        {                                                                                            //DSIV00001007
            //-------------------------------------------------------------------------------------
            //  Adjust cassette PostProcess Flag.
            //-------------------------------------------------------------------------------------
            //Get lot cassette
            objLot_cassette_Get_out strLot_cassette_Get_out;
            rc = lot_cassette_Get( strLot_cassette_Get_out, strObjCommonIn,
                                   lotID);

            if( rc == RC_NOT_FOUND_CST )
            {
                //Do nothing..
            }
            else if( rc != RC_OK  )
            {
                PPT_METHODTRACE_V1(""," ### lot_cassette_Get() rc != RC_OK ");
                strPostProcessExecReqResult.strResult = strLot_cassette_Get_out.strResult;
                return rc;
            }
            else  //RC_OK
            {
//PSN000100936                objCassette_lotList_GetDR_out strCassette_lotList_GetDR_out;
//PSN000100936                rc = cassette_lotList_GetDR( strCassette_lotList_GetDR_out,
//PSN000100936                                             strObjCommonIn,
//PSN000100936                                             strLot_cassette_Get_out.cassetteID );
//PSN000100936                if( rc != RC_OK )
//PSN000100936                {
//PSN000100936                    PPT_METHODTRACE_V1("", "cassette_lotList_GetDR() != RC_OK");
//PSN000100936                    strPostProcessExecReqResult.strResult = strCassette_lotList_GetDR_out.strResult;
//PSN000100936                    return rc;
//PSN000100936                }
//PSN000100936
                CORBA::Boolean lotPostProcessingFlag = FALSE;
//PSN000100936                CORBA::ULong lotLen = strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID.length();
//PSN000100936                for( CORBA::ULong i = 0 ; i < lotLen ; i++ )
//PSN000100936                {
//PSN000100936                    //-----------------------------------------------
//PSN000100936                    // Get PostProcess Action List
//PSN000100936                    //-----------------------------------------------
//PSN000100936                    PPT_METHODTRACE_V1("", "Get PostProcess Action List");
//DSN000041641                     pptPostProcessActionListInqResult__100 strPostProcessActionListInqResult;
//DSN000050720                    pptPostProcessActionListInqResult__130 strPostProcessActionListInqResult;   //DSN000041641
//PSN000100936                    objPostProcessQueue_ListDR_out__100 strPostProcessQueue_ListDR_out; //DSN000050720
//PSN000100936
 //PSN000100936                   pptPostProcessTargetObject strPostProcessTargetObject;
//PSIV00000507  strPostProcessTargetObject.lotID = lotID;
//PSN000100936                    strPostProcessTargetObject.lotID = strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID[i];    //PSIV00000507
//DSN000041641                     rc = txPostProcessActionListInq__100( strPostProcessActionListInqResult,
//DSN000041641                                                          strObjCommonIn,
//DSN000041641                                                          NULL,                          // key
//DSN000041641                                                          -1,                            // seqNo
//DSN000041641                                                          NULL,                          // watchdogName
//DSN000041641                                                          NULL,                          // postProcID
//DSN000041641                                                          -1,                            // syncFlag
//DSN000041641                                                          NULL,                          // txID
//DSN000041641                                                          NULL,                          // targetType
//DSN000041641                                                          strPostProcessTargetObject,
//DSN000041641                                                          NULL,                          // status
//DSN000041641                                                          -1,                            // passedTime
//DSN000041641                                                          NULL,                          // claimUserID
//DSN000041641                                                          NULL,                          // startCreateTimeStamp
//DSN000041641                                                          NULL,                          // endCreateTimeStamp
//DSN000041641                                                          NULL,                          // startUpdateTimeStamp
//DSN000041641                                                          NULL,                          // endUpdateTimeStamp
//DSN000041641                                                          -1 );                          // maxCount
//DSN000041641 Add Start

//DSN000050720                    rc = txPostProcessActionListInq__130( strPostProcessActionListInqResult,
//DSN000050720                                                         strObjCommonIn,
//DSN000050720                                                         NULL,                          // key
//DSN000050720                                                         -1,                            // seqNo
//DSN000050720                                                         NULL,                          // watchdogName
//DSN000050720                                                         NULL,                          // postProcID
//DSN000050720                                                         -1,                            // syncFlag
//DSN000050720                                                         NULL,                          // txID
//DSN000050720                                                         NULL,                          // targetType
//DSN000050720                                                         strPostProcessTargetObject,
//DSN000050720                                                         NULL,                          // status
//DSN000050720                                                         -1,                            // passedTime
//DSN000050720                                                         NULL,                          // claimUserID
//DSN000050720                                                         NULL,                          // startCreateTimeStamp
//DSN000050720                                                         NULL,                          // endCreateTimeStamp
//DSN000050720                                                         NULL,                          // startUpdateTimeStamp
//DSN000050720                                                         NULL,                          // endUpdateTimeStamp
//DSN000050720                                                         -1,                            // maxCount
//DSN000050720                                                         false );                       // additionalInfoFlag
//DSN000041641 Add End
//DSN000050720 Add Start
//PSN000100936                    rc = postProcessQueue_ListDR__130( strPostProcessQueue_ListDR_out,
//PSN000100936                                                       strObjCommonIn,
//PSN000100936                                                       "",         //key
//PSN000100936                                                       -1,         //seqNo
//PSN000100936                                                       "",         //watchdogName
//PSN000100936                                                       "",         //postProcID
//PSN000100936                                                       -1,         //syncFlag
//PSN000100936                                                       "",         //txID
//PSN000100936                                                       "",         //targetType
//PSN000100936                                                       strPostProcessTargetObject,  // <====== objectID
//PSN000100936                                                       "",         //status
//PSN000100936                                                       -1,         //passedTime
//PSN000100936                                                       "",         //claimUserID
//PSN000100936                                                       "",         //startCreateTimeStamp
//PSN000100936                                                       "",         //endCreateTimeStamp
//PSN000100936                                                       "",         //startUpdateTimeStamp
//PSN000100936                                                       "",         //endUpdateTimeStamp
//PSN000100936                                                       -1,         //maxCount
//PSN000100936                                                       TRUE        //committedReadFlag
//PSN000100936                                                       );
//DSN000050720 Add End
//PSN000100936                    if ( rc != RC_OK )
//PSN000100936                    {
//PSN000100936                        PPT_METHODTRACE_V2("", "##### txPostProcessActionListInq__100() != RC_OK", rc);
//DSN000050720                        strPostProcessExecReqResult.strResult = strPostProcessActionListInqResult.strResult ;
//PSN000100936                        strPostProcessExecReqResult.strResult = strPostProcessQueue_ListDR_out.strResult ;  //DSN000050720
//PSN000100936                        return rc;
//PSN000100936                    }

//DSN000050720                    if( 0 == strPostProcessActionListInqResult.strPostProcessActionInfoSeq.length() )
//PSN000100936                    if( 0 == strPostProcessQueue_ListDR_out.strActionInfoSeq.length() )                     //DSN000050720
//PSN000100936                    {
//DSN000050720                        PPT_METHODTRACE_V1("", " #### 0 == strPostProcessActionListInqResult.strPostProcessActionInfoSeq.length ");
//PSN000100936                        PPT_METHODTRACE_V1("", " #### 0 == strPostProcessQueue_ListDR_out.strActionInfoSeq.length ");   //DSN000050720
//PSN000100936                        continue;
//PSN000100936                    }
//PSN000100936
//DSN000050720                    if( 0 == CIMFWStrCmp( strPostProcessActionListInqResult.strPostProcessActionInfoSeq[0].postProcID, SP_PostProcess_ActionID_InterFabXfer ) )
//PSN000100936                    if( 0 == CIMFWStrCmp( strPostProcessQueue_ListDR_out.strActionInfoSeq[0].postProcID, SP_PostProcess_ActionID_InterFabXfer ) )   //DSN000050720
//PSN000100936                    {
//PSN000100936                        PPT_METHODTRACE_V1("", " #### actionID == SP_PostProcess_ActionID_InterFabXfer");
//PSN000100936                        continue;
//PSN000100936                    }
//PSN000100936
//PSN000100936                    lotPostProcessingFlag = TRUE;
//PSN000100936                    break;
//PSN000100936                }
//PSN000100936 Add Start
                objPostProcess_LastFlagForCarrier_GetDR_out strPostProcess_LastFlagForCarrier_GetDR_out;
                objPostProcess_LastFlagForCarrier_GetDR_in  strPostProcess_LastFlagForCarrier_GetDR_in;
                strPostProcess_LastFlagForCarrier_GetDR_in.carrierID = strLot_cassette_Get_out.cassetteID;

                rc = postProcess_LastFlagForCarrier_GetDR( strPostProcess_LastFlagForCarrier_GetDR_out,
                                                           strObjCommonIn,
                                                           strPostProcess_LastFlagForCarrier_GetDR_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "postProcess_LastFlagForCarrier_GetDR() != RC_OK");
                    strPostProcessExecReqResult.strResult = strPostProcess_LastFlagForCarrier_GetDR_out.strResult;
                    return rc;
                }
                lotPostProcessingFlag = strPostProcess_LastFlagForCarrier_GetDR_out.lotPostProcessingFlag;
//PSN000100936 Add End
                //Set post process flag.
                if( FALSE == lotPostProcessingFlag )
                {
                    objCassette_inPostProcessFlag_Set_out strCassette_inPostProcessFlag_Set_out;
                    objCassette_inPostProcessFlag_Set_in  strCassette_inPostProcessFlag_Set_in;
                    strCassette_inPostProcessFlag_Set_in.cassetteID = strLot_cassette_Get_out.cassetteID;
                    strCassette_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE ;
                    rc = cassette_inPostProcessFlag_Set( strCassette_inPostProcessFlag_Set_out, strObjCommonIn, strCassette_inPostProcessFlag_Set_in);
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "##### cassette_inPostProcessFlag_Set() != RC_OK", rc);
                        strPostProcessExecReqResult.strResult = strCassette_inPostProcessFlag_Set_out.strResult ;
                        return rc;
                    }
                }
            }
        }   //DSIV00001007

        if( TRUE == interFabXferFlag )
        {
            SET_MSG_RC( strPostProcessExecReqResult, MSG_OK, RC_INTERFAB_LOTXFER_EXECUTED );
            return ( RC_INTERFAB_LOTXFER_EXECUTED );
        }
//DSIV00000214 add end
    }
//DSN000096126 Add Start
//DSN000101569    else if( 0 == CIMFWStrCmp( info.targetType , SP_PostProcess_TargetType_CAST ) )
//DSN000101569 add start
    // Post process for durables process
    else if( 0 == CIMFWStrCmp( info.targetType , SP_PostProcess_TargetType_CAST ) && 0 == CIMFWStrLen(lotID.identifier) )
//DSN000101569 add end
    {
        PPT_METHODTRACE_V1("", "targetType is CAST");

        objDurable_OnRoute_Check_out strDurable_OnRoute_Check_out;
        objDurable_OnRoute_Check_in  strDurable_OnRoute_Check_in;
        strDurable_OnRoute_Check_in.durableCategory = durableCategory;
        strDurable_OnRoute_Check_in.durableID       = cassetteID;
        rc = durable_OnRoute_Check(strDurable_OnRoute_Check_out, strObjCommonIn, strDurable_OnRoute_Check_in);
        if( rc == RC_DURABLE_ONROUTE)
        {
            PPT_METHODTRACE_V1("", "durable_OnRoute_Check() == RC_DURABLE_ONROUTE");

            //--------------------------
            // Delete Queue
            //--------------------------
            pptPostProcessActionInfoSequence__100 actionInfoSeq(1);
            actionInfoSeq.length(1);
            actionInfoSeq[0].dKey  = info.dKey;
            actionInfoSeq[0].seqNo = info.seqNo;
            objPostProcessQueue_UpdateDR_out__100 strPostProcessQueue_UpdateDR_out;
            rc = postProcessQueue_UpdateDR__100( strPostProcessQueue_UpdateDR_out, strObjCommonIn, SP_PostProcessActionInfo_Delete, actionInfoSeq );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "postProcessQueue_UpdateDR__100() != RC_OK");
                strPostProcessExecReqResult.strResult = strPostProcessQueue_UpdateDR_out.strResult;
                return rc ;
            }

//DSN000101569            if(bHoldRelease == TRUE)
//DSN000101569            {
//DSN000101569                PPT_METHODTRACE_V1("", "bHoldRelease == TRUE");

            //---------------------------------------------------
            // Check whether Queue of the same Durable remains yet.
            //---------------------------------------------------
            objPostProcessQueue_GetDR_out__100 strPostProcessQueue_GetDR_out3;
            rc = postProcessQueue_GetDR__100(  strPostProcessQueue_GetDR_out3, strObjCommonIn, key, -1, nullSeqNoList, NULL, -1, info.targetType, cassetteID );
            if( rc != RC_OK )
            {
                if( rc == RC_NOT_FOUND_ENTRY )
                {
                    PPT_METHODTRACE_V1("", "rc == RC_NOT_FOUND_ENTRY");

                    // Set InPostProcessFlag of Durable to OFF
                    objDurable_inPostProcessFlag_Set_out strDurable_inPostProcessFlag_Set_out;
                    objDurable_inPostProcessFlag_Set_in  strDurable_inPostProcessFlag_Set_in;
                    strDurable_inPostProcessFlag_Set_in.durableCategory   = durableCategory;
                    strDurable_inPostProcessFlag_Set_in.durableID         = cassetteID;
                    strDurable_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE;
                    rc = durable_inPostProcessFlag_Set(strDurable_inPostProcessFlag_Set_out, strObjCommonIn, strDurable_inPostProcessFlag_Set_in);
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "durable_inPostProcessFlag_Set() != RC_OK");
                        strPostProcessExecReqResult.strResult = strDurable_inPostProcessFlag_Set_out.strResult;
                        return( rc );
                    }

                    if( bHoldRelease == TRUE && bFindLockHoldFlag == TRUE && lockHoldUseFlag == 1 )
                    {
                        // Release Durable Hold.
                        PPT_METHODTRACE_V1("", " Release Durables' Hold (LOCK) ");
                        pptHoldDurableReleaseReqResult  strHoldDurableReleaseReqResult;
                        pptHoldDurableReleaseReqInParam strHoldDurableReleaseReqInParam;
                        strHoldDurableReleaseReqInParam.durableCategory     = durableCategory;
                        strHoldDurableReleaseReqInParam.durableID           = cassetteID;
                        strHoldDurableReleaseReqInParam.releaseReasonCodeID.identifier = CIMFWStrDup(SP_Reason_DurableLockRelease);
                        strHoldDurableReleaseReqInParam.strDurableHoldList  = strDurableHoldList;
                        rc = txHoldDurableReleaseReq(strHoldDurableReleaseReqResult, strObjCommonIn, strHoldDurableReleaseReqInParam, claimMemo);
//DSN000101569                        if( rc != RC_OK )
//DSN000101569                        {
//DSN000101569                            PPT_METHODTRACE_V1("", "txHoldDurableReleaseReq() != RC_OK");
//DSN000101569 add start
                        if( rc != RC_OK
                         && rc != RC_INVALID_CAST_STAT
                         && rc != RC_INVALID_RETICLEPOD_STAT
                         && rc != RC_INVALID_RETICLE_STAT
                         && rc != RC_DRBL_NOT_AVAILSTAT_FOR_DRBLPROCESS )
                        {
                            PPT_METHODTRACE_V2("", "txHoldDurableReleaseReq() != RC_OK", rc);
//DSN000101569 add end
                            strPostProcessExecReqResult.strResult = strHoldDurableReleaseReqResult.strResult;
                            return( rc );
                        }
                    }
                }
                else
                {
                    PPT_METHODTRACE_V1("", "postProcessQueue_GetDR__100() != RC_OK");
                    strPostProcessExecReqResult.strResult = strPostProcessQueue_GetDR_out3.strResult;
                    return rc;
                }
            }
//DSN000101569            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "durable_OnRoute_Check() == RC_DURABLE_NOT_ONROUTE");
            pptPostProcessActionInfoSequence__100 actionInfoSeq(1);
            actionInfoSeq.length(1);
            actionInfoSeq[0].dKey  = info.dKey;
            actionInfoSeq[0].seqNo = info.seqNo;

            objPostProcessQueue_UpdateDR_out__100 strPostProcessQueue_UpdateDR_out;
            rc = postProcessQueue_UpdateDR__100(strPostProcessQueue_UpdateDR_out, strObjCommonIn, SP_PostProcessActionInfo_Delete, actionInfoSeq);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "postProcessQueue_UpdateDR__100() != RC_OK");
                strPostProcessExecReqResult.strResult = strPostProcessQueue_UpdateDR_out.strResult;
                return rc ;
            }
        }
    }
//DSN000096126 Add End
    else
    {
        //--------------------------
        // Delete Queue
        //--------------------------
//DSIV00000201        pptPostProcessActionInfoSequence    actionInfoSeq(1);
        pptPostProcessActionInfoSequence__100    actionInfoSeq(1);  //DSIV00000201
        actionInfoSeq.length(1);
        actionInfoSeq[0].dKey  = info.dKey;
        actionInfoSeq[0].seqNo = info.seqNo;

//DSIV00000201        objPostProcessQueue_UpdateDR_out strPostProcessQueue_UpdateDR_out;
//DSIV00000201        rc = postProcessQueue_UpdateDR( strPostProcessQueue_UpdateDR_out, strObjCommonIn, SP_PostProcessActionInfo_Delete, actionInfoSeq );
//DSIV00000201 add start
        objPostProcessQueue_UpdateDR_out__100 strPostProcessQueue_UpdateDR_out;
        rc = postProcessQueue_UpdateDR__100( strPostProcessQueue_UpdateDR_out, strObjCommonIn, SP_PostProcessActionInfo_Delete, actionInfoSeq );
//DSIV00000201 add end
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "postProcessQueue_UpdateDR__100() != RC_OK");
            strPostProcessExecReqResult.strResult = strPostProcessQueue_UpdateDR_out.strResult;
            return rc ;
        }
    }

    //-------------------------------------------------------------------------------------
    // commitFlag is checked whether performing with TX_COMMIT or without TX_COMMIT.
    //-------------------------------------------------------------------------------------
    PPT_METHODTRACE_V2("", "commitFlag is ...", info.commitFlag);
    if( info.commitFlag == TRUE )
    {
        strPostProcessExecReqResult.strResult = strPostProcessQueue_GetDR_out.strResult;
        SET_MSG_RC( strPostProcessExecReqResult, MSG_POSTPROC_NEXT_ENTRY_WITH_COMMIT, RC_POSTPROC_NEXT_ENTRY_WITH_COMMIT);
        return ( RC_POSTPROC_NEXT_ENTRY_WITH_COMMIT );
    }
    else
    {
        strPostProcessExecReqResult.strResult = strPostProcessQueue_GetDR_out.strResult;
        SET_MSG_RC( strPostProcessExecReqResult, MSG_POSTPROC_NEXT_ENTRY_WITHOUT_COMMIT, RC_POSTPROC_NEXT_ENTRY_WITHOUT_COMMIT);
        return ( RC_POSTPROC_NEXT_ENTRY_WITHOUT_COMMIT );
    }

    //-----------------------------
    // Return to Main
    //-----------------------------
    SET_MSG_RC(strPostProcessExecReqResult, MSG_OK, RC_OK);
    PPT_METHODTRACE_EXIT("PPTManager_i:: txPostProcessExecReq__100") ;
    return RC_OK;
}
