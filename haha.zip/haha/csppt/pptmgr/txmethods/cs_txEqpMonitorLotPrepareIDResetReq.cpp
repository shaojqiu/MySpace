//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txEqpMonitorLotPrepareIDResetReq.cpp
//
#include "cs_pptmgr.hpp"
//
// Class: PPTManager
//
// Service: cs_txEqpMonitorLotPrepareIDResetReq()
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------- -------------- -------------------------------------------
// 2017/10/18 INN-R170016   Yangxiaojun    NPW Monitor Customization
//
// Description:
//
// Return:
//     long
//
// Parameter:
//      csEqpMonitorLotPrepareIDResetReqResult&         strEqpMonitorLotPrepareIDResetReqResult
//      const pptObjCommonIn&                           strObjCommonIn
//      const csEqpMonitorLotPrepareIDResetReqInParm&   strEqpMonitorLotPrepareIDResetReqInParm
//      const char*                                     claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//

CORBA::Long CS_PPTManager_i::cs_txEqpMonitorLotPrepareIDResetReq(
    csEqpMonitorLotPrepareIDResetReqResult&         strEqpMonitorLotPrepareIDResetReqResult,
    const pptObjCommonIn&                           strObjCommonIn,
    const csEqpMonitorLotPrepareIDResetReqInParm&   strEqpMonitorLotPrepareIDResetReqInParm,
    const char*                                     claimMemo
    CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txEqpMonitorLotPrepareIDResetReq")
    CORBA::Long rc = RC_OK;
        
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txEqpMonitorLotPrepareIDResetReq")
    return( RC_OK );
}
