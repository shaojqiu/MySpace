#ifndef lint
static char *sccsid =  "%Z% %I% %W% %G% %U% [ %H% %T% ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2012. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2012. All rights reserved.
//
// SiView
// Name: txArrivalCarrierCancelForInternalBufferReq__090.cpp
//

#include "cs_pptmgr.hpp"

#include <unistd.h>

// Class: PPTManager
//
// Service: txArrivalCarrierCancelForInternalBufferReq__090
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2001/07/23 D4000028 K.Takikita     Initial Release (R40)
// 2001/08/20 P4000099 K.Matsuei      Invalid obj-method filename.
// 2001/08/30 D4000028(1) T.Yamamoto  Fix for Trap
// 2001/08/30 D4000028(2) T.Yamamoto  Fix for logic of Check
// 2001/09/07 D4000060 K.Kido         Add retry TCS request logic
// 2001/10/11 D4000348    T.Yamamoto  Add cassetteCount:0 case, return error
// 2002/02/14 D4100134 C.Tsuchiya     Use getenv() instead of Mgr class member 'theSP_xxx'
// 2004/04/28 P5100087 K.Matsuei      ModeChange cannot be performed by DispatchCarrierID remains in Port.
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2005/09/09 D6000418 M.Murata       Lock Port Object.
// 2005/10/24 D6000479 K.Kido         Lock Port Object.
// 2007/04/20 D9000001 H.Murakami     64bit support.
// ------------------------------------------------------------------------------
// 2007/06/20 D9000005 K.Kido         Intitial release for Wafer Sorter automation (AAS support).
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2012/11/29 DSN000049350 F.Chen         Equipment parallel processing support (P2)
//---------- ------------ -------------- -------------------------------------------
// 2017/09/25 INN-R170003  XL.Cong        Add new transfer state PI/PO to control FOUP location
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//  pptArrivalCarrierCancelForInternalBufferReqResult strArrivalCarrierCancelForInternalBufferReqResult
//  in pptUser requestUserID,                              <= the value input from OPI.
//  in objectIdentifier equipmentID,                       <= the parameter returned from txEqpInfoInq.
//  in string portGroupID,                                 <= the parameter selected by Operator.
//  in pptNPWXferCassetteSequence strNPWXferCassette,      -
//  in CORBA::Boolean notifyToTCSFlag,                     -
//  in string claimMemo;                                  -
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090 (
    pptArrivalCarrierCancelForInternalBufferReqResult__090& strArrivalCarrierCancelForInternalBufferReqResult,
    const pptObjCommonIn&                                   strObjCommonIn,
    const objectIdentifier&                                 equipmentID,
    const char *                                            portGroupID,
    const pptNPWXferCassetteSequence&                       strNPWXferCassette,
    CORBA::Boolean                                          notifyToTCSFlag,
    const char *                                            claimMemo
    CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090 ")

    CORBA::Long rc = RC_OK ;
    objectIdentifier    controlJobID;

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Check Transaction ID                                                */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "Check Transaction ID" );
    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID );

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "equipment_categoryVsTxID_CheckCombination() != RC_OK" );
        strArrivalCarrierCancelForInternalBufferReqResult.strResult = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return( rc );
    }


    CORBA::Long nStrNPWXferCassetteLen = strNPWXferCassette.length();      //4000348
                                                                           //4000348
    if( nStrNPWXferCassetteLen == 0 )                                      //4000348
    {                                                                      //4000348
        PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "strNPWXferCassette.length is 0"); //4000348
        SET_MSG_RC(strArrivalCarrierCancelForInternalBufferReqResult,MSG_INVALID_INPUT_PARM,RC_INVALID_INPUT_PARM);//4000348
        return( RC_INVALID_INPUT_PARM );                                   //4000348
    }                                                                      //4000348

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Object Lock Process                                                 */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "Object Lock Process" );

//DSN000049350 Add Start
    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = equipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXLGC017" ); // TxArrivalCarrierCancelForInternalBufferReq
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

    PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strArrivalCarrierCancelForInternalBufferReqResult.strResult = strObject_lockMode_Get_out.strResult;
        return( rc );
    }
    
    objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
    
    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
    if (lockMode != SP_EQP_LOCK_MODE_WRITE)
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
        objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
        objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
        
        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strArrivalCarrierCancelForInternalBufferReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
        /*--------------------------------*/
        /*   Lock objects to be updated   */
        /*--------------------------------*/
        PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "Lock objects to be updated" );
        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn,equipmentID, SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "object_Lock" );
            strArrivalCarrierCancelForInternalBufferReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    } //DSN000049350

//4000348    CORBA::Long nStrNPWXferCassetteLen = strNPWXferCassette.length();
    CORBA::Long i;
    pptStartCassetteSequence     strStartCassetteSequence;
    strStartCassetteSequence.length(nStrNPWXferCassetteLen);                                 //D4000028(1)

//D6000418 add start
    /*--------------------------------------------*/
    /*                                            */
    /*        Port Object Lock Process            */
    /*                                            */
    /*--------------------------------------------*/
    PPT_METHODTRACE_V1("", "#### Port Object Lock ");
    /*--------------------------------*/
    /*   Lock Port object (To)        */
    /*--------------------------------*/
//DSN000049350 Add Start
    if (lockMode != SP_EQP_LOCK_MODE_WRITE)
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
        CORBA::ULong lenCast = strNPWXferCassette.length();
        
        for ( CORBA::ULong ll=0 ; ll<lenCast ; ll++ )
        {
            PPT_METHODTRACE_V2( "", "calling object_LockForEquipmentResource()", SP_ClassName_PosPortResource );
            rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                  strObjCommonIn,
                                                  equipmentID,
                                                  strNPWXferCassette[ll].loadPortID,
                                                  SP_ClassName_PosPortResource );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", rc);
                strArrivalCarrierCancelForInternalBufferReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
                return( rc );
            }
            
            PPT_METHODTRACE_V2("", "Locked port object  : ", strNPWXferCassette[ll].loadPortID.identifier);
        }// lenCast = strNPWXferCassette.length();
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
        objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
        rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out,
                                                        strObjCommonIn,
                                                        equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "##### equipment_portInfoForInternalBuffer_GetDR() != RC_OK", rc);
            strArrivalCarrierCancelForInternalBufferReqResult.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
            return( rc );
        }

//D6000479    for ( CORBA::Long ii=0; ii<nStrNPWXferCassetteLen; ii++ )
//D6000479    {
        CORBA::Long lenPortInfo = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
        for ( CORBA::Long jj=0 ; jj<lenPortInfo ; jj++ )
        {
//D6000479            if ( 0 != CIMFWStrCmp( strNPWXferCassette[ii].loadPortID.identifier,
//D6000479                                   strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[jj].portID.identifier) )
//D6000479            {
//D6000479                PPT_METHODTRACE_V1("", "Not same portID, <<continue...>>");
//D6000479                continue;
//D6000479            }

//DSN000049350            objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
            rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                  strObjCommonIn,
                                                  equipmentID,
                                                  strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[jj].portID,
                                                  SP_ClassName_PosPortResource );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[jj].portID.identifier);
                strArrivalCarrierCancelForInternalBufferReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
                return( rc );
            }
            PPT_METHODTRACE_V2("", "Locked port object(to)  : ", strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[jj].portID.identifier);
        }// lenPortInfo = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
//D6000479    }// strNPWXferCassette.length()
    } //DSN000049350

    /*--------------------------------*/
    /*   Lock Port object (From)      */
    /*--------------------------------*/
//D6000479    for ( ii=0 ; ii<nStrNPWXferCassetteLen ; ii++ )
    for ( CORBA::Long ii=0 ; ii<nStrNPWXferCassetteLen ; ii++ )
    {
        /*-----------------------------------*/
        /*  Check cassette transfer status   */
        /*-----------------------------------*/
        PPT_METHODTRACE_V1( "", "Check cassette transfer status");
        objCassette_transferState_Get_out strCassette_transferState_Get_out;
        rc = cassette_transferState_Get( strCassette_transferState_Get_out,
                                         strObjCommonIn,
                                         strNPWXferCassette[ii].cassetteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "cassette_transferState_Get != RC_OK", rc);
            strArrivalCarrierCancelForInternalBufferReqResult.strResult = strCassette_transferState_Get_out.strResult;
            return( rc );
        }
//INN-R170003 if ( 0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn ) )
//INN-R170003 add start
        if ( 0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn )
           || 0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentOut ) )
//INN-R170003 add end
        {
            PPT_METHODTRACE_V2( "", "Cassette's transferState == EI ", strNPWXferCassette[ii].cassetteID.identifier);
            /*------------------------------------*/
            /*   Get Cassette Info in Equipment   */
            /*------------------------------------*/
            PPT_METHODTRACE_V1( "","Get Cassette Info in Equipment");
            objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
            rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                           strObjCommonIn,
                                           strNPWXferCassette[ii].cassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "", "cassette_equipmentID_Get != RC_OK", rc);
                strArrivalCarrierCancelForInternalBufferReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
                return( rc );
            }
            PPT_METHODTRACE_V2( "", "equipmentID", strCassette_equipmentID_Get_out.equipmentID.identifier);

            objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
            rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out,
                                                            strObjCommonIn,
                                                            strCassette_equipmentID_Get_out.equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "##### equipment_portInfoForInternalBuffer_GetDR != RC_OK", rc);
                strArrivalCarrierCancelForInternalBufferReqResult.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
                return( rc );
            }

            /*----------------------------------------------------------*/
            /*  Lock port object which has the specified cassette.      */
            /*----------------------------------------------------------*/
            CORBA::Long lenFromPort = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
            for ( CORBA::Long jj=0 ; jj < lenFromPort ; jj++ )
            {
//D6000479      if ( 0 == CIMFWStrCmp( strNPWXferCassette[ii].cassetteID.identifier,
//D6000479                             strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[jj].loadedCassetteID.identifier) )
//D6000479      {
//DSN000049350 Add Start
					if (lockMode != SP_EQP_LOCK_MODE_WRITE )
					{
						PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
						// This port is not reserved by this NPWRsv
						if ( 0 != CIMFWStrCmp( strNPWXferCassette[ii].cassetteID.identifier,
											   strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[jj].loadedCassetteID.identifier) )
						{
							PPT_METHODTRACE_V2("", "cassette is not reserved by NPW", strNPWXferCassette[ii].cassetteID.identifier);
							// Check next port
							continue;
						}
					}
//DSN000049350 Add End

//DSN000049350                    objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
                    rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                          strObjCommonIn,
                                                          strCassette_equipmentID_Get_out.equipmentID,
                                                          strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[jj].portID,
                                                          SP_ClassName_PosPortResource );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[jj].portID.identifier);
                        strArrivalCarrierCancelForInternalBufferReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
                        return( rc );
                    }
                    PPT_METHODTRACE_V2("", "Locked port object  : ", strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[jj].portID.identifier);
//D6000479      }
            }// lenFromPort = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
        }// 0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn )
    }// nStrNPWXferCassetteLen = strNPWXferCassette.length();

//D6000418 add end

//DSN000049350 Add Start
    objectIdentifierSequence cassetteIDs;
    cassetteIDs.length(nStrNPWXferCassetteLen);
//DSN000049350 Add End

    for( i = 0 ; i < nStrNPWXferCassetteLen ; i++ )
    {
        PPT_METHODTRACE_V2("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "strNPWXferCassette",i );


//DSN000049350       rc = object_Lock( strObject_Lock_out ,strObjCommonIn,strNPWXferCassette[i].cassetteID, SP_ClassName_PosCassette );
//DSN000049350       if ( rc != RC_OK )
//DSN000049350       {
//DSN000049350            PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "object_Lock" );
//DSN000049350            strArrivalCarrierCancelForInternalBufferReqResult.strResult = strObject_Lock_out.strResult;
//DSN000049350            return( rc );
//DSN000049350       }

//DSN000049350 Add Start
        cassetteIDs[i] = strNPWXferCassette[i].cassetteID;  //DSN000049350
        if (lockMode != SP_EQP_LOCK_MODE_WRITE)
        {
            PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
            objAdvanced_object_LockForEquipmentResource_out strAdvanced_object_LockForEquipmentResource_out;
            objAdvanced_object_LockForEquipmentResource_in strAdvanced_object_LockForEquipmentResource_in;
            strAdvanced_object_LockForEquipmentResource_in.equipmentID              = equipmentID;
            strAdvanced_object_LockForEquipmentResource_in.className                = CIMFWStrDup( SP_ClassName_PosMaterialLocation_ByCastID );
            strAdvanced_object_LockForEquipmentResource_in.objectID                 = strNPWXferCassette[i].cassetteID;
            strAdvanced_object_LockForEquipmentResource_in.objectLockType           = SP_ObjectLock_LockType_WRITE;
            strAdvanced_object_LockForEquipmentResource_in.bufferResourceName       = strNPWXferCassette[i].loadPurposeType;
            strAdvanced_object_LockForEquipmentResource_in.bufferResourceLockType   = SP_ObjectLock_LockType_READ;
            
            PPT_METHODTRACE_V3( "", "calling advanced_object_LockForEquipmentResource()", SP_ClassName_PosMaterialLocation_ByCastID, strNPWXferCassette[i].cassetteID.identifier);
            rc =  advanced_object_LockForEquipmentResource( strAdvanced_object_LockForEquipmentResource_out,
                                                            strObjCommonIn,
                                                            strAdvanced_object_LockForEquipmentResource_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_LockForEquipmentResource() != RC_OK", rc);
                strArrivalCarrierCancelForInternalBufferReqResult.strResult = strAdvanced_object_LockForEquipmentResource_out.strResult;
                return( rc );
            }

        }
//DSN000049350 Add End

        PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "Make StrStartCassette" );
        PPT_METHODTRACE_V2("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "loadSequenceNumber ", strNPWXferCassette[i].loadSequenceNumber );
        PPT_METHODTRACE_V2("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "cassetteID         ", strNPWXferCassette[i].cassetteID.identifier         );
        PPT_METHODTRACE_V2("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "loadPurposeType    ", strNPWXferCassette[i].loadPurposeType    );
        PPT_METHODTRACE_V2("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "loadPortID         ", strNPWXferCassette[i].loadPortID.identifier         );
        PPT_METHODTRACE_V2("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "unloadPortID       ", strNPWXferCassette[i].unloadPortID.identifier       );

        strStartCassetteSequence[i].loadSequenceNumber = strNPWXferCassette[i].loadSequenceNumber ;
        strStartCassetteSequence[i].cassetteID         = strNPWXferCassette[i].cassetteID         ;
        strStartCassetteSequence[i].loadPurposeType    = strNPWXferCassette[i].loadPurposeType    ;
        strStartCassetteSequence[i].loadPortID         = strNPWXferCassette[i].loadPortID         ;
        strStartCassetteSequence[i].unloadPortID       = strNPWXferCassette[i].unloadPortID       ;
    }

//DSN000049350 Add Start
    /*-------------------*/
    /*   Lock Cassette   */
    /*-------------------*/
    objObjectSequence_Lock_out strObjectSequence_Lock_out;

    PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosCassette );
    rc = objectSequence_Lock( strObjectSequence_Lock_out,
                              strObjCommonIn,
                              cassetteIDs,
                              SP_ClassName_PosCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
        strArrivalCarrierCancelForInternalBufferReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }
//DSN000049350 Add End

//D4000028(2) Delete Start
//  /*-----------------------------------------------------------------------*/
//  /*                                                                       */
//  /*   Check Process for Cassette                                          */
//  /*                                                                       */
//  /*   The following conditions are checked by this object                 */
//  /*                                                                       */
//  /*   - dispatchState                                                     */
//  /*   - controlJobID                                                      */
//  /*                                                                       */
//  /*-----------------------------------------------------------------------*/
//  PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "/*--------------------------------*/" );
//  PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "/*   Check Process for Cassette   */" );
//  PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "/*--------------------------------*/" );
//
//  objCassette_CheckConditionForStartReserveCancel_out strCassette_CheckConditionForStartReserveCancel_out;
//  rc = cassette_CheckConditionForStartReserveCancel( strCassette_CheckConditionForStartReserveCancel_out,
//                                                     strObjCommonIn,
//                                                     controlJobID,
//                                                     strStartCassetteSequence );
//  if ( rc != RC_OK )
//  {
//      PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "cassette_CheckConditionForStartReserveCancel() != RC_OK");
//      strArrivalCarrierCancelForInternalBufferReqResult.strResult = strCassette_CheckConditionForStartReserveCancel_out.strResult;
//      return( rc );
//  }
//
//  /*-----------------------------------------------------------------------*/
//  /*                                                                       */
//  /*   Check Process for Lot                                               */
//  /*                                                                       */
//  /*   The following conditions are checked by this object                 */
//  /*                                                                       */
//  /*   - lotProcessState                                                   */
//  /*   - controlJobID                                                      */
//  /*                                                                       */
//  /*-----------------------------------------------------------------------*/
//  PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "/*---------------------------*/" );
//  PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "/*   Check Process for Lot   */" );
//  PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "/*---------------------------*/" );
//
//  objLot_CheckConditionForStartReserveCancel_out strLot_CheckConditionForStartReserveCancel_out;
//  rc = lot_CheckConditionForStartReserveCancel( strLot_CheckConditionForStartReserveCancel_out,
//                                                strObjCommonIn,
//                                                controlJobID,
//                                                strStartCassetteSequence );
//  if ( rc != RC_OK )
//  {
//      PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "lot_CheckConditionForStartReserveCancel() != RC_OK");
//      strArrivalCarrierCancelForInternalBufferReqResult.strResult = strLot_CheckConditionForStartReserveCancel_out.strResult;
//      return( rc );
//  }
//
//   /*-----------------------------------------------------------------------*/
//   /*                                                                       */
//   /*   Check Process for Equipment                                         */
//   /*                                                                       */
//   /*   The following conditions are checked by this object                 */
//   /*                                                                       */
//   /*   - reservedControlJobID                                              */
//   /*                                                                       */
//   /*-----------------------------------------------------------------------*/
//     PPT_METHODTRACE_V1("", "/*---------------------------------*/" );
//     PPT_METHODTRACE_V1("", "/*   Check Process for Equipment   */" );
//     PPT_METHODTRACE_V1("", "/*---------------------------------*/" );
//
//     objEquipment_CheckConditionForStartReserveCancel_out strEquipment_CheckConditionForStartReserveCancel_out;
//     rc = equipment_CheckConditionForStartReserveCancel( strEquipment_CheckConditionForStartReserveCancel_out,
//                                                         strObjCommonIn,
//                                                         equipmentID,
//                                                         controlJobID );
//     if ( rc != RC_OK )
//     {
//         PPT_METHODTRACE_V1("", "##### equipment_CheckConditionForStartReserveCancel() != RC_OK");
//         strStartLotsReservationCancelForInternalBufferReqResult.strResult = strEquipment_CheckConditionForStartReserveCancel_out.strResult;
//         return( rc );
//     }
//
//  /*---------------------------------*/
//  /*   Get Equipment's Online Mode   */
//  /*---------------------------------*/
//  PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "/*---------------------------------*/" );
//  PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "/*   Get Equipment's Online Mode   */" );
//  PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "/*---------------------------------*/" );
//
//  objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
//  rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
//                                              strObjCommonIn,
//                                              equipmentID,
//                                              strStartCassetteSequence[0].unloadPortID );
//  if ( rc != RC_OK )
//  {
//      PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "portResource_currentOperationMode_Get() != RC_OK");
//      strArrivalCarrierCancelForInternalBufferReqResult.strResult = strPortResource_currentOperationMode_Get_out.strResult;
//      return( rc );
//  }
//
//  /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
//  /*                                                                       */
//  /*   Port Status Change Process    (From Equipment)                      */
//  /*                                                                       */
//  /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
//  PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "Port Status Change Process    (From Equipment)");
//
//  for( i = 0 ; i < nStrNPWXferCassetteLen ; i ++ )
//  {
//      /*-----------------------------------*/
//      /*  Check cassette transfer status   */
//      /*-----------------------------------*/
//      PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "Check cassette transfer status");
//      objCassette_transferState_Get_out strCassette_transferState_Get_out;
//      rc = cassette_transferState_Get( strCassette_transferState_Get_out,
//                                       strObjCommonIn,
//                                       strNPWXferCassette[i].cassetteID );
//      if ( rc != RC_OK )
//      {
//          PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "cassette_transferState_Get() != RC_OK");
//          strArrivalCarrierCancelForInternalBufferReqResult.strResult = strCassette_transferState_Get_out.strResult;
//          return( rc );
//      }
//
//      if ( 0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn ) )
//      {
//
//          /*------------------------------------*/
//          /*   Get Cassette Info in Equipment   */
//          /*------------------------------------*/
//          PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "Get Cassette Info in Equipment");
//          objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
//          rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
//                                         strObjCommonIn,
//                                         strNPWXferCassette[i].cassetteID );
//
//          if ( rc != RC_OK )
//          {
//              PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "cassette_equipmentID_Get() != RC_OK");
//              strArrivalCarrierCancelForInternalBufferReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
//              return( rc );
//          }
//
//          objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
//          rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
//                                       strObjCommonIn,
//                                       strCassette_equipmentID_Get_out.equipmentID );
//
//          if ( rc != RC_OK )
//          {
//              PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "equipment_portInfo_Get() != RC_OK");
//              strArrivalCarrierCancelForInternalBufferReqResult.strResult = strEquipment_portInfo_Get_out.strResult;
//              return( rc );
//          }
//
//
//          CORBA::Long lenEqpPort = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
//          for ( CORBA::Long j=0; j < lenEqpPort; j++ )
//          {
//              PPT_METHODTRACE_V2("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "strEqpPortStatus",j);
//              if ( 0 == CIMFWStrCmp( strNPWXferCassette[i].cassetteID.identifier,
//                                     strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier) )
//              {
//
//                  if ( 0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_UnloadReq) &&
//                       0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].dispatchState, SP_PortRsc_DispatchState_Dispatched) )
//                  {
//
//                      /*------------------------*/
//                      /*   change to Required   */
//                      /*------------------------*/
//                      PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "change to Required");
//                      objectIdentifier dummyOI;
//                      objEquipment_dispatchState_Change_out strEquipment_dispatchState_Change_out;
//                      rc = equipment_dispatchState_Change( strEquipment_dispatchState_Change_out,
//                                                           strObjCommonIn,
//                                                           strCassette_equipmentID_Get_out.equipmentID,
//                                                           strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portID,
//                                                           SP_PortRsc_DispatchState_Required,
//                                                           dummyOI,
//                                                           dummyOI,
//                                                           dummyOI,
//                                                           dummyOI );
//
//                      if ( rc != RC_OK )
//                      {
//                          PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "equipment_dispatchState_Change() != RC_OK");
//                          strArrivalCarrierCancelForInternalBufferReqResult.strResult = strEquipment_dispatchState_Change_out.strResult ;
//                          return( rc );
//                      }
//                  }
//              }
//          }
//      }
//  }
//D4000028(2) Delete End

//P5100087 start
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        /*                                                                       */
        /*   Port Status Change Process    (To Equipment)                        */
        /*                                                                       */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
        PPT_METHODTRACE_V1("", "Port Status Change Process    (To Equipment)" );
        for ( i=0 ; i < nStrNPWXferCassetteLen ; i++ )
        {
            PPT_METHODTRACE_V2("", "PPTNPWCassette Len" ,i);

            objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
            rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out,
                                                            strObjCommonIn,
                                                            equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "##### equipment_portInfoForInternalBuffer_GetDR() != RC_OK", rc);
                strArrivalCarrierCancelForInternalBufferReqResult.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
                return( rc );
            }

            CORBA::Long lenPortInfo = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
            for ( CORBA::Long j=0 ; j<lenPortInfo ; j++ )
            {
                if ( 0 != CIMFWStrCmp( strNPWXferCassette[i].loadPortID.identifier,
                                       strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID.identifier) )
                {
                    PPT_METHODTRACE_V1("", "strNPWXferCassette[i].loadPortID != [j].portID.identifier" );
                    continue;
                }

                if ( 0 == CIMFWStrCmp( SP_PortRsc_DispatchState_Dispatched, strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].dispatchState) )
                {
                    PPT_METHODTRACE_V1("", "dispatchState is [Dispatched]" );
                    /*------------------------*/
                    /*   change to Required   */
                    /*------------------------*/
                    objectIdentifier dummyOI;
                    objEquipment_dispatchState_Change_out strEquipment_dispatchState_Change_out ;
                    rc = equipment_dispatchState_Change( strEquipment_dispatchState_Change_out,
                                                         strObjCommonIn,
                                                         equipmentID,
                                                         strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID,
                                                         SP_PortRsc_DispatchState_Required,
                                                         dummyOI,
                                                         dummyOI,
                                                         dummyOI,
                                                         dummyOI );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "##### equipment_dispatchState_Change() != RC_OK", rc);
                        strArrivalCarrierCancelForInternalBufferReqResult.strResult = strEquipment_dispatchState_Change_out.strResult ;
                        return( rc );
                    }

                    break;
                }
            }
        }

        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        /*   Port Status Change Process    (From Equipment)                                                           */
        /*                                                                                                            */
        /*   Normally, equipment_dispatchState_Change() of this logic is not performed.                               */
        /*   Because condition of XferState:[EI] , PortState:[UnLoad] , DispatchState:[Dispatched] does not happen.   */
        /*   But this logic remains in order to delete garbage.                                                       */
        /*                                                                                                            */
        /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-*/
        PPT_METHODTRACE_V1("", "Port Status Change Process" );

        for ( i=0; i < nStrNPWXferCassetteLen; i++ )
        {
            PPT_METHODTRACE_V2("", "PPTNpwCassetteLen", i);
            /*-----------------------------------*/
            /*  Check cassette transfer status   */
            /*-----------------------------------*/
            objCassette_transferState_Get_out strCassette_transferState_Get_out;
            rc = cassette_transferState_Get( strCassette_transferState_Get_out,
                                             strObjCommonIn,
                                             strNPWXferCassette[i].cassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "##### cassette_transferState_Get() != RC_OK", rc);
                strArrivalCarrierCancelForInternalBufferReqResult.strResult = strCassette_transferState_Get_out.strResult;
                return( rc );
            }

//INN-R170003 if ( 0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn ) )
//INN-R170003 add start
            if ( 0 == CIMFWStrCmp( strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn ) ||
               0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentOut ) )
//INN-R170003 add end
            {
                PPT_METHODTRACE_V1("", "transferState = [EI]" );
                /*------------------------------------*/
                /*   Get Cassette Info in Equipment   */
                /*------------------------------------*/
                objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
                rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                               strObjCommonIn,
                                               strNPWXferCassette[i].cassetteID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "##### cassette_equipmentID_Get() != RC_OK", rc);
                    strArrivalCarrierCancelForInternalBufferReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
                    return( rc );
                }

                objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
                rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out,
                                                                strObjCommonIn,
                                                                strCassette_equipmentID_Get_out.equipmentID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "##### equipment_portInfo_Get() != RC_OK", rc);
                    strArrivalCarrierCancelForInternalBufferReqResult.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
                    return( rc );
                }

                CORBA::Long lenEqpPort = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
                PPT_METHODTRACE_V2("", "lenEqpPort", lenEqpPort);
                for ( CORBA::Long j=0; j < lenEqpPort; j++ )
                {
                    PPT_METHODTRACE_V2("", "PptEqpPortStatus", j);
                    if ( 0 == CIMFWStrCmp( strNPWXferCassette[i].cassetteID.identifier,
                                           strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier) )
                    {
                        PPT_METHODTRACE_V1("", "cassetteID = loadedCassetteID");

                        if ( 0 == CIMFWStrCmp( strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portState, SP_PortRsc_PortState_UnloadReq) &&
                             0 == CIMFWStrCmp( strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].dispatchState, SP_PortRsc_DispatchState_Dispatched) )
                        {
                            PPT_METHODTRACE_V1("", "portState = [UnloadReq] && dispatchState = [Dispatched]");
                            /*------------------------*/
                            /*   change to Required   */
                            /*------------------------*/
                            objectIdentifier dummyOI;
                            objEquipment_dispatchState_Change_out strEquipment_dispatchState_Change_out;
                            rc = equipment_dispatchState_Change( strEquipment_dispatchState_Change_out,
                                                                 strObjCommonIn,
                                                                 strCassette_equipmentID_Get_out.equipmentID,
                                                                 strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID,
                                                                 SP_PortRsc_DispatchState_Required,
                                                                 dummyOI,
                                                                 dummyOI,
                                                                 dummyOI,
                                                                 dummyOI );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "##### equipment_dispatchState_Change() != RC_OK", rc);
                                strArrivalCarrierCancelForInternalBufferReqResult.strResult = strEquipment_dispatchState_Change_out.strResult ;
                                return( rc );
                            }
                        }
                    }
                }
            }
        }
//P5100087 end

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Check Process                                                       */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "Check Process");

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Cassette                                          */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - dispatchState should be TRUE.                                     */
    /*   - controlJobID should be blank'.                                    */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "Check Process for Cassette");
    objCassette_CheckConditionForArrivalCarrierCancel_out   strCassette_CheckConditionForArrivalCarrierCancel_out;
    rc = cassette_CheckConditionForArrivalCarrierCancel( strCassette_CheckConditionForArrivalCarrierCancel_out,
                                                         strObjCommonIn,
                                                         strNPWXferCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "equipment_dispatchState_Change() != RC_OK");
        strArrivalCarrierCancelForInternalBufferReqResult.strResult = strCassette_CheckConditionForArrivalCarrierCancel_out.strResult ;
        return( rc );
    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Lot                                               */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*   - Omit Empty cassette.                                              */
    /*   - lotProcessState should not be InProcessing.                       */
    /*   - controlJobID should be blank.                                     */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "Check Process for Lot");
    objLot_CheckConditionForArrivalCarrierCancel_out   strLot_CheckConditionForArrivalCarrierCancel_out;
    rc = lot_CheckConditionForArrivalCarrierCancel( strLot_CheckConditionForArrivalCarrierCancel_out,
                                                    strObjCommonIn,
                                                    controlJobID,
                                                    strStartCassetteSequence );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "lot_CheckConditionForArrivalCarrierCancel() != RC_OK");
        strArrivalCarrierCancelForInternalBufferReqResult.strResult = strLot_CheckConditionForArrivalCarrierCancel_out.strResult ;
        return( rc );
    }

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Main Process                                                        */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "Main Process");

    /*---------------------------------------------------*/
    /*                                                   */
    /*   Cassette Related Information Update Procedure   */
    /*                                                   */
    /*---------------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "Cassette Related Information Update Procedure");
    for( i = 0 ; i < nStrNPWXferCassetteLen ; i ++ )
    {

        /*-----------------------------------------------*/
        /*   Change Cassette's Dispatch State to FALSE   */
        /*-----------------------------------------------*/
        PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "Change Cassette's Dispatch State to FALSE");

        objCassette_dispatchState_Change_out   strCassette_dispatchState_Change_out;
        rc = cassette_dispatchState_Change( strCassette_dispatchState_Change_out,
                                            strObjCommonIn,
                                            strNPWXferCassette[i].cassetteID,
                                            FALSE );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "cassette_dispatchState_Change() != RC_OK");
            strArrivalCarrierCancelForInternalBufferReqResult.strResult = strCassette_dispatchState_Change_out.strResult ;
            return( rc );
        }

        /*--------------------------------------------------*/
        /*   Change Cassette's NPWLoadPurposeType to NULL   */
        /*--------------------------------------------------*/
        PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "Change Cassette's NPWLoadPurposeType to NULL");
        objCassette_SetNPWLoadPurposeType_out   strCassette_SetNPWLoadPurposeType_out;
        rc = cassette_SetNPWLoadPurposeType( strCassette_SetNPWLoadPurposeType_out,
                                                   strObjCommonIn,
                                                   strNPWXferCassette[i].cassetteID,
                                                   NULL );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "cassette_ChangeSetNPWLoadPurposeType() != RC_OK");
            strArrivalCarrierCancelForInternalBufferReqResult.strResult = strCassette_SetNPWLoadPurposeType_out.strResult ;
            return( rc );
        }

    }

    /*-------------------------------------------------*/
    /*                                                 */
    /*   Clear MaterialLocations(shelf of equipment)   */
    /*                                                 */
    /*-------------------------------------------------*/
    PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "Clear MaterialLocations(shelf of equipment)");
    objEquipment_ArrivalCarrierCancelForInternalBuffer_out   strEquipment_ArrivalCarrierCancelForInternalBuffer_out;
    rc = equipment_ArrivalCarrierCancelForInternalBuffer( strEquipment_ArrivalCarrierCancelForInternalBuffer_out,
                                                          strObjCommonIn,
                                                          equipmentID,
                                                          controlJobID,
                                                          strNPWXferCassette
                                                          );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "equipment_ArrivalCarrierCancelForInternalBuffer() != RC_OK");
        strArrivalCarrierCancelForInternalBufferReqResult.strResult = strEquipment_ArrivalCarrierCancelForInternalBuffer_out.strResult ;
        return( rc );
    }

    /*------------------------------------------------------------------------*/
    /*                                                                        */
    /*   Send ArrivalCarrierCancelForInternalBufferReq() to TCS Procedure     */
    /*                                                                        */
    /*------------------------------------------------------------------------*/
    if( TRUE == notifyToTCSFlag )           //D9000005
    {                                       //D9000005
        PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "Send ArrivalCarrierCancelForInternalBufferReq() to TCS Procedure");
//D4000060    objTCSMgr_SendArrivalCarrierCancelForInternalBufferReq_out   strTCSMgr_SendArrivalCarrierCancelForInternalBufferReq_out;
//D4000060    rc = TCSMgr_SendArrivalCarrierCancelForInternalBufferReq( strTCSMgr_SendArrivalCarrierCancelForInternalBufferReq_out,
//D4000060                                                              strObjCommonIn,
//D4000060                                                              strObjCommonIn.strUser,
//D4000060                                                              equipmentID,
//D4000060                                                              portGroupID,
//D4000060                                                              strNPWXferCassette,
//D4000060                                                              claimMemo
//D4000060                                                             );
//D4000060    if ( rc != RC_OK )
//D4000060    {
//D4000060        PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "TCSMgr_SendArrivalCarrierCancelReq() != RC_OK");
//D4000060        strArrivalCarrierCancelForInternalBufferReqResult.strResult = strTCSMgr_SendArrivalCarrierCancelForInternalBufferReq_out.strResult ;
//D4000060        return( rc );
//D4000060    }
//D4000060 add start
//D4100134    CORBA::String_var tmpSleepTimeValue = theSP_BIND_SLEEP_TIME_TCS;
//D4100134    CORBA::String_var tmpRetryCountValue = theSP_BIND_RETRY_COUNT_TCS;
        CORBA::String_var tmpSleepTimeValue = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));   //D4100134
        CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS)); //D4100134
        CORBA::Long sleepTimeValue;
        CORBA::Long retryCountValue;

        if (CIMFWStrLen(tmpSleepTimeValue) == 0)
        {
            sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
        }
        else
        {

//D9000001        sleepTimeValue = atol(tmpSleepTimeValue) ;
            sleepTimeValue = atoi(tmpSleepTimeValue) ;    //D9000001
        }

        if (CIMFWStrLen(tmpRetryCountValue) == 0)
        {
            retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
        }
        else
        {
//D9000001        retryCountValue = atol(tmpRetryCountValue);
            retryCountValue = atoi(tmpRetryCountValue);    //D9000001
        }

        PPT_METHODTRACE_V2("","env value of SP_BIND_SLEEP_TIME_TCS  = ",sleepTimeValue);
        PPT_METHODTRACE_V2("","env value of SP_BIND_RETRY_COUNT_TCS = ",retryCountValue);

        objTCSMgr_SendArrivalCarrierCancelForInternalBufferReq_out   strTCSMgr_SendArrivalCarrierCancelForInternalBufferReq_out;

        //'retryCountValue + 1' means first try plus retry count
        for(i = 0 ; i < (retryCountValue + 1) ; i++)
        {
            /*--------------------------*/
            /*    Send Request to TCS   */
            /*--------------------------*/
            rc = TCSMgr_SendArrivalCarrierCancelForInternalBufferReq( strTCSMgr_SendArrivalCarrierCancelForInternalBufferReq_out,
                                                                      strObjCommonIn,
                                                                      strObjCommonIn.strUser,
                                                                      equipmentID,
                                                                      portGroupID,
                                                                      strNPWXferCassette,
                                                                      claimMemo
                                                                      );


            PPT_METHODTRACE_V2("","rc = ",rc);

            if(rc == RC_OK)
            {
                PPT_METHODTRACE_V1("","Now TCS subSystem is alive!! Go ahead");
                break;
            }
            else if ( rc == RC_EXT_SERVER_BIND_FAIL ||
                      rc == RC_EXT_SERVER_NIL_OBJ   ||
                      rc == RC_TCS_NO_RESPONSE )
            {
                PPT_METHODTRACE_V2("","TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...",i);
                PPT_METHODTRACE_V2("","now sleeping... ",sleepTimeValue);
                sleep(sleepTimeValue);
                continue;
            }
            else
            {
                PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "TCSMgr_SendArrivalCarrierCancelReq() != RC_OK");
                strArrivalCarrierCancelForInternalBufferReqResult.strResult = strTCSMgr_SendArrivalCarrierCancelForInternalBufferReq_out.strResult ;
                return( rc );
            }

        }

        if ( rc != RC_OK ) {
            PPT_METHODTRACE_V1("PPTManager_i::txArrivalCarrierCancelForInternalBufferReq__090", "TCSMgr_SendArrivalCarrierCancelReq() != RC_OK");
            strArrivalCarrierCancelForInternalBufferReqResult.strResult = strTCSMgr_SendArrivalCarrierCancelForInternalBufferReq_out.strResult ;
            return( rc );
        }
//D4000060 add end
    }       //D9000005

   /*--------------------*/
   /*                    */
   /*   Return to Main   */
   /*                    */
   /*--------------------*/

   SET_MSG_RC(strArrivalCarrierCancelForInternalBufferReqResult, MSG_OK, RC_OK);

   PPT_METHODTRACE_EXIT("PPTManager_i::txArrivalCarrierNotificationReq ")
   return( RC_OK );
}

