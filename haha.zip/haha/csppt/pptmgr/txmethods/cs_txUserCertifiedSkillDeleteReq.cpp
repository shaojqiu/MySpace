// (c) Copyright: IBM  Company Ltd, 2017, 2027. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017, 2027. All rights reserved.
//
// SiView
// Name: cs_txUserCertifiedSkillDeleteReq.cpp
//
// Modeficaiton History:
// Date       Defect           Name             Description
// ---------- -------- ---------------- ----------------------------------------------
// 2017/09/04 INN-R170008      Menghua Yin      TA Certify

// Class: PPTServiceManager
//
// Service: cs_txUserCertifiedSkillDeleteReq()

// Description:
//<Method Summary>
// TA Certify Skill Delete
//</Method Summary>

// Return:
//     long
//
// Parameter:
//
//     csUserCertifiedSkillDeleteReqResult&       strUserCertifiedSkillDeleteReqResult
//     const pptObjCommonIn&                      strObjCommonIn
//     const csUserCertifiedSkillDeleteReqInParm& strUserCertifiedSkillDeleteReqInParm

//<Method Start>
#include "cs_pptmgr.hpp"

CORBA::Long CS_PPTManager_i::cs_txUserCertifiedSkillDeleteReq (
    csUserCertifiedSkillDeleteReqResult&       strUserCertifiedSkillDeleteReqResult,
    const pptObjCommonIn&                      strObjCommonIn,
    const csUserCertifiedSkillDeleteReqInParm& strUserCertifiedSkillDeleteReqInParm CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("PPTManager_i::cs_txUserCertifiedSkillDeleteReq");
    CORBA::Long rc = RC_OK;

    //----------------------------------------------------------------
    //
    //  Pre Process
    //
    //----------------------------------------------------------------
    // If one of user_id ,skill_id or certify_date is empty,return MSG_INVALID_INPUT_PARM
    CORBA::Long nLen = strUserCertifiedSkillDeleteReqInParm.strUserSkillInfoSeq.length();
    if (nLen <= 0)
    {
        PPT_METHODTRACE_V1("", "return RC_INVALID_INPUT_PARM");
        SET_MSG_RC(strUserCertifiedSkillDeleteReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM);
        return RC_INVALID_INPUT_PARM;
    }
    
    PPT_METHODTRACE_V2("", "nLen", nLen);
    for (int i = 0; i < nLen; i++)
    {
        PPT_METHODTRACE_V1("", "enter for loop");
        if (CIMFWStrLen(strUserCertifiedSkillDeleteReqInParm.strUserSkillInfoSeq[i].userID.identifier) == 0)
        {
            PPT_METHODTRACE_V1("", "return RC_INVALID_INPUT_PARM");
            SET_MSG_RC(strUserCertifiedSkillDeleteReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM);
            return MSG_INVALID_INPUT_PARM;
        }

        CORBA::Long nSkillInfoLen = strUserCertifiedSkillDeleteReqInParm.strUserSkillInfoSeq[i].strSkillInfo.length();
        PPT_METHODTRACE_V2("", "nSkillInfoLen", nSkillInfoLen);
        for (int j = 0; j < nSkillInfoLen; j++)
        {
            PPT_METHODTRACE_V1("", "enter for loop1");
            if (CIMFWStrLen(strUserCertifiedSkillDeleteReqInParm.strUserSkillInfoSeq[i].strSkillInfo[j].skillID) == 0)
            {
                PPT_METHODTRACE_V1("", "return RC_INVALID_INPUT_PARM");
                SET_MSG_RC(strUserCertifiedSkillDeleteReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM);
                return MSG_INVALID_INPUT_PARM;
            }
        }
    }

    //----------------------------------------------------------------------
    //
    //  Main Process
    //
    //----------------------------------------------------------------------
    // call cs_person_SkillList_DelDR
    csObjPerson_SkillList_DelDR_in strObjPerson_SkillList_DelDR_in;
    strObjPerson_SkillList_DelDR_in.strUserSkillInfoSeq = strUserCertifiedSkillDeleteReqInParm.strUserSkillInfoSeq;

    PPT_METHODTRACE_V1("", "call cs_person_SkillList_DelDR()");
    csObjPerson_SkillList_DelDR_out strObjPerson_SkillList_DelDR_out;
    
    rc = cs_person_SkillList_DelDR( strObjPerson_SkillList_DelDR_out,
                                    strObjCommonIn,
                                    strObjPerson_SkillList_DelDR_in );
                                    
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "cs_person_SkillList_DelDR() rc != RC_OK. ", rc);
        strUserCertifiedSkillDeleteReqResult.strResult = strObjPerson_SkillList_DelDR_out.strResult;
        return(rc);
    }

    // Return to caller
    SET_MSG_RC(strUserCertifiedSkillDeleteReqResult, MSG_OK, RC_OK);
    PPT_METHODTRACE_EXIT("PPTManager_i::cs_txUserCertifiedSkillDeleteReq");
    return RC_OK;
}