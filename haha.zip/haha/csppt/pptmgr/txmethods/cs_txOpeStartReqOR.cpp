#ifndef lint
static char *sccsid =  "@(#) 1.9 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txOpeStartReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/15/07 15:53:11 [ 11/15/07 15:53:12 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cs_txOpeStartReqOR.cpp
//

#include "cs_pptmgr.hpp"
#include "penin.hh"
#include "plot.hh"          //P4100063

#include <unistd.h>

extern void traceSampledStartCassette( const pptStartCassetteSequence& strStartCassette );    //D9000003 for Cassette trace


// Class: CS_PPTManager
//
// Service: txOpeStartReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/18          O.Sugiyama     Initial Release
// 2000/09/11 0.01     Y.Iwasaki      Bug Fix (parameter for lot_CheckConditionFor...)
// 2000-09-16 P3000185 Y.Iwasaki      Add comment
// 2000-09-22 Q3000127 Y.Iwasaki      Change position for MonitorGroup making
// 2000-09-25 Q3000106 M.Ameshita     Bug Fix (Add check logic of entity inhibit for reticle)
// 2000-10-13 Q3000297 Y.Iwasaki      Add Rparm update logic
// 2000-10-23 P3000280 S.Kawabe       Boolean variable initialize
// 2000-10-30 D3000079 Y.Iwasaki      Change comment of cassette_CheckConditionForOperation
//                                    (Logic no-change)
// 2001-03-06 P3100009 K.Matsuei      Multiple Reticle Inhibit
// 2001-04-17 P3100289 K.Matsuei      Change comment of cassette_CheckConditionForOperation
//                                    (Logic no-change)
// 2001-07-05 D4000015 H.Katoh        Add Equipment Category Check Logic because of
//                                    Internal Buffer Support
// 2001-07-05 D4000016 M.Shimizu      Contamination Control(Copper/Non Copper [R40 Core])
// 2001-08-01 D4000056 M.Shimizu      Add Slot Map Exist Check for Wafer Sorter [R40 Core]
// 2001-08-21 P4000099 H.Adachi       Change objectName(waferSorter_SlotMap_SelectDR to waferSorter_slotMap_SelectDR)
// 2001/08/23 D4000056 M.Shimizu      Add Param's destinationCassetteManagedBySiViewFlag
//                                                originalCassetteManagedBySiViewFlag
// 2001-08-24 D4000056 M.Shimizu      Change Call objmethod equipment_CheckCategoryForWaferSorter() -> strEqpInfoBySQL()
// 2001/09/03 D4000060 K.Kido         Add retry TCS request logic
// 2001/09/19 P4100063 M.Ameshita     Fix to check reticle inhibit in the case sub lot type is specified.
// 2002/02/14 D4100134 C.Tsuchiya     Use getenv() instead of Mgr class member 'theSP_xxx'
// 2002/03/25 D4100206 C.Tsuchiya     Remove SP_EqpInfo_By_SQL env val and use DR code every time for EqpInfo.
// 2002/06/11 P4100536 T.Nishimura    Source Check : Wrong reference to dimension.
// 2002/07/04 P4200025 T.Nishimura    Source Check : return without message.
// 2002/08/07 D4200039 H.Adachi       Replace Direct FW Calling.
// 2002/08/07 D4200081 K.Matsuei      New combination of Inhibit is supported.
// 2002/09/20 D4200031 H.Adachi       Chg not to check reticle for the case a lot is in a operation with no photo layer.
// 2003/04/08 D5000001 K.Matsuei      Wafer Level Control.
// 2003/08/25 P5000247 H.Adachi       Add InParameter check of Control Job Combination.
// 2004/04/07 D5100232 K.Matsuei      Initial Release. Add DCS Interface to MM.
// 2004/04/26 D5100087 K.Kido         Change for Chamber Inhibit Support.
// 2004/08/11 D51M0000 K.Tachibana    APC I/F Enhance for Interface Spec-B
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2005/10/31 D7000006 T.Ohsaki       exchange "controlJob_Create()" and "controlJob_status_Change()" to "txControlJobManageReq()"
// 2006/01/20 D7000182 H.Mutoh        Enhancement of re-sending APCControlJobInformation.
// 2006/04/03 D7000041 K.Matsuei      Need to check empty carrier's category on next operation.
// 2006/07/25 D7000228 M.Murata       Add the logic to send OpeStartCancel to DCS.
// 2006/11/22 D8000024 H.Mutoh        Flexible Process Condition Change (R80)
// 2007/04/02 D8000207 M.Murata       Add changing logic processJobExecFlag.
// 2007/04/20 D9000001 H.Murakami     64bit support.
// 2007/06/04 D9000003 M.Nakano       Modify changing and registering logic processJobExecFlag for wafer sampling operation.
// 2007/09/20 D9000079 D.Tamura       FlowBatch Enhancement.
// 2007/10/10 D9000084 H.Hotta        Add check of reticle required for the lot
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/03 DSIV00000099 M.Ogawa        equipment_brInfo_GetDR ==> equipment_brInfo_GetDR__100
//                                        Add check logic for SLM operation.
// 2010/04/30 DSIV00001830 R.Okano        Wafer Stacking Operation Support.
// 2010/06/25 PSIV00002138 R.Okano        Fix Monitor Group Creation condition for Bonding Equipment
// 2010/06/25 PSIV00002149 S.Kawabe       Start Lot Reservation fails when a lot in FOUP is not on a route.
// 2011/08/08 DSN000015229 Sa Guo         lot_processJobExecFlag_ValidCheck ==> lot_processJobExecFlag_ValidCheckForOpeStart
// 2012/11/28 DSN000049350 F.Chen         Equipment parallel processing support (P2)
// 2013/08/29 DSN000081739 Sa Guo         Equipment Monitor Automation Support
// 2015/08/04 DSN000096135 T.Ishida       Virtual Operation
// 2015/11/11 DSN000096126 C.Mo           reticle_detailInfo_GetDR__090 ==> reticle_detailInfo_GetDR__160
// 2016/06/06 DSN000102497 K.Yamaoku      Support tMSP
// 2016/07/13 DSN000101569 K.Yamaoku      Durable Sub Status Control
// 2016/07/27 DSN000101569 C.Mo           reticle_detailInfo_GetDR__160 ==> reticle_detailInfo_GetDR__170
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/15 INN-R170002  JJ.Zhang       Contamination Control
// 2017/09/28 INN-R170003  Joan Zhou      INN-R170003:Durable Management Enhancement
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    pptOpeStartReqResult&               strOpeStartReqResult
//    const pptObjCommonIn&               strObjCommonIn
//    const objectIdentifier&             equipmentID
//    const char *                        portGroupID
//    const objectIdentifier&             controlJobID
//    const pptStartCassetteSequence&     strStartCassette
//    CORBA::Boolean                      processJobPauseFlag
//    const char*                         claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i:: txOpeStartReq (
    pptOpeStartReqResult&               strOpeStartReqResult,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             equipmentID,
    const char *                        portGroupID,
    const objectIdentifier&             controlJobID,
    const pptStartCassetteSequence&     strStartCassette,
    CORBA::Boolean                      processJobPauseFlag,  //D5000001
//D6000025     const char*                         claimMemo,
//D6000025     CORBA::Environment &                IT_env)
//D7000182    const char*                         claimMemo //D6000025
    const char*                         claimMemo,          //D7000182
    char *&                             APCIFControlStatus, //D7000182
    char *&                             DCSIFControlStatus  //D7000182
    CORBAENV_LAST_CPP)                            //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txOpeStartReq");
    CORBA::Long rc = RC_OK ;

    traceSampledStartCassette( strStartCassette );  //D9000003

    //P4100536 add start
    // Check length of In-Parameter
    if(0 >= strStartCassette.length())
    {
        SET_MSG_RC(strOpeStartReqResult, MSG_INVALID_PARAMETER, RC_INVALID_PARAMETER); //P4200025 add
        return RC_INVALID_PARAMETER;
    }
    //P4100536 add end

    char * methodName = NULL;                                                   //P4100063

//D8000207 add start
    //----------------------------------------
    // Change processJobExecFlag to True.
    //----------------------------------------
    pptStartCassetteSequence tmpStartCassette;
    tmpStartCassette = strStartCassette;
//D9000003 delete start
//    PPT_METHODTRACE_V2("","SP_OPER_START_WAFER_FLAG_CONTROL is ", atol(getenv(SP_OPER_START_WAFER_FLAG_CONTROL)));
//    if( 1 == atol(getenv(SP_OPER_START_WAFER_FLAG_CONTROL)) )
//    {
//        if( processJobPauseFlag == FALSE )
//        {
//            objStartCassette_processJobExecFlag_Set_out   strStartCassette_processJobExecFlag_Set_out;
//            rc = startCassette_processJobExecFlag_Set(strStartCassette_processJobExecFlag_Set_out, strObjCommonIn, strStartCassette );
//            if( rc != RC_OK )
//            {
//                PPT_METHODTRACE_V1("","objStartCassette_processJobExecFlag_Set() != RC_OK ");
//                strOpeStartReqResult.strResult = strStartCassette_processJobExecFlag_Set_out.strResult;
//                return rc ;
//            }
//            tmpStartCassette = strStartCassette_processJobExecFlag_Set_out.strStartCassette;
//        }
//    }
//D9000003 delete end
//D8000207 add end

//D9000003 add start
    //Input parameter check.
    //Check every lot has at least one wafer with processJobExecFlag == TRUE
    PPT_METHODTRACE_V1("","Check every lot has at least one wafer with processJobExecFlag == TRUE.");
//DSN000015229    objLot_processJobExecFlag_ValidCheck_out strLot_processJobExecFlag_ValidCheck_out;
//DSN000015229    objLot_processJobExecFlag_ValidCheck_in strLot_processJobExecFlag_ValidCheck_in;
//DSN000015229    strLot_processJobExecFlag_ValidCheck_in.strStartCassette = tmpStartCassette;
//DSN000015229
//DSN000015229    rc = lot_processJobExecFlag_ValidCheck(strLot_processJobExecFlag_ValidCheck_out, strObjCommonIn, strLot_processJobExecFlag_ValidCheck_in);
//DSN000015229    if( rc != RC_OK)
//DSN000015229    {
//DSN000015229        PPT_METHODTRACE_V1("","objLot_processJobExecFlag_ValidCheck() != RC_OK ");
//DSN000015229        strOpeStartReqResult.strResult = strLot_processJobExecFlag_ValidCheck_out.strResult;
//DSN000015229        return rc;
//DSN000015229    }
//DSN000015229 Add Start
    objLot_processJobExecFlag_ValidCheckForOpeStart_out strLot_processJobExecFlag_ValidCheckForOpeStart_out;
    objLot_processJobExecFlag_ValidCheckForOpeStart_in strLot_processJobExecFlag_ValidCheckForOpeStart_in;
    strLot_processJobExecFlag_ValidCheckForOpeStart_in.strStartCassette = tmpStartCassette;
    strLot_processJobExecFlag_ValidCheckForOpeStart_in.processJobPauseFlag = processJobPauseFlag;

    rc = lot_processJobExecFlag_ValidCheckForOpeStart(strLot_processJobExecFlag_ValidCheckForOpeStart_out, strObjCommonIn, strLot_processJobExecFlag_ValidCheckForOpeStart_in);
    if( rc != RC_OK)
    {
        PPT_METHODTRACE_V2("","lot_processJobExecFlag_ValidCheckForOpeStart() != RC_OK", rc);
        strOpeStartReqResult.strResult = strLot_processJobExecFlag_ValidCheckForOpeStart_out.strResult;
        return rc;
    }
//DSN000015229 Add End
//D9000003 add end



    //D4000015 Start
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    //   Check Process
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","equipment_categoryVsTxID_CheckCombination() returned error.");

        strOpeStartReqResult.strResult
            = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return (rc);
    }
    //D4000015 End

//DSN000096135 Add Start
    CORBA::Boolean virtualOperationFlag = FALSE;
    if( CIMFWStrLen( portGroupID ) <= 0 )
    {
        objVirtualOperation_CheckByStartCassette_out strVirtualOperation_CheckByStartCassette_out;
        objVirtualOperation_CheckByStartCassette_in  strVirtualOperation_CheckByStartCassette_in;

        strVirtualOperation_CheckByStartCassette_in.strStartCassette = tmpStartCassette;

        rc = virtualOperation_CheckByStartCassette( strVirtualOperation_CheckByStartCassette_out, strObjCommonIn, strVirtualOperation_CheckByStartCassette_in );

        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "virtualOperation_CheckByStartCassette() != RC_OK" );
            strOpeStartReqResult.strResult = strVirtualOperation_CheckByStartCassette_out.strResult;
            return( rc );
        }

        PPT_METHODTRACE_V2( "", "virtualOperationFlag = ", strVirtualOperation_CheckByStartCassette_out.virtualOperationFlag );
        virtualOperationFlag = strVirtualOperation_CheckByStartCassette_out.virtualOperationFlag;
    }
//DSN000096135 Add End

//D4000056 Add Start
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    //   Check Process for WaferSorter
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    PPT_METHODTRACE_V1("","OpeStart should be made acceptable if data are left in SlotMap.");

//P4000099    objEquipment_categoryCheckForWaferSorter_out strEquipment_categoryCheckForWaferSorter_out;
//P4000099    rc = equipment_categoryCheckForWaferSorter(
//P4000099                                strEquipment_categoryCheckForWaferSorter_out,
//P4000099                                strObjCommonIn,
//P4000099                                equipmentID);

//D4000056    objEquipment_CheckCategoryForWaferSorter_out strEquipment_CheckCategoryForWaferSorter_out;//P4000099
//D4000056    rc = equipment_CheckCategoryForWaferSorter(
//D4000056                                strEquipment_CheckCategoryForWaferSorter_out,
//D4000056                                strObjCommonIn,
//D4000056                                equipmentID);                                                 //P4000099

//D4000056    if ( rc != RC_OK )
//D4000056    {
//P4000099        PPT_METHODTRACE_V2("txOpeStartReq","equipment_categoryCheckForWaferSorter() != RC_OK",rc);
//P4000099        strOpeStartReqResult.strResult = strEquipment_categoryCheckForWaferSorter_out.strResult;
//D4000056        PPT_METHODTRACE_V2("txOpeStartReq","equipment_CheckCategoryForWaferSorter() != RC_OK",rc); //P4000099
//D4000056        strOpeStartReqResult.strResult = strEquipment_CheckCategoryForWaferSorter_out.strResult;   //P4000099
//D4000056        return (rc);
//D4000056    }

//Add S D4000056
    CORBA::String_var strEquipmentCategory;
    strEquipmentCategory = CIMFWStrDup("");

//D4100206
//D4100206 //D4100134    CORBA::String_var strEqpInfoBySQL = theSP_EqpInfo_By_SQL;
//D4100206     CORBA::String_var strEqpInfoBySQL = CIMFWStrDup(getenv(SP_EqpInfo_By_SQL));   //D4100134
//D4100206     PPT_METHODTRACE_V2("", "Env value is    ",strEqpInfoBySQL);

//D4100206     if(CIMFWStrCmp(strEqpInfoBySQL , "1") == 0)
//D4100206     {
//DSIV00000099        PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeStartReq", "call equipment_brInfo_GetDR()...");
//DSIV00000099        objEquipment_brInfo_GetDR_out strEquipment_brInfo_GetDR_out;
//DSIV00000099        rc = equipment_brInfo_GetDR(strEquipment_brInfo_GetDR_out, strObjCommonIn, equipmentID);
//DSIV00000099        PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeStartReq", "end equipment_brInfo_GetDR()...");
//DSIV00000099        if ( rc != RC_OK )
//DSIV00000099        {
//DSIV00000099            PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeStartReq", "rc = ",rc);
//DSIV00000099            PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeStartReq", "equipment_brInfo_GetDR() rc != RC_OK");
//DSIV00000099            strOpeStartReqResult.strResult = strEquipment_brInfo_GetDR_out.strResult;
//DSIV00000099            return( rc );
//DSIV00000099        }
//DSN000015229//DSIV00000099 add start
//DSN000015229    PPT_METHODTRACE_V1("", "call equipment_brInfo_GetDR__100()...");
//DSN000015229    objEquipment_brInfo_GetDR_out__100 strEquipment_brInfo_GetDR_out;
//DSN000015229    objEquipment_brInfo_GetDR_in__100  strEquipment_brInfo_GetDR_in;
//DSN000015229    strEquipment_brInfo_GetDR_in.equipmentID = equipmentID;
//DSN000015229    rc = equipment_brInfo_GetDR__100( strEquipment_brInfo_GetDR_out, strObjCommonIn, strEquipment_brInfo_GetDR_in );
//DSN000015229    if ( rc != RC_OK )
//DSN000015229    {
//DSN000015229        PPT_METHODTRACE_V2("", "equipment_brInfo_GetDR__100() rc != RC_OK", rc);
//DSN000015229        strOpeStartReqResult.strResult = strEquipment_brInfo_GetDR_out.strResult;
//DSN000015229        return( rc );
//DSN000015229    }
//DSN000015229//DSIV00000099 add end
//DSN000015229 Add Start
    PPT_METHODTRACE_V1("", "call equipment_brInfo_GetDR__120()...");
    objEquipment_brInfo_GetDR_out__120 strEquipment_brInfo_GetDR_out;
    objEquipment_brInfo_GetDR_in__100  strEquipment_brInfo_GetDR_in;
    strEquipment_brInfo_GetDR_in.equipmentID = equipmentID;
    rc = equipment_brInfo_GetDR__120( strEquipment_brInfo_GetDR_out, strObjCommonIn, strEquipment_brInfo_GetDR_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipment_brInfo_GetDR__120() rc != RC_OK", rc);
        strOpeStartReqResult.strResult = strEquipment_brInfo_GetDR_out.strResult;
        return( rc );
    }
//DSN000015229 Add End

    strEquipmentCategory = CIMFWStrDup(strEquipment_brInfo_GetDR_out.equipmentBRInfo.equipmentCategory);
//D4100206     }
//D4100206     else
//D4100206     {
//D4100206         PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeStartReq", "call equipment_brInfo_Get()...");
//D4100206         objEquipment_brInfo_Get_out strEquipment_brInfo_Get_out;
//D4100206         rc = equipment_brInfo_Get(strEquipment_brInfo_Get_out, strObjCommonIn, equipmentID);
//D4100206         if ( rc != RC_OK )
//D4100206         {
//D4100206             PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeStartReq", "rc = ",rc);
//D4100206             PPT_METHODTRACE_V1("CS_PPTManager_i:: txOpeStartReq", "equipment_brInfo_Get() rc != RC_OK");
//D4100206            strOpeStartReqResult.strResult = strEquipment_brInfo_Get_out.strResult;
//D4100206            return( rc );
//D4100206        }
//D4100206        strEquipmentCategory = CIMFWStrDup(strEquipment_brInfo_Get_out.equipmentBRInfo.equipmentCategory);
//D4100206    }
//Add E D4000056

    PPT_METHODTRACE_V2("", "strEquipmentCategory",strEquipmentCategory);
//P4000099    if(strEquipment_categoryCheckForWaferSorter_out.bCheckCategory == TRUE)
//D4000056    if(strEquipment_CheckCategoryForWaferSorter_out.bCheckCategory == TRUE)          //P4000099
    if ( CIMFWStrCmp(strEquipmentCategory, SP_Mc_Category_WaferSorter) == 0 )                  //D4000056
    {
        PPT_METHODTRACE_V1("","equipment category is WaferSorter ");
        //-----------------------------
        //  Read a Slot Map
        //-----------------------------
        pptWaferSorterSlotMap strWaferSorterGetSlotMapReferenceCondition;
        CORBA::String_var requiredData;
        requiredData = CIMFWStrDup(SP_Sorter_SlotMap_AllData);

        strWaferSorterGetSlotMapReferenceCondition.portGroup                           = CIMFWStrDup(portGroupID);
        strWaferSorterGetSlotMapReferenceCondition.equipmentID.identifier              = equipmentID.identifier;
        strWaferSorterGetSlotMapReferenceCondition.actionCode                          = CIMFWStrDup("");
        strWaferSorterGetSlotMapReferenceCondition.requestTime                         = CIMFWStrDup("");
        strWaferSorterGetSlotMapReferenceCondition.direction                           = CIMFWStrDup("");
        strWaferSorterGetSlotMapReferenceCondition.waferID.identifier                  = CIMFWStrDup("");
        strWaferSorterGetSlotMapReferenceCondition.lotID.identifier                    = CIMFWStrDup("");
        strWaferSorterGetSlotMapReferenceCondition.destinationCassetteID.identifier    = CIMFWStrDup("");
        strWaferSorterGetSlotMapReferenceCondition.destinationPortID.identifier        = CIMFWStrDup("");
        strWaferSorterGetSlotMapReferenceCondition.bDestinationCassetteManagedBySiView = FALSE;
        strWaferSorterGetSlotMapReferenceCondition.destinationSlotNumber               = 0;
        strWaferSorterGetSlotMapReferenceCondition.originalCassetteID.identifier       = CIMFWStrDup("");
        strWaferSorterGetSlotMapReferenceCondition.originalPortID.identifier           = CIMFWStrDup("");
        strWaferSorterGetSlotMapReferenceCondition.bOriginalCassetteManagedBySiView    = FALSE;
        strWaferSorterGetSlotMapReferenceCondition.originalSlotNumber                  = 0;
        strWaferSorterGetSlotMapReferenceCondition.requestUserID.identifier            = CIMFWStrDup("");
        strWaferSorterGetSlotMapReferenceCondition.replyTime                           = CIMFWStrDup("");
        strWaferSorterGetSlotMapReferenceCondition.sorterStatus                        = CIMFWStrDup(SP_Sorter_Requested);
        strWaferSorterGetSlotMapReferenceCondition.slotMapCompareStatus                = CIMFWStrDup("");
        strWaferSorterGetSlotMapReferenceCondition.mmCompareStatus                     = CIMFWStrDup("");

//P4000099        objWaferSorter_SlotMap_SelectDR_out strWaferSorter_SlotMap_SelectDR_out;
//P4000099        rc = waferSorter_SlotMap_SelectDR( strWaferSorter_SlotMap_SelectDR_out,
//P4000099                                           strObjCommonIn,
//P4000099                                           requiredData,
//P4000099                                           "",
//P4000099                                           strWaferSorterGetSlotMapReferenceCondition );

        objWaferSorter_slotMap_SelectDR_out strWaferSorter_slotMap_SelectDR_out;         //P4000099
        rc = waferSorter_slotMap_SelectDR( strWaferSorter_slotMap_SelectDR_out,
                                           strObjCommonIn,
                                           requiredData,
                                           "",
                                           SP_Sorter_Ignore_SiViewFlag,
                                           SP_Sorter_Ignore_SiViewFlag,
                                           strWaferSorterGetSlotMapReferenceCondition ); //P4000099

        if (rc == RC_NOT_FOUND_SLOTMAP_RECORD)
        {
              PPT_METHODTRACE_V1("","waferSorter_slotMap_SelectDR == RC_NOT_FOUND_SLOTMAP_RECORD");
        }
        else if ( rc != RC_OK)
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i::txOpeStartReq",
                               "waferSorter_slotMap_SelectDR() != RC_OK",rc);
//P4000099            strOpeStartReqResult.strResult = strWaferSorter_SlotMap_SelectDR_out.strResult;
            strOpeStartReqResult.strResult = strWaferSorter_slotMap_SelectDR_out.strResult;    //P4000099
            return ( rc );
        }

        //-------------------------------
        //   Check Slot Map DATA Exist
        //-------------------------------
//P4000099        CORBA::Long nCheckLen = strWaferSorter_SlotMap_SelectDR_out.strWaferSorterSlotMapSequence.length();
        CORBA::Long nCheckLen = strWaferSorter_slotMap_SelectDR_out.strWaferSorterSlotMapSequence.length();  //P4000099

        if ( nCheckLen > 0 )
        {
            PPT_METHODTRACE_V1("txOpeStartReq","Slot Map DATA Exist ");
            PPT_SET_MSG_RC_KEY ( strOpeStartReqResult, MSG_FOUND_SLOTMAP, RC_FOUND_SLOTMAP,"*****");

            return( RC_FOUND_SLOTMAP );
        }
    }
    else
    {
        //-------------------------------------------------
        //  Check Scrap Wafer Exsit In Carrier
        //-------------------------------------------------
        objectIdentifierSequence cassetteIDs ;
        CORBA::Long castLen = strStartCassette.length();
        CORBA::Long cnt = 0;
        cassetteIDs.length( castLen ) ;

        for(cnt = 0 ; cnt < castLen; cnt++ )
        {
            cassetteIDs[cnt] = strStartCassette[cnt].cassetteID;
        }

        objCassette_scrapWafer_SelectDR_out  strCassette_scrapWafer_SelectDR_out;
        rc = cassette_scrapWafer_SelectDR( strCassette_scrapWafer_SelectDR_out,
                                           strObjCommonIn,
                                           cassetteIDs);

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeStartReq", "cassette_scrapWafer_SelectDR() != RC_OK",rc);
            strOpeStartReqResult.strResult = strCassette_scrapWafer_SelectDR_out.strResult;
            return (rc);
        }

        CORBA::Long scrapCount = strCassette_scrapWafer_SelectDR_out.strLotWaferMap.length();
        if( scrapCount > 0 )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txOpeStartReq", "ScrapWafer Found ",scrapCount);
            SET_MSG_RC(strOpeStartReqResult, MSG_FOUND_SCRAP, RC_FOUND_SCRAP) ;
            return (RC_FOUND_SCRAP);
        }
    }

//D4000056 Add End

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Object Lock Process                                                 */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

//DSN000049350 Add Start
    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = equipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    // controlJobID is not empty
    if ( 0 < CIMFWStrLen(controlJobID.identifier) )
    {
        PPT_METHODTRACE_V1("", "controlJobID exists");
        strObject_lockMode_Get_in.functionCategory = CIMFWStrDup( "TXTRC002" ); // TxOpeStartReq
    }
    // controlJobID is empty
    else
    {
        PPT_METHODTRACE_V1("", "controlJobID is empty");
        strObject_lockMode_Get_in.functionCategory = CIMFWStrDup( SP_FunctionCategory_OpeStartWithCJIDGenTxID ); // TxOpeStartReq with control job ID generation
    }
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

    PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strOpeStartReqResult.strResult = strObject_lockMode_Get_out.strResult;
        return( rc );
    }
    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;
    
    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
    if (lockMode != SP_EQP_LOCK_MODE_WRITE)
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strOpeStartReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
        /*--------------------------------*/
        /*   Lock objects to be updated   */
        /*--------------------------------*/
//DSN000049350        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn,
                          equipmentID, SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "object_Lock(equipmentID) rc != RC_OK");
            strOpeStartReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    } //DSN000049350

    CORBA::Long i = 0;
    CORBA::Long nILen = strStartCassette.length();
    PPT_METHODTRACE_V2("", "nILen", nILen);

//DSN000049350 Add Start
    objectIdentifierSequence lotIDs;
    objectIdentifierSequence cassetteIDs;
    CORBA::ULong extendLen     = 25;
    CORBA::ULong t_lotIDLen    = extendLen;
    CORBA::ULong lotIDCnt      = 0;
    lotIDs.length(t_lotIDLen);
    cassetteIDs.length(nILen);
//DSN000049350 Add End

    for (i=0; i<nILen; i++)
    {

//DSN000049350        rc = object_Lock( strObject_Lock_out, strObjCommonIn,
//DSN000049350                          strStartCassette[i].cassetteID, SP_ClassName_PosCassette );
//DSN000049350        if ( rc != RC_OK )
//DSN000049350        {
//DSN000049350            PPT_METHODTRACE_V2("", "object_Lock(cassetteID) rc != RC_OK", i);
//DSN000049350            strOpeStartReqResult.strResult = strObject_Lock_out.strResult;
//DSN000049350            return( rc );
//DSN000049350        }

        cassetteIDs[i] = strStartCassette[i].cassetteID;  //DSN000049350

        CORBA::Long j = 0;
        CORBA::Long nJLen = strStartCassette[i].strLotInCassette.length();
        PPT_METHODTRACE_V2("", "nJLen", nJLen);
        for (j=0 ; j<nJLen; j++)
        {
//DSN000049350            rc = object_Lock( strObject_Lock_out, strObjCommonIn,
//DSN000049350                              strStartCassette[i].strLotInCassette[j].lotID, SP_ClassName_PosLot );
//DSN000049350            if ( rc != RC_OK )
//DSN000049350            {
//DSN000049350                PPT_METHODTRACE_V3("", "object_Lock(lotID) rc != RC_OK", i, j);
//DSN000049350                strOpeStartReqResult.strResult = strObject_Lock_out.strResult;
//DSN000049350                return( rc );
//DSN000049350            }
//DSN000049350 Add Start
            if( lotIDCnt >= t_lotIDLen )
            {
                PPT_METHODTRACE_V1("", "lotIDCnt >= t_lotIDLen");
                t_lotIDLen += extendLen;
                lotIDs.length( t_lotIDLen );
            }
            lotIDs[lotIDCnt++] = strStartCassette[i].strLotInCassette[j].lotID;
//DSN000049350 Add End
        }
    }
    lotIDs.length(lotIDCnt);                        //DSN000049350
    PPT_METHODTRACE_V2( "", "lotIDCnt", lotIDCnt);  //DSN000049350

//DSN000049350 Add Start
    if (lockMode != SP_EQP_LOCK_MODE_WRITE)
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
        objEquipment_onlineMode_Get_out strEquipment_onlineMode_Get_out;
        rc = equipment_onlineMode_Get( strEquipment_onlineMode_Get_out, strObjCommonIn, equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_onlineMode_Get() rc != RC_OK", rc);
            strOpeStartReqResult.strResult = strEquipment_onlineMode_Get_out.strResult;
            return rc;
        }
        
        if ( 0 == CIMFWStrCmp( strEquipment_onlineMode_Get_out.onlineMode, SP_Eqp_OnlineMode_Offline ) )
        {
            // Lock Equipment ProcLot Element (Count)
            stringSequence dummySeq;
            dummySeq.length(0);
            strAdvanced_object_Lock_in.objectID   = equipmentID;
            strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
            strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_InProcessingLot );
            strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_COUNT;
            strAdvanced_object_Lock_in.keySeq     = dummySeq;

            PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_InProcessingLot );
            rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                       strObjCommonIn,
                                       strAdvanced_object_Lock_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                strOpeStartReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                return( rc );
            }
        }
        
        // Lock Equipment LoadCassette Element (Read)
        CORBA::ULong cassetteLen = cassetteIDs.length();
        stringSequence loadCastSeq;
        loadCastSeq.length(cassetteLen);
        for (i=0; i<cassetteLen; i++)
        {
            loadCastSeq[i] = cassetteIDs[i].identifier;
        }
        
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
        strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_READ;
        strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_LoadCassette );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strOpeStartReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
        
        // controlJobID is not empty
        if ( 0 < CIMFWStrLen(controlJobID.identifier) )
        {
            PPT_METHODTRACE_V1("", "controlJobID exists");
            /*------------------------------*/
            /*   Lock ControlJob Object     */
            /*------------------------------*/
            PPT_METHODTRACE_V2( "", "calling object_Lock()", SP_ClassName_PosControlJob );
            rc = object_Lock( strObject_Lock_out,
                              strObjCommonIn,
                              controlJobID,
                              SP_ClassName_PosControlJob );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                strOpeStartReqResult.strResult = strObject_Lock_out.strResult;
                return( rc );
            }        
        }
        // controlJobID is empty
        else
        {
            PPT_METHODTRACE_V1("", "controlJobID is empty");
            /*------------------------------*/
            /*   Lock Dispatcher Object     */
            /*------------------------------*/
            PPT_METHODTRACE_V2( "", "calling object_Lock()", SP_ClassName_PosDispatcher );
            rc = object_Lock( strObject_Lock_out,
                              strObjCommonIn,
                              equipmentID,
                              SP_ClassName_PosDispatcher );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                strOpeStartReqResult.strResult = strObject_Lock_out.strResult;
                return( rc );
            }            

        }
    }
    /*------------------------------*/
    /*   Lock Cassette/Lot Object   */
    /*-------------------------------*/
    objObjectSequence_Lock_out strObjectSequence_Lock_out;

    PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosCassette );
    rc = objectSequence_Lock( strObjectSequence_Lock_out,
                              strObjCommonIn,
                              cassetteIDs,
                              SP_ClassName_PosCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
        strOpeStartReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }

    PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosLot );
    rc = objectSequence_Lock( strObjectSequence_Lock_out,
                              strObjCommonIn,
                              lotIDs,
                              SP_ClassName_PosLot );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
        strOpeStartReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }
//DSN000049350 Add End

//DSN000081739 Add Start
    CORBA::Long eqpMonitorSwitch = atoi( getenv(SP_EQPMONITOR_SWITCH) );
    if ( 1 == eqpMonitorSwitch )
    {
        PPT_METHODTRACE_V1("", "1 == SP_EQPMONITOR_SWITCH");
        objectIdentifierSequence eqpMonitorList;
        CORBA::ULong eqpMonitorCnt = 0;
        CORBA::ULong eqpMonitorLen = 5;
        eqpMonitorList.length(eqpMonitorLen);
        pptEqpMonitorJobInfoSequence strEqpMonitorJobInfoSeq;
        CORBA::ULong eqpMonJobCnt = 0;
        CORBA::ULong eqpMonJobLen = 5;
        strEqpMonitorJobInfoSeq.length(eqpMonJobLen);
        CORBA::ULong castLen = tmpStartCassette.length();
        for ( i=0; i<castLen; i++ )
        {
            PPT_METHODTRACE_V2("", "loop to tmpStartCassette.length()", i);
            CORBA::ULong lotLen = tmpStartCassette[i].strLotInCassette.length();
            for ( CORBA::ULong j=0; j<lotLen; j++ )
            {
                PPT_METHODTRACE_V2("", "loop to tmpStartCassette[i].strLotInCassette.length()", j);
                /*---------------------------*/
                /*   Omit Not-OpeStart Lot   */
                /*---------------------------*/
                if ( FALSE == tmpStartCassette[i].strLotInCassette[j].operationStartFlag )
                {
                    PPT_METHODTRACE_V1("", "tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE, continue");
                    continue;
                }

                if ( 0 != CIMFWStrCmp(tmpStartCassette[i].strLotInCassette[j].lotType, SP_Lot_Type_EquipmentMonitorLot)
                  && 0 != CIMFWStrCmp(tmpStartCassette[i].strLotInCassette[j].lotType, SP_Lot_Type_DummyLot) )
                {
                    PPT_METHODTRACE_V1("", "tmpStartCassette[i].strLotInCassette[j].lotType is not Equipment Monitor and Dummy, continue");
                    continue;
                }

                objLot_eqpMonitorSectionInfo_GetForJob_out strLot_eqpMonitorSectionInfo_GetForJob_out;
                objLot_eqpMonitorSectionInfo_GetForJob_in  strLot_eqpMonitorSectionInfo_GetForJob_in;
                strLot_eqpMonitorSectionInfo_GetForJob_in.lotID = tmpStartCassette[i].strLotInCassette[j].lotID;
                rc = lot_eqpMonitorSectionInfo_GetForJob( strLot_eqpMonitorSectionInfo_GetForJob_out,
                                                          strObjCommonIn,
                                                          strLot_eqpMonitorSectionInfo_GetForJob_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_eqpMonitorSectionInfo_GetForJob() != RC_OK", rc);
                    strOpeStartReqResult.strResult = strLot_eqpMonitorSectionInfo_GetForJob_out.strResult;
                    return rc;
                }

                if ( 0 < CIMFWStrLen( strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier ) )
                {
                    PPT_METHODTRACE_V1("", "0 < CIMFWStrLen( strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier )");
                    if ( 0 == CIMFWStrCmp(strLot_eqpMonitorSectionInfo_GetForJob_out.operationLabel, SP_EqpMonitor_OpeLabel_Monitor) )
                    {
                        PPT_METHODTRACE_V1("", "strLot_eqpMonitorSectionInfo_GetForJob_out.operationLabel is Monitor");
                        CORBA::Boolean bNewEqpMonitor = TRUE;
                        for ( CORBA::ULong iCnt1=0; iCnt1<eqpMonitorCnt; iCnt1++ )
                        {
                            PPT_METHODTRACE_V2("", "loop to eqpMonitorCnt", iCnt1);
                            if ( 0 == CIMFWStrCmp(eqpMonitorList[iCnt1].identifier, strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "eqpMonitorList[iCnt1].identifier == strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID.identifier");
                                bNewEqpMonitor = FALSE;
                                break;
                            }
                        }

                        if ( TRUE == bNewEqpMonitor )
                        {
                            PPT_METHODTRACE_V1("", "TRUE == bNewEqpMonitor");
                            if ( eqpMonitorCnt > eqpMonitorLen )
                            {
                                PPT_METHODTRACE_V1("", "eqpMonitorCnt > eqpMonitorLen");
                                eqpMonitorLen = eqpMonitorLen + 5;
                                eqpMonitorList.length(eqpMonitorLen);
                            }
                            eqpMonitorList[eqpMonitorCnt] = strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID;

                            eqpMonitorCnt++;
                        }
                    }

                    if ( 0 == CIMFWStrCmp(strLot_eqpMonitorSectionInfo_GetForJob_out.operationLabel, SP_EqpMonitor_OpeLabel_Monitor)
                      || TRUE == strLot_eqpMonitorSectionInfo_GetForJob_out.exitFlag )
                    {
                        PPT_METHODTRACE_V1("", "strLot_eqpMonitorSectionInfo_GetForJob_out.operationLabel is Monitor or strLot_eqpMonitorSectionInfo_GetForJob_out.exitFlag is TRUE");
                        CORBA::Boolean bNewEqpMonJob = TRUE;
                        for ( CORBA::ULong iCnt2=0; iCnt2<eqpMonJobCnt; iCnt2++ )
                        {
                            PPT_METHODTRACE_V2("", "loop to eqpMonJobCnt", iCnt2);
                            if ( 0 == CIMFWStrCmp(strEqpMonitorJobInfoSeq[iCnt2].eqpMonitorJobID.identifier,
                                                  strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier) )
                            {
                                PPT_METHODTRACE_V1("", "strEqpMonitorJobInfoSeq[iCnt2].eqpMonitorJobID.identifier == strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier");
                                bNewEqpMonJob = FALSE;
                                break;
                            }
                        }

                        if ( TRUE == bNewEqpMonJob )
                        {
                            PPT_METHODTRACE_V1("", "TRUE == bNewEqpMonJob");
                            if ( eqpMonJobCnt > eqpMonJobLen )
                            {
                                PPT_METHODTRACE_V1("", "eqpMonJobCnt > eqpMonJobLen");
                                eqpMonJobLen = eqpMonJobLen + 5;
                                strEqpMonitorJobInfoSeq.length(eqpMonJobLen);
                            }
                            strEqpMonitorJobInfoSeq[eqpMonJobCnt].eqpMonitorJobID = strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID;
                            strEqpMonitorJobInfoSeq[eqpMonJobCnt].eqpMonitorID    = strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID;

                            eqpMonJobCnt++;
                        }
                    }
                }
            }
        }
        eqpMonitorList.length(eqpMonitorCnt);
        strEqpMonitorJobInfoSeq.length(eqpMonJobCnt);
        for ( CORBA::ULong iCnt3=0; iCnt3<eqpMonitorCnt; iCnt3++ )
        {
            PPT_METHODTRACE_V2("", "loop to eqpMonitorCnt", iCnt3);
            //Lock EqpMonitor object
            objObject_Lock_out strObject_Lock_out;
            rc = object_Lock( strObject_Lock_out, strObjCommonIn, eqpMonitorList[iCnt3], SP_ClassName_PosEqpMonitor );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2(" ", "##### RC_OK != object_Lock()", rc);
                strOpeStartReqResult.strResult = strObject_Lock_out.strResult;
                return rc;
            }
        }

        for ( CORBA::ULong iCnt4=0; iCnt4<eqpMonJobCnt; iCnt4++ )
        {
            PPT_METHODTRACE_V2("", "loop to eqpMonJobCnt", iCnt4);
            //Lock EqpMonitor job object
            objObject_LockForEqpMonitorJob_out strObject_LockForEqpMonitorJob_out;
            objObject_LockForEqpMonitorJob_in  strObject_LockForEqpMonitorJob_in;
            strObject_LockForEqpMonitorJob_in.eqpMonitorID    = strEqpMonitorJobInfoSeq[iCnt4].eqpMonitorID;
            strObject_LockForEqpMonitorJob_in.eqpMonitorJobID = strEqpMonitorJobInfoSeq[iCnt4].eqpMonitorJobID;
            rc = object_LockForEqpMonitorJob( strObject_LockForEqpMonitorJob_out,
                                              strObjCommonIn,
                                              strObject_LockForEqpMonitorJob_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_LockForEqpMonitorJob() != RC_OK", rc);
                strOpeStartReqResult.strResult = strObject_LockForEqpMonitorJob_out.strResult;
                return rc;
            }
        }
    }
//DSN000081739 Add End

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   BRScript Execution Process                                          */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    nILen = strStartCassette.length();
    PPT_METHODTRACE_V2("", "nILen", nILen);
    for (i=0 ; i<nILen; i++)
    {
        /*-------------------------*/
        /*   Omit Empty Cassette   */
        /*-------------------------*/
        if (CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
        {
            continue;
        }

        CORBA::Long j = 0;
        CORBA::Long nJLen = strStartCassette[i].strLotInCassette.length();
        for (j=0 ; j<nJLen; j++)
        {
            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            {
                continue;
            }

            /*-------------------------*/
            /*   Execute Pre2 BRScript */
            /*-------------------------*/
            pptRunBRScriptReqResult strRunBRScriptReqResult;
            rc = txRunBRScriptReq( strRunBRScriptReqResult, strObjCommonIn,
                                   SP_BRScript_Pre2,
                                   strStartCassette[i].strLotInCassette[j].lotID,
                                   equipmentID );
            if ( rc == RC_NOT_FOUND_SCRIPT )
            {
                rc = RC_OK;
            }
            else if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V3("", "txRunBRScriptReq() rc != RC_OK", i, j);
                strOpeStartReqResult.strResult = strRunBRScriptReqResult.strResult;
                return( rc );
            }
        }
    }

//D51M0000 add start
//D8000207 move to upper    pptStartCassetteSequence tmpStartCassette;
//D8000207 move to upper    tmpStartCassette = strStartCassette;
    CORBA::Boolean sendTxFlag = FALSE;
    // sendTxFlag and strAPCRunTimeCapabilityInqResult is used by APCRuntimeCapability_RegistDR()
    // So, these cannot move into 'if sentence' and must initialize 'sendTxFlag=FALSE' and skip calling it.
    pptAPCRunTimeCapabilityInqResult strAPCRunTimeCapabilityInqResult;
    if(CIMFWStrLen(controlJobID.identifier) == 0)
    {
        PPT_METHODTRACE_V1("", "controlJobID.length() == 0");
        sendTxFlag = TRUE;
        /*-----------------------------------------*/
        /*   call txAPCRunTimeCapabilityInq        */
        /*-----------------------------------------*/
        PPT_METHODTRACE_V1("","call txAPCRunTimeCapabilityInq");
        rc = txAPCRunTimeCapabilityInq(strAPCRunTimeCapabilityInqResult,
                                       strObjCommonIn,
                                       equipmentID,
                                       controlJobID,
                                       tmpStartCassette,
                                       TRUE);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "txAPCRunTimeCapabilityInq() != RC_OK");
            strOpeStartReqResult.strResult = strAPCRunTimeCapabilityInqResult.strResult;
            return( rc );
        }

//D7000182 add start
        CORBA::Long RunCapaRespCount = strAPCRunTimeCapabilityInqResult.strAPCRunTimeCapabilityResponse.length();
        if( rc == RC_OK && RunCapaRespCount > 0 )
        {
            PPT_METHODTRACE_V1("", "Received RunTimeCapabilityResponse from APC.");
            CORBA::String_var tmpString = APCIFControlStatus;
            APCIFControlStatus = CIMFWStrDup(SP_APC_ControlJobStatus_Canceled);
        }
//D7000182 add end
        /*---------------------------------------------*/
        /*   call txAPCRecipeParameterAdjustInq        */
        /*---------------------------------------------*/
        PPT_METHODTRACE_V1("","call txAPCRecipeParameterAdjustInq");
        pptAPCRecipeParameterAdjustInqResult strAPCRecipeParameterAdjustInqResult;
        rc = txAPCRecipeParameterAdjustInq(strAPCRecipeParameterAdjustInqResult,
                                           strObjCommonIn,
                                           equipmentID,
                                           tmpStartCassette,
                                           strAPCRunTimeCapabilityInqResult.strAPCRunTimeCapabilityResponse,
                                           TRUE);
//D7000182        if( rc != RC_OK )
        if( rc != RC_OK && rc != RC_OK_NO_IF )    //D7000182
        {
            PPT_METHODTRACE_V1("","txAPCRecipeParameterAdjustInq() != RC_OK");
            strOpeStartReqResult.strResult = strAPCRecipeParameterAdjustInqResult.strResult;
            return( rc );
        }
        PPT_METHODTRACE_V1("", "Move structure(strAPCRecipeParameterAdjustInqResult.strStartCassette) to temporary domain");
        tmpStartCassette = strAPCRecipeParameterAdjustInqResult.strStartCassette;

//D7000182 add start
        if( rc == RC_OK )
        {
            PPT_METHODTRACE_V1("", "Received APCRecipeParameterResponse normally.");
            CORBA::String_var tmpString = APCIFControlStatus;
            APCIFControlStatus = CIMFWStrDup(SP_APC_ControlJobStatus_Canceled);
        }
//D7000182 add end
    }
    strOpeStartReqResult.strStartCassette = tmpStartCassette;
//D51M0000 add end

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Check Process                                                       */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

//D9000003 add start
    //APC result check.
    //Check every lot has at least one wafer with processJobExecFlag == TRUE
    PPT_METHODTRACE_V1("","Check every lot of APC result has at least one wafer with processJobExecFlag == TRUE.");
//DSN000015229    strLot_processJobExecFlag_ValidCheck_in.strStartCassette = tmpStartCassette;
//DSN000015229
//DSN000015229    rc = lot_processJobExecFlag_ValidCheck(strLot_processJobExecFlag_ValidCheck_out, strObjCommonIn, strLot_processJobExecFlag_ValidCheck_in);
//DSN000015229    if( rc != RC_OK)
//DSN000015229    {
//DSN000015229        PPT_METHODTRACE_V1("","objLot_processJobExecFlag_ValidCheck() != RC_OK ");
//DSN000015229        strOpeStartReqResult.strResult = strLot_processJobExecFlag_ValidCheck_out.strResult;
//DSN000015229        return rc;
//DSN000015229    }
//DSN000015229 Add Start
    strLot_processJobExecFlag_ValidCheckForOpeStart_in.strStartCassette = tmpStartCassette;
    strLot_processJobExecFlag_ValidCheckForOpeStart_in.processJobPauseFlag = processJobPauseFlag;
    rc = lot_processJobExecFlag_ValidCheckForOpeStart(strLot_processJobExecFlag_ValidCheckForOpeStart_out, strObjCommonIn, strLot_processJobExecFlag_ValidCheckForOpeStart_in);
    if( rc != RC_OK)
    {
        PPT_METHODTRACE_V2("","lot_processJobExecFlag_ValidCheckForOpeStart() != RC_OK", rc);
        strOpeStartReqResult.strResult = strLot_processJobExecFlag_ValidCheckForOpeStart_out.strResult;
        return rc;
    }
//DSN000015229 Add End
//D9000003 add end



    //P5000247 Add Start
    //---------------------------------------------------------------------------------
    // ControlJob Checking
    // If Start Cassette had a Control Job whether InParameter of Control Job is blank,
    // Makes request fail.
    //---------------------------------------------------------------------------------
    if ( CIMFWStrLen(controlJobID.identifier) == 0 )
    {
        PPT_METHODTRACE_V1("","Inpara controlJoID is Blank");
        //-----------------------------------------------------------
        // ControlJob Check for first record of strStartCassette.
        // Because checking ControlJob whether All ControlJoj is same
        // at cassette_CheckConditionForOperation().
        //-----------------------------------------------------------
        objCassette_controlJobID_Get_out   strCassette_controlJobID_Get_out;
//D51M0000        rc = cassette_controlJobID_Get(strCassette_controlJobID_Get_out, strObjCommonIn, strStartCassette[0].cassetteID );
        rc = cassette_controlJobID_Get(strCassette_controlJobID_Get_out, strObjCommonIn, tmpStartCassette[0].cassetteID );          //D51M0000
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "cassette_controlJobID_Get() rc != RC_OK")
            strOpeStartReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
            return( rc );
        }

        if ( CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) > 0 )
        {
            //---------------------------------
            // Inpara ControlJob is not blank
            // but StartCassette has ControlJo.
            //---------------------------------
            PPT_METHODTRACE_V2("","cassette's controlJob is not nil",strCassette_controlJobID_Get_out.controlJobID.identifier);
            SET_MSG_RC( strOpeStartReqResult, MSG_CAST_CTRLJOBID_FILLED, RC_CAST_CTRLJOBID_FILLED );
            return( RC_CAST_CTRLJOBID_FILLED );
        }
    }
    //P5000247 Add End

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Cassette                                          */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - controlJobID                                                      */
    /*   - multiLotType                                                      */
    /*   - transferState                                                     */
    /*   - transferReserved                                                  */
    /*   - dispatchState                                                     */
    /*   - maxBatchSize                                                      */
    /*   - minBatchSize                                                      */
    /*   - emptyCassetteCount                                                */
    /*   - cassette's loadingSequenceNumber                                  */ //P3000185
    /*   - eqp's multiRecipeCapability and recipeParameter                   */ //D3000079
    /*   - Upper/Lower Limit for RecipeParameterChange                       */ //P3100289
    /*   - MonitorLotCount or OperationStartLotCount                         */ //P3100289
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    objCassette_CheckConditionForOperation_out strCassette_CheckConditionForOperation_out;
    rc = cassette_CheckConditionForOperation( strCassette_CheckConditionForOperation_out, strObjCommonIn,
//D51M0000                                              equipmentID, portGroupID, strStartCassette, SP_Operation_OpeStart );
                                              equipmentID, portGroupID, tmpStartCassette, SP_Operation_OpeStart );          //D51M0000
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cassette_CheckConditionForOperation() rc != RC_OK");
        strOpeStartReqResult.strResult = strCassette_CheckConditionForOperation_out.strResult;
        return( rc );
    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Lot                                               */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - controlJobID                                                      */
    /*   - lot's equipmentID                                                 */
    /*   - lotHoldState                                                      */
    /*   - lotProcessState                                                   */
    /*   - lotInventoryState                                                 */
    /*   - entityInhibition                                                  */
    /*   - minWaferCount                                                     */
    /*   - equipment's availability for specified lot                        */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    objLot_CheckConditionForOperation_out strLot_CheckConditionForOperation_out;
    rc = lot_CheckConditionForOperation( strLot_CheckConditionForOperation_out, strObjCommonIn,
//0.01                                   equipmentID, portGroupID, strStartCassette, SP_Operation_StartReservation );
//D51M0000                                         equipmentID, portGroupID, strStartCassette, SP_Operation_OpeStart ); //0.01
                                         equipmentID, portGroupID, tmpStartCassette, SP_Operation_OpeStart ); //D51M0000
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_CheckConditionForOperation() rc != RC_OK");
        strOpeStartReqResult.strResult = strLot_CheckConditionForOperation_out.strResult;
        return( rc );
    }

    /*-----------------------------------------------------------------------------*/
    /*                                                                             */
    /*   Check Equipment Port for OpeStart                                         */
    /*                                                                             */
    /*   The following conditions are checked by this object                       */
    /*                                                                             */
    /*   1. All of ports' loadMode must be CIMFW_PortRsc_Input or _InputOutput.    */
    /*   2. All of port, which is registered as in-parm's portGroup, must be       */
    /*      _LoadComp when equipment is online.                                    */
    /*   3. All of port, which is registered as in-parm's portGroup, must have     */
    /*      loadedCassetteID. And each combination of cassetteID/portID must be    */
    /*      same as in-parm's startCassette perfectly.                             */
    /*   4. strStartCassette[].loadPortID's portGroupID must be same as in-parm's  */
    /*      portGroupID.                                                           */
    /*   5. strStartCassette[].loadPurposeType must be match as specified port's   */
    /*      loadPutposeType.                                                       */
    /*   6. strStartCassette[].loadSequenceNumber must be same as specified port's */
    /*      loadSequenceNumber.                                                    */
    /*                                                                             */
    /*-----------------------------------------------------------------------------*/
    objEquipment_portState_CheckForOpeStart_out strEquipment_portState_CheckForOpeStart_out;

    if( virtualOperationFlag == FALSE )    //DSN000096135
    {                                      //DSN000096135
        rc = equipment_portState_CheckForOpeStart( strEquipment_portState_CheckForOpeStart_out, strObjCommonIn,
//D51M0000                                               equipmentID, portGroupID, strStartCassette );
                                                   equipmentID, portGroupID, tmpStartCassette );                //D51M0000
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "equipment_portState_CheckForOpeStart() rc != RC_OK");
            strOpeStartReqResult.strResult = strEquipment_portState_CheckForOpeStart_out.strResult;
            return( rc );
        }
    }                                      //DSN000096135

    /*---------------------------------*/
    /*   Get Equipment's Online Mode   */
    /*---------------------------------*/
    objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;

    if( virtualOperationFlag == FALSE )    //DSN000096135
    {                                      //DSN000096135
        rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out, strObjCommonIn,
//D51M0000                                                equipmentID, strStartCassette[0].loadPortID );
                                                    equipmentID, tmpStartCassette[0].loadPortID );              //D51M0000
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "portResource_currentOperationMode_Get() rc != RC_OK");
            strOpeStartReqResult.strResult = strPortResource_currentOperationMode_Get_out.strResult;
            return( rc );
        }
    }                                      //DSN000096135

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for FlowBatch                                         */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   1. whether in-parm's equipment has reserved flowBatchID or not      */
    /*      fill  -> all of flowBatch member and in-parm's lot must be       */
    /*               same perfectly.                                         */
    /*      blank -> no check                                                */
    /*                                                                       */
    /*   2. whether lot is in flowBatch section or not                       */
    /*      in    -> lot must have flowBatchID, and flowBatch must have      */
    /*               reserved equipmentID.                                   */
    /*               if lot is on target operation, flowBatch's reserved     */
    /*               equipmentID and in-parm's equipmentID must be same.     */
    /*      out   -> no check                                                */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
//D9000079    objEquipment_lot_CheckFlowBatchConditionForOpeStart_out strEquipment_lot_CheckFlowBatchConditionForOpeStart_out;
//D9000079    rc = equipment_lot_CheckFlowBatchConditionForOpeStart( strEquipment_lot_CheckFlowBatchConditionForOpeStart_out, strObjCommonIn,
//D9000079//D51M0000                                                           equipmentID, portGroupID, strStartCassette );
//D9000079                                                           equipmentID, portGroupID, tmpStartCassette );            //D51M0000
//D9000079 add start
    objEquipment_lot_CheckFlowBatchConditionForOpeStart_out__090 strEquipment_lot_CheckFlowBatchConditionForOpeStart_out;
    objEquipment_lot_CheckFlowBatchConditionForOpeStart_in__090  strEquipment_lot_CheckFlowBatchConditionForOpeStart_in;
    strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.equipmentID = equipmentID;
    strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.portGroupID = portGroupID;
    strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.strStartCassette = tmpStartCassette;
    rc = equipment_lot_CheckFlowBatchConditionForOpeStart__090( strEquipment_lot_CheckFlowBatchConditionForOpeStart_out,
                                                                strObjCommonIn,
                                                                strEquipment_lot_CheckFlowBatchConditionForOpeStart_in);
//D9000079 add end
    if ( rc != RC_OK )
    {
//D9000079        PPT_METHODTRACE_V1("", "equipment_lot_CheckFlowBatchConditionForOpeStart() rc != RC_OK");
        PPT_METHODTRACE_V1("", "equipment_lot_CheckFlowBatchConditionForOpeStart__090() rc != RC_OK");          //D9000079
        strOpeStartReqResult.strResult = strEquipment_lot_CheckFlowBatchConditionForOpeStart_out.strResult;
        return( rc );
    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Process Durable                                   */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   1. Whether equipment requires process durable or not                */
    /*      If no-need, return OK;                                           */
    /*                                                                       */
    /*   2. All of specified reticles / fixtures must be in the equipment.   */
    /*      And, their state must be _Available or _InUse.                   */
    /*                                                                       */
    /*   3. Entity inhibition for all of specified reticles must not be      */
    /*      registered.                                                      */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/

    /*-----------------------------------------*/
    /*   Check Process Durable Required Flag   */
    /*-----------------------------------------*/
    objEquipment_processDurableRequiredFlag_Get_out strEquipment_processDurableRequiredFlag_Get_out;
    rc = equipment_processDurableRequiredFlag_Get( strEquipment_processDurableRequiredFlag_Get_out, strObjCommonIn,
                                                   equipmentID);
    CORBA::Long saveRC = rc;
    if ( rc == RC_EQP_PROCDRBL_RTCL_REQD ||
         rc == RC_EQP_PROCDRBL_FIXT_REQD )
    {
        PPT_METHODTRACE_V1("", "rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD");
        CORBA::Long i = 0;
//D51M0000        CORBA::Long nILen = strStartCassette.length();
        CORBA::Long nILen = tmpStartCassette.length();              //D51M0000
        PPT_METHODTRACE_V2("", "nILen", nILen);
        for (i=0 ; i<nILen; i++)
        {
//D51M0000            if (CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
            if (CIMFWStrCmp(tmpStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)            //D51M0000
            {
                continue;
            }

            CORBA::Long j = 0;
//D51M0000            CORBA::Long nJLen = strStartCassette[i].strLotInCassette.length();
            CORBA::Long nJLen = tmpStartCassette[i].strLotInCassette.length();                                      //D51M0000
            PPT_METHODTRACE_V3("", "nJLen", nJLen, i);
            for (j=0 ; j<nJLen; j++)
            {
//D51M0000                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                if ( tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )                          //D51M0000
                {
                    continue;
                }

//D4200031      if ( saveRC == RC_EQP_PROCDRBL_RTCL_REQD )
                if ( saveRC == RC_EQP_PROCDRBL_RTCL_REQD                                                  //D4200031
//D51M0000                  && strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle.length() > 0 )//D4200031
                  && tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle.length() > 0 )          //D51M0000
                {
                    PPT_METHODTRACE_V3("", "saveRC == RC_EQP_PROCDRBL_RTCL_REQD", i, j);

                    /*---------------------------------*/
                    /*   Get and Check Reticle State   */
                    /*     - state                     */
                    /*     - transferState             */
                    /*---------------------------------*/
                    objReticle_state_Check_out strReticle_state_Check_out;
//DSN000101569                     rc = reticle_state_Check( strReticle_state_Check_out,  strObjCommonIn,
//DSN000101569                                               equipmentID,
//DSN000101569 //D51M0000                                              strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle );
//DSN000101569                                               tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle );         //D51M0000
//DSN000101569 add start
                    rc = reticle_state_Check__170( strReticle_state_Check_out,
                                                   strObjCommonIn,
                                                   equipmentID,
                                                   tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle,
                                                   tmpStartCassette[i].strLotInCassette[j].lotID );
//DSN000101569 add end
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V3("", "reticle_state_Check() rc != RC_OK", i, j);
                        strOpeStartReqResult.strResult = strReticle_state_Check_out.strResult;
                        return( rc );
                    }

//D4200081 delete start
//D4200081                    /*------------------------------*/
//D4200081                    /*   Check Reticle Inhibition   */
//D4200081                    /*------------------------------*/
//D4200081                    //--- Get sub lot type to use in reticle inhibition ---------------------------//     //P4100063
//D4200081//D4200039                    PosLot_var aLot;                                                                      //P4100063
//D4200081//D4200039                    PPT_CONVERT_LOTID_TO_LOT_OR( aLot                                            ,        //P4100063
//D4200081//D4200039                                                 strStartCassette[i].strLotInCassette[j].lotID   ,        //P4100063
//D4200081//D4200039                                                 strOpeStartReqResult                            ,        //P4100063
//D4200081//D4200039                                                 txOpeStartReq )                                 ;        //P4100063
//D4200081//D4200039                                                                                                          //P4100063
//D4200081//D4200039                    CORBA::String_var aSubLotType = CORBA::String(NULL) ;                                 //P4100063
//D4200081//D4200039                                                                                                          //P4100063
//D4200081//D4200039                    if ( !CORBA::is_nil(aLot) )                                                           //P4100063
//D4200081//D4200039                    {                                                                                     //P4100063
//D4200081//D4200039                        aSubLotType = aLot->getSubLotType();                                              //P4100063
//D4200081//D4200039                        PPT_METHODTRACE_V2("", "Sub Lot Type", aSubLotType );                             //P4100063
//D4200081//D4200039                    }                                                                                     //P4100063
//D4200081
//D4200081                    //D4200039 Add Start
//D4200081                    objLot_subLotType_Get_out    strLot_subLotType_Get_out;
//D4200081                    rc = lot_subLotType_Get( strLot_subLotType_Get_out, strObjCommonIn, strStartCassette[i].strLotInCassette[j].lotID );
//D4200081                    if ( rc != RC_OK )
//D4200081                    {
//D4200081                        strOpeStartReqResult.strResult = strLot_subLotType_Get_out.strResult;
//D4200081                        return rc;
//D4200081                    }
//D4200081                    CORBA::String_var aSubLotType = strLot_subLotType_Get_out.subLotType;
//D4200081
//D4200081                    PPT_METHODTRACE_V2("","SubLotType Getting By ObjMethod",aSubLotType);
//D4200081                    //D4200039 Add End
//D4200081
//D4200081                    CORBA::Long rtclLen = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle.length();
//D4200081
//D4200081//                    pptEntityInhibitAttributes entityInhibitAttributes(rtclLen);
//D4200081                    pptEntityInhibitAttributes entityInhibitAttributes;
//D4200081                    entityInhibitAttributes.entities.length(rtclLen);
//D4200081                    CORBA::Long k = 0;
//D4200081                    PPT_METHODTRACE_V4("", "rtclLen", rtclLen, i, j);
//D4200081                    for ( k=0 ; k<rtclLen ; k++ )
//D4200081                    {
//D4200081                        entityInhibitAttributes.entities[k].className = CIMFWStrDup( SP_InhibitClassID_Reticle );
//D4200081                        entityInhibitAttributes.entities[k].objectID  = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID;
//D4200081                        entityInhibitAttributes.entities[k].attrib    = CIMFWStrDup( "" );
//D4200081
//D4200081                        PPT_METHODTRACE_V2("", "entityInhibitAttributes.entities[k].objectID ---> ", entityInhibitAttributes.entities[k].objectID.identifier);
//D4200081                    }
//D4200081
//D4200081                    //--- Set sub lot type --------------------------------------------------------//     //P4100063
//D4200081                    if ( aSubLotType != NULL )                                                            //P4100063
//D4200081                    {                                                                                     //P4100063
//D4200081                        entityInhibitAttributes.subLotTypes.length(1) ;                                   //P4100063
//D4200081                        entityInhibitAttributes.subLotTypes[0] = CIMFWStrDup( aSubLotType ) ;             //P4100063
//D4200081                    }                                                                                     //P4100063
//D4200081                    else                                                                                  //P4100063
//D4200081                    {                                                                                     //P4100063
//D4200081                        entityInhibitAttributes.subLotTypes.length(0) ;                                   //P4100063
//D4200081                    }                                                                                     //P4100063
//D4200081
//D4200081                    objEntityInhibit_CheckForEntities_out strEntityInhibit_CheckForEntities_out;
//D4200081                    rc = entityInhibit_CheckForEntities( strEntityInhibit_CheckForEntities_out, strObjCommonIn,
//D4200081                                                         entityInhibitAttributes );
//D4200081                    if ( rc != RC_OK )
//D4200081                    {
//D4200081                        PPT_METHODTRACE_V3("", "entityInhibit_CheckForEntities() rc != RC_OK", i, j);
//D4200081                        strOpeStartReqResult.strResult = strEntityInhibit_CheckForEntities_out.strResult;
//D4200081                        return( rc );
//D4200081                    }
//D4200081
//D4200081                    CORBA::Long lenInhibit = strEntityInhibit_CheckForEntities_out.entityInhibitInfo.length() ;                       //Q3000106
//D4200081                    if( lenInhibit > 0 )                                                                                              //Q3000106
//D4200081                    {                                                                                                                 //Q3000106
//D4200081                        //P4100536 add start
//D4200081                        // Check length of Entity Inhibit
//D4200081                        if(0 >= strEntityInhibit_CheckForEntities_out.entityInhibitInfo[0].entityInhibitAttributes.entities.length())
//D4200081                        {
//D4200081                            SET_MSG_RC(strOpeStartReqResult, MSG_NOT_FOUND_ENTITYINHIBIT, RC_NOT_FOUND_ENTITYINHIBIT); //P4200025 add
//D4200081                            return RC_NOT_FOUND_ENTITYINHIBIT;
//D4200081                        }
//D4200081                        //P4100536 add end
//D4200081                        PPT_METHODTRACE_V2("", "Inhibit record for reticle is found", lenInhibit );       //Q3000106
//D4200081                        PPT_SET_MSG_RC_KEY2 ( strOpeStartReqResult,                                                                   //Q3000106
//D4200081                                              MSG_INHIBIT_ENTITY ,                                                                    //Q3000106
//D4200081                                              RC_INHIBIT_ENTITY ,                                                                     //Q3000106
//D4200081                                              strEntityInhibit_CheckForEntities_out.entityInhibitInfo[0].entityInhibitAttributes.entities[0].objectID.identifier,  //P3100009
//D4200081//P3100009                                              entityInhibitAttributes.entities[0].objectID.identifier ,                               //Q3000106
//D4200081                                              SP_InhibitClassID_Reticle );                                                            //Q3000106
//D4200081                        return( RC_INHIBIT_ENTITY );                                                                                  //Q3000106
//D4200081                    }                                                                                                                 //Q3000106
//D4200081//D4200081 delete end

//D4200081 start
//D51M0000 delete start
//                    PPT_METHODTRACE_V1("", "call equipment_CheckInhibitForLotWithMachineRecipe()");
//                    pptStartCassetteSequence strStartCassetteSeq;
//                    strStartCassetteSeq.length(1);
//                    strStartCassetteSeq[0].strLotInCassette.length(1);
//
//                    objectIdentifierSequence checkLotIDs;
//                    checkLotIDs.length(1);
//                    checkLotIDs[0] = strStartCassette[i].strLotInCassette[j].lotID;
//                    PPT_METHODTRACE_V2("", "lotID", strStartCassette[i].strLotInCassette[j].lotID.identifier);
//
//                    strStartCassetteSeq[0].strLotInCassette[0].lotID = strStartCassette[i].strLotInCassette[j].lotID;
//                    strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.machineRecipeID = strStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID;
//                    PPT_METHODTRACE_V2("", "machineRecipeID", strStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID.identifier);
//
//                    CORBA::Long rtclLen = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle.length();
//                    PPT_METHODTRACE_V2("", "rtclLen", rtclLen);
//                    strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.strStartReticle.length( rtclLen );
//
//                    strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.logicalRecipeID = strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID;    //D5100087
//                    PPT_METHODTRACE_V2("", "logicalRecipeID", strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID.identifier);                          //D5100087
//
//                    for ( CORBA::Long k=0; k < rtclLen; k++ )
//                    {
//                        strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.strStartReticle[k].reticleID
//                                = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID;
//                        PPT_METHODTRACE_V2("", "reticleID", strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID.identifier);
//                    }
//D51M0000 delete end
//D51M0000 add start
// strStartCassette -> tmpStartCassette
                    PPT_METHODTRACE_V1("", "call equipment_CheckInhibitForLotWithMachineRecipe()");
                    pptStartCassetteSequence strStartCassetteSeq;
                    strStartCassetteSeq.length(1);
                    strStartCassetteSeq[0].strLotInCassette.length(1);

                    objectIdentifierSequence checkLotIDs;
                    checkLotIDs.length(1);
                    checkLotIDs[0] = tmpStartCassette[i].strLotInCassette[j].lotID;
                    PPT_METHODTRACE_V2("", "lotID", tmpStartCassette[i].strLotInCassette[j].lotID.identifier);

                    strStartCassetteSeq[0].strLotInCassette[0].lotID = tmpStartCassette[i].strLotInCassette[j].lotID;
                    strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.machineRecipeID = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID;
                    PPT_METHODTRACE_V2("", "machineRecipeID", tmpStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID.identifier);

                    CORBA::Long rtclLen = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle.length();
                    PPT_METHODTRACE_V2("", "rtclLen", rtclLen);
                    strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.strStartReticle.length( rtclLen );

                    strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.logicalRecipeID = strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID;
                    PPT_METHODTRACE_V2("", "logicalRecipeID", tmpStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID.identifier);

                    for ( CORBA::Long k=0; k < rtclLen; k++ )
                    {
                        strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.strStartReticle[k].reticleID
                                = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID;
                        PPT_METHODTRACE_V2("", "reticleID", tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID.identifier);
                    }
//D51M0000 add end

                    objEquipment_CheckInhibitForLotWithMachineRecipe_out strEquipment_CheckInhibitForLotWithMachineRecipe_out;
                    rc = equipment_CheckInhibitForLotWithMachineRecipe( strEquipment_CheckInhibitForLotWithMachineRecipe_out,
                                                                        strObjCommonIn,
                                                                        equipmentID,
                                                                        checkLotIDs,
                                                                        strStartCassetteSeq );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "##### equipment_CheckInhibitForLotWithMachineRecipe() rc != RC_OK", rc);
                        strOpeStartReqResult.strResult = strEquipment_CheckInhibitForLotWithMachineRecipe_out.strResult;
                        return( rc );
                    }
//D4200081 end

//D9000084 add start
                    rtclLen = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle.length();
                    for ( k = 0; k < rtclLen; k++ )
                    {
                        /*--------------------------------------*/
                        /*  Check ReticleDispatchJob existence  */
                        /*--------------------------------------*/
                        objectIdentifier dummyID;
                        objReticle_dispatchJob_CheckExistenceDR_out strReticle_dispatchJob_CheckExistenceDR_out;
                        rc = reticle_dispatchJob_CheckExistenceDR( strReticle_dispatchJob_CheckExistenceDR_out,
                                                                   strObjCommonIn,
                                                                   tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID,
                                                                   dummyID,    //reticlePodID
                                                                   dummyID );  //toEquipmentID
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "reticle_dispatchJob_CheckExistenceDR() != RC_OK", rc);
                            strOpeStartReqResult.strResult = strReticle_dispatchJob_CheckExistenceDR_out.strResult;
                            return( rc );
                        }

                        /*--------------------------------*/
                        /*  Check Reticle Pod relation.   */
                        /*--------------------------------*/
//DSN000096126                        objReticle_detailInfo_GetDR_in__090 strReticle_detailInfo_GetDR_in__090;
//DSN000096126                        strReticle_detailInfo_GetDR_in__090.reticleID = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID;
//DSN000096126
//DSN000096126                        objReticle_detailInfo_GetDR_out__090 strReticle_detailInfo_GetDR_out__090;
//DSN000096126                        rc = reticle_detailInfo_GetDR__090( strReticle_detailInfo_GetDR_out__090,
//DSN000096126                                                            strObjCommonIn,
//DSN000096126                                                            strReticle_detailInfo_GetDR_in__090 );
//DSN000096126                        if( rc != RC_OK )
//DSN000096126                        {
//DSN000096126                            PPT_METHODTRACE_V2("", "reticle_detailInfo_GetDR__090() != RC_OK", rc);
//DSN000096126                            strOpeStartReqResult.strResult = strReticle_detailInfo_GetDR_out__090.strResult;
//DSN000096126                            return( rc );
//DSN000096126                        }
//DSN000096126 Add Start
//DSN000101569                        objReticle_detailInfo_GetDR_out__160 strReticle_detailInfo_GetDR_out;
                        objReticle_detailInfo_GetDR_out__170 strReticle_detailInfo_GetDR_out;                                   //DSN000101569
                        objReticle_detailInfo_GetDR_in__160  strReticle_detailInfo_GetDR_in;
                        strReticle_detailInfo_GetDR_in.reticleID                   = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID;
                        strReticle_detailInfo_GetDR_in.durableOperationInfoFlag    = FALSE;
                        strReticle_detailInfo_GetDR_in.durableWipOperationInfoFlag = FALSE;
//DSN000101569                        rc = reticle_detailInfo_GetDR__160(strReticle_detailInfo_GetDR_out, strObjCommonIn, strReticle_detailInfo_GetDR_in);
                        rc = reticle_detailInfo_GetDR__170(strReticle_detailInfo_GetDR_out, strObjCommonIn, strReticle_detailInfo_GetDR_in); //DSN000101569
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "reticle_detailInfo_GetDR__170() != RC_OK", rc);
                            strOpeStartReqResult.strResult = strReticle_detailInfo_GetDR_out.strResult;
                            return( rc );
                        }
//DSN000096126 Add End

//DSN000096126                        if( 0 != CIMFWStrLen( strReticle_detailInfo_GetDR_out__090.strReticleStatusInqResult.reticleStatusInfo.reticlePodID.identifier ) )
                        if( 0 != CIMFWStrLen( strReticle_detailInfo_GetDR_out.strReticleStatusInqResult.reticleStatusInfo.reticlePodID.identifier ) ) //DSN000096126
                        {
                            PPT_METHODTRACE_V3("","Required reticle relates with reticlePod.",
                                                  tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID.identifier,
//DSN000096126                                                  strReticle_detailInfo_GetDR_out__090.strReticleStatusInqResult.reticleStatusInfo.reticlePodID.identifier );
                                                  strReticle_detailInfo_GetDR_out.strReticleStatusInqResult.reticleStatusInfo.reticlePodID.identifier ); //DSN000096126
                            SET_MSG_RC(strOpeStartReqResult, MSG_NOT_AVAILABLE_RETICLE, RC_NOT_AVAILABLE_RETICLE);
                            return( RC_NOT_AVAILABLE_RETICLE );
                        }
                    }
//D9000084 add end
                }
                else if ( saveRC == RC_EQP_PROCDRBL_FIXT_REQD )
                {
                    PPT_METHODTRACE_V3("", "saveRC == RC_EQP_PROCDRBL_FIXT_REQD", i, j);
                    /*---------------------------------*/
                    /*   Get and Check Fixture State   */
                    /*     - state                     */
                    /*     - transferState             */
                    /*---------------------------------*/
                    objFixture_state_Check_out strFixture_state_Check_out;
                    rc = fixture_state_Check( strFixture_state_Check_out, strObjCommonIn,
//D51M0000                                              equipmentID, strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture );
                                              equipmentID, tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture );            //D51M0000
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V3("", "entitfixture_state_CheckyInhibit_CheckForEntities() rc != RC_OK", i, j);
                        strOpeStartReqResult.strResult = strFixture_state_Check_out.strResult;
                        return( rc );
                    }

//D4200081 start
//D51M0000 delete start
//                    PPT_METHODTRACE_V1("", "call equipment_CheckInhibitForLotWithMachineRecipe()");
//                    pptStartCassetteSequence strStartCassetteSeq;
//                    strStartCassetteSeq.length(1);
//                    strStartCassetteSeq[0].strLotInCassette.length(1);
//
//                    objectIdentifierSequence checkLotIDs;
//                    checkLotIDs.length(1);
//                    checkLotIDs[0] = strStartCassette[i].strLotInCassette[j].lotID;
//                    PPT_METHODTRACE_V2("", "lotID", strStartCassette[i].strLotInCassette[j].lotID.identifier);
//
//                    strStartCassetteSeq[0].strLotInCassette[0].lotID = strStartCassette[i].strLotInCassette[j].lotID;
//                    strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.machineRecipeID = strStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID;
//                    PPT_METHODTRACE_V2("", "machineRecipeID", strStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID.identifier);
//
//                    CORBA::Long fixtureLen = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture.length();
//                    PPT_METHODTRACE_V2("", "fixtureLen", fixtureLen);
//                    strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.strStartFixture.length( fixtureLen );
//
//                    strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.logicalRecipeID = strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID;    //D5100087
//                    PPT_METHODTRACE_V2("", "logicalRecipeID", strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID.identifier);                          //D5100087
//
//                    for ( CORBA::Long k=0; k < fixtureLen; k++ )
//                    {
//                        strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.strStartFixture[k].fixtureID
//                                = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture[k].fixtureID;
//                        PPT_METHODTRACE_V2("", "fixtureID", strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture[k].fixtureID.identifier);
//                    }
//D51M0000 delete end
//D51M0000 add start
// strStartCassette -> tmpStartCassette
                    PPT_METHODTRACE_V1("", "call equipment_CheckInhibitForLotWithMachineRecipe()");
                    pptStartCassetteSequence strStartCassetteSeq;
                    strStartCassetteSeq.length(1);
                    strStartCassetteSeq[0].strLotInCassette.length(1);

                    objectIdentifierSequence checkLotIDs;
                    checkLotIDs.length(1);
                    checkLotIDs[0] = tmpStartCassette[i].strLotInCassette[j].lotID;
                    PPT_METHODTRACE_V2("", "lotID", tmpStartCassette[i].strLotInCassette[j].lotID.identifier);

                    strStartCassetteSeq[0].strLotInCassette[0].lotID = tmpStartCassette[i].strLotInCassette[j].lotID;
                    strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.machineRecipeID = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID;
                    PPT_METHODTRACE_V2("", "machineRecipeID", tmpStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID.identifier);

                    CORBA::Long fixtureLen = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture.length();
                    PPT_METHODTRACE_V2("", "fixtureLen", fixtureLen);
                    strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.strStartFixture.length( fixtureLen );

                    strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.logicalRecipeID = strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID;
                    PPT_METHODTRACE_V2("", "logicalRecipeID", tmpStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID.identifier);

                    for ( CORBA::Long k=0; k < fixtureLen; k++ )
                    {
                        strStartCassetteSeq[0].strLotInCassette[0].strStartRecipe.strStartFixture[k].fixtureID
                                = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture[k].fixtureID;
                        PPT_METHODTRACE_V2("", "fixtureID", tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture[k].fixtureID.identifier);
                    }
//D51M0000 add end

                    objEquipment_CheckInhibitForLotWithMachineRecipe_out strEquipment_CheckInhibitForLotWithMachineRecipe_out;
                    rc = equipment_CheckInhibitForLotWithMachineRecipe( strEquipment_CheckInhibitForLotWithMachineRecipe_out,
                                                                        strObjCommonIn,
                                                                        equipmentID,
                                                                        checkLotIDs,
                                                                        strStartCassetteSeq );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "##### equipment_CheckInhibitForLotWithMachineRecipe() rc != RC_OK", rc);
                        strOpeStartReqResult.strResult = strEquipment_CheckInhibitForLotWithMachineRecipe_out.strResult;
                        return( rc );
                    }
//D4200081 end
                }
            }
        }
    }
    else if ( rc == RC_EQP_PROCDRBL_NOT_REQD )
    {
         rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1("", "equipment_processDurableRequiredFlag_Get() rc != RC_OK");
        strOpeStartReqResult.strResult = strEquipment_processDurableRequiredFlag_Get_out.strResult;
        return( rc );
    }

//D4000016 Add Start
    /*---------------------------------------------------------------------------*/
    /*                                                                           */
    /*   Check Category for Copper/Non Copper                                    */
    /*                                                                           */
    /*   It is checked in the following method whether it is the condition       */
    /*   that Lot of the object is made of OpeStart.                             */
    /*                                                                           */
    /*   1. It is checked whether CassetteCategory of RequiredCassetteCategory   */
    /*      of PosLot and PosCassette is the same.                               */
    /*                                                                           */
    /*   2. It is checked whether CassetteCategoryCapability of CassetteCategory */
    /*      of PosCassette and PosPortResource is the same.                      */
    /*                                                                           */
    /*   3. It is proper condition if CassetteCategoryCapability is the same     */
    /*      as RequiredCassetteCategory and CassetteCategory.                    */
    /*                                                                           */
    /*---------------------------------------------------------------------------*/
    CORBA::Long ii;
    CORBA::Long jj;
//D51M0000    CORBA::Long nCastLen = strStartCassette.length();
    CORBA::Long nCastLen = tmpStartCassette.length();               //D51M0000
    CORBA::Long nLotInCastLen;

    for ( ii = 0; ii < nCastLen; ii++ )
    {
//D51M0000        nLotInCastLen = strStartCassette[ii].strLotInCassette.length();
        nLotInCastLen = tmpStartCassette[ii].strLotInCassette.length();             //D51M0000
        for ( jj = 0; jj < nLotInCastLen; jj++ )
        {
//D51M0000            if ( strStartCassette[ii].strLotInCassette[jj].operationStartFlag == FALSE )        //D4000016 add 08292001
            if ( tmpStartCassette[ii].strLotInCassette[jj].operationStartFlag == FALSE )        //D51M0000
            {                                                                                   //D4000016 add 08292001
                continue;                                                                       //D4000016 add 08292001
            }                                                                                   //D4000016 add 08292001

            objLot_CassetteCategory_CheckForContaminationControl_out strLot_CassetteCategory_CheckForContaminationControl_out;

            if( virtualOperationFlag == FALSE )    //DSN000096135
            {                                      //DSN000096135
                rc = lot_CassetteCategory_CheckForContaminationControl( strLot_CassetteCategory_CheckForContaminationControl_out,
                                                          strObjCommonIn,
//D51M0000                                                      strStartCassette[ii].strLotInCassette[jj].lotID,
                                                          tmpStartCassette[ii].strLotInCassette[jj].lotID,              //D51M0000
//D51M0000                                                      strStartCassette[ii].cassetteID,
                                                          tmpStartCassette[ii].cassetteID,                              //D51M0000
                                                          equipmentID,
//D51M0000                                                      strStartCassette[ii].loadPortID);
                                                          tmpStartCassette[ii].loadPortID);                             //D51M0000
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "CS_PPTManager_i:: txOpeStartReq", "lot_CassetteCategory_CheckForContaminationControl() != RC_OK");
                    strOpeStartReqResult.strResult = strLot_CassetteCategory_CheckForContaminationControl_out.strResult;
                    return( rc );
                }
            }                                      //DSN000096135
        }
//INN-R170002 add start
        if ( 0 == CIMFWStrCmp(tmpStartCassette[ii].loadPurposeType, SP_LoadPurposeType_EmptyCassette) )
        {
            //check empty
        }
        else
        {
            csObjLot_ContaminationInfo_CheckForProcess_in  strLot_ContaminationInfo_CheckForProcess_in;
            strLot_ContaminationInfo_CheckForProcess_in.equipmentID = equipmentID;
            strLot_ContaminationInfo_CheckForProcess_in.carrierID   = tmpStartCassette[ii].cassetteID;
            strLot_ContaminationInfo_CheckForProcess_in.strLotInCassette = tmpStartCassette[ii].strLotInCassette;

            csObjLot_ContaminationInfo_CheckForProcess_out strLot_ContaminationInfo_CheckForProcess_out;
            rc = cs_lot_ContaminationInfo_CheckForProcess( strLot_ContaminationInfo_CheckForProcess_out,
                                                           strObjCommonIn,
                                                           strLot_ContaminationInfo_CheckForProcess_in);

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "cs_lot_ContaminationInfo_CheckForProcess() != RC_OK");
                strOpeStartReqResult.strResult = strLot_ContaminationInfo_CheckForProcess_out.strResult;
                return( rc );
            }
            if ( FALSE == strLot_ContaminationInfo_CheckForProcess_out.matchFlag )
            {
                PPT_METHODTRACE_V1( "", "strLot_ContaminationInfo_CheckForProcess_out.matchFlag=FALSE");
                CS_PPT_SET_MSG_RC_KEY1( strOpeStartReqResult,
                                     CS_MSG_CARRIER_CONTAMINATION_MISMATCH,
                                     CS_RC_CARRIER_CONTAMINATION_MISMATCH,
                                     tmpStartCassette[ii].cassetteID.identifier );
                return CS_RC_CARRIER_CONTAMINATION_MISMATCH;
            }
        }
//INN-R170002 add end
    }
//D4000016 Add End

//D7000041 start
    /*---------------------------------------------------------------------------*/
    /*                                                                           */
    /*   Check Carrier Category for next operation of Empty carrier.             */
    /*                                                                           */
    /*---------------------------------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call emptyCassette_CheckCategoryForOperation()");
    objEmptyCassette_CheckCategoryForOperation_out strEmptyCassette_CheckCategoryForOperation_out;
    rc = emptyCassette_CheckCategoryForOperation( strEmptyCassette_CheckCategoryForOperation_out, strObjCommonIn, tmpStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "emptyCassette_CheckCategoryForOperation() != RC_OK", rc);
        strOpeStartReqResult.strResult = strEmptyCassette_CheckCategoryForOperation_out.strResult;
        return( rc );
    }
//D7000041 end

//D5000001 start
    /*-------------------------------*/
    /*   Check for RecipeParameter   */
    /*-------------------------------*/
    PPT_METHODTRACE_V1( "CS_PPTManager_i:: txOpeStartReq", "Check for RecipeParameter");
    objRecipeParameter_CheckConditionForOpeStart_out  strRecipeParameter_CheckConditionForOpeStart_out;
    rc = recipeParameter_CheckConditionForOpeStart( strRecipeParameter_CheckConditionForOpeStart_out,
                                                    strObjCommonIn,
                                                    equipmentID,
                                                    portGroupID,
                                                    controlJobID,
//D51M0000                                                    strStartCassette,
                                                    tmpStartCassette,               //D51M0000
                                                    processJobPauseFlag );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2( "CS_PPTManager_i:: txOpeStartReq", "recipeParameter_CheckConditionForOpeStart() != RC_OK", rc);
        strOpeStartReqResult.strResult = strRecipeParameter_CheckConditionForOpeStart_out.strResult;
        return( rc );
    }
//D5000001 end

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Main Process                                                        */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

    /*--------------------------------------------------------*/
    /*     Control Job Related Information Update Procedure   */
    /*--------------------------------------------------------*/
    objectIdentifier saveControlJobID;

    if ( CIMFWStrLen(controlJobID.identifier) == 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) == 0");

        /*-------------------------------------------------------------*/
        /*   Create Control Job and Assign to Each Cassettes / Lots    */
        /*                                                             */
        /*   - Create new controlJob                                   */
        /*   - Set created controlJobID to each cassettes / lots       */
        /*   - Set created controlJobID to equipment                   */
        /*-------------------------------------------------------------*/
//D7000006        objControlJob_Create_out strControlJob_Create_out;
//D7000006        rc = controlJob_Create( strControlJob_Create_out, strObjCommonIn,
//D7000006//D51M0000                                equipmentID, portGroupID, strStartCassette );
//D7000006                               equipmentID, portGroupID, tmpStartCassette );       //D51M0000
//D7000006        if ( rc != RC_OK )
//D7000006        {
//D7000006            PPT_METHODTRACE_V1("", "controlJob_Create() rc != RC_OK");
//D7000006            strOpeStartReqResult.strResult = strControlJob_Create_out.strResult;
//D7000006            return( rc );
//D7000006        }
//D7000006        saveControlJobID = strControlJob_Create_out.controlJobID;
        //D7000006 Add Start
        pptControlJobManageReqResult strControlJobManageReqResult;
        pptControlJobCreateRequest   strControlJobCreateRequest;
        objectIdentifier             dummyControlJobID;
        strControlJobCreateRequest.equipmentID = equipmentID;
        strControlJobCreateRequest.portGroupID = portGroupID;
        strControlJobCreateRequest.strStartCassette = tmpStartCassette;
        rc = txControlJobManageReq( strControlJobManageReqResult,
                                    strObjCommonIn,
                                    dummyControlJobID,
                                    SP_ControlJobAction_Type_create,
                                    strControlJobCreateRequest,
                                    claimMemo );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "txControlJobManageReq() != RC_OK");
            strOpeStartReqResult.strResult = strControlJobManageReqResult.strResult;
            return( rc );
        }
        saveControlJobID = strControlJobManageReqResult.controlJobID;
        //D7000006 Add End

        /*----------------------------------------------------*/
        /*   Set Start Reservation Info to Each Lots' PO      */
        /*                                                    */
        /*   - Set created controlJobID into each cassette.   */
        /*   - Set created controlJobID into each lot.        */
        /*   - Set control job info (StartRecipe, DCDefs,     */
        /*     DCSpecs, Parameters, ...) into each lot's      */
        /*     cunrrent PO.                                   */
        /*----------------------------------------------------*/
//D9000003 delete start
//        objProcess_startReserveInformation_Set_out strProcess_startReserveInformation_Set_out;
//        rc = process_startReserveInformation_Set( strProcess_startReserveInformation_Set_out, strObjCommonIn,
////D51M0000                                                  equipmentID, portGroupID, saveControlJobID, strStartCassette );
//                                                  equipmentID, portGroupID, saveControlJobID, tmpStartCassette );               //D51M0000
//        if ( rc != RC_OK )
//        {
//            PPT_METHODTRACE_V1("", "process_startReserveInformation_Set() rc != RC_OK");
//            strOpeStartReqResult.strResult = strProcess_startReserveInformation_Set_out.strResult;
//            return( rc );
//        }
//D9000003 delete end
//D9000003 add start
        objProcess_startReserveInformation_Set_out__090 strProcess_startReserveInformation_Set_out__090;
        objProcess_startReserveInformation_Set_in__090 strProcess_startReserveInformation_Set_in__090;
        strProcess_startReserveInformation_Set_in__090.equipmentID = equipmentID;
        strProcess_startReserveInformation_Set_in__090.portGroupID = portGroupID;
        strProcess_startReserveInformation_Set_in__090.controlJobID = saveControlJobID;
        strProcess_startReserveInformation_Set_in__090.strStartCassette = tmpStartCassette;
        strProcess_startReserveInformation_Set_in__090.processJobPauseFlag = processJobPauseFlag;

        rc = process_startReserveInformation_Set__090( strProcess_startReserveInformation_Set_out__090, strObjCommonIn, strProcess_startReserveInformation_Set_in__090);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "process_startReserveInformation_Set__090() rc != RC_OK");
            strOpeStartReqResult.strResult = strProcess_startReserveInformation_Set_out__090.strResult;
            return( rc );
        }
//D9000003 add end



//D8000024 add start

//D9000001        CORBA::Long  tmpFPCAdoptFlag = atol( getenv(SP_FPC_Adaptation_Flag) );
        CORBA::Long  tmpFPCAdoptFlag = atoi( getenv(SP_FPC_Adaptation_Flag) );    //D9000001
        if( 1 == tmpFPCAdoptFlag )
        {
            CORBA::Long casLen = tmpStartCassette.length();
            for( CORBA::Long casCnt=0; casCnt<casLen; casCnt++ )
            {
                CORBA::Long lotLen = tmpStartCassette[casCnt].strLotInCassette.length();
                for( CORBA::Long lotCnt=0; lotCnt<lotLen; lotCnt++ )
                {
                    if( tmpStartCassette[casCnt].strLotInCassette[lotCnt].operationStartFlag == FALSE ) //PSIV00002149
                    {                                                                                   //PSIV00002149
                        PPT_METHODTRACE_V1("", "operationStartFlag == FALSE" );                         //PSIV00002149
                        continue;                                                                       //PSIV00002149
                    }                                                                                   //PSIV00002149
                    PPT_METHODTRACE_V2("", "Check lot's FPC definition.",
                                       tmpStartCassette[casCnt].strLotInCassette[lotCnt].lotID.identifier);
                    objLot_currentFPCInfo_Get_out strLot_currentFPCInfo_Get_out;
                    rc = lot_currentFPCInfo_Get( strLot_currentFPCInfo_Get_out, strObjCommonIn,
                                                 tmpStartCassette[casCnt].strLotInCassette[lotCnt].lotID,
                                                 equipmentID, FALSE, FALSE, FALSE, FALSE );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_currentFPCInfo_Get() != RC_OK", rc);
                        strOpeStartReqResult.strResult = strLot_currentFPCInfo_Get_out.strResult;
                        return( rc );
                    }

                    CORBA::Long fpcLen = strLot_currentFPCInfo_Get_out.strFPCInfoList.length();
                    if( fpcLen > 0 )
                    {
                        PPT_METHODTRACE_V2("", "This lot is influenced by FPC.", fpcLen);
                        PPT_SET_MSG_RC_KEY( strOpeStartReqResult,
                                            MSG_FPC_REQUIRE_START_RESERVE, RC_FPC_REQUIRE_START_RESERVE,
                                            tmpStartCassette[casCnt].strLotInCassette[lotCnt].lotID.identifier );
                        return RC_FPC_REQUIRE_START_RESERVE;
                    }
                }
            }
        }
//D8000024 add end
    }
    else
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) != 0");

        /*----------------------------------------------------*/
        /*   Clear Start Reserved Control Job in Equipment    */
        /*----------------------------------------------------*/
        saveControlJobID = controlJobID;
        objectIdentifier nullControlJobID;
        objEquipment_reservedControlJobID_Clear_out strEquipment_reservedControlJobID_Clear_out;
        rc = equipment_reservedControlJobID_Clear( strEquipment_reservedControlJobID_Clear_out, strObjCommonIn,
                                                   equipmentID, controlJobID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "equipment_reservedControlJobID_Clear() rc != RC_OK");
            strOpeStartReqResult.strResult = strEquipment_reservedControlJobID_Clear_out.strResult;
            return( rc );
        }

        //Q3000297 add start
        /*----------------------------------------------------*/
        /*   Update Start Reservation Info                    */
        /*                                                    */
        /*   - To update recipe parameters, this process is   */
        /*     required.                                      */
        /*----------------------------------------------------*/
//D9000003 delete start
//        objProcess_startReserveInformation_Set_out   strProcess_startReserveInformation_Set_out;
//        rc = process_startReserveInformation_Set( strProcess_startReserveInformation_Set_out,
//                                                  strObjCommonIn,
//                                                  equipmentID,
//                                                  portGroupID,
//                                                  controlJobID,
////D51M0000                                                  strStartCassette );
//                                                  tmpStartCassette );                   //D51M0000
//        if ( rc != RC_OK )
//        {
//            PPT_METHODTRACE_V1("", "process_startReserveInformation_Set() != RC_OK");
//            strOpeStartReqResult.strResult = strProcess_startReserveInformation_Set_out.strResult;
//            return( rc );
//        }
//D9000003 delete end
//D9000003 add start
        objProcess_startReserveInformation_Set_out__090 strProcess_startReserveInformation_Set_out__090;
        objProcess_startReserveInformation_Set_in__090 strProcess_startReserveInformation_Set_in__090;
        strProcess_startReserveInformation_Set_in__090.equipmentID = equipmentID;
        strProcess_startReserveInformation_Set_in__090.portGroupID = portGroupID;
        strProcess_startReserveInformation_Set_in__090.controlJobID = controlJobID;
        strProcess_startReserveInformation_Set_in__090.strStartCassette = tmpStartCassette;
        strProcess_startReserveInformation_Set_in__090.processJobPauseFlag = processJobPauseFlag;

        rc = process_startReserveInformation_Set__090( strProcess_startReserveInformation_Set_out__090, strObjCommonIn, strProcess_startReserveInformation_Set_in__090);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "process_startReserveInformation_Set__090() rc != RC_OK");
            strOpeStartReqResult.strResult = strProcess_startReserveInformation_Set_out__090.strResult;
            return( rc );
        }
//D9000003 add end

        //Q3000297 add end
    }

//D8000024 add start
    PPT_METHODTRACE_V1("","Now check whiteFlag.");
    objFPC_startCassette_processCondition_Check_out  strFPC_startCassette_processCondition_Check_out;
    rc = FPC_startCassette_processCondition_Check( strFPC_startCassette_processCondition_Check_out,
                                                   strObjCommonIn,
                                                   equipmentID,
                                                   tmpStartCassette,
                                                   FALSE,     // FPC category check
                                                   TRUE );    // FPC whiteFlag check
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","FPC_startCassette_processCondition_Check() != RC_OK", rc);
        strOpeStartReqResult.strResult = strFPC_startCassette_processCondition_Check_out.strResult;

        return rc;
    }
//D8000024 add end

//DSIV00000099 start
    /*----------------------------------------*/
    /*                                        */
    /*   Check Condition for SLM.             */
    /*                                        */
    /*----------------------------------------*/
    PPT_METHODTRACE_V1("","Check Condition for SLM.");
    objSLM_CheckConditionForOperation_out strSLM_CheckConditionForOperation_out;
    objSLM_CheckConditionForOperation_in  strSLM_CheckConditionForOperation_in;

    strSLM_CheckConditionForOperation_in.equipmentID = equipmentID;
    strSLM_CheckConditionForOperation_in.portGroupID = portGroupID;
    strSLM_CheckConditionForOperation_in.controlJobID = controlJobID;
    strSLM_CheckConditionForOperation_in.strStartCassette = strStartCassette;
    strSLM_CheckConditionForOperation_in.operation = CIMFWStrDup( SP_Operation_OpeStart );

    PPT_METHODTRACE_V1("", "call SLM_CheckConditionForOperation()");
    rc = SLM_CheckConditionForOperation( strSLM_CheckConditionForOperation_out,
                                         strObjCommonIn,
                                         strSLM_CheckConditionForOperation_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "SLM_CheckConditionForOperation() != RC_OK", rc);
        strOpeStartReqResult.strResult = strSLM_CheckConditionForOperation_out.strResult;
        return( rc );
    }
//DSIV00000099 end

//DSIV00001830 add start
    //-----------------------------------------------------------//
    //  Wafer Stacking Operation                                 //
    //    If Equipment Category is SP_Mc_Category_WaferBonding,  //
    //    update Bonding Group Information                       //
    //-----------------------------------------------------------//
    if ( 0 == CIMFWStrCmp( strEquipmentCategory, SP_Mc_Category_WaferBonding) )
    {
        PPT_METHODTRACE_V1("", "##### Equipment Category is  SP_Mc_Category_WaferBonding")

        objLot_bondingGroup_UpdateByOperation_out strLot_bondingGroup_UpdateByOperation_out;
        objLot_bondingGroup_UpdateByOperation_in strLot_bondingGroup_UpdateByOperation_in;
        strLot_bondingGroup_UpdateByOperation_in.equipmentID = equipmentID;
        strLot_bondingGroup_UpdateByOperation_in.controlJobID = controlJobID;
        strLot_bondingGroup_UpdateByOperation_in.strStartCassette = strStartCassette;
        if ( processJobPauseFlag )
        {
            strLot_bondingGroup_UpdateByOperation_in.operation = CIMFWStrDup( SP_Operation_OpeStartByWafer );
        }
        else
        {
            strLot_bondingGroup_UpdateByOperation_in.operation = CIMFWStrDup( SP_Operation_OpeStart );
        }

        PPT_METHODTRACE_V1("", "call lot_bondingGroup_UpdateByOperation()");
        rc = lot_bondingGroup_UpdateByOperation( strLot_bondingGroup_UpdateByOperation_out, strObjCommonIn, strLot_bondingGroup_UpdateByOperation_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "lot_bondingGroup_UpdateByOperation() != RC_OK", rc );
            strOpeStartReqResult.strResult = strLot_bondingGroup_UpdateByOperation_out.strResult;
            return (rc);
        }
    }
//DSIV00001830 add end

    /*------------------------------------------------------*/
    /*                                                      */
    /*     Equipment Related Information Update Procedure   */
    /*                                                      */
    /*------------------------------------------------------*/

    /*------------------------------------------------------*/
    /*   Add StartLot to EqpInfo's ProcessingLot Sequence   */
    /*------------------------------------------------------*/
    objEquipment_processingLot_Add_out strEquipment_processingLot_Add_out;
    rc = equipment_processingLot_Add( strEquipment_processingLot_Add_out, strObjCommonIn,
//D51M0000                                      equipmentID, saveControlJobID, strStartCassette );
                                      equipmentID, saveControlJobID, tmpStartCassette );            //D51M0000
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "equipment_processingLot_Add() rc != RC_OK");
        strOpeStartReqResult.strResult = strEquipment_processingLot_Add_out.strResult;
        return( rc );
    }

//DSN000081739 Add Start
    if ( 1 == eqpMonitorSwitch )
    {
        PPT_METHODTRACE_V1("", "1 == SP_EQPMONITOR_SWITCH");
        CORBA::Boolean getEqpStateAtStart = TRUE;
        objectIdentifier eqpStateAtStart;
        objectIdentifier chamberID;
        CORBA::Boolean eqpStatusChg = TRUE;
        CORBA::ULong castLen = tmpStartCassette.length();
        for ( i=0; i<castLen; i++ )
        {
            PPT_METHODTRACE_V2("", "loop to castLen", i);
            CORBA::ULong lotLen = tmpStartCassette[i].strLotInCassette.length();
            for ( CORBA::ULong j=0; j<lotLen; j++ )
            {
                PPT_METHODTRACE_V2("", "loop to lotLen", j);
                /*---------------------------*/
                /*   Omit Not-OpeStart Lot   */
                /*---------------------------*/
                if ( FALSE == tmpStartCassette[i].strLotInCassette[j].operationStartFlag )
                {
                    PPT_METHODTRACE_V1("", "tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE, continue");
                    continue;
                }

                if ( 0 != CIMFWStrCmp(tmpStartCassette[i].strLotInCassette[j].lotType, SP_Lot_Type_EquipmentMonitorLot)
                  && 0 != CIMFWStrCmp(tmpStartCassette[i].strLotInCassette[j].lotType, SP_Lot_Type_DummyLot) )
                {
                    PPT_METHODTRACE_V1("", "tmpStartCassette[i].strLotInCassette[j].lotType is not Equipment Monitor and Dummy, continue");
                    continue;
                }

                objLot_eqpMonitorSectionInfo_GetForJob_out strLot_eqpMonitorSectionInfo_GetForJob_out;
                objLot_eqpMonitorSectionInfo_GetForJob_in  strLot_eqpMonitorSectionInfo_GetForJob_in;
                strLot_eqpMonitorSectionInfo_GetForJob_in.lotID  = tmpStartCassette[i].strLotInCassette[j].lotID;
                rc = lot_eqpMonitorSectionInfo_GetForJob( strLot_eqpMonitorSectionInfo_GetForJob_out,
                                                          strObjCommonIn,
                                                          strLot_eqpMonitorSectionInfo_GetForJob_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_eqpMonitorSectionInfo_GetForJob() != RC_OK", rc);
                    strOpeStartReqResult.strResult = strLot_eqpMonitorSectionInfo_GetForJob_out.strResult;
                    return rc;
                }

                if ( 0 < CIMFWStrLen( strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier ) )
                {
                    PPT_METHODTRACE_V1("", "0 < CIMFWStrLen( strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier )");
                    if( 0 == CIMFWStrCmp(strLot_eqpMonitorSectionInfo_GetForJob_out.operationLabel, SP_EqpMonitor_OpeLabel_Monitor) )
                    {
                        PPT_METHODTRACE_V1("", "strLot_eqpMonitorSectionInfo_GetForJob_out.operationLabel is Monitor");
                        //Get EqpMonitorJob Information
                        objEqpMonitorJob_info_Get_out strEqpMonitorJob_info_Get_out;
                        objEqpMonitorJob_info_Get_in  strEqpMonitorJob_info_Get_in;
                        strEqpMonitorJob_info_Get_in.eqpMonitorID    = strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID;
                        strEqpMonitorJob_info_Get_in.eqpMonitorJobID = strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID;
                        rc = eqpMonitorJob_info_Get( strEqpMonitorJob_info_Get_out,
                                                     strObjCommonIn,
                                                     strEqpMonitorJob_info_Get_in );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "eqpMonitorJob_info_Get() != RC_OK", rc);
                            strOpeStartReqResult.strResult = strEqpMonitorJob_info_Get_out.strResult;
                            return rc;
                        }

                        CORBA::Boolean eqpMonitorJobStatusChg = TRUE;
                        if ( 0 != CIMFWStrCmp(strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].monitorJobStatus, SP_EqpMonitorJob_Status_Ready) )
                        {
                            PPT_METHODTRACE_V1("", "strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].monitorJobStatus is not Ready");
                            eqpStatusChg = FALSE;
                            eqpMonitorJobStatusChg = FALSE;
                        }

                        if ( TRUE == eqpStatusChg )
                        {
                            PPT_METHODTRACE_V1("", "TRUE == eqpStatusChg");
                            if ( 0 < CIMFWStrLen( strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID.identifier ) && TRUE == getEqpStateAtStart )
                            {
                                PPT_METHODTRACE_V1("", "0 < CIMFWStrLen(strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID.identifier) && TRUE==getEqpStateAtStart");
                                //Get EqpMonitor information
                                objEqpMonitor_info_Get_out strEqpMonitor_info_Get_out;
                                objEqpMonitor_info_Get_in  strEqpMonitor_info_Get_in;
                                strEqpMonitor_info_Get_in.eqpMonitorID = strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorID;
                                rc = eqpMonitor_info_Get( strEqpMonitor_info_Get_out,
                                                          strObjCommonIn,
                                                          strEqpMonitor_info_Get_in );
                                if ( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V2("", "eqpMonitor_info_Get() != RC_OK", rc);
                                    strOpeStartReqResult.strResult = strEqpMonitor_info_Get_out.strResult;
                                    return rc;
                                }

                                if ( 0 < CIMFWStrLen( strEqpMonitor_info_Get_out.strEqpMonitorDetailInfos[0].eqpStateAtStart.equipmentStatusCode.identifier ) )
                                {
                                    PPT_METHODTRACE_V1("", "0 < CIMFWStrLen(strEqpMonitor_info_Get_out.strEqpMonitorDetailInfos[0].eqpStateAtStart.equipmentStatusCode.identifier)");
                                    eqpStateAtStart = strEqpMonitor_info_Get_out.strEqpMonitorDetailInfos[0].eqpStateAtStart.equipmentStatusCode;
                                    chamberID       = strEqpMonitor_info_Get_out.strEqpMonitorDetailInfos[0].chamberID;
                                    getEqpStateAtStart = FALSE;
                                }
                            }
                        }

                        if ( TRUE == eqpMonitorJobStatusChg )
                        {
                            PPT_METHODTRACE_V1("", "TRUE == eqpMonitorJobStatusChg");
                            //Status of EqpMonitor job is updated to "Executing"
                            pptEqpMonitorJobStatusChangeRptResult strEqpMonitorJobStatusChangeRptResult;
                            pptEqpMonitorJobStatusChangeRptInParm strEqpMonitorJobStatusChangeRptInParm;
                            strEqpMonitorJobStatusChangeRptInParm.equipmentID      = strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].equipmentID;
                            strEqpMonitorJobStatusChangeRptInParm.eqpMonitorID     = strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].eqpMonitorID;
                            strEqpMonitorJobStatusChangeRptInParm.eqpMonitorJobID  = strEqpMonitorJob_info_Get_out.strEqpMonitorJobInfoSeq[0].eqpMonitorJobID;
                            strEqpMonitorJobStatusChangeRptInParm.monitorJobStatus = CIMFWStrDup(SP_EqpMonitorJob_Status_Executing);
                            rc = txEqpMonitorJobStatusChangeRpt( strEqpMonitorJobStatusChangeRptResult,
                                                                 strObjCommonIn,
                                                                 strEqpMonitorJobStatusChangeRptInParm,
                                                                 claimMemo );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "txEqpMonitorJobStatusChangeRpt() != RC_OK", rc);
                                strOpeStartReqResult.strResult = strEqpMonitorJobStatusChangeRptResult.strResult;
                                return rc;
                            }
                        }
                    }

                    //Update information of EqpMonitor job lot
                    objEqpMonitorJob_lot_Update_out strEqpMonitorJob_lot_Update_out;
                    objEqpMonitorJob_lot_Update_in  strEqpMonitorJob_lot_Update_in;
                    strEqpMonitorJob_lot_Update_in.lotID     = tmpStartCassette[i].strLotInCassette[j].lotID;
                    strEqpMonitorJob_lot_Update_in.operation = CIMFWStrDup(SP_EqpMonitorJob_OpeCategory_OpeStart);
                    rc = eqpMonitorJob_lot_Update( strEqpMonitorJob_lot_Update_out,
                                                   strObjCommonIn,
                                                   strEqpMonitorJob_lot_Update_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "eqpMonitorJob_lot_Update() != RC_OK", rc);
                        strOpeStartReqResult.strResult = strEqpMonitorJob_lot_Update_out.strResult;
                        return rc;
                    }
                }
            }
        }

        if ( 0 < CIMFWStrLen( eqpStateAtStart.identifier ) )
        {
            PPT_METHODTRACE_V1("", "0 < CIMFWStrLen( eqpStateAtStart.identifier )");
            if ( 0 < CIMFWStrLen( chamberID.identifier ) )
            {
                //Update Chamber's Status
                PPT_METHODTRACE_V1("", "call txChamberStatusChangeReq");

                pptEqpChamberStatusSequence strEqpChamberStatus;
                strEqpChamberStatus.length(1);

                strEqpChamberStatus[0].chamberID         = chamberID;
                strEqpChamberStatus[0].chamberStatusCode = eqpStateAtStart;

                //-------------------------------------------------------
                //   Call txChamberStatusChangeReq
                //-------------------------------------------------------
                pptChamberStatusChangeReqResult strChamberStatusChangeReqResult;
                rc = txChamberStatusChangeReq( strChamberStatusChangeReqResult,
                                               strObjCommonIn,
                                               equipmentID,
                                               strEqpChamberStatus,
                                               claimMemo );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "txChamberStatusChangeReq() != RC_OK", rc);
                    strOpeStartReqResult.strResult = strChamberStatusChangeReqResult.strResult;
                    return rc;
                }
            }
            else
            {
                //Update Eqp's Status
                PPT_METHODTRACE_V1("", "call txEqpStatusChangeReq");

                objectIdentifier statusCode;
                statusCode = eqpStateAtStart;

                //-------------------------------------------------------
                //   Call txEqpStatusChangeReq
                //-------------------------------------------------------
                pptEqpStatusChangeReqResult strEqpStatusChangeReqResult;
                rc = txEqpStatusChangeReq( strEqpStatusChangeReqResult,
                                           strObjCommonIn,
                                           equipmentID,
                                           statusCode,
                                           claimMemo );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "txEqpStatusChangeReq() != RC_OK", rc);
                    strOpeStartReqResult.strResult = strEqpStatusChangeReqResult.strResult;
                    return rc;
                }
            }
        }
    }
//DSN000081739 Add End

    /*---------------------------------------------*/
    /*   Maintain Eqp's Status for OFF-LINE Mode   */
    /*---------------------------------------------*/
    if ( CIMFWStrCmp( strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode, SP_Eqp_OnlineMode_Offline ) == 0 )
    {
        PPT_METHODTRACE_V1("", "onlineMode == SP_Eqp_OnlineMode_Offline");

        /*-----------------------------------------------*/
        /*   Change Equipment's Status to 'PRODUCTIVE'   */
        /*-----------------------------------------------*/

        /*===== get StateChageableFlag ===*/
        objEquipment_currentState_CheckToManufacturing_out strEquipment_currentState_CheckToManufacturing_out;
        strEquipment_currentState_CheckToManufacturing_out.ManufacturingStateChangeableFlag = FALSE; //P3000280
        rc = equipment_currentState_CheckToManufacturing( strEquipment_currentState_CheckToManufacturing_out, strObjCommonIn,
                                                          equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "equipment_currentState_GetManufacturing() rc != RC_OK");
            strOpeStartReqResult.strResult = strEquipment_currentState_CheckToManufacturing_out.strResult;
            return( rc );
        }

        if ( strEquipment_currentState_CheckToManufacturing_out.ManufacturingStateChangeableFlag == TRUE )
        {
            PPT_METHODTRACE_V1("", "ManufacturingStateChangeableFlag == TRUE");

            /*===== get Defaclt Status Code for Productive / Standby ===*/
            objEquipment_recoverState_GetManufacturing_out strEquipment_recoverState_GetManufacturing_out;
            rc = equipment_recoverState_GetManufacturing( strEquipment_recoverState_GetManufacturing_out, strObjCommonIn,
                                                          equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "equipment_recoverState_GetManufacturing() rc != RC_OK");
                strOpeStartReqResult.strResult = strEquipment_recoverState_GetManufacturing_out.strResult;
                return( rc );
            }

            /*---------------------------------*/
            /*   Call txEqpStatusChangeReq()   */
            /*---------------------------------*/
            pptEqpStatusChangeReqResult strEqpStatusChangeReqResult;
            rc = txEqpStatusChangeReq( strEqpStatusChangeReqResult, strObjCommonIn,
                                       equipmentID,
                                       strEquipment_recoverState_GetManufacturing_out.equipmentStatusCode,
                                       claimMemo );
            if ( rc != RC_OK && rc != RC_CURRSTATE_SAME )
            {
                PPT_METHODTRACE_V1("", "txEqpStatusChangeReq() rc != RC_OK");
                strOpeStartReqResult.strResult = strEqpStatusChangeReqResult.strResult;
                return( rc );
            }
        }
    }

    /*------------------------------------------*/
    /*   Update Equipment's Usage Information   */
    /*------------------------------------------*/
    objEquipment_usageCount_Increment_out strEquipment_usageCount_Increment_out;
    rc = equipment_usageCount_Increment( strEquipment_usageCount_Increment_out, strObjCommonIn,
//D51M0000                                         equipmentID, strStartCassette );
                                         equipmentID, tmpStartCassette );               //D51M0000
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "equipment_usageCount_Increment() rc != RC_OK");
        strOpeStartReqResult.strResult = strEquipment_usageCount_Increment_out.strResult;
        return( rc );
    }

    /*------------------------------------------------------*/
    /*                                                      */
    /*     FlowBatch Related Information Update Procedure   */
    /*                                                      */
    /*------------------------------------------------------*/

//D9000079    /*------------------------------------------*/
//D9000079    /*   Update FlowBatch Information           */
//D9000079    /*                                          */
//D9000079    /*   If equipment has reservedFlowBatchID,  */
//D9000079    /*   it is cleared. And Flowbatch's         */
//D9000079    /*   reservedEquipmentID is cleared, too.   */
//D9000079    /*------------------------------------------*/
//D9000079    objFlowBatch_Information_UpdateByOpeStart_out strFlowBatch_Information_UpdateByOpeStart_out;
//D9000079    rc = flowBatch_Information_UpdateByOpeStart( strFlowBatch_Information_UpdateByOpeStart_out, strObjCommonIn,
//D9000079                                                 equipmentID );
//D9000079    if ( rc != RC_OK )
//D9000079    {
//D9000079        PPT_METHODTRACE_V1("", "flowBatch_information_UpdateByOpeStart() rc != RC_OK");
//D9000079        strOpeStartReqResult.strResult = strFlowBatch_Information_UpdateByOpeStart_out.strResult;
//D9000079        return( rc );
//D9000079 add start
    //-----------------------------------------------------------
    //  Update Flow Batch Information
    //
    //  envValue SP_FLOWBATCH_CLEARED_BY_OPERSTART is "1"
    //     Equipment's researvedFlowBatchID is cleared.
    //     FlowBatch's reservedEquipmentID is also cleared.
    //  envValue SP_FLOWBATCH_CLEARED_BY_OPERSTART is "0".
    //     Nothing is cleared.
    //-----------------------------------------------------------
    if( 0 != CIMFWStrLen( strEquipment_lot_CheckFlowBatchConditionForOpeStart_out.flowBatchID.identifier ))
    {
        objFlowBatch_Information_UpdateByOpeStart_out__090 strFlowBatch_Information_UpdateByOpeStart_out;
        objFlowBatch_Information_UpdateByOpeStart_in__090  strFlowBatch_Information_UpdateByOpeStart_in;
        strFlowBatch_Information_UpdateByOpeStart_in.equipmentID = equipmentID;
        strFlowBatch_Information_UpdateByOpeStart_in.flowBatchID = strEquipment_lot_CheckFlowBatchConditionForOpeStart_out.flowBatchID;
        rc = flowBatch_Information_UpdateByOpeStart__090( strFlowBatch_Information_UpdateByOpeStart_out,
                                                          strObjCommonIn,
                                                          strFlowBatch_Information_UpdateByOpeStart_in);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "flowBatch_information_UpdateByOpeStart__090() rc != RC_OK");
            strOpeStartReqResult.strResult = strFlowBatch_Information_UpdateByOpeStart_out.strResult;
            return( rc );
        }
    }
//D9000079 add end
    /*-----------------------------------------------------*/
    /*                                                     */
    /*     Cassette Related Information Update Procedure   */
    /*                                                     */
    /*-----------------------------------------------------*/
//D51M0000    nILen = strStartCassette.length();
    nILen = tmpStartCassette.length();              //D51M0000
    PPT_METHODTRACE_V2("", "nILen", nILen);
    for ( i=0 ; i<nILen; i++ )
    {

        /*-----------------------------------------------*/
        /*   Change Cassette's Dispatch State to FALSE   */
        /*-----------------------------------------------*/
        PPT_METHODTRACE_V2("", "Change Cassette's Dispatch State to FALSE", i);

        objCassette_dispatchState_Change_out strCassette_dispatchState_Change_out;
        rc = cassette_dispatchState_Change( strCassette_dispatchState_Change_out, strObjCommonIn,
//D51M0000                                            strStartCassette[i].cassetteID, FALSE );
                                            tmpStartCassette[i].cassetteID, FALSE );                //D51M0000
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cassette_dispatchState_Change() rc != RC_OK", i);
            strOpeStartReqResult.strResult = strCassette_dispatchState_Change_out.strResult;
            return( rc );
        }

        /*------------------------------------------*/
        /*   Update Casssette's Usage Information   */
        /*------------------------------------------*/
        objCassette_usageCount_Increment_out strCassette_usageCount_Increment_out;
        rc = cassette_usageCount_Increment( strCassette_usageCount_Increment_out, strObjCommonIn,
//D51M0000                                            strStartCassette[i].cassetteID );
                                            tmpStartCassette[i].cassetteID );                       //D51M0000
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cassette_usageCount_Increment() rc != RC_OK", i);
            strOpeStartReqResult.strResult = strCassette_usageCount_Increment_out.strResult;
            return( rc );
        }
    }

    /*------------------------------------------------*/
    /*                                                */
    /*     Lot Related Information Update Procedure   */
    /*                                                */
    /*------------------------------------------------*/

//Q3000127 add start
    /*----------------------------------------------------------------*/
    /*   Make Monitor Relation for ProcessMonitorLot and ProcessLot   */
    /*----------------------------------------------------------------*/

    /*-----------------------------------*/
    /*   Get LotID's for Each Purpose    */
    /*-----------------------------------*/
    objOperationStartLot_lotCount_GetByLoadPurposeType_out strOperationStartLot_lotCount_GetByLoadPurposeType_out;
    rc = operationStartLot_lotCount_GetByLoadPurposeType( strOperationStartLot_lotCount_GetByLoadPurposeType_out, strObjCommonIn,
//D51M0000                                                          strStartCassette );
                                                          tmpStartCassette );                       //D51M0000
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "operationStartLot_lotCount_GetByLoadPurposeType() rc != RC_OK");
        strOpeStartReqResult.strResult = strOperationStartLot_lotCount_GetByLoadPurposeType_out.strResult;
        return( rc );
    }

    if ( CIMFWStrLen(strOperationStartLot_lotCount_GetByLoadPurposeType_out.processMonitorLotID.identifier) != 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(strOperationStartLot_lotCount_GetByLoadPurposeType_out.processMonitorLotID.identifier) != 0");

        /*------------------------*/
        /*    Prepare Structure   */
        /*------------------------*/
        CORBA::Long plCnt = strOperationStartLot_lotCount_GetByLoadPurposeType_out.processLotIDs.length();
        CORBA::Long savePlCnt = 0;    //PSIV00002138

        pptMonRelatedProdLotsSequence strMonRelatedProdLots(plCnt);
        strMonRelatedProdLots.length(plCnt);

        CORBA::Long i = 0;
        PPT_METHODTRACE_V2("", "plCnt", plCnt);

//PSIV00002138 add start
        //----------------------------------//
        //   Get Bonding Group Information  //
        //----------------------------------//
        pptBondingGroupInfoSequence strBondingGroupInfoSeq;
        strBondingGroupInfoSeq.length(0);
        CORBA::Long bndGrpLen = strBondingGroupInfoSeq.length();
        
        if ( 0 == CIMFWStrCmp( strEquipmentCategory, SP_Mc_Category_WaferBonding) )
        {
            PPT_METHODTRACE_V1("", "##### Equipment Category is  SP_Mc_Category_WaferBonding")
            objBondingGroup_infoByEqp_GetDR_out strBondingGroup_infoByEqp_GetDR_out;
            objBondingGroup_infoByEqp_GetDR_in strBondingGroup_infoByEqp_GetDR_in;
            strBondingGroup_infoByEqp_GetDR_in.equipmentID        = equipmentID;
            strBondingGroup_infoByEqp_GetDR_in.controlJobID       = saveControlJobID;
            strBondingGroup_infoByEqp_GetDR_in.bondingMapInfoFlag = TRUE;

            PPT_METHODTRACE_V1( "", "call bondingGroup_infoByEqp_GetDR()" );
            rc = bondingGroup_infoByEqp_GetDR( strBondingGroup_infoByEqp_GetDR_out, strObjCommonIn,
                                               strBondingGroup_infoByEqp_GetDR_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "", "bondingGroup_infoByEqp_GetDR() != RC_OK", rc );
                strOpeStartReqResult.strResult = strBondingGroup_infoByEqp_GetDR_out.strResult;
                return rc;
            }
            
            bndGrpLen = strBondingGroup_infoByEqp_GetDR_out.strBondingGroupInfoSeq.length();
            strBondingGroupInfoSeq.length(bndGrpLen);
            strBondingGroupInfoSeq = strBondingGroup_infoByEqp_GetDR_out.strBondingGroupInfoSeq;
        }
//PSIV00002138 add end
        for ( i=0 ; i<plCnt ; i++ )
        {
//PSIV00002138 add start
            /*------------------------------------------------*/
            /*    Check Top Lot existence for Monitor Group   */
            /*------------------------------------------------*/
            CORBA::Boolean bTopLot = FALSE;
            for ( CORBA::Long nGrpCnt = 0; nGrpCnt < bndGrpLen; nGrpCnt++ )
            {
                PPT_METHODTRACE_V2("", "nGrpCnt", nGrpCnt);
                CORBA::Long bndMapLen = strBondingGroupInfoSeq[nGrpCnt].strBondingMapInfoSequence.length();;
                for ( CORBA::Long nMapCnt = 0; nMapCnt < bndMapLen; nMapCnt++ )
                {
                    PPT_METHODTRACE_V2("", "nMapCnt", nMapCnt);
                    if ( 0 == CIMFWStrCmp( strOperationStartLot_lotCount_GetByLoadPurposeType_out.processLotIDs[i].identifier,
                                           strBondingGroupInfoSeq[nGrpCnt].strBondingMapInfoSequence[nMapCnt].planTopLotID.identifier ) )
                    {
                        // Top Lot should NOT be included in Monitor Group
                        PPT_METHODTRACE_V1("", "Top Lot Found! Omit this lot from Monitor Group candidates.");
                        bTopLot = TRUE;
                        break;
                    }
                }
                if ( bTopLot )
                {
                    break;
                }
            }
            if ( bTopLot )
            {
                continue;
            }
//PSIV00002138 add end
//PSIV00002138            strMonRelatedProdLots[i].productLotID = strOperationStartLot_lotCount_GetByLoadPurposeType_out.processLotIDs[i];
            PPT_METHODTRACE_V2("", "Set Product Lot. savePlCnt", savePlCnt);                                                                             //PSIV00002138
            strMonRelatedProdLots[savePlCnt].productLotID = strOperationStartLot_lotCount_GetByLoadPurposeType_out.processLotIDs[i];    //PSIV00002138
            savePlCnt++;                                                                                                                //PSIV00002138
        }
        PPT_METHODTRACE_V2("", "savePlCnt", savePlCnt);    //PSIV00002138
        strMonRelatedProdLots.length( savePlCnt );         //PSIV00002138

        /*----------------------------------------------*/
        /*    Call txMakeRelationMonitorProdLotsReq()   */
        /*----------------------------------------------*/
        pptMakeRelationMonitorProdLotsReqResult strMakeRelationMonitorProdLotsReqResult;
        rc = txMakeRelationMonitorProdLotsReq( strMakeRelationMonitorProdLotsReqResult, strObjCommonIn,
                                               strOperationStartLot_lotCount_GetByLoadPurposeType_out.processMonitorLotID,
                                               strMonRelatedProdLots );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "txMakeRelationMonitorProdLotsReq() rc != RC_OK");
            strOpeStartReqResult.strResult = strMakeRelationMonitorProdLotsReqResult.strResult;
            return( rc );
        }
    }
//Q3000127 add end

    /*--------------------------------------------*/
    /*   Change Lot Process State to Processing   */
    /*--------------------------------------------*/
    objLot_processState_MakeProcessing_out strLot_processState_MakeProcessing_out;
    rc = lot_processState_MakeProcessing( strLot_processState_MakeProcessing_out, strObjCommonIn,
//D51M0000                                          strStartCassette );
                                          tmpStartCassette );               //D51M0000
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_processState_MakeProcessing() rc != RC_OK");
        strOpeStartReqResult.strResult = strLot_processState_MakeProcessing_out.strResult;
        return( rc );
    }

    /*----------------------------*/
    /*   Stop Q-Time Management   */
    /*----------------------------*/
    objQtime_StopByOpeStart_out strQtime_StopByOpeStart_out;
    rc = qtime_StopByOpeStart( strQtime_StopByOpeStart_out, strObjCommonIn,
//D51M0000                               strStartCassette );
                               tmpStartCassette );                          //D51M0000
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "qtime_StopByOpeStart() rc != RC_OK");
        strOpeStartReqResult.strResult = strQtime_StopByOpeStart_out.strResult;
        return( rc );
    }

//Q3000127 move position    /*----------------------------------------------------------------*/
//Q3000127 move position    /*   Make Monitor Relation for ProcessMonitorLot and ProcessLot   */
//Q3000127 move position    /*----------------------------------------------------------------*/
//Q3000127 move position
//Q3000127 move position    /*-----------------------------------*/
//Q3000127 move position    /*   Get LotID's for Each Purpose    */
//Q3000127 move position    /*-----------------------------------*/
//Q3000127 move position    objOperationStartLot_lotCount_GetByLoadPurposeType_out strOperationStartLot_lotCount_GetByLoadPurposeType_out;
//Q3000127 move position    rc = operationStartLot_lotCount_GetByLoadPurposeType( strOperationStartLot_lotCount_GetByLoadPurposeType_out, strObjCommonIn,
//Q3000127 move position                                                          strStartCassette );
//Q3000127 move position    if ( rc != RC_OK )
//Q3000127 move position    {
//Q3000127 move position        PPT_METHODTRACE_V1("", "operationStartLot_lotCount_GetByLoadPurposeType() rc != RC_OK");
//Q3000127 move position        strOpeStartReqResult.strResult = strOperationStartLot_lotCount_GetByLoadPurposeType_out.strResult;
//Q3000127 move position        return( rc );
//Q3000127 move position    }
//Q3000127 move position
//Q3000127 move position    if ( CIMFWStrLen(strOperationStartLot_lotCount_GetByLoadPurposeType_out.processMonitorLotID.identifier) != 0 )
//Q3000127 move position    {
//Q3000127 move position        PPT_METHODTRACE_V1("", "CIMFWStrLen(strOperationStartLot_lotCount_GetByLoadPurposeType_out.processMonitorLotID.identifier) != 0");
//Q3000127 move position
//Q3000127 move position        /*------------------------*/
//Q3000127 move position        /*    Prepare Structure   */
//Q3000127 move position        /*------------------------*/
//Q3000127 move position        CORBA::Long plCnt = strOperationStartLot_lotCount_GetByLoadPurposeType_out.processLotIDs.length();
//Q3000127 move position
//Q3000127 move position        pptMonRelatedProdLotsSequence strMonRelatedProdLots(plCnt);
//Q3000127 move position        strMonRelatedProdLots.length(plCnt);
//Q3000127 move position
//Q3000127 move position       CORBA::Long i = 0;
//Q3000127 move position        PPT_METHODTRACE_V2("", "plCnt", plCnt);
//Q3000127 move position        for ( i=0 ; i<plCnt ; i++ )
//Q3000127 move position        {
//Q3000127 move position            strMonRelatedProdLots[i].productLotID = strOperationStartLot_lotCount_GetByLoadPurposeType_out.processLotIDs[i];
//Q3000127 move position        }
//Q3000127 move position
//Q3000127 move position        /*----------------------------------------------*/
//Q3000127 move position        /*    Call txMakeRelationMonitorProdLotsReq()   */
//Q3000127 move position        /*----------------------------------------------*/
//Q3000127 move position        pptMakeRelationMonitorProdLotsReqResult strMakeRelationMonitorProdLotsReqResult;
//Q3000127 move position        rc = txMakeRelationMonitorProdLotsReq( strMakeRelationMonitorProdLotsReqResult, strObjCommonIn,
//Q3000127 move position                                               strOperationStartLot_lotCount_GetByLoadPurposeType_out.processMonitorLotID,
//Q3000127 move position                                               strMonRelatedProdLots );
//Q3000127 move position        if ( rc != RC_OK )
//Q3000127 move position        {
//Q3000127 move position            PPT_METHODTRACE_V1("", "txMakeRelationMonitorProdLotsReq() rc != RC_OK");
//Q3000127 move position            strOpeStartReqResult.strResult = strMakeRelationMonitorProdLotsReqResult.strResult;
//Q3000127 move position            return( rc );
//Q3000127 move position        }
//Q3000127 move position    }

    /*------------------------------------------------------------*/
    /*                                                            */
    /*   Reticle / Fixture Related Information Update Procedure   */
    /*                                                            */
    /*------------------------------------------------------------*/
    if ( saveRC == RC_EQP_PROCDRBL_RTCL_REQD ||
         saveRC == RC_EQP_PROCDRBL_FIXT_REQD )
    {
        PPT_METHODTRACE_V1("", "saveRC == RC_EQP_PROCDRBL_RTCL_REQD || saveRC == RC_EQP_PROCDRBL_FIXT_REQD");

        CORBA::Long i = 0;
//D51M0000        CORBA::Long nILen = strStartCassette.length();
        CORBA::Long nILen = tmpStartCassette.length();                  //D51M0000
        PPT_METHODTRACE_V2("", "nILen", nILen);
        for ( i=0; i<nILen; i++ )
        {

//D51M0000            if (CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette ) == 0)
            if (CIMFWStrCmp(tmpStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette ) == 0)               //D51M0000
            {
                continue;
            }

            CORBA::Long j = 0;
//D51M0000            CORBA::Long nJLen = strStartCassette[i].strLotInCassette.length();
            CORBA::Long nJLen = tmpStartCassette[i].strLotInCassette.length();                                          //D51M0000
            PPT_METHODTRACE_V3("", "nJLen", nJLen, i);
            for ( j=0; j<nJLen; j++ )
            {

//D51M0000                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                if ( tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )                              //D51M0000
                {
                    continue;
                }

                if ( saveRC == RC_EQP_PROCDRBL_RTCL_REQD )
                {
                    PPT_METHODTRACE_V3("", "saveRC == RC_EQP_PROCDRBL_RTCL_REQD", i, j);

                    /*--------------------------------------*/
                    /*   Update Reticle Usage Information   */
                    /*--------------------------------------*/
                    CORBA::Long k = 0;
                    //INN-R170003
                    CORBA::Long lngWfrCnt = tmpStartCassette[i].strLotInCassette[j].strLotWafer.length();
                    //D51M0000                    CORBA::Long nKLen = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle.length();
                    CORBA::Long nKLen = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle.length();    //D51M0000
                    PPT_METHODTRACE_V4("", "nKLen", nKLen, i, j);
                    for (k = 0; k<nKLen; k++)
                    {
                    //INN-R170003 Start
                        //objReticle_UsageCount_Increment_out strReticle_UsageCount_Increment_out;
                        //rc = reticle_UsageCount_Increment(strReticle_UsageCount_Increment_out, strObjCommonIn,
                        //    //D51M0000                                                           strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID );
                        //    tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID);   //D51M0000
                        //if (rc != RC_OK)
                        //{
                        //    PPT_METHODTRACE_V1("", "reticle_UsageCount_Increment() rc != RC_OK");
                        //    strOpeStartReqResult.strResult = strReticle_UsageCount_Increment_out.strResult;
                        //    return(rc);
                        //}
                        csObjReticle_WaferCount_Increment_out      strReticle_WaferCount_Increment_out;
                        csObjReticle_WaferCount_Increment_in       strReticle_WaferCount_Increment_in;
                        strReticle_WaferCount_Increment_in.waferCount = lngWfrCnt;
                        strReticle_WaferCount_Increment_in.reticleID = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID;
                        PPT_METHODTRACE_V2("", "cs_txOpeStartReqOR start cs_reticle_WaferCount_Increment----------------->",strReticle_WaferCount_Increment_in.reticleID.identifier);
                        rc = cs_reticle_WaferCount_Increment(strReticle_WaferCount_Increment_out, strObjCommonIn, strReticle_WaferCount_Increment_in);
                        if (rc != RC_OK)
                        {
                            PPT_METHODTRACE_V1("", "cs_reticle_WaferCount_Increment() != RC_OK ");
                            strOpeStartReqResult.strResult = strReticle_WaferCount_Increment_out.strResult;
                            return rc;
                        }
                    //INN-R170003 End

                    }
                }
                else
                {
                    PPT_METHODTRACE_V3("", "saveRC != RC_EQP_PROCDRBL_RTCL_REQD", i, j);

                    /*--------------------------------------*/
                    /*   Update Fixture Usage Information   */
                    /*--------------------------------------*/
                    CORBA::Long k = 0;
//D51M0000                    CORBA::Long nKLen = strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture.length();
                    CORBA::Long nKLen = tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture.length();            //D51M0000
                    PPT_METHODTRACE_V4("", "nKLen", nKLen, i, j);
                    for ( k=0; k<nKLen; k++ )
                    {
                        objFixture_UsageCount_Increment_out strFixture_UsageCount_Increment_out;
                        rc = fixture_UsageCount_Increment( strFixture_UsageCount_Increment_out, strObjCommonIn,
//D51M0000                                                           strStartCassette[i].strLotInCassette[j].lotID,
                                                           tmpStartCassette[i].strLotInCassette[j].lotID,                           //D51M0000
//D51M0000                                                           strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture[k].fixtureID );
                                                           tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture[k].fixtureID );   //D51M0000
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "fixture_UsageCount_Increment() rc != RC_OK");
                            strOpeStartReqResult.strResult = strFixture_UsageCount_Increment_out.strResult;
                            return( rc );
                        }
                    }
                }
            }
        }
    }

    /*---------------------------------*/
    /*                                 */
    /*    CP Test Function Procedure   */
    /*                                 */
    /*---------------------------------*/
//D51M0000    nILen = strStartCassette.length();
    nILen = tmpStartCassette.length();              //D51M0000
    PPT_METHODTRACE_V2("", "nILen", nILen);
    for ( i=0; i<nILen; i++ )
    {

        /*-------------------------*/
        /*   Omit Empty Cassette   */
        /*-------------------------*/
//D51M0000        if (CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
        if (CIMFWStrCmp(tmpStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)            //D51M0000
        {
            continue;
        }

        CORBA::Long j = 0;
//D51M0000        CORBA::Long nJLen = strStartCassette[i].strLotInCassette.length();
        CORBA::Long nJLen = tmpStartCassette[i].strLotInCassette.length();                  //D51M0000
        PPT_METHODTRACE_V3("", "nJLen", nJLen, i);
        for ( j=0; j<nJLen; j++ )
        {

            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
//D51M0000            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            if ( tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )      //D51M0000
            {
                continue;
            }

            /*-----------------------------------------*/
            /*   Check Test Type of Current Process    */
            /*-----------------------------------------*/
            objLot_testTypeID_Get_out strLot_testTypeID_Get_out;
            rc = lot_testTypeID_Get( strLot_testTypeID_Get_out, strObjCommonIn,
//D51M0000                                     strStartCassette[i].strLotInCassette[j].lotID );
                                     tmpStartCassette[i].strLotInCassette[j].lotID );       //D51M0000
            if ( rc != RC_OK && rc != RC_NOT_FOUND_TESTTYPE )
            {
                PPT_METHODTRACE_V1("", "lot_testTypeID_Get() rc != RC_OK");
                strOpeStartReqResult.strResult = strLot_testTypeID_Get_out.strResult;
                return( rc );
            }

            if (CIMFWStrLen(strLot_testTypeID_Get_out.testTypeID.identifier) != 0)
            {
                PPT_METHODTRACE_V3("", "CIMFWStrLen(strLot_testTypeID_Get_out.testTypeID.identifier) != 0", i, j);

                /*------------------------------------------*/
                /*   Update binReportCount of Bin Summary   */
                /*------------------------------------------*/
                objBinSummary_binRptCount_SetDR_out strBinSummary_binRptCount_SetDR_out;
                rc = binSummary_binRptCount_SetDR( strBinSummary_binRptCount_SetDR_out, strObjCommonIn,
//D51M0000                                                   strStartCassette[i].strLotInCassette[j].lotID,
                                                   tmpStartCassette[i].strLotInCassette[j].lotID,           //D51M0000
                                                   strLot_testTypeID_Get_out.testTypeID.identifier,
                                                   "1" );
                if ( rc != RC_OK && rc != RC_NOT_FOUND_BINSUM )
                {
                    PPT_METHODTRACE_V1("", "binSummary_binRptCount_SetDR() rc != RC_OK");
                    strOpeStartReqResult.strResult = strBinSummary_binRptCount_SetDR_out.strResult;
                    return( rc );
                }
            }
        }
    }

    /*--------------------------*/
    /*                          */
    /*   Event Make Procedure   */
    /*                          */
    /*--------------------------*/
//D51M0000    nILen = strStartCassette.length();
    nILen = tmpStartCassette.length();              //D51M0000
    PPT_METHODTRACE_V2("", "nILen", nILen);
    for ( i=0; i<nILen; i++ )
    {

        /*-------------------------*/
        /*   Omit Empty Cassette   */
        /*-------------------------*/
//D51M0000        if (CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
        if (CIMFWStrCmp(tmpStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)            //D51M0000
        {
            continue;
        }

        CORBA::Long j = 0;
//D51M0000        CORBA::Long nJLen = strStartCassette[i].strLotInCassette.length();
        CORBA::Long nJLen = tmpStartCassette[i].strLotInCassette.length();                                      //D51M0000
        PPT_METHODTRACE_V3("", "nJLen", nJLen, i);
        for ( j=0; j<nJLen; j++ )
        {
            /*---------------------------*/
            /*   Omit Not-OpeStart Lot   */
            /*---------------------------*/
            PPT_METHODTRACE_V3("", "Omit Not-OpeStart Lot", i, j);

//D51M0000            if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
            if ( tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )                          //D51M0000
            {
                continue;
            }

            /*--------------------------------------------------------------*/
            /*   Make OperationMoveEvent for Operation History - OpeStart   */
            /*--------------------------------------------------------------*/
            objLotOperationMoveEvent_MakeOpeStart_out strLotOperationMoveEvent_MakeOpeStart_out;
            rc = lotOperationMoveEvent_MakeOpeStart( strLotOperationMoveEvent_MakeOpeStart_out, strObjCommonIn,
                                                     "TXTRC002",
                                                     equipmentID,
                                                     strPortResource_currentOperationMode_Get_out.strOperationMode.operationMode.identifier,
                                                     saveControlJobID,
//D51M0000                                                     strStartCassette[i].cassetteID,
                                                     tmpStartCassette[i].cassetteID,                            //D51M0000
//D51M0000                                                     strStartCassette[i].strLotInCassette[j],
                                                     tmpStartCassette[i].strLotInCassette[j],                   //D51M0000
                                                     claimMemo );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lotOperationMoveEvent_MakeOpeStart() rc != RC_OK");
                strOpeStartReqResult.strResult = strLotOperationMoveEvent_MakeOpeStart_out.strResult;
                return( rc );
            }
        }
    }

//D5100232 start
    /*------------------------------------------------------------------------*/
    /*                                                                        */
    /*   Send OpeComp Report to DCS Procedure                                 */
    /*                                                                        */
    /*------------------------------------------------------------------------*/
    CORBA::Boolean bDCSAvailable = FALSE;
    CORBA::String_var DCSAvailable = CIMFWStrDup(getenv(SP_DCS_Available));
    PPT_METHODTRACE_V2("", "DCSAvailable", DCSAvailable);
    if (CIMFWStrCmp(DCSAvailable, "1") == 0 )
    {
        PPT_METHODTRACE_V1("", "DCS Interface Available");
        bDCSAvailable = TRUE;
    }

//DSN000102497 add start
    CORBA::Long DCSReport = atoi( getenv(SP_DCS_REPORT) );
    PPT_METHODTRACE_V2("","DCSReport", DCSReport);
//DSN000102497 add end

    if ( 0 != CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode, SP_Eqp_OnlineMode_Offline)
      && TRUE == bDCSAvailable && 0 == DCSReport ) //DSN000102497
//DSN000102497      && TRUE == bDCSAvailable )
    {
        PPT_METHODTRACE_V1("", "Send OpeComp Report to DCS");

        CORBA::String_var IgnoreErr = CIMFWStrDup(getenv(SP_DCS_Ignore_OpeStart_Result));
        PPT_METHODTRACE_V2("", "SP_DCS_IGNORE_OPESTART_RESULT", IgnoreErr);

        DCSControlJobInfo controlJobInfo;
        controlJobInfo.equipmentID = equipmentID;
        controlJobInfo.portGroupID = portGroupID;
        controlJobInfo.controlJobID = saveControlJobID;
//D51M0000        controlJobInfo.strStartCassette = strStartCassette;
        controlJobInfo.strStartCassette = tmpStartCassette;             //D51M0000

        objDCSMgr_SendOperationStartRpt_out strDCSMgr_SendOperationStartRpt_out;
        rc = DCSMgr_SendOperationStartRpt( strDCSMgr_SendOperationStartRpt_out, strObjCommonIn, controlJobInfo );

        if ( rc != RC_OK && 0 != CIMFWStrCmp(IgnoreErr, "1") )
        {
            PPT_METHODTRACE_V2("", "##### DCSMgr_SendOperationStartRpt() != RC_OK", rc);
            strOpeStartReqResult.strResult = strDCSMgr_SendOperationStartRpt_out.strResult;
            return( rc );
        }
//D7000228 add start
        else if ( rc == RC_OK )
        {
            //Set CJ to DCSIFControlStatus
            PPT_METHODTRACE_V1("","DCS interface is successful.");
            CORBA::String_var tmpStringForDCS = DCSIFControlStatus;
            DCSIFControlStatus                = CIMFWStrDup(controlJobInfo.controlJobID.identifier);
        }
//D7000228 add end
    }
//D5100232 end

    /*------------------------------------------------------------------------*/
    /*                                                                        */
    /*   Send OpeStart Request to TCS Procedure                               */
    /*                                                                        */
    /*   - If specified portGroup's startMode is Auto, OpeStartReq itself is  */
    /*     come from TCS, so OpeStartReq sending procedure is required for    */
    /*     startMode=Manu case only.                                          */
    /*                                                                        */
    /*------------------------------------------------------------------------*/
    if (CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.operationStartMode, SP_Eqp_StartMode_Manual) == 0)
    {
//D4000060        PPT_METHODTRACE_V1("", "operationStartMode == SP_Eqp_StartMode_Manual");
//D4000060
//D4000060        /*--------------------------*/
//D4000060        /*    Send Request to TCS   */
//D4000060        /*--------------------------*/
//D4000060         objTCSMgr_SendOpeStartReq_out strTCSMgr_SendOpeStartReq_out;
//D4000060         rc = TCSMgr_SendOpeStartReq( strTCSMgr_SendOpeStartReq_out, strObjCommonIn,
//D4000060                                      strObjCommonIn.strUser,
//D4000060                                      equipmentID,
//D4000060                                      portGroupID,
//D4000060                                      saveControlJobID,
//D4000060                                      strStartCassette,
//D4000060                                      claimMemo );
//D4000060         if ( rc != RC_OK )
//D4000060         {
//D4000060             PPT_METHODTRACE_V1("", "TCSMgr_SendOpeStartReq() rc != RC_OK");
//D4000060             strOpeStartReqResult.strResult = strTCSMgr_SendOpeStartReq_out.strResult;
//D4000060             return( rc );
//D4000060         }
//D4000060 add start
//D4100134     CORBA::String_var tmpSleepTimeValue = theSP_BIND_SLEEP_TIME_TCS;
//D4100134     CORBA::String_var tmpRetryCountValue = theSP_BIND_RETRY_COUNT_TCS;
        CORBA::String_var tmpSleepTimeValue  = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));  //D4100134
        CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS)); //D4100134
        CORBA::Long sleepTimeValue;
        CORBA::Long retryCountValue;

        if (CIMFWStrLen(tmpSleepTimeValue) == 0)
        {
            sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
        }
        else
        {
//D9000001         sleepTimeValue = atol(tmpSleepTimeValue) ;
            sleepTimeValue = atoi(tmpSleepTimeValue) ;    //D9000001
        }

        if (CIMFWStrLen(tmpRetryCountValue) == 0)
        {
            retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
        }
        else
        {
//D9000001         retryCountValue = atol(tmpRetryCountValue);
            retryCountValue = atoi(tmpRetryCountValue);    //D9000001
        }

        PPT_METHODTRACE_V2("","env value of SP_BIND_SLEEP_TIME_TCS  = ",sleepTimeValue);
        PPT_METHODTRACE_V2("","env value of SP_BIND_RETRY_COUNT_TCS = ",retryCountValue);

        objTCSMgr_SendOpeStartReq_out strTCSMgr_SendOpeStartReq_out;

        //'retryCountValue + 1' means first try plus retry count
        for(CORBA::Long i = 0 ; i < (retryCountValue + 1) ; i++)
        {
            /*--------------------------*/
            /*    Send Request to TCS   */
            /*--------------------------*/
            rc = TCSMgr_SendOpeStartReq( strTCSMgr_SendOpeStartReq_out, strObjCommonIn,
                                         strObjCommonIn.strUser,
                                         equipmentID,
                                         portGroupID,
                                         saveControlJobID,
//D51M0000                                      strStartCassette,
                                         tmpStartCassette,     //D51M0000
                                         processJobPauseFlag,  //D5000001
                                         claimMemo );

            PPT_METHODTRACE_V2("","rc = ",rc);

            if (rc == RC_OK)
            {
                PPT_METHODTRACE_V1("","Now TCS subSystem is alive!! Go ahead");
                break;
            }
            else if ( rc == RC_EXT_SERVER_BIND_FAIL ||
                      rc == RC_EXT_SERVER_NIL_OBJ   ||
                      rc == RC_TCS_NO_RESPONSE )
            {
                PPT_METHODTRACE_V2("","TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...",i);
                PPT_METHODTRACE_V2("","now sleeping... ",sleepTimeValue);
                sleep(sleepTimeValue);
                continue;
            }
            else
            {
                PPT_METHODTRACE_V1("", "TCSMgr_SendOpeStartReq() rc != RC_OK");
                strOpeStartReqResult.strResult = strTCSMgr_SendOpeStartReq_out.strResult;
                return( rc );
            }

        }

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "TCSMgr_SendOpeStartReq() rc != RC_OK");
            strOpeStartReqResult.strResult = strTCSMgr_SendOpeStartReq_out.strResult;
            return( rc );
        }
//D4000060 add end
    }

//D51M0000 add start
    /*----------------------------------------*/
    /*   call controlJob_status_Change        */
    /*----------------------------------------*/
    PPT_METHODTRACE_V1("", "call controlJob_status_Change");
//D7000006    objControlJob_status_Change_out strControlJob_status_Change_out;
//D7000006    rc = controlJob_status_Change(strControlJob_status_Change_out,
//D7000006                                  strObjCommonIn,
//D7000006                                  saveControlJobID,
//D7000006                                  SP_APC_ControlJobStatus_Executing);
//D7000006    if( rc != RC_OK )
//D7000006    {
//D7000006        PPT_METHODTRACE_V1("", "controlJob_status_Change() != RC_OK");
//D7000006        strOpeStartReqResult.strResult = strControlJob_status_Change_out.strResult;
//D7000006        return( rc );
//D7000006    }
    //D7000006 Add Start
    pptControlJobManageReqResult strControlJobManageReqResult;
    pptControlJobCreateRequest   dummyControlJobCreateRequest;
    rc = txControlJobManageReq( strControlJobManageReqResult,
                                strObjCommonIn,
                                saveControlJobID,
                                SP_ControlJobAction_Type_queue,
                                dummyControlJobCreateRequest,
                                claimMemo );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "txControlJobManageReq() != RC_OK");
        strOpeStartReqResult.strResult = strControlJobManageReqResult.strResult;
        return( rc );
    }
    //D7000006 Add End

//strAPCRunTimeCapabilityInqResult is not initialized when sendTxFlag == FALSE.
//Be careful not to use strAPCRunTimeCapabilityInqResult when sendTxFlag == FALSE.
    if( sendTxFlag == TRUE )
    {
        PPT_METHODTRACE_V2("", "sendTxFlag == TRUE", sendTxFlag);
        /*---------------------------------------------------*/
        /*   call APCRuntimeCapability_RegistDR              */
        /*---------------------------------------------------*/
        PPT_METHODTRACE_V1("", "call APCRuntimeCapability_RegistDR");
        objAPCRuntimeCapability_RegistDR_out strAPCRuntimeCapability_RegistDR_out;
        rc = APCRuntimeCapability_RegistDR(  strAPCRuntimeCapability_RegistDR_out,
                                             strObjCommonIn,
                                             saveControlJobID,
                                             strAPCRunTimeCapabilityInqResult.strAPCRunTimeCapabilityResponse);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "APCRuntimeCapability_RegistDR() != RC_OK");
            strOpeStartReqResult.strResult = strAPCRuntimeCapability_RegistDR_out.strResult;
            return( rc );
        }
    }

    /*-------------------------------------------------*/
    /*   call cassette_APCInformation_GetDR            */
    /*-------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call cassette_APCInformation_GetDR");
    objCassette_APCInformation_GetDR_out strCassette_APCInformation_GetDR_out;
    rc = cassette_APCInformation_GetDR ( strCassette_APCInformation_GetDR_out,
                                      strObjCommonIn,
                                      equipmentID,
                                      tmpStartCassette );
    if ( rc == RC_SYSTEM_ERROR )
    {
        PPT_METHODTRACE_V1("", "cassette_APCInformation_GetDR() == RC_SYSTEM_ERROR");
        strOpeStartReqResult.strResult = strCassette_APCInformation_GetDR_out.strResult;
        return ( rc ) ;
    }
    else if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cassette_APCInformation_GetDR() != RC_OK");
        strOpeStartReqResult.strResult = strCassette_APCInformation_GetDR_out.strResult;
    }

    /*--------------------------------------------------*/
    /*   call APCMgr_SendControlJobInformationDR        */
    /*--------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call APCMgr_SendControlJobInformationDR");
    objAPCMgr_SendControlJobInformationDR_out strAPCMgr_SendControlJobInformationDR_out;
    rc = APCMgr_SendControlJobInformationDR(strAPCMgr_SendControlJobInformationDR_out,
                                            strObjCommonIn,
                                            equipmentID,
                                            saveControlJobID,
                                            SP_APC_ControlJobStatus_Executing,
                                            strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList);
//D7000182    if( rc != RC_OK )
    if( rc != RC_OK && rc != RC_OK_NO_IF )    //D7000182
    {
        PPT_METHODTRACE_V1("", "APCMgr_SendControlJobInformationDR != RC_OK");
        strOpeStartReqResult.strResult = strAPCMgr_SendControlJobInformationDR_out.strResult;
        return( rc );
    }

//D7000182 add start
    if( rc == RC_OK )
    {
        PPT_METHODTRACE_V1("", "APCControlJobInformation was sent normally.");
        if(CIMFWStrLen(controlJobID.identifier) == 0)
        {
            PPT_METHODTRACE_V1("", "OpeStart with no StartReservation");
            CORBA::String_var tmpString = APCIFControlStatus;
            APCIFControlStatus = CIMFWStrDup(SP_APC_ControlJobStatus_Canceled);
        }
        else
        {
            PPT_METHODTRACE_V1("", "OpeStart with StartReservation");
            CORBA::String_var tmpString = APCIFControlStatus;
            APCIFControlStatus = CIMFWStrDup(SP_APC_ControlJobStatus_Created);
        }
    }
//D7000182 add end
//D51M0000 add end

    traceSampledStartCassette( strOpeStartReqResult.strStartCassette );  //D9000003

    /*------------------------------------------*/
    /*                                          */
    /*   Set ControlJobID to Return Structure   */
    /*                                          */
    /*------------------------------------------*/
    strOpeStartReqResult.controlJobID = saveControlJobID;

    /*----------------------*/
    /*                      */
    /*   Return to Caller   */
    /*                      */
    /*----------------------*/
    SET_MSG_RC ( strOpeStartReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txOpeStartReq")
    return( RC_OK );
}
