#ifndef lint
static char *sccsid =  "@(#) 1.2 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txScrapWaferReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 8/3/07 13:32:36 [ 8/3/07 13:32:37 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txScrapWaferReqOR.cpp
//

#include "cs_pptmgr.hpp"

// Class: PPTManager
//
// Service: txScrapWaferReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/09/07          O.Sugiyama     Initial Release
// 2000/09/07 P3000065 O.Sugiyama     Fix. Correct RC handling
// 2000/09/11 P3000044 O.Sugiyama     Modify in para cassetteID
// 2000/09/26 Q3000147 S.Kawabe       Add Check Lot's Control Job ID
// 2000/10/16 C3000005 O.Sugiyama     modify bug. deferent define macro
// 2000/10/23 P3000280 S.Kawabe       Boolean variable initialize
// 2001/02/08 P3100007 K.Matsuei      change parameter name
// 2001/06/05 P4000010 O.Sugiyama     MultiLotType was not updated correctly in ScrapWafer
// 2001/06/27 P4000032 K.Kido         Add Object_Lock
// 2001/07/02 P4000037 K.Kido         Add XferStatus check
// 2001/08/01 P4000079 K.Kido         Change XferState check logic
// 2001/08/29 D4000056 Y.Yoshihara    Change timing of cassette_multiLotType_Update
// 2002/03/02 D4100036 K.Matsuei      FlowBatch Control.
// 2002/10/23 P4200267 K.Kido         Add : Check lot's backupState.
// 2003/02/25 P4200571 K.Matsuei      Data inconsistency by MonitorLot's Scrap/BankIn.
// 2003/09/09 P5000145 H.Adachi       Fix Message and Message Macro mismatch.
// 2003/12/05 P5100063 K.Matsuei      OpeComp fails by AutoBankIn.
// 2004/05/07 D5100051 K.Tachibana    Deletion of useless FlowBatch logic.
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2005/11/18 D7000021 M.Murata       Add : Check lot's hold state. (LOCK)
// 2007/06/08 D9000038 D.Tamura       Remove In-Cassette Limitation.
// 2007/08/03 D9000056 H.Hotta        Add check logic for InPostProcessFlag.
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2010/03/15 DSIV00001830 S.Kawabe       Wafer Stacking Operation Support
// 2013/05/09 DSN000071674 C.Mo           Remove part of the EI state limitation
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/10 INN-R170003  YangXigang     Durable Management Enhancement
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    pptScrapWaferReqResult&       strScrapWaferReqResult
//    const pptObjCommonIn&         strObjCommonIn
//    const objectIdentifier&       lotID
//    const objectIdentifier&       cassetteID
//    const objectIdentifier&       reasonRouteID
//    const objectIdentifier&       reasonOperationID
//    const char *                  reasonOperationNumber
//    const char *                  reasonOperationPass
//    const char *                  objrefPO
//    const pptScrapWafersSequence& strScrapWafers
//    const char *                  claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::txScrapWaferReq (
    pptScrapWaferReqResult&       strScrapWaferReqResult,
    const pptObjCommonIn&         strObjCommonIn,
    const objectIdentifier&       lotID,
    const objectIdentifier&       inCassetteID,                     //P3000044
    const objectIdentifier&       reasonRouteID,
    const objectIdentifier&       reasonOperationID,
    const char *                  reasonOperationNumber,
    const char *                  reasonOperationPass,
    const char *                  objrefPO,
    const pptScrapWafersSequence& strScrapWafers,
//D6000025     const char *                  claimMemo,
//D6000025     CORBA::Environment &          IT_env)
    const char *                  claimMemo //D6000025
    CORBAENV_LAST_CPP)                      //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txScrapWaferReq ");
    CORBA::Long rc = RC_OK;

//P5100063//P4200571 start
//P5100063    PPT_METHODTRACE_V1("", "call lot_monitorGroup_CheckForCancelDR()");
//P5100063    objLot_monitorGroup_CheckForCancelDR_out  strLot_monitorGroup_CheckForCancelDR_out;
//P5100063    rc = lot_monitorGroup_CheckForCancelDR( strLot_monitorGroup_CheckForCancelDR_out, strObjCommonIn, lotID );
//P5100063
//P5100063    if ( rc != RC_OK )
//P5100063    {
//P5100063        PPT_METHODTRACE_V2("", "##### lot_monitorGroup_CheckForCancelDR() != RC_OK", rc);
//P5100063        strScrapWaferReqResult.strResult = strLot_monitorGroup_CheckForCancelDR_out.strResult ;
//P5100063        return ( rc );
//P5100063    }
//P5100063//P4200571 end
//P5100063 start
    PPT_METHODTRACE_V1("", "call lot_RemoveFromMonitorGroup()");
    objLot_RemoveFromMonitorGroup_out  strLot_RemoveFromMonitorGroup_out;
    rc = lot_RemoveFromMonitorGroup( strLot_RemoveFromMonitorGroup_out, strObjCommonIn, lotID );

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "##### lot_RemoveFromMonitorGroup() != RC_OK", rc);
        strScrapWaferReqResult.strResult = strLot_RemoveFromMonitorGroup_out.strResult ;
        return ( rc );
    }
//P5100063 end

//P3000044 start
    /*------------------------------------------------------------------------*/
    /*   Check Lot is in cassette                                             */
    /*------------------------------------------------------------------------*/
    objLot_cassette_Get_out strLot_cassette_Get_out;
    rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn,
                          lotID);
//D9000038    if( rc != RC_OK)
    if ( rc != RC_OK && rc != RC_NOT_FOUND_CST ) //D9000038
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "lot_cassette_Get() rc != RC_OK");
        strScrapWaferReqResult.strResult = strLot_cassette_Get_out.strResult ;
        return(rc);
    }
    objectIdentifier cassetteID;
    cassetteID = strLot_cassette_Get_out.cassetteID;
//P3000044 end

//P4000032 add start
    PPT_METHODTRACE_V2("","Now Lock CassetteID is ",cassetteID.identifier);
    PPT_METHODTRACE_V2("","Now Lock CassetteID is ",cassetteID.stringifiedObjectReference);

    //--------------------------------
    //   Lock objects to be updated
    //--------------------------------
    objObject_Lock_out strObject_Lock_out;
    rc = object_Lock(strObject_Lock_out,
                     strObjCommonIn,
                     cassetteID,
                     SP_ClassName_PosCassette);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "object_Lock(cassetteID) rc != RC_OK");
        strScrapWaferReqResult.strResult = strObject_Lock_out.strResult;
        return( rc );
    }
//P4000032 add end

    /*------------------------------------------------------------------------*/
    /*   Check conditions of the Lot                                          */
    /*------------------------------------------------------------------------*/

//D7000021 add start
    /*-----------------------*/
    /*   Check LOCK Hold     */
    /*-----------------------*/
    PPT_METHODTRACE_V1("", "Check LOCK Hold. ");
    objectIdentifierSequence lotIDSeq;
    lotIDSeq.length(1);
    lotIDSeq[0] = lotID;
    objLot_CheckLockHoldConditionForOperation_out  strLot_CheckLockHoldConditionForOperation_out;
    rc = lot_CheckLockHoldConditionForOperation( strLot_CheckLockHoldConditionForOperation_out, strObjCommonIn, lotIDSeq );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "lot_CheckLockHoldConditionForOperation rc != RC_OK", lotIDSeq[0].identifier );
        strScrapWaferReqResult.strResult = strLot_CheckLockHoldConditionForOperation_out.strResult;
        return ( rc );
    }
//D7000021 add end

//D9000056 add start
    PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
    //----------------------------------
    //  Get InPostProcessFlag of Lot
    //----------------------------------
    objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
    objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
    strLot_inPostProcessFlag_Get_in.lotID = lotID;

    rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                    strObjCommonIn,
                                    strLot_inPostProcessFlag_Get_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
        strScrapWaferReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
        return( rc );
    }

    //----------------------------------------------
    //  If Lot is in post process, returns error
    //----------------------------------------------
    if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
    {
        PPT_METHODTRACE_V1("", "Lot is in post process.");
//DSIV00000201 Add Start
        /*---------------------------*/
        /* Get UserGroupID By UserID */
        /*---------------------------*/
        objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
        rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                         strObjCommonIn,
                                         strObjCommonIn.strUser.userID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
            strScrapWaferReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
            return( rc );
        }
        objectIdentifierSequence userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
        CORBA::ULong userGroupIDsLen = userGroupIDs.length();
        PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);
        
        CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
        PPT_METHODTRACE_V2("", "extPostProc", extPostProc);
        
        CORBA::ULong nCnt = 0;
        for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
        {
            PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
            if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
            {
                PPT_METHODTRACE_V1("", "# External Post Process User!");
                break;
            }
            
        }
        if (nCnt == userGroupIDsLen)
        {
            PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
            PPT_SET_MSG_RC_KEY( strScrapWaferReqResult,
                                MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                lotID.identifier );
            return( RC_LOT_INPOSTPROCESS );
        }   //DSIV00000201
    }
//D9000056 add end

    /**========================================**/
    /** LotStatus should be Active or Finished **/
    /**========================================**/

    objLot_state_Get_out strLot_state_Get_out ;
    rc = lot_state_Get(strLot_state_Get_out,strObjCommonIn,lotID) ;
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "lot_state_Get() rc != RC_OK");
        strScrapWaferReqResult.strResult = strLot_state_Get_out.strResult ;
        return(rc);
    }
    else if(!((CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Finished) == 0) ||
              (CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Active)   == 0)  ))
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Finished) || CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Active)");
        PPT_SET_MSG_RC_KEY(strScrapWaferReqResult,MSG_INVALID_LOT_STAT ,RC_INVALID_LOT_STAT,strLot_state_Get_out.lotState);
        return(RC_INVALID_LOT_STAT);
    }

    /**=======================================**/
    /** FinishedStatus should not be Scrapped **/
    /**  or Emptied  (should be Completed),   **/
    /**  in the case of "lotState = Finished" **/
    /**=======================================**/

    if (CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Finished) == 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "!CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Finished)");
        objLot_finishedState_Get_out strLot_finishedState_Get_out;
        rc = lot_finishedState_Get(strLot_finishedState_Get_out,strObjCommonIn,lotID) ;
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "rc != RC_OK");
            strScrapWaferReqResult.strResult = strLot_finishedState_Get_out.strResult ;
            return rc ;
        }
        else if (CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,CIMFW_Lot_FinishedState_Completed) != 0)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_FinishedState_Completed)");
            PPT_SET_MSG_RC_KEY(strScrapWaferReqResult, MSG_INVALID_LOT_FINISHSTAT ,RC_INVALID_LOT_FINISHSTAT,
                               strLot_finishedState_Get_out.lotFinishedState);

            return(RC_INVALID_LOT_FINISHSTAT);
        }
    }

//DSIV00001830 add start
    //---------------------------------------
    // Check Bonding Group 
    //---------------------------------------
    objLot_bondingGroupID_GetDR_in  strLot_bondingGroupID_GetDR_in;
    strLot_bondingGroupID_GetDR_in.lotID = lotID;

    objLot_bondingGroupID_GetDR_out strLot_bondingGroupID_GetDR_out;
    rc = lot_bondingGroupID_GetDR( strLot_bondingGroupID_GetDR_out, strObjCommonIn, strLot_bondingGroupID_GetDR_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_bondingGroupID_GetDR() rc != RC_OK");
        strScrapWaferReqResult.strResult = strLot_bondingGroupID_GetDR_out.strResult;
        return rc;
    }
    if( CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0");
        PPT_SET_MSG_RC_KEY2( strScrapWaferReqResult,
                             MSG_LOT_HAS_BONDINGGROUP,
                             RC_LOT_HAS_BONDINGGROUP,
                             strLot_bondingGroupID_GetDR_in.lotID.identifier,
                             strLot_bondingGroupID_GetDR_out.bondingGroupID );
        return RC_LOT_HAS_BONDINGGROUP;
    }
//DSIV00001830 add end

    /**=======================================**/
    /** ProcessState should not be Processing **/
    /**=======================================**/

    objLot_processState_Get_out strLot_processState_Get_out ;
    rc = lot_processState_Get(strLot_processState_Get_out,strObjCommonIn,lotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "rc != RC_OK");
        strScrapWaferReqResult.strResult = strLot_processState_Get_out.strResult ;
        strScrapWaferReqResult.strResult.returnCode = ConvertLongtoString( rc ) ;
        return rc ;
    }
    else if (CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Processing) == 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "!CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Processing)");
        PPT_SET_MSG_RC_KEY2(strScrapWaferReqResult, MSG_INVALID_LOT_PROCSTAT  ,RC_INVALID_LOT_PROCSTAT,lotID.identifier, strLot_processState_Get_out.theLotProcessState);
        return( RC_INVALID_LOT_PROCSTAT );
    }

//P4200267 add start
    /*-----------------------------------*/
    /*   Check Backup Info               */
    /*-----------------------------------*/
    objLot_backupInfo_Get_out strLot_backupInfo_Get_out;
    rc = lot_backupInfo_Get( strLot_backupInfo_Get_out, strObjCommonIn, lotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", " lot_backupInfo_Get() rc != RC_OK");
        strScrapWaferReqResult.strResult = strLot_backupInfo_Get_out.strResult ;
        return( rc );
    }
    else if( strLot_backupInfo_Get_out.strLotBackupInfo.currentLocationFlag == FALSE ||
             strLot_backupInfo_Get_out.strLotBackupInfo.transferFlag == TRUE )
    {
        PPT_METHODTRACE_V1("", "##### backup condition is invalid.");
        PPT_SET_MSG_RC_KEY( strScrapWaferReqResult,
                            MSG_LOT_IN_OTHERSITE,
                            RC_LOT_IN_OTHERSITE,
                            lotID.identifier );
        return( RC_LOT_IN_OTHERSITE );
    }
//P4200267 add end

//DSN000071674 add start
    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );
    if ( 1 == lotOperationEIcheck )
    {
        PPT_METHODTRACE_V1("", "lotOperationEIcheck = 1");
//DSN000071674 add end
        /**=======================================**/
        /** DispatchState should be NO            **/
        /**=======================================**/
//D9000038 add start
        if( CIMFWStrLen( cassetteID.identifier ) > 0)
        {
//D9000038 add end
            objCassette_dispatchState_Get_out strCassette_dispatchState_Get_out ;
            strCassette_dispatchState_Get_out.dispatchReservedFlag = FALSE; //P3000280
            rc = cassette_dispatchState_Get( strCassette_dispatchState_Get_out,
                                             strObjCommonIn,
                                             cassetteID );
            if (rc != RC_OK)
            {
               PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "rc != RC_OK");
               strScrapWaferReqResult.strResult = strCassette_dispatchState_Get_out.strResult ;
               return( rc );
            }
            else if (strCassette_dispatchState_Get_out.dispatchReservedFlag == TRUE)
            {
               // Required to differ from the PC.
               PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "strCassette_dispatchState_Get_out.dispatchReservedFlag == TRUE");
               SET_MSG_RC(strScrapWaferReqResult, MSG_INVALID_CAST_DISPATCH_STAT, RC_INVALID_CAST_DISPATCH_STAT);
               return( RC_INVALID_CAST_DISPATCH_STAT );
            }
//D9000038 add start
        }
        else
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "The cassetteID is empty. Skip cassette_dispatchState_Get().");
        }
//D9000038 add end
    } //DSN000071674

    /**========================================**/
    /** TransferState should be EO/MO/IO/HO/AO **/
    /**========================================**/
//D9000038 add start
    if( CIMFWStrLen( cassetteID.identifier ) > 0)
    {
//DSN000071674 add start
        if ( 1 == lotOperationEIcheck )
        {
//DSN000071674 add end
//D9000038 add end
            objLot_transferState_Get_out strLot_transferState_Get_out ;
            rc = lot_transferState_Get(strLot_transferState_Get_out,strObjCommonIn,lotID);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "rc != RC_OK");
                strScrapWaferReqResult.strResult = strLot_transferState_Get_out.strResult ;
                return(rc);
            }
//P4000079    else if(!(CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_TransState_EquipmentOut)    == 0  ||
//P4000079              CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_TransState_ManualOut)       == 0  ||
//P4000079              CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_TransState_IntermediateOut) == 0  ||
//P4000079              CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_TransState_ShelfOut)        == 0  ||
//P4000079              CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_UNDEFINED_STATE)            == 0  ||
//P4000079              CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_TransState_AbnormalOut)     == 0  ||
//P4000079              CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_TransState_StationOut)     == 0 ))         //P4000037
            // INN-R170003 else if (CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_BayOut    ) == 0 || 
            // INN-R170003         CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0)              //P4000079 
            // INN-R170003 add start
            else if ( CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_BayOut) == 0 || 
                      CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 ||
                      CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_EquipmentOut) == 0 ||
                      CIMFWStrCmp(strLot_transferState_Get_out.transferState, CS_TRANS_STATE_PORT_IN) == 0
                     )
            // INN-R170003 add end
            {
                PPT_METHODTRACE_V2("", "strLot_transferState_Get_out.transferState = ", strLot_transferState_Get_out.transferState);
                PPT_METHODTRACE_V2("CS_PPTManager_i:: txScrapWaferReq", strLot_transferState_Get_out.transferState,"transferState");
                PPT_SET_MSG_RC_KEY2(strScrapWaferReqResult, MSG_INVALID_LOT_XFERSTAT ,RC_INVALID_LOT_XFERSTAT,lotID.identifier,strLot_transferState_Get_out.transferState);
                return( RC_INVALID_LOT_XFERSTAT );
            }
//D9000038 add start
        } //DSN000071674
    }
    else
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "The cassetteID is empty. Skip lot_transferState_Get().");
    }
//D9000038 add end
//D4100036 start
    /*-------------------------------*/
    /*   Check FlowBatch Condition   */
    /*-------------------------------*/
    PPT_METHODTRACE_V1("", "Check FlowBatch Condition  [ParentLot]") ;
    objLot_flowBatchID_Get_out strLot_flowBatchID_Get_out;
    rc = lot_flowBatchID_Get( strLot_flowBatchID_Get_out, strObjCommonIn, lotID );

    if ( rc == RC_LOT_FLOW_BATCH_ID_FILLED )
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() == RC_LOT_BATCH_ID_BLANK") ;
//P5000145        PPT_SET_MSG_RC_KEY( strScrapWaferReqResult, MSG_FLOW_BATCH_LIMITATION, RC_FLOW_BATCH_LIMITATION, "");
        SET_MSG_RC( strScrapWaferReqResult, MSG_FLOW_BATCH_LIMITATION, RC_FLOW_BATCH_LIMITATION );        //P5000145
        return RC_FLOW_BATCH_LIMITATION;
    }
    else if ( rc == RC_LOT_FLOW_BATCH_ID_BLANK )
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() == RC_LOT_BATCH_ID_BLANK") ;
    }
    else
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() != RC_OK") ;
        strScrapWaferReqResult.strResult = strLot_flowBatchID_Get_out.strResult ;
        return( rc );
    }
//D4100036 end

//Q3000147 add start
    /*----------------------------------*/
    /*   Check Lot's Control Job ID     */
    /*----------------------------------*/
    objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, lotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "lot_controlJobID_Get() != RC_OK");
        strScrapWaferReqResult.strResult = strLot_controlJobID_Get_out.strResult ;
        return(rc);
    }
    if (CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) == 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "CIMFWStrLen(controlJobID.identifier) = 0") ;
        rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "CIMFWStrLen(controlJobID.identifier) > 0") ;
        PPT_SET_MSG_RC_KEY2( strScrapWaferReqResult,
                             MSG_LOT_CTLJOBID_FILLED,
                             RC_LOT_CTLJOBID_FILLED,
                             lotID.identifier,
                             strLot_controlJobID_Get_out.controlJobID.identifier ) ;
        return( RC_LOT_CTLJOBID_FILLED );
    }
//Q3000147 add end

    /*------------------------------------------------------------------------*/
    /*   Check all claimed wafer existance                                    */
    /*------------------------------------------------------------------------*/

    objLot_materials_CheckExistance_out strLot_materials_CheckExistance_out ;
    rc = lot_materials_CheckExistance(strLot_materials_CheckExistance_out,strObjCommonIn,lotID,strScrapWafers);
    if (rc == RC_NOT_FOUND_WAFER)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "rc == RC_NOT_FOUND_WAFER");
//P5000145        PPT_SET_MSG_RC_KEY(strScrapWaferReqResult, MSG_NOT_FOUND_WAFER, RC_NOT_FOUND_WAFER, "*****");
        SET_MSG_RC( strScrapWaferReqResult, MSG_NOT_FOUND_WAFER, RC_NOT_FOUND_WAFER );        //P5000145
        return( RC_NOT_FOUND_WAFER );
    }
    else if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "rc != RC_OK");
        strScrapWaferReqResult.strResult = strLot_materials_CheckExistance_out.strResult ;
        return(rc);
    }

    /*------------------------------------------------------------------------*/
    /*   Check if all claimed reasons are correct                             */
    /*------------------------------------------------------------------------*/

//P3100007    objCode_CheckExistance_out strCode_CheckExistance_out ;
    objCode_CheckExistanceDR_out strCode_CheckExistanceDR_out ;  //P3100007

    CORBA::Long seqLen = strScrapWafers.length();
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txScrapWaferReq", "strScrapWafers.length()",seqLen);

    pptCheckedCodesSequence strCheckedCodes(seqLen);
    strCheckedCodes.length(seqLen);

    for (CORBA::Long i = 0; i < seqLen ; i++)
    {
        strCheckedCodes[i].codeDataID = strScrapWafers[i].reasonCodeID;
    }

//P3100007    rc = code_CheckExistanceDR(strCode_CheckExistance_out,strObjCommonIn,SP_OperationCategory_WaferScrap,strCheckedCodes);
    rc = code_CheckExistanceDR(strCode_CheckExistanceDR_out,strObjCommonIn,SP_OperationCategory_WaferScrap,strCheckedCodes);  //P3100007
    if (rc == RC_NOT_FOUND_CODE)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "rc == RC_NOT_FOUND_CODE");
        PPT_SET_MSG_RC_KEY2(strScrapWaferReqResult, MSG_NOT_FOUND_CODE , RC_NOT_FOUND_CODE,SP_OperationCategory_WaferScrap,"*****");
        return( RC_NOT_FOUND_CODE );
    }
    else if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "rc != RC_OK");
//P3100007        strScrapWaferReqResult.strResult = strCode_CheckExistance_out.strResult ;
        strScrapWaferReqResult.strResult = strCode_CheckExistanceDR_out.strResult ;  //P3100007
        return(rc);
    }

    /*------------------------------------------------------------------------*/
    /*   Check this Lot contents are 'Wafer style' product                    */
    /*------------------------------------------------------------------------*/

    objLot_contents_Get_out strLot_contents_Get_out ;
    rc = lot_contents_Get(strLot_contents_Get_out,strObjCommonIn,lotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "rc != RC_OK");
        strScrapWaferReqResult.strResult = strLot_contents_Get_out.strResult ;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_contents_Get_out.theLotContents,SP_ProdType_Wafer) != 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "CIMFWStrCmp(strLot_contents_Get_out.theLotContents,SP_ProdType_Wafer)");
        PPT_SET_MSG_RC_KEY(strScrapWaferReqResult, MSG_INVALID_LOT_CONTENTS, RC_INVALID_LOT_CONTENTS,lotID.identifier);
        return( RC_INVALID_LOT_CONTENTS );
    }


    /*------------------------------------------------------------------------*/
    /*   Do Wafer Scrap                                                       */
    /*------------------------------------------------------------------------*/

    objLot_materials_ScrapByWafer_out strLot_materials_ScrapByWafer_out ;
    rc = lot_materials_ScrapByWafer(strLot_materials_ScrapByWafer_out,strObjCommonIn,lotID,strScrapWafers);

//D4000056 Start
    //D9000038 add start
    if( CIMFWStrCmp(cassetteID.identifier, "") != 0 )                                                      //D7000219
    {
    //D9000038 add end
        objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
        CORBA::Long tmpRc ;
        tmpRc = cassette_multiLotType_Update( strCassette_multiLotType_Update_out, strObjCommonIn, cassetteID );
        if (tmpRc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "cassette_multiLotType_Update() != RC_OK") ;
            strScrapWaferReqResult.strResult = strCassette_multiLotType_Update_out.strResult ;
            return(tmpRc);
        }
    //D9000038 add start
    }
    else
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "The cassetteID is empty. Skip cassette_multiLotType_Update().");
    }
    //D9000038 add end
//D4000056 End

    if (rc == RC_ALL_SCRAPPED)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "rc == RC_ALL_SCRAPPED");

//P4000010 add start
        /*---------------------------------------*/
        /*   Update Cassette's MultiLotType      */
        /*---------------------------------------*/

//D4000056        objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
//D4000056        rc = cassette_multiLotType_Update( strCassette_multiLotType_Update_out, strObjCommonIn, cassetteID );
//D4000056        if (rc != RC_OK)
//D4000056        {
//D4000056            PPT_METHODTRACE_V1("", "cassette_multiLotType_Update() != RC_OK") ;
//D4000056            strScrapWaferReqResult.strResult = strCassette_multiLotType_Update_out.strResult ;
//D4000056            return(rc);
//D4000056        }
//P4000010 add end

        objLot_type_Get_out strLot_type_Get_out ;
        rc = lot_type_Get(strLot_type_Get_out,strObjCommonIn,lotID);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "rc != RC_OK");
            strScrapWaferReqResult.strResult = strLot_type_Get_out.strResult ;
            return(rc);
        }
        else if ((CIMFWStrCmp(strLot_type_Get_out.theLotType, SP_Lot_Type_EquipmentMonitorLot) == 0) ||
                 (CIMFWStrCmp(strLot_type_Get_out.theLotType, SP_Lot_Type_CorrelationLot     ) == 0))

        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "CIMFWStrCmp(strLot_type_Get_out.theLotType,SP_Lot_Type_*)");
        }

//D5100051        /*-------------------------------*/
//D5100051        /*   Remove Lot from FlowBatch   */
//D5100051        /*-------------------------------*/
//D5100051//P3000065        objLot_batchID_Get_out strLot_batchID_Get_out;
//D5100051//P3000065        rc = lot_batchID_Get( strLot_batchID_Get_out,
//D5100051//P3000065                              strObjCommonIn,
//D5100051//P3000065                              lotID );
//D5100051        objLot_flowBatchID_GetDR_out strLot_flowBatchID_GetDR_out; //P3000065
//D5100051        rc = lot_flowBatchID_GetDR( strLot_flowBatchID_GetDR_out,  //P3000065
//D5100051                                    strObjCommonIn,                //P3000065
//D5100051                                    lotID );                       //P3000065
//D5100051//P3000065        if ( rc == RC_LOT_BATCH_ID_FILLED )
//D5100051        if ( rc == RC_LOT_FLOW_BATCH_ID_FILLED )                   //P3000065
//D5100051        {
//D5100051           PPT_METHODTRACE_V1("", "rc == RC_LOT_FLOW_BATCH_ID_FILLED");
//D5100051
//D5100051           pptLotRemoveFromFlowBatchReqResult strLotRemoveFromFlowBatchReqResult ;
//D5100051           pptRemoveLotSequence*          strRemoveLot = new pptRemoveLotSequence(1);
//D5100051           pptRemoveLotSequence_var       strRemoveLotVar;
//D5100051
//D5100051           strRemoveLot->length(1);
//D5100051           strRemoveLotVar = strRemoveLot;
//D5100051
//D5100051           (*strRemoveLot)[0].lotID      = lotID;
//D5100051           (*strRemoveLot)[0].cassetteID = cassetteID;
//D5100051        }
//D5100051//P3000065        else if ( rc != RC_LOT_BATCH_ID_BLANK )
//D5100051//C3000005        else if ( rc != RC_LOT_FLOW_BATCH_ID_FILLED )     //P3000065
//D5100051        else if ( rc != RC_LOT_FLOW_BATCH_ID_BLANK )                //C3000005
//D5100051        {
//D5100051           PPT_METHODTRACE_V1("", "rc != RC_LOT_FLOW_BATCH_ID_FILLED");
//D5100051
//D5100051           strScrapWaferReqResult.strResult = strLot_flowBatchID_GetDR_out.strResult ;
//D5100051           return( rc );
//D5100051        }
//D5100051        PPT_METHODTRACE_V1("", "rc == ?");

    }
    else if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "rc != RC_OK");
        strScrapWaferReqResult.strResult = strLot_materials_ScrapByWafer_out.strResult ;
        return(rc);
    }

    /*------------------------------------------------------------------------*/
    /*   Make History records                                                 */
    /*------------------------------------------------------------------------*/

    /**========================================**/
    /** PosLot WaferHis pointer update         **/
    /**========================================**/

    objLot_waferLotHistoryPointer_Update_out  strLot_waferLotHistoryPointer_Update_out;
    rc = lot_waferLotHistoryPointer_Update(strLot_waferLotHistoryPointer_Update_out,strObjCommonIn,lotID);
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "rc != RC_OK");
//P5000145        PPT_SET_MSG_RC_KEY(strScrapWaferReqResult, MSG_FAIL_MAKE_HISTORY, rc,lotID.identifier);
        SET_MSG_RC( strScrapWaferReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145
        return(rc);
    }

    /**========================================**/
    /** Create Operation History               **/
    /**========================================**/

    objLotWaferScrapEvent_Make_out  strLotWaferScrapEvent_Make_out;
    rc = lotWaferScrapEvent_Make(strLotWaferScrapEvent_Make_out, strObjCommonIn, "TXDFC002", lotID, cassetteID, reasonRouteID,
                                 reasonOperationID, reasonOperationNumber, reasonOperationPass, strScrapWafers, claimMemo);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "rc != RC_OK");
//P5000145        PPT_SET_MSG_RC_KEY(strScrapWaferReqResult, MSG_FAIL_MAKE_HISTORY , rc ,lotID.identifier);
        SET_MSG_RC( strScrapWaferReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145

        return( rc );
    }

    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
    SET_MSG_RC(strScrapWaferReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txScrapWaferReq ");
    return(RC_OK);
}


