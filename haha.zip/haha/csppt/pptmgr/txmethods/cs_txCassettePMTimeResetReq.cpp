//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2003. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2003. All rights reserved.
//
// SiView
// Name: cs_txCassettePMTimeResetReq.cpp
//

#include "cs_pptmgr.hpp"

//
//
// Subsystem Name      : CS_PPT Service Manager
//
//
// Change history:
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/09/04 INN-R170003 Helios Zhen    Durable Management Enhancement
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     csCassettePMTimeResetReqResult& strCassettePMTimeResetReqResult
//     const pptObjCommonIn& strObjCommonIn
//     const objectIdentifier& cassetteID
//     const char * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::cs_txCassettePMTimeResetReq(
    csCassettePMTimeResetReqResult&          strCassettePMTimeResetReqResult,
    const pptObjCommonIn&                    strObjCommonIn,
    const objectIdentifier&                  cassetteID,
    const char*                              claimMemo
	CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txCassettePMTimeResetReq")
    CORBA::Long rc = RC_OK ;


    //------------------------------
    // Object Lock for Cassette
    //------------------------------
    objObject_Lock_out  strObject_Lock_out;
    rc = object_Lock(strObject_Lock_out, strObjCommonIn, cassetteID, SP_ClassName_PosCassette);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
        strCassettePMTimeResetReqResult.strResult = strObject_Lock_out.strResult;
        return( rc );
    }
	
    //---------------------------------
    //   Get Cassette's ControlJobID
    //---------------------------------
    objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

    rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                    strObjCommonIn,
                                    cassetteID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2( "", "cassette_controlJobID_Get() != RC_OK", rc);
        strCassettePMTimeResetReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
        return( rc );
    }

    if ( CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) > 0 )
    {
        PPT_METHODTRACE_V1( "", "len(controlJobID) > 0" );
        SET_MSG_RC( strCassettePMTimeResetReqResult,
                    MSG_CAST_CTRLJOBID_FILLED,
                    RC_CAST_CTRLJOBID_FILLED );

        return RC_CAST_CTRLJOBID_FILLED;
    }
    else
    {
        PPT_METHODTRACE_V1("", "strCassette_controlJobID_Get_out.controlJobID.identifier is nil") ;
    }
    //------------------------------
    // get durable substate
    //------------------------------
    objDurable_subState_Get_out strDurable_subState_Get_out;
    objDurable_subState_Get_in  strDurable_subState_Get_in;
    strDurable_subState_Get_in.durableCategory = CIMFWStrDup(SP_DurableCat_Cassette);
    strDurable_subState_Get_in.durableID       = cassetteID;
    rc = durable_subState_Get(strDurable_subState_Get_out, strObjCommonIn, strDurable_subState_Get_in);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "durable_subState_Get() != RC_OK");
        strCassettePMTimeResetReqResult.strResult = strDurable_subState_Get_out.strResult;
        return rc;
    }
    else if (0 != CIMFWStrCmp(strDurable_subState_Get_out.durableSubStatus.identifier, CS_FOUP_DURABLE_SUB_STATE_WAITCLEAN))
    {
        PPT_METHODTRACE_V2("", "durableSubState is not FOUP_WaitClean",rc);
        
        CORBA::ULong durableStatusInfoLen = 0 ;
        durableStatusInfoLen += CIMFWStrLen( strDurable_subState_Get_out.durableStatus );
        durableStatusInfoLen += CIMFWStrLen( strDurable_subState_Get_out.durableSubStatus.identifier ); 
        durableStatusInfoLen += 1 ;

        char* tmpDurableStatusInfo = CORBA::string_alloc( durableStatusInfoLen );
        if( tmpDurableStatusInfo != NULL )
        {
            tmpDurableStatusInfo[0] = NULL;
            CIMFWStrCpy( tmpDurableStatusInfo , strDurable_subState_Get_out.durableStatus );
            CIMFWStrCat( tmpDurableStatusInfo , "." );
            CIMFWStrCat( tmpDurableStatusInfo , strDurable_subState_Get_out.durableSubStatus.identifier );      
        }
        CORBA::String_var tmpdurableStatusInfo_var = tmpDurableStatusInfo;        
        PPT_SET_MSG_RC_KEY2(strCassettePMTimeResetReqResult,
                           MSG_INVALID_CAST_STAT,
                           RC_INVALID_DURABLE_STAT,
                           tmpdurableStatusInfo_var,
                           cassetteID.identifier);
        return(RC_INVALID_DURABLE_STAT);
    }
    //-------------------------------------------
    // Set durable status to FOUP_Fresh
    //-------------------------------------------
    pptDurableStatusMultiChangeReqResult strDurableStatusMultiChangeReqResult;
    pptDurableStatusMultiChangeReqInParm strDurableStatusMultiChangeReqInParm;
    strDurableStatusMultiChangeReqInParm.durableStatus
                                                        = CORBA::string_dup(CIMFW_Durable_Available);
    strDurableStatusMultiChangeReqInParm.durableSubStatus.identifier
                                                        = CORBA::string_dup(CS_FOUP_DURABLE_SUB_STATE_FRESH);
    strDurableStatusMultiChangeReqInParm.durableCategory
                                                        = CORBA::string_dup(SP_DurableCat_Cassette);
    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq.length(1);
    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableID.identifier
                                                        = CORBA::string_dup(cassetteID.identifier);
    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableStatus
                                                        = CORBA::string_dup(strDurable_subState_Get_out.durableStatus);
    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableSubStatus.identifier
                                                        = CORBA::string_dup(strDurable_subState_Get_out.durableSubStatus.identifier);
 
    rc = txDurableStatusMultiChangeReq(strDurableStatusMultiChangeReqResult, strObjCommonIn, strDurableStatusMultiChangeReqInParm, claimMemo);

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "txDurableStatusMultiChangeReq() rc != RC_OK", rc);
        strCassettePMTimeResetReqResult.strResult = strDurableStatusMultiChangeReqResult.strResult;
        return(rc);
    }
    /*------------------------------------------------*/
    /*   Reset cassette PM time information   */
    /*------------------------------------------------*/
	csObjCassette_PMTime_Reset_out strCassette_PMTime_Reset_out;
    rc = cs_cassette_PMTime_Reset(strCassette_PMTime_Reset_out,strObjCommonIn,cassetteID,claimMemo);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_cassette_PMTime_Reset() rc != RC_OK", rc)
        strCassettePMTimeResetReqResult.strResult = strCassette_PMTime_Reset_out.strResult ;
        return( rc );
    }

    /*---------------------------------------------*/
    /*   Create Durable Change Event               */
    /*---------------------------------------------*/
    objDurableChangeEvent_Make_out strDurableChangeEvent_Make_out;
    rc = durableChangeEvent_Make(strDurableChangeEvent_Make_out,
                                 strObjCommonIn,
                                 "TXPDC008",
                                 cassetteID,
                                 SP_DurableCat_Cassette,
                                 CS_DURABLE_EVENT_ACTION_PM_RESET,
                                 claimMemo) ;

    if( rc )
    {
        PPT_METHODTRACE_V2("", "durableChangeEvent_Make() rc != RC_OK",rc)
        strCassettePMTimeResetReqResult.strResult = strDurableChangeEvent_Make_out.strResult ;
        SET_MSG_RC( strCassettePMTimeResetReqResult, MSG_FAIL_MAKE_HISTORY, rc );
        return rc ;
    }

    /*-----------------------*/
    /*   Set out structure   */
    /*-----------------------*/
    strCassettePMTimeResetReqResult.cassetteID = cassetteID ;

    SET_MSG_RC(strCassettePMTimeResetReqResult, MSG_OK, RC_OK); 

    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txCassettePMTimeResetReq")
    return( RC_OK );
    
}
