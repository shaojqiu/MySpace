//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_txLotComplicatedHoldReq.cpp
//

#include "cs_pptmgr.hpp"


// Class: CS_PPTManager
//
// Service: cs_txLotComplicatedHoldReq()
//
// Innotron Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/13 INN-R170009  Nick Tsai      add lot hold for external system
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::cs_txLotComplicatedHoldReq (
    csLotComplicatedHoldReqResult&          strLotComplicatedHoldReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const csLotComplicatedHoldReqInParam&   strLotComplicatedHoldReqInParam
    CORBAENV_LAST_CPP )
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txLotComplicatedHoldReq");
    CORBA::Long rc = RC_OK;

    //================================================================//
    //   Print input parameters                                       //
    //================================================================//
    CORBA::Long lLotLen = strLotComplicatedHoldReqInParam.lotIDs.length();
    for( CORBA::Long lLotIdx = 0; lLotIdx < lLotLen; lLotIdx ++ )
    {
        PPT_METHODTRACE_V3("", "(Print) idx - lotID ", lLotIdx, strLotComplicatedHoldReqInParam.lotIDs[lLotIdx].identifier );
    }
    PPT_METHODTRACE_V2("", "(Print) action ",               strLotComplicatedHoldReqInParam.action);
    PPT_METHODTRACE_V2("", "(Print) reasonCode ",           strLotComplicatedHoldReqInParam.reasonCode.identifier);
    PPT_METHODTRACE_V2("", "(Print) relatedLotID ",         strLotComplicatedHoldReqInParam.relatedLotID.identifier);
    PPT_METHODTRACE_V2("", "(Print) routeID ",              strLotComplicatedHoldReqInParam.strFutureHoldInfo.routeID.identifier);
    PPT_METHODTRACE_V2("", "(Print) operationNumber ",      strLotComplicatedHoldReqInParam.strFutureHoldInfo.operationNumber);
    PPT_METHODTRACE_V2("", "(Print) postFlag ",             strLotComplicatedHoldReqInParam.strFutureHoldInfo.postFlag);
    PPT_METHODTRACE_V2("", "(Print) singleTriggerFlag ",    strLotComplicatedHoldReqInParam.strFutureHoldInfo.singleTriggerFlag);

    //================================================================//
    //   Check input parameters                                       //
    //================================================================//
    if ( CIMFWStrCmp ( strLotComplicatedHoldReqInParam.action, CS_COMPLICATED_HOLD_ACTION_IMMEDIATE_HOLD) != 0 &&
         CIMFWStrCmp ( strLotComplicatedHoldReqInParam.action, CS_COMPLICATED_HOLD_ACTION_FUTURE_HOLD) != 0 )
    {
        PPT_METHODTRACE_V1("","action != CS_COMPLICATED_HOLD_ACTION_IMMEDIATE_HOLD && action != CS_COMPLICATED_HOLD_ACTION_FUTURE_HOLD");
        SET_MSG_RC( strLotComplicatedHoldReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
        return RC_INVALID_INPUT_PARM;
    }

    if ( CIMFWStrCmp ( strLotComplicatedHoldReqInParam.action, CS_COMPLICATED_HOLD_ACTION_FUTURE_HOLD) == 0 &&
         ( CIMFWStrLen ( strLotComplicatedHoldReqInParam.strFutureHoldInfo.routeID.identifier ) == 0 ||
           CIMFWStrLen ( strLotComplicatedHoldReqInParam.strFutureHoldInfo.operationNumber ) == 0   )    )
    {
        PPT_METHODTRACE_V1("","action == CS_COMPLICATED_HOLD_ACTION_FUTURE_HOLD, but input strFutureHoldInfo is invalid");
        SET_MSG_RC( strLotComplicatedHoldReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
        return RC_INVALID_INPUT_PARM;
    }

    for( lLotIdx = 0; lLotIdx < lLotLen; lLotIdx ++ )
    {
        PPT_METHODTRACE_V3("", "(Check) idx - lotID", lLotIdx, strLotComplicatedHoldReqInParam.lotIDs[lLotIdx].identifier );

        if ( CIMFWStrLen ( strLotComplicatedHoldReqInParam.lotIDs[lLotIdx].identifier) == 0 )
        {
            PPT_METHODTRACE_V1("","CIMFWStrLen (lotID.identifier) == 0");
            SET_MSG_RC( strLotComplicatedHoldReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }
    }

    //========================================================================//
    //   Get lot state to decide what kind of hold should be performed        //
    //========================================================================//
    for( lLotIdx = 0 ; lLotIdx < lLotLen ; lLotIdx ++ )
    {
        PPT_METHODTRACE_V3("", "(Performing) idx - lotID", lLotIdx, strLotComplicatedHoldReqInParam.lotIDs[lLotIdx].identifier );

        //========================================================================//
        //   Get lot inventory state                                              //
        //========================================================================//
        objLot_inventoryState_Get_out strLot_inventoryState_Get_out ;
        rc = lot_inventoryState_Get( strLot_inventoryState_Get_out, strObjCommonIn, strLotComplicatedHoldReqInParam.lotIDs[lLotIdx] ) ;
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V2("", "lot_inventoryState_Get() != RC_OK", rc) ;
            strLotComplicatedHoldReqResult.strResult = strLot_inventoryState_Get_out.strResult ;
            return(rc);
        }

        //========================================================================//
        //   Get lot process state                                                //
        //========================================================================//
        objLot_processState_Get_out strLot_processState_Get_out;
        rc = lot_processState_Get(strLot_processState_Get_out, strObjCommonIn, strLotComplicatedHoldReqInParam.lotIDs[lLotIdx] );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_processState_Get() != RC_OK", rc) ;
            strLotComplicatedHoldReqResult.strResult =  strLot_processState_Get_out.strResult ;
            return(rc);
        }

        //========================================================================//
        //   Immediate hold                                                       //
        //========================================================================//
        if ( CIMFWStrCmp( strLotComplicatedHoldReqInParam.action, CS_COMPLICATED_HOLD_ACTION_IMMEDIATE_HOLD ) == 0 )
        {
            PPT_METHODTRACE_V2("", "Immediate hold, lotID :", strLotComplicatedHoldReqInParam.lotIDs[lLotIdx].identifier) ;

            if ( CIMFWStrCmp( strLot_inventoryState_Get_out.lotInventoryState, SP_Lot_InventoryState_InBank ) == 0 )
            {
                //========================================================================//
                //   Bank hold                                                            //
                //========================================================================//
                PPT_METHODTRACE_V1("", "Lot is in bank, perform txHoldBankLotReq") ;

                pptHoldBankLotReqResult strHoldBankLotReqResult;
                strHoldBankLotReqResult.strHoldBankLotResult.length(1);
                CORBA::Long lBankLotIdx = 0;

                objectIdentifierSequence lotIDs;
                lotIDs.length(1);
                lotIDs[0] = strLotComplicatedHoldReqInParam.lotIDs[lLotIdx];

                rc = txHoldBankLotReq( strHoldBankLotReqResult,
                                       strObjCommonIn,
                                       lBankLotIdx,
                                       lotIDs,
                                       strLotComplicatedHoldReqInParam.reasonCode,
                                       strLotComplicatedHoldReqInParam.claimMemo );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("","txHoldBankLotReq() != RC_OK", rc );
                    strLotComplicatedHoldReqResult.strResult = strHoldBankLotReqResult.strResult;
                    return rc;
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "Lot is not in bank") ;

                //========================================================================//
                //   Regist future hold at pre1 of next operation                         //
                //========================================================================//
                if ( CIMFWStrCmp ( strLot_processState_Get_out.theLotProcessState, SP_Lot_ProcState_Processing ) == 0 )
                {
                    PPT_METHODTRACE_V1("", "Lot is inporcessing, perform txEnhancedFutureHoldReq to regist at pre1 of next operation") ;

                    objLot_nextOperation_Get_out strLot_nextOperation_Get_out;
                    rc = lot_nextOperation_Get ( strLot_nextOperation_Get_out,
                                                 strObjCommonIn,
                                                 strLotComplicatedHoldReqInParam.lotIDs[lLotIdx] );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("","lot_nextOperation_Get() != RC_OK", rc );
                        strLotComplicatedHoldReqResult.strResult  = strLot_nextOperation_Get_out.strResult;
                        return( rc );
                    }

                    PPT_METHODTRACE_V2("","next routeID         :", strLot_nextOperation_Get_out.routeID );
                    PPT_METHODTRACE_V2("","next operationNumber :", strLot_nextOperation_Get_out.operationNumber    );

                    objectIdentifier routeID;
                    routeID.identifier = strLot_nextOperation_Get_out.routeID;
                    pptEnhancedFutureHoldReqResult strEnhancedFutureHoldReqResult;
                    rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult,
                                                  strObjCommonIn,
                                                  SP_HoldType_FutureHold,
                                                  strLotComplicatedHoldReqInParam.lotIDs[lLotIdx],
                                                  routeID,
                                                  strLot_nextOperation_Get_out.operationNumber,
                                                  strLotComplicatedHoldReqInParam.reasonCode,
                                                  strLotComplicatedHoldReqInParam.relatedLotID,
                                                  FALSE,            //postFlag
                                                  FALSE,            //singleTriggerFlag
                                                  strLotComplicatedHoldReqInParam.claimMemo );

                    if ( rc != RC_OK && rc != RC_DUPLICATE_FTHOLD_ENTRY )
                    {
                        PPT_METHODTRACE_V2("", "txEnhancedFutureHoldReq() != RC_OK && RC_DUPLICATE_FTHOLD_ENTRY", rc);
                        strLotComplicatedHoldReqResult.strResult = strEnhancedFutureHoldReqResult.strResult;
                        return( rc );
                    }
                }
                //========================================================================//
                //   Lot hold                                                             //
                //========================================================================//
                else
                {
                    PPT_METHODTRACE_V1("", "Lot is not inporcessing, perform txHoldLotReq") ;

                    objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
                    rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out,
                                                       strObjCommonIn,
                                                       strLotComplicatedHoldReqInParam.lotIDs[lLotIdx] );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("","lot_currentOperationInfo_Get() != RC_OK", rc );
                        strLotComplicatedHoldReqResult.strResult  = strLot_currentOperationInfo_Get_out.strResult;
                        return( rc );
                    }

                    PPT_METHODTRACE_V2("","current routeID         :", strLot_currentOperationInfo_Get_out.routeID.identifier );
                    PPT_METHODTRACE_V2("","current operationNumber :", strLot_currentOperationInfo_Get_out.operationNumber    );

                    pptHoldListSequence  strHoldListSeq;
                    strHoldListSeq.length(1);
                    strHoldListSeq[0].holdType                  = CIMFWStrDup ( SP_HoldType_LotHold );
                    strHoldListSeq[0].holdReasonCodeID          = strLotComplicatedHoldReqInParam.reasonCode ;
                    strHoldListSeq[0].holdUserID                = strObjCommonIn.strUser.userID ;
                    strHoldListSeq[0].responsibleOperationMark  = CIMFWStrDup ( SP_ResponsibleOperation_Current );
                    strHoldListSeq[0].routeID                   = strLot_currentOperationInfo_Get_out.routeID ;
                    strHoldListSeq[0].operationNumber           = strLot_currentOperationInfo_Get_out.operationNumber ;
                    strHoldListSeq[0].claimMemo                 = strLotComplicatedHoldReqInParam.claimMemo ;
                    strHoldListSeq[0].relatedLotID              = strLotComplicatedHoldReqInParam.relatedLotID ;

                    pptHoldLotReqResult  strHoldLotReqResult;
                    rc = txHoldLotReq( strHoldLotReqResult,
                                       strObjCommonIn,
                                       strLotComplicatedHoldReqInParam.lotIDs[lLotIdx],
                                       strHoldListSeq );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("","txHoldLotReq() != RC_OK", rc );
                        strLotComplicatedHoldReqResult.strResult = strHoldLotReqResult.strResult;
                        return rc;
                    }
                }
            }
        }
        //========================================================================//
        //   Future hold                                                          //
        //========================================================================//
        else if ( CIMFWStrCmp( strLotComplicatedHoldReqInParam.action, CS_COMPLICATED_HOLD_ACTION_FUTURE_HOLD ) == 0 )
        {
            PPT_METHODTRACE_V2("", "Future hold, lotID :", strLotComplicatedHoldReqInParam.lotIDs[lLotIdx].identifier) ;
            pptEnhancedFutureHoldReqResult strEnhancedFutureHoldReqResult;
            rc = txEnhancedFutureHoldReq( strEnhancedFutureHoldReqResult,
                                          strObjCommonIn,
                                          SP_HoldType_FutureHold,
                                          strLotComplicatedHoldReqInParam.lotIDs[lLotIdx],
                                          strLotComplicatedHoldReqInParam.strFutureHoldInfo.routeID,
                                          strLotComplicatedHoldReqInParam.strFutureHoldInfo.operationNumber,
                                          strLotComplicatedHoldReqInParam.reasonCode,
                                          strLotComplicatedHoldReqInParam.relatedLotID,
                                          strLotComplicatedHoldReqInParam.strFutureHoldInfo.postFlag,
                                          strLotComplicatedHoldReqInParam.strFutureHoldInfo.singleTriggerFlag,
                                          strLotComplicatedHoldReqInParam.claimMemo );

            if ( rc != RC_OK && rc != RC_DUPLICATE_FTHOLD_ENTRY )
            {
                PPT_METHODTRACE_V2("", "txEnhancedFutureHoldReq() != RC_OK && RC_DUPLICATE_FTHOLD_ENTRY", rc);
                strLotComplicatedHoldReqResult.strResult = strEnhancedFutureHoldReqResult.strResult;
                return( rc );
            }
        }
    }

    //========================================================================//
    //   Return                                                               //
    //========================================================================//
    SET_MSG_RC(strLotComplicatedHoldReqResult, MSG_OK, RC_OK);
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txLotComplicatedHoldReq");
    return (RC_OK);
}

