//
// (c) Copyright: IBM Taiwan Industrial Solution Co., Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// File : cs_txVendorLotReserveListInq.cpp
//
// Description :
//
// Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/07/25 INN-R170084 Jacky Yeh      170084: Automatic Vendor Lot Receive and Prepare
//

#include "cs_pptmgr.hpp"

CORBA::Long CS_PPTManager_i::cs_txVendorLotReserveListInq (
    csVendorLotReserveListInqResult&                  strVendorLotReserveListInqResult,
    const pptObjCommonIn&                             strObjCommonIn,
    const objectIdentifier&                           cassetteID
    CORBAENV_LAST_CPP )
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txVendorLotReserveListInq");

    CORBA::Long rc = RC_OK;
    
    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    // Call cs_vendorLotReserve_SelDR
    csObjVendorLotReserve_SelDR_out strVendorLotReserve_SelDR_out ;
    rc = cs_vendorLotReserve_SelDR( strVendorLotReserve_SelDR_out,
                                    strObjCommonIn,
                                    cassetteID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "cs_vendorLotReserve_SelDR() rc != RC_OK", rc);
        strVendorLotReserveListInqResult.strResult = strVendorLotReserve_SelDR_out.strResult ;
        return(rc);
    }

    /*-----------------------------------------------------------------------*/
    /*   Return to Caller                                                    */
    /*-----------------------------------------------------------------------*/
    strVendorLotReserveListInqResult.strResult = strVendorLotReserve_SelDR_out.strResult;
    strVendorLotReserveListInqResult.strVendorLotReserveDataSequence = strVendorLotReserve_SelDR_out.strVendorLotReserveDataSequence;
    
    SET_MSG_RC( strVendorLotReserveListInqResult, MSG_OK, RC_OK ) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txVendorLotReserveListInq");
    return RC_OK;
}
