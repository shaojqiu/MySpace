//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2003. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2003. All rights reserved.
//
// SiView
// Name: cs_txReticleUsedDurationResetReq.cpp
//

#include "cs_pptmgr.hpp"

//
//
// Subsystem Name      : CS_PPT Service Manager
//
//
// Change history:
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/28 INN-R170003 Helios Zhen    INN-R170003:Durable Management Enhancement
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     csReticleUsedDurationResetReqResult& strReticleUsedDurationResetReqResult
//     const pptObjCommonIn& strObjCommonIn
//     const objectIdentifier& reticleID
//     const char * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_txReticleUsedDurationResetReq(
    csReticleUsedDurationResetReqResult&	strReticleUsedDurationResetReqResult,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&					reticleID,
    const char*                             claimMemo
	CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txReticleUsedDurationResetReq")
    CORBA::Long rc = RC_OK ;


    //------------------------------
    // Object Lock for Reticle
    //------------------------------
    objObject_Lock_out  strObject_Lock_out;
    rc = object_Lock(strObject_Lock_out, strObjCommonIn, reticleID, SP_ClassName_PosReticle);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
        strReticleUsedDurationResetReqResult.strResult = strObject_Lock_out.strResult;
        return( rc );
    }
    //------------------------------
    // get durable substate
    //------------------------------
    objDurable_subState_Get_out strDurable_subState_Get_out;
    objDurable_subState_Get_in  strDurable_subState_Get_in;
    strDurable_subState_Get_in.durableCategory = CIMFWStrDup(SP_DurableCat_Reticle);
    strDurable_subState_Get_in.durableID       = reticleID;
    rc = durable_subState_Get(strDurable_subState_Get_out, strObjCommonIn, strDurable_subState_Get_in);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "durable_subState_Get() != RC_OK");
        strReticleUsedDurationResetReqResult.strResult = strDurable_subState_Get_out.strResult;
        return rc;
    }
    else if (0 != CIMFWStrCmp(strDurable_subState_Get_out.durableSubStatus.identifier, CS_RETICLE_DURABLE_SUB_STATE_INSPDIE))
    {
        PPT_METHODTRACE_V2("", "durableSubState is not RTCL_InspDie",rc);

        CORBA::ULong durableStatusInfoLen = 0 ;
        durableStatusInfoLen += CIMFWStrLen( strDurable_subState_Get_out.durableStatus );
        durableStatusInfoLen += CIMFWStrLen( strDurable_subState_Get_out.durableSubStatus.identifier ); 
        durableStatusInfoLen += 1 ;

        char* tmpDurableStatusInfo = CORBA::string_alloc( durableStatusInfoLen );
        if( tmpDurableStatusInfo != NULL )
        {
            tmpDurableStatusInfo[0] = NULL;
            CIMFWStrCpy( tmpDurableStatusInfo , strDurable_subState_Get_out.durableStatus );
            CIMFWStrCat( tmpDurableStatusInfo , "." );
            CIMFWStrCat( tmpDurableStatusInfo , strDurable_subState_Get_out.durableSubStatus.identifier );      
        }
        CORBA::String_var tmpdurableStatusInfo_var = tmpDurableStatusInfo;
        
        PPT_SET_MSG_RC_KEY2(strReticleUsedDurationResetReqResult,
                           MSG_INVALID_RETICLE_STAT,
                           RC_INVALID_RETICLE_STAT,
                           reticleID.identifier,
                           tmpdurableStatusInfo_var);
        return(RC_INVALID_RETICLE_STAT);
    }
    //-------------------------------------------
    // Set durable status to RTCL_Idle
    //-------------------------------------------
    pptDurableStatusMultiChangeReqResult strDurableStatusMultiChangeReqResult;
    pptDurableStatusMultiChangeReqInParm strDurableStatusMultiChangeReqInParm;
    strDurableStatusMultiChangeReqInParm.durableStatus
                                                        = CORBA::string_dup(CIMFW_Durable_Available);
    strDurableStatusMultiChangeReqInParm.durableSubStatus.identifier
                                                        = CORBA::string_dup(CS_RETICLE_DURABLE_SUB_STATE_IDLE);
    strDurableStatusMultiChangeReqInParm.durableCategory
                                                        = CORBA::string_dup(SP_DurableCat_Reticle);
    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq.length(1);
    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableID.identifier
                                                        = CORBA::string_dup(reticleID.identifier);
    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableStatus
                                                        = CORBA::string_dup(strDurable_subState_Get_out.durableStatus);
    strDurableStatusMultiChangeReqInParm.strCurrentDurableStatusInfoSeq[0].durableSubStatus.identifier
                                                        = CORBA::string_dup(strDurable_subState_Get_out.durableSubStatus.identifier);
 
    rc = txDurableStatusMultiChangeReq(strDurableStatusMultiChangeReqResult, strObjCommonIn, strDurableStatusMultiChangeReqInParm, claimMemo);

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "txDurableStatusMultiChangeReq() rc != RC_OK", rc);
        strReticleUsedDurationResetReqResult.strResult = strDurableStatusMultiChangeReqResult.strResult;
        return(rc);
    }
    	

    /*------------------------------------------------*/
    /*   Reset reticle used duration information        */
    /*------------------------------------------------*/
	csObjReticle_UsedDuration_Reset_out strReticle_UsedDuration_Reset_out;
    rc = cs_reticle_UsedDuration_Reset(strReticle_UsedDuration_Reset_out,strObjCommonIn,reticleID,claimMemo);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cs_reticle_UsedDuration_Reset() rc != RC_OK", rc)
        strReticleUsedDurationResetReqResult.strResult = strReticle_UsedDuration_Reset_out.strResult ;
        return( rc );
    }

    /*---------------------------------------------*/
    /*   Create Durable Change Event               */
    /*---------------------------------------------*/
    objDurableChangeEvent_Make_out strDurableChangeEvent_Make_out;
    rc = durableChangeEvent_Make(strDurableChangeEvent_Make_out,
                                 strObjCommonIn,
                                 "TXPDC007",
                                 reticleID,
                                 SP_DurableCat_Reticle,
                                 CS_DURABLE_EVENT_ACTION_USED_DURATION_RESET,
                                 claimMemo) ;

    if( rc )
    {
        PPT_METHODTRACE_V2("", "durableChangeEvent_Make() rc != RC_OK",rc)
        strReticleUsedDurationResetReqResult.strResult = strDurableChangeEvent_Make_out.strResult ;
        SET_MSG_RC( strReticleUsedDurationResetReqResult, MSG_FAIL_MAKE_HISTORY, rc );
        return rc ;
    }

    /*-----------------------*/
    /*   Set out structure   */
    /*-----------------------*/
    strReticleUsedDurationResetReqResult.reticleID = reticleID ;

    SET_MSG_RC(strReticleUsedDurationResetReqResult, MSG_OK, RC_OK); 

    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txReticleUsedDurationResetReq")
    return( RC_OK );
    
}
