#ifndef lint
static char *sccsid =  "@(#) 1.2 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txScrapWaferCancelReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 8/3/07 16:30:17 [ 8/3/07 16:30:18 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txScrapWaferCancelReqOR.cpp
//

#include "cs_pptmgr.hpp"


// Class: PPTManager
//
// Service: txScrapWaferCancelReq()
//
// Change history:
// Date       Defect#    Person         Comments
// ---------- --------   -------------- -------------------------------------------
// 2000/09/12 0.00     H.Ueda         Intial Release               (R30)
// 2000/09/12 P3000044 H.Ueda         Modify in para cassetteID.
// 2000/09/12 P3000139 S.Kawabe       add SET_MSG_RC
// 2000/09/26 Q3000147 S.Kawabe       Add Check Lot's Control Job ID
// 2000/10/17 P3000268 O.Sugiyama     Add logic all scrap cancel
// 2000/10/23 P3000280 S.Kawabe       Boolean variable initialize
// 2001/02/08 P3100007 K.Matsuei      change parameter name
// 2001/06/06 P4000014 H.Adachi       (TSMC-F12)Con Not UnScrap
// 2001/07/02 P4000037 K.Kido         Add XferState Check
// 2001/08/01 P4000079 K.Kido         Change XferState check logic
// 2001/10/24 D4000243 K.Kido         Check lot's duration
// 2002/03/02 D4100036 K.Matsuei      FlowBatch Control.
// 2002/05/13 P4100425 K.Matsuei      The number of Parameters to assemble Message in PPT_SET_MSG_RC_KEY*** mistakes it.
// 2002/10/11 D4200029 K.Kimura       Process Hold Control.
// 2002/10/23 P4200267 K.Kido         Add : Check lot's backupState.
// 2002/11/07 P4200314 H.Adachi       Add check of wafer and cassette relation.
// 2002/12/02 D4200229 K.Kimura       Delete Logic of ProcessHold at ScrapWaferCancelReq.
// 2003/09/09 P5000145 H.Adachi       Fix Message and Message Macro mismatch.
// 2004/10/22 D6000025 K.Murakami     eBroker Migration.
// 2005/05/12 D6000256 Hasegawa       Change position of lot_CheckDurationForOperation().
// 2006/05/18 D7000092 Y.Kadowaki     Add object lock for cassette.
// 2007/04/20 D9000001 H.Murakami     64bit support.
// 2007/06/08 D9000038 D.Tamura       Remove In-Cassette Limitation.
// 2007/08/03 D9000056 H.Hotta        Add check logic for InPostProcessFlag.
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2010/03/15 DSIV00001830 S.Kawabe       Wafer Stacking Operation Support
// 2013/05/10 DSN000071674 C.Mo           Remove part of the EI state limitation
// 2014/01/21 PSN000083176 C.Mo           Data inconsistency might occur when start lot reservation is called together with lot operation transactions for the same cassette
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/10 INN-R170003  YangXigang     Durable Management Enhancement
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptScrapWaferCancelReqResult& strScrapWaferCancelReqResult
//     const pptObjCommonIn& strObjCommonIn
//     const objectIdentifer lotID
//     const objectIdentifer inCassetteID
//     const pptScrapCancelWafersSequence& strScrapCancelWafers
//     const char * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::txScrapWaferCancelReq (
    pptScrapWaferCancelReqResult&        strScrapWaferCancelReqResult,
    const pptObjCommonIn&                strObjCommonIn,
    const objectIdentifier&              lotID,
    const objectIdentifier&              inCassetteID,
    const pptScrapCancelWafersSequence&  strScrapCancelWafers,
//D6000025     const char *                         claimMemo,
//D6000025     CORBA::Environment &                 IT_env)
    const char *                         claimMemo //D6000025
    CORBAENV_LAST_CPP)                             //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txScrapWaferCancelReq ")
    CORBA::Long rc = RC_OK;

    PPT_METHODTRACE_V2("", "in para lotID       ", lotID.identifier);
    PPT_METHODTRACE_V2("", "in para inCassetteID", inCassetteID.identifier);

    objCassette_lot_Get_out  strCassette_lot_Get_out;
    objectIdentifier LotID = lotID;
    objectIdentifier CassetteID ; // = cassetteID; As Per Nagamine_san
    CORBA::Boolean bMrgLotInCast  = TRUE; //D9000038

//P3000268 //P3000044 start
//P3000268     /*------------------------------------------------------------------------*/
//P3000268     /*   Check Lot is in cassette                                             */
//P3000268     /*------------------------------------------------------------------------*/
//P3000268     objLot_cassette_Get_out strLot_cassette_Get_out;
//P3000268     rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn,
//P3000268                          lotID);
//P3000268    if( rc != RC_OK)
//P3000268    {
//P3000268        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferReq", "lot_cassette_Get() rc != RC_OK");
//P3000268        strScrapWaferCancelReqResult.strResult = strLot_cassette_Get_out.strResult ;
//P3000268        return(rc);
//P3000268    }
//P3000268    CassetteID = strLot_cassette_Get_out.cassetteID;
//P3000268//P3000044 end

    /*------------------------------------------------------------------------*/
    /*   Check Finished State of lot                                          */
    /*------------------------------------------------------------------------*/
    //D4200229 CORBA::Boolean allScrapFlag = FALSE ;    //D4200029
    objLot_finishedState_Get_out strLot_finishedState_Get_out;
    rc = lot_finishedState_Get(strLot_finishedState_Get_out,strObjCommonIn,LotID) ;
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq", "rc != RC_OK")
        strScrapWaferCancelReqResult.strResult = strLot_finishedState_Get_out.strResult ;
        return rc ;
    }
//DSIV00001830 add start
    else if( CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,SP_LOT_FINISHED_STATE_STACKED) == 0 )
    { 
        PPT_METHODTRACE_V1("", "CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,SP_LOT_FINISHED_STATE_STACKED) == 0");
        PPT_SET_MSG_RC_KEY( strScrapWaferCancelReqResult,
                            MSG_INVALID_LOT_FINISHSTAT,
                            RC_INVALID_LOT_FINISHSTAT,
                            strLot_finishedState_Get_out.lotFinishedState );
    
        return RC_INVALID_LOT_FINISHSTAT;
    }
//DSIV00001830 add end
    else if (CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,CIMFW_Lot_FinishedState_Scrapped) == 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq", "Cancel from All Scrap")
//D9000038        CassetteID = inCassetteID;  //P3000268
        //D4200229 allScrapFlag = TRUE ;       //D4200029
//P4000014        /*------------------------------------------------------------------------*/
//P4000014        /*   Check if Empty Cassette or Not                                       */
//P4000014        /*------------------------------------------------------------------------*/
//P4000014        objCassette_CheckEmpty_out strCassette_CheckEmpty_out;
//P4000014        rc = cassette_CheckEmpty(strCassette_CheckEmpty_out,strObjCommonIn,
//P4000014                                 CassetteID);
//P4000014        if ( rc != RC_OK )
//P4000014        {
//P4000014            PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq", "rc != RC_OK")
//P4000014            strScrapWaferCancelReqResult.strResult = strCassette_CheckEmpty_out.strResult ;
//P4000014            return rc ;
//P4000014        }
//P3000268        CassetteID = inCassetteID;

        //D6000256 Add Start : The logic which checks duration was moved from backward, to apply at All Scrap case only.
        objLot_CheckDurationForOperation_out  strLot_CheckDurationForOperation_out;
        rc = lot_CheckDurationForOperation( strLot_CheckDurationForOperation_out, strObjCommonIn, lotID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_CheckDurationForOperation() != RC_OK");
            strScrapWaferCancelReqResult.strResult = strLot_CheckDurationForOperation_out.strResult;
            return rc;
        }
        else if( strLot_CheckDurationForOperation_out.bOperableFlag == FALSE )
        {
            PPT_METHODTRACE_V1("", "The target Lot is reserved to deletion.");
            SET_MSG_RC( strScrapWaferCancelReqResult, MSG_RESERVED_BY_DELETION_PROGRAM, RC_RESERVED_BY_DELETION_PROGRAM );
            return RC_RESERVED_BY_DELETION_PROGRAM;
        }
        PPT_METHODTRACE_V1("", "The target Lot is not reserved to deletion.");
        //D6000256 Add End
    }
    else if (CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,CIMFW_Lot_FinishedState_Scrapped) != 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq", "Cancel from Partial Scrap")
        /*------------------------------------------------------------------------*/
        /*   Check Cassette/Lot combination                                       */
        /*------------------------------------------------------------------------*/
        //R30 rc = cassette_lot_Get(strCassette_lot_Get_out,strObjCommonIn,LotID,CassetteID);
        //R30 if (rc != RC_OK)
        //R30 {
        //R30     PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq ", "rc != RC_OK")
        //R30     strScrapWaferCancelReqResult.strResult = strCassette_lot_Get_out.strResult;
        //R30     return(rc);
        //R30 }
//P3000268 start
        /*------------------------------------------------------------------------*/
        /*   Check Lot is in cassette                                             */
        /*------------------------------------------------------------------------*/
    }//D9000038

//DSIV00001830 add start
    //---------------------------------------
    // Check Bonding Group
    //---------------------------------------
    objLot_bondingGroupID_GetDR_in  strLot_bondingGroupID_GetDR_in;
    strLot_bondingGroupID_GetDR_in.lotID = LotID;

    objLot_bondingGroupID_GetDR_out strLot_bondingGroupID_GetDR_out;
    rc = lot_bondingGroupID_GetDR( strLot_bondingGroupID_GetDR_out, strObjCommonIn, strLot_bondingGroupID_GetDR_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_bondingGroupID_GetDR() rc != RC_OK");
        strScrapWaferCancelReqResult.strResult = strLot_bondingGroupID_GetDR_out.strResult;
        return rc;
    }
    if( CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(strLot_bondingGroupID_GetDR_out.lotID.identifier) > 0");
        PPT_SET_MSG_RC_KEY2( strScrapWaferCancelReqResult,
                             MSG_LOT_HAS_BONDINGGROUP,
                             RC_LOT_HAS_BONDINGGROUP,
                             strLot_bondingGroupID_GetDR_in.lotID.identifier,
                             strLot_bondingGroupID_GetDR_out.bondingGroupID );
        return RC_LOT_HAS_BONDINGGROUP;
    }
//DSIV00001830 add end

    objLot_cassette_Get_out strLot_cassette_Get_out;
    rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn,
                          lotID);
//D9000038 add start
    PPT_METHODTRACE_V2("", "lot_cassette_Get(), rc = ", rc );
    if ( rc == RC_NOT_FOUND_CST )
    {
        PPT_METHODTRACE_V1("", "The input lot is not in a cassette.");
        bMrgLotInCast = FALSE;
        if ( 0 != CIMFWStrLen( inCassetteID.identifier ) )
        {
            PPT_METHODTRACE_V1("", "Invalid Input Cassette ID !!");
            SET_MSG_RC( strScrapWaferCancelReqResult, MSG_INVALID_INPUT_CAST_ID, RC_INVALID_INPUT_CAST_ID );
            return RC_INVALID_INPUT_CAST_ID;
        }
    }
    else if ( rc != RC_OK)
//D9000038 add end
//D9000038        if( rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_cassette_Get() rc != RC_OK");
        strScrapWaferCancelReqResult.strResult = strLot_cassette_Get_out.strResult ;
        return(rc);
    }
//D9000038  add start
    else if ( rc == RC_OK )
    {
//D9000038  add end
        CassetteID = strLot_cassette_Get_out.cassetteID;
        PPT_METHODTRACE_V2("", "CassetteID", CassetteID.identifier);
//D9000038 add start
        if ( 0 != CIMFWStrCmp( CassetteID.identifier, inCassetteID.identifier ) )
        {
            PPT_METHODTRACE_V1("", "Invalid Input Cassette ID !!");
            SET_MSG_RC( strScrapWaferCancelReqResult, MSG_INVALID_INPUT_CAST_ID, RC_INVALID_INPUT_CAST_ID );
            return RC_INVALID_INPUT_CAST_ID;
        }
    }
//D9000038 add end
//P3000268 end
//D9000038    }

//D7000092 add start
    objObject_Lock_out  strObject_Lock_out;

//DSN000071674 add start
    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );

    CORBA::Boolean updateControlJobFlag = FALSE;
    CORBA::Long lockMode = 0; //PSN000083176

    objCassette_transferState_Get_out strCassetteTransferState;

    if ( 0 == lotOperationEIcheck && TRUE == bMrgLotInCast )
    {
        //-------------------------------
        // Get carrier transfer status
        //-------------------------------
        rc = cassette_transferState_Get(strCassetteTransferState, strObjCommonIn,
                                        CassetteID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "rc != RC_OK");
            strScrapWaferCancelReqResult.strResult = strCassetteTransferState.strResult ;
            return( rc );
        }

        /*------------------------------------*/
        /*   Get equipment ID in Cassette     */
        /*------------------------------------*/
        objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
        rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                       strObjCommonIn,
                                       CassetteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "cassette_equipmentID_Get != RC_OK", rc);
            strScrapWaferCancelReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
            return( rc );
        }

        //-------------------------------
        // Get required equipment lock mode
        //-------------------------------
        objObject_lockMode_Get_out strObject_lockMode_Get_out;
        objObject_lockMode_Get_in  strObject_lockMode_Get_in;
        strObject_lockMode_Get_in.objectID           = strCassette_equipmentID_Get_out.equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXDFC003" ); // TxScrapWaferCancelReq
        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strScrapWaferCancelReqResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }

//PSN000083176        CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
        lockMode = strObject_lockMode_Get_out.lockMode; //PSN000083176

        PPT_METHODTRACE_V2( "", "lockMode", lockMode );

        // INN-R170003 if ( 0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) ) 
        // INN-R170003 add start
        if ( 0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) ||
             0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentOut)||
             0 == CIMFWStrCmp(strCassetteTransferState.transferState, CS_TRANS_STATE_PORT_IN) 
           )
        // INN-R170003 add end
        {
            PPT_METHODTRACE_V2("", "strCassetteTransferState.transferState = ", strCassetteTransferState.transferState);
            updateControlJobFlag = TRUE;

            if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
            {
                objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
                objAdvanced_object_Lock_in strAdvanced_object_Lock_in;

                // Lock Equipment Main Object
                stringSequence dummySeq;
                dummySeq.length(0);
                strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
                strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
                strAdvanced_object_Lock_in.keySeq     = dummySeq;

                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strScrapWaferCancelReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }

                // Lock Equipment LoadCassette Element (Write)
                stringSequence loadCastSeq;
                loadCastSeq.length(1);
                loadCastSeq[0] = CassetteID.identifier;
                strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
                strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
                strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strScrapWaferCancelReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }
            }
            else
            {
                /*--------------------------------*/
                /*   Lock Macihne object          */
                /*--------------------------------*/
                rc = object_Lock( strObject_Lock_out, strObjCommonIn, strCassette_equipmentID_Get_out.equipmentID, SP_ClassName_PosMachine );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc) ;
                    strScrapWaferCancelReqResult.strResult = strObject_Lock_out.strResult ;
                    return( rc );
                }
            }
        }

//PSN000083176        if ( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176        {
//PSN000083176            //---------------------------------
//PSN000083176            //   Get Cassette's ControlJobID
//PSN000083176            //---------------------------------
//PSN000083176            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

//PSN000083176            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
//PSN000083176                                            strObjCommonIn,
//PSN000083176                                            CassetteID );
//PSN000083176            if ( rc != RC_OK )
//PSN000083176            {
//PSN000083176                PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
//PSN000083176                strScrapWaferCancelReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
//PSN000083176                return( rc );
//PSN000083176            }
//PSN000083176            if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
//PSN000083176            {
//PSN000083176                PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
//PSN000083176                updateControlJobFlag = TRUE;

//PSN000083176                if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176                {
//PSN000083176                    /*------------------------------*/
//PSN000083176                    /*   Lock ControlJob Object     */
//PSN000083176                    /*------------------------------*/
//PSN000083176                    rc = object_Lock( strObject_Lock_out,
//PSN000083176                                      strObjCommonIn, 
//PSN000083176                                      strCassette_controlJobID_Get_out.controlJobID, 
//PSN000083176                                      SP_ClassName_PosControlJob );
//PSN000083176                    if ( rc != RC_OK )
//PSN000083176                    {
//PSN000083176                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
//PSN000083176                        strScrapWaferCancelReqResult.strResult = strObject_Lock_out.strResult;
//PSN000083176                        return( rc );
//PSN000083176                    }
//PSN000083176                }
//PSN000083176            }
//PSN000083176        }
    }
//DSN000071674 add end

    rc = object_Lock(strObject_Lock_out, strObjCommonIn, CassetteID, SP_ClassName_PosCassette);
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
        strScrapWaferCancelReqResult.strResult = strObject_Lock_out.strResult;
        return( rc );
    }
//D7000092 add end

//PSN000083176 add start
    if ( 0 == lotOperationEIcheck && TRUE == bMrgLotInCast )
    {
        if ( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
        {
            //---------------------------------
            //   Get Cassette's ControlJobID
            //---------------------------------
            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                            strObjCommonIn,
                                            CassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
                strScrapWaferCancelReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
                return( rc );
            }
            if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
            {
                PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
                updateControlJobFlag = TRUE;

                if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
                {
                    /*------------------------------*/
                    /*   Lock ControlJob Object     */
                    /*------------------------------*/
                    rc = object_Lock( strObject_Lock_out,
                                      strObjCommonIn, 
                                      strCassette_controlJobID_Get_out.controlJobID, 
                                      SP_ClassName_PosControlJob );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                        strScrapWaferCancelReqResult.strResult = strObject_Lock_out.strResult;
                        return( rc );
                    }
                }
            }
        }
    }
//PSN000083176 add end

    //P4200314 Add Start
    //----------------------------------------------------------
    // Check Wafer is in Cassette
    //----------------------------------------------------------
    objWafer_LotCassette_Get_out strWafer_LotCassette_Get_out;
    CORBA::Long scrapCancelWaferLen = strScrapCancelWafers.length();
    CORBA::Long jj;
//D9000038 add start
    CORBA::Boolean bValidCastComb = TRUE;
    CORBA::Boolean bScrapInCast   = TRUE;
//D9000038 add end

    PPT_METHODTRACE_V2("","ScrapCancelWafer Quantity",scrapCancelWaferLen);
    for ( jj = 0; jj < scrapCancelWaferLen; jj++ )
    {
        //-----------------------------------------
        // Get cassetteID strScrapCancelWafers[jj]
        // For Check of Wafer is in Cassette
        //-----------------------------------------
        PPT_METHODTRACE_V3("","ScrapCancelWaferID",jj, strScrapCancelWafers[jj].waferID.identifier);

        rc = wafer_LotCassette_Get( strWafer_LotCassette_Get_out, strObjCommonIn, strScrapCancelWafers[jj].waferID );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "wafer_LotCassette_Get() rc != RC_OK");
            strScrapWaferCancelReqResult.strResult = strWafer_LotCassette_Get_out.strResult;
            return(rc);
        }

        PPT_METHODTRACE_V2("","strWafer_LotCassette_Get_out.cassetteID",strWafer_LotCassette_Get_out.cassetteID.identifier);


        if (CIMFWStrLen( strWafer_LotCassette_Get_out.cassetteID.identifier ) == 0)
        {
            PPT_METHODTRACE_V1("", "Scrap Cancel Wafer is not in Cassette!!!");

//D9000038            PPT_SET_MSG_RC_KEY( strScrapWaferCancelReqResult, MSG_WAFER_IS_NOT_IN_CASSETTE, RC_WAFER_IS_NOT_IN_CASSETTE,
//D9000038                                strScrapCancelWafers[jj].waferID.identifier );
//D9000038            return ( RC_WAFER_IS_NOT_IN_CASSETTE );
            bScrapInCast = FALSE; //D9000038
        }

        //D9000038 add start
        //-----------------------------------------------------------------------//
        // Check the cassette combination of scrap-cancel wafers and merged lot. //
        //-----------------------------------------------------------------------//
        if ( bMrgLotInCast == TRUE )
        {
            PPT_METHODTRACE_V1("", " bMrgLotInCast == TRUE");
            if ( bScrapInCast == FALSE )
            {
                PPT_METHODTRACE_V1("", " bMrgLotInCast == TRUE && bScrapInCast == FALSE.");
                bValidCastComb = FALSE;
            }
            else if ( 0 != CIMFWStrCmp( CassetteID.identifier, strWafer_LotCassette_Get_out.cassetteID.identifier ) )
            {
                PPT_METHODTRACE_V1("", " bMrgLotInCast == TRUE && bScrapInCast == TRUE, but NOT in an identical cassette.");
                bValidCastComb = FALSE;
            }
        }
        else if ( bMrgLotInCast == FALSE )
        {
            PPT_METHODTRACE_V1("", " bMrgLotInCast == FALSE");
            if ( bScrapInCast == TRUE )
            {
                PPT_METHODTRACE_V1("", " bMrgLotInCast == FALSE && bScrapInCast == TRUE.");
                bValidCastComb = FALSE;
            }
        }

        if ( bValidCastComb == FALSE )
        {
            PPT_METHODTRACE_V1("", "#################################");
            PPT_METHODTRACE_V1("", "##  bValidCastComb is FALSE !! ##");
            PPT_METHODTRACE_V1("", "#################################");

            SET_MSG_RC( strScrapWaferCancelReqResult,
                        MSG_INVALID_CASSETTE_COMBINATION,
                         RC_INVALID_CASSETTE_COMBINATION );
            return RC_INVALID_CASSETTE_COMBINATION;
        }
        else if ( bValidCastComb == TRUE )
        {
            PPT_METHODTRACE_V1("", "*** bValidCastComb is TRUE. ***");
        }
        //D9000038 add end
    }
    //P4200314 Add End

//D9000056 add start
    PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
    //----------------------------------
    //  Get InPostProcessFlag of Lot
    //----------------------------------
    objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
    objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
    strLot_inPostProcessFlag_Get_in.lotID = lotID;

    rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                    strObjCommonIn,
                                    strLot_inPostProcessFlag_Get_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
        strScrapWaferCancelReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
        return( rc );
    }

    //----------------------------------------------
    //  If Lot is in post process, returns error
    //----------------------------------------------
    if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
    {
        PPT_METHODTRACE_V1("", "Lot is in post process.");
//DSIV00000201 Add Start
        /*---------------------------*/
        /* Get UserGroupID By UserID */
        /*---------------------------*/
        objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
        rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                         strObjCommonIn,
                                         strObjCommonIn.strUser.userID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
            strScrapWaferCancelReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
            return( rc );
        }
        objectIdentifierSequence userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
        CORBA::ULong userGroupIDsLen = userGroupIDs.length();
        PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);
        
        CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
        PPT_METHODTRACE_V2("", "extPostProc", extPostProc);
        
        CORBA::ULong nCnt = 0;
        for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
        {
            PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
            if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
            {
                PPT_METHODTRACE_V1("", "# External Post Process User!");
                break;
            }
            
        }
        if (nCnt == userGroupIDsLen)
        {
            PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
            PPT_SET_MSG_RC_KEY( strScrapWaferCancelReqResult,
                                MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                lotID.identifier );
            return( RC_LOT_INPOSTPROCESS );
        }   //DSIV00000201
    }
//D9000056 add end

    /*------------------------------------------------------------------------*/
    /*   Check conditions of the Lot                                          */
    /*                                                                        */
    /*      strScrapCancelWafers.lotID are same in the input array.           */
    /*      Use first array's strScrapCancelWafers.lotID as an input of the   */
    /*      following ObjectMethod call ... (A),(B),(C),(D),(E),(F)           */
    /*------------------------------------------------------------------------*/
    /**=================(A)====================**/
    /** LotStatus should be Active or Finished **/
    /**========================================**/

    objLot_state_Get_out strLot_state_Get_out;
    rc = lot_state_Get(strLot_state_Get_out,strObjCommonIn,lotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq ", "rc != RC_OK")
        strScrapWaferCancelReqResult.strResult = strLot_state_Get_out.strResult;
        return(rc);
    }
    else if(!((CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Finished) == 0)||
              (CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Active)   == 0)  ))
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq ", "CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_*)")
        PPT_SET_MSG_RC_KEY(strScrapWaferCancelReqResult,MSG_INVALID_LOT_STAT,RC_INVALID_LOT_STAT,
                           strLot_state_Get_out.lotState)
        return(RC_INVALID_LOT_STAT);
    }

    /**=================(C)===================**/
    /** ProcessState should not be Processing **/
    /**=======================================**/

    objLot_processState_Get_out strLot_processState_Get_out;
    rc = lot_processState_Get(strLot_processState_Get_out,strObjCommonIn,lotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq ", "rc != RC_OK")
        strScrapWaferCancelReqResult.strResult = strLot_processState_Get_out.strResult;
        return(rc);
    }
    else if ((CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Processing)) == 0 )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq ", "(CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState,SP_Lot_ProcState_Processing)) == 0 ")
//P4100425 start
        PPT_SET_MSG_RC_KEY2( strScrapWaferCancelReqResult,
                             MSG_INVALID_LOT_PROCSTAT, RC_INVALID_LOT_PROCSTAT,
                             lotID.identifier,
                             strLot_processState_Get_out.theLotProcessState );
//P4100425 end
//P4100425        PPT_SET_MSG_RC_KEY(strScrapWaferCancelReqResult,MSG_INVALID_LOT_PROCSTAT,RC_INVALID_LOT_PROCSTAT,
//P4100425                           strLot_processState_Get_out.theLotProcessState)
        return(RC_INVALID_LOT_PROCSTAT);
    }

//P4200267 add start
    /*-----------------------------------*/
    /*   Check Backup Info               */
    /*-----------------------------------*/
    objLot_backupInfo_Get_out strLot_backupInfo_Get_out;
    rc = lot_backupInfo_Get( strLot_backupInfo_Get_out, strObjCommonIn, lotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", " lot_backupInfo_Get() rc != RC_OK");
        strScrapWaferCancelReqResult.strResult = strLot_backupInfo_Get_out.strResult ;
        return( rc );
    }
    else if ( strLot_backupInfo_Get_out.strLotBackupInfo.currentLocationFlag == FALSE ||
              strLot_backupInfo_Get_out.strLotBackupInfo.transferFlag == TRUE )
    {
        PPT_METHODTRACE_V1("", "##### backup condition is invalid.");
        PPT_SET_MSG_RC_KEY( strScrapWaferCancelReqResult,
                            MSG_LOT_IN_OTHERSITE,
                            RC_LOT_IN_OTHERSITE,
                            lotID.identifier );
        return( RC_LOT_IN_OTHERSITE );
    }
//P4200267 add end

//DSN000071674 add start
    if ( 1 == lotOperationEIcheck )
    {
        PPT_METHODTRACE_V1("", "lotOperationEIcheck = 1");
//DSN000071674 add end
        /**=================(D)===================**/
        /** DispatchState should be NO            **/
        /**=======================================**/
//D9000038 add start
        if( bMrgLotInCast == TRUE )
        {
//D9000038 add end
            objCassette_dispatchState_Get_out strCassette_dispatchState_Get_out ;
            strCassette_dispatchState_Get_out.dispatchReservedFlag = FALSE; //P3000280
            rc = cassette_dispatchState_Get( strCassette_dispatchState_Get_out,
                                             strObjCommonIn,
                                             CassetteID );
            if (rc != RC_OK)
            {
               PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq", "rc != RC_OK")
               strScrapWaferCancelReqResult.strResult = strCassette_dispatchState_Get_out.strResult ;
               return( rc );
            }
            else if (strCassette_dispatchState_Get_out.dispatchReservedFlag == TRUE)
            {
               // Required to differ from the PC.
               PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq", "strCassette_dispatchState_Get_out.dispatchReservedFlag == TRUE")
               SET_MSG_RC(strScrapWaferCancelReqResult, MSG_INVALID_CAST_DISPATCH_STAT, RC_INVALID_CAST_DISPATCH_STAT)
               return( RC_INVALID_CAST_DISPATCH_STAT );
            }
//D9000038 add start
        }
        else
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i::txScrapWaferCancelReq", "The cassetteID is empty. Skip cassette_dispatchState_Get().");
        }
//D9000038 add end
    } //DSN000071674

    objCassette_transferState_Get_out strCassette_transferState_Get_out;  //DSN000071674

    /**=================(E)====================**/
    /** TransferState should be EO/MO/IO/HO/AO **/
    /**========================================**/
//D9000038 add start
    if( bMrgLotInCast == TRUE )
    {
//D9000038 add end
//DSN000071674        objCassette_transferState_Get_out strCassette_transferState_Get_out;
//DSN000071674 add start
        // INN-R170003 if ( 1 == lotOperationEIcheck 
        // INN-R170003 || ( 0 == lotOperationEIcheck && 0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) ) ) 
        // INN-R170003 add start
        if ( 1 == lotOperationEIcheck 
             || ( 0 == lotOperationEIcheck && (    0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) 
                                                || 0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentOut)
                                                || 0 != CIMFWStrCmp(strCassetteTransferState.transferState, CS_TRANS_STATE_PORT_IN)
                                               ) 
           ))
        //INN-R170003 add end
        {
//DSN000071674 add end
            PPT_METHODTRACE_V2("", "strCassetteTransferState.transferState = ", strCassetteTransferState.transferState);
            rc = cassette_transferState_Get(strCassette_transferState_Get_out,strObjCommonIn,CassetteID);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq ", "rc != RC_OK")
                strScrapWaferCancelReqResult.strResult = strCassette_transferState_Get_out.strResult;
                return(rc);
            }
//DSN000071674 add start
            if ( 0 == lotOperationEIcheck )
            {
                PPT_METHODTRACE_V1("", "lotOperationEIcheck = 0");
                //INN-R170003 if ( 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) ) //D4100091   
                //INN-R170003 add start
                if (   0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) 
                    || 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentOut) 
                    || 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, CS_TRANS_STATE_PORT_IN) 
                   )
                // INN-R170003 add end    
                
                {
                    PPT_METHODTRACE_V1("","Changed to EI by other operation");
                    PPT_METHODTRACE_V2("", "strCassette_transferState_Get_out.transferState = ", strCassette_transferState_Get_out.transferState);
                    strScrapWaferCancelReqResult.strResult = strCassette_transferState_Get_out.strResult ;
                    PPT_SET_MSG_RC_KEY(strScrapWaferCancelReqResult, MSG_CHANGED_TO_EI_BY_OTHER_OPERATION, RC_CHANGED_TO_EI_BY_OTHER_OPERATION,
                                       CassetteID.identifier);
                    return( RC_CHANGED_TO_EI_BY_OTHER_OPERATION );
                }
            }
//DSN000071674 add end
//P4000079    else if(!((CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_EquipmentOut))      == 0 ||
//P4000079             (CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_ManualOut))          == 0 ||
//P4000079             (CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_IntermediateOut))    == 0 ||
//P4000079             (CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_ShelfOut))           == 0 ||
//P4000079             (CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_UNDEFINED_STATE))               == 0 ||
//P4000079             (CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_AbnormalOut))        == 0 ||
//P4000079             (CIMFWStrCmp(strCassette_transferState_Get_out.transferState,SP_TransState_StationOut))        == 0 )  )       //P4000037
            // INN-R170003  else if (CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_BayOut    ) == 0 ||  
            // INN-R170003        CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0)              //P4000079 
            // INN-R170003 add start
            else if ( CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_BayOut    ) == 0 || 
                      CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 ||
                      CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentOut) == 0 ||
                      CIMFWStrCmp(strCassette_transferState_Get_out.transferState, CS_TRANS_STATE_PORT_IN) == 0 
                     )
            //INN-R170003 add end         
            {
                PPT_METHODTRACE_V2("", "strCassette_transferState_Get_out.transferState = ", strCassette_transferState_Get_out.transferState);
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq ", "CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_Lot_TransState_*)")
                PPT_SET_MSG_RC_KEY2(strScrapWaferCancelReqResult,MSG_INVALID_LOT_XFERSTAT, RC_INVALID_LOT_XFERSTAT,
                                    CassetteID.identifier,strCassette_transferState_Get_out.transferState)

                return(RC_INVALID_LOT_XFERSTAT);
            }
//DSN000071674 add start
        }
        if ( 0 == lotOperationEIcheck )
        {
            strCassette_transferState_Get_out = strCassetteTransferState;
        }
//DSN000071674 add end
//D9000038 add start
    }
    else
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i::txScrapWaferCancelReq", "The cassetteID is empty. Skip cassette_transferState_Get().");
    }
//D9000038 add end

    /**==================(F)==============================**/
    /** Check this Lot contents are 'Wafer style' product **/
    /**===================================================**/

    objLot_contents_Get_out strLot_contents_Get_out;
    rc = lot_contents_Get(strLot_contents_Get_out,strObjCommonIn,lotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq ", "rc != RC_OK")
        strScrapWaferCancelReqResult.strResult = strLot_contents_Get_out.strResult;
        return(rc);
    }
    else if ((CIMFWStrCmp(strLot_contents_Get_out.theLotContents,SP_ProdType_Wafer)) != 0 )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq ", "(CIMFWStrCmp(strLot_contents_Get_out.theLotContents,SP_ProdType_Wafer)) != 0 ")
        PPT_SET_MSG_RC_KEY(strScrapWaferCancelReqResult,MSG_INVALID_LOT_CONTENTS, RC_INVALID_LOT_CONTENTS,
                           lotID.identifier)

        return(RC_INVALID_LOT_CONTENTS);
    }

//D4100036 start
    /*-------------------------------*/
    /*   Check FlowBatch Condition   */
    /*-------------------------------*/
    PPT_METHODTRACE_V1("", "Check FlowBatch Condition") ;
    objLot_flowBatchID_Get_out strLot_flowBatchID_Get_out;
    rc = lot_flowBatchID_Get( strLot_flowBatchID_Get_out, strObjCommonIn, lotID );

    if ( rc == RC_LOT_FLOW_BATCH_ID_FILLED )
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() == RC_LOT_BATCH_ID_BLANK") ;
//P5000145        PPT_SET_MSG_RC_KEY( strScrapWaferCancelReqResult, MSG_FLOW_BATCH_LIMITATION, RC_FLOW_BATCH_LIMITATION, "");
        SET_MSG_RC( strScrapWaferCancelReqResult, MSG_FLOW_BATCH_LIMITATION, RC_FLOW_BATCH_LIMITATION );        //P5000145
        return RC_FLOW_BATCH_LIMITATION;
    }
    else if ( rc == RC_LOT_FLOW_BATCH_ID_BLANK )
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() == RC_LOT_BATCH_ID_BLANK") ;
    }
    else
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() != RC_OK") ;
        strScrapWaferCancelReqResult.strResult = strLot_flowBatchID_Get_out.strResult ;
        return( rc );
    }
//D4100036 end

//Q3000147 add start
    /*----------------------------------*/
    /*   Check Lot's Control Job ID     */
    /*----------------------------------*/
    objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, lotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq", "lot_controlJobID_Get() != RC_OK");
        strScrapWaferCancelReqResult.strResult = strLot_controlJobID_Get_out.strResult ;
        return(rc);
    }
    if (CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) == 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq", "CIMFWStrLen(controlJobID.identifier) = 0") ;
        rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq", "CIMFWStrLen(controlJobID.identifier) > 0") ;
        PPT_SET_MSG_RC_KEY2( strScrapWaferCancelReqResult,
                             MSG_LOT_CTLJOBID_FILLED,
                             RC_LOT_CTLJOBID_FILLED,
                             lotID.identifier,
                             strLot_controlJobID_Get_out.controlJobID.identifier ) ;
        return( RC_LOT_CTLJOBID_FILLED );
    }
//Q3000147 add end

    /*------------------------------------------------------------------------*/
    /*   Check if all claimed reasons are correct                             */
    /*------------------------------------------------------------------------*/

    CORBA::Long seqLen = strScrapCancelWafers.length();
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txScrapWaferCancelReq ", "strScrapCancelWafers.length()", seqLen)
    pptCheckedCodesSequence strCheckedCodes(seqLen);
    strCheckedCodes.length(seqLen);

    for (CORBA::Long i =0; i < seqLen ; i++)
    {
        strCheckedCodes[i].codeDataID = strScrapCancelWafers[i].reasonCodeID;
    }

//P3100007    objCode_CheckExistance_out strCode_CheckExistance_out;
    objCode_CheckExistanceDR_out strCode_CheckExistanceDR_out;  //P3100007
//P3100007    rc = code_CheckExistanceDR(strCode_CheckExistance_out,strObjCommonIn,SP_OperationCategory_WaferScrapCancel,strCheckedCodes);
    rc = code_CheckExistanceDR(strCode_CheckExistanceDR_out,strObjCommonIn,SP_OperationCategory_WaferScrapCancel,strCheckedCodes);  //P3100007
    if (rc == RC_NOT_FOUND_CODE)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq ", "rc == RC_NOT_FOUND_CODE")
        PPT_SET_MSG_RC_KEY2(strScrapWaferCancelReqResult,MSG_NOT_FOUND_CODE, RC_NOT_FOUND_CODE,
                            SP_OperationCategory_WaferScrapCancel, "*****")
        return (RC_NOT_FOUND_CODE);
    }
    else if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq ", "rc != RC_OK")
//P3100007        strScrapWaferCancelReqResult.strResult = strCode_CheckExistance_out.strResult;
        strScrapWaferCancelReqResult.strResult = strCode_CheckExistanceDR_out.strResult;  //P3100007
        return(rc);
    }
//D6000256 : The logic which checks duration was moved forward. This logic should be applied at All Scrap case only.
//D6000256//D4000243 add start
//D6000256    objLot_CheckDurationForOperation_out strLot_CheckDurationForOperation_out;
//D6000256    rc = lot_CheckDurationForOperation(strLot_CheckDurationForOperation_out,
//D6000256                                       strObjCommonIn,
//D6000256                                       lotID);
//D6000256
//D6000256    if ( rc != RC_OK)
//D6000256    {
//D6000256        PPT_METHODTRACE_V1("", "rc != RC_OK");
//D6000256        strScrapWaferCancelReqResult.strResult = strLot_CheckDurationForOperation_out.strResult;
//D6000256        return ( rc );
//D6000256    }
//D6000256
//D6000256    if ( strLot_CheckDurationForOperation_out.bOperableFlag == FALSE )
//D6000256    {
//D6000256        PPT_METHODTRACE_V1("", "strLot_CheckDurationForOperation_out.bOperableFlag == FALSE");
//D6000256        SET_MSG_RC(strScrapWaferCancelReqResult,
//D6000256                   MSG_RESERVED_BY_DELETION_PROGRAM,
//D6000256                   RC_RESERVED_BY_DELETION_PROGRAM);
//D6000256        return RC_RESERVED_BY_DELETION_PROGRAM ;
//D6000256    }
//D6000256
//D6000256    PPT_METHODTRACE_V1("", "strLot_CheckDurationForOperation_out.bOperableFlag == TRUE");
//D6000256//D4000243 add end

    /*------------------------------------------------------------------------*/
    /*   Do Wafer Scrap Cancel                                                */
    /*------------------------------------------------------------------------*/

    objLot_materials_ScrapCancelByWafer_out strLot_materials_ScrapCancelByWafer_out;
    rc = lot_materials_ScrapCancelByWafer(strLot_materials_ScrapCancelByWafer_out,
                                         strObjCommonIn,LotID,CassetteID,strScrapCancelWafers);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("CS_PPTManager_i:: txScrapWaferCancelReq ", "rc != RC_OK", i)
        strScrapWaferCancelReqResult.strResult = strLot_materials_ScrapCancelByWafer_out.strResult;
        return(rc);
    }

//P4000014 add start
    /*---------------------------------------*/
    /*   Update Cassette's MultiLotType      */
    /*---------------------------------------*/
//D9000038 add start
    if( bMrgLotInCast == TRUE )
    {
//DSN000071674 add start
        if ( TRUE == updateControlJobFlag )
        {
            //----------------------
            // Update control Job Info and
            // Machine Cassette info if information exist
            //----------------------
            objectIdentifierSequence tmpCassetteIDSeq;
            tmpCassetteIDSeq.length(1);
            tmpCassetteIDSeq[0] = CassetteID;
            objControlJob_relatedInfo_Update_out strControlJob_relatedInfo_Update_out;
            rc = controlJob_relatedInfo_Update(strControlJob_relatedInfo_Update_out, strObjCommonIn,
                                               tmpCassetteIDSeq);
            if (rc)
            {
                PPT_METHODTRACE_V2("", "controlJob_relatedInfo_Update() != RC_OK", rc);
                strScrapWaferCancelReqResult.strResult = strControlJob_relatedInfo_Update_out.strResult;
                return(rc);
            }
        }
//DSN000071674 add end

//D9000038 add end
        objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
        rc = cassette_multiLotType_Update( strCassette_multiLotType_Update_out, strObjCommonIn, CassetteID );
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "cassette_multiLotType_Update() != RC_OK") ;
            strScrapWaferCancelReqResult.strResult = strCassette_multiLotType_Update_out.strResult ;
            return(rc);
        }
//D9000038 add start
    }
    else
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i::txScrapWaferCancelReq", "The cassetteID is empty. Skip cassette_multiLotType_Update().");
    }
//D9000038 add end
//P4000014 add end

    /**========================================**/
    /** PosLot WaferHis pointer update         **/
    /**========================================**/

    objLot_waferLotHistoryPointer_Update_out strLot_waferLotHistoryPointer_Update_out;

    rc = lot_waferLotHistoryPointer_Update(strLot_waferLotHistoryPointer_Update_out, strObjCommonIn,lotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq ", "rc != RC_OK")
//P5000145        PPT_SET_MSG_RC_KEY(strScrapWaferCancelReqResult, MSG_FAIL_MAKE_HISTORY, rc, lotID.identifier)
        SET_MSG_RC( strScrapWaferCancelReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145
        return(rc);
    }

//D4200229//D4200029 Add Start
//D4200229    if( allScrapFlag == TRUE )
//D4200229    {
//D4200229        //-----------------------//
//D4200229        //     Process Hold      //
//D4200229        //-----------------------//
//D4200229        PPT_METHODTRACE_V1("","Call txProcessHoldExecReq()");
//D4200229        pptProcessHoldExecReqResult strProcessHoldExecReqResult;
//D4200229
//D4200229        rc = txProcessHoldExecReq( strProcessHoldExecReqResult,
//D4200229                                   strObjCommonIn,
//D4200229                                   lotID,
//D4200229                                   claimMemo );
//D4200229
//D4200229        if ( rc != RC_OK )
//D4200229        {
//D4200229            PPT_METHODTRACE_V2("","txProcessHoldExecReq() != RC_OK", rc );
//D4200229            strScrapWaferCancelReqResult.strResult = strProcessHoldExecReqResult.strResult ;
//D4200229            return( rc );
//D4200229        }
//D4200229    }
//D4200229//D4200029 Add End

    /**========================================**/
    /** Create Operation History               **/
    /**========================================**/

    objLotWaferScrapEvent_Make_out strLotWaferScrapEvent_Make_out;

    objectIdentifier reasonRouteID ;
    objectIdentifier reasonOperationID ;
    char *reasonOperationNumber = NULL ;
    char *reasonOperationPass   = NULL ;

    CORBA::Long nlen = strScrapCancelWafers.length() ;
    pptScrapWafersSequence strScrapWafers(nlen) ;
    strScrapWafers.length(nlen);

//D9000001    for (long ii=0;ii<nlen;ii++)
    for (CORBA::Long ii=0;ii<nlen;ii++)    //D9000001
    {
        strScrapWafers[ii].waferID      = strScrapCancelWafers[ii].waferID;
        strScrapWafers[ii].reasonCodeID = strScrapCancelWafers[ii].reasonCodeID;
    }

    rc = lotWaferScrapEvent_Make(strLotWaferScrapEvent_Make_out, strObjCommonIn, "TXDFC003", LotID, CassetteID, reasonRouteID,
                                 reasonOperationID, reasonOperationNumber, reasonOperationPass, strScrapWafers,claimMemo);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txScrapWaferCancelReq ", "rc != RC_OK")
//P5000145        PPT_SET_MSG_RC_KEY(strScrapWaferCancelReqResult, MSG_FAIL_MAKE_HISTORY, rc, LotID.identifier)
        SET_MSG_RC( strScrapWaferCancelReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145
        return(rc);
    }

    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
    SET_MSG_RC(strScrapWaferCancelReqResult, MSG_OK, RC_OK) ;    //P3000139
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txScrapWaferCancelReq ")
    return(RC_OK);
}


