#ifndef lint
static char *sccsid =  "@(#) 1.7 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txStartLotsReservationReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/15/07 16:00:57 [ 11/15/07 16:00:58 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2012. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2012. All rights reserved.
//
// SiView
// Name: cs_txStartLotsReservationReqOR.cpp
//

//INN-A170001 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp" //INN-A170001

#include <unistd.h>

extern void traceSampledStartCassette( const pptStartCassetteSequence& strStartCassette );    //D9000003 for Cassette trace


//=============================================================================
// For TXTRC041 : txStartLotsReservationReq
//=============================================================================
// Class: CS_PPTManager
//
// Service: txStartLotsReservationReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/04          O.Sugiyama     Initial Release
// 2000/09/12 0.01     Y.Iwasaki      Bug fix (set created controlJobID)
// 2000-09-16 P3000185 Y.Iwasaki      Add comment
// 2000-09-26 0.02     Y.Iwasaki      Bug fix for TCSMgr_Send...'s parameter
// 2000-10-30 D3000079 Y.Iwasaki      Change comment of cassette_CheckConditionForOperation
//                                    (Logic no-change)
// 2001-04-17 P3100289 K.Matsuei      Change comment of cassette_CheckConditionForOperation
//                                    (Logic no-change)
// 2001-07-05 D4000015 H.Katoh        Add Check Logic of Equipment Category because of
//                                    Internal Buffer Support
// 2001-07-02 D4000016 M.Shimizu      Contamination Control(Copper/Non Copper [R40 Core])
// 2001-08-09 D4000048 M.Ameshita     Reticle set support                    [R40 Core]
// 2001/09/07 D4000060 K.Kido         Add retry TCS request logic
// 2001-09-21 P4000228 M.Shimizu      doesn't check empty carrier's contamination statuses when start lot reservation
// 2001/12/05 P4100018 M.Shimizu      Add LogicalScrap Check(Except loadPurposeType=Other carrier)
// 2002/02/05 P4100102 N.Maeda        Add Add a logic for skip a contamination check logic when a lot in a cassette doesn't have a true opestart Flag.
// 2003/11/05 D5100041 H.Adachi       Enhancement of EqpObject Lock.( Remove Object Lock for EQP.)
// 2004/08/11 D51M0000 K.Tachibana    APC I/F Enhance for Interface Spec-B
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2005/09/09 D6000418 M.Murata       Lock Port Object.
// 2005/10/31 D7000006 T.Ohsaki       exchange "controlJob_Create()" and "controlJob_status_Change()" to "txControlJobManageReq()"
// 2006/01/20 D7000182 H.Mutoh        Enhancement of re-sending APCControlJobInformation.
// 2006/04/03 D7000041 K.Matsuei      Need to check empty carrier's category on next operation.
// 2006/07/27 D7000265 K.Kido         Restore machine object lock. (The lock timing is moved after APC interface)
// 2006/11/21 D8000024 Y.Kadowaki     Flexible Process Condition Change (R80)
// 2007/04/02 D8000207 M.Murata       Add changing logic processJobExecFlag.
// 2007/04/20 D9000001 H.Murakami     64bit support.
// 2007/06/01 D9000003 M.Nakano       Remove changing logic processJobExecFlag, add check logic and modify regist logic for processJobExecFlag of startCassette.
// 2007/07/10 P9000022 M.Murata       Fix logic for Recipe Body Management.
// 2007/09/20 D9000079 D.Tamura       FlowBatch Enhancement.
// 2008/06/24 DSIV00000099 K.Matsuei  SLM(Small Lot Manufacturing) Support.
// 2010/04/16 DSIV00001830 R.Okano    Wafer Stacking Operation Support.
// 2012/11/27 DSN000049350 F.Chen     Equipment parallel processing support (P2)
//
// Innotron Modification history :
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
// 2017/09/08 INN-R170002 JJ.Zhang       Contamination Control
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptStartLotsReservationReqResult&   strStartLotsReservationReqResult,
//     const pptObjCommonIn&               strObjCommonIn,
//     const objectIdentifier&             equipmentID,
//     const char *                        portGroupID,
//     const objectIdentifier&             controlJobID,
//     const pptStartCassetteSequence&     strStartCassette,
//     const char *                        claimMemo,
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::txStartLotsReservationReq(
    pptStartLotsReservationReqResult&   strStartLotsReservationReqResult,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             equipmentID,
    const char *                        portGroupID,
    const objectIdentifier&             controlJobID,
    const pptStartCassetteSequence&     strStartCassette,
//D6000025     const char *                        claimMemo,
//D6000025     CORBA::Environment &                IT_env)
//D7000182    const char *                        claimMemo  //D6000025
    const char *                        claimMemo,           //D7000182
    char *&                             APCIFControlStatus   //D7000182
    CORBAENV_LAST_CPP)                             //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txStartLotsReservationReq");
    CORBA::Long rc = RC_OK ;
    pptStartCassetteSequence     tmpStartCassette;
    tmpStartCassette = strStartCassette;

    traceSampledStartCassette( tmpStartCassette );  //D9000003

//D7000265    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
//D7000265    /*                                                                       */
//D7000265    /*   Object Lock Process                                                 */
//D7000265    /*                                                                       */
//D7000265    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
//D7000265    PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationReq", "Check Process..." );
//D7000265
//D7000265//D6000418 add start
    CORBA::Long lenCassette = strStartCassette.length();
    if ( 0>= lenCassette )
    {
        PPT_METHODTRACE_V1("", "0>= CIMFWStrLen(strStartCassette.length())");
        SET_MSG_RC(strStartLotsReservationReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM) ;
        return( RC_INVALID_INPUT_PARM );
    }

//D7000265    /*--------------------------------------------*/
//D7000265    /*                                            */
//D7000265    /*        Port Object Lock Process            */
//D7000265    /*                                            */
//D7000265    /*--------------------------------------------*/
//D7000265    PPT_METHODTRACE_V1("", "#### Port Object Lock ");
//D7000265    /*--------------------------------------------------------*/
//D7000265    /*   Get All Ports being in the same Port Group as ToPort */
//D7000265    /*--------------------------------------------------------*/
//D7000265    objPortResource_allPortsInSameGroup_Get_out strPortResource_allPortsInSameGroup_Get_out;
//D7000265    rc = portResource_allPortsInSameGroup_Get( strPortResource_allPortsInSameGroup_Get_out,
//D7000265                                               strObjCommonIn,
//D7000265                                               equipmentID,
//D7000265                                               strStartCassette[0].loadPortID );
//D7000265    if ( rc != RC_OK )
//D7000265    {
//D7000265        PPT_METHODTRACE_V2("", "portResource_allPortsInSameGroup_Get() rc != RC_OK", rc);
//D7000265        strStartLotsReservationReqResult.strResult = strPortResource_allPortsInSameGroup_Get_out.strResult;
//D7000265        return( rc );
//D7000265    }
//D7000265
//D7000265    /*---------------------------------------------------------*/
//D7000265    /* Lock All Ports being in the same Port Group as ToPort   */
//D7000265    /*---------------------------------------------------------*/
//D7000265    CORBA::Long lenToPort = strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus.length();
//D7000265    for ( CORBA::Long kk =0 ; kk < lenToPort ; kk++ )
//D7000265    {
//D7000265        objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
//D7000265        rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
//D7000265                                              strObjCommonIn,
//D7000265                                              equipmentID,
//D7000265                                              strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[kk].portID,
//D7000265                                              SP_ClassName_PosPortResource );
//D7000265        if ( rc != RC_OK )
//D7000265        {
//D7000265            PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[kk].portID.identifier) ;
//D7000265            strStartLotsReservationReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
//D7000265            return( rc );
//D7000265        }
//D7000265        PPT_METHODTRACE_V2("", "Locked port object  : ", strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[kk].portID.identifier) ;
//D7000265    }
//D7000265//D6000418 add end
//D7000265
//D7000265    objObject_Lock_out strObject_Lock_out;
//D7000265
//D7000265//D5100041    rc = object_Lock( strObject_Lock_out, strObjCommonIn, equipmentID, SP_ClassName_PosMachine );
//D7000265//D5100041    if ( rc != RC_OK )
//D7000265//D5100041    {
//D7000265//D5100041        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationReq", "object_Lock() != RC_OK" );
//D7000265//D5100041        strStartLotsReservationReqResult.strResult = strObject_Lock_out.strResult;
//D7000265//D5100041        return( rc );
//D7000265//D5100041    }
//D7000265
//D7000265    CORBA::Long i     = 0;
//D7000265    CORBA::Long nILen = tmpStartCassette.length();
//D7000265    PPT_METHODTRACE_V2( "CS_PPTManager_i:: txStartLotsReservationReq", "nILen", nILen);
//D7000265    for ( i=0 ; i<nILen ; i++ )
//D7000265    {
//D7000265        rc = object_Lock( strObject_Lock_out, strObjCommonIn, tmpStartCassette[i].cassetteID,
//D7000265                          SP_ClassName_PosCassette );
//D7000265        if ( rc != RC_OK )
//D7000265        {
//D7000265            PPT_METHODTRACE_V2( "CS_PPTManager_i:: txStartLotsReservationReq", "object_Lock() != RC_OK", i );
//D7000265            strStartLotsReservationReqResult.strResult = strObject_Lock_out.strResult;
//D7000265            return( rc );
//D7000265        }
//D7000265
//D7000265        CORBA::Long j     = 0;
//D7000265        CORBA::Long nJLen = tmpStartCassette[i].strLotInCassette.length();
//D7000265        PPT_METHODTRACE_V3( "CS_PPTManager_i:: txStartLotsReservationReq", "nJLen", nJLen, i);
//D7000265        for ( j=0 ; j<nJLen ; j++ )
//D7000265        {
//D7000265           rc = object_Lock( strObject_Lock_out, strObjCommonIn,
//D7000265                             tmpStartCassette[i].strLotInCassette[j].lotID, SP_ClassName_PosLot );
//D7000265           if ( rc != RC_OK )
//D7000265           {
//D7000265               PPT_METHODTRACE_V3( "CS_PPTManager_i:: txStartLotsReservationReq", "object_Lock() != RC_OK", i, j );
//D7000265               strStartLotsReservationReqResult.strResult = strObject_Lock_out.strResult;
//D7000265               return( rc );
//D7000265            }
//D7000265        }
//D7000265    }

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Check Process                                                       */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
//D4000015 Start
    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","equipment_categoryVsTxID_CheckCombination() returned error.");

        strStartLotsReservationReqResult.strResult
            = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return (rc);
    }
//D4000015 End

//D9000003 delete start
////D8000207 add start
//    //----------------------------------------
//    // Change processJobExecFlag to True.
//    //----------------------------------------
//    PPT_METHODTRACE_V2("","SP_OPER_START_WAFER_FLAG_CONTROL is ", atol(getenv(SP_OPER_START_WAFER_FLAG_CONTROL)));
//    if( 1 == atol(getenv(SP_OPER_START_WAFER_FLAG_CONTROL)) )
//    {
//        objStartCassette_processJobExecFlag_Set_out   strStartCassette_processJobExecFlag_Set_out;
//        rc = startCassette_processJobExecFlag_Set(strStartCassette_processJobExecFlag_Set_out, strObjCommonIn, strStartCassette );
//        if( rc != RC_OK )
//        {
//            PPT_METHODTRACE_V1("","objStartCassette_processJobExecFlag_Set() != RC_OK ");
//            strStartLotsReservationReqResult.strResult = strStartCassette_processJobExecFlag_Set_out.strResult;
//            return rc ;
//        }
//        tmpStartCassette = strStartCassette_processJobExecFlag_Set_out.strStartCassette;
//    }
////D8000207 add end
//D9000003 delete end

//D9000003 add start
    //Input parameter check.
    //Check every lot has at least one wafer with processJobExecFlag == TRUE
    PPT_METHODTRACE_V1("","Check every lot has at least one wafer with processJobExecFlag == TRUE.");
    objLot_processJobExecFlag_ValidCheck_out strLot_processJobExecFlag_ValidCheck_out;
    objLot_processJobExecFlag_ValidCheck_in strLot_processJobExecFlag_ValidCheck_in;
    strLot_processJobExecFlag_ValidCheck_in.strStartCassette = tmpStartCassette;

    rc = lot_processJobExecFlag_ValidCheck(strLot_processJobExecFlag_ValidCheck_out, strObjCommonIn, strLot_processJobExecFlag_ValidCheck_in);
    if( rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","objLot_processJobExecFlag_ValidCheck() != RC_OK ");
        strStartLotsReservationReqResult.strResult = strLot_processJobExecFlag_ValidCheck_out.strResult;
        return rc;
    }
//D9000003 add end


//P4100018 Add Start
    //-------------------------------------------------
    //  Check Scrap Wafer Exsit In Carrier
    //-------------------------------------------------
    objectIdentifierSequence cassetteIDs ;
    CORBA::Long castLen = tmpStartCassette.length();
    CORBA::Long cnt = 0;
    cassetteIDs.length( castLen ) ;

    for(cnt = 0 ; cnt < castLen; cnt++ )
    {
        cassetteIDs[cnt] = tmpStartCassette[cnt].cassetteID;
    }

    objCassette_scrapWafer_SelectDR_out  strCassette_scrapWafer_SelectDR_out;
    rc = cassette_scrapWafer_SelectDR( strCassette_scrapWafer_SelectDR_out,
                                       strObjCommonIn,
                                       cassetteIDs);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cassette_scrapWafer_SelectDR() != RC_OK",rc);
        strStartLotsReservationReqResult.strResult = strCassette_scrapWafer_SelectDR_out.strResult;
        return (rc);
    }

    CORBA::Long scrapCount = strCassette_scrapWafer_SelectDR_out.strLotWaferMap.length();
    if( scrapCount > 0 )
    {
        PPT_METHODTRACE_V2("", "ScrapWafer Found ",scrapCount);
        SET_MSG_RC(strStartLotsReservationReqResult, MSG_FOUND_SCRAP, RC_FOUND_SCRAP) ;
        return (RC_FOUND_SCRAP);
    }
//P4100018 Add End

//D51M0000 add start
    /*-----------------------------------------*/
    /*   call txAPCRunTimeCapabilityInq        */
    /*-----------------------------------------*/
    PPT_METHODTRACE_V1("", "call txAPCRunTimeCapabilityInq");
    pptAPCRunTimeCapabilityInqResult strAPCRunTimeCapabilityInqResult;
    rc = txAPCRunTimeCapabilityInq(strAPCRunTimeCapabilityInqResult,
                                   strObjCommonIn,
                                   equipmentID,
                                   controlJobID,
                                   tmpStartCassette,
                                   TRUE);
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "txAPCRunTimeCapabilityInq() != RC_OK");
        strStartLotsReservationReqResult.strResult = strAPCRunTimeCapabilityInqResult.strResult;
        return( rc );
    }

//D7000182 add start
    CORBA::Long RunCapaRespCount = strAPCRunTimeCapabilityInqResult.strAPCRunTimeCapabilityResponse.length();
    if( rc == RC_OK && RunCapaRespCount > 0 )
    {
        PPT_METHODTRACE_V1("", "Received RuntimeCapabilityResponse from APC.");
        CORBA::String_var tmpString = APCIFControlStatus;
        APCIFControlStatus = CIMFWStrDup(SP_APC_ControlJobStatus_Canceled);
    }
//D7000182 add end

    /*------------------------------------------------*/
    /*   call txAPCRecipeParameterAdjustInq           */
    /*------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call txAPCRecipeParameterAdjustInq");
    pptAPCRecipeParameterAdjustInqResult strAPCRecipeParameterAdjustInqResult;
    rc = txAPCRecipeParameterAdjustInq(strAPCRecipeParameterAdjustInqResult,
                                       strObjCommonIn,
                                       equipmentID,
                                       tmpStartCassette,
                                       strAPCRunTimeCapabilityInqResult.strAPCRunTimeCapabilityResponse,
                                       TRUE);
//D7000182    if(rc != RC_OK)
    if(rc != RC_OK && rc != RC_OK_NO_IF)    //D7000182
    {
        PPT_METHODTRACE_V2("", "txAPCRecipeParameterAdjustInq() != RC_OK", rc);
        strStartLotsReservationReqResult.strResult = strAPCRecipeParameterAdjustInqResult.strResult;
        return rc;
    }
    tmpStartCassette = strAPCRecipeParameterAdjustInqResult.strStartCassette;

//D7000182 add start
    if( rc == RC_OK )
    {
        PPT_METHODTRACE_V1("", "Received APCRecipeParameterResponse normally.");
        CORBA::String_var tmpString = APCIFControlStatus;
        APCIFControlStatus = CIMFWStrDup(SP_APC_ControlJobStatus_Canceled);
    }
//D7000182 add end
//D51M0000 add end


//D9000003 add start
    //APC result check.
    //Check every lot has at least one wafer with processJobExecFlag == TRUE
    strLot_processJobExecFlag_ValidCheck_in.strStartCassette = tmpStartCassette;
    PPT_METHODTRACE_V1("","Check every lot of APC result has at least one wafer with processJobExecFlag == TRUE.");
    rc = lot_processJobExecFlag_ValidCheck(strLot_processJobExecFlag_ValidCheck_out, strObjCommonIn, strLot_processJobExecFlag_ValidCheck_in);
    if( rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","objLot_processJobExecFlag_ValidCheck() != RC_OK ");
        strStartLotsReservationReqResult.strResult = strLot_processJobExecFlag_ValidCheck_out.strResult;
        return rc;
    }
//D9000003 add end


//D7000265 add start
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Object Lock Process                                                 */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    PPT_METHODTRACE_V1( "", "Object lock Process..." );

//DSN000049350 Add Start
    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = equipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXTRC041" ); // TxStartLotsReservationReq
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

    PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strStartLotsReservationReqResult.strResult = strObject_lockMode_Get_out.strResult;
        return( rc );
    }
    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;
    
    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
    if (lockMode != SP_EQP_LOCK_MODE_WRITE)
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strStartLotsReservationReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }
        /*------------------------------*/
        /*   Lock Dispatcher Object     */
        /*------------------------------*/
        PPT_METHODTRACE_V2( "", "calling object_Lock()", SP_ClassName_PosDispatcher );
        rc = object_Lock( strObject_Lock_out,
                          strObjCommonIn,
                          equipmentID,
                          SP_ClassName_PosDispatcher );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
            strStartLotsReservationReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
    /*--------------------------------------------*/
    /*                                            */
    /*      Machine Object Lock Process           */
    /*                                            */
    /*--------------------------------------------*/
        PPT_METHODTRACE_V1("", "#### Machine Object Lock ");
//DSN000049350        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, equipmentID, SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "object_Lock() != RC_OK" );
            strStartLotsReservationReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    } //DSN000049350

    /*--------------------------------------------*/
    /*                                            */
    /*        Port Object Lock Process            */
    /*                                            */
    /*--------------------------------------------*/
    PPT_METHODTRACE_V1("", "#### Port Object Lock ");
    /*--------------------------------------------------------*/
    /*   Get All Ports being in the same Port Group as ToPort */
    /*--------------------------------------------------------*/
    objPortResource_allPortsInSameGroup_Get_out strPortResource_allPortsInSameGroup_Get_out;
    rc = portResource_allPortsInSameGroup_Get( strPortResource_allPortsInSameGroup_Get_out,
                                               strObjCommonIn,
                                               equipmentID,
                                               strStartCassette[0].loadPortID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "portResource_allPortsInSameGroup_Get() rc != RC_OK", rc);
        strStartLotsReservationReqResult.strResult = strPortResource_allPortsInSameGroup_Get_out.strResult;
        return( rc );
    }

    /*---------------------------------------------------------*/
    /* Lock All Ports being in the same Port Group as ToPort   */
    /*---------------------------------------------------------*/
    CORBA::Long lenToPort = strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus.length();
    for ( CORBA::Long kk =0 ; kk < lenToPort ; kk++ )
    {
        objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
        rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                              strObjCommonIn,
                                              equipmentID,
                                              strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[kk].portID,
                                              SP_ClassName_PosPortResource );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[kk].portID.identifier) ;
            strStartLotsReservationReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
            return( rc );
        }
        PPT_METHODTRACE_V2("", "Locked port object  : ", strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[kk].portID.identifier) ;
    }

    /*--------------------------------------------*/
    /*                                            */
    /*       Cassette Object Lock Process         */
    /*                                            */
    /*--------------------------------------------*/
    PPT_METHODTRACE_V1("", "#### Cassette Object Lock ");
    CORBA::Long i     = 0;
    CORBA::Long nILen = tmpStartCassette.length();
    PPT_METHODTRACE_V2( "", "nILen", nILen);

//DSN000049350 Add Start
    objectIdentifierSequence lotIDs;
    CORBA::ULong extendLen     = 25;
    CORBA::ULong t_lotIDLen    = extendLen;
    CORBA::ULong lotIDCnt      = 0;
    lotIDs.length(t_lotIDLen);
    cassetteIDs.length(nILen);
//DSN000049350 Add End

    for ( i=0 ; i<nILen ; i++ )
    {
//DSN000049350        rc = object_Lock( strObject_Lock_out, strObjCommonIn, tmpStartCassette[i].cassetteID,
//DSN000049350                          SP_ClassName_PosCassette );
//DSN000049350        if ( rc != RC_OK )
//DSN000049350        {
//DSN000049350            PPT_METHODTRACE_V2( "", "object_Lock() != RC_OK", i );
//DSN000049350            strStartLotsReservationReqResult.strResult = strObject_Lock_out.strResult;
//DSN000049350            return( rc );
//DSN000049350        }

        cassetteIDs[i] = tmpStartCassette[i].cassetteID;  //DSN000049350

        /*--------------------------------------------*/
        /*                                            */
        /*         Lot Object Lock Process            */
        /*                                            */
        /*--------------------------------------------*/
        PPT_METHODTRACE_V1("", "#### Lot Object Lock ");
        CORBA::Long j     = 0;
        CORBA::Long nJLen = tmpStartCassette[i].strLotInCassette.length();
        PPT_METHODTRACE_V3( "", "nJLen", nJLen, i);
        for ( j=0 ; j<nJLen ; j++ )
        {
//DSN000049350            rc = object_Lock( strObject_Lock_out, strObjCommonIn,
//DSN000049350                              tmpStartCassette[i].strLotInCassette[j].lotID, SP_ClassName_PosLot );
//DSN000049350            if ( rc != RC_OK )
//DSN000049350            {
//DSN000049350                PPT_METHODTRACE_V3( "", "object_Lock() != RC_OK", i, j );
//DSN000049350                strStartLotsReservationReqResult.strResult = strObject_Lock_out.strResult;
//DSN000049350                return( rc );
//DSN000049350            }
//DSN000049350 Add Start
            if( lotIDCnt >= t_lotIDLen )
            {
                PPT_METHODTRACE_V1("", "lotIDCnt >= t_lotIDLen");
                t_lotIDLen += extendLen;
                lotIDs.length( t_lotIDLen );
            }
            lotIDs[lotIDCnt++] = tmpStartCassette[i].strLotInCassette[j].lotID;
//DSN000049350 Add End
        }
    }
    lotIDs.length(lotIDCnt);                        //DSN000049350
    PPT_METHODTRACE_V2( "", "lotIDCnt", lotIDCnt);  //DSN000049350

//DSN000049350 Add Start
    /*------------------------------*/
    /*   Lock Cassette/Lot Object   */
    /*-------------------------------*/
    objObjectSequence_Lock_out strObjectSequence_Lock_out;

    PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosCassette );
    rc = objectSequence_Lock( strObjectSequence_Lock_out,
                              strObjCommonIn,
                              cassetteIDs,
                              SP_ClassName_PosCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
        strStartLotsReservationReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }

    PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosLot );
    rc = objectSequence_Lock( strObjectSequence_Lock_out,
                              strObjCommonIn,
                              lotIDs,
                              SP_ClassName_PosLot );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
        strStartLotsReservationReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }
//DSN000049350 Add End

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Check Process                                                       */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    //-------------------------------------------------
    //  Check scrap wafer existence in carrier
    //-------------------------------------------------
    cnt = 0;
    cassetteIDs.length( castLen ) ;

    for(cnt = 0 ; cnt < castLen; cnt++ )
    {
        cassetteIDs[cnt] = tmpStartCassette[cnt].cassetteID;
    }

    rc = cassette_scrapWafer_SelectDR( strCassette_scrapWafer_SelectDR_out,
                                       strObjCommonIn,
                                       cassetteIDs);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cassette_scrapWafer_SelectDR() != RC_OK",rc);
        strStartLotsReservationReqResult.strResult = strCassette_scrapWafer_SelectDR_out.strResult;
        return (rc);
    }

    scrapCount = strCassette_scrapWafer_SelectDR_out.strLotWaferMap.length();
    if( scrapCount > 0 )
    {
        PPT_METHODTRACE_V2("", "ScrapWafer Found ",scrapCount);
        SET_MSG_RC(strStartLotsReservationReqResult, MSG_FOUND_SCRAP, RC_FOUND_SCRAP) ;
        return (RC_FOUND_SCRAP);
    }
//D7000265 add end

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Cassette                                          */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - controlJobID                                                      */
    /*   - multiLotType                                                      */
    /*   - transferState                                                     */
    /*   - transferReserved                                                  */
    /*   - dispatchState                                                     */
    /*   - maxBatchSize                                                      */
    /*   - minBatchSize                                                      */
    /*   - emptyCassetteCount                                                */
    /*   - cassette'sloadingSequenceNomber                                   */ //P3000185
    /*   - eqp's multiRecipeCapability and recipeParameter                   */ //D3000079
    /*   - Upper/Lower Limit for RecipeParameterChange                       */ //P3100289
    /*   - MonitorLotCount or OperationStartLotCount                         */ //P3100289
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    objCassette_CheckConditionForOperation_out strCassette_CheckConditionForOperation_out;
    rc = cassette_CheckConditionForOperation( strCassette_CheckConditionForOperation_out,
                                              strObjCommonIn, equipmentID, portGroupID,
                                              tmpStartCassette, SP_Operation_StartReservation );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationReq", "cassette_CheckConditionForOperation() != RC_OK" );
        strStartLotsReservationReqResult.strResult = strCassette_CheckConditionForOperation_out.strResult;
        return( rc );
    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Lot                                               */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - controlJobID                                                      */
    /*   - lot's equipmentID                                                 */
    /*   - lotHoldState                                                      */
    /*   - lotProcessState                                                   */
    /*   - lotInventoryState                                                 */
    /*   - entityInhibition                                                  */
    /*   - minWaferCount                                                     */
    /*   - equipment's availability for specified lot                        */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    objLot_CheckConditionForOperation_out strLot_CheckConditionForOperation_out;
    rc = lot_CheckConditionForOperation( strLot_CheckConditionForOperation_out,
                                         strObjCommonIn, equipmentID, portGroupID,
                                         tmpStartCassette, SP_Operation_StartReservation );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationReq", "lot_CheckConditionForOperation() != RC_OK" );
        strStartLotsReservationReqResult.strResult = strLot_CheckConditionForOperation_out.strResult;
        return( rc );
    }

    /*-----------------------------------------------------------------------------*/
    /*                                                                             */
    /*   Check Equipment Port for Start Reservation                                */
    /*                                                                             */
    /*   The following conditions are checked by this object                       */
    /*                                                                             */
    /*   1. In-parm's portGroupID must not have controlJobID.                      */
    /*   2. All of ports' loadMode must be CIMFW_PortRsc_Input or _InputOutput.    */
    /*   3. All of port, which is registered as in-parm's portGroup, must be       */
    /*      _LoadAvail or _LoadReq when equipment is online.                       */
    /*      As exceptional case, if equipment's takeOutInTransferFlag is True,     */
    /*      _UnloadReq is also OK for start reservation when equipment is Online.  */
    /*   4. All of port, which is registered as in-parm's portGroup,               */
    /*      must not have loadedCassetteID.                                        */
    /*   5. strStartCassette[].loadPortID's portGroupID must be same               */
    /*      as in-parm's portGroupID.                                              */
    /*   6. strStartCassette[].loadPurposeType must be match as specified port's   */
    /*      loadPutposeType.                                                       */
    /*   7. strStartCassette[].loadSequenceNumber must be same as specified port's */
    /*      loadSequenceNumber.                                                    */
    /*                                                                             */
    /*-----------------------------------------------------------------------------*/
    objEquipment_portState_CheckForStartReservation_out strEquipment_portState_CheckForStartReservation_out;
    rc = equipment_portState_CheckForStartReservation( strEquipment_portState_CheckForStartReservation_out,
                                                       strObjCommonIn, equipmentID, portGroupID,
                                                       tmpStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationReq", "equipment_portState_CheckForStartReservation() != RC_OK" );
        strStartLotsReservationReqResult.strResult = strEquipment_portState_CheckForStartReservation_out.strResult;
        return( rc );
    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for FlowBatch                                         */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   1. whether in-parm's equipment has reserved flowBatchID or not      */
    /*      fill  -> all of flowBatch member and in-parm's lot must be       */
    /*               same perfectly.                                         */
    /*      blank -> no check                                                */
    /*                                                                       */
    /*   2. whether lot is in flowBatch section or not                       */
    /*      in    -> lot must have flowBatchID, and flowBatch must have      */
    /*               reserved equipmentID.                                   */
    /*               if lot is on target operation, flowBatch's reserved     */
    /*               equipmentID and in-parm's equipmentID must be same.     */
    /*      out   -> no check                                                */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
//D9000079    objEquipment_lot_CheckFlowBatchConditionForOpeStart_out strEquipment_lot_CheckFlowBatchConditionForOpeStart_out;
//D9000079    rc = equipment_lot_CheckFlowBatchConditionForOpeStart( strEquipment_lot_CheckFlowBatchConditionForOpeStart_out,
//D9000079                                                           strObjCommonIn, equipmentID, portGroupID,
//D9000079                                                           tmpStartCassette );
//D9000079 add start
    objEquipment_lot_CheckFlowBatchConditionForOpeStart_out__090 strEquipment_lot_CheckFlowBatchConditionForOpeStart_out;
    objEquipment_lot_CheckFlowBatchConditionForOpeStart_in__090  strEquipment_lot_CheckFlowBatchConditionForOpeStart_in;
    strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.equipmentID = equipmentID;
    strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.portGroupID = portGroupID;
    strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.strStartCassette = tmpStartCassette;

    rc = equipment_lot_CheckFlowBatchConditionForOpeStart__090( strEquipment_lot_CheckFlowBatchConditionForOpeStart_out,
                                                                strObjCommonIn,
                                                                strEquipment_lot_CheckFlowBatchConditionForOpeStart_in );
//D9000079 add end
    if ( rc != RC_OK )
    {
//D9000079        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationReq", "equipment_lot_CheckFlowBatchConditionForOpeStart() != RC_OK" );
        PPT_METHODTRACE_V1( "", "equipment_lot_CheckFlowBatchConditionForOpeStart__090() != RC_OK" );   //D9000079
        strStartLotsReservationReqResult.strResult = strEquipment_lot_CheckFlowBatchConditionForOpeStart_out.strResult;
        return( rc );
    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Process Durable                                   */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   1. Whether equipment requires process durable or not                */
    /*      If no-need, return OK;                                           */
    /*                                                                       */
    /*   2. At least one of reticle / fixture for each reticleGroup /        */
    /*      fixtureGroup is in the equipment or not.                         */
    /*      Even if required reticle is in the equipment, its status must    */
    /*      be _Available or _InUse.                                         */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/

    /*-----------------------------------------*/
    /*   Check Process Durable Required Flag   */
    /*-----------------------------------------*/
    objEquipment_processDurableRequiredFlag_Get_out strEquipment_processDurableRequiredFlag_Get_out;
    rc = equipment_processDurableRequiredFlag_Get(strEquipment_processDurableRequiredFlag_Get_out, strObjCommonIn,
                                                  equipmentID);
    if ( rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD )
    {
        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationReq", "rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD");
        CORBA::Long i     = 0;
        CORBA::Long nIMax = tmpStartCassette.length();
        PPT_METHODTRACE_V2( "CS_PPTManager_i:: txStartLotsReservationReq", "nIMax", nIMax);
        for ( i=0 ; i<nIMax; i++ )
        {
            if ( CIMFWStrCmp(tmpStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
            {
                continue;
            }

            CORBA::Long j     = 0;
            CORBA::Long nJMax = tmpStartCassette[i].strLotInCassette.length();
            PPT_METHODTRACE_V3( "CS_PPTManager_i:: txStartLotsReservationReq", "nJMax", nJMax, i);
            for ( j=0 ; j<nJMax; j++ )
            {
                if ( tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    continue;
                }

                /*--------------------------------------------------*/
                /*   Check Process Durable Condition for OpeStart   */
                /*--------------------------------------------------*/
                objProcessDurable_CheckConditionForOpeStart_out strProcessDurable_CheckConditionForOpeStart_out;
                rc = processDurable_CheckConditionForOpeStart( strProcessDurable_CheckConditionForOpeStart_out,
                                                               strObjCommonIn, equipmentID,
                                                               tmpStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID,
//D4000048                                                     tmpStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID );
                                                               tmpStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID,   //D4000048
                                                               tmpStartCassette[i].strLotInCassette[j].lotID );                          //D4000048
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V3( "CS_PPTManager_i:: txStartLotsReservationReq", "processDurable_CheckConditionForOpeStart() != RC_OK", i, j );
                    strStartLotsReservationReqResult.strResult = strProcessDurable_CheckConditionForOpeStart_out.strResult;
                    return( rc );
                }

                /*---------------------------------------*/
                /*   Set Available Reticles / Fixtures   */
                /*---------------------------------------*/
                tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle = strProcessDurable_CheckConditionForOpeStart_out.strStartReticle;
                tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture = strProcessDurable_CheckConditionForOpeStart_out.strStartFixture;
            }
        }
        rc = RC_OK;
    }
    else if ( rc == RC_EQP_PROCDRBL_NOT_REQD )
    {
        rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationReq", "!RC_EQP_PROCDRBL_RTCL_REQD && !RC_EQP_PROCDRBL_FIXT_REQD && !RC_EQP_PROCDRBL_NOT_REQD" );
        strStartLotsReservationReqResult.strResult = strEquipment_processDurableRequiredFlag_Get_out.strResult;
        return( rc );
    }

    /*----------------------------------------------------------------------*/
    /*                                                                      */
    /*   Confirmation for Uploaded Recipe Body and Eqp's Recipe Body        */
    /*                                                                      */
    /*   When the following conditions are all matched, recipe body         */
    /*   confirmation request is sent to TCS.                               */
    /*                                                                      */
    /*   1. Equipment's onlineMode is Online                                */
    /*   2. Equipment's recipe body manage flag is TRUE.                    */
    /*   3. Machine recipe's recipe body confirm flag is TRUE.              */
    //                                                                                                                             //P9000022
    //   Force Down Load Flag  Recipe Body Confirm Flag  Conditional Down Load Flag                                                //P9000022
    //           Yes                      No                       No                      -> Download it without confirmation.    //P9000022
    //           No                       Yes                      No                      -> Confirm only.                        //P9000022
    //           No                       Yes                      Yes                     -> If confirmation is NG, download it.  //P9000022
    //           No                       No                       No                      -> No action.                           //P9000022
    /*                                                                      */
    /*----------------------------------------------------------------------*/

//P9000022    /*---------------------------------------------*/
//P9000022    /*   Get Machine Recipe List to be Confirmed   */
//P9000022    /*---------------------------------------------*/
//P9000022    objMachineRecipe_GetListForConfirmation_out strMachineRecipe_GetListForConfirmation_out;
//P9000022    rc = machineRecipe_GetListForConfirmation( strMachineRecipe_GetListForConfirmation_out,
//P9000022                                               strObjCommonIn, equipmentID, tmpStartCassette );
//P9000022    if ( rc != RC_OK )
//P9000022    {
//P9000022        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationReq", "machineRecipe_GetListForConfirmation() != RC_OK" );
//P9000022        strStartLotsReservationReqResult.strResult = strMachineRecipe_GetListForConfirmation_out.strResult;
//P9000022        return( rc );
//P9000022    }
//P9000022
//P9000022    i = 0;
//P9000022    CORBA::Long nIMax = strMachineRecipe_GetListForConfirmation_out.machineRecipeID.length();
//P9000022    PPT_METHODTRACE_V2( "CS_PPTManager_i:: txStartLotsReservationReq", "nIMax", nIMax);
//P9000022    for ( i=0 ; i<nIMax; i++ )
//P9000022    {
//P9000022        /*-------------------------------------------*/
//P9000022        /*   Send Recipe Body Confirmation Request   */
//P9000022        /*-------------------------------------------*/
//P9000022        pptRecipeConfirmationReqResult strRecipeConfirmationReqResult;
//P9000022        rc = txRecipeConfirmationReq( strRecipeConfirmationReqResult, strObjCommonIn, equipmentID,
//P9000022                                 strMachineRecipe_GetListForConfirmation_out.machineRecipeID[i],
//P9000022                                 "", "", "", FALSE, "");
//P9000022        if ( rc != RC_OK )
//P9000022        {
//P9000022            PPT_METHODTRACE_V2( "CS_PPTManager_i:: txStartLotsReservationReq", "txRecipeConfirmationReq() != RC_OK", i );
//P9000022            strStartLotsReservationReqResult.strResult = strRecipeConfirmationReqResult.strResult;
//P9000022            return( rc );
//P9000022        }
//P9000022
//P9000022    }

//P9000022 add start
    CORBA::Long nIMax = 0;
    //---------------------------------------------------
    // Get Machine Recipe List for Recipe Body Management
    //---------------------------------------------------
    PPT_METHODTRACE_V1( "", "Get Machine Recipe List for Recipe Body Mangement." );
    objMachineRecipe_GetListForRecipeBodyManagement_out strMachineRecipe_GetListForRecipeBodyManagement_out;
    objMachineRecipe_GetListForRecipeBodyManagement_in  strMachineRecipe_GetListForRecipeBodyManagement_in;
    strMachineRecipe_GetListForRecipeBodyManagement_in.equipmentID      = equipmentID;
    strMachineRecipe_GetListForRecipeBodyManagement_in.strStartCassette = tmpStartCassette;
    rc = machineRecipe_GetListForRecipeBodyManagement( strMachineRecipe_GetListForRecipeBodyManagement_out, strObjCommonIn, strMachineRecipe_GetListForRecipeBodyManagement_in);
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1( "", "machineRecipe_GetListForRecipeBodyManagement() != RC_OK" );
        strStartLotsReservationReqResult.strResult = strMachineRecipe_GetListForRecipeBodyManagement_out.strResult;
        return( rc );
    }

    //INN-A170001 Add Start
    char * ptrRMSGlobalFlag = getenv(CS_SP_RMS_CHECK_ONLINE_FLAG);
    CORBA::Boolean bolConstFlag=FALSE;
    CORBA::Boolean bolAuditAlready=FALSE;
    csObjEquipment_constantsManageFlag_Get_out strObjEquipment_constantsManageFlag_Get_out;
    rc = cs_equipment_constantsManageFlag_Get(strObjEquipment_constantsManageFlag_Get_out,strObjCommonIn,equipmentID);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "cs_equipment_constantsManageFlag_Get() != RC_OK" );
        strStartLotsReservationReqResult.strResult = strObjEquipment_constantsManageFlag_Get_out.strResult;
        return( rc );
    }
    PPT_METHODTRACE_V2("", "DEBUG_strObjEquipment_constantsManageFlag_Get_out.equipmentConstantsManageFlag",((strObjEquipment_constantsManageFlag_Get_out.equipmentConstantsManageFlag)?1:0));
    bolConstFlag = strObjEquipment_constantsManageFlag_Get_out.equipmentConstantsManageFlag;
    PPT_METHODTRACE_V2("", "DEBUG_bolConstFlag",((bolConstFlag)?1:0));
    //INN-A170001 Add End

    CORBA::Long targetRecipeLen = strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq.length();
    if( 0 == targetRecipeLen )
    {
        PPT_METHODTRACE_V1( "", "Recipe for Recipe Body Management does not exist." );
    }

    for(CORBA::Long targetRecipeCnt=0; targetRecipeCnt<targetRecipeLen; targetRecipeCnt++)
    {
        PPT_METHODTRACE_V2(""," Machine Recipe ID          ",  strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID.identifier);
        PPT_METHODTRACE_V2(""," Force Down Load Flag       ", (strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].forceDownLoadFlag?"True":"False"));
        PPT_METHODTRACE_V2(""," Recipe Body Confirm Flag   ", (strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].recipeBodyConfirmFlag?"True":"False"));
        PPT_METHODTRACE_V2(""," Conditional Down Load Flag ", (strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].conditionalDownLoadFlag?"True":"False"));

        //-------------------
        // Force Down Load
        //-------------------
        CORBA::Boolean downLoadFlag = FALSE;
        if( TRUE == strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].forceDownLoadFlag )
        {
             PPT_METHODTRACE_V1("","downLoadFlag turns to True.");
             downLoadFlag = TRUE;
        }
        else
        {
//INN-A170001            if( TRUE == strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].recipeBodyConfirmFlag )
//INN-A170001            {
//INN-A170001                //---------------------
//INN-A170001                // Recipe Confirmation
//INN-A170001                //---------------------
//INN-A170001                PPT_METHODTRACE_V1("","Call txRecipeConfirmationReq");
//INN-A170001                pptRecipeConfirmationReqResult strRecipeConfirmationReqResult;
//INN-A170001                rc = txRecipeConfirmationReq( strRecipeConfirmationReqResult, strObjCommonIn, equipmentID,
//INN-A170001                                              strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID,
//INN-A170001                                              strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].physicalRecipeID,
//INN-A170001                                              strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].fileLocation,
//INN-A170001                                              strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].fileName,
//INN-A170001                                              strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].formatFlag, "");
//INN-A170001
//INN-A170001                if ( rc != RC_OK && rc != RC_TCS_MM_TAP_PP_CONFIRM_ERROR)  // RC_TCS_MM_TAP_PP_CONFIRM_ERROR = 5914
//INN-A170001                {
//INN-A170001                    PPT_METHODTRACE_V2( "", "txRecipeConfirmationReq() != RC_OK", i );
//INN-A170001                    strStartLotsReservationReqResult.strResult = strRecipeConfirmationReqResult.strResult;
//INN-A170001                    return( rc );
//INN-A170001                }
//INN-A170001                if( rc == RC_TCS_MM_TAP_PP_CONFIRM_ERROR )
//INN-A170001                {
//INN-A170001                    if( TRUE == strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].conditionalDownLoadFlag )
//INN-A170001                    {
//INN-A170001                        //--------------------------
//INN-A170001                        // Conditional Down Load
//INN-A170001                        //--------------------------
//INN-A170001                        PPT_METHODTRACE_V1("","downLoadFlag turns to True.");
//INN-A170001                        downLoadFlag = TRUE;
//INN-A170001                    }
//INN-A170001                    else
//INN-A170001                    {
//INN-A170001                        //Recipe Body Confirmation error. the Recipe Body differs between Uploaded it to system and the owned it by equipment.
//INN-A170001                        PPT_METHODTRACE_V2("","Recipe Body Confirmation error. the Recipe Body differs between Uploaded it to system and the owned it by equipment.",
//INN-A170001                                              strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID.identifier);
//INN-A170001                        PPT_SET_MSG_RC_KEY(strStartLotsReservationReqResult, MSG_RECIPE_CONFIRM_ERROR, RC_RECIPE_CONFIRM_ERROR ,
//INN-A170001                                           strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID.identifier);
//INN-A170001                        return ( RC_RECIPE_CONFIRM_ERROR );
//INN-A170001                    }
//INN-A170001                }
//INN-A170001            }
//INN-A170001            else
//INN-A170001            {
//INN-A170001                PPT_METHODTRACE_V1("","Recipe Body management .. no action.");
//INN-A170001                // no action.
//INN-A170001            }

            //INN-A170001 Add Start
            if (0 == CIMFWStrCmp(ptrRMSGlobalFlag ,"1"))
            {
                if((TRUE == strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].recipeBodyConfirmFlag ) &&
                     (CIMFWStrCmp(strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].physicalRecipeID, "DYNAMIC" ) != 0))
                {
                      bolAuditAlready = TRUE ;
                    csRecipeAuditReqResult strRecipeAuditReqResult;
                    rc = cs_txRecipeAuditReq(strRecipeAuditReqResult,strObjCommonIn,equipmentID,strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID,
                                             bolConstFlag,strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].recipeBodyConfirmFlag);
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2( "", "cs_txRecipeAuditReq() != RC_OK", rc);
                        strStartLotsReservationReqResult.strResult = strRecipeAuditReqResult.strResult;
                        return( rc );
                    }
                }
            }
            //INN-A170001 Add End
        }

        PPT_METHODTRACE_V2("","Recipe Down Load ??", (downLoadFlag?"True":"False"));
        if( TRUE == downLoadFlag )
        {
            //---------------------
            // Recipe Down Load
            //---------------------
            PPT_METHODTRACE_V1("","Call txRecipeDownloadReq");
            pptRecipeDownloadReqResult strRecipeDownloadReqResult;
            rc = txRecipeDownloadReq( strRecipeDownloadReqResult, strObjCommonIn, equipmentID,
                                      strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID,
                                      strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].physicalRecipeID,
                                      strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].fileLocation,
                                      strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].fileName,
                                      strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].formatFlag, "");

            if(rc != RC_OK)
            {

                PPT_METHODTRACE_V2( "", "txRecipeDownloadReq() != RC_OK", i );
                strStartLotsReservationReqResult.strResult = strRecipeDownloadReqResult.strResult;
                return ( rc );
            }
        }
    } //Loop of targetRecipeLen

    //INN-A170001 Add Start
    if (0 == CIMFWStrCmp(ptrRMSGlobalFlag ,"1"))
    {
        if( bolConstFlag && !bolAuditAlready)
        {
            csRecipeAuditReqResult strRecipeAuditReqResult;
            objectIdentifier machineRecipeID;
            machineRecipeID.identifier = CIMFWStrDup("");
            rc = cs_txRecipeAuditReq(strRecipeAuditReqResult,strObjCommonIn,equipmentID,machineRecipeID, bolConstFlag,0);
            if ( rc != RC_OK )
            {
                    PPT_METHODTRACE_V2( "", "cs_txRecipeAuditReq() != RC_OK", rc);
                    strStartLotsReservationReqResult.strResult = strRecipeAuditReqResult.strResult;
                    return( rc );
            }
        }
    }
    //INN-A170001 Add End
    
//P9000022 add end

//D4000016 Add Start
    /*---------------------------------------------------------------------------*/
    /*                                                                           */
    /*   Check Category for Copper/Non Copper                                    */
    /*                                                                           */
    /*   It is checked in the following method whether it is the condition       */
    /*   that Lot of the object is made of OpeStart.                             */
    /*                                                                           */
    /*   1. It is checked whether CassetteCategory of RequiredCassetteCategory   */
    /*      of PosLot and PosCassette is the same.                               */
    /*                                                                           */
    /*   2. It is checked whether CassetteCategoryCapability of CassetteCategory */
    /*      of PosCassette and PosPortResource is the same.                      */
    /*                                                                           */
    /*   3. It is proper condition if CassetteCategoryCapability is the same     */
    /*      as RequiredCassetteCategory and CassetteCategory.                    */
    /*                                                                           */
    /*---------------------------------------------------------------------------*/
    CORBA::Long ii;
    CORBA::Long jj;
//P4000228    CORBA::Long nCastLen = strStartCassette.length();
    CORBA::Long nCastLen = tmpStartCassette.length();       //P4000228
    CORBA::Long nLotInCastLen;

//P4000228    for ( ii = 0; ii < nCastLen; ii++ )
//P4000228    {
//P4000228        nLotInCastLen = strStartCassette[ii].strLotInCassette.length();
//P4000228        for ( jj = 0; jj < nLotInCastLen; jj++ )
//P4000228        {
//P4000228            objLot_CassetteCategory_CheckForContaminationControl_out strLot_CassetteCategory_CheckForContaminationControl_out;
//P4000228            rc = lot_CassetteCategory_CheckForContaminationControl( strLot_CassetteCategory_CheckForContaminationControl_out,
//P4000228                                                      strObjCommonIn,
//P4000228                                                      strStartCassette[ii].strLotInCassette[jj].lotID,
//P4000228                                                      strStartCassette[ii].cassetteID,
//P4000228                                                      equipmentID,
//P4000228                                                      strStartCassette[ii].loadPortID);
//P4000228            if ( rc != RC_OK )
//P4000228            {
//P4000228                PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationReq", "lot_CassetteCategory_CheckForContaminationControl() != RC_OK");
//P4000228                strStartLotsReservationReqResult.strResult = strLot_CassetteCategory_CheckForContaminationControl_out.strResult;
//P4000228                return( rc );
//P4000228            }
//P4000228        }
//P4000228    }

//P4000228 Add Start
    objectIdentifier dummyLotID;

    for ( ii = 0; ii < nCastLen; ii++ )
    {
        if ( CIMFWStrCmp(tmpStartCassette[ii].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
        {
            objLot_CassetteCategory_CheckForContaminationControl_out strLot_CassetteCategory_CheckForContaminationControl_out;
            rc = lot_CassetteCategory_CheckForContaminationControl( strLot_CassetteCategory_CheckForContaminationControl_out,
                                                      strObjCommonIn,
                                                      dummyLotID,
                                                      tmpStartCassette[ii].cassetteID,
                                                      equipmentID,
                                                      tmpStartCassette[ii].loadPortID);

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationReq", "lot_CassetteCategory_CheckForContaminationControl() != RC_OK");
                strStartLotsReservationReqResult.strResult = strLot_CassetteCategory_CheckForContaminationControl_out.strResult;
                return( rc );
            }
        }
        else
        {
            nLotInCastLen = tmpStartCassette[ii].strLotInCassette.length();
            for ( jj = 0; jj < nLotInCastLen; jj++ )
            {
//P4100102 add start
                if ( tmpStartCassette[ii].strLotInCassette[jj].operationStartFlag == FALSE )
                {
                    continue;
                }
//P4100102 add en
                objLot_CassetteCategory_CheckForContaminationControl_out strLot_CassetteCategory_CheckForContaminationControl_out;
                rc = lot_CassetteCategory_CheckForContaminationControl( strLot_CassetteCategory_CheckForContaminationControl_out,
                                                                        strObjCommonIn,
                                                                        tmpStartCassette[ii].strLotInCassette[jj].lotID,
                                                                        tmpStartCassette[ii].cassetteID,
                                                                        equipmentID,
                                                                        tmpStartCassette[ii].loadPortID);

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationReq", "lot_CassetteCategory_CheckForContaminationControl() != RC_OK");
                    strStartLotsReservationReqResult.strResult = strLot_CassetteCategory_CheckForContaminationControl_out.strResult;
                    return( rc );
                }
            }
//INN-R170002 add start
            csObjLot_ContaminationInfo_CheckForProcess_in  strLot_ContaminationInfo_CheckForProcess_in;
            strLot_ContaminationInfo_CheckForProcess_in.equipmentID = equipmentID;
            strLot_ContaminationInfo_CheckForProcess_in.carrierID   = tmpStartCassette[ii].cassetteID;
            strLot_ContaminationInfo_CheckForProcess_in.strLotInCassette = tmpStartCassette[ii].strLotInCassette;

            csObjLot_ContaminationInfo_CheckForProcess_out strLot_ContaminationInfo_CheckForProcess_out;
            rc = cs_lot_ContaminationInfo_CheckForProcess( strLot_ContaminationInfo_CheckForProcess_out,
                                                           strObjCommonIn,
                                                           strLot_ContaminationInfo_CheckForProcess_in);

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "cs_lot_ContaminationInfo_CheckForProcess() != RC_OK");
                strStartLotsReservationReqResult.strResult = strLot_ContaminationInfo_CheckForProcess_out.strResult;
                return( rc );
            }
            if ( FALSE == strLot_ContaminationInfo_CheckForProcess_out.matchFlag )
            {
                PPT_METHODTRACE_V1( "", "strLot_ContaminationInfo_CheckForProcess_out.matchFlag=FALSE");

                csStartLotsReservationReqResult_siInfo strStartLotsReservationReqResult_siInfo;
                strStartLotsReservationReqResult_siInfo.holdLotIDs = strLot_ContaminationInfo_CheckForProcess_out.holdLotIDs;
                strStartLotsReservationReqResult.siInfo <<= strStartLotsReservationReqResult_siInfo;

                CS_PPT_SET_MSG_RC_KEY1( strStartLotsReservationReqResult,
                                     CS_MSG_CARRIER_CONTAMINATION_MISMATCH,
                                     CS_RC_CARRIER_CONTAMINATION_MISMATCH,
                                     tmpStartCassette[ii].cassetteID.identifier );
                return CS_RC_CARRIER_CONTAMINATION_MISMATCH;
            }
//INN-R170002 add end
        }
    }
//P4000228 Add End
//D4000016 Add End

//D7000041 start
    /*---------------------------------------------------------------------------*/
    /*                                                                           */
    /*   Check Carrier Category for next operation of Empty carrier.             */
    /*                                                                           */
    /*---------------------------------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call emptyCassette_CheckCategoryForOperation()");
    objEmptyCassette_CheckCategoryForOperation_out strEmptyCassette_CheckCategoryForOperation_out;
    rc = emptyCassette_CheckCategoryForOperation( strEmptyCassette_CheckCategoryForOperation_out, strObjCommonIn, tmpStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "emptyCassette_CheckCategoryForOperation() != RC_OK", rc);
        strStartLotsReservationReqResult.strResult = strEmptyCassette_CheckCategoryForOperation_out.strResult;
        return( rc );
    }
//D7000041 end

//DSIV00000099 start
    /*----------------------------------------*/
    /*                                        */
    /*   Check Condition for SLM.             */
    /*                                        */
    /*----------------------------------------*/
    objSLM_CheckConditionForOperation_out strSLM_CheckConditionForOperation_out;
    objSLM_CheckConditionForOperation_in  strSLM_CheckConditionForOperation_in;

    strSLM_CheckConditionForOperation_in.equipmentID = equipmentID;
    strSLM_CheckConditionForOperation_in.portGroupID = portGroupID;
    strSLM_CheckConditionForOperation_in.controlJobID = controlJobID;
    strSLM_CheckConditionForOperation_in.strStartCassette = strStartCassette;
    strSLM_CheckConditionForOperation_in.operation = CIMFWStrDup( SP_Operation_StartReservation );

    PPT_METHODTRACE_V1("", "call SLM_CheckConditionForOperation()");
    rc = SLM_CheckConditionForOperation( strSLM_CheckConditionForOperation_out,
                                         strObjCommonIn,
                                         strSLM_CheckConditionForOperation_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "SLM_CheckConditionForOperation() != RC_OK", rc);
        strStartLotsReservationReqResult.strResult = strSLM_CheckConditionForOperation_out.strResult;
        return( rc );
    }
//DSIV00000099 end

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Main Process                                                        */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

    /*----------------------------------------------*/
    /*                                              */
    /*   Change Cassette's Dispatch State to TRUE   */
    /*                                              */
    /*----------------------------------------------*/
    i     = 0;
    nIMax = tmpStartCassette.length();
    PPT_METHODTRACE_V2( "CS_PPTManager_i:: txStartLotsReservationReq", "nIMax", nIMax);
    for ( i=0 ; i<nIMax; i++ )
    {
        objCassette_dispatchState_Change_out strCassette_dispatchState_Change_out;
        rc = cassette_dispatchState_Change( strCassette_dispatchState_Change_out, strObjCommonIn,
                                            tmpStartCassette[i].cassetteID, TRUE );
        if ( rc != RC_OK ) {
            PPT_METHODTRACE_V2( "CS_PPTManager_i:: txStartLotsReservationReq", "cassette_dispatchState_Change() != RC_OK", i );
            strStartLotsReservationReqResult.strResult = strCassette_dispatchState_Change_out.strResult;
            return( rc );
        }

    }

    /*-------------------------------------------------------------*/
    /*                                                             */
    /*   Create Control Job and Assign to Each Cassettes / Lots    */
    /*                                                             */
    /*   - Create new controlJob                                   */
    /*   - Set created controlJobID to each cassettes / lots       */
    /*   - Set created controlJobID to equipment                   */
    /*                                                             */
    /*-------------------------------------------------------------*/
//D7000006    objControlJob_Create_out strControlJob_Create_out;
//D7000006    rc = controlJob_Create( strControlJob_Create_out, strObjCommonIn,
//D7000006                            equipmentID, portGroupID, tmpStartCassette );
//D7000006    if ( rc != RC_OK )
//D7000006    {
//D7000006        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationReq", "controlJob_Create() != RC_OK");
//D7000006        strStartLotsReservationReqResult.strResult = strControlJob_Create_out.strResult;
//D7000006        return( rc );
//D7000006    }
//D7000006 Add Start
    pptControlJobManageReqResult strControlJobManageReqResult;
    pptControlJobCreateRequest   strControlJobCreateRequest;
    objectIdentifier             dummyControlJobID;
    strControlJobCreateRequest.equipmentID = equipmentID;
    strControlJobCreateRequest.portGroupID = portGroupID;
    strControlJobCreateRequest.strStartCassette = tmpStartCassette;
    rc = txControlJobManageReq( strControlJobManageReqResult,
                                strObjCommonIn,
                                dummyControlJobID,
                                SP_ControlJobAction_Type_create,
                                strControlJobCreateRequest,
                                claimMemo );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "txControlJobManageReq() != RC_OK");
        strStartLotsReservationReqResult.strResult = strControlJobManageReqResult.strResult;
        return( rc );
    }
//D7000006 Add End

    /*----------------------------------------------------*/
    /*                                                    */
    /*   Set Start Reserved Control Job into Equipment    */
    /*                                                    */
    /*----------------------------------------------------*/
    objEquipment_reservedControlJobID_Set_out strEquipment_reservedControlJobID_Set_out;
//D7000006    rc = equipment_reservedControlJobID_Set( strEquipment_reservedControlJobID_Set_out,
//D7000006                                             strObjCommonIn, equipmentID, strControlJob_Create_out.controlJobID );
//D7000006 Add Start
    rc = equipment_reservedControlJobID_Set( strEquipment_reservedControlJobID_Set_out,
                                             strObjCommonIn,
                                             equipmentID,
                                             strControlJobManageReqResult.controlJobID );
//D7000006 Add End
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationReq", "equipment_reservedControlJobID_Set() != RC_OK");
        strStartLotsReservationReqResult.strResult = strEquipment_reservedControlJobID_Set_out.strResult;
        return( rc );
    }

    /*----------------------------------------------------*/
    /*                                                    */
    /*   Get Start Information for each Cassette / Lot    */
    /*                                                    */
    /*   - strStartCassette information is not filled     */
    /*     perfectly. By this object function, it will    */
    /*     be filled.                                     */
    /*                                                    */
    /*----------------------------------------------------*/
    objProcess_startReserveInformation_Get_out strProcess_startReserveInformation_Get_out;
    strProcess_startReserveInformation_Get_out.strStartCassette = tmpStartCassette;
    rc = process_startReserveInformation_Get( strProcess_startReserveInformation_Get_out,
                                              strObjCommonIn, equipmentID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationReq", "process_startReserveInformation_Get() != RC_OK");
        strStartLotsReservationReqResult.strResult = strProcess_startReserveInformation_Get_out.strResult;
        return( rc );
    }

//D8000024 add start
    // Apply FPCInformation for StartCassette.

//D9000001    CORBA::Long  tmpFPCAdoptFlag = atol( getenv(SP_FPC_Adaptation_Flag) );
    CORBA::Long  tmpFPCAdoptFlag = atoi( getenv(SP_FPC_Adaptation_Flag) );    //D9000001
    if( 1 == tmpFPCAdoptFlag )
    {
        PPT_METHODTRACE_V1("","FPC Adopt Flag is ON. Now apply FPCInfo.");
        objFPCStartCassetteInfo_Exchange_out  strFPCStartCassetteInfo_Exchange_out;
        rc = FPCStartCassetteInfo_Exchange( strFPCStartCassetteInfo_Exchange_out,
                                            strObjCommonIn,
                                            SP_FPC_ExchangeType_StartReserveReq,
                                            equipmentID,
                                            strProcess_startReserveInformation_Get_out.strStartCassette );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("","FPCStartCassetteInfo_Exchange() != RC_OK", rc);
            strStartLotsReservationReqResult.strResult = strFPCStartCassetteInfo_Exchange_out.strResult;

            return rc;
        }
        strProcess_startReserveInformation_Get_out.strStartCassette = strFPCStartCassetteInfo_Exchange_out.strStartCassette;
    }
    else
    {
        PPT_METHODTRACE_V1("","FPC Adopt Flag is OFF. Now only check whiteFlag.");
        objFPC_startCassette_processCondition_Check_out  strFPC_startCassette_processCondition_Check_out;
        rc = FPC_startCassette_processCondition_Check( strFPC_startCassette_processCondition_Check_out,
                                                       strObjCommonIn,
                                                       equipmentID,
                                                       strProcess_startReserveInformation_Get_out.strStartCassette,
                                                       FALSE,     // FPC category check
                                                       TRUE );    // FPC whiteFlag check
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("","FPC_startCassette_processCondition_Check() != RC_OK", rc);
            strStartLotsReservationReqResult.strResult = strFPC_startCassette_processCondition_Check_out.strResult;

            return rc;
        }
    }
//D8000024 add end

    /*----------------------------------------------------*/
    /*                                                    */
    /*   Set Start Reservation Info to Each Lots' PO      */
    /*                                                    */
    /*   - Set created controlJobID into each cassette.   */
    /*   - Set created controlJobID into each lot.        */
    /*   - Set control job info (StartRecipe, DCDefs,     */
    /*     DCSpecs, Parameters, ...) into each lot's      */
    /*     current PO.                                    */
    /*                                                    */
    /*----------------------------------------------------*/
//D9000003 delete start
//    objProcess_startReserveInformation_Set_out strProcess_startReserveInformation_Set_out;
//    // P3000094 change controlJobID -> strControlJob_Create_out.controlJobID
////D7000006    rc = process_startReserveInformation_Set( strProcess_startReserveInformation_Set_out,
////D7000006                                              strObjCommonIn, equipmentID, portGroupID,
////D7000006                                              strControlJob_Create_out.controlJobID,
////D7000006//                                            tmpStartCassette );
////D7000006                                              strProcess_startReserveInformation_Get_out.strStartCassette );
//    //D7000006 Add Start
//    rc = process_startReserveInformation_Set( strProcess_startReserveInformation_Set_out,
//                                              strObjCommonIn,
//                                              equipmentID,
//                                              portGroupID,
//                                              strControlJobManageReqResult.controlJobID,
//                                              strProcess_startReserveInformation_Get_out.strStartCassette );
//    //D7000006 Add End
//    if ( rc != RC_OK )
//    {
//        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationReq", "process_startReserveInformation_Set() != RC_OK");
//        strStartLotsReservationReqResult.strResult = strProcess_startReserveInformation_Set_out.strResult;
//        return( rc );
//   }
//D9000003 delete end
//D9000003 add start
    objProcess_startReserveInformation_Set_out__090 strProcess_startReserveInformation_Set_out__090;
    objProcess_startReserveInformation_Set_in__090 strProcess_startReserveInformation_Set_in__090;
    strProcess_startReserveInformation_Set_in__090.equipmentID = equipmentID;
    strProcess_startReserveInformation_Set_in__090.portGroupID = portGroupID;
    strProcess_startReserveInformation_Set_in__090.controlJobID = strControlJobManageReqResult.controlJobID;
    strProcess_startReserveInformation_Set_in__090.strStartCassette = strProcess_startReserveInformation_Get_out.strStartCassette;
    strProcess_startReserveInformation_Set_in__090.processJobPauseFlag = FALSE;

    rc = process_startReserveInformation_Set__090( strProcess_startReserveInformation_Set_out__090, strObjCommonIn, strProcess_startReserveInformation_Set_in__090);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationReq", "process_startReserveInformation_Set__090() != RC_OK");
        strStartLotsReservationReqResult.strResult = strProcess_startReserveInformation_Set_out__090.strResult;
        return( rc );
    }
//D9000003 add end

//DSIV00001830 add start
    //-----------------------------------------------------------//
    //  Wafer Stacking Operation                                 //
    //    If Equipment Category is SP_Mc_Category_WaferBonding,  //
    //    update Bonding Group Information                       //
    //-----------------------------------------------------------//
    objLot_bondingGroup_UpdateByOperation_out strLot_bondingGroup_UpdateByOperation_out;
    objLot_bondingGroup_UpdateByOperation_in strLot_bondingGroup_UpdateByOperation_in;
    strLot_bondingGroup_UpdateByOperation_in.equipmentID = equipmentID;
    strLot_bondingGroup_UpdateByOperation_in.controlJobID = strControlJobManageReqResult.controlJobID;
    strLot_bondingGroup_UpdateByOperation_in.strStartCassette = strProcess_startReserveInformation_Get_out.strStartCassette;
    strLot_bondingGroup_UpdateByOperation_in.operation = CIMFWStrDup( SP_Operation_StartReservation );

    PPT_METHODTRACE_V1("", "call lot_bondingGroup_UpdateByOperation()");
    rc = lot_bondingGroup_UpdateByOperation( strLot_bondingGroup_UpdateByOperation_out, strObjCommonIn, strLot_bondingGroup_UpdateByOperation_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2( "", "lot_bondingGroup_UpdateByOperation() != RC_OK", rc );
        strStartLotsReservationReqResult.strResult = strLot_bondingGroup_UpdateByOperation_out.strResult;
        return (rc);
    }
//DSIV00001830 add end

    /*-------------------------------------------*/
    /*                                           */
    /*   Send TxStartLotsReservationReq to TCS   */
    /*                                           */
    /*-------------------------------------------*/

//    /*------------------------------*/
//    /*   Get Cell Controller Name   */
//    /*------------------------------*/
//    objEquipment_cellController_Gett_out strEquipment_cellController_Get_out;
//    rc = equipment_cellController_Get( strEquipment_cellController_Get_out, strObjCommonIn,
//                                       equipmentID );
//    if ( rc != RC_OK )
//    {
//        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationReq", "equipment_cellController_Get() != RC_OK");
//        strStartLotsReservationReqResult.strResult = strEquipment_cellController_Get_out.strResult;
//        return( rc );
//    }

//    if ( CIMFWStrCmp(strEquipment_cellController_Get_out.cellController.identifier, "") != 0)
//    {
    /*----------------------------------------*/
    /*   Send Start Lots Reservation to TCS   */
    /*----------------------------------------*/
//D4000060        objTCSMgr_SendStartLotsReservationReq_out strTCSMgr_SendStartLotsReservationReq_out;
//D4000060        // P3000094 change controlJobID -> strControlJob_Create_out.controlJobID
//D4000060//0.02  rc = TCSMgr_SendStartLotsReservationReq(strTCSMgr_SendStartLotsReservationReq_out, strObjCommonIn,
//D4000060//0.02                                          strObjCommonIn.strUser, equipmentID,
//D4000060//0.02                                          portGroupID, strControlJob_Create_out.controlJobID, tmpStartCassette,
//D4000060//0.02                                          claimMemo);
//D4000060        //0.02 add start
//D4000060        rc = TCSMgr_SendStartLotsReservationReq(strTCSMgr_SendStartLotsReservationReq_out,
//D4000060                                                strObjCommonIn,
//D4000060                                                strObjCommonIn.strUser,
//D4000060                                                equipmentID,
//D4000060                                                portGroupID,
//D4000060                                                strControlJob_Create_out.controlJobID,
//D4000060                                                strProcess_startReserveInformation_Get_out.strStartCassette,
//D4000060                                                claimMemo);
//D4000060        //0.02 add end
//D4000060        if ( rc != RC_OK )
//D4000060        {
//D4000060            PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationReq", "TCSMgr_SendStartLotsReservationReq() != RC_OK");
//D4000060            strStartLotsReservationReqResult.strResult = strTCSMgr_SendStartLotsReservationReq_out.strResult;
//D4000060            return( rc );
//D4000060        }
//D4000060 add start
    CORBA::String_var tmpSleepTimeValue = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
    CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));
    CORBA::Long sleepTimeValue;
    CORBA::Long retryCountValue;

    if (CIMFWStrLen(tmpSleepTimeValue) == 0)
    {
        sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
    }
    else
    {
//D9000001            sleepTimeValue = atol(tmpSleepTimeValue) ;
        sleepTimeValue = atoi(tmpSleepTimeValue) ;    //D9000001
    }

    if (CIMFWStrLen(tmpRetryCountValue) == 0)
    {
        retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
    }
    else
    {
//D9000001            retryCountValue = atol(tmpRetryCountValue);
        retryCountValue = atoi(tmpRetryCountValue);    //D9000001
    }

    PPT_METHODTRACE_V2("","env value of SP_BIND_SLEEP_TIME_TCS  = ",sleepTimeValue);
    PPT_METHODTRACE_V2("","env value of SP_BIND_RETRY_COUNT_TCS = ",retryCountValue);

    objTCSMgr_SendStartLotsReservationReq_out strTCSMgr_SendStartLotsReservationReq_out;

    //'retryCountValue + 1' means first try plus retry count
    for (i = 0 ; i < (retryCountValue + 1) ; i++)
    {
        /*--------------------------*/
        /*    Send Request to TCS   */
        /*--------------------------*/
        rc = TCSMgr_SendStartLotsReservationReq( strTCSMgr_SendStartLotsReservationReq_out,
                                                 strObjCommonIn,
                                                 strObjCommonIn.strUser,
                                                 equipmentID,
                                                 portGroupID,
//D7000006                                                     strControlJob_Create_out.controlJobID,
                                                 strControlJobManageReqResult.controlJobID, //D7000006
                                                 strProcess_startReserveInformation_Get_out.strStartCassette,
                                                 claimMemo );
        PPT_METHODTRACE_V2("","rc = ",rc);

        if (rc == RC_OK)
        {
            PPT_METHODTRACE_V1("","Now TCS subSystem is alive!! Go ahead");
            break;
        }
        else if ( rc == RC_EXT_SERVER_BIND_FAIL ||
                  rc == RC_EXT_SERVER_NIL_OBJ   ||
                  rc == RC_TCS_NO_RESPONSE )
        {
            PPT_METHODTRACE_V2("","TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...",i);
            PPT_METHODTRACE_V2("","now sleeping... ",sleepTimeValue);
            sleep(sleepTimeValue);
            continue;
        }
        else
        {
            PPT_METHODTRACE_V1("", "TCSMgr_SendStartLotsReservationReq() != RC_OK");
            strStartLotsReservationReqResult.strResult = strTCSMgr_SendStartLotsReservationReq_out.strResult;
            return( rc );
        }

    }

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "TCSMgr_SendStartLotsReservationReq() != RC_OK");
        strStartLotsReservationReqResult.strResult = strTCSMgr_SendStartLotsReservationReq_out.strResult;
        return( rc );
    }
//D4000060 add end
//    }

//D51M0000 add start
//D7000006    /*-------------------------------------------------*/
//D7000006    /*   call controlJob_status_Change                 */
//D7000006    /*-------------------------------------------------*/
//D7000006    PPT_METHODTRACE_V1("", "call controlJob_status_Change");
//D7000006    objControlJob_status_Change_out strControlJob_status_Change_out;
//D7000006    rc = controlJob_status_Change ( strControlJob_status_Change_out,
//D7000006                                    strObjCommonIn,
//D7000006                                    strControlJob_Create_out.controlJobID,
//D7000006                                    SP_APC_ControlJobStatus_Created );
//D7000006    if ( rc != RC_OK )
//D7000006    {
//D7000006        PPT_METHODTRACE_V1("", "controlJob_status_Change() != RC_OK");
//D7000006        strStartLotsReservationReqResult.strResult = strControlJob_status_Change_out.strResult;
//D7000006        return( rc );
//D7000006    }

    /*-------------------------------------------------*/
    /*   call APCRuntimeCapability_RegistDR            */
    /*-------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call APCRuntimeCapability_RegistDR");
    objAPCRuntimeCapability_RegistDR_out strAPCRuntimeCapability_RegistDR_out;
    rc = APCRuntimeCapability_RegistDR ( strAPCRuntimeCapability_RegistDR_out,
                                         strObjCommonIn,
//D7000006                                         strControlJob_Create_out.controlJobID,
                                         strControlJobManageReqResult.controlJobID, //D7000006
                                         strAPCRunTimeCapabilityInqResult.strAPCRunTimeCapabilityResponse );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "APCRuntimeCapability_RegistDR() != RC_OK");
        strStartLotsReservationReqResult.strResult = strAPCRuntimeCapability_RegistDR_out.strResult;
        return( rc );
    }

    /*-------------------------------------------------*/
    /*   call cassette_APCInformation_GetDR            */
    /*-------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call cassette_APCInformation_GetDR");
    objCassette_APCInformation_GetDR_out strCassette_APCInformation_GetDR_out;
    rc = cassette_APCInformation_GetDR ( strCassette_APCInformation_GetDR_out,
                                         strObjCommonIn,
                                         equipmentID,
                                         tmpStartCassette );
    if ( rc == RC_SYSTEM_ERROR )
    {
        PPT_METHODTRACE_V1("", "cassette_APCInformation_GetDR() == RC_SYSTEM_ERROR");
        strStartLotsReservationReqResult.strResult = strCassette_APCInformation_GetDR_out.strResult;
        return ( rc ) ;
    }
    else if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cassette_APCInformation_GetDR() != RC_OK");
        strStartLotsReservationReqResult.strResult = strCassette_APCInformation_GetDR_out.strResult;
    }

    /*-------------------------------------------------*/
    /*   call APCMgr_SendControlJobInformationDR       */
    /*-------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call APCMgr_SendControlJobInformationDR");
    objAPCMgr_SendControlJobInformationDR_out strAPCMgr_SendControlJobInformationDR_out;
    rc = APCMgr_SendControlJobInformationDR ( strAPCMgr_SendControlJobInformationDR_out,
                                              strObjCommonIn,
                                              equipmentID,
//D7000006                                              strControlJob_Create_out.controlJobID,
                                              strControlJobManageReqResult.controlJobID, //D7000006
                                              SP_APC_ControlJobStatus_Created,
                                              strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList );
//D7000182    if ( rc != RC_OK )
    if ( rc != RC_OK && rc != RC_OK_NO_IF )    //D7000182
    {
        PPT_METHODTRACE_V1("", "APCMgr_SendControlJobInformationDR() != RC_OK");
        strStartLotsReservationReqResult.strResult = strAPCMgr_SendControlJobInformationDR_out.strResult;
        return( rc );
    }
//D7000182 add start
    if( rc == RC_OK )
    {
        PPT_METHODTRACE_V1("", "APCControlJobInformation was sent normally.");
        CORBA::String_var tmpString = APCIFControlStatus;
        APCIFControlStatus = CIMFWStrDup(SP_APC_ControlJobStatus_Canceled);
    }
//D7000182 add end
//D51M0000 add end

    traceSampledStartCassette( tmpStartCassette );  //D9000003

    /*--------------------*/
    /*                    */
    /*   Return to Main   */
    /*                    */
    /*--------------------*/
//D7000006    strStartLotsReservationReqResult.controlJobID = strControlJob_Create_out.controlJobID; //0.01
    strStartLotsReservationReqResult.controlJobID = strControlJobManageReqResult.controlJobID; //D7000006
    SET_MSG_RC ( strStartLotsReservationReqResult, MSG_OK, RC_OK );

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txStartLotsReservationReq");
    return ( RC_OK );
}
