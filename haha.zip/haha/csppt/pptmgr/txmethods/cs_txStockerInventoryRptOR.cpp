#ifndef lint
static char *sccsid =  "@(#) 1.3 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txStockerInventoryRptOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/18/08 17:33:49 [ 7/18/08 17:33:50 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: txStockerInventoryRpt.cpp
//

#include "cs_pptmgr.hpp"

// Class: PPTManager
//
// Service: txStockerInventoryRpt()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/23          O.Sugiyama     Initial Release
// 2003/11/27 D5100078 S.Yamamoto     Delete unnecessary event creation object methods.
// 2003/12/11 P5100002 M.Kase         Delete lotCassetteXferEvent_Make()
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2008/07/15 P9000368 K.Kido         1.Check FOSB  2.Object lock for equipment port 3.Object lock for cassette
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2012/11/29 DSN000049350 S.Liu          Equipment parallel processing support (P2)
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/10 INN-R170003  YangXigang     Durable Management Enhancement
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    pptStockerInventoryRptResult&       strStockerInventoryRptResult
//    const pptObjCommonIn&               strObjCommonIn
//    const objectIdentifier&             stockerID
//    const pptInventoryLotInfoSequence&  strInventoryLotInfo
//    const char *                        claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::txStockerInventoryRpt (
    pptStockerInventoryRptResult&       strStockerInventoryRptResult, 
    const pptObjCommonIn&               strObjCommonIn,  
    const objectIdentifier&             stockerID,  
    const pptInventoryLotInfoSequence&  strInventoryLotInfo,  
//D6000025     const char *                        claimMemo,  
//D6000025     CORBA::Environment &                IT_env)
    const char *                        claimMemo   //D6000025
    CORBAENV_LAST_CPP)                              //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txStockerInventoryRpt ");

    CORBA::Long rc;
//P9000368    CORBA::Long rcDataError;

    /*-----------------------------------*/
    /*   Request for Automated Stocker   */
    /*-----------------------------------*/

    objCassette_position_UpdateByStockerInventory_out  strCassette_position_UpdateByStockerInventory_out;

    if (CIMFWStrLen(stockerID.identifier) > 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryRpt", "CIMFWStrLen(stockerID.identifier) > 0 && CIMFWStrLen(stockerID.stringifiedObjectReference) > 0") ;

        strStockerInventoryRptResult.stockerID = stockerID ;

        /*--------------------------------*/
        /*   Lock objects to be updated   */
        /*--------------------------------*/
        objObject_Lock_out strObject_Lock_out;

        rc = object_Lock( strObject_Lock_out, strObjCommonIn, stockerID, SP_ClassName_PosStorageMachine );
        if ( rc != RC_OK ) 
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryRpt", "object_Lock() rc != RC_OK");
            strStockerInventoryRptResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }

        /*------------------------*/
        /*   Check Stocker Type   */
        /*------------------------*/

        objStocker_type_Get_out strStocker_type_Get_out;
        rc = stocker_type_Get(strStocker_type_Get_out,strObjCommonIn,stockerID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryRpt", "rc != RC_OK");
            strStockerInventoryRptResult.strResult = strStocker_type_Get_out.strResult;
            return( rc );
        }
        if (CIMFWStrCmp(strStocker_type_Get_out.stockerType, SP_Stocker_Type_Auto)   != 0 &&
            CIMFWStrCmp(strStocker_type_Get_out.stockerType, SP_Stocker_Type_Interm) != 0)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryRpt", "CIMFWStrCmp(strStocker_type_Get_out.stockerType, SP_Stocker_Type_*)");
            PPT_SET_MSG_RC_KEY(strStockerInventoryRptResult,MSG_NOT_AUTO_STOCKER,RC_NOT_AUTO_STOCKER,
                               stockerID.identifier);
            return( RC_NOT_AUTO_STOCKER );
        }

//P9000368 add start
        //------------------------------------------------------
        //   1. Omit FOSB from input parameter.
        //   2. Lock equipment object of 'EI' cassette.
        //------------------------------------------------------
        CORBA::Boolean NotFoundfoupFlg = FALSE;

        CORBA::ULong nLen = strInventoryLotInfo.length();
        PPT_METHODTRACE_V2("","strInventoryLotInfo.length() =", nLen) ;

        pptInventoryLotInfoSequence carrierInfoSeq, FOSBInfoSeq;
        carrierInfoSeq.length(nLen);
        FOSBInfoSeq.length(nLen);
        CORBA::ULong fpCnt = 0, fbCnt = 0 , eqpCnt = 0;

        objectIdentifierSequence equipmentSeq;
        equipmentSeq.length(nLen);

        objectIdentifierSequence carrierLoadEqpIDSeq; //DSN000049350
        carrierLoadEqpIDSeq.length(nLen);             //DSN000049350

        for ( CORBA::ULong i = 0 ; i < nLen ; i++ )
        {
            /*-----------------------------------------------------------*/
            /*  Check carrier existence and get location information     */
            /*-----------------------------------------------------------*/
            objCassette_LocationInfo_GetDR_out strCassette_LocationInfo_GetDR_out;
            rc = cassette_LocationInfo_GetDR( strCassette_LocationInfo_GetDR_out,
                                              strObjCommonIn,
                                              strInventoryLotInfo[i].cassetteID );

            if( rc == RC_NOT_FOUND_CASSETTE )
            {
                PPT_METHODTRACE_V2("", "Reported carrier is not registered in MM    ID = ", strInventoryLotInfo[i].cassetteID.identifier);
                FOSBInfoSeq[fbCnt] = strInventoryLotInfo[i] ;
                fbCnt++;
                NotFoundfoupFlg = TRUE;
                continue;
            }
            else if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "cassette_LocationInfo_GetDR() != RC_OK") ;
                strStockerInventoryRptResult.strResult = strCassette_LocationInfo_GetDR_out.strResult ;
                return ( rc );
            }

            PPT_METHODTRACE_V2("", "Reported carrier ID is registered in MM    ID = ", strInventoryLotInfo[i].cassetteID.identifier);
            carrierInfoSeq[fpCnt] = strInventoryLotInfo[i] ;
            carrierLoadEqpIDSeq[fpCnt].identifier = CIMFWStrDup(""); //DSN000049350
            fpCnt++;

            /*---------------------------------------------------------------*/
            /*  If carrier location is 'EI', get equipmentID for object lock */
            /*---------------------------------------------------------------*/
            //INN-R170003 if( 0 == CIMFWStrCmp(strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus, SP_TransState_EquipmentIn)
            //INN-R170003 add start
            if( 0 == CIMFWStrCmp(strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus, SP_TransState_EquipmentIn) ||
                0 == CIMFWStrCmp(strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus, SP_TransState_EquipmentOut)||
                0 == CIMFWStrCmp(strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus, CS_TRANS_STATE_PORT_IN)
              )
            //INN-R170003 add end
            {
                /*---------------------------------------------------------------*/
                /*  Check control job existence. If exist, no need to list up    */
                /*---------------------------------------------------------------*/
                PPT_METHODTRACE_V2("", "strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus = ", strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus);
                objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;
                rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                                strObjCommonIn,
                                                strInventoryLotInfo[i].cassetteID );

                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "cassette_controlJobID_Get() != RC_OK") ;
                    strStockerInventoryRptResult.strResult = strCassette_controlJobID_Get_out.strResult ;
                    return ( rc );
                }

                if( 0 != CIMFWStrLen( strCassette_controlJobID_Get_out.controlJobID.identifier ) )
                {
                    PPT_METHODTRACE_V1("", "cassette has controljob ...");
                    continue;
                }
                
                // set load equipment ID
                carrierLoadEqpIDSeq[fpCnt-1] = strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.equipmentID; //DSN000049350

                /*-----------------------------------------------------*/
                /*  Check whether equipment already collected or not   */
                /*-----------------------------------------------------*/
                CORBA::Boolean alreadyCollectedFlag = FALSE ;
                CORBA::ULong collectedEqpLen = equipmentSeq.length();
                for( CORBA::ULong j = 0 ; j < collectedEqpLen ; j++ )
                {
                    if( 0 == CIMFWStrCmp( equipmentSeq[j].identifier, strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.equipmentID.identifier) )
                    {
                        alreadyCollectedFlag = TRUE;
                        break;
                    }
                }

                if( FALSE == alreadyCollectedFlag )
                {
                    equipmentSeq[eqpCnt] = strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.equipmentID;
                    eqpCnt++;
                }
            }
        }
        carrierInfoSeq.length(fpCnt);
        FOSBInfoSeq.length(fbCnt);
        equipmentSeq.length(eqpCnt);
        carrierLoadEqpIDSeq.length(fpCnt);            //DSN000049350
        PPT_METHODTRACE_V2( "", "eqpCnt", eqpCnt);    //DSN000049350
        PPT_METHODTRACE_V2( "", "fpCnt", fpCnt);      //DSN000049350

        /*------------------*/
        /*  Screen log out  */
        /*------------------*/
        CORBA::ULong logCnt = 0 ;
        for( logCnt = 0 ; logCnt < fpCnt ; logCnt++ )
        {
            PPT_METHODTRACE_V2("","## carrierID = ", carrierInfoSeq[logCnt].cassetteID.identifier);
        }
        for( logCnt = 0 ; logCnt < fbCnt ; logCnt++ )
        {
            PPT_METHODTRACE_V2("","## FOSB ID   = ", FOSBInfoSeq[logCnt].cassetteID.identifier);
        }
        for( logCnt = 0 ; logCnt < eqpCnt ; logCnt++ )
        {
            PPT_METHODTRACE_V2("","## equipmentID = ", equipmentSeq[logCnt].identifier);
        }

        /*---------------------------------------------------------------*/
        /*  Set reason text if FOSB is included in reported carrieres    */
        /*---------------------------------------------------------------*/
        CORBA::String_var reasonText;
        if( 0 != fbCnt )
        {
            ostrstream errorMsg;
            errorMsg << "[Information : FOSB reported : Following reported carriers are FOSB. Its location was not changed.] =>" ;

            for( CORBA::ULong i = 0 ; i < fbCnt ; i++ )
            {
                errorMsg << (const char*)FOSBInfoSeq[i].cassetteID.identifier ;
                if( i < (fbCnt-1) )
                {
                    errorMsg << ", " ;
                }
            }

            errorMsg << ends;

            reasonText = CIMFWStrDup(errorMsg.str());
            errorMsg.rdbuf()->freeze(0);
            PPT_METHODTRACE_V2("","## reasonText = ", reasonText);
        }

        /*------------------------------------------------------*/
        /*   Lock equipment/FOUP object for check (and update)  */
        /*------------------------------------------------------*/
        CORBA::ULong lockCnt = 0 ;
        for( lockCnt = 0 ; lockCnt < eqpCnt ; lockCnt++ )
        {
//DSN000049350 Add Start
            objObject_lockMode_Get_out strObject_lockMode_Get_out;
            objObject_lockMode_Get_in  strObject_lockMode_Get_in;
            strObject_lockMode_Get_in.objectID           = equipmentSeq[lockCnt];
            strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
            strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXLGR003" ); // TxStockerInventoryRpt
            strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

            PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentSeq[lockCnt].identifier );
            rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                      strObjCommonIn,
                                      strObject_lockMode_Get_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
                strStockerInventoryRptResult.strResult = strObject_lockMode_Get_out.strResult;
                return( rc );
            }

            objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
            objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
            
            CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
            PPT_METHODTRACE_V2( "", "lockMode", lockMode );
            if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
            {
                PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");

                // Advanced Mode
                // Lock Equipment Main Object
                stringSequence dummySeq;
                dummySeq.length(0);
                strAdvanced_object_Lock_in.objectID   = equipmentSeq[lockCnt];
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
                strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
                strAdvanced_object_Lock_in.keySeq     = dummySeq;

                PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
                rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                           strObjCommonIn,
                                           strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strStockerInventoryRptResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }
                
                stringSequence loadCastSeq;
                loadCastSeq.length(fpCnt);
                CORBA::ULong loadCastCnt = 0;
                for ( CORBA::ULong castCnt = 0 ; castCnt < fpCnt ; castCnt++ )
                {
                    if ( 0 == CIMFWStrCmp( equipmentSeq[lockCnt].identifier, carrierLoadEqpIDSeq[castCnt].identifier) )
                    {
                        loadCastSeq[loadCastCnt] = carrierInfoSeq[castCnt].cassetteID.identifier;
                        loadCastCnt++;
                    }
                }
                loadCastSeq.length(loadCastCnt);
                PPT_METHODTRACE_V2( "", "loadCastCnt", loadCastCnt);
                
                // Lock Equipment LoadCassette Element (Write)
                if ( 0 < loadCastSeq.length() )
                {
                    strAdvanced_object_Lock_in.objectID   = equipmentSeq[lockCnt];
                    strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                    strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
                    strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
                    strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

                    PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_LoadCassette );
                    rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                               strObjCommonIn,
                                               strAdvanced_object_Lock_in );
                    if ( rc != RC_OK && rc != RC_NOT_FOUND_SOME_OBJECT)
                    {
                        PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                        strStockerInventoryRptResult.strResult = strAdvanced_object_Lock_out.strResult;
                        return( rc );
                    }
                }                
            }
            else
            {
                PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
                rc = object_Lock( strObject_Lock_out, strObjCommonIn,
                                  equipmentSeq[lockCnt], SP_ClassName_PosMachine );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "", "object_Lock(equipmentID) != RC_OK" );
                    strStockerInventoryRptResult.strResult = strObject_Lock_out.strResult;
                    return( rc );
                }
            } //DSN000049350
        }

        for( lockCnt = 0 ; lockCnt < fpCnt ; lockCnt++ )
        {
            rc = object_Lock( strObject_Lock_out, strObjCommonIn,
                              carrierInfoSeq[lockCnt].cassetteID, SP_ClassName_PosCassette );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "object_Lock(cassetteID) != RC_OK" );
                strStockerInventoryRptResult.strResult = strObject_Lock_out.strResult;
                return( rc );
            }
        }
//P9000368 add end

        /*--------------------------------*/
        /*   Update Cassette's position   */
        /*--------------------------------*/

//P9000368        rc = cassette_position_UpdateByStockerInventory(strCassette_position_UpdateByStockerInventory_out,strObjCommonIn,stockerID,strInventoryLotInfo);
        rc = cassette_position_UpdateByStockerInventory(strCassette_position_UpdateByStockerInventory_out,strObjCommonIn,stockerID,carrierInfoSeq);    //P9000368
        switch( rc )
        {
            case RC_OK:
                SET_MSG_RC(strStockerInventoryRptResult, MSG_OK, RC_OK) ;    //P9000368
                break;
            case RC_SOMECASTINV_DATA_ERROR:
                 PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryRpt", "case RC_SOMECASTINV_DATA_ERROR:");
                SET_MSG_RC(strStockerInventoryRptResult, MSG_OK, RC_OK) ;                                                                      //P9000368
                strStockerInventoryRptResult.strResult.reasonText = strCassette_position_UpdateByStockerInventory_out.strResult.reasonText;    //P9000368
//P9000368      rcDataError = RC_SOMECASTINV_DATA_ERROR;
                break;
            default:
                 PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryRpt", "default:");
                strStockerInventoryRptResult.strResult = strCassette_position_UpdateByStockerInventory_out.strResult;
                return( rc );
        }

//P9000368 add start
        /*-----------------------*/
        /*   Set reason text     */
        /*-----------------------*/
        if( 0 != CIMFWStrLen(reasonText) )
        {
            ostrstream errorMsg;
            errorMsg << reasonText << strStockerInventoryRptResult.strResult.reasonText << ends;

            strStockerInventoryRptResult.strResult.reasonText = CIMFWStrDup(errorMsg.str());
            errorMsg.rdbuf()->freeze(0);
            PPT_METHODTRACE_V2("","## final reasonText = ", strStockerInventoryRptResult.strResult.reasonText);
        }
//P9000368 add end

        /*-----------------------------*/
        /*   Change Inventory Status   */
        /*-----------------------------*/

        objStocker_inventoryState_Change_out strStocker_inventoryState_Change_out;
        rc = stocker_inventoryState_Change(strStocker_inventoryState_Change_out,strObjCommonIn,stockerID, FALSE);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryRpt", "rc != RC_OK");
            strStockerInventoryRptResult.strResult = strStocker_inventoryState_Change_out.strResult;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryRpt", "CIMFWStrLen(stockerID.identifier) < 0 || CIMFWStrLen(stockerID.stringifiedObjectReference) < 0");
        SET_MSG_RC(strStockerInventoryRptResult,MSG_INVALID_INPUT_PARM,RC_INVALID_INPUT_PARM);
        return( RC_INVALID_INPUT_PARM );
    }

//    strStockerInventoryRptResult.strInventoriedLotInfo = strCassette_position_UpdateByStockerInventory_out.strInventoriedLotInfo ;
//P9000368    strStockerInventoryRptResult.strResult = strCassette_position_UpdateByStockerInventory_out.strResult ;

//P5100002    CORBA::Long nLen = strCassette_position_UpdateByStockerInventory_out.strInventoriedLotInfo.length();
//P5100002    PPT_METHODTRACE_V2("CS_PPTManager_i:: txStockerInventoryRpt", "strCassette_position_UpdateByStockerInventory_out.strInventoriedLotInfo.length()", nLen);
//P5100002    objCFMMgr_MakeLotInfo_out strCFMMgr_MakeLotInfo_out;
//P5100002
//P5100002    for (CORBA::Long j = 0; j < nLen ; j++)
//P5100002    {
//P5100002        CORBA::String_var aTmpStr = ConvertLongtoString( RC_OK ) ;
//P5100002        if( CIMFWStrCmp(strCassette_position_UpdateByStockerInventory_out.strInventoriedLotInfo[j].returnCode, aTmpStr) != 0 )
//P5100002        {
//P5100002            PPT_METHODTRACE_V2("CS_PPTManager_i:: txStockerInventoryRpt", "atol(strCassette_position_UpdateByStockerInventory_out.strInventoriedLotInfo[j].returnCode) != RC_OK", j);
//P5100002            continue;
//P5100002        }
//P5100002
//P5100002        /*---------------------------------*/
//P5100002        /*   Check empty cassette or not   */
//P5100002        /*---------------------------------*/
//P5100002        objCassette_CheckEmpty_out strCassette_CheckEmpty_out;
//P5100002        objCassette_lot_Get_out    strCassette_lot_Get_out;
//P5100002
//P5100002        rc = cassette_CheckEmpty( strCassette_CheckEmpty_out,
//P5100002                                  strObjCommonIn,
//P5100002                                  strCassette_position_UpdateByStockerInventory_out.strInventoriedLotInfo[j].cassetteID );
//P5100002
//P5100002        if (rc == RC_OK)
//P5100002        {
//P5100002            PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryRpt", "cassette_CheckEmpty() == RC_OK");
//P5100002            continue;
//P5100002        }
//P5100002        else if (rc == RC_CAST_NOT_EMPTY)
//P5100002        {
//P5100002            PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryRpt", "cassette_CheckEmpty() == RC_CAST_NOT_EMPTY");
//P5100002        }
//P5100002        else
//P5100002        {
//P5100002            PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryRpt", "cassette_CheckEmpty() != RC_OK and != RC_CAST_NOT_EMPTY " );
//P5100002            strStockerInventoryRptResult.strResult = strCassette_CheckEmpty_out.strResult ;
//P5100002            return rc;
//P5100002        }
//P5100002
//D5100078        /*------------------*/
//D5100078        /*   CFM Trx Make   */
//D5100078        /*------------------*/
//D5100078        objLotCassetteXferEvent_Make_out strLotCassetteXferEvent_Make_out;
//D5100078        rc = lotCassetteXferEvent_Make(strLotCassetteXferEvent_Make_out, strObjCommonIn, "TXLGR003", strCassette_position_UpdateByStockerInventory_out.strInventoriedLotInfo[j].lotID,
//D5100078                                       strCassette_position_UpdateByStockerInventory_out.strInventoriedLotInfo[j].cassetteID, claimMemo );
//D5100078        if (rc)
//D5100078        {
//D5100078            PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryRpt", "rc != RC_OK");
//D5100078            strStockerInventoryRptResult.strResult = strLotCassetteXferEvent_Make_out.strResult ;
//D5100078            return rc;
//D5100078        }
//P5100002    }

    /*-----------------------*/
    /*   Set out structure   */
    /*-----------------------*/

//P9000368    if( rcDataError == RC_SOMECASTINV_DATA_ERROR )
//P9000368    {
//P9000368        PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryRpt", "rcDataError == RC_SOMECASTINV_DATA_ERROR");
//P9000368        strStockerInventoryRptResult.strResult = strCassette_position_UpdateByStockerInventory_out.strResult;
//P9000368    }
//P9000368    else
//P9000368    {
//P9000368        PPT_METHODTRACE_V1("CS_PPTManager_i:: txStockerInventoryRpt", "rcDataError != RC_SOMECASTINV_DATA_ERROR");
//P9000368        strStockerInventoryRptResult.strResult.returnCode = ConvertLongtoString( RC_OK ) ;
//P9000368    }
//P9000368
    SET_MSG_RC(strStockerInventoryRptResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txStockerInventoryRpt ");
    return RC_OK ;
}

