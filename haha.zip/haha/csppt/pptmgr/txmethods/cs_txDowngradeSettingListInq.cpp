//
// (c) Copyright: IBM Japan Industrial Solution Co., Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txDowngradeSettingListInq.cpp
//
#include "cs_pptmgr.hpp"
//
// Class: PPTManager
//
// Service: txDowngradeSettingListInq()
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------- -------------- -------------------------------------------
// 2017-10-18 INN-R170016   Thomas Song    NPW Monitor Customization 
//
// Description:
//
// Return:
//     long
//
// Parameter:
//     csDowngradeSettingListInqResult&            strDowngradeSettingListInqResult
//     const pptObjCommonIn&                       strObjCommonIn
//     const csDowngradeSettingListInqInParm&      strDowngradeSettingListInqInParm
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//
CORBA::Long CS_PPTManager_i::cs_txDowngradeSettingListInq(
    csDowngradeSettingListInqResult&            strDowngradeSettingListInqResult,
    const pptObjCommonIn&                       strObjCommonIn,
    const csDowngradeSettingListInqInParm&      strDowngradeSettingListInqInParm
  	CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txDowngradeSettingListInq")
    CORBA::Long rc = RC_OK ;

    
    //---------------------------
    //  Set out structure
    //---------------------------
    SET_MSG_RC(strDowngradeSettingListInqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txDowngradeSettingListInq")
    return( RC_OK );

}