#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txStartLotsReservationForTakeOutInReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 2/27/08 14:42:30 [ 2/27/08 14:42:31 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2012. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2012. All rights reserved.
//
// SiView
// Name: cs_txStartLotsReservationForTakeOutInReqOR.cpp
//

#include "cs_pptmgr.hpp"

//=============================================================================
// For TXTRC079 : txStartLotsReservationForTakeOutInReq
//=============================================================================
// Class: CS_PPTManager
//
// Service: txStartLotsReservationForTakeOutInReq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2008/02/20 D9000175 K.Kido         Initial release for TakeOutIn transfer function.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2012/11/27 DSN000049350 F.Chen         Equipment parallel processing support (P2)
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/08/28 INN-R170002  Yangxiaojun    Overide txStartLotsReservationForTakeOutInReq
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptStartLotsReservationForTakeOutInReqResult&       strStartLotsReservationForTakeOutInReqResult,
//     const pptObjCommonIn&                               strObjCommonIn,
//     const pptStartLotsReservationForTakeOutInReqInParm& strStartLotsReservationForTakeOutInReqInParm,
//     const char *                                        claimMemo,
//
//typedef struct pptStartLotsReservationForTakeOutInReqInParm_struct
//{
//    objectIdentifier            equipmentID;               //<i>Equipment ID
//    string                      portGroupID;               //<i>Port Group ID
//    objectIdentifier            controlJobID;              //<i>Control Job ID
//    pptStartCassetteSequence    strStartCassetteSequence;  //<i>Start Cassette information
//    any siInfo;                                            //<i>Reserved for SI customization
//} pptStartLotsReservationForTakeOutInReqInParm;
//
//typedef struct pptLotCassetteTakeOutInReqResult_struct
//{
//    pptRetCode        strResult;           //<i>Transaction Result
//    objectIdentifier  controlJobID;        //<i>Control Job ID
//    string            APCIFControlStatus;  //<i>APCIF control status
//    any siInfo;                            //<i>Reserved for SI customization}
//}pptLotCassetteTakeOutInReqResult;
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::txStartLotsReservationForTakeOutInReq(
    pptStartLotsReservationForTakeOutInReqResult&       strStartLotsReservationForTakeOutInReqResult,
    const pptObjCommonIn&                               strObjCommonIn,
    const pptStartLotsReservationForTakeOutInReqInParm& strStartLotsReservationForTakeOutInReqInParm,
    const char *                                        claimMemo
    CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txStartLotsReservationForTakeOutInReq");
    CORBA::Long rc = RC_OK ;

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*   Initialize                                                          */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    objectIdentifier equipmentID;
    CORBA::String_var portGroupID;
    objectIdentifier controlJobID;
    pptStartCassetteSequence tmpStartCassette;
    equipmentID = strStartLotsReservationForTakeOutInReqInParm.equipmentID;
    portGroupID = strStartLotsReservationForTakeOutInReqInParm.portGroupID;
    controlJobID = strStartLotsReservationForTakeOutInReqInParm.controlJobID;
    tmpStartCassette = strStartLotsReservationForTakeOutInReqInParm.strStartCassetteSequence;

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Check Process                                                       */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    CORBA::ULong lenCassette = tmpStartCassette.length();
    if ( 0>= lenCassette )
    {
        PPT_METHODTRACE_V1("", "0>= CIMFWStrLen(tmpStartCassette.length())");
        SET_MSG_RC(strStartLotsReservationForTakeOutInReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM) ;
        return( RC_INVALID_INPUT_PARM );
    }

    PPT_METHODTRACE_V1("","Check Transaction ID and equipment Category combination.");

    objEquipment_categoryVsTxID_CheckCombination_out strEquipment_categoryVsTxID_CheckCombination_out;
    rc = equipment_categoryVsTxID_CheckCombination(
                                strEquipment_categoryVsTxID_CheckCombination_out,
                                strObjCommonIn,
                                equipmentID);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","equipment_categoryVsTxID_CheckCombination() returned error.");

        strStartLotsReservationForTakeOutInReqResult.strResult
            = strEquipment_categoryVsTxID_CheckCombination_out.strResult;
        return (rc);
    }

    //Input parameter check.
    //Check every lot has at least one wafer with processJobExecFlag == TRUE
    PPT_METHODTRACE_V1("","Check every lot has at least one wafer with processJobExecFlag == TRUE.");
    objLot_processJobExecFlag_ValidCheck_out strLot_processJobExecFlag_ValidCheck_out;
    objLot_processJobExecFlag_ValidCheck_in strLot_processJobExecFlag_ValidCheck_in;
    strLot_processJobExecFlag_ValidCheck_in.strStartCassette = tmpStartCassette;

    rc = lot_processJobExecFlag_ValidCheck(strLot_processJobExecFlag_ValidCheck_out, strObjCommonIn, strLot_processJobExecFlag_ValidCheck_in);
    if( rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","objLot_processJobExecFlag_ValidCheck() != RC_OK ");
        strStartLotsReservationForTakeOutInReqResult.strResult = strLot_processJobExecFlag_ValidCheck_out.strResult;
        return rc;
    }

    //-------------------------------------------------
    //  Check Scrap Wafer Exsit In Carrier
    //-------------------------------------------------
    objectIdentifierSequence cassetteIDs ;
    CORBA::Long castLen = tmpStartCassette.length();
    CORBA::Long cnt = 0;
    cassetteIDs.length( castLen ) ;

    for(cnt = 0 ; cnt < castLen; cnt++ )
    {
        cassetteIDs[cnt] = tmpStartCassette[cnt].cassetteID;
    }

    objCassette_scrapWafer_SelectDR_out  strCassette_scrapWafer_SelectDR_out;
    rc = cassette_scrapWafer_SelectDR( strCassette_scrapWafer_SelectDR_out,
                                       strObjCommonIn,
                                       cassetteIDs);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cassette_scrapWafer_SelectDR() != RC_OK",rc);
        strStartLotsReservationForTakeOutInReqResult.strResult = strCassette_scrapWafer_SelectDR_out.strResult;
        return (rc);
    }

    CORBA::Long scrapCount = strCassette_scrapWafer_SelectDR_out.strLotWaferMap.length();
    if( scrapCount > 0 )
    {
        PPT_METHODTRACE_V2("", "ScrapWafer Found ",scrapCount);
        SET_MSG_RC(strStartLotsReservationForTakeOutInReqResult, MSG_FOUND_SCRAP, RC_FOUND_SCRAP) ;
        return (RC_FOUND_SCRAP);
    }

    /*-----------------------------------------*/
    /*   call txAPCRunTimeCapabilityInq        */
    /*-----------------------------------------*/
    PPT_METHODTRACE_V1("", "call txAPCRunTimeCapabilityInq");
    pptAPCRunTimeCapabilityInqResult strAPCRunTimeCapabilityInqResult;
    rc = txAPCRunTimeCapabilityInq(strAPCRunTimeCapabilityInqResult,
                                   strObjCommonIn,
                                   equipmentID,
                                   controlJobID,
                                   tmpStartCassette,
                                   TRUE);
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "txAPCRunTimeCapabilityInq() != RC_OK");
        strStartLotsReservationForTakeOutInReqResult.strResult = strAPCRunTimeCapabilityInqResult.strResult;
        return( rc );
    }

    CORBA::Long RunCapaRespCount = strAPCRunTimeCapabilityInqResult.strAPCRunTimeCapabilityResponse.length();
    if( rc == RC_OK && RunCapaRespCount > 0 )
    {
        PPT_METHODTRACE_V1("", "Received RuntimeCapabilityResponse from APC.");
        strStartLotsReservationForTakeOutInReqResult.APCIFControlStatus = CIMFWStrDup(SP_APC_ControlJobStatus_Canceled);
    }

    /*------------------------------------------------*/
    /*   call txAPCRecipeParameterAdjustInq           */
    /*------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call txAPCRecipeParameterAdjustInq");
    pptAPCRecipeParameterAdjustInqResult strAPCRecipeParameterAdjustInqResult;
    rc = txAPCRecipeParameterAdjustInq(strAPCRecipeParameterAdjustInqResult,
                                       strObjCommonIn,
                                       equipmentID,
                                       tmpStartCassette,
                                       strAPCRunTimeCapabilityInqResult.strAPCRunTimeCapabilityResponse,
                                       TRUE);
    if(rc != RC_OK && rc != RC_OK_NO_IF)
    {
        PPT_METHODTRACE_V2("", "txAPCRecipeParameterAdjustInq() != RC_OK", rc);
        strStartLotsReservationForTakeOutInReqResult.strResult = strAPCRecipeParameterAdjustInqResult.strResult;
        return rc;
    }
    tmpStartCassette = strAPCRecipeParameterAdjustInqResult.strStartCassette;

    if( rc == RC_OK )
    {
        PPT_METHODTRACE_V1("", "Received APCRecipeParameterResponse normally.");
        strStartLotsReservationForTakeOutInReqResult.APCIFControlStatus = CIMFWStrDup(SP_APC_ControlJobStatus_Canceled);
    }

    //APC result check.
    //Check every lot has at least one wafer with processJobExecFlag == TRUE
    strLot_processJobExecFlag_ValidCheck_in.strStartCassette = tmpStartCassette;
    PPT_METHODTRACE_V1("","Check every lot of APC result has at least one wafer with processJobExecFlag == TRUE.");
    rc = lot_processJobExecFlag_ValidCheck(strLot_processJobExecFlag_ValidCheck_out, strObjCommonIn, strLot_processJobExecFlag_ValidCheck_in);
    if( rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","objLot_processJobExecFlag_ValidCheck() != RC_OK ");
        strStartLotsReservationForTakeOutInReqResult.strResult = strLot_processJobExecFlag_ValidCheck_out.strResult;
        return rc;
    }

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Object Lock Process                                                 */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    PPT_METHODTRACE_V1( "", "Object lock Process..." );

//DSN000049350 Add Start    
    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = equipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXTRC079" ); // TxStartLotsReservationForTakeOutInReq
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

    PPT_METHODTRACE_V2( "", "calling object_lockMode_Get()", equipmentID.identifier );
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strStartLotsReservationForTakeOutInReqResult.strResult = strObject_lockMode_Get_out.strResult;
        return( rc );
    }
    
    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;
    
    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
    if (lockMode != SP_EQP_LOCK_MODE_WRITE)
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2( "", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject );
        rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                    strObjCommonIn,
                                    strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strStartLotsReservationForTakeOutInReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return( rc );
        }

        /*------------------------------*/
        /*   Lock Dispatcher Object     */
        /*------------------------------*/
        PPT_METHODTRACE_V2( "", "calling object_Lock()", SP_ClassName_PosDispatcher );
        rc = object_Lock( strObject_Lock_out,
                          strObjCommonIn,
                          equipmentID,
                          SP_ClassName_PosDispatcher );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
            strStartLotsReservationForTakeOutInReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode = SP_EQP_LOCK_MODE_WRITE");
//DSN000049350 Add End
        /*--------------------------------------------*/
        /*                                            */
        /*      Machine Object Lock Process           */
        /*                                            */
        /*--------------------------------------------*/
        PPT_METHODTRACE_V1("", "#### Machine Object Lock ");
//DSN000049350        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock( strObject_Lock_out, strObjCommonIn, equipmentID, SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "object_Lock() != RC_OK" );
            strStartLotsReservationForTakeOutInReqResult.strResult = strObject_Lock_out.strResult;
            return( rc );
        }
    } //DSN000049350

    /*--------------------------------------------*/
    /*                                            */
    /*        Port Object Lock Process            */
    /*                                            */
    /*--------------------------------------------*/
    PPT_METHODTRACE_V1("", "#### Port Object Lock ");
    /*--------------------------------------------------------*/
    /*   Get All Ports being in the same Port Group as ToPort */
    /*--------------------------------------------------------*/
    objPortResource_allPortsInSameGroup_Get_out strPortResource_allPortsInSameGroup_Get_out;
    rc = portResource_allPortsInSameGroup_Get( strPortResource_allPortsInSameGroup_Get_out,
                                               strObjCommonIn,
                                               equipmentID,
                                               tmpStartCassette[0].loadPortID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "portResource_allPortsInSameGroup_Get() rc != RC_OK", rc);
        strStartLotsReservationForTakeOutInReqResult.strResult = strPortResource_allPortsInSameGroup_Get_out.strResult;
        return( rc );
    }

    /*---------------------------------------------------------*/
    /* Lock All Ports being in the same Port Group as ToPort   */
    /*---------------------------------------------------------*/
    CORBA::Long lenToPort = strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus.length();
    for ( CORBA::Long kk =0 ; kk < lenToPort ; kk++ )
    {
        objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
        rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                              strObjCommonIn,
                                              equipmentID,
                                              strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[kk].portID,
                                              SP_ClassName_PosPortResource );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[kk].portID.identifier) ;
            strStartLotsReservationForTakeOutInReqResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
            return( rc );
        }
        PPT_METHODTRACE_V2("", "Locked port object  : ", strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[kk].portID.identifier) ;
    }

    /*--------------------------------------------*/
    /*                                            */
    /*       Cassette Object Lock Process         */
    /*                                            */
    /*--------------------------------------------*/
    PPT_METHODTRACE_V1("", "#### Cassette Object Lock ");
    CORBA::Long i     = 0;
    CORBA::Long nILen = tmpStartCassette.length();
    PPT_METHODTRACE_V2( "", "nILen", nILen);

//DSN000049350 Add Start
    objectIdentifierSequence lotIDs;
    CORBA::ULong extendLen     = 25;
    CORBA::ULong t_lotIDLen    = extendLen;
    CORBA::ULong lotIDCnt      = 0;
    lotIDs.length(t_lotIDLen);
    cassetteIDs.length(nILen);
//DSN000049350 Add End

    for ( i=0 ; i<nILen ; i++ )
    {
//DSN000049350        rc = object_Lock( strObject_Lock_out, strObjCommonIn, tmpStartCassette[i].cassetteID,
//DSN000049350                          SP_ClassName_PosCassette );
//DSN000049350        if ( rc != RC_OK )
//DSN000049350        {
//DSN000049350            PPT_METHODTRACE_V2( "", "object_Lock() != RC_OK", i );
//DSN000049350            strStartLotsReservationForTakeOutInReqResult.strResult = strObject_Lock_out.strResult;
//DSN000049350            return( rc );
//DSN000049350        }

        cassetteIDs[i] = tmpStartCassette[i].cassetteID;  //DSN000049350

        /*--------------------------------------------*/
        /*                                            */
        /*         Lot Object Lock Process            */
        /*                                            */
        /*--------------------------------------------*/
        PPT_METHODTRACE_V1("", "#### Lot Object Lock ");
        CORBA::Long j     = 0;
        CORBA::Long nJLen = tmpStartCassette[i].strLotInCassette.length();
        PPT_METHODTRACE_V3( "", "nJLen", nJLen, i);
        for ( j=0 ; j<nJLen ; j++ )
        {
//DSN000049350            rc = object_Lock( strObject_Lock_out, strObjCommonIn,
//DSN000049350                              tmpStartCassette[i].strLotInCassette[j].lotID, SP_ClassName_PosLot );
//DSN000049350            if ( rc != RC_OK )
//DSN000049350            {
//DSN000049350                PPT_METHODTRACE_V3( "", "object_Lock() != RC_OK", i, j );
//DSN000049350                strStartLotsReservationForTakeOutInReqResult.strResult = strObject_Lock_out.strResult;
//DSN000049350                return( rc );
//DSN000049350            }
//DSN000049350 Add Start
            if( lotIDCnt >= t_lotIDLen )
            {
                PPT_METHODTRACE_V1("", "lotIDCnt >= t_lotIDLen");
                t_lotIDLen += extendLen;
                lotIDs.length( t_lotIDLen );
            }
            lotIDs[lotIDCnt++] = tmpStartCassette[i].strLotInCassette[j].lotID;
//DSN000049350 Add End
        }
    }
    lotIDs.length(lotIDCnt);                        //DSN000049350
    PPT_METHODTRACE_V2( "", "lotIDCnt", lotIDCnt);  //DSN000049350

//DSN000049350 Add Start
    /*------------------------------*/
    /*   Lock Cassette/Lot Object   */
    /*-------------------------------*/
    objObjectSequence_Lock_out strObjectSequence_Lock_out;

    PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosCassette );
    rc = objectSequence_Lock( strObjectSequence_Lock_out,
                              strObjCommonIn,
                              cassetteIDs,
                              SP_ClassName_PosCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
        strStartLotsReservationForTakeOutInReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }

    PPT_METHODTRACE_V2( "", "calling objectSequence_Lock()", SP_ClassName_PosLot );
    rc = objectSequence_Lock( strObjectSequence_Lock_out,
                              strObjCommonIn,
                              lotIDs,
                              SP_ClassName_PosLot );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
        strStartLotsReservationForTakeOutInReqResult.strResult = strObjectSequence_Lock_out.strResult;
        return( rc );
    }
//DSN000049350 Add End

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Check Process                                                       */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    //-------------------------------------------------
    //  Check scrap wafer existence in carrier
    //-------------------------------------------------
    cnt = 0;
    cassetteIDs.length( castLen ) ;

    for(cnt = 0 ; cnt < castLen; cnt++ )
    {
        cassetteIDs[cnt] = tmpStartCassette[cnt].cassetteID;
    }

    rc = cassette_scrapWafer_SelectDR( strCassette_scrapWafer_SelectDR_out,
                                       strObjCommonIn,
                                       cassetteIDs);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "cassette_scrapWafer_SelectDR() != RC_OK",rc);
        strStartLotsReservationForTakeOutInReqResult.strResult = strCassette_scrapWafer_SelectDR_out.strResult;
        return (rc);
    }

    scrapCount = strCassette_scrapWafer_SelectDR_out.strLotWaferMap.length();
    if( scrapCount > 0 )
    {
        PPT_METHODTRACE_V2("", "ScrapWafer Found ",scrapCount);
        SET_MSG_RC(strStartLotsReservationForTakeOutInReqResult, MSG_FOUND_SCRAP, RC_FOUND_SCRAP) ;
        return (RC_FOUND_SCRAP);
    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Cassette                                          */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - controlJobID                                                      */
    /*   - multiLotType                                                      */
    /*   - transferState                                                     */
    /*   - transferReserved                                                  */
    /*   - dispatchState                                                     */
    /*   - maxBatchSize                                                      */
    /*   - minBatchSize                                                      */
    /*   - emptyCassetteCount                                                */
    /*   - cassette'sloadingSequenceNomber                                   */
    /*   - eqp's multiRecipeCapability and recipeParameter                   */
    /*   - Upper/Lower Limit for RecipeParameterChange                       */
    /*   - MonitorLotCount or OperationStartLotCount                         */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    objCassette_CheckConditionForOperation_out strCassette_CheckConditionForOperation_out;
    rc = cassette_CheckConditionForOperation( strCassette_CheckConditionForOperation_out,
                                              strObjCommonIn, equipmentID, portGroupID,
                                              tmpStartCassette, SP_Operation_StartReservation );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationForTakeOutInReq", "cassette_CheckConditionForOperation() != RC_OK" );
        strStartLotsReservationForTakeOutInReqResult.strResult = strCassette_CheckConditionForOperation_out.strResult;
        return( rc );
    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Lot                                               */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   - controlJobID                                                      */
    /*   - lot's equipmentID                                                 */
    /*   - lotHoldState                                                      */
    /*   - lotProcessState                                                   */
    /*   - lotInventoryState                                                 */
    /*   - entityInhibition                                                  */
    /*   - minWaferCount                                                     */
    /*   - equipment's availability for specified lot                        */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    objLot_CheckConditionForOperation_out strLot_CheckConditionForOperation_out;
    rc = lot_CheckConditionForOperation( strLot_CheckConditionForOperation_out,
                                         strObjCommonIn, equipmentID, portGroupID,
                                         tmpStartCassette, SP_Operation_StartReservation );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationForTakeOutInReq", "lot_CheckConditionForOperation() != RC_OK" );
        strStartLotsReservationForTakeOutInReqResult.strResult = strLot_CheckConditionForOperation_out.strResult;
        return( rc );
    }

    /*-----------------------------------------------------------------------------*/
    /*                                                                             */
    /*   Check Equipment Port for Start Reservation                                */
    /*                                                                             */
    /*   The following conditions are checked by this object                       */
    /*                                                                             */
    /*   1. In-parm's portGroupID must not have controlJobID.                      */
    /*   2. All of ports' loadMode must be CIMFW_PortRsc_Input or _InputOutput.    */
    /*   3. All of port, which is registered as in-parm's portGroup, must be       */
    /*      _LoadAvail or _LoadReq or _UnloadReq when equipment is online.         */
    /*   4. strStartCassette[].loadPortID's portGroupID must be same               */
    /*      as in-parm's portGroupID.                                              */
    /*   5. strStartCassette[].loadPurposeType must be match as specified port's   */
    /*      loadPutposeType.                                                       */
    /*   6. strStartCassette[].loadSequenceNumber must be same as specified port's */
    /*      loadSequenceNumber.                                                    */
    /*                                                                             */
    /*-----------------------------------------------------------------------------*/
    PPT_METHODTRACE_V1("","===== equipment_portState_CheckForStartReservation() ==========");
    objEquipment_portState_CheckForTakeOutIn_out strEquipment_portState_CheckForTakeOutIn_out;
    objEquipment_portState_CheckForTakeOutIn_in  strEquipment_portState_CheckForTakeOutIn_in;
    strEquipment_portState_CheckForTakeOutIn_in.equipmentID = equipmentID;
    strEquipment_portState_CheckForTakeOutIn_in.portGroupID = CIMFWStrDup(portGroupID);
    strEquipment_portState_CheckForTakeOutIn_in.strStartCassette = tmpStartCassette;

    rc = equipment_portState_CheckForTakeOutIn( strEquipment_portState_CheckForTakeOutIn_out,
                                                strObjCommonIn,
                                                strEquipment_portState_CheckForTakeOutIn_in );

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationForTakeOutInReq", "equipment_portState_CheckForStartReservation() != RC_OK" );
        strStartLotsReservationForTakeOutInReqResult.strResult = strEquipment_portState_CheckForTakeOutIn_out.strResult;
        return( rc );
    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for FlowBatch                                         */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   1. whether in-parm's equipment has reserved flowBatchID or not      */
    /*      fill  -> all of flowBatch member and in-parm's lot must be       */
    /*               same perfectly.                                         */
    /*      blank -> no check                                                */
    /*                                                                       */
    /*   2. whether lot is in flowBatch section or not                       */
    /*      in    -> lot must have flowBatchID, and flowBatch must have      */
    /*               reserved equipmentID.                                   */
    /*               if lot is on target operation, flowBatch's reserved     */
    /*               equipmentID and in-parm's equipmentID must be same.     */
    /*      out   -> no check                                                */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/
    objEquipment_lot_CheckFlowBatchConditionForOpeStart_out__090 strEquipment_lot_CheckFlowBatchConditionForOpeStart_out;
    objEquipment_lot_CheckFlowBatchConditionForOpeStart_in__090  strEquipment_lot_CheckFlowBatchConditionForOpeStart_in;
    strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.equipmentID = equipmentID;
    strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.portGroupID = portGroupID;
    strEquipment_lot_CheckFlowBatchConditionForOpeStart_in.strStartCassette = tmpStartCassette;

    rc = equipment_lot_CheckFlowBatchConditionForOpeStart__090( strEquipment_lot_CheckFlowBatchConditionForOpeStart_out,
                                                                strObjCommonIn,
                                                                strEquipment_lot_CheckFlowBatchConditionForOpeStart_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "equipment_lot_CheckFlowBatchConditionForOpeStart__090() != RC_OK" );
        strStartLotsReservationForTakeOutInReqResult.strResult = strEquipment_lot_CheckFlowBatchConditionForOpeStart_out.strResult;
        return( rc );
    }

    /*-----------------------------------------------------------------------*/
    /*                                                                       */
    /*   Check Process for Process Durable                                   */
    /*                                                                       */
    /*   The following conditions are checked by this object                 */
    /*                                                                       */
    /*   1. Whether equipment requires process durable or not                */
    /*      If no-need, return OK;                                           */
    /*                                                                       */
    /*   2. At least one of reticle / fixture for each reticleGroup /        */
    /*      fixtureGroup is in the equipment or not.                         */
    /*      Even if required reticle is in the equipment, its status must    */
    /*      be _Available or _InUse.                                         */
    /*                                                                       */
    /*-----------------------------------------------------------------------*/

    /*-----------------------------------------*/
    /*   Check Process Durable Required Flag   */
    /*-----------------------------------------*/
    objEquipment_processDurableRequiredFlag_Get_out strEquipment_processDurableRequiredFlag_Get_out;
    rc = equipment_processDurableRequiredFlag_Get(strEquipment_processDurableRequiredFlag_Get_out, strObjCommonIn,
                                                  equipmentID);
    if ( rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD )
    {
        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationForTakeOutInReq", "rc == RC_EQP_PROCDRBL_RTCL_REQD || rc == RC_EQP_PROCDRBL_FIXT_REQD");
        CORBA::Long i     = 0;
        CORBA::Long nIMax = tmpStartCassette.length();
        PPT_METHODTRACE_V2( "CS_PPTManager_i:: txStartLotsReservationForTakeOutInReq", "nIMax", nIMax);
        for ( i=0 ; i<nIMax; i++ )
        {
            if ( CIMFWStrCmp(tmpStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
            {
                continue;
            }

            CORBA::Long j     = 0;
            CORBA::Long nJMax = tmpStartCassette[i].strLotInCassette.length();
            PPT_METHODTRACE_V3( "CS_PPTManager_i:: txStartLotsReservationForTakeOutInReq", "nJMax", nJMax, i);
            for ( j=0 ; j<nJMax; j++ )
            {
                if ( tmpStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                {
                    continue;
                }

                /*--------------------------------------------------*/
                /*   Check Process Durable Condition for OpeStart   */
                /*--------------------------------------------------*/
                objProcessDurable_CheckConditionForOpeStart_out strProcessDurable_CheckConditionForOpeStart_out;
                rc = processDurable_CheckConditionForOpeStart( strProcessDurable_CheckConditionForOpeStart_out,
                                                               strObjCommonIn, equipmentID,
                                                               tmpStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID,
                                                               tmpStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID,
                                                               tmpStartCassette[i].strLotInCassette[j].lotID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V3( "CS_PPTManager_i:: txStartLotsReservationForTakeOutInReq", "processDurable_CheckConditionForOpeStart() != RC_OK", i, j );
                    strStartLotsReservationForTakeOutInReqResult.strResult = strProcessDurable_CheckConditionForOpeStart_out.strResult;
                    return( rc );
                }

                /*---------------------------------------*/
                /*   Set Available Reticles / Fixtures   */
                /*---------------------------------------*/
                tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle = strProcessDurable_CheckConditionForOpeStart_out.strStartReticle;
                tmpStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture = strProcessDurable_CheckConditionForOpeStart_out.strStartFixture;
            }
        }
        rc = RC_OK;
    }
    else if ( rc == RC_EQP_PROCDRBL_NOT_REQD )
    {
        rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationForTakeOutInReq", "!RC_EQP_PROCDRBL_RTCL_REQD && !RC_EQP_PROCDRBL_FIXT_REQD && !RC_EQP_PROCDRBL_NOT_REQD" );
        strStartLotsReservationForTakeOutInReqResult.strResult = strEquipment_processDurableRequiredFlag_Get_out.strResult;
        return( rc );
    }

    /*----------------------------------------------------------------------------------------------------------------------*/
    /*                                                                                                                      */
    /*   Confirmation for Uploaded Recipe Body and Eqp's Recipe Body                                                        */
    /*                                                                                                                      */
    /*   When the following conditions are all matched, recipe body                                                         */
    /*   confirmation request is sent to TCS.                                                                               */
    /*                                                                                                                      */
    /*   1. Equipment's onlineMode is Online                                                                                */
    /*   2. Equipment's recipe body manage flag is TRUE.                                                                    */
    /*   3. Machine recipe's recipe body confirm flag is TRUE.                                                              */
    //                                                                                                                      */
    //   Force Down Load Flag  Recipe Body Confirm Flag  Conditional Down Load Flag                                         */
    //           Yes                      No                       No               -> Download it without confirmation.    */
    //           No                       Yes                      No               -> Confirm only.                        */
    //           No                       Yes                      Yes              -> If confirmation is NG, download it.  */
    //           No                       No                       No               -> No action.                           */
    /*                                                                                                                      */
    /*----------------------------------------------------------------------------------------------------------------------*/
    CORBA::Long nIMax = 0;
    //---------------------------------------------------
    // Get Machine Recipe List for Recipe Body Mangement
    //---------------------------------------------------
    PPT_METHODTRACE_V1( "", "Get Machine Recipe List for Recipe Body Mangement." );
    objMachineRecipe_GetListForRecipeBodyManagement_out strMachineRecipe_GetListForRecipeBodyManagement_out;
    objMachineRecipe_GetListForRecipeBodyManagement_in  strMachineRecipe_GetListForRecipeBodyManagement_in;
    strMachineRecipe_GetListForRecipeBodyManagement_in.equipmentID      = equipmentID;
    strMachineRecipe_GetListForRecipeBodyManagement_in.strStartCassette = tmpStartCassette;
    rc = machineRecipe_GetListForRecipeBodyManagement( strMachineRecipe_GetListForRecipeBodyManagement_out, strObjCommonIn, strMachineRecipe_GetListForRecipeBodyManagement_in);
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1( "", "machineRecipe_GetListForRecipeBodyManagement() != RC_OK" );
        strStartLotsReservationForTakeOutInReqResult.strResult = strMachineRecipe_GetListForRecipeBodyManagement_out.strResult;
        return( rc );
    }

    CORBA::Long targetRecipeLen = strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq.length();
    if( 0 == targetRecipeLen )
    {
        PPT_METHODTRACE_V1( "", "Recipe for Recipe Body Management does not exist." );
    }

    for(CORBA::Long targetRecipeCnt=0; targetRecipeCnt<targetRecipeLen; targetRecipeCnt++)
    {
        PPT_METHODTRACE_V2(""," Machine Recipe ID          ",  strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID.identifier);
        PPT_METHODTRACE_V2(""," Force Down Load Flag       ", (strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].forceDownLoadFlag?"True":"False"));
        PPT_METHODTRACE_V2(""," Recipe Body Confirm Flag   ", (strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].recipeBodyConfirmFlag?"True":"False"));
        PPT_METHODTRACE_V2(""," Conditional Down Load Flag ", (strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].conditionalDownLoadFlag?"True":"False"));

        //-------------------
        // Force Down Load
        //-------------------
        CORBA::Boolean downLoadFlag = FALSE;
        if( TRUE == strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].forceDownLoadFlag )
        {
             PPT_METHODTRACE_V1("","downLoadFlag turns to True.");
             downLoadFlag = TRUE;
        }
        else
        {
            if( TRUE == strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].recipeBodyConfirmFlag )
            {
                //---------------------
                // Recipe Confirmation
                //---------------------
                PPT_METHODTRACE_V1("","Call txRecipeConfirmationReq");
                pptRecipeConfirmationReqResult strRecipeConfirmationReqResult;
                rc = txRecipeConfirmationReq( strRecipeConfirmationReqResult, strObjCommonIn, equipmentID,
                                              strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID,
                                              strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].physicalRecipeID,
                                              strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].fileLocation,
                                              strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].fileName,
                                              strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].formatFlag, "");

                if ( rc != RC_OK && rc != RC_TCS_MM_TAP_PP_CONFIRM_ERROR)  // RC_TCS_MM_TAP_PP_CONFIRM_ERROR = 5914
                {
                    PPT_METHODTRACE_V2( "", "txRecipeConfirmationReq() != RC_OK", i );
                    strStartLotsReservationForTakeOutInReqResult.strResult = strRecipeConfirmationReqResult.strResult;
                    return( rc );
                }
                if( rc == RC_TCS_MM_TAP_PP_CONFIRM_ERROR )
                {
                    if( TRUE == strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].conditionalDownLoadFlag )
                    {
                        //--------------------------
                        // Conditional Down Load
                        //--------------------------
                        PPT_METHODTRACE_V1("","downLoadFlag turns to True.");
                        downLoadFlag = TRUE;
                    }
                    else
                    {
                        //Recipe Body Confirmation error. the Recipe Body differs between Uploaded it to system and the owned it by equipment.
                        PPT_METHODTRACE_V2("","Recipe Body Confirmation error. the Recipe Body differs between Uploaded it to system and the owned it by equipment.",
                                              strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID.identifier);
                        PPT_SET_MSG_RC_KEY(strStartLotsReservationForTakeOutInReqResult, MSG_RECIPE_CONFIRM_ERROR, RC_RECIPE_CONFIRM_ERROR ,
                                           strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID.identifier);
                        return ( RC_RECIPE_CONFIRM_ERROR );
                    }
                }
            }
            else
            {
                PPT_METHODTRACE_V1("","Recipe Body management .. no action.");
                // no action.
            }
        }

        PPT_METHODTRACE_V2("","Recipe Down Load ??", (downLoadFlag?"True":"False"));
        if( TRUE == downLoadFlag )
        {
            //---------------------
            // Recipe Down Load
            //---------------------
            PPT_METHODTRACE_V1("","Call txRecipeDownloadReq");
            pptRecipeDownloadReqResult strRecipeDownloadReqResult;
            rc = txRecipeDownloadReq( strRecipeDownloadReqResult, strObjCommonIn, equipmentID,
                                      strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID,
                                      strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].physicalRecipeID,
                                      strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].fileLocation,
                                      strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].fileName,
                                      strMachineRecipe_GetListForRecipeBodyManagement_out.strRecipeBodyManagementSeq[targetRecipeCnt].formatFlag, "");

            if(rc != RC_OK)
            {

                PPT_METHODTRACE_V2( "", "txRecipeDownloadReq() != RC_OK", i );
                strStartLotsReservationForTakeOutInReqResult.strResult = strRecipeDownloadReqResult.strResult;
                return ( rc );
            }
        }
    } //Loop of targetRecipeLen

    /*---------------------------------------------------------------------------*/
    /*                                                                           */
    /*   Check Category for Copper/Non Copper                                    */
    /*                                                                           */
    /*   It is checked in the following method whether it is the condition       */
    /*   that Lot of the object is made of OpeStart.                             */
    /*                                                                           */
    /*   1. It is checked whether CassetteCategory of RequiredCassetteCategory   */
    /*      of PosLot and PosCassette is the same.                               */
    /*                                                                           */
    /*   2. It is checked whether CassetteCategoryCapability of CassetteCategory */
    /*      of PosCassette and PosPortResource is the same.                      */
    /*                                                                           */
    /*   3. It is proper condition if CassetteCategoryCapability is the same     */
    /*      as RequiredCassetteCategory and CassetteCategory.                    */
    /*                                                                           */
    /*---------------------------------------------------------------------------*/
    CORBA::Long ii = 0;
    CORBA::Long jj = 0;
    CORBA::Long nCastLen = tmpStartCassette.length();
    CORBA::Long nLotInCastLen = 0;

    objectIdentifier dummyLotID;

    for ( ii = 0; ii < nCastLen; ii++ )
    {
        if ( CIMFWStrCmp(tmpStartCassette[ii].loadPurposeType, SP_LoadPurposeType_EmptyCassette) == 0)
        {
            objLot_CassetteCategory_CheckForContaminationControl_out strLot_CassetteCategory_CheckForContaminationControl_out;
            rc = lot_CassetteCategory_CheckForContaminationControl( strLot_CassetteCategory_CheckForContaminationControl_out,
                                                      strObjCommonIn,
                                                      dummyLotID,
                                                      tmpStartCassette[ii].cassetteID,
                                                      equipmentID,
                                                      tmpStartCassette[ii].loadPortID);

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationForTakeOutInReq", "lot_CassetteCategory_CheckForContaminationControl() != RC_OK");
                strStartLotsReservationForTakeOutInReqResult.strResult = strLot_CassetteCategory_CheckForContaminationControl_out.strResult;
                return( rc );
            }
        }
        else
        {
            nLotInCastLen = tmpStartCassette[ii].strLotInCassette.length();
            for ( jj = 0; jj < nLotInCastLen; jj++ )
            {
                if ( tmpStartCassette[ii].strLotInCassette[jj].operationStartFlag == FALSE )
                {
                    continue;
                }
                objLot_CassetteCategory_CheckForContaminationControl_out strLot_CassetteCategory_CheckForContaminationControl_out;
                rc = lot_CassetteCategory_CheckForContaminationControl( strLot_CassetteCategory_CheckForContaminationControl_out,
                                                                        strObjCommonIn,
                                                                        tmpStartCassette[ii].strLotInCassette[jj].lotID,
                                                                        tmpStartCassette[ii].cassetteID,
                                                                        equipmentID,
                                                                        tmpStartCassette[ii].loadPortID);

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationForTakeOutInReq", "lot_CassetteCategory_CheckForContaminationControl() != RC_OK");
                    strStartLotsReservationForTakeOutInReqResult.strResult = strLot_CassetteCategory_CheckForContaminationControl_out.strResult;
                    return( rc );
                }
            }
        }
    }

    /*---------------------------------------------------------------------------*/
    /*                                                                           */
    /*   Check Carrier Category for next operation of Empty carrier.             */
    /*                                                                           */
    /*---------------------------------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call emptyCassette_CheckCategoryForOperation()");
    objEmptyCassette_CheckCategoryForOperation_out strEmptyCassette_CheckCategoryForOperation_out;
    rc = emptyCassette_CheckCategoryForOperation( strEmptyCassette_CheckCategoryForOperation_out, strObjCommonIn, tmpStartCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "emptyCassette_CheckCategoryForOperation() != RC_OK", rc);
        strStartLotsReservationForTakeOutInReqResult.strResult = strEmptyCassette_CheckCategoryForOperation_out.strResult;
        return( rc );
    }

    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/
    /*                                                                       */
    /*   Main Process                                                        */
    /*                                                                       */
    /*=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=*/

    /*----------------------------------------------*/
    /*                                              */
    /*   Change Cassette's Dispatch State to TRUE   */
    /*                                              */
    /*----------------------------------------------*/
    i     = 0;
    nIMax = tmpStartCassette.length();
    PPT_METHODTRACE_V2( "CS_PPTManager_i:: txStartLotsReservationForTakeOutInReq", "nIMax", nIMax);
    for ( i=0 ; i<nIMax; i++ )
    {
        objCassette_dispatchState_Change_out strCassette_dispatchState_Change_out;
        rc = cassette_dispatchState_Change( strCassette_dispatchState_Change_out, strObjCommonIn,
                                            tmpStartCassette[i].cassetteID, TRUE );
        if ( rc != RC_OK ) {
            PPT_METHODTRACE_V2( "CS_PPTManager_i:: txStartLotsReservationForTakeOutInReq", "cassette_dispatchState_Change() != RC_OK", i );
            strStartLotsReservationForTakeOutInReqResult.strResult = strCassette_dispatchState_Change_out.strResult;
           return( rc );
        }

    }

    /*-------------------------------------------------------------*/
    /*                                                             */
    /*   Create Control Job and Assign to Each Cassettes / Lots    */
    /*                                                             */
    /*   - Create new controlJob                                   */
    /*   - Set created controlJobID to each cassettes / lots       */
    /*   - Set created controlJobID to equipment                   */
    /*                                                             */
    /*-------------------------------------------------------------*/
    pptControlJobManageReqResult strControlJobManageReqResult;
    pptControlJobCreateRequest   strControlJobCreateRequest;
    objectIdentifier             dummyControlJobID;
    strControlJobCreateRequest.equipmentID = equipmentID;
    strControlJobCreateRequest.portGroupID = portGroupID;
    strControlJobCreateRequest.strStartCassette = tmpStartCassette;
    rc = txControlJobManageReq( strControlJobManageReqResult,
                                strObjCommonIn,
                                dummyControlJobID,
                                SP_ControlJobAction_Type_create,
                                strControlJobCreateRequest,
                                claimMemo );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "", "txControlJobManageReq() != RC_OK");
        strStartLotsReservationForTakeOutInReqResult.strResult = strControlJobManageReqResult.strResult;
        return( rc );
    }

    /*----------------------------------------------------*/
    /*                                                    */
    /*   Set Start Reserved Control Job into Equipment    */
    /*                                                    */
    /*----------------------------------------------------*/
    objEquipment_reservedControlJobID_Set_out strEquipment_reservedControlJobID_Set_out;
    rc = equipment_reservedControlJobID_Set( strEquipment_reservedControlJobID_Set_out,
                                             strObjCommonIn,
                                             equipmentID,
                                             strControlJobManageReqResult.controlJobID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationForTakeOutInReq", "equipment_reservedControlJobID_Set() != RC_OK");
        strStartLotsReservationForTakeOutInReqResult.strResult = strEquipment_reservedControlJobID_Set_out.strResult;
        return( rc );
    }

    /*----------------------------------------------------*/
    /*                                                    */
    /*   Get Start Information for each Cassette / Lot    */
    /*                                                    */
    /*   - strStartCassette information is not filled     */
    /*     perfectlly. By this object function, it will   */
    /*     be filled.                                     */
    /*                                                    */
    /*----------------------------------------------------*/
    objProcess_startReserveInformation_Get_out strProcess_startReserveInformation_Get_out;
    strProcess_startReserveInformation_Get_out.strStartCassette = tmpStartCassette;
    rc = process_startReserveInformation_Get( strProcess_startReserveInformation_Get_out,
                                              strObjCommonIn, equipmentID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationForTakeOutInReq", "process_startReserveInformation_Get() != RC_OK");
        strStartLotsReservationForTakeOutInReqResult.strResult = strProcess_startReserveInformation_Get_out.strResult;
        return( rc );
    }

    // Apply FPCInformation for StartCassette.
    CORBA::Long  tmpFPCAdoptFlag = atoi( getenv(SP_FPC_Adaptation_Flag) );
    if( 1 == tmpFPCAdoptFlag )
    {
        PPT_METHODTRACE_V1("","FPC Adopt Flag is ON. Now apply FPCInfo.");
        objFPCStartCassetteInfo_Exchange_out  strFPCStartCassetteInfo_Exchange_out;
        rc = FPCStartCassetteInfo_Exchange( strFPCStartCassetteInfo_Exchange_out,
                                            strObjCommonIn,
                                            SP_FPC_ExchangeType_StartReserveReq,
                                            equipmentID,
                                            strProcess_startReserveInformation_Get_out.strStartCassette );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("","FPCStartCassetteInfo_Exchange() != RC_OK", rc);
            strStartLotsReservationForTakeOutInReqResult.strResult = strFPCStartCassetteInfo_Exchange_out.strResult;

            return rc;
        }
        strProcess_startReserveInformation_Get_out.strStartCassette = strFPCStartCassetteInfo_Exchange_out.strStartCassette;
    }
    else
    {
        PPT_METHODTRACE_V1("","FPC Adopt Flag is OFF. Now only check whiteFlag.");
        objFPC_startCassette_processCondition_Check_out  strFPC_startCassette_processCondition_Check_out;
        rc = FPC_startCassette_processCondition_Check( strFPC_startCassette_processCondition_Check_out,
                                                       strObjCommonIn,
                                                       equipmentID,
                                                       strProcess_startReserveInformation_Get_out.strStartCassette,
                                                       FALSE,     // FPC category check
                                                       TRUE );    // FPC whiteFlag check
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("","FPC_startCassette_processCondition_Check() != RC_OK", rc);
            strStartLotsReservationForTakeOutInReqResult.strResult = strFPC_startCassette_processCondition_Check_out.strResult;

            return rc;
        }
    }

    /*----------------------------------------------------*/
    /*                                                    */
    /*   Set Start Reservation Info to Each Lots' PO      */
    /*                                                    */
    /*   - Set created controlJobID into each cassette.   */
    /*   - Set created controlJobID into each lot.        */
    /*   - Set control job info (StartRecipe, DCDefs,     */
    /*     DCSpecs, Parameters, ...) into each lot's      */
    /*     cunrrent PO.                                   */
    /*                                                    */
    /*----------------------------------------------------*/
    objProcess_startReserveInformation_Set_out__090 strProcess_startReserveInformation_Set_out__090;
    objProcess_startReserveInformation_Set_in__090 strProcess_startReserveInformation_Set_in__090;
    strProcess_startReserveInformation_Set_in__090.equipmentID = equipmentID;
    strProcess_startReserveInformation_Set_in__090.portGroupID = portGroupID;
    strProcess_startReserveInformation_Set_in__090.controlJobID = strControlJobManageReqResult.controlJobID;
    strProcess_startReserveInformation_Set_in__090.strStartCassette = strProcess_startReserveInformation_Get_out.strStartCassette;
    strProcess_startReserveInformation_Set_in__090.processJobPauseFlag = FALSE;

    rc = process_startReserveInformation_Set__090( strProcess_startReserveInformation_Set_out__090, strObjCommonIn, strProcess_startReserveInformation_Set_in__090);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1( "CS_PPTManager_i:: txStartLotsReservationForTakeOutInReq", "process_startReserveInformation_Set__090() != RC_OK");
        strStartLotsReservationForTakeOutInReqResult.strResult = strProcess_startReserveInformation_Set_out__090.strResult;
        return( rc );
    }

    /*-------------------------------------------*/
    /*                                           */
    /*   Send TxStartLotsReservationForTakeOutInReq to TCS   */
    /*                                           */
    /*-------------------------------------------*/
    CORBA::String_var tmpSleepTimeValue = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
    CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));
    CORBA::Long sleepTimeValue = 0 ;
    CORBA::Long retryCountValue = 0 ;

    if (CIMFWStrLen(tmpSleepTimeValue) == 0)
    {
        sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
    }
    else
    {
        sleepTimeValue = atoi(tmpSleepTimeValue) ;
    }

    if (CIMFWStrLen(tmpRetryCountValue) == 0)
    {
        retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
    }
    else
    {
        retryCountValue = atoi(tmpRetryCountValue);
    }

    PPT_METHODTRACE_V2("","env value of SP_BIND_SLEEP_TIME_TCS  = ",sleepTimeValue);
    PPT_METHODTRACE_V2("","env value of SP_BIND_RETRY_COUNT_TCS = ",retryCountValue);

    objTCSMgr_SendStartLotsReservationReq_out strTCSMgr_SendStartLotsReservationReq_out;

    //'retryCountValue + 1' means first try plus retry count
    for(i = 0 ; i < (retryCountValue + 1) ; i++)
    {
        /*--------------------------*/
        /*    Send Request to TCS   */
        /*--------------------------*/
        rc = TCSMgr_SendStartLotsReservationReq( strTCSMgr_SendStartLotsReservationReq_out,
                                                 strObjCommonIn,
                                                 strObjCommonIn.strUser,
                                                 equipmentID,
                                                 portGroupID,
                                                 strControlJobManageReqResult.controlJobID,
                                                 strProcess_startReserveInformation_Get_out.strStartCassette,
                                                 claimMemo);
        PPT_METHODTRACE_V2("","rc = ",rc);

        if(rc == RC_OK)
        {
            PPT_METHODTRACE_V1("","Now TCS subSystem is alive!! Go ahead");
            break;
        }
        else if ( rc == RC_EXT_SERVER_BIND_FAIL ||
                  rc == RC_EXT_SERVER_NIL_OBJ   ||
                  rc == RC_TCS_NO_RESPONSE )
        {
            PPT_METHODTRACE_V2("","TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...",i);
            PPT_METHODTRACE_V2("","now sleeping... ",sleepTimeValue);
            sleep(sleepTimeValue);
            continue;
        }
        else
        {
            PPT_METHODTRACE_V1("", "TCSMgr_SendStartLotsReservationForTakeOutInReq() != RC_OK");
            strStartLotsReservationForTakeOutInReqResult.strResult = strTCSMgr_SendStartLotsReservationReq_out.strResult;
            return( rc );
        }

    }

    if ( rc != RC_OK )
    {
       PPT_METHODTRACE_V1("", "TCSMgr_SendStartLotsReservationForTakeOutInReq() != RC_OK");
       strStartLotsReservationForTakeOutInReqResult.strResult = strTCSMgr_SendStartLotsReservationReq_out.strResult;
       return( rc );
    }

    /*-------------------------------------------------*/
    /*   call APCRuntimeCapability_RegistDR            */
    /*-------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call APCRuntimeCapability_RegistDR");
    objAPCRuntimeCapability_RegistDR_out strAPCRuntimeCapability_RegistDR_out;
    rc = APCRuntimeCapability_RegistDR ( strAPCRuntimeCapability_RegistDR_out,
                                         strObjCommonIn,
                                         strControlJobManageReqResult.controlJobID,
                                         strAPCRunTimeCapabilityInqResult.strAPCRunTimeCapabilityResponse );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "APCRuntimeCapability_RegistDR() != RC_OK");
        strStartLotsReservationForTakeOutInReqResult.strResult = strAPCRuntimeCapability_RegistDR_out.strResult;
        return( rc );
    }

    /*-------------------------------------------------*/
    /*   call cassette_APCInformation_GetDR            */
    /*-------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call cassette_APCInformation_GetDR");
    objCassette_APCInformation_GetDR_out strCassette_APCInformation_GetDR_out;
    rc = cassette_APCInformation_GetDR ( strCassette_APCInformation_GetDR_out,
                                         strObjCommonIn,
                                         equipmentID,
                                         tmpStartCassette );
    if ( rc == RC_SYSTEM_ERROR )
    {
        PPT_METHODTRACE_V1("", "cassette_APCInformation_GetDR() == RC_SYSTEM_ERROR");
        strStartLotsReservationForTakeOutInReqResult.strResult = strCassette_APCInformation_GetDR_out.strResult;
        return ( rc ) ;
    }
    else if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cassette_APCInformation_GetDR() != RC_OK");
        strStartLotsReservationForTakeOutInReqResult.strResult = strCassette_APCInformation_GetDR_out.strResult;
    }

    /*-------------------------------------------------*/
    /*   call APCMgr_SendControlJobInformationDR       */
    /*-------------------------------------------------*/
    PPT_METHODTRACE_V1("", "call APCMgr_SendControlJobInformationDR");
    objAPCMgr_SendControlJobInformationDR_out strAPCMgr_SendControlJobInformationDR_out;
    rc = APCMgr_SendControlJobInformationDR ( strAPCMgr_SendControlJobInformationDR_out,
                                              strObjCommonIn,
                                              equipmentID,
                                              strControlJobManageReqResult.controlJobID,
                                              SP_APC_ControlJobStatus_Created,
                                              strCassette_APCInformation_GetDR_out.strAPCBaseCassetteList );
    if ( rc != RC_OK && rc != RC_OK_NO_IF )
    {
        PPT_METHODTRACE_V1("", "APCMgr_SendControlJobInformationDR() != RC_OK");
        strStartLotsReservationForTakeOutInReqResult.strResult = strAPCMgr_SendControlJobInformationDR_out.strResult;
        return( rc );
    }
    if( rc == RC_OK )
    {
        PPT_METHODTRACE_V1("", "APCControlJobInformation was sent normally.");
        strStartLotsReservationForTakeOutInReqResult.APCIFControlStatus = CIMFWStrDup(SP_APC_ControlJobStatus_Canceled);
    }

    /*--------------------*/
    /*                    */
    /*   Return to Main   */
    /*                    */
    /*--------------------*/
    strStartLotsReservationForTakeOutInReqResult.controlJobID = strControlJobManageReqResult.controlJobID;
    SET_MSG_RC ( strStartLotsReservationForTakeOutInReqResult, MSG_OK, RC_OK );

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txStartLotsReservationForTakeOutInReq");
    return ( RC_OK );
}
