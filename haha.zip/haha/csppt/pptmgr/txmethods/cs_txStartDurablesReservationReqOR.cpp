//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: cs_txStartDurablesReservationReqOR.cpp
//

//INN-R170003 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp"    //INN-R170003
#include <unistd.h>

// Class: CS_PPTManager
//
// Service: txStartDurablesReservationReq()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2014/12/17 DSN000085770 Sa Guo         Durable Management.
// 2015/07/31 DSN000096126 C.Mo           Durable Process Flow Control Support.
//
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2017/09/28 INN-R170003  Nick Tsai      Take DCJ to TCS.
//
//
// Description:
//    This function performs process start reservation for the specified Durables to the Equipment.
//      - Consisytency check of Transaction ID and SpecialControl of Equipment Category
//      - Check condition of durable( PFX is not Nil, durableControlJobID is Nil, Transfer Status... )
//      - Check status of durable( Should be NotAvailable )
//      - Check equipment and port state for cassette and reticle pod( Input portGroupID must not have controlJobID... )
//      - Download recipe if needed
//      - Check cassette category and change cassette dispatch reserved status
//      - Create durable controlJob
//      - Set startDurablesReserve information
//      - Send start durables reservation notification request to TCS
//
// Return:
//    long
//
// Parameter:
//
//  [Input Parameters]:
//    const pptObjCommonIn&                              strObjCommonIn
//    const pptStartDurablesReservationReqInParam&       strStartDurablesReservationReqInParam
//    const char *                                       claimMemo
//
//  [Output Parameters]:
//    pptStartDurablesReservationReqResult&              strStartDurablesReservationReqResult
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

//INN-R170003 CORBA::Long PPTManager_i::txStartDurablesReservationReq(
CORBA::Long CS_PPTManager_i::txStartDurablesReservationReq(            //INN-R170003
    pptStartDurablesReservationReqResult&              strStartDurablesReservationReqResult,
    const pptObjCommonIn&                              strObjCommonIn,
    const pptStartDurablesReservationReqInParam&       strStartDurablesReservationReqInParam,
    const char *                                       claimMemo
    CORBAENV_LAST_CPP )
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::txStartDurablesReservationReq");
    //----------------------------------------------------------------
    //
    //  Pre Process
    //
    //----------------------------------------------------------------

    // Initialize
    CORBA::Long rc = RC_OK;

    const pptStartDurablesReservationReqInParam& strInParm = strStartDurablesReservationReqInParam;

    //----------------------------------------------------------------
    //  In-Parameter Trace
    //----------------------------------------------------------------
    //Trace InParameters
    PPT_METHODTRACE_V2("", "in-parm equipmentID      ", strInParm.equipmentID.identifier);
    PPT_METHODTRACE_V2("", "in-parm durableCategory  ", strInParm.durableCategory);

    const char* durableCategory = strInParm.durableCategory;
    if( 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Cassette)
     && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_ReticlePod)
     && 0 != CIMFWStrCmp(durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V2("", "Invalid durable category", durableCategory);
        PPT_SET_MSG_RC_KEY( strStartDurablesReservationReqResult,
                            MSG_INVALID_DURABLE_CATEGORY,
                            RC_INVALID_DURABLE_CATEGORY,
                            durableCategory );
        return RC_INVALID_DURABLE_CATEGORY ;
    }

    CORBA::ULong durableLen = strInParm.strStartDurables.length();
    if ( 0 >= durableLen )
    {
        PPT_METHODTRACE_V1("", "0 > = CIMFWStrLen(strStartDurables.length())");
        SET_MSG_RC( strStartDurablesReservationReqResult, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
        return RC_INVALID_INPUT_PARM;
    }

    objEquipment_SpecialControlVsTxID_CheckCombination_out strEquipment_SpecialControlVsTxID_CheckCombination_out;
    objEquipment_SpecialControlVsTxID_CheckCombination_in  strEquipment_SpecialControlVsTxID_CheckCombination_in;
    strEquipment_SpecialControlVsTxID_CheckCombination_in.equipmentID = strInParm.equipmentID;
    rc = equipment_SpecialControlVsTxID_CheckCombination( strEquipment_SpecialControlVsTxID_CheckCombination_out,
                                                          strObjCommonIn,
                                                          strEquipment_SpecialControlVsTxID_CheckCombination_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "equipment_SpecialControlVsTxID_CheckCombination() != RC_OK", rc);
        strStartDurablesReservationReqResult.strResult = strEquipment_SpecialControlVsTxID_CheckCombination_out.strResult;
        return rc;
    }

    // Get required equipment lock mode
    objObject_lockMode_Get_out strObject_lockMode_Get_out;
    objObject_lockMode_Get_in  strObject_lockMode_Get_in;
    strObject_lockMode_Get_in.objectID           = strInParm.equipmentID;
    strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
    strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXPDC040" ); // TxStartDurablesReservationReq
    strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;
    rc = object_lockMode_Get( strObject_lockMode_Get_out,
                              strObjCommonIn,
                              strObject_lockMode_Get_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
        strStartDurablesReservationReqResult.strResult = strObject_lockMode_Get_out.strResult;
        return rc;
    }

    objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
    objAdvanced_object_Lock_in strAdvanced_object_Lock_in;
    objObject_Lock_out strObject_Lock_out;

    CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
    PPT_METHODTRACE_V2( "", "lockMode", lockMode );
    if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
    {
        PPT_METHODTRACE_V1("", "lockMode != SP_EQP_LOCK_MODE_WRITE");
        // Lock Equipment Main Object
        stringSequence dummySeq;
        dummySeq.length(0);
        strAdvanced_object_Lock_in.objectID   = strInParm.equipmentID;
        strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
        strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
        strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
        strAdvanced_object_Lock_in.keySeq     = dummySeq;

        PPT_METHODTRACE_V2("", "calling advanced_object_Lock()", SP_ObjectLock_ObjectType_MainObject);
        rc = advanced_object_Lock( strAdvanced_object_Lock_out,
                                   strObjCommonIn,
                                   strAdvanced_object_Lock_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
            strStartDurablesReservationReqResult.strResult = strAdvanced_object_Lock_out.strResult;
            return rc;
        }
    }
    else
    {
        PPT_METHODTRACE_V1("", "lockMode == SP_EQP_LOCK_MODE_WRITE");
        /*--------------------------------------------*/
        /*                                            */
        /*      Machine Object Lock Process           */
        /*                                            */
        /*--------------------------------------------*/
        PPT_METHODTRACE_V1("", "#### Machine Object Lock ");
        rc = object_Lock( strObject_Lock_out,
                          strObjCommonIn,
                          strInParm.equipmentID,
                          SP_ClassName_PosMachine );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
            strStartDurablesReservationReqResult.strResult = strObject_Lock_out.strResult;
            return rc;
        }
    }

    /*------------------------------*/
    /*   Lock Dispatcher Object     */
    /*------------------------------*/
    PPT_METHODTRACE_V2("", "calling object_Lock()", SP_ClassName_PosDispatcher);
    rc = object_Lock( strObject_Lock_out,
                      strObjCommonIn,
                      strInParm.equipmentID,
                      SP_ClassName_PosDispatcher );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
        strStartDurablesReservationReqResult.strResult = strObject_Lock_out.strResult;
        return rc;
    }

    CORBA::ULong durableCnt = 0;
    if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
        objPortResource_allPortsInSameGroup_Get_out strPortResource_allPortsInSameGroup_Get_out;
        rc = portResource_allPortsInSameGroup_Get( strPortResource_allPortsInSameGroup_Get_out,
                                                   strObjCommonIn,
                                                   strInParm.equipmentID,
                                                   strInParm.strStartDurables[0].strStartDurablePort.loadPortID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "portResource_allPortsInSameGroup_Get() != RC_OK", rc);
            strStartDurablesReservationReqResult.strResult = strPortResource_allPortsInSameGroup_Get_out.strResult;
            return rc;
        }

        /*---------------------------------------------------------*/
        /* Lock All Ports being in the same Port Group as ToPort   */
        /*---------------------------------------------------------*/
        CORBA::ULong lenToPort = strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus.length();
        for ( CORBA::ULong portCnt=0; portCnt < lenToPort; portCnt++ )
        {
            PPT_METHODTRACE_V2("", "loop to strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus.length()", portCnt);
            objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;
            rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                                  strObjCommonIn,
                                                  strInParm.equipmentID,
                                                  strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID,
                                                  SP_ClassName_PosPortResource );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID.identifier);
                strStartDurablesReservationReqResult.strResult = strObject_LockForEquipmentResource_out.strResult;
                return rc;
            }
            PPT_METHODTRACE_V2("", "Locked port object  : ", strPortResource_allPortsInSameGroup_Get_out.strEqpPortInfo.strEqpPortStatus[portCnt].portID.identifier);
        }
    }
    else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_ReticlePod");
        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
            objObject_LockForEquipmentResource_out strobject_LockForEquipmentResource_out;
            rc = object_LockForEquipmentResource( strobject_LockForEquipmentResource_out,
                                                  strObjCommonIn,
                                                  strInParm.equipmentID,
                                                  strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID,
                                                  SP_ClassName_PosReticlePodPortResource );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", rc);
                strStartDurablesReservationReqResult.strResult = strobject_LockForEquipmentResource_out.strResult;
                return rc;
            }
        }
    }

    objectIdentifierSequence durableIDs;
    durableIDs.length(durableLen);
    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
        durableIDs[durableCnt] = strInParm.strStartDurables[durableCnt].durableID;
    }

    if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosCassette);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  durableIDs,
                                  SP_ClassName_PosCassette );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strStartDurablesReservationReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }
    else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_ReticlePod");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosReticlePod);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  durableIDs,
                                  SP_ClassName_PosReticlePod );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strStartDurablesReservationReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }
    else if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Reticle) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Reticle");
        objObjectSequence_Lock_out strObjectSequence_Lock_out;
        PPT_METHODTRACE_V2("", "calling objectSequence_Lock()", SP_ClassName_PosProcessDurable);
        rc = objectSequence_Lock( strObjectSequence_Lock_out,
                                  strObjCommonIn,
                                  durableIDs,
                                  SP_ClassName_PosProcessDurable );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "objectSequence_Lock() != RC_OK", rc);
            strStartDurablesReservationReqResult.strResult = strObjectSequence_Lock_out.strResult;
            return rc;
        }
    }

//DSN000096126 add start
    CORBA::Boolean bOnRouteFlag  = FALSE;
    CORBA::Boolean bOffRouteFlag = FALSE;
    for( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
        objDurable_OnRoute_Check_out strDurable_OnRoute_Check_out;
        objDurable_OnRoute_Check_in  strDurable_OnRoute_Check_in;
        strDurable_OnRoute_Check_in.durableCategory = strInParm.durableCategory;
        strDurable_OnRoute_Check_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
        rc = durable_OnRoute_Check(strDurable_OnRoute_Check_out, strObjCommonIn, strDurable_OnRoute_Check_in);

        if( rc == RC_DURABLE_ONROUTE )
        {
            PPT_METHODTRACE_V1("","##### durable is on  route");
            bOnRouteFlag = TRUE;
        }
        else
        {
            PPT_METHODTRACE_V1("","##### durable is off route");
            bOffRouteFlag = TRUE;
        }
    }
    if( bOnRouteFlag && bOffRouteFlag )
    {
        PPT_METHODTRACE_V1("", "all durable OnRoute state is not same");
        SET_MSG_RC( strStartDurablesReservationReqResult, MSG_DURABLE_ONROUTE_STAT_NOT_SAME, RC_DURABLE_ONROUTE_STAT_NOT_SAME );
        return( RC_DURABLE_ONROUTE_STAT_NOT_SAME );
    }

    if( bOnRouteFlag && 0 == CIMFWStrLen(strInParm.strDurableStartRecipe.logicalRecipeID.identifier) )
    {
        PPT_METHODTRACE_V1("", "logicalRecipeID is blank");
        SET_MSG_RC( strStartDurablesReservationReqResult, MSG_DURABLE_CANNOT_OFFROUTE_RESERVE, RC_DURABLE_CANNOT_OFFROUTE_RESERVE );
        return( RC_DURABLE_CANNOT_OFFROUTE_RESERVE );
    }
//DSN000096126 add end

    CORBA::String_var portGroupID;
    if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
        objEquipment_portGroupID_Get_out strEquipment_portGroupID_Get_out;
        objEquipment_portGroupID_Get_in  strEquipment_portGroupID_Get_in;
        strEquipment_portGroupID_Get_in.equipmentID = strInParm.equipmentID;
        strEquipment_portGroupID_Get_in.portID      = strInParm.strStartDurables[0].strStartDurablePort.loadPortID;
        rc = equipment_portGroupID_Get( strEquipment_portGroupID_Get_out,
                                        strObjCommonIn,
                                        strEquipment_portGroupID_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_portGroupID_Get() != RC_OK", rc);
            strStartDurablesReservationReqResult.strResult = strEquipment_portGroupID_Get_out.strResult;
            return rc;
        }
        portGroupID = strEquipment_portGroupID_Get_out.portGroupID;
    }
    else
    {
        PPT_METHODTRACE_V1("", "durableCategory != SP_DurableCat_Cassette");
        portGroupID = CIMFWStrDup("");
    }

    objDurable_CheckConditionForOperation_out strDurable_CheckConditionForOperation_out;
    objDurable_CheckConditionForOperation_in  strDurable_CheckConditionForOperation_in;
    strDurable_CheckConditionForOperation_in.operation             = CIMFWStrDup( SP_Operation_StartReservation );
    strDurable_CheckConditionForOperation_in.equipmentID           = strInParm.equipmentID;
    strDurable_CheckConditionForOperation_in.durableCategory       = strInParm.durableCategory;
    strDurable_CheckConditionForOperation_in.strStartDurables      = strInParm.strStartDurables;
    strDurable_CheckConditionForOperation_in.strDurableStartRecipe = strInParm.strDurableStartRecipe;
    rc = durable_CheckConditionForOperation( strDurable_CheckConditionForOperation_out,
                                             strObjCommonIn,
                                             strDurable_CheckConditionForOperation_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "durable_CheckConditionForOperation() != RC_OK", rc);
        strStartDurablesReservationReqResult.strResult = strDurable_CheckConditionForOperation_out.strResult;
        return rc;
    }

    for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
        objDurable_status_CheckForOperation_out strDurable_status_CheckForOperation_out;
        objDurable_status_CheckForOperation_in  strDurable_status_CheckForOperation_in;
        strDurable_status_CheckForOperation_in.operation       = CIMFWStrDup( SP_Operation_StartReservation );
        strDurable_status_CheckForOperation_in.durableID       = strInParm.strStartDurables[durableCnt].durableID;
        strDurable_status_CheckForOperation_in.durableCategory = strInParm.durableCategory;
        rc = durable_status_CheckForOperation( strDurable_status_CheckForOperation_out,
                                               strObjCommonIn,
                                               strDurable_status_CheckForOperation_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "durable_status_CheckForOperation() != RC_OK", rc);
            strStartDurablesReservationReqResult.strResult = strDurable_status_CheckForOperation_out.strResult;
            return rc;
        }
    }

    if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette)
      || 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_ReticlePod) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette || SP_DurableCat_ReticlePod");
        objEquipment_and_portState_CheckForDurableOperation_out strEquipment_and_portState_CheckForDurableOperation_out;
        objEquipment_and_portState_CheckForDurableOperation_in  strEquipment_and_portState_CheckForDurableOperation_in;
        strEquipment_and_portState_CheckForDurableOperation_in.operation        = CIMFWStrDup( SP_Operation_StartReservation );
        strEquipment_and_portState_CheckForDurableOperation_in.equipmentID      = strInParm.equipmentID;
        strEquipment_and_portState_CheckForDurableOperation_in.portGroupID      = portGroupID;
        strEquipment_and_portState_CheckForDurableOperation_in.durableCategory  = strInParm.durableCategory;
        strEquipment_and_portState_CheckForDurableOperation_in.strStartDurables = strInParm.strStartDurables;
        rc = equipment_and_portState_CheckForDurableOperation( strEquipment_and_portState_CheckForDurableOperation_out,
                                                               strObjCommonIn,
                                                               strEquipment_and_portState_CheckForDurableOperation_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_and_portState_CheckForDurableOperation() != RC_OK", rc);
            strStartDurablesReservationReqResult.strResult = strEquipment_and_portState_CheckForDurableOperation_out.strResult;
            return rc;
        }
    }

    objMachineRecipe_GetListForRecipeBodyManagementForDurable_out strMachineRecipe_GetListForRecipeBodyManagementForDurable_out;
    objMachineRecipe_GetListForRecipeBodyManagementForDurable_in  strMachineRecipe_GetListForRecipeBodyManagementForDurable_in;
    strMachineRecipe_GetListForRecipeBodyManagementForDurable_in.equipmentID            = strInParm.equipmentID;
    strMachineRecipe_GetListForRecipeBodyManagementForDurable_in.durableCategory        = strInParm.durableCategory;
    strMachineRecipe_GetListForRecipeBodyManagementForDurable_in.strStartDurables       = strInParm.strStartDurables; //DSN000096126
    pptDurableStartRecipeSequence strDurableStartRecipes;
    strDurableStartRecipes.length(1);
    strDurableStartRecipes[0] = strInParm.strDurableStartRecipe;
    strMachineRecipe_GetListForRecipeBodyManagementForDurable_in.strDurableStartRecipes = strDurableStartRecipes;
    rc = machineRecipe_GetListForRecipeBodyManagementForDurable( strMachineRecipe_GetListForRecipeBodyManagementForDurable_out,
                                                                 strObjCommonIn,
                                                                 strMachineRecipe_GetListForRecipeBodyManagementForDurable_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "machineRecipe_GetListForRecipeBodyManagementForDurable() != RC_OK", rc);
        strStartDurablesReservationReqResult.strResult = strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strResult;
        return rc;
    }

    CORBA::ULong targetRecipeLen = strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq.length();
    for ( CORBA::ULong targetRecipeCnt=0; targetRecipeCnt<targetRecipeLen; targetRecipeCnt++ )
    {
        PPT_METHODTRACE_V2("", "loop to strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq.length()", targetRecipeCnt);
        PPT_METHODTRACE_V2("", " Machine Recipe ID          ",  strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID.identifier);
        PPT_METHODTRACE_V2("", " Force Down Load Flag       ", (strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].forceDownLoadFlag?"True":"False"));
        PPT_METHODTRACE_V2("", " Recipe Body Confirm Flag   ", (strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].recipeBodyConfirmFlag?"True":"False"));
        PPT_METHODTRACE_V2("", " Conditional Down Load Flag ", (strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].conditionalDownLoadFlag?"True":"False"));

        //-------------------
        // Force Down Load
        //-------------------
        CORBA::Boolean downLoadFlag = FALSE;
        if ( TRUE == strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].forceDownLoadFlag )
        {
             PPT_METHODTRACE_V1("", "downLoadFlag turns to True.");
             downLoadFlag = TRUE;
        }
        else
        {
            PPT_METHODTRACE_V1("", "else.");
            if ( TRUE == strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].recipeBodyConfirmFlag )
            {
                PPT_METHODTRACE_V1("", "recipeBodyConfirmFlag == TRUE");
                //---------------------
                // Recipe Confirmation
                //---------------------
                PPT_METHODTRACE_V1("", "Call txRecipeConfirmationReq");
                pptRecipeConfirmationReqResult strRecipeConfirmationReqResult;
                rc = txRecipeConfirmationReq( strRecipeConfirmationReqResult,
                                              strObjCommonIn,
                                              strInParm.equipmentID,
                                              strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID,
                                              strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].physicalRecipeID,
                                              strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].fileLocation,
                                              strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].fileName,
                                              strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].formatFlag,
                                              "" );

                if ( rc != RC_OK && rc != RC_TCS_MM_TAP_PP_CONFIRM_ERROR)  // RC_TCS_MM_TAP_PP_CONFIRM_ERROR = 5914
                {
                    PPT_METHODTRACE_V2("", "txRecipeConfirmationReq() != RC_OK", rc);
                    strStartDurablesReservationReqResult.strResult = strRecipeConfirmationReqResult.strResult;
                    return rc;
                }

                if ( rc == RC_TCS_MM_TAP_PP_CONFIRM_ERROR )
                {
                    PPT_METHODTRACE_V1("", "rc == RC_TCS_MM_TAP_PP_CONFIRM_ERROR");
                    if ( TRUE == strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].conditionalDownLoadFlag )
                    {
                        //--------------------------
                        // Conditional Down Load
                        //--------------------------
                        PPT_METHODTRACE_V1("", "downLoadFlag turns to True.");
                        downLoadFlag = TRUE;
                    }
                    else
                    {
                        //Recipe Body Confirmation error. the Recipe Body differs between Uploaded it to system and the owned it by equipment.
                        PPT_METHODTRACE_V2("", "Recipe Body Confirmation error. the Recipe Body differs between Uploaded it to system and the owned it by equipment.",
                                           strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID.identifier);
                        PPT_SET_MSG_RC_KEY( strStartDurablesReservationReqResult,
                                            MSG_RECIPE_CONFIRM_ERROR,
                                            RC_RECIPE_CONFIRM_ERROR,
                                            strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID.identifier );
                        return RC_RECIPE_CONFIRM_ERROR;
                    }
                }
            }
            else
            {
                PPT_METHODTRACE_V1("","Recipe Body management .. no action.");
                // no action.
            }
        }

        PPT_METHODTRACE_V2("", "Recipe Down Load ??", (downLoadFlag?"True":"False"));
        if ( TRUE == downLoadFlag )
        {
            //---------------------
            // Recipe Down Load
            //---------------------
            PPT_METHODTRACE_V1("","Call txRecipeDownloadReq");
            pptRecipeDownloadReqResult strRecipeDownloadReqResult;
            rc = txRecipeDownloadReq( strRecipeDownloadReqResult,
                                      strObjCommonIn,
                                      strInParm.equipmentID,
                                      strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].machineRecipeID,
                                      strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].physicalRecipeID,
                                      strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].fileLocation,
                                      strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].fileName,
                                      strMachineRecipe_GetListForRecipeBodyManagementForDurable_out.strRecipeBodyManagementSeq[targetRecipeCnt].formatFlag,
                                      "" );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "txRecipeDownloadReq() != RC_OK", rc);
                strStartDurablesReservationReqResult.strResult = strRecipeDownloadReqResult.strResult;
                return rc;
            }
        }
    } //Loop of targetRecipeLen

    if ( 0 == CIMFWStrCmp(strInParm.durableCategory, SP_DurableCat_Cassette) )
    {
        PPT_METHODTRACE_V1("", "durableCategory == SP_DurableCat_Cassette");
        for ( durableCnt=0; durableCnt < durableLen; durableCnt++ )
        {
            PPT_METHODTRACE_V2("", "loop to strInParm.strStartDurables.length()", durableCnt);
            objDurable_CassetteCategory_CheckForContaminationControl_out strDurable_CassetteCategory_CheckForContaminationControl_out;
            objDurable_CassetteCategory_CheckForContaminationControl_in  strDurable_CassetteCategory_CheckForContaminationControl_in;
            strDurable_CassetteCategory_CheckForContaminationControl_in.cassetteID  = strInParm.strStartDurables[durableCnt].durableID;
            strDurable_CassetteCategory_CheckForContaminationControl_in.equipmentID = strInParm.equipmentID;
            strDurable_CassetteCategory_CheckForContaminationControl_in.portID      = strInParm.strStartDurables[durableCnt].strStartDurablePort.loadPortID;
            rc = durable_CassetteCategory_CheckForContaminationControl( strDurable_CassetteCategory_CheckForContaminationControl_out,
                                                                        strObjCommonIn,
                                                                        strDurable_CassetteCategory_CheckForContaminationControl_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "durable_CassetteCategory_CheckForContaminationControl() != RC_OK", rc);
                strStartDurablesReservationReqResult.strResult = strDurable_CassetteCategory_CheckForContaminationControl_out.strResult;
                return rc;
            }

            objCassette_dispatchState_Change_out strCassette_dispatchState_Change_out;
            rc = cassette_dispatchState_Change( strCassette_dispatchState_Change_out,
                                                strObjCommonIn,
                                                strInParm.strStartDurables[durableCnt].durableID,
                                                TRUE );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "cassette_dispatchState_Change() != RC_OK", rc);
                strStartDurablesReservationReqResult.strResult = strCassette_dispatchState_Change_out.strResult;
                return rc;
            }
        }
    }

    pptDurableControlJobManageReqResult  strDurableControlJobManageReqResult;
    pptDurableControlJobManageReqInParam strDurableControlJobManageReqInParam;
    objectIdentifier dummyDurableControlJobID;
    dummyDurableControlJobID.identifier = CIMFWStrDup("");
    strDurableControlJobManageReqInParam.durableControlJobID               = dummyDurableControlJobID;
    strDurableControlJobManageReqInParam.controlJobAction                  = CIMFWStrDup( SP_DurableControlJobAction_Type_create );
    pptDurableControlJobCreateRequest strDurableControlJobCreateRequest;
    strDurableControlJobCreateRequest.equipmentID      = strInParm.equipmentID;
    strDurableControlJobCreateRequest.durableCategory  = strInParm.durableCategory;
    strDurableControlJobCreateRequest.strStartDurables = strInParm.strStartDurables;
    strDurableControlJobManageReqInParam.strDurableControlJobCreateRequest = strDurableControlJobCreateRequest;
    rc = txDurableControlJobManageReq( strDurableControlJobManageReqResult,
                                       strObjCommonIn,
                                       strDurableControlJobManageReqInParam,
                                       claimMemo );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "txDurableControlJobManageReq() != RC_OK", rc);
        strStartDurablesReservationReqResult.strResult = strDurableControlJobManageReqResult.strResult;
        return rc;
    }

    objProcess_startDurablesReserveInformation_Set_out strProcess_startDurablesReserveInformation_Set_out;
    objProcess_startDurablesReserveInformation_Set_in  strProcess_startDurablesReserveInformation_Set_in;
    strProcess_startDurablesReserveInformation_Set_in.equipmentID           = strInParm.equipmentID;
    strProcess_startDurablesReserveInformation_Set_in.portGroupID           = portGroupID;
    strProcess_startDurablesReserveInformation_Set_in.durableControlJobID   = strDurableControlJobManageReqResult.durableControlJobID;
    strProcess_startDurablesReserveInformation_Set_in.durableCategory       = strInParm.durableCategory;
    strProcess_startDurablesReserveInformation_Set_in.strStartDurables      = strInParm.strStartDurables;
    strProcess_startDurablesReserveInformation_Set_in.strDurableStartRecipe = strInParm.strDurableStartRecipe;
    rc = process_startDurablesReserveInformation_Set( strProcess_startDurablesReserveInformation_Set_out,
                                                      strObjCommonIn,
                                                      strProcess_startDurablesReserveInformation_Set_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "process_startDurablesReserveInformation_Set() != RC_OK", rc);
        strStartDurablesReservationReqResult.strResult = strProcess_startDurablesReserveInformation_Set_out.strResult;
        return rc;
    }

    /*--------------------------------------------*/
    /*   Send Start Durables Reservation to TCS   */
    /*--------------------------------------------*/
    CORBA::String_var tmpSleepTimeValue  = CIMFWStrDup(getenv(SP_BIND_SLEEP_TIME_TCS));
    CORBA::String_var tmpRetryCountValue = CIMFWStrDup(getenv(SP_BIND_RETRY_COUNT_TCS));
    CORBA::Long sleepTimeValue = 0;
    CORBA::Long retryCountValue = 0;

    if ( 0 == CIMFWStrLen(tmpSleepTimeValue) )
    {
        PPT_METHODTRACE_V1("", "0 == CIMFWStrLen(tmpSleepTimeValue)");
        sleepTimeValue = SP_DEFAULT_SLEEP_TIME_TCS;
    }
    else
    {
        PPT_METHODTRACE_V1("", "0 != CIMFWStrLen(tmpSleepTimeValue)");
        sleepTimeValue = atoi(tmpSleepTimeValue);
    }

    if ( 0 == CIMFWStrLen(tmpRetryCountValue) )
    {
        PPT_METHODTRACE_V1("", "0 == CIMFWStrLen(tmpRetryCountValue)");
        retryCountValue = SP_DEFAULT_RETRY_COUNT_TCS;
    }
    else
    {
        PPT_METHODTRACE_V1("", "0 != CIMFWStrLen(tmpRetryCountValue)");
        retryCountValue = atoi(tmpRetryCountValue);
    }

    PPT_METHODTRACE_V2("", "env value of SP_BIND_SLEEP_TIME_TCS  = ", sleepTimeValue);
    PPT_METHODTRACE_V2("", "env value of SP_BIND_RETRY_COUNT_TCS = ", retryCountValue);

    //INN-R170003 add start
    csStartDurablesReservationReqInParam_siInfo strStartDurablesReservationReqInParam_siInfo ;
    strStartDurablesReservationReqInParam_siInfo.durableControlJobID = strDurableControlJobManageReqResult.durableControlJobID ;
    PPT_METHODTRACE_V2("", "durableControlJobID = ", strStartDurablesReservationReqInParam_siInfo.durableControlJobID.identifier) ;
    //INN-R170003 add end

    objTCSMgr_SendStartDurablesReservationReq_out strTCSMgr_SendStartDurablesReservationReq_out;
    objTCSMgr_SendStartDurablesReservationReq_in  strTCSMgr_SendStartDurablesReservationReq_in;
    strTCSMgr_SendStartDurablesReservationReq_in.strStartDurablesReservationReqInParam          = strInParm;
    strTCSMgr_SendStartDurablesReservationReq_in.strStartDurablesReservationReqInParam.siInfo <<= strStartDurablesReservationReqInParam_siInfo;     //INN-R170003
    strTCSMgr_SendStartDurablesReservationReq_in.claimMemo                                      = claimMemo;

    //'retryCountValue + 1' means first try plus retry count
    for ( CORBA::ULong retryNum=0; retryNum < (retryCountValue + 1); retryNum++ )
    {
        PPT_METHODTRACE_V2("", "loop to retryCountValue + 1", retryNum);
        /*--------------------------*/
        /*    Send Request to TCS   */
        /*--------------------------*/
        rc = TCSMgr_SendStartDurablesReservationReq( strTCSMgr_SendStartDurablesReservationReq_out,
                                                     strObjCommonIn,
                                                     strTCSMgr_SendStartDurablesReservationReq_in );

        PPT_METHODTRACE_V2("", "rc = ", rc);

        if (rc == RC_OK)
        {
            PPT_METHODTRACE_V1("", "Now TCS subSystem is alive!! Go ahead");
            break;
        }
        else if ( rc == RC_EXT_SERVER_BIND_FAIL
               || rc == RC_EXT_SERVER_NIL_OBJ
               || rc == RC_TCS_NO_RESPONSE )
        {
            PPT_METHODTRACE_V2("", "TCS subsystem has return NO_RESPONSE!! just retry now!!  now count...", retryNum);
            PPT_METHODTRACE_V2("", "now sleeping... ", sleepTimeValue);
            sleep(sleepTimeValue);
            continue;
        }
        else
        {
            PPT_METHODTRACE_V1("", "TCSMgr_SendStartDurablesReservationReq() != RC_OK");
            strStartDurablesReservationReqResult.strResult = strTCSMgr_SendStartDurablesReservationReq_out.strResult;
            return rc;
        }
    }

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "TCSMgr_SendStartDurablesReservationReq() != RC_OK");
        strStartDurablesReservationReqResult.strResult = strTCSMgr_SendStartDurablesReservationReq_out.strResult;
        return rc;
    }

    // Set Return Structure
    strStartDurablesReservationReqResult.durableControlJobID = strDurableControlJobManageReqResult.durableControlJobID;

    // Return to caller
    SET_MSG_RC( strStartDurablesReservationReqResult, MSG_OK, RC_OK );
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txStartDurablesReservationReq");
    return RC_OK;
}