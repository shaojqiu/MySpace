#ifndef lint
static char *sccsid =  "@(#) 1.3 superpos/src/spppt/source/posppt/pptmgr/txmethods/txReworkPartialWaferLotCancelReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 8/3/07 13:52:17 [ 8/3/07 13:52:18 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2014. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2014. All rights reserved.
//
// SiView
// Name: txReworkPartialWaferLotCancelReq.cpp
//

#include "cs_pptmgr.hpp"
#include "penin.hh"

// Class: PPTManager
//
// Service: txReworkPartialWaferLotCancelReq()
//
// Change history:
// Date       Defect#    Person         Comments
// ---------- ---------- -------------- -------------------------------------------
// 2000/08/18            O.Sugiyama     Initial Release
// 2000/09/12 P3000139   M.Mori         add SET_MSG_RC
// 2000/09/18 P3000139   T.Yamano       add SET_MSG_RC
// 2000/09/26 Q3000147   M.Mori         Add Check Lot's Control Job ID
// 2001-02-27 P3100051   M.Shimizu      LC:Delete LC/FR-Definition when Child-Lot is merged.
// 2001-03-15 P3100053   M.Shimizu      LC:add process_CheckMergeForLCFR() call
// 2001-03-15 P3100053   M.Shimizu      LC:Delete modification on 2001-03-08.
// 2001/04/10 P3100257   K.Matsuei      PartialReworkCancel shouldn't be forgiven after it is
//                                      returned to MailRoute with AllReworkCancel.
// 2001/07/02 P4000037   K.Kido         Add XferState Check
// 2001/08/01 P4000079   K.Kido         Change XferState check logic
// 2002/01/15 D4100069   C.Tsuchiya     Drop LCFR logic
// 2002/03/01 D4100120   N.Minami       Future Action
// 2002/03/05 D4100036   K.Matsuei      FlowBatch Control.
// 2003/05/30 D5000023   K.Kido         Wafer level control for ReworkCount(Rel5.0). Delete decrement logic for parentLot.
// 2003/09/09 P5000145   H.Adachi       Fix Message and Message Macro mismatch.
// 2003/11/05 P5100032   JosephSoong    Decrease wafer rework count of ChildLot for Wafer level control.
// 2004/10/22 D6000025   K.Murakami     eBroker Migration.
// 2005/05/18 D6000259   H.Hasegawa     Change the logic which judges the necessity of txHoldLotReleaseReq().
// 2005/08/17 P6000592   H.Hasegawa     Move the logic which increments the counters.
// 2005/09/22 D7000012   M.Kase         Change order of process_reworkCount_Decrement() and process_CancelBranchRoute()
//                                      (Change wafer level control for rework count)
// 2005/11/18 D7000021   M.Murata       Add : Check lot's hold state. (LOCK)
// 2005/12/16 P7000058   Y.Kadowaki     Add check logic for carrier dispatch status.
// 2006/05/18 D7000092   Y.Kadowaki     Add object lock for cassette.
// 2007/02/16 P8000005   D.Tamura       Add lot_RemoveFromMonitorGroup().
// 2007/06/13 D9000005   H.Hotta        WaferSorter automation support.
// 2007/08/03 D9000056   H.Hotta        Add check logic for InPostProcessFlag.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
// 2008/10/29 DSIV00000214 S.Miyata       Multi Fab Transfer Support
// 2010/03/15 DSIV00001830 S.Kawabe       Wafer Stacking Operation Support
// 2012/02/15 DSN000033655 K.Yamaoku      Q-Time Lot Merge Improvement
// 2013/05/10 DSN000071674 Liuya          Remove part of the EI state limitation
// 2014/01/21 PSN000083176 C.Mo           Data inconsistency might occur when start lot reservation is called together with lot operation transactions for the same cassette
// 2014/06/05 DSN000085791 C.Mo           Entity Inhibit Exception Lot Support. (R150)
// 2014/07/29 DSN000085792 Sa Guo         Q-Time Improvements.
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/09 INN-R170003  XL.Cong        Durable Management Enhancement
//
//
//
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    pptReworkPartialWaferLotCancelReqResult&    strReworkPartialWaferLotCancelReqResult
//    const pptObjCommonIn&                       strObjCommonIn
//    const objectIdentifier&                     parentLotID
//    const objectIdentifier&                     childLotID
//    const objectIdentifier&                     reasonCodeID
//    const char *                                claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::txReworkPartialWaferLotCancelReq (
    pptReworkPartialWaferLotCancelReqResult&    strReworkPartialWaferLotCancelReqResult,
    const pptObjCommonIn&                       strObjCommonIn,
    const objectIdentifier&                     parentLotID,
    const objectIdentifier&                     childLotID,
    const objectIdentifier&                     reasonCodeID,
//D6000025     const char *                                claimMemo,
//D6000025     CORBA::Environment &                        IT_env)
    const char *                                claimMemo //D6000025
    CORBAENV_LAST_CPP)                                    //D6000025
{
    PPT_METHODTRACE_ENTRY("PPTManager_i:: txReworkPartialWaferLotCancelReq ");
    CORBA::Long rc = RC_OK;

//P7000058 add start
    //------------------------------
    // Get cassette ID of parent Lot
    //------------------------------
    objLot_cassette_Get_out strLot_cassette_Get_out;
    rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, parentLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lot_cassette_Get() rc != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_cassette_Get_out.strResult;
        return( rc );
    }
//P7000058 add end

    //--------------------------------
    //   Lock objects to be updated
    //--------------------------------
    objObject_Lock_out strObject_Lock_out;

//DSN000071674 add start
    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );

    CORBA::Boolean updateControlJobFlag = FALSE;
    CORBA::Long lockMode = 0; //PSN000083176

    objCassette_transferState_Get_out strCassetteTransferState;

    if ( 0 == lotOperationEIcheck )
    {
        //-------------------------------
        // Get carrier transfer status
        //-------------------------------
        rc = cassette_transferState_Get(strCassetteTransferState, strObjCommonIn,
                                        strLot_cassette_Get_out.cassetteID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "rc != RC_OK");
            strReworkPartialWaferLotCancelReqResult.strResult = strCassetteTransferState.strResult ;
            return( rc );
        }

        /*------------------------------------*/
        /*   Get equipment ID in Cassette     */
        /*------------------------------------*/
        objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
        rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                       strObjCommonIn,
                                       strLot_cassette_Get_out.cassetteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "cassette_equipmentID_Get != RC_OK", rc);
            strReworkPartialWaferLotCancelReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
            return( rc );
        }

        //-------------------------------
        // Get required equipment lock mode
        //-------------------------------
        objObject_lockMode_Get_out strObject_lockMode_Get_out;
        objObject_lockMode_Get_in  strObject_lockMode_Get_in;
        strObject_lockMode_Get_in.objectID           = strCassette_equipmentID_Get_out.equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXTRC029" ); // TxReworkPartialWaferLotCancelReq
        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strReworkPartialWaferLotCancelReqResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }

//PSN000083176        CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
        lockMode = strObject_lockMode_Get_out.lockMode; //PSN000083176
        PPT_METHODTRACE_V2( "", "lockMode", lockMode );
//INN-R170003 if ( 0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn))
//INN-R170003 add start
        if ( 0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) ||
             0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentOut) || 
             0 == CIMFWStrCmp(strCassetteTransferState.transferState, CS_TRANS_STATE_PORT_IN))
//INN-R170003 add end
        {
            updateControlJobFlag = TRUE;

            if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
            {
                objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
                objAdvanced_object_Lock_in strAdvanced_object_Lock_in;

                // Lock Equipment Main Object
                stringSequence dummySeq;
                dummySeq.length(0);
                strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
                strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
                strAdvanced_object_Lock_in.keySeq     = dummySeq;

                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strReworkPartialWaferLotCancelReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }

                // Lock Equipment LoadCassette Element (Write)
                stringSequence loadCastSeq;
                loadCastSeq.length(1);
                loadCastSeq[0] = strLot_cassette_Get_out.cassetteID.identifier;
                strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
                strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
                strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strReworkPartialWaferLotCancelReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }
            }
            else
            {
                /*--------------------------------*/
                /*   Lock Macihne object          */
                /*--------------------------------*/
                rc = object_Lock( strObject_Lock_out, strObjCommonIn, strCassette_equipmentID_Get_out.equipmentID, SP_ClassName_PosMachine );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc) ;
                    strReworkPartialWaferLotCancelReqResult.strResult = strObject_Lock_out.strResult ;
                    return( rc );
                }
            }
        }
//PSN000083176        if( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176        {
//PSN000083176            //---------------------------------
//PSN000083176            //   Get Cassette's ControlJobID
//PSN000083176            //---------------------------------
//PSN000083176            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

//PSN000083176            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
//PSN000083176                                            strObjCommonIn,
//PSN000083176                                            strLot_cassette_Get_out.cassetteID );
//PSN000083176            if ( rc != RC_OK )
//PSN000083176            {
//PSN000083176                PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
//PSN000083176                strReworkPartialWaferLotCancelReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
//PSN000083176                return( rc );
//PSN000083176            }
//PSN000083176            if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
//PSN000083176            {
//PSN000083176                PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
//PSN000083176                updateControlJobFlag = TRUE;
//PSN000083176                if( lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176                {
//PSN000083176                    /*------------------------------*/
//PSN000083176                    /*   Lock ControlJob Object     */
//PSN000083176                    /*------------------------------*/
//PSN000083176                    rc = object_Lock( strObject_Lock_out,
//PSN000083176                                      strObjCommonIn, 
//PSN000083176                                      strCassette_controlJobID_Get_out.controlJobID, 
//PSN000083176                                      SP_ClassName_PosControlJob );
//PSN000083176                    if ( rc != RC_OK )
//PSN000083176                    {
//PSN000083176                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
//PSN000083176                        strReworkPartialWaferLotCancelReqResult.strResult = strObject_Lock_out.strResult;
//PSN000083176                        return( rc );
//PSN000083176                    }
//PSN000083176                }
//PSN000083176            }
//PSN000083176        }
    }
//DSN000071674 add end

//D7000092 add start
    rc = object_Lock(strObject_Lock_out, strObjCommonIn,
                     strLot_cassette_Get_out.cassetteID, SP_ClassName_PosCassette);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_Lock(cassette) rc != RC_OK", rc);
        strReworkPartialWaferLotCancelReqResult.strResult = strObject_Lock_out.strResult;
        return( rc );
    }
//D7000092 add end

//PSN000083176 add start
    if ( 0 == lotOperationEIcheck )
    {
        if( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
        {
            //---------------------------------
            //   Get Cassette's ControlJobID
            //---------------------------------
            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                            strObjCommonIn,
                                            strLot_cassette_Get_out.cassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
                strReworkPartialWaferLotCancelReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
                return( rc );
            }
            if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
            {
                PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
                updateControlJobFlag = TRUE;
                if( lockMode != SP_EQP_LOCK_MODE_WRITE )
                {
                    /*------------------------------*/
                    /*   Lock ControlJob Object     */
                    /*------------------------------*/
                    rc = object_Lock( strObject_Lock_out,
                                      strObjCommonIn, 
                                      strCassette_controlJobID_Get_out.controlJobID, 
                                      SP_ClassName_PosControlJob );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                        strReworkPartialWaferLotCancelReqResult.strResult = strObject_Lock_out.strResult;
                        return( rc );
                    }
                }
            }
        }
    }
//PSN000083176 add end

    rc = object_Lock(strObject_Lock_out, strObjCommonIn,
                     parentLotID, SP_ClassName_PosLot); // for Parent Lot
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "object_Lock(parentLotID) rc != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strObject_Lock_out.strResult;
        return( rc );
    }

    rc = object_Lock(strObject_Lock_out, strObjCommonIn, childLotID, SP_ClassName_PosLot); // for Child Lot
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "object_Lock(childLotID) rc != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strObject_Lock_out.strResult;
        return( rc );
    }

//D7000021 add start
    //------------------------------------
    // Check LOCK Hold.
    //------------------------------------
    PPT_METHODTRACE_V1("", "Check LOCK Hold. ");
    objectIdentifierSequence lotIDSeq;
    lotIDSeq.length(2);
    lotIDSeq[0] = parentLotID;
    lotIDSeq[1] = childLotID;
    objLot_CheckLockHoldConditionForOperation_out  strLot_CheckLockHoldConditionForOperation_out;
    rc = lot_CheckLockHoldConditionForOperation( strLot_CheckLockHoldConditionForOperation_out, strObjCommonIn, lotIDSeq );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_CheckLockHoldConditionForOperation rc != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_CheckLockHoldConditionForOperation_out.strResult;
        return ( rc );
    }
//D7000021 add end

//D9000056 add start
    //-----------------------------
    //  Check InPostProcessFlag
    //-----------------------------
    PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
//DSIV00000201 Add Start
    objectIdentifierSequence userGroupIDs;
    userGroupIDs.length(0);
    CORBA::ULong userGroupIDsLen = userGroupIDs.length();

//DSIV00000201 Add End
    for( CORBA::Long loopCnt = 0; loopCnt < lotIDSeq.length(); loopCnt++ )
    {
        //----------------------------------
        //  Get InPostProcessFlag of Lot
        //----------------------------------
        objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
        objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
        strLot_inPostProcessFlag_Get_in.lotID = lotIDSeq[loopCnt];

        rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                        strObjCommonIn,
                                        strLot_inPostProcessFlag_Get_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
            strReworkPartialWaferLotCancelReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
            return( rc );
        }

        //----------------------------------------------
        //  If Lot is in post process, returns error
        //----------------------------------------------
        if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
        {
            PPT_METHODTRACE_V1("", "Lot is in post process.");
//DSIV00000201 Add Start
            if (userGroupIDsLen == 0)
            {
                /*---------------------------*/
                /* Get UserGroupID By UserID */
                /*---------------------------*/
                objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
                rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                                 strObjCommonIn,
                                                 strObjCommonIn.strUser.userID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
                    strReworkPartialWaferLotCancelReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
                    return( rc );
                }
                userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
                userGroupIDsLen = userGroupIDs.length();
                PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);
            }
            CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
            PPT_METHODTRACE_V2("", "extPostProc", extPostProc);
            
            CORBA::ULong nCnt = 0;
            for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
            {
                PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
                if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
                {
                    PPT_METHODTRACE_V1("", "# External Post Process User!");
                    break;
                }
                
            }
            if (nCnt == userGroupIDsLen)
            {
                PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
                PPT_SET_MSG_RC_KEY( strReworkPartialWaferLotCancelReqResult,
                                    MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                    lotIDSeq[loopCnt].identifier );
                return( RC_LOT_INPOSTPROCESS );
            }   //DSIV00000201
        }
    }
//D9000056 add end

//DSIV00000214 add start
    //---------------------------------------
    //   Check interFabXferPlan existence
    //---------------------------------------
    objLot_currentRouteID_Get_out strLot_currentRouteID_Get_out;
    rc = lot_currentRouteID_Get( strLot_currentRouteID_Get_out,
                                 strObjCommonIn,
                                 childLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_currentRouteID_Get() != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_currentRouteID_Get_out.strResult;
        return( rc );
    }

    objInterFab_xferPlanList_GetDR_out strInterFab_xferPlanList_GetDR_out;
    objInterFab_xferPlanList_GetDR_in strInterFab_xferPlanList_GetDR_in;
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.lotID = childLotID;
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.seqNo = 0;
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalFabID = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalRouteID = strLot_currentRouteID_Get_out.currentRouteID;
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalOpeNumber = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.destinationFabID = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.destinationRouteID.identifier = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.destinationOpeNumber = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.xferType = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.description = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.modifierUserID.identifier = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.modifiedTime = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.state = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.stateUpdateTime = CIMFWStrDup("");

    rc = interFab_xferPlanList_GetDR( strInterFab_xferPlanList_GetDR_out,
                                      strObjCommonIn,
                                      strInterFab_xferPlanList_GetDR_in );
    if( rc != RC_OK && rc != RC_INTERFAB_NOT_FOUND_XFERPLAN )
    {
        PPT_METHODTRACE_V1("", "interFab_xferPlanList_GetDR() != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strInterFab_xferPlanList_GetDR_out.strResult;
        return( rc );
    }

    CORBA::Long xferLen = strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq.length();
    for( CORBA::Long xCnt = 0; xCnt < xferLen; xCnt++ )
    {
        if( 0 != CIMFWStrCmp(strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq[xCnt].state,
                             SP_InterFab_XferPlanState_Completed) )
        {
            PPT_METHODTRACE_V1("", "strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq.length != 0");
            SET_MSG_RC( strReworkPartialWaferLotCancelReqResult,
                        MSG_INTERFAB_BRANCH_CANCEL_ERROR,
                        RC_INTERFAB_BRANCH_CANCEL_ERROR );
            return( RC_INTERFAB_BRANCH_CANCEL_ERROR );
        }
    }
//DSIV00000214 add end

//D9000005 add start
    /*-------------------------------*/
    /*   Check SorterJob existence   */
    /*-------------------------------*/
    pptEquipmentLoadPortAttribute dummyEquipmentPortAttribute;
    objectIdentifierSequence dummyCastIDs;

    objWaferSorter_sorterJob_CheckForOperation_out strWaferSorter_sorterJob_CheckForOperation_out;
    objWaferSorter_sorterJob_CheckForOperation_in  strWaferSorter_sorterJob_CheckForOperation_in;
    strWaferSorter_sorterJob_CheckForOperation_in.strEquipmentLoadPortAttribute = dummyEquipmentPortAttribute;
    strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs                   = dummyCastIDs;
    strWaferSorter_sorterJob_CheckForOperation_in.lotIDs                        = lotIDSeq;
    strWaferSorter_sorterJob_CheckForOperation_in.operation                     = CIMFWStrDup(SP_Operation_For_Lot);

    rc = waferSorter_sorterJob_CheckForOperation( strWaferSorter_sorterJob_CheckForOperation_out,
                                                  strObjCommonIn,
                                                  strWaferSorter_sorterJob_CheckForOperation_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "waferSorter_sorterJob_CheckForOperation() != RC_OK" );
        strReworkPartialWaferLotCancelReqResult.strResult = strWaferSorter_sorterJob_CheckForOperation_out.strResult;
        return( rc );
    }
//D9000005 add end

//P3100257 start
    objLot_productionState_Get_out strLot_productionState_Get_out ;
    rc = lot_productionState_Get(strLot_productionState_Get_out, strObjCommonIn, childLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_productionState_Get() != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_productionState_Get_out.strResult;
        return(rc);
    }
    else if( 0 != CIMFWStrCmp(strLot_productionState_Get_out.lotProductionState, CIMFW_Lot_ProductionState_InRework) )
    {
        PPT_METHODTRACE_V1("", "lotProductionState != CIMFW_Lot_ProductionState_InRework");
        PPT_SET_MSG_RC_KEY2(strReworkPartialWaferLotCancelReqResult,
                            MSG_INVALID_LOT_PRODSTAT,
                            RC_INVALID_LOT_PRODSTAT,
                            childLotID.identifier,
                            strLot_productionState_Get_out.lotProductionState );
        return(RC_INVALID_LOT_PRODSTAT);
    }
//P3100257 end

//P4000037 add start
    //----------------------------------
    // Check parent lot transfer status
    //----------------------------------
    objLot_transferState_Get_out strLot_transferState_Get_out ;

//DSN000071674 add start
//INN-R170003 if ( 1 == lotOperationEIcheck || ( 0 == lotOperationEIcheck && ( 0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn)
//INN-R170003 add start
    if ( 1 == lotOperationEIcheck
    || ( 0 == lotOperationEIcheck && 
            ( 0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) &&
              0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentOut) &&
              0 != CIMFWStrCmp(strCassetteTransferState.transferState, CS_TRANS_STATE_PORT_IN ) ) ) )
//INN-R170003 add end
    {
//DSN000071674 add end
        rc = lot_transferState_Get(strLot_transferState_Get_out,strObjCommonIn,parentLotID);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "rc != RC_OK");
            strReworkPartialWaferLotCancelReqResult.strResult = strLot_transferState_Get_out.strResult ;
            return(rc);
        }
//DSN000071674 add start
        CORBA::String_var parentCassetteXferState = strLot_transferState_Get_out.transferState;
        if ( 0 == lotOperationEIcheck )
        {
            PPT_METHODTRACE_V1("", "lotOperationEIcheck = 0");
//INN-R170003 if ( 0 == CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_EquipmentIn))
//INN-R170003 add start
            if ( 0 == CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_EquipmentIn) ||
                 0 == CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_EquipmentOut) ||
                 0 == CIMFWStrCmp(strLot_transferState_Get_out.transferState, CS_TRANS_STATE_PORT_IN))
//INN-R170003 add end                                                      //D4100091
            {
                PPT_METHODTRACE_V1("","Changed to EI by other operation");
                strReworkPartialWaferLotCancelReqResult.strResult = strLot_transferState_Get_out.strResult ;
                PPT_SET_MSG_RC_KEY(strReworkPartialWaferLotCancelReqResult, MSG_CHANGED_TO_EI_BY_OTHER_OPERATION, RC_CHANGED_TO_EI_BY_OTHER_OPERATION,
                                   strLot_cassette_Get_out.cassetteID.identifier);
//INN-R170003   return( RC_INVALID_LOT_XFERSTAT )
//INN-R170003 add start
                return( CS_RC_CAST_XFERSTATE_BE_CHANGED_BY_OTHER_OPERATION );
//INN-R170003 add end
            }
        }
//DSN000071674 add end
//P4000079    else if(!(CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_TransState_EquipmentOut)    == 0  ||
//P4000079              CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_TransState_ManualOut)       == 0  ||
//P4000079              CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_TransState_IntermediateOut) == 0  ||
//P4000079              CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_TransState_ShelfOut)        == 0  ||
//P4000079              CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_UNDEFINED_STATE)            == 0  ||
//P4000079              CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_TransState_AbnormalOut)     == 0  ||
//P4000079              CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_TransState_StationOut)      == 0) )
//INN-R170003 else if (CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_BayOut    ) == 0 ||CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 )
//INN-R170003 add start
        else if (CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_BayOut    ) == 0 ||
                 CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 ||              //P4000079
                 CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_EquipmentOut) == 0 ||
                 CIMFWStrCmp(strLot_transferState_Get_out.transferState, CS_TRANS_STATE_PORT_IN) == 0)
//INN-R170003 add end
        {
            PPT_METHODTRACE_V1("","XFERSTAT is INVALID...");
            PPT_SET_MSG_RC_KEY2(strReworkPartialWaferLotCancelReqResult,
                                MSG_INVALID_LOT_XFERSTAT ,
                                RC_INVALID_LOT_XFERSTAT,
                                parentLotID.identifier,
                                strLot_transferState_Get_out.transferState);
            return( RC_INVALID_LOT_XFERSTAT );
        }
//DSN000071674 add start
    }
    if ( 0 == lotOperationEIcheck )
    {
        strLot_transferState_Get_out.transferState = strCassetteTransferState.transferState;
    }
//DSN000071674 add end

//DSN000071674 add start
    if ( 1 == lotOperationEIcheck )
    {
//DSN000071674 add end
        //----------------------------------
        // Check child lot transfer status
        //----------------------------------
        rc = lot_transferState_Get(strLot_transferState_Get_out,strObjCommonIn,childLotID);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "rc != RC_OK");
            strReworkPartialWaferLotCancelReqResult.strResult = strLot_transferState_Get_out.strResult ;
            return(rc);
        }
//P4000079    else if(!(CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_TransState_EquipmentOut)    == 0  ||
//P4000079              CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_TransState_ManualOut)       == 0  ||
//P4000079              CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_TransState_IntermediateOut) == 0  ||
//P4000079              CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_TransState_ShelfOut)        == 0  ||
//P4000079              CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_UNDEFINED_STATE)            == 0  ||
//P4000079              CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_TransState_AbnormalOut)     == 0  ||
//P4000079              CIMFWStrCmp(strLot_transferState_Get_out.transferState,SP_TransState_StationOut)      == 0) )
//INN-R170003 else if (CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_BayOut    ) == 0 || CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 )
//INN-R170003 add start
        else if (CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_BayOut    ) == 0 ||
                 CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 ||             //P4000079
                 CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_EquipmentOut) == 0 ||
                 CIMFWStrCmp(strLot_transferState_Get_out.transferState, CS_TRANS_STATE_PORT_IN) == 0)
//INN-R170003 add end
        {
            PPT_METHODTRACE_V1("","XFERSTAT is INVALID...");
            PPT_SET_MSG_RC_KEY2(strReworkPartialWaferLotCancelReqResult,
                                MSG_INVALID_LOT_XFERSTAT ,
                                RC_INVALID_LOT_XFERSTAT,
                                childLotID.identifier,
                                strLot_transferState_Get_out.transferState);
            return( RC_INVALID_LOT_XFERSTAT );
        }
    } //DSN000071674
//P4000037 add end

    //---------------------------------------------
    // Check Lot Contents for Parent Lot
    //---------------------------------------------
    objLot_contents_Get_out strLot_contents_Get_out;

    rc = lot_contents_Get(strLot_contents_Get_out, strObjCommonIn, parentLotID);  //for ParentLot
    if ( rc )
    {
        PPT_METHODTRACE_V1("", "lot_contents_Get(parentLotID) rc != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_contents_Get_out.strResult;
        return( rc );
    }
    if (CIMFWStrCmp(strLot_contents_Get_out.theLotContents, SP_ProdType_Wafer) != 0 &&
        CIMFWStrCmp(strLot_contents_Get_out.theLotContents, SP_ProdType_Die  ) != 0)
    {
        PPT_METHODTRACE_V1("", "lot_contents_Get(parentLotID) theLotContents !SP_ProdType_Wafer && !SP_ProdType_Die");
        PPT_SET_MSG_RC_KEY(strReworkPartialWaferLotCancelReqResult, MSG_INVALID_LOT_CONTENTS, RC_INVALID_LOT_CONTENTS,
                           parentLotID.identifier);
        return( RC_INVALID_LOT_CONTENTS );
    }

    //---------------------------------------------
    // Check Lot Contents for Child Lot
    //---------------------------------------------
    rc = lot_contents_Get(strLot_contents_Get_out, strObjCommonIn, childLotID);   //for childLot
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lot_contents_Get(childLotID) rc != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_contents_Get_out.strResult;
        return( rc );
    }
    if (CIMFWStrCmp(strLot_contents_Get_out.theLotContents, SP_ProdType_Wafer) != 0 &&
        CIMFWStrCmp(strLot_contents_Get_out.theLotContents, SP_ProdType_Die  ) != 0)
    {
        PPT_METHODTRACE_V1("", "lot_contents_Get(childLotID) theLotContents !SP_ProdType_Wafer && !SP_ProdType_Die");
        PPT_SET_MSG_RC_KEY(strReworkPartialWaferLotCancelReqResult, MSG_INVALID_LOT_CONTENTS, RC_INVALID_LOT_CONTENTS,
                           childLotID.identifier);
        return( RC_INVALID_LOT_CONTENTS );
    }

//DSIV00001830 add start
    //---------------------------------------
    // Check Finished State of parent lot
    //---------------------------------------
    objLot_finishedState_Get_out strLot_finishedState_Get_out;
    rc = lot_finishedState_Get(strLot_finishedState_Get_out,strObjCommonIn,parentLotID);
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_finishedState_Get() rc != RC_OK")
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_finishedState_Get_out.strResult;
        return rc;
    }
    else if( CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,SP_LOT_FINISHED_STATE_STACKED) == 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,SP_LOT_FINISHED_STATE_STACKED) == 0");
        PPT_SET_MSG_RC_KEY( strReworkPartialWaferLotCancelReqResult,
                            MSG_INVALID_LOT_FINISHSTAT,
                            RC_INVALID_LOT_FINISHSTAT,
                            strLot_finishedState_Get_out.lotFinishedState );
    
        return RC_INVALID_LOT_FINISHSTAT;
    }

    //---------------------------------------
    // Check Finished State of child lot
    //---------------------------------------
    rc = lot_finishedState_Get(strLot_finishedState_Get_out,strObjCommonIn,childLotID);
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_finishedState_Get() rc != RC_OK")
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_finishedState_Get_out.strResult;
        return rc;
    }
    else if( CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,SP_LOT_FINISHED_STATE_STACKED) == 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrCmp(strLot_finishedState_Get_out.lotFinishedState,SP_LOT_FINISHED_STATE_STACKED) == 0");
        PPT_SET_MSG_RC_KEY2( strReworkPartialWaferLotCancelReqResult,
                             MSG_INVALID_LOT_FINISHSTAT,
                             RC_INVALID_LOT_FINISHSTAT,
                             childLotID.identifier,
                             strLot_finishedState_Get_out.lotFinishedState );
        return RC_INVALID_LOT_FINISHSTAT;
    }

    //---------------------------------------
    // Check Bonding Group for parent lot
    //---------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "Check Bonding Group for parent lot");

    objLot_bondingGroupID_GetDR_in  strLot_bondingGroupID_GetDR_in;
    strLot_bondingGroupID_GetDR_in.lotID = parentLotID;

    objLot_bondingGroupID_GetDR_out strLot_bondingGroupID_GetDR_out;
    rc = lot_bondingGroupID_GetDR( strLot_bondingGroupID_GetDR_out, strObjCommonIn, strLot_bondingGroupID_GetDR_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_bondingGroupID_GetDR() rc != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_bondingGroupID_GetDR_out.strResult;
        return rc;
    }
    if( CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0");
        PPT_SET_MSG_RC_KEY2( strReworkPartialWaferLotCancelReqResult,
                             MSG_LOT_HAS_BONDINGGROUP,
                             RC_LOT_HAS_BONDINGGROUP,
                             strLot_bondingGroupID_GetDR_in.lotID.identifier,
                             strLot_bondingGroupID_GetDR_out.bondingGroupID );
        return RC_LOT_HAS_BONDINGGROUP;
    }

    //---------------------------------------
    // Check Bonding Group for child lot
    //---------------------------------------
    PPT_METHODTRACE_V1("PPTManager_i:: txMergeWaferLotReq", "Check Bonding Group for child lot");

    strLot_bondingGroupID_GetDR_in.lotID = childLotID;
    rc = lot_bondingGroupID_GetDR( strLot_bondingGroupID_GetDR_out, strObjCommonIn, strLot_bondingGroupID_GetDR_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_bondingGroupID_GetDR() rc != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_bondingGroupID_GetDR_out.strResult;
        return rc;
    }
    if( CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0");
        PPT_SET_MSG_RC_KEY2( strReworkPartialWaferLotCancelReqResult,
                             MSG_LOT_HAS_BONDINGGROUP,
                             RC_LOT_HAS_BONDINGGROUP,
                             strLot_bondingGroupID_GetDR_in.lotID.identifier,
                             strLot_bondingGroupID_GetDR_out.bondingGroupID );
        return RC_LOT_HAS_BONDINGGROUP;
    }
//DSIV00001830 add end

    //---------------------------------------------
    // Check Lot Process State for Parent Lot
    //---------------------------------------------
    objLot_processState_Get_out strLot_processState_Get_out;
    rc = lot_processState_Get(strLot_processState_Get_out, strObjCommonIn, parentLotID); //for parentLotID
    if ( rc )
    {
        PPT_METHODTRACE_V1("", "lot_processState_Get() rc != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_processState_Get_out.strResult;
        return( rc );
    }
    if (CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState, SP_Lot_ProcState_Processing) == 0)
    {
        PPT_METHODTRACE_V1("", "lot_processState_Get() theLotProcessState == SP_Lot_ProcState_Processing");
        PPT_SET_MSG_RC_KEY2(strReworkPartialWaferLotCancelReqResult, MSG_INVALID_LOT_PROCSTAT, RC_INVALID_LOT_PROCSTAT,
                            parentLotID.identifier, strLot_processState_Get_out.theLotProcessState);
        return( RC_INVALID_LOT_PROCSTAT );
    }

    //---------------------------------------------
    // Collect all lot state for Child Lot
    //---------------------------------------------
    objLot_allState_Get_out strLot_allState_Get_out;
    rc = lot_allState_Get(strLot_allState_Get_out, strObjCommonIn, childLotID);
    if ( rc )
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() rc != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_allState_Get_out.strResult;
        return( rc );
    }

    //---------------------------------------------
    // Check Lot Process State for Child Lot
    //---------------------------------------------
    if (CIMFWStrCmp(strLot_allState_Get_out.processState, SP_Lot_ProcState_Processing) == 0)
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() processState == SP_Lot_ProcState_Processing");
        PPT_SET_MSG_RC_KEY2(strReworkPartialWaferLotCancelReqResult, MSG_INVALID_LOT_PROCSTAT, RC_INVALID_LOT_PROCSTAT,
                            childLotID.identifier, strLot_allState_Get_out.processState);
        return( RC_INVALID_LOT_PROCSTAT );
    }
    //---------------------------------------------
    // Check Lot Inventory State for Child Lot
    //---------------------------------------------
    if (CIMFWStrCmp(strLot_allState_Get_out.inventoryState, SP_Lot_InventoryState_OnFloor) != 0)
    {
        PPT_METHODTRACE_V1("", "lot_allState_Get() inventoryState != SP_Lot_InventoryState_OnFloor");
        PPT_SET_MSG_RC_KEY2(strReworkPartialWaferLotCancelReqResult, MSG_INVALID_LOT_INVENTORYSTAT, RC_INVALID_LOT_INVENTORYSTAT,
                            childLotID.identifier, strLot_allState_Get_out.inventoryState);
        return( RC_INVALID_LOT_INVENTORYSTAT );
    }

    //---------------------------------------------
    // Check Rework Cancel can be done or not with Lot Family
    //---------------------------------------------
    objLot_family_CheckReworkCancel_out strLot_family_CheckReworkCancel_out;
    rc = lot_family_CheckReworkCancel(strLot_family_CheckReworkCancel_out, strObjCommonIn, parentLotID, childLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lot_family_CheckReworkCancel() rc != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_family_CheckReworkCancel_out.strResult;
        return( rc );
    }

    //---------------------------------------------
    // Check Lot Merge can be done or not
    //---------------------------------------------
    objProcess_CheckMerge_out strProcess_CheckMerge_out;
    rc = process_CheckMerge(strProcess_CheckMerge_out, strObjCommonIn, parentLotID, childLotID);
    if ( rc != RC_OK &&
         rc != RC_SAME_PRE_OPERATION )
    {
        PPT_METHODTRACE_V1("", "process_CheckMerge() rc != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strProcess_CheckMerge_out.strResult;
        return( rc );
    }

//P3100053//P3100053 add start
//P3100053
//P3100053    CORBA::Long  rcParent = RC_OK;
//P3100053    CORBA::Long  rcChild  = RC_OK;
//P3100053    {
//P3100053        objLot_CheckForLCFR_out  strLot_CheckForLCFR_out;
//P3100053        rcParent = lot_CheckForLCFR( strLot_CheckForLCFR_out, strObjCommonIn, parentLotID, SP_LotCustomize_DBRECORD );
//P3100053
//P3100053        {
//P3100053            objLot_CheckForLCFR_out  strLot_CheckForLCFR_out;
//P3100053            rcChild = lot_CheckForLCFR( strLot_CheckForLCFR_out, strObjCommonIn, childLotID, SP_LotCustomize_DBRECORD );
//P3100053        }
//P3100053
//P3100053    }
//P3100053
//P3100053    if ( ( rcParent == RC_OK) || ( rcChild == RC_OK) )
//P3100053    {
//P3100053        PPT_METHODTRACE_V3("", "(rcParent == RC_OK) || (rcChild == RC_OK)", rcParent, rcChild);
//P3100053
//P3100053        objProcess_CheckMergeForLCFR_out   strProcess_CheckMergeForLCFR_out;
//P3100053        rc = process_CheckMergeForLCFR( strProcess_CheckMergeForLCFR_out, strObjCommonIn, parentLotID, childLotID );
//P3100053        if ( rc != RC_OK )
//P3100053        {
//P3100053            PPT_METHODTRACE_V2("", "process_CheckMergeForLCFR() != RC_OK ", rc);
//P3100053            strReworkPartialWaferLotCancelReqResult.strResult = strProcess_CheckMergeForLCFR_out.strResult;
//P3100053            return( rc );
//P3100053        }
//P3100053    }
//P3100053    else
//P3100053    {
//P3100053        PPT_METHODTRACE_V3("", "*** !( (rcParent == RC_OK) || (rcChild == RC_OK) )", rcParent, rcChild);
//P3100053    }
//P3100053
//P3100053//P3100053 add end

    //---------------------------------------------
    // Check Lot Hold List for Rework Cancel
    //---------------------------------------------
    objLot_holdList_CheckReworkCancel_out strLot_holdList_CheckReworkCancel_out;
    rc = lot_holdList_CheckReworkCancel(strLot_holdList_CheckReworkCancel_out, strObjCommonIn, parentLotID, childLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lot_holdList_CheckReworkCancel() rc != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_holdList_CheckReworkCancel_out.strResult;
        return( rc );
    }

    //---------------------------------------------
    // Check Lot Future Hold for Lot Merge
    //---------------------------------------------
    objLot_futureHoldRequests_CheckMerge_out strLot_futureHoldRequests_CheckMerge_out;
    rc = lot_futureHoldRequests_CheckMerge(strLot_futureHoldRequests_CheckMerge_out, strObjCommonIn, childLotID, parentLotID);
    if ( rc )
    {
        PPT_METHODTRACE_V1("", "lot_futureHoldRequests_CheckMerge() rc != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_futureHoldRequests_CheckMerge_out.strResult;
        return( rc );
    }

    objectIdentifier aReasonCodeID;
    aReasonCodeID.identifier = CIMFWStrDup( SP_Reason_Merge );

    if (strLot_futureHoldRequests_CheckMerge_out.strHoldReqList.length() > 0 )
    {
        PPT_METHODTRACE_V1("", "strLot_futureHoldRequests_CheckMerge_out.strHoldReqList.length() > 0");
        //---------------------------------------------
        // Cancel Future Hold Registration of Child Lot
        //---------------------------------------------

        pptFutureHoldCancelReqResult strFutureHoldCancelReqResult;
        rc = txFutureHoldCancelReq(strFutureHoldCancelReqResult, strObjCommonIn,
                                   childLotID, aReasonCodeID, SP_EntryType_Remove,
                                   strLot_futureHoldRequests_CheckMerge_out.strHoldReqList);
            // Input parameters
            //  - lotID = childLotID
            //  - releaseReasonCodeID = aReasonCodeID
            //  - entryType = SP_EntryType_Remove
            //  - strFutureHoldCancelReqList = strLot_futureHoldRequests_CheckMerge_out.strHoldReqList
        if ( rc )
        {
            PPT_METHODTRACE_V1("", "txFutureHoldCancelReq() rc != RC_OK");
            strReworkPartialWaferLotCancelReqResult.strResult = strFutureHoldCancelReqResult.strResult;
            return( rc );
        }

        //---------------------------------------------
        // Prepare data for Parent Lot
        //---------------------------------------------
        strLot_futureHoldRequests_CheckMerge_out.strHoldReqList[0].relatedLotID = childLotID;  // set child lot id as relatedLotID;

//D6000259        //---------------------------------------------
//D6000259        // If Parent Lot is held, Cancel Lot Hold of Parent Lot
//D6000259        // If Parent Lot has
//D6000259        //---------------------------------------------
//D6000259        objLot_holdState_Get_out strLot_holdState_Get_out;
//D6000259        rc = lot_holdState_Get(strLot_holdState_Get_out, strObjCommonIn, parentLotID);   // for Parent Lot
//D6000259        if ( rc )
//D6000259        {
//D6000259            PPT_METHODTRACE_V1("", "lot_holdState_Get() rc != RC_OK");
//D6000259            strReworkPartialWaferLotCancelReqResult.strResult = strLot_holdState_Get_out.strResult;
//D6000259            return( rc );
//D6000259        }
        //D6000259 Add Start
        //-------------------------------------------------------
        // Get Parent Lot's Hold Rocords
        //-------------------------------------------------------
        pptHoldListSequence  strReleaseList;
        pptHoldListSequence  strCancelList;

        objLot_FillInTxTRQ005DR_out  strLot_FillInTxTRQ005DR_out;
        rc = lot_FillInTxTRQ005DR( strLot_FillInTxTRQ005DR_out, strObjCommonIn, parentLotID );
        if( rc != RC_OK && rc != RC_NOT_FOUND_ENTRY )
        {
            PPT_METHODTRACE_V1("", "lot_FillInTxTRQ005DR() != RC_OK");

            strReworkPartialWaferLotCancelReqResult.strResult = strLot_FillInTxTRQ005DR_out.strResult;
            return rc;
        }
        else if( rc == RC_OK )
        {
            //-------------------------------------------------------
            // Sort out Parent Lot's Hold Record
            //-------------------------------------------------------
            PPT_METHODTRACE_V1("", "Parent Lot has some Hold Records. The one by Merge/Rework Hold Request is sorted out.");

            CORBA::Long  requestLen = strLot_futureHoldRequests_CheckMerge_out.strHoldReqList.length();
            CORBA::Long  recordLen  = strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes.length();
            CORBA::Long  releaseCnt = 0;
            CORBA::Long  cancelCnt  = 0;

            strReleaseList.length( requestLen );
            strCancelList.length( requestLen );

            for( CORBA::Long  requestCnt = 0; requestCnt < requestLen; requestCnt++ )
            {
                CORBA::Boolean  foundRecord = FALSE;

                PPT_METHODTRACE_V5("", requestCnt,                                                                                     //P6000592
                                   strLot_futureHoldRequests_CheckMerge_out.strHoldReqList[requestCnt].holdType,                       //P6000592
                                   strLot_futureHoldRequests_CheckMerge_out.strHoldReqList[requestCnt].holdReasonCodeID.identifier,    //P6000592
                                   strLot_futureHoldRequests_CheckMerge_out.strHoldReqList[requestCnt].holdUserID.identifier,          //P6000592
                                   strLot_futureHoldRequests_CheckMerge_out.strHoldReqList[requestCnt].relatedLotID.identifier);       //P6000592

                for( CORBA::Long  recordCnt = 0; recordCnt < recordLen; recordCnt++ )
                {
                    if( CIMFWStrCmp( strLot_futureHoldRequests_CheckMerge_out.strHoldReqList[requestCnt].holdType,
                                     strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes[recordCnt].holdType                         ) == 0 &&
                        CIMFWStrCmp( strLot_futureHoldRequests_CheckMerge_out.strHoldReqList[requestCnt].holdReasonCodeID.identifier,
                                     strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes[recordCnt].reasonCodeID.identifier          ) == 0 &&
                        CIMFWStrCmp( strLot_futureHoldRequests_CheckMerge_out.strHoldReqList[requestCnt].holdUserID.identifier,
                                     strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes[recordCnt].userID.identifier                ) == 0 &&
                        CIMFWStrCmp( strLot_futureHoldRequests_CheckMerge_out.strHoldReqList[requestCnt].relatedLotID.identifier,
                                     strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes[recordCnt].relatedLotID.identifier          ) == 0   )
                    {
                        foundRecord = TRUE;
                        break;
                    }
                }

                if( foundRecord == TRUE )
                {
                    PPT_METHODTRACE_V1("", "Hold Record by Merge/Rework Hold Request is found.");                                      //P6000592
                    strReleaseList[releaseCnt++] = strLot_futureHoldRequests_CheckMerge_out.strHoldReqList[requestCnt];                //P6000592
//P6000592                    PPT_METHODTRACE_V2("", "Hold Record by Merge/Rework Hold Request is found.", requestCnt);
//P6000592                    strReleaseList[releaseCnt] = strLot_futureHoldRequests_CheckMerge_out.strHoldReqList[requestCnt];
//P6000592                    PPT_METHODTRACE_V5("", releaseCnt, strReleaseList[releaseCnt].holdType, strReleaseList[releaseCnt].holdReasonCodeID.identifier,
//P6000592                                           strReleaseList[releaseCnt].holdUserID.identifier, strReleaseList[releaseCnt++].relatedLotID.identifier);
                }
                else
                {
                    PPT_METHODTRACE_V1("", "Hold Record by Merge/Rework Hold Request is not found.");                                  //P6000592
                    strCancelList[cancelCnt++] = strLot_futureHoldRequests_CheckMerge_out.strHoldReqList[requestCnt];                  //P6000592
//P6000592                    PPT_METHODTRACE_V2("", "Hold Record by Merge/Rework Hold Request is not found.", requestCnt);
//P6000592                    strCancelList[cancelCnt] = strLot_futureHoldRequests_CheckMerge_out.strHoldReqList[requestCnt];
//P6000592                    PPT_METHODTRACE_V5("", cancelCnt, strCancelList[cancelCnt].holdType, strCancelList[cancelCnt].holdReasonCodeID.identifier,
//P6000592                                           strCancelList[cancelCnt].holdUserID.identifier, strCancelList[cancelCnt++].relatedLotID.identifier);
                }
            }
            strReleaseList.length( releaseCnt );
            strCancelList.length( cancelCnt );
        }
        else
        {
            PPT_METHODTRACE_V1("", "Parent Lot has no Hold Record.");

            strReleaseList.length( 0 );
            strCancelList = strLot_futureHoldRequests_CheckMerge_out.strHoldReqList;
        }
        //D6000259 Add End

        //---------------------------------------------
        // If Parent Lot is held by ReworkMerge reason,
        // Cancel Lot Hold of Parent Lot
        //---------------------------------------------
//D6000259        if (CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState, CIMFW_Lot_HoldState_OnHold) == 0)
        if( strReleaseList.length() > 0 )                                                            //D6000259
        {
//D6000259            PPT_METHODTRACE_V1("", "lotHoldState == CIMFW_Lot_HoldState_OnHold");
            PPT_METHODTRACE_V1("", "Hold Records of Merge/Rework Hold Requests are released.");      //D6000259

            pptHoldLotReleaseReqResult strHoldLotReleaseReqResult;
            rc = txHoldLotReleaseReq(strHoldLotReleaseReqResult, strObjCommonIn,
                                     parentLotID, aReasonCodeID, /* SP_EntryType_Remove, */
                                     strReleaseList );                                               //D6000259
//D6000259                                     strLot_futureHoldRequests_CheckMerge_out.strHoldReqList);
                // Input parameters
                //  - lotID = parentLotID
                //  - releaseReasonCodeID = aReasonCodeID
                //  - strLotHoldReqList = strReleaseList                                             //D6000259
//D6000259                //  - entryType = SP_EntryType_Remove
//D6000259                //  - strFutureHoldCancelReqList = strLot_futureHoldRequests_CheckMerge_out.strHoldReqList
            if ( rc )
            {
                PPT_METHODTRACE_V1("", "txHoldLotReleaseReq() rc != RC_OK");
                strReworkPartialWaferLotCancelReqResult.strResult = strHoldLotReleaseReqResult.strResult;
                return( rc );
            }
        }

        //---------------------------------------------
        // If lot has future hold registration for rework Merge
        // Cancel Future Hold registration of Parent Lot
        //---------------------------------------------
//D6000259        if (CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState, CIMFW_Lot_HoldState_NotOnHold) == 0)
        if( strCancelList.length() > 0 )                                                             //D6000259
        {
//D6000259            PPT_METHODTRACE_V1("", "lotHoldState == CIMFW_Lot_HoldState_NotOnHold");
            PPT_METHODTRACE_V1("", "Merge/Rework Hold Requests are cancelled.");                     //D6000259

            pptFutureHoldCancelReqResult strFutureHoldCancelReqResult;
            rc = txFutureHoldCancelReq(strFutureHoldCancelReqResult, strObjCommonIn,
                                       parentLotID, aReasonCodeID, SP_EntryType_Remove,
                                       strCancelList );                                              //D6000259
//D6000259                                       strLot_futureHoldRequests_CheckMerge_out.strHoldReqList);
                // Input parameters
                //  - lotID = parentLotID
                //  - releaseReasonCodeID = aReasonCodeID
                //  - entryType = SP_EntryType_Remove
                //  - strFutureHoldCancelReqList = strCancelList                                     //D6000259
//D6000259                //  - strFutureHoldCancelReqList = strLot_futureHoldRequests_CheckMerge_out.strHoldReqList
            if ( rc )
            {
                PPT_METHODTRACE_V1("", "txFutureHoldCancelReq() rc != RC_OK");
                strReworkPartialWaferLotCancelReqResult.strResult = strFutureHoldCancelReqResult.strResult;
                return( rc );
            }
        }
    }

//D4100036 start
    /*-------------------------------*/
    /*   Check FlowBatch Condition   */
    /*-------------------------------*/

    // for parentLot
    PPT_METHODTRACE_V1("", "Check FlowBatch Condition  [ParentLot]") ;
    objLot_flowBatchID_Get_out strLot_flowBatchID_Get_out;
    rc = lot_flowBatchID_Get( strLot_flowBatchID_Get_out, strObjCommonIn, parentLotID );

    if ( rc == RC_LOT_FLOW_BATCH_ID_FILLED )
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() == RC_LOT_BATCH_ID_BLANK") ;
//P5000145        PPT_SET_MSG_RC_KEY( strReworkPartialWaferLotCancelReqResult, MSG_FLOW_BATCH_LIMITATION, RC_FLOW_BATCH_LIMITATION, "");
        SET_MSG_RC( strReworkPartialWaferLotCancelReqResult, MSG_FLOW_BATCH_LIMITATION, RC_FLOW_BATCH_LIMITATION );        //P5000145
        return RC_FLOW_BATCH_LIMITATION;
    }
    else if ( rc == RC_LOT_FLOW_BATCH_ID_BLANK )
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() == RC_LOT_BATCH_ID_BLANK") ;
    }
    else
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() != RC_OK") ;
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_flowBatchID_Get_out.strResult ;
        return( rc );
    }

    // for childLot
    PPT_METHODTRACE_V1("", "Check FlowBatch Condition  [Child]") ;
    rc = lot_flowBatchID_Get( strLot_flowBatchID_Get_out, strObjCommonIn, childLotID );

    if ( rc == RC_LOT_FLOW_BATCH_ID_FILLED )
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() == RC_LOT_BATCH_ID_BLANK") ;
//P5000145        PPT_SET_MSG_RC_KEY( strReworkPartialWaferLotCancelReqResult, MSG_FLOW_BATCH_LIMITATION, RC_FLOW_BATCH_LIMITATION, "");
        SET_MSG_RC( strReworkPartialWaferLotCancelReqResult, MSG_FLOW_BATCH_LIMITATION, RC_FLOW_BATCH_LIMITATION );        //P5000145
        return RC_FLOW_BATCH_LIMITATION;
    }
    else if ( rc == RC_LOT_FLOW_BATCH_ID_BLANK )
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() == RC_LOT_BATCH_ID_BLANK") ;
    }
    else
    {
        PPT_METHODTRACE_V1("", "lot_flowBatchID_Get() != RC_OK") ;
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_flowBatchID_Get_out.strResult ;
        return( rc );
    }
//D4100036 end

//Q3000147 add start
    /*----------------------------------*/
    /*   Check Lot's Control Job ID     */
    /*----------------------------------*/

    // for parentLot
    objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, parentLotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_controlJobID_Get() != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_controlJobID_Get_out.strResult;
        return(rc);
    }
    if (CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) == 0)
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) = 0");
        rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) > 0");
        PPT_SET_MSG_RC_KEY2( strReworkPartialWaferLotCancelReqResult,
                             MSG_LOT_CTLJOBID_FILLED,
                             RC_LOT_CTLJOBID_FILLED,
                             parentLotID.identifier,
                             strLot_controlJobID_Get_out.controlJobID.identifier );
        return( RC_LOT_CTLJOBID_FILLED );
    }

    // for childLot
    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, childLotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_controlJobID_Get() != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_controlJobID_Get_out.strResult;
        return(rc);
    }
    if (CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) == 0)
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) = 0");
        rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) > 0");
        PPT_SET_MSG_RC_KEY2( strReworkPartialWaferLotCancelReqResult,
                             MSG_LOT_CTLJOBID_FILLED,
                             RC_LOT_CTLJOBID_FILLED,
                             childLotID.identifier,
                             strLot_controlJobID_Get_out.controlJobID.identifier );
        return( RC_LOT_CTLJOBID_FILLED );
    }
//Q3000147 add end

//DSN000071674 add start
    if ( 1 == lotOperationEIcheck )
    {
        PPT_METHODTRACE_V1("", "lotOperationEIcheck = 1");
//DSN000071674 add end
//P7000058 add start
        //-------------------------------
        // Check carrier dispatch status
        //-------------------------------
        objCassette_dispatchState_Get_out strCassette_dispatchState_Get_out;
        strCassette_dispatchState_Get_out.dispatchReservedFlag = FALSE;
        rc = cassette_dispatchState_Get(strCassette_dispatchState_Get_out, strObjCommonIn,
                                        strLot_cassette_Get_out.cassetteID);
        if (strCassette_dispatchState_Get_out.dispatchReservedFlag == TRUE)
        {
            PPT_METHODTRACE_V1("", "cassette_dispatchState_Get() dispatchReservedFlag == TRUE");
            strReworkPartialWaferLotCancelReqResult.strResult = strCassette_dispatchState_Get_out.strResult ;
            SET_MSG_RC(strReworkPartialWaferLotCancelReqResult,
                       MSG_ALREADY_DISPATCH_RESVED_CST, RC_ALREADY_DISPATCH_RESVED_CST);
            return( RC_ALREADY_DISPATCH_RESVED_CST );
        }
//P7000058 add end
    } //DSN000071674

    //---------------------------------------------
    // Collecte Child Lot Wafers
    //---------------------------------------------
    objLot_waferMap_Get_out strLot_waferMap_Get_out;
    rc = lot_waferMap_Get(strLot_waferMap_Get_out, strObjCommonIn, childLotID);     // for child lot
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lot_waferMap_Get() rc != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_waferMap_Get_out.strResult;
        return( rc );
    }

    pptNewLotAttributes strNewLotAttributes;    // This structure is used when creating History Data
    CORBA::Long i = 0;
    CORBA::Long nLen = strLot_waferMap_Get_out.strLotWaferMap.length();
    strNewLotAttributes.strNewWaferAttributes.length(nLen);
    PPT_METHODTRACE_V2("", "nLen", nLen);
    for (i=0; i<nLen; i++)
    {
        strNewLotAttributes.strNewWaferAttributes[i].newLotID      = parentLotID;
        strNewLotAttributes.strNewWaferAttributes[i].newWaferID    = strLot_waferMap_Get_out.strLotWaferMap[i].waferID;
        strNewLotAttributes.strNewWaferAttributes[i].newSlotNumber = strLot_waferMap_Get_out.strLotWaferMap[i].slotNumber;
        strNewLotAttributes.strNewWaferAttributes[i].sourceLotID   = childLotID;
        strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID = strLot_waferMap_Get_out.strLotWaferMap[i].waferID;
    }

    /*------------------------------------------------------------------------*/
    /*   Make History 1                                                       */
    /*------------------------------------------------------------------------*/
    objLot_waferLotHistoryPointer_Update_out strLot_waferLotHistoryPointer_Update_out;
    rc = lot_waferLotHistoryPointer_Update(strLot_waferLotHistoryPointer_Update_out, strObjCommonIn, parentLotID);   //for Parent Lot
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lot_waferLotHistoryPointer_Update() rc != RC_OK");
//P3000139        strReworkPartialWaferLotCancelReqResult.strResult = strLot_waferLotHistoryPointer_Update_out.strResult; //P3000139
        SET_MSG_RC(strReworkPartialWaferLotCancelReqResult, MSG_FAIL_MAKE_HISTORY, rc);
        return( rc );
    }

    objLotPartialReworkCancelEvent_Make_out strLotPartialReworkCancelEvent_Make_out;
    rc = lotPartialReworkCancelEvent_Make(strLotPartialReworkCancelEvent_Make_out, strObjCommonIn,
                                          "TXTRC029", childLotID, parentLotID, reasonCodeID, claimMemo);
        // Transaction ID : "TXTRC029"
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lotPartialReworkCancelEvent_Make() rc != RC_OK");
//P3000139        strReworkPartialWaferLotCancelReqResult.strResult = strLotPartialReworkCancelEvent_Make_out.strResult;   //P3000139
        SET_MSG_RC(strReworkPartialWaferLotCancelReqResult, MSG_FAIL_MAKE_HISTORY, rc);
        return( rc );
    }

//D4100120 Add Start
    /*-----------------------------------*/
    /*   Check Future Action Procedure   */
    /*-----------------------------------*/
    objSchdlChangeReservation_CheckForMerge_out strSchdlChangeReservation_CheckForMerge_out;
    rc = schdlChangeReservation_CheckForMerge(strSchdlChangeReservation_CheckForMerge_out,
                                              strObjCommonIn,
                                              parentLotID,
                                              childLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "schdlChangeReservation_CheckForMerge() != RC_OK") ;
        strReworkPartialWaferLotCancelReqResult.strResult = strSchdlChangeReservation_CheckForMerge_out.strResult;
        return(rc);
    }
//D4100120 Add End

//DSN000085792 Add Start
    /*-----------------------------------------------------------*/
    /* Roll back Target Operation for rework route               */
    /*-----------------------------------------------------------*/
    objQTime_targetOpe_cancelReplace_out strQTime_targetOpe_cancelReplace_out;
    objQTime_targetOpe_cancelReplace_in  strQTime_targetOpe_cancelReplace_in;
    strQTime_targetOpe_cancelReplace_in.lotID = childLotID;
    rc = qTime_targetOpe_cancelReplace( strQTime_targetOpe_cancelReplace_out,
                                        strObjCommonIn,
                                        strQTime_targetOpe_cancelReplace_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "qTime_targetOpe_cancelReplace() != RC_OK", rc);
        strReworkPartialWaferLotCancelReqResult.strResult = strQTime_targetOpe_cancelReplace_out.strResult;
        return rc;
    }
//DSN000085792 Add End

//DSN000033655 Add Start
    /*----------------------------------------*/
    /*   Check Q-Time information condition   */
    /*----------------------------------------*/
    objQTime_CheckForMerge_out strQTime_CheckForMerge_out;
    objQTime_CheckForMerge_in  strQTime_CheckForMerge_in;
    strQTime_CheckForMerge_in.parentLotID = parentLotID;
    strQTime_CheckForMerge_in.childLotID  = childLotID;
    rc = qTime_CheckForMerge(strQTime_CheckForMerge_out,
                             strObjCommonIn,
                             strQTime_CheckForMerge_in);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "qTime_CheckForMerge() != RC_OK") ;
        strReworkPartialWaferLotCancelReqResult.strResult = strQTime_CheckForMerge_out.strResult;
        return(rc);
    }
//DSN000033655 Add End

//D7000012 move from the lower part start
    //-----------------------------------------------------------------
    // Decrement Rework Count of Child Lot before they are merged.
    //-----------------------------------------------------------------
    objProcess_reworkCount_Decrement_out strProcess_reworkCount_Decrement_out;
    rc = process_reworkCount_Decrement(strProcess_reworkCount_Decrement_out, strObjCommonIn, childLotID); // for ChildLot
    if (rc)
    {
        PPT_METHODTRACE_V1("", "process_reworkCount_Decrement() rc != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strProcess_reworkCount_Decrement_out.strResult;
        return( rc );
    }
//D7000012 move from the lower part end

//P8000005 Add Start
    //--------------------------------------------------
    // Remove the child lot from monitor groups
    //--------------------------------------------------
    objLot_RemoveFromMonitorGroup_out  strLot_RemoveFromMonitorGroup_out;
    rc = lot_RemoveFromMonitorGroup( strLot_RemoveFromMonitorGroup_out, strObjCommonIn, childLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_RemoveFromMonitorGroup() != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_RemoveFromMonitorGroup_out.strResult;
        return rc;
    }
//P8000005 Add End

//P5100032 add start
    /*------------------------------------------------------------------------*/
    /*   Change ChildLot State                                                */
    /*------------------------------------------------------------------------*/
    objProcess_CancelBranchRoute_out strProcess_CancelBranchRoute_out ;
    rc = process_CancelBranchRoute( strProcess_CancelBranchRoute_out,strObjCommonIn,childLotID) ;
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "process_CancelBranchRoute() != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strProcess_CancelBranchRoute_out.strResult ;
        return (rc) ;
    }

//D7000012  move to the upper part start
//D7000012    //-----------------------------------------------------------------
//D7000012    // Decrement Rework Count of Child Lot before they are merged.
//D7000012    //-----------------------------------------------------------------
//D7000012    objProcess_reworkCount_Decrement_out strProcess_reworkCount_Decrement_out;
//D7000012    rc = process_reworkCount_Decrement(strProcess_reworkCount_Decrement_out, strObjCommonIn, childLotID); // for ChildLot
//D7000012    if (rc)
//D7000012    {
//D7000012        PPT_METHODTRACE_V1("", "process_reworkCount_Decrement() rc != RC_OK");
//D7000012        strReworkPartialWaferLotCancelReqResult.strResult = strProcess_reworkCount_Decrement_out.strResult;
//D7000012        return( rc );
//D7000012    }
//D7000012  move to the upper part end
//P5100032 add end

    //---------------------------------------------
    // Merge Child Lot to Parent Lot
    //---------------------------------------------
    objLot_MergeWaferLot_out strLot_MergeWaferLot_out;
    rc = lot_MergeWaferLot(strLot_MergeWaferLot_out, strObjCommonIn, parentLotID, childLotID);
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lot_MergeWaferLot() rc != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strLot_MergeWaferLot_out.strResult;
        return( rc );
    }

//D4100069    objLot_CheckForLCFR_out  strLot_CheckForLCFR_out;                                                       //P3100051
//D4100069    rc = lot_CheckForLCFR( strLot_CheckForLCFR_out, strObjCommonIn, childLotID, SP_LotCustomize_DBRECORD ); //P3100051
//D4100069    if ( rc == RC_OK)                                                                                       //P3100051
//D4100069    {                                                                                                       //P3100051
//D4100069        PPT_METHODTRACE_V1("", "lot_CheckForLCFR() == RC_OK");
//D4100069        objLot_MergeWaferLotForLCFR_out  strLot_MergeWaferLotForLCFR_out;                                   //P3100051
//D4100069        rc = lot_MergeWaferLotForLCFR( strLot_MergeWaferLotForLCFR_out, strObjCommonIn, childLotID );       //P3100051
//D4100069        if ( rc != RC_OK)                                                                                   //P3100051
//D4100069        {                                                                                                   //P3100051
//D4100069            PPT_METHODTRACE_V1("", "lot_MergeWaferLotForLCFR() != RC_OK");
//D4100069            strReworkPartialWaferLotCancelReqResult.strResult =                                             //P3100051
//D4100069                                       strLot_MergeWaferLotForLCFR_out.strResult;                           //P3100051
//D4100069            return(rc);                                                                                     //P3100051
//D4100069        }                                                                                                   //P3100051
//D4100069    }                                                                                                       //P3100051

//D5000023    //---------------------------------------------
//D5000023    // Decrement Rework Count of Parent Lot
//D5000023    //---------------------------------------------
//P5100032    objProcess_reworkCount_Decrement_out strProcess_reworkCount_Decrement_out;
//D5000023    rc = process_reworkCount_Decrement(strProcess_reworkCount_Decrement_out, strObjCommonIn, parentLotID); // for parentLotID
//D5000023    if (rc)
//D5000023    {
//D5000023        PPT_METHODTRACE_V1("", "process_reworkCount_Decrement() rc != RC_OK");
//D5000023        strReworkPartialWaferLotCancelReqResult.strResult = strProcess_reworkCount_Decrement_out.strResult;
//D5000023        return( rc );
//D5000023    }

//DSN000033655 Add Start
    /*----------------------------------------*/
    /*   Merge Q-Time information             */
    /*----------------------------------------*/
    objQTime_infoMerge_out strQTime_infoMerge_out;
    objQTime_infoMerge_in  strQTime_infoMerge_in;
    strQTime_infoMerge_in.parentLotID = parentLotID;
    strQTime_infoMerge_in.childLotID  = childLotID;
    rc = qTime_infoMerge(strQTime_infoMerge_out,
                         strObjCommonIn,
                         strQTime_infoMerge_in);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "qTime_infoMerge() != RC_OK") ;
        strReworkPartialWaferLotCancelReqResult.strResult = strQTime_infoMerge_out.strResult;
        return(rc);
    }
//DSN000033655 Add End

//DSN000071674 add start
    if ( TRUE == updateControlJobFlag )
    {
        //----------------------
        // Update control Job Info and
        // Machine Cassette info if information exist
        //----------------------
        objectIdentifierSequence tmpCassetteIDSeq;
        tmpCassetteIDSeq.length(1);
        tmpCassetteIDSeq[0] = strLot_cassette_Get_out.cassetteID;
        objControlJob_relatedInfo_Update_out strControlJob_relatedInfo_Update_out;
        rc = controlJob_relatedInfo_Update(strControlJob_relatedInfo_Update_out, strObjCommonIn,
                                           tmpCassetteIDSeq);
        if (rc)
        {
            PPT_METHODTRACE_V2("", "controlJob_relatedInfo_Update() != RC_OK", rc);
            strReworkPartialWaferLotCancelReqResult.strResult = strControlJob_relatedInfo_Update_out.strResult;
            return(rc);
        }
    }
//DSN000071674 add end

    //----------------------
    // Update cassette multi lot type
    //----------------------
//P7000058    objLot_cassette_Get_out strLot_cassette_Get_out;
//P7000058    rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, parentLotID); // for Parent Lot
//P7000058    if (rc)
//P7000058    {
//P7000058        PPT_METHODTRACE_V1("", "lot_cassette_Get() rc != RC_OK");
//P7000058        strReworkPartialWaferLotCancelReqResult.strResult = strLot_cassette_Get_out.strResult;
//P7000058        return( rc );
//P7000058    }

    objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
    rc = cassette_multiLotType_Update(strCassette_multiLotType_Update_out, strObjCommonIn,
                                      strLot_cassette_Get_out.cassetteID);  // use returned cassetteID from lot_cassette_Get()
    if (rc)
    {
        PPT_METHODTRACE_V1("", "cassette_multiLotType_Update() rc != RC_OK");
        strReworkPartialWaferLotCancelReqResult.strResult = strCassette_multiLotType_Update_out.strResult;
        return( rc );
    }

    //---------------------------------------------------
    //   Make History 2
    //---------------------------------------------------
    objLotWaferMoveEvent_Make_out strLotWaferMoveEvent_Make_out;
    rc = lotWaferMoveEvent_Make(strLotWaferMoveEvent_Make_out, strObjCommonIn,
                                "TXTRC029", strNewLotAttributes, claimMemo);
        // Transaction ID : "TXTRC029"
    if (rc)
    {
        PPT_METHODTRACE_V1("", "lotWaferMoveEvent_Make() rc != RC_OK");
//P3000139        strReworkPartialWaferLotCancelReqResult.strResult = strLotWaferMoveEvent_Make_out.strResult;   //P3000139
        SET_MSG_RC(strReworkPartialWaferLotCancelReqResult, MSG_FAIL_MAKE_HISTORY, rc);
        return( rc );
    }

//DSN000085791 add start
    //-- Entity Inhibit Exception Lot Data --//
    // Get Entity Inhibition Info
    PosEntityInhibitSequence_var aEntityInhibitSeq = theEntityInhibitManager->getEntityInhibitsWithExceptionLotByLot(childLotID);
    CORBA::ULong numOfInhibit = aEntityInhibitSeq->length();
    PPT_METHODTRACE_V2( "", "numOfInhibit", numOfInhibit );

    // Make Exception Lot Cancel Data
    if( numOfInhibit > 0 )
    {
        pptEntityInhibitExceptionLotCancelReqInParm cancelReqData;
        cancelReqData.strEntityInhibitExceptionLots.length(numOfInhibit);

        for( CORBA::ULong nInhibit = 0; nInhibit < numOfInhibit; nInhibit++ )
        {
            posEntityInhibitRecord_var entityInhibitRecord = (*aEntityInhibitSeq)[nInhibit]->getInhibitRecord();
            
            cancelReqData.strEntityInhibitExceptionLots[nInhibit].entityInhibitID.identifier                 = CIMFWStrDup(entityInhibitRecord->identifier);
            cancelReqData.strEntityInhibitExceptionLots[nInhibit].entityInhibitID.stringifiedObjectReference = CIMFWStrDup(entityInhibitRecord->stringifiedObjectReference);
            cancelReqData.strEntityInhibitExceptionLots[nInhibit].lotID = childLotID;
        }

        PPT_METHODTRACE_V1("", "call txEntityInhibitExceptionLotCancelReq");
        CORBA::String_var claimMemo = CIMFWStrDup("Delete for ReworkPartialWaferLotCancel");
        pptEntityInhibitExceptionLotCancelReqResult strExceptionLotCancelReqResult;
        rc = txEntityInhibitExceptionLotCancelReq(strExceptionLotCancelReqResult, strObjCommonIn, cancelReqData, claimMemo);
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "txEntityInhibitExceptionLotCancelReq() != RC_OK");
            strReworkPartialWaferLotCancelReqResult.strResult = strExceptionLotCancelReqResult.strResult;
            return( rc );
        }
    }
//DSN000085791 add end

    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
    SET_MSG_RC(strReworkPartialWaferLotCancelReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("PPTManager_i:: txReworkPartialWaferLotCancelReq ");
    return RC_OK;
}
