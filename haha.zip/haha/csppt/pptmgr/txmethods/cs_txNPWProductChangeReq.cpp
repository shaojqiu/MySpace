// @(#) 1.4 superpos/src/csppt/source/posppt/pptmgr/txmethods/cs_txTestFunction.cpp, mm_srv_5_0_cspp, mm_srv_5_0_cspp 6/9/03 14:16:50 [ 6/9/03 14:16:52 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_txNPWProductChangeReq.cpp
#include "cs_pptmgr.hpp"
// INNOTRON Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/19 INN-R170027  Vera Chen      NPW Product Change
// Description:
//
// Return:
//     long
//
// Parameter:
//
// Require:
// 
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_txNPWProductChangeReq (
    csNPWProductChangeReqResult&                    strNPWProductChangeReqResult,
    const pptObjCommonIn&                           strObjCommonIn,
    const csNPWProductChangeReqInParm&              strNPWProductChangeReqInParm,
    const char*                                     claimMemo
    CORBAENV_LAST_CPP )
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: cs_txNPWProductChangeReq") ;
    /*
    PPT_METHODTRACE_V2("", "in para functionName ", functionName);
    PPT_METHODTRACE_V2("", "in para lotID        ", lotID.identifier);
    PPT_METHODTRACE_V2("", "in para equipmentID  ", equipmentID.identifier );
    //INN-R170009 add start
    PPT_METHODTRACE_V2("", "in para routeID      ", routeID.identifier );
    PPT_METHODTRACE_V2("", "in para operationNumber", operationNumber );   
    //INN-R170009 add end	
    PPT_METHODTRACE_V2("", "in para userID       ", strObjCommonIn.strUser.userID.identifier);

    //--------------
    // Initialize
    //--------------
    CORBA::Long rc = RC_OK;

    //--------------------------------------------------------------
    // Test Function
    //-------------------------------------------------------------
	//INN-R170009 objTestFunction_Obj_out strTestFunction_Obj_out;
    //INN-R170009 add start
    csObjAPC_LithoAvailable_CheckCondition_out     strAPC_LithoAvailable_CheckCondition_out;
    csObjAPC_LithoAvailable_CheckCondition_in      strAPC_LithoAvailable_CheckCondition_in;
    strAPC_LithoAvailable_CheckCondition_in.routeID = routeID;
    strAPC_LithoAvailable_CheckCondition_in.operationNumber = operationNumber;
    strAPC_LithoAvailable_CheckCondition_in.equipmentID = equipmentID;
	rc = cs_APC_LithoAvailable_CheckCondition( strAPC_LithoAvailable_CheckCondition_out, strObjCommonIn, strAPC_LithoAvailable_CheckCondition_in );

	//------------------------------------------------------
    // When Error Occures.
    //------------------------------------------------------
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","cs_testFunction() returned error");
        strTestFunctionResult.strResult = strAPC_LithoAvailable_CheckCondition_out.strResult ;
        return(rc); 
    }
    
    //------------------------------------------------------
    // Set Object returned value to Tx Value
    //------------------------------------------------------
    strTestFunctionResult.infos.length(1);
	strTestFunctionResult.infos[0].inquireType           = strAPC_LithoAvailable_CheckCondition_out.inquireType;
	strTestFunctionResult.infos[0].recommendFlag = strAPC_LithoAvailable_CheckCondition_out.recommendFlag;
	strTestFunctionResult.infos[0].usedFlag      = strAPC_LithoAvailable_CheckCondition_out.usedFlag;
	strTestFunctionResult.infos[0].metrologyFlag      = strAPC_LithoAvailable_CheckCondition_out.metrologyFlag;
    //INN-R170009 add end
    //----------
    //   Return
    //----------
    SET_MSG_RC(strTestFunctionResult, MSG_OK, RC_OK);
    */
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: cs_txNPWProductChangeReq") ;
    return(RC_OK);
}
