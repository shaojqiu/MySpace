#ifndef lint
static char *sccsid =  "@(#) 1.2 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txSubRouteBranchCancelReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 8/3/07 16:24:31 [ 8/3/07 16:24:32 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txSubRouteBranchCancelReqOR.cpp
//

#include "cs_pptmgr.hpp"
#include "penin.hh"
extern char* makeInhibitListFromEntityInhibits(const PosEntityInhibitSequence* entityInhibits);

// Class: CS_PPTManager
//
// Service: txSubRouteBranchCancelReq()
//
// Change history:
// Date       Defect#    Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/08          S.Kawabe       Initial Release (R30)
// 2000/09/26 Q3000147 K.Matsuei      Add Check Lot's Control Job ID
// 2001-01-12 D3000118 M.Shimizu      Lot Customization and Flexible Rework
// 2001-01-12 D3000119 M.Shimizu      Lot Customization and Flexible Rework
// 2001-02-16 P3100014 K.Muguruma     LC:Bug Fix of SubRouteBranchCancel
// 2001-02-27 P3100057 K.Muguruma     LC:Bug Fix (add lot_CheckForLCFR())
// 2001-03-15 P3100043 M.Shimizu      LC:extendedOperationNumber for LC-subRoute
// 2001-03-21 P3100121 M.SHimizu      LC:Can't Cancel Branch from Flexible Rework Route.
// 2001-04-10 P3100256 K.Matsuei      BranchCancel should not be allowed for Rework Lot.
// 2001-04-13 P3100279 K.Muguruma     LC:bug fix and code refinement
// 2001/07/12 D4000016 M.Shimizu      Contamination Control(Copper/Non Copper [R40 Core])
// 2002/01/15 D4100069 C.Tsuchiya     Drop LCFR logic
// 2002/01/21 D4100020 N.Maeda        Change oldCurrentPOS to oldCurrentPOData
// 2002/02/12 D4100083 Y.Kurisu       Enhanced Future Hold
// 2002/02/25 P4100159 H.Adachi       Add Cassette Xfer Status Check
// 2002/02/28 D4100120 N.Minami       Future Action
// 2002/03/25 D4100210 H.Adachi       Add InParameter CurrentRouteID & CurrentOperationNum For Check Condition
// 2002/07/29 D4200029 K.Kimura       Process Hold Control
// 2003/09/09 P5000145 H.Adachi       Fix Message and Message Macro mismatch.
// 10/22/04   D6000025 K.Murakami     eBroker Migration.
// 2006/05/18 D7000092 Y.Kadowaki     Add object lock for cassette.
// 2007/08/03 D9000056 H.Hotta        Add check logic for InPostProcessFlag.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
// 2008/10/29 DSIV00000214 S.Miyata       Multi Fab Transfer Support
// 2013/05/10 DSN000071674 C.Mo           Remove part of the EI state limitation
// 2014/07/28 DSN000085792 Sa Guo         Q-Time Improvements.
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/08/28 INN-R170002  Yangxiaojun    Overide txSubRouteBranchCancelReq
// 2017/09/12 INN-R170002  Thomas Song    Contamination Control
// 2017/10/10 INN-R170003  YangXigang     Durable Management Enhancement
//
//
// Description:
//
// Return:
//     long
//
// Parameter:
//     pptSubRouteBranchCancelReqResult& strSubRouteBranchCancelReqResult
//     const pptObjCommonIn& strObjCommonIn
//     const objectIdentifier& lotID
//     const char * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//      TXTRC035

CORBA::Long CS_PPTManager_i::txSubRouteBranchCancelReq (pptSubRouteBranchCancelReqResult& strSubRouteBranchCancelReqResult,
                                                     const pptObjCommonIn& strObjCommonIn,
                                                     const objectIdentifier& lotID,
                                                     const objectIdentifier& currentRouteID,       //D4100210
                                                     const char * currentOperationNumber,          //D4100210
//D6000025                                                      const char * claimMemo,
//D6000025                                                      CORBA::Environment &IT_env)
                                                     const char * claimMemo //D6000025
                                                     CORBAENV_LAST_CPP)     //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::txSubRouteBranchCancelReq");
    CORBA::Long rc = RC_OK;

    PPT_METHODTRACE_V2("", "in param - lotID ", lotID.identifier);

    objectIdentifier aLotID( lotID );
    objectIdentifier aCassetteID;

    /*------------------------------------------------------------------------*/
    /*   Get cassette / lot connection                                        */
    /*------------------------------------------------------------------------*/
    objLot_cassette_Get_out strLot_cassette_Get_out;
    rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_cassette_Get() != RC_OK");
        strSubRouteBranchCancelReqResult.strResult = strLot_cassette_Get_out.strResult;
        return(rc);
    }
    aCassetteID = strLot_cassette_Get_out.cassetteID;

    /*--------------------------------*/
    /*   Lock objects to be updated   */
    /*--------------------------------*/
    objObject_Lock_out strObject_Lock_out;
//D7000092 add start
    rc = object_Lock( strObject_Lock_out, strObjCommonIn, aCassetteID, SP_ClassName_PosCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
        strSubRouteBranchCancelReqResult.strResult = strObject_Lock_out.strResult;
        return( rc );
    }
//D7000092 add end

    rc = object_Lock( strObject_Lock_out, strObjCommonIn, aLotID, SP_ClassName_PosLot );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1(" ", "object_Lock() rc != RC_OK" );
        strSubRouteBranchCancelReqResult.strResult = strObject_Lock_out.strResult;
        return( rc );
    }

    //D4100210 add start
    //--------------------------------------------------------------------------
    //   Check whether Lot is on the specified Route/Operation or Not
    //--------------------------------------------------------------------------
    PPT_METHODTRACE_V1("","Check whether Lot is on the specified Route/Operation or Not...");

    objectIdentifier  tmpCurrentRouteID         = currentRouteID;
    CORBA::String_var tmpCurrentOperationNumber = CIMFWStrDup(currentOperationNumber);

    if ((CIMFWStrLen(tmpCurrentRouteID.identifier) != 0)&&
        (CIMFWStrLen(tmpCurrentOperationNumber) != 0))
    {
        PPT_METHODTRACE_V1("","InPara Current Info is Not Null. Begin to Check!!");

        objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
        rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out, strObjCommonIn, aLotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","lot_currentOperationInfo_Get() != RC_OK");
            strSubRouteBranchCancelReqResult.strResult  = strLot_currentOperationInfo_Get_out.strResult;
            return( rc );
        }

        PPT_METHODTRACE_V2("","In-parm's routeID            :", tmpCurrentRouteID.identifier );
        PPT_METHODTRACE_V2("","In-Parm's operationNumber    :", tmpCurrentOperationNumber    );

        PPT_METHODTRACE_V2("","Lot's currentRouteID         :", strLot_currentOperationInfo_Get_out.routeID.identifier );
        PPT_METHODTRACE_V2("","Lot's currentOperationNumber :", strLot_currentOperationInfo_Get_out.operationNumber    );

        if ( CIMFWStrCmp(tmpCurrentRouteID.identifier, strLot_currentOperationInfo_Get_out.routeID.identifier) == 0 &&
             CIMFWStrCmp(tmpCurrentOperationNumber   , strLot_currentOperationInfo_Get_out.operationNumber   ) == 0 )
        {
            PPT_METHODTRACE_V1("","Route/Operation check OK. Go ahead...");
        }
        else
        {
            PPT_METHODTRACE_V1("","Route/Operation check NG.");
            PPT_SET_MSG_RC_KEY2(strSubRouteBranchCancelReqResult,
                                MSG_NOT_SAME_ROUTE,
                                RC_NOT_SAME_ROUTE,
                                "Input parameter's currentRouteID/currentOperationNumber",
                                "lot's current currentRouteID/currentOperationNumber");
            return( RC_NOT_SAME_ROUTE );
        }
    }
    else
    {
        PPT_METHODTRACE_V1("","InPara Current Info is Null. No Check!!");
    }
    //D4100210 add end
    /*------------------------------------------------------------------------*/
    /*   Check Condition                                                      */
    /*------------------------------------------------------------------------*/
    objLot_holdState_Get_out strLot_holdState_Get_out;
    rc = lot_holdState_Get(strLot_holdState_Get_out, strObjCommonIn, aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_holdState_Get() != RC_OK");
        strSubRouteBranchCancelReqResult.strResult = strLot_holdState_Get_out.strResult;
        return(rc);
    }
    else if( (CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState, CIMFW_Lot_HoldState_OnHold)) == 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState,CIMFW_Lot_HoldState_OnHold)) == 0" );
        PPT_SET_MSG_RC_KEY2(strSubRouteBranchCancelReqResult,
                            MSG_INVALID_LOT_HOLDSTAT,
                            RC_INVALID_LOT_HOLDSTAT,
                            aLotID.identifier,
                            strLot_holdState_Get_out.lotHoldState);
        return(RC_INVALID_LOT_HOLDSTAT);
    }

    objLot_state_Get_out strLot_state_Get_out;
    rc = lot_state_Get(strLot_state_Get_out,strObjCommonIn,aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_state_Get() != RC_OK");
        strSubRouteBranchCancelReqResult.strResult = strLot_state_Get_out.strResult;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_state_Get_out.lotState, CIMFW_Lot_State_Active)!=0)
    {
        PPT_METHODTRACE_V1("", "CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Active)!=0");
        PPT_SET_MSG_RC_KEY(strSubRouteBranchCancelReqResult,
                           MSG_INVALID_LOT_STAT,
                           RC_INVALID_LOT_STAT,
                           strLot_state_Get_out.lotState);
        return(RC_INVALID_LOT_STAT);
    }

    objLot_processState_Get_out strLot_processState_Get_out;
    rc = lot_processState_Get(strLot_processState_Get_out,strObjCommonIn,aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_processState_Get() != RC_OK");
        strSubRouteBranchCancelReqResult.strResult = strLot_processState_Get_out.strResult;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState, SP_Lot_ProcState_Processing) == 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState, SP_Lot_ProcState_Processing) == 0");
        PPT_SET_MSG_RC_KEY2(strSubRouteBranchCancelReqResult,
                            MSG_INVALID_LOT_PROCSTAT,
                            RC_INVALID_LOT_PROCSTAT,
                            aLotID.identifier,strLot_processState_Get_out.theLotProcessState);
        return(RC_INVALID_LOT_PROCSTAT);
    }

    objLot_inventoryState_Get_out strLot_inventoryState_Get_out;
    rc = lot_inventoryState_Get(strLot_inventoryState_Get_out,strObjCommonIn,aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_inventoryState_Get() != RC_OK");
        strSubRouteBranchCancelReqResult.strResult = strLot_inventoryState_Get_out.strResult;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState,SP_Lot_InventoryState_OnFloor) != 0)
    {
        PPT_METHODTRACE_V1("", "CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState,SP_Lot_InventoryState_OnFloor) != 0");
        PPT_SET_MSG_RC_KEY2(strSubRouteBranchCancelReqResult,
                            MSG_INVALID_LOT_INVENTORYSTAT,
                            RC_INVALID_LOT_INVENTORYSTAT,
                            aLotID.identifier, strLot_inventoryState_Get_out.lotInventoryState);
        return(RC_INVALID_LOT_INVENTORYSTAT);
    }

//P3100256 start
    objLot_productionState_Get_out strLot_productionState_Get_out;
    rc = lot_productionState_Get(strLot_productionState_Get_out, strObjCommonIn, aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_productionState_Get() != RC_OK");
        strSubRouteBranchCancelReqResult.strResult = strLot_productionState_Get_out.strResult;
        return(rc);
    }
    else if( 0 != CIMFWStrCmp(strLot_productionState_Get_out.lotProductionState, CIMFW_Lot_ProductionState_InProduction) )
    {
        PPT_METHODTRACE_V1("", "lotProductionState != CIMFW_Lot_ProductionState_InProduction");
        PPT_SET_MSG_RC_KEY2(strSubRouteBranchCancelReqResult,
                            MSG_INVALID_LOT_PRODSTAT,
                            RC_INVALID_LOT_PRODSTAT,
                            aLotID.identifier,
                            strLot_productionState_Get_out.lotProductionState );
        return(RC_INVALID_LOT_PRODSTAT);
    }
//P3100256 end

//D9000056 add start
    PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
    //----------------------------------
    //  Get InPostProcessFlag of Lot
    //----------------------------------
    objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
    objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
    strLot_inPostProcessFlag_Get_in.lotID = aLotID;

    rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                    strObjCommonIn,
                                    strLot_inPostProcessFlag_Get_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
        strSubRouteBranchCancelReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
        return( rc );
    }

    //----------------------------------------------
    //  If Lot is in post process, returns error
    //----------------------------------------------
    if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
    {
        PPT_METHODTRACE_V1("", "Lot is in post process.");
//DSIV00000201 Add Start
        /*---------------------------*/
        /* Get UserGroupID By UserID */
        /*---------------------------*/
        objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
        rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                         strObjCommonIn,
                                         strObjCommonIn.strUser.userID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
            strSubRouteBranchCancelReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
            return( rc );
        }
        objectIdentifierSequence userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
        CORBA::ULong userGroupIDsLen = userGroupIDs.length();
        PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);
        
        CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
        PPT_METHODTRACE_V2("", "extPostProc", extPostProc);
        
        CORBA::ULong nCnt = 0;
        for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
        {
            PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
            if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
            {
                PPT_METHODTRACE_V1("", "# External Post Process User!");
                break;
            }
            
        }
        if (nCnt == userGroupIDsLen)
        {
            PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
            PPT_SET_MSG_RC_KEY( strSubRouteBranchCancelReqResult,
                                MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                aLotID.identifier );
            return( RC_LOT_INPOSTPROCESS );
        }   //DSIV00000201
    }
//D9000056 add end

//DSIV00000214 add start
    //---------------------------------------
    //   Check interFabXferPlan existence
    //---------------------------------------
    objInterFab_xferPlanList_GetDR_out strInterFab_xferPlanList_GetDR_out;
    objInterFab_xferPlanList_GetDR_in strInterFab_xferPlanList_GetDR_in;
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.lotID = aLotID;
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.seqNo = 0;
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalFabID = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalRouteID = currentRouteID;
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalOpeNumber = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.destinationFabID = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.destinationRouteID.identifier = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.destinationOpeNumber = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.xferType = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.description = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.modifierUserID.identifier = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.modifiedTime = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.state = CIMFWStrDup("");
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.stateUpdateTime = CIMFWStrDup("");

    rc = interFab_xferPlanList_GetDR( strInterFab_xferPlanList_GetDR_out,
                                      strObjCommonIn,
                                      strInterFab_xferPlanList_GetDR_in );
    if( rc != RC_OK && rc != RC_INTERFAB_NOT_FOUND_XFERPLAN )
    {
        PPT_METHODTRACE_V1("", "interFab_xferPlanList_GetDR() != RC_OK");
        strSubRouteBranchCancelReqResult.strResult = strInterFab_xferPlanList_GetDR_out.strResult;
        return( rc );
    }

    CORBA::Long xferLen = strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq.length();
    for( CORBA::Long xCnt = 0; xCnt < xferLen; xCnt++ )
    {
        if( 0 != CIMFWStrCmp(strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq[xCnt].state,
                             SP_InterFab_XferPlanState_Completed) )
        {
            PPT_METHODTRACE_V1("", "strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq.length != 0");
            SET_MSG_RC( strSubRouteBranchCancelReqResult,
                        MSG_INTERFAB_BRANCH_CANCEL_ERROR,
                        RC_INTERFAB_BRANCH_CANCEL_ERROR );
            return( RC_INTERFAB_BRANCH_CANCEL_ERROR );
        }
    }
//DSIV00000214 add end

//DSN000071674 add start
    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );
    if ( 1 == lotOperationEIcheck )
    {
//DSN000071674 add end
        //P4100159 Add Start
        //==================================
        // TransferState should be Not EI
        //==================================
        objCassette_transferState_Get_out strCassette_transferState_Get_out;
        rc = cassette_transferState_Get(strCassette_transferState_Get_out,strObjCommonIn,aCassetteID);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "cassette_transferState_Get rc != RC_OK")
            strSubRouteBranchCancelReqResult.strResult = strCassette_transferState_Get_out.strResult;
            return(rc);
        }
        //INN-R170003 else if (CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0)  
        //INN-R170003 add start
        else if (CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 ||
                 CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentOut) == 0 ||
                 CIMFWStrCmp(strCassette_transferState_Get_out.transferState, CS_TRANS_STATE_PORT_IN) == 0
                )
        //INN-R170003 add end
        {
            PPT_METHODTRACE_V1("", "Cassette Transfer State is EI !!!")
            PPT_METHODTRACE_V2("", "strCassette_transferState_Get_out.transferState = ", strCassette_transferState_Get_out.transferState);
            PPT_SET_MSG_RC_KEY2(strSubRouteBranchCancelReqResult,MSG_INVALID_LOT_XFERSTAT, RC_INVALID_LOT_XFERSTAT,
                                aCassetteID.identifier,strCassette_transferState_Get_out.transferState)

            return(RC_INVALID_LOT_XFERSTAT);
        }
        //P4100159 Add End
    } //DSN000071674

//Q3000147 add start
    /*----------------------------------*/
    /*   Check Lot's Control Job ID     */
    /*----------------------------------*/
    objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, lotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lot_controlJobID_Get() != RC_OK");
        strSubRouteBranchCancelReqResult.strResult = strLot_controlJobID_Get_out.strResult;
        return(rc);
    }
    if (CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) == 0)
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) = 0");
        rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(controlJobID.identifier) > 0");
        PPT_SET_MSG_RC_KEY2( strSubRouteBranchCancelReqResult,
                             MSG_LOT_CTLJOBID_FILLED,
                             RC_LOT_CTLJOBID_FILLED,
                             lotID.identifier,
                             strLot_controlJobID_Get_out.controlJobID.identifier );
        return( RC_LOT_CTLJOBID_FILLED );
    }
//Q3000147 add end

//D4100069//(D3000118,D3000119) add start
//D4100069    /*--------------------------------------------------*/
//D4100069    /*   Check Logic for Lot-Customized Branch Route    */
//D4100069    /*   Not applicable to  Lot-Customized Branch Route */
//D4100069    /*--------------------------------------------------*/
//D4100069    objLot_CheckForLCFR_out  strLot_CheckForLCFR_out;
//D4100069    rc = lot_CheckForLCFR(strLot_CheckForLCFR_out, strObjCommonIn, lotID, SP_LotCustomize_DBRECORD); //P3100057
//D4100069    if ( rc == RC_OK )                                                                                     //P3100057
//D4100069    {                                                                                                      //P3100057
//D4100069        PPT_METHODTRACE_V1("", "lot_CheckForLCFR() == RC_OK");
//D4100069
//D4100069//P3100121  add start
//D4100069
//D4100069        /* ----------------------------------------------------- */
//D4100069        /* Check whether current route is Flexible Rework Route, */
//D4100069        /* or not.                                               */
//D4100069        /* If current route is FR Route, don't cancel Branch.    */
//D4100069        /* ----------------------------------------------------- */
//D4100069        objLot_currentLCFRInfo_Get_out   strLot_currentLCFRInfo_Get_out;
//D4100069        rc = lot_currentLCFRInfo_Get( strLot_currentLCFRInfo_Get_out, strObjCommonIn, lotID );
//D4100069        if ( rc != RC_OK )
//D4100069        {
//D4100069            PPT_METHODTRACE_V2("", "lot_currentLCFRInfo_Get() != RC_OK", rc);
//D4100069            strSubRouteBranchCancelReqResult.strResult = strLot_currentLCFRInfo_Get_out.strResult;
//D4100069            return( rc );
//D4100069        }
//D4100069
//D4100069        if ( CIMFWStrCmp( strLot_currentLCFRInfo_Get_out.routeKind, SP_RouteKind_FRSUB ) == 0 )
//D4100069        {
//D4100069            PPT_METHODTRACE_V1("", "strLot_currentLCFRInfo_Get_out.routeKind == SP_RouteKind_FRSUB");
//D4100069            PPT_SET_MSG_RC_KEY( strSubRouteBranchCancelReqResult,
//D4100069                                MSG_INVALID_OPE_TO_FRSUBROUTE,
//D4100069                                RC_INVALID_OPE_TO_FRSUBROUTE,
//D4100069                                lotID.identifier);
//D4100069            return( RC_INVALID_OPE_TO_FRSUBROUTE );
//D4100069        }
//D4100069
//D4100069//P3100121  add end
//D4100069
//D4100069//P3100279 add start
//D4100069        if ( CIMFWStrCmp( strLot_currentLCFRInfo_Get_out.routeKind, SP_RouteKind_LCSUB ) == 0 )
//D4100069        {
//D4100069            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSubRouteBranchCancelReq",
//D4100069                               "strLot_currentLCFRInfo_Get_out.routeKind == SP_RouteKind_LCSUB");
//D4100069            PPT_SET_MSG_RC_KEY( strSubRouteBranchCancelReqResult,
//D4100069                                MSG_INVALID_OPE_TO_LCSUBROUTE,
//D4100069                                RC_INVALID_OPE_TO_LCSUBROUTE,
//D4100069                                lotID.identifier) ;
//D4100069            return( RC_INVALID_OPE_TO_LCSUBROUTE );
//D4100069        }
//D4100069//P3100279 add end

//P3100279  remove start
//P3100279        /*===== get connected route : SubRoute =====*/
//P3100279        objProcess_connectedRouteListForLCFR_out strProcess_connectedRouteListForLCFR_out;
//P3100279        rc = process_connectedRouteListForLCFR( strProcess_connectedRouteListForLCFR_out,
//P3100279                                                strObjCommonIn,
//P3100279                                                SP_MAINPDTYPE_BRANCH,
//P3100279                                                lotID );
//P3100279
//P3100279        if( rc != RC_OK )
//P3100279        {
//P3100279            PPT_METHODTRACE_V2("", "process_connectedRouteListForLCFR(lotID) != RC_OK",rc);
//P3100279
//P3100279            strSubRouteBranchCancelReqResult.strResult = strProcess_connectedRouteListForLCFR_out.strResult;
//P3100279            return( rc );
//P3100279        }
//P3100279
//P3100279        /*===== compare returned routeID vs in-parm's subRouteID =====*/
//P3100279        objLot_currentRouteID_Get_out strLot_currentRouteID_Get_out;
//P3100279        rc = lot_currentRouteID_Get(    strLot_currentRouteID_Get_out,
//P3100279                                        strObjCommonIn,
//P3100279                                        lotID);
//P3100279
//P3100279        if( rc != RC_OK )
//P3100279        {
//P3100279            PPT_METHODTRACE_V2("", "lot_currentRouteID_Get() != RC_OK",rc);
//P3100279
//P3100279            strSubRouteBranchCancelReqResult.strResult = strLot_currentRouteID_Get_out.strResult;
//P3100279            return( rc );
//P3100279        }
//P3100279
//P3100279        CORBA::Long subRouteLen = strProcess_connectedRouteListForLCFR_out.strConnectedRouteList.length();
//P3100279        CORBA::Boolean findFlag = FALSE;
//P3100279
//P3100279        for ( CORBA::Long i = 0; i < subRouteLen; i++ )
//P3100279        {
//P3100279            PPT_METHODTRACE_V2("", "compare subRouteID Loop Count = ",i);
//P3100279
//P3100279            if ( CIMFWStrCmp( strProcess_connectedRouteListForLCFR_out.strConnectedRouteList[i].routeID.identifier, strLot_currentRouteID_Get_out.currentRouteID.identifier ) == 0 )
//P3100279            {
//P3100279                findFlag = TRUE;
//P3100279                break;
//P3100279            }
//P3100279        }
//P3100279
//P3100279        if ( findFlag == TRUE )
//P3100279        {
//P3100279            PPT_METHODTRACE_V1("", "findFlag == TRUE");
//P3100279
//P3100279            objLot_originalRouteList_Get_out    strLot_originalRouteList_Get_out;
//P3100279            rc = lot_originalRouteList_Get( strLot_originalRouteList_Get_out,
//P3100279                                            strObjCommonIn,
//P3100279                                            lotID);
//P3100279            if ( rc != RC_OK )
//P3100279            {
//P3100279                PPT_METHODTRACE_V2("", "lot_originalRouteList_Get() != RC_OK", rc);
//P3100279                strSubRouteBranchCancelReqResult.strResult = strLot_originalRouteList_Get_out.strResult;
//P3100279                return( rc );
//P3100279            }
//P3100279
//P3100279            CORBA::Long  lenOriginalRouteIDSeq = strLot_originalRouteList_Get_out.originalRouteID.length();
//P3100279
//P3100279            if ( lenOriginalRouteIDSeq == 1 && CIMFWStrCmp( strLot_originalRouteList_Get_out.returnOperationNumber[0], SP_LotCustomize_Dummy_OperationNumber ) == 0 )
//P3100279            {
//P3100279                PPT_METHODTRACE_V1("", "lenOriginalRouteIDSeq == 1 && CIMFWStrCmp( strLot_originalRouteList_Get_out.returnOperationNumber[0], SP_LotCustomize_Dummy_OperationNumber ) == 0");
//P3100279//P3100014      findFlag = FALSE;
//P3100279                findFlag = TRUE;  //P3100014
//P3100279            }                     //P3100014
//P3100279            else                  //P3100014
//P3100279            {
//P3100279                PPT_METHODTRACE_V1("", "lenOriginalRouteIDSeq != 1  || CIMFWStrCmp( strLot_originalRouteList_Get_out.returnOperationNumber[0], SP_LotCustomize_Dummy_OperationNumber ) != 0");
//P3100279                findFlag = FALSE; //P3100014
//P3100279            }                     //P3100014
//P3100279
//P3100279        }
//P3100279
//P3100279        if ( findFlag == TRUE )
//P3100279        {
//P3100279            PPT_METHODTRACE_V1("", "findFlag == FALSE");
//P3100279
//P3100279            PPT_SET_MSG_RC_KEY( strSubRouteBranchCancelReqResult,
//P3100279                                MSG_INVALID_OPE_TO_LCSUBROUTE,
//P3100279                                RC_INVALID_OPE_TO_LCSUBROUTE,
//P3100279                                lotID.identifier);
//P3100279
//P3100279            PPT_METHODTRACE_EXIT("CS_PPTManager_i::txSubRouteBranchCancelReq ");
//P3100279            return( RC_INVALID_OPE_TO_LCSUBROUTE );
//P3100279        }
//P3100279  remove end

//D4100069    }                                                                                                    //P3100057
//D4100069    else                                                                                                 //P3100057
//D4100069    {                                                                                                    //P3100057
//D4100069        PPT_METHODTRACE_V1("", "lot_CheckForLCFR() != RC_OK");   //P3100057
//D4100069    }                                                                                                    //P3100057
//D4100069
//D4100069//(D3000118,D3000119) add end

    objProcess_CheckBranchCancel_out strProcess_CheckBranchCancel_out;
    rc = process_CheckBranchCancel( strProcess_CheckBranchCancel_out , strObjCommonIn , aLotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "process_CheckBranchCancel() != RC_OK",rc);
        strSubRouteBranchCancelReqResult.strResult = strProcess_CheckBranchCancel_out.strResult;
        return (rc);
    }

    objLot_futureHoldRequests_CheckBranchCancel_out strLot_futureHoldRequests_CheckBranchCancel_out;
    rc = lot_futureHoldRequests_CheckBranchCancel(strLot_futureHoldRequests_CheckBranchCancel_out, strObjCommonIn, aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "lot_futureHoldRequests_CheckBranchCancel() != RC_OK",rc);
        strSubRouteBranchCancelReqResult.strResult = strLot_futureHoldRequests_CheckBranchCancel_out.strResult;
        return(rc);
    }

//D4100120 Add Start
    /*-----------------------------------*/
    /*   Check Future Action Procedure   */
    /*-----------------------------------*/
    objSchdlChangeReservation_CheckForBranchCancel_out strSchdlChangeReservation_CheckForBranchCancel_out;
    rc = schdlChangeReservation_CheckForBranchCancelDR(strSchdlChangeReservation_CheckForBranchCancel_out,
                                                       strObjCommonIn,
                                                       aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "schdlChangeReservation_CheckForBranchCancelDR() != RC_OK") ;
        strSubRouteBranchCancelReqResult.strResult = strSchdlChangeReservation_CheckForBranchCancel_out.strResult;
        return(rc);
    }
//D4100120 Add End

//DSN000085792 Add Start
    /*-----------------------------------------------------------*/
    /* Roll back Target Operation for sub route                  */
    /*-----------------------------------------------------------*/
    objQTime_targetOpe_cancelReplace_out strQTime_targetOpe_cancelReplace_out;
    objQTime_targetOpe_cancelReplace_in  strQTime_targetOpe_cancelReplace_in;
    strQTime_targetOpe_cancelReplace_in.lotID = aLotID;
    rc = qTime_targetOpe_cancelReplace( strQTime_targetOpe_cancelReplace_out,
                                        strObjCommonIn,
                                        strQTime_targetOpe_cancelReplace_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "qTime_targetOpe_cancelReplace() != RC_OK", rc);
        strSubRouteBranchCancelReqResult.strResult = strQTime_targetOpe_cancelReplace_out.strResult;
        return rc;
    }
//DSN000085792 Add End

    /*-----------------------------------------------------------*/
    /* Route change request                                      */
    /*-----------------------------------------------------------*/
    objProcess_CancelBranchRoute_out strProcess_CancelBranchRoute_out;
    rc = process_CancelBranchRoute( strProcess_CancelBranchRoute_out , strObjCommonIn , aLotID );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "process_CancelBranchRoute() != RC_OK");
        strSubRouteBranchCancelReqResult.strResult = strProcess_CancelBranchRoute_out.strResult;
        return(rc);
    }

//D4100069//P3100043  add start
//D4100069    objLot_futureHoldRequests_Effect_out strLot_futureHoldRequests_Effect_out;
//D4100069    {
//D4100069        objLot_CheckForLCFR_out  strLot_CheckForLCFR_out;
//D4100069        rc = lot_CheckForLCFR( strLot_CheckForLCFR_out, strObjCommonIn, aLotID, SP_LotCustomize_DBRECORD );
//D4100069        if ( rc != RC_OK )
//D4100069        {
//D4100069            PPT_METHODTRACE_V2("", "lot_CheckForLCFR() != RC_OK", rc);
//D4100069
//D4100069            rc = lot_futureHoldRequests_Effect( strLot_futureHoldRequests_Effect_out,strObjCommonIn, aLotID );
//D4100069            if ( rc != RC_OK )
//D4100069            {
//D4100069                PPT_METHODTRACE_V2("", "lot_futureHoldRequests_Effect() != RC_OK", rc);
//D4100069                strSubRouteBranchCancelReqResult.strResult = strLot_futureHoldRequests_Effect_out.strResult;
//D4100069                return( rc );
//D4100069            }
//D4100069        }
//D4100069        else
//D4100069        {
//D4100069            PPT_METHODTRACE_V1("", "lot_CheckForLCFR() == RC_OK");
//D4100069
//D4100069            objLot_futureHoldRequests_EffectForLCFR_out  strLot_futureHoldRequests_EffectForLCFR_out;
//D4100069            rc = lot_futureHoldRequests_EffectForLCFR( strLot_futureHoldRequests_EffectForLCFR_out, strObjCommonIn, aLotID );
//D4100069            if ( rc == RC_OK )
//D4100069            {
//D4100069                PPT_METHODTRACE_V1("", "lot_futureHoldRequests_EffectForLCFR() == RC_OK");
//D4100069                strLot_futureHoldRequests_Effect_out.strLotHoldReqList = strLot_futureHoldRequests_EffectForLCFR_out.strLotHoldReqList;
//D4100069            }
//D4100069            else
//D4100069            {
//D4100069                PPT_METHODTRACE_V2("", "lot_futureHoldRequests_EffectForLCFR() != RC_OK", rc);
//D4100069                strSubRouteBranchCancelReqResult.strResult = strLot_futureHoldRequests_EffectForLCFR_out.strResult;
//D4100069                return( rc );
//D4100069            }
//D4100069        }
//D4100069    }
//D4100069//P3100043  add end

//P3100043    objLot_futureHoldRequests_Effect_out strLot_futureHoldRequests_Effect_out;
//P3100043    rc = lot_futureHoldRequests_Effect(strLot_futureHoldRequests_Effect_out,strObjCommonIn,aLotID);
//P3100043    if (rc != RC_OK)
//P3100043    {
//P3100043        PPT_METHODTRACE_V1("", "lot_futureHoldRequests_Effect() != RC_OK");
//P3100043        strSubRouteBranchCancelReqResult.strResult = strLot_futureHoldRequests_Effect_out.strResult;
//P3100043        return(rc);
//P3100043    }

//D4100069 restore start
//D4100083 Del Start
//    objLot_futureHoldRequests_Effect_out strLot_futureHoldRequests_Effect_out;
//    rc = lot_futureHoldRequests_Effect(strLot_futureHoldRequests_Effect_out,strObjCommonIn,aLotID);
//    if (rc != RC_OK)
//    {
//        PPT_METHODTRACE_V1("", "lot_futureHoldRequests_Effect() != RC_OK");
//        strSubRouteBranchCancelReqResult.strResult = strLot_futureHoldRequests_Effect_out.strResult;
//        return(rc);
//    }
//D4100083 Del End
//D4100069 restore end

//D4100083 Add Start
    pptEffectCondition strEffectCondition;
    objectIdentifier releaseReasonCodeID ;
    objLot_futureHoldRequests_DeleteEffectedByCondition_out strLot_futureHoldRequests_DeleteEffectedByCondition_out;

    strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_PRE );
    strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_ALL );

    objLot_futureHoldRequests_EffectByCondition_out strLot_futureHoldRequests_EffectByCondition_out;
    rc = lot_futureHoldRequests_EffectByCondition( strLot_futureHoldRequests_EffectByCondition_out,
                                                   strObjCommonIn,
                                                   aLotID,
                                                   strEffectCondition);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_futureHoldRequests_EffectByCondition() != RC_OK") ;
        strSubRouteBranchCancelReqResult.strResult = strLot_futureHoldRequests_EffectByCondition_out.strResult ;
        return( rc );
    }
//D4100083 Add End

//D4100083    if ( strLot_futureHoldRequests_Effect_out.strLotHoldReqList.length() > 0 )
    if ( strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList.length() > 0 ) //D4100083
    {
        pptHoldLotReqResult strHoldLotReqResult;
//D4100083        rc = txHoldLotReq (strHoldLotReqResult, strObjCommonIn, aLotID, strLot_futureHoldRequests_Effect_out.strLotHoldReqList);
        rc = txHoldLotReq (strHoldLotReqResult, strObjCommonIn, aLotID, strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList); //D4100083
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK");
            strSubRouteBranchCancelReqResult.strResult = strHoldLotReqResult.strResult;
            return(rc);
        }
    }
//D4100083 Add Start
    strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_PRE );
    strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_SINGLE );

    rc = lot_futureHoldRequests_DeleteEffectedByCondition( strLot_futureHoldRequests_DeleteEffectedByCondition_out,
                                                           strObjCommonIn,
                                                           aLotID,
                                                           strEffectCondition );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_futureHoldRequests_DeleteEffectedByCondition() != RC_OK") ;
        strSubRouteBranchCancelReqResult.strResult = strLot_futureHoldRequests_DeleteEffectedByCondition_out.strResult ;
        return( rc );
    }

    if( strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList.length() > 0 )
    {
        pptFutureHoldCancelReqResult strFutureHoldCancelReqResult ;
        rc = txFutureHoldCancelReq(strFutureHoldCancelReqResult,
                                   strObjCommonIn,
                                   aLotID,
                                   releaseReasonCodeID,
                                   SP_EntryType_Remove,
                                   strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList) ;
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "txFutureHoldCancelReq() != RC_OK") ;
            strSubRouteBranchCancelReqResult.strResult = strFutureHoldCancelReqResult.strResult ;
            return(rc);
        }
    }
//D4100083 Add End

    /*---------------------------------------*/
    /*   Update Cassette's MultiLotType      */
    /*---------------------------------------*/
    objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
    rc = cassette_multiLotType_Update(strCassette_multiLotType_Update_out, strObjCommonIn, aCassetteID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "cassette_multiLotType_Update() != RC_OK");
        strSubRouteBranchCancelReqResult.strResult = strCassette_multiLotType_Update_out.strResult;
        return(rc);
    }

#if 1
//D4000016 Add Start
    //--------------------------------------------------------------------------------------------------
    // UpDate RequiredCassetteCategory
    //--------------------------------------------------------------------------------------------------
    objLot_CassetteCategory_UpdateForContaminationControl_out   strLot_CassetteCategory_UpdateForContaminationControl_out;
    rc = lot_CassetteCategory_UpdateForContaminationControl( strLot_CassetteCategory_UpdateForContaminationControl_out,
                                                             strObjCommonIn,
                                                             aLotID );

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","lot_CassetteCategory_UpdateForContaminationControl != RC_OK");
        strSubRouteBranchCancelReqResult.strResult = strLot_CassetteCategory_UpdateForContaminationControl_out.strResult;
        return rc;
    }
//D4000016 Add end
#endif

//INN-R170002 Add Start
    //--------------------------------------------------------------------------------------------------
    // Check Contamination Level
    //--------------------------------------------------------------------------------------------------
    csObjLot_ContaminationInfo_CheckForMove_in strLot_ContaminationInfo_CheckForMove_in;
    strLot_ContaminationInfo_CheckForMove_in.lotID = aLotID;
    strLot_ContaminationInfo_CheckForMove_in.carrierID = aCassetteID;
    csObjLot_ContaminationInfo_CheckForMove_out strLot_ContaminationInfo_CheckForMove_out;
    rc = cs_lot_ContaminationInfo_CheckForMove( strLot_ContaminationInfo_CheckForMove_out,
                                                strObjCommonIn,
                                                strLot_ContaminationInfo_CheckForMove_in );

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","cs_lot_ContaminationInfo_CheckForMove != RC_OK");
        strSubRouteBranchCancelReqResult.strResult = strLot_ContaminationInfo_CheckForMove_out.strResult;
        return rc;
    }

    if(strLot_ContaminationInfo_CheckForMove_out.holdReqFlag == TRUE)
    {
        pptHoldLotReqResult strHoldLotReqResult;
        pptHoldListSequence strLotHoldReqList( 1 );
        strLotHoldReqList.length( 1 );

        strLotHoldReqList[0].holdType                    = CIMFWStrDup( SP_HoldType_LotHold );
        strLotHoldReqList[0].holdReasonCodeID.identifier = CIMFWStrDup( CS_SP_Reason_ContaminationMismatchHold );
        strLotHoldReqList[0].holdUserID                  = strObjCommonIn.strUser.userID;
        strLotHoldReqList[0].responsibleOperationMark    = CIMFWStrDup( SP_ResponsibleOperation_Current );
        strLotHoldReqList[0].claimMemo                   = claimMemo;

        rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn,
                           aLotID,
                           strLotHoldReqList );

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
            strSubRouteBranchCancelReqResult.strResult = strHoldLotReqResult.strResult ;
            return rc ;
        }
        else
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() == RC_OK For LotHold") ;
        }
    }
//INN-R170002 Add End

//D4200029 Add Start
    //-----------------------//
    //     Process Hold      //
    //-----------------------//
    PPT_METHODTRACE_V1("","Call txProcessHoldExecReq()");
    pptProcessHoldExecReqResult strProcessHoldExecReqResult;

    rc = txProcessHoldExecReq( strProcessHoldExecReqResult,
                               strObjCommonIn,
                               lotID,
                               claimMemo );

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","txProcessHoldExecReq() != RC_OK", rc );
        strSubRouteBranchCancelReqResult.strResult = strProcessHoldExecReqResult.strResult ;
        return( rc );
    }

//D4200029 Add End

    /*-----------------------------------------------------------*/
    /*   Make History                                            */
    /*-----------------------------------------------------------*/
    objLotOperationMoveEvent_MakeBranch_out  strLotOperationMoveEvent_MakeBranch_out;
    rc = lotOperationMoveEvent_MakeBranch(strLotOperationMoveEvent_MakeBranch_out,
                                          strObjCommonIn,
                                          "TXTRC035",
                                          aLotID,
//                                        strProcess_CancelBranchRoute_out.oldCurrentPOS,                    //D4100020 Delete
                                          strProcess_CancelBranchRoute_out.oldCurrentPOData,                 //D4100020 Add
                                          claimMemo);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "lotOperationMoveEvent_MakeBranch() != RC_OK");
//P5000145        PPT_SET_MSG_RC_KEY(strSubRouteBranchCancelReqResult, MSG_FAIL_MAKE_HISTORY, rc, aLotID.identifier);
        SET_MSG_RC( strSubRouteBranchCancelReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145
        return (rc);
    }

    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
    SET_MSG_RC(strSubRouteBranchCancelReqResult, MSG_OK, RC_OK);
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txSubRouteBranchCancelReq ");
    return(RC_OK);
}
