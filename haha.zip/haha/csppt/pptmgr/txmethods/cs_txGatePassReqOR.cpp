#ifndef lint
static char *sccsid =  "@(#) 1.4 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txGatePassReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/22/07 17:30:25 [ 11/22/07 17:30:27 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txGatePassReqOR.cpp
//

#include "cs_pptmgr.hpp"
#include "penin.hh"
extern char* makeInhibitListFromEntityInhibits(const PosEntityInhibitSequence* entityInhibits);

// Class: CS_PPTManager
//
// Service: txGatePassReq()
//
// Change history:
// Date       Defect#    Person         Comments
// ---------- ---------- -------------- -------------------------------------------
// 2000/08/08            S.Kawabe       Initial Release (R30)
// 2000/09/26 Q3000147   S.Kawabe       Add Check Lot's Control Job ID
// 2000/10/23 P3000280   S.Kawabe       Boolean variable initialize
// 2001-01-11 D3000118   S.NAKATA       Lot Customization and Flexible Rework
// 2001-01-11 D3000119   S.NAKATA       Lot Customization and Flexible Rework
// 2001-03-01 D3100060   M.Shimizu      All Merge Check Delete Trace
// 2001-03-15 P3100043   M.Shimizu      extendedOperationNumber for LC-subRoute
// 2001-06-11 P4000015   K.Muguruma     LC:Fix USTR of ZeroFault (initialize autoBankInFlag)
// 2001-07-06 P4000047   K.Kido         incorecct return structure fix
// 2001-07-18 P4000061   Y.Yoshihara    Fix return code management routine
// 2001/07/25 D4000016   M.Shimizu      Contamination Control(Copper/Non Copper [R40 Core])
// 2001/08/13 P4000090   K.Kido         Set return structure in sequence
// 2001/12/17 D40A0027   Y.Iwasaki      Add for ProcessLagTime function.
// 2002/01/16 D4100069   C.Tsuchiya     Drop LCFR logic
// 2002/02/08 D4100083   T.Michii       Enhancement Future Hold
// 2002/02/28 D4100120   N.Minami       Future Action
// 2002/03/02 D4100036   K.Matsuei      FlowBatch Control. add check FlowBatch.
// 2002/03/07 D4100170   Y.Iwasaki      Change In-Parm
// 2002/03/25 D4100210   H.Adachi       Chenge Menber Name(Add Current)
// 2002/03/25 P4100027   M.Ameshita     Fix to set the reason code for waiting monitor hold.
// 2002/03/25 P4100040   M.Ameshita     Fix to use the passed PD for monitor group related logic.
// 2002/05/29 P4100492   K.Matsuei      Seqnence length is not correct when txBankInReq is called from txGatePassReq.
// 2002/06/11 P4100536   T.Nishimura    Source Check : Wrong reference to dimension.
// 2002/07/04 P4200025   T.Nishimura    Source Check : return without message.
// 2002/07/30 D4200029   K.Kimura       Process Hold Control
// 2002/09/30 P4200204   H.Adachi       Add Parameter of holdReleasedLotIDs for txGatePassReq
// 2003/09/09 P5000145   H.Adachi       Fix Message and Message Macro mismatch.
// 2004/04/16 D5100184   H.Hasegawa     Add the logic which repeats Gate Pass for Monitored Lot
// 2004/08/03 P5100473   H.Adachi       Add logic of setting parameter for txSchdlChangeReservationExecuteReq().
// 2004/10/22 D6000025   K.Murakami     eBroker Migration.
// 2004/12/09 P6000118   M.Mori         Add the logic which sets a return code to a return structure.
// 2006/04/25 D7000213   Y.Kadowaki     Add a check for transfer state of cassette.
// 2006/05/18 D7000092   Y.Kadowaki     Add object lock for cassette.
// 2006/06/07 P7000282   Y.Kadowaki     Fix missing of return code for each lot.
// 2006/10/26 D7000354   H.Hasegawa     Add the logic which resets Q-Time actions
// 2007/08/23 D9000056   H.Hotta        Add check logic for InPostProcessFlag.
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
// 2008/11/21 DSIV00000214 H.Mutoh        Multi Fab Transfer Support.
// 2009-07-28 PSIV00001188 R.Iriguchi     Fix auto bank-in/schedule change reservation handling.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2010/03/20 DSIV00001830 S.Kawabe       Wafer Stacking Operation Support
// 2010/10/14 DSIV00002435 M.Ogawa        Support SubLotType change by Schedule Change Reservation
// 2011/10/20 DSN000015229 M.Ogawa        Advanced Wafer Level Control
// 2013/01/23 DSN000050720 M.Ogawa        Change locked object in Post Process parallel execution.
// 2013/05/09 DSN000071674 C.Mo           Remove part of the EI state limitation
// 2013/09/03 DSN000081739 Sa Guo         Equipment Monitor Automation Support
// 2014/05/13 DSN000085698 S.Wang         Support equipment monitor used count function
// 2015/02/26 PSN000097781 VietNQ         Specify TransactionId parameter used to make eqpMonitorWaferUsedCountUpdate event
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/08/28 INN-R170002  Yangxiaojun    Overide txGatePassReq
// 2017/09/07 INN-R170002  JQ.Shao        Contamination Control
// 2017/09/27 INN-R170003  SF.Peng        Add new transfer state PI/PO to control FOUP location
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptGatePassReqResult& strGatePassReqResult
//     const pptObjCommonIn& strObjCommonIn
//     CORBA::Long seqIndex
// //  const objectIdentifierSequence& lotID
//     const pptGatePassLotInfoSequence& strGatePassLotInfo      //D4100170
//     const char * claimMemo
//     objectIdentifierSequence holdReleasedLotIDs               //P4200204
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//P4200204 Delete Start
//CORBA::Long CS_PPTManager_i::txGatePassReq (pptGatePassReqResult& strGatePassReqResult,
//                                         const pptObjCommonIn& strObjCommonIn,
//                                         CORBA::Long seqIndex,
////D4100170                               const objectIdentifierSequence& lotID,
//                                         const pptGatePassLotInfoSequence& strGatePassLotInfo,       //D4100170
//                                         const char * claimMemo,
//                                         CORBA::Environment &IT_env)
//P4200204 Delete End

//P4200204 Add
CORBA::Long CS_PPTManager_i::txGatePassReq (pptGatePassReqResult& strGatePassReqResult,
                                         const pptObjCommonIn& strObjCommonIn,
                                         CORBA::Long seqIndex,
                                         const pptGatePassLotInfoSequence& strGatePassLotInfo,
                                         const char * claimMemo,
//D6000025                                          objectIdentifierSequence& holdReleasedLotIDs,
//D6000025                                          CORBA::Environment &IT_env)
                                         objectIdentifierSequence& holdReleasedLotIDs //D6000025
                                         CORBAENV_LAST_CPP)                           //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txGatePassReq") ;
    CORBA::Long rc = RC_OK ;

//P4100536 add start
    // Check length of In-Parameter
    if(seqIndex >= strGatePassLotInfo.length() || seqIndex >= strGatePassReqResult.strGatePassLotsResult.length())
    {
        SET_MSG_RC(strGatePassReqResult, MSG_INVALID_PARAMETER, RC_INVALID_PARAMETER); //P4200025 add
        return RC_INVALID_PARAMETER;
    }
//P4100536 add end

//  objectIdentifier aLotID = lotID[seqIndex] ;
    objectIdentifier aLotID = strGatePassLotInfo[seqIndex].lotID;    //D4100170
    objectIdentifier aCassetteID;

//D4100210    objectIdentifier  routeID         = strGatePassLotInfo[seqIndex].routeID;                        //D4100170
//D4100210    CORBA::String_var operationNumber = CIMFWStrDup(strGatePassLotInfo[seqIndex].operationNumber);   //D4100170

    objectIdentifier  routeID         = strGatePassLotInfo[seqIndex].currentRouteID;                        //D4100210
    CORBA::String_var operationNumber = CIMFWStrDup(strGatePassLotInfo[seqIndex].currentOperationNumber);   //D4100210

    /*------------------------------------------------------------------------*/
    /*   Get lot / cassette connection                                        */
    /*------------------------------------------------------------------------*/
    objLot_cassette_Get_out    strLot_cassette_Get_out ;
    rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_cassette_Get() != RC_OK") ;
        strGatePassReqResult.strResult = strLot_cassette_Get_out.strResult ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].lotID = aLotID ;
        return(rc);
    }
    aCassetteID = strLot_cassette_Get_out.cassetteID ;

//DSN000050720 Add Start
    // Get PostProcForLotFlag from thread specific data
    CORBA::Boolean bParallelPostProcFlag = FALSE;
    char* methodName = NULL;
    CORBA::String_var strParallelPostProcFlag;
    try
    {
        methodName = CIMFWStrDup("getThreadSpecificDataString");
        strParallelPostProcFlag = getThreadSpecificDataString(SP_ThreadSpecificData_Key_PostProcParallelFlag);
        CORBA::string_free(methodName);
        methodName = NULL;
    }
    CATCH_GLOBAL_EXCEPTIONS(strGatePassReqResult, txGatePassReq, methodName);

    PPT_METHODTRACE_V2("", "strParallelPostProcFlag", strParallelPostProcFlag);

    if ( 0 == CIMFWStrCmp(strParallelPostProcFlag, SP_PostProcess_ParallelExecution_ON) )
    {
        PPT_METHODTRACE_V1("","strParallelPostProcFlag=SP_PostProcess_ParallelExecution_ON");
        bParallelPostProcFlag = TRUE;
    }
//DSN000050720 Add End
//D7000092 add start
    /*--------------------------------*/
    /*   Object Lock for Cassette     */
    /*--------------------------------*/
    objObject_Lock_out  strObject_Lock_out;
//DSN000050720 Add Start

    //----------------------------------------------------------//
    //   Skip cassette lock to increase parallel availability   //
    //   under PostProcess parallel execution                   //
    //----------------------------------------------------------//
    if( FALSE == bParallelPostProcFlag )
    {
        //PostProcess sequential execution
        PPT_METHODTRACE_V1("", "Lock cassette object.");
//DSN000050720 Add End
//DSN000050720 Indent Start
        rc = object_Lock(strObject_Lock_out, strObjCommonIn, aCassetteID, SP_ClassName_PosCassette);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
            strGatePassReqResult.strResult = strObject_Lock_out.strResult;
            strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc);
            strGatePassReqResult.strGatePassLotsResult[seqIndex].lotID = aLotID;
            return(rc);
        }
//DSN000050720 Indent End
    }   //DSN000050720
//D7000092 add end

//DSN000071674 add start
    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );
    if ( 1 == lotOperationEIcheck )
    {
        PPT_METHODTRACE_V1("", "lotOperationEIcheck = 1") ;
//DSN000071674 add end
//D7000213 add start
        //------------------------------------------------------------------------------------------------
        // TransferState should not be EI except when called from BRScript with OpeComp/OpeStartCancel.
        //------------------------------------------------------------------------------------------------
        if( CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC004") != 0 &&  //TxOpeCompWithDataReq
            CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC055") != 0 &&  //TxOpeCompForInternalBufferReq
            CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC015") != 0 &&  //TxPartialOpeCompWithDataReq           //DSN000015229
            CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC016") != 0 &&  //TxPartialOpeCompForInternalBufferReq  //DSN000015229
            CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC010") != 0 &&  //TxForceOpeCompReq
            CIMFWStrCmp(strObjCommonIn.transactionID, "TXEWC011") != 0 &&  //TxForceOpeCompForInternalBufferReq
            CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC003") != 0 &&  //TxOpeStartCancelReq
            CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC061") != 0 )   //TxOpeStartCancelForInternalBufferReq
        {
            objCassette_transferState_Get_out  strCassette_transferState_Get_out;
            rc = cassette_transferState_Get( strCassette_transferState_Get_out, strObjCommonIn, aCassetteID );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "cassette_transferState_Get() != RC_OK", rc);
                strGatePassReqResult.strResult = strCassette_transferState_Get_out.strResult;
//P7000282 add start
                strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc);
                strGatePassReqResult.strGatePassLotsResult[seqIndex].lotID = aLotID;
//P7000282 add end
                return( rc );
            }

//INN-R170003            if( CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 )
//INN-R170003 Add Start
            if( CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 ||
                CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentOut) == 0 ||
                CIMFWStrCmp(strCassette_transferState_Get_out.transferState, CS_TRANS_STATE_PORT_IN) == 0 )
//INN-R170003 Add End
            {
//INN-R170003                 PPT_METHODTRACE_V1("", "TransferState of cassette is EI");
                PPT_METHODTRACE_V2("", "TransferState of cassette is ", strCassette_transferState_Get_out.transferState); //INN-R170003
                PPT_SET_MSG_RC_KEY2( strGatePassReqResult,
                                     MSG_INVALID_CAST_XFERSTAT,
                                     RC_INVALID_CAST_XFERSTAT,
//INN-R170003                                     SP_TransState_EquipmentIn,
                                     strCassette_transferState_Get_out.transferState,  //INN-R170003
                                     aCassetteID.identifier );
//P7000282 add start
                strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(RC_INVALID_CAST_XFERSTAT);
                strGatePassReqResult.strGatePassLotsResult[seqIndex].lotID = aLotID;
//P7000282 add end
                return( RC_INVALID_CAST_XFERSTAT );
            }
        }
//D7000213 add end.
    } //DSN000071674

    /*--------------------------------*/
    /*   Lock objects to be updated   */
    /*--------------------------------*/
//D7000092    objObject_Lock_out strObject_Lock_out;
    rc = object_Lock( strObject_Lock_out, strObjCommonIn, aLotID, SP_ClassName_PosLot );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq ", "object_Lock() != RC_OK") ;
        strGatePassReqResult.strResult = strObject_Lock_out.strResult ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc);          //P4000047
        strGatePassReqResult.strGatePassLotsResult[seqIndex].lotID = aLotID;                                //P4000047
        return( rc );
    }

//DSN000050720 Add Start
    if( TRUE == bParallelPostProcFlag )
    {
        //-------------------------------------------------------------------------------//
        //   Lock MonitorGroup to reactivate object in Post Process parallel execution   //
        //-------------------------------------------------------------------------------//
        objMonitorGroup_GetDR_out strMonitorGroup_GetDR_out ;
        rc = monitorGroup_GetDR( strMonitorGroup_GetDR_out,
                                 strObjCommonIn,
                                 aLotID ) ;
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "monitorGroup_GetDR() != RC_OK", rc);
            strGatePassReqResult.strResult = strMonitorGroup_GetDR_out.strResult;
            return( rc );
        }

        CORBA::ULong monGrpLen = strMonitorGroup_GetDR_out.strMonitorGroups.length();
        PPT_METHODTRACE_V2("", "monGrpLen", monGrpLen);
        for( CORBA::ULong i = 0; i < monGrpLen; i++ )
        {
            PPT_METHODTRACE_V2( "", "Loop for monitor group.", strMonitorGroup_GetDR_out.strMonitorGroups[i].monitorGroupID.identifier );
            rc = object_Lock( strObject_Lock_out, strObjCommonIn, strMonitorGroup_GetDR_out.strMonitorGroups[i].monitorGroupID, SP_ClassName_PosMonitorGroup );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                strGatePassReqResult.strResult = strObject_Lock_out.strResult;
                return( rc );
            }
        } //[i]
    }
//DSN000050720 Add End

    // ****This initialisation is common for all.****
    strGatePassReqResult.strGatePassLotsResult[seqIndex].lotID = aLotID ;

//D4100170 add start
    //--------------------------------------------------------------------------
    //   Check whether Lot is on the specified Route/Operation or Not
    //--------------------------------------------------------------------------
    PPT_METHODTRACE_V1("","Check whether Lot is on the specified Route/Operation or Not...");

    objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
    rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out, strObjCommonIn, aLotID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("","lot_currentOperationInfo_Get() != RC_OK");
        strGatePassReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc);
        strGatePassReqResult.strGatePassLotsResult[seqIndex].lotID      = aLotID;
        return( rc );
    }

    PPT_METHODTRACE_V2("","In-parm's routeID            :", routeID.identifier );
    PPT_METHODTRACE_V2("","In-Parm's operationNumber    :", operationNumber    );

    PPT_METHODTRACE_V2("","Lot's currentRouteID         :", strLot_currentOperationInfo_Get_out.routeID.identifier );
    PPT_METHODTRACE_V2("","Lot's currentOperationNumber :", strLot_currentOperationInfo_Get_out.operationNumber    );

    if ( CIMFWStrCmp(routeID.identifier, strLot_currentOperationInfo_Get_out.routeID.identifier) == 0 &&
         CIMFWStrCmp(operationNumber   , strLot_currentOperationInfo_Get_out.operationNumber   ) == 0 )
    {
        PPT_METHODTRACE_V1("","Route/Operation check OK. Go ahead...");
    }
    else
    {
        PPT_METHODTRACE_V1("","Route/Operation check NG.");
        PPT_SET_MSG_RC_KEY2(strGatePassReqResult,
                            MSG_NOT_SAME_ROUTE,
                            RC_NOT_SAME_ROUTE,
                            "Input parameter's route/operation",
                            "lot's current route/operation");
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(RC_NOT_SAME_ROUTE);
        strGatePassReqResult.strGatePassLotsResult[seqIndex].lotID      = aLotID;
        return( RC_NOT_SAME_ROUTE );
    }
//D4100170 add end

    /*------------------------------------------------------------------------*/
    /*   Check Condition                                                      */
    /*------------------------------------------------------------------------*/
    objProcess_CheckGatePass_out strProcess_CheckGatePass_out ;
    rc = process_CheckGatePass( strProcess_CheckGatePass_out, strObjCommonIn, aLotID) ;
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "process_CheckGatePass() != RC_OK") ;
        strGatePassReqResult.strResult = strProcess_CheckGatePass_out.strResult ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        return(rc);
    }

    objProcess_CheckGatePassForBondingFlowSection_out strProcess_CheckGatePassForBondingFlowSection_out;                         //DSIV00001830
    rc = process_CheckGatePassForBondingFlowSection( strProcess_CheckGatePassForBondingFlowSection_out, strObjCommonIn, aLotID); //DSIV00001830
    if( rc != RC_OK )                                                                                                            //DSIV00001830
    {                                                                                                                            //DSIV00001830
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "process_CheckGatePassForBondingFlowSection() != RC_OK");             //DSIV00001830
        strGatePassReqResult.strResult = strProcess_CheckGatePassForBondingFlowSection_out.strResult;                            //DSIV00001830
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc);                               //DSIV00001830
        return rc;                                                                                                               //DSIV00001830
    }                                                                                                                            //DSIV00001830

    objLot_state_Get_out strLot_state_Get_out ;
    rc = lot_state_Get(strLot_state_Get_out, strObjCommonIn, aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_state_Get() != RC_OK") ;
        strGatePassReqResult.strResult = strLot_state_Get_out.strResult ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_state_Get_out.lotState, CIMFW_Lot_State_Active) != 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq",
                           "CIMFWStrCmp(strLot_state_Get_out.lotState, CIMFW_Lot_State_Active) != 0") ;
        PPT_SET_MSG_RC_KEY(strGatePassReqResult,
                           MSG_INVALID_LOT_STAT,
                           RC_INVALID_LOT_STAT,
                           strLot_state_Get_out.lotState ) ;
//P4000061 strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString( MSG_INVALID_LOT_STAT ) ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString( RC_INVALID_LOT_STAT ) ;
        return(RC_INVALID_LOT_STAT);
    }

    objLot_holdState_Get_out strLot_holdState_Get_out ;
    rc = lot_holdState_Get(strLot_holdState_Get_out, strObjCommonIn, aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_holdState_Get() != RC_OK") ;
        strGatePassReqResult.strResult = strLot_holdState_Get_out.strResult ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState, CIMFW_Lot_HoldState_NotOnHold) != 0 )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq",
                           "CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState, CIMFW_Lot_HoldState_NotOnHold) != 0") ;
        PPT_SET_MSG_RC_KEY2(strGatePassReqResult,
                            MSG_INVALID_LOT_HOLDSTAT,
                            RC_INVALID_LOT_HOLDSTAT,
                            aLotID.identifier,
                            strLot_holdState_Get_out.lotHoldState) ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(RC_INVALID_LOT_HOLDSTAT) ;
        return(RC_INVALID_LOT_HOLDSTAT);
    }

    objLot_processState_Get_out strLot_processState_Get_out ;
    rc = lot_processState_Get(strLot_processState_Get_out, strObjCommonIn, aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_processState_Get() != RC_OK") ;
        strGatePassReqResult.strResult = strLot_processState_Get_out.strResult ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState, SP_Lot_ProcState_Waiting) != 0 )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq",
                           "CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState, SP_Lot_ProcState_Waiting) != 0") ;
        PPT_SET_MSG_RC_KEY2(strGatePassReqResult,
                            MSG_INVALID_LOT_PROCSTAT,
                            RC_INVALID_LOT_PROCSTAT,
                            aLotID.identifier,
                            strLot_processState_Get_out.theLotProcessState) ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(RC_INVALID_LOT_PROCSTAT) ;
        return(RC_INVALID_LOT_PROCSTAT);
    }

    objLot_inventoryState_Get_out strLot_inventoryState_Get_out ;
    rc = lot_inventoryState_Get(strLot_inventoryState_Get_out, strObjCommonIn, aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_inventoryState_Get() != RC_OK") ;
        strGatePassReqResult.strResult = strLot_inventoryState_Get_out.strResult ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState, SP_Lot_InventoryState_OnFloor) != 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq",
                           "CIMFWStrCmp(strLot_inventoryState_Get_out.lotInventoryState, SP_Lot_InventoryState_OnFloor) != 0") ;
        PPT_SET_MSG_RC_KEY2(strGatePassReqResult,
                            MSG_INVALID_LOT_INVENTORYSTAT,
                            RC_INVALID_LOT_INVENTORYSTAT,
                            aLotID.identifier,
                            strLot_inventoryState_Get_out.lotInventoryState) ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(RC_INVALID_LOT_INVENTORYSTAT) ;
        return(RC_INVALID_LOT_INVENTORYSTAT);
    }

//D9000056 add start
    PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
    //----------------------------------
    //  Get InPostProcessFlag of Lot
    //----------------------------------
    objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
    objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
    strLot_inPostProcessFlag_Get_in.lotID = aLotID;

    rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                    strObjCommonIn,
                                    strLot_inPostProcessFlag_Get_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
        strGatePassReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString( rc );
        return( rc );
    }

    //----------------------------------------------
    //  If Lot is in post process, returns error
    //----------------------------------------------
    if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
    {
        PPT_METHODTRACE_V1("", "Lot is in post process.");
//DSIV00000201 Add Start
        /*---------------------------*/
        /* Get UserGroupID By UserID */
        /*---------------------------*/
        objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
        rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                         strObjCommonIn,
                                         strObjCommonIn.strUser.userID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
            strGatePassReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
            return( rc );
        }
        objectIdentifierSequence userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
        CORBA::ULong userGroupIDsLen = userGroupIDs.length();
        PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);

        CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
        PPT_METHODTRACE_V2("", "extPostProc", extPostProc);

        CORBA::ULong nCnt = 0;
        for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
        {
            PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
            if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
            {
                PPT_METHODTRACE_V1("", "# External Post Process User!");
                break;
            }

        }
        if (nCnt == userGroupIDsLen)
        {
            PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
            PPT_SET_MSG_RC_KEY( strGatePassReqResult,
                                MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                aLotID.identifier );
            strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString( RC_LOT_INPOSTPROCESS );
            return( RC_LOT_INPOSTPROCESS );
        }   //DSIV00000201

    }
//D9000056 add end

//DSIV00000214 add start
    //---------------------------------------
    // Check interFabXferPlan existence
    //---------------------------------------
    CORBA::String_var curFabID = CIMFWStrDup( getenv(SP_FAB_ID) );

    objInterFab_xferPlanList_GetDR_out strInterFab_xferPlanList_GetDR_out;
    objInterFab_xferPlanList_GetDR_in  strInterFab_xferPlanList_GetDR_in;
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.lotID = strGatePassLotInfo[seqIndex].lotID;
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalFabID = CIMFWStrDup(curFabID);
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalRouteID = strGatePassLotInfo[seqIndex].currentRouteID;
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalOpeNumber = CIMFWStrDup(strGatePassLotInfo[seqIndex].currentOperationNumber);
    rc = interFab_xferPlanList_GetDR( strInterFab_xferPlanList_GetDR_out, strObjCommonIn,
                                      strInterFab_xferPlanList_GetDR_in );
    if( rc != RC_OK && rc != RC_INTERFAB_NOT_FOUND_XFERPLAN )
    {
        PPT_METHODTRACE_V2("", "interFab_xferPlanList_GetDR() != RC_OK", rc);
        strGatePassReqResult.strResult = strInterFab_xferPlanList_GetDR_out.strResult;
        return rc;
    }

    CORBA::ULong planLen = strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq.length();

    if( 0 < planLen )
    {
        PPT_METHODTRACE_V1("", "xfer plans exist");
        CORBA::ULong pCnt = 0;
        for( pCnt=0; pCnt<planLen; pCnt++ )
        {
            if( 0 == CIMFWStrCmp(strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq[pCnt].state,
                                 SP_InterFab_XferPlanState_Created) ||
                0 == CIMFWStrCmp(strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq[pCnt].state,
                                 SP_InterFab_XferPlanState_Canceled) )
            {
                PPT_METHODTRACE_V1("", "Unexecuted interFabXfer plan of is defined on this peocess.");
                PPT_SET_MSG_RC_KEY( strGatePassReqResult,
                                    MSG_INTERFAB_PROCESS_SKIP_ERROR, RC_INTERFAB_PROCESS_SKIP_ERROR,
                                    strGatePassLotInfo[seqIndex].currentOperationNumber );
                return RC_INTERFAB_PROCESS_SKIP_ERROR;
            }
        }
    }
//DSIV00000214 add end

#if 0
//D4100036 start
    /*-------------------------------*/
    /*   Check FlowBatch Condition   */
    /*-------------------------------*/
    PPT_METHODTRACE_V1("", "Check FlowBatch Condition");
    CORBA::Boolean bLocateDirection = TRUE;
    objLot_flowBatch_CheckLocate_out strLot_flowBatch_CheckLocate_out ;
    rc = lot_flowBatch_CheckLocate( strLot_flowBatch_CheckLocate_out,
                                    strObjCommonIn,
                                    bLocateDirection,
                                    aLotID,
                                    aProcessRef );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "lot_flowBatch_CheckLocate() != RC_OK", rc) ;
        /*-------------------------------*/
        /*   Remove Lot from FlowBatch   */
        /*-------------------------------*/
        if ( rc == RC_LOT_REMOVE_FROM_BATCH )
        {
            PPT_METHODTRACE_V1("", "lot_flowBatch_CheckLocate() == RC_LOT_REMOVE_FROM_BATCH") ;
            objLot_flowBatchID_Get_out strLot_flowBatchID_Get_out;
            rc = lot_flowBatchID_Get( strLot_flowBatchID_Get_out, strObjCommonIn, aLotID );
            if ( rc == RC_LOT_FLOW_BATCH_ID_FILLED )
            {
                pptLotRemoveFromFlowBatchReqResult  strLotRemoveFromFlowBatchReqResult;

                pptRemoveCassetteSequence strRemoveCassette;
                strRemoveCassette.length(1);

                strRemoveCassette[0].lotID.length(1);
                strRemoveCassette[0].lotID[0] = aLotID;
                strRemoveCassette[0].cassetteID = aCassetteID;

                PPT_METHODTRACE_V1("", "call txLotRemoveFromFlowBatchReq()");
                rc = txLotRemoveFromFlowBatchReq( strLotRemoveFromFlowBatchReqResult,
                                                  strObjCommonIn,
                                                  strLot_flowBatchID_Get_out.flowBatchID,
                                                  strRemoveCassette,
                                                  claimMemo );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "##### txLotRemoveFromFlowBatchReq() != RC_OK", rc );
                    strGatePassReqResult.strResult = strLotRemoveFromFlowBatchReqResult.strResult;
                    return( rc );
                }
            }
            else if ( rc != RC_LOT_FLOW_BATCH_ID_BLANK )
            {
                PPT_METHODTRACE_V2("", "##### lot_batchID_Get() != RC_LOT_BATCH_ID_BLANK", rc);
                strGatePassReqResult.strResult = strLot_flowBatchID_Get_out.strResult;
                return( rc );
            }
        }
        else
        {
            PPT_METHODTRACE_V2("", "lot_flowBatch_CheckLocate() != RC_OK , RC_LOT_FLOW_BATCH_ID_FILLED", rc);
            strGatePassReqResult.strResult = strLot_flowBatch_CheckLocate_out.strResult;
            return rc;
        }
    }
//D4100036 end
#endif

    /*----------------------------------*/
    /*   Check Lot's Control Job ID     */
    /*----------------------------------*/
    objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, aLotID );
//Q3000147 start
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_controlJobID_Get() != RC_OK");
        strGatePassReqResult.strResult = strLot_controlJobID_Get_out.strResult ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString( rc ) ;       //P4000090
        return(rc);
    }
//Q3000147 end
    if (CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) == 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq",
                           "CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) == 0");
        rc = RC_OK;
    }
    else
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq",
                           "IMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) != 0");
        PPT_SET_MSG_RC_KEY2( strGatePassReqResult,
                             MSG_LOT_CTLJOBID_FILLED,
                             RC_LOT_CTLJOBID_FILLED,
                             aLotID.identifier,
                             strLot_controlJobID_Get_out.controlJobID.identifier ) ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString( RC_LOT_CTLJOBID_FILLED ) ;       //P4000090
        return( RC_LOT_CTLJOBID_FILLED );
    }

    /*---------------------------*/
    /*   Check BankIn Operation  */
    /*---------------------------*/
    objProcess_CheckBankIn_out strProcess_CheckBankIn_out ;
    rc = process_CheckBankIn(strProcess_CheckBankIn_out, strObjCommonIn, aLotID);
    if (rc != RC_NOT_BANKIN_OPERATION )   // If this operation is BankIn operation, return error.
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "process_CheckBankIn() != RC_NOT_BANKIN_OPERATION") ;
        strGatePassReqResult.strResult = strProcess_CheckBankIn_out.strResult ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString( rc );
        return(rc);
    }

//D4100120 Add Start
    /*-----------------------------------*/
    /*   Check Future Action Procedure   */
    /*-----------------------------------*/
//PSIV00001188    CORBA::String_var EmptyString;

//DSIV00002435    objSchdlChangeReservation_CheckForAction_out strSchdlChangeReservation_CheckForAction_out;
//DSIV00002435    rc = schdlChangeReservation_CheckForActionDR(strSchdlChangeReservation_CheckForAction_out,
//DSIV00002435                                                 strObjCommonIn,
//DSIV00002435                                                 aLotID,
//DSIV00002435//PSIV00001188                                                 EmptyString,
//DSIV00002435                                                 strLot_currentOperationInfo_Get_out.routeID.identifier,        //PSIV00001188
//DSIV00002435//PSIV00001188                                                 EmptyString);
//DSIV00002435                                                 strLot_currentOperationInfo_Get_out.operationNumber);          //PSIV00001188
//DSIV00002435 add start
    objSchdlChangeReservation_CheckForActionDR_out__110 strSchdlChangeReservation_CheckForAction_out;
    objSchdlChangeReservation_CheckForActionDR_in__110  strSchdlChangeReservation_CheckForActionDR_in;
    strSchdlChangeReservation_CheckForActionDR_in.lotID           = aLotID;
    strSchdlChangeReservation_CheckForActionDR_in.routeID         = strLot_currentOperationInfo_Get_out.routeID.identifier;
    strSchdlChangeReservation_CheckForActionDR_in.operationNumber = strLot_currentOperationInfo_Get_out.operationNumber;
    rc = schdlChangeReservation_CheckForActionDR__110( strSchdlChangeReservation_CheckForAction_out,
                                                       strObjCommonIn,
                                                       strSchdlChangeReservation_CheckForActionDR_in );
//DSIV00002435 add end
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "schdlChangeReservation_CheckForActionDR() != RC_OK") ;
        strGatePassReqResult.strResult = strSchdlChangeReservation_CheckForAction_out.strResult;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        return(rc);
    }
//D4100120 Add End

    /*------------------------------------------------------------------------*/
    /*   Change State                                                         */
    /*------------------------------------------------------------------------*/
//P4100040    objMonitorGroup_DeleteComp_out strMonitorGroup_DeleteComp_out ;
//P4100040    rc = monitorGroup_DeleteComp(strMonitorGroup_DeleteComp_out, strObjCommonIn, aLotID);
//P4100040    if (rc != RC_OK)
//P4100040    {
//P4100040        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "monitorGroup_DeleteComp() != RC_OK") ;
//P4100040        strGatePassReqResult.strResult = strMonitorGroup_DeleteComp_out.strResult ;
//P4100040        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
//P4100040        return(rc);
//P4100040    }
//P4100040
//P4100040    objectIdentifier aReasonCodeID ;
//P4100040    aReasonCodeID.identifier = CIMFWStrDup( SP_Reason_WaitingMonitorHoldRelease ) ;              //P4100027
//P4100040
//P4100040    CORBA::Long nCompLotSeq = strMonitorGroup_DeleteComp_out.strMonitoredCompLots.length() ;
//P4100040    PPT_METHODTRACE_V2("CS_PPTManager_i:: txGatePassReq",
//P4100040                       "strMonitorGroup_DeleteComp_out.strMonitoredCompLots.length()", nCompLotSeq) ;
//P4100040
//P4100040    for(CORBA::Long i=0; i<nCompLotSeq; i++)
//P4100040    {
//P4100040        if( strMonitorGroup_DeleteComp_out.strMonitoredCompLots[i].strLotHoldReleaseReqList.length() > 0 )
//P4100040        {
//P4100040            pptHoldLotReleaseReqResult strHoldLotReleaseReqResult ;
//P4100040            rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult,
//P4100040                                      strObjCommonIn,
//P4100040                                      strMonitorGroup_DeleteComp_out.strMonitoredCompLots[i].productLotID,
//P4100040                                      aReasonCodeID,
//P4100040                                      strMonitorGroup_DeleteComp_out.strMonitoredCompLots[i].strLotHoldReleaseReqList) ;
//P4100040            if (rc != RC_OK)
//P4100040            {
//P4100040                PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "txHoldLotReleaseReq() != RC_OK") ;
//P4100040                strGatePassReqResult.strResult = strHoldLotReleaseReqResult.strResult ;
//P4100040                strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
//P4100040                return rc ;
//P4100040            }
//P4100040        }
//P4100040    }

    objQtime_SetClearByOperationComp_out strQtime_SetClearByOperationComp_out ;
    rc = qtime_SetClearByOperationComp( strQtime_SetClearByOperationComp_out , strObjCommonIn , aLotID ) ;
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "qtime_SetClearByOperationComp() != RC_OK") ;
        strGatePassReqResult.strResult = strQtime_SetClearByOperationComp_out.strResult ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        return(rc);
    }

//D7000354 Add Start
    //--------------------------------------------------
    // Reset Q-Time actions
    //--------------------------------------------------
    objectIdentifier  resetReasonCodeID;
    resetReasonCodeID.identifier = CIMFWStrDup( SP_Reason_QTimeClear );

    //----- Lot Hold Actions -------//
    if( strQtime_SetClearByOperationComp_out.strLotHoldReleaseList.length() > 0 )
    {
        PPT_METHODTRACE_V1("", "The lot hold actions to reset was found.");

        pptHoldLotReleaseReqResult  strHoldLotReleaseReqResult;
        rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult, strObjCommonIn, aLotID,
                                  resetReasonCodeID, strQtime_SetClearByOperationComp_out.strLotHoldReleaseList );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "txHoldLotReleaseReq() != RC_OK");
            strGatePassReqResult.strResult = strHoldLotReleaseReqResult.strResult;
            return rc;
        }
    }

    //----- Future Hold Actions -------//
    if( strQtime_SetClearByOperationComp_out.strFutureHoldCancelList.length() > 0 )
    {
        PPT_METHODTRACE_V1("", "The future hold actions to cancel was found.");

        pptFutureHoldCancelReqResult  strFutureHoldCancelReqResult;
        rc = txFutureHoldCancelReq( strFutureHoldCancelReqResult, strObjCommonIn, aLotID, resetReasonCodeID,
                                    SP_EntryType_Cancel, strQtime_SetClearByOperationComp_out.strFutureHoldCancelList );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "txFutureHoldCancelReq() != RC_OK");
            strGatePassReqResult.strResult = strFutureHoldCancelReqResult.strResult;
            return rc;
        }
    }

    //----- Future Rework Actions -------//
    CORBA::Long  cancelLen = strQtime_SetClearByOperationComp_out.strFutureReworkCancelList.length();
    if( cancelLen > 0 )
    {
        PPT_METHODTRACE_V2("", "The future rework actions to cancel was found.", cancelLen);

        for( CORBA::Long  cancelCnt = 0; cancelCnt < cancelLen; cancelCnt++ )
        {
            pptFutureReworkInfo  strFutureRework = strQtime_SetClearByOperationComp_out.strFutureReworkCancelList[cancelCnt];

            pptFutureReworkCancelReqResult  strFutureReworkCancelReqResult;
            rc = txFutureReworkCancelReq( strFutureReworkCancelReqResult, strObjCommonIn, strFutureRework.lotID, strFutureRework.routeID,
                                          strFutureRework.operationNumber, strFutureRework.strFutureReworkDetailInfoSeq, "" );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "txFutureReworkCancelReq() != RC_OK");
                strGatePassReqResult.strResult = strFutureReworkCancelReqResult.strResult;
                return rc;
            }
        }
    }
//D7000354 Add End

//D4100069//P3100043  add start
//D4100069    objLot_futureHoldRequests_DeleteEffected_out strLot_futureHoldRequests_DeleteEffected_out ;
//D4100069    {
//D4100069        objLot_CheckForLCFR_out strLot_CheckForLCFR_out;
//D4100069        rc = lot_CheckForLCFR(  strLot_CheckForLCFR_out,strObjCommonIn,aLotID,SP_LotCustomize_DBRECORD );
//D4100069        if ( rc != RC_OK )
//D4100069        {
//D4100069            PPT_METHODTRACE_V2("CS_PPTManager_i:: txGatePassReq", "lot_CheckForLCFR() != RC_OK", rc);
//D4100069            rc = lot_futureHoldRequests_DeleteEffected(strLot_futureHoldRequests_DeleteEffected_out, strObjCommonIn, aLotID) ;
//D4100069            if(rc != RC_OK)
//D4100069            {
//D4100069                PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_futureHoldRequests_DeleteEffected() != RC_OK") ;
//D4100069                strGatePassReqResult.strResult = strLot_futureHoldRequests_DeleteEffected_out.strResult ;
//D4100069                strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString( rc ) ;
//D4100069                return(rc);
//D4100069            }
//D4100069        }
//D4100069        else
//D4100069        {
//D4100069            PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_CheckForLCFR() == RC_OK");
//D4100069
//D4100069            objLot_futureHoldRequests_DeleteEffectedForLCFR_out  strLot_futureHoldRequests_DeleteEffectedForLCFR_out;
//D4100069            rc = lot_futureHoldRequests_DeleteEffectedForLCFR( strLot_futureHoldRequests_DeleteEffectedForLCFR_out, strObjCommonIn, aLotID );
//D4100069            if ( rc == RC_OK )
//D4100069            {
//D4100069                PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_futureHoldRequests_DeleteEffectedForLCFR() == RC_OK");
//D4100069                strLot_futureHoldRequests_DeleteEffected_out.strFutureHoldReleaseReqList = strLot_futureHoldRequests_DeleteEffectedForLCFR_out.strFutureHoldReleaseReqList;
//D4100069            }
//D4100069            else
//D4100069            {
//D4100069                PPT_METHODTRACE_V2("CS_PPTManager_i:: txGatePassReq", "lot_futureHoldRequests_DeleteEffectedForLCFR() != RC_OK", rc);
//D4100069                strGatePassReqResult.strResult = strLot_futureHoldRequests_DeleteEffectedForLCFR_out.strResult;
//D4100069                strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString( rc ) ;
//D4100069                return( rc );
//D4100069            }
//D4100069        }
//D4100069    }
//D4100069//P3100043  add end

//P3100043    objLot_futureHoldRequests_DeleteEffected_out strLot_futureHoldRequests_DeleteEffected_out ;
//P3100043    rc = lot_futureHoldRequests_DeleteEffected(strLot_futureHoldRequests_DeleteEffected_out, strObjCommonIn, aLotID );
//P3100043    if (rc != RC_OK)
//P3100043    {
//P3100043        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_futureHoldRequests_DeleteEffected() != RC_OK") ;
//P3100043        strGatePassReqResult.strResult = strLot_futureHoldRequests_DeleteEffected_out.strResult ;
//P3100043        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString( rc ) ;
//P3100043        return(rc);
//P3100043    }

//D4100069 restore start
//D4100083    objLot_futureHoldRequests_DeleteEffected_out strLot_futureHoldRequests_DeleteEffected_out ;
//D4100083    rc = lot_futureHoldRequests_DeleteEffected(strLot_futureHoldRequests_DeleteEffected_out, strObjCommonIn, aLotID );
//D4100083    if (rc != RC_OK)
//D4100083    {
//D4100083        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_futureHoldRequests_DeleteEffected() != RC_OK") ;
//D4100083        strGatePassReqResult.strResult = strLot_futureHoldRequests_DeleteEffected_out.strResult ;
//D4100083        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString( rc ) ;
//D4100083        return(rc);
//D4100083    }
//D4100069 restore end
//D4100083 Add Start
    /*-------------------------------*/
    /*   Get Effected Future Hold    */
    /*-------------------------------*/
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "Get Effected Future Hold") ;
    pptEffectCondition strEffectCondition;
    strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_POST );
    strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_ALL );
    objLot_futureHoldRequests_EffectByCondition_out strLot_futureHoldRequests_EffectByCondition_out;

    rc = lot_futureHoldRequests_EffectByCondition( strLot_futureHoldRequests_EffectByCondition_out,
                                                   strObjCommonIn,
                                                   aLotID,
                                                   strEffectCondition);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_futureHoldRequests_EffectByCondition() != RC_OK") ;
        strGatePassReqResult.strResult = strLot_futureHoldRequests_EffectByCondition_out.strResult ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        return( rc );
    }

    /*-------------------------------------------*/
    /*   Delete Effected Future Hold Direction   */
    /*-------------------------------------------*/
    strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_ALL );
    strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_ALL );

    objLot_futureHoldRequests_DeleteEffectedByCondition_out strLot_futureHoldRequests_DeleteEffectedByCondition_out;
    rc = lot_futureHoldRequests_DeleteEffectedByCondition( strLot_futureHoldRequests_DeleteEffectedByCondition_out,
                                                           strObjCommonIn,
                                                           aLotID,
                                                           strEffectCondition );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_futureHoldRequests_DeleteEffectedByCondition() != RC_OK") ;
        strGatePassReqResult.strResult = strLot_futureHoldRequests_DeleteEffectedByCondition_out.strResult ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        return( rc );
    }

//D4100083 Add End

    objectIdentifier releaseReasonCodeID ;

    if ( strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList.length() > 0 )  //D4100083
//D4100083    if( strLot_futureHoldRequests_DeleteEffected_out.strFutureHoldReleaseReqList.length() > 0 )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq",
                           "strLot_futureHoldRequests_DeleteEffected_out.strFutureHoldReleaseReqList.length() > 0") ;

        pptFutureHoldCancelReqResult strFutureHoldCancelReqResult ;
        rc = txFutureHoldCancelReq(strFutureHoldCancelReqResult,
                                   strObjCommonIn,
                                   aLotID,
                                   releaseReasonCodeID,
                                   SP_EntryType_Remove,
                                   strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList);  //D4100083
//D4100083                                   strLot_futureHoldRequests_DeleteEffected_out.strFutureHoldReleaseReqList ) ;
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "txFutureHoldCancelReq() != RC_OK") ;
            strGatePassReqResult.strResult = strFutureHoldCancelReqResult.strResult ;
            strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString( rc ) ;
            return(rc);
        }
    }

//DSN000081739 Add Start
    //------------------------------------
    // Update EqpMonitor job information
    //------------------------------------
    CORBA::Boolean bOpeCompFlag = FALSE;
    CORBA::Long eqpMonitorSwitch = atoi( getenv(SP_EQPMONITOR_SWITCH) );
    objLot_eqpMonitorSectionInfo_GetForJob_out strLot_eqpMonitorSectionInfo_GetForJob_out;
    if ( 1 == eqpMonitorSwitch )
    {
        PPT_METHODTRACE_V1("", "1 == SP_EQPMONITOR_SWITCH");
        objLot_lotType_Get_out strLot_lotType_Get_out;
        objLot_lotType_Get_in  strLot_lotType_Get_in;
        strLot_lotType_Get_in.lotID = aLotID;
        rc = lot_lotType_Get( strLot_lotType_Get_out,
                              strObjCommonIn,
                              strLot_lotType_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_lotType_Get() != RC_OK", rc);
            strGatePassReqResult.strResult = strLot_lotType_Get_out.strResult;
            return rc;
        }

        if ( 0 == CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_EquipmentMonitorLot)
          || 0 == CIMFWStrCmp(strLot_lotType_Get_out.lotType, SP_Lot_Type_DummyLot) )
        {
            PPT_METHODTRACE_V1("", "strLot_lotType_Get_out.lotType is Equipment Monitor or Dummy");

            pptObjCommonIn tmpObjCommonIn;
            tmpObjCommonIn = strObjCommonIn;
            if( 0 == CIMFWStrCmp( strObjCommonIn.transactionID, "TXTRC004")     //TxOpeCompWithDataReq
             || 0 == CIMFWStrCmp( strObjCommonIn.transactionID, "TXTRC055")     //TxOpeCompForInternalBufferReq
             || 0 == CIMFWStrCmp( strObjCommonIn.transactionID, "TXEWC010")     //TxForceOpeCompReq
             || 0 == CIMFWStrCmp( strObjCommonIn.transactionID, "TXEWC011")     //TxForceOpeCompForInternalBufferReq
             || 0 == CIMFWStrCmp( strObjCommonIn.transactionID, "TXEWC015")     //TxPartialOpeCompWithDataReq
             || 0 == CIMFWStrCmp( strObjCommonIn.transactionID, "TXEWC016") )   //TxPartialOpeCompForInternalBufferReq
            {
                //----- Notification !! -----------------------------------------------------------------------------------
                // In case OpeComp transactions ID is filled in strObjCommonIn.transactionID (GatePass in post process),
                // set Tx ID of TxGatePassReq into tmpObjCommonIn.transactionID temporarily
                // to process with current PO in lot_eqpMonitorSectionInfo_GetForJob and eqpMonitorJob_lot_Update.
                //---------------------------------------------------------------------------------------------------------
                PPT_METHODTRACE_V1("", "OpeComp transaction.")
                bOpeCompFlag = TRUE;
                tmpObjCommonIn.transactionID = CIMFWStrDup("TXTRC014");     //TxGatePassReq
            }
//DSN000085698 Add Start
            objLot_eqpMonitorOperationLabel_Get_out strLot_eqpMonitorOperationLabel_Get_out;
            objLot_eqpMonitorOperationLabel_Get_in  strLot_eqpMonitorOperationLabel_Get_in;
            strLot_eqpMonitorOperationLabel_Get_in.lotID = aLotID;
            rc = lot_eqpMonitorOperationLabel_Get( strLot_eqpMonitorOperationLabel_Get_out,
                                                   tmpObjCommonIn,
                                                   strLot_eqpMonitorOperationLabel_Get_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "lot_eqpMonitorOperationLabel_Get() != RC_OK", rc);
                strGatePassReqResult.strResult = strLot_eqpMonitorOperationLabel_Get_out.strResult;
                return (rc);
            }
            CORBA::Boolean bMonitorLabel = FALSE;
            for ( CORBA::ULong x=0; x<strLot_eqpMonitorOperationLabel_Get_out.strEqpMonitorLabelInfoSeq.length(); x++ )
            {
                PPT_METHODTRACE_V2("","Loop through strEqpMonitorLabelInfoSeq",x);
                if( 0 == CIMFWStrCmp(strLot_eqpMonitorOperationLabel_Get_out.strEqpMonitorLabelInfoSeq[x].operationLabel,SP_EqpMonitor_OpeLabel_Monitor) )
                {
                    PPT_METHODTRACE_V1("","Found Monitor label.");
                    bMonitorLabel = TRUE;
                    break;
                }
            }
            if ( TRUE == bMonitorLabel )
            {
                PPT_METHODTRACE_V1("","EqpMon Operation label is Monitor");
                //Increment Equipment Monitor used count by 1 for all lot�fs wafers.
                objEqpMonitorWaferUsedCountUpdate_out      strEqpMonitorWaferUsedCountUpdate_out;
                objEqpMonitorWaferUsedCountUpdate_in       strEqpMonitorWaferUsedCountUpdate_in;
                strEqpMonitorWaferUsedCountUpdate_in.lotID          = aLotID;
                strEqpMonitorWaferUsedCountUpdate_in.action         = CIMFWStrDup(SP_EQPMONUSEDCNT_ACTION_INCREMENT);
                rc = eqpMonitorWaferUsedCountUpdate(strEqpMonitorWaferUsedCountUpdate_out,strObjCommonIn,strEqpMonitorWaferUsedCountUpdate_in);
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "rc != RC_OK");
                    strGatePassReqResult.strResult = strEqpMonitorWaferUsedCountUpdate_out.strResult ;
                    return(rc);
                }
                // Create Operation History
                objEqpMonitorWaferUsedCountUpdateEvent_Make_out  strEqpMonitorWaferUsedCountUpdateEvent_Make_out;
                objEqpMonitorWaferUsedCountUpdateEvent_Make_in   strEqpMonitorWaferUsedCountUpdateEvent_Make_in;
                strEqpMonitorWaferUsedCountUpdateEvent_Make_in.lotID         = aLotID;
//PSN000097781                strEqpMonitorWaferUsedCountUpdateEvent_Make_in.transactionID = strObjCommonIn.transactionID;
                strEqpMonitorWaferUsedCountUpdateEvent_Make_in.transactionID = CIMFWStrDup("TXTRC014");                                  //PSN000097781
                strEqpMonitorWaferUsedCountUpdateEvent_Make_in.strEqpMonitorWaferUsedCountSeq   = strEqpMonitorWaferUsedCountUpdate_out.strEqpMonitorWaferUsedCountSeq;
                strEqpMonitorWaferUsedCountUpdateEvent_Make_in.claimMemo     = claimMemo;
                rc = eqpMonitorWaferUsedCountUpdateEvent_Make(strEqpMonitorWaferUsedCountUpdateEvent_Make_out, strObjCommonIn,strEqpMonitorWaferUsedCountUpdateEvent_Make_in );
                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "rc != RC_OK");
                    SET_MSG_RC( strGatePassReqResult, MSG_FAIL_MAKE_HISTORY, rc );
                    return( rc );
                }
            }
//DSN000085698 Add End

            objLot_eqpMonitorSectionInfo_GetForJob_in  strLot_eqpMonitorSectionInfo_GetForJob_in;
            strLot_eqpMonitorSectionInfo_GetForJob_in.lotID  = aLotID;
            rc = lot_eqpMonitorSectionInfo_GetForJob( strLot_eqpMonitorSectionInfo_GetForJob_out,
                                                      tmpObjCommonIn,
                                                      strLot_eqpMonitorSectionInfo_GetForJob_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "lot_eqpMonitorSectionInfo_GetForJob() != RC_OK", rc);
                strGatePassReqResult.strResult = strLot_eqpMonitorSectionInfo_GetForJob_out.strResult;
                return rc;
            }

            if ( 0 < CIMFWStrLen(strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier)
              && 1 == strLot_eqpMonitorSectionInfo_GetForJob_out.exitFlag )
            {
                PPT_METHODTRACE_V2("", "Exit operation. EqpMonitor job", strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier);

                PPT_METHODTRACE_V1("", "call eqpMonitorJob_lot_Update");
                //Update information of EqpMonitor job lot
                objEqpMonitorJob_lot_Update_out strEqpMonitorJob_lot_Update_out;
                objEqpMonitorJob_lot_Update_in  strEqpMonitorJob_lot_Update_in;
                strEqpMonitorJob_lot_Update_in.lotID     = aLotID;
                strEqpMonitorJob_lot_Update_in.operation = CIMFWStrDup(SP_EqpMonitorJob_OpeCategory_GatePass);
                rc = eqpMonitorJob_lot_Update( strEqpMonitorJob_lot_Update_out,
                                               tmpObjCommonIn,
                                               strEqpMonitorJob_lot_Update_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "eqpMonitorJob_lot_Update() != RC_OK", rc);
                    strGatePassReqResult.strResult = strEqpMonitorJob_lot_Update_out.strResult;
                    return rc;
                }

                if ( FALSE == bOpeCompFlag )
                {
                    //----- Notification !! -----------------------------------------------------------------------------------
                    // In case of not OpeComp transactions, current PO is used in txEqpMonitorJobLotRemoveReq.
                    // Then txEqpMonitorJobLotRemoveReq must be called before process_Move().
                    //---------------------------------------------------------------------------------------------------------
                    PPT_METHODTRACE_V1("", "FALSE == bOpeCompFlag");

                    //Delete Lot from EqpMonitorJob
                    pptEqpMonitorJobLotRemoveReqResult strEqpMonitorJobLotRemoveReqResult;
                    pptEqpMonitorJobLotRemoveReqInParm strEqpMonitorJobLotRemoveReqInParm;
                    strEqpMonitorJobLotRemoveReqInParm.lotID = aLotID;
                    rc = txEqpMonitorJobLotRemoveReq( strEqpMonitorJobLotRemoveReqResult,
                                                      strObjCommonIn,
                                                      strEqpMonitorJobLotRemoveReqInParm,
                                                      claimMemo );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "txEqpMonitorJobLotRemoveReq() != RC_OK", rc);
                        strGatePassReqResult.strResult = strEqpMonitorJobLotRemoveReqResult.strResult;
                        return rc;
                    }
                }
            }
        }
    }
//DSN000081739 Add End

//INN-R170002 add start
    //-------------------------------------------
    // Update contamination Info for lot
    //-------------------------------------------
    csObjLot_ContaminationInfo_Set_in strLot_ContaminationInfo_Set_in;
    strLot_ContaminationInfo_Set_in.lotID = aLotID;

    csObjLot_ContaminationInfo_Set_out strLot_ContaminationInfo_Set_out;
    rc = cs_lot_ContaminationInfo_Set( strLot_ContaminationInfo_Set_out,
                                       strObjCommonIn,
                                       strLot_ContaminationInfo_Set_in );
    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "cs_lot_ContaminationInfo_Set() rc != RC_OK", rc);
        strGatePassReqResult.strResult = strLot_ContaminationInfo_Set_out.strResult;
        return( rc );
    }
//INN-R170002 add end

    objProcess_Move_out strProcess_Move_out ;
    strProcess_Move_out.autoBankInFlag = FALSE; //P3000280
    rc = process_Move(strProcess_Move_out, strObjCommonIn, aLotID) ;
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "process_Move() != RC_OK") ;
        strGatePassReqResult.strResult = strProcess_Move_out.strResult ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        return(rc);
    }

//DSN000081739 Add Start
    if ( 0 < CIMFWStrLen(strLot_eqpMonitorSectionInfo_GetForJob_out.eqpMonitorJobID.identifier)
      && 1 == strLot_eqpMonitorSectionInfo_GetForJob_out.exitFlag
      && TRUE == bOpeCompFlag )
    {
        //----- Notification !! -----------------------------------------------------------------------------------
        // In case of OpeComp transactions, previous PO is used in txEqpMonitorJobLotRemoveReq.
        // Then txEqpMonitorJobLotRemoveReq must be called after process_Move().
        //---------------------------------------------------------------------------------------------------------
        PPT_METHODTRACE_V1("", "OpeComp transaction. Remove EqpMonitor lot from EqpMonitor job.");

        //Delete Lot from EqpMonitorJob
        pptEqpMonitorJobLotRemoveReqResult strEqpMonitorJobLotRemoveReqResult;
        pptEqpMonitorJobLotRemoveReqInParm strEqpMonitorJobLotRemoveReqInParm;
        strEqpMonitorJobLotRemoveReqInParm.lotID = aLotID;
        rc = txEqpMonitorJobLotRemoveReq( strEqpMonitorJobLotRemoveReqResult,
                                          strObjCommonIn,
                                          strEqpMonitorJobLotRemoveReqInParm,
                                          claimMemo );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "txEqpMonitorJobLotRemoveReq() != RC_OK", rc);
            strGatePassReqResult.strResult = strEqpMonitorJobLotRemoveReqResult.strResult;
            return rc;
        }
    }
//DSN000081739 Add End

    //----------------------------------------------------------------------------------------------------                       //P4100040
    // Updatemonitor group information                                                                                           //P4100040
    //----------------------------------------------------------------------------------------------------                       //P4100040
    objMonitorGroup_DeleteComp_out strMonitorGroup_DeleteComp_out ;                                                              //P4100040
    rc = monitorGroup_DeleteComp(strMonitorGroup_DeleteComp_out, strObjCommonIn, aLotID);                                        //P4100040
    if (rc != RC_OK)                                                                                                             //P4100040
    {                                                                                                                            //P4100040
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "monitorGroup_DeleteComp() != RC_OK") ;                               //P4100040
        strGatePassReqResult.strResult = strMonitorGroup_DeleteComp_out.strResult ;                                              //P4100040
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;                              //P4100040
        return(rc);                                                                                                              //P4100040
    }                                                                                                                            //P4100040
                                                                                                                                 //P4100040
    objectIdentifier aReasonCodeID ;                                                                                             //P4100040
    aReasonCodeID.identifier = CIMFWStrDup( SP_Reason_WaitingMonitorHoldRelease ) ;                                              //P4100040
                                                                                                                                 //P4100040
    CORBA::Long nCompLotSeq = strMonitorGroup_DeleteComp_out.strMonitoredCompLots.length() ;                                     //P4100040
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txGatePassReq",                                                                           //P4100040
                       "strMonitorGroup_DeleteComp_out.strMonitoredCompLots.length()", nCompLotSeq) ;                            //P4100040
                                                                                                                                 //P4100040
    CORBA::Long holdReleasedLotCount = 0;                                                                               //P4200204
    holdReleasedLotIDs.length(nCompLotSeq);                                                                             //P4200204

    for(CORBA::Long i=0; i<nCompLotSeq; i++)                                                                                     //P4100040
    {                                                                                                                            //P4100040
        if( strMonitorGroup_DeleteComp_out.strMonitoredCompLots[i].strLotHoldReleaseReqList.length() > 0 )                       //P4100040
        {                                                                                                                        //P4100040
            pptHoldLotReleaseReqResult strHoldLotReleaseReqResult ;                                                              //P4100040
            rc = txHoldLotReleaseReq( strHoldLotReleaseReqResult,                                                                //P4100040
                                      strObjCommonIn,                                                                            //P4100040
                                      strMonitorGroup_DeleteComp_out.strMonitoredCompLots[i].productLotID,                       //P4100040
                                      aReasonCodeID,                                                                             //P4100040
                                      strMonitorGroup_DeleteComp_out.strMonitoredCompLots[i].strLotHoldReleaseReqList) ;         //P4100040
            if (rc != RC_OK)                                                                                                     //P4100040
            {                                                                                                                    //P4100040
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "txHoldLotReleaseReq() != RC_OK") ;                           //P4100040
                strGatePassReqResult.strResult = strHoldLotReleaseReqResult.strResult ;                                          //P4100040
                strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;                      //P4100040
                return rc ;                                                                                                      //P4100040
            }                                                                                                                    //P4100040

//P4200204 Add Start
            //-------------------------------------
            //Return Hold Released LotID for Caller
            //-------------------------------------
            holdReleasedLotIDs[holdReleasedLotCount] = strMonitorGroup_DeleteComp_out.strMonitoredCompLots[i].productLotID;

            PPT_METHODTRACE_V3("","Hold Released LotID",holdReleasedLotCount,  holdReleasedLotIDs[holdReleasedLotCount].identifier );
            holdReleasedLotCount++;
//P4200204 Add End

//D5100184 Add Start
            //------------------------------------------
            //  Get Lot Type of Monitoring Lot
            //------------------------------------------
            objLot_type_Get_out  strLot_type_Get_out;
            rc = lot_type_Get( strLot_type_Get_out, strObjCommonIn, aLotID );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "lot_type_Get() != RC_OK", rc);
                continue;
            }

            if( CIMFWStrCmp( SP_Lot_Type_ProductionLot, strLot_type_Get_out.theLotType ) == 0 )
            {
                while( 1 )
                {
                    //------------------------------------------
                    //  Check whether GatePass is required
                    //------------------------------------------
                    PPT_METHODTRACE_V2("", "===== repeatGatePass_CheckCondition() ========", aLotID.identifier);

                    objRepeatGatePass_CheckCondition_out  strRepeatGatePass_CheckCondition_out;
                    strRepeatGatePass_CheckCondition_out.gatePassRequiredFlag = TRUE;
                    rc = repeatGatePass_CheckCondition( strRepeatGatePass_CheckCondition_out,
                                                        strObjCommonIn,
                                                        aLotID,
                                                        strMonitorGroup_DeleteComp_out.strMonitoredCompLots[i].productLotID );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "repeatGatePass_CheckCondition() != RC_OK", rc);
                        strGatePassReqResult.strResult = strRepeatGatePass_CheckCondition_out.strResult;
                        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;     //P6000118
                        return( rc );
                    }
                    if( strRepeatGatePass_CheckCondition_out.gatePassRequiredFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "gatePassRequiredFlag == FALSE");
                        break;
                    }

                    //--------------------------------
                    //  Get Monitored Lot's Info
                    //--------------------------------
                    objLot_currentOperationInfo_Get_out  strLot_currentOperationInfo_Get_out;
                    rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out,
                                                       strObjCommonIn,
                                                       strMonitorGroup_DeleteComp_out.strMonitoredCompLots[i].productLotID );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("","lot_currentOperationInfo_Get() != RC_OK", rc);
                        strGatePassReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult;
                        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;     //P6000118
                        return( rc );
                    }

                    //------------------------------------------
                    //  Call txGatePassReq()
                    //------------------------------------------
                    pptGatePassReqResult        strGatePassReqResult;
                    CORBA::Long                 seqIndex = 0;
                    pptGatePassLotInfoSequence  strGatePassLotInfo;
                    objectIdentifierSequence    dummyLotIDs;        //for Return, but it's dummy.

                    strGatePassReqResult.strGatePassLotsResult.length( 1 );
                    strGatePassLotInfo.length( 1 );
                    strGatePassLotInfo[0].lotID                  = strMonitorGroup_DeleteComp_out.strMonitoredCompLots[i].productLotID;
                    strGatePassLotInfo[0].currentRouteID         = strLot_currentOperationInfo_Get_out.routeID;
                    strGatePassLotInfo[0].currentOperationNumber = CIMFWStrDup( strLot_currentOperationInfo_Get_out.operationNumber );

                    rc = txGatePassReq( strGatePassReqResult,
                                        strObjCommonIn,
                                        seqIndex,
                                        strGatePassLotInfo,
                                        claimMemo,
                                        dummyLotIDs );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "txGatePassReq() != RC_OK", rc);
                        strGatePassReqResult.strResult = strGatePassReqResult.strResult;
                        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;     //P6000118
                        return( rc );
                    }
                }
            }
            else
            {
                continue;
            }
//D5100184 Add End
        }                                                                                                                        //P4100040
    }                                                                                                                            //P4100040

    holdReleasedLotIDs.length(holdReleasedLotCount);                              //P4200204
    PPT_METHODTRACE_V2("","HoldReleased Lot Count is", holdReleasedLotCount );    //P4200204

//D4100083 Add Start
    /*----------------------------------------------------------------------------*/
    /*   Lot FutureHold Post By Previous Operation Effect after Operation Move    */
    /*----------------------------------------------------------------------------*/
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "Lot FutureHold Post By Previous Operation Effect after Operation Move  ") ;

    if (strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList.length() > 0)
    {

        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "strLotHoldReqList.length() > 0") ;

        /*-----------------------------------------------------*/
        /*   Convert OpeNo, RouteID from previous to current   */
        /*-----------------------------------------------------*/
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "Convert OpeNo from previous to current") ;

        objLot_futureHold_EffectedProcessConversion_out strLot_futureHold_EffectedProcessConversion_out;
        rc = lot_futureHold_EffectedProcessConversion( strLot_futureHold_EffectedProcessConversion_out,
                                                       strObjCommonIn,
                                                       strLot_futureHoldRequests_EffectByCondition_out.lotID,
                                                       strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_futureHold_EffectedProcessConversion() != RC_OK") ;
            strGatePassReqResult.strResult = strLot_futureHold_EffectedProcessConversion_out.strResult ;
            strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
            return( rc );
        }

        pptHoldLotReqResult strHoldLotReqResult ;

        rc = txHoldLotReq( strHoldLotReqResult,
                           strObjCommonIn ,
                           strLot_futureHoldRequests_EffectByCondition_out.lotID ,
                           strLot_futureHold_EffectedProcessConversion_out.strLotHoldReqList ) ;

        if ( rc != RC_OK && rc != RC_EXIST_SAME_HOLD )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "txHoldLotReq() != RC_OK") ;
            strGatePassReqResult.strResult = strHoldLotReqResult.strResult ;
            strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
            return( rc );
        }
    }

//D4100083 Add End

//D4100069// (D3000118,D3000119)  add start
//D4100069    objLot_CheckForLCFR_out strLot_CheckForLCFR_out ;
//D4100069    rc = lot_CheckForLCFR(strLot_CheckForLCFR_out, strObjCommonIn, aLotID, SP_LotCustomize_DBRECORD );
//D4100069    if(rc == RC_OK)
//D4100069    {
//D4100069        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_CheckForLCFR() = RC_OK") ;
//D4100069        objProcess_MoveForLCFR_out strProcess_MoveForLCFR_out ;
//D4100069        strProcess_MoveForLCFR_out.autoBankInFlag = FALSE;       //P4000015
//D4100069        rc = process_MoveForLCFR(strProcess_MoveForLCFR_out , strObjCommonIn, aLotID);
//D4100069        switch ( rc )
//D4100069        {
//D4100069            case RC_OK:
//D4100069            {
//D4100069                 PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "process_MoveForLCFR() = RC_OK") ;
//D4100069                 if( strProcess_MoveForLCFR_out.autoBankInFlag == TRUE)
//D4100069                 {
//D4100069                     strProcess_Move_out.autoBankInFlag = TRUE;
//D4100069                 }
//D4100069            }
//D4100069            break;
//D4100069            default:
//D4100069            {
//D4100069                 PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "process_MoveForLCFR = default")
//D4100069
//D4100069                 strGatePassReqResult.strResult = strProcess_MoveForLCFR_out.strResult ;
//D4100069                 strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString( rc ) ;
//D4100069
//D4100069                 objectIdentifier CurrentRouteID;
//D4100069                 objLot_currentRouteID_Get_out strLot_currentRouteID_Get_out;
//D4100069
//D4100069                 rc = lot_currentRouteID_Get(  strLot_currentRouteID_Get_out,
//D4100069                                               strObjCommonIn,
//D4100069                                               aLotID);
//D4100069
//D4100069                 if( rc != RC_OK )
//D4100069                 {
//D4100069                     PPT_METHODTRACE_V2("CS_PPTManager_i:: txGatePassReq", "lot_currentRouteID_Get() != RC_OK",rc);
//D4100069
//D4100069                     strGatePassReqResult.strResult = strLot_currentRouteID_Get_out.strResult;
//D4100069                     strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString( rc ) ;        //P4000090
//D4100069                     return( rc );
//D4100069                 }
//D4100069                 CurrentRouteID = strLot_currentRouteID_Get_out.currentRouteID;
//D4100069
//D4100069//P3100060                 PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq",
//D4100069//P3100060                                "process_MoveForLCFR() rc = RC_ROUTEID_DELETED | RC_OPENO_DELETED  ") ;
//D4100069
//D4100069                 pptHoldLotReqResult strHoldLotReqResult ;
//D4100069                 aReasonCodeID.identifier = CIMFWStrDup( SP_Reason_LCFR_Hold ) ;
//D4100069
//D4100069                 pptHoldListSequence strLotHoldReqList ;
//D4100069                 strLotHoldReqList.length( 1 ) ;
//D4100069                 strLotHoldReqList[0].holdType                 = CIMFWStrDup( SP_HoldType_LCFR_Route_Deleted ) ;
//D4100069                 strLotHoldReqList[0].holdReasonCodeID         = aReasonCodeID;
//D4100069                 strLotHoldReqList[0].holdUserID               = strObjCommonIn.strUser.userID;
//D4100069                 strLotHoldReqList[0].responsibleOperationMark = CIMFWStrDup( SP_ResponsibleOperation_Current );
//D4100069                 strLotHoldReqList[0].routeID                  = CurrentRouteID ;
//D4100069                 strLotHoldReqList[0].operationNumber          = CIMFWStrDup( SP_LotCustomize_Dummy_OperationNumber );
//D4100069                 strLotHoldReqList[0].relatedLotID             = aLotID ;
//D4100069                 strLotHoldReqList[0].claimMemo                = CIMFWStrDup( "");
//D4100069                 rc = txHoldLotReq(strHoldLotReqResult,strObjCommonIn, aLotID, strLotHoldReqList) ;
//D4100069                 if (rc != RC_OK)
//D4100069                 {
//D4100069                    PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "txHoldLotReq() rc != RC_OK") ;
//D4100069                    // set returned strResult to strResult of out parameter
//D4100069                    strGatePassReqResult.strResult = strHoldLotReqResult.strResult ;
//D4100069                    strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
//D4100069                    return(rc);
//D4100069                 }
//D4100069            }
//D4100069            break;
//D4100069        }
//D4100069    }
//D4100069// (D3000118,D3000119)   add end

//D4100069//P3100043 ADD START
//D4100083    objLot_futureHoldRequests_Effect_out strLot_futureHoldRequests_Effect_out ;
//D4100069    {
//D4100069        objLot_CheckForLCFR_out strLot_CheckForLCFR_out;
//D4100069        rc = lot_CheckForLCFR(  strLot_CheckForLCFR_out,strObjCommonIn,aLotID,SP_LotCustomize_DBRECORD );
//D4100069        if ( rc != RC_OK )
//D4100069        {
//D4100069            PPT_METHODTRACE_V2("CS_PPTManager_i:: txGatePassReq", "lot_CheckForLCFR() != RC_OK", rc);
//D4100069            rc = lot_futureHoldRequests_Effect(strLot_futureHoldRequests_Effect_out, strObjCommonIn, aLotID) ;
//D4100069            if(rc != RC_OK)
//D4100069            {
//D4100069                PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_futureHoldRequests_Effect() != RC_OK") ;
//D4100069                strGatePassReqResult.strResult = strLot_futureHoldRequests_Effect_out.strResult ;
//D4100069                strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
//D4100069                return(rc);
//D4100069            }
//D4100069        }
//D4100069        else
//D4100069        {
//D4100069            PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_CheckForLCFR() == RC_OK");
//D4100069
//D4100069            objLot_futureHoldRequests_EffectForLCFR_out  strLot_futureHoldRequests_EffectForLCFR_out;
//D4100069            rc = lot_futureHoldRequests_EffectForLCFR( strLot_futureHoldRequests_EffectForLCFR_out, strObjCommonIn, aLotID );
//D4100069            if ( rc == RC_OK )
//D4100069            {
//D4100069                PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_futureHoldRequests_EffectForLCFR() == RC_OK");
//D4100069                strLot_futureHoldRequests_Effect_out.strLotHoldReqList = strLot_futureHoldRequests_EffectForLCFR_out.strLotHoldReqList;
//D4100069            }
//D4100069            else
//D4100069            {
//D4100069                PPT_METHODTRACE_V2("CS_PPTManager_i:: txGatePassReq", "lot_futureHoldRequests_EffectForLCFR() != RC_OK", rc);
//D4100069                strGatePassReqResult.strResult = strLot_futureHoldRequests_EffectForLCFR_out.strResult;
//D4100069                strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
//D4100069                return( rc );
//D4100069            }
//D4100069        }
//D4100069
//D4100069    }

//P3100043    rc = lot_futureHoldRequests_Effect(strLot_futureHoldRequests_Effect_out, strObjCommonIn, aLotID);
//P3100043    if (rc != RC_OK)
//P3100043    {
//P3100043        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_futureHoldRequests_Effect() != RC_OK") ;
//P3100043        strGatePassReqResult.strResult = strLot_futureHoldRequests_Effect_out.strResult ;
//P3100043        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
//P3100043        return(rc);
//P3100043    }
//D4100069 restore start
//D4100083    rc = lot_futureHoldRequests_Effect(strLot_futureHoldRequests_Effect_out, strObjCommonIn, aLotID);
//D4100083    if (rc != RC_OK)
//D4100083    {
//D4100083        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_futureHoldRequests_Effect() != RC_OK") ;
//D4100083        strGatePassReqResult.strResult = strLot_futureHoldRequests_Effect_out.strResult ;
//D4100083        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
//D4100083        return(rc);
//D4100083    }
//D4100069 restore end
//D4100069//P3100043 ADD END

//D4100083 Add Start
    /*------------------------------------------------------------------*/
    /*   Get Effected Future Hold PRE of Current after Operation Move   */
    /*------------------------------------------------------------------*/
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "Get Effected Future Hold PRE of Current after Operation Move") ;

    strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_PRE );
    strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_ALL );

    rc = lot_futureHoldRequests_EffectByCondition( strLot_futureHoldRequests_EffectByCondition_out,
                                                   strObjCommonIn,
                                                   aLotID,
                                                   strEffectCondition);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_futureHoldRequests_EffectByCondition() != RC_OK") ;
        strGatePassReqResult.strResult = strLot_futureHoldRequests_EffectByCondition_out.strResult ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        return( rc );
    }

    if( strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList.length() > 0 )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList.length() > 0") ;

//D4100083 Add End

//D4100083    if ( strLot_futureHoldRequests_Effect_out.strLotHoldReqList.length() > 0 )
//D4100083    {
//D4100083        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq",
//D4100083                           "strLot_futureHoldRequests_Effect_out.strLotHoldReqList.length() > 0") ;

        pptHoldLotReqResult strHoldLotReqResult ;
        rc = txHoldLotReq (strHoldLotReqResult,
                           strObjCommonIn,
                           aLotID,
                           strLot_futureHoldRequests_EffectByCondition_out.strLotHoldReqList ) ;  //D4100083
//D4100083                           strLot_futureHoldRequests_Effect_out.strLotHoldReqList) ;
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "txHoldLotReq() != RC_OK") ;
            strGatePassReqResult.strResult = strHoldLotReqResult.strResult ;
            strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
            return(rc);
        }
    }

//D4100083 Add Start
    /*------------------------------------------------------------------------------------*/
    /*   Get Effected Future Hold Cancel PRE and SINGLE of Current after Operation Move   */
    /*------------------------------------------------------------------------------------*/
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "Get Effected Future Hold Cancel PRE and SINGLE of Current after Operation Move") ;

    strEffectCondition.phase        = CIMFWStrDup( SP_FutureHold_PRE );
    strEffectCondition.triggerLevel = CIMFWStrDup( SP_FutureHold_SINGLE );

    rc = lot_futureHoldRequests_DeleteEffectedByCondition( strLot_futureHoldRequests_DeleteEffectedByCondition_out,
                                                           strObjCommonIn,
                                                           aLotID,
                                                           strEffectCondition );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lot_futureHoldRequests_DeleteEffectedByCondition() != RC_OK") ;
        strGatePassReqResult.strResult = strLot_futureHoldRequests_DeleteEffectedByCondition_out.strResult ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        return( rc );
    }

    if ( strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList.length() > 0 )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList.length() > 0") ;
        pptFutureHoldCancelReqResult strFutureHoldCancelReqResult ;
        rc = txFutureHoldCancelReq( strFutureHoldCancelReqResult,
                                    strObjCommonIn,
                                    aLotID,
                                    releaseReasonCodeID,
                                    SP_EntryType_Remove,
                                    strLot_futureHoldRequests_DeleteEffectedByCondition_out.strFutureHoldReleaseReqList);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "txFutureHoldCancelReq() != RC_OK") ;
            strGatePassReqResult.strResult = strFutureHoldCancelReqResult.strResult ;
            strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
            return( rc );
        }
    }

//D4100083 Add End

    /*---------------------------------------*/
    /*   Update Cassette's MultiLotType      */
    /*---------------------------------------*/
    objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
    rc = cassette_multiLotType_Update(strCassette_multiLotType_Update_out, strObjCommonIn, aCassetteID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "cassette_multiLotType_Update() != RC_OK") ;
        strGatePassReqResult.strResult = strCassette_multiLotType_Update_out.strResult ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        return(rc);
    }

#if 1
//D4000016 Add Start
    //--------------------------------------------------------------------------------------------------
    // UpDate RequiredCassetteCategory
    //--------------------------------------------------------------------------------------------------
    objLot_CassetteCategory_UpdateForContaminationControl_out   strLot_CassetteCategory_UpdateForContaminationControl_out;
    rc = lot_CassetteCategory_UpdateForContaminationControl( strLot_CassetteCategory_UpdateForContaminationControl_out,
                                                             strObjCommonIn,
                                                             aLotID );

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","lot_CassetteCategory_UpdateForContaminationControl != RC_OK");
        strGatePassReqResult.strResult = strLot_CassetteCategory_UpdateForContaminationControl_out.strResult;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;          //P4000090
        return rc;
    }
//D4000016 Add end
#endif

//INN-R170002 Add Start
    //--------------------------------------------------------------------------------------------------
    // Check Contamination Level
    //--------------------------------------------------------------------------------------------------
    csObjLot_ContaminationInfo_CheckForMove_in strLot_ContaminationInfo_CheckForMove_in;
    strLot_ContaminationInfo_CheckForMove_in.lotID = aLotID;
    strLot_ContaminationInfo_CheckForMove_in.carrierID = aCassetteID;
    csObjLot_ContaminationInfo_CheckForMove_out strLot_ContaminationInfo_CheckForMove_out;
    rc = cs_lot_ContaminationInfo_CheckForMove( strLot_ContaminationInfo_CheckForMove_out,
                                                strObjCommonIn,
                                                strLot_ContaminationInfo_CheckForMove_in );

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","cs_lot_ContaminationInfo_CheckForMove != RC_OK");
        strGatePassReqResult.strResult = strLot_ContaminationInfo_CheckForMove_out.strResult;
        return rc;
    }

    if(strLot_ContaminationInfo_CheckForMove_out.holdReqFlag == TRUE)
    {
        pptHoldLotReqResult strHoldLotReqResult;
        pptHoldListSequence strLotHoldReqList( 1 );
        strLotHoldReqList.length( 1 );

        strLotHoldReqList[0].holdType                    = CIMFWStrDup( SP_HoldType_LotHold );
        strLotHoldReqList[0].holdReasonCodeID.identifier = CIMFWStrDup( CS_SP_Reason_ContaminationMismatchHold );
        strLotHoldReqList[0].holdUserID                  = strObjCommonIn.strUser.userID;
        strLotHoldReqList[0].responsibleOperationMark    = CIMFWStrDup( SP_ResponsibleOperation_Current );
        strLotHoldReqList[0].claimMemo                   = claimMemo;

        rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn,
                           aLotID,
                           strLotHoldReqList );

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
            strGatePassReqResult.strResult = strHoldLotReqResult.strResult ;
            return rc ;
        }
        else
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() == RC_OK For LotHold") ;
        }
    }
//INN-R170002 Add End

//D40A0027 add start
    //--------------------------------------//
    //   Call txProcessLagTimeUpdateReq()   //
    //--------------------------------------//
    PPT_METHODTRACE_V1("", "Call txProcessLagTimeUpdateReq()...") ;
    pptProcessLagTimeUpdateReqResult strProcessLagTimeUpdateReqResult;
    rc = txProcessLagTimeUpdateReq( strProcessLagTimeUpdateReqResult,
                                    strObjCommonIn,
                                    aLotID,
                                    SP_ProcessLagTime_Action_Set,
                                    claimMemo );
    if ( rc != RC_OK)
    {
        PPT_METHODTRACE_V1("", "txProcessLagTimeUpdateReq() != RC_OK");
        strGatePassReqResult.strResult = strProcessLagTimeUpdateReqResult.strResult;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc);
        return( rc );
    }
//D40A0027 add end

//D4200029 Add Start
    //-----------------------//
    //     Process Hold      //
    //-----------------------//
    PPT_METHODTRACE_V1("","Call txProcessHoldExecReq()");
    pptProcessHoldExecReqResult strProcessHoldExecReqResult;

    rc = txProcessHoldExecReq( strProcessHoldExecReqResult,
                               strObjCommonIn,
                               aLotID,
                               claimMemo );

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","txProcessHoldExecReq() != RC_OK", rc );
        strGatePassReqResult.strResult = strProcessHoldExecReqResult.strResult ;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;     //P6000118
        return( rc );
    }
//D4200029 Add End

    /*------------------------------------------------------------------------*/
    /*   Make History                                                         */
    /*------------------------------------------------------------------------*/
    objLotOperationMoveEvent_MakeGatePass_out strLotOperationMoveEvent_MakeGatePass_out;
    rc = lotOperationMoveEvent_MakeGatePass(strLotOperationMoveEvent_MakeGatePass_out,
                                            strObjCommonIn,
                                            "TXTRC014",
                                            aLotID,
                                            claimMemo) ;
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "lotOperationMoveEvent_MakeGatePass() != RC_OK") ;
//P5000145        PPT_SET_MSG_RC_KEY(strGatePassReqResult,MSG_FAIL_MAKE_HISTORY,rc,aLotID.identifier) ;
        SET_MSG_RC( strGatePassReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
        return(rc);
    }

//D4100120 Add Start
    /*-------------------------------------*/
    /*   Execute Future Action Procedure   */
    /*-------------------------------------*/
    if (strSchdlChangeReservation_CheckForAction_out.existFlag == True)
    {
        pptSchdlChangeReservationExecuteReqResult strSchdlChangeReservationExecuteReqResult;
//DSIV00002435        pptRescheduledLotAttributesSequence strRescheduledLotAttributes;
        pptRescheduledLotAttributesSequence__110 strRescheduledLotAttributes;           //DSIV00002435
        strRescheduledLotAttributes.length(1);
        strRescheduledLotAttributes[0].lotID                  = aLotID;
        strRescheduledLotAttributes[0].productID              = strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation.productID;
        strRescheduledLotAttributes[0].routeID                = strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation.routeID;
        strRescheduledLotAttributes[0].currentOperationNumber = strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation.operationNumber;
        strRescheduledLotAttributes[0].subLotType             = strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation.subLotType;      //DSIV00002435

//P5100473 Add Start
        //------------------------------------------------------------------------//
        // Get current RouteID by lotID                                           //
        //------------------------------------------------------------------------//
        objLot_currentRouteID_Get_out       strLot_currentRouteID_Get_out;
        rc = lot_currentRouteID_Get( strLot_currentRouteID_Get_out,
                                     strObjCommonIn,
                                     aLotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_currentRouteID_Get() != RC_OK :", rc);
            strGatePassReqResult.strResult = strLot_currentRouteID_Get_out.strResult;
            strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;     //P6000118
            return( rc );
        }

        strRescheduledLotAttributes[0].originalRouteID = strLot_currentRouteID_Get_out.currentRouteID.identifier;
        PPT_METHODTRACE_V2( "", "OriginalRouteID", strRescheduledLotAttributes[0].originalRouteID );

        //------------------------------------------------------------------------//
        // Get current oparation No. by lotID                                     //
        //------------------------------------------------------------------------//
        objLot_currentOpeNo_Get_out strLot_currentOpeNo_Get_out;
        rc = lot_currentOpeNo_Get(strLot_currentOpeNo_Get_out,
                                  strObjCommonIn,
                                  aLotID);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V2("", "lot_currentOpeNo_Get() != RC_OK",rc);
            strGatePassReqResult.strResult = strLot_currentOpeNo_Get_out.strResult;
            strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;     //P6000118
            return(rc);
        }

        strRescheduledLotAttributes[0].originalOperationNumber = CIMFWStrDup( strLot_currentOpeNo_Get_out.currentOperationNumber );
        PPT_METHODTRACE_V2("","OroginalOperationNumber",strRescheduledLotAttributes[0].originalOperationNumber);
//P5100473 Add End

//DSIV00002435        rc = txSchdlChangeReservationExecuteReq(strSchdlChangeReservationExecuteReqResult,
        rc = txSchdlChangeReservationExecuteReq__110(strSchdlChangeReservationExecuteReqResult,     //DSIV00002435
                                                strObjCommonIn,
                                                strRescheduledLotAttributes,
                                                strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation.eventID);

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "txSchdlChangeReservationExecuteReq() != RC_OK");
            strGatePassReqResult.strResult = strSchdlChangeReservationExecuteReqResult.strResult;
            strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc);
            return(rc);
        }

        objSchdlChangeReservation_applyCount_Increase_out strSchdlChangeReservation_applyCount_Increase_out;
//DSIV00002435        rc = schdlChangeReservation_applyCount_IncreaseDR(strSchdlChangeReservation_applyCount_Increase_out,
//DSIV00002435                                                          strObjCommonIn,
//DSIV00002435                                                          strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation);
//DSIV00002435 add start
        objSchdlChangeReservation_applyCount_IncreaseDR_in__110  strSchdlChangeReservation_applyCount_IncreaseDR_in;
        strSchdlChangeReservation_applyCount_IncreaseDR_in.strSchdlChangeReservation = strSchdlChangeReservation_CheckForAction_out.strSchdlChangeReservation;
        rc = schdlChangeReservation_applyCount_IncreaseDR__110( strSchdlChangeReservation_applyCount_Increase_out,
                                                                strObjCommonIn,
                                                                strSchdlChangeReservation_applyCount_IncreaseDR_in );
//DSIV00002435 add end
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "schdlChangeReservation_applyCount_IncreaseDR() != RC_OK");
            strGatePassReqResult.strResult = strSchdlChangeReservation_applyCount_Increase_out.strResult;
            strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc);
            return(rc);
        }
    }
//D4100120 Add End

//PSIV00001188 Add Start
    /*---------------------------------------------------------------*/
    /*   Auto-Bank-In Procedure                                      */
    /*---------------------------------------------------------------*/
    objLot_CheckConditionForAutoBankIn_out  strLot_CheckConditionForAutoBankIn_out;
    objLot_CheckConditionForAutoBankIn_in   strLot_CheckConditionForAutoBankIn_in;
    strLot_CheckConditionForAutoBankIn_in.lotID = aLotID;

    rc = lot_CheckConditionForAutoBankIn( strLot_CheckConditionForAutoBankIn_out,
                                          strObjCommonIn,
                                          strLot_CheckConditionForAutoBankIn_in  );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","lot_CheckConditionForAutoBankIn() != RC_OK", rc);
        strGatePassReqResult.strResult = strLot_CheckConditionForAutoBankIn_out.strResult;
        strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc);
        return(rc);
    }

    if (strLot_CheckConditionForAutoBankIn_out.autoBankInFlag)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "strLot_CheckConditionForAutoBankIn_out.autoBankInFlag == TRUE");
//PSIV00001188 Add End
//PSIV00001188    if (strProcess_Move_out.autoBankInFlag == TRUE)
//PSIV00001188    {
//PSIV00001188        PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "strProcess_Move_out.autoBankInFlag == TRUE") ;

//D4100170   CORBA::Long nLen = lotID.length();
//D4100170 add start
        objectIdentifierSequence lotID(1);
        lotID.length(1);
        lotID[0] = strGatePassLotInfo[seqIndex].lotID;
//D4100170 add end

        pptBankInReqResult strBankInReqResult ;
//D4100170   pptBankInReqResult.strBankInLotResult.length(nLen) ;
//D4100170   rc = txBankInReq(strBankInReqResult, strObjCommonIn, seqIndex, lotID, claimMemo);
        strBankInReqResult.strBankInLotResult.length(1);  //P4100492
        rc = txBankInReq(strBankInReqResult, strObjCommonIn, 0, lotID, claimMemo);  //D4100170
        if( rc == RC_INVALID_LOT_HOLDSTAT )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i:: txGatePassReq","txBankInReq() == RC_INVALID_LOT_HOLDSTAT" ,rc) ;
//P5000145            PPT_SET_MSG_RC_KEY(strGatePassReqResult,MSG_OK, RC_OK, aLotID.identifier) ;
            SET_MSG_RC( strGatePassReqResult, MSG_OK, RC_OK );        //P5000145
        }
        else if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txGatePassReq", "txBankInReq() != RC_OK") ;
            PPT_SET_MSG_RC_KEY(strGatePassReqResult,MSG_FAIL_MAKE_PFHLHS,rc,aLotID.identifier) ;
            strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(rc) ;
            return(rc);
        }
    }

    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
    strGatePassReqResult.strGatePassLotsResult[seqIndex].returnCode = ConvertLongtoString(RC_OK) ;

    SET_MSG_RC(strGatePassReqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txGatePassReq") ;
    return(RC_OK);
}

