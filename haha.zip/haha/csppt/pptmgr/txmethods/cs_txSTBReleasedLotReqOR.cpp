#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txSTBReleasedLotReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:34:48 [ 7/13/07 21:34:49 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txSTBReleasedLotReqOR.cpp
//

#include "cs_pptmgr.hpp"
#include "penin.hh"

// Class: CS_PPTManager
//
// Service: txSTBReleasedLotReq()
//
// Change history:
// Date       Defect#    Person         Comments
// ---------- ---------- -------------- -------------------------------------------
// 2000/08/10            O.Sugiyama     Initial Release
// 2000/09/08 P3000080   K.Matsuei      Bug Fix
// 2000/10/23 P3000280   S.Kawabe       Boolean variable initialize 
// 2001/07/12 D4000016   M.Shimizu      Contamination Control(Copper/Non Copper [R40 Core])
// 2001/09/19 D4000177   M.Ameshita     Add to make reticle set chnage event.
// 2002/07/30 D4200029   K.Kimura       Process Hold Control
// 2005/10/22 D6000025   K.Murakami     eBroker Migration.
// 2005/03/30 P6000084   K.Kido         Add check for Scrapped Wafer.
// 2005/09/26 D6000455   F.Masada       Add object_Lock for PosProductRequest. 
// 2007/06/13 D9000005   H.Hotta        WaferSorter automation support.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2013/05/10 DSN000071674 C.Mo           Remove part of the EI state limitation
// 2014/01/21 PSN000083176 C.Mo           Data inconsistency might occur when start lot reservation is called together with lot operation transactions for the same cassette
// 2015/10/02 DSN000096141 S.Kawabe       Rework responsible operation tracking at wafer level
// 2016/05/17 PSN000102296 C.Mo           STB doesn't check sorter job as source cassette
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/11 INN-R170002  JQ.Shao        Contamination Control
// 2017/10/10 INN-R170003  YangXigang     Durable Management Enhancement
//
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    pptSTBReleasedLotReqResult&     strSTBReleasedLotReqResult
//    const pptObjCommonIn&           strObjCommonIn
//    const objectIdentifier&         productRequestID
//    const pptNewLotAttributes&      strNewLotAttributes
//    const char *                    claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i:: txSTBReleasedLotReq (
    pptSTBReleasedLotReqResult&     strSTBReleasedLotReqResult, 
    const pptObjCommonIn&           strObjCommonIn, 
    const objectIdentifier&         productRequestID, 
    const pptNewLotAttributes&      strNewLotAttributes, 
//D6000025     const char *                    claimMemo, 
//D6000025     CORBA::Environment &            IT_env)
    const char *                    claimMemo  //D6000025
    CORBAENV_LAST_CPP)                         //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txSTBReleasedLotReq");
    CORBA::Long rc = RC_OK ;

    //----------------------------------------------------
    // Copy input parameter and use tmpNewLotAttributes
    // inside of this method
    //----------------------------------------------------
    pptNewLotAttributes tmpNewLotAttributes;
    tmpNewLotAttributes = strNewLotAttributes;

    //D6000455 add start
    //--------------------------------
    // Lock objects of product request
    //--------------------------------
    PPT_METHODTRACE_V1("", "Lock objects of product request to be updated");
    objObject_Lock_out strObject_Lock_out;
    rc = object_Lock(strObject_Lock_out, strObjCommonIn,
                     productRequestID,
                     SP_ClassName_PosProductRequest);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "object_Lock(productRequestID) rc != RC_OK");
        strSTBReleasedLotReqResult.strResult = strObject_Lock_out.strResult;
        return(rc);
    }
    //D6000455 add end

//DSN000071674 add start
    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );

    CORBA::Boolean updateControlJobFlag = FALSE;
    CORBA::Long lockMode = 0; //PSN000083176

    objCassette_transferState_Get_out strCassetteTransferState;

    if ( 0 == lotOperationEIcheck )
    {
        //-------------------------------
        // Get carrier transfer status
        //-------------------------------
        rc = cassette_transferState_Get(strCassetteTransferState, strObjCommonIn,
                                        tmpNewLotAttributes.cassetteID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "rc != RC_OK");
            strSTBReleasedLotReqResult.strResult = strCassetteTransferState.strResult ;
            return( rc );
        }

        /*------------------------------------*/
        /*   Get equipment ID in Cassette     */
        /*------------------------------------*/
        objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
        rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                       strObjCommonIn,
                                       tmpNewLotAttributes.cassetteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "cassette_equipmentID_Get != RC_OK", rc);
            strSTBReleasedLotReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
            return( rc );
        }

        //-------------------------------
        // Get required equipment lock mode
        //-------------------------------
        objObject_lockMode_Get_out strObject_lockMode_Get_out;
        objObject_lockMode_Get_in  strObject_lockMode_Get_in;
        strObject_lockMode_Get_in.objectID           = strCassette_equipmentID_Get_out.equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXTRC001" ); // TxSTBReleasedLotReq
        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strSTBReleasedLotReqResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }

//PSN000083176        CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
        lockMode = strObject_lockMode_Get_out.lockMode; //PSN000083176
        PPT_METHODTRACE_V2( "", "lockMode", lockMode );

        //INN-R170003 if ( 0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) )
        //INN-R170003 add start
        if( 0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) ||
            0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentOut)||
            0 == CIMFWStrCmp(strCassetteTransferState.transferState, CS_TRANS_STATE_PORT_IN)
          )
        //INN-R170003 add end
        {
            PPT_METHODTRACE_V2("", "strCassetteTransferState.transferState = ", strCassetteTransferState.transferState);
            updateControlJobFlag = TRUE;
            if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
            {
                objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
                objAdvanced_object_Lock_in strAdvanced_object_Lock_in;

                // Lock Equipment Main Object
                stringSequence dummySeq;
                dummySeq.length(0);
                strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
                strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
                strAdvanced_object_Lock_in.keySeq     = dummySeq;

                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strSTBReleasedLotReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }

                // Lock Equipment LoadCassette Element (Write)
                stringSequence loadCastSeq;
                loadCastSeq.length(1);
                loadCastSeq[0] = tmpNewLotAttributes.cassetteID.identifier;
                strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
                strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
                strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strSTBReleasedLotReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }
            }
            else
            {
                /*--------------------------------*/
                /*   Lock Macihne object          */
                /*--------------------------------*/
                rc = object_Lock( strObject_Lock_out, strObjCommonIn, strCassette_equipmentID_Get_out.equipmentID, SP_ClassName_PosMachine );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc) ;
                    strSTBReleasedLotReqResult.strResult = strObject_Lock_out.strResult ;
                    return( rc );
                }
            }
        }

//PSN000083176        if ( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176        {
//PSN000083176            //---------------------------------
//PSN000083176            //   Get Cassette's ControlJobID
//PSN000083176            //---------------------------------
//PSN000083176            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

//PSN000083176            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
//PSN000083176                                            strObjCommonIn,
//PSN000083176                                            tmpNewLotAttributes.cassetteID );
//PSN000083176            if ( rc != RC_OK )
//PSN000083176            {
//PSN000083176                PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
//PSN000083176                strSTBReleasedLotReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
//PSN000083176                return( rc );
//PSN000083176            }
//PSN000083176            if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
//PSN000083176            {
//PSN000083176                PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
//PSN000083176                updateControlJobFlag = TRUE;

//PSN000083176                if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176                {
//PSN000083176                    /*------------------------------*/
//PSN000083176                    /*   Lock ControlJob Object     */
//PSN000083176                    /*------------------------------*/
//PSN000083176                    rc = object_Lock( strObject_Lock_out,
//PSN000083176                                      strObjCommonIn, 
//PSN000083176                                      strCassette_controlJobID_Get_out.controlJobID, 
//PSN000083176                                      SP_ClassName_PosControlJob );
//PSN000083176                    if ( rc != RC_OK )
//PSN000083176                    {
//PSN000083176                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
//PSN000083176                        strSTBReleasedLotReqResult.strResult = strObject_Lock_out.strResult;
//PSN000083176                        return( rc );
//PSN000083176                    }
//PSN000083176                }
//PSN000083176            }
//PSN000083176        }
    }
//DSN000071674 add end
   
//P6000084 add start
    //--------------------------------
    //   Lock objects of cassette to be updated
    // for tmpNewLotAttributes.cassetteID
    //--------------------------------
    PPT_METHODTRACE_V1("", "Lock objects of cassette to be updated");
    //D6000455 objObject_Lock_out strObject_Lock_out;
    rc = object_Lock(strObject_Lock_out, strObjCommonIn,
                     tmpNewLotAttributes.cassetteID,
                     SP_ClassName_PosCassette);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "object_Lock(tmpNewLotAttributes.cassetteID) rc != RC_OK");
        strSTBReleasedLotReqResult.strResult = strObject_Lock_out.strResult;
        return(rc);
    }
//P6000084 add end
//PSN000083176 add start
    if ( 0 == lotOperationEIcheck )
    {
        if ( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
        {
            //---------------------------------
            //   Get Cassette's ControlJobID
            //---------------------------------
            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                            strObjCommonIn,
                                            tmpNewLotAttributes.cassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
                strSTBReleasedLotReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
                return( rc );
            }
            if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
            {
                PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
                updateControlJobFlag = TRUE;

                if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
                {
                    /*------------------------------*/
                    /*   Lock ControlJob Object     */
                    /*------------------------------*/
                    rc = object_Lock( strObject_Lock_out,
                                      strObjCommonIn, 
                                      strCassette_controlJobID_Get_out.controlJobID, 
                                      SP_ClassName_PosControlJob );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                        strSTBReleasedLotReqResult.strResult = strObject_Lock_out.strResult;
                        return( rc );
                    }
                }
            }
        }
    }
//PSN000083176 add end
    //--------------------------------
    //   Lock objects of source lot
    //--------------------------------
    CORBA::Long i = 0;
    CORBA::Long nLen = tmpNewLotAttributes.strNewWaferAttributes.length();
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txSTBReleasedLotReq", "nLen", nLen);
    for (i=0; i<nLen; i++)   // use 'i' for loop counter
    {
        if (i>0 &&
            CIMFWStrCmp(tmpNewLotAttributes.strNewWaferAttributes[  i].sourceLotID.identifier, 
                        tmpNewLotAttributes.strNewWaferAttributes[i-1].sourceLotID.identifier) == 0)
        {
            continue;
        }
//DSN000071674        objObject_Lock_out strObject_Lock_out;
        rc = object_Lock(strObject_Lock_out, strObjCommonIn, 
                         tmpNewLotAttributes.strNewWaferAttributes[i].sourceLotID,
                         SP_ClassName_PosLot); 
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "object_Lock() != RC_OK");
            strSTBReleasedLotReqResult.strResult = strObject_Lock_out.strResult;
            return(rc);
        }

//DSN000071674 add start
        if ( 0 == lotOperationEIcheck )
        {
            //----------------------------------
            //   Check Lot's Control Job ID
            //----------------------------------
            objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
            rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, tmpNewLotAttributes.strNewWaferAttributes[i].sourceLotID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "lot_controlJobID_Get() != RC_OK", rc);
                strSTBReleasedLotReqResult.strResult = strLot_controlJobID_Get_out.strResult;
                return( rc );
            }
            if ( 0 == CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) )
            {
                PPT_METHODTRACE_V1("", "strLot_controlJobID_Get_out.controlJobID.identifier == 0");
            }
            else
            {
                PPT_METHODTRACE_V1("", "strLot_controlJobID_Get_out.controlJobID.identifier != 0");
                PPT_SET_MSG_RC_KEY2( strSTBReleasedLotReqResult,
                                     MSG_LOT_CTLJOBID_FILLED,
                                     RC_LOT_CTLJOBID_FILLED,
                                     tmpNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier,
                                     strLot_controlJobID_Get_out.controlJobID.identifier );
                return RC_LOT_CTLJOBID_FILLED;
            }

            //----------------------------------
            //  Get InPostProcessFlag of Lot
            //----------------------------------
            objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
            objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
            strLot_inPostProcessFlag_Get_in.lotID = tmpNewLotAttributes.strNewWaferAttributes[i].sourceLotID;

            rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                            strObjCommonIn,
                                            strLot_inPostProcessFlag_Get_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
                strSTBReleasedLotReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
                return( rc );
            }

            //----------------------------------------------
            //  If Lot is in post process, returns error
            //----------------------------------------------
            if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
            {
                PPT_METHODTRACE_V1("", "Lot is in post process");
                PPT_SET_MSG_RC_KEY( strSTBReleasedLotReqResult,
                                    MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                    tmpNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier );
                return( RC_LOT_INPOSTPROCESS );
            }
        }
//DSN000071674 add end
    }

//DSN000071674 add start
    //INN-R170003 if ( 0 == lotOperationEIcheck && 0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) )
    //INN-R170003 add start
    if ( 0 == lotOperationEIcheck && ( 0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) ||
                                       0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentOut) ||
                                       0 != CIMFWStrCmp(strCassetteTransferState.transferState, CS_TRANS_STATE_PORT_IN))
       )
    //INN-R170003 add end
    {
        //-------------------------------
        // Check carrier transfer status
        //-------------------------------
         PPT_METHODTRACE_V2("", "strCassetteTransferState.transferState = ", strCassetteTransferState.transferState);
        objCassette_transferState_Get_out strCassette_transferState_Get_out;
        rc = cassette_transferState_Get(strCassette_transferState_Get_out, strObjCommonIn,
                                        tmpNewLotAttributes.cassetteID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "rc != RC_OK");
            strSTBReleasedLotReqResult.strResult = strCassette_transferState_Get_out.strResult ;
            return( rc );
        }
        //INN-R170003 if ( 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) )                                                    //D4100091
        //INN-R170003 add start
           if( 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) ||
               0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentOut)||
               0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, CS_TRANS_STATE_PORT_IN)
              )
        //INN-R170003 add end
        {
            PPT_METHODTRACE_V1("","Changed to EI by other operation");
            PPT_METHODTRACE_V2("", "strCassette_transferState_Get_out.transferState = ", strCassette_transferState_Get_out.transferState);
            strSTBReleasedLotReqResult.strResult = strCassette_transferState_Get_out.strResult ;
            PPT_SET_MSG_RC_KEY(strSTBReleasedLotReqResult, MSG_CHANGED_TO_EI_BY_OTHER_OPERATION, RC_CHANGED_TO_EI_BY_OTHER_OPERATION,
                               tmpNewLotAttributes.cassetteID.identifier);
             //return( RC_CHANGED_TO_EI_BY_OTHER_OPERATION ); 
             //INN-R170003 add start
               return (CS_RC_CAST_XFERSTATE_BE_CHANGED_BY_OTHER_OPERATION);
            //INN-R170003 add end
        }
    }
//DSN000071674 add end

    //----------------------
    // Check input parameter
    //----------------------
//P6000084 add start
    objectIdentifierSequence cassetteIDSeq;
    cassetteIDSeq.length(1);
    cassetteIDSeq[0] = tmpNewLotAttributes.cassetteID;
    objCassette_scrapWafer_SelectDR_out  strCassette_scrapWafer_SelectDR_out;
    rc = cassette_scrapWafer_SelectDR( strCassette_scrapWafer_SelectDR_out,
                                       strObjCommonIn,
                                       cassetteIDSeq);

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cassette_scrapWafer_SelectDR() != RC_OK");
        strSTBReleasedLotReqResult.strResult = strCassette_scrapWafer_SelectDR_out.strResult;
        return (rc);
    }

    CORBA::Long scrapCount = strCassette_scrapWafer_SelectDR_out.strLotWaferMap.length();
    if( scrapCount > 0 )
    {
        PPT_METHODTRACE_V2("", " ScrapWafer Found ", scrapCount);
        SET_MSG_RC(strSTBReleasedLotReqResult, MSG_FOUND_SCRAP, RC_FOUND_SCRAP) ;
        return (RC_FOUND_SCRAP);
    }
//P6000084 add end

//D9000005 add start
    /*-------------------------------*/
    /*   Check SorterJob existence   */
    /*-------------------------------*/
    pptEquipmentLoadPortAttribute dummyEquipmentPortAttribute;
    objectIdentifierSequence dummyLotIDs ;

    objWaferSorter_sorterJob_CheckForOperation_out strWaferSorter_sorterJob_CheckForOperation_out;
    objWaferSorter_sorterJob_CheckForOperation_in  strWaferSorter_sorterJob_CheckForOperation_in;
    strWaferSorter_sorterJob_CheckForOperation_in.strEquipmentLoadPortAttribute = dummyEquipmentPortAttribute;
    strWaferSorter_sorterJob_CheckForOperation_in.cassetteIDs                   = cassetteIDSeq;
    strWaferSorter_sorterJob_CheckForOperation_in.lotIDs                        = dummyLotIDs;
//PSN000102296    strWaferSorter_sorterJob_CheckForOperation_in.operation                     = CIMFWStrDup(SP_Operation_For_DestCast);
    strWaferSorter_sorterJob_CheckForOperation_in.operation                     = CIMFWStrDup(SP_Operation_For_Cast);    //PSN000102296

    rc = waferSorter_sorterJob_CheckForOperation( strWaferSorter_sorterJob_CheckForOperation_out,
                                                  strObjCommonIn,
                                                  strWaferSorter_sorterJob_CheckForOperation_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "waferSorter_sorterJob_CheckForOperation() != RC_OK" );
        strSTBReleasedLotReqResult.strResult = strWaferSorter_sorterJob_CheckForOperation_out.strResult;
        return( rc );
    }
//D9000005 add end

    objProductRequest_GetDetail_out strProductRequest_GetDetail_out;
    rc = productRequest_GetDetail(strProductRequest_GetDetail_out,
                                  strObjCommonIn,
                                  productRequestID);
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "productRequest_GetDetail() != RC_OK");
        strSTBReleasedLotReqResult.strResult = strProductRequest_GetDetail_out.strResult;
        return(rc);
    }


    objLot_parameterForLotGeneration_Check_out strLot_parameterForLotGeneration_Check_out;
    strLot_parameterForLotGeneration_Check_out.bWaferIDAssignRequred = FALSE; //P3000280
    rc = lot_parameterForLotGeneration_Check(strLot_parameterForLotGeneration_Check_out,
                                             strObjCommonIn,
                                             strProductRequest_GetDetail_out.strProdReqInq.startBankID,
                                             tmpNewLotAttributes);
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "lot_parameterForLotGeneration_Check() != RC_OK");
        strSTBReleasedLotReqResult.strResult = strLot_parameterForLotGeneration_Check_out.strResult;
        return(rc);
    }
    if (strLot_parameterForLotGeneration_Check_out.bWaferIDAssignRequred == TRUE)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "bWaferIDAssignRequred == TRUE");

        objLot_waferID_Generate_out strLot_waferID_Generate_out;
        rc = lot_waferID_Generate(strLot_waferID_Generate_out, strObjCommonIn,
                                  tmpNewLotAttributes);
        if (rc)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "lot_waferID_Generate() != RC_OK");
            strSTBReleasedLotReqResult.strResult = strLot_waferID_Generate_out.strResult;
            return(rc);
        }
        tmpNewLotAttributes = strLot_waferID_Generate_out.strNewLotAttributes;
    }
    //PTR3000273 Start
    nLen = tmpNewLotAttributes.strNewWaferAttributes.length();
    for (i=0; i<nLen; i++)
    {
        if( 0 == CIMFWStrLen(tmpNewLotAttributes.strNewWaferAttributes[i].newWaferID.identifier)
         && 0 <  CIMFWStrLen(tmpNewLotAttributes.strNewWaferAttributes[i].sourceWaferID.identifier))
        {
            tmpNewLotAttributes.strNewWaferAttributes[i].newWaferID
             = tmpNewLotAttributes.strNewWaferAttributes[i].sourceWaferID;
        }
    }
    //PTR3000273 End

    //----------------------
    // Prepare wafer of source lot
    //----------------------
    nLen = tmpNewLotAttributes.strNewWaferAttributes.length();
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "Prepare wafer of source lot");
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txSTBReleasedLotReq", "nLen", nLen);
    for (i=0; i<nLen; i++)
    {
        PPT_METHODTRACE_V1("Source Lot ID           ", tmpNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier);
        PPT_METHODTRACE_V1("Source Wafer ID         ", tmpNewLotAttributes.strNewWaferAttributes[i].sourceWaferID.identifier);
        PPT_METHODTRACE_V1("New Lot ID              ", tmpNewLotAttributes.strNewWaferAttributes[i].newLotID.identifier);
        PPT_METHODTRACE_V1("New Wafer ID            ", tmpNewLotAttributes.strNewWaferAttributes[i].newWaferID.identifier);
        PPT_METHODTRACE_V1("New Wafer Slot Number   ", tmpNewLotAttributes.strNewWaferAttributes[i].newSlotNumber);
    }

    for (i=0; i<nLen; i++)
    {
        if (CIMFWStrLen(tmpNewLotAttributes.strNewWaferAttributes[i].sourceWaferID.identifier) == 0)
        {
            objLot_wafer_Create_out strLot_wafer_Create_out;
            rc = lot_wafer_Create(strLot_wafer_Create_out, strObjCommonIn,
                                  tmpNewLotAttributes.strNewWaferAttributes[i].sourceLotID,
                                  tmpNewLotAttributes.strNewWaferAttributes[i].newWaferID.identifier);
            if (rc)
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "lot_wafer_Create() != RC_OK");
                strSTBReleasedLotReqResult.strResult = strLot_wafer_Create_out.strResult;
                return(rc);
            }
            tmpNewLotAttributes.strNewWaferAttributes[i].sourceWaferID = strLot_wafer_Create_out.newWaferID;

            PPT_METHODTRACE_V3("CS_PPTManager_i:: txSTBReleasedLotReq", "sourceWaferID", 
                               tmpNewLotAttributes.strNewWaferAttributes[i].sourceWaferID.identifier, i);

            objWafer_materialContainer_Change_out strWafer_materialContainer_Change_out;
            pptWafer strWafer;
            strWafer.waferID    = strLot_wafer_Create_out.newWaferID;
            strWafer.slotNumber =  tmpNewLotAttributes.strNewWaferAttributes[i].newSlotNumber;
            rc = wafer_materialContainer_Change(strWafer_materialContainer_Change_out, strObjCommonIn,
                                                tmpNewLotAttributes.cassetteID,
                                                strWafer);
            // newCassetteID = tmpNewLotAttributes.cassetteID
            // strWafer.waferID = strLot_wafer_Create_out.newWaferID
            // strWafer.slotNumber = tmpNewLotAttributes.strNewWaferAttributes[i].newSlotNumber
            if (rc)
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "wafer_materialContainer_Change() != RC_OK");
                strSTBReleasedLotReqResult.strResult = strWafer_materialContainer_Change_out.strResult;
                return(rc);
            }
        }
    }

    //------------------------------------------------------
    // Check source lot property and lot - bank combination
    //------------------------------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "Check source lot property and lot - bank combination");

    objBank_lotSTB_Check_out strBank_lotSTB_Check_out;
    rc = bank_lotSTB_Check(strBank_lotSTB_Check_out, strObjCommonIn,
                           productRequestID, tmpNewLotAttributes);
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "bank_lotSTB_Check() != RC_OK");
        strSTBReleasedLotReqResult.strResult = strBank_lotSTB_Check_out.strResult;
        return(rc);
    }

    //------------------------------------------------------
    // STB Lot
    //------------------------------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "STB Lot");

    objLot_STB_out strLot_STB_out;
    rc = lot_STB(strLot_STB_out, strObjCommonIn,
                 productRequestID, tmpNewLotAttributes);
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "lot_STB() != RC_OK");
        strSTBReleasedLotReqResult.strResult = strLot_STB_out.strResult;
        return(rc);
    }

//P3000080 start
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txSTBReleasedLotReq", "@@@@@ Set createdLotID @@@@@", strLot_STB_out.createdLotID.identifier);

    strSTBReleasedLotReqResult.lotID = strLot_STB_out.createdLotID;
//P3000080 end

    //------------------------------------------------------
    // Copy stringified object reference of created lot
    //------------------------------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "Copy stringified object reference of created lot");

    PPT_METHODTRACE_V2("CS_PPTManager_i:: txSTBReleasedLotReq",
                       "Created Lot ID                ",
                       strLot_STB_out.createdLotID.identifier);
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txSTBReleasedLotReq",
                       "Created Lot Stringified ObjRef",
                       strLot_STB_out.createdLotID.stringifiedObjectReference);

    nLen = tmpNewLotAttributes.strNewWaferAttributes.length();
    PPT_METHODTRACE_V2("CS_PPTManager_i:: txSTBReleasedLotReq", "nLen", nLen);
    for(i=0; i<nLen; i++)
    {
        tmpNewLotAttributes.strNewWaferAttributes[i].newLotID = strLot_STB_out.createdLotID;
    }

    //----------------------
    // Update control Job Info and
    // Machine Cassette info if information exist
    //----------------------
    // PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "Update control Job Info and Machine Cassette info if information exist");

    // objectIdentifierSequence tmpCassetteIDSeq;
    // tmpCassetteIDSeq.length(1);
    // tmpCassetteIDSeq[0] = tmpNewLotAttributes.cassetteID;
    // objControlJob_relatedInfo_Update_out strControlJob_relatedInfo_Update_out;
    // rc = controlJob_relatedInfo_Update(strControlJob_relatedInfo_Update_out, strObjCommonIn,
    //                                   tmpCassetteIDSeq);
    // if (rc)
    // {
    //     PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "controlJob_relatedInfo_Update() != RC_OK");
    //     strSTBReleasedLotReqResult.strResult = strControlJob_relatedInfo_Update_out.strResult;
    //     return(rc);
    // }

//DSN000071674 add start
    if ( TRUE == updateControlJobFlag )
    {
        //----------------------
        // Update control Job Info and
        // Machine Cassette info if information exist
        //----------------------
        objectIdentifierSequence tmpCassetteIDSeq;
        tmpCassetteIDSeq.length(1);
        tmpCassetteIDSeq[0] = tmpNewLotAttributes.cassetteID;
        objControlJob_relatedInfo_Update_out strControlJob_relatedInfo_Update_out;
        rc = controlJob_relatedInfo_Update(strControlJob_relatedInfo_Update_out, strObjCommonIn,
                                           tmpCassetteIDSeq);
        if (rc)
        {
            PPT_METHODTRACE_V2("", "controlJob_relatedInfo_Update() != RC_OK", rc);
            strSTBReleasedLotReqResult.strResult = strControlJob_relatedInfo_Update_out.strResult;
            return(rc);
        }
    }
//DSN000071674 add end

    //----------------------
    // Update cassette multi lot type
    //----------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "Update cassette multi lot type");

    objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
    rc = cassette_multiLotType_Update(strCassette_multiLotType_Update_out, strObjCommonIn,
                                      tmpNewLotAttributes.cassetteID);
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "cassette_multiLotType_Update() != RC_OK");
        strSTBReleasedLotReqResult.strResult = strCassette_multiLotType_Update_out.strResult;
        return(rc);
    }

#if 1
    //D4000016 Add Start
    //--------------------------------------------------------------------------------------------------
    // UpDate RequiredCassetteCategory 
    //--------------------------------------------------------------------------------------------------
    objLot_CassetteCategory_UpdateForContaminationControl_out   strLot_CassetteCategory_UpdateForContaminationControl_out;
    rc = lot_CassetteCategory_UpdateForContaminationControl( strLot_CassetteCategory_UpdateForContaminationControl_out,
                                                             strObjCommonIn,
                                                             strLot_STB_out.createdLotID);

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","lot_CassetteCategory_UpdateForContaminationControl != RC_OK");
        strSTBReleasedLotReqResult.strResult = strLot_CassetteCategory_UpdateForContaminationControl_out.strResult;
        return rc;
    }
    //D4000016 Add end
#endif

//INN-R170002 add start
    //------------------------------------------------------------------------
    //   Check contamination information for newly created lot
    //------------------------------------------------------------------------
    PPT_METHODTRACE_V1("", "Check contamination information");

    csObjLot_ContaminationInfo_CheckForMove_out strLot_ContaminationInfo_CheckForMove_out;
    csObjLot_ContaminationInfo_CheckForMove_in  strLot_ContaminationInfo_CheckForMove_in;
    strLot_ContaminationInfo_CheckForMove_in.lotID = strLot_STB_out.createdLotID;
    strLot_ContaminationInfo_CheckForMove_in.carrierID = tmpNewLotAttributes.cassetteID;

    rc = cs_lot_ContaminationInfo_CheckForMove(strLot_ContaminationInfo_CheckForMove_out, strObjCommonIn,
                                 strLot_ContaminationInfo_CheckForMove_in); 
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "cs_lot_ContaminationInfo_CheckForMove() rc != RC_OK",rc);
        strSTBReleasedLotReqResult.strResult = strLot_ContaminationInfo_CheckForMove_out.strResult;
        return(rc);
    }
    if (TRUE == strLot_ContaminationInfo_CheckForMove_out.holdReqFlag)
    {
        PPT_METHODTRACE_V1("", "strLot_ContaminationInfo_CheckForMove_out.holdReqFlag= TRUE");
        CS_PPT_SET_MSG_RC_KEY2( strSTBReleasedLotReqResult,
                                CS_MSG_LOT_CONTAMINATION_MISMATCH,
                                CS_RC_LOT_CONTAMINATION_MISMATCH,
                                strLot_STB_out.createdLotID.identifier,
                                tmpNewLotAttributes.cassetteID.identifier );
        return CS_RC_LOT_CONTAMINATION_MISMATCH;
    }
//INN-R170002 add end

//D4200029 Add Start
    //-----------------------//
    //     Process Hold      //
    //-----------------------//
    PPT_METHODTRACE_V1("","Call txProcessHoldExecReq()");
    pptProcessHoldExecReqResult strProcessHoldExecReqResult;

    rc = txProcessHoldExecReq( strProcessHoldExecReqResult,
                               strObjCommonIn,
                               strLot_STB_out.createdLotID,
                               claimMemo );

    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("","txProcessHoldExecReq() != RC_OK", rc );
        strSTBReleasedLotReqResult.strResult = strProcessHoldExecReqResult.strResult ;
        return( rc );
    }
//D4200029 Add End

    //------------------------------------------------------------------------
    //   Make History                                                         
    //------------------------------------------------------------------------
    PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "Make History");

    if ((CIMFWStrCmp(strLot_STB_out.productType, SP_ProdType_Wafer) == 0 ) ||
        (CIMFWStrCmp(strLot_STB_out.productType, SP_ProdType_Die  ) == 0 )  )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "productType == SP_ProdType_Die");

        objLot_waferLotHistoryPointer_Update_out strLot_waferLotHistoryPointer_Update_out;
        rc = lot_waferLotHistoryPointer_Update(strLot_waferLotHistoryPointer_Update_out, strObjCommonIn,
                                               strLot_STB_out.createdLotID);
        if (rc)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "lot_waferLotHistoryPointer_Update() != RC_OK");
            strSTBReleasedLotReqResult.strResult = strLot_waferLotHistoryPointer_Update_out.strResult;
            return(rc);
        }

        nLen = tmpNewLotAttributes.strNewWaferAttributes.length();
        PPT_METHODTRACE_V2("CS_PPTManager_i:: txSTBReleasedLotReq", "nLen", nLen);
        for (i=0; i<nLen; i++)
        {
            if (i>0 &&
                CIMFWStrCmp(tmpNewLotAttributes.strNewWaferAttributes[  i].sourceLotID.identifier, 
                            tmpNewLotAttributes.strNewWaferAttributes[i-1].sourceLotID.identifier) == 0)
            {
                continue;
            }

            PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "Call lot_waferLotHistoryPointer_Update");

            objLot_waferLotHistoryPointer_Update_out strLot_waferLotHistoryPointer_Update_out;
            rc = lot_waferLotHistoryPointer_Update( strLot_waferLotHistoryPointer_Update_out,
                                                    strObjCommonIn,
                                                    tmpNewLotAttributes.strNewWaferAttributes[i].sourceLotID);  //for Source lot

            if (rc)
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "lot_waferLotHistoryPointer_Update() != RC_OK");
                strSTBReleasedLotReqResult.strResult = strLot_waferLotHistoryPointer_Update_out.strResult;
                return(rc);
            }
        }
    }

    PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "Call lotWaferMoveEvent_Make");

    objLotWaferMoveEvent_Make_out strLotWaferMoveEvent_Make_out;
    rc = lotWaferMoveEvent_Make(strLotWaferMoveEvent_Make_out, strObjCommonIn,
                                "TXTRC001", tmpNewLotAttributes, claimMemo);
    if (rc)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txSTBReleasedLotReq", "lotWaferMoveEvent_Make() != RC_OK");
        strSTBReleasedLotReqResult.strResult = strLotWaferMoveEvent_Make_out.strResult;
        return(rc);
    }

    objLotReticleSetChangeEvent_Make_out strLotReticleSetChangeEvent_Make_out;                               //D4000177
    rc = lotReticleSetChangeEvent_Make( strLotReticleSetChangeEvent_Make_out,                                //D4000177
                                        strObjCommonIn,                                                      //D4000177
                                        "TXTRC001",                                                          //D4000177
                                        strLot_STB_out.createdLotID,                                         //D4000177
                                        claimMemo);                                                          //D4000177
    if (rc != RC_OK)                                                                                         //D4000177
    {                                                                                                        //D4000177
        PPT_METHODTRACE_V1("CS_PPTManager_i::txSTBReleasedLotReq", "lotReticleSetChangeEvent_Make() rc != RC_OK"); //D4000177
        strSTBReleasedLotReqResult.strResult = strLotReticleSetChangeEvent_Make_out.strResult;               //D4000177
        return(rc);                                                                                          //D4000177
    }                                                                                                        //D4000177

//DSN000096141 add start
    CORBA::Long lotOperationMoveEventCreation = atoi(getenv(SP_LOT_OPERATION_MOVE_EVENT_CREATION_FOR_STB) );
    if( lotOperationMoveEventCreation == 1 )
    {
        objLotOperationMoveEvent_MakeOther_out strLotOperationMoveEvent_MakeOther_out;
        rc = lotOperationMoveEvent_MakeOther(strLotOperationMoveEvent_MakeOther_out, strObjCommonIn,
                                    "TXTRC001", strLot_STB_out.createdLotID, claimMemo);
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i::txSTBReleasedLotReq ", "lotReticleSetChangeEvent_Make() rc != RC_OK");
            strSTBReleasedLotReqResult.strResult = strLotOperationMoveEvent_MakeOther_out.strResult;
            return(rc);
        }
    }
//DSN000096141 add end

    //------------------------------------------------------------------------
    //   Return                                                               
    //------------------------------------------------------------------------
    SET_MSG_RC(strSTBReleasedLotReqResult, MSG_OK, RC_OK);

    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txSTBReleasedLotReq");
    return(RC_OK);
}
