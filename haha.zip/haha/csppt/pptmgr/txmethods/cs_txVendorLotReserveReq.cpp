//
// (c) Copyright: IBM Taiwan Industrial Solution Co., Ltd, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017. All rights reserved.
//
// SiView
// File : cs_txVendorLotReserveReq.cpp
//
// Description :
//
// Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/07/25 INN-R170084  Jacky Yeh      170084: Automatic Vendor Lot Receive and Prepare
//

#include "cs_pptmgr.hpp"

CORBA::Long CS_PPTManager_i::cs_txVendorLotReserveReq (
    csVendorLotReserveReqResult&                      strVendorLotReserveReqResult,
    const pptObjCommonIn&                             strObjCommonIn,
    const objectIdentifier&                           bankID,
    const char *                                      lotType,
    const char *                                      subLotType,
    const char *                                      sourceProduct,
    const char *                                      partNo,
    const pptNewLotAttributes&                        strNewLotAttributes
    CORBAENV_LAST_CPP )
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_txVendorLotReserveReq");

    CORBA::Long rc = RC_OK;
    
    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    // check input parameter
    if( CIMFWStrLen(bankID.identifier) == 0 ||
        CIMFWStrLen(lotType)          == 0 ||
        CIMFWStrLen(subLotType)       == 0 ||
        CIMFWStrLen(sourceProduct)    == 0 )
//modify by qufd 20170927        ||
//modify by qufd 20170927        CIMFWStrLen(partNo)           == 0 )
    {
        PPT_SET_MSG_RC_KEY( strVendorLotReserveReqResult,
                            MSG_BLANK_INPUT_PARAMETER,
                            RC_BLANK_INPUT_PARAMETER,
                            "bankID or lotType or subLotType or sourceProduct or partNo" );
                 
        return RC_BLANK_INPUT_PARAMETER;
    }

    // check input carrier & Wafer Sequence
    if( CIMFWStrLen(strNewLotAttributes.cassetteID.identifier) == 0 ||
        strNewLotAttributes.strNewWaferAttributes.length() == 0 )
    {
        PPT_SET_MSG_RC_KEY( strVendorLotReserveReqResult,
                            MSG_BLANK_INPUT_PARAMETER,
                            RC_BLANK_INPUT_PARAMETER,
                            "cassetteID or wafer information" );
                 
        return RC_BLANK_INPUT_PARAMETER;
    }

    // Call cs_vendorLotReserve_AddDR
    csObjVendorLotReserve_AddDR_out strVendorLotReserve_AddDR_out ;
    rc = cs_vendorLotReserve_AddDR( strVendorLotReserve_AddDR_out,
                                    strObjCommonIn,
                                    bankID, 
                                    lotType, 
                                    subLotType, 
                                    sourceProduct,
                                    partNo,
                                    strNewLotAttributes );
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "cs_vendorLotReserve_AddDR() rc != RC_OK", rc);
        strVendorLotReserveReqResult.strResult = strVendorLotReserve_AddDR_out.strResult ;
        return(rc);
    }

    /*-----------------------------------------------------------------------*/
    /*   Return to Caller                                                    */
    /*-----------------------------------------------------------------------*/
    strVendorLotReserveReqResult.strResult = strVendorLotReserve_AddDR_out.strResult;
    
    SET_MSG_RC( strVendorLotReserveReqResult, MSG_OK, RC_OK ) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_txVendorLotReserveReq");
    return RC_OK;
}
