//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_txSTBCancelReqOR.cpp
//

#include "cs_pptmgr.hpp"

// Class: PPTManager
//
// Service: txSTBCancelReq()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/10 DSIV00000220 M.Ogawa        Initial release
// 2008/10/30 DSIV00000214 S.Miyata       Multi Fab Transfer Support
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2010/03/15 DSIV00001830 S.Kawabe       Wafer Stacking Operation Support
// 2013/05/09 DSN000071674 C.Mo           Remove part of the EI state limitation
// 2014/01/21 PSN000083176 C.Mo           Data inconsistency might occur when start lot reservation is called together with lot operation transactions for the same cassette
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/10 INN-R170003  YangXigang     Durable Management Enhancement
//
// Description:
//
// Return:
//
// Parameter:
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i:: txSTBCancelReq(
        pptSTBCancelReqResult&         strSTBCancelReqResult,
        const pptObjCommonIn&          strObjCommonIn,
        const pptSTBCancelReqInParm&   strSTBCancelReqInParm,
        const char*                    claimMemo
        CORBAENV_LAST_CPP)
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txSTBCancelReq ")
    CORBA::Long rc = RC_OK ;

    CORBA::Long i    = 0;
    CORBA::Long j    = 0;
    CORBA::Long k    = 0;
    CORBA::Long l    = 0;
    CORBA::Long nLen = 0;

    //---------------------------------
    // Input Parameter
    //---------------------------------
    const objectIdentifier&              STBCancelledLotID          = strSTBCancelReqInParm.STBCancelledLotID;
    const pptNewPreparedLotInfoSequence& inputNewPreparedLotInfoSeq = strSTBCancelReqInParm.strNewPreparedLotInfoSeq;
    const pptNewLotAttributes&           inputNewLotAttributes      = strSTBCancelReqInParm.strNewLotAttributes;

    PPT_METHODTRACE_V2("", "InParam [STBCancelledLotID] ", STBCancelledLotID.identifier);

    //------------------------------------------------------
    //  Check input STBCancelledLotID
    //------------------------------------------------------
    PPT_METHODTRACE_V1("", "Check input STBCancelledLotID");
    if( 0 == CIMFWStrLen(STBCancelledLotID.identifier) )
    {
        PPT_METHODTRACE_V1("", "Lot isn't specified");
        SET_MSG_RC( strSTBCancelReqResult,
                    MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
        return RC_INVALID_INPUT_PARM;
    }

    //------------------------------------------------------
    //  Check SP_LOT_STBCANCEL
    //------------------------------------------------------
    PPT_METHODTRACE_V1("", "Check SP_LOT_STBCANCEL.");
    CORBA::String_var tmpSTBCancelEnv = CIMFWStrDup(getenv(SP_LOT_STBCANCEL));
    PPT_METHODTRACE_V2("","SP_LOT_STBCANCEL env value ON/OFF. tmpSTBCancelEnv = ", tmpSTBCancelEnv);

    if(CIMFWStrCmp(tmpSTBCancelEnv, SP_LOT_STBCANCEL_ON) != 0)
    {
        PPT_METHODTRACE_V1("", "SP_LOT_STBCANCEL env value is OFF !! --> Return !!");
        SET_MSG_RC( strSTBCancelReqResult,
                    MSG_SP_LOT_STBCANCEL_OFF, RC_SP_LOT_STBCANCEL_OFF );
        return RC_SP_LOT_STBCANCEL_OFF;
    }

    //------------------------------------------------------
    //  Check input parameter
    //------------------------------------------------------
    PPT_METHODTRACE_V1("", "Check input parameter");
    nLen = inputNewPreparedLotInfoSeq.length();
    PPT_METHODTRACE_V2("", "nLen", nLen);
    for( i = 0; i < nLen; i++ )
    {
        for( j = i + 1; j < nLen; j++ )
        {
            if( 0 == CIMFWStrCmp( inputNewPreparedLotInfoSeq[i].STBSourceLotID,
                                  inputNewPreparedLotInfoSeq[j].STBSourceLotID ) )
            {
                PPT_METHODTRACE_V2("", "STB source lots are duplicate in input parameter.",
                                        inputNewPreparedLotInfoSeq[i].STBSourceLotID);
                PPT_SET_MSG_RC_KEY( strSTBCancelReqResult,
                                    MSG_DUPLICATE_VALUES_IN_INPUT,
                                    RC_DUPLICATE_VALUES_IN_INPUT,
                                    inputNewPreparedLotInfoSeq[i].STBSourceLotID );
                return RC_DUPLICATE_VALUES_IN_INPUT;
            }
        }
    }

//DSN000071674 add start
    CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );

    CORBA::Boolean updateControlJobFlag = FALSE;
    CORBA::Long lockMode = 0; //PSN000083176

    objCassette_transferState_Get_out strCassetteTransferState;
    objObject_Lock_out strObject_Lock_out;

    if ( 0 == lotOperationEIcheck )
    {
        //-------------------------------
        // Get carrier transfer status
        //-------------------------------
        rc = cassette_transferState_Get(strCassetteTransferState, strObjCommonIn,
                                        inputNewLotAttributes.cassetteID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "rc != RC_OK");
            strSTBCancelReqResult.strResult = strCassetteTransferState.strResult ;
            return( rc );
        }

        /*------------------------------------*/
        /*   Get equipment ID in Cassette     */
        /*------------------------------------*/
        objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
        rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                       strObjCommonIn,
                                       inputNewLotAttributes.cassetteID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "cassette_equipmentID_Get != RC_OK", rc);
            strSTBCancelReqResult.strResult = strCassette_equipmentID_Get_out.strResult;
            return( rc );
        }

        //-------------------------------
        // Get required equipment lock mode
        //-------------------------------
        objObject_lockMode_Get_out strObject_lockMode_Get_out;
        objObject_lockMode_Get_in  strObject_lockMode_Get_in;
        strObject_lockMode_Get_in.objectID           = strCassette_equipmentID_Get_out.equipmentID;
        strObject_lockMode_Get_in.className          = CIMFWStrDup( SP_ClassName_PosMachine );
        strObject_lockMode_Get_in.functionCategory   = CIMFWStrDup( "TXTRC083" ); // TxSTBCancelReq
        strObject_lockMode_Get_in.userDataUpdateFlag = FALSE;

        rc = object_lockMode_Get( strObject_lockMode_Get_out,
                                  strObjCommonIn,
                                  strObject_lockMode_Get_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_lockMode_Get() != RC_OK", rc);
            strSTBCancelReqResult.strResult = strObject_lockMode_Get_out.strResult;
            return( rc );
        }

//PSN000083176        CORBA::Long lockMode = strObject_lockMode_Get_out.lockMode;
        lockMode = strObject_lockMode_Get_out.lockMode; //PSN000083176
        PPT_METHODTRACE_V2( "", "lockMode", lockMode );

        //INN-R170003 if ( 0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) )
        //INN-R170003 add start
        if( 0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) ||
            0 == CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentOut)||
            0 == CIMFWStrCmp(strCassetteTransferState.transferState, CS_TRANS_STATE_PORT_IN)
          )
        //INN-R170003 add end
        {
            PPT_METHODTRACE_V2("", "strCassetteTransferState.transferState = ", strCassetteTransferState.transferState);
            updateControlJobFlag = TRUE;

            if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
            {
                objAdvanced_object_Lock_out strAdvanced_object_Lock_out;
                objAdvanced_object_Lock_in strAdvanced_object_Lock_in;

                // Lock Equipment Main Object
                stringSequence dummySeq;
                dummySeq.length(0);
                strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_MainObject );
                strAdvanced_object_Lock_in.lockType   = strObject_lockMode_Get_out.requiredLockForMainObject;
                strAdvanced_object_Lock_in.keySeq     = dummySeq;

                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strSTBCancelReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }

                // Lock Equipment LoadCassette Element (Write)
                stringSequence loadCastSeq;
                loadCastSeq.length(1);
                loadCastSeq[0] = inputNewLotAttributes.cassetteID.identifier;
                strAdvanced_object_Lock_in.objectID   = strCassette_equipmentID_Get_out.equipmentID;
                strAdvanced_object_Lock_in.className  = CIMFWStrDup( SP_ClassName_PosMachine );
                strAdvanced_object_Lock_in.objectType = CIMFWStrDup( SP_ObjectLock_ObjectType_LoadCassette );
                strAdvanced_object_Lock_in.lockType   = SP_ObjectLock_LockType_WRITE;
                strAdvanced_object_Lock_in.keySeq     = loadCastSeq;

                rc =  advanced_object_Lock( strAdvanced_object_Lock_out,
                                            strObjCommonIn,
                                            strAdvanced_object_Lock_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "advanced_object_Lock() != RC_OK", rc);
                    strSTBCancelReqResult.strResult = strAdvanced_object_Lock_out.strResult;
                    return( rc );
                }
            }
            else
            {
                /*--------------------------------*/
                /*   Lock Macihne object          */
                /*--------------------------------*/
                rc = object_Lock( strObject_Lock_out, strObjCommonIn, strCassette_equipmentID_Get_out.equipmentID, SP_ClassName_PosMachine );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc) ;
                    strSTBCancelReqResult.strResult = strObject_Lock_out.strResult ;
                    return( rc );
                }
            }
        }

//PSN000083176        if ( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176        {
//PSN000083176            //---------------------------------
//PSN000083176            //   Get Cassette's ControlJobID
//PSN000083176            //---------------------------------
//PSN000083176            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

//PSN000083176            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
//PSN000083176                                            strObjCommonIn,
//PSN000083176                                            inputNewLotAttributes.cassetteID );
//PSN000083176            if ( rc != RC_OK )
//PSN000083176            {
//PSN000083176                PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
//PSN000083176                strSTBCancelReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
//PSN000083176                return( rc );
//PSN000083176            }
//PSN000083176            if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
//PSN000083176            {
//PSN000083176                PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
//PSN000083176                updateControlJobFlag = TRUE;

//PSN000083176                if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
//PSN000083176                {
//PSN000083176                    /*------------------------------*/
//PSN000083176                    /*   Lock ControlJob Object     */
//PSN000083176                    /*------------------------------*/
//PSN000083176                    rc = object_Lock( strObject_Lock_out,
//PSN000083176                                      strObjCommonIn, 
//PSN000083176                                      strCassette_controlJobID_Get_out.controlJobID, 
//PSN000083176                                      SP_ClassName_PosControlJob );
//PSN000083176                    if ( rc != RC_OK )
//PSN000083176                    {
//PSN000083176                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
//PSN000083176                        strSTBCancelReqResult.strResult = strObject_Lock_out.strResult;
//PSN000083176                        return( rc );
//PSN000083176                    }
//PSN000083176                }
//PSN000083176            }
//PSN000083176        }
    }
//DSN000071674 add end

    //----------------------
    // Object Lock for cassette
    //----------------------
    PPT_METHODTRACE_V1("", "call object_Lock( CASSETTE )");
//DSN000071674    objObject_Lock_out strObject_Lock_out;
    rc = object_Lock( strObject_Lock_out, strObjCommonIn,
                      inputNewLotAttributes.cassetteID,
                      SP_ClassName_PosCassette );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "object_Lock() != RC_OK");
        strSTBCancelReqResult.strResult = strObject_Lock_out.strResult;
        return(rc);
    }
//PSN000083176 add start
    if ( 0 == lotOperationEIcheck )
    {
        if ( !updateControlJobFlag || lockMode != SP_EQP_LOCK_MODE_WRITE )
        {
            //---------------------------------
            //   Get Cassette's ControlJobID
            //---------------------------------
            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;

            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                            strObjCommonIn,
                                            inputNewLotAttributes.cassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "cassette_controlJobID_Get() != RC_OK" );
                strSTBCancelReqResult.strResult = strCassette_controlJobID_Get_out.strResult;
                return( rc );
            }
            if ( 0 < CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
            {
                PPT_METHODTRACE_V1( "", "cassette's controlJobID isn't blank" );
                updateControlJobFlag = TRUE;

                if ( lockMode != SP_EQP_LOCK_MODE_WRITE )
                {
                    /*------------------------------*/
                    /*   Lock ControlJob Object     */
                    /*------------------------------*/
                    rc = object_Lock( strObject_Lock_out,
                                      strObjCommonIn, 
                                      strCassette_controlJobID_Get_out.controlJobID, 
                                      SP_ClassName_PosControlJob );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", rc);
                        strSTBCancelReqResult.strResult = strObject_Lock_out.strResult;
                        return( rc );
                    }
                }
            }
        }
    }
//PSN000083176 add end
    //-------------------------------------
    // Object Lock for STB Cancelled lot
    //-------------------------------------
    PPT_METHODTRACE_V1("", "call object_Lock( LOT )");
    rc = object_Lock( strObject_Lock_out, strObjCommonIn, STBCancelledLotID, SP_ClassName_PosLot);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "object_Lock() != RC_OK", i);
        strSTBCancelReqResult.strResult = strObject_Lock_out.strResult;
        return(rc);
    }

//DSIV00000214 add start
    //---------------------------------------
    //   Check interFabXferPlan existence
    //---------------------------------------
    PPT_METHODTRACE_V2("", "call lot_currentOperationInfo_Get()", STBCancelledLotID.identifier);
    objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
    rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out,
                                       strObjCommonIn,
                                       STBCancelledLotID );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "##### lot_currentOperationInfo_Get() != RC_OK", rc);
        strSTBCancelReqResult.strResult = strLot_currentOperationInfo_Get_out.strResult;
        return( rc );
    }

    PPT_METHODTRACE_V1("", "call interFab_xferPlanList_GetDR()");
    objInterFab_xferPlanList_GetDR_out strInterFab_xferPlanList_GetDR_out;
    objInterFab_xferPlanList_GetDR_in strInterFab_xferPlanList_GetDR_in;
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.lotID = STBCancelledLotID;
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.seqNo = 0;
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalRouteID = strLot_currentOperationInfo_Get_out.routeID;
    strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalOpeNumber = strLot_currentOperationInfo_Get_out.operationNumber;

    rc = interFab_xferPlanList_GetDR( strInterFab_xferPlanList_GetDR_out,
                                      strObjCommonIn,
                                      strInterFab_xferPlanList_GetDR_in );
    if( rc != RC_OK && rc != RC_INTERFAB_NOT_FOUND_XFERPLAN )
    {
        PPT_METHODTRACE_V2("", "##### interFab_xferPlanList_GetDR() != RC_OK", rc);
        strSTBCancelReqResult.strResult = strInterFab_xferPlanList_GetDR_out.strResult;
        return( rc );
    }

    CORBA::Long xferLen = strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq.length();
    PPT_METHODTRACE_V2("", "xferLen", xferLen);
    if( xferLen != 0 )
    {
        PPT_METHODTRACE_V1("", "##### strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq.length != 0");
        SET_MSG_RC( strSTBCancelReqResult, MSG_INTERFAB_BRANCH_CANCEL_ERROR, RC_INTERFAB_BRANCH_CANCEL_ERROR );
        return( RC_INTERFAB_BRANCH_CANCEL_ERROR );
    }
//DSIV00000214 add end

//DSIV00001830 add start
    //---------------------------------------
    // Check Bonding Group
    //---------------------------------------
    objLot_bondingGroupID_GetDR_in  strLot_bondingGroupID_GetDR_in;
    strLot_bondingGroupID_GetDR_in.lotID = STBCancelledLotID;

    objLot_bondingGroupID_GetDR_out strLot_bondingGroupID_GetDR_out;
    rc = lot_bondingGroupID_GetDR( strLot_bondingGroupID_GetDR_out, strObjCommonIn, strLot_bondingGroupID_GetDR_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_bondingGroupID_GetDR() rc != RC_OK");
        strSTBCancelReqResult.strResult = strLot_bondingGroupID_GetDR_out.strResult;
        return rc;
    }
    if( CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0 )
    {
        PPT_METHODTRACE_V1("", "CIMFWStrLen(strLot_bondingGroupID_GetDR_out.bondingGroupID) > 0");
        PPT_SET_MSG_RC_KEY2( strSTBCancelReqResult,
                             MSG_LOT_HAS_BONDINGGROUP,
                             RC_LOT_HAS_BONDINGGROUP,
                             strLot_bondingGroupID_GetDR_in.lotID.identifier,
                             strLot_bondingGroupID_GetDR_out.bondingGroupID );
        return RC_LOT_HAS_BONDINGGROUP;
    }
//DSIV00001830 add end

//DSN000071674 add start
    if ( 0 == lotOperationEIcheck )
    {
        //----------------------------------
        //   Check Lot's Control Job ID
        //----------------------------------
        objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
        rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, STBCancelledLotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_controlJobID_Get() != RC_OK", rc);
            strSTBCancelReqResult.strResult = strLot_controlJobID_Get_out.strResult;
            return( rc );
        }
        if ( 0 == CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) )
        {
            PPT_METHODTRACE_V1("", "strLot_controlJobID_Get_out.controlJobID.identifier == 0");
        }
        else
        {
            PPT_METHODTRACE_V1("", "strLot_controlJobID_Get_out.controlJobID.identifier != 0");
            PPT_SET_MSG_RC_KEY2( strSTBCancelReqResult,
                                 MSG_LOT_CTLJOBID_FILLED,
                                 RC_LOT_CTLJOBID_FILLED,
                                 STBCancelledLotID.identifier,
                                 strLot_controlJobID_Get_out.controlJobID.identifier );
            return RC_LOT_CTLJOBID_FILLED;
        }

        //----------------------------------
        //  Get InPostProcessFlag of Lot
        //----------------------------------
        objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
        objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
        strLot_inPostProcessFlag_Get_in.lotID = STBCancelledLotID;

        rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                        strObjCommonIn,
                                        strLot_inPostProcessFlag_Get_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
            strSTBCancelReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
            return( rc );
        }

        //----------------------------------------------
        //  If Lot is in post process, returns error
        //----------------------------------------------
        if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
        {
            PPT_METHODTRACE_V1("", "Lot is in post process");
            PPT_SET_MSG_RC_KEY( strSTBCancelReqResult,
                                MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                STBCancelledLotID.identifier );
            return( RC_LOT_INPOSTPROCESS );
        }
    }
//DSN000071674 add end

//DSN000071674 add start
    //INN-R170003 if ( 0 == lotOperationEIcheck && 0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) ) 
    //INN-R170003 add start
    if ( 0 == lotOperationEIcheck && ( 0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentIn) ||
                                       0 != CIMFWStrCmp(strCassetteTransferState.transferState, SP_TransState_EquipmentOut) ||
                                       0 != CIMFWStrCmp(strCassetteTransferState.transferState, CS_TRANS_STATE_PORT_IN)
       ))
    //INN-R170003 add end
    {
        //-------------------------------
        // Check carrier transfer status
        //-------------------------------
        PPT_METHODTRACE_V2("", "strCassetteTransferState.transferState = ", strCassetteTransferState.transferState);
        objCassette_transferState_Get_out strCassette_transferState_Get_out;
        rc = cassette_transferState_Get(strCassette_transferState_Get_out, strObjCommonIn,
                                        inputNewLotAttributes.cassetteID);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "rc != RC_OK");
            strSTBCancelReqResult.strResult = strCassette_transferState_Get_out.strResult ;
            return( rc );
        }
        //INN-R170003 if ( 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) )                                                     //D4100091
        //INN-R170003 add start
        if( 0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentIn) ||
            0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, SP_TransState_EquipmentOut)||
            0 == CIMFWStrCmp(strCassette_transferState_Get_out.transferState, CS_TRANS_STATE_PORT_IN)
           )
        //INN-R170003 add end
        {
            PPT_METHODTRACE_V1("","Changed to EI by other operation");
            PPT_METHODTRACE_V2("", "strCassette_transferState_Get_out.transferState = ", strCassette_transferState_Get_out.transferState);
            strSTBCancelReqResult.strResult = strCassette_transferState_Get_out.strResult ;
            PPT_SET_MSG_RC_KEY(strSTBCancelReqResult, MSG_CHANGED_TO_EI_BY_OTHER_OPERATION, RC_CHANGED_TO_EI_BY_OTHER_OPERATION,
                               inputNewLotAttributes.cassetteID.identifier);
            return( RC_CHANGED_TO_EI_BY_OTHER_OPERATION );
        }
    }
//DSN000071674 add end

    //--------------------------------------------
    // Get STB Cancel information
    //--------------------------------------------
    PPT_METHODTRACE_V1("", "call lot_STBCancelInfo_Get()");
    objLot_STBCancelInfo_GetDR_out  strLot_STBCancelInfo_GetDR_out;
    objLot_STBCancelInfo_GetDR_in   strLot_STBCancelInfo_GetDR_in;
    strLot_STBCancelInfo_GetDR_in.STBCancelledLotID = STBCancelledLotID;

    rc = lot_STBCancelInfo_GetDR( strLot_STBCancelInfo_GetDR_out,
                                  strObjCommonIn,
                                  strLot_STBCancelInfo_GetDR_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_STBCancelInfo_GetDR() != RC_OK");
        strSTBCancelReqResult.strResult = strLot_STBCancelInfo_GetDR_out.strResult;
        return(rc);
    }

    //--------------------------------------------
    // Set collected STB cancel information to temporary structure
    //--------------------------------------------
    PPT_METHODTRACE_V1("", "Set collected STB cancel information to temporary structure");
    pptSTBCancelledLotInfo        tmpSTBCancelledLotInfo ;
    pptNewPreparedLotInfoSequence tmpNewPreparedLotInfoSeq;
    pptSTBCancelWaferInfoSequence tmpSTBCancelWaferInfoSeq;

    tmpSTBCancelledLotInfo   = strLot_STBCancelInfo_GetDR_out.strSTBCancelledLotInfo ;
    tmpNewPreparedLotInfoSeq = strLot_STBCancelInfo_GetDR_out.strNewPreparedLotInfoSeq;
    tmpSTBCancelWaferInfoSeq = strLot_STBCancelInfo_GetDR_out.strSTBCancelWaferInfoSeq;

    //--------------------------------------------
    // Check if input cassetteID is STB cancelled lot's cassette
    //--------------------------------------------
    PPT_METHODTRACE_V1("", "Check if input cassetteID is STB cancelled lot's cassette");
    if( 0 != CIMFWStrCmp( inputNewLotAttributes.cassetteID.identifier,
                          tmpSTBCancelledLotInfo.cassetteID.identifier ) )
    {
        PPT_METHODTRACE_V2("", "STB cancelled lot is not in input cassette.", inputNewLotAttributes.cassetteID.identifier);
        SET_MSG_RC( strSTBCancelReqResult,
                    MSG_INVALID_INPUT_CAST_ID,
                    RC_INVALID_INPUT_CAST_ID );
        return RC_INVALID_INPUT_CAST_ID;
    }

    //--------------------------------------------------------------
    // Check if STB cancelled wafers' STB source lots info exist
    //--------------------------------------------------------------
    PPT_METHODTRACE_V1("", "Check if STB cancelled wafers' STB source lots info exist");
    CORBA::Long newPreparedLotLen = tmpNewPreparedLotInfoSeq.length() ;
    CORBA::Long castWaferLen      = tmpSTBCancelWaferInfoSeq.length() ;
    PPT_METHODTRACE_V2("", "newPreparedLotLen ", newPreparedLotLen) ;
    PPT_METHODTRACE_V2("", "castWaferLen      ", castWaferLen) ;
    for( i = 0; i < castWaferLen; i++ )
    {
        if( 0 == CIMFWStrCmp( tmpSTBCancelWaferInfoSeq[i].currentLotID.identifier,
                              STBCancelledLotID.identifier ) )
        {
            if( 0 == CIMFWStrLen(tmpSTBCancelWaferInfoSeq[i].STBSourceLotID) )
            {
                PPT_METHODTRACE_V2("", "This wafer doesn't have STB source lot info. Wafer ID = ",
                                        tmpSTBCancelWaferInfoSeq[i].waferID.identifier);
                PPT_SET_MSG_RC_KEY( strSTBCancelReqResult,
                                    MSG_WAFER_NO_STBSOURCELOT_INFO,
                                    RC_WAFER_NO_STBSOURCELOT_INFO,
                                    tmpSTBCancelWaferInfoSeq[i].waferID.identifier );
                return RC_WAFER_NO_STBSOURCELOT_INFO;
            }

            CORBA::Boolean bSTBInfoFoundFlag = FALSE;
            for( j = 0; j < newPreparedLotLen; j++ )
            {
                if( 0 == CIMFWStrCmp( tmpSTBCancelWaferInfoSeq[i].STBSourceLotID,
                                      tmpNewPreparedLotInfoSeq[j].STBSourceLotID ) )
                {
                    PPT_METHODTRACE_V3("", "STB source lot info is found for wafer. WaferID:STBSourceLotID",
                                           tmpSTBCancelWaferInfoSeq[i].waferID.identifier,
                                           tmpSTBCancelWaferInfoSeq[i].STBSourceLotID)
                    bSTBInfoFoundFlag = TRUE ;
                    break ;
                }
            }
            if( FALSE == bSTBInfoFoundFlag )
            {
                PPT_METHODTRACE_V2("", "STB source lot info for wafer doesn't exist. STBSourceLotID",
                                       tmpSTBCancelWaferInfoSeq[i].STBSourceLotID)
                PPT_SET_MSG_RC_KEY( strSTBCancelReqResult,
                                    MSG_STBSOURCELOT_INFO_NOT_EXIST,
                                    RC_STBSOURCELOT_INFO_NOT_EXIST,
                                    tmpSTBCancelWaferInfoSeq[i].STBSourceLotID );
                return RC_STBSOURCELOT_INFO_NOT_EXIST;
            }
        }
    }

    //------------------------------------------------------------------------------------------------
    // Set STB Cancel information to strSTBCancelInfoSeq to call productRequest_release_BySTBCancel
    //------------------------------------------------------------------------------------------------
    PPT_METHODTRACE_V1("", "Set STB Cancel information to strSTBCancelInfoSeq to call productRequest_release_BySTBCancel");
    nLen = inputNewPreparedLotInfoSeq.length();
    CORBA::Long inputWaferLen = inputNewLotAttributes.strNewWaferAttributes.length() ;
    PPT_METHODTRACE_V2("", "nLen =              ", nLen) ;
    PPT_METHODTRACE_V2("", "inputWaferLen =     ", inputWaferLen) ;

    pptSTBCancelInfoSequence strSTBCancelInfoSeq;
    strSTBCancelInfoSeq.length(newPreparedLotLen);
    for( i = 0; i < newPreparedLotLen; i++ )
    {
        CORBA::Boolean bLotFoundFlag = FALSE;
        pptNewLotAttributes tmpNewLotAttributes;
        tmpNewLotAttributes.strNewWaferAttributes.length(25);
        CORBA::Long newLotWaferCnt = 0;
        for( j = 0; j < nLen; j++ )
        {
            if( 0 == CIMFWStrCmp( tmpNewPreparedLotInfoSeq[i].STBSourceLotID,
                                  inputNewPreparedLotInfoSeq[j].STBSourceLotID ) )
            {
                PPT_METHODTRACE_V2("", "STBSourceLotID ", tmpNewPreparedLotInfoSeq[i].STBSourceLotID)

                tmpNewPreparedLotInfoSeq[i].lotType    = inputNewPreparedLotInfoSeq[j].lotType;
                tmpNewPreparedLotInfoSeq[i].subLotType = inputNewPreparedLotInfoSeq[j].subLotType;

                PPT_METHODTRACE_V2("", "lotType        ", tmpNewPreparedLotInfoSeq[i].lotType)
                PPT_METHODTRACE_V2("", "subLotType     ", tmpNewPreparedLotInfoSeq[i].subLotType)
                bLotFoundFlag = TRUE;

                for( k = 0; k < castWaferLen; k++ )
                {
                    PPT_METHODTRACE_V3("", "Round k:WaferID", k, tmpSTBCancelWaferInfoSeq[k].waferID.identifier )
                    if( 0 == CIMFWStrCmp( STBCancelledLotID.identifier,
                                          tmpSTBCancelWaferInfoSeq[k].currentLotID.identifier ) )
                    {
                        if( 0 == CIMFWStrCmp( tmpNewPreparedLotInfoSeq[i].STBSourceLotID,
                                              tmpSTBCancelWaferInfoSeq[k].STBSourceLotID ) )
                        {
                            PPT_METHODTRACE_V2("", "This wafer has STB source lot info. Wafer ID = ", tmpSTBCancelWaferInfoSeq[k].waferID.identifier) ;
                            tmpNewLotAttributes.strNewWaferAttributes[newLotWaferCnt].sourceWaferID = tmpSTBCancelWaferInfoSeq[k].waferID;
                            tmpNewLotAttributes.strNewWaferAttributes[newLotWaferCnt].sourceLotID   = STBCancelledLotID;
                            tmpNewLotAttributes.strNewWaferAttributes[newLotWaferCnt].newSlotNumber = tmpSTBCancelWaferInfoSeq[k].slotNo;
                            for( l = 0; l < inputWaferLen; l++ )
                            {
                                if( ( 0 == CIMFWStrCmp( tmpNewLotAttributes.strNewWaferAttributes[newLotWaferCnt].sourceWaferID.identifier,
                                                        inputNewLotAttributes.strNewWaferAttributes[l].sourceWaferID.identifier ) )
                                 && ( 0 < CIMFWStrLen(inputNewLotAttributes.strNewWaferAttributes[l].newWaferID.identifier) ) )
                                {
                                    PPT_METHODTRACE_V2("", "newWaferID is specified for the wafer. sourceWaferID",
                                                            tmpNewLotAttributes.strNewWaferAttributes[newLotWaferCnt].sourceWaferID.identifier) ;
                                    tmpNewLotAttributes.strNewWaferAttributes[newLotWaferCnt].newWaferID.identifier
                                     = inputNewLotAttributes.strNewWaferAttributes[l].newWaferID.identifier ;
                                }
                            }
                            newLotWaferCnt++;
                        }
                    }
                }
                tmpNewLotAttributes.cassetteID = inputNewLotAttributes.cassetteID ;
                tmpNewLotAttributes.strNewWaferAttributes.length(newLotWaferCnt);
                tmpNewPreparedLotInfoSeq[i].waferCount = newLotWaferCnt;

                strSTBCancelInfoSeq[i].strNewPreparedLotInfo = tmpNewPreparedLotInfoSeq[i];
                strSTBCancelInfoSeq[i].strNewLotAttributes   = tmpNewLotAttributes;
            }

        }
        if( FALSE == bLotFoundFlag )
        {
            PPT_METHODTRACE_V1("", "FALSE == bLotFoundFlag");
            PPT_SET_MSG_RC_KEY( strSTBCancelReqResult,
                                MSG_STBSOURCELOT_INFO_NOT_IN_INPUT,
                                RC_STBSOURCELOT_INFO_NOT_IN_INPUT,
                                tmpNewPreparedLotInfoSeq[i].STBSourceLotID );
            return RC_STBSOURCELOT_INFO_NOT_IN_INPUT;
        }
    }


    //------------------------------------------------------------------------------------------------
    // Set STB Cancel information to strSTBCancelInfoSeq to call productRequest_Release_BySTBCancel
    //------------------------------------------------------------------------------------------------
    CORBA::Long createdLotsLen = 0;
    createdLotsLen = strSTBCancelInfoSeq.length() ;
    PPT_METHODTRACE_V2("", "createdLotsLen = ", createdLotsLen);
    for( i = 0; i < createdLotsLen; i++)
    {
        //----------------------
        // Prepare Product Request for New Prepared Lot
        //----------------------
        PPT_METHODTRACE_V1("", "call productRequest_Release_BySTBCancel()") ;
        objProductRequest_release_BySTBCancel_out strProductRequest_release_BySTBCancel_out;
        objProductRequest_release_BySTBCancel_in  strProductRequest_release_BySTBCancel_in;
        strProductRequest_release_BySTBCancel_in.productID    = strSTBCancelInfoSeq[i].strNewPreparedLotInfo.productID;
        strProductRequest_release_BySTBCancel_in.bankID       = tmpSTBCancelledLotInfo.routeStartBankID;
        strProductRequest_release_BySTBCancel_in.lotType      = strSTBCancelInfoSeq[i].strNewPreparedLotInfo.lotType;
        strProductRequest_release_BySTBCancel_in.subLotType   = strSTBCancelInfoSeq[i].strNewPreparedLotInfo.subLotType;
        strProductRequest_release_BySTBCancel_in.productCount = strSTBCancelInfoSeq[i].strNewPreparedLotInfo.waferCount;

        rc = productRequest_release_BySTBCancel( strProductRequest_release_BySTBCancel_out,
                                                 strObjCommonIn,
                                                 strProductRequest_release_BySTBCancel_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "productRequest_release_BySTBCancel() != RC_OK", i);
            strSTBCancelReqResult.strResult = strProductRequest_release_BySTBCancel_out.strResult;
            return(rc);
        }

        strSTBCancelInfoSeq[i].prodReqID = strProductRequest_release_BySTBCancel_out.createdProductRequestID;
        PPT_METHODTRACE_V2("", "Created product reqest", strSTBCancelInfoSeq[i].prodReqID.identifier);

        //----------------------
        // Copy generated New Lot ID to structure
        //----------------------
        PPT_METHODTRACE_V1("", "Copy generated New Lot ID to structure");
        CORBA::Long waferLen = 0;
        waferLen = strSTBCancelInfoSeq[i].strNewLotAttributes.strNewWaferAttributes.length() ;
        PPT_METHODTRACE_V2("", "waferLen", waferLen);
        for(j = 0; j < waferLen; j++ )
        {
            strSTBCancelInfoSeq[i].strNewLotAttributes.strNewWaferAttributes[j].newLotID
             = strProductRequest_release_BySTBCancel_out.createdProductRequestID ;
        } //[j]

        //----------------------
        // Check input parameter
        //----------------------
        PPT_METHODTRACE_V1("", "call lot_parameterForLotGeneration_Check()");
        objLot_parameterForLotGeneration_Check_out strLot_parameterForLotGeneration_Check_out;
        strLot_parameterForLotGeneration_Check_out.bWaferIDAssignRequred = FALSE;
        rc = lot_parameterForLotGeneration_Check( strLot_parameterForLotGeneration_Check_out,
                                                  strObjCommonIn,
                                                  tmpSTBCancelledLotInfo.routeStartBankID,
                                                  strSTBCancelInfoSeq[i].strNewLotAttributes );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_parameterForLotGeneration_Check() != RC_OK");
            strSTBCancelReqResult.strResult = strLot_parameterForLotGeneration_Check_out.strResult;
            return(rc);
        }
        if( strLot_parameterForLotGeneration_Check_out.bWaferIDAssignRequred == TRUE )
        {
            PPT_METHODTRACE_V1("", "bWaferIDAssignRequred == TRUE");
            objLot_waferID_Generate_out strLot_waferID_Generate_out;
            rc = lot_waferID_Generate( strLot_waferID_Generate_out, strObjCommonIn,
                                       strSTBCancelInfoSeq[i].strNewLotAttributes );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_waferID_Generate() != RC_OK");
                strSTBCancelReqResult.strResult = strLot_waferID_Generate_out.strResult;
                return(rc);
            }
            strSTBCancelInfoSeq[i].strNewLotAttributes = strLot_waferID_Generate_out.strNewLotAttributes;
        }

        waferLen = strSTBCancelInfoSeq[i].strNewLotAttributes.strNewWaferAttributes.length();
        PPT_METHODTRACE_V2("", "waferLen", waferLen);
        for( j = 0; j < waferLen; j++ )
        {
            if( 0 == CIMFWStrLen( strSTBCancelInfoSeq[i].strNewLotAttributes.strNewWaferAttributes[j].newWaferID.identifier ) )
            {
                PPT_METHODTRACE_V2("", "count j = ", j);
                strSTBCancelInfoSeq[i].strNewLotAttributes.strNewWaferAttributes[j].newWaferID
                 = strSTBCancelInfoSeq[i].strNewLotAttributes.strNewWaferAttributes[j].sourceWaferID;
            }
        } //[j]
    } //[i]

    //----------------------
    // Check STB Cancel Condition for Cassette, Lot, Wafer, Bank
    //----------------------
    PPT_METHODTRACE_V1("", "call lot_STBCancel_Check()");
    objLot_STBCancel_Check_out strLot_STBCancel_Check_out;
    objLot_STBCancel_Check_in  strLot_STBCancel_Check_in;
    strLot_STBCancel_Check_in.STBCancelledLotID   = STBCancelledLotID;
    strLot_STBCancel_Check_in.startBankID         = tmpSTBCancelledLotInfo.routeStartBankID;
    strLot_STBCancel_Check_in.strSTBCancelInfoSeq = strSTBCancelInfoSeq;

    rc = lot_STBCancel_Check( strLot_STBCancel_Check_out,
                              strObjCommonIn,
                              strLot_STBCancel_Check_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "lot_STBCancel_Check() != RC_OK", i);
        strSTBCancelReqResult.strResult = strLot_STBCancel_Check_out.strResult;
        return(rc);
    }

    //----------------------
    // STB Cancel
    //----------------------
    PPT_METHODTRACE_V1("", "call lot_STB_Cancel()");
    objLot_STB_Cancel_out strLot_STB_Cancel_out;
    objLot_STB_Cancel_in  strLot_STB_Cancel_in;
    strLot_STB_Cancel_in.STBCancelledLotID   = STBCancelledLotID;
    strLot_STB_Cancel_in.startBankID         = tmpSTBCancelledLotInfo.routeStartBankID;
    strLot_STB_Cancel_in.strSTBCancelInfoSeq = strSTBCancelInfoSeq;

    rc = lot_STB_Cancel( strLot_STB_Cancel_out, strObjCommonIn, strLot_STB_Cancel_in );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V2("", "lot_STB_Cancel() != RC_OK", i);
        strSTBCancelReqResult.strResult = strLot_STB_Cancel_out.strResult;
        return(rc);
    }

    pptPreparedLotInfoSequence strPreparedLotInfoSeq ;
    strPreparedLotInfoSeq = strLot_STB_Cancel_out.strPreparedLotInfoSeq;
    unsigned int preparedLotLen = 0 ;
    preparedLotLen = strPreparedLotInfoSeq.length() ;

//DSN000071674 add start
    if ( TRUE == updateControlJobFlag )
    {
        //----------------------
        // Update control Job Info and
        // Machine Cassette info if information exist
        //----------------------
        objectIdentifierSequence tmpCassetteIDSeq;
        tmpCassetteIDSeq.length(1);
        tmpCassetteIDSeq[0] = inputNewLotAttributes.cassetteID;
        objControlJob_relatedInfo_Update_out strControlJob_relatedInfo_Update_out;
        rc = controlJob_relatedInfo_Update(strControlJob_relatedInfo_Update_out, strObjCommonIn,
                                           tmpCassetteIDSeq);
        if (rc)
        {
            PPT_METHODTRACE_V2("", "controlJob_relatedInfo_Update() != RC_OK", rc);
            strSTBCancelReqResult.strResult = strControlJob_relatedInfo_Update_out.strResult;
            return(rc);
        }
    }
//DSN000071674 add end

    //----------------------
    // Update cassette multi lot type
    //----------------------
    PPT_METHODTRACE_V1("", "Update cassette multi lot type");
    objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
    rc = cassette_multiLotType_Update( strCassette_multiLotType_Update_out, strObjCommonIn,
                                       inputNewLotAttributes.cassetteID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "cassette_multiLotType_Update() != RC_OK");
        strSTBCancelReqResult.strResult = strCassette_multiLotType_Update_out.strResult;
        return(rc);
    }

    /*----------------------------------------------------------------------------*/
    /*   Prepare structure for making history                                     */
    /*   ######### Attention !! ##########                                        */
    /*       To reuse the existing LotWaferMoveEvent, STB cancel history          */
    /*     information is set to strNewLotAttributesHstry in reverse.             */
    /*     ex)                                                                    */
    /*        strNewWaferAttributes[].sourceWaferID = waferID after STB cancel    */
    /*        strNewWaferAttributes[].newWaferID    = waferID before STB cancel   */
    /*        strNewWaferAttributes[].sourceLotID   = LotID after STB cancel      */
    /*        strNewWaferAttributes[].newLotID      = LotID before STB cancel     */
    /*----------------------------------------------------------------------------*/
    unsigned int newLotLen = strSTBCancelInfoSeq.length() ;
    PPT_METHODTRACE_V2("", "newLotLen", newLotLen);
    pptNewLotAttributes strNewLotAttributesHstry;
    strNewLotAttributesHstry.strNewWaferAttributes.length(inputWaferLen);
    unsigned int waferCnt = 0 ;
    unsigned int newLotWaferLen = 0 ;
    for( i = 0; i < newLotLen; i++ )
    {
        PPT_METHODTRACE_V2("", "Round for i", i);
        newLotWaferLen = strSTBCancelInfoSeq[i].strNewLotAttributes.strNewWaferAttributes.length() ;
        for( j = 0; j < newLotWaferLen; j++ )
        {
            PPT_METHODTRACE_V3("", "Round for wafer [j:newWaferID]", j, strSTBCancelInfoSeq[i].strNewLotAttributes.strNewWaferAttributes[j].newWaferID.identifier);
            for( k = 0; k < preparedLotLen; k++ )
            {
                if( 0 == CIMFWStrCmp( strSTBCancelInfoSeq[i].strNewLotAttributes.strNewWaferAttributes[j].newLotID.identifier,
                                      strPreparedLotInfoSeq[k].lotID.identifier ) )
                {
                    PPT_METHODTRACE_V2("", "lotID is found in new prepared lots", strPreparedLotInfoSeq[k].lotID.identifier);
                    strNewLotAttributesHstry.strNewWaferAttributes[waferCnt].sourceLotID = strPreparedLotInfoSeq[k].lotID ;
                }
            }
            strNewLotAttributesHstry.strNewWaferAttributes[waferCnt].sourceWaferID = strSTBCancelInfoSeq[i].strNewLotAttributes.strNewWaferAttributes[j].newWaferID ;
            strNewLotAttributesHstry.strNewWaferAttributes[waferCnt].sourceWaferID.stringifiedObjectReference
             = strSTBCancelInfoSeq[i].strNewLotAttributes.strNewWaferAttributes[j].sourceWaferID.stringifiedObjectReference ;
            strNewLotAttributesHstry.strNewWaferAttributes[waferCnt].newWaferID    = strSTBCancelInfoSeq[i].strNewLotAttributes.strNewWaferAttributes[j].sourceWaferID ;
            strNewLotAttributesHstry.strNewWaferAttributes[waferCnt].newLotID      = strSTBCancelInfoSeq[i].strNewLotAttributes.strNewWaferAttributes[j].sourceLotID ;
            strNewLotAttributesHstry.strNewWaferAttributes[waferCnt].newSlotNumber = strSTBCancelInfoSeq[i].strNewLotAttributes.strNewWaferAttributes[j].newSlotNumber ;
            waferCnt++;
        }
    }
    strNewLotAttributesHstry.strNewWaferAttributes.length(waferCnt);
    PPT_METHODTRACE_V2("", "waferCnt", waferCnt);

    /*------------------------------------------------------------------------*/
    /*   Make History                                                         */
    /*------------------------------------------------------------------------*/
    //call lot_waferLotHistoryPointer_Update() for STB cancelled lot
    PPT_METHODTRACE_V1("", "call lot_waferLotHistoryPointer_Update() for STB cancelled lot");
    objLot_waferLotHistoryPointer_Update_out  strLot_waferLotHistoryPointer_Update_out;
    rc = lot_waferLotHistoryPointer_Update( strLot_waferLotHistoryPointer_Update_out, strObjCommonIn, STBCancelledLotID );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_waferLotHistoryPointer_Update() != RC_OK");
        SET_MSG_RC( strSTBCancelReqResult, MSG_FAIL_MAKE_HISTORY, rc );
        return rc;
    }

    //call lot_waferLotHistoryPointer_Update() for new prepared lots
    PPT_METHODTRACE_V1("", "call lot_waferLotHistoryPointer_Update() for new prepared lots");
    createdLotsLen = strLot_STB_Cancel_out.strPreparedLotInfoSeq.length() ;
    PPT_METHODTRACE_V2("", "createdLotsLen", createdLotsLen) ;
    for( i = 0; i < createdLotsLen; i++ )
    {
        PPT_METHODTRACE_V3("", "call lot_waferLotHistoryPointer_Update(). count i:LotID",
                               i,
                               strLot_STB_Cancel_out.strPreparedLotInfoSeq[i].lotID.identifier);
        objLot_waferLotHistoryPointer_Update_out  strLot_waferLotHistoryPointer_Update_out;
        rc = lot_waferLotHistoryPointer_Update( strLot_waferLotHistoryPointer_Update_out, strObjCommonIn,
                                                strLot_STB_Cancel_out.strPreparedLotInfoSeq[i].lotID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "lot_waferLotHistoryPointer_Update() != RC_OK");
            SET_MSG_RC( strSTBCancelReqResult, MSG_FAIL_MAKE_HISTORY, rc );
            return rc;
        }
    } //[i]

    //Make wafer move event
    PPT_METHODTRACE_V1("", "call lotWaferMoveEvent_Make()");
    objLotWaferMoveEvent_Make_out strLotWaferMoveEvent_Make_out;
    rc = lotWaferMoveEvent_Make( strLotWaferMoveEvent_Make_out, strObjCommonIn,
                                 "TXTRC083", strNewLotAttributesHstry, claimMemo );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lotWaferMoveEvent_Make() != RC_OK");
        SET_MSG_RC( strSTBCancelReqResult, MSG_FAIL_MAKE_HISTORY, rc );
        return(rc);
    }

    //----------------------
    // Set created lot information to output structure
    //----------------------
    PPT_METHODTRACE_V1("", "Set created lot information to output structure");
    strSTBCancelReqResult.strPreparedLotInfoSeq = strLot_STB_Cancel_out.strPreparedLotInfoSeq;
    strSTBCancelReqResult.bankID = tmpSTBCancelledLotInfo.routeStartBankID;

    //----------------
    // Return
    //----------------
    SET_MSG_RC(strSTBCancelReqResult, MSG_OK, RC_OK);
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::txSTBCancelReq ");
    return RC_OK ;

}
