#ifndef lint
static char *sccsid =  "@(#) 1.7 superpos/src/spppt/source/posppt/pptmgr/txmethods/txEqpPortStatusChangeRpt.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 6/13/08 20:18:12 [ 6/13/08 20:18:13 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: txEqpPortStatusChangeRpt.cpp
//

#include "cs_pptmgr.hpp"

// Class: PPTManager
//
// Service: txEqpPortStatusChangeRpt()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/16          S.Kawabe       Initial Release (R30)
// 2000/09/05 P3000040 S.Kawabe       Bug fix
// 2000/09/09 P3000100 M.Mori         Change mode condition
// 2000/09/25 0.02     S.Tokumasu     Add txSingleCarrierXferReq during no exist DeliveryReq.
// 2000/10/17 Q3000300 S.Tokumasu     debug
// 2000/10/26 P3000298 S.Kawabe       using CIMFWStrDup(getenv("SP_XXX"));
// 2000/10/26 P3000300 S.Tokumasu     remove SystemMsg
// 2000-12-07 P3000364 S.Tokumasu     Add Empty Cassette Logic
// 2001-01-17 P3000426 K.Matsuei      Bug fix for Memory Leak
// 2001/03/22 P3100156 M.Mori         Dispatch State Change Fail
// 2001/03/26 P3100156 M.Mori         Bug Fix
// 2001/04/25 P3100300 M.Mori         Carrier-ID for UnloadReq/UnloadComp when CarrierIDRead-Error
// 2001/05/29 D4000011 M.Mori         Add getenv Values on Manager Class Member
// 2001/07/25 P4000065 K.Kido         When lot_GetNextStockerDR() returns RC_INVLID_LOT_PROCSTAT,
//                                    change returncode LOCKED_BY_ANOTHER
// 2001/10/09 P4000332 K.Matsuei      E-Mail for Error which CassetteDelivery sends is inappropriate.
// 2001/10/30 D4000255 Y.Iwasaki      Add "Unknown" port status handling logic
// 2002/02/14 D4100134 C.Tsuchiya     Drop D4000011
// 2003/11/27 D5100078 S.Yamamoto     Delete unnecessary event creation object methods.
// 2004/10/22 D6000025 K.Murakami     eBroker Migration.
// 2005/12/12 D7000096 Y.Kadowaki     Delete environment variable "SP_DELIVERY_REQ_EXIST"
// 2007/07/12 P9000027 H.Hotta        Add logic of clearing Dispatch Reserve at LoadReq.
// 2007/08/29 P9000027(0.01) K.Kido   Change logic of clearing Dispatch Reserve at LoadReq.
// 2008/02/21 D9000175 K.Kido         Change for takeOutIn function.
// 2008/02/27 P9000237 K.Matsuei      NPW Reserve information is not maintained properly when UnloadReq is reported.
// 2008/06/13 P9000307 K.Kido         Call equipment_portGroupInfo_Get instead of equipment_portInfo_Get
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2011/08/09 DSN000015229 Yang Xia       equipment_brInfoForInternalBuffer_GetDR ==> equipment_brInfoForInternalBuffer_GetDR__120
// 2016/10/25 DSN000101505 C.Mo           Port Status Change History Support
//
// Innotron Modification history:
// Date       DCR/PCR No   Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/18 INN-R170003  LiHejing       Durable Management Enhancement.
//
//
// Description:
//     TXEQR002
//
// Return:
//     long
//
// Parameter:
//
//     pptEqpPortStatusChangeRptResult& strEqpPortStatusChangeRptResult
//     const pptObjCommonIn& strObjCommonIn
//     const objectIdentifier& equipmentID
//     const pptEqpPortEventOnTCSSequence& strEqpPortEventOnTCS
//     const char * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::txEqpPortStatusChangeRpt (pptEqpPortStatusChangeRptResult& strEqpPortStatusChangeRptResult,
                                                    const pptObjCommonIn& strObjCommonIn,
                                                    const objectIdentifier& equipmentID,
//D4000255                                          const pptEqpPortEventOnTCSSequence& strEqpPortEventOnTCS,
                                                    const pptEqpPortEventOnTCSSequence& strEqpPortEventOnTCSconst,  //D4000255
//D6000025                                                     const char * claimMemo,
//D6000025                                                     CORBA::Environment &IT_env)
                                                    const char * claimMemo //D6000025
                                                    CORBAENV_LAST_CPP)     //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txEqpPortStatusChangeRpt ") ;
    CORBA::Long rc = RC_OK ;

    //D4000255 add start
    //--------------------------------//
    //   Convert "Unknown" to "-"     //
    //--------------------------------//
    pptEqpPortEventOnTCSSequence  strEqpPortEventOnTCS;
    strEqpPortEventOnTCS = strEqpPortEventOnTCSconst;

    CORBA::Long nLen = strEqpPortEventOnTCS.length();

    for ( CORBA::Long ii=0 ; ii<nLen ; ii++ )
    {
        if ( CIMFWStrCmp(strEqpPortEventOnTCS[ii].portStatus, SP_PortRsc_PortState_UnknownForTCS) == 0 )
        {
            strEqpPortEventOnTCS[ii].portStatus = CIMFWStrDup(SP_PortRsc_PortState_Unknown);
        }
    }
    //D4000255 add end

    /*--------------------------------*/
    /*   Lock objects to be updated   */
    /*--------------------------------*/
    objObject_LockForEquipmentResource_out strObject_LockForEquipmentResource_out;

    CORBA::Long seqLen = strEqpPortEventOnTCS.length();
    PPT_METHODTRACE_V2("", "trEqpPortEventOnTCS.length()", seqLen) ;

    booleanSequence bAccessModeFlagSeq;       //P3100300
    bAccessModeFlagSeq.length(seqLen);        //P3100300

    for (CORBA::Long i=0; i<seqLen; i++)
    {
        rc = object_LockForEquipmentResource( strObject_LockForEquipmentResource_out,
                                              strObjCommonIn,
                                              equipmentID,
                                              strEqpPortEventOnTCS[i].portID,
                                              SP_ClassName_PosPortResource );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "object_LockForEquipmentResource() != RC_OK", i) ;
            strEqpPortStatusChangeRptResult.strResult = strObject_LockForEquipmentResource_out.strResult ;
            return( rc );
        }
    }

    /*------------------------------*/
    /*   Check Port Operation Mode  */
    /*------------------------------*/
    for (i=0; i<seqLen; i++)
    {
        objPortResource_currentOperationMode_Get_out  strPortResource_currentOperationMode_Get_out;
        rc = portResource_currentOperationMode_Get(strPortResource_currentOperationMode_Get_out,
                                                   strObjCommonIn,
                                                   equipmentID,
                                                   strEqpPortEventOnTCS[i].portID);

//P3100300 add start
        if ( CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode, SP_Eqp_AccessMode_Auto) == 0  )
        {
            PPT_METHODTRACE_V1("", "CIMFWStrCmp(strEquipment_operationMode_Get_out.strOperationMode.accessMode, SP_Eqp_AccessMode_Auto) == 0") ;
            bAccessModeFlagSeq[i] = TRUE;
        }
        else
        {
            PPT_METHODTRACE_V1("", "CIMFWStrCmp(strEquipment_operationMode_Get_out.strOperationMode.accessMode, SP_Eqp_AccessMode_Auto) != 0") ;
            bAccessModeFlagSeq[i] = FALSE;
        }
//P3100300 add end

//P3000100        if ( CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode ,SP_Eqp_OnlineMode_OnlineRemote ) !=0 )
        if ( CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode ,SP_Eqp_OnlineMode_Offline ) ==0 )
        {
            PPT_METHODTRACE_V1("", "CIMFWStrCmp(strEquipment_operationMode_Get_out.operationMode,SP_Eqp_OnlineMode_Offline) == 0") ;
            PPT_SET_MSG_RC_KEY2(strEqpPortStatusChangeRptResult,
                                MSG_INVALID_EQP_MODE,
                                RC_INVALID_EQP_MODE,
                                equipmentID.identifier,
                                strPortResource_currentOperationMode_Get_out.strOperationMode.onlineMode) ;
            return( RC_INVALID_EQP_MODE);
        }
    }
//D9000175 add start
    /*----------------------------------*/
    /*  Check equipment TakeOutInMode   */
    /*----------------------------------*/
    objEquipment_TakeOutInMode_Check_out strEquipment_TakeOutInMode_Check_out;
    objEquipment_TakeOutInMode_Check_in strEquipment_TakeOutInMode_Check_in;
    strEquipment_TakeOutInMode_Check_in.equipmentID = equipmentID;
    rc = equipment_TakeOutInMode_Check( strEquipment_TakeOutInMode_Check_out, strObjCommonIn,
                                        strEquipment_TakeOutInMode_Check_in);
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "### equipment_TakeOutInMode_Check() != RC_OK");
        strEqpPortStatusChangeRptResult.strResult = strEquipment_TakeOutInMode_Check_out.strResult ;
        return rc ;
    }

    CORBA::Long eqpTakeOutInSupport = strEquipment_TakeOutInMode_Check_out.eqpTakeOutInSupport;
    PPT_METHODTRACE_V2("", "### eqpTakeOutInSupport = ",eqpTakeOutInSupport);

    /*-----------------------------------*/
    /*  Get equipment port information   */
    /*-----------------------------------*/
    CORBA::Boolean takeOutInModeFlag = FALSE;
    objEquipment_portInfo_GetDR_out strEquipment_portInfo_GetDR_out;
//INN-R170003    if( 1 == eqpTakeOutInSupport )
//INN-R170003    {
        //Get port control job information for port status change by TakeOutIn mode.
        rc = equipment_portInfo_GetDR( strEquipment_portInfo_GetDR_out,
                                       strObjCommonIn,
                                       equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("","equipment_portInfo_Get != RC_OK");
            strEqpPortStatusChangeRptResult.strResult = strEquipment_portInfo_GetDR_out.strResult;
            return( rc );
        }
//INN-R170003    }
//D9000175 add end
//INN-R170003 add start
    CORBA::Long e, f;
    objObject_Lock_out strObject_Lock_out;
    PPT_METHODTRACE_V2("", "### seqLen = ",seqLen);
    for (f=0; f<seqLen; f++)
    {
        PPT_METHODTRACE_V2("", "### strEqpPortEventOnTCS[f].portStatus = ",strEqpPortEventOnTCS[f].portStatus);
        if ( CIMFWStrCmp(strEqpPortEventOnTCS[f].portStatus , SP_PortRsc_PortState_UnloadReq) == 0  )
        {
            PPT_METHODTRACE_V2("", "### strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus.length() = ",strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus.length());
            for (e=0; e<strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus.length(); e++)
            {
                PPT_METHODTRACE_V2("", "### strEqpPortEventOnTCS[f].portID.identifier = ",strEqpPortEventOnTCS[f].portID.identifier);
                if ( CIMFWStrCmp( strEqpPortEventOnTCS[f].portID.identifier , strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[e].portID.identifier ) == 0  )
                {
                    PPT_METHODTRACE_V2(" ", "PortEventOnTCS.PortID = EqpPortInfo.PortID, Port = ", strEqpPortEventOnTCS[f].portID.identifier);
                    rc = object_Lock( strObject_Lock_out, strObjCommonIn ,strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[e].loadedCassetteID, SP_ClassName_PosCassette );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2(" ", "##### RC_OK != object_Lock()", rc);
                        strEqpPortStatusChangeRptResult.strResult = strObject_Lock_out.strResult;
                        return rc;
                    }
                    break;
                }
            }
        }
    }
//INN-R170003 add end

    CORBA::Long j = 0;
    objEquipment_portState_Change_out strEquipment_portState_Change_out;
    pptDeleteUnloadableLotSequence    strDeleteUnloadableLot;

    for (i=0; i<seqLen; i++)
    {
//D9000175 add start
        if( 1 == eqpTakeOutInSupport )
        {
            PPT_METHODTRACE_V2("", "### Check controlJob existence for port ", strEqpPortEventOnTCS[i].portID.identifier);
            CORBA::ULong portLen = strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
            CORBA::Boolean takeOutModeFlag = FALSE;
            for( CORBA::ULong j = 0 ; j < portLen ; j++ )
            {
                /*------------------------------------*/
                /*  Check port controlJob existence   */
                /*------------------------------------*/
                if(  0 == CIMFWStrCmp(strEqpPortEventOnTCS[i].portID.identifier, strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID.identifier)
                  && 0 != CIMFWStrLen(strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].loadResrvedCassetteID.identifier)
                  )
                {
                    PPT_METHODTRACE_V1("", "### This port has control job. change port status by TakeOutIn mode ");
                    objEquipment_portState_ChangeForTakeOutInMode_out strEquipment_portState_ChangeForTakeOutInMode_out;
                    objEquipment_portState_ChangeForTakeOutInMode_in  strEquipment_portState_ChangeForTakeOutInMode_in;
                    strEquipment_portState_ChangeForTakeOutInMode_in.equipmentID = equipmentID;
                    strEquipment_portState_ChangeForTakeOutInMode_in.portID = strEqpPortEventOnTCS[i].portID;
                    strEquipment_portState_ChangeForTakeOutInMode_in.portStatus = strEqpPortEventOnTCS[i].portStatus;
                    strEquipment_portState_ChangeForTakeOutInMode_in.cassetteID = strEqpPortEventOnTCS[i].cassetteID;

                    rc = equipment_portState_ChangeForTakeOutInMode( strEquipment_portState_ChangeForTakeOutInMode_out,
                                                                     strObjCommonIn,
                                                                     strEquipment_portState_ChangeForTakeOutInMode_in );

                    if(rc!=RC_OK)
                    {
                        PPT_METHODTRACE_V1("", "equipment_portState_ChangeForTakeOutInMode() != RC_OK") ;
                        strEqpPortStatusChangeRptResult.strResult = strEquipment_portState_ChangeForTakeOutInMode_out.strResult ;
                        return rc;
                    }

                    takeOutModeFlag = TRUE;
                    break;
                }
            }

            if( TRUE == takeOutModeFlag )
            {
                PPT_METHODTRACE_V1("", "### port status was changed by TakeOutInMode. other port status should not be changed.... continue!!!") ;
                continue;
            }
        }
//D9000175 add end

        /*----------------------------------*/
        /*   Change Equipment Port Status   */
        /*----------------------------------*/
        rc = equipment_portState_Change(strEquipment_portState_Change_out,
                                        strObjCommonIn,
                                        equipmentID,
                                        strEqpPortEventOnTCS[i].portID,
                                        strEqpPortEventOnTCS[i].portStatus,
                                        strEqpPortEventOnTCS[i].cassetteID);
        if(rc!=RC_OK)
        {
            PPT_METHODTRACE_V1("", "equipment_portState_Change() != RC_OK") ;
            strEqpPortStatusChangeRptResult.strResult = strEquipment_portState_Change_out.strResult ;
            return (rc);
        }

        if ( CIMFWStrCmp(strEqpPortEventOnTCS[i].portStatus, SP_PortRsc_PortState_UnloadComp) == 0)
        {
            /*-----------------------------------------------------------*/
            /*   Set Unload Lot Information to be deleted in Equipment   */
            /*-----------------------------------------------------------*/
            CORBA::Long lotIDLen  = 0;
            CORBA::Long castIDLen = 0;

            lotIDLen  = CIMFWStrLen( strEqpPortEventOnTCS[i].lotID.identifier      );
            castIDLen = CIMFWStrLen( strEqpPortEventOnTCS[i].cassetteID.identifier );

            if ( lotIDLen > 0 )
            {
                if ( *(strEqpPortEventOnTCS[i].lotID.identifier) == ' ' )
                {
                    lotIDLen = 0;
                }
            }
            if ( castIDLen > 0 )
            {
                if ( *(strEqpPortEventOnTCS[i].cassetteID.identifier) == ' ' )
                {
                    castIDLen = 0;
                }
            }

            if ( lotIDLen == 0 && castIDLen == 0 )
            {
                continue;
            }

            strDeleteUnloadableLot.length( j+1 );
            strDeleteUnloadableLot[j].lotID        = strEqpPortEventOnTCS[i].lotID;
            strDeleteUnloadableLot[j].cassetteID   = strEqpPortEventOnTCS[i].cassetteID;
            strDeleteUnloadableLot[j].unloadPortID = strEqpPortEventOnTCS[i].portID;
            j++;
        }

//P3100156 add start
        if ( CIMFWStrCmp(strEqpPortEventOnTCS[i].portStatus, SP_PortRsc_PortState_LoadReq) == 0)
        {
//P9000027(0.01) add start
            //----------------------------------------------------------
            //  Check NPW Reservation for Fixed buffer equipment
            //----------------------------------------------------------
//DSN000015229            objEquipment_brInfoForInternalBuffer_GetDR_out strEquipment_brInfoForInternalBuffer_GetDR_out;
//DSN000015229            rc = equipment_brInfoForInternalBuffer_GetDR( strEquipment_brInfoForInternalBuffer_GetDR_out,
//DSN000015229                                                          strObjCommonIn,
//DSN000015229                                                          equipmentID );
//DSN000015229            if ( rc != RC_OK )
//DSN000015229            {
//DSN000015229                PPT_METHODTRACE_V1("", "equipment_brInfoForInternalBuffer_GetDR() != RC_OK");
//DSN000015229                strEqpPortStatusChangeRptResult.strResult = strEquipment_brInfoForInternalBuffer_GetDR_out.strResult;
//DSN000015229                return( rc );
//DSN000015229            }
//DSN000015229 Add Start
            objEquipment_brInfoForInternalBuffer_GetDR__120_out strEquipment_brInfoForInternalBuffer_GetDR_out;
            rc = equipment_brInfoForInternalBuffer_GetDR__120( strEquipment_brInfoForInternalBuffer_GetDR_out,
                                                               strObjCommonIn,
                                                               equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "equipment_brInfoForInternalBuffer_GetDR__120() != RC_OK" );
                strEqpPortStatusChangeRptResult.strResult = strEquipment_brInfoForInternalBuffer_GetDR_out.strResult;
                return( rc );
            }
//DSN000015229 Add End

            PPT_METHODTRACE_V2("", "equipmentCategory", strEquipment_brInfoForInternalBuffer_GetDR_out.equipmentBRInfoForInternalBuffer.equipmentCategory);

            if( 0 != CIMFWStrCmp( strEquipment_brInfoForInternalBuffer_GetDR_out.equipmentBRInfoForInternalBuffer.equipmentCategory, SP_Mc_Category_InternalBuffer ) )
            {
                PPT_METHODTRACE_V2("", "Equipment Category is fixed Buffer ", equipmentID.identifier);
//P9000027(0.01) add end
//P9000027 add start
                //-------------------------------------
                //   Get Reserve CarrierID
                //-------------------------------------
                PPT_METHODTRACE_V1("", "Get Reserve CarrierID");
                objEquipment_NPWReserveInfo_GetDR_out strEquipment_NPWReserveInfo_GetDR_out;
                objEquipment_NPWReserveInfo_GetDR_in strEquipment_NPWReserveInfo_GetDR_in;
                strEquipment_NPWReserveInfo_GetDR_in.equipmentID = equipmentID;
                rc = equipment_NPWReserveInfo_GetDR( strEquipment_NPWReserveInfo_GetDR_out,
                                                     strObjCommonIn,
                                                     strEquipment_NPWReserveInfo_GetDR_in);

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "equipment_NPWReserveInfo_GetDR() rc != RC_OK");
                    strEqpPortStatusChangeRptResult.strResult = strEquipment_NPWReserveInfo_GetDR_out.strResult;
                    return( rc );
                }

                CORBA::Long npwReserveLen = strEquipment_NPWReserveInfo_GetDR_out.strNPWReserveInfoSeq.length();
                for( CORBA::Long l=0; l<npwReserveLen; l++ )
                {
                    if( CIMFWStrCmp(strEquipment_NPWReserveInfo_GetDR_out.strNPWReserveInfoSeq[l].reservedLoadPortID.identifier, strEqpPortEventOnTCS[i].portID.identifier) == 0 )
                    {
                        //-------------------------------------
                        //   Check Cassette's Dispatch State
                        //-------------------------------------
                        PPT_METHODTRACE_V2("", "carrierID = ", strEqpPortEventOnTCS[i].cassetteID.identifier);

                        PPT_METHODTRACE_V1("", "Check Cassette's Dispatch State");
                        objCassette_dispatchState_Get_out strCassette_dispatchState_Get_out;
                        rc = cassette_dispatchState_Get( strCassette_dispatchState_Get_out,
                                                         strObjCommonIn,
                                                         strEquipment_NPWReserveInfo_GetDR_out.strNPWReserveInfoSeq[l].cassetteID);

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "cassette_dispatchState_Get() rc != RC_OK");
                            strEqpPortStatusChangeRptResult.strResult = strCassette_dispatchState_Get_out.strResult;
                            return( rc );
                        }

                        PPT_METHODTRACE_V2("", "dispatchReservedFlag =", strCassette_dispatchState_Get_out.dispatchReservedFlag );

                        if( strCassette_dispatchState_Get_out.dispatchReservedFlag == FALSE )
                        {
                            PPT_METHODTRACE_V1("", "dispatchReservedFlag == FALSE, dispatchReserve is already Cleared.");
                        }
                        else
                        {
                            //-----------------------------------------------
                            //   Change Cassette's Dispatch State to FALSE
                            //-----------------------------------------------
                            PPT_METHODTRACE_V1("", "dispatchReservedFlag == TRUE, Need to Change Cassette's Dispatch State to FALSE.");

                            objCassette_dispatchState_Change_out strCassette_dispatchState_Change_out;
                            rc = cassette_dispatchState_Change( strCassette_dispatchState_Change_out,
                                                                strObjCommonIn,
                                                                strEquipment_NPWReserveInfo_GetDR_out.strNPWReserveInfoSeq[l].cassetteID,
                                                                FALSE );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("", "cassette_dispatchState_Change() rc != RC_OK");
                                strEqpPortStatusChangeRptResult.strResult = strCassette_dispatchState_Change_out.strResult;
                                return( rc );
                            }
                            //--------------------------------------------------
                            //   Change Cassette's NPWLoadPurposeType to NULL
                            //--------------------------------------------------
                            PPT_METHODTRACE_V1("", "Change Cassette's NPWLoadPurposeType to NULL" );

                            objCassette_SetNPWLoadPurposeType_out strCassette_SetNPWLoadPurposeType_out;
                            rc = cassette_SetNPWLoadPurposeType( strCassette_SetNPWLoadPurposeType_out ,
                                                                 strObjCommonIn,
                                                                 strEquipment_NPWReserveInfo_GetDR_out.strNPWReserveInfoSeq[l].cassetteID,
                                                                 NULL );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("", "cassette_SetNPWLoadPurposeType() != RC_OK" );
                                strEqpPortStatusChangeRptResult.strResult = strCassette_SetNPWLoadPurposeType_out.strResult ;
                                return( rc );
                            }
                        }

//P9000027(0.01)    //----------------------------------------------------------
//P9000027(0.01)    //  NPW Reservation cancel for Internal Buffer equipment
//P9000027(0.01)    //----------------------------------------------------------
//P9000027(0.01)    objEquipment_brInfoForInternalBuffer_GetDR_out strEquipment_brInfoForInternalBuffer_GetDR_out;
//P9000027(0.01)    rc = equipment_brInfoForInternalBuffer_GetDR( strEquipment_brInfoForInternalBuffer_GetDR_out,
//P9000027(0.01)                                                  strObjCommonIn,
//P9000027(0.01)                                                  equipmentID );
//P9000027(0.01)    if ( rc != RC_OK )
//P9000027(0.01)    {
//P9000027(0.01)        PPT_METHODTRACE_V1("", "equipment_brInfoForInternalBuffer_GetDR() != RC_OK");
//P9000027(0.01)        strEqpPortStatusChangeRptResult.strResult = strEquipment_brInfoForInternalBuffer_GetDR_out.strResult;
//P9000027(0.01)        return( rc );
//P9000027(0.01)    }
//P9000027(0.01)
//P9000027(0.01)    PPT_METHODTRACE_V2("", "equipmentCategory", strEquipment_brInfoForInternalBuffer_GetDR_out.equipmentBRInfoForInternalBuffer.equipmentCategory);
//P9000027(0.01)
//P9000027(0.01)    if( 0 == CIMFWStrCmp( strEquipment_brInfoForInternalBuffer_GetDR_out.equipmentBRInfoForInternalBuffer.equipmentCategory, SP_Mc_Category_InternalBuffer ) )
//P9000027(0.01)    {
//P9000027(0.01)        PPT_METHODTRACE_V2("", "Equipment Category is Internal Buffer ", equipmentID.identifier);
//P9000027(0.01)        objectIdentifier dummyID;
//P9000027(0.01)        pptNPWXferCassetteSequence strNPWXferCassette;
//P9000027(0.01)        strNPWXferCassette.length(1);
//P9000027(0.01)        strNPWXferCassette[0].cassetteID = strEquipment_NPWReserveInfo_GetDR_out.strNPWReserveInfoSeq[l].cassetteID;
//P9000027(0.01)
//P9000027(0.01)        objEquipment_ArrivalCarrierCancelForInternalBuffer_out strEquipment_ArrivalCarrierCancelForInternalBuffer_out;
//P9000027(0.01)        rc = equipment_ArrivalCarrierCancelForInternalBuffer( strEquipment_ArrivalCarrierCancelForInternalBuffer_out,
//P9000027(0.01)                                                              strObjCommonIn,
//P9000027(0.01)                                                              equipmentID,
//P9000027(0.01)                                                              dummyID,
//P9000027(0.01)                                                              strNPWXferCassette );
//P9000027(0.01)        if ( rc != RC_OK )
//P9000027(0.01)        {
//P9000027(0.01)            PPT_METHODTRACE_V1("", "equipment_ArrivalCarrierCancelForInternalBuffer() != RC_OK");
//P9000027(0.01)            strEqpPortStatusChangeRptResult.strResult = strEquipment_ArrivalCarrierCancelForInternalBuffer_out.strResult;
//P9000027(0.01)            return( rc );
//P9000027(0.01)        }
//P9000027(0.01)    }
                    }
                }
            }   //P9000027(0.01)
//P9000027 add end

            /*-----------------------------------------------*/
            /* Get All Ports registered as Same Port Group   */
            /*-----------------------------------------------*/
            PPT_METHODTRACE_V1("", "Get All Ports registered as Same Port Group...");

//P9000307  objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
//P9000307  rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
//P9000307                               strObjCommonIn,
//P9000307                               equipmentID );
//P9000307
//P9000307  if ( rc != RC_OK )
//P9000307  {
//P9000307      PPT_METHODTRACE_V1("", "equipment_portInfo_Get() rc != RC_OK");
//P9000307      strEqpPortStatusChangeRptResult.strResult = strEquipment_portInfo_Get_out.strResult;
//P9000307      return( rc );
//P9000307  }
//P9000307 add start
            objEquipment_portGroupInfo_Get_out strEquipment_portGroupInfo_Get_out;
            objEquipment_portGroupInfo_Get_in strEquipment_portGroupInfo_Get_in;
            strEquipment_portGroupInfo_Get_in.equipmentID = equipmentID;
            strEquipment_portGroupInfo_Get_in.portID = strEqpPortEventOnTCS[i].portID ;
            rc = equipment_portGroupInfo_Get( strEquipment_portGroupInfo_Get_out,
                                              strObjCommonIn,
                                              strEquipment_portGroupInfo_Get_in );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "equipment_portGroupInfo_Get() rc != RC_OK");
                strEqpPortStatusChangeRptResult.strResult = strEquipment_portGroupInfo_Get_out.strResult;
                return( rc );
            }

            CORBA::Long pLen = strEquipment_portGroupInfo_Get_out.strEqpPortAttributesSeq.length();
            CORBA::ULong k = 0 ;
//P9000307 add end

//P9000307            /*-----------------------------------*/
//P9000307            /* Get Specified Port's Port Group   */
//P9000307            /*-----------------------------------*/
//P9000307            PPT_METHODTRACE_V1("", "Get Specified Port's Port Group...");
//P9000307
//P9000307            CORBA::Long basePGNo = 0;
//P9000307            CORBA::Long pLen = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
//P9000307            for ( CORBA::Long k=0 ; k<pLen ; k++ )
//P9000307            {
//P9000307                PPT_METHODTRACE_V3("", "For-Loop of k-pLen...", k, pLen);
//P9000307
//P9000307//P3100156      if ( CIMFWStrCmp(strEqpPortEventOnTCS[k].portID.identifier, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[k].portID.identifier) == 0 )
//P9000307                if ( CIMFWStrCmp(strEqpPortEventOnTCS[i].portID.identifier, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[k].portID.identifier) == 0 )   //P3100156
//P9000307                {
//P9000307                    PPT_METHODTRACE_V2("", "Same portID", k);
//P9000307                    basePGNo = k;
//P9000307                    break;
//P9000307                }
//P9000307            }

            /*------------------------------*/
            /* Find Port ID to be Updated   */
            /*------------------------------*/
            PPT_METHODTRACE_V1("", "Find Port ID to be Updated...");

            for ( k=0 ; k<pLen ; k++ )
            {
                PPT_METHODTRACE_V3("", "For-Loop of k-pLen...", k, pLen);

                /*===== Omit Base Port (In-Parm's Port) =====*/
//P9000307      if ( k == basePGNo )
                if ( 0 == CIMFWStrCmp( strEqpPortEventOnTCS[i].portID.identifier, strEquipment_portGroupInfo_Get_out.strEqpPortAttributesSeq[k].portID.identifier) )   //P9000307
                {
//P9000307          PPT_METHODTRACE_V1("", "k == basePGNo, continue...");
                    PPT_METHODTRACE_V2("", "original port... continue!! ", strEquipment_portGroupInfo_Get_out.strEqpPortAttributesSeq[k].portID.identifier );    //P9000307
                    continue;
                }
//P9000307      /*===== Omit Different Group's Port =====*/
//P9000307      if ( CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[k].portGroup, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[basePGNo].portGroup) != 0 )
//P9000307      {
//P9000307          PPT_METHODTRACE_V1("", "Not same portGroup, continue...");
//P9000307          continue;
//P9000307      }
                /*===== Check Port's Status =====*/
//P9000307      if ( CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[k].portState    , SP_PortRsc_PortState_LoadReq) == 0 &&
//P9000307           CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[k].dispatchState, SP_PortRsc_DispatchState_NotDispatched) == 0 )
                if ( CIMFWStrCmp(strEquipment_portGroupInfo_Get_out.strEqpPortAttributesSeq[k].portState    , SP_PortRsc_PortState_LoadReq) == 0 &&             //P9000307
                     CIMFWStrCmp(strEquipment_portGroupInfo_Get_out.strEqpPortAttributesSeq[k].dispatchState, SP_PortRsc_DispatchState_NotDispatched) == 0 )    //P9000307
                {
                    /*-----------------------------------------------------------------------------*/
                    /* Change Same Group's Not-Specified Port's DispatchState to "Required"        */
                    /*-----------------------------------------------------------------------------*/
                    PPT_METHODTRACE_V1("", "Change Same Group's Not-Specified Port's DispatchState to 'Required'...");

                    objectIdentifier dmyObjID;
                    objEquipment_dispatchState_Change_out strEquipment_dispatchState_Change_out;
                    rc = equipment_dispatchState_Change( strEquipment_dispatchState_Change_out,
                                                         strObjCommonIn,
                                                         equipmentID,
//P9000307                                               strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[k].portID,
                                                         strEquipment_portGroupInfo_Get_out.strEqpPortAttributesSeq[k].portID,    //P9000307
                                                         SP_PortRsc_DispatchState_Required,
                                                         dmyObjID,
                                                         dmyObjID,
                                                         dmyObjID,
                                                         dmyObjID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "equipment_dispatchState_Change() rc != RC_OK");
                        strEqpPortStatusChangeRptResult.strResult = strEquipment_dispatchState_Change_out.strResult;
                        return( rc );
                    }
                }
            }
        }
//P3100156 add end

//P3100300 add start
        if ( CIMFWStrCmp(strEqpPortEventOnTCS[i].portStatus, SP_PortRsc_PortState_UnloadReq) == 0)
        {
            PPT_METHODTRACE_V1("", "PortStatus is UnloadReq");

//P9000237 start
            //----------------------------------------------------------
            //  Check NPW Reservation for Fixed buffer equipment
            //----------------------------------------------------------
//DSN000015229            objEquipment_brInfoForInternalBuffer_GetDR_out strEquipment_brInfoForInternalBuffer_GetDR_out;
//DSN000015229            rc = equipment_brInfoForInternalBuffer_GetDR( strEquipment_brInfoForInternalBuffer_GetDR_out,
//DSN000015229                                                          strObjCommonIn,
//DSN000015229                                                          equipmentID );
//DSN000015229            if ( rc != RC_OK )
//DSN000015229            {
//DSN000015229                PPT_METHODTRACE_V1("", "equipment_brInfoForInternalBuffer_GetDR() != RC_OK");
//DSN000015229                strEqpPortStatusChangeRptResult.strResult = strEquipment_brInfoForInternalBuffer_GetDR_out.strResult;
//DSN000015229                return( rc );
//DSN000015229            }
//DSN000015229 Add Start
            objEquipment_brInfoForInternalBuffer_GetDR__120_out strEquipment_brInfoForInternalBuffer_GetDR_out;
            rc = equipment_brInfoForInternalBuffer_GetDR__120( strEquipment_brInfoForInternalBuffer_GetDR_out,
                                                               strObjCommonIn,
                                                               equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1( "", "equipment_brInfoForInternalBuffer_GetDR__120() != RC_OK" );
                strEqpPortStatusChangeRptResult.strResult = strEquipment_brInfoForInternalBuffer_GetDR_out.strResult;
                return( rc );
            }
//DSN000015229 Add End
            PPT_METHODTRACE_V2("", "equipmentCategory", strEquipment_brInfoForInternalBuffer_GetDR_out.equipmentBRInfoForInternalBuffer.equipmentCategory);

            if ( 0 != CIMFWStrCmp( strEquipment_brInfoForInternalBuffer_GetDR_out.equipmentBRInfoForInternalBuffer.equipmentCategory, SP_Mc_Category_InternalBuffer ) )
            {
                PPT_METHODTRACE_V2("", "Equipment Category is fixed Buffer", equipmentID.identifier);

                //-------------------------------------
                //   Get Reserve CarrierID
                //-------------------------------------
                PPT_METHODTRACE_V1("", "Get Reserve CarrierID");
                objEquipment_NPWReserveInfo_GetDR_out strEquipment_NPWReserveInfo_GetDR_out;
                objEquipment_NPWReserveInfo_GetDR_in strEquipment_NPWReserveInfo_GetDR_in;
                strEquipment_NPWReserveInfo_GetDR_in.equipmentID = equipmentID;
                rc = equipment_NPWReserveInfo_GetDR( strEquipment_NPWReserveInfo_GetDR_out,
                                                     strObjCommonIn,
                                                     strEquipment_NPWReserveInfo_GetDR_in);

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "equipment_NPWReserveInfo_GetDR() rc != RC_OK", rc);
                    strEqpPortStatusChangeRptResult.strResult = strEquipment_NPWReserveInfo_GetDR_out.strResult;
                    return( rc );
                }

                CORBA::Long npwReserveLen = strEquipment_NPWReserveInfo_GetDR_out.strNPWReserveInfoSeq.length();
                PPT_METHODTRACE_V2("", "npwReserveLen", npwReserveLen);

                for ( CORBA::Long l=0; l < npwReserveLen; l++ )
                {
                    if ( 0 == CIMFWStrCmp(strEquipment_NPWReserveInfo_GetDR_out.strNPWReserveInfoSeq[l].reservedLoadPortID.identifier,
                                          strEqpPortEventOnTCS[i].portID.identifier) )
                    {
                        //-------------------------------------
                        //   Check Cassette's Dispatch State
                        //-------------------------------------
                        PPT_METHODTRACE_V2("", "carrierID", strEqpPortEventOnTCS[i].cassetteID.identifier);

                        PPT_METHODTRACE_V1("", "Check Cassette's Dispatch State");
                        objCassette_dispatchState_Get_out strCassette_dispatchState_Get_out;
                        rc = cassette_dispatchState_Get( strCassette_dispatchState_Get_out,
                                                         strObjCommonIn,
                                                         strEquipment_NPWReserveInfo_GetDR_out.strNPWReserveInfoSeq[l].cassetteID);

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "cassette_dispatchState_Get() rc != RC_OK", rc);
                            strEqpPortStatusChangeRptResult.strResult = strCassette_dispatchState_Get_out.strResult;
                            return( rc );
                        }

                        PPT_METHODTRACE_V2("", "dispatchReservedFlag", strCassette_dispatchState_Get_out.dispatchReservedFlag );

                        if ( strCassette_dispatchState_Get_out.dispatchReservedFlag == FALSE )
                        {
                            PPT_METHODTRACE_V1("", "dispatchReservedFlag == FALSE");
                        }
                        else
                        {
                            //-----------------------------------------------
                            //   Change Cassette's Dispatch State to FALSE
                            //-----------------------------------------------
                            PPT_METHODTRACE_V1("", "call cassette_dispatchState_Change()");
                            objCassette_dispatchState_Change_out strCassette_dispatchState_Change_out;
                            rc = cassette_dispatchState_Change( strCassette_dispatchState_Change_out,
                                                                strObjCommonIn,
                                                                strEquipment_NPWReserveInfo_GetDR_out.strNPWReserveInfoSeq[l].cassetteID,
                                                                FALSE );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "cassette_dispatchState_Change() rc != RC_OK", rc);
                                strEqpPortStatusChangeRptResult.strResult = strCassette_dispatchState_Change_out.strResult;
                                return( rc );
                            }
                            //--------------------------------------------------
                            //   Change Cassette's NPWLoadPurposeType to NULL
                            //--------------------------------------------------
                            PPT_METHODTRACE_V1("", "call cassette_SetNPWLoadPurposeType()");
                            objCassette_SetNPWLoadPurposeType_out strCassette_SetNPWLoadPurposeType_out;
                            rc = cassette_SetNPWLoadPurposeType( strCassette_SetNPWLoadPurposeType_out ,
                                                                 strObjCommonIn,
                                                                 strEquipment_NPWReserveInfo_GetDR_out.strNPWReserveInfoSeq[l].cassetteID,
                                                                 NULL );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "cassette_SetNPWLoadPurposeType() != RC_OK", rc);
                                strEqpPortStatusChangeRptResult.strResult = strCassette_SetNPWLoadPurposeType_out.strResult;
                                return( rc );
                            }
                        }
                    }
                } //[l]
            }
//P9000237 end

            if ( ( bAccessModeFlagSeq[i] == TRUE ) &&
                 ( CIMFWStrLen(strEqpPortEventOnTCS[i].cassetteID.identifier) == 0 ) &&
                 ( CIMFWStrLen(strEqpPortEventOnTCS[i].cassetteID.stringifiedObjectReference) == 0 ) )
            {
                PPT_METHODTRACE_V1("", "AccessMode is Auto and cassetteID is Null");

                pptSystemMsgRptResult strSystemMsgRptResult;
                objectIdentifier dummy;

                PPT_METHODTRACE_V2("", "EquipmentID :", equipmentID.identifier);
                PPT_METHODTRACE_V2("", "TimeStamp", strObjCommonIn.strTimeStamp.reportTimeStamp);

//P4000332 start
                //-------------------------------------------------------
                // Prepare e-mail Message Text
                //-------------------------------------------------------
                CORBA::String_var msg;
                PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< Unexpected Carrier was Placed >>>" );
                PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Eqpipment ID         : " );
                PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)equipmentID.identifier );
                PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Port ID              : " );
                PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strEqpPortEventOnTCS[i].portID.identifier );
                PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Port State           : " );
                PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strEqpPortEventOnTCS[i].portStatus );
                PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Lot ID               : " );
                PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strEqpPortEventOnTCS[i].lotID.identifier );
                PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Cassette ID          : " );
                PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strEqpPortEventOnTCS[i].cassetteID.identifier );

                PPT_METHODTRACE_V2("", "messageText--->", msg);
//P4000332 end

                rc = txSystemMsgRpt( strSystemMsgRptResult,
                                     strObjCommonIn,
                                     SP_SubSystemID_MM,
                                     SP_SystemMsgCode_DeliveryError,
//P4000332                                     "",
                                     msg,       //P4000332
                                     TRUE,
                                     equipmentID,           // equipmentID
                                     "",                    // equipmentStatus
                                     dummy,                 // stockerID
                                     "",                    // stockerStatus
                                     dummy,                 // AGVID
                                     "",                    // AGVStatus
//P4000332                                     dummy,                   // lotID
                                     strEqpPortEventOnTCS[i].lotID,                 //P4000332
                                     "",                    // lotStatus
                                     dummy,                 // routeID
                                     dummy,                 // operationID
                                     "",                    // operationNumber
                                     strObjCommonIn.strTimeStamp.reportTimeStamp,
                                     "" );

                if (rc != RC_OK)
                {
                    PPT_METHODTRACE_V1("", "txSystemMsgRpt() != RC_OK");
                    strEqpPortStatusChangeRptResult.strResult = strSystemMsgRptResult.strResult;
                    PPT_METHODTRACE_V2("", "returnCode", strEqpPortStatusChangeRptResult.strResult.returnCode);
                    return( rc );
                }
            }
//INN-R170003 add start
        CORBA::Long g, h;
        PPT_METHODTRACE_V2("", "### seqLen = ",seqLen);
        for (g=0; g<seqLen; g++)
        {
            PPT_METHODTRACE_V2("", "### strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus.length = ",strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus.length());
            for (h=0; h<strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus.length(); h++)
            {
                PPT_METHODTRACE_V2("", "### strEqpPortEventOnTCS[g].portID = ",strEqpPortEventOnTCS[g].portID.identifier);
                if ( CIMFWStrCmp( strEqpPortEventOnTCS[g].portID.identifier , strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[h].portID.identifier ) == 0  )
                {
                    PPT_METHODTRACE_V2("", "### strEqpPortEventOnTCS[g].cassetteID.identifier = ",strEqpPortEventOnTCS[g].cassetteID.identifier);
                   if ( CIMFWStrLen(strEqpPortEventOnTCS[g].cassetteID.identifier)>0 
                        && CIMFWStrCmp( strEqpPortEventOnTCS[g].cassetteID.identifier , strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[h].loadedCassetteID.identifier ) != 0  )
                    {
                        PPT_METHODTRACE_V1("", "EqpPortEventOnTCS.cassetteID != Port loadedCassetteID");
                        return RC_INVALID_CAST_PORT_COMBINATION;
                    }
                    
                    /*--------------------------------*/
                    /*   LotCassetteXferStatusChange  */
                    /*--------------------------------*/
                    PPT_METHODTRACE_V1("", "/*---------------------------------*/");
                    PPT_METHODTRACE_V1("", "/* Lot Cassette Xfer Status Change */");
                    PPT_METHODTRACE_V1("", "/*---------------------------------*/");
                    pptLotCassetteXferStatusChangeRptResult strLotCassetteXferStatusChangeRptResult;
                    
                    rc = txLotCassetteXferStatusChangeRpt__160 ( strLotCassetteXferStatusChangeRptResult,
                                                                 strObjCommonIn,
                                                                 strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[h].loadedCassetteID,
                                                                 SP_TransState_EquipmentOut,
                                                                 FALSE,
                                                                 equipmentID,
                                                                 strEqpPortEventOnTCS[g].portID,
                                                                 "",
                                                                 "",
                                                                 strObjCommonIn.strTimeStamp.reportTimeStamp,
                                                                 claimMemo);
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "##### txLotCassetteXferStatusChangeRpt__160() rc != RC_OK"); 
                        strEqpPortStatusChangeRptResult.strResult = strLotCassetteXferStatusChangeRptResult.strResult;
                        return( rc );
                    }
                    
                    PPT_METHODTRACE_V1("","##### txLotCassetteXferStatusChangeRpt__160() rc = RC_OK");
                }
            }
        }
//INN-R170003 add end
        } 
//P3100300 add end
//DSN000101505 Add Start
        //----------------------------------------------------------
        //  Create event for equipment port status change
        //----------------------------------------------------------
        objEquipment_portStatusChangeEvent_Make_out strEquipment_portStatusChangeEvent_Make_out;
        objEquipment_portStatusChangeEvent_Make_in  strEquipment_portStatusChangeEvent_Make_in;
        strEquipment_portStatusChangeEvent_Make_in.equipmentID       = equipmentID;
        strEquipment_portStatusChangeEvent_Make_in.portType          = CIMFWStrDup(SP_DurableCat_Cassette);
        strEquipment_portStatusChangeEvent_Make_in.portID            = strEqpPortEventOnTCS[i].portID;
        strEquipment_portStatusChangeEvent_Make_in.portStatus        = CIMFWStrDup(strEqpPortEventOnTCS[i].portStatus);
        strEquipment_portStatusChangeEvent_Make_in.dispatchDurableID = CIMFWStrDup(strEqpPortEventOnTCS[i].cassetteID.identifier);
        strEquipment_portStatusChangeEvent_Make_in.claimMemo         = CIMFWStrDup(claimMemo);

        objEquipment_portGroupInfo_Get_out strEquipment_portGroupInfo_Get_out;
        objEquipment_portGroupInfo_Get_in  strEquipment_portGroupInfo_Get_in;
        strEquipment_portGroupInfo_Get_in.equipmentID = equipmentID;
        strEquipment_portGroupInfo_Get_in.portID      = strEqpPortEventOnTCS[i].portID;
        rc = equipment_portGroupInfo_Get(strEquipment_portGroupInfo_Get_out,
                                         strObjCommonIn,
                                         strEquipment_portGroupInfo_Get_in);

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "equipment_portGroupInfo_Get() rc != RC_OK");
            strEqpPortStatusChangeRptResult.strResult = strEquipment_portGroupInfo_Get_out.strResult;
            return rc;
        }

        CORBA::ULong portAttrLen = strEquipment_portGroupInfo_Get_out.strEqpPortAttributesSeq.length();
        for (CORBA::ULong portAttrCnt = 0; portAttrCnt < portAttrLen; portAttrCnt++)
        {
            PPT_METHODTRACE_V3("", "For-Loop of portAttrLen...", portAttrCnt, portAttrLen);
            if (0 == CIMFWStrCmp(strEqpPortEventOnTCS[i].portID.identifier, strEquipment_portGroupInfo_Get_out.strEqpPortAttributesSeq[portAttrCnt].portID.identifier))
            {
                PPT_METHODTRACE_V2("", "portID=", strEqpPortEventOnTCS[i].portID.identifier);
                strEquipment_portStatusChangeEvent_Make_in.portUsage     = CIMFWStrDup(strEquipment_portGroupInfo_Get_out.strEqpPortAttributesSeq[portAttrCnt].portUsage);
                strEquipment_portStatusChangeEvent_Make_in.accessMode    = CIMFWStrDup(strEquipment_portGroupInfo_Get_out.strEqpPortAttributesSeq[portAttrCnt].currentAccessMode);
                strEquipment_portStatusChangeEvent_Make_in.dispatchTime  = CIMFWStrDup(strEquipment_portGroupInfo_Get_out.strEqpPortAttributesSeq[portAttrCnt].portDispatchTimeStamp);
                strEquipment_portStatusChangeEvent_Make_in.dispatchState = CIMFWStrDup(strEquipment_portGroupInfo_Get_out.strEqpPortAttributesSeq[portAttrCnt].dispatchState);
                break;
            }
        }

        rc = equipment_portStatusChangeEvent_Make(strEquipment_portStatusChangeEvent_Make_out, 
                                                  strObjCommonIn, 
                                                  strEquipment_portStatusChangeEvent_Make_in);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "equipment_PortStatusChangeEvent_Make() != RC_OK");
            strEqpPortStatusChangeRptResult.strResult = strEquipment_portStatusChangeEvent_Make_out.strResult;
            return rc;
        }
//DSN000101505 Add End
    }

    /*------------------------------------------------*/
    /*   Delete Unload Lot Information in Equipment   */
    /*------------------------------------------------*/
    //R30 pptLoadUnloadLotDeleteReqResult strLoadUnloadLotDeleteReqResult;
    //R30 pptDeleteLoadedLotSequence      strDeleteLoadedLot(0);
    //R30 strDeleteLoadedLot.length(0);
    //R30
    //R30 rc = txLoadUnloadLotDeleteReq ( strLoadUnloadLotDeleteReqResult,
    //R30                                 strObjCommonIn,
    //R30                                 equipmentID,
    //R30                                 strDeleteLoadedLot,
    //R30                                 strDeleteUnloadableLot) ;
    //R30
    //R30 if(rc!=RC_OK)
    //R30 {
    //R30     PPT_METHODTRACE_V1("", "txLoadUnloadLotDeleteReq() != RC_OK") ;
    //R30     strEqpPortStatusChangeRptResult.strResult = strLoadUnloadLotDeleteReqResult.strResult ;
    //R30     return rc;
    //R30 }

//D5100078    /*-------------------------------------*/
//D5100078    /*   Create Port Status Change Event   */
//D5100078    /*-------------------------------------*/
//D5100078    for (i = 0; i < seqLen ; i++)
//D5100078    {
//D5100078        objPortStatusChangeEvent_Make_out strPortStatusChangeEvent_Make_out;
//D5100078        rc = portStatusChangeEvent_Make( strPortStatusChangeEvent_Make_out,
//D5100078                                         strObjCommonIn,
//D5100078                                         "TXEQR002",
//D5100078                                         equipmentID,
//D5100078                                         strEqpPortEventOnTCS[i].portID,
//D5100078                                         strEqpPortEventOnTCS[i].portStatus,
//D5100078                                         strEqpPortEventOnTCS[i].lotID,
//D5100078                                         strEqpPortEventOnTCS[i].cassetteID,
//D5100078                                         claimMemo );
//D5100078        if(rc != RC_OK)
//D5100078        {
//D5100078            PPT_METHODTRACE_V1("", "portStatusChangeEvent_Make() != RC_OK") ;
//D5100078            strEqpPortStatusChangeRptResult.strResult = strPortStatusChangeEvent_Make_out.strResult;
//D5100078            return( rc );
//D5100078        }
//D5100078    }

/*** 0.02 start ***/
//D7000096    PPT_METHODTRACE_V1("","Start Xfer Logic");

//    CORBA::String_var deliveryReqExist;
//    CIMFWStrCat( deliveryReqExist, getenv("SP_DELIVERY_REQ_EXIST") );

//P3000298    CORBA::String_var deliveryReqExist = getenv("SP_DELIVERY_REQ_EXIST");
//P3000426    char * deliveryReqExist = CIMFWStrDup(getenv("SP_DELIVERY_REQ_EXIST"));    //P3000298
//D4000011    CORBA::String_var deliveryReqExist = CIMFWStrDup(getenv("SP_DELIVERY_REQ_EXIST"));    //P3000426
//D4000011    PPT_METHODTRACE_V2("","deliveryReqExist=",deliveryReqExist);

//D4000011    if ( 0 != CIMFWStrCmp(deliveryReqExist, "YES") )

//D4100134    PPT_METHODTRACE_V2("","theSP_DELIVERY_REQ_EXIST=",theSP_DELIVERY_REQ_EXIST);  //D4000011
//D4100134    if ( 0 != CIMFWStrCmp(theSP_DELIVERY_REQ_EXIST, "YES") )   //D4000011

//D7000096    CORBA::String_var deliveryReqExist = CIMFWStrDup(getenv("SP_DELIVERY_REQ_EXIST"));    //D4100134 restored
//D7000096    PPT_METHODTRACE_V2("","deliveryReqExist=",deliveryReqExist);                          //D4100134 restored

//D7000096    if ( 0 != CIMFWStrCmp(deliveryReqExist, "YES") )                                      //D4100134 restored
//D7000096    {
//D7000096        /*-------------------------------------*/
//D7000096        /*   Return carrier to Stocker         */
//D7000096        /*-------------------------------------*/
//D7000096        PPT_METHODTRACE_V1("", "call equipment_portInfo_Get()...");
//D7000096
//D7000096        objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
//D7000096
//D7000096        rc = equipment_portInfo_Get(strEquipment_portInfo_Get_out, strObjCommonIn, equipmentID);
//D7000096        if ( rc != RC_OK )
//D7000096        {
//D7000096           PPT_METHODTRACE_V1("", "equipment_portInfo_Get() rc != RC_OK");
//D7000096           strEqpPortStatusChangeRptResult.strResult = strEquipment_portInfo_Get_out.strResult;
//D7000096           return( rc );
//D7000096        }
//D7000096
//D7000096        CORBA::Long portLen = 0;
//D7000096        CORBA::Long m, n, p, q;
//D7000096
//D7000096        portLen = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
//D7000096        PPT_METHODTRACE_V2("", "strEqpPortStatus.length", portLen);
//D7000096
//D7000096        for ( m=0; m < seqLen; m++ )
//D7000096        {
//D7000096
//D7000096//P3100300 add start
//D7000096            if ( ( bAccessModeFlagSeq[m] == TRUE )
//D7000096              && 0 == CIMFWStrCmp(strEqpPortEventOnTCS[m].portStatus, SP_PortRsc_PortState_UnloadReq)
//D7000096              && 0 == CIMFWStrLen(strEqpPortEventOnTCS[m].cassetteID.identifier)
//D7000096              && 0 == CIMFWStrLen(strEqpPortEventOnTCS[m].cassetteID.stringifiedObjectReference) )
//D7000096            {
//D7000096                PPT_METHODTRACE_V1("", "AccessMode is Auto and PortStatus is UnloadReq and cassetteID is Null");
//D7000096                continue;
//D7000096            }
//D7000096//P3100300 add end
//D7000096
//D7000096            for ( n=0; n < portLen; n++ )
//D7000096            {
//D7000096//              PPT_METHODTRACE_V2("", "TCS Report  PortID is ",strEqpPortEventOnTCS[m].portID.identifier);
//D7000096//              PPT_METHODTRACE_V2("", "Compare     PortID is ",strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[n].portID.identifier);
//D7000096//              PPT_METHODTRACE_V2("", "Port Access Mode   is ",strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[n].accessMode);
//D7000096
//D7000096                PPT_METHODTRACE_V1("", "call strCassette_controlJobID_Get_out()...");
//D7000096                /* Input-parameter is strEqpPortEventOnTCS[m].cassetteID */
//D7000096                objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;
//D7000096
//D7000096                rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out, strObjCommonIn, strEqpPortEventOnTCS[m].cassetteID );
//D7000096
//D7000096                PPT_METHODTRACE_V2("", "TCS Report  PortID is ",strEqpPortEventOnTCS[m].portID.identifier);
//D7000096                PPT_METHODTRACE_V2("", "Compare     PortID is ",strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[n].portID.identifier);
//D7000096                PPT_METHODTRACE_V2("", "Port Access Mode   is ",strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[n].accessMode);
//D7000096                PPT_METHODTRACE_V2("", "cassetteID of controlJobID_Get  is ",strEqpPortEventOnTCS[m].cassetteID.identifier);
//D7000096                PPT_METHODTRACE_V2("", "length     of controlJobID is "     ,CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier));
//D7000096                PPT_METHODTRACE_V2("", "reported port status is "           ,strEqpPortEventOnTCS[m].portStatus);
//D7000096
//D7000096                if ( 0 == CIMFWStrCmp(strEqpPortEventOnTCS[m].portID.identifier, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[n].portID.identifier)
//D7000096                  && 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[n].accessMode, SP_Eqp_AccessMode_Auto)
//D7000096                  && 0 == CIMFWStrCmp(strEqpPortEventOnTCS[m].portStatus, SP_PortRsc_PortState_UnloadReq)
//D7000096                  && 0 == CIMFWStrLen(strCassette_controlJobID_Get_out.controlJobID.identifier) )
//D7000096                {
//D7000096                    PPT_METHODTRACE_V3("", "Where Next!! [m], [n]", m, n);
//D7000096
//D7000096                    /* Where Next   */
//D7000096                    CORBA::Boolean  EmptyCastFlag = TRUE;                   //P3000364
//D7000096                    /*----------------------------------------------*/
//D7000096                    /*   Check the representative lotID             */
//D7000096                    /*----------------------------------------------*/
//D7000096                    PPT_METHODTRACE_V1("", "Check the representative lotID");
//D7000096
//D7000096                    objectIdentifier aLotID;
//D7000096                    objLot_GetNextStockerDR_out strLot_GetNextStockerDR_out;            //P3000364
//D7000096                    objCassette_representLot_Get_out strCassette_representLot_Get_out;
//D7000096
//D7000096                    rc = cassette_representLot_Get( strCassette_representLot_Get_out, strObjCommonIn, strEqpPortEventOnTCS[m].cassetteID );
//D7000096//P3000364          if (rc != RC_OK)
//D7000096                    if (rc != RC_OK && rc != RC_NOT_FOUND_LOT)
//D7000096                    {
//D7000096                       PPT_METHODTRACE_V1("", "cassette_representLot_Get() != RC_OK") ;
//D7000096                       strEqpPortStatusChangeRptResult.strResult = strCassette_representLot_Get_out.strResult;
//D7000096                       return rc;
//D7000096                    }
//D7000096                    if(rc == RC_OK)
//D7000096                    {
//D7000096                        EmptyCastFlag = FALSE;                              //P3000364
//D7000096                        aLotID = strCassette_representLot_Get_out.lotID;
//D7000096                        PPT_METHODTRACE_V2("","representative lotID", aLotID.identifier) ;
//D7000096
//D7000096                    /*--------------------------------------------------*/
//D7000096                    /*   Get and set the destination to be transferred  */
//D7000096                    /*--------------------------------------------------*/
//D7000096                        PPT_METHODTRACE_V1("", "Get and set the destination to be transferred");
//D7000096
//D7000096                        rc = lot_GetNextStockerDR( strLot_GetNextStockerDR_out, strObjCommonIn, aLotID );
//D7000096//P4000065 add start
//D7000096                        if ( rc == RC_INVALID_LOT_PROCSTAT )
//D7000096                        {
//D7000096                            /*----------------------------------------------------*/
//D7000096                            /*   This return code is returned only when 'OpeComp' */
//D7000096                            /* and 'UnloadReq' are come from TCS at same time.    */
//D7000096                            /*   if TCS receives RC_LOCKED_BY_ANOTHER , this      */
//D7000096                            /* txEqpPortStatusChangeRpt() will be retried by TCS  */
//D7000096                            /*----------------------------------------------------*/
//D7000096                            PPT_METHODTRACE_V1("","lot_GetNextStockerDR() == RC_INVALID_LOT_PROCSTAT");
//D7000096                            PPT_METHODTRACE_V1("","returnCode will be exchange to RC_LOCKED_BY_ANOTHER");
//D7000096                            PPT_METHODTRACE_V1("","TCS will be retried later...");
//D7000096
//D7000096                            return ( RC_LOCKED_BY_ANOTHER );
//D7000096                        }
//D7000096                        else
//D7000096//P4000065 add end
//D7000096                        if (rc != RC_OK)
//D7000096                        {
//D7000096                            PPT_METHODTRACE_V1("", "lot_GetNextStockerDR() != RC_OK") ;
//D7000096                            strEqpPortStatusChangeRptResult.strResult = strLot_GetNextStockerDR_out.strResult;
//D7000096                            return rc;
//D7000096                        }
//D7000096                    }
//D7000096
//D7000096//P3000364          aLotID = strCassette_representLot_Get_out.lotID;
//D7000096//P3000364          PPT_METHODTRACE_V2("","representative lotID", aLotID.identifier) ;
//D7000096//P3000364
//D7000096//P3000364          /*--------------------------------------------------*/
//D7000096//P3000364          /*   Get and set the destination to be transferred  */
//D7000096//P3000364          /*--------------------------------------------------*/
//D7000096//P3000364          PPT_METHODTRACE_V1("", "Get and set the destination to be transferred");
//D7000096//P3000364
//D7000096//P3000364          objLot_GetNextStockerDR_out strLot_GetNextStockerDR_out;
//D7000096//P3000364
//D7000096//P3000364          rc = lot_GetNextStockerDR( strLot_GetNextStockerDR_out, strObjCommonIn, aLotID );
//D7000096//P3000364          if (rc != RC_OK)
//D7000096//P3000364          {
//D7000096//P3000364             PPT_METHODTRACE_V1("", "lot_GetNextStockerDR() != RC_OK") ;
//D7000096//P3000364             strEqpPortStatusChangeRptResult.strResult = strLot_GetNextStockerDR_out.strResult;
//D7000096//P3000364             return rc;
//D7000096//P3000364          }
//D7000096//P3000364
//D7000096                    /* Xfer Request */
//D7000096
//D7000096                    PPT_METHODTRACE_V1("", "Xfer Request");
//D7000096
//D7000096                    pptTranJobCreateReq tranJobCreateReq;
//D7000096                    tranJobCreateReq.jobCreateData.length(1);
//D7000096
//D7000096                    tranJobCreateReq.jobCreateData[0].fromMachineID  = equipmentID;
//D7000096                    tranJobCreateReq.jobCreateData[0].fromPortID     = strEqpPortEventOnTCS[m].portID;
//D7000096                    tranJobCreateReq.jobCreateData[0].carrierID      = strEqpPortEventOnTCS[m].cassetteID;
//D7000096
//D7000096                    objCassette_zoneType_Get_out strCassette_zoneType_Get_out;
//D7000096
//D7000096                    /* strEqpPortEventOnTCS[m].cassetteID is in-parameter */
//D7000096                    rc = cassette_zoneType_Get( strCassette_zoneType_Get_out, strObjCommonIn, strEqpPortEventOnTCS[m].cassetteID );
//D7000096                    if (rc != RC_OK)
//D7000096                    {
//D7000096                       PPT_METHODTRACE_V1("", "lot_GetNextStockerDR() != RC_OK") ;
//D7000096                       strEqpPortStatusChangeRptResult.strResult = strLot_GetNextStockerDR_out.strResult;
//D7000096                       return rc;
//D7000096                    }
//D7000096
//D7000096                    PPT_METHODTRACE_V2("", "strCassette_zoneType_Get_out.zoneType", strCassette_zoneType_Get_out.zoneType);
//D7000096                    tranJobCreateReq.jobCreateData[0].zoneType = strCassette_zoneType_Get_out.zoneType;
//D7000096                    tranJobCreateReq.jobCreateData[0].priority = strCassette_zoneType_Get_out.priority;         //P3000364
//D7000096
//D7000096//P3000364          CORBA::Long mLen = strLot_GetNextStockerDR_out.strWhereNext.strWhereNextEqpStatus.length();
//D7000096                    CORBA::Long mLen = 0;
//D7000096                    if(EmptyCastFlag == FALSE)                                                          //P3000364
//D7000096                    {                                                                                   //P3000364
//D7000096                        mLen = strLot_GetNextStockerDR_out.strWhereNext.strWhereNextEqpStatus.length();
//D7000096                    }                                                                                   //P3000364
//D7000096
//D7000096                    PPT_METHODTRACE_V2("", "strWhereNextEqpStatus.length", mLen);
//D7000096
//D7000096                    CORBA::Long stkLen = 0;
//D7000096                    objectIdentifierSequence machines;
//D7000096
//D7000096                    for ( p=0; p < mLen; p++ )
//D7000096                    {
//D7000096                        CORBA::Long nLen = strLot_GetNextStockerDR_out.strWhereNext.strWhereNextEqpStatus[p].strEqpStockerStatus.length();
//D7000096                        for ( q=0; q < nLen; q++ )
//D7000096                        {
//D7000096                            if (strLot_GetNextStockerDR_out.strWhereNext.strWhereNextEqpStatus[p].strEqpStockerStatus[q].stockerID.identifier != NULL)
//D7000096                            {
//D7000096                                stkLen++;
//D7000096                                machines.length(stkLen);
//D7000096                                machines[stkLen-1] = strLot_GetNextStockerDR_out.strWhereNext.strWhereNextEqpStatus[p].strEqpStockerStatus[q].stockerID;
//D7000096                                PPT_METHODTRACE_V3("", "set stockerID", stkLen, machines[stkLen-1].identifier);
//D7000096                            }
//D7000096                        }
//D7000096                    }
//D7000096
//D7000096                    if(mLen==0 || stkLen == 0){
//D7000096//P3000364              stkLen=1;
//D7000096                        objEquipment_stockerInfo_Get_out strEquipment_stockerInfo_Get_out;
//D7000096                        pptEqpStockerInfo    equipmentStockerInfo;
//D7000096
//D7000096                        PPT_METHODTRACE_V1("", "call equipment_stockerInfo_Get()...");
//D7000096                        rc = equipment_stockerInfo_Get(strEquipment_stockerInfo_Get_out, strObjCommonIn, equipmentID);
//D7000096                        if ( rc != RC_OK )
//D7000096                        {
//D7000096                            PPT_METHODTRACE_V1("", "equipment_stockerInfo_Get() rc != RC_OK");
//D7000096                            strEqpPortStatusChangeRptResult.strResult = strEquipment_stockerInfo_Get_out.strResult;
//D7000096                            return( rc );
//D7000096                        }
//D7000096                        equipmentStockerInfo = strEquipment_stockerInfo_Get_out.equipmentStockerInfo;
//D7000096                        stkLen = equipmentStockerInfo.strEqpStockerStatus.length();                 //P3000364
//D7000096                        machines.length(stkLen);                                                    //P3000364
//D7000096                        for (CORBA::Long jj = 0; jj < stkLen; jj++)                                 //P3000364
//D7000096                        {                                                                           //P3000364
//D7000096                            machines[jj] = equipmentStockerInfo.strEqpStockerStatus[jj].stockerID;  //P3000364
//D7000096                        }                                                                           //P3000364
//D7000096//P3000364              machines.length(1);
//D7000096//P3000364              machines[0] = equipmentStockerInfo.strEqpStockerStatus[0].stockerID;
//D7000096                    }
//D7000096
//D7000096                    /* re-create toMachineID,if found same stocker,then delete 2nd data*/
//D7000096                    PPT_METHODTRACE_V1("", "re-create toMachineID,if found same stocker,then delete 2nd data");
//D7000096
//D7000096                    objectIdentifierSequence toMachines;
//D7000096                    toMachines = machines;
//D7000096
//D7000096                    CORBA::Boolean existFlag = FALSE;
//D7000096                    CORBA::Long Cnt = 0;
//D7000096                    objectIdentifier nilObj;
//D7000096                    tranJobCreateReq.jobCreateData[0].toMachine.length(stkLen);
//D7000096                    PPT_METHODTRACE_V2("", "toMachine.length (stkLen)-->", stkLen);
//D7000096
//D7000096                    for ( CORBA::Long i=0; i < stkLen; i++ )
//D7000096                    {
//D7000096                        for ( CORBA::Long j=0; j < i; j++ )
//D7000096                        {
//D7000096                            if ( 0 == CIMFWStrCmp(machines[i].identifier, toMachines[j].identifier) )
//D7000096                            {
//D7000096                                PPT_METHODTRACE_V3("", "set existFlag = TRUE  [i], [j]", i, j);
//D7000096                                existFlag = TRUE;
//D7000096                            }
//D7000096                        }
//D7000096                        if ( existFlag == FALSE || i ==0 )
//D7000096                        {
//D7000096                            PPT_METHODTRACE_V3("", "existFlag == FALSE || i ==0  [i], [j]", i, j);
//D7000096                            tranJobCreateReq.jobCreateData[0].toMachine[Cnt].toMachineID = machines[i];
//D7000096//P3000300                  tranJobCreateReq.jobCreateData[0].toMachine[p].toPortID = nilObj;
//D7000096                            tranJobCreateReq.jobCreateData[0].toMachine[Cnt].toPortID = nilObj;
//D7000096                            Cnt++;
//D7000096                        }
//D7000096                    }
//D7000096                    tranJobCreateReq.jobCreateData[0].toMachine.length(Cnt);
//D7000096
//D7000096                    /*-----------------------------------------------------------*/
//D7000096                    /* Trans            fer Request to XMSMgr                    */
//D7000096                    /*-----------------------------------------------------------*/
//D7000096                    objXMSMgr_SendTransportJobCreateReq_out strXMSMgr_SendTransportJobCreateReq_out;
//D7000096                    rc = XMSMgr_SendTransportJobCreateReq( strXMSMgr_SendTransportJobCreateReq_out,
//D7000096                                                           strObjCommonIn,
//D7000096                                                           strObjCommonIn.strUser,
//D7000096                                                           tranJobCreateReq );
//D7000096                    if ( rc != RC_OK )
//D7000096                    {
//D7000096                        PPT_METHODTRACE_V1("", "XMSMgr_SendTransportJobCreateReq != RC_OK");
//D7000096                        pptSystemMsgRptResult strSystemMsgRptResult;
//D7000096                        objectIdentifier dummy;
//D7000096//P3000300              CORBA::String    reason;
//D7000096
//D7000096                        PPT_METHODTRACE_V2("", "Reson Text  :", strXMSMgr_SendTransportJobCreateReq_out.strResult.reasonText);
//D7000096                        PPT_METHODTRACE_V2("", "EquipmentID :", equipmentID.identifier);
//D7000096                        PPT_METHODTRACE_V2("", "TimeStamp", strObjCommonIn.strTimeStamp.reportTimeStamp);
//D7000096
//D7000096//P4000332 start
//D7000096                        //-------------------------------------------------------
//D7000096                        // Prepare e-mail Message Text
//D7000096                        //-------------------------------------------------------
//D7000096                        CORBA::String_var msg;
//D7000096                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "<<< It failed in TransportJobCreate of UnloadRequest >>>" );
//D7000096                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Eqpipment ID    : " );
//D7000096                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)tranJobCreateReq.jobCreateData[0].fromMachineID.identifier );
//D7000096                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "From Port ID         : " );
//D7000096                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)tranJobCreateReq.jobCreateData[0].fromPortID.identifier );
//D7000096                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Cassette ID          : " );
//D7000096                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)tranJobCreateReq.jobCreateData[0].carrierID.identifier );
//D7000096
//D7000096                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Equipment ID      : " );
//D7000096                        CORBA::Boolean bFirstSet = FALSE;
//D7000096                        CORBA::Long ii;
//D7000096                        CORBA::Long lenToEqp = tranJobCreateReq.jobCreateData[0].toMachine.length();
//D7000096                        for ( ii=0; ii < lenToEqp; ii++ )
//D7000096                        {
//D7000096                            if ( TRUE == bFirstSet )
//D7000096                            {
//D7000096                                PPT_STRDUPCAT_STRING( FALSE, msg, msg, ", " );
//D7000096                            }
//D7000096                            PPT_STRDUPCAT_STRING( FALSE, msg, msg, tranJobCreateReq.jobCreateData[0].toMachine[ii].toMachineID.identifier );
//D7000096                            bFirstSet = TRUE;
//D7000096                        }
//D7000096                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
//D7000096
//D7000096                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "To Port ID           : " );
//D7000096                        bFirstSet = FALSE;
//D7000096                        for ( ii=0; ii < lenToEqp; ii++ )
//D7000096                        {
//D7000096                            if ( TRUE == bFirstSet )
//D7000096                            {
//D7000096                                PPT_STRDUPCAT_STRING( FALSE, msg, msg, ", " );
//D7000096                            }
//D7000096                            PPT_STRDUPCAT_STRING( FALSE, msg, msg, tranJobCreateReq.jobCreateData[0].toMachine[ii].toPortID.identifier );
//D7000096                            bFirstSet = TRUE;
//D7000096                        }
//D7000096                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
//D7000096
//D7000096                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "" );
//D7000096                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Transaction ID       : " );
//D7000096                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strXMSMgr_SendTransportJobCreateReq_out.strResult.transactionID );
//D7000096                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Return Code          : " );
//D7000096                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strXMSMgr_SendTransportJobCreateReq_out.strResult.returnCode );
//D7000096                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message ID           : " );
//D7000096                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strXMSMgr_SendTransportJobCreateReq_out.strResult.messageID );
//D7000096                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Message Text         : " );
//D7000096                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strXMSMgr_SendTransportJobCreateReq_out.strResult.messageText );
//D7000096                        PPT_STRDUPCAT_STRING( FALSE, msg, msg, "Reason Text          : " );
//D7000096                        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strXMSMgr_SendTransportJobCreateReq_out.strResult.reasonText );
//D7000096
//D7000096                        PPT_METHODTRACE_V2("", "messageText--->", msg);
//D7000096//P4000332 end
//D7000096
//D7000096                        rc = txSystemMsgRpt( strSystemMsgRptResult,
//D7000096                                             strObjCommonIn,
//D7000096                                             SP_SubSystemID_MM,
//D7000096                                             SP_SystemMsgCode_DeliveryError,
//D7000096//P4000332                                             "",
//D7000096                                             msg,       //P4000332
//D7000096                                             TRUE,
//D7000096                                             equipmentID,
//D7000096                                             "",
//D7000096                                             dummy,
//D7000096                                             "",
//D7000096                                             dummy,
//D7000096                                             "",
//D7000096                                             dummy,
//D7000096                                             "",
//D7000096                                             dummy,
//D7000096                                             dummy,
//D7000096                                             "",
//D7000096                                             strObjCommonIn.strTimeStamp.reportTimeStamp,
//D7000096                                             "" );
//D7000096                        if (rc != RC_OK)
//D7000096                        {
//D7000096                            PPT_METHODTRACE_V1("", "txSystemMsgRpt() != RC_OK");
//D7000096                            strEqpPortStatusChangeRptResult.strResult = strSystemMsgRptResult.strResult;
//D7000096                            PPT_METHODTRACE_V2("", "returnCode", strEqpPortStatusChangeRptResult.strResult.returnCode);
//D7000096                            return( rc );
//D7000096                        }
//D7000096                        PPT_METHODTRACE_V1("", "XMSMgr_SendTransportJobCreateReq End");
//D7000096                    }
//D7000096                }
//D7000096            }
//D7000096        }
//D7000096    }
/*** 0.02 end ***/

    /*----------------------*/
    /*   Return to Caller   */
    /*----------------------*/
    strEqpPortStatusChangeRptResult.equipmentID = equipmentID ;

    SET_MSG_RC(strEqpPortStatusChangeRptResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txEqpPortStatusChangeRpt ") ;
    return(RC_OK);
}
