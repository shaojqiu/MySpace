#ifndef lint
static char *sccsid =  "@(#) 1.8 superpos/src/spppt/source/posppt/pptmgr/txmethods/cs_txHoldLotReleaseReqOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 12/3/07 18:21:30 [ 12/3/07 18:21:31 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// SiView
// Name: cs_txHoldLotReleaseReqOR.cpp
//

#include "cs_pptmgr.hpp"

// Class: CS_PPTManager
//
// Service: txHoldLotReleaseReq()
//
// Change history:
// Date       Defect#    Person         Comments
// ---------- ---------- -------------- -------------------------------------------
// 2000/08/08          S.Kawabe       Initial Release (R30)
// 2000/09/12 P3000139 O.Sugiyama     add SET_MSG_RC
// 2000/09/18 P3000139 T.Yamano       add SET_MSG_RC
// 2001/02/08 P3100007 K.Matsuei      change parameter name
// 2001/02/16 D3100021 M.Ameshita     Add logic to check NonProBankHold record.
// 2002/06/11 P4100536 T.Nishimura    Source Check : Wrong reference to dimension.
// 2002/07/04 P4200025 T.Nishimura    Source Check : return without message.
// 2002/07/25 D4200029 K.Kimura       Process Hold Control
// 2002/09/19 D4200062 K.Kido         Change for backupOperation(Rel4.2).
// 2003/09/09 P5000145 H.Adachi       Fix Message and Message Macro mismatch.
// 2004/08/27 D51M0000 M.Murata       Add logic to APC I/F
// 2004/10/22 D6000025 K.Murakami     eBroker Migration.
// 2004/11/01 D6000051 H.Adachi       Add Hold Release Reason Code of LockRelease.
// 2006/04/14 P7000215 H.Hasegawa     Add the existence check for the future hold requests before the cancellation.
// 2006/05/18 D7000092 Y.Kadowaki     Add object lock for cassette.
// 2006/09/01 D7000338 M.Murata       Delete some unnecessary logics for APC I/F.
// 2007/06/08 D9000038 D.Tamura       Skip to updating MultiLotType, if the lot is not in a cassette
// 2007/08/23 D9000056 H.Hotta        Add check logic for InPostProcessFlag.
// 2008/10/06 DSIV00000201 F.Chen         Improvement of Post Process.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/11/02 DSIV00000214 S.Miyata       Multi Fab Transfer Support
// 2009/04/16 PSIV00000763 M.Ogawa        Add code check for NonProBankHold
// 2010/02/02 PSIV00001766 S.Kawabe       Change the check of sequence no. for strLotHoldReqList
// 2013/01/23 DSN000050720 M.Ogawa        Skip cassette lock in Post Process parallel execution
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/13 INN-R170002  Thomas Song    Contamination Control
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//     pptHoldLotReleaseReqResult& strHoldLotReleaseReqResult
//     const pptObjCommonIn& strObjCommonIn
//     const objectIdentifier& lotID
//     const char * releaseReasonCodeID
//     const pptHoldListSequence& strLotHoldReqList
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::txHoldLotReleaseReq (pptHoldLotReleaseReqResult& strHoldLotReleaseReqResult,
                                               const pptObjCommonIn& strObjCommonIn,
                                               const objectIdentifier& lotID,
                                               const objectIdentifier& releaseReasonCodeID,
//D6000025                                                const pptHoldListSequence& strLotHoldReqList,
//D6000025                                                CORBA::Environment &IT_env)
                                               const pptHoldListSequence& strLotHoldReqList //D6000025
                                               CORBAENV_LAST_CPP)                           //D6000025
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i:: txHoldLotReleaseReq ") ;
    CORBA::Long rc = RC_OK ;

    //P4100536 add start
    // Check length of In-Parameter
    if(0 >= strLotHoldReqList.length())
    {
        SET_MSG_RC(strHoldLotReleaseReqResult, MSG_INVALID_PARAMETER, RC_INVALID_PARAMETER); //P4200025 add
        return RC_INVALID_PARAMETER;
    }
    //P4100536 add end

    objectIdentifier aLotID( lotID ) ;
    objectIdentifier aCassetteID ;

//D4200062 add start
    CORBA::Boolean backupProcessingFlag = FALSE;
    if( 0 == CIMFWStrCmp(strObjCommonIn.transactionID , "TXBOC006") ||
        0 == CIMFWStrCmp(strObjCommonIn.transactionID , "TXBOC009") ||
        0 == CIMFWStrCmp(strObjCommonIn.transactionID , "TXBOC003") )
    {
        PPT_METHODTRACE_V1("", " ##### backupProcessingFlag == TRUE ");
        backupProcessingFlag = TRUE ;
    }
//D4200062 add end
    /*-----------------------------------*/
    /*   Get cassette / lot connection   */
    /*-----------------------------------*/
    objLot_cassette_Get_out    strLot_cassette_Get_out ;
    rc = lot_cassette_Get(strLot_cassette_Get_out, strObjCommonIn, aLotID);
//D9000038    if (rc != RC_OK)
    if (rc != RC_OK && rc != RC_NOT_FOUND_CST ) //D9000038
    {
        if( FALSE == backupProcessingFlag )                                                              //D4200062
        {                                                                                                //D4200062
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txHoldLotReleaseReq", "lot_cassette_Get() != RC_OK") ;
            strHoldLotReleaseReqResult.strResult = strLot_cassette_Get_out.strResult ;
            return(rc);
        }                                                                                                //D4200062
    }
    aCassetteID = strLot_cassette_Get_out.cassetteID ;

    /*--------------------------------*/
    /*   Lock objects to be updated   */
    /*--------------------------------*/
    objObject_Lock_out strObject_Lock_out;
//D7000092 add start
//DSN000050720 Add Start
    // Get PostProcForLotFlag from thread specific data
    char* methodName = NULL;
    CORBA::String_var strParallelPostProcFlag;
    try
    {
        methodName = CIMFWStrDup("getThreadSpecificDataString");
        strParallelPostProcFlag = getThreadSpecificDataString(SP_ThreadSpecificData_Key_PostProcParallelFlag);
        CORBA::string_free(methodName);
        methodName = NULL;
    }
    CATCH_GLOBAL_EXCEPTIONS(strHoldLotReleaseReqResult, txHoldLotReleaseReq, methodName);

    PPT_METHODTRACE_V2("", "strParallelPostProcFlag", strParallelPostProcFlag);

    //----------------------------------------------------------//
    //   Skip cassette lock to increase parallel availability   //
    //   under PostProcess parallel execution                   //
    //----------------------------------------------------------//
    if ( 0 != CIMFWStrCmp(strParallelPostProcFlag, SP_PostProcess_ParallelExecution_ON) )
    {
        //PostProcess sequential execution
        PPT_METHODTRACE_V1("", "Lock cassette object.");
//DSN000050720 Add End
//DSN000050720 Indent Start
        if( FALSE == backupProcessingFlag )
        {
            rc = object_Lock( strObject_Lock_out, strObjCommonIn, aCassetteID, SP_ClassName_PosCassette );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("","object_Lock() rc != RC_OK", rc);
                strHoldLotReleaseReqResult.strResult = strObject_Lock_out.strResult;
                return( rc );
            }
        }
//DSN000050720 Indent End
    }   //DSN000050720
//D7000092 add end

    rc = object_Lock( strObject_Lock_out, strObjCommonIn, aLotID, SP_ClassName_PosLot );
    if ( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txHoldLotReleaseReq ", "object_Lock() rc != RC_OK") ;
        strHoldLotReleaseReqResult.strResult = strObject_Lock_out.strResult ;
        return( rc );
    }

    /*-----------------------------------------------------------*/
    /* Check Condition                                           */
    /*-----------------------------------------------------------*/

    //D6000051 Add Start
    //---------------------------------------------
    // Check Release Season Code for LOCR
    //---------------------------------------------
    if( CIMFWStrCmp( releaseReasonCodeID.identifier, SP_Reason_LotLockRelease ) == 0 )
    {
        PPT_METHODTRACE_V1( "", "releaseReasonCodeID: SP_Reason_LotLockRelease" );

        CORBA::Long    i;
        CORBA::Long    holdReqListLen = strLotHoldReqList.length();

        PPT_METHODTRACE_V2( "", "holdReqListLen" , holdReqListLen );

        for ( i = 0; i < holdReqListLen; i++ )
        {
            if ( CIMFWStrCmp( strLotHoldReqList[i].holdReasonCodeID.identifier, SP_Reason_LotLock ) != 0 )
            {
                PPT_METHODTRACE_V1( "", "holdReasonCodeID is not SP_Reason_LotLock" );
                SET_MSG_RC( strHoldLotReleaseReqResult, MSG_CANNOT_HOLD_RELEASE_WITH_LOCR, RC_CANNOT_HOLD_RELEASE_WITH_LOCR );
                return RC_CANNOT_HOLD_RELEASE_WITH_LOCR;
            }
        }
    }
    else
    {
        CORBA::Long    i;
        CORBA::Long    holdReqListLen = strLotHoldReqList.length();

        for ( i = 0; i < holdReqListLen; i++ )
        {
            //-----------------------------------------
            // Check LOCK record existence
            //-----------------------------------------
            if ( CIMFWStrCmp( strLotHoldReqList[i].holdReasonCodeID.identifier, SP_Reason_LotLock ) == 0 )
            {
                PPT_METHODTRACE_V1( "", "holdReasonCodeID is SP_Reason_LotLock" );
                SET_MSG_RC( strHoldLotReleaseReqResult, MSG_CANNOT_HOLD_RELEASE_FOR_LOCK, RC_CANNOT_HOLD_RELEASE_FOR_LOCK );
                return RC_CANNOT_HOLD_RELEASE_FOR_LOCK;
            }
        }
    }
    //D6000051 Add End

    for(CORBA::Long i=0; i<strLotHoldReqList.length(); i++)                                                        //PSIV00001766
    {                                                                                                              //PSIV00001766
//PSIV00001766        if( CIMFWStrCmp( strLotHoldReqList[0].holdReasonCodeID.identifier, SP_Reason_NonProBankHold ) == 0 )                                                        //D3100021
        if( CIMFWStrCmp( strLotHoldReqList[i].holdReasonCodeID.identifier, SP_Reason_NonProBankHold ) == 0 )       //PSIV00001766
        {                                                                                                                                                           //D3100021
//D4200062        if ( CIMFWStrCmp( strObjCommonIn.transactionID , "TXBKC011" ) != 0 )                                                                          //D3100021
            if ( CIMFWStrCmp( strObjCommonIn.transactionID , "TXBKC011" ) != 0 &&                                                                                   //D4200062
                 CIMFWStrCmp( strObjCommonIn.transactionID , "TXBOC006" ) != 0 &&                                                                                   //D4200062
                 CIMFWStrCmp( strObjCommonIn.transactionID , "TXBOC009" ) != 0 )                                                                                    //D4200062
            {                                                                                                                                                       //D3100021
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txHoldLotReleaseReq", "NonProBankHold is allowed only to TXBKC010") ;                                            //D3100021
//P5000145            PPT_SET_MSG_RC_KEY( strHoldLotReleaseReqResult, MSG_CANNOT_HOLDRELEASE_WITH_NPBH, RC_CANNOT_HOLDRELEASE_WITH_NPBH, strObjCommonIn.transactionID ) ; //D3100021
                SET_MSG_RC( strHoldLotReleaseReqResult, MSG_CANNOT_HOLDRELEASE_WITH_NPBH, RC_CANNOT_HOLDRELEASE_WITH_NPBH );        //P5000145
                return( RC_CANNOT_HOLDRELEASE_WITH_NPBH );                                                                                                          //D3100021
            }                                                                                                                                                       //D3100021
        }                                                                                                                                                           //D3100021
    }                                                                                                              //PSIV00001766
                                                                                                                                                                //D3100021
    if( CIMFWStrCmp( releaseReasonCodeID.identifier, SP_Reason_NonProBankHoldRelease ) == 0 )                                                                   //D3100021
    {                                                                                                                                                           //D3100021
//D4200062        if ( CIMFWStrCmp( strObjCommonIn.transactionID , "TXBKC011" ) != 0 )                                                                          //D3100021
        if ( CIMFWStrCmp( strObjCommonIn.transactionID , "TXBKC011" ) != 0 &&                                                                                   //D4200062
             CIMFWStrCmp( strObjCommonIn.transactionID , "TXBOC006" ) != 0 &&                                                                                   //D4200062
             CIMFWStrCmp( strObjCommonIn.transactionID , "TXBOC009" ) != 0 )                                                                                    //D4200062
        {                                                                                                                                                       //D3100021
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txHoldLotReleaseReq", "NonProBankHoldRelease is allowed only to TXBKC010") ;                                     //D3100021
//P5000145            PPT_SET_MSG_RC_KEY( strHoldLotReleaseReqResult, MSG_CANNOT_HOLDRELEASE_WITH_NPBR, RC_CANNOT_HOLDRELEASE_WITH_NPBR, strObjCommonIn.transactionID ) ; //D3100021
            SET_MSG_RC( strHoldLotReleaseReqResult, MSG_CANNOT_HOLDRELEASE_WITH_NPBR, RC_CANNOT_HOLDRELEASE_WITH_NPBR );        //P5000145
            return( RC_CANNOT_HOLDRELEASE_WITH_NPBR );                                                                                                          //D3100021
        }                                                                                                                                                       //D3100021
    }                                                                                                                                                           //D3100021

    for(i=0; i<strLotHoldReqList.length(); i++)                                                                    //PSIV00001766
    {                                                                                                              //PSIV00001766
//PSIV00001766        if( CIMFWStrCmp( strLotHoldReqList[0].holdReasonCodeID.identifier, SP_Reason_BackupOperation_Hold ) == 0 )                                                  //D4200062
        if( CIMFWStrCmp( strLotHoldReqList[i].holdReasonCodeID.identifier, SP_Reason_BackupOperation_Hold ) == 0 ) //PSIV00001766
        {                                                                                                                                                           //D4200062
            if ( CIMFWStrCmp( strObjCommonIn.transactionID , "TXBOC006" ) != 0 &&                                                                                   //D4200062
                 CIMFWStrCmp( strObjCommonIn.transactionID , "TXBOC009" ) != 0 &&                                                                                   //D4200062
                 CIMFWStrCmp( strObjCommonIn.transactionID , "TXBOC003" ) != 0 )                                                                                    //D4200062
            {                                                                                                                                                       //D4200062
                PPT_METHODTRACE_V1("", "BackupOperationHold is allowed TXBOC006 or TXBOC009") ;                                                                     //D4200062
                SET_MSG_RC( strHoldLotReleaseReqResult, MSG_CANNOT_HOLDRELEASE_WITH_BOHL, RC_CANNOT_HOLDRELEASE_WITH_BOHL ) ;                                       //D4200062
                return( RC_CANNOT_HOLDRELEASE_WITH_BOHL );                                                                                                          //D4200062
            }                                                                                                                                                       //D4200062
        }                                                                                                                                                           //D4200062
    }                                                                                                              //PSIV00001766

    if( CIMFWStrCmp( releaseReasonCodeID.identifier, SP_Reason_BackupOperation_HoldRelease ) == 0 )                                                             //D4200062
    {                                                                                                                                                           //D4200062
        if ( CIMFWStrCmp( strObjCommonIn.transactionID , "TXBOC006" ) != 0 &&                                                                                   //D4200062
             CIMFWStrCmp( strObjCommonIn.transactionID , "TXBOC009" ) != 0 &&                                                                                   //D4200062
             CIMFWStrCmp( strObjCommonIn.transactionID , "TXBOC003" ) != 0 )                                                                                    //D4200062
        {                                                                                                                                                       //D4200062
            PPT_METHODTRACE_V1("", "BackupOperationHoldRelease is allowed TXBOC006 or TXBOC009") ;                                                              //D4200062
            SET_MSG_RC( strHoldLotReleaseReqResult, MSG_CANNOT_HOLDRELEASE_WITH_BOHR, RC_CANNOT_HOLDRELEASE_WITH_BOHR ) ;                                       //D4200062
            return( RC_CANNOT_HOLDRELEASE_WITH_BOHR );                                                                                                          //D4200062
        }                                                                                                                                                       //D4200062
    }                                                                                                                                                           //D4200062

    objLot_state_Get_out strLot_state_Get_out ;
    rc = lot_state_Get(strLot_state_Get_out,strObjCommonIn,aLotID) ;
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txHoldLotReleaseReq", "lot_state_Get() != RC_OK") ;
        strHoldLotReleaseReqResult.strResult = strLot_state_Get_out.strResult ;
        return(rc) ;
    }
    else if (CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Active))
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txHoldLotReleaseReq",
                           "CIMFWStrCmp(strLot_state_Get_out.lotState,CIMFW_Lot_State_Active)") ;
        if( FALSE == backupProcessingFlag )                                                          //D4200062
        {                                                                                            //D4200062
            PPT_SET_MSG_RC_KEY(strHoldLotReleaseReqResult,
                               MSG_INVALID_LOT_STAT,
                               RC_INVALID_LOT_STAT,
                               strLot_state_Get_out.lotState) ;
            return(RC_INVALID_LOT_STAT);
        }                                                                                            //D4200062
    }

    objLot_holdState_Get_out strLot_holdState_Get_out ;
    rc = lot_holdState_Get(strLot_holdState_Get_out,strObjCommonIn,aLotID);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txHoldLotReleaseReq", "lot_holdState_Get() != RC_OK") ;
        strHoldLotReleaseReqResult.strResult = strLot_holdState_Get_out.strResult ;
        return(rc);
    }
    else if (CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState,CIMFW_Lot_HoldState_NotOnHold) == 0)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txHoldLotReleaseReq",
                           "CIMFWStrCmp(strLot_holdState_Get_out.lotHoldState,CIMFW_Lot_HoldState_NotOnHold)") ;
        PPT_SET_MSG_RC_KEY(strHoldLotReleaseReqResult,MSG_LOT_NOT_HELD,RC_LOT_NOT_HELD,aLotID.identifier) ;
        return(RC_LOT_NOT_HELD);
    }

//D9000056 add start
    PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");
    //----------------------------------
    //  Get InPostProcessFlag of Lot
    //----------------------------------
    objLot_inPostProcessFlag_Get_out strLot_inPostProcessFlag_Get_out;
    objLot_inPostProcessFlag_Get_in  strLot_inPostProcessFlag_Get_in;
    strLot_inPostProcessFlag_Get_in.lotID = aLotID;

    rc = lot_inPostProcessFlag_Get( strLot_inPostProcessFlag_Get_out,
                                    strObjCommonIn,
                                    strLot_inPostProcessFlag_Get_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_inPostProcessFlag_Get() != RC_OK");
        strHoldLotReleaseReqResult.strResult = strLot_inPostProcessFlag_Get_out.strResult;
        return( rc );
    }

//DSIV00000214 add start
    //-----------------------------------------------------------
    // Check lot interFabXferState
    //-----------------------------------------------------------
    objLot_interFabXferState_Get_out strLot_interFabXferState_Get_out;
    objLot_interFabXferState_Get_in  strLot_interFabXferState_Get_in;
    strLot_interFabXferState_Get_in.lotID = aLotID;
    rc = lot_interFabXferState_Get( strLot_interFabXferState_Get_out,    
                                    strObjCommonIn,
                                    strLot_interFabXferState_Get_in );
    if( rc != RC_OK )
    {
        PPT_METHODTRACE_V1("", "lot_interFabXferState_Get() != RC_OK");
        strHoldLotReleaseReqResult.strResult = strLot_interFabXferState_Get_out.strResult;
        return( rc );
    }
//DSIV00000214 add end

    //----------------------------------------------
    //  If Lot is in post process, returns error
    //----------------------------------------------
    if( TRUE == strLot_inPostProcessFlag_Get_out.inPostProcessFlagOfLot )
    {
        PPT_METHODTRACE_V1("", "Lot is in post process.");

        if ( CIMFWStrCmp(strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Required) != 0 )    //DSIV00000214
        {    //DSIV00000214
            PPT_METHODTRACE_V1("", "interFabXferState != Required");    //DSIV00000214
//DSIV00000201 Add Start
            /*---------------------------*/
            /* Get UserGroupID By UserID */
            /*---------------------------*/
            objPerson_userGroupList_GetDR_out  strPerson_userGroupList_GetDR_out;
            rc = person_userGroupList_GetDR( strPerson_userGroupList_GetDR_out,
                                             strObjCommonIn,
                                             strObjCommonIn.strUser.userID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "person_userGroupList_GetDR != RC_OK");
                strHoldLotReleaseReqResult.strResult = strPerson_userGroupList_GetDR_out.strResult;
                return( rc );
            }
            objectIdentifierSequence userGroupIDs = strPerson_userGroupList_GetDR_out.userGroupIDs;
            CORBA::ULong userGroupIDsLen = userGroupIDs.length();
            PPT_METHODTRACE_V2("", "userGroupIDsLen", userGroupIDsLen);
            
            CORBA::String_var extPostProc = CIMFWStrDup(getenv (SP_ExternalPostProc_UserGrp));
            PPT_METHODTRACE_V2("", "extPostProc", extPostProc);
            
            CORBA::ULong nCnt = 0;
            for (nCnt = 0; nCnt < userGroupIDsLen; nCnt++)
            {
                PPT_METHODTRACE_V3("", "# Loop[nCnt]/userID", nCnt, userGroupIDs[nCnt].identifier);
                if (CIMFWStrCmp (userGroupIDs[nCnt].identifier, extPostProc) == 0)
                {
                    PPT_METHODTRACE_V1("", "# External Post Process User!");
                    break;
                }
                
            }
            if (nCnt == userGroupIDsLen)
            {
                PPT_METHODTRACE_V1("", "NOT External Post Process User!");
//DSIV00000201 Add End
                PPT_SET_MSG_RC_KEY( strHoldLotReleaseReqResult,
                                    MSG_LOT_INPOSTPROCESS, RC_LOT_INPOSTPROCESS,
                                    aLotID.identifier );
                return( RC_LOT_INPOSTPROCESS );
            }   //DSIV00000201
        }    //DSIV00000214
    }
//D9000056 add end

    /*-----------------------------------------------------------*/
    /*   Check PosCode                                           */
    /*-----------------------------------------------------------*/
    pptCheckedCodesSequence strCheckedCodes ;
    strCheckedCodes.length(1) ;
    strCheckedCodes[0].codeDataID = releaseReasonCodeID ;

//P3100007    objCode_CheckExistance_out strCode_CheckExistance_out ;
    objCode_CheckExistanceDR_out strCode_CheckExistanceDR_out ;  //P3100007
//P3100007    rc = code_CheckExistanceDR(strCode_CheckExistance_out, strObjCommonIn, SP_ReasonCat_LotHoldRelease, strCheckedCodes);

    if ( CIMFWStrCmp( strObjCommonIn.transactionID, "TXPCC019")==0 )                                                             //D4200029
    {                                                                                                                            //D4200029
        PPT_METHODTRACE_V1("","transactionID...TXPCC019");                                                                       //D4200029
        PPT_METHODTRACE_V2("","releaseReasonCodeID...",strCheckedCodes[0].codeDataID.identifier);                                //D4200029
        rc = code_CheckExistanceDR(strCode_CheckExistanceDR_out, strObjCommonIn,SP_ReasonCat_ProcessHoldCancel,strCheckedCodes); //D4200029
        if (rc != RC_OK)                                                                                                         //D4200029
        {                                                                                                                        //D4200029
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txHoldLotReleaseReq", "code_CheckExistanceDR() != RC_OK") ;                       //D4200029
            strHoldLotReleaseReqResult.strResult = strCode_CheckExistanceDR_out.strResult ;                                      //D4200029
            return rc ;                                                                                                          //D4200029
        }                                                                                                                        //D4200029
    }                                                                                                                            //D4200029
    else if ( 0 == CIMFWStrCmp( releaseReasonCodeID.identifier, SP_Reason_NonProBankHoldRelease ) )                              //PSIV00000763
    {                                                                                                                            //PSIV00000763
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txHoldLotReleaseReq", "0 == CIMFWStrCmp( releaseReasonCodeID.identifier, SP_Reason_NonProBankHoldRelease )") ;  //PSIV00000763
        // Do Nothing.                                                                                                           //PSIV00000763
    }                                                                                                                            //PSIV00000763
    else                                                                                                                         //D4200029
    {                                                                                                                            //D4200029
        PPT_METHODTRACE_V1("","transactionID is not TXPCC019");                                                                  //D4200029
        PPT_METHODTRACE_V2("","releaseReasonCodeID...",strCheckedCodes[0].codeDataID.identifier);                                //D4200029
        rc = code_CheckExistanceDR(strCode_CheckExistanceDR_out, strObjCommonIn, SP_ReasonCat_LotHoldRelease, strCheckedCodes);  //P3100007
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txHoldLotReleaseReq", "code_CheckExistanceDR() != RC_OK") ;
    //P3100007        strHoldLotReleaseReqResult.strResult = strCode_CheckExistance_out.strResult ;
            strHoldLotReleaseReqResult.strResult = strCode_CheckExistanceDR_out.strResult ;  //P3100007
            return rc ;
        }
    }                                                                                                                            //D4200029

    /*------------------------------------------------------------------------*/
    /*   Change State                                                         */
    /*------------------------------------------------------------------------*/
    objLot_HoldRelease_out strLot_HoldRelease ;
    rc = lot_HoldRelease(strLot_HoldRelease,strObjCommonIn,aLotID,releaseReasonCodeID,strLotHoldReqList);
    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTManager_i:: txHoldLotReleaseReq", "lot_HoldRelease() != RC_OK") ;
        strHoldLotReleaseReqResult.strResult = strLot_HoldRelease.strResult ;
        return(rc);
    }

//INN-R170002 Add Start
    //--------------------------------------------------------------------------------------------------
    // Check Contamination Level
    //--------------------------------------------------------------------------------------------------
    csObjLot_ContaminationInfo_CheckForMove_in strLot_ContaminationInfo_CheckForMove_in;
    strLot_ContaminationInfo_CheckForMove_in.lotID = aLotID;
    strLot_ContaminationInfo_CheckForMove_in.carrierID = aCassetteID;
    csObjLot_ContaminationInfo_CheckForMove_out strLot_ContaminationInfo_CheckForMove_out;
    rc = cs_lot_ContaminationInfo_CheckForMove( strLot_ContaminationInfo_CheckForMove_out,
                                                strObjCommonIn,
                                                strLot_ContaminationInfo_CheckForMove_in );

    if(rc != RC_OK)
    {
        PPT_METHODTRACE_V1("","cs_lot_ContaminationInfo_CheckForMove != RC_OK");
        strHoldLotReleaseReqResult.strResult = strLot_ContaminationInfo_CheckForMove_out.strResult;
        return rc;
    }

    if(strLot_ContaminationInfo_CheckForMove_out.holdReqFlag == TRUE)
    {
        for(i=0; i<strLotHoldReqList.length(); i++)
        {
            if( CIMFWStrCmp( strLotHoldReqList[i].holdReasonCodeID.identifier, CS_SP_Reason_ContaminationMismatchHold ) == 0 )
            {
                PPT_METHODTRACE_V1("","holdReasonCodeID==CCMH");
                CS_PPT_SET_MSG_RC_KEY1( strHoldLotReleaseReqResult,
                                     CS_MSG_CANNOT_HOLDRELEASE_CCMH,
                                     CS_RC_CANNOT_HOLDRELEASE_CCMH,
                                     aLotID.identifier );
                return CS_RC_CANNOT_HOLDRELEASE_CCMH;
            }
        }
        //hold the lot if mismatch exists
        pptHoldListSequence strLotHoldReqList;
        strLotHoldReqList.length( 1 );
        strLotHoldReqList[0].holdType                    = CIMFWStrDup( SP_HoldType_LotHold );
        strLotHoldReqList[0].holdReasonCodeID.identifier = CIMFWStrDup( CS_SP_Reason_ContaminationMismatchHold );
        strLotHoldReqList[0].holdUserID                  = strObjCommonIn.strUser.userID;
        strLotHoldReqList[0].responsibleOperationMark    = CIMFWStrDup( SP_ResponsibleOperation_Current );
        strLotHoldReqList[0].claimMemo                   = CIMFWStrDup("");

        pptHoldLotReqResult strHoldLotReqResult;
        rc = txHoldLotReq( strHoldLotReqResult, strObjCommonIn,
                           aLotID,
                           strLotHoldReqList );
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() != RC_OK") ;
            strHoldLotReleaseReqResult.strResult = strHoldLotReqResult.strResult ;
            return rc ;
        }
        else
        {
            PPT_METHODTRACE_V1("", "txHoldLotReq() == RC_OK For LotHold") ;
        }
    }
//INN-R170002 Add End

    /*---------------------------------------*/
    /*   Update Cassette's MultiLotType      */
    /*---------------------------------------*/
    if( FALSE == backupProcessingFlag )                                                          //D4200062
    {                                                                                            //D4200062
//D9000038 add start
        if( CIMFWStrLen( aCassetteID.identifier ) > 0)
        {
//D9000038 add end
            objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
            rc = cassette_multiLotType_Update(strCassette_multiLotType_Update_out, strObjCommonIn, aCassetteID);
            if (rc != RC_OK)
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txHoldLotReleaseReq", "cassette_multiLotType_Update() != RC_OK") ;
                strHoldLotReleaseReqResult.strResult = strCassette_multiLotType_Update_out.strResult ;
                return(rc);
            }
//D9000038 add start
        }
        else
        {
            PPT_METHODTRACE_V1("", "The cassetteID is empty.");
        }
//D9000038 add end
    }                                                                                            //D4200062

    /*------------------------------------------------------------------------*/
    /*   Make Lot Hold Release History                                        */
    /*------------------------------------------------------------------------*/
    //D6000051 Add Start
    if( CIMFWStrCmp( releaseReasonCodeID.identifier, SP_Reason_LotLockRelease ) != 0 )                                   //D3100021
    {    //D6000051 Add End And following Logic was neted

        objLotHoldEvent_Make_out strLotHoldEvent_Make_out ;
        rc = lotHoldEvent_Make(strLotHoldEvent_Make_out, strObjCommonIn, "TXTRC018", aLotID, strLot_HoldRelease.strHoldHistory) ;
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i:: txHoldLotReleaseReq", "lotHoldEvent_Make() != RC_OK") ;
//P3000139        strHoldLotReleaseReqResult.strResult = strLotHoldEvent_Make_out.strResult ; //P3000139
//P5000145        PPT_SET_MSG_RC_KEY(strHoldLotReleaseReqResult, MSG_FAIL_MAKE_HISTORY, rc, aLotID.identifier) ;
            SET_MSG_RC( strHoldLotReleaseReqResult, MSG_FAIL_MAKE_HISTORY, rc );        //P5000145
            return(rc);
        }
    }    //D6000051

    /*------------------------------------------------------------------------*/
    /*   Future Hold Cancel                                                   */
    /*------------------------------------------------------------------------*/
    if(strLot_HoldRelease.strFutureHoldCancelReqList.length())
    {
        //P7000215 Add Start
        CORBA::Long  foundCnt  = 0;
        CORBA::Long  cancelLen = strLot_HoldRelease.strFutureHoldCancelReqList.length();

        pptHoldListSequence  futureHoldCancelList;
        futureHoldCancelList.length( cancelLen );

        for( CORBA::Long  cancelCnt = 0; cancelCnt < cancelLen; cancelCnt++ )
        {
            pptFutureHoldSearchKey  fhSearchKey;

            fhSearchKey.lotID           = lotID;
            fhSearchKey.holdType        = strLot_HoldRelease.strFutureHoldCancelReqList[cancelCnt].holdType;
            fhSearchKey.reasonCodeID    = strLot_HoldRelease.strFutureHoldCancelReqList[cancelCnt].holdReasonCodeID;
            fhSearchKey.userID          = strLot_HoldRelease.strFutureHoldCancelReqList[cancelCnt].holdUserID;
            fhSearchKey.routeID         = strLot_HoldRelease.strFutureHoldCancelReqList[cancelCnt].routeID;
            fhSearchKey.operationNumber = strLot_HoldRelease.strFutureHoldCancelReqList[cancelCnt].operationNumber;
            fhSearchKey.relatedLotID    = strLot_HoldRelease.strFutureHoldCancelReqList[cancelCnt].relatedLotID;

            PPT_METHODTRACE_V4("", "The conditions to search", fhSearchKey.holdType, fhSearchKey.reasonCodeID.identifier, fhSearchKey.userID.identifier);
            PPT_METHODTRACE_V3("", fhSearchKey.routeID.identifier, fhSearchKey.operationNumber, fhSearchKey.relatedLotID.identifier);

            objLot_FutureHoldListbyKeyDR_out  strLot_FutureHoldListbyKeyDR_out;
            rc = lot_futureHoldListbyKeyDR( strLot_FutureHoldListbyKeyDR_out, strObjCommonIn, fhSearchKey, 1 );
            if( rc == RC_OK )
            {
                PPT_METHODTRACE_V1("", "The target future hold request is found.");
                futureHoldCancelList[foundCnt++] = strLot_HoldRelease.strFutureHoldCancelReqList[cancelCnt];
            }
            else if( rc == RC_NOT_FOUND_FTHOLD_ENT_W )
            {
                PPT_METHODTRACE_V1("", "The target future hold request is not found. It may have been cancelled.");
            }
            else
            {
                PPT_METHODTRACE_V1("", "lot_futureHoldListbyKeyDR() != RC_OK");
                strHoldLotReleaseReqResult.strResult = strLot_FutureHoldListbyKeyDR_out.strResult;
                return rc;
            }
        }

        PPT_METHODTRACE_V2("", "The number of future hold requests to be cancelled", foundCnt);
        if( foundCnt > 0 )
        {
        //P7000215 Add End : The following lines' indention is adjusted.
            futureHoldCancelList.length( foundCnt );               //P7000215

//P7000215            PPT_METHODTRACE_V1("CS_PPTManager_i:: txHoldLotReleaseReq", strLot_HoldRelease.strFutureHoldCancelReqList.length()) ;
            pptFutureHoldCancelReqResult strFutureHoldCancelReqResult ;
            rc = txFutureHoldCancelReq( strFutureHoldCancelReqResult,
                                        strObjCommonIn,
                                        aLotID,
                                        releaseReasonCodeID,
                                        SP_EntryType_Remove,
                                        futureHoldCancelList );    //P7000215
//P7000215                                       strLotHoldReqList) ;
            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: txHoldLotReleaseReq", "txFutureHoldCancelReq() != RC_OK") ;
                strHoldLotReleaseReqResult.strResult = strFutureHoldCancelReqResult.strResult ;
                return rc ;
            }
        }                                                          //P7000215
    }

//D7000338//D51M0000 add start
//D7000338    /*------------------------------------------------------------------------*/
//D7000338    /*   APC RuntimeCapability Delete for Lot                                 */
//D7000338    /*   records of FRRUNCAPAxx delete                                        */
//D7000338    /*   when HoldReasonCode is "APCH" and requestUserID is not "APCWatcher". */
//D7000338    /*------------------------------------------------------------------------*/
//D7000338    CORBA::Long nHoldReqLen = strLotHoldReqList.length();
//D7000338    CORBA::Boolean APCHFlag = FALSE ;
//D7000338    if (CIMFWStrCmp( strObjCommonIn.strUser.userID.identifier, SP_APCWatchDog_Person ) != 0 )
//D7000338    {
//D7000338        for( CORBA::Long i = 0 ; i < nHoldReqLen ; i++ )
//D7000338        {
//D7000338            if( CIMFWStrCmp( strLotHoldReqList[i].holdReasonCodeID.identifier, SP_Reason_WaitAPCResultHold ) == 0 )
//D7000338            {
//D7000338                APCHFlag = TRUE;
//D7000338                break;
//D7000338            }
//D7000338        }
//D7000338
//D7000338        if( APCHFlag == TRUE )
//D7000338        {
//D7000338            objAPCRuntimeCapability_DeleteLotDR_out  strAPCRuntimeCapability_DeleteLotDR_out;
//D7000338            rc = APCRuntimeCapability_DeleteLotDR(   strAPCRuntimeCapability_DeleteLotDR_out,
//D7000338                                                     strObjCommonIn,
//D7000338                                                     aLotID );
//D7000338            if( rc != RC_OK )
//D7000338            {
//D7000338                PPT_METHODTRACE_V1("", "APCRuntimeCapability_DeleteLotDR() != RC_OK") ;
//D7000338                strHoldLotReleaseReqResult.strResult = strAPCRuntimeCapability_DeleteLotDR_out.strResult ;
//D7000338                return rc ;
//D7000338            }
//D7000338         }
//D7000338     }
//D7000338//D51M0000 add end

    /*------------------------------------------------------------------------*/
    /*   Return                                                               */
    /*------------------------------------------------------------------------*/
    SET_MSG_RC(strHoldLotReleaseReqResult, MSG_OK, RC_OK) ;
    PPT_METHODTRACE_EXIT("CS_PPTManager_i:: txHoldLotReleaseReq ") ;
    return(RC_OK);
}
