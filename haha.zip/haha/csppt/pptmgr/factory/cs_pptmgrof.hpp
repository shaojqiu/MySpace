// SCCS ID: @(#) 1.1 superpos/src/csppt/source/posppt/pptmgr/factory/cs_pptmgrof.hpp, mm_srv_90e_cspp, mm_srv_90e_cspp 7/13/07 19:55:09 [ 7/13/07 19:55:10 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView - PPT Manager
// Name: cs_pptmgrof.hpp
// Description : Definition of Customized PPTManagerObjectFactory
//
// ** Notice **
//   This is a sample code for customizing a PPT Manager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT ServiceManager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//
// Change history:
//
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya      Initial Release for R5.0
// 09/15/04   D6000025 K.Murakami      BOAImpl was added in order to make it TIE to BOA. 
// 10/26/04   D6000025 K.Murakami      eBrokerMigration.
//

#ifndef cs_pptmgrof_ih
#define cs_pptmgrof_ih
#ifndef EXCEPTIONS
#define EXCEPTIONS
#endif

#include "pptmgrof.hpp"
#include "cs_pptmgrof.hh"

#ifdef MO_BOA   //D6000025
class CS_PPTManagerObjectFactory_i: virtual public PPTManagerObjectFactory_i, virtual public CS_PPTManagerObjectFactoryBOAImpl  //D6000025
#else   //D6000025
class CS_PPTManagerObjectFactory_i: public PPTManagerObjectFactory_i
#endif  //D6000025
{
public:
//D6000025    virtual PPTManager_ptr createPPTManager (CORBA::Environment &IT_env=CORBA::default_environment) ;
    virtual PPTManager_ptr createPPTManager (CORBAENV_ONLY_HPP) ;  //D6000025
    CS_PPTManagerObjectFactory_i() ;
    ~CS_PPTManagerObjectFactory_i() ;
};

#ifndef MO_BOA  //D6000025
DEF_TIE_CS_PPTManagerObjectFactory(CS_PPTManagerObjectFactory_i);
#endif         //D6000025

#endif
