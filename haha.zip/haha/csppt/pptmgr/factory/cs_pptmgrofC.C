//----------------------------------------------------------------------------
//
//  Generated from cs_pptmgrof.idl
//  On Thursday, October 19, 2017 7:30:47 PM GMT+07:00
//  by IBM CORBA 2.3 (uc) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _cs_pptmgrof_bindings_defined
#define _cs_pptmgrof_bindings_defined
#endif 
#ifdef SOMCBNOLOCALINCLUDES
#include <cs_pptmgrof.hh>
#else
#include "cs_pptmgrof.hh"
#endif
#ifdef SIVIEW_EBROKER
 #ifdef linux
  #include <new>
 #else
  #include <new.h>
 #endif
#endif


#ifdef _AIX
#ifndef _UNIX
#define _UNIX
#endif
#endif
#include <private/wasdpriv.h>
#include <assert.h>

enum BoundaryCheckMode { BCM_None, BCM_Logging, BCM_Exception, BCM_Assertion };

#define SOMD_BOUNDARY_CHECK_ERROR(checkMode,index,maxlength)\
    switch(checkMode)\
    {\
    case BCM_Logging:\
            somdLogMsg( __FILE__, __LINE__,SOMRAS_EL_SEVERITY_ERROR,"",WASMessage(WASL_MSG_6S, WASLog::WASLogSvcCatalogName)<<"Boundary check error at " << __FUNCTION__ << ". index:" << index << ", "  #maxlength " :" << maxlength );\
            break;\
    case BCM_Exception:\
            throw CORBA::BAD_PARAM(SOMDMINOR_BAD_PARAM_OTHER,CORBA::COMPLETED_NO);\
            break;\
    case BCM_Assertion:\
            assert( index < maxlength );\
            break;\
    case BCM_None:\
    default:\
            break;\
    }\

static BoundaryCheckMode boundaryCheck_Maximum = BCM_None;
static BoundaryCheckMode boundaryCheck_Length = BCM_None;

static void __cs_pptmgrof_initialize()
{
    class __cs_pptmgrof_initializer
    {
    public:
        __cs_pptmgrof_initializer()
        {
            boundaryCheck_Length = (BoundaryCheckMode)WasGetParmInt("com.ibm.CORBA.actionForBoundaryCheckOfSequenceLength", (int)BCM_None );
            boundaryCheck_Maximum = (BoundaryCheckMode)WasGetParmInt("com.ibm.CORBA.actionForBoundaryCheckOfSequenceMaxLength", (int)BCM_Logging );
        }
    };
    static __cs_pptmgrof_initializer initialize;
}


#ifdef _DCL_CS_PPTManagerObjectFactory
::CORBA::Object_ptr SOMLINK CS_PPTManagerObjectFactory_getBase(void *p){ return(CS_PPTManagerObjectFactory_ptr) p; }
::CS_PPTManagerObjectFactory_ptr SOMLINK CS_PPTManagerObjectFactory_aux_duplicate(::CS_PPTManagerObjectFactory_ptr o) { return CS_PPTManagerObjectFactory::_duplicate(o); }
::CS_PPTManagerObjectFactory_ptr SOMLINK CS_PPTManagerObjectFactory_aux_narrow(::CORBA::Object_ptr  o) { return CS_PPTManagerObjectFactory::_narrow(o); }
::CS_PPTManagerObjectFactory_ptr SOMLINK CS_PPTManagerObjectFactory_aux_nil(){ return CS_PPTManagerObjectFactory::_nil(); }
const char* SOMLINK CS_PPTManagerObjectFactory_aux_CN() { return CS_PPTManagerObjectFactory::CS_PPTManagerObjectFactory_CN; }


CS_PPTManagerObjectFactory_StructElem::CS_PPTManagerObjectFactory_StructElem () { 
   _ptr = ::CS_PPTManagerObjectFactory::_nil();
}

CS_PPTManagerObjectFactory_StructElem::CS_PPTManagerObjectFactory_StructElem (const ::CS_PPTManagerObjectFactory_StructElem &s) { 
   _ptr = ::CS_PPTManagerObjectFactory::_duplicate (s._ptr); 
}

CS_PPTManagerObjectFactory_StructElem::~CS_PPTManagerObjectFactory_StructElem () {
   ::CORBA::release((::CORBA::Object_ptr)_ptr);
}

CS_PPTManagerObjectFactory_StructElem& CS_PPTManagerObjectFactory_StructElem::operator= (::CS_PPTManagerObjectFactory_ptr p) {
   if (_ptr)
      ::CORBA::release ((::CORBA::Object_ptr)_ptr);
    _ptr = p;
    return *this;
 }

CS_PPTManagerObjectFactory_StructElem& CS_PPTManagerObjectFactory_StructElem::operator= (::CS_PPTManagerObjectFactory_var v) {
   if (_ptr)
      ::CORBA::release ((::CORBA::Object_ptr)_ptr);
    _ptr = ::CS_PPTManagerObjectFactory::_duplicate(v);
    return *this;
 }

CS_PPTManagerObjectFactory_StructElem& CS_PPTManagerObjectFactory_StructElem::operator= (const ::CS_PPTManagerObjectFactory_StructElem &s) {
   if (this == &s) return *this;
   if (_ptr)
      ::CORBA::release ((::CORBA::Object_ptr)_ptr);
   _ptr = ::CS_PPTManagerObjectFactory::_duplicate (s._ptr);
   return *this;
}

CS_PPTManagerObjectFactory_StructElem::operator ::CORBA::Object_ptr() const {
   return (::CORBA::Object_ptr)_ptr;
}
CS_PPTManagerObjectFactory_StructElem::operator CS_PPTManagerObjectFactory_ptr () const {
   return _ptr;
}

CS_PPTManagerObjectFactory_SeqElem::CS_PPTManagerObjectFactory_SeqElem (::CS_PPTManagerObjectFactory_ptr* p, unsigned char rel) {
   _ptr = p;
   _release = rel;
}

CS_PPTManagerObjectFactory_SeqElem& CS_PPTManagerObjectFactory_SeqElem::operator= (::CS_PPTManagerObjectFactory_ptr p) {
   if (!_ptr)
      return *this;
   if (*(_ptr) && _release)
      ::CORBA::release ((::CORBA::Object_ptr)(*_ptr));
   *(_ptr) = p;
   return *this;
}

CS_PPTManagerObjectFactory_SeqElem& CS_PPTManagerObjectFactory_SeqElem::operator= (::CS_PPTManagerObjectFactory_var v) {
   if (*(_ptr) && _release)
      ::CORBA::release ((::CORBA::Object_ptr)(*_ptr));
    (*_ptr) = ::CS_PPTManagerObjectFactory::_duplicate(v);
    return *this;
 }

CS_PPTManagerObjectFactory_SeqElem& CS_PPTManagerObjectFactory_SeqElem::operator= (const ::CS_PPTManagerObjectFactory_SeqElem &s) {
   if ((this == &s) || !_ptr || !s._ptr)
      return *this;
   if (*(_ptr) && _release)
      ::CORBA::release (( ::CORBA::Object_ptr)(*_ptr));
   *(_ptr) = ::CS_PPTManagerObjectFactory::_duplicate(*(s._ptr));
   return *this;
}

CS_PPTManagerObjectFactory_SeqElem::operator ::CS_PPTManagerObjectFactory_ptr () const {
   if (!_ptr)
      return ::CS_PPTManagerObjectFactory::_nil();
   return *_ptr;
}

::CS_PPTManagerObjectFactory_ptr CS_PPTManagerObjectFactory_SeqElem::operator -> () const {
   if (!_ptr)
      return ::CS_PPTManagerObjectFactory::_nil();
   return *_ptr;
}


const char* CS_PPTManagerObjectFactory::CS_PPTManagerObjectFactory_CN = "CS_PPTManagerObjectFactory";
const char* CS_PPTManagerObjectFactory::CS_PPTManagerObjectFactory_RID = "IDL:CS_PPTManagerObjectFactory:1.0";

void * CS_PPTManagerObjectFactory::_deref() { return (void *)this; }
CS_PPTManagerObjectFactory::CS_PPTManagerObjectFactory()
{}
CS_PPTManagerObjectFactory::~CS_PPTManagerObjectFactory()
{}
CS_PPTManagerObjectFactory_ptr CS_PPTManagerObjectFactory::_nil () { return (CS_PPTManagerObjectFactory_ptr) ((void*)CORBA::Object::_nil()); }
::CS_PPTManagerObjectFactory_ptr  CS_PPTManagerObjectFactory::_duplicate(::CS_PPTManagerObjectFactory_ptr obj)
{
   if (!::CORBA::is_nil((::CORBA::Object_ptr)obj))
      obj->_incref();
   return obj;
}

#ifdef _MSC_VER
#pragma warning(disable:4101)
#endif
::CS_PPTManagerObjectFactory_ptr CS_PPTManagerObjectFactory::_narrow (::CORBA::Object_ptr obj) 
{
try {
    if ( ! obj)
        return ::CS_PPTManagerObjectFactory::_nil();
    ::CS_PPTManagerObjectFactory_ptr casted = (::CS_PPTManagerObjectFactory_ptr)(obj->_has_ancestor(::CS_PPTManagerObjectFactory::CS_PPTManagerObjectFactory_CN));
    if (casted) return _duplicate(casted);
    /* use ORB implementation of narrow*/
    if (obj->_is_a(::CS_PPTManagerObjectFactory::CS_PPTManagerObjectFactory_RID)) {
        ::CORBA::Object_ptr newproxy = ::CORBA::ORB::rebuild_proxy(obj, ::CS_PPTManagerObjectFactory::CS_PPTManagerObjectFactory_CN);
        return (::CS_PPTManagerObjectFactory_ptr)(newproxy->_has_ancestor(::CS_PPTManagerObjectFactory::CS_PPTManagerObjectFactory_CN));
    }
} catch(::CORBA::SystemException &e){ 
    throw;
} catch(...) {
    ::CORBA::UNKNOWN _unknown_except(SOMDERROR_Unknown, ::CORBA::COMPLETED_NO);
    throw _unknown_except;
}
#ifdef _MSC_VER
#pragma warning(default:4101)
#endif
    return ::CS_PPTManagerObjectFactory::_nil();
}

#ifndef _MSC_VER
::CS_PPTManagerObjectFactory_ptr CS_PPTManagerObjectFactory::_self()
{
    ::CORBA::Object_ptr _temp = _localReference();
    if ( !::CORBA::is_nil(_temp) ) {
        ::CORBA::Object_var _localProxy = _temp;
        if ( _localProxy == (::CORBA::Object_ptr)this) return this;
        ::CS_PPTManagerObjectFactory_ptr _casted = (::CS_PPTManagerObjectFactory_ptr)_localProxy->_has_ancestor(::CS_PPTManagerObjectFactory::CS_PPTManagerObjectFactory_CN);
        if ( _casted ) return _casted;
    }
    ::CORBA::INV_OBJREF _tmpexcept(0, ::CORBA::COMPLETED_NO);
    throw _tmpexcept;
}
::CS_PPTManagerObjectFactory_ptr CS_PPTManagerObjectFactory::_this()
{
    return _duplicate(_self());
}
#endif /* _MSC_VER */

void* CS_PPTManagerObjectFactory::_has_ancestor(const char* classname)
{
::CORBA::Long _code = ::CORBA::_somd_hash_string(classname);
/* testing 6 ancestors */
if ( _code <= 0x6e8adf9){
    if ( _code == 0x1d8a979 && !strcmp(classname, ::PPTManagerObjectFactory::PPTManagerObjectFactory_CN)){
        /* "PPTManagerObjectFactory" */
        return (void *)(::PPTManagerObjectFactory_ptr)this;
    }
    else if ( _code == 0x3083d19 && !strcmp(classname, ::MOFW_TransManagedObjectFactory::MOFW_TransManagedObjectFactory_CN)){
        /* "MOFW_TransManagedObjectFactory" */
        return (void *)(::MOFW_TransManagedObjectFactory_ptr)this;
    }
    else if ( _code == 0x6e8adf9 && !strcmp(classname, ::CS_PPTManagerObjectFactory::CS_PPTManagerObjectFactory_CN)){
        /* "CS_PPTManagerObjectFactory" */
        return (void *)(::CS_PPTManagerObjectFactory_ptr)this;
    }
} else { 
    if ( _code == 0x71f6f34 && !strcmp(classname, ::CORBA::Object::Object_CN)){
        /* CORBA::Object */ return (void *)(::CORBA::Object_ptr)this;
    }
    else if ( _code == 0x87623e9 && !strcmp(classname, ::MOFW_ManagedObjectFactory::MOFW_ManagedObjectFactory_CN)){
        /* "MOFW_ManagedObjectFactory" */
        return (void *)(::MOFW_ManagedObjectFactory_ptr)this;
    }
    else if ( _code == 0xecbaa44 && !strcmp(classname, ::CosTransactions::TransactionalObject::TransactionalObject_CN)){
        /* "CosTransactions::TransactionalObject" */
        return (void *)(::CosTransactions::TransactionalObject_ptr)this;
    }
}
return 0;
}


void * CS_PPTManagerObjectFactory::_SOMThis(const char *&ifname){
    ifname = ::CS_PPTManagerObjectFactory::CS_PPTManagerObjectFactory_CN;
    return this;
}
CS_PPTManagerObjectFactory_var::CS_PPTManagerObjectFactory_var () { _ptr = ::CS_PPTManagerObjectFactory_aux_nil (); }

CS_PPTManagerObjectFactory_var::CS_PPTManagerObjectFactory_var (CS_PPTManagerObjectFactory *p) { _ptr = p; }

CS_PPTManagerObjectFactory_var::CS_PPTManagerObjectFactory_var (const CS_PPTManagerObjectFactory_var &s) {
  _ptr = ::CS_PPTManagerObjectFactory_aux_duplicate (s._ptr);
}
CS_PPTManagerObjectFactory_var::CS_PPTManagerObjectFactory_var (const CS_PPTManagerObjectFactory_StructElem &s) {
  _ptr = ::CS_PPTManagerObjectFactory_aux_nil ();
  operator=(s);
}
CS_PPTManagerObjectFactory_var::CS_PPTManagerObjectFactory_var (const CS_PPTManagerObjectFactory_SeqElem &s) {
  _ptr = ::CS_PPTManagerObjectFactory_aux_nil ();
  operator=(s);
}
CS_PPTManagerObjectFactory_var::~CS_PPTManagerObjectFactory_var () { ::CORBA::release ((::CORBA::Object_ptr)_ptr); }

::CS_PPTManagerObjectFactory_var& CS_PPTManagerObjectFactory_var::operator= (const ::CS_PPTManagerObjectFactory_StructElem &s) {
  if (_ptr)
     ::CORBA::release ((::CORBA::Object_ptr)_ptr);
  _ptr = ::CS_PPTManagerObjectFactory::_duplicate (s._ptr);
  return *this;
}
::CS_PPTManagerObjectFactory_var& CS_PPTManagerObjectFactory_var::operator= (const ::CS_PPTManagerObjectFactory_SeqElem &s) {
  if (_ptr)
     ::CORBA::release ((::CORBA::Object_ptr)_ptr);
  _ptr = ::CS_PPTManagerObjectFactory::_duplicate (s);
  return *this;
}
::CS_PPTManagerObjectFactory_var& CS_PPTManagerObjectFactory_var::operator= (::CS_PPTManagerObjectFactory *p) {
  if (_ptr == p)
     return *this;
  if (_ptr)
     ::CORBA::release ((::CORBA::Object_ptr)_ptr);
  _ptr = p;
  return *this;
}

::CS_PPTManagerObjectFactory_var& CS_PPTManagerObjectFactory_var::operator= (const ::CS_PPTManagerObjectFactory_var &s) {
  if (this == &s) return *this;
  if (_ptr)
     ::CORBA::release ((::CORBA::Object_ptr)_ptr);
  _ptr = ::CS_PPTManagerObjectFactory::_duplicate (s._ptr);
  return *this;
}
::CS_PPTManagerObjectFactory_ptr CS_PPTManagerObjectFactory_var::in () const { return _ptr; }
::CS_PPTManagerObjectFactory_ptr& CS_PPTManagerObjectFactory_var::inout () { return _ptr; }
::CS_PPTManagerObjectFactory_ptr& CS_PPTManagerObjectFactory_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     ::CORBA::release ((::CORBA::Object_ptr)_ptr);
  _ptr = ::CS_PPTManagerObjectFactory_aux_nil ();
  return _ptr;}
::CS_PPTManagerObjectFactory_ptr CS_PPTManagerObjectFactory_var::_retn () {
  // yield ownership of managed object reference
  CS_PPTManagerObjectFactory_ptr ret = _ptr;
  _ptr = ::CS_PPTManagerObjectFactory_aux_nil ();
  return ret;}
CS_PPTManagerObjectFactory_ptr CS_PPTManagerObjectFactory_var::operator-> () { return _ptr; };
CS_PPTManagerObjectFactory_var::operator CS_PPTManagerObjectFactory_ptr& () { return _ptr; };
CS_PPTManagerObjectFactory_var::operator const CS_PPTManagerObjectFactory_ptr& () const { return _ptr; };


#ifdef _MSC_VER
#pragma warning(disable:4250)
#endif
CS_PPTManagerObjectFactoryBOAImpl::CS_PPTManagerObjectFactoryBOAImpl() {
  if ( !m_classname 
       || !strcmp(m_classname, ::CORBA::Object::Object_CN)
       || !strcmp(m_classname, "PPTManagerObjectFactory")) {
       m_classname = (char*)CS_PPTManagerObjectFactory::CS_PPTManagerObjectFactory_CN;
       m_target_type_id = (char*)CS_PPTManagerObjectFactory::CS_PPTManagerObjectFactory_RID; 
       if (m_dispatcher) delete (::CORBA::SOMDDispatcher*) m_dispatcher; // out with the old,
       m_dispatcher = (::CORBA::SOMDDispatcher*) new CS_PPTManagerObjectFactory_Dispatcher(this); // in with the new
    }
}

CS_PPTManagerObjectFactoryBOAImpl::~CS_PPTManagerObjectFactoryBOAImpl()
{ 
  if (m_dispatcher) delete (::CORBA::SOMDDispatcher*) m_dispatcher; 
  m_dispatcher = 0;
}

CS_PPTManagerObjectFactoryBOAImpl& CS_PPTManagerObjectFactoryBOAImpl::operator= (const CS_PPTManagerObjectFactoryBOAImpl &s) 
{
  return *this;
}

CS_PPTManagerObjectFactoryBOAImpl::CS_PPTManagerObjectFactoryBOAImpl (const CS_PPTManagerObjectFactoryBOAImpl &s)
{
  if (m_dispatcher) delete (::CORBA::SOMDDispatcher*) m_dispatcher;
  m_dispatcher = (::CORBA::SOMDDispatcher*) new CS_PPTManagerObjectFactory_Dispatcher (this);
}
#ifdef _MSC_VER
#pragma warning(default:4250)
#endif
CS_PPTManagerObjectFactory_Dispatcher::CS_PPTManagerObjectFactory_Dispatcher (::CORBA::Object_ptr target) : 
#ifndef _MSC_VER
  ::CORBA::
#endif
           SOMDDispatcher(target )
{
}
CS_PPTManagerObjectFactory_Dispatcher::CS_PPTManagerObjectFactory_Dispatcher ()
{
}
#ifndef CS_PPTManagerObjectFactory_dispatcher

::CORBA::Boolean CS_PPTManagerObjectFactory_Dispatcher::dispatch (::CORBA::Request &r)
{
   return 0;
}

#endif

CS_PPTManagerObjectFactory_ORBProxy::CS_PPTManagerObjectFactory_ORBProxy () { 
  m_classname = (char*)
                       CS_PPTManagerObjectFactory::
                       CS_PPTManagerObjectFactory_CN;
}
CS_PPTManagerObjectFactoryProxyFactory::CS_PPTManagerObjectFactoryProxyFactory (::CORBA::Boolean is_default) :
#ifndef _MSC_VER
  ::CORBA::
#endif
           SOMDProxyFactory (CS_PPTManagerObjectFactory::CS_PPTManagerObjectFactory_CN, is_default) 
{ }
::CORBA::Object_ptr CS_PPTManagerObjectFactoryProxyFactory::create_proxy (const char *classname)
{
   return  new class ::CS_PPTManagerObjectFactory_ORBProxy();
}

::CORBA::Object_ptr CS_PPTManagerObjectFactoryProxyFactory::asObject(void *obj) {
   return  (::CORBA::Object_ptr) (::CS_PPTManagerObjectFactory_ptr)obj;
}

CS_PPTManagerObjectFactoryProxyFactory _CS_PPTManagerObjectFactoryProxyFactory(1);


#endif // _DCL_CS_PPTManagerObjectFactory
/*
 * TypeCode constants
 */
#ifdef _DCL_CS_PPTManagerObjectFactory
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_CS_PPTManagerObjectFactory = NULL;
#else
::CORBA::TypeCode_ptr _tc_CS_PPTManagerObjectFactory =NULL;
#endif // _USE_NAMESPACE
#endif
static void __cs_pptmgrof_emit_tc(::CORBA::ORB_ptr _orb)
{ 

#ifdef _DCL_CS_PPTManagerObjectFactory
::CORBA::TypeCode_ptr _tmp_tc__CS_PPTManagerObjectFactory = _orb->create_interface_tc("IDL:CS_PPTManagerObjectFactory:1.0", "CS_PPTManagerObjectFactory", 0);
_tc_CS_PPTManagerObjectFactory = _tmp_tc__CS_PPTManagerObjectFactory;
#endif
}
static ::CORBA::TypeCodeInitStruct __cs_pptmgrof_TypeCodeInitStruct = { __cs_pptmgrof_emit_tc, 0 , "cs_pptmgrof"};
static ::CORBA::TypeCodeInitializer __cs_pptmgrof_TypeCodeInitializer(&__cs_pptmgrof_TypeCodeInitStruct);
/*
 * Overloaded CORBA::Any operators.
 */
#ifndef _Anyops_for_CS_PPTManagerObjectFactory
#define _Anyops_for_CS_PPTManagerObjectFactory
void operator <<= (::CORBA::Any& _any, ::CS_PPTManagerObjectFactory_ptr _data)
{
   _any.replace(::_tc_CS_PPTManagerObjectFactory, (void*)_data);
}
void operator <<= (::CORBA::Any& _any, ::CS_PPTManagerObjectFactory_ptr* _data)
{
   _any.replace(::_tc_CS_PPTManagerObjectFactory, (void*)*_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::CS_PPTManagerObjectFactory_ptr& _data)
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_CS_PPTManagerObjectFactory)) {
     _data = (::CS_PPTManagerObjectFactory_ptr)(_any.value());
      return 1;
   }
   else return 0;
}
#endif // _Anyops_for_CS_PPTManagerObjectFactory
