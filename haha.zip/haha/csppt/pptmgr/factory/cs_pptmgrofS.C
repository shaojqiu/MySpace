//----------------------------------------------------------------------------
//
//  Generated from cs_pptmgrof.idl
//  On Thursday, October 19, 2017 7:30:46 PM GMT+07:00
//  by IBM CORBA 2.3 (sc) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#define _cs_pptmgrof_bindings_defined
#ifdef SOMCBNOLOCALINCLUDES
#include <cs_pptmgrof.hh>
#else
#include "cs_pptmgrof.hh"
#endif
#ifdef _DCL_CS_PPTManagerObjectFactory

#define CS_PPTManagerObjectFactory_dispatcher

CORBA::Boolean CS_PPTManagerObjectFactory_Dispatcher::dispatch (CORBA::Request &_req) 
{
   const char *mname = _req.operation();
   CORBA::Long _code = CORBA::_somd_hash_string(mname);
   return ( 
#ifndef _MSC_VER
::PPTManagerObjectFactory_Dispatcher::dispatch(_req)
#else
__PPTManagerObjectFactory__dispatch(_req)
#endif
          );

}

#ifdef _MSC_VER
CORBA::Boolean CS_PPTManagerObjectFactory_Dispatcher::__CS_PPTManagerObjectFactory__dispatch (CORBA::Request &_req)
{
   typedef ::CS_PPTManagerObjectFactory_Dispatcher _scope_;
   return (_scope_::dispatch(_req));
}
#endif // _MSC_VER

#endif // _DCL_CS_PPTManagerObjectFactory

#define _cs_pptmgrof_server_defined
#ifdef SOMCBNOLOCALINCLUDES
#include <cs_pptmgrofC.C>
#else
#include "cs_pptmgrofC.C"
#endif

