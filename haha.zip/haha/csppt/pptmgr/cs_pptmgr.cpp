#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/csppt/source/posppt/pptmgr/cs_pptmgr.cpp, mm_srv_90e_cspp, mm_srv_90e_cspp 7/13/07 19:53:54 [ 7/13/07 19:53:56 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView - CS PPT Manager
// Name: cs_pptmgr.cpp
// Description : Implementation of Customized PPT Manager
//
// ** Notice **
//   This is a sample code for customizing a PPT Manager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT Manager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//
// Change history:
//
// Date       Defect#  Person         Comments
// ---------- -------- -------------- ----------------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya      Initial Release for R5.0
// 2004/10/26 D6000025 K.Murakami      eBrokerMigration.
//


#include "cs_pptmgr.hpp"

CS_PPTManager_i::CS_PPTManager_i()
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::CS_PPTManager_i");

    PPT_METHODTRACE_EXIT("CS_PPTManager_i::CS_PPTManager_i");
}

CS_PPTManager_i::~CS_PPTManager_i()
{
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::~CS_PPTManager_i");
    CS_PPTManager_uninit();
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::~CS_PPTManager_i");
}

//D6000025void CS_PPTManager_i:: CS_PPTManager_init (CORBA::Environment &IT_env)  {
void CS_PPTManager_i:: CS_PPTManager_init (CORBAENV_ONLY_CPP)  {  //D6000025
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::CS_PPTManager_init");
    PPTManager_i::PPTManager_init();
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::CS_PPTManager_init");
}

//D6000025void CS_PPTManager_i:: CS_PPTManager_uninit (CORBA::Environment &IT_env)  {
void CS_PPTManager_i:: CS_PPTManager_uninit (CORBAENV_ONLY_CPP)  {   //D6000025
    PPT_METHODTRACE_ENTRY("CS_PPTManager_i::~CS_PPTManager_uninit");
    PPT_METHODTRACE_EXIT("CS_PPTManager_i::~CS_PPTManager_uninit");
}


