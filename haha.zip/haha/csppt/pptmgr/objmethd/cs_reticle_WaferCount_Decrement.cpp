//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_reticle_WaferCount_Decrement.cpp
//


#include "cs_pptmgr.hpp"
#include "timstamp.hpp"
#include "duration.hpp"
#include "ppcdr.hh"
#include "ppcdrcp.hh"
#include "pperson.hh"
#include "pmc.hh"
#include "pstmc.hh"
#include "pperson.hh"
#include "pbufrs.hh"
#include "pdrmggl.hh"
#include "mtrllctn.hh"

// Class: CS_PPTManager
//
// Service: cs_reticle_WaferCount_Decrement()
//
// Change history:
// Date       Defect#       Person        Comments
// ---------- --------      ------------- -------------------------------------------
// 2017/09/12 INN-R170003   Joan Zhou     INN-R170003:Durable Management Enhancement
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    objReticle_WaferCount_Decrement_out&        strReticle_WaferCount_Decrement_out,
//    const pptObjCommonIn&                   strObjCommonIn,
//    objReticle_WaferCount_Decrement_in&        strReticle_WaferCount_Decrement_in,
//
//    typedef struct csObjReticle_WaferCount_Decrement_out_struct {
//        pptRetCode              strResult;
//        any                     siInfo;
//    }  csObjReticle_WaferCount_Decrement_out;
//    
//    typedef struct csObjReticle_WaferCount_Decrement_in_struct {
//        objectIdentifier        reticleID;
//        long                    waferCount;
//        any                     siInfo;
//    }  csObjReticle_WaferCount_Decrement_in;
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_reticle_WaferCount_Decrement(
    csObjReticle_WaferCount_Decrement_out&      strReticle_WaferCount_Decrement_out,
    const pptObjCommonIn&                       strObjCommonIn,
    csObjReticle_WaferCount_Decrement_in&       strReticle_WaferCount_Decrement_in)

{
    char * methodName = NULL;

    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_reticle_WaferCount_Decrement");

        objectIdentifier reticleID = strReticle_WaferCount_Decrement_in.reticleID;
        PPT_METHODTRACE_V2("","reticleID---------------->", reticleID.identifier);
        /*------------------------------------------------------------------------*/
        /*   Get Reticle                                                          */
        /*------------------------------------------------------------------------*/
        PosProcessDurable_var aReticle;
        PPT_CONVERT_RETICLEID_TO_RETICLE_OR(aReticle,
            strReticle_WaferCount_Decrement_in.reticleID,
            strReticle_WaferCount_Decrement_out,
            cs_reticle_WaferCount_Decrement);
        CORBA::String_var  varDecrementWaferCount;
        try
        {
            CORBA::String_var varWaferCount;
            SI_PPT_USERDATA_GET_STRING(aReticle,
                CS_M_RTCL_USED_WAFER_COUNT,
                varWaferCount);
            PPT_METHODTRACE_V2("", "SI_PPT_USERDATA_GET_STRING CS_M_RTCL_USED_WAFER_COUNT---------------->", varWaferCount);

            varDecrementWaferCount = ConvertLongtoString(strReticle_WaferCount_Decrement_in.waferCount - atol(varWaferCount));
            PPT_METHODTRACE_V2("", "WaferCount Decrement Result---------------->", varDecrementWaferCount);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getUserDataNamed);

        /*------------------------------------------------------------------------*/
        /*   Set Reticle                                                          */
        /*------------------------------------------------------------------------*/
        try
        {
            SI_PPT_USERDATA_SET_STRING(aReticle,
                CS_M_RTCL_USED_WAFER_COUNT,
                varDecrementWaferCount);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setUserDataNamed);

        try
        {
            SI_PPT_USERDATA_SET_STRING(aReticle,
                CS_M_RTCL_LAST_REPAIR_TIME,
                strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setUserDataNamed);

        try
        {
            aReticle->setLastMaintenanceTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setLastMaintenanceTimeStamp);

        PosPerson_var aPerson;
        PPT_GET_PERSON_FROM_USERID(aPerson, strObjCommonIn.strUser.userID, strReticle_WaferCount_Decrement_out, cs_reticle_WaferCount_Decrement)

            try
        {
            aReticle->setLastMaintenancePerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setLastMaintenancePerson);

        try
        {
            aReticle->setLastClaimedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setLastClaimedTimeStamp);

        try
        {
            aReticle->setLastClaimedPerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setLastClaimedPerson);

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_reticle_WaferCount_Decrement");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strReticle_WaferCount_Decrement_out, cs_reticle_WaferCount_Decrement, methodName)
}


