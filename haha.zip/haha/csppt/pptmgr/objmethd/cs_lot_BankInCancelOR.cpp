#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cs_lot_BankInCancelOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 20:00:01 [ 7/13/07 20:00:03 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: lot_BankInCancel.cpp
//

#include "cs_pptmgr.hpp"

#include "plottype.hh"
#include "plot.hh"
#include "plotfm.hh"
#include "pbank.hh"
#include "pperson.hh"
#include "ppcope.hh" //PSN000081346


// Class: CS_PPTManager
//
// Service: lot_BankInCancel()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/09/19 D4000172 Y.Kurisu       Initial Release
// 2002/04/23 P4100402 K.Kido         Fix MemoryLeak.
// 2003/09/08 P5000145 H.Adachi       Fix Message and Message Macro mismatch.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2015/02/18  PSN000081346 S.Kawabe      "Bank-In Cancel" transaction fails. 
//

// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------  -------------- -------------------------------------------
// 2017-09-08 INN-R170002   JQ.Shao        Change required 'Carrier Category' from 'no check' to blank

//[Function Description]:
//
//
//[Input Parameters]:
//  in  pptObjCommonIn      strObjCommonIn;
//  in  objectIdentifier    lotID
//
//[Output Parameters]:
//
//  out objLot_BankInCancel_out  strLot_BankInCancel;
//
//  typedef struct objLot_BankInCancel_out_struct {
//      pptRetCode          strResult;
//  } objLot_BankInCancel_out;
//
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::lot_BankInCancel(
                        objLot_BankInCancel_out& strLot_BankInCancel_out,
                        const pptObjCommonIn& strObjCommonIn,
                        const objectIdentifier&   lotID )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::lot_BankInCancel");
        PosLot_var aLot;
        PPT_CONVERT_LOTID_TO_LOT_OR(aLot,
                                    lotID,
                                    strLot_BankInCancel_out,
                                    lot_BankInCancel) ;

        if ( CORBA::is_nil( aLot ) == TRUE )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i::lot_BankInCancel", "CORBA::is_nil( aLot ) == TRUE");
            PPT_SET_MSG_RC_KEY( strLot_BankInCancel_out,
                                MSG_NOT_FOUND_LOT,
                                RC_NOT_FOUND_LOT,
                                lotID.identifier );
            return RC_NOT_FOUND_LOT;
        }

        LotFamily_var aLotFamily;
        try
        {
            aLotFamily = aLot->getLotFamily();
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::getLotFamily)

        if(CORBA::is_nil(aLotFamily))
        {
//P5000145            PPT_SET_MSG_RC_KEY( strLot_BankInCancel_out,
//P5000145                                MSG_NOT_FOUND_LOTFAMILY,
//P5000145                                RC_NOT_FOUND_LOTFAMILY, "" );
            SET_MSG_RC( strLot_BankInCancel_out,                              //P5000145
                        MSG_NOT_FOUND_LOTFAMILY, RC_NOT_FOUND_LOTFAMILY );    //P5000145
            return RC_NOT_FOUND_LOTFAMILY ;
        }

        try
        {
            aLotFamily->removeArchive(aLot);
        }
        catch (PosLotFamily::LotNotFoundSignal)
        {
            SET_FW_MSG_RC(strLot_BankInCancel_out,
                          lot_BankInCancel,
                          MSG_NOT_FOUND_LOT,
                          RC_NOT_FOUND_LOT,
                          PosLotFamily::removeArchive,
                          PosLotFamily::LotNotFoundSignal,
                          lotID.identifier)
            return RC_NOT_FOUND_LOT ;
        }
        CATCH_AND_RAISE_EXCEPTIONS(LotFamily::removeArchive)

        try
        {
            aLotFamily->addLot(aLot);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::addLot)

        /*-----   Check actualCompletionTime   -----*/
//P4100402        TimeStampImpl actualCompTime;
        CORBA::String_var actualCompTime ;            //P4100402

        try
        {
            actualCompTime = aLotFamily->actualCompletionTime();
        }
        CATCH_AND_RAISE_EXCEPTIONS(LotFamily::actualCompletionTime)

        if (CIMFWStrCmp( actualCompTime , SP_TIMESTAMP_NIL_OBJECT_STRING) > 0 )
        {
            try
            {
                aLotFamily->setActualCompletionTime(SP_TIMESTAMP_NIL_OBJECT_STRING);
            }
            CATCH_AND_RAISE_EXCEPTIONS(LotFamily::setActualCompletionTime)
        }
        /*-----   New FW Method   -----*/
        try
        {
            aLot->setAllStateForBankInCancel();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setAllStateForBankInCancel)

        /*-----   Set Data   -----*/

        PosBank_var aBank ;
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aBank = aLot->getBank();
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::getBank)

        if(CORBA::is_nil(aBank))
        {
            PPT_SET_MSG_RC_KEY( strLot_BankInCancel_out,
                                MSG_NOT_FOUND_BANK,
                                RC_NOT_FOUND_BANK, "" );
            return RC_NOT_FOUND_BANK ;
        }

        try
        {
            aLot->setBank( PosBank::_nil() ) ;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setBank)

        try
        {
            aLot->setPreviousBank( aBank ) ;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setPreviousBank)


        try
        {
            aLot->setLastClaimedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::setLastClaimedTimeStamp)

        PosPerson_var aPerson;
        PPT_GET_PERSON_FROM_USERID(aPerson,strObjCommonIn.strUser.userID,strLot_BankInCancel_out,lot_BankInCancel);


        try
        {
            aLot->setLastClaimedPerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::setLastClaimedPerson)


        try
        {
            aLot->setStateChangedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::setStateChangedTimeStamp)


        try
        {
            aLot->setStateChangedPerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::setStateChangedPerson)


        try
        {
            theDispatchingManager->addToQueue(aLot);
        }
        CATCH_AND_RAISE_EXCEPTIONS(DispatchingManager::removeFromQueue)

//PSN000081346 add start
        PosProcessOperation_var aPosProcessOperation_var ;
        try
        {
            ProcessOperation_var aProcessOperation_var = aLot->getProcessOperation() ;
            aPosProcessOperation_var = PosProcessOperation::_narrow( aProcessOperation_var ) ;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation)

        if( CORBA::is_nil(aPosProcessOperation_var) )
        {
            PPT_METHODTRACE_V1("", "aPosProcessOperation_var is nil");
            PPT_SET_MSG_RC_KEY2( strLot_BankInCancel_out,
                                 MSG_NOT_FOUND_PO,
                                 RC_NOT_FOUND_PO,
                                 "*****",
                                 lotID.identifier);
            return( RC_NOT_FOUND_PO );
        }

        CORBA::String_var requiredCassetteCategory_var;
        try
        {
            requiredCassetteCategory_var = aPosProcessOperation_var->getRequiredCassetteCategory();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getRequiredCassetteCategory)

//INN-R170002 Add Start
        PPT_METHODTRACE_V2("", "requiredCassetteCategory_var", requiredCassetteCategory_var);

        if( 0 == CIMFWStrCmp(requiredCassetteCategory_var, CS_CarrierCategory_NoCheck) )
        {
            PPT_METHODTRACE_V1("", "requiredCassetteCategory_var == NoCheck");
            requiredCassetteCategory_var = CIMFWStrDup("");
        }
//INN-R170002 Add End

        if( CIMFWStrLen(requiredCassetteCategory_var) > 0 )
        {
            try
            {
                aLot->setRequiredCassetteCategory(requiredCassetteCategory_var);
            }
            CATCH_AND_RAISE_EXCEPTIONS(Lot::setRequiredCassetteCategory)
        }
//PSN000081346 add end

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::lot_BankInCancel");

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_BankInCancel_out, lot_BankInCancel, methodName)
}
