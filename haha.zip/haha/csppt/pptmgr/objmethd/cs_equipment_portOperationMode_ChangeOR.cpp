#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/equipment_portOperationMode_Change.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:47:07 [ 7/13/07 19:47:09 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: equipment_portOperationMode_Change.cpp
//

//vera #include "pptmgr.hpp"
#include "cs_pptmgr.hpp"

#include "ppcope.hh"
#include "pportrs.hh"
#include "pcodegl.hh"
#include "pmom.hh"
#include "pperson.hh" //P4000180

// Class: PPTManager
//
// Service: equipment_portOperationMode_Change()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/01          H.Katoh        Initial Release
// 2001/09/13 P4000180 M.Ameshita     Fix to update claimed user/timestamp.
// 2003/04/03 P5000011 K.Matsuei      Add Check Logic into EqpModeChange.
// 2005/07/26 D6000362 K.Matsuei      Enhancement of check for EqpModeChange.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/02/28 DSN000104510 K.Yamaoku      Clear dispatch carrier for equipment when it was changed mode
//
// Description:
//
// Return:
//     Long
//
//[Function Description]:
//
//  * Change equipment port operation mode as input parameter
//
//[Input Parameters]:
//  in  pptObjCommonIn                  strObjCommonIn;
//  in  objectIdentifier                equipmentID;
//  in  pptPortOperationModeSequence    strPortOperationMode;
//
//[Output Parameters]:
//
//  out objEquipment_portOperationMode_Change_out  strEquipment_portOperationMode_Change_out;
//
//  typedef struct objEquipment_portOperationMode_Change_out_struct {
//      pptRetCode              strResult;
//  } objEquipment_portOperationMode_Change_out;
//
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
// Date       version           Person         Comments
// ---------- -----------       -------------- -------------------------------------------
// 2017/09/18 INN-R170012       Vera Chen      Support Online mode and offline can be mixed for Inline Pilot 
//
//

//INN-R170012 CORBA::Long PPTManager_i::equipment_portOperationMode_Change(
CORBA::Long CS_PPTManager_i::equipment_portOperationMode_Change(
                                objEquipment_portOperationMode_Change_out& strEquipment_portOperationMode_Change_out,
                                const pptObjCommonIn& strObjCommonIn,
                                const objectIdentifier& equipmentID,
                                const pptPortOperationModeSequence& strPortOperationMode )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::equipment_portOperationMode_Change");

//P5000011 start
        CORBA::Long rc = RC_OK;

        PPT_METHODTRACE_V2("", "strPortOperationMode.length()", strPortOperationMode.length());
        for ( CORBA::Long I=0; I < strPortOperationMode.length(); I++ )
        {
            PPT_METHODTRACE_V1("", "-------------------------------------------------");
            PPT_METHODTRACE_V2("", "portID_______________", strPortOperationMode[I].portID.identifier);
            PPT_METHODTRACE_V2("", "portGroup____________", strPortOperationMode[I].portGroup);
            PPT_METHODTRACE_V2("", "portUsage____________", strPortOperationMode[I].portUsage);
            PPT_METHODTRACE_V2("", "operationMode________", strPortOperationMode[I].strOperationMode.operationMode.identifier);
            PPT_METHODTRACE_V2("", "onlineMode___________", strPortOperationMode[I].strOperationMode.onlineMode);
            PPT_METHODTRACE_V2("", "dispatchMode_________", strPortOperationMode[I].strOperationMode.dispatchMode);
            PPT_METHODTRACE_V2("", "accessMode___________", strPortOperationMode[I].strOperationMode.accessMode);
            PPT_METHODTRACE_V2("", "operationStartMode___", strPortOperationMode[I].strOperationMode.operationStartMode);
            PPT_METHODTRACE_V2("", "operationCompMode____", strPortOperationMode[I].strOperationMode.operationCompMode);
            PPT_METHODTRACE_V2("", "description__________", strPortOperationMode[I].strOperationMode.description);
        }
//P5000011 end

        //-------------------------------------
        // Get object reference of Equipment
        // object reference must be retrieved
        //-------------------------------------
        PPT_METHODTRACE_V1("","Get object reference of Equipment");

        PosMachine_var aPosMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aPosMachine,
                                         equipmentID,
                                         strEquipment_portOperationMode_Change_out,
                                         equipment_portOperationMode_Change );

        //-------------------------------------
        // Get object reference of PosPortResource
        // from input parameter
        //-------------------------------------
        PPT_METHODTRACE_V1("","Get object reference of PosPortResource");

        CORBA::Long i;
        CORBA::Long lenOpeMode = strPortOperationMode.length();

        PPT_METHODTRACE_V2("","strPortOperationMode->length()", lenOpeMode);

        for ( i=0; i < lenOpeMode; i++ )
        {
            PortResource_var aPs;
            PosPortResource_var aPosPort;
            PPT_CONVERT_PORTID_TO_PORTRESOURCE_OR( aPosMachine,
                                                   aPs,
                                                   strPortOperationMode[i].portID,
                                                   strEquipment_portOperationMode_Change_out,
                                                   equipment_portOperationMode_Change );
            aPosPort = PosPortResource::_narrow(aPs);

//D6000362 start
            //----------------------------------------------------------------------
            // It checkes whether OperationMode that can be changed is specified.
            //----------------------------------------------------------------------
            PPT_METHODTRACE_V2("", "Port::getAllAllowedOperationMode", strPortOperationMode[i].portID.identifier);
            PosMachineOperationModeSequence*    anAllAllowedOpeModeSeq = NULL;
            PosMachineOperationModeSequence_var anAllAllowedOpeModeSeqVar;
            try
            {
                anAllAllowedOpeModeSeq = aPosPort->getAllAllowedOperationMode();
                anAllAllowedOpeModeSeqVar = anAllAllowedOpeModeSeq;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::getAllAllowedOperationMode)

            CORBA::Long nModeLen = anAllAllowedOpeModeSeq->length();
            PPT_METHODTRACE_V2("", "nModeLen", nModeLen);

            CORBA::Boolean bFount = FALSE;
            for ( CORBA::Long j=0; j < nModeLen; j++ )
            {
                objectIdentifier allowedOpeModeID;
                PPT_SET_OBJECT_IDENTIFIER( allowedOpeModeID,
                                           (*anAllAllowedOpeModeSeq)[j],
                                           strEquipment_portOperationMode_Change_out,
                                           equipment_portOperationMode_Change,
                                           PosMachineOperationMode );
                if ( 0 == CIMFWStrCmp(allowedOpeModeID.identifier, strPortOperationMode[i].strOperationMode.operationMode.identifier) )
                {
                    PPT_METHODTRACE_V1("", "Found operation mode");
                    bFount = TRUE;
                    break;
                }
            }
            if ( !bFount )
            {
                PPT_METHODTRACE_V1("", "##### Specified OperationMode was not found");
                SET_MSG_RC( strEquipment_portOperationMode_Change_out, MSG_INVALID_MODE_TRANSITION, RC_INVALID_MODE_TRANSITION );
                return( RC_INVALID_MODE_TRANSITION );
            }
//D6000362 end

//DSN000104510 add start
            if ( 0 == CIMFWStrCmp(getenv(SP_DISPATCH_CAST_CLEARED_BY_CHANGE_TO_ONLINE), "1" ) )
            {
                PPT_METHODTRACE_V1("", "SP_DISPATCH_CAST_CLEARED_BY_CHANGE_TO_ONLINE = 1");
                //------------------
                // Change to Online
                //------------------
                if ( 0 == CIMFWStrCmp(strPortOperationMode[i].strOperationMode.onlineMode, SP_Eqp_OnlineMode_OnlineLocal)
                  || 0 == CIMFWStrCmp(strPortOperationMode[i].strOperationMode.onlineMode, SP_Eqp_OnlineMode_OnlineRemote) )
                {
                    PPT_METHODTRACE_V2("", "onlineMode", strPortOperationMode[i].strOperationMode.onlineMode);

                    //---------------------------------------
                    // Get object of current  operation mode
                    //---------------------------------------
                    PosMachineOperationMode_var aCurrPortOpeMode;
                    try
                    {
                        aCurrPortOpeMode = aPosPort->getMachineOperationMode();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::getMachineOperationMode)

                    if ( CORBA::is_nil(aCurrPortOpeMode) )
                    {
                        PPT_METHODTRACE_V1("","aCurrPortOpeMode = nil" );
                        SET_MSG_RC( strEquipment_portOperationMode_Change_out,
                                    MSG_NOT_FOUND_MACHINEOPEMODE,
                                    RC_NOT_FOUND_MACHINEOPEMODE );

                        return RC_NOT_FOUND_MACHINEOPEMODE;
                    }

                    //--------------------------------------------------
                    // Get detail information of current operation mode
                    //--------------------------------------------------
                    posOperationModeInfo_var aCurrOpeModeInfo;
                    try
                    {
                        aCurrOpeModeInfo = aCurrPortOpeMode->getOperationModeInfo();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosMachineOperationMode::getOperationModeInfo)

                    if ( aCurrOpeModeInfo == NULL )
                    {
                        PPT_METHODTRACE_V1("","aCurrOpeModeInfo = null" );
                        SET_MSG_RC( strEquipment_portOperationMode_Change_out,
                                    MSG_NOT_FOUND_MACHINEOPEMODE,
                                    RC_NOT_FOUND_MACHINEOPEMODE );

                        return RC_NOT_FOUND_MACHINEOPEMODE;
                    }

                    //---------------------
                    // Change from Offline
                    //---------------------
                    if ( 0 == CIMFWStrCmp(aCurrOpeModeInfo->onlineMode, SP_Eqp_OnlineMode_Offline) )
                    {
                        PPT_METHODTRACE_V1("","Offline => Online" );

                        //------------------------------------------
                        //   clear Disp.unload Cast/Lot information
                        //------------------------------------------
                        PosLot_var aDummyLot;
                        try
                        {
                            aPosPort->setDispatchUnloadLot( aDummyLot );
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::setDispatchUnloadLot);

                        PosCassette_var aDummyCassette;
                        try
                        {
                            aPosPort->setDispatchUnloadCassette( aDummyCassette );
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::setDispatchUnloadCassette);

                        //-----------------------
                        // Change from Offline-1
                        //-----------------------
                        if ( 0 == CIMFWStrCmp(aCurrOpeModeInfo->accessMode, SP_Eqp_AccessMode_Manual) )
                        {
                            PPT_METHODTRACE_V1("","Offline-1 => Online" );

                            //------------------------------------------
                            //   clear Disp.load Cast/Lot information
                            //------------------------------------------
                            try
                            {
                                aPosPort->setDispatchLoadLot( aDummyLot );
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::setDispatchLoadLot);

                            try
                            {
                                aPosPort->setDispatchLoadCassette( aDummyCassette );
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::setDispatchLoadCassette);
                        }
                    }
                }
            }
//DSN000104510 add end

            PosMachineOperationMode_var anOperationMode;
            PPT_CONVERT_MACHINEOPEMODE_TO_MACHINEOPEMODE_OR( anOperationMode,
                                                             strPortOperationMode[i].strOperationMode.operationMode,
                                                             strEquipment_portOperationMode_Change_out,
                                                             equipment_portOperationMode_Change );

            try
            {
                aPosPort->setMachineOperationMode(anOperationMode);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::setMachineOperationMode)

            //----------------------------------------------                                                 //P4000180
            //       Update TimeStamp and Person Info                                                        //P4000180
            //----------------------------------------------                                                 //P4000180
            try                                                                                              //P4000180
            {                                                                                                //P4000180
                aPosPort->setLastStatusChangeTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);         //P4000180
            }                                                                                                //P4000180
            CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::setLastStatusChangeTimeStamp);                       //P4000180
                                                                                                             //P4000180
            PosPerson_var aPerson;                                                                           //P4000180
            PPT_GET_PERSON_FROM_USERID( aPerson,                                                             //P4000180
                                        strObjCommonIn.strUser.userID,                                       //P4000180
                                        strEquipment_portOperationMode_Change_out,                           //P4000180
                                        equipment_portOperationMode_Change );                                //P4000180
                                                                                                             //P4000180
            try                                                                                              //P4000180
            {                                                                                                //P4000180
                aPosPort->setLastStatusChangePerson(aPerson);                                                //P4000180
            }                                                                                                //P4000180
            CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::setLastStatusChangePerson);                          //P4000180
                                                                                                             //P4000180
            try                                                                                              //P4000180
            {                                                                                                //P4000180
                aPosPort->setLastClaimedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);              //P4000180
            }                                                                                                //P4000180
            CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::setLastClaimedTimeStamp);                            //P4000180
                                                                                                             //P4000180
            try                                                                                              //P4000180
            {                                                                                                //P4000180
                aPosPort->setLastClaimedPerson(aPerson);                                                     //P4000180
            }                                                                                                //P4000180
            CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::setLastClaimedPerson);                               //P4000180
        }
        //INN-R170012 add start
        stringSequence_var specialControls;
        try
        {
            specialControls = aPosMachine->getSpecialEquipmentControls();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getSpecialEquipmentControls)
        CORBA::Boolean bInlinePilot = FALSE;
        for ( CORBA::ULong iCnt=0; iCnt < specialControls->length(); iCnt++ )
        {
            PPT_METHODTRACE_V2("", "loop to specialControls->length()", iCnt);
            if ( 0 == CIMFWStrCmp((*specialControls)[iCnt], SP_Mc_SpecialEquipmentControl_InlinePilot))
            {
                PPT_METHODTRACE_V1("", "specialControl is Inline Pilot");
                bInlinePilot=TRUE;
                break;
            }
        }
        //INN-R170012 add end
//P5000011 start
        objEquipment_portInfo_Get_out  strEquipment_portInfo_Get_out;
        rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out, strObjCommonIn, equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "##### equipment_portInfo_Get() rc != RC_OK", rc);
            strEquipment_portOperationMode_Change_out.strResult = strEquipment_portInfo_Get_out.strResult;
            return( rc );
        }

        CORBA::Long lenPortInfo = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
        PPT_METHODTRACE_V2("", "lenPortInfo", lenPortInfo);

        /****************************************************************/
        /*   In All Ports                                               */
        /*   As for OnlineMode, Online and Offline must not be mixed.   */
        /****************************************************************/
        PPT_METHODTRACE_V1("", "In All Ports, As for OnlineMode, Online and Offline must not be mixed.");
        CORBA::String_var tmpOnlineMode;
        for ( i=0; i < lenPortInfo; i++ )
        {
            PPT_METHODTRACE_V1("", "--------------------------------------------------------");
            PPT_METHODTRACE_V2("", "PortID    ", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].portID.identifier);
            PPT_METHODTRACE_V2("", "onlineMode", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].onlineMode);

            if ( 0 == i )
            {
                tmpOnlineMode = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].onlineMode;
                PPT_METHODTRACE_V2("", "tmpOnlineMode", tmpOnlineMode);
            }
            else if ( 0 == CIMFWStrCmp(SP_Eqp_OnlineMode_Offline, tmpOnlineMode) )
            {
                PPT_METHODTRACE_V1("", "tmpOnlineMode is [Offline]");
                if ( 0 != CIMFWStrCmp(SP_Eqp_OnlineMode_Offline, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].onlineMode) )
                {
                    //INN-R170012 add start
                    if(!bInlinePilot)
                    {
                    //INN-R170012 add end
                        PPT_METHODTRACE_V1("", "##### return RC_INVALID_PORT_MODE_COMBINATION");
                        SET_MSG_RC( strEquipment_portOperationMode_Change_out,
                                    MSG_INVALID_PORT_MODE_COMBINATION,
                                    RC_INVALID_PORT_MODE_COMBINATION );
                        return RC_INVALID_PORT_MODE_COMBINATION;
                    }//INN-R170012
                }
                else
                {
                    PPT_METHODTRACE_V1("", "onlineMode of PortInfo is [Offline] ... GOOD");
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "tmpOnlineMode is not [Offline]");
                if ( 0 != CIMFWStrCmp(SP_Eqp_OnlineMode_OnlineLocal, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].onlineMode)
                  && 0 != CIMFWStrCmp(SP_Eqp_OnlineMode_OnlineRemote, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].onlineMode) )
                {
                    //vera add start
                    if(!bInlinePilot)
                    {
                    //vera add end
                        PPT_METHODTRACE_V1("", "##### return RC_INVALID_PORT_MODE_COMBINATION");
                        SET_MSG_RC( strEquipment_portOperationMode_Change_out,
                                    MSG_INVALID_PORT_MODE_COMBINATION,
                                    RC_INVALID_PORT_MODE_COMBINATION );
                        return RC_INVALID_PORT_MODE_COMBINATION;
                    }//vera
                }
                else
                {
                    PPT_METHODTRACE_V1("", "onlineMode of PortInfo is [Online] ... GOOD");
                }
            }
        }

        /********************************************/
        /*   In Port Group Unit                     */
        /*   All OperationModes must be the same.   */
        /********************************************/
        PPT_METHODTRACE_V1("", "In Port Group Unit, All OperationModes must be the same.");
        pptPortOperationModeSequence tmp_strPortOperationMode;

        for ( i=0; i < lenPortInfo; i++ )
        {
            PPT_METHODTRACE_V1("", "--------------------------------------------------------");
            PPT_METHODTRACE_V2("", "PortGroup    ", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].portGroup);
            PPT_METHODTRACE_V2("", "PortID       ", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].portID.identifier);
            PPT_METHODTRACE_V2("", "operationMode", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].operationMode);

            CORBA::Long lenPortOpeMode = tmp_strPortOperationMode.length();
            PPT_METHODTRACE_V2("", "lenPortOpeMode", lenPortOpeMode);

            CORBA::Boolean bFound = FALSE;

            for ( CORBA::Long j=0; j < lenPortOpeMode; j++ )
            {
                if ( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].portGroup,
                                      tmp_strPortOperationMode[j].portGroup) )
                {
                    PPT_METHODTRACE_V2("", "Found same PortGroup", tmp_strPortOperationMode[j].portGroup);
                    bFound = TRUE;
                    if ( 0 != CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].operationMode,
                                          tmp_strPortOperationMode[j].strOperationMode.operationMode.identifier) )
                    {
                        PPT_METHODTRACE_V1("", "Different OperationMode was found !!");
                        PPT_METHODTRACE_V1("", "##### return RC_INVALID_PORT_MODE_COMBINATION");
                        SET_MSG_RC( strEquipment_portOperationMode_Change_out,
                                    MSG_INVALID_PORT_MODE_COMBINATION,
                                    RC_INVALID_PORT_MODE_COMBINATION );
                        return RC_INVALID_PORT_MODE_COMBINATION;
                    }
                }
            }
            if ( TRUE != bFound )
            {
                PPT_METHODTRACE_V1("", "TRUE != bFound");
                tmp_strPortOperationMode.length(lenPortOpeMode + 1);
                tmp_strPortOperationMode[lenPortOpeMode].portGroup = CIMFWStrDup(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].portGroup);
                tmp_strPortOperationMode[lenPortOpeMode].strOperationMode.operationMode.identifier = CIMFWStrDup(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].operationMode);
            }
        }
//P5000011 end

        PPT_METHODTRACE_EXIT("PPTManager_i::equipment_portOperationMode_Change");

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strEquipment_portOperationMode_Change_out, equipment_portOperationMode_Change, methodName)
}
