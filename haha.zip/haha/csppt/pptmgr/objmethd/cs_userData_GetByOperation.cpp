//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
//
// SiView
// Name: cs_userData_GetByOperation.cpp
//

// Class: CS_PPTManager
//
// [Object Function Name]: long   cs_userData_GetByOperation
//
//
// Innotron Modification history:
// Date       Defect#     Person        Comments
// ---------- ----------- ------------- -------------------------------------------
// 2017/09/15 INN-R170009 Gary Ke       User data get by operation
//
// Function Description:
//
// Input Parameters:
// in csObjUserData_GetByOperation_in  strUserData_GetByOperation_in;
//
// typedef struct csObjUserData_GetByOperation_in_struct {
//    objectIdentifier        routeID;
//    string                  operationNumber;
//    stringSequence          userDataNameSeq;
//    any                     siInfo;
// } csObjUserData_GetByOperation_in
//
// Output Parameters:
// out csObjUserData_GetByOperation_out strUserData_GetByOperation_out;
//
// typedef struct csObjUserData_GetByOperation_out_struct {
//     pptRetCode             strResult;
//     pptUserDataSequence    strUserDataSeq;
//     any                    siInfo;
// } csObjUserData_GetByOperation_out;
//
// Return Value:
//
// Exception:
//
// Pseudo code:
//

#include "cs_pptmgr.hpp"
#include "plot.hh"
#include "ppcflwx.hh"
#include "ppcflw.hh"
#include "ppcope.hh"
#include "ppcopsp.hh"

CORBA::Long CS_PPTManager_i::cs_userData_GetByOperation(
    csObjUserData_GetByOperation_out&       strUserData_GetByOperation_out,
    const pptObjCommonIn&                   strObjCommonIn,
    const csObjUserData_GetByOperation_in&  strUserData_GetByOperation_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY( "CS_PPTManager::cs_userData_GetByOperation" );
        CORBA::Long rc = RC_OK;
        pptUserDataSequence strUserDataSeq;
        strUserDataSeq.length(0);

        const objectIdentifier& routeID         = strUserData_GetByOperation_in.routeID;
        const char*             operationNumber = strUserData_GetByOperation_in.operationNumber;
        const stringSequence&   userDataNameSeq = strUserData_GetByOperation_in.userDataNameSeq;
        CORBA::Long lngNameLen                  = userDataNameSeq.length();

        //-------------------------
        //   Trace Input Parameter
        //-------------------------
        PPT_METHODTRACE_V2("", "in para lotID     ", routeID.identifier);
        PPT_METHODTRACE_V2("", "in para action    ", operationNumber);
        PPT_METHODTRACE_V2("", "in para lngNameLen", lngNameLen);

        //---------------------------------------------------------------------------
        //   Get PD object for MainPD
        //---------------------------------------------------------------------------
        ProcessDefinition_var    varPD;
        PosProcessDefinition_var varPosPD;
        try
        {
            varPD = theProcessDefinitionManager->findMainProcessDefinitionNamed( routeID.identifier ) ;
        }
        CATCH_AND_RAISE_EXCEPTIONS(ProcessDefinitionManager::findMainProcessDefinitionNamed);
        PPT_METHODTRACE_V2("", "varPD", varPD);
        varPosPD = PosProcessDefinition::_narrow( varPD ) ;
        if( CORBA::is_nil( varPosPD ) )
        {
            PPT_METHODTRACE_V1("", "CORBA::is_nil( varPosPD )");
            PPT_SET_MSG_RC_KEY( strUserData_GetByOperation_out,
                                MSG_NOT_FOUND_PD,
                                RC_NOT_FOUND_PD,
                                routeID.identifier );
            return RC_NOT_FOUND_PD ;
        }

        //---------------------------------------------------------------------------
        //   Get Active Process Flow for MainPD
        //---------------------------------------------------------------------------
        PosProcessFlow_var varPosProcessFlow;
        try
        {
            varPosProcessFlow = varPosPD->getActiveProcessFlow();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDefinition::getActiveProcessFlow)
        PPT_METHODTRACE_V2("", "varPosProcessFlow", varPosProcessFlow);
        if(CORBA::is_nil(varPosProcessFlow))
        {
            PPT_METHODTRACE_V1("", "CORBA::is_nil(varPosProcessFlow)");
            PPT_SET_MSG_RC_KEY( strUserData_GetByOperation_out,
                                MSG_NOT_FOUND_PF,
                                RC_NOT_FOUND_PF, "" );
            return RC_NOT_FOUND_PF ;
        }

        //---------------------------------------------------------------------------
        //   Get POS for specified Operation
        //---------------------------------------------------------------------------
        PosProcessOperationSpecification_var varMainPOS;
        try
        {
            varMainPOS = varPosProcessFlow->findProcessOperationSpecificationOnDefault( operationNumber );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlow::findProcessOperationSpecificationOnDefault)
        PPT_METHODTRACE_V2("", "varMainPOS", varMainPOS);
        //---------------------------------------------------------------------------
        //   Get all User Data for POS
        //---------------------------------------------------------------------------
        userDataSetSequence_var varUserDataSeq;
        varUserDataSeq->length(0);

        if( !CORBA::is_nil( varMainPOS ) )
        {
            PPT_METHODTRACE_V1("", "!CORBA::is_nil( varMainPOS )");
            try
            {
                varUserDataSeq = varMainPOS->allUserDataSets();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperationSpecification::getUserDataNamed)
        }

        //---------------------------------------------------------------------------
        //   Filter by input User Data Name
        //---------------------------------------------------------------------------
        CORBA::Long lngUserDataLen = varUserDataSeq->length();
        PPT_METHODTRACE_V2("", "lngUserDataLen", lngUserDataLen);
        strUserDataSeq.length(lngNameLen);
        CORBA::Long lngCnt = 0;

        for ( CORBA::Long lngNameCnt = 0; lngNameCnt < lngNameLen; lngNameCnt++ )
        {
            PPT_METHODTRACE_V2("", "lngNameCnt", lngNameCnt);
            for ( CORBA::Long lngUserDataCnt = 0; lngUserDataCnt < lngUserDataLen; lngUserDataCnt++ )
            {
                PPT_METHODTRACE_V2("", "lngUserDataCnt", lngUserDataCnt);
                if ( 0 == CIMFWStrCmp( userDataNameSeq[lngNameCnt], varUserDataSeq[lngUserDataCnt].name ) )
                {
                    PPT_METHODTRACE_V1("", "found");
                    strUserDataSeq[lngCnt].name       = CIMFWStrDup( varUserDataSeq[lngUserDataCnt].name );
                    strUserDataSeq[lngCnt].type       = CIMFWStrDup( varUserDataSeq[lngUserDataCnt].type );
                    strUserDataSeq[lngCnt].value      = CIMFWStrDup( varUserDataSeq[lngUserDataCnt].value );
                    strUserDataSeq[lngCnt].originator = CIMFWStrDup( varUserDataSeq[lngUserDataCnt].originator );
                    lngCnt++;
                    break;
                }
            }
        }
        PPT_METHODTRACE_V2("", "lngCnt", lngCnt);
        strUserDataSeq.length(lngCnt);

        //--------------------
        //   Return to Caller
        //--------------------
        strUserData_GetByOperation_out.strUserDataSeq = strUserDataSeq;

        SET_MSG_RC(strUserData_GetByOperation_out, MSG_OK, RC_OK);
        PPT_METHODTRACE_EXIT( "CS_PPTManager::cs_userData_GetByOperation" );
        return rc;
    }
    CATCH_GLOBAL_EXCEPTIONS( strUserData_GetByOperation_out, cs_userData_GetByOperation, methodName )
}
