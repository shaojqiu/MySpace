#ifndef lint
static char *sccsid =  "@(#) 1.9 superpos/src/spppt/source/posppt/pptmgr/objmethd/reticle_ChangeTransportState.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 20:26:53 [ 7/13/07 20:26:54 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: cs_reticle_ChangeTransportState.cpp
//

#include "cs_pptmgr.hpp"

#include "timstamp.hpp"
#include "duration.hpp"

#include "ppcdr.hh"
#include "ppcdrcp.hh"
#include "pperson.hh"
#include "pmc.hh"
#include "pstmc.hh"
#include "pperson.hh"
#include "pbufrs.hh"
#include "pdrmggl.hh"
#include "mtrllctn.hh"


// Class: PPTManager
//
// Service: reticle_ChangeTransportState()
//
// Change history:
// Date       Defect#    Person         Comments
// ---------- ---------- -------------- -------------------------------------------
// 12-05-01   P4100026   M.Shimizu      Last Claimed Timestamp in Reticle POD List is not changed by EI/EO.
// 02-04-02   D4100110   S.Tokumasu     Add timeStamp into xferStatusChangeRpt
// 2002-02-14 D4100110-1 Y.Iwasaki      Bug fix of D4100110
// 2002-04-04 P4100317   K.Matsuei      There is a place where CIMFWStrDup shouldn't be used.
// 2002-04-05 P4100272   K.Matsuei      Check and fix MemoryLeak every transaction.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2015/01/05 DSN000085770 C.Mo           Durable Control Job Management support.
// 2017/09/15 INN-R170003  Joan Zhou      INN-R170003:Durable Management Enhancement
// Description:
//
//
// Return:
//     Long
//
// Parameter:
//    objReticle_ChangeTransportState_out&   strReticle_ChangeTransportState_out
//    const pptObjCommonIn& strObjCommonIn
//    const objectIdentifier& stockerID
//    const objectIdentifier& equipmentID
//    const pptXferReticleSequence& strXferReticle
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::reticle_ChangeTransportState(objReticle_ChangeTransportState_out&   strReticle_ChangeTransportState_out, const pptObjCommonIn& strObjCommonIn,  const objectIdentifier& stockerID,  const objectIdentifier& equipmentID,  const pptXferReticleSequence& strXferReticle)
{
    char * methodName = NULL;
    CORBA::Long rc = RC_OK;  //DSN000085770

    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::reticle_ChangeTransportState")
        PosMachine_var aMachine;
        PosStorageMachine_var aStorageMachine;
        strReticle_ChangeTransportState_out.stockerID      = stockerID;
        strReticle_ChangeTransportState_out.equipmentID    = equipmentID;
        strReticle_ChangeTransportState_out.strXferReticle = strXferReticle;

        CORBA::Boolean firstEquipment, firstStocker;
        CORBA::Long len, i;
        len = strXferReticle.length();
        PPT_METHODTRACE_V2("", "strXferReticle.length()", len)
        firstEquipment = TRUE;
        firstStocker   = TRUE;
//P4100317        TimeStamp recordTimeStamp; //D4100110
        CORBA::String_var recordTimeStamp; //P4100317

        for ( i=0; i<len; i++)
        {
            PosProcessDurable_var aReticle;
            PPT_CONVERT_RETICLEID_TO_RETICLE_OR(aReticle, strXferReticle[i].reticleID,strReticle_ChangeTransportState_out,reticle_ChangeTransportState) ;

            //D4100110 Start
            /*---------------------------------------*/
            /*   Check Cassette's XferChgTimeStamp   */
            /*---------------------------------------*/
//P4100272            CORBA::String xferStatChgTimeStamp;
            CORBA::String_var xferStatChgTimeStamp;  //P4100272
            try
            {
                xferStatChgTimeStamp = aReticle->getTransferStatusChangedTimeStamp();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getTransferStatusChangedTimeStamp);

//D4100110-1PPT_METHODTRACE_V2("", "transferStatusChangeTimeStamp", strXferReticle[i].transferStatusChangeTimeStamp);
//D4100110-1PPT_METHODTRACE_V2("", "xferStatChgTimeStamp         ", xferStatChgTimeStamp);

            if(CIMFWStrLen(strXferReticle[i].transferStatusChangeTimeStamp) == 0 )
            {
//P4100317                recordTimeStamp = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);
                recordTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;  //P4100317
            }
            else
            {
//P4100317                recordTimeStamp = CIMFWStrDup(strXferReticle[i].transferStatusChangeTimeStamp);
                recordTimeStamp = strXferReticle[i].transferStatusChangeTimeStamp;  //P4100317
            }

            PPT_METHODTRACE_V2("", "recordTimeStamp      ", strXferReticle[i].transferStatusChangeTimeStamp);  //D4100110-1
            PPT_METHODTRACE_V2("", "xferStatChgTimeStamp ", xferStatChgTimeStamp);                             //D4100110-1

//D4100110-1if(recordTimeStamp < xferStatChgTimeStamp)
            if ( CIMFWStrCmp(recordTimeStamp, xferStatChgTimeStamp) < 0 )                                      //D4100110-1
            {
//D4100110-1    PPT_METHODTRACE_V1("", "transferStatusChangeTimeStamp < xferStatChgTimeStamp!");
                PPT_METHODTRACE_V1("", "recordTimeStamp < xferStatChgTimeStamp!");                             //D4100110-1
                PPT_METHODTRACE_V1("", "XferStat is not updated. becouse it is old event!!");
                continue;
            }
            //--- set TimeStamp
            try
            {
                aReticle->setTransferStatusChangedTimeStamp(recordTimeStamp);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setTransferStatusChangeTimeStamp);

            //D4100110 End

            if( CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_EquipmentIn) == 0 )
            {
                PPT_METHODTRACE_V2("", "CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_EquipmentIn) == 0", i)
                try
                {
                    aReticle->makeEquipmentIn() ;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::makeEquipmentIn) ;
                //INN-R170003 Start
                try
                {
                    
                    SI_PPT_USERDATA_SET_STRING(aReticle,CS_M_RTCL_EQUIPMENTIN_TIME,
                                               strObjCommonIn.strTimeStamp.reportTimeStamp);
                    PPT_METHODTRACE_V2("", "set aReticle CS_M_RTCL_EQUIPMENTIN_TIME", strObjCommonIn.strTimeStamp.reportTimeStamp);
                    
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setUserDataNamed);
                //INN-R170003 End
            }
            if( CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_EquipmentOut) == 0 )
            {
                PPT_METHODTRACE_V2("", "CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_EquipmentOut) == 0", i)
//DSN000085770 Add Start
                objDurable_durableControlJobID_Get_out strDurable_durableControlJobID_Get_out;
                objDurable_durableControlJobID_Get_in  strDurable_durableControlJobID_Get_in;
                strDurable_durableControlJobID_Get_in.durableID       = strXferReticle[i].reticleID;
                strDurable_durableControlJobID_Get_in.durableCategory = CIMFWStrDup(SP_DurableCat_Reticle);
                rc = durable_durableControlJobID_Get( strDurable_durableControlJobID_Get_out, 
                                                      strObjCommonIn, 
                                                      strDurable_durableControlJobID_Get_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","durable_durableControlJobID_Get() returned error.");
                    strReticle_ChangeTransportState_out.strResult = strDurable_durableControlJobID_Get_out.strResult;
                    return (rc);
                }

                if ( CIMFWStrLen(strDurable_durableControlJobID_Get_out.durableControlJobID.identifier) > 0 )
                {
                    objDurableControlJob_status_Get_out strDurableControlJob_status_Get_out;
                    objDurableControlJob_status_Get_in  strDurableControlJob_status_Get_in;
                    strDurableControlJob_status_Get_in.durableControlJobID = strDurable_durableControlJobID_Get_out.durableControlJobID;
                    rc = durableControlJob_status_Get( strDurableControlJob_status_Get_out, 
                                                       strObjCommonIn, 
                                                       strDurableControlJob_status_Get_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("","durableControlJob_status_Get() returned error.");
                        strReticle_ChangeTransportState_out.strResult = strDurableControlJob_status_Get_out.strResult;
                        return (rc);
                    }

                    if ( CIMFWStrCmp(strDurableControlJob_status_Get_out.durableControlJobStatus, SP_DurableControlJobStatus_Created) != 0 &&
                         CIMFWStrCmp(strDurableControlJob_status_Get_out.durableControlJobStatus, SP_DurableControlJobStatus_Delete) != 0 )
                    {
                        PPT_METHODTRACE_V1("", "##### return RC_INVALID_DCJSTATUS");
                        PPT_SET_MSG_RC_KEY( strReticle_ChangeTransportState_out, 
                                            MSG_INVALID_DCJSTATUS, 
                                            RC_INVALID_DCJSTATUS, 
                                            strDurableControlJob_status_Get_out.durableControlJobStatus );
// INN-R170003 Add Start
                        try
                        {   
                            CORBA::String_var EquipmentInTimeStamp;
                            SI_PPT_USERDATA_GET_STRING(aReticle,CS_M_RTCL_EQUIPMENTIN_TIME,EquipmentInTimeStamp);
                            PPT_METHODTRACE_V2("", "SI_PPT_USERDATA_GET_STRING CS_M_RTCL_EQUIPMENTIN_TIME", EquipmentInTimeStamp);
                            // evaluate
                            if (EquipmentInTimeStamp != NULL && CIMFWStrLen(EquipmentInTimeStamp) != 0)
                            {
                                PPT_METHODTRACE_V1("", "EquipmentInTimeStamp != NULL && CIMFWStrLen(EquipmentInTimeStamp) != 0");
                                CORBA::Long lDuration = atol(strObjCommonIn.strTimeStamp.reportTimeStamp) - atol(EquipmentInTimeStamp);
                                try
                                {
                                    Duration aDuration(lDuration);
                                    aReticle->setDurationUsed( aDuration );
                                    PPT_METHODTRACE_V2("", "aReticle->setDurationUsed---------------------->", lDuration);                                    
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setDurationUsed) ;
                                try
                                {
                                    SI_PPT_USERDATA_SET_STRING(aReticle,CS_M_RTCL_EQUIPMENTIN_TIME,"");
                                    PPT_METHODTRACE_V1("", "set aReticle->CS_M_RTCL_EQUIPMENTIN_TIME null");                                    
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setUserDataNamed) ;
                            }
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getUserDataNamed);
// INN-R170003 Add End
                        return RC_INVALID_DCJSTATUS;
                    }
                }
//DSN000085770 Add End
                try
                {
                    aReticle->makeEquipmentOut() ;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::makeEquipmentOut)
            }
            if( CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_StationIn) == 0 )
            {
                PPT_METHODTRACE_V2("", "CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_StationIn) == 0", i)
                try
                {
                    aReticle->makeStationIn() ;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::makeStationIn)
            }
            if( CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_StationOut) == 0 )
            {
                PPT_METHODTRACE_V2("", "CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_StationOut) == 0", i)
                try
                {
                    aReticle->makeStationOut() ;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::makeStationOut)
            }
            if( CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_BayIn) == 0 )
            {
                PPT_METHODTRACE_V2("", "CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_BayIn) == 0", i)
                try
                {
                    aReticle->makeBayIn() ;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::makeBayIn)
            }
            if( CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_BayOut) == 0 )
            {
                PPT_METHODTRACE_V2("", "CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_BayOut) == 0", i)
                try
                {
                    aReticle->makeBayOut() ;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::makeBayOut)
            }
            if( CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_ManualIn) == 0 )
            {
                PPT_METHODTRACE_V2("", "CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_ManualIn) == 0", i)
                try
                {
                    aReticle->makeManualIn();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::makeManualIn);
            }
            if( CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_ManualOut) == 0 )
            {
                PPT_METHODTRACE_V2("", "CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_ManualOut) == 0", i)
                try
                {
                    aReticle->makeManualOut();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::makeManualOut);
            }
            if( CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_AbnormalIn) == 0 )
            {
                PPT_METHODTRACE_V2("", "CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_AbnormalIn) == 0", i)
                try
                {
                    aReticle->makeAbnormalIn();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::makeAbnormalIn);
            }
            if( CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_AbnormalOut) == 0 )
            {
                PPT_METHODTRACE_V2("", "CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_AbnormalOut) == 0", i)
                try
                {
                    aReticle->makeAbnormalOut();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::makeAbnormalOut);
            }
            if( CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_ShelfIn) == 0 )
            {
                PPT_METHODTRACE_V2("", "CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_ShelfIn) == 0", i)
                try
                {
                    aReticle->makeShelfIn();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::makeShelfIn);
            }
            if( CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_ShelfOut) == 0 )
            {
                PPT_METHODTRACE_V2("", "CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_ShelfOut) == 0", i)
                try
                {
                    aReticle->makeShelfOut();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::makeShelfOut);
            }
            if( CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_IntermediateIn) == 0 )
            {
                PPT_METHODTRACE_V2("", "CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_IntermediateIn) == 0", i)
                try
                {
                    aReticle->makeIntermediateIn();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::makeIntermediateIn);
            }
            if( CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_IntermediateOut) == 0 )
            {
                PPT_METHODTRACE_V2("", "CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_IntermediateOut) == 0", i)
                try
                {
                    aReticle->makeIntermediateOut();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::makeIntermediateOut);
            }
            if( CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_EquipmentIn)  == 0  ||
                CIMFWStrCmp(strXferReticle[i].transferStatus, SP_TransState_EquipmentOut) == 0 )
            {
                PPT_METHODTRACE_V2("", "CIMFWStrCmp(transferStatus, SP_TransState_EquipmentIn)  == 0  || CIMFWStrCmp(transferStatus, SP_TransState_EquipmentOut) == 0 )", i)
                if (firstEquipment)
                {
                    PPT_METHODTRACE_V3("", "CIMFWStrCmp(transferStatus, SP_TransState_EquipmentIn)  == 0  || CIMFWStrCmp(transferStatus, SP_TransState_EquipmentOut) == 0 )", "firstEquipment", i)
                    PPT_CONVERT_EQPID_TO_MACHINE_OR(aMachine, equipmentID, strReticle_ChangeTransportState_out,reticle_ChangeTransportState);
                    firstEquipment = FALSE; // Use aMachine for further equipmentID
                }
                try
                {
                    aReticle->assign_toMachine(aMachine);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::assign_toMachine);
            }
            else
            {
                PPT_METHODTRACE_V2("", "else of CIMFWStrCmp(transferStatus, SP_TransState_EquipmentIn)  == 0  || CIMFWStrCmp(transferStatus, SP_TransState_EquipmentOut) == 0 )", i)
                if (firstStocker)
                {
                    PPT_METHODTRACE_V3("", "else of CIMFWStrCmp(transferStatus, SP_TransState_EquipmentIn)  == 0  || CIMFWStrCmp(transferStatus, SP_TransState_EquipmentOut) == 0 )", "firstStocker", i)
                    PPT_CONVERT_STOCKERID_TO_STORAGEMACHINE_OR(aStorageMachine, stockerID, strReticle_ChangeTransportState_out,reticle_ChangeTransportState);
                    firstStocker = FALSE; // Use aStorageMachine for further stockerID
                }
                try
                {
                    aReticle->assign_toMachine(aStorageMachine);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::assign_toMachine);
            }

//P4100026 Add Start
            try
            {
                PPT_DISPLAY_RESPONSE_TIME();
                aReticle->setLastClaimedTimeStamp( strObjCommonIn.strTimeStamp.reportTimeStamp );
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setLastClaimedTimeStamp)

            PosPerson_var aPerson;

            PPT_GET_PERSON_FROM_USERID(aPerson,strObjCommonIn.strUser.userID,strReticle_ChangeTransportState_out,reticle_ChangeTransportState)
            try
            {
                PPT_DISPLAY_RESPONSE_TIME();
                aReticle->setLastClaimedPerson( aPerson );
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setLastClaimedPerson)
//P4100026 Add End

        }

        PPT_METHODTRACE_EXIT("PPTManager_i::reticle_ChangeTransportState")
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strReticle_ChangeTransportState_out, reticle_ChangeTransportState, methodName)
}
