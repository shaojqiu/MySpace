//
// (c) Copyright: IBM Taiwan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_APC_LotEventQueue_Make.dr
//
// Class: CS_PPTManager
//
// [Object Function Name]: long   cs_APC_LotEventQueue_Make
//
// Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/17 INN-R170009  Qufd           Add APC Squeue
//
// Function Description:
//
// Input Parameters:
//
// Output Parameters:
//
// Return Value:
//
// Exception:
//
// Pseudo code:
//

#include "cs_pptmgr.hpp"

CORBA::Long CS_PPTManager_i::cs_APC_LotEventQueue_Make(
    csObjAPC_LotEventQueue_Make_out&        strObjAPC_LotEventQueue_Make_out,
    const pptObjCommonIn&                   strObjCommonIn,
    const csObjAPC_LotEventQueue_Make_in&   strObjAPC_LotEventQueue_Make_in
)
{
    char * methodName = NULL;

    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_APC_LotEventQueue_Make");
        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;
        CORBA::Long lCastLen = strObjAPC_LotEventQueue_Make_in.strStartCassette.length();
 
        //Default set wafer count as SP_Lot_MaximumWafersInALot(25)
        CORBA::Long csAPClen = lCastLen*SP_Lot_MaximumWafersInALot;

        csObjAPC_EventQueue_AddDR_out       strObjAPC_EventQueue_AddDR_out;
        csObjAPC_EventQueue_AddDR_in        strObjAPC_EventQueue_AddDR_in;

        strObjAPC_EventQueue_AddDR_in.strAPCEventQueueSeq.length(csAPClen);

        CORBA::Long k = 0 ;

        PPT_METHODTRACE_V2("", "in para equipmentID    ",strObjAPC_LotEventQueue_Make_in.equipmentID.identifier );

        for (  CORBA::Long i = 0; i < lCastLen; i++ )
        {
            PPT_METHODTRACE_V2("", "for (  CORBA::Long i = 0; i < lCastLen; i++ )",i );

            csObjAPC_LithoAvailable_CheckCondition_out   strAPC_LithoAvailable_CheckCondition_out;
            csObjAPC_LithoAvailable_CheckCondition_in   strAPC_LithoAvailable_CheckCondition_in;
            CORBA::Long lLotLen = strObjAPC_LotEventQueue_Make_in.strStartCassette[i].strLotInCassette.length();
             
            for (  CORBA::Long j = 0; j < lLotLen; j++ )
            {
                PPT_METHODTRACE_V2("", "for (  CORBA::Long j = 0; j < lLotLen; j++ )",j );

                strAPC_LithoAvailable_CheckCondition_in.equipmentID = strObjAPC_LotEventQueue_Make_in.equipmentID;
                strAPC_LithoAvailable_CheckCondition_in.routeID = strObjAPC_LotEventQueue_Make_in.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID;
                strAPC_LithoAvailable_CheckCondition_in.operationNumber = strObjAPC_LotEventQueue_Make_in.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber;

                PPT_METHODTRACE_V2("", "in para routeID         ",strAPC_LithoAvailable_CheckCondition_in.routeID.identifier );
                PPT_METHODTRACE_V2("", "in para operationNumber ",strAPC_LithoAvailable_CheckCondition_in.operationNumber );

                rc = cs_APC_LithoAvailable_CheckCondition( strAPC_LithoAvailable_CheckCondition_out,
                                                           strObjCommonIn,
                                                           strAPC_LithoAvailable_CheckCondition_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "cs_APC_LithoAvailable_CheckCondition() != RC_OK", rc);
                    strObjAPC_LotEventQueue_Make_out.strResult = strAPC_LithoAvailable_CheckCondition_out.strResult;
                    return( rc );
                }


                if ( strAPC_LithoAvailable_CheckCondition_out.usedFlag == TRUE )
                {
                    PPT_METHODTRACE_V1("", "strAPC_LithoAvailable_CheckCondition_out.usedFlag == TRUE");

                    strObjAPC_EventQueue_AddDR_in.strAPCEventQueueSeq[k].eventID = CIMFWStrDup ( CS_APC_EVENT_USED );
                    strObjAPC_EventQueue_AddDR_in.strAPCEventQueueSeq[k].lotID =  strObjAPC_LotEventQueue_Make_in.strStartCassette[i].strLotInCassette[j].lotID;
                    strObjAPC_EventQueue_AddDR_in.strAPCEventQueueSeq[k].controlJobID =  strObjAPC_LotEventQueue_Make_in.controlJobID;
                    strObjAPC_EventQueue_AddDR_in.strAPCEventQueueSeq[k].eventTime = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    k++;
                }

                if ( strAPC_LithoAvailable_CheckCondition_out.metrologyFlag == TRUE )
                {
                    PPT_METHODTRACE_V1("", "strAPC_LithoAvailable_CheckCondition_out.metrologyFlag == TRUE");

                    strObjAPC_EventQueue_AddDR_in.strAPCEventQueueSeq[k].eventID = CIMFWStrDup (CS_APC_EVENT_METROLOGY);
                    strObjAPC_EventQueue_AddDR_in.strAPCEventQueueSeq[k].lotID =  strObjAPC_LotEventQueue_Make_in.strStartCassette[i].strLotInCassette[j].lotID;
                    strObjAPC_EventQueue_AddDR_in.strAPCEventQueueSeq[k].controlJobID =  strObjAPC_LotEventQueue_Make_in.controlJobID;
                    strObjAPC_EventQueue_AddDR_in.strAPCEventQueueSeq[k].eventTime = strObjCommonIn.strTimeStamp.reportTimeStamp;
                    k++;
                }

                if ( k >= csAPClen )
                {
                    PPT_METHODTRACE_V2("", "strObjAPC_EventQueue_AddDR_in.strAPCEventQueueSeq.length != RC_OK", k);
                    strObjAPC_LotEventQueue_Make_out.strResult = strAPC_LithoAvailable_CheckCondition_out.strResult;
                    return 100;
                }
            }
        }

        strObjAPC_EventQueue_AddDR_in.strAPCEventQueueSeq.length(k);

        rc = cs_APC_EventQueue_AddDR( strObjAPC_EventQueue_AddDR_out,
                                      strObjCommonIn,
                                      strObjAPC_EventQueue_AddDR_in);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "cs_APC_EventQueue_AddDR() != RC_OK", rc);
            strObjAPC_LotEventQueue_Make_out.strResult = strObjAPC_EventQueue_AddDR_out.strResult;
            return( rc );
        }

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_APC_LotEventQueue_Make");
        SET_MSG_RC(strObjAPC_LotEventQueue_Make_out,MSG_OK,RC_OK)

        return ( RC_OK );
    }

    CATCH_GLOBAL_EXCEPTIONS(strObjAPC_LotEventQueue_Make_out, cs_APC_LotEventQueue_Make, methodName);
}
