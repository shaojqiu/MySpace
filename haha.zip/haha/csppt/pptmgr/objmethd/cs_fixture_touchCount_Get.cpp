//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_fixture_touchCount_Get.cpp
//


#include "cs_pptmgr.hpp"
#include "ppcdr.hh"

// Class: CS_PPTManager
//
// Service: cs_fixture_touchCount_Get()
//
// Innotron Modification history :
// Date       Defect#       Person               Comments
// ---------- ------------- -------------------- -------------------------------------------
// 2017/09/28 INN-R170006   Sam Hsueh            Initial, get touch count
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    csObjFixture_touchCount_Get_out&       strFixture_touchCount_Get_out,
//    pptObjCommonIn&                        strObjCommonIn,
//    csObjFixture_touchCount_Get_in&         strFixture_touchCount_Get_in
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_fixture_touchCount_Get(
    csObjFixture_touchCount_Get_out&         strFixture_touchCount_Get_out,
    const pptObjCommonIn&                    strObjCommonIn,
    const csObjFixture_touchCount_Get_in&    strFixture_touchCount_Get_in) 
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_fixture_touchCount_Get");

        PosProcessDurable_var aFixture;
        PPT_CONVERT_FIXTUREID_TO_FIXTURE_OR( aFixture, 
                                             strFixture_touchCount_Get_in.fixtureID,
                                             strFixture_touchCount_Get_out,
                                             cs_fixture_touchCount_Get );
                                            
        CORBA::Long lngCurrentTouchCount = 0;
        CORBA::Long lngAccumulatedTouchCount = 0;
        
        try
        {
             lngCurrentTouchCount = aFixture->getCurrentTouchCount();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getCurrentTouchCount);
        
        try
        {
             SI_PPT_USERDATA_GET_INTEGER( aFixture,
                                          CS_M_Fixture_CumulativeTouchCount,
                                          lngAccumulatedTouchCount);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getUserDataNamed);   

        //Set return structure
        strFixture_touchCount_Get_out.strFixtureTouchCountInfo.touchCount      = lngCurrentTouchCount ;
        strFixture_touchCount_Get_out.strFixtureTouchCountInfo.accumTouchCount = lngAccumulatedTouchCount ;

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_fixture_touchCount_Get");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strFixture_touchCount_Get_out, cs_fixture_touchCount_Get, methodName);
}
