#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_transferState_Change.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:36:24 [ 7/13/07 19:36:25 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_cassette_transferState_ChangeOR.cpp
//

#include "cs_pptmgr.hpp"
#include "pstmc.hh"
#include "pcas.hh"
#include "pperson.hh" //D4100306

//[Object Function Name]: long   cassette_transferState_Change
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2000-08-16  0.00      Y.Iwasaki      Initial Release
// 2000-08-23  0.01      Y.Iwasaki      If condition change
// 2000-10-12  Q3000294  Y.Iwasaki      Add check logic for EI to any case
// 2002-02-04  D4100110  S.Tokumasu     Add TimeStamp into xferStatusChangeRpt
// 2002-02-14  D4100110-1 Y.Iwasaki     Bug fix of D4100110
// 2002-04-04  D4100314  Y.Iwasaki      Except timestamp compare logic when EI/EO
// 2002-04-04  P4100317  K.Matsuei      There is a place where CIMFWStrDup shouldn't be used.
// 2002-06-19  D4100306  K.Kimura       LastClaimTimestamp of Carrier is not updated by Stock-in or Stock-out.
//
// Innotron Modification history:
// Date       DCR/PCR No   Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/15 INN-R170003  Jun Zhang      New Transfer State PI/PO.
//
//
//[Function Description]:
//  Change specified cassette's transfer status by using input parameter.
//  If reported cassette contains lot, and this lot's processState is Processing,
//  the following cases should not be allowd.
//  - MI / SI / II / BI / BO
//
//
//[Input Parameters]:
//  in  pptObjCommonIn        strObjCommonIn;
//  in  objectIdentifier      stockerID;
//  in  objectIdentifier      equipmentID;
//  in  objectIdentifier      cassetteID;
//  in  pptXferCassette       strXferCassette;
//
//  typedef struct pptXferCassette_struct {
//     objectIdentifier cassetteID;
//     string           xPosition;
//     string           yPosition;
//     string           zPosition;
//     objectIdentifier portID;
//     string           transferStatus;
//  } pptXferCassette;
//
//[Output Parameters]:
//  out objCassette_transferState_Change_out   strCassette_transferState_Change_out;
//
//  typedef struct objCassette_transferState_Change_out_struct {
//      pptRetCode            strResult;
//  } objCassette_transferState_Change_out;
//
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------

//D4100110 CORBA::Long PPTManager_i::cassette_transferState_Change(
//D4100110                             objCassette_transferState_Change_out& strCassette_transferState_Change_out,
//D4100110                             const  pptObjCommonIn& strObjCommonIn,
//D4100110                             const  objectIdentifier& stockerID,
//D4100110                             const  objectIdentifier& equipmentID,
//D4100110                             const  objectIdentifier& cassetteID,
//D4100110                             const  pptXferCassette& strXferCassette)

CORBA::Long CS_PPTManager_i::cassette_transferState_Change(
                            objCassette_transferState_Change_out& strCassette_transferState_Change_out,
                            const  pptObjCommonIn& strObjCommonIn,
                            const  objectIdentifier& stockerID,
                            const  objectIdentifier& equipmentID,
                            const  objectIdentifier& cassetteID,
                            const  pptXferCassette& strXferCassette,
                            const  char*            transferStatusChangeTimeStamp)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cassette_transferState_Change");
        PPT_METHODTRACE_V2( "","in-parm's stockerID", stockerID.identifier);
        PPT_METHODTRACE_V2( "","in-parm's equipmentID", equipmentID.identifier);
        PPT_METHODTRACE_V2( "","in-parm's cassetteID", cassetteID.identifier);
        PPT_METHODTRACE_V2( "","in-parm's strXferCassette", "pptXferCassette");
        PPT_METHODTRACE_V2("", "in-parm's strXferCassette.transferStatus", strXferCassette.transferStatus); //INN-R170003

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        /*------------------------*/
        /*   Get Machine Object   */
        /*------------------------*/
        PosMachine_var aMachine;
        if (CIMFWStrLen(equipmentID.identifier) != 0)
        {
            PPT_METHODTRACE_V1("", "CIMFWStrLen(equipmentID,identifier) != 0");
            PPT_CONVERT_EQPID_TO_MACHINE_OR(aMachine,equipmentID,strCassette_transferState_Change_out,cassette_transferState_Change);
        }

        /*------------------------*/
        /*   Get Stocker Object   */
        /*------------------------*/
        PosStorageMachine_var aStocker;
        if (CIMFWStrLen(stockerID.identifier) != 0)
        {
            PPT_METHODTRACE_V1("", "CIMFWStrLen(stockerID.identifier) != 0");
            PPT_CONVERT_STOCKERID_TO_STORAGEMACHINE_OR(aStocker,stockerID,strCassette_transferState_Change_out,cassette_transferState_Change)
        }

        /*-------------------------*/
        /*   Get Cassette Object   */
        /*-------------------------*/
        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR(aCassette,cassetteID,strCassette_transferState_Change_out,cassette_transferState_Change);

        /*------------------------------------*/
        /*   Check In-Parm's Validity Check   */
        /*------------------------------------*/
        CORBA::String_var transferStatus;
        transferStatus = strXferCassette.transferStatus;
        if (CIMFWStrCmp(transferStatus,SP_TransState_EquipmentIn) == 0 ||
            CIMFWStrCmp(transferStatus,SP_TransState_EquipmentOut) == 0 ||
            CIMFWStrCmp(transferStatus,CS_TRANS_STATE_PORT_IN) == 0 || //INN-R170003
            CIMFWStrCmp(transferStatus,CS_TRANS_STATE_PORT_OUT) == 0)  //INN-R170003
        {
            PPT_METHODTRACE_V1("", "transferStatus == (SP_TransState_EquipmentIn,SP_TransState_EquipmentOut,CS_TRANS_STATE_PORT_IN,CS_TRANS_STATE_PORT_OUT)");
            if (CORBA::is_nil(aMachine) == TRUE)
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil(aMachine) == TRUE");
                SET_MSG_RC(strCassette_transferState_Change_out,MSG_INVALID_DATA_COMBINATION,RC_INVALID_DATA_COMBINATION);
                return(RC_INVALID_DATA_COMBINATION);
            }
        }
        else
        {
            PPT_METHODTRACE_V1("", "transferStatus != (SP_TransState_EquipmentIn,SP_TransState_EquipmentOut,CS_TRANS_STATE_PORT_IN,CS_TRANS_STATE_PORT_OUT)");
            if (CORBA::is_nil(aStocker) == TRUE)
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil(aStocker) == TRUE");
                SET_MSG_RC(strCassette_transferState_Change_out,MSG_INVALID_DATA_COMBINATION,RC_INVALID_DATA_COMBINATION);
                return(RC_INVALID_DATA_COMBINATION);
            }
        }

        if (CIMFWStrCmp(transferStatus,SP_TransState_StationIn) == 0 ||
            CIMFWStrCmp(transferStatus,SP_TransState_StationOut) == 0 ||
            CIMFWStrCmp(transferStatus,SP_TransState_BayIn) == 0 ||
            CIMFWStrCmp(transferStatus,SP_TransState_BayOut) == 0 ||
            CIMFWStrCmp(transferStatus,SP_TransState_ManualIn) == 0 ||
            CIMFWStrCmp(transferStatus,SP_TransState_ManualOut) == 0 ||
            CIMFWStrCmp(transferStatus,SP_TransState_EquipmentIn) == 0 ||
            CIMFWStrCmp(transferStatus,SP_TransState_EquipmentOut) == 0 ||
            CIMFWStrCmp(transferStatus,CS_TRANS_STATE_PORT_IN) == 0 ||  //INN-R170003
            CIMFWStrCmp(transferStatus,CS_TRANS_STATE_PORT_OUT) == 0 || //INN-R170003
            CIMFWStrCmp(transferStatus,SP_TransState_ShelfIn) == 0 ||
            CIMFWStrCmp(transferStatus,SP_TransState_ShelfOut) == 0 ||
            CIMFWStrCmp(transferStatus,SP_TransState_IntermediateIn) == 0 ||
            CIMFWStrCmp(transferStatus,SP_TransState_IntermediateOut) == 0 ||
            CIMFWStrCmp(transferStatus,SP_TransState_AbnormalIn) == 0 ||
            CIMFWStrCmp(transferStatus,SP_TransState_AbnormalOut) == 0)
        {
            PPT_METHODTRACE_V1("", "transferStatus == SI, SO, BI, BO, MI, MO, EI, EO, PI, PO, HI, HO, II, IO, AI, AO");
            rc = RC_OK;
        }
        else
        {
            PPT_METHODTRACE_V1("", "transferStatus != SI, SO, BI, BO, MI, MO, EI, EO, PI, PO, HI, HO, II, IO, AI, AO");
            SET_MSG_RC(strCassette_transferState_Change_out,MSG_INVALID_DATA_COMBINATION,RC_INVALID_DATA_COMBINATION);
            return(RC_INVALID_DATA_COMBINATION);
        }

        //Q3000294 add start
        /*-----------------------------------*/
        /*   Check Transition from EI case   */
        /*-----------------------------------*/
        CORBA::String_var curState;
        try
        {
           curState = aCassette->getTransportState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTransportState);

        PPT_METHODTRACE_V2("", "transferStatus", transferStatus); //INN-R170003

        if ( CIMFWStrCmp(curState, SP_TransState_EquipmentIn) == 0 )
        {
//INN-R170003 Temp solution for test, before integration test, please rollback it
//INN-R170003   if ( CIMFWStrCmp(transferStatus, SP_TransState_EquipmentOut) == 0 )
            if ( CIMFWStrCmp(transferStatus, SP_TransState_EquipmentOut) == 0 ||  //INN-R170003
                 CIMFWStrCmp(transferStatus, CS_TRANS_STATE_PORT_OUT) == 0 )      //INN-R170003
            {
                rc = RC_OK;
            }
            else
            {
                PPT_SET_MSG_RC_KEY2(strCassette_transferState_Change_out,
                                    MSG_INVALID_CAST_XFERSTAT,
                                    RC_INVALID_CAST_XFERSTAT,
                                    curState,
                                    cassetteID.identifier);
                return( RC_INVALID_CAST_XFERSTAT );
            }
        }
        //Q3000294 add end
        //INN-R170003 add start
        /*-----------------------------------*/
        /*   Check Transition from EO case   */
        /*-----------------------------------*/
        else if ( CIMFWStrCmp(curState, SP_TransState_EquipmentOut) == 0 )
        {
            if ( CIMFWStrCmp(transferStatus, CS_TRANS_STATE_PORT_OUT) != 0 )
            {
                PPT_SET_MSG_RC_KEY2(strCassette_transferState_Change_out,
                                    MSG_INVALID_CAST_XFERSTAT,
                                    RC_INVALID_CAST_XFERSTAT,
                                    curState,
                                    cassetteID.identifier);
                return( RC_INVALID_CAST_XFERSTAT );
            }
        }
        //INN-R170003 add end

        //D4100110 Start
        /*---------------------------------------*/
        /*   Check Cassette's XferChgTimeStamp   */
        /*---------------------------------------*/
        CORBA::String_var xferStatChgTimeStamp;
        try
        {
            xferStatChgTimeStamp = aCassette->getTransferStatusChangedTimeStamp();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTransferStatusChangedTimeStamp);

        PPT_METHODTRACE_V2("", "transferStatusChangeTimeStamp", transferStatusChangeTimeStamp);
        PPT_METHODTRACE_V2("", "xferStatChgTimeStamp         ", xferStatChgTimeStamp);

//D4100110-1 if(transferStatusChangeTimeStamp < xferStatChgTimeStamp)

        //----------------------------------------                           //P4100314
        //   If EI/EO case, change Forcely.                                  //P4100314
        //   Otherwise, must compare timestama                               //P4100314
        //----------------------------------------                           //P4100314
        if ( 0 != CIMFWStrCmp(transferStatus, SP_TransState_EquipmentIn) &&  //P4100314
             0 != CIMFWStrCmp(transferStatus, SP_TransState_EquipmentOut) && //P4100314
             0 != CIMFWStrCmp(transferStatus, CS_TRANS_STATE_PORT_OUT))      //INN-R170003
        {                                                                    //P4100314
            if( CIMFWStrCmp(transferStatusChangeTimeStamp, xferStatChgTimeStamp) < 0 ) //D4100110-1
            {
                PPT_METHODTRACE_V1("", "transferStatusChangeTimeStamp < xferStatChgTimeStamp!");
                PPT_METHODTRACE_V1("", "XferStat is not updated. becouse it is old event!!");
                return( RC_OK );
            }
        }                                                                    //P4100314

        //--- set TimeStamp
//P4100317        TimeStamp recordTimeStamp;
//P4100317        recordTimeStamp = CIMFWStrDup(transferStatusChangeTimeStamp);
        try
        {
//P4100317            aCassette->setTransferStatusChangedTimeStamp(recordTimeStamp);
            aCassette->setTransferStatusChangedTimeStamp(transferStatusChangeTimeStamp);  //P4100317
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setTransferStatusChangeTimeStamp);

        //D4100110 End

        /*---------------------------------------*/
        /*   Update Cassette's Transfer Status   */
        /*---------------------------------------*/
        try
        {
            aCassette->setTransportState(transferStatus);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setTransportState);

        /*---------------------------*/
        /*   Set AssignedToMachine   */
        /*---------------------------*/
        if (CIMFWStrCmp(transferStatus,SP_TransState_EquipmentIn) == 0 ||
            CIMFWStrCmp(transferStatus,SP_TransState_EquipmentOut) == 0 ||
            CIMFWStrCmp(transferStatus,CS_TRANS_STATE_PORT_IN) == 0 || //INN-R170003
            CIMFWStrCmp(transferStatus,CS_TRANS_STATE_PORT_OUT) == 0)  //INN-R170003
        {
            PPT_METHODTRACE_V1("", "transferStatus == (SP_TransState_EquipmentIn,SP_TransState_EquipmentOut,CS_TRANS_STATE_PORT_IN,CS_TRANS_STATE_PORT_OUT");
            try
            {
                aCassette->assign_toMachine(aMachine);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::assign_toMachine);
        }
        else
        {
            PPT_METHODTRACE_V1("", "transferStatus != (SP_TransState_EquipmentIn,SP_TransState_EquipmentOut,CS_TRANS_STATE_PORT_IN,CS_TRANS_STATE_PORT_OUT");
            try
            {
                aCassette->assign_toMachine(aStocker);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::assign_toMachine);
        }

        //D4100306 Add Start
        /*--------------------------*/
        /*  Set Claimed Time Stamp  */
        /*--------------------------*/
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aCassette->setLastClaimedTimeStamp( strObjCommonIn.strTimeStamp.reportTimeStamp );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setLastClaimedTimeStamp);

        PosPerson_var aPerson;
        PPT_GET_PERSON_FROM_USERID( aPerson, strObjCommonIn.strUser.userID, strCassette_transferState_Change_out, cassette_transferState_Change);
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aCassette->setLastClaimedPerson( aPerson );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::setLastClaimedPerson);
        //D4100306 Add End

        /*----------------------*/
        /*   Return to Caller   */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cassette_transferState_Change");
        return( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_transferState_Change_out, cassette_transferState_Change, methodName);
}
