#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/equipment_recipeBodyManageFlag_Get.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:49:19 [ 7/13/07 19:49:21 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_equipment_recipeBodyManageFlag_GetOR.cpp
//

//INN-A170001 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp" //INN-A170001 

#include "mtrllctn.hh"
#include "parea.hh"
#include "pbank.hh"
#include "pbufrs.hh"
#include "pcas.hh"
#include "pdcdf.hh"
//D6000044 #include "pdorv.hh"
#include "pdp.hh"
#include "pdpgl.hh"
#include "pe10st.hh"             //DCR 9900001
#include "pevalrm.hh"
#include "pevbase.hh"
#include "pevcmbs.hh"
#include "peveqps.hh"
#include "pevmg.hh"
#include "pevmggl.hh"
#include "pflwbch.hh"
#include "pflwdp.hh"
#include "plcrc.hh"
#include "plot.hh"
//PTR2300043 #include "pltopnt.hh"            //(DCR9900205) (R20b)
#include "pmc.hh"
#include "pmcmggl.hh"
#include "pmcnote.hh"
#include "pmcrc.hh"
#include "pmstat.hh"             //DCR 9900001
#include "ppcdf.hh"
#include "ppcdr.hh"
#include "ppcdrcp.hh"
#include "ppcflw.hh"
#include "ppcflwx.hh"
//D5000016 #include "ppcgrp.hh"
//D5000016 #include "ppcj.hh"
//D5000016 #include "ppcjmg.hh"
#include "ppcope.hh"
#include "ppcopsp.hh"
#include "ppcrs.hh"
#include "pperson.hh"
#include "pportrs.hh"
#include "pprmggl.hh"
#include "pprsp.hh"
#include "prcssctv.hh"
#include "prmsts.hh"             //DCR 9900001
#include "pstmc.hh"
#include "ptesttp.hh"
//D5000016 #include "ptrrs.hh"

#define SP_EqpStateConvertType_ByStartLot           "STLT"      //DCR 9900001
#define SP_EqpStateConvertType_ByStartSubLot        "STSL"      //DCR 9900001
#define SP_EqpStateConvertType_ByStartRoute         "STRT"      //DCR 9900001
#define SP_EqpStateConvertType_ByInProcessLot       "IPLT"      //DCR 9900001
#define SP_EqpStateConvertType_ByInProcessSubLot    "IPSL"      //DCR 9900001
#define SP_EqpStateConvertType_ByInProcessRoute     "IPRT"      //DCR 9900001

//[Object Function Name]: long   equipment_recipeBodyManageFlag_Get
//
// Date       Level    Author         Note
// ---------- -----    -------------  -------------------------------------------
// 1999-11-16 0.00     Y.Iwasaki      Initial Release (DCR2200008) (R22)
// 2000/09/12 P3000139 T.Yamano       SET_MSG_RC(MSG_OK,RC_OK) Comment Out
// 2003/05/20 D5000016 K.Kido         Useless class deletion(R5.0).
// 2004/11/10 D6000044 F.Masada       Remove Document Component.
//
// Change history:
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
//
//[Function Description]:
//  Get recipeBodyManageFlag of equipment, and set to out parameter.
//
//[Input Parameters]:
//  in  pptObjCommonIn        strObjCommonIn;
//  in  objectIdentifier      equipmentID;
//
//[Output Parameters]:
//  out objEquipment_recipeBodyManageFlag_Get_out   strEquipment_recipeBodyManageFlag_Get_out;
//
//  typedef struct objEquipment_recipeBodyManageFlag_Get_out_struct {
//      pptRetCode            strResult;
//      boolean               recipeBodyManageFlag;
//  } objEquipment_recipeBodyManageFlag_Get_out;
//
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//  RC_NOT_FOUND_EQP          MSG_NOT_FOUND_EQP
//  RC_SYSTEM_ERROR           MSG_SYSTEM_ERROR
//
//
CORBA::Long CS_PPTManager_i::equipment_recipeBodyManageFlag_Get(
                          objEquipment_recipeBodyManageFlag_Get_out&   strEquipment_recipeBodyManageFlag_Get_out,
                          const pptObjCommonIn&                        strObjCommonIn,
                          const objectIdentifier&                      equipmentID )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY( "CS_PPTManager_i::equipment_recipeBodyManageFlag_Get" );

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
//P3000139        SET_MSG_RC( strEquipment_recipeBodyManageFlag_Get_out, MSG_OK, RC_OK );

        /*--------------------------*/
        /*   Get Equipment Object   */
        /*--------------------------*/
        PosMachine_var aMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine,
                                         equipmentID,
                                         strEquipment_recipeBodyManageFlag_Get_out,
                                         equipment_recipeBodyManageFlag_Get );

//INN-A170001        /*-----------------------------------------*/
//INN-A170001        /*   Get Special Equipment Control Value   */
//INN-A170001        /*-----------------------------------------*/
//INN-A170001        try
//INN-A170001        {
//INN-A170001            strEquipment_recipeBodyManageFlag_Get_out.recipeBodyManageFlag = aMachine->isRecipeBodyManageFlagOn();
//INN-A170001        }
//INN-A170001        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::isRecipeBodyManageFlagOn);

        //INN-A170001 Add Start
        /*-------------------------------------------*/
        /*    Get equipment's RMS RecipeBody flag    */
        /*-------------------------------------------*/
        PPT_METHODTRACE_V1("", "DEBUG_Get equipment's RMS RecipeBody flag");
        CORBA::String_var varEqpRMSBodyFlag;
        try
        {
            varEqpRMSBodyFlag = aMachine->getUserDataNamed( CS_M_RMS_BODY_FLAG );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getUserDataNamed)
        
        PPT_METHODTRACE_V2("", "CS_M_RMS_BODY_FLAG = ", varEqpRMSBodyFlag);
        if( 0 == CIMFWStrCmp( varEqpRMSBodyFlag , "1" ) )
        {
            strEquipment_recipeBodyManageFlag_Get_out.recipeBodyManageFlag = TRUE;
        }            
        else
        {
            strEquipment_recipeBodyManageFlag_Get_out.recipeBodyManageFlag = FALSE;
        }
        //INN-A170001 Add End

        PPT_METHODTRACE_EXIT( "CS_PPTManager_i::equipment_recipeBodyManageFlag_Get" );
        return( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS( strEquipment_recipeBodyManageFlag_Get_out, equipment_recipeBodyManageFlag_Get, methodName );
}
