//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_cassette_InspectionTime_Reset.cpp
//


#include "cs_pptmgr.hpp"
#include "timstamp.hpp"
#include "duration.hpp"

#include "pcas.hh"
#include "plot.hh"
#include "pperson.hh"
#include "pstmc.hh"
#include "pmc.hh"
#include "pbufrs.hh"
#include "pmaloc.hh"

// Class: CS_PPTManager
//
// Service: cs_cassette_InspectionTime_Reset()
//
// Change history:
// Date       Defect#       Person        Comments
// ---------- --------      ------------- -------------------------------------------
// 2017/08/31 INN-R170003   Helios Zhen   Durable Management Enhancement
//
// Description:
//
// Return:
//     long
//
// Parameter:
//
//    csObjCassette_InspectionTime_Reset_out& strCassette_InspectionTime_Reset_out,
//    const pptObjCommonIn&                   strObjCommonIn,
//    const objectIdentifier&                 cassetteID,
//    const char*                             claimMemo
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long CS_PPTManager_i::cs_cassette_InspectionTime_Reset(
    csObjCassette_InspectionTime_Reset_out& strCassette_InspectionTime_Reset_out,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&                 cassetteID,
    const char*                             claimMemo) 

{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_cassette_InspectionTime_Reset");

        //PosCassette_var aCassette;
        //PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR(aCassette, cassetteID, strCassette_InspectionTime_Reset_out,
        //                                    cs_cassette_InspectionTime_Reset);

        //CORBA::String_var varCassetteObjRef;

        //varCassetteObjRef = SP_OBJECT_TO_STRING( aCassette );
 
        //strUserDataSeq.length(1);
        //strUserDataSeq[0].name       = CIMFWStrDup( CS_M_CAST_LAST_INSPECTION_TIME );
        //strUserDataSeq[0].type       = CIMFWStrDup( CS_UDATA_TYPE_STRING );
        //strUserDataSeq[0].value      = CIMFWStrDup( strObjCommonIn.strTimeStamp.reportTimeStamp );
        //strUserDataSeq[0].originator = CIMFWStrDup( SP_USERDATA_ORIG_MM );
 
        //objObject_UserData_Set_out strObject_UserData_Set_out;
        
        //PPT_METHODTRACE_V1("", "call object_userData_Set");
        //rc = object_userData_Set( strObject_UserData_Set_out,
        //                          strObjCommonIn,
        //                          strUserDataSeq[lngUDataCnt],
        //                          varLotObjRef );
        
        //if ( rc != RC_OK )
        //{
        //    PPT_METHODTRACE_V1( "", "object_userData_Set() rc != RC_OK" );
        //    strCassette_InspectionTime_Reset_out.strResult = strObject_UserData_Set_out.strResult;
        //    return rc;
        //}

        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR(aCassette,
                                              cassetteID,
                                              strCassette_InspectionTime_Reset_out,
                                              cs_cassette_InspectionTime_Reset);

        try
        {
            SI_PPT_USERDATA_SET_STRING(aCassette,
                                       CS_M_CAST_LAST_INSPECTION_TIME,
                                       strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setUserDataNamed);   

        try
        {
            aCassette->setLastMaintenanceTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setLastMaintenanceTimeStamp);

        PosPerson_var aPerson;
        PPT_GET_PERSON_FROM_USERID(aPerson, strObjCommonIn.strUser.userID, strCassette_InspectionTime_Reset_out,cs_cassette_InspectionTime_Reset)

        try
        {
            aCassette->setLastMaintenancePerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setLastMaintenancePerson);

        try
        {
            aCassette->setLastClaimedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setLastClaimedTimeStamp);

        try
        {
            aCassette->setLastClaimedPerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setLastClaimedPerson);

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_cassette_InspectionTime_Reset");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_InspectionTime_Reset_out, cs_cassette_InspectionTime_Reset, methodName)
}
