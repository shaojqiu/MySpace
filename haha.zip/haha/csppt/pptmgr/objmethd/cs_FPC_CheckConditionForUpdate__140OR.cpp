//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: FPC_CheckConditionForUpdate__140.cpp
//

#include "cs_pptmgr.hpp"
#include "plot.hh"

//[Object Function Name]: long   FPC_CheckConditionForUpdate__140
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2006/10/30  D8000024  H.Mutoh        Initial release (R8.0)
// 2006/12/18  P8000045  M.Murata       Fixed to initialize out parameter.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2013/10/23 DSN000081739 Shudi Wang     Equipment Monitor Automation Support
// 2015/07/17 PSN000100033 T.Ishida       Add check lot in cassette before checking xfer status
//
// Innotron Modification history:
// Date       DCR/PCR No   Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/18 INN-R170003  LiHejing       Durable Management Enhancement.
//
//[Function Description]:
//  The same lot of specified process is extracted. Returns the lot list.
//  At the same time, check AvailFalg of every Lot.
//
//[Input Parameters]:
//  in  pptObjCommonIn        strObjCommonIn;
//  in  objectIdentifier      lotFamilyID;
//  in  string                actionType;
//  in  objectIdentifier      mainPDID;
//  in  string                mainOpeNo;
//  in  objectIdentifier      orgMainPDID;
//  in  string                orgOpeNo;
//  in  objectIdentifier      subMainPDID;
//  in  string                subOpeNo;
//
//[Output Parameters]:
//  out objFPC_CheckConditionForUpdate_out__140   strFPC_CheckConditionForUpdate_out;
//
//  typedef struct objFPC_CheckConditionForUpdate_out__140_struct {
//      pptRetCode                         strResult;
//      boolean                            holdFlag;
//      pptLotFamily_CurrentStatusSequence strLotFamily_CurrentStatusList;
//      objectIdentifierSequence           heldLotIDs;  //DSN000081739
//      any                                siInfo;
//  } struct objFPC_CheckConditionForUpdate_out__140;
//
//  typedef struct pptLotFamily_CurrentStatus_struct {
//      objectIdentifier lotID;
//      any              siInfo:
//  } pptLotFamily_CurrentStatus;
//
//  typedef sequence <pptLotFamily_CurrentStatus> pptLotFamily_CurrentStatusSequence;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK

CORBA::Long CS_PPTManager_i::FPC_CheckConditionForUpdate__140(
//DSN000081739        objFPC_CheckConditionForUpdate_out& strFPC_CheckConditionForUpdate_out,
        objFPC_CheckConditionForUpdate_out__140& strFPC_CheckConditionForUpdate_out,  //DSN000081739
        const pptObjCommonIn&                 strObjCommonIn,
        const objectIdentifier&               lotFamilyID,
        const char *                          actionType,
        const objectIdentifier&               mainPDID,
        const char *                          mainOpeNo,
        const objectIdentifier&               orgMainPDID,
        const char *                          orgOpeNo,
        const objectIdentifier&               subMainPDID,
        const char *                          subOpeNo )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::FPC_CheckConditionForUpdate__140");
        PPT_METHODTRACE_V2( "", "in-para lotFamilyID", lotFamilyID.identifier );
        PPT_METHODTRACE_V2( "", "in-para actionType",  actionType );
        PPT_METHODTRACE_V2( "", "in-para mainPDID",    mainPDID.identifier );
        PPT_METHODTRACE_V2( "", "in-para mainOpeNo",   mainOpeNo );
        PPT_METHODTRACE_V2( "", "in-para orgMainPDID", orgMainPDID.identifier );
        PPT_METHODTRACE_V2( "", "in-para orgOpeNoy",   orgOpeNo);
        PPT_METHODTRACE_V2( "", "in-para subMainPDID", subMainPDID.identifier );
        PPT_METHODTRACE_V2( "", "in-para subOpeNo",    subOpeNo );

        /*----------------*/
        /*                */
        /*   Initialize   */
        /*                */
        /*----------------*/
        CORBA::Long rc = RC_OK;
        strFPC_CheckConditionForUpdate_out.holdFlag = FALSE;    //P8000045

        if( CIMFWStrLen(lotFamilyID.identifier) == 0 )
        {
            SET_MSG_RC( strFPC_CheckConditionForUpdate_out,
                        MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        if( CIMFWStrLen(mainPDID.identifier) == 0                                     ||
            CIMFWStrLen(mainOpeNo)           == 0                                     ||
            (CIMFWStrLen(orgMainPDID.identifier) != 0 && CIMFWStrLen(orgOpeNo)  == 0) ||
            (CIMFWStrLen(orgMainPDID.identifier) == 0 && CIMFWStrLen(orgOpeNo)  != 0) ||
            (CIMFWStrLen(subMainPDID.identifier) != 0 && CIMFWStrLen(subOpeNo)  == 0) ||
            (CIMFWStrLen(subMainPDID.identifier) == 0 && CIMFWStrLen(subOpeNo)  != 0) ||
            (CIMFWStrLen(orgMainPDID.identifier) == 0 && CIMFWStrLen(subMainPDID.identifier) != 0) )
        {
            SET_MSG_RC( strFPC_CheckConditionForUpdate_out,
                        MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        /*--------------------------------*/
        /*   Get LotIDList from FRWAFER   */
        /*--------------------------------*/
        objLot_wafersStatusList_GetDR_out strLot_waferStatusList_GetDR_out;
        rc = lot_wafersStatusList_GetDR( strLot_waferStatusList_GetDR_out, strObjCommonIn, lotFamilyID );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "lot_waferStatusList_GetDR() != RC_OK", rc);
            strFPC_CheckConditionForUpdate_out.strResult = strLot_waferStatusList_GetDR_out.strResult;
            return rc;
        }

        // narrow down to unique lot
        CORBA::Long tmpLotLen = strLot_waferStatusList_GetDR_out.strWaferListInLotFamilyInfoSeq.length();
        PPT_METHODTRACE_V2("", "Lot count in lotFamily.", tmpLotLen);
        objectIdentifierSequence lotIDList;
        lotIDList.length(tmpLotLen);
        CORBA::Long lotCnt = 0;
        CORBA::Boolean firstCondition = TRUE;
        CORBA::Boolean existFlag      = FALSE;
        for(CORBA::Long tmpLotCnt=0; tmpLotCnt<tmpLotLen; tmpLotCnt++ )
        {
            if( firstCondition )
            {
                lotIDList[lotCnt] =
                    strLot_waferStatusList_GetDR_out.strWaferListInLotFamilyInfoSeq[tmpLotCnt].lotID;
                PPT_METHODTRACE_V2("", "ActiveLotID in this LotFamily", lotIDList[lotCnt].identifier);
                firstCondition = FALSE;
                lotCnt++;
            }
            else
            {
                existFlag = FALSE;
                for(CORBA::Long tmpCnt=0; tmpCnt<lotCnt; tmpCnt++ )
                {
                    if( CIMFWStrCmp( strLot_waferStatusList_GetDR_out.strWaferListInLotFamilyInfoSeq[tmpLotCnt].lotID.identifier, lotIDList[tmpCnt].identifier ) == 0 )
                    {
                        PPT_METHODTRACE_V1("", "this lot is already obtained.");
                        existFlag = TRUE;
                        break;
                    }
                }

                if( !existFlag )
                {
                    lotIDList[lotCnt] =
                        strLot_waferStatusList_GetDR_out.strWaferListInLotFamilyInfoSeq[tmpLotCnt].lotID;
                    PPT_METHODTRACE_V2("", "ActiveLotID in this LotFamily", lotIDList[lotCnt].identifier);
                    lotCnt++;
                }
            }
        }

        lotIDList.length(lotCnt);
        CORBA::Long lotLen = lotCnt;
        PPT_METHODTRACE_V2("", "lotLen", lotLen);
        CORBA::Long count = 0;

        pptLotFamily_CurrentStatusSequence strLotFamily_CurrentStatusList;
        strLotFamily_CurrentStatusList.length(lotLen);

        if( lotLen > 0 )
        {
            for( lotCnt=0; lotCnt<lotLen; lotCnt++ )
            {
                /*---------------------*/
                /*   Check AvailFlag   */
                /*---------------------*/
                objLot_FPCAvailFlag_Get_out strLot_FPCAvailFlag_Get_out;
                rc = lot_FPCAvailFlag_Get( strLot_FPCAvailFlag_Get_out, strObjCommonIn, lotIDList[lotCnt] );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_FPCAvailFlag_Get() != RC_OK", rc);
                    strFPC_CheckConditionForUpdate_out.strResult = strLot_FPCAvailFlag_Get_out.strResult;
                    return rc;
                }

                if( FALSE == strLot_FPCAvailFlag_Get_out.FPCAvailableFlag )
                {
                    PPT_METHODTRACE_V1("", "LotFPCAvailableFlag is OFF");
                    SET_MSG_RC( strFPC_CheckConditionForUpdate_out,
                                MSG_FPC_NOTAVAILABLE_ERROR, RC_FPC_NOTAVAILABLE_ERROR );
                    return RC_FPC_NOTAVAILABLE_ERROR;
                }

                /*--------------------------*/
                /*   Get Lot current info   */
                /*--------------------------*/
                objLot_currentOperationInfo_Get_out strLot_currentOperationInfo_Get_out;
                rc = lot_currentOperationInfo_Get( strLot_currentOperationInfo_Get_out, strObjCommonIn, lotIDList[lotCnt] );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "lot_currentOperationInfo_Get() != RC_OK", rc);
                    strFPC_CheckConditionForUpdate_out.strResult =
                        strLot_currentOperationInfo_Get_out.strResult;
                    return rc;
                }

                if( CIMFWStrCmp(mainPDID.identifier,
                                strLot_currentOperationInfo_Get_out.routeID.identifier) == 0 &&
                    CIMFWStrCmp(mainOpeNo,
                                strLot_currentOperationInfo_Get_out.operationNumber)    == 0 )
                {
                    PPT_METHODTRACE_V3("",
                        "Defined routeID in FPC info and the routeID of currentLot is corresponded.",
                        strLot_currentOperationInfo_Get_out.routeID.identifier,
                        strLot_currentOperationInfo_Get_out.operationNumber);

                    PPT_METHODTRACE_V2("", "lotID = ", lotIDList[lotCnt].identifier);

                    /*----------------------*/
                    /*   Check controlJob   */
                    /*----------------------*/
                    objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
                    rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn, lotIDList[lotCnt] );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_controlJobID_Get() != RC_OK", rc);
                        strFPC_CheckConditionForUpdate_out.strResult = strLot_controlJobID_Get_out.strResult;
                        return rc;
                    }

                    if( CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) != 0 )
                    {
                        PPT_METHODTRACE_V2("", "Lot has controlJob.",
                                           strLot_controlJobID_Get_out.controlJobID.identifier);
                        PPT_SET_MSG_RC_KEY2( strFPC_CheckConditionForUpdate_out,
                                             MSG_LOT_CTLJOBID_FILLED, RC_LOT_CTLJOBID_FILLED,
                                             lotIDList[lotCnt].identifier,
                                             strLot_controlJobID_Get_out.controlJobID.identifier );
                        return RC_LOT_CTLJOBID_FILLED;
                    }

//PSN000100033 Add Start
                    //---------------------------
                    // Get Cassette from Lot
                    //---------------------------
                    objLot_cassette_Get_out strLot_cassette_Get_out;
                    rc = lot_cassette_Get( strLot_cassette_Get_out, strObjCommonIn, lotIDList[lotCnt] );

                    if( rc != RC_OK && rc != RC_NOT_FOUND_CST )
                    {
                        PPT_METHODTRACE_V2( "", "lot_cassette_Get() != RC_OK && lot_cassette_Get() != RC_NOT_FOUND_CST", rc );
                        strFPC_CheckConditionForUpdate_out.strResult = strLot_cassette_Get_out.strResult;
                        return rc;
                    }

                    if( rc == RC_OK )
                    {
//PSN000100033 Add End
                        /*----------------------*/
                        /*   Check Xfer state   */
                        /*----------------------*/
                        objLot_transferState_Get_out strLot_transferState_Get_out;
                        rc = lot_transferState_Get( strLot_transferState_Get_out, strObjCommonIn, lotIDList[lotCnt] );
                        if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "lot_transferState_Get() != RC_OK", rc);
                            strFPC_CheckConditionForUpdate_out.strResult = strLot_transferState_Get_out.strResult;
                            return rc;
                        }

                        PPT_METHODTRACE_V2("", "xferState", strLot_transferState_Get_out.transferState);
//INN-R170003                        if( CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 )
//INN-R170003 add start
                        if( CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_EquipmentIn) == 0 ||
                               CIMFWStrCmp(strLot_transferState_Get_out.transferState, CS_TRANS_STATE_PORT_IN) == 0)
//INN-R170003 add end
                        {
                            PPT_METHODTRACE_V1("", "Lot transfer state is 'EI' or 'PI'."); //INN-R170003
                            PPT_SET_MSG_RC_KEY2( strFPC_CheckConditionForUpdate_out,
                                                 MSG_INVALID_LOT_XFERSTAT, RC_INVALID_LOT_XFERSTAT,
                                                 lotIDList[lotCnt].identifier,
                                                 strLot_transferState_Get_out.transferState );
                            return RC_INVALID_LOT_XFERSTAT;
                        }
                    }    //PSN000100033

                    /*-------------------------*/
                    /*   Check process state   */
                    /*-------------------------*/
                    objLot_processState_Get_out strLot_processState_Get_out;
                    rc = lot_processState_Get( strLot_processState_Get_out, strObjCommonIn, lotIDList[lotCnt] );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "lot_processState_Get() != RC_OK", rc);
                        strFPC_CheckConditionForUpdate_out.strResult = strLot_processState_Get_out.strResult;
                        return rc;
                    }

                    PPT_METHODTRACE_V2("", "lot processState", strLot_processState_Get_out.theLotProcessState);
                    if( CIMFWStrCmp(strLot_processState_Get_out.theLotProcessState, SP_Lot_ProcState_Processing) == 0 )
                    {
                        PPT_METHODTRACE_V1("", "Lot processState is 'Processing'");
                        PPT_SET_MSG_RC_KEY2( strFPC_CheckConditionForUpdate_out,
                                             MSG_INVALID_LOT_PROCSTAT, RC_INVALID_LOT_PROCSTAT,
                                             lotIDList[lotCnt].identifier,
                                             strLot_processState_Get_out.theLotProcessState );
                        return RC_INVALID_LOT_PROCSTAT;
                    }

                    strLotFamily_CurrentStatusList[count].lotID = lotIDList[lotCnt];
                    count++;
                }
            } // end of [lotCnt]
        }

        PPT_METHODTRACE_V2("", "lot count of same operation", count);
        strLotFamily_CurrentStatusList.length(count);
        objectIdentifierSequence   heldLotIDs;  //DSN000081739

        if( count > 0 )
        {
            /*-----------------------*/
            /*   Check Hold Record   */
            /*-----------------------*/
            CORBA::Boolean bNonHoldFlag   = TRUE;
            CORBA::Boolean bFoundFPCHFlag = FALSE;
            CORBA::Boolean bFoundRSOPFlag = FALSE;
            CORBA::Boolean bOKFlag        = FALSE;
            heldLotIDs.length(count);               //DSN000081739
            CORBA::ULong nHeldLotCnt = 0;           //DSN000081739
            for( lotCnt=0; lotCnt<count; lotCnt++ )
            {
                bFoundFPCHFlag = FALSE;  //DSN000081739
                bFoundRSOPFlag = FALSE;  //DSN000081739
                PosLot_var aLot;
                PPT_CONVERT_LOTID_TO_LOT_OR( aLot, strLotFamily_CurrentStatusList[lotCnt].lotID,
                                             strFPC_CheckConditionForUpdate_out, FPC_CheckConditionForUpdate__140 );

                CORBA::Long hrLen = 0;
                PosHoldRecordSequence* strHoldRecords = NULL ;

                try
                {
                    strHoldRecords = aLot->allHoldRecords();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::allHoldRecords);

                PosHoldRecordSequence_var strHoldRecordsVar = strHoldRecords;
                hrLen = strHoldRecords->length();

                PPT_METHODTRACE_V2("", "strHoldRecords->length()", hrLen);

                if( hrLen == 0 )
                {
                    PPT_METHODTRACE_V1("", "Not found hold record.");
                    continue;
                }

                for( CORBA::Long hrCnt=0; hrCnt<hrLen; hrCnt++ )
                {
                    bNonHoldFlag = FALSE;

                    objectIdentifier reasonCodeID;
                    reasonCodeID = (*strHoldRecords)[hrCnt].reasonCode;
                    PPT_METHODTRACE_V2("", "This holdReason is ", reasonCodeID.identifier);

                    CORBA::Boolean responsibleOpeFlag = FALSE;
                    responsibleOpeFlag = (*strHoldRecords)[hrCnt].responsibleOperationFlag;

                    if( CIMFWStrCmp( reasonCodeID.identifier, SP_Reason_FPCHold ) == 0 )
                    {
                        PPT_METHODTRACE_V1("", "holdReason is 'FPCH'. break.");
                        bFoundFPCHFlag = TRUE;
                        break;
                    }
                    else if( responsibleOpeFlag == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "responsibleOperationFlag is TRUE. break.");
                        bFoundRSOPFlag = TRUE;
                        break;
                    }
                } // hrCnt( count of holdRecord )

                if( bFoundFPCHFlag == TRUE  || bFoundRSOPFlag == TRUE )
                {
                    PPT_METHODTRACE_V1("", "This Lot has 'FPCH' hold record or responsibleOpeFlag is true. return OK");
                    bOKFlag = TRUE;
//DSN000081739                    break;
                    heldLotIDs[nHeldLotCnt] = strLotFamily_CurrentStatusList[lotCnt].lotID;  //DSN000081739
                    nHeldLotCnt++;                                                           //DSN000081739

                }
            } // LotCnt(lot count of same oparation)

            heldLotIDs.length(nHeldLotCnt);                              //DSN000081739
            strFPC_CheckConditionForUpdate_out.heldLotIDs = heldLotIDs;  //DSN000081739

            if( bOKFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "return LotIDs");
                strFPC_CheckConditionForUpdate_out.strLotFamily_CurrentStatusList = strLotFamily_CurrentStatusList;
                strFPC_CheckConditionForUpdate_out.holdFlag = TRUE;
            }
            else if( bNonHoldFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "all lot of same operations has no hold record.");
                if( CIMFWStrCmp( actionType, SP_FPCInfo_Update ) == 0 )
                {
                    PPT_METHODTRACE_V1("", "actionType is 'Update'. return OK.");
                    strFPC_CheckConditionForUpdate_out.strLotFamily_CurrentStatusList = strLotFamily_CurrentStatusList;
                    strFPC_CheckConditionForUpdate_out.holdFlag = FALSE;
                }
                else
                {
                    SET_MSG_RC( strFPC_CheckConditionForUpdate_out,
                                MSG_FPC_LOT_EXIST_CURRENT_OPE_WITH_NOT_ONHOLD,
                                RC_FPC_LOT_EXIST_CURRENT_OPE_WITH_NOT_ONHOLD );
                    return RC_FPC_LOT_EXIST_CURRENT_OPE_WITH_NOT_ONHOLD;
                }
            }
            else
            {
                PPT_METHODTRACE_V1("", "error case.");
                SET_MSG_RC( strFPC_CheckConditionForUpdate_out,
                            MSG_FPC_LOT_EXIST_CURRENT_OPE_WITH_ONHOLD,
                            MSG_FPC_LOT_EXIST_CURRENT_OPE_WITH_ONHOLD );
                return MSG_FPC_LOT_EXIST_CURRENT_OPE_WITH_ONHOLD;
            }
        }

        /*----------------------*/
        /*                      */
        /*   Return to Caller   */
        /*                      */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::FPC_CheckConditionForUpdate__140");
        return(RC_OK);
    }
    CATCH_GLOBAL_EXCEPTIONS(strFPC_CheckConditionForUpdate_out, FPC_CheckConditionForUpdate__140, methodName);
}
