//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_cassette_CheckConditionForSLMDestCassetteOR.cpp
//

#include "cs_pptmgr.hpp"
#include "plot.hh"
#include "pmc.hh"
#include "pcas.hh"
#include "pprsp.hh"  //INN-R170002

// Class: PPTManager
//
// Service: cassette_CheckConditionForSLMDestCassette()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/06/23 DSIV00000099 M.Murata       SLM(Small Lot Manufacturing) Support.
// 2008/11/07 DSIV00000214 K.Kido         Multi Fab Support.
// 2009/03/12 DSIV00000744 F.Chen         (CJM) Cassette Xfer Status Check For Retrieving Cassette Assignment.
//
// Innotron Modification history:
// Date       DCR/PCR No   Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/10/04 INN-R170002  JJ.Zhang       Contaminaiton Control
// 2017/10/10 INN-R170003  YangXigang     Durable Management Enhancement
//
//[Function Description]:
// Check availability of cassette for destination (SLM).
//
//[Input Parameters]:
//typedef struct objCassette_CheckConditionForSLMDestCassette_in_struct{
//    objectIdentifier  equipmentID;
//    objectIdentifier  controlJobID;
//    objectIdentifier  cassetteID;
//    objectIdentifier  lotID;
//    any               siInfo;
//}objCassette_CheckConditionForSLMDestCassette_in;
//
//[Output Parameters]:
// typedef objBase_out objCassette_CheckConditionForSLMDestCassette_out
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

//INN-R170002 CORBA::Long PPTManager_i::cassette_CheckConditionForSLMDestCassette(
CORBA::Long CS_PPTManager_i::cassette_CheckConditionForSLMDestCassette(        //INN-R170002
    objCassette_CheckConditionForSLMDestCassette_out&       strCassette_CheckConditionForSLMDestCassette_out,
    const pptObjCommonIn&                                   strObjCommonIn,
    const objCassette_CheckConditionForSLMDestCassette_in&  strCassette_CheckConditionForSLMDestCassette_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cassette_CheckConditionForSLMDestCassette");

        CORBA::Long rc = RC_OK;

        //---------------------------------
        // Input Parameter
        //---------------------------------

        const objectIdentifier& equipmentID  = strCassette_CheckConditionForSLMDestCassette_in.equipmentID;
        const objectIdentifier& controlJobID = strCassette_CheckConditionForSLMDestCassette_in.controlJobID;
        const objectIdentifier& cassetteID   = strCassette_CheckConditionForSLMDestCassette_in.cassetteID;
        const objectIdentifier& lotID        = strCassette_CheckConditionForSLMDestCassette_in.lotID;

        PPT_METHODTRACE_V2("", "InParam [equipmentID] ", equipmentID.identifier);
        PPT_METHODTRACE_V2("", "InParam [controlJobID]", controlJobID.identifier);
        PPT_METHODTRACE_V2("", "InParam [cassetteID]  ", cassetteID.identifier);
        PPT_METHODTRACE_V2("", "InParam [lotID]       ", lotID.identifier);

        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette, cassetteID,
                                               strCassette_CheckConditionForSLMDestCassette_out,
                                               cassette_CheckConditionForSLMDestCassette );

        //-----------------------------------------------------------
        // Check ControlJob of Cassette
        //-----------------------------------------------------------
        PPT_METHODTRACE_V1("", "Check ControlJob of Cassette");
        PosControlJob_var aControlJob;
        try
        {
            aControlJob = aCassette->getControlJob();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob);

        if ( !CORBA::is_nil(aControlJob) )
        {
            objectIdentifier castCJID;
            PPT_SET_OBJECT_IDENTIFIER( castCJID, aControlJob,
                                       strCassette_CheckConditionForSLMDestCassette_out,
                                       cassette_CheckConditionForSLMDestCassette,
                                       PosControlJob );
            PPT_METHODTRACE_V2("", "castCJID", castCJID.identifier);

            if ( 0 != CIMFWStrCmp(castCJID.identifier, controlJobID.identifier) )
            {
                PPT_METHODTRACE_V1("", "return RC_SLM_DSTCAST_RESERVED_ANOTHER_CTRLJOB");
                PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForSLMDestCassette_out, MSG_SLM_DSTCAST_RESERVED_ANOTHER_CTRLJOB, RC_SLM_DSTCAST_RESERVED_ANOTHER_CTRLJOB, cassetteID.identifier);
                return RC_SLM_DSTCAST_RESERVED_ANOTHER_CTRLJOB;
            }
        }

        //--------------------------------------------------
        // Check SLMReserveEquipmentID of Cassette
        //--------------------------------------------------
        PPT_METHODTRACE_V1("", "Check SLMReserveEquipmentID of Cassette");
        PosMachine_var aSLMReservedMachine;
        try
        {
            aSLMReservedMachine = aCassette->getSLMReservedMachine();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getSLMReservedMachine);

        if ( !CORBA::is_nil(aSLMReservedMachine) )
        {
            objectIdentifier castSLMRsvEqpID;
            PPT_SET_OBJECT_IDENTIFIER( castSLMRsvEqpID, aSLMReservedMachine,
                                       strCassette_CheckConditionForSLMDestCassette_out,
                                       cassette_CheckConditionForSLMDestCassette,
                                       PosMachine );
            PPT_METHODTRACE_V2("", "castSLMRsvEqpID", castSLMRsvEqpID.identifier);

            if ( 0 != CIMFWStrCmp(castSLMRsvEqpID.identifier, equipmentID.identifier) )
            {
                PPT_METHODTRACE_V3("", " !!!!! Error Because the specified destination cassette is reserved by another Equipment SLM.", cassetteID.identifier, equipmentID.identifier);
                PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForSLMDestCassette_out, MSG_ALREADY_RESERVED_CAST_SLM, RC_ALREADY_RESERVED_CAST_SLM, cassetteID.identifier );
                return RC_ALREADY_RESERVED_CAST_SLM;
            }
            else
            {
                PPT_METHODTRACE_V1("", "0 == CIMFWStrCmp(castSLMRsvEqpID.identifier, equipmentID.identifier)");
                objEquipmentContainerPosition_info_GetByDestCassette_out strEquipmentContainerPosition_info_GetByDestCassette_out;
                objEquipmentContainerPosition_info_GetByDestCassette_in  strEquipmentContainerPosition_info_GetByDestCassette_in;
                strEquipmentContainerPosition_info_GetByDestCassette_in.equipmentID = equipmentID;
                strEquipmentContainerPosition_info_GetByDestCassette_in.cassetteID  = cassetteID;
                
                rc = equipmentContainerPosition_info_GetByDestCassette( strEquipmentContainerPosition_info_GetByDestCassette_out,
                                                                        strObjCommonIn,
                                                                        strEquipmentContainerPosition_info_GetByDestCassette_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "equipmentContainerPosition_info_GetByDestCassette() rc != RC_OK", rc);
                    strCassette_CheckConditionForSLMDestCassette_out.strResult = strEquipmentContainerPosition_info_GetByDestCassette_out.strResult;
                    return rc;
                }

                if( 0 != CIMFWStrCmp( strEquipmentContainerPosition_info_GetByDestCassette_out.strEqpContainerPositionSeq[0].controlJobID.identifier,
                                      controlJobID.identifier ))
                {
                    PPT_METHODTRACE_V1("", "return RC_ALREADY_RESERVED_CAST_SLM");
                    PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForSLMDestCassette_out, MSG_ALREADY_RESERVED_CAST_SLM, RC_ALREADY_RESERVED_CAST_SLM, cassetteID.identifier );
                    return RC_ALREADY_RESERVED_CAST_SLM;
                }
            }
        }

        //----------------------------------------------------
        // Check SortJob of Cassette
        //----------------------------------------------------
        PPT_METHODTRACE_V1("", "Check SortJob of Cassette");
        objSorter_jobList_GetDR_in strSorter_jobList_GetDR_in;
        strSorter_jobList_GetDR_in.carrierID = cassetteID;

        objSorter_jobList_GetDR_out strSorter_jobList_GetDR_out;
        rc = sorter_jobList_GetDR( strSorter_jobList_GetDR_out, strObjCommonIn, strSorter_jobList_GetDR_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "sorter_jobList_GetDR() rc != RC_OK", rc);
            strCassette_CheckConditionForSLMDestCassette_out.strResult = strSorter_jobList_GetDR_out.strResult;
            return rc;
        }

        CORBA::Long lenSortJob = strSorter_jobList_GetDR_out.strSortJobListAttributesSeq.length();
        PPT_METHODTRACE_V2("", "lenSortJob", lenSortJob);
        if ( 0 < lenSortJob )
        {
            PPT_METHODTRACE_V1("", "return RC_EXIST_SORTERJOB_FOR_CASSETTE");
            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForSLMDestCassette_out,
                                 MSG_EXIST_SORTERJOB_FOR_CASSETTE, RC_EXIST_SORTERJOB_FOR_CASSETTE,
                                 cassetteID.identifier,
                                 strSorter_jobList_GetDR_out.strSortJobListAttributesSeq[0].sorterJobID.identifier );
            return RC_EXIST_SORTERJOB_FOR_CASSETTE;
        }

        //-------------------------------------------------------
        // Check PostProcessFlag of cassette
        //-------------------------------------------------------
        PPT_METHODTRACE_V1("", "Check PostProcessFlag of cassette");
        CORBA::Boolean bPostProcFlg = FALSE;
        try
        {
            bPostProcFlg = aCassette->isPostProcessFlagOn();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isPostProcessFlagOn);
        PPT_METHODTRACE_V2("", "bPostProcFlg", (long)bPostProcFlg);

        if( TRUE == bPostProcFlg )
        {
            PPT_METHODTRACE_V1("", "return RC_CAST_INPOSTPROCESS");
            PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForSLMDestCassette_out,
                                MSG_CAST_INPOSTPROCESS, RC_CAST_INPOSTPROCESS,
                                cassetteID.identifier );
            return RC_CAST_INPOSTPROCESS;
        }
//DSIV00000214 add start
        //-------------------------------------------------------
        // Check cassette InterFabXfer State
        //-------------------------------------------------------
        CORBA::String_var castInterFabState;
        try
        {
            castInterFabState = aCassette->getInterFabTransferState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getInterFabXferState);

        PPT_METHODTRACE_V2("", " #### interFabXferState :", castInterFabState );
        if( 0 == CIMFWStrCmp( castInterFabState, SP_InterFab_XferState_Transferring ) )
        {
            PPT_METHODTRACE_V1("", "return RC_CAST_INPOSTPROCESS");
            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForSLMDestCassette_out,
                                 MSG_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                 RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                 cassetteID.identifier,
                                 (const char*)castInterFabState );
            return RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ;
        }
//DSIV00000214 add end

        //-------------------------------------------------------
        // Check available condition of cassette
        //-------------------------------------------------------
        PPT_METHODTRACE_V1("", "Check available condition of cassette");
        CORBA::String_var cassetteState;
        try
        {
            cassetteState = aCassette->getDurableState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getDurableState);
        PPT_METHODTRACE_V2("", "cassetteState", cassetteState);

        if ( 0 != CIMFWStrCmp(cassetteState, CIMFW_Durable_Available) )
        {
            PPT_METHODTRACE_V1("", "return RC_INVALID_CAST_STAT");
            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForSLMDestCassette_out,
                                 MSG_INVALID_CAST_STAT, RC_INVALID_CAST_STAT,
                                 cassetteState,
                                 cassetteID.identifier );
            return RC_INVALID_CAST_STAT;
        }

        //-------------------------------------------------------
        // Check dispatch reservation condition of cassette
        //-------------------------------------------------------
        PPT_METHODTRACE_V1("", "Check dispatch reservation condition of cassette");
        CORBA::Boolean bDispatchReserved = FALSE;
        try
        {
            bDispatchReserved = aCassette->isDispatchReserved();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isDispatchReserved);
        PPT_METHODTRACE_V2("", "bDispatchReserved", (long)bDispatchReserved);

        if ( TRUE == bDispatchReserved )
        {
            CORBA::String_var NPWLoadPurposeType;
            try
            {
                NPWLoadPurposeType = aCassette->getNPWLoadPurposeType();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getNPWLoadPurposeType)
            PPT_METHODTRACE_V2("", "NPWLoadPurposeType", NPWLoadPurposeType);

            if ( 0 == CIMFWStrCmp(NPWLoadPurposeType, SP_LoadPurposeType_SLMRetrieving) )
            {
                PPT_METHODTRACE_V1("", "return RC_ALREADY_DISPATCH_RESVED_CST");
                SET_MSG_RC( strCassette_CheckConditionForSLMDestCassette_out,
                            MSG_ALREADY_DISPATCH_RESVED_CST, RC_ALREADY_DISPATCH_RESVED_CST );
                return RC_ALREADY_DISPATCH_RESVED_CST;
            }
        }

        //-------------------------------------------------------
        // Check CarrierCategory of cassette
        //-------------------------------------------------------
        PPT_METHODTRACE_V1("", "Check CarrierCategory of cassette");
        CORBA::String_var castCategory;
        try
        {
            castCategory = aCassette->getCassetteCategory();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getCassetteCategory)
        PPT_METHODTRACE_V2("", "castCategory", castCategory);

        // Get required cassette category of current operation of Lot.
        PosLot_var aPosLot;
        PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot, lotID,
                                     strCassette_CheckConditionForSLMDestCassette_out,
                                     cassette_CheckConditionForSLMDestCassette );

//DSIV00000214 add start
        //-------------------------------------------------------
        // Check cassette InterFabXfer State
        //-------------------------------------------------------
        CORBA::String_var lotInterFabState;
        try
        {
            lotInterFabState = aPosLot->getInterFabTransferState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getInterFabXferState);

        PPT_METHODTRACE_V2("", " #### interFabXferState :", lotInterFabState );
        if( 0 == CIMFWStrCmp( lotInterFabState, SP_InterFab_XferState_Transferring ) ||
            0 == CIMFWStrCmp( lotInterFabState, SP_InterFab_XferState_Required ) )
        {
            PPT_METHODTRACE_V1("", "return RC_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ,");
            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForSLMDestCassette_out,
                                 MSG_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ,
                                 RC_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ,
                                 lotID.identifier,
                                 (const char*)lotInterFabState );
            return RC_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ;
        }
//DSIV00000214 add end

        CORBA::String_var curOpeCastCategory;
        try
        {
            curOpeCastCategory = aPosLot->getRequiredCassetteCategory();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getRequiredCassetteCategory)
        PPT_METHODTRACE_V2("", "curOpeCastCategory", curOpeCastCategory);

        if ( 0 < CIMFWStrLen(castCategory) && 0 < CIMFWStrLen(curOpeCastCategory) )
        {
            // Get required cassette category of next operation of Lot.
            PPT_METHODTRACE_V1("", "call lot_requiredCassetteCategory_GetForNextOperation()");
            objLot_requiredCassetteCategory_GetForNextOperation_out strLot_requiredCassetteCategory_GetForNextOperation_out;
            rc = lot_requiredCassetteCategory_GetForNextOperation( strLot_requiredCassetteCategory_GetForNextOperation_out,
                                                                   strObjCommonIn,
                                                                   lotID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "##### return lot_requiredCassetteCategory_GetForNextOperation", rc);
                strCassette_CheckConditionForSLMDestCassette_out.strResult = strLot_requiredCassetteCategory_GetForNextOperation_out.strResult;
                return( rc );
            }
            PPT_METHODTRACE_V2("", "nextRequiredCassetteCategory", strLot_requiredCassetteCategory_GetForNextOperation_out.nextRequiredCassetteCategory);

            if ( 0 < CIMFWStrLen(strLot_requiredCassetteCategory_GetForNextOperation_out.nextRequiredCassetteCategory)
              && 0 != CIMFWStrCmp(castCategory, strLot_requiredCassetteCategory_GetForNextOperation_out.nextRequiredCassetteCategory) )
            {
                PPT_METHODTRACE_V1("", "return RC_MISMATCH_DEST_CAST_CATEGORY");
                PPT_SET_MSG_RC_KEY4( strCassette_CheckConditionForSLMDestCassette_out,
                                     MSG_MISMATCH_DEST_CAST_CATEGORY, RC_MISMATCH_DEST_CAST_CATEGORY,
                                     cassetteID.identifier,
                                     castCategory,
                                     curOpeCastCategory,
                                     strLot_requiredCassetteCategory_GetForNextOperation_out.nextRequiredCassetteCategory );
                return RC_MISMATCH_DEST_CAST_CATEGORY;
            }
        }
//INN-R170002 Add Start
        ProductSpecification_var aTmpProductSpecification;
        PosProductSpecification_var aProductSpecification;
        try
        {
            aTmpProductSpecification = aPosLot->getProductSpecification();
            aProductSpecification = PosProductSpecification::_narrow(aTmpProductSpecification);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification);

        if ( TRUE == CORBA::is_nil(aProductSpecification) )
        {
            PPT_METHODTRACE_V1("", "Error : Lot Product ID is NIL");
            SET_MSG_RC( strCassette_CheckConditionForSLMDestCassette_out,
                        MSG_NOT_FOUND_PRODUCTSPEC,
                        RC_NOT_FOUND_PRODUCTSPEC );
            return RC_NOT_FOUND_PRODUCTSPEC;
        }

        CORBA::String_var strReqUsageType;
        SI_PPT_USERDATA_GET_STRING( aProductSpecification, CS_S_PROD_CarrierUsageType, strReqUsageType );

        CORBA::String_var strCarrierUsageType;
        SI_PPT_USERDATA_GET_STRING( aCassette, CS_M_CAST_UsageType, strCarrierUsageType );
        PPT_METHODTRACE_V2("", "strCarrierUsageType", strCarrierUsageType );

        if ( 0 <  CIMFWStrLen(strReqUsageType) && 0 < CIMFWStrLen(strCarrierUsageType)
          && 0 != CIMFWStrCmp(strCarrierUsageType, strReqUsageType ) )
        {
            PPT_METHODTRACE_V2("", "Usage Type not match", strReqUsageType);
            CS_PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForSLMDestCassette_out,
                                    CS_MSG_CARRIER_USAGE_TYPE_MISMATCH,
                                    CS_RC_CARRIER_USAGE_TYPE_MISMATCH,
                                    strReqUsageType, lotID.identifier );
            return CS_RC_CARRIER_USAGE_TYPE_MISMATCH;
        }
//INN-R170002 Add End
//DSIV00000744 Add Start
        //-------------------------------------------------------
        // Check cassette transfer status
        // When any of Equipment port access mode is "Manual"
        //     Retrieving cassette should be any of "SI, MI" status; 
        //     If cassette transfer status is "EI", the current cassette loading port should have access mode of "Auto" too.
        //     If Reroute is allowed, cassette status is allowed to be "BO/BI" status; if cassette has a transfer job, "SO" and "EO" are also allowed
        //-------------------------------------------------------
        //  Get equipment port information
        objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
        rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                     strObjCommonIn,
                                     equipmentID );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1( "", "equipment_portInfo_Get() != RC_OK");
            strCassette_CheckConditionForSLMDestCassette_out.strResult = strEquipment_portInfo_Get_out.strResult;
            return( rc );
        }

        CORBA::ULong nPortLen1 = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
        PPT_METHODTRACE_V2("", "nPortLen1", nPortLen1);
        
        CORBA::ULong nCnt1 = 0;
        CORBA::Boolean manualAccessFlag = FALSE;
        
        // check access mode
        for( nCnt1 = 0; nCnt1 < nPortLen1; nCnt1++ )
        {
            PPT_METHODTRACE_V3("", "# Loop[nCnt1], portID = ", nCnt1, strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[nCnt1].portID.identifier);
            if (0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[nCnt1].accessMode, SP_Eqp_AccessMode_Manual))
            {
                PPT_METHODTRACE_V3("", "# Port/AccessMode",
                                        strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[nCnt1].portID.identifier,
                                        strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[nCnt1].accessMode);
                manualAccessFlag = TRUE;
                break;
            }
        }
        if (manualAccessFlag == FALSE) // All "Auto" Access mode
        {
            //Get transferState (cassette)
            PPT_METHODTRACE_V1("","Get TransferState");
            CORBA::String_var transferState;
            try
            {
                transferState = aCassette->getTransportState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTransportState)
            PPT_METHODTRACE_V2("","transferState", transferState);
            
            // transfer status of SI and MI is allowed
            if (0 == CIMFWStrCmp(transferState, SP_TransState_StationIn) ||
                0 == CIMFWStrCmp(transferState, SP_TransState_ManualIn))
            {
                PPT_METHODTRACE_V1("","transferState = MI or SI");
            }
            else if (0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn))
            {
                PPT_METHODTRACE_V1("","transferState = EI");
                
                // When cassette xferstatus is EI, cassette current loaded equipment(port) access mode should be Auto
                //get cassette eqp access mode 
                Machine_var aMachine;
                try
                {
                    aMachine = aCassette->currentAssignedMachine();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::currentAssignedMachine)
                objectIdentifier currentEquipmentID;
                PPT_SET_OBJECT_IDENTIFIER( currentEquipmentID,
                                           aMachine,
                                           strCassette_CheckConditionForSLMDestCassette_out,
                                           cassette_CheckConditionForSLMDestCassette,
                                           PosMachine );
                // get current loading equipment port information
                objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out_current;

                rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out_current,
                                             strObjCommonIn,
                                             currentEquipmentID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "", "equipment_portInfo_Get() != RC_OK");
                    strCassette_CheckConditionForSLMDestCassette_out.strResult = strEquipment_portInfo_Get_out_current.strResult;
                    return( rc );
                }
                CORBA::ULong nPortLen2 = strEquipment_portInfo_Get_out_current.strEqpPortInfo.strEqpPortStatus.length();
                PPT_METHODTRACE_V2("", "nPortLen2", nPortLen2);
                
                for( nCnt1 = 0; nCnt1 < nPortLen2; nCnt1++ )
                {
                    PPT_METHODTRACE_V3("", "# Loop[nCnt1], portID = ", nCnt1, strEquipment_portInfo_Get_out_current.strEqpPortInfo.strEqpPortStatus[nCnt1].portID.identifier);
                    if (0 == CIMFWStrCmp(strEquipment_portInfo_Get_out_current.strEqpPortInfo.strEqpPortStatus[nCnt1].loadedCassetteID.identifier, cassetteID.identifier))
                    {
                        PPT_METHODTRACE_V2("", "# cassette is loaded on port",
                                                strEquipment_portInfo_Get_out_current.strEqpPortInfo.strEqpPortStatus[nCnt1].portID.identifier);
                        
                        if (0 == CIMFWStrCmp(strEquipment_portInfo_Get_out_current.strEqpPortInfo.strEqpPortStatus[nCnt1].accessMode, SP_Eqp_AccessMode_Auto))
                        {
                            PPT_METHODTRACE_V1("","Access Mode = Auto");
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("","Access Mode != Auto");
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForSLMDestCassette_out,
                                                 MSG_INVALID_CAST_XFERSTAT,
                                                 RC_INVALID_CAST_XFERSTAT,
                                                 transferState,
                                                 cassetteID.identifier);
                            return RC_INVALID_CAST_XFERSTAT;
                        }
                        break;
                    }
                }
                if (nCnt1 == nPortLen2)
                {
                    PPT_METHODTRACE_V1("","Data inconsistency");
                    PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForSLMDestCassette_out,
                                        MSG_INVALID_PARAMETER_WITH_MSG, RC_INVALID_PARAMETER_WITH_MSG,
                                        "Data inconsistency: transferStatus = EI, but cassette is not loaded" );
                    return( RC_INVALID_PARAMETER_WITH_MSG );
                }
                
            }
            else
            {
                //get rerouteFlag
                CORBA::String_var reRouteXferFlag = CIMFWStrDup(getenv(SP_REROUTE_XFER_FLAG));
                PPT_METHODTRACE_V2("","SP_REROUTE_XFER_FLAG ",reRouteXferFlag);
                
                if ( 0 == CIMFWStrCmp(reRouteXferFlag, "1"))
                {
                    PPT_METHODTRACE_V1("","reRouteXferFlag = 1");
                    if (0 == CIMFWStrCmp(transferState, SP_TransState_BayIn) ||
                        0 == CIMFWStrCmp(transferState, SP_TransState_BayOut))
                    {
                        PPT_METHODTRACE_V1("","transferState = BI or BO");
                    }
                    else if (0 == CIMFWStrCmp(transferState, SP_TransState_StationOut) ||
                    //INN-R170003 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentOut))
                             0 == CIMFWStrCmp(transferState, CS_TRANS_STATE_PORT_OUT))//INN-R170003
                    {
                        PPT_METHODTRACE_V1("","transferState = SO or EO");
                        PPT_METHODTRACE_V2("", "transferState = ", transferState);
                        //get transferjob (cassetterID)
                        objCassette_transferJobRecord_GetDR_out strCassette_transferJobRecord_GetDR_out;
                        rc = cassette_transferJobRecord_GetDR( strCassette_transferJobRecord_GetDR_out,
                                                               strObjCommonIn,
                                                               cassetteID );

                        if( rc == RC_CARRIER_NOT_TRANSFERING )
                        {
                            PPT_METHODTRACE_V1("", "rc == RC_CARRIER_NOT_TRANSFERING");
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForSLMDestCassette_out,
                                                 MSG_INVALID_CAST_XFERSTAT,
                                                 RC_INVALID_CAST_XFERSTAT,
                                                 transferState,
                                                 cassetteID.identifier);
                            return RC_INVALID_CAST_XFERSTAT;
                        }
                        else if( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "cassette_transferJobRecord_GetDR() rc != RC_OK");
                            strCassette_CheckConditionForSLMDestCassette_out.strResult = strCassette_transferJobRecord_GetDR_out.strResult ;
                            return( rc );
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", "transfer job existing");
                        }
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "Invalid transfer status");
                        PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForSLMDestCassette_out,
                                             MSG_INVALID_CAST_XFERSTAT,
                                             RC_INVALID_CAST_XFERSTAT,
                                             transferState,
                                             cassetteID.identifier);
                        return RC_INVALID_CAST_XFERSTAT;
                    }
                }
                else
                {
                    PPT_METHODTRACE_V1("", "Invalid transfer status");
                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForSLMDestCassette_out,
                                         MSG_INVALID_CAST_XFERSTAT,
                                         RC_INVALID_CAST_XFERSTAT,
                                         transferState,
                                         cassetteID.identifier);
                    return RC_INVALID_CAST_XFERSTAT;
                }
            }
        } // if access mode = true
        else
        {
            PPT_METHODTRACE_V1("", "access mode = false");
        }

//DSIV00000744 Add End

        PPT_METHODTRACE_V1("", "This cassette's condition is Good");

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cassette_CheckConditionForSLMDestCassette");

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_CheckConditionForSLMDestCassette_out, cassette_CheckConditionForSLMDestCassette, methodName)
}
