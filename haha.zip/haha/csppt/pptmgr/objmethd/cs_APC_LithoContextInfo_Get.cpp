//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
//
// SiView
// Name: cs_APC_LithoContextInfo_Get.cpp
//

#include "cs_pptmgr.hpp"

void debugLotInCassette( const pptLotInCassette& strLotInCassette );

// Class: CS_PPTManager
//
// [Object Function Name]: long   cs_APC_LithoContextInfo.cpp
//
//
// Innotron Modification history:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/09/26 INN-R170009 Nick Tsai      Prepare Litho Context Info for APC I/F
//
// Function Description:
//
// Input Parameters:
// in csObjAPC_LithoContextInfo_Get_in  strobjAPC_lithoContextInfo_Get_in;
//
//typedef struct csObjAPC_LithoContextInfo_Get_in_struct {
//    objectIdentifier            equipmentID;
//    pptLotInCassette            strLotInCassette;
//    string                      action;
//    any                         siInfo;
//}csObjAPC_LithoContextInfo_Get_in;
//
//
// Output Parameters:
// out csObjAPC_lithoContextInfo_Get_out strobjAPC_lithoContextInfo_Get_out;
//
//typedef struct csObjAPC_LithoContextInfo_Get_out_struct {
//    pptRetCode                      strResult;
//    csAPCLithoContextInfo           strAPCLithoContextInfo;
//    any                             siInfo;
//}csObjAPC_LithoContextInfo_Get_out;
//
// Return Value:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::cs_APC_LithoContextInfo_Get (
    csObjAPC_LithoContextInfo_Get_out&          strObjAPC_lithoContextInfo_Get_out,
    const pptObjCommonIn&                       strObjCommonIn,
    const csObjAPC_LithoContextInfo_Get_in&     strObjAPC_LithoContextInfo_Get_in )
{
    //======================================================//
    //     Initial                                          //
    //======================================================//
    CORBA::Long rc = RC_OK;

    //======================================================//
    //     Print Input Parameters                           //
    //======================================================//
    PPT_METHODTRACE_V2("", "action      :", strObjAPC_LithoContextInfo_Get_in.action ) ;
    PPT_METHODTRACE_V2("", "equipmentID :", strObjAPC_LithoContextInfo_Get_in.equipmentID.identifier ) ;
    debugLotInCassette ( strObjAPC_LithoContextInfo_Get_in.strLotInCassette );

    //==========================================//
    //     controlJobType                       //
    //==========================================//


//Nick ======================== controlJobType ========================
//Nick strAPCLithoRecommendContextInfo.controlJobType              = "LITHORECOMMEND"
//Nick
//Nick ======================== transactionID ========================
//Nick strAPCLithoRecommendContextInfo.transactionID               = LotID+yyyymmddhhmmss  (reportedTimeStamp, ex : LOTID00001.0120170905230812 )
//Nick
//Nick ======================== lotID ========================
//Nick strAPCLithoRecommendContextInfo.lotID                       = strLotInCassette.lotID
//Nick
//Nick ======================== lotType ========================
//Nick strAPCLithoRecommendContextInfo.lotType                     = P|E|M
//Nick ===> strLotInCassette.lotType  (Lot Type : P:Production | E:Engineering | M:Monitor)  //For other lot type, such as Dummy. Confirm later.
//Nick
//Nick ======================== partID ========================
//Nick strAPCLithoRecommendContextInfo.partID                      = strLotInCassette.productID
//Nick
//Nick ======================== layer ========================
//Nick strAPCLithoRecommendContextInfo.layer                       = layer
//Nick PO = PosLot -> getProcessOperation(),
//Nick layer = PO -> getPhotoLayer()
//Nick
//Nick ======================== routeGroup ========================
//Nick strAPCLithoRecommendContextInfo.routeGroup                  = get route user data ( S_MAINPD_RouteGroup )
//Nick
//Nick ======================== reticleID ========================
//Nick strAPCLithoRecommendContextInfo.reticleID                   = "RETICLE1" or "RETICLE1 RETICLE2" <-- if double exposure
//Nick for ( strLotInCassette.startRecipe.strStartReticle.reticleID )
//Nick     ==> conbime reticleIDs to a string "RETICLE1 RETICLE2", separated reticleID by space
//Nick
//Nick ======================== processEquipmentType ========================
//Nick strAPCLithoRecommendContextInfo.processEquipmentType        = get equipmentID type user data (S_EQPTYPE_ProcessEquipmentType)
//Nick
//Nick ======================== processEquipmentID ========================
//Nick strAPCLithoRecommendContextInfo.processEquipmentID          = equipmentID
//Nick
//Nick ======================== reworkLotFlag ========================
//Nick strAPCLithoRecommendContextInfo.reworkLotFlag =             = TRUE|FALSE
//Nick for ( strLotInCassette.strLotWafer )
//Nick     convert WAFERID to WAFER
//Nick     reworkCount = aPosWafer -> getReworkCount( route + operationNumber );
//Nick     if ( reworkCount > 0 )
//Nick         TRUE
//Nick         break
//Nick
//Nick ======================== recommendMode ========================
//Nick strAPCLithoRecommendContextInfo.recommendMode               = CALCULATE|REWORK|SENDAHEAD    ( CALCULATE: LOT, REWORK: Rework Lot, SENDAHEAD : Targeting Lot )
//Nick if action == Pilot_Reserve_Recommend or action == Pilot_OpeStart_Recommend
//Nick     SENDAHEAD
//Nick else if strAPCLithoRecommendContextInfo.reworkLotFlag == TRUE
//Nick     REWORK
//Nick else
//Nick     CALCULATE
//Nick
//Nick ======================== routeID ========================
//Nick strAPCLithoRecommendContextInfo.routeID                     = strLotInCassette.strStartOperationInfo.routeID
//Nick
//Nick ======================== operationNumber ========================
//Nick strAPCLithoRecommendContextInfo.operationNumber             = strLotInCassette.strStartOperationInfo.operationNumber
//Nick
//Nick ======================== parentLotID ========================
//Nick strAPCLithoRecommendContextInfo.parentLotID                 = lotFamilyID
//Nick lotFamily = lot->getLotFamily(),
//Nick lotFamilyID = lotFamily->getIdentifier()
//Nick
//Nick ======================== controlJobType ========================
//Nick strAPCLithoRecommendContextInfo.preToolID                   = preToolID
//Nick get cs_userData_GetByOperation(routeID, OperationNumber, S_MAINPD_OpeAPCPreOpeNo),
//Nick POS = lot ->getPO (S_MAINPD_OpeAPCPreOpeNo.value),
//Nick preToolID = POS->getAssignedMachine()
//Nick
//Nick ======================== sendAheadFlag ========================
//Nick strAPCLithoRecommendContextInfo.sendAheadFlag               = TRUE|FALSE
//Nick get lot user data (M_LOT_PilotFlag)
//Nick if flag == 1
//Nick     TRUE
//Nick
//Nick ======================== ParameterNames ========================
//Nick strAPCLithoRecommendContextInfo.ParameterNames              = "RParm1 RParm2 RParm3 ..."
//Nick for (strLotInCassette.strLotWafer[0].strStartRecipeParameter)   <-- just for the first wafer
//Nick     conbime strLotInCassette.strLotWafer[0].strStartRecipeParameter.parameterName to a string
//Nick
//Nick ======================== availableSubUnit ========================
//Nick strAPCLithoRecommendContextInfo.availableSubUnit            = 11|10|01|00
//Nick get chamber status of equipmentID
//Nick for ( chamber.length )
//Nick     //concat chamber status to a string,
//Nick     if chamber.status == AVAILABLE
//Nick         1           //Chamber1 == AVAILABLE >> 1, Chamber2 == AVAILABLE >> 11. Up to 2 chambers
//Nick
//Nick ======================== opeStartRecommendFlag ========================
//Nick strAPCLithoRecommendContextInfo.opeStartRecommendFlag
//Nick if action == OpeStart_Recommend
//Nick     TRUE
//Nick
//Nick ======================== feedForward1 ========================
//Nick strAPCLithoRecommendContextInfo.feedForward1                = empty
//Nick
//Nick ======================== feedForward2 ========================
//Nick strAPCLithoRecommendContextInfo.feedForward2                = empty
//Nick
//Nick ======================== feedForward3 ========================
//Nick strAPCLithoRecommendContextInfo.feedForward3                = empty
//Nick
//Nick ======================== feedForward4 ========================
//Nick strAPCLithoRecommendContextInfo.feedForward4                = empty
//Nick
//Nick ======================== extends ========================
//Nick strAPCLithoRecommendContextInfo.extends                     = empty (confirm later)



    return(RC_OK);
}

//************************************************************************************
// debugStartCassette
//************************************************************************************
void debugLotInCassette( const pptLotInCassette& strLotInCassette )
{
    PPT_METHODTRACE_V1( "", "debug strLotInCassette ********************************************************" );
/*
    CORBA::Long j, k, m, n;
    CORBA::Long len2, len3, len4, len5;

    len2 = strLotInCassette.length();
    PPT_METHODTRACE_V2( "", "strLotInCassette.length----->", len2 );
    for ( j = 0; j < len2; j++ )
    {
        PPT_METHODTRACE_V2( "", "  operationStartFlag_______________________________", (CORBA::Long) strLotInCassette[j].operationStartFlag );
        PPT_METHODTRACE_V2( "", "  monitorLotFlag___________________________________", (CORBA::Long) strLotInCassette[j].monitorLotFlag );
        PPT_METHODTRACE_V2( "", "  lotID____________________________________________", strLotInCassette[j].lotID.identifier );
        PPT_METHODTRACE_V2( "", "  lotType__________________________________________", strLotInCassette[j].lotType );
        PPT_METHODTRACE_V2( "", "  subLotType_______________________________________", strLotInCassette[j].subLotType );
        PPT_METHODTRACE_V2( "", "    logicalRecipeID________________________________", strLotInCassette[j].strStartRecipe.logicalRecipeID.identifier );
        PPT_METHODTRACE_V2( "", "    machineRecipeID________________________________", strLotInCassette[j].strStartRecipe.machineRecipeID.identifier );
        PPT_METHODTRACE_V2( "", "    physicalRecipeID_______________________________", strLotInCassette[j].strStartRecipe.physicalRecipeID );

        len3 = strLotInCassette[j].strStartRecipe.strStartReticle.length();
        PPT_METHODTRACE_V2( "", "strLotInCassette[j].strStartRecipe.strStartReticle.length----->", len3 );
        for ( k = 0; k < len3; k++ )
        {
            PPT_METHODTRACE_V2( "", "      sequenceNumber_______________________________", strLotInCassette[j].strStartRecipe.strStartReticle[k].sequenceNumber );
            PPT_METHODTRACE_V2( "", "      reticleID____________________________________", strLotInCassette[j].strStartRecipe.strStartReticle[k].reticleID.identifier );
        }
        len3 = strLotInCassette[j].strStartRecipe.strStartFixture.length();
        PPT_METHODTRACE_V2( "", "strLotInCassette[j].strStartRecipe.strStartFixture.length----->", len3 );
        for ( k = 0; k < len3; k++ )
        {
            PPT_METHODTRACE_V2( "", "      fixtureID____________________________________", strLotInCassette[j].strStartRecipe.strStartFixture[k].fixtureID.identifier );
            PPT_METHODTRACE_V2( "", "      fixtureCategory______________________________", strLotInCassette[j].strStartRecipe.strStartFixture[k].fixtureCategory );
        }

        PPT_METHODTRACE_V2( "", "    dataCollectionFlag_____________________________", strLotInCassette[j].strStartRecipe.dataCollectionFlag );

        len3 = strLotInCassette[j].strStartRecipe.strDCDef.length();
        PPT_METHODTRACE_V2( "", "strLotInCassette[j].strStartRecipe.strDCDef.length----->", len3 );
        for ( k = 0; k < len3; k++ )
        {
            PPT_METHODTRACE_V2( "", "      dataCollectionDefinitionID___________________", strLotInCassette[j].strStartRecipe.strDCDef[k].dataCollectionDefinitionID.identifier );
            PPT_METHODTRACE_V2( "", "      description__________________________________", strLotInCassette[j].strStartRecipe.strDCDef[k].description );
            PPT_METHODTRACE_V2( "", "      dataCollectionType___________________________", strLotInCassette[j].strStartRecipe.strDCDef[k].dataCollectionType );

            len4 = strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem.length();
            PPT_METHODTRACE_V2( "", "strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem.length----->", len4 );
            for ( m = 0; m < len4; m++ )
            {
                PPT_METHODTRACE_V2( "", "        dataCollectionItemName_____________________", strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[m].dataCollectionItemName );
                PPT_METHODTRACE_V2( "", "        dataCollectionMode_________________________", strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[m].dataCollectionMode );
                PPT_METHODTRACE_V2( "", "        dataCollectionUnit_________________________", strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[m].dataCollectionUnit );
                PPT_METHODTRACE_V2( "", "        dataType___________________________________", strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[m].dataType );
                PPT_METHODTRACE_V2( "", "        itemType___________________________________", strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[m].itemType );
                PPT_METHODTRACE_V2( "", "        measurementType____________________________", strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[m].measurementType );
                PPT_METHODTRACE_V2( "", "        waferID____________________________________", strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[m].waferID.identifier );
                PPT_METHODTRACE_V2( "", "        waferPosition______________________________", strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[m].waferPosition );
                PPT_METHODTRACE_V2( "", "        sitePosition_______________________________", strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[m].sitePosition );
                PPT_METHODTRACE_V2( "", "        historyRequiredFlag________________________", (CORBA::Long) strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[m].historyRequiredFlag );
                PPT_METHODTRACE_V2( "", "        calculationType____________________________", strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[m].calculationType );
                PPT_METHODTRACE_V2( "", "        calculationExpression______________________", strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[m].calculationExpression );
                PPT_METHODTRACE_V2( "", "        dataValue__________________________________", strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[m].dataValue );
                PPT_METHODTRACE_V2( "", "        targetValue________________________________", strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[m].targetValue );
                PPT_METHODTRACE_V2( "", "        specCheckResult____________________________", strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[m].specCheckResult );

                len5 = strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[m].actionCode.length();
                PPT_METHODTRACE_V2( "", "strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[m].actionCode.length----->", len5 );
                for ( n = 0; n < len5; n++ )
                {
                    PPT_METHODTRACE_V2( "", "        actionCode_________________________________", strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[m].actionCode[n] );
                }
            }

            PPT_METHODTRACE_V2( "", "      calculationRequiredFlag______________________", (CORBA::Long) strLotInCassette[j].strStartRecipe.strDCDef[k].calculationRequiredFlag );
            PPT_METHODTRACE_V2( "", "      specCheckRequiredFlag________________________", (CORBA::Long) strLotInCassette[j].strStartRecipe.strDCDef[k].specCheckRequiredFlag );
            PPT_METHODTRACE_V2( "", "      dataCollectionSpecificationID________________", strLotInCassette[j].strStartRecipe.strDCDef[k].dataCollectionSpecificationID.identifier );
            PPT_METHODTRACE_V2( "", "      previousDataCollectionDefinitionID___________", strLotInCassette[j].strStartRecipe.strDCDef[k].previousDataCollectionDefinitionID.identifier );
            PPT_METHODTRACE_V2( "", "      previousOperationID__________________________", strLotInCassette[j].strStartRecipe.strDCDef[k].previousOperationID.identifier );
            PPT_METHODTRACE_V2( "", "      previousOperationNumber______________________", strLotInCassette[j].strStartRecipe.strDCDef[k].previousOperationNumber );
        }
        PPT_METHODTRACE_V2( "", "  recipeParameterChangeType________________________", strLotInCassette[j].recipeParameterChangeType );

        len3 = strLotInCassette[j].strLotWafer.length();
        PPT_METHODTRACE_V2( "", "strLotInCassette[j].strLotWafer.length----->", len3 );
        for ( k = 0; k < len3; k++ )
        {
            PPT_METHODTRACE_V2( "", "    waferID________________________________________", strLotInCassette[j].strLotWafer[k].waferID.identifier );
            PPT_METHODTRACE_V2( "", "    slotNumber_____________________________________", strLotInCassette[j].strLotWafer[k].slotNumber );
            PPT_METHODTRACE_V2( "", "    controlWaferFlag_______________________________", (CORBA::Long) strLotInCassette[j].strLotWafer[k].controlWaferFlag );
            PPT_METHODTRACE_V2( "", "    processJobExecFlag_____________________________", (CORBA::Long) strLotInCassette[j].strLotWafer[k].processJobExecFlag );

            len4 = strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length();
            PPT_METHODTRACE_V2( "", "strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length----->", len4 );
            for ( m = 0; m < len4; m++ )
            {
                PPT_METHODTRACE_V2( "", "      parameterName________________________________", strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[m].parameterName );
                PPT_METHODTRACE_V2( "", "      parameterValue_______________________________", strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[m].parameterValue );
                PPT_METHODTRACE_V2( "", "      targetValue__________________________________", strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[m].targetValue );
                PPT_METHODTRACE_V2( "", "      useCurrentSettingValueFlag___________________", (CORBA::Long) strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[m].useCurrentSettingValueFlag );
            }
        }
        PPT_METHODTRACE_V2( "", "  productID________________________________________", strLotInCassette[j].productID.identifier );
        PPT_METHODTRACE_V2( "", "    routeID________________________________________", strLotInCassette[j].strStartOperationInfo.routeID.identifier );
        PPT_METHODTRACE_V2( "", "    operationID____________________________________", strLotInCassette[j].strStartOperationInfo.operationID.identifier );
        PPT_METHODTRACE_V2( "", "    operationNumber________________________________", strLotInCassette[j].strStartOperationInfo.operationNumber );
        PPT_METHODTRACE_V2( "", "    passCount______________________________________", strLotInCassette[j].strStartOperationInfo.passCount );
    }
*/

    PPT_METHODTRACE_V1( "", "****************************************************************************" );
}

