#ifndef lint
static char *sccsid =  "@(#) 1.2 superpos/src/spppt/source/posppt/pptmgr/objmethd/cs_controlJob_startReserveInformation_GetOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 3/10/08 18:17:20 [ 3/10/08 18:17:21 ]";
#endif
//
// (c) Copyright: IBM Taiwan Corporation, 2017, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_controlJob_startReserveInformation_GetOR.cpp
//

#include "cs_pptmgr.hpp"
#include "plot.hh"
#include "ppcope.hh"
#include "pctrlj.hh"
#include "pprmggl.hh"  //DSIV00000099
#include "pwafer.hh"  //INN-R170006
#include "pstage.hh"  //INN-R170006
#include "pperson.hh" //INN-R170006

//[Object Function Name]: long   controlJob_startReserveInformation_Get
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2000-08-01  0.00      Y.Iwasaki      Initial Release
// 2000-08-31  0.01      Y.Iwasaki      Change actionCodes set logic
// 2000-09-21  Q3000124  K.Matsuei      Nil Check
// 2000-09-25  P3000209  H.Ueda         Change logic when cassetteExchange was done.
// 2000-10-16  Q3000306  Y.Iwasaki      Bug fix for R-Parm set logic
// 2000/11/09  P2200204  R.Furuta       Initialize local pointers
// 2000/01/09  D3000116  K.Takikita     Changed For Structure(ProductID)
// 2001/09/27  P4000272  K.Matsuei      TCS can't do OpeStart.
// 2002/05/13  P4100425  K.Matsuei      The number of Parameters to assemble Message in PPT_SET_MSG_RC_KEY*** mistakes it.
// 2002/06/07  P4100522  H.Adachi       Add Dimension Length Check for wrong dimension access
// 2002/09/25  P4200192  H.Adachi       Add Nil Check
// 2003/09/08  P5000145  H.Adachi       Fix Message and Message Macro mismatch.
// 2006/02/06  D7000178  H.Adachi       Add reference condition for PO.
// 2006/09/25  D8000025  M.Kase         Add set dcSpecDescription and strDCSpec logic.
// 2007/06/01  D9000003  M.Nakano       Add set processJobExecFlag logic.
// 2008/03/10  P9000251  K.Matsuei      ControlJobID of the force-loaded Lot is not erased when StartReservationCancel is performed.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/15 DSIV00000099 F.Chen         SLM(Small Lot Manufacturing) Support.
// 2009/04/13 PSIV00000935 M.Ogawa        Set information on start operation.
// 2011/08/15 DSN000015229 Yang Xia       Disable this function for process job level control
// 2012/05/02 PSN000040375 Dawei Liang    Fix the fetching of wrong route id.
// 2014/05/13 DSN000085698 S.Wang         Support equipment monitor used count function
// 2015/07/07 PSN000099917 T.Ishida       Fix logic which judges whether it's CurrentPO or PreviousPO.
// 2017/02/13 DSN000104277 K.Yamaoku      Performance improvement(reference:lot_wafers_GetDR)
//
//
// Innotron Modification history :
// Date       Defect#        Person               Comments
// ---------- -------------- -------------------- -------------------------------------------
// 2017/10/03 INN-R170006    Sam Hsueh            initial, for Probe tester, get stage ID, CJ reserved person and wafer UData
//
//
//[Function Description]:
//
//  This object function fill the return structure's value by accessing PosControlJob
//  and related objects.
//
//  typedef struct pptStartCassette_struct {
//      long                          loadSequenceNumber;
//      objectIdentifier              cassetteID;
//      string                        loadPurposeType;
//      objectIdentifier              loadPortID;
//      objectIdentifier              unloadPortID;
//      sequence <pptLotInCassette>   strLotInCassette;
//  } pptStartLot;
//
//  typedef struct pptLotInCassette_struct
//      boolean                       operationStartFlag;
//      boolean                       monitorLotFlag;
//      objectIdentifier              lotID;
//      string                        lotType;
//      string                        subLotType;
//      pptStartRecipe                strStartRecipe;
//      string                        recipeParameterChangeType;
//      sequence <pptLotWafer>        strLotWafer;
//      pptStartOperationInfo         strStartOperationInfo;               //PSIV00000935
//  } pptLotInCassette;
//
//  typedef struct pptLotWafer_struct {
//      objectIdentifier              waferID;
//      long                          slotNumber;
//      boolean                       controlWaferFlag;
//      sequence <pptStartRecipeParameter> strStartRecipeParameter;
//  } pptLotWafer;
//
//  typedef struct pptStartRecipeParameter_struct {
//      string                        parameterName;
//      string                        parameterValue;
//      string                        targetValue;
//      boolean                       useCurrentSettingValueFlag;
//  } pptStartRecipeParameter;
//
//  typedef struct pptStartRecipe_struct {
//      objectIdentifier              logicalRecipeID;
//      objectIdentifier              machineRecipeID;
//      string                        physicalRecipeID;
//      sequence <pptStartReticle>    strStartReticle;
//      sequence <pptStartFixture>    strStartFixture;
//      boolean                       dataCollectioinFlag;
//      sequence <pptDCDef>           strDCDef;
//  } pptStartRecipe;
//
//  typedef struct pptStartReticle_struct {
//     long                           sequenceNumber;
//     objectIdentifier               reticleID;
//  } pptStartReticle;
//
//  typedef struct pptStartFixture_struct {
//     objectIdentifier               fixtureID;
//     string                         fixtureCategory;
//  } pptStartFixture;
//
//  typedef struct pptDCDef_struct {
//      objectIdentifier              dataCollectionDefinitionID;
//      string                        description;
//      string                        dataCollectionType;
//      sequence <pptDCItem>          strDCItem;
//      boolean                       calculationRequiredFlag;
//      boolean                       specCheckRequiredFlag;
//      objectIdentifier              dataCollectionSpecificationID;
//      objectIdentifier              previousDataCollectionDefinitionID;
//      objectIdentifier              previousOperationID;
//      string                        previousOperationNumber;
//  } pptDCDef;
//
//  typedef struct pptDCItem_struct {
//      string                        dataCollectionItemName;
//      string                        dataCollectionMode;
//      string                        dataCollectionUnit;
//      string                        dataType;
//      string                        itemType;
//      string                        measurementType;
//      objectIdentifier              waferID;
//      string                        waferPosition;
//      string                        sitePosition;
//      boolean                       historyRequiredFlag;
//      string                        calculationType;
//      string                        calculationExpression;
//      string                        dataValue;
//      string                        targetValue;
//      string                        specCheckResult;
//      stringSequence                actionCode;
//  } pptDCItem;
//
//  typedef struct pptStartOperationInfo_struct {                          //PSIV00000935
//      objectIdentifier              routeID;                             //PSIV00000935
//      objectIdentifier              operationID;                         //PSIV00000935
//      string                        operationNumber;                     //PSIV00000935
//      long                          passCount;                           //PSIV00000935
//  } pptStartOperationInfo;                                               //PSIV00000935
//
//[Input Parameters]:
//  in  pptObjCommonIn            strObjCommonIn;
//  in  objectIdentifier          controlJobID;
//
//[Output Parameters]:
//  out objControlJob_startReserveInformation_Get_out   strControlJob_startReserveInformation_Get_out;
//
//  typedef struct objControlJob_startReserveInformation_Get_out_struct {
//      pptRetCode                strResult;
//      objectIdentifier          equipmentID;
//      string                    portGroupID;
//      pptStartCassetteSequence  strStartCassette;
//  } objControlJob_startReserveInformation_Get_out;
//
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_NOT_FOUND_PO             MSG_NOT_FOUND_PO
//  RC_NOT_FOUND_LOT            MSG_NOT_FOUND_LOT
//  RC_LOCKED_BY_ANOTHER        MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR             MSG_SYSTEM_ERROR
//  RC_NOT_FOUND_EQP            MSG_NOT_FOUND_EQP
//  RC_NOT_FOUND_MCRECIPE       MSG_NOT_FOUND_MCRECIPE
//  RC_NOT_FOUND_LCRECIPE       MSG_NOT_FOUND_LCRECIPE
//  RC_NOT_FOUND_RETICLE        MSG_NOT_FOUND_RETICLE
//  RC_NOT_FOUND_FIXTURE        MSG_NOT_FOUND_FIXTURE
//  RC_NOT_FOUND_DCDEF          MSG_NOT_FOUND_DCDEF
//  RC_NOT_FOUND_PROCGRP        MSG_NOT_FOUND_PROCGRP

CORBA::Long CS_PPTManager_i::controlJob_startReserveInformation_Get(
                            objControlJob_startReserveInformation_Get_out& strControlJob_startReserveInformation_Get_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& controlJobID)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::controlJob_startReserveInformation_Get");
        PPT_METHODTRACE_V2( "","in-parm's controlJobID", controlJobID.identifier);

        /*----------------*/
        /*                */
        /*   Initialize   */
        /*                */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        /*---------------------------*/
        /*                           */
        /*   Get ControlJob Object   */
        /*                           */
        /*---------------------------*/
        PosControlJob_var aControlJob;
        PPT_CONVERT_CONTROLJOBID_TO_CONTROLJOB_OR(aControlJob,controlJobID,strControlJob_startReserveInformation_Get_out,controlJob_startReserveInformation_Get);

        /*---------------------------------*/
        /*                                 */
        /*   Get and Set ControlJob Info   */
        /*                                 */
        /*---------------------------------*/

        /*-------------------------*/
        /*   Get ControlJob Info   */
        /*-------------------------*/
        PosStartCassetteInfoSequence*     startCassetteInfoSeq = NULL; //P2200204
        PosStartCassetteInfoSequence_var  startCassetteInfoSeqVar;
        try
        {
            startCassetteInfoSeq    = aControlJob->getStartCassetteInfo();
            startCassetteInfoSeqVar = startCassetteInfoSeq;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosControlJob::getStartCassetteInfo);

        PosMachine_var aMachine;
        try
        {
            aMachine = aControlJob->getMachine();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosControlJob::getMachine);

        CORBA::Boolean    bCJMachineNil = FALSE;        //D7000178

        //P4200192 Add Start
        if (CORBA::is_nil(aMachine))
        {
            PPT_METHODTRACE_V1("", "aMachine is Nil");
//P5000145            SET_MSG_RC(strControlJob_startReserveInformation_Get_out, MSG_NOT_FOUND_EQP, RC_NOT_FOUND_EQP);
//D7000178            PPT_SET_MSG_RC_KEY(strControlJob_startReserveInformation_Get_out, MSG_NOT_FOUND_EQP, RC_NOT_FOUND_EQP, "*****");    //P5000145
//D7000178            return(RC_NOT_FOUND_EQP);
            bCJMachineNil = TRUE;    //D7000178
        }
        //P4200192 Add End

        //INN-R170006 add start
        PosPerson_var aCJOwner;
        try
        {
            aCJOwner = aControlJob->getOwner();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosControlJob::getOwner);
        //INN-R170006 add end
//D7000178 add start
        //---------------------------------------------- ----------------------------
        //  Get PortGroup from aMachine.
        //  If CJ exists but does not have EQP, it means that EQP is removed from CJ.
        //  So, getting PortGroup and allCassettes are skiped.
        //---------------------------------------------------------------------------
        PosMachineCassetteSequence* strMachineCassetteSeq = NULL;
        PosMachineCassetteSequence_var castSeqVar;

        if ( bCJMachineNil == FALSE )
        {
            PPT_METHODTRACE_V1("", "aMachine is not Nil");    //D7000178 Add End and Following logics are nested.

            CORBA::String_var portGroup;
            try
            {
                portGroup = aControlJob->getPortGroup();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosControlJob::getPortGroup);

//P4000272 start
            PPT_METHODTRACE_V1("", "aMachine->allCassettes");
//D7000178            PosMachineCassetteSequence* strMachineCassetteSeq = NULL;
//D7000178            PosMachineCassetteSequence_var castSeqVar;
            try
            {
                strMachineCassetteSeq = aMachine->allCassettes();
                castSeqVar            = strMachineCassetteSeq;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosMachine::allCassettes)
//P4000272 end

            /*-----------------------------------------------*/
            /*   Set ControlJob Info into Return Structure   */
            /*-----------------------------------------------*/
            PPT_SET_OBJECT_IDENTIFIER(strControlJob_startReserveInformation_Get_out.equipmentID,aMachine,strControlJob_startReserveInformation_Get_out,controlJob_startReserveInformation_Get,PosMachine);
            strControlJob_startReserveInformation_Get_out.portGroupID = portGroup;

        }
//D7000178 add end

        CORBA::Long castLen;
        castLen = startCassetteInfoSeq->length();

//DSIV00000099 Add Start
        /* -----------------------------------------------------------------------------------------*/
        // Ceate startCassette from controlJob lot for SLM
        // By SLM function, lot is allowed to be cut relation from startCassette while processing
        // CAUTION: the startCassette could be created with blank cassetteID
        /* -----------------------------------------------------------------------------------------*/

        PosLotInControlJobInfoSequence_var strLotInControlJobInfoSeq;
        strLotInControlJobInfoSeq = aControlJob->allControlJobLots();

        CORBA::Boolean lotNotInCastFlag = FALSE;

        for (CORBA::ULong nCnt1=0 ; nCnt1<strLotInControlJobInfoSeq->length() ; nCnt1++)
        {
            PPT_METHODTRACE_V3("", "# Loop[nCnt1], lotID = ", nCnt1, (*strLotInControlJobInfoSeq)[nCnt1].lotID.identifier);
            lotNotInCastFlag = TRUE;
            for (CORBA::ULong nCnt2=0 ; nCnt2<castLen ; nCnt2++)
            {
                PPT_METHODTRACE_V3("", "## Loop[nCnt2], cassetteID = ", nCnt2, (*startCassetteInfoSeq)[nCnt2].cassetteID.identifier);
                for (CORBA::ULong nCnt3=0 ; nCnt3<(*startCassetteInfoSeq)[nCnt2].lotInCassetteInfo.length() ; nCnt3++)
                {
                    PPT_METHODTRACE_V3("", "### Loop[nCnt3], lotID = ", nCnt3, (*startCassetteInfoSeq)[nCnt2].lotInCassetteInfo[nCnt3].lotID.identifier);
                    if (CIMFWStrCmp((*startCassetteInfoSeq)[nCnt2].lotInCassetteInfo[nCnt3].lotID.identifier,
                                    (*strLotInControlJobInfoSeq)[nCnt1].lotID.identifier) == 0)
                    {
                        PPT_METHODTRACE_V2("", "### Found lot in cassette, lotID ", (*startCassetteInfoSeq)[nCnt2].lotInCassetteInfo[nCnt3].lotID.identifier);
                        lotNotInCastFlag = FALSE;
                        break;
                    }
                }
                if (lotNotInCastFlag == FALSE)
                {
                    PPT_METHODTRACE_V1("", "## lotNotInCastFlag = TRUE, break");
                    break;
                }
            } // loop for castLen
            if (lotNotInCastFlag == TRUE)
            {
                PPT_METHODTRACE_V1("", "# lotNotInCastFlag = TRUE, add to startCassette");
                // create startCassette from this lot
                CORBA::ULong tmpCastLen = startCassetteInfoSeq->length();
                startCassetteInfoSeq->length(tmpCastLen+1);

                posStartCassetteInfo tmpStartCassetteInfo;
                objectIdentifier dummyID;
                dummyID.identifier = CIMFWStrDup("");

                tmpStartCassetteInfo.loadSequenceNumber = 0;
                tmpStartCassetteInfo.cassetteID         = dummyID;
                tmpStartCassetteInfo.loadPurposeType    = CIMFWStrDup("");
                tmpStartCassetteInfo.loadPortID         = dummyID;
                tmpStartCassetteInfo.unloadPortID       = dummyID;

                posLotInCassetteInfo tmpLotInCassette;
                tmpLotInCassette.operationStartFlag = TRUE;
                tmpLotInCassette.monitorLotFlag     = (*strLotInControlJobInfoSeq)[nCnt1].monitorLotFlag;
                tmpLotInCassette.lotID              = (*strLotInControlJobInfoSeq)[nCnt1].lotID;

                tmpStartCassetteInfo.lotInCassetteInfo.length(1);
                tmpStartCassetteInfo.lotInCassetteInfo[0] = tmpLotInCassette;

                (*startCassetteInfoSeq)[tmpCastLen] = tmpStartCassetteInfo;

            } // lotNotInCastFlag = true

        } // loop for strLotInControlJobInfoSeq

        castLen = startCassetteInfoSeq->length();
        PPT_METHODTRACE_V2("", "castLen", castLen);
//DSIV00000099 Add End

        strControlJob_startReserveInformation_Get_out.strStartCassette.length(castLen);

        for (CORBA::Long i=0 ; i<castLen ; i++)
        {
            PPT_METHODTRACE_V3("", "loop to startCassetteInfoSeq->length()",castLen,i);
            strControlJob_startReserveInformation_Get_out.strStartCassette[i].loadSequenceNumber = (*startCassetteInfoSeq)[i].loadSequenceNumber;
            strControlJob_startReserveInformation_Get_out.strStartCassette[i].cassetteID         = (*startCassetteInfoSeq)[i].cassetteID;
            strControlJob_startReserveInformation_Get_out.strStartCassette[i].loadPurposeType    = (*startCassetteInfoSeq)[i].loadPurposeType;
            strControlJob_startReserveInformation_Get_out.strStartCassette[i].loadPortID         = (*startCassetteInfoSeq)[i].loadPortID;
            strControlJob_startReserveInformation_Get_out.strStartCassette[i].unloadPortID       = (*startCassetteInfoSeq)[i].unloadPortID;

//D7000178 add start
            //-----------------------------------------------------------------------------------------------------
            //  Get unloadPortID.
            //  If bCJMachineNil is FALSE, it means that OpeComp is finished and Cassettes might be taken from EQP.
            //  So, following logics are skiped.
            //-----------------------------------------------------------------------------------------------------
            if ( bCJMachineNil == FALSE )
            {                                    //D7000178 Add End and Following logics are nested.
//P4000272 start
                CORBA::Long lenMacCas = strMachineCassetteSeq->length();
                PPT_METHODTRACE_V2("", "strMachineCassetteSeq->length", lenMacCas);
                for (CORBA::Long k=0 ; k < lenMacCas; k++ )
                {
                    if ( 0 == CIMFWStrCmp((*strMachineCassetteSeq)[k].cassetteID.identifier, (*startCassetteInfoSeq)[i].cassetteID.identifier) )
                    {
                        PPT_METHODTRACE_V2("", "Found!! unloadPortID", (*strMachineCassetteSeq)[k].unloadPortID.identifier);
                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].unloadPortID = (*strMachineCassetteSeq)[k].unloadPortID;
                        break;
                    }
                }
//P4000272 end
            }
//D7000178 add end

            CORBA::Long lotLen;
            lotLen = (*startCassetteInfoSeq)[i].lotInCassetteInfo.length();
            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette.length(lotLen);
//P3000209
//          /*-------------------------*/
//          /*   Omit Empty Cassette   */
//          /*-------------------------*/
//          CORBA::String_var loadPurposeType = strControlJob_startReserveInformation_Get_out.strStartCassette[i].loadPurposeType;
//          if (CIMFWStrCmp(loadPurposeType,SP_LoadPurposeType_EmptyCassette) == 0)
//          {
//              PPT_METHODTRACE_V1("CS_PPTManager_i::controlJob_startReserveInformation_Get", "loadPurposeType == SP_LoadPurposeType_EmptyCassette");
//              continue;
//P3000209  }

            /*-------------------------*/
            /*   Set Lot Information   */
            /*-------------------------*/
            for (CORBA::Long j=0 ; j<lotLen ; j++)
            {
                PPT_METHODTRACE_V3("", "loop to (*startCassetteInfoSeq)[i].lotInCassetteInfo.length()",lotLen,j);
                strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].operationStartFlag = (*startCassetteInfoSeq)[i].lotInCassetteInfo[j].operationStartFlag;
                strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].monitorLotFlag     = (*startCassetteInfoSeq)[i].lotInCassetteInfo[j].monitorLotFlag;
                strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID              = (*startCassetteInfoSeq)[i].lotInCassetteInfo[j].lotID;

                /*--------------------*/
                /*   Get Wafer Info   */
                /*--------------------*/
//DSN000015229                  objLot_wafers_GetDR_out strLot_wafers_GetDR_out;
//DSN000015229                  objLot_wafers_GetDR_in  strInParm ;
//DSN000015229                  strInParm.lotID          = strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID;
//DSN000015229                  strInParm.scrapCheckFlag = TRUE;   //omit scrapped wafer
//DSN000015229
//DSN000015229                  rc = lot_wafers_GetDR(strLot_wafers_GetDR_out,strObjCommonIn,strInParm);
//DSN000015229                  if(rc != RC_OK)
//DSN000015229                  {
//DSN000015229                      PPT_METHODTRACE_V1("", "lot_wafers_GetDR() != RC_OK");
//DSN000015229                      strControlJob_startReserveInformation_Get_out.strResult = strLot_wafers_GetDR_out.strResult;
//DSN000015229                      return(rc);
//DSN000015229                  }
//DSN000015229 Add Start
//DSN000085698                const pptLotWaferAttributesSequence *pLotWaferAttributesSequence = NULL;
                const pptLotWaferAttributesSequence__150 *pLotWaferAttributesSequence = NULL;   //DSN000085698
//DSN000104277//DSN000085698                objLot_wafers_GetDR_out strLot_wafers_GetDR_out;
//DSN000104277                objLot_wafers_GetDR_out__150 strLot_wafers_GetDR_out;   //DSN000085698
                pptLotWaferAttributesSequence__150 strLotWaferAttributesSequence;     //DSN000104277
                objLot_materials_GetWafers_out strLot_materials_GetWafers_out;
                if ( 0 == CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC015" )    //TxPartialOpeCompWithDataReq
                  || 0 == CIMFWStrCmp( strObjCommonIn.transactionID , "TXEWC016" ) )  //TxPartialOpeCompForInternalBufferReq
                {
                    PPT_METHODTRACE_V1("", "call lot_materials_GetWafers()");
                    rc = lot_materials_GetWafers( strLot_materials_GetWafers_out, strObjCommonIn, strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID);

                    if ( rc != RC_OK )
                    {
                        //Set Result;
                        PPT_METHODTRACE_V2("", "##### lot_materials_GetWafers() != RC_OK", rc);
                        strControlJob_startReserveInformation_Get_out.strResult = strLot_materials_GetWafers_out.strResult;
                        return( rc );
                    }
//DSN000085698                    pLotWaferAttributesSequence = (const pptLotWaferAttributesSequence*)&strLot_materials_GetWafers_out.strLotWaferAttributes;
                    pLotWaferAttributesSequence = (const pptLotWaferAttributesSequence__150*)&strLot_materials_GetWafers_out.strLotWaferAttributes;     //DSN000085698
                }
                else
                {
//DSN000104277                    objLot_wafers_GetDR_in  strInParm ;
//DSN000104277                    strInParm.lotID          = strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID;
//DSN000104277                    strInParm.scrapCheckFlag = TRUE;   //omit scrapped wafer
//DSN000104277
//DSN000104277//DSN000085698                    rc = lot_wafers_GetDR(strLot_wafers_GetDR_out,strObjCommonIn,strInParm);
//DSN000104277                    rc = lot_wafers_GetDR__150(strLot_wafers_GetDR_out,strObjCommonIn,strInParm);    //DSN000085698
//DSN000104277                    if(rc != RC_OK)
//DSN000104277                    {
//DSN000104277//DSN000085698                        PPT_METHODTRACE_V1("", "lot_wafers_GetDR() != RC_OK");
//DSN000104277                        PPT_METHODTRACE_V1("", "lot_wafers_GetDR__150() != RC_OK");  //DSN000085698
//DSN000104277                        strControlJob_startReserveInformation_Get_out.strResult = strLot_wafers_GetDR_out.strResult;
//DSN000104277                        return(rc);
//DSN000104277                    }
//DSN000104277//DSN000085698                    pLotWaferAttributesSequence = (const pptLotWaferAttributesSequence*)&strLot_wafers_GetDR_out.strLotWaferAttributes;
//DSN000104277                    pLotWaferAttributesSequence = (const pptLotWaferAttributesSequence__150*)&strLot_wafers_GetDR_out.strLotWaferAttributes; //DSN000085698
//DSN000104277                }
//DSN000104277//DSN000085698                const pptLotWaferAttributesSequence &strLotWaferAttributes = *pLotWaferAttributesSequence;
//DSN000104277 add start
                    objLot_waferInfoList_GetDR_out strLot_waferInfoList_GetDR_out;
                    objLot_waferInfoList_GetDR_in  strLot_waferInfoList_GetDR_in;
                    strLot_waferInfoList_GetDR_in.lotID          = strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID;
                    strLot_waferInfoList_GetDR_in.scrapCheckFlag = TRUE; //omit scrapped wafer
                    rc = lot_waferInfoList_GetDR( strLot_waferInfoList_GetDR_out, strObjCommonIn, strLot_waferInfoList_GetDR_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "##### lot_waferInfoList_GetDR() != RC_OK", rc);
                        strControlJob_startReserveInformation_Get_out.strResult = strLot_waferInfoList_GetDR_out.strResult;
                        return( rc );
                    }
                    CORBA::ULong lotWaferLen = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes.length();
                    strLotWaferAttributesSequence.length(lotWaferLen);
                    for (CORBA::ULong lotWaferIdx = 0; lotWaferIdx < lotWaferLen; lotWaferIdx++ )
                    {
                        strLotWaferAttributesSequence[lotWaferIdx].waferID             = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[lotWaferIdx].waferID;
                        strLotWaferAttributesSequence[lotWaferIdx].cassetteID          = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[lotWaferIdx].cassetteID;
                        strLotWaferAttributesSequence[lotWaferIdx].aliasWaferName      = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[lotWaferIdx].aliasWaferName;
                        strLotWaferAttributesSequence[lotWaferIdx].slotNumber          = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[lotWaferIdx].slotNumber;
                        strLotWaferAttributesSequence[lotWaferIdx].productID           = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[lotWaferIdx].productID;
                        strLotWaferAttributesSequence[lotWaferIdx].grossUnitCount      = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[lotWaferIdx].grossUnitCount;
                        strLotWaferAttributesSequence[lotWaferIdx].goodUnitCount       = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[lotWaferIdx].goodUnitCount;
                        strLotWaferAttributesSequence[lotWaferIdx].repairUnitCount     = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[lotWaferIdx].repairUnitCount;
                        strLotWaferAttributesSequence[lotWaferIdx].failUnitCount       = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[lotWaferIdx].failUnitCount;
                        strLotWaferAttributesSequence[lotWaferIdx].controlWaferFlag    = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[lotWaferIdx].controlWaferFlag;
                        strLotWaferAttributesSequence[lotWaferIdx].STBAllocFlag        = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[lotWaferIdx].STBAllocFlag;
                        strLotWaferAttributesSequence[lotWaferIdx].reworkCount         = 0;
                        strLotWaferAttributesSequence[lotWaferIdx].eqpMonitorUsedCount = strLot_waferInfoList_GetDR_out.strLotWaferInfoAttributes[lotWaferIdx].eqpMonitorUsedCount;
                    }
                    pLotWaferAttributesSequence = (const pptLotWaferAttributesSequence__150*)&strLotWaferAttributesSequence;
                }
//DSN000104277 add end
                const pptLotWaferAttributesSequence__150 &strLotWaferAttributes = *pLotWaferAttributesSequence;     //DSN000085698
//DSN000015229 Add End

                CORBA::Long wfrLen;
//DSN000015229                  wfrLen = strLot_wafers_GetDR_out.strLotWaferAttributes.length();
                wfrLen = strLotWaferAttributes.length(); //DSN000015229
                strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer.length(wfrLen);

                if ( wfrLen > 0 )                                                                                                //P4100522
                {                                                                                                                //P4100522
                    for (CORBA::Long w=0 ; w<wfrLen ; w++ )
                    {
//DSN000015229                          PPT_METHODTRACE_V3("", "loop to strLot_wafers_GetDR_out.strLotWaferAttributes.length()",wfrLen,w);
                        PPT_METHODTRACE_V3("", "loop to strLotWaferAttributes.length()",wfrLen,w); //DSN000015229

//DSN000015229                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[w].waferID          = strLot_wafers_GetDR_out.strLotWaferAttributes[w].waferID;
//DSN000015229                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[w].slotNumber       = strLot_wafers_GetDR_out.strLotWaferAttributes[w].slotNumber;
//DSN000015229                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[w].controlWaferFlag = strLot_wafers_GetDR_out.strLotWaferAttributes[w].controlWaferFlag;

                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[w].waferID          = strLotWaferAttributes[w].waferID;          //DSN000015229
                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[w].slotNumber       = strLotWaferAttributes[w].slotNumber;       //DSN000015229
                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[w].controlWaferFlag = strLotWaferAttributes[w].controlWaferFlag; //DSN000015229
                    }

                    /*------------------------------------------*/                                                               //D3000116
                    /*   Get ProductID from LotWaferAttributs   */                                                               //D3000116
                    /*------------------------------------------*/                                                               //D3000116
                    PPT_METHODTRACE_V1("", "Set ProductID");                 //D3000116
//DSN000015229                      strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].productID              //D3000116
//DSN000015229                                                      = strLot_wafers_GetDR_out.strLotWaferAttributes[0].productID;                //D3000116
//DSN000015229 Add Start
                    strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].productID              //D3000116
                                                    = strLotWaferAttributes[0].productID;
//DSN000015229 Add End


                    PPT_METHODTRACE_V2( "",                                   //D3000116
                                        "ProductID",                                                                              //D3000116
                                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].productID.identifier);                   //D3000116

                }                                                                                                                 //P4100522
                /*---------------------------------*/
                /*   Omit Not OperationStart Lot   */
                /*---------------------------------*/
                CORBA::Boolean operationStartFlag = strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].operationStartFlag;
                if (operationStartFlag  == FALSE)
                {
                    PPT_METHODTRACE_V1("", "operationStartFlag  == FALSE");
                    continue;
                }

                /*--------------------------*/
                /*   Get Lot Related Info   */
                /*--------------------------*/
                PosLot_var aLot;
                PPT_CONVERT_LOTID_TO_LOT_OR(aLot, strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID, strControlJob_startReserveInformation_Get_out , controlJob_startReserveInformation_Get);

                ProcessOperation_var aPO;
                PosProcessOperation_var aPosPO;

//D7000178                try
//D7000178                {
//D7000178                    aPO = aLot->getProcessOperation();
//D7000178                    aPosPO = PosProcessOperation::_narrow(aPO);
//D7000178                }
//D7000178                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation);

//D7000178 add start
                //------------------------------------------
                // Current PO or Previous PO ?
                //------------------------------------------
//PSN000099917                objLot_CheckConditionForPO_out strLot_CheckConditionForPO_out;
//PSN000099917                rc = lot_CheckConditionForPO( strLot_CheckConditionForPO_out, strObjCommonIn,
//PSN000099917                                              strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID);
//PSN000099917                if ( rc != RC_OK )
//PSN000099917                {
//PSN000099917                    PPT_METHODTRACE_V1("", "lot_CheckConditionForPO() != RC_OK ") ;
//PSN000099917                    strControlJob_startReserveInformation_Get_out.strResult = strLot_CheckConditionForPO_out.strResult ;
//PSN000099917                    return( rc );
//PSN000099917                }

//PSN000099917                if ( strLot_CheckConditionForPO_out.currentPOFlag == TRUE )

//PSN000099917 Add Start
                objLot_CheckConditionForPOByControlJob_in  strLot_CheckConditionForPOByControlJob_in;
                objLot_CheckConditionForPOByControlJob_out strLot_CheckConditionForPOByControlJob_out;

                strLot_CheckConditionForPOByControlJob_in.lotID        = strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID;
                strLot_CheckConditionForPOByControlJob_in.controlJobID = controlJobID;

                rc = lot_CheckConditionForPOByControlJob( strLot_CheckConditionForPOByControlJob_out,
                                                          strObjCommonIn,
                                                          strLot_CheckConditionForPOByControlJob_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1( "", "lot_CheckConditionForPOByControlJob() != RC_OK" );
                    strControlJob_startReserveInformation_Get_out.strResult = strLot_CheckConditionForPOByControlJob_out.strResult ;
                    return( rc );
                }

                if ( strLot_CheckConditionForPOByControlJob_out.currentPOFlag == TRUE )
//PSN000099917 Add End
                {
                    //--------------------------------------------------------------------------
                    // Get PO from Current Operation.
                    //--------------------------------------------------------------------------
                    PPT_METHODTRACE_V1("", "Get PO from the current Operation." )

                    try
                    {
                        aPO = aLot->getProcessOperation();
                        aPosPO = PosProcessOperation::_narrow(aPO);
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation);
                }
                else
                {
                    //--------------------------------------------------------------------------
                    // Get PO from Previous Operation.
                    //--------------------------------------------------------------------------
                    PPT_METHODTRACE_V1("", "Get PO from the previous Operation.")

                    try
                    {
                        aPO = aLot->getPreviousProcessOperation();
                        aPosPO = PosProcessOperation::_narrow(aPO);
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosLot::getPreviousProcessOperation);
                }
//D7000178 add end

//Q3000124 start
                if ( CORBA::is_nil(aPosPO) )
                {
//P4100425                    PPT_SET_MSG_RC_KEY( strCassette_multiLotType_Update_out, MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO, "" );
//P4100425 start
                    PPT_SET_MSG_RC_KEY2( strControlJob_startReserveInformation_Get_out,
                                         MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO,
                                         "", strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID.identifier );
//P4100425 end
                    return( RC_NOT_FOUND_PO );
                }
//Q3000124 end

                posActualStartInformationForPO_var actualStartInfo;
                try
                {
                    actualStartInfo = aPosPO->getActualStartInfo();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getActualStartInfo);

//PSIV00000935 start
                //--------------------------//
                //   RouteID                //
                //--------------------------//
                PosProcessDefinition_var aMainPD;
                try
                {
//PSN000040375                    aMainPD = aLot->getMainProcessDefinition();
                    aMainPD = aPosPO->getMainProcessDefinition();                             //PSN000040375
                }
//PSN000040375                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getMainProcessDefinition)
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getMainProcessDefinition)     //PSN000040375

                if ( CORBA::is_nil(aMainPD) )
                {
                    PPT_METHODTRACE_V1("", "aMainPD is nil");
                    PPT_SET_MSG_RC_KEY( strControlJob_startReserveInformation_Get_out,
                                        MSG_NOT_FOUND_ROUTE, RC_NOT_FOUND_ROUTE,  "" );
                    return RC_NOT_FOUND_ROUTE;
                }

                PPT_SET_OBJECT_IDENTIFIER( strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID,
                                           aMainPD,
                                           strControlJob_startReserveInformation_Get_out,
                                           controlJob_startReserveInformation_Get,
                                           PosProcessDefinition );
                PPT_METHODTRACE_V2("", "routeID", strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID.identifier);

                //--------------------------//
                //   PDID                   //
                //--------------------------//
                PosProcessDefinition_var aPD;
                try
                {
                    aPD = aPosPO->getProcessDefinition();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getProcessDefinition)

                if ( CORBA::is_nil(aPD) )
                {
                    PPT_METHODTRACE_V1("", "aPD is nil");
                    PPT_SET_MSG_RC_KEY( strControlJob_startReserveInformation_Get_out,
                                        MSG_NOT_FOUND_PD, RC_NOT_FOUND_PD, "" );
                    return RC_NOT_FOUND_PD;
                }

                PPT_SET_OBJECT_IDENTIFIER( strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationID,
                                           aPD,
                                           strControlJob_startReserveInformation_Get_out,
                                           controlJob_startReserveInformation_Get,
                                           PosProcessDefinition );
                PPT_METHODTRACE_V2("", "operationID", strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationID.identifier);

                //--------------------------//
                //   OperationNumber        //
                //--------------------------//
                try
                {
                    strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber = aPosPO->getOperationNumber();
                    PPT_METHODTRACE_V2("", "operationNumber", strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getOperationNumber)

                //--------------------------//
                //   PassCount              //
                //--------------------------//
                try
                {
                    strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.passCount = aPosPO->getPassCount();
                    PPT_METHODTRACE_V2("", "passCount", strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartOperationInfo.passCount);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getPassCount)
//PSIV00000935 end

                /*===== set Lot Info =====*/
                try
                {
                    strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotType = aLot->getLotType();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotType);
                try
                {
                    strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].subLotType = aLot->getSubLotType();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getSubLotType);

//D9000003 add start
                //------------------------------------------
                // Get sampled waferIDs on PO
                //------------------------------------------
                PPT_METHODTRACE_V1("", "Get sampled waferIDs on PO.")
                stringSequence assignedSamplingWafers;
                assignedSamplingWafers = actualStartInfo->assignedSamplingWafers;

                /*===== set processJobExecFlag Info =====*/
                if( assignedSamplingWafers.length() > 0 )
                {
                    PPT_METHODTRACE_V1("", " assignedSamplingWafers.length() > 0 ")
                    CORBA::Long waferLen = strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                    for(CORBA::Long waferCnt = 0; waferCnt < waferLen; waferCnt++)
                    {
                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[waferCnt].processJobExecFlag == FALSE;
                    }

                    CORBA::Boolean lackWaferFlag = FALSE;
                    CORBA::Boolean matchWaferFlag = FALSE;
                    CORBA::Long sampledWaferLen = assignedSamplingWafers.length();
                    for (CORBA::Long sampledWaferCnt = 0; sampledWaferCnt < sampledWaferLen; sampledWaferCnt++)
                    {
                        matchWaferFlag = FALSE;
                        for(CORBA::Long waferCnt = 0; waferCnt < waferLen; waferCnt++)
                        {
                            if( !CIMFWStrCmp(assignedSamplingWafers[sampledWaferCnt],
                                    strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[waferCnt].waferID.identifier))
                            {
                                strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[waferCnt].processJobExecFlag = TRUE;
                                matchWaferFlag = TRUE;
                                break;
                            }
                        }
                        if( matchWaferFlag == FALSE)
                        {
                            lackWaferFlag = TRUE;
                            break;
                        }
                    }

                    if ( lackWaferFlag == TRUE)
                    {
                        PPT_METHODTRACE_V1("", " lackWaferFlag == TRUE ")
                        SET_MSG_RC( strControlJob_startReserveInformation_Get_out,
                                         MSG_LACK_OF_SMPL_WAFER, RC_LACK_OF_SMPL_WAFER);
                        return RC_LACK_OF_SMPL_WAFER;
                    }
                }
                else  //When no wafers are found , it is not wafer sampling operation. all wafers are to be started.
                {
                    PPT_METHODTRACE_V1("", " assignedSamplingWafers.length() == 0 ")
                    CORBA::Long waferLen = strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                    for(CORBA::Long waferCnt = 0; waferCnt < waferLen; waferCnt++)
                    {
                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[waferCnt].processJobExecFlag = TRUE;
                    }
                }
//D9000003 add end

                /*===== set Recipe Info =====*/
                strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].recipeParameterChangeType         = actualStartInfo->assignedRecipeParameterChangeType;
                strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.logicalRecipeID    = actualStartInfo->assignedLogicalRecipe;
                strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.machineRecipeID    = actualStartInfo->assignedMachineRecipe;
                strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.physicalRecipeID   = actualStartInfo->assignedPhysicalRecipe;
                strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.dataCollectionFlag = actualStartInfo->assignedDataCollectionFlag;

                /*===== set Reticle Info =====*/
                CORBA::Long rtclLen;
                rtclLen = actualStartInfo->assignedReticles.length();
                strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle.length(rtclLen);

                for (CORBA::Long rr=0 ; rr<rtclLen ; rr++)
                {
                    PPT_METHODTRACE_V3("", "loop to actualStartInfo->assignedReticles.length()",rtclLen,rr);
                    strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[rr].sequenceNumber = actualStartInfo->assignedReticles[rr].sequenceNumber;
                    strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartReticle[rr].reticleID      = actualStartInfo->assignedReticles[rr].reticleID;
                }

                /*===== set Fixture Info =====*/
                CORBA::Long fixtLen;
                fixtLen = actualStartInfo->assignedFixtures.length();
                strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture.length(fixtLen);

                for (CORBA::Long ff=0 ; ff<fixtLen ; ff++)
                {
                    PPT_METHODTRACE_V3("", "loop to actualStartInfo->assignedFixtures.length()",fixtLen,ff);
                    strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture[ff].fixtureID       = actualStartInfo->assignedFixtures[ff].fixtureID;
                    strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strStartFixture[ff].fixtureCategory = actualStartInfo->assignedFixtures[ff].fixtureCategory;
                }

                //INN-R170006 add start
                PPT_METHODTRACE_V2("", "fixtLen", fixtLen);
                if ( 0 < fixtLen )
                {
                    csLotInCassette_siInfo strLotInCassette_siInfo;
                    PPT_METHODTRACE("");
                    PosStage_var aStage;
                    try
                    {
                        aStage = aPosPO->getStage();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getStage);

                    PPT_METHODTRACE("");
                    if ( !CORBA::is_nil( aStage ) )
                    {
                        PPT_METHODTRACE("");
                        strLotInCassette_siInfo.stageID = aStage->getIdentifier();
                    }
                    PPT_METHODTRACE_V3("", "stageID", strLotInCassette_siInfo.stageID, strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID.identifier);

                    if ( !CORBA::is_nil(aCJOwner) )
                    {
                        PPT_METHODTRACE("");
                        try
                        {
                            strLotInCassette_siInfo.CJReserveUserID = aCJOwner->getIdentifier();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosPerson::getIdentifier)
                    }
                    PPT_METHODTRACE_V2("", "CJReserveUserID", strLotInCassette_siInfo.CJReserveUserID);
                    strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].siInfo <<= strLotInCassette_siInfo;

                    for (CORBA::Long iw=0; iw < wfrLen; iw++)
                    {
                        PPT_METHODTRACE_V4("", "loop to strLotWaferAttributes.length()", wfrLen, iw, strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[iw].waferID.identifier);

                        csLotWafer_siInfo strLotWafer_siInfo;
                        PosWafer_var aWafer;
                        PPT_CONVERT_WAFERID_TO_WAFER_OR( aWafer,
                                                         strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[iw].waferID,
                                                         strControlJob_startReserveInformation_Get_out,
                                                         controlJob_startReserveInformation_Get );

                        SI_PPT_USERDATA_GET_INTEGER(aWafer, CS_M_WAFER_FixtureTouchCount, strLotWafer_siInfo.touchCountByFixture);
                        PPT_METHODTRACE_V2("", "touchCountByFixture", strLotWafer_siInfo.touchCountByFixture);

                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[iw].siInfo <<= strLotWafer_siInfo;
                    }

                }
                //INN-R170006 add end

                /*===== set Recipe Parameter Info =====*/
                CORBA::Long rpsetLen;
                rpsetLen = actualStartInfo->assignedRecipeParameterSets.length();

                CORBA::Long rparmLen;

//Q3000306 add start
                if ( rpsetLen == 1 )
                {
                    PPT_METHODTRACE_V1("", "rpsetLen == 1");
                    rparmLen = actualStartInfo->assignedRecipeParameterSets[0].recipeParameters.length();
                    PPT_METHODTRACE_V2("", "actualStartInfo->assignedRecipeParameterSets[0].recipeParameters.length--->", rparmLen);

                    if ( rparmLen == 1 )
                    {
                        PPT_METHODTRACE_V1("", "rparmLen == 1");

                        if ( CIMFWStrLen(actualStartInfo->assignedRecipeParameterSets[0].recipeParameters[0].parameterName ) == 0 &&
                             CIMFWStrLen(actualStartInfo->assignedRecipeParameterSets[0].recipeParameters[0].parameterValue) == 0 &&
                             CIMFWStrLen(actualStartInfo->assignedRecipeParameterSets[0].recipeParameters[0].targetValue   ) == 0 )
                        {
                            PPT_METHODTRACE_V1("", "set rpsetLen = 0");
                            rpsetLen = 0;
                        }
                    }
                }
//Q3000306 add end

                if (rpsetLen > 0)
                {
                    PPT_METHODTRACE_V1("", "actualStartInfo->assignedRecipeParameterSets.length() > 0");
                    rparmLen = actualStartInfo->assignedRecipeParameterSets[0].recipeParameters.length();

//P4100522                    for (w=0 ; w<wfrLen ; w++)
                   for (CORBA::Long w=0 ; w<wfrLen ; w++)                                                              //P4100522
                   {
//DSN000015229                          PPT_METHODTRACE_V3("", "loop to strLot_wafers_GetDR_out.strLotWaferAttributes.length()",wfrLen,w);
                        PPT_METHODTRACE_V3("", "loop to strLotWaferAttributes.length()",wfrLen,w); //DSN000015229

                        if (CIMFWStrCmp(actualStartInfo->assignedRecipeParameterChangeType,SP_Rparm_ChangeType_ByLot) == 0)
                        {
                            PPT_METHODTRACE_V1("", "actualStartInfo->recipeParameterChangeType == SP_Rparm_ChangeType_ByLot");
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter.length(rparmLen);
                            for (CORBA::Long rp=0 ; rp<rparmLen ; rp++ )
                            {
                                PPT_METHODTRACE_V3("", "loop to actualStartInfo->assignedRecipeParameterSets[0].recipeParameters.length()",rparmLen,rp);
                                strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter[rp].parameterName              = actualStartInfo->assignedRecipeParameterSets[0].recipeParameters[rp].parameterName;
                                strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter[rp].parameterValue             = actualStartInfo->assignedRecipeParameterSets[0].recipeParameters[rp].parameterValue;
                                strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter[rp].targetValue                = actualStartInfo->assignedRecipeParameterSets[0].recipeParameters[rp].targetValue;
                                strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter[rp].useCurrentSettingValueFlag = actualStartInfo->assignedRecipeParameterSets[0].recipeParameters[rp].useCurrentSettingValueFlag;
                            }
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", "actualStartInfo->recipeParameterChangeType != SP_Rparm_ChangeType_ByLot");
                            for (CORBA::Long rs=0 ; rs<rpsetLen ; rs++ )
                            {
                                PPT_METHODTRACE_V3("", "loop to actualStartInfo->assignedRecipeParameterSets.length()",rpsetLen,rs);
                                if (CIMFWStrCmp(strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[w].waferID.identifier,
                                                actualStartInfo->assignedRecipeParameterSets[rs].applyWafers[0].waferID.identifier) == 0)
                                {
                                    PPT_METHODTRACE_V1("", "strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[w].waferID.identifier == actualStartInfo->assignedRecipeParameterSets[rs].applyWafers[0].waferID");
                                    strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter.length(rparmLen);
                                    for (CORBA::Long rp=0 ; rp<rparmLen ; rp++ )
                                    {
                                        PPT_METHODTRACE_V3("", "loop to actualStartInfo->assignedRecipeParameterSets[0].recipeParameters.length()",rparmLen,rp);
                                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter[rp].parameterName              = actualStartInfo->assignedRecipeParameterSets[rs].recipeParameters[rp].parameterName;
                                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter[rp].parameterValue             = actualStartInfo->assignedRecipeParameterSets[rs].recipeParameters[rp].parameterValue;
                                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter[rp].targetValue                = actualStartInfo->assignedRecipeParameterSets[rs].recipeParameters[rp].targetValue;
                                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strLotWafer[w].strStartRecipeParameter[rp].useCurrentSettingValueFlag = actualStartInfo->assignedRecipeParameterSets[rs].recipeParameters[rp].useCurrentSettingValueFlag;
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }

                /*===== set Data Collection Info =====*/
                if (actualStartInfo->assignedDataCollectionFlag == TRUE)
                {
                    PPT_METHODTRACE_V1("", "actualStartInfo->assignedDataCollectionFlag == TRUE");
                    CORBA::Long dcLen;
                    dcLen = actualStartInfo->assignedDataCollections.length();
                    strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef.length(dcLen);

                    for (CORBA::Long dc=0 ; dc<dcLen ; dc++)
                    {
                        PPT_METHODTRACE_V3("", "loop to actualStartInfo->assignedDataCollections.length()",dcLen,dc);
                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].dataCollectionDefinitionID         = actualStartInfo->assignedDataCollections[dc].dataCollectionDefinitionID;
                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].description                        = actualStartInfo->assignedDataCollections[dc].description;
                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].dataCollectionType                 = actualStartInfo->assignedDataCollections[dc].dataCollectionType;
                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].calculationRequiredFlag            = actualStartInfo->assignedDataCollections[dc].calculationRequiredFlag;
                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].specCheckRequiredFlag              = actualStartInfo->assignedDataCollections[dc].specCheckRequiredFlag;
                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].dataCollectionSpecificationID      = actualStartInfo->assignedDataCollections[dc].dataCollectionSpecificationID;
                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].dcSpecDescription                  = actualStartInfo->assignedDataCollections[dc].dcSpecDescription;    //D8000025
                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].previousDataCollectionDefinitionID = actualStartInfo->assignedDataCollections[dc].previousDataCollectionDefinitionID;
                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].previousOperationID                = actualStartInfo->assignedDataCollections[dc].previousOperationID;
                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].previousOperationNumber            = actualStartInfo->assignedDataCollections[dc].previousOperationNumber;

                        CORBA::Long itemLen;
                        itemLen = actualStartInfo->assignedDataCollections[dc].dcItems.length();
                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem.length(itemLen);

                        for (CORBA::Long it=0 ; it<itemLen ; it++)
                        {
                            PPT_METHODTRACE_V3("", "loop to actualStartInfo->assignedDataCollections[dc].dcItems.length()",itemLen,it);
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].dataCollectionItemName = actualStartInfo->assignedDataCollections[dc].dcItems[it].dataCollectionItemName;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].dataCollectionMode     = actualStartInfo->assignedDataCollections[dc].dcItems[it].dataCollectionMode;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].dataCollectionUnit     = actualStartInfo->assignedDataCollections[dc].dcItems[it].dataCollectionUnit;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].dataType               = actualStartInfo->assignedDataCollections[dc].dcItems[it].dataType;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].itemType               = actualStartInfo->assignedDataCollections[dc].dcItems[it].itemType;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].measurementType        = actualStartInfo->assignedDataCollections[dc].dcItems[it].measurementType;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].waferID                = actualStartInfo->assignedDataCollections[dc].dcItems[it].waferID;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].waferPosition          = actualStartInfo->assignedDataCollections[dc].dcItems[it].waferPosition;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].sitePosition           = actualStartInfo->assignedDataCollections[dc].dcItems[it].sitePosition;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].historyRequiredFlag    = actualStartInfo->assignedDataCollections[dc].dcItems[it].historyRequiredFlag;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].calculationType        = actualStartInfo->assignedDataCollections[dc].dcItems[it].calculationType;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].calculationExpression  = actualStartInfo->assignedDataCollections[dc].dcItems[it].calculationExpression;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].dataValue              = actualStartInfo->assignedDataCollections[dc].dcItems[it].dataValue;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].targetValue            = actualStartInfo->assignedDataCollections[dc].dcItems[it].targetValue;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].specCheckResult        = actualStartInfo->assignedDataCollections[dc].dcItems[it].specCheckResult;
//0.01                      strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].actionCode.length(0);
                            //0.01 add start
                            /*---------------------*/
                            /*   Set actionCodes   */
                            /*---------------------*/
                            CORBA::Long actCodesBuffSize = CIMFWStrLen(actualStartInfo->assignedDataCollections[dc].dcItems[it].actionCodes);
                            if (actCodesBuffSize == 0)
                            {
                                PPT_METHODTRACE_V1( "","CIMFWStrLen(actualStartInfo.assignedDataCollections[dc].dcItems[it].actionCodes) == 0");
                                strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].actionCode.length(0);
                            }
                            else
                            {
                                PPT_METHODTRACE_V1( "","CIMFWStrLen(actualStartInfo.assignedDataCollections[dc].dcItems[it].actionCodes) != 0");

                                char tmpActCodes[1024];
                                CIMFWStrCpy(&tmpActCodes[0],actualStartInfo->assignedDataCollections[dc].dcItems[it].actionCodes);

                                char *startPos = &tmpActCodes[0];
                                char *endPos   = &tmpActCodes[0];

                                CORBA::Long ActCodeDataNum;
                                for(ActCodeDataNum=0 ; endPos!=NULL ; ActCodeDataNum++)
                                {
                                    PPT_METHODTRACE_V2( "","loop to search ActionCodesDataNum", (ActCodeDataNum+1));
                                    endPos = strstr(startPos,SP_PosDataCollection_String_Seperator_Char);
                                    if (endPos != NULL)
                                    {
                                        PPT_METHODTRACE_V1( "","SP_PosDataCollection_String_Seperator_Char == actionCodes");
                                       *endPos = '\0';
                                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].actionCode.length(ActCodeDataNum+1);
                                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].actionCode[ActCodeDataNum] = CIMFWStrDup(startPos);
                                        startPos = endPos+1;
                                    }
                                    else
                                    {
                                        PPT_METHODTRACE_V1( "","SP_PosDataCollection_String_Seperator_Char != actionCodes");
                                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].actionCode.length(ActCodeDataNum+1);
                                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCItem[it].actionCode[ActCodeDataNum] = CIMFWStrDup(startPos);
                                   }
                                }
                            }
                            //0.01 add end
                        }

//D8000025 add start
                        CORBA::Long specLen = actualStartInfo->assignedDataCollections[dc].dcSpecs.length();
                        strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec.length(specLen);

                        for (CORBA::Long sp=0 ; sp<specLen ; sp++)
                        {
                            PPT_METHODTRACE_V3("", "loop to actualStartInfo->assignedDataCollections[dc].dcSpecs.length()", specLen, sp);
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].dataItemName              = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].dataItemName;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].screenLimitUpperRequired  = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].screenLimitUpperRequired;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].screenLimitUpper          = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].screenLimitUpper;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].actionCodes_uscrn         = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].actionCodes_uscrn;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].screenLimitLowerRequired  = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].screenLimitLowerRequired;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].screenLimitLower          = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].screenLimitLower;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].actionCodes_lscrn         = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].actionCodes_lscrn;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].specLimitUpperRequired    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].specLimitUpperRequired;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].specLimitUpper            = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].specLimitUpper;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].actionCodes_usl           = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].actionCodes_usl;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].specLimitLowerRequired    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].specLimitLowerRequired;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].specLimitLower            = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].specLimitLower;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].actionCodes_lsl           = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].actionCodes_lsl;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].controlLimitUpperRequired = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].controlLimitUpperRequired;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].controlLimitUpper         = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].controlLimitUpper;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].actionCodes_ucl           = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].actionCodes_ucl;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].controlLimitLowerRequired = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].controlLimitLowerRequired;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].controlLimitLower         = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].controlLimitLower;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].actionCodes_lcl           = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].actionCodes_lcl;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].target                    = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].target;
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[dc].strDCSpec[sp].tag                       = actualStartInfo->assignedDataCollections[dc].dcSpecs[sp].tag;
                        }
//D8000025 add end
                    }
                }
            }         //end j-loop
        }             //end i-loop

//P9000251 start
        // When ForceLoad is performed, all OpeStartFlag are changed to FALSE.
        // So OpeStartFlag is revived only when ForceLoad is performed.

        if ( 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC042")    // TxStartLotsReservationCancelReq
          || 0 == CIMFWStrCmp(strObjCommonIn.transactionID, "TXTRC057") )  // TxStartLotsReservationCancelForInternalBufferReq
        {
            PPT_METHODTRACE_V1("", "transactionID is TXTRC042(StartRsvCancel) or TXTRC057(StartRsvCancelForIB)");

            // Check OpeStartFlags condition.
            // If all OpeStartFlags are OFF, It is judged that ForceLoad was performed.
            CORBA::Boolean bNeedToAssignOpeStaFlag = TRUE;
            CORBA::Long casLen = strControlJob_startReserveInformation_Get_out.strStartCassette.length();
            for ( i=0; i < casLen; i++ )
            {
                CORBA::Long lotLen = strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette.length();
                for ( CORBA::Long j=0; j < lotLen; j++ )
                {
                    if ( strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].operationStartFlag )
                    {
                        bNeedToAssignOpeStaFlag = FALSE;
                        break;
                    }
                }
                if ( TRUE != bNeedToAssignOpeStaFlag )
                {
                    break;
                }
            }
            PPT_METHODTRACE_V2("", "bNeedToAssignOpeStaFlag", (int)bNeedToAssignOpeStaFlag);

            // Only when ForceLoad was performed, OpeStartFlag is revived.
            if ( TRUE == bNeedToAssignOpeStaFlag )
            {
                for ( i=0; i < casLen; i++ )
                {
                    CORBA::Long lotLen = strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette.length();
                    for ( CORBA::Long j=0; j < lotLen; j++ )
                    {
                        PPT_METHODTRACE_V2("", "lotID", strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID.identifier);

                        objLot_controlJobID_Get_out strLot_controlJobID_Get_out;
                        rc = lot_controlJobID_Get( strLot_controlJobID_Get_out, strObjCommonIn,
                                                   strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].lotID );
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "##### lot_controlJobID_Get() != RC_OK", rc);
                            strControlJob_startReserveInformation_Get_out.strResult = strLot_controlJobID_Get_out.strResult;
                            return( rc );
                        }
                        PPT_METHODTRACE_V2("", "ControlJobID", strLot_controlJobID_Get_out.controlJobID.identifier);

                        if ( 0 < CIMFWStrLen(strLot_controlJobID_Get_out.controlJobID.identifier) )
                        {
                            PPT_METHODTRACE_V1("", "Change OpeStartFlag to TRUE.");
                            strControlJob_startReserveInformation_Get_out.strStartCassette[i].strLotInCassette[j].operationStartFlag = TRUE;
                        }
                    }
                }
            }
        }
//P9000251 end

        CORBA::Long SCLength;
        SCLength = strControlJob_startReserveInformation_Get_out.strStartCassette.length();
        for (CORBA::Long sc=0 ; sc<SCLength ; sc++)
        {
            PPT_METHODTRACE_V3("", "strStartCassette[sc].loadSequenceNumber...", strControlJob_startReserveInformation_Get_out.strStartCassette[sc].loadSequenceNumber, sc);
            PPT_METHODTRACE_V3("", "strStartCassette[sc].cassetteID...........", strControlJob_startReserveInformation_Get_out.strStartCassette[sc].cassetteID.identifier, sc);
            PPT_METHODTRACE_V3("", "strStartCassette[sc].loadPurposeType......", strControlJob_startReserveInformation_Get_out.strStartCassette[sc].loadPurposeType, sc);
            PPT_METHODTRACE_V3("", "strStartCassette[sc].loadPortID...........", strControlJob_startReserveInformation_Get_out.strStartCassette[sc].loadPortID.identifier, sc);
            PPT_METHODTRACE_V3("", "strStartCassette[sc].unloadPortID.........", strControlJob_startReserveInformation_Get_out.strStartCassette[sc].unloadPortID.identifier, sc);

            CORBA::Long LICLength;
            LICLength = strControlJob_startReserveInformation_Get_out.strStartCassette[sc].strLotInCassette.length();
            for (CORBA::Long sl=0 ; sl<LICLength ; sl++)
            {
                pptLotInCassette strLotInCassette;
                strLotInCassette = strControlJob_startReserveInformation_Get_out.strStartCassette[sc].strLotInCassette[sl];

                PPT_METHODTRACE_V3("", "strLotInCassette[sl].operationStartFlag..................", (strLotInCassette.operationStartFlag ? "True" : "False"), sl);
                PPT_METHODTRACE_V3("", "strLotInCassette[sl].monitorLotFlag......................", (strLotInCassette.monitorLotFlag ? "True" : "False"), sl);
                PPT_METHODTRACE_V3("", "strLotInCassette[sl].lotID...............................", strLotInCassette.lotID.identifier, sl);
                PPT_METHODTRACE_V3("", "strLotInCassette[sl].lotType.............................", strLotInCassette.lotType, sl);
                PPT_METHODTRACE_V3("", "strLotInCassette[sl].subLotType..........................", strLotInCassette.subLotType, sl);
                PPT_METHODTRACE_V3("", "strLotInCassette[sl].recipeParameterChangeType...........", strLotInCassette.recipeParameterChangeType, sl);
                PPT_METHODTRACE_V3("", "strLotInCassette[sl].strStartRecipe.logicalRecipeID......", strLotInCassette.strStartRecipe.logicalRecipeID.identifier, sl);
                PPT_METHODTRACE_V3("", "strLotInCassette[sl].strStartRecipe.machineRecipeID......", strLotInCassette.strStartRecipe.machineRecipeID.identifier, sl);
                PPT_METHODTRACE_V3("", "strLotInCassette[sl].strStartRecipe.physicalRecipeID.....", strLotInCassette.strStartRecipe.physicalRecipeID, sl);
                PPT_METHODTRACE_V3("", "strLotInCassette[sl].strStartRecipe.dataCollectionFlag...", (strLotInCassette.strStartRecipe.dataCollectionFlag ? "True" : "False"), sl);

                CORBA::Long LWLength;
                LWLength = strLotInCassette.strLotWafer.length();
                for (CORBA::Long sw=0 ; sw<LWLength ; sw++ )
                {
                    PPT_METHODTRACE_V3("", "strLotInCassette.strLotWafer[sw].waferID............", strLotInCassette.strLotWafer[sw].waferID.identifier, sw);
                    PPT_METHODTRACE_V3("", "strLotInCassette.strLotWafer[sw].slotNumber.........", strLotInCassette.strLotWafer[sw].slotNumber, sw);
                    PPT_METHODTRACE_V3("", "strLotInCassette.strLotWafer[sw].controlWaferFlag...", (strLotInCassette.strLotWafer[sw].controlWaferFlag ? "True" : "False"), sw);


                    CORBA::Long SRPLength;
                    SRPLength = strLotInCassette.strLotWafer[sw].strStartRecipeParameter.length();
                    for (CORBA::Long srp=0 ; srp<SRPLength ; srp++ )
                    {
                        PPT_METHODTRACE_V3("", "strStartRecipeParameter[srp].parameterName................",strLotInCassette.strLotWafer[sw].strStartRecipeParameter[srp].parameterName, srp);
                        PPT_METHODTRACE_V3("", "strStartRecipeParameter[srp].parameterValue...............",strLotInCassette.strLotWafer[sw].strStartRecipeParameter[srp].parameterValue, srp);
                        PPT_METHODTRACE_V3("", "strStartRecipeParameter[srp].targetValue..................",strLotInCassette.strLotWafer[sw].strStartRecipeParameter[srp].targetValue, srp);
                        PPT_METHODTRACE_V3("", "strStartRecipeParameter[srp].useCurrentSettingValueFlag...", (strLotInCassette.strLotWafer[sw].strStartRecipeParameter[srp].useCurrentSettingValueFlag ? "True" : "False"), srp);
                    }

                }

                CORBA::Long SRLength;
                SRLength = strLotInCassette.strStartRecipe.strStartReticle.length();
                for (CORBA::Long sr=0 ; sr<SRLength ; sr++)
                {
                    PPT_METHODTRACE_V3("", "strStartReticle[sr].sequenceNumber....", strLotInCassette.strStartRecipe.strStartReticle[sr].sequenceNumber, sr);
                    PPT_METHODTRACE_V3("", "strStartReticle[sr].reticleID.........", strLotInCassette.strStartRecipe.strStartReticle[sr].reticleID.identifier, sr);
                }

                CORBA::Long SFLength;
                SFLength = strLotInCassette.strStartRecipe.strStartFixture.length();
                for (CORBA::Long sf=0 ; sf<SFLength ; sf++)
                {
                    PPT_METHODTRACE_V3("", "strStartFixture[sf].fixtureID.........", strLotInCassette.strStartRecipe.strStartFixture[sf].fixtureID.identifier, sf);
                    PPT_METHODTRACE_V3("", "strStartFixture[sf].fixtureCategory...", strLotInCassette.strStartRecipe.strStartFixture[sf].fixtureCategory, sf);
                }


                pptDCDef strDCDef;
                CORBA::Long DCLength;
                DCLength = strLotInCassette.strStartRecipe.strDCDef.length();
                for (CORBA::Long sdc=0 ; sdc<DCLength ; sdc++)
                {
                    strDCDef = strLotInCassette.strStartRecipe.strDCDef[sdc];

                    PPT_METHODTRACE_V3("", "strDCDef[sdc].dataCollectionDefinitionID..........", strDCDef.dataCollectionDefinitionID.identifier, sdc);
                    PPT_METHODTRACE_V3("", "strDCDef[sdc].description.........................", strDCDef.description, sdc);
                    PPT_METHODTRACE_V3("", "strDCDef[sdc].dataCollectionType..................", strDCDef.dataCollectionType, sdc);
                    PPT_METHODTRACE_V3("", "strDCDef[sdc].calculationRequiredFlag.............", (strDCDef.calculationRequiredFlag ? "True" : "False"), sdc);
                    PPT_METHODTRACE_V3("", "strDCDef[sdc].specCheckRequiredFlag...............", (strDCDef.specCheckRequiredFlag ? "True" : "False"), sdc);
                    PPT_METHODTRACE_V3("", "strDCDef[sdc].dataCollectionSpecificationID.......", strDCDef.dataCollectionSpecificationID.identifier, sdc);
                    PPT_METHODTRACE_V3("", "strDCDef[sdc].dcSpecDescription...................", strDCDef.dcSpecDescription, sdc);    //D8000025
                    PPT_METHODTRACE_V3("", "strDCDef[sdc].previousDataCollectionDefinitionID..", strDCDef.previousDataCollectionDefinitionID.identifier, sdc);
                    PPT_METHODTRACE_V3("", "strDCDef[sdc].previousOperationID.................", strDCDef.previousOperationID.identifier, sdc);
                    PPT_METHODTRACE_V3("", "strDCDef[sdc].previousOperationNumber.............", strDCDef.previousOperationNumber, sdc);

                    CORBA::Long DCLength;
                    DCLength = strDCDef.strDCItem.length();
                    for (CORBA::Long sdi=0 ; sdi<DCLength ; sdi++)
                    {
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].dataCollectionItemName...", strDCDef.strDCItem[sdi].dataCollectionItemName, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].dataCollectionMode.......", strDCDef.strDCItem[sdi].dataCollectionMode, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].dataCollectionUnit.......", strDCDef.strDCItem[sdi].dataCollectionUnit, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].dataType.................", strDCDef.strDCItem[sdi].dataType, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].itemType.................", strDCDef.strDCItem[sdi].itemType, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].measurementType..........", strDCDef.strDCItem[sdi].measurementType, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].waferID..................", strDCDef.strDCItem[sdi].waferID.identifier, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].waferPosition............", strDCDef.strDCItem[sdi].waferPosition, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].sitePosition.............", strDCDef.strDCItem[sdi].sitePosition, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].historyRequiredFlag......", (strDCDef.strDCItem[sdi].historyRequiredFlag ? "True" : "False"), sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].calculationType..........", strDCDef.strDCItem[sdi].calculationType, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].calculationExpression....", strDCDef.strDCItem[sdi].calculationExpression, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].dataValue................", strDCDef.strDCItem[sdi].dataValue, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].targetValue..............", strDCDef.strDCItem[sdi].targetValue, sdi);
                        PPT_METHODTRACE_V3("", "strDCItem[sdi].specCheckResult..........", strDCDef.strDCItem[sdi].specCheckResult, sdi);

                        CORBA::Long ActCodeLength;
                        ActCodeLength = strDCDef.strDCItem[sdi].actionCode.length();
                        for(CORBA::Long acd=0 ; acd<ActCodeLength ; acd++)
                        {
                            PPT_METHODTRACE_V3("", "strDCItem[sdi].actionCode[acd]..........", strDCDef.strDCItem[sdi].actionCode[acd], acd);
                        }
                    }

//D8000025 add start
                    CORBA::Long DCSLength = strDCDef.strDCSpec.length();
                    for (CORBA::Long sds=0 ; sds<DCSLength ; sds++)
                    {
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].dataItemName................", strDCDef.strDCSpec[sds].dataItemName, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].screenLimitUpperRequired....", (strDCDef.strDCSpec[sds].screenLimitUpperRequired ? "True" : "False"), sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].screenLimitUpper............", strDCDef.strDCSpec[sds].screenLimitUpper, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].actionCodes_uscrn...........", strDCDef.strDCSpec[sds].actionCodes_uscrn, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].screenLimitLowerRequired....", (strDCDef.strDCSpec[sds].screenLimitLowerRequired ? "True" : "False"), sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].screenLimitLower............", strDCDef.strDCSpec[sds].screenLimitLower, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].actionCodes_lscrn...........", strDCDef.strDCSpec[sds].actionCodes_lscrn, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].specLimitUpperRequired......", (strDCDef.strDCSpec[sds].specLimitUpperRequired ? "True" : "False"), sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].specLimitUpper..............", strDCDef.strDCSpec[sds].specLimitUpper, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].actionCodes_usl.............", strDCDef.strDCSpec[sds].actionCodes_usl, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].specLimitLowerRequired......", (strDCDef.strDCSpec[sds].specLimitLowerRequired ? "True" : "False"), sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].specLimitLower..............", strDCDef.strDCSpec[sds].specLimitLower, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].actionCodes_lsl.............", strDCDef.strDCSpec[sds].actionCodes_lsl, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].controlLimitUpperRequired...", (strDCDef.strDCSpec[sds].controlLimitUpperRequired ? "True" : "False"), sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].controlLimitUpper...........", strDCDef.strDCSpec[sds].controlLimitUpper, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].actionCodes_ucl.............", strDCDef.strDCSpec[sds].actionCodes_ucl, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].controlLimitLowerRequired...", (strDCDef.strDCSpec[sds].controlLimitLowerRequired ? "True" : "False"), sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].controlLimitLower...........", strDCDef.strDCSpec[sds].controlLimitLower, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].actionCodes_lcl.............", strDCDef.strDCSpec[sds].actionCodes_lcl, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].target......................", strDCDef.strDCSpec[sds].target, sds);
                        PPT_METHODTRACE_V3("", "strDCSpec[sds].tag.........................", strDCDef.strDCSpec[sds].tag, sds);
                    }
//D8000025 add end
                }
            }
        }

        /*----------------------*/
        /*                      */
        /*   Return to Caller   */
        /*                      */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::controlJob_startReserveInformation_Get");
        return( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS(strControlJob_startReserveInformation_Get_out, controlJob_startReserveInformation_Get, methodName);
}

