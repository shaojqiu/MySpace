#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/lotType_lotID_Assign.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:58:53 [ 7/13/07 19:58:54 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: lotType_lotID_Assign.cpp
//

//INN-R170001 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp"//INN-R170001

#include "pprsp.hh"
#include "plot.hh"
#include "plottype.hh"
#include "time.h"   //INN-R170001
// Class: PPTManager
//
// Service: lotType_lotID_Assign()
//
// Change history: 
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2002/02/05 D4100108 C.Tsuchiya     Initial Release
//
// Description: 
// 
// Return: 
//     Long
//
//[Function Description]:
//
//
//[Input Parameters]:
//  const  pptObjCommonIn&           strObjCommonIn;
//  const  string                    lotType;
//  const  objectIdentifier&         productID;
//  const  string                    subLotType;
//
//[Output Parameters]:
//
//  out objLotType_lotID_Assign_out  strLotType_lotID_Assign_out;
//
//  typedef struct objLotType_lotID_Assign_out_struct {
//     pptRetCode           strResult;
//     string               assignedLotID;
//  } objLotType_lotID_Assign_out;
//
//
// Require: 
//
// Ensure:
//
// Exception: 
// 
// Pseudo code: 
// 
// Innotron Modification history :
// Date         Defect#         Person          Comments
// ----------   ------------    --------------  -------------------------------------------
// 2017/09/22   INN-R170001     Vera Chen       Lot ID naming rule    
//
//
//

//INN-R170001 CORBA::Long CS_PPTManager_i::lotType_lotID_Assign(
CORBA::Long CS_PPTManager_i::lotType_lotID_Assign(  //INN-R170001
                        objLotType_lotID_Assign_out& strLotType_lotID_Assign_out,
                        const pptObjCommonIn& strObjCommonIn,
                        const char * lotType,
                        const objectIdentifier& productID,
                        const char * subLotType) 
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::lotType_lotID_Assign")
        CORBA::Long rc = RC_OK;//INN-R170001
        //-----------------------------------------------------
        // get object reference of Product Spec.
        // this ID must be given from input parameter
        //-----------------------------------------------------
        PPT_METHODTRACE_V2("CS_PPTManager_i::lotType_lotID_Assign","get object reference of Product Spec", __LINE__);

        PosProductSpecification_var aProductSpecification;
        PPT_CONVERT_PRODUCTID_TO_PRODUCTSP_OR( aProductSpecification,
                                               productID,
                                               strLotType_lotID_Assign_out,
                                               lotType_lotID_Assign );

        //-----------------------------------------------------
        // get lotType 
        //-----------------------------------------------------
        PPT_METHODTRACE_V2("CS_PPTManager_i::lotType_lotID_Assign","get lotType", __LINE__);

        PosLotType_var aPosLotType;
        try
        {
            aPosLotType = theProductManager->findLotTypeNamed(lotType);
        }
        CATCH_AND_RAISE_EXCEPTIONS(ProductManager::findLotTypeNamed)

        if ( CORBA::is_nil( aPosLotType ) )                      
        {                                                  
            PPT_SET_MSG_RC_KEY( strLotType_lotID_Assign_out,
                                MSG_NOT_FOUND_LOTTYPE,
                                RC_NOT_FOUND_LOTTYPE,
                                "" );
            return RC_NOT_FOUND_LOTTYPE;
        }                                                 

        //-----------------------------------------------------
        // assign new Lot ID
        //-----------------------------------------------------
        PPT_METHODTRACE_V2("CS_PPTManager_i::lotType_lotID_Assign","assign new Lot ID", __LINE__);

//INN-R170001        try
//INN-R170001        {
//INN-R170001            strLotType_lotID_Assign_out.assignedLotID = aPosLotType->nextIdentifier(aProductSpecification, subLotType);
//INN-R170001        }
//INN-R170001        CATCH_AND_RAISE_EXCEPTIONS(PosLotType::nextIdentifier)

//INN-R170001 Add start
        
        PosSubLotTypeSequence* aPosSubLotTypeSeq = NULL;
        PosSubLotTypeSequence_var aPosSubLotTypeSeqVar;
        try
        {
            aPosSubLotTypeSeq = aPosLotType->allSubLotTypes();
            aPosSubLotTypeSeqVar = aPosSubLotTypeSeq;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLotType::allSubLotTypes)

        CORBA::Long lenSubLotTypeSeq = aPosSubLotTypeSeq->length();
        CORBA::String_var varLeadingChar = CIMFWStrDup("");
        PPT_METHODTRACE_V2("CS_PPTManager_i::lotType_lotID_Assign","aPosSubLotTypeSeq->length", lenSubLotTypeSeq);

        for ( CORBA::Long j=0; j < lenSubLotTypeSeq; j++ )
        {
            if(CIMFWStrCmp(subLotType,(*aPosSubLotTypeSeq)[j].subLotType) == 0)
            {
                varLeadingChar = CIMFWStrDup((*aPosSubLotTypeSeq)[j].leadingCharacter);
                PPT_METHODTRACE_V2("CS_PPTManager_i::lotType_lotID_Assign","Get Leading Char", varLeadingChar);
                break;
            }
        }
        
        char currentYear[5];
        memset(currentYear,'\0', sizeof(currentYear));
        CIMFWStrnCpy( currentYear , strObjCommonIn.strTimeStamp.reportTimeStamp , 4 );        

        PPT_METHODTRACE_V2("CS_PPTManager_i::lotType_lotID_Assign", "currentYear", currentYear);
        PPT_METHODTRACE_V2("CS_PPTManager_i::lotType_lotID_Assign", "currentYear[3]", currentYear[3]);
        char table[]   = "0123456789ACDEFGHJKLMNPQRSTWXY";
        
        
        csObjLotID_ControlInfo_GetDR_out        strObjLotID_ControlInfo_GetDR_out;
        csObjLotID_ControlInfo_GetDR_in         strObjLotID_ControlInfo_GetDR_in;
        strObjLotID_ControlInfo_GetDR_in.leadingChar = CIMFWStrDup(varLeadingChar);
        strObjLotID_ControlInfo_GetDR_in.year = CIMFWStrDup(currentYear);
        
        rc = cs_lotID_ControlInfo_GetDR(    strObjLotID_ControlInfo_GetDR_out,
                                            strObjCommonIn,
                                            strObjLotID_ControlInfo_GetDR_in);
        if(rc != RC_OK && rc != CS_RC_LOTIDCTRL_NOT_FOUND)
        {
            PPT_METHODTRACE_V2("","cs_lotID_ControlInfo_GetDR != RC_OK", rc);
            strLotType_lotID_Assign_out.strResult = strObjLotID_ControlInfo_GetDR_out.strResult;
            return rc;
        }
        else if (rc == CS_RC_LOTIDCTRL_NOT_FOUND)
        {
            csObjLotID_ControlInfo_AddDR_out    strObjLotID_ControlInfo_AddDR_out;
            csObjLotID_ControlInfo_AddDR_in     strObjLotID_ControlInfo_AddDR_in;
            strObjLotID_ControlInfo_AddDR_in.leadingChar    =CIMFWStrDup(varLeadingChar);
            strObjLotID_ControlInfo_AddDR_in.lastUsedNumber =1;
            strObjLotID_ControlInfo_AddDR_in.year   = CIMFWStrDup(currentYear);
            char sub[2];
            memset(sub,'\0', sizeof(sub));
            CIMFWStrnCpy(sub,&table[0],1);
            strObjLotID_ControlInfo_AddDR_in.subChar   = CIMFWStrDup(sub);
            
            
            rc = cs_lotID_ControlInfo_AddDR(    strObjLotID_ControlInfo_AddDR_out,
                                                strObjCommonIn,
                                                strObjLotID_ControlInfo_AddDR_in);
            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V2("","cs_lotID_ControlInfo_AddDR != RC_OK", rc);
                strLotType_lotID_Assign_out.strResult = strObjLotID_ControlInfo_AddDR_out.strResult;
                return rc;
            }

            char chrLotID[13];
            memset( chrLotID, '\0', sizeof(chrLotID));
            sprintf(chrLotID,"%s%s%s%05d.00",(const char *)varLeadingChar,&currentYear[3],(const char *)strObjLotID_ControlInfo_AddDR_in.subChar,strObjLotID_ControlInfo_AddDR_in.lastUsedNumber);
            strLotType_lotID_Assign_out.assignedLotID = CIMFWStrDup(chrLotID);
            
        }
        
        if(CIMFWStrLen(strObjLotID_ControlInfo_GetDR_out.leadingChar) > 0)
        {
            csObjLotID_ControlInfo_SetDR_out    strObjLotID_ControlInfo_SetDR_out;
            csObjLotID_ControlInfo_SetDR_in     strObjLotID_ControlInfo_SetDR_in;
            strObjLotID_ControlInfo_SetDR_in.leadingChar = strObjLotID_ControlInfo_GetDR_out.leadingChar;
            strObjLotID_ControlInfo_SetDR_in.year        = strObjLotID_ControlInfo_GetDR_out.year;
            strObjLotID_ControlInfo_SetDR_in.subChar     = strObjLotID_ControlInfo_GetDR_out.subChar;
            
            CORBA::Long len = CIMFWStrLen(table);
            if(strObjLotID_ControlInfo_GetDR_out.lastUsedNumber == 99999)
            {
                PPT_METHODTRACE_V1("","lastUsedNumber == 99999");
                strObjLotID_ControlInfo_SetDR_in.lastUsedNumber        = 1;
                for(CORBA::Long i = 0 ; i < len ;i++)
                {
                    if(CIMFWStrCmp(strObjLotID_ControlInfo_GetDR_out.subChar,&table[i]) == 0)
                    {
                        char sub[2];
                        memset(sub,'\0', sizeof(sub));
                        
                        if(i+1 < len)
                        {
                            CIMFWStrnCpy(sub,&table[i+1],1);
                            strObjLotID_ControlInfo_SetDR_in.subChar = CIMFWStrDup(sub);
                            PPT_METHODTRACE_V2("","next char...break", strObjLotID_ControlInfo_SetDR_in.subChar);
                            break;
                        }
                        else
                        {
                            CIMFWStrnCpy(sub,&table[0],1);
                            strObjLotID_ControlInfo_SetDR_in.subChar = CIMFWStrDup(sub);
                            PPT_METHODTRACE_V2("","next char...break", strObjLotID_ControlInfo_SetDR_in.subChar);
                            break;
                        }                            
                    }
                }               
            }
            else
            {
                strObjLotID_ControlInfo_SetDR_in.lastUsedNumber = strObjLotID_ControlInfo_GetDR_out.lastUsedNumber+1;
            }

            rc = cs_lotID_ControlInfo_SetDR(strObjLotID_ControlInfo_SetDR_out,
                                            strObjCommonIn,
                                            strObjLotID_ControlInfo_SetDR_in);
            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V2("","cs_lotID_ControlInfo_SetDR != RC_OK", rc);
                strLotType_lotID_Assign_out.strResult = strObjLotID_ControlInfo_SetDR_out.strResult;
                return rc;
            }
            char chrLotID[13];
            memset( chrLotID, '\0', sizeof(chrLotID));
            sprintf(chrLotID,"%s%s%s%05d.00",(const char *)varLeadingChar,&currentYear[3],(const char *)strObjLotID_ControlInfo_SetDR_in.subChar,strObjLotID_ControlInfo_SetDR_in.lastUsedNumber);
            strLotType_lotID_Assign_out.assignedLotID = CIMFWStrDup(chrLotID);
        }
        
//INN-R170001 Add end

        PPT_METHODTRACE_V2("","gotten new Lot ID", strLotType_lotID_Assign_out.assignedLotID);

        //-------------------------------------
        // return to caller
        //-------------------------------------
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::lotType_lotID_Assign")

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strLotType_lotID_Assign_out, lotType_lotID_Assign_out, methodName)
}
