//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_lot_udata_CopyToChild.cpp
//
#include "cs_pptmgr.hpp"

#include "plot.hh"
// Class: CS_PPTManager
//
// Service: cs_lot_udata_CopyToChild()
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------  -------------- -------------------------------------------
// 2017-09-07 INN-R170002   JQ.Shao        Contamination control 
//
//[Function Description]:
//
//
//[Input Parameters]:
//  in  pptObjCommonIn                   strObjCommonIn;
//  in  csObjLot_udata_CopyToChild_in    strLot_udata_CopyToChild_in
//
//[Output Parameters]:
//
//  out csObjLot_udata_CopyToChild_out  strLot_ContaminationInfo_Set_out;
//
//  typedef objBase_out csObjLot_udata_CopyToChild_out;
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::cs_lot_udata_CopyToChild(
    csObjLot_udata_CopyToChild_out      &strLot_ContaminationInfo_Set_out,
    const pptObjCommonIn                &strObjCommonIn,
    const csObjLot_udata_CopyToChild_in &strLot_udata_CopyToChild_in)
{
    char * methodName = NULL;
    try
    {        
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_lot_udata_CopyToChild");
        CORBA::Long rc = RC_OK;

        objectIdentifier parentLotID = strLot_udata_CopyToChild_in.parentLotID;
        PPT_METHODTRACE_V2("","parentLotID--->", parentLotID.identifier);

        PosLot_var aParentLot;
        PPT_CONVERT_LOTID_TO_LOT_OR( aParentLot, parentLotID, strLot_ContaminationInfo_Set_out, cs_lot_udata_CopyToChild );

        CORBA::String_var varContaminationFlag;
        CORBA::String_var varPRFlag;

        SI_PPT_USERDATA_GET_STRING( aParentLot, CS_M_LOT_Contamination_Flag, varContaminationFlag );
        SI_PPT_USERDATA_GET_STRING( aParentLot, CS_M_LOT_PR_Flag, varPRFlag );

        //----------------------------------------------
        //Get contamination flag from parent lot
        //----------------------------------------------
        PPT_METHODTRACE_V2("","Parent CS_M_LOT_Contamination_Flag --->", varContaminationFlag);
        PPT_METHODTRACE_V2("","Parent CS_M_LOT_PR_Flag       --->", varPRFlag);

        objectIdentifier childLotID = strLot_udata_CopyToChild_in.childLotID;
        PPT_METHODTRACE_V2("","childLotID--->", childLotID.identifier);

        PosLot_var aChildLot;
        PPT_CONVERT_LOTID_TO_LOT_OR( aChildLot, childLotID, strLot_ContaminationInfo_Set_out, cs_lot_udata_CopyToChild );

        //----------------------------------------------
        //Set contamination flag for child lot
        //----------------------------------------------
        PPT_METHODTRACE_V1("","Set CS_M_LOT_Contamination_Flag for Child Lot");
        SI_PPT_USERDATA_SET_STRING( aChildLot, CS_M_LOT_Contamination_Flag, varContaminationFlag );
        
        //----------------------------------------------
        //Set PR flag for child lot
        //----------------------------------------------
        PPT_METHODTRACE_V1("","Set CS_M_LOT_PR_Flag for Child Lot");
        SI_PPT_USERDATA_SET_STRING( aChildLot, CS_M_LOT_PR_Flag, varPRFlag );

       PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_lot_udata_CopyToChild");
       return rc;
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_ContaminationInfo_Set_out, cs_lot_udata_CopyToChild, methodName)
}
