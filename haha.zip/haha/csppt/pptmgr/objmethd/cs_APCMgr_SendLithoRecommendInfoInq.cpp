//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
//
// SiView
// Name: cs_APCMgr_SendLithoRecommendInfoInq.cpp
//

// Class: CS_PPTManager
//
// [Object Function Name]: long   cs_APCMgr_SendLithoRecommendInfoInq.cpp
//
//
// Innotron Modification history:
// Date       Defect#   Person         Comments
// ---------- --------- -------------- -------------------------------------------
// 2017/09/26 INN-R170009  Xinxin_Liu      Add APC Litho
//
// Function Description:
//
// Input Parameters:
// in csObjAPCMgr_SendLithoRecommendInfoInq_in  strObjAPCMgr_SendLithoRecommendInfoInq_in;
//
//typedef struct csObjAPCMgr_SendLithoRecommendInfoInq_in_struct {
//    objectIdentifier            equipmentID;
//    pptStartCassetteSequence    strStartCassette;
//    string                      action;
//    any                         siInfo;
//}csObjAPCMgr_SendLithoRecommendInfoInq_in;

//
// Output Parameters:
// out csObjAPCMgr_SendLithoRecommendInfoInq_out strObjAPCMgr_SendLithoRecommendInfoInq_out;
//
//typedef struct csObjAPCMgr_SendLithoRecommendInfoInq_out_struct {
//    pptRetCode                      strResult;
//    pptStartCassetteSequence        strStartCassette;
//    any                             siInfo;
//}csObjAPCMgr_SendLithoRecommendInfoInq_out;

//
// Return Value:
//
// Exception:
//
// Pseudo code:
//

#include "cs_pptmgr.hpp"


CORBA::Long CS_PPTManager_i::cs_APCMgr_SendLithoRecommendInfoInq(
    csObjAPCMgr_SendLithoRecommendInfoInq_out&       strObjAPCMgr_SendLithoRecommendInfoInq_out,
    const pptObjCommonIn&                              strObjCommonIn,
    const csObjAPCMgr_SendLithoRecommendInfoInq_in&  strObjAPCMgr_SendLithoRecommendInfoInq_in )
{
    CORBA::Long rc = RC_OK;
    PPT_METHODTRACE_V2("", "Action", strObjAPCMgr_SendLithoRecommendInfoInq_in.action); 
    return(RC_OK);
}