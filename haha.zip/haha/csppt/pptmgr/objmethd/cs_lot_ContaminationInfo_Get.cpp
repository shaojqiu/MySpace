//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_lot_ContaminationInfo_Get.cpp
//
#include "cs_pptmgr.hpp"

#include "plot.hh"
#include "ppcope.hh"
#include "ppcopsp.hh"
//
// Class: CS_PPTManager
//
// Service: cs_lot_ContaminationInfo_Get()
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------  -------------- -------------------------------------------
// 2017-09-08 INN-R170002   Thomas.Song    Contamination control 
//
//[Function Description]:
//
//
//[Input Parameters]:
//  in  pptObjCommonIn      strObjCommonIn;
//  in  csObjLot_ContaminationInfo_Get_in   strLot_ContaminationInfo_Get_in
//
//[Output Parameters]:
//
//  out csObjLot_ContaminationInfo_Get_out  strLot_ContaminationInfo_Get_Out;
//
//  typedef objBase_out csObjLot_ContaminationInfo_Get_Out;
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::cs_lot_ContaminationInfo_Get(
    csObjLot_ContaminationInfo_Get_out&      strLot_ContaminationInfo_Get_out, 
    const pptObjCommonIn&                    strObjCommonIn, 
    const csObjLot_ContaminationInfo_Get_in& strLot_ContaminationInfo_Get_in)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_lot_ContaminationInfo_Get");
        CORBA::Long rc = RC_OK;

        objectIdentifier lotID = strLot_ContaminationInfo_Get_in.lotID;
        PPT_METHODTRACE_V2("","lotID--->", lotID.identifier);

        csLotContaminationInfo strLotContaminationInfo;
        strLotContaminationInfo.lotID = lotID;
        strLotContaminationInfo.operationStartFlag = FALSE;
        //----------------------------------------------
        // Get Lot u-data
        //----------------------------------------------
        PosLot_var aPosLot;
        PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot, lotID, strLot_ContaminationInfo_Get_out, cs_lot_ContaminationInfo_Get);

        //lotContamiFlag
        SI_PPT_USERDATA_GET_STRING( aPosLot, CS_M_LOT_Contamination_Flag, strLotContaminationInfo.lotContamiFlag );

        //lotPRFlag
        SI_PPT_USERDATA_GET_STRING( aPosLot, CS_M_LOT_PR_Flag, strLotContaminationInfo.lotPRFlag );

        //----------------------------------------------
        // Get POS u-data for lot
        //----------------------------------------------
        ProcessOperation_var aTempPO;
        PosProcessOperation_var aPosPO;
        try
        {
            aTempPO = aPosLot->getProcessOperation();
            aPosPO = PosProcessOperation::_narrow( aTempPO );
        }
        CATCH_AND_RAISE_EXCEPTIONS(Lot::getProcessOperation);

        if( TRUE == CORBA::is_nil(aPosPO) )
        {
            PPT_METHODTRACE_V1("","aPosProcessOperation is nil");
            PPT_SET_MSG_RC_KEY2( strLot_ContaminationInfo_Get_out,
                                 MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO,
                                 "*****", lotID.identifier );
            return RC_NOT_FOUND_PO;
        }

        ProcessOperationSpecification_var aTempPOS ;
        PosProcessOperationSpecification_var aPosPOS;
        try
        {
            aTempPOS = aPosPO->getProcessOperationSpecification() ;
            aPosPOS = PosProcessOperationSpecification::_narrow( aTempPOS) ;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getProcessOperationSpecification)

        if( TRUE == CORBA::is_nil(aPosPOS) )
        {
            PPT_METHODTRACE_V1("","aPosPOS is nil");
            PPT_SET_MSG_RC_KEY( strLot_ContaminationInfo_Get_out, MSG_NOT_FOUND_POS_FOR_LOT, RC_NOT_FOUND_POS, lotID.identifier );
            return RC_NOT_FOUND_POS;
        }

        //Operation ContaminationInLevel
        SI_PPT_USERDATA_GET_STRING( aPosPOS, CS_S_MAINPD_OpeContamiInLevel, strLotContaminationInfo.opeContamiInLevel );
        PPT_METHODTRACE_V2("","CS_S_MAINPD_OpeContamiInLevel", strLotContaminationInfo.opeContamiInLevel );
        if( 0 == CIMFWStrCmp(strLotContaminationInfo.opeContamiInLevel, CS_ContaminationLevel_NoCheck) )
        {
            strLotContaminationInfo.opeContamiInLevel = CIMFWStrDup("");
        }

        //Operation ContaminationOutLevel
        SI_PPT_USERDATA_GET_STRING( aPosPOS, CS_S_MAINPD_OpeContamiOutLevel, strLotContaminationInfo.opeContamiOutLevel );
        PPT_METHODTRACE_V2("","CS_S_MAINPD_OpeContamiOutLevel", strLotContaminationInfo.opeContamiOutLevel );
        if( 0 == CIMFWStrCmp(strLotContaminationInfo.opeContamiOutLevel, CS_ContaminationLevel_NoCheck) )
        {
            strLotContaminationInfo.opeContamiOutLevel = CIMFWStrDup("");
        }

        //Operation PRControl
        SI_PPT_USERDATA_GET_STRING( aPosPOS, CS_S_MAINPD_OpePRControl, strLotContaminationInfo.opePRControl );

        PPT_METHODTRACE_V2("","lotContamiFlag    ", strLotContaminationInfo.lotContamiFlag );
        PPT_METHODTRACE_V2("","lotPRFlag         ", strLotContaminationInfo.lotPRFlag );
        PPT_METHODTRACE_V2("","opeContamiInLevel ", strLotContaminationInfo.opeContamiInLevel );
        PPT_METHODTRACE_V2("","opeContamiOutLevel", strLotContaminationInfo.opeContamiOutLevel );
        PPT_METHODTRACE_V2("","opePRControl      ", strLotContaminationInfo.opePRControl );

        //----------------------------
        //  Return to Caller
        //----------------------------
        strLot_ContaminationInfo_Get_out.strLotContaminationInfo = strLotContaminationInfo;
        SET_MSG_RC(strLot_ContaminationInfo_Get_out, MSG_OK, RC_OK);
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_lot_ContaminationInfo_Get");
        return rc;
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_ContaminationInfo_Get_out, cs_lot_ContaminationInfo_Get, methodName)   
}
