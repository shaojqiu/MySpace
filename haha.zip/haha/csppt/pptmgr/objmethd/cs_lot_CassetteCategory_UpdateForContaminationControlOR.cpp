#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cs_lot_CassetteCategory_UpdateForContaminationControlOR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 20:00:14 [ 7/13/07 20:00:15 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_lot_CassetteCategory_UpdateForContaminationControlOR.cpp
//
#include "cs_pptmgr.hpp"
#include "plot.hh"
#include "ppcope.hh"
#include "ppcopsp.hh"
// Class: CS_PPTManager
//
// Service: lot_CassetteCategory_UpdateForContaminationControl()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2001/07/05 D4000016 M.Shimizu      The first coding (R40)
// 2002-01-07 D4100020 K.Matsuei      Change for Effective Module Process Release(Rel4.1)
// 2002-09-25 P4200192 H.Adachi       Add Nil Check NG RETURN
// 2007-02-16 P8000113 H.Adachi       Add Logic of Checking of Lot's inventory state and generation of Required Carrier Category.


// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------  -------------- -------------------------------------------
// 2017-09-08 R170002       JQ.Shao        Contamination Control


//
// Description:
//     UpDate requiredCassetteCategory to PosLot  Object for Copper/Non Copper
//
// Return:
//     Long
//
// [Input Parameters]:
//   in  pptObjCommonIn    strObjCommonIn;
//   in  objectIdentifier  lotID;
//
// [Output Parameters]:
//   out objLot_CassetteCategory_UpdateForContaminationControl_out   strLot_CassetteCategory_UpdateForContaminationControl_out;
//
//  typedef struct objLot_CassetteCategory_UpdateForContaminationControl_out_struct {
//      pptRetCode                     strResult;
//      any siInfo;
//  } objLot_CassetteCategory_UpdateForContaminationControl_out;
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
// [Return Value]:
//
//  Return Code                Messsage ID
//  -------------------------  --------------------------------------------------
//  RC_OK                      MSG_OK
//  RC_INVALID_CATEGORY_UPDATE MSG_INVALID_CATEGORY_UPDATE
//
CORBA::Long CS_PPTManager_i::lot_CassetteCategory_UpdateForContaminationControl(
                                objLot_CassetteCategory_UpdateForContaminationControl_out& strLot_CassetteCategory_UpdateForContaminationControl_out,
                                const pptObjCommonIn& strObjCommonIn,
                                const objectIdentifier& lotID)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::lot_CassetteCategory_UpdateForContaminationControl")

        CORBA::Long rc = RC_OK;

        /*--------------------------------------------------------------------------------------------------*/
        /* PosLot_var is made by LotID.                                                                     */
        /*--------------------------------------------------------------------------------------------------*/
        PosLot_var aLot;
        PPT_CONVERT_LOTID_TO_LOT_OR( aLot,
                                     lotID,
                                     strLot_CassetteCategory_UpdateForContaminationControl_out,
                                     lot_CassetteCategory_UpdateForContaminationControl );

        /*--------------------------------------------------------------------------------------------------*/
        /* ProcessOperation_var is made by PosLot_var.                                                      */
        /*--------------------------------------------------------------------------------------------------*/
//D4100020 start
        PosProcessOperation_var aProcessOperation ;
        try
        {
            ProcessOperation_var aTmpPO ;
            aTmpPO = aLot->getProcessOperation() ;
            aProcessOperation  = PosProcessOperation::_narrow( aTmpPO ) ;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation)
//D4100020 end
//D4100020        ProcessOperation_var aProcessOperation ;
//D4100020        try
//D4100020        {
//D4100020            aProcessOperation = aLot->getProcessOperation() ;
//D4100020        }
//D4100020        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation)

        if( CORBA::is_nil(aProcessOperation) == TRUE )
        {
            PPT_METHODTRACE_V1("", "aProcessOperation is nil");
            PPT_SET_MSG_RC_KEY2( strLot_CassetteCategory_UpdateForContaminationControl_out,
                                 MSG_NOT_FOUND_PO,
                                 RC_NOT_FOUND_PO,
                                 "*****",
                                 lotID.identifier);
            return( RC_NOT_FOUND_PO );                //P4200192
        }

//D4100020        /*--------------------------------------------------------------------------------------------------*/
//D4100020        /* ProcessOperationSpecification_var is made by ProcessOperation_var.                               */
//D4100020        /*--------------------------------------------------------------------------------------------------*/
//D4100020        ProcessOperationSpecification_var aProcessOperationSpecification ;
//D4100020        try
//D4100020        {
//D4100020            aProcessOperationSpecification = aProcessOperation->getProcessOperationSpecification() ;
//D4100020        }
//D4100020        CATCH_AND_RAISE_EXCEPTIONS(ProcessOperation::getProcessOperationSpecification)
//D4100020
//D4100020        if( CORBA::is_nil(aProcessOperationSpecification) == TRUE )
//D4100020        {
//D4100020            PPT_METHODTRACE_V1("", "aProcessOperationSpecification is nil");
//D4100020            PPT_SET_MSG_RC_KEY2( strLot_CassetteCategory_UpdateForContaminationControl_out,
//D4100020                        MSG_NOT_FOUND_POS,
//D4100020                        RC_NOT_FOUND_POS,
//D4100020                        "*****",
//D4100020                        lotID.identifier);
//D4100020        }
//D4100020
//D4100020        /*--------------------------------------------------------------------------------------------------*/
//D4100020        /* PosProcessOperationSpecification_var is made by ProcessOperationSpecification_var.               */
//D4100020        /*--------------------------------------------------------------------------------------------------*/
//D4100020        PosProcessOperationSpecification_var aPosProcessOperationSpecification ;
//D4100020        aPosProcessOperationSpecification = PosProcessOperationSpecification::_narrow( aProcessOperationSpecification ) ;
//D4100020
//D4100020        if( CORBA::is_nil(aPosProcessOperationSpecification) == TRUE )
//D4100020        {
//D4100020            PPT_METHODTRACE_V1("", "aPosProcessOperationSpecification is nil");
//D4100020            PPT_SET_MSG_RC_KEY2( strLot_CassetteCategory_UpdateForContaminationControl_out,
//D4100020                        MSG_NOT_FOUND_POS,
//D4100020                        RC_NOT_FOUND_POS,
//D4100020                        "*****",
//D4100020                        lotID.identifier);
//D4100020        }

        /*--------------------------------------------------------------------------------------------------*/
        /* Get RequiredCassetteCategory                                                                     */
        /*--------------------------------------------------------------------------------------------------*/
        //P8000113 Add Start
        //--------------------------------------
        // Check Lot's Inventory State
        //--------------------------------------
        CORBA::String_var inventoryState;
        try
        {
            inventoryState = aLot->getLotInventoryState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotInventoryState)

        if ( 0 == CIMFWStrCmp(inventoryState, SP_Lot_InventoryState_InBank) )
        {
            PPT_METHODTRACE_V1("","inventoryState == SP_Lot_InventoryState_InBank. So set  BLANK to Required Carrire Category.");
            //---------------------------------------------
            // blank is set on setRequiredCassetteCategory.
            //---------------------------------------------
            try
            {
                aLot->setRequiredCassetteCategory("");
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::setRequiredCassetteCategory)
        }
        else
        {
            PPT_METHODTRACE_V1("","inventoryState != SP_Lot_InventoryState_InBank. So set Required Carrire Category.");
            //P8000113 Add End and following lines are nested.

            CORBA::String_var requiredCassetteCategory;
//D4100020        try
//D4100020        {
//D4100020            requiredCassetteCategory = aPosProcessOperationSpecification->getRequiredCassetteCategory() ;
//D4100020        }
//D4100020        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperationSpecification::getRequiredCassetteCategory)
//D4100020 start
            try
            {
                requiredCassetteCategory = aProcessOperation->getRequiredCassetteCategory() ;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getRequiredCassetteCategory)
//D4100020 end
//R170002 Add Start
            PPT_METHODTRACE_V2("","requiredCassetteCategory", requiredCassetteCategory);
            if( 0 == CIMFWStrCmp(requiredCassetteCategory, CS_CarrierCategory_NoCheck) )
            {
                PPT_METHODTRACE_V1("","requiredCassetteCategory==NoCheck");
                requiredCassetteCategory = CIMFWStrDup("");
            }
//R170002 Add End

            /*--------------------------------------------------------------------------------------------------*/
            /* Set RequiredCassetteCategory                                                                     */
            /*--------------------------------------------------------------------------------------------------*/
            try
            {
                aLot->setRequiredCassetteCategory(requiredCassetteCategory);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::setRequiredCassetteCategory)

        }    //P8000113

        return rc;
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_CassetteCategory_UpdateForContaminationControl_out, lot_CassetteCategory_UpdateForContaminationControl, methodName)

}
