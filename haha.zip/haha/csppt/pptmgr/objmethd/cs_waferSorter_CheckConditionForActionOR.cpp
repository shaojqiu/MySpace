#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/waferSorter_CheckConditionForAction.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 20:30:55 [ 7/13/07 20:30:56 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: waferSorter_CheckConditionForAction.cpp
//

//INN-R170002 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp"    //INN-R170002
#include "plot.hh"
#include "pctrlj.hh"

#include "ppcope.hh"
#include "pprsp.hh"
#include "plcrc.hh"
#include "pmcrc.hh"
#include "pportrs.hh"
#include "pcas.hh"
#include "pwafer.hh"
#include "plot.hh"

//[Object Function Name]: long   waferSorter_CheckConditionForAction_Verify
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2001/07/12  D4000056  Y.Yoshihara    WaferSorterOnline Support .
// 2001/08/09  D4000056  Y.Yoshihara    Change IDL
// 2001/08/20  P4000099  Y.Yoshihara    Change name waferSorter_condition to
//                                      waferSorter_condition 
// 2001/08/21  P4000099  Y.Yoshihara    Change name  waferSorter_CheckConditionForAction
//                                      to waferSorter_CheckConditionForAction_Verify
// 2001/08/29  P4000056  Y.Yoshihara    Enhance Check Logic
// 2001/09/07  P4000056  Y.Yoshihara    Fix invalid parameter routine
// 2001/10/04  P4000323  M.Shimizu      Bug Fix Unnecessary CheckLogic runs with Adjust. 
// 2001/10/05  D4000220  M.Shimizu      If all Wafers inside Lot are being done with Scrap, MM is made be to make of ScrapOut in Cassette to manage. 
// 2001/10/22  D4000234  M.Shimizu      Add a Action Code 'AdjustToSorter'. 
// 2001/11/12  P40A0007  H.Adachi       Bad verifying a conbination of lot and wafers
// 2002/01/25  P4100091  H.Adachi       Wrong Method Name in PPT_METHODTRACE_Vx
// 2002/02/14  D4100134  C.Tsuchiya     Use getenv() instead of Mgr class member 'theSP_xxx'
// 2002/05/13  P4100425  K.Matsuei      The number of Parameters to assemble Message in PPT_SET_MSG_RC_KEY*** mistakes it.
// 2002/10/10  D4200133  K.Matsuei      Add try - catch
// 2003/01/28  P4200546  H.Adachi       Fix memory leak.
// 2003/09/09  P5000145  H.Adachi       Fix Message and Message Macro mismatch.
// 2006/12/14  D7000239  H.Mutoh        Add equipment availability check.
// 2007/04/20  D9000001  H.Murakami     64bit support.
// 2007/06/20  D9000005  K.Kido         Wafer Sorter automation support(R9.0)
//
// 2009/04/17  PSIV00000956  F.Chen         Sort job creation should not be affected by other port group operation mode
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/14 INN-R170002  JQ.Shao        Contamination Control
//
//[Function Description]:
//  Check sorter request input parameter to verify.
//  The following conditions are checked for each specified operation.
//  After completion of data verification, default variable was filled .
//
//[Input Parameters]:
//
//  objWaferSorter_CheckConditionForAction_out& strWaferSorter_CheckConditionForAction_out,
//  const pptObjCommonIn&                          strObjCommonIn,
//  const pptUser&                                 requestUserID,
//  const objectIdentifier&                        equipmentID,
//  const char *                                   actionCode,
//  const pptWaferSorterSlotMapSequence&           strWaferSorterSlotMapSequence,
//  const char *                                   portGroup,
//  const char *                                   physicalRecipeID
//
//[Output Parameters]:
//  objWaferSorter_CheckConditionForAction_out  strWaferSorter_CheckConditionForAction_out,
//
// typedef struct objWaferSorter_CheckConditionForAction_struct{
//    pptRetCode                         strResult;
//    pptWaferSorterSlotMapSequence      strWaferSorterSlotMapSequence ; 
//    any siInfo;
// } objWaferSorter_CheckConditionForAction_out;
//
//[Return Value]:
//
//  Return Code                               Messsage ID
//  ----------------------------------------- ------------------------------------------------
//  RC_OK                                     MSG_OK
//  RC_INVALID_ACTION_CODE                    MSG_INVALID_ACTION_CODE 
//  RC_MACHINE_TYPE_NOT_SORTER                MSG_MACHINE_TYPE_NOT_SORTER
//  RC_PORT_PORTGROUP_UNMATCH                 MSG_PORT_PORTGROUP_UNMATCH
//  RC_INVALID_PORT_STATE                     MSG_INVALID_PORT_STATE
//  RC_INVALID_PORTGROUP                      MSG_INVALID_PORTGROUP
//  RC_EQUIPMENT_UNMATCH                      MSG_EQUIPMENT_UNMATCH
//  RC_NOT_FOUND_PHYSICAL_RECIPE              MSG_NOT_FOUND_PHYSICAL_RECIPE
//  RC_INVALID_DIRECTION                      MSG_INVALID_DIRECTION
//  RC_INVALID_SORTERSTATUS                   MSG_INVALID_SORTERSTATUS
//  RC_INVALID_REGISTERED_CARRIER             MSG_INVALID_REGISTERED_CARRIER
//  RC_INVALID_UNREGISTERED_CARRIER           MSG_INVALID_UNREGISTERED_CARRIER
//  RC_INVALID_SLOTNUMBER_FOR_WAFERIDMINIREAD MSG_INVALID_SLOTNUMBER_FOR_WAFERIDMINIREAD
//  RC_NOT_FOUND_WAFER                        MSG_NOT_FOUND_WAFER
//  RC_NOT_FOUND_CASSETTE                     MSG_NOT_FOUND_CASSETTE
//  RC_NOT_FOUND_LOT                          MSG_NOT_FOUND_LOT
//  RC_INVALID_WAFER_POSITION                 MSG_INVALID_WAFER_POSITION
//  RC_ACTIONCODE_UNMATCH                     MSG_ACTIONCODE_UNMATCH
//  RC_USERID_UNMATCH                         MSG_USERID_UNMATCH
//  RC_INVALID_CASSETTEID_FOR_WAFERIDREAD     MSG_INVALID_CASSETTEID_FOR_WAFERIDREAD
//  RC_INVALID_PORTID_FOR_WAFERIDREAD         MSG_INVALID_PORTID_FOR_WAFERIDREAD 
//  RC_INVALID_CASSETTEID_FOR_WAFERIDMINIREAD MSG_INVALID_CASSETTEID_FOR_WAFERIDMINIREAD
//  RC_INVALID_PORTID_FOR_WAFERIDMINIREAD     MSG_INVALID_PORTID_FOR_WAFERIDMINIREAD
//  RC_INVALID_WAFERIDMINIREAD_SLOTNUMBER     MSG_INVALID_WAFERIDMINIREAD_SLOTNUMBER
//  RC_INVALID_WAFERIDPOSCHANGE_SIVIEWFLAG    MSG_INVALID_WAFERIDPOSCHANGE_SIVIEWFLAG
//  RC_INVALID_SIVIEWFLAG_FOR_JUSTIN          MSG_INVALID_SIVIEWFLAG_FOR_JUSTIN
//  RC_INVALID_SIVIEWFLAG_FOR_JUSTOUT         MSG_INVALID_SIVIEWFLAG_FOR_JUSTOUT
//  RC_INVALID_SIVIEWFLAG_FOR_SCRAPOUT        MSG_INVALID_SIVIEWFLAG_FOR_SCRAPOUT
//  RC_INVALID_SEQLEN_FOR_END                 MSG_INVALID_SEQLEN_FOR_END
//  RC_DUPLICATE_LOCATION                     MSG_DUPLICATE_LOCATION
//  RC_DIFFERENT_CARRIER_IN_PORT              MSG_DIFFERENT_CARRIER_IN_PORT
//  RC_DUPLICATE_CARRIER                      MSG_DUPLICATE_CARRIER
//  RC_INVALID_DEST_WAFER_POSITION            MSG_INVALID_DEST_WAFER_POSITION
//  
//
//
//[Pseudo Code]:
//
CORBA::Long CS_PPTManager_i::waferSorter_CheckConditionForAction(
           objWaferSorter_CheckConditionForAction_out&    strWaferSorter_CheckConditionForAction_out,
           const pptObjCommonIn&                          strObjCommonIn,
           const pptUser&                                 requestUserID,
           const objectIdentifier&                        equipmentID,
           const char *                                   actionCode,
           const pptWaferSorterSlotMapSequence&           strWaferSorterSlotMapSequence,
           const char *                                   portGroup,
           const char *                                   physicalRecipeID)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::waferSorter_CheckConditionForAction");

        PPT_METHODTRACE_V2("","in para equipmentID"      ,equipmentID.identifier);
        PPT_METHODTRACE_V2("","in para actionCode"       ,actionCode);
        PPT_METHODTRACE_V2("","in para portGroupName"    ,portGroup);
        PPT_METHODTRACE_V2("","in para physicalRecipeID" ,physicalRecipeID);

        //---------------------
        // Initialize
        //---------------------
        CORBA::Long   rc = RC_OK;
        CORBA::Long   WaferSorterSlotMapSequenceLen = strWaferSorterSlotMapSequence.length();

        //----------------------------
        // No Parameters are specified
        //----------------------------
        if( WaferSorterSlotMapSequenceLen == 0)
        {
            //--------------------------------------------------
            // If ActionCode is not SP_Sorter_End, then error
            //--------------------------------------------------
            if(CIMFWStrCmp(actionCode,SP_Sorter_End) != 0 ) 
            {
                PPT_METHODTRACE_V1("","WaferSorterSlotMapSequenceLen is 0");
//P5000145                PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                            MSG_INVALID_PARAMETER,
//P5000145                                            RC_INVALID_PARAMETER,"");
                SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,           //P5000145
                            MSG_INVALID_PARAMETER, RC_INVALID_PARAMETER );        //P5000145
                return(RC_INVALID_PARAMETER);
            }
        }
        PPT_METHODTRACE_V2("","Length of strWaferSorterSlotMapSequence is " , WaferSorterSlotMapSequenceLen );

        //=======================================================
        // In-Parameter check routine
        // --------------------------
        // These Parameters are verified 
        //     actionCode/equipmentID/equipment category/portGroup
        //=======================================================
        //----------------------------------------------------------------------------------
        //    Check ActionCode is valid 
        //    => SP_Sorter_Read/SP_Sorter_MiniRead/SP_Sorter_PositionChange/SP_Sorter_JustIn
        //       SP_Sorter_JustOut/SP_Sorter_Scrap/SP_Sorter_End is only valid 
        //----------------------------------------------------------------------------------
        if( CIMFWStrCmp(actionCode,SP_Sorter_Read)           != 0 &&
            CIMFWStrCmp(actionCode,SP_Sorter_MiniRead)       != 0 &&
            CIMFWStrCmp(actionCode,SP_Sorter_PositionChange) != 0 &&
            CIMFWStrCmp(actionCode,SP_Sorter_JustIn)         != 0 &&
            CIMFWStrCmp(actionCode,SP_Sorter_JustOut)        != 0 &&
            CIMFWStrCmp(actionCode,SP_Sorter_Scrap)          != 0 &&
            CIMFWStrCmp(actionCode,SP_Sorter_AdjustToMM)     != 0 &&            //P4000323
            CIMFWStrCmp(actionCode,SP_Sorter_AdjustToSorter) != 0 &&            //D4000234
            CIMFWStrCmp(actionCode,SP_Sorter_AutoSorting   ) != 0 &&            //D9000005
            CIMFWStrCmp(actionCode,SP_Sorter_End)            != 0 ) 
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                               "Invalid ActionCode(In Parameter)",actionCode);
            PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
                                            MSG_INVALID_ACTION_CODE,
                                            RC_INVALID_ACTION_CODE, "" );
            return(RC_INVALID_ACTION_CODE);
        }
        PPT_METHODTRACE_V2("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                           "Specified ActionCode is ",actionCode);

        //----------------------------------------------------------------------------------
        //    Check Equipment Category
        //    => SP_Mc_Category_WaferSorter is only valid
        //----------------------------------------------------------------------------------
        PPT_METHODTRACE_V1("","Getting Equipment Category Information ");

        PosMachine_var aPosMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR(aPosMachine,
                                        equipmentID,
                                        strWaferSorter_CheckConditionForAction_out,
                                        waferSorter_CheckConditionForAction);

        CORBA::String_var strMachneCategory;
        //D4200133 start
        try
        {
            strMachneCategory = aPosMachine->getCategory();
        }
        CATCH_AND_RAISE_EXCEPTIONS( PosMachine::getCategory );
        //D4200133 end
//D4200133        strMachneCategory = aPosMachine->getCategory();

        PPT_METHODTRACE_V1("","Check Equipment Category");
        if( CIMFWStrCmp(strMachneCategory,SP_Mc_Category_WaferSorter) != 0 )
        {
            PPT_METHODTRACE_V2("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                               "Machine Category is not WaferSorter ",strMachneCategory);
            PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
                                            MSG_MACHINE_TYPE_NOT_SORTER,
                                            RC_MACHINE_TYPE_NOT_SORTER,"");
            return(RC_MACHINE_TYPE_NOT_SORTER);
        }

        //-------------------------------------------------------
        //    Check PortGroup 
        //    => PortGroupame should be same as inpara
        //-------------------------------------------------------
        objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
        rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                     strObjCommonIn,
                                     equipmentID );
        if ( rc != RC_OK )
        {
//P4100091            PPT_METHODTRACE_V1("CS_PPTManager_i::equipment_CheckConditionForLoading","equipment_portInfo_Get != RC_OK");
            PPT_METHODTRACE_V1("","equipment_portInfo_Get != RC_OK");    //P4100091
            strWaferSorter_CheckConditionForAction_out.strResult = strEquipment_portInfo_Get_out.strResult;
            return rc;
        }

        CORBA::Long lenPortInfo = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();

        CORBA::Long i;
        CORBA::Long j;
        CORBA::Long k;
        CORBA::Long l;
        objectIdentifier operationModeID;   //PSIV00000956
        objectIdentifier portID;            //PSIV00000956

        for ( i=0; i < lenPortInfo ; i++ )
        {
            // ---------------------------------------------
            // Check On-Line Mode of Port
            // ---------------------------------------------
            if( i == 0) { 
                if ( CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].onlineMode,
                     SP_Eqp_OnlineMode_OnlineRemote) != 0 )
                {
                    PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                  "Port OnlineMode is not Online");
//P4100425 start
                    PPT_SET_MSG_RC_KEY2( strWaferSorter_CheckConditionForAction_out, MSG_INVALID_PORT_STATE, RC_INVALID_PORT_STATE,
                                         strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].portID.identifier,
                                         strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].portState );
//P4100425 end
//P4100425                    PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P4100425                                            MSG_INVALID_PORT_STATE,
//P4100425                                            RC_INVALID_PORT_STATE,"");
                    return(RC_INVALID_PORT_STATE);
                }
//PSIV00000956 //D9000005 add start
//PSIV00000956                 if( 0 == CIMFWStrCmp( actionCode, SP_Sorter_AutoSorting ) )
//PSIV00000956                 {
//PSIV00000956                     if ( 0 != CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].operationModeID.identifier, SP_Eqp_Port_OperationMode_Auto_1) &&
//PSIV00000956                          0 != CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].operationModeID.identifier, SP_Eqp_Port_OperationMode_Auto_2) )
//PSIV00000956                     {
//PSIV00000956                         PPT_SET_MSG_RC_KEY2( strWaferSorter_CheckConditionForAction_out,
//PSIV00000956                                              MSG_INVALID_PORT_OPERATION_MODE,
//PSIV00000956                                              RC_INVALID_PORT_OPERATION_MODE,
//PSIV00000956                                              strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].portID.identifier,
//PSIV00000956                                              strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].operationModeID.identifier);
//PSIV00000956                         return RC_INVALID_PORT_OPERATION_MODE;
//PSIV00000956                     }
//PSIV00000956                 }
//PSIV00000956                 else
//PSIV00000956                 {
//PSIV00000956                     if ( 0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].operationModeID.identifier, SP_Eqp_Port_OperationMode_Auto_1) ||
//PSIV00000956                          0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].operationModeID.identifier, SP_Eqp_Port_OperationMode_Auto_2) ||
//PSIV00000956                          0 == CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].operationModeID.identifier, SP_Eqp_Port_OperationMode_Auto_3) )
//PSIV00000956                     {
//PSIV00000956                         PPT_SET_MSG_RC_KEY2( strWaferSorter_CheckConditionForAction_out,
//PSIV00000956                                              MSG_INVALID_PORT_OPERATION_MODE,
//PSIV00000956                                              RC_INVALID_PORT_OPERATION_MODE,
//PSIV00000956                                              strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].portID.identifier,
//PSIV00000956                                              strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].operationModeID.identifier);
//PSIV00000956                         return RC_INVALID_PORT_OPERATION_MODE;
//PSIV00000956                     }
//PSIV00000956                 }
//PSIV00000956 //D9000005 add end
            }
            // ---------------------------------------------
            // Check In-Para Port Group is on EQP Port Group
            // ---------------------------------------------
            if(CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].portGroup,portGroup)==0)
            {
                PPT_METHODTRACE_V2("", "Found the portGroup!", portGroup);
                operationModeID = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].operationModeID; //PSIV00000956
                portID = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[i].portID;                   //PSIV00000956
                break;  
            }

            //--------------------
            // Case in Final Loop
            //--------------------
            if(i == (lenPortInfo - 1))
            {
               PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                  "PortGroup invalid");
//P5000145               PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                            MSG_PORT_PORTGROUP_UNMATCH,
//P5000145                                            RC_PORT_PORTGROUP_UNMATCH,"");
               SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,                     //P5000145
                           MSG_PORT_PORTGROUP_UNMATCH, RC_PORT_PORTGROUP_UNMATCH );        //P5000145
               return(RC_PORT_PORTGROUP_UNMATCH);
            }
        }
//PSIV00000956 add start
        if( 0 == CIMFWStrCmp( actionCode, SP_Sorter_AutoSorting ) )
        {
            PPT_METHODTRACE_V1("","actionCode = SP_Sorter_AutoSorting");
            if ( 0 != CIMFWStrCmp( operationModeID.identifier, SP_Eqp_Port_OperationMode_Auto_1) &&
                 0 != CIMFWStrCmp( operationModeID.identifier, SP_Eqp_Port_OperationMode_Auto_2) )
            {
                PPT_METHODTRACE_V2("","Invalid operationModeID = ", operationModeID.identifier);
                PPT_SET_MSG_RC_KEY2( strWaferSorter_CheckConditionForAction_out,
                                     MSG_INVALID_PORT_OPERATION_MODE,
                                     RC_INVALID_PORT_OPERATION_MODE,
                                     portID.identifier,
                                     operationModeID.identifier);
                return RC_INVALID_PORT_OPERATION_MODE;
            }
        }
        else
        {
            PPT_METHODTRACE_V2("","actionCode = ", actionCode);
            if ( 0 == CIMFWStrCmp( operationModeID.identifier, SP_Eqp_Port_OperationMode_Auto_1) ||
                 0 == CIMFWStrCmp( operationModeID.identifier, SP_Eqp_Port_OperationMode_Auto_2) ||
                 0 == CIMFWStrCmp( operationModeID.identifier, SP_Eqp_Port_OperationMode_Auto_3) )
            {
                PPT_METHODTRACE_V2("","Invalid operationModeID = ", operationModeID.identifier);
                PPT_SET_MSG_RC_KEY2( strWaferSorter_CheckConditionForAction_out,
                                     MSG_INVALID_PORT_OPERATION_MODE,
                                     RC_INVALID_PORT_OPERATION_MODE,
                                     portID.identifier,
                                     operationModeID.identifier);
                return RC_INVALID_PORT_OPERATION_MODE;
            }
        }
//PSIV00000956 add end
        //-------------------------------------------------------
        // Check PhysicalRecipeID
        // => physicalRecipeID should be input except SP_Sorter_End
        //-------------------------------------------------------
        PPT_METHODTRACE_V1("","Check PhysicalRecipeID");
        if ( CIMFWStrLen(physicalRecipeID) == 0)
        {
//D4000234  if(CIMFWStrCmp(actionCode,SP_Sorter_End) != 0 ) 
            if(CIMFWStrCmp(actionCode,SP_Sorter_End) != 0 &&                //D4000234
               CIMFWStrCmp(actionCode,SP_Sorter_AdjustToSorter) != 0 )      //D4000234
            {
//P5000145                 PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                            MSG_NOT_FOUND_PHYSICAL_RECIPE,
//P5000145                                            RC_NOT_FOUND_PHYSICAL_RECIPE,"");
                 SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,                           //P5000145
                             MSG_NOT_FOUND_PHYSICAL_RECIPE, RC_NOT_FOUND_PHYSICAL_RECIPE );        //P5000145
                 return(RC_NOT_FOUND_PHYSICAL_RECIPE);
            }
        }
//D9000005 add start
        if( 0 == CIMFWStrCmp( actionCode, SP_Sorter_AutoSorting ) )
        {
            objSorter_jobList_GetDR_in strSorter_jobList_GetDR_in;
            strSorter_jobList_GetDR_in.sorterJobID.identifier = physicalRecipeID ;

            objSorter_jobList_GetDR_out strSorter_jobList_GetDR_out;
            rc = sorter_jobList_GetDR( strSorter_jobList_GetDR_out,
                                       strObjCommonIn,
                                       strSorter_jobList_GetDR_in);

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "sorter_jobList_GetDR() rc != RC_OK");
                strWaferSorter_CheckConditionForAction_out.strResult = strSorter_jobList_GetDR_out.strResult;
                return rc;
            }

            if( 0 == strSorter_jobList_GetDR_out.strSortJobListAttributesSeq.length() )
            {
                PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out, 
                                    MSG_NOT_FOUND_SORTERJOB,
                                    RC_NOT_FOUND_SORTERJOB,
                                    physicalRecipeID );
                return RC_NOT_FOUND_SORTERJOB;
            }
        }
//D9000005 add end

//D7000239 add start
        //------------------------------------
        //   Check equipment availability
        //------------------------------------
        objEquipment_CheckAvail_out strEquipment_CheckAvail_out;
        rc = equipment_CheckAvail( strEquipment_CheckAvail_out, strObjCommonIn, equipmentID );
        if( rc == RC_OK )
        {
            PPT_METHODTRACE_V1("", "Equipment is now available. Go ahead!!");
        }
        else
        {
            PPT_METHODTRACE_V2("", "Equipment is not available. return to caller.", rc);
            strWaferSorter_CheckConditionForAction_out.strResult = strEquipment_CheckAvail_out.strResult;
            return( rc );
        }
//D7000239 add end

        //======================================================
        //    Each Check of Structure by ActionCode
        //======================================================
        CORBA::Long    lotFoundCount = 0;
        PosLotSequence aPosLotSeq;
        stringSequence cassetteIDs;
        stringSequence lotIDs;
        CORBA::Boolean waferFound = FALSE;
        PosWafer_var   aPosWafer;

        lotIDs.length(WaferSorterSlotMapSequenceLen);
        aPosLotSeq.length(WaferSorterSlotMapSequenceLen);
        cassetteIDs.length(WaferSorterSlotMapSequenceLen);

        // --------------------------------------------------------------
        // Check All Data in Structure Sequence
        // --------------------------------------------------------------
        for( i = 0; i < WaferSorterSlotMapSequenceLen ; i++)
        {
            PPT_METHODTRACE_V1("Loop Count is ",i);
            PPT_METHODTRACE_V1("portGroup",strWaferSorterSlotMapSequence[i].portGroup);
            PPT_METHODTRACE_V1("equipmentID",strWaferSorterSlotMapSequence[i].equipmentID.identifier);
            PPT_METHODTRACE_V1("actionCode",strWaferSorterSlotMapSequence[i].actionCode);
            PPT_METHODTRACE_V1("requestTime",strWaferSorterSlotMapSequence[i].requestTime);
            PPT_METHODTRACE_V1("direction",strWaferSorterSlotMapSequence[i].direction);
            PPT_METHODTRACE_V1("waferID",strWaferSorterSlotMapSequence[i].waferID.identifier);
            PPT_METHODTRACE_V1("lotID",strWaferSorterSlotMapSequence[i].lotID.identifier);
            PPT_METHODTRACE_V1("destinationCassetteID",strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier);
            PPT_METHODTRACE_V1("destinationPortID",strWaferSorterSlotMapSequence[i].destinationPortID.identifier);
            if(strWaferSorterSlotMapSequence[i].bDestinationCassetteManagedBySiView==TRUE)
            {
                PPT_METHODTRACE_V1("bDestinationCassetteManagedBySiView:","TRUE");
            }
            else
            {
                PPT_METHODTRACE_V1("bDestinationCassetteManagedBySiView:","FALSE");
            }
            PPT_METHODTRACE_V1("destinationSlotNumber",strWaferSorterSlotMapSequence[i].destinationSlotNumber);
            PPT_METHODTRACE_V1("originalCassetteID",strWaferSorterSlotMapSequence[i].originalCassetteID.identifier);
            PPT_METHODTRACE_V1("originalPortID",strWaferSorterSlotMapSequence[i].originalPortID.identifier);
            if(strWaferSorterSlotMapSequence[i].bOriginalCassetteManagedBySiView==TRUE)
            {
                PPT_METHODTRACE_V1("bOriginalCassetteManagedBySiView:","TRUE");
            }
            else
            {
                PPT_METHODTRACE_V1("bOriginalCassetteManagedBySiView:","FALSE");
            }
            PPT_METHODTRACE_V1("originalSlotNumber",strWaferSorterSlotMapSequence[i].originalSlotNumber);
            PPT_METHODTRACE_V1("requestUserID",strWaferSorterSlotMapSequence[i].requestUserID.identifier);
            PPT_METHODTRACE_V1("replyTime",strWaferSorterSlotMapSequence[i].replyTime);
            PPT_METHODTRACE_V1("sorterStatus",strWaferSorterSlotMapSequence[i].sorterStatus);
            PPT_METHODTRACE_V1("slotMapCompareStatus",strWaferSorterSlotMapSequence[i].slotMapCompareStatus);
            PPT_METHODTRACE_V1("mmCompareStatus",strWaferSorterSlotMapSequence[i].mmCompareStatus);
            
            //=====================================================================================
            //    Common Check
            //=====================================================================================

            //--------------------------------------------------
            // Compare In-para variable and structure variable
            //--------------------------------------------------
            //---------------------------------
            // 1. PortGroup Check
            //---------------------------------
            if(CIMFWStrCmp( strWaferSorterSlotMapSequence[i].portGroup,  
                            portGroup ) !=0 )
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                   "PortGroup Data of structure invalid");
//P5000145                PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                            MSG_PORTGROUP_UNMATCH,
//P5000145                                            RC_PORTGROUP_UNMATCH,"");
                SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,           //P5000145
                            MSG_PORTGROUP_UNMATCH, RC_PORTGROUP_UNMATCH );        //P5000145
                return(RC_PORTGROUP_UNMATCH);
            }

             PPT_METHODTRACE_V1("","PortGroup Check is OK");
            //---------------------------------
            // 2. Equipment ID Check
            //---------------------------------
            if(CIMFWStrCmp( strWaferSorterSlotMapSequence[i].equipmentID.identifier, 
                            equipmentID.identifier) !=0 )
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                   "Equipment Data of structure invalid");
                PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
                                            MSG_EQUIPMENT_UNMATCH,
                                            RC_EQUIPMENT_UNMATCH,"");
                return(RC_EQUIPMENT_UNMATCH);
            }
             PPT_METHODTRACE_V1("","Equipment ID Check is OK");

            //---------------------------------
            // 3. ActionCode Check
            //---------------------------------
            if(CIMFWStrCmp( strWaferSorterSlotMapSequence[i].actionCode,
                            actionCode ) !=0 )
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                   "ActionCode of structure invalid");
                PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
                                            MSG_ACTIONCODE_UNMATCH,
                                            RC_ACTIONCODE_UNMATCH,"");
                return(RC_ACTIONCODE_UNMATCH);
            }
            PPT_METHODTRACE_V1("","ActionCode Check is OK");

            //--------------------------------------------------
            // Other Checks
            //--------------------------------------------------
            //---------------------------------
            // 4. Direction
            //---------------------------------
            if( CIMFWStrCmp( strWaferSorterSlotMapSequence[i].direction,
                            SP_Sorter_Direction_MM) !=0 )
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                   "Direction for WaferSorter is invalid ");
//P5000145                PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                            MSG_INVALID_DIRECTION,
//P5000145                                            RC_INVALID_DIRECTION,"");
                SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,           //P5000145
                            MSG_INVALID_DIRECTION, RC_INVALID_DIRECTION );        //P5000145
                return(RC_INVALID_DIRECTION);
            }
            PPT_METHODTRACE_V1("","Direction Check is OK");

            //---------------------------------
            // 5. requestUserID Check
            //---------------------------------
            if( CIMFWStrCmp( strWaferSorterSlotMapSequence[i].requestUserID.identifier, 
                             requestUserID.userID.identifier) !=0 )
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                   "UserID of structure invalid");
//P5000145                PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                            MSG_USERID_UNMATCH,
//P5000145                                            RC_USERID_UNMATCH,"");
                SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,     //P5000145
                            MSG_USERID_UNMATCH, RC_USERID_UNMATCH );        //P5000145
                return(RC_USERID_UNMATCH);
            }
            PPT_METHODTRACE_V1("","UserID Check is OK");

            //---------------------------------
            // 6. SorterStatus Check
            //---------------------------------
            if( CIMFWStrCmp( strWaferSorterSlotMapSequence[i].sorterStatus,
                            SP_Sorter_Requested) !=0 )
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                   "Sorter Status Check");
//P5000145                PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                            MSG_INVALID_SORTERSTATUS,
//P5000145                                            RC_INVALID_SORTERSTATUS,"");
                SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,                 //P5000145
                            MSG_INVALID_SORTERSTATUS, RC_INVALID_SORTERSTATUS );        //P5000145
                return(RC_INVALID_SORTERSTATUS);
            }
            PPT_METHODTRACE_V1("","SorterStatus Check is OK");
           
            //---------------------------------------------------------------------------------------------
            // Destination SlotNumber Check
            //---------------------------------------------------------------------------------------------
            PosCassette_var aCassette;
            CORBA::Boolean cassetteFound = FALSE;
            CORBA::Boolean destinationCassetteFound = FALSE;

            PPT_CONVERT_CASSETTEID_TO_CASSETTE_WITH_NO_RETURN(aCassette
                                              ,strWaferSorterSlotMapSequence[i].destinationCassetteID);
            destinationCassetteFound = cassetteFound;

            //=================================
            //    Check by ActionCode
            //=================================
            //---------------------------------------------------------------------------------------------
            // ActionCode : SP_Sorter_Read/SP_Sorter_MiniRead/SP_Sorter_End
            //---------------------------------------------------------------------------------------------
            //    Checking Items : 
            //        bDestinationCassetteManagedBySiView == TRUE)
            //           destinationCassetteID must exist in MM
            //        bDestinationCassetteManagedBySiView == FALSE)
            //           size of destinationCassetteID is bigger than 0  
            //        MiniRead)
            //           destinationSlotNumber must be in 1 to theSP_EnvName_MaximumWafersInALot
            //--------------------------------------------------------------------------------------------
            if( ( CIMFWStrCmp(actionCode,SP_Sorter_Read)      ==0 ) || 
                ( CIMFWStrCmp(actionCode,SP_Sorter_MiniRead)  ==0)  ||
                ( CIMFWStrCmp(actionCode,SP_Sorter_End)       ==0) )
            {

                // -------------------------------
                // Case MM Known Carriers
                // -------------------------------
                if( strWaferSorterSlotMapSequence[i].bDestinationCassetteManagedBySiView == TRUE )
                {
                    if(destinationCassetteFound == FALSE ) 
                    {
                        PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                           "SviewFlag/Cassette Status MisMatch");
//P5000145                        PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                            MSG_INVALID_REGISTERED_CARRIER,
//P5000145                                            RC_INVALID_REGISTERED_CARRIER,"");
                        SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,                             //P5000145
                                    MSG_INVALID_REGISTERED_CARRIER, RC_INVALID_REGISTERED_CARRIER );        //P5000145
                        return(RC_INVALID_REGISTERED_CARRIER);
                    }
                } 
                // -------------------------------
                // Case MM Unknown Carriers
                // -------------------------------
                else
                {
                    if( destinationCassetteFound == TRUE || CIMFWStrLen(strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier) ==0)
                    {
                        PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                           "FOSB ID is not specified");
//P5000145                        PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                            MSG_INVALID_UNREGISTERED_CARRIER,
//P5000145                                            RC_INVALID_UNREGISTERED_CARRIER,"");
                        SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,                                 //P5000145
                                    MSG_INVALID_UNREGISTERED_CARRIER, RC_INVALID_UNREGISTERED_CARRIER );        //P5000145
                        return(RC_INVALID_UNREGISTERED_CARRIER);
                    }
                }
                // -------------------------------------------------------------------
                // If ActionCode is SP_Sorter_MiniRead, SlotNumber should be specified
                // -------------------------------------------------------------------
                if( CIMFWStrCmp(actionCode,SP_Sorter_MiniRead)==0 )
                { 
                    if( (0 > strWaferSorterSlotMapSequence[i].destinationSlotNumber) ||
//D4100134                        (strWaferSorterSlotMapSequence[i].destinationSlotNumber > atol(theSP_EnvName_MaximumWafersInALot)))
                        (strWaferSorterSlotMapSequence[i].destinationSlotNumber > atol(getenv(SP_EnvName_MaximumWafersInALot))))  //D4100134
                    {
                        PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                           "destinationSlotNumber is Invalid");
//P5000145                        PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                            MSG_INVALID_SLOTNUMBER_FOR_WAFERIDMINIREAD,
//P5000145                                            RC_INVALID_SLOTNUMBER_FOR_WAFERIDMINIREAD,"");
                        SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,         //P5000145
                                    MSG_INVALID_SLOTNUMBER_FOR_WAFERIDMINIREAD,         //P5000145
                                    RC_INVALID_SLOTNUMBER_FOR_WAFERIDMINIREAD );        //P5000145
                        return(RC_INVALID_SLOTNUMBER_FOR_WAFERIDMINIREAD);
                    }
                }
                PPT_METHODTRACE_V1("","check for Read  / MiniRead / End is OK");
            }
            //-----------------------------------------------------------------------------------------
            // ActionCode : SP_Sorter_PositionChange/SP_Sorter_JustOut/SP_Sorter_JustIn/SP_Sorter_Scrap
            //-----------------------------------------------------------------------------------------
            else 
            {
                // -------------------------------------------------------------
                // WaferID Existence Check
                //   => WaferID Should be existed
                // -------------------------------------------------------------

                PPT_CONVERT_WAFERID_TO_WAFER_WITH_NO_RETURN(aPosWafer, strWaferSorterSlotMapSequence[i].waferID);
                // -------------------------------------------------------------
                // Case WaferID is not found 
                // => Then Error 
                // -------------------------------------------------------------
                if ( waferFound == FALSE )
                {
                    PPT_METHODTRACE_V2("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                           "WaferID is not found", strWaferSorterSlotMapSequence[i].waferID.identifier);
//P5000145                    PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                        MSG_NOT_FOUND_WAFER,
//P5000145                                        RC_NOT_FOUND_WAFER,
//P5000145                                        "" );
                    SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,       //P5000145
                                MSG_NOT_FOUND_WAFER, RC_NOT_FOUND_WAFER );        //P5000145
                    return(RC_NOT_FOUND_WAFER);
                }
 
                // -------------------------------------------------------------
                // Getting Wafers 
                // => Then Error 
                // -------------------------------------------------------------
                PPT_METHODTRACE_V1("","Checking Current Carrier Information");
                PosCassette_var aCurCassette;
                try
                {
                    MaterialContainer_var aMtrlCntnr;
                    aMtrlCntnr = aPosWafer->getMaterialContainer();
                    aCurCassette = PosCassette::_narrow(aMtrlCntnr);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getMaterialContainer)
                  
                //--------------------------------------------------------------
                // If Carrier information is not found then Error except Just-IN
                //--------------------------------------------------------------
                PPT_METHODTRACE_V1("","Carrier Information Copy");
                CORBA::String_var strCurrentCassetteID;
                CORBA::Long nCurPosition;
                if( CORBA::is_nil(aCurCassette) )
                {
                    if( CIMFWStrCmp(actionCode ,SP_Sorter_JustIn) !=0 )
                    {
                        PPT_SET_MSG_RC_KEY(strWaferSorter_CheckConditionForAction_out,
                                       MSG_NOT_FOUND_CASSETTE,
                                       RC_NOT_FOUND_CASSETTE,
                                       "*****" );
                        return(RC_NOT_FOUND_CASSETTE);
                    }
                    nCurPosition = 0; 
                }
                else
                {
                    // -------------------------------------------------------------
                    // Getting Current Carrier Information
                    // -------------------------------------------------------------
                    try
                    {
                        strCurrentCassetteID = aCurCassette->getIdentifier();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getIdentifier)
                    PPT_METHODTRACE_V3("","cassetteIDs:",i,strCurrentCassetteID);
                    cassetteIDs[i] = CIMFWStrDup( strCurrentCassetteID );

                    // -------------------------------------------------------------
                    // Getting Current SlotPosition Information
                    // -------------------------------------------------------------
                    PPT_METHODTRACE_V1("","GetPosition Information");
                    try
                    {
                        nCurPosition = aPosWafer->getPosition();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getPosition)
                }

                // -------------------------------------------------------------
                // GetLotID for Future Check
                // -------------------------------------------------------------
                PPT_METHODTRACE_V1("","Get Lot Information ");
                Lot_var aTmpLot;
                try
                { 
                    aTmpLot = aPosWafer->getLot();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getLot)

                PPT_METHODTRACE_V1("","Checking Temp Lot ");
                if( CORBA::is_nil(aTmpLot) )
                {
                    PPT_METHODTRACE_V1("","Could not retrieve PosLot from PosWafer");

                    // Error
                    PPT_SET_MSG_RC_KEY(strWaferSorter_CheckConditionForAction_out,
                                       MSG_NOT_FOUND_LOT,
                                       RC_NOT_FOUND_LOT,
                                       "*****" );

                    return(RC_NOT_FOUND_LOT);
                }
                aPosLotSeq[i] = PosLot::_narrow(aTmpLot);

//D9000005 add start
                if (CORBA::is_nil(aPosLotSeq[i]) )
                {
                    PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
                                        MSG_NOT_FOUND_LOT,
                                        RC_NOT_FOUND_LOT,
                                        "*****" );
                    return(RC_NOT_FOUND_LOT);
                }
//D9000005 add end

                CORBA::String_var tmpLotID;
                try
                {
                    tmpLotID = aPosLotSeq[i]->getIdentifier();
                    lotIDs[i] = aPosLotSeq[i]->getIdentifier();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getIdentifier)
                PPT_METHODTRACE_V2("","LotID is ",lotIDs[i]);
           
                //---------------------------------------------------------------------------------------------
                // Destination SlotNumber Check
                //---------------------------------------------------------------------------------------------
                if( (0 > strWaferSorterSlotMapSequence[i].destinationSlotNumber)|| 
//D4100134                   (strWaferSorterSlotMapSequence[i].destinationSlotNumber > atol(theSP_EnvName_MaximumWafersInALot)))
                   (strWaferSorterSlotMapSequence[i].destinationSlotNumber > atol(getenv(SP_EnvName_MaximumWafersInALot))))   //D4100134
                {
                        PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
//D4100134                                 "destinationSlotNumber is not in 1-theSP_EnvName_MaximumWafersInALot ");
                                           "destinationSlotNumber is not in 1-SP_EnvName_MaximumWafersInALot ");
//P5000145                        PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                            MSG_INVALID_WAFER_POSITION,
//P5000145                                            RC_INVALID_WAFER_POSITION,"");
                        SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,                     //P5000145
                                    MSG_INVALID_WAFER_POSITION, RC_INVALID_WAFER_POSITION );        //P5000145
                        return(RC_INVALID_WAFER_POSITION);
                }
//D9000005 add start
                if( 0 == CIMFWStrCmp( actionCode , SP_Sorter_AutoSorting) ) 
                {
                    if( (1 > strWaferSorterSlotMapSequence[i].destinationSlotNumber)||
                       (strWaferSorterSlotMapSequence[i].destinationSlotNumber > atol(getenv(SP_EnvName_MaximumWafersInALot))))
                    {
                            SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,
                                        MSG_INVALID_WAFER_POSITION, RC_INVALID_WAFER_POSITION );
                            return(RC_INVALID_WAFER_POSITION);
                    }
                }
//D9000005 add end

                //---------------------------------------
                // Getting Original Cassette Information
                //---------------------------------------
                CORBA::Boolean cassetteFound = FALSE;
                CORBA::Boolean originalCassetteFound = FALSE;

                PPT_CONVERT_CASSETTEID_TO_CASSETTE_WITH_NO_RETURN(aCassette 
                                              ,strWaferSorterSlotMapSequence[i].originalCassetteID);
                originalCassetteFound = cassetteFound;
            
                //---------------------------------------------------------------------------------------------
                // PositionChange
                //---------------------------------------------------------------------------------------------
                //    Checking Items : 
                //        All bDestinationCassetteManagedBySiView/bOriginalCassetteManagedBySiView must be TRUE
                //                         | Original         |     Destination
                //             ------------+------------------+-------------------
                //             SiView Flag |     TRUE         |        TRUE
                //             Cassette    | MM Registered    |    MM Registered
                //             
                //---------------------------------------------------------------------------------------------
//P4000323      if ( CIMFWStrCmp(actionCode ,SP_Sorter_PositionChange      ) ==0 )
                if ( CIMFWStrCmp(actionCode ,SP_Sorter_PositionChange      ) ==0 ||           //P4000323
                     CIMFWStrCmp(actionCode ,SP_Sorter_AdjustToMM          ) ==0 ||           //P4000323
                     CIMFWStrCmp(actionCode ,SP_Sorter_AutoSorting         ) ==0 ||           //D9000005
                     CIMFWStrCmp(actionCode ,SP_Sorter_AdjustToSorter      ) ==0)             //D4000234
                {
                    if( strWaferSorterSlotMapSequence[i].bDestinationCassetteManagedBySiView != TRUE  ||
                        destinationCassetteFound                                             != TRUE  ||
                        strWaferSorterSlotMapSequence[i].bOriginalCassetteManagedBySiView    != TRUE  ||
                        originalCassetteFound                                                != TRUE )
                    {
                        PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                           "PositionChange:ManagedBy Siview is Invalid");
//P5000145                        PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                            MSG_INVALID_SIVIEWFLAG_FOR_WAFERIDPOSCHANGE,
//P5000145                                            RC_INVALID_SIVIEWFLAG_FOR_WAFERIDPOSCHANGE,"");
                        SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,          //P5000145
                                    MSG_INVALID_SIVIEWFLAG_FOR_WAFERIDPOSCHANGE,         //P5000145
                                    RC_INVALID_SIVIEWFLAG_FOR_WAFERIDPOSCHANGE );        //P5000145
                        return(RC_INVALID_SIVIEWFLAG_FOR_WAFERIDPOSCHANGE);
                    }
                    PPT_METHODTRACE_V1("","check for PositionChange is OK");
                }

                //---------------------------------------------------------------------------------------------
                // JustIn
                //---------------------------------------------------------------------------------------------
                //    Checking Items : 
                //        bDestinationCassetteManagedBySiView must be TRUE
                //        bOriginalCassetteManagedBySiView    must be FALSE 
                //                         | Original         |     Destination
                //             ------------+------------------+-------------------
                //             SiView Flag |     FALSE        |        TRUE
                //             Cassette    | MM Un-Registered |    MM Registered
                //---------------------------------------------------------------------------------------------
                if ( CIMFWStrCmp(actionCode ,SP_Sorter_JustIn) ==0 )
                {
                    if( strWaferSorterSlotMapSequence[i].bDestinationCassetteManagedBySiView != TRUE  ||
                        destinationCassetteFound                                             != TRUE  ||
                        strWaferSorterSlotMapSequence[i].bOriginalCassetteManagedBySiView    != FALSE || 
                        originalCassetteFound                                                != FALSE )
                    {
                        PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                               "JustIn:ManagedBy Siviewis Invalid");
//P5000145                        PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                                MSG_INVALID_SIVIEWFLAG_FOR_JUSTIN,
//P5000145                                                RC_INVALID_SIVIEWFLAG_FOR_JUSTIN,"");
                        SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,                                   //P5000145
                                    MSG_INVALID_SIVIEWFLAG_FOR_JUSTIN, RC_INVALID_SIVIEWFLAG_FOR_JUSTIN );        //P5000145
                        return(RC_INVALID_SIVIEWFLAG_FOR_JUSTIN);
                    }
                    PPT_METHODTRACE_V1("","check for JustInis OK");
                }
    
                //---------------------------------------------------------------------------------------------
                // SP_Sorter_JustOut
                //---------------------------------------------------------------------------------------------
                //    Checking Items : 
                //        bDestinationCassetteManagedBySiView must be TRUE
                //        bOriginalCassetteManagedBySiView    must be FALSE 
                //---------------------------------------------------------------------------------------------
                if ( CIMFWStrCmp(actionCode ,SP_Sorter_JustOut) ==0 )
                {
                    if( strWaferSorterSlotMapSequence[i].bDestinationCassetteManagedBySiView != FALSE ||
                        destinationCassetteFound                                             != FALSE ||
                        strWaferSorterSlotMapSequence[i].bOriginalCassetteManagedBySiView    != TRUE  ||
                        originalCassetteFound                                                != TRUE  )
                    {
                        PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                           "JustOut:ManagedBy Siview is Invalid");
//P5000145                        PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                            MSG_INVALID_SIVIEWFLAG_FOR_JUSTOUT,
//P5000145                                            RC_INVALID_SIVIEWFLAG_FOR_JUSTOUT,"");
                        SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,                                     //P5000145
                                    MSG_INVALID_SIVIEWFLAG_FOR_JUSTOUT, RC_INVALID_SIVIEWFLAG_FOR_JUSTOUT );        //P5000145
                        return(RC_INVALID_SIVIEWFLAG_FOR_JUSTOUT);
                    }
                    PPT_METHODTRACE_V1("","check for SP_Sorter_JustOut/SP_Sorter_Scrap OK");
                }

                //---------------------------------------------------------------------------------------------
                // SP_Sorter_JustOut/SP_Sorter_Scrap
                //---------------------------------------------------------------------------------------------
                //    Checking Items : 
                //        bDestinationCassetteManagedBySiView must be TRUE
                //        bOriginalCassetteManagedBySiView    must be FALSE 
                //---------------------------------------------------------------------------------------------
//D4000220                if ( CIMFWStrCmp(actionCode ,SP_Sorter_Scrap)   ==0 )
//D4000220                {
//D4000220                    if( strWaferSorterSlotMapSequence[i].bDestinationCassetteManagedBySiView != FALSE ||
//D4000220                        destinationCassetteFound                                             != FALSE ||
//D4000220                        strWaferSorterSlotMapSequence[i].bOriginalCassetteManagedBySiView    != TRUE  ||
//D4000220                        originalCassetteFound                                                != TRUE  )
//D4000220                    {
//D4000220                        PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
//D4000220                                           "ScrapOut:ManagedBy Siview is Invalid");
//D4000220                        PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//D4000220                                            MSG_INVALID_SIVIEWFLAG_FOR_SCRAPOUT,
//D4000220                                            RC_INVALID_SIVIEWFLAG_FOR_SCRAPOUT,"");
//D4000220                        return(RC_INVALID_SIVIEWFLAG_FOR_SCRAPOUT);
//D4000220                    }
//D4000220                    PPT_METHODTRACE_V1("","check for SP_Sorter_JustOut/SP_Sorter_Scrap OK");
//D4000220                }

            }
            // ------------------------------------------------------------------------
            // Carrier/Port/Slot Duplicate Check
            // Carrier/Port/Slot should be unique because each slot can have only one wafer
            // ------------------------------------------------------------------------
            for(j=0;j<WaferSorterSlotMapSequenceLen;j++)
            {
                // No Check Same Data
                if( i==j )
                {
                    continue;
                }
                //---------------------------------------------------------
                // Check Destination Information
                // ActionCode : ALL
                //---------------------------------------------------------
                // -------------------
                // Case PortID is Same
                // -------------------
                if(CIMFWStrCmp( strWaferSorterSlotMapSequence[i].destinationPortID.identifier,
                                strWaferSorterSlotMapSequence[j].destinationPortID.identifier) == 0 )
                {
                    // --------------------
                    // Case Carrier is same
                    // --------------------
                    if( CIMFWStrCmp( strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier,
                                    strWaferSorterSlotMapSequence[j].destinationCassetteID.identifier) == 0 ) 
                    {
                        // -----------------------------------
                        // If Slot Number is same then Error
                        // -----------------------------------
                        if ( strWaferSorterSlotMapSequence[i].destinationSlotNumber == strWaferSorterSlotMapSequence[j].destinationSlotNumber )
                        {
                            PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                               "Dupulicate Destination SlotInformation was specified ");
//P5000145                            PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                                MSG_DUPLICATE_LOCATION,
//P5000145                                                RC_DUPLICATE_LOCATION,"");
                            SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,             //P5000145
                                        MSG_DUPLICATE_LOCATION, RC_DUPLICATE_LOCATION );        //P5000145
                            return(RC_DUPLICATE_LOCATION);
                        }
                    }
                   // --------------------------------------------
                   // Carrier is not same on same port then error
                   // --------------------------------------------
                    else
                    {
                        PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                           "Different Destination CARRIER  specified in same Port ");
//P5000145                        PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                            MSG_DIFFERENT_CARRIER_IN_PORT,
//P5000145                                            RC_DIFFERENT_CARRIER_IN_PORT,"");
                        SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,                           //P5000145
                                    MSG_DIFFERENT_CARRIER_IN_PORT, RC_DIFFERENT_CARRIER_IN_PORT );        //P5000145
                        return(RC_DIFFERENT_CARRIER_IN_PORT);
                    
                    }
                }
                // -------------------------
                // Case Port is not Same
                // -------------------------
                else
                {
                    // -------------------------
                    // Case Carrier is not Same
                    // -------------------------
                    if( CIMFWStrCmp( strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier,
                                    strWaferSorterSlotMapSequence[j].destinationCassetteID.identifier) == 0 ) 
                    {
                        PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                           "Same Destination CARRIER  specified in Different Port ");
//P5000145                        PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                            MSG_DUPLICATE_CARRIER,
//P5000145                                            RC_DUPLICATE_CARRIER,"");
                        SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,           //P5000145
                                    MSG_DUPLICATE_CARRIER, RC_DUPLICATE_CARRIER );        //P5000145
                        return(RC_DUPLICATE_CARRIER);
                    }
                }

                //---------------------------------------------------------
                // Check Original Information
                // ActionCode : PositionChange/JustIn/JustOut/Scrap
                //---------------------------------------------------------
                if ( CIMFWStrCmp(actionCode ,SP_Sorter_PositionChange) ==0 ||
                     CIMFWStrCmp(actionCode ,SP_Sorter_JustOut)        ==0 ||
                     CIMFWStrCmp(actionCode ,SP_Sorter_JustIn)         ==0 ||
                     CIMFWStrCmp(actionCode ,SP_Sorter_AdjustToMM)     ==0 ||       //P4000323
                     CIMFWStrCmp(actionCode ,SP_Sorter_AdjustToSorter) ==0 ||       //D4000234
                     CIMFWStrCmp(actionCode ,SP_Sorter_AutoSorting)    ==0 ||       //D9000005
                     CIMFWStrCmp(actionCode ,SP_Sorter_Scrap)          ==0 )
                {
                    if(CIMFWStrCmp( strWaferSorterSlotMapSequence[i].originalPortID.identifier,
                                    strWaferSorterSlotMapSequence[j].originalPortID.identifier) == 0 )
                    {
                        // --------------------
                        // Case Carrier is same
                        // --------------------
                        if( CIMFWStrCmp( strWaferSorterSlotMapSequence[i].originalCassetteID.identifier,
                                        strWaferSorterSlotMapSequence[j].originalCassetteID.identifier) == 0 ) 
                        {
                            // -----------------------------------
                            // If Slot Number is same then Error
                            // -----------------------------------
                            if ( strWaferSorterSlotMapSequence[i].originalSlotNumber == strWaferSorterSlotMapSequence[j].originalSlotNumber )
                            {
                                PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                                   "Dupulicate Original SlotInformation was specified ");
//P5000145                                PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                                    MSG_DUPLICATE_LOCATION,
//P5000145                                                    RC_DUPLICATE_LOCATION,"");
                                SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,             //P5000145
                                            MSG_DUPLICATE_LOCATION, RC_DUPLICATE_LOCATION );        //P5000145
                                return(RC_DUPLICATE_LOCATION);
                            }
                        }
                       // --------------------------------------------
                       // Carrier is not same on same port then error
                       // --------------------------------------------
                        else
                        {
                            PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                               "Different Original CARRIER  specified in same Port ");
//P5000145                            PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                                MSG_DUPLICATE_CARRIER,
//P5000145                                                RC_DUPLICATE_CARRIER,"");
                            SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,           //P5000145
                                        MSG_DUPLICATE_CARRIER, RC_DUPLICATE_CARRIER );        //P5000145
                            return(RC_DUPLICATE_CARRIER);
                        
                        }
                    }
                    // -------------------------
                    // Case Carrier is not Same
                    // -------------------------
                    else
                    {
                        if( CIMFWStrCmp( strWaferSorterSlotMapSequence[i].originalCassetteID.identifier,
                                        strWaferSorterSlotMapSequence[j].originalCassetteID.identifier) == 0 ) 
                        {
                            PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                               "Same Original CARRIER  specified in Different Port ");
//P5000145                            PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                                MSG_DIFFERENT_CARRIER_IN_PORT,
//P5000145                                                RC_DIFFERENT_CARRIER_IN_PORT,"");
                            SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,                           //P5000145
                                        MSG_DIFFERENT_CARRIER_IN_PORT, RC_DIFFERENT_CARRIER_IN_PORT );        //P5000145
                            return(RC_DIFFERENT_CARRIER_IN_PORT);
                        }
                    }
                }
            }
        }  // End of for loop 

        //=========================================================================
        // Prepare AnyData for sorter_waferTransferInfo_Verify
        // because it needs all waferdata in specified lot
        // So this routine adds waferinformation to strWaferTransferSequence 
        // Invoke it only case PositionChange/JustIn/JustOut/Scrap
        //=========================================================================
        //---------------------------------------------------------------------------------------------
        // PositionChange/JustIn/JustOut/Scrap
        //---------------------------------------------------------------------------------------------
        //    Checking Items : 
        //        Send Parameters to sorter_waferTransferInfo_Verify and get return code
        //---------------------------------------------------------------------------------------------
        //-----------------------------------------------------
        // Preparation for Sorter transfer buffer
        //-----------------------------------------------------
        pptWaferTransferSequence strWaferTransferSequence;
        strWaferTransferSequence.length(WaferSorterSlotMapSequenceLen);

        if ( CIMFWStrCmp(actionCode ,SP_Sorter_PositionChange) ==0 || 
             CIMFWStrCmp(actionCode ,SP_Sorter_JustOut)        ==0 ||
             CIMFWStrCmp(actionCode ,SP_Sorter_JustIn)         ==0 ||
             CIMFWStrCmp(actionCode ,SP_Sorter_AutoSorting)    ==0 ||    //D9000005
             CIMFWStrCmp(actionCode ,SP_Sorter_Scrap)          ==0 )
        {
            PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                           "Check Parameters using sorter_waferTransferInfo_Verify" );

            //======================================================
            //   Copy Variable for Data check
            //======================================================
            for( i = 0; i < WaferSorterSlotMapSequenceLen ; i++)
            {
                //-------------------------------------
                // Copy variables for future data check
                //-------------------------------------
                strWaferTransferSequence[i].waferID               
                                       = strWaferSorterSlotMapSequence[i].waferID;
                strWaferTransferSequence[i].destinationCassetteID 
                                       = strWaferSorterSlotMapSequence[i].destinationCassetteID;
                strWaferTransferSequence[i].bDestinationCassetteManagedBySiView 
                                       = strWaferSorterSlotMapSequence[i].bDestinationCassetteManagedBySiView;
                strWaferTransferSequence[i].destinationSlotNumber 
                                       = strWaferSorterSlotMapSequence[i].destinationSlotNumber;
                strWaferTransferSequence[i].originalCassetteID    
                                       = strWaferSorterSlotMapSequence[i].originalCassetteID;
                strWaferTransferSequence[i].bOriginalCassetteManagedBySiView 
                                       = strWaferSorterSlotMapSequence[i].bOriginalCassetteManagedBySiView;
                strWaferTransferSequence[i].originalSlotNumber    
                                       = strWaferSorterSlotMapSequence[i].originalSlotNumber;
            }

            CORBA::Long   VerifyCount = WaferSorterSlotMapSequenceLen ;
            //-----------------------------------------------------------------------------
            // Add Other wafers that are on same lot to call sorter_waferTransferInfo_Verify
            //-----------------------------------------------------------------------------
            CORBA::Long LotLen= lotIDs.length();

            for( i = 0 ; i < LotLen ; i++ )
            {
                //-----------------------------------------------------------------------------
                // Getting All Wafers from LotID
                //-----------------------------------------------------------------------------
                MaterialSequence_var aMtrlSeq;
                try
                {
                    aMtrlSeq = aPosLotSeq[i]->allMaterial();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::allMaterial)

                CORBA::Long nLotWaferLen=0;
                nLotWaferLen = aMtrlSeq->length();

                PPT_METHODTRACE_V1("Lot Count is ",nLotWaferLen );
                for(j=0; j<nLotWaferLen ; j++) 
                {
                    CORBA::Boolean bLotWaferFound = FALSE;
                    CORBA::String_var strLotWaferID;
                    try
                    {
                        strLotWaferID = (*aMtrlSeq)[j]->getIdentifier();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(Material::getIdentifier)
 
                    CORBA::Long nCurPosition=0;
                    if (CIMFWStrCmp(actionCode ,SP_Sorter_JustIn) !=0 )
                    {
                        try
                        {
                            nCurPosition = (*aMtrlSeq)[j]->getPosition();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getPosition)
                    }

                    // ---------------------------------------------------
                    // If Wafers re not copied to strWaferTransferSequence
                    // ---------------------------------------------------
                    PPT_METHODTRACE_V3("Checking Wafer:Target ", strLotWaferID,":",VerifyCount );

                    // ---------------------------------------------------
                    // Add Wafers that are not on verified wafer sequence 
                    // ---------------------------------------------------
                    for ( k = 0 ; k < VerifyCount ; k++ )
                    {
                        PPT_METHODTRACE_V3("Checking Wafer ", k,":",strWaferTransferSequence[k].waferID.identifier);
                        // ---------------------------------------------------
                        // If there are same waferID in verified sequence then return 
                        // ---------------------------------------------------
                        if( CIMFWStrCmp( strLotWaferID,strWaferTransferSequence[k].waferID.identifier) ==0 )
                        {
                            break;
                        }
                        // -----------------------------------------------------------------------
                        // If not found wafer then add these after check duplicate position check
                        // -----------------------------------------------------------------------
                        if( k == ( VerifyCount - 1 ))
                        {
                            // -----------------------------------------------------------------------
                            // Check same position is existed on transfered structure
                            // -----------------------------------------------------------------------
                            PPT_METHODTRACE_V1("Check Adding wafers are not duplicated location",strLotWaferID);
                            for( l = 0; l < WaferSorterSlotMapSequenceLen ; l++)
                            {
                                // If there are same cassette/position found in strWaferSorterSlotMapSequence
                                // then error
                                if( CIMFWStrCmp(strWaferSorterSlotMapSequence[l].destinationCassetteID.identifier,cassetteIDs[i]) ==0 &&
                                    strWaferSorterSlotMapSequence[l].destinationSlotNumber == nCurPosition )
                                {
                                    PPT_METHODTRACE_V3("","There are waferID on specified location cassete/slotnumber",
                                                          cassetteIDs[i],nCurPosition);

//D9000001 add start
                                    char buf[128];
                                    memset(buf,'\0',sizeof(buf));
                                    sprintf(buf, "%d", strWaferSorterSlotMapSequence[l].destinationSlotNumber);
//D9000001 add end

                                    PPT_SET_MSG_RC_KEY3(strWaferSorter_CheckConditionForAction_out, 
                                               MSG_INVALID_DEST_WAFER_POSITION,
                                               RC_INVALID_DEST_WAFER_POSITION,
                                               strWaferSorterSlotMapSequence[l].waferID.identifier,
//D9000001                                               (const char*)strWaferSorterSlotMapSequence[l].destinationSlotNumber,
                                               buf,    //D9000001
                                               strWaferSorterSlotMapSequence[l].destinationCassetteID.identifier);
                                    return(RC_INVALID_DEST_WAFER_POSITION);
                                }
                            }

                            PPT_METHODTRACE_V1("Adding to check wafers ",strLotWaferID);
                            strWaferTransferSequence.length(VerifyCount+1);
                            strWaferTransferSequence[VerifyCount].waferID.identifier
                                       = CIMFWStrDup(strLotWaferID);

                            //P40A0007 Add Start
                            PosWafer_var   aPosWaferTemp;
                            PPT_CONVERT_WAFERID_TO_WAFER_WITH_NO_RETURN(aPosWaferTemp, strWaferTransferSequence[VerifyCount].waferID);

                            // -------------------------------------------------------------
                            // Case WaferID is not found
                            // => Then Error
                            // -------------------------------------------------------------
                            if ( waferFound == FALSE )
                            {
                                PPT_METHODTRACE_V2("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                                                "WaferID is not found", strLotWaferID);
//P5000145                                PPT_SET_MSG_RC_KEY( strWaferSorter_CheckConditionForAction_out,
//P5000145                                                    MSG_NOT_FOUND_WAFER,
//P5000145                                                    RC_NOT_FOUND_WAFER,
//P5000145                                                    "" );
                                SET_MSG_RC( strWaferSorter_CheckConditionForAction_out,       //P5000145
                                            MSG_NOT_FOUND_WAFER, RC_NOT_FOUND_WAFER );        //P5000145
                                return(RC_NOT_FOUND_WAFER);
                            }

                            // -------------------------------------------------------------
                            // Getting Wafers
                            // => Then Error
                            // -------------------------------------------------------------
                            PPT_METHODTRACE_V1("","Checking Current Carrier Information");
                            PosCassette_var aCurCassetteTemp;
                            try
                            {
                                MaterialContainer_var aMtrlCntnrTemp;
                                aMtrlCntnrTemp = aPosWaferTemp->getMaterialContainer();
                                aCurCassetteTemp = PosCassette::_narrow(aMtrlCntnrTemp);
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getMaterialContainer)

                            if( ! CORBA::is_nil(aCurCassetteTemp) )
                            {
                                // -------------------------------------------------------------
                                // Getting Current Carrier Information
                                // -------------------------------------------------------------
                                PPT_METHODTRACE_V1("","GetCarrier Information");
                                CORBA::String_var strCurrentCassetteIDTemp;
                                try
                                {
                                    strCurrentCassetteIDTemp = aCurCassetteTemp->getIdentifier();
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getIdentifier)
                                PPT_METHODTRACE_V2("","strCurrentCassetteIDTemp:", strCurrentCassetteIDTemp);
                                strWaferTransferSequence[VerifyCount].destinationCassetteID.identifier = CIMFWStrDup( strCurrentCassetteIDTemp);
                                strWaferTransferSequence[VerifyCount].originalCassetteID.identifier    = CIMFWStrDup( strCurrentCassetteIDTemp);
                                // -------------------------------------------------------------
                                // Getting Current SlotPosition Information
                                // -------------------------------------------------------------
                                PPT_METHODTRACE_V1("","GetPosition Information");
                                try
                                {
                                    nCurPosition = aPosWaferTemp->getPosition();
                                }
                                CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getPosition)
                                PPT_METHODTRACE_V2("","nCurPosition:", nCurPosition);
                                strWaferTransferSequence[VerifyCount].destinationSlotNumber = nCurPosition;
                                strWaferTransferSequence[VerifyCount].originalSlotNumber    = nCurPosition;

                                strWaferTransferSequence[VerifyCount].bDestinationCassetteManagedBySiView
                                       = TRUE;
                                strWaferTransferSequence[VerifyCount].bOriginalCassetteManagedBySiView
                                       = TRUE;
                            }
                            else
                            {
                                strWaferTransferSequence[VerifyCount].bDestinationCassetteManagedBySiView
                                       = FALSE;
                                strWaferTransferSequence[VerifyCount].bOriginalCassetteManagedBySiView
                                       = FALSE;
                            }
                            //P40A0007 Add End

//P40A0007                            strWaferTransferSequence[VerifyCount].destinationCassetteID.identifier
//P40A0007                                       = CIMFWStrDup(cassetteIDs[i]);
//P40A0007                            if ( CIMFWStrCmp(actionCode ,SP_Sorter_JustIn) == 0 )
//P40A0007                            {        
//P40A0007                                strWaferTransferSequence[VerifyCount].bDestinationCassetteManagedBySiView 
//P40A0007                                       = FALSE;
//P40A0007                                strWaferTransferSequence[VerifyCount].bOriginalCassetteManagedBySiView 
//P40A0007                                       = FALSE;
//P40A0007                            }
//P40A0007                            else
//P40A0007                            {
//P40A0007                                strWaferTransferSequence[VerifyCount].bDestinationCassetteManagedBySiView 
//P40A0007                                       = TRUE;
//P40A0007                                strWaferTransferSequence[VerifyCount].bOriginalCassetteManagedBySiView 
//P40A0007                                       = TRUE;
//P40A0007                            }
//P40A0007                            strWaferTransferSequence[VerifyCount].destinationSlotNumber 
//P40A0007                                       = nCurPosition;
//P40A0007                            strWaferTransferSequence[VerifyCount].originalCassetteID.identifier
//P40A0007                                       = CIMFWStrDup(cassetteIDs[i]);
//P40A0007                            strWaferTransferSequence[VerifyCount].originalSlotNumber    
//P40A0007                                       = nCurPosition;
                            VerifyCount++;
                        }
                        // ------------------------------------------------------
                        // When Exceed LotID x theSP_EnvName_MaximumWafersInALot 
                        // ------------------------------------------------------
//D4100134              if( VerifyCount > (nLotWaferLen*atol(theSP_EnvName_MaximumWafersInALot)))
                        if( VerifyCount > (nLotWaferLen*atol(getenv(SP_EnvName_MaximumWafersInALot))))   //D4100134
                        {
//D4100134                  PPT_METHODTRACE_V1("WaferID Number Exceed than ",nLotWaferLen*atol(theSP_EnvName_MaximumWafersInALot));
                            PPT_METHODTRACE_V1("WaferID Number Exceed than ",nLotWaferLen*atol(getenv(SP_EnvName_MaximumWafersInALot)));
                            SET_MSG_RC(strWaferSorter_CheckConditionForAction_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
                            return(RC_SYSTEM_ERROR);
                        }
                    }
                    PPT_METHODTRACE_V3("Checking Wafer End :Target ", strLotWaferID,":",VerifyCount );
                }

            }
            //---------------------------------------------------------------
            // Check Strusture data for wafer transfer (Sorter operation)
            //---------------------------------------------------------------
            PPT_METHODTRACE_V1(""," Executing sorter_waferTransferInfo_Verify" );
            objSorter_waferTransferInfo_Verify_out strSorter_waferTransferInfo_Verify_out;
            rc = sorter_waferTransferInfo_Verify(strSorter_waferTransferInfo_Verify_out, strObjCommonIn,
                                                 strWaferTransferSequence,  // D4000135
                                                 SP_Sorter_Location_CheckBy_SlotMap);   
            // --------------------------------------------------------------
            // If Error Occures
            // --------------------------------------------------------------
            if ( rc != 0 )
            {
                    PPT_METHODTRACE_V2("", "sorter_waferTransferInfo_Verify returns != 0 : RC = ",rc);
                    strWaferSorter_CheckConditionForAction_out.strResult = strSorter_waferTransferInfo_Verify_out.strResult;
                    return(rc);
            }
            PPT_METHODTRACE_V1("","check for sorter_waferTransferInfo_Verify OK");
            //---------------------------------------
            // Check input parameter and
            // Server data condition
            //---------------------------------------
            objCassette_CheckConditionForWaferSort_out strCassette_CheckConditionForWaferSort_out;
            rc = cassette_CheckConditionForWaferSort( strCassette_CheckConditionForWaferSort_out,
                                                      strObjCommonIn,
                                                      equipmentID,
                                                      strWaferTransferSequence);
            if(rc)
            {
                PPT_METHODTRACE_V1("CS_PPTManager_i:: waferSorter_CheckConditionForAction", "cassette_CheckConditionForWaferSort() rc != RC_OK");
                strWaferSorter_CheckConditionForAction_out.strResult  = strCassette_CheckConditionForWaferSort_out.strResult;
                return( rc );
            }
            PPT_METHODTRACE_V1("","check for cassette_CheckConditionForWaferSort OK");
        }

        PPT_METHODTRACE_V1("CS_PPTManager_i::waferSorter_CheckConditionForAction",
                           "Assignning Default value for SlotMap ");

        // --------------------------------------------------------------
        // If Copy input condition structure to output Structure
        // --------------------------------------------------------------
        strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence = strWaferSorterSlotMapSequence;

        //======================================================
        //    Assign Default Data to Structure Variable for TCS's Job
        //======================================================
        for( i = 0; i < WaferSorterSlotMapSequenceLen ; i++)
        {
            //-----------------------------------------------------------------------------
            // Common Routine
            //-----------------------------------------------------------------------------
//P4200546            strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].requestTime
//P4200546                             = (const char *)CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);

//D9000005            strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].requestTime
//D9000005                                       = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);        //P4200546
//D9000005 add start
            if ( 0 == CIMFWStrCmp( actionCode, SP_Sorter_AutoSorting ) )
            {
                PPT_METHODTRACE_V1("", "actionCode == Auto Sorting");
                strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].requestTime
                                           = strWaferSorterSlotMapSequence[i].requestTime;
            }
            else
            {
                strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].requestTime
                                           = CIMFWStrDup(strObjCommonIn.strTimeStamp.reportTimeStamp);
            }
//D9000005 add end

            strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].slotMapCompareStatus
                             = (const char *)"";
            strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].mmCompareStatus
                             = (const char *)"";

            if ( CIMFWStrCmp(actionCode ,SP_Sorter_Read)     ==0 ||
                 CIMFWStrCmp(actionCode ,SP_Sorter_MiniRead) ==0 )
            {
//D9000005                strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].waferID.identifier
//D9000005                             = (const char *)"";
//D9000005                strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].lotID.identifier
//D9000005                             = (const char *)"";
//D9000005                strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].originalCassetteID.identifier
//D9000005                             = (const char *)"";
//D9000005                strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].originalPortID.identifier
//D9000005                             = (const char *)"";
//D9000005                strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].bOriginalCassetteManagedBySiView = FALSE;
//D9000005                strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].originalSlotNumber = 0;
//D9000005                if ( CIMFWStrCmp(actionCode ,SP_Sorter_Read)     ==0 )
//D9000005                {
//D9000005                    strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].destinationSlotNumber = 0;
//D9000005                }
//D9000005 add start
                strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].waferID.identifier               = (const char *)"";
                strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].lotID.identifier                 = (const char *)"";
                strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].originalCassetteID.identifier    = strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier;
                strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].originalPortID.identifier        = strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].destinationPortID.identifier;
                strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].bOriginalCassetteManagedBySiView = strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].bDestinationCassetteManagedBySiView;
                strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].originalSlotNumber               = strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].destinationSlotNumber;

                if ( CIMFWStrCmp(actionCode ,SP_Sorter_Read)     ==0 )
                {
                    strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].destinationSlotNumber = 0;
                    strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].originalSlotNumber    = 0;
                }

                PPT_METHODTRACE_V2("","==== Output Param of strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i],  i = ",i);
                PPT_METHODTRACE_V2("","portGroup                           = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].portGroup);
                PPT_METHODTRACE_V2("","equipmentID                         = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].equipmentID.identifier);
                PPT_METHODTRACE_V2("","actionCode                          = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].actionCode);
                PPT_METHODTRACE_V2("","requestTime                         = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].requestTime);
                PPT_METHODTRACE_V2("","direction                           = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].direction);
                PPT_METHODTRACE_V2("","waferID                             = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].waferID.identifier);
                PPT_METHODTRACE_V2("","lotID                               = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].lotID.identifier);
                PPT_METHODTRACE_V2("","destinationCassetteID               = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier);
                PPT_METHODTRACE_V2("","destinationPortID                   = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].destinationPortID.identifier);
                PPT_METHODTRACE_V2("","bDestinationCassetteManagedBySiView = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].bDestinationCassetteManagedBySiView);
                PPT_METHODTRACE_V2("","destinationSlotNumber               = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].destinationSlotNumber);
                PPT_METHODTRACE_V2("","originalCassetteID                  = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].originalCassetteID.identifier);
                PPT_METHODTRACE_V2("","originalPortID                      = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].originalPortID.identifier);
                PPT_METHODTRACE_V2("","bOriginalCassetteManagedBySiView    = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].bOriginalCassetteManagedBySiView);
                PPT_METHODTRACE_V2("","originalSlotNumber                  = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].originalSlotNumber);
                PPT_METHODTRACE_V2("","requestUserID                       = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].requestUserID.identifier);
                PPT_METHODTRACE_V2("","replyTime                           = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].replyTime);
                PPT_METHODTRACE_V2("","sorterStatus                        = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].sorterStatus);
                PPT_METHODTRACE_V2("","slotMapCompareStatus                = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].slotMapCompareStatus);
                PPT_METHODTRACE_V2("","mmCompareStatus                     = ",strWaferSorter_CheckConditionForAction_out.strWaferSorterSlotMapSequence[i].mmCompareStatus);
                PPT_METHODTRACE_V1("","==========================================================================================================");

//D9000005 add end
            }
        }
//INN-R170002 Add Start
        //======================================================
        // Check Contamination level for destination Cassette
        //======================================================
        if ( CIMFWStrCmp(actionCode ,SP_Sorter_PositionChange) ==0 || 
             CIMFWStrCmp(actionCode ,SP_Sorter_JustIn)         ==0 )
        {
            objectIdentifierSequence moveToCassetteIDSeq;
            objectIdentifierSequence lotIDs;
            CORBA::Long lenDesCasIDSeq   = 0;
            CORBA::Long lenLotIDSeq      = 0;
            CORBA::Long i_wfr            = 0;
            CORBA::Long j_cas            = 0;
            CORBA::Long k_lot            = 0;
            CORBA::Boolean bCassetteFind = FALSE;
            CORBA::Boolean bLotFind      = FALSE;
            moveToCassetteIDSeq.length(0);
            lotIDs.length(0);
            for( i = 0; i < WaferSorterSlotMapSequenceLen ; i++)
            {
                //---------------------------------------
                // Collect CassetteID of MoveToCassette
                //---------------------------------------
                if ( TRUE == strWaferSorterSlotMapSequence[i].bDestinationCassetteManagedBySiView )
                {
                    if( 0 <  CIMFWStrLen(strWaferSorterSlotMapSequence[i].originalCassetteID.identifier)
                     && 0 <  CIMFWStrLen(strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier)
                     && 0 != CIMFWStrCmp(strWaferSorterSlotMapSequence[i].originalCassetteID.identifier, strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier) )
                    {
                        bCassetteFind = FALSE;

                        lenDesCasIDSeq = moveToCassetteIDSeq.length();
                        PPT_METHODTRACE_V2("", "lenDesCasIDSeq-->", lenDesCasIDSeq);

                        for ( j_cas = 0; j_cas < lenDesCasIDSeq; j_cas++ )
                        {
                            if ( 0 == CIMFWStrCmp(strWaferSorterSlotMapSequence[i].destinationCassetteID.identifier, moveToCassetteIDSeq[j_cas].identifier) )
                            {
                                PPT_METHODTRACE_V2("", "set bCassetteFind = TRUE", j_cas);
                                bCassetteFind = TRUE;
                                break;
                            }
                        }
                        if ( bCassetteFind == FALSE )
                        {
                            PPT_METHODTRACE_V1("", "bCassetteFind == FALSE");
                            lenDesCasIDSeq++;
                            moveToCassetteIDSeq.length(lenDesCasIDSeq);
                            moveToCassetteIDSeq[lenDesCasIDSeq-1] = strWaferSorterSlotMapSequence[i].destinationCassetteID;
                        }
                    }
                }
            }

            //------------------------------------------------
            // Check Lot Contamination for Wafer Sorter
            //------------------------------------------------
            for ( j_cas = 0; j_cas < lenDesCasIDSeq; j_cas++ )
            {
                lenLotIDSeq = 0;
                for ( i_wfr = 0; i_wfr < WaferSorterSlotMapSequenceLen; i_wfr++ )
                {
                    if ( TRUE == strWaferSorterSlotMapSequence[i_wfr].bDestinationCassetteManagedBySiView )
                    {
                        if( 0 <  CIMFWStrLen(strWaferSorterSlotMapSequence[i_wfr].originalCassetteID.identifier)
                         && 0 <  CIMFWStrLen(strWaferSorterSlotMapSequence[i_wfr].destinationCassetteID.identifier)
                         && 0 != CIMFWStrCmp(strWaferSorterSlotMapSequence[i_wfr].originalCassetteID.identifier, strWaferSorterSlotMapSequence[i_wfr].destinationCassetteID.identifier) )
                        {
                            if( 0 == CIMFWStrCmp(moveToCassetteIDSeq[j_cas].identifier, strWaferSorterSlotMapSequence[i_wfr].destinationCassetteID.identifier) )
                            {
                                objWafer_lot_Get_out strWafer_lot_Get_out;
                                rc = wafer_lot_Get(strWafer_lot_Get_out, strObjCommonIn, strWaferSorterSlotMapSequence[i_wfr].waferID);
                                if(rc!= RC_OK)
                                {
                                    PPT_METHODTRACE_V2("", "wafer_lot_Get() != RC_OK", strWaferSorterSlotMapSequence[i_wfr].waferID.identifier);
                                    strWaferSorter_CheckConditionForAction_out.strResult = strWafer_lot_Get_out.strResult;
                                    return( rc );
                                }

                                bLotFind = FALSE;

                                lenLotIDSeq = lotIDs.length();
                                PPT_METHODTRACE_V2("", "lenDesCasIDSeq-->", lenDesCasIDSeq);

                                for ( k_lot = 0; k_lot < lenLotIDSeq; k_lot++ )
                                {
                                    if ( 0 == CIMFWStrCmp(strWafer_lot_Get_out.lotID.identifier, lotIDs[k_lot].identifier) )
                                    {
                                        PPT_METHODTRACE_V2("", "set bLotFind = TRUE", k_lot);
                                        bLotFind = TRUE;
                                        break;
                                    }
                                }
                                if ( bLotFind == FALSE )
                                {
                                    PPT_METHODTRACE_V1("", "bLotFind == FALSE");
                                    lenLotIDSeq++;
                                    lotIDs.length(lenLotIDSeq);
                                    lotIDs[lenLotIDSeq-1] = strWafer_lot_Get_out.lotID;
                                }
                            }
                        }
                    }
                }

                csObjLot_ContaminationInfo_CheckForCarrierExchange_out strLot_ContaminationInfo_CheckForCarrierExchange_out; 
                csObjLot_ContaminationInfo_CheckForCarrierExchange_in  strLot_ContaminationInfo_CheckForCarrierExchange_in;
                strLot_ContaminationInfo_CheckForCarrierExchange_in.carrierID = moveToCassetteIDSeq[j_cas];
                strLot_ContaminationInfo_CheckForCarrierExchange_in.lotIDs    = lotIDs;
                rc = cs_lot_ContaminationInfo_CheckForCarrierExchange(strLot_ContaminationInfo_CheckForCarrierExchange_out,
                                                                      strObjCommonIn,
                                                                      strLot_ContaminationInfo_CheckForCarrierExchange_in);
                if(rc!= RC_OK)
                {
                    PPT_METHODTRACE_V2("", "cs_lot_ContaminationInfo_CheckForCarrierExchange() != RC_OK", moveToCassetteIDSeq[j_cas].identifier);
                    strWaferSorter_CheckConditionForAction_out.strResult = strLot_ContaminationInfo_CheckForCarrierExchange_out.strResult;
                    return( rc );
                }
            }
        }
//INN-R170002 Add End
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::waferSorter_CheckConditionForAction");
        return (RC_OK) ;
    }
    CATCH_GLOBAL_EXCEPTIONS(strWaferSorter_CheckConditionForAction_out,  
                            waferSorter_CheckConditionForAction,
                            methodName)
}
