// @(#) 1.3 superpos/src/csppt/source/posppt/pptmgr/objmethd/cs_objmethod.hpp, mm_srv_5_0_cspp, mm_srv_5_0_cspp 6/9/03 14:23:08 [ 6/9/03 14:23:09 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView         : MMS
// File Name      : cs_objmethod.hpp
// Description    : Declaration Customized obj Method
//
// ** Notice **
//   This is a sample code for customizing a PPT ServiceManager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT ServiceManager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//
// Change history:

//
// Date       Defect#   Person         Comments
// ---------- --------- -------------- -------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya      Initial Release for R5.0
//
// Innotron Modification history :
// Date       Defect#         Person               Comments
// ---------- --------------- -------------------- -------------------------------------------
// 2017/08/02 INN-A170001     Mike Chang           INN-A170001:RMS enabling
// 2017/08/28 INN-R170002     Yang Xigang          Add for contamination control
// 2017/08/29 INN-R170001     Gary Ke              INN-R170001: Add for Durable Sub Status Control 
// 2017/08/30 INN-R170003     Helios Zhen          INN-R170003:Durable Management Enhancement
// 2017/08/30 INN-C170001     Gary Ke              INN-C170001: Add for Durable Sub Status Control
// 2017/07/25 INN-R170084     Jacky Yeh            170084: Automatic Vendor Lot Receive and Prepare
// 2017/09/04 INN-R170008     Menghua Yin          TA Certify
// 2017/09/06 INN-R170002     Thomas Song          Add lot_SplitWaferLot
// 2017/09/11 INN-R170003     Gary Ke              INN-R170003: Add for Durable Management Enhancement
// 2017/08/28 INN-R170006     YangXigang           For fixture
// 2017/09/14 INN-R170003     Li Hejing            For Durable Management
// 2017/09/15 INN-R170009     Gary Ke              INN-R170009: User Data Get by Operation
// 2017/09/18 INN-R170014     shenql               INN-R170014: User Data Get by Operation
// 2017/09/18 INN-R170003     Li Hejing            For Durable Management
// 2017/09/18 INN-R170003     Jun Zhang            New Transfer State PI/PO
// 2017/09/21 INN-R170001     Vera Chen            Lot ID naming rule
// 2017/09/21 INN-R170012     Vera Chen            FOUP Exchanger Support
// 2017/09/22 INN-R170001     Vera Chen            Add lotType_lotID_Assign,cs_lotID_ControlInfo_GetDR,cs_lotID_ControlInfo_SetDR
// 2017/09/26 INN-R170009     liu Xinxin           Add litho APC Enhancement
// 2017/09/28 INN-R170006     Sam Hsueh            Add cs_fixture_touchCount_Get, cs_wafer_userDataInfo_GetDR, cs_durable_userDataInfo_GetDR
// 2017/09/29 INN-R170006     Sam Hsueh            Add controlJob_startReserveInformation_Get
// 2017/10/03 INN-A170007     Sam Hsueh            Add lot_CheckConditionForLoading
// 2017/10/10 INN-A170003     YangXigang           Durable Management
// 2017/10/11 INN-R170012     Vera Chen            Add equipment_operationModeCombination_Check
// 2017/10/16 INN-R170023     Sam Hsueh            Add process_startReserveInformation_Get
// 2017/10/17 INN_R170009     Qufd                 Add APC Queue
// 2017/10/18 INN-R170016     JQ.Shao              NPW Management Initial Release
// 2017/10/19 INN-R170017     LiHejing             Add WaferList Get,Add,Delete
// 2017/10/19 INN-R170027     Vera Chen            NPW Product Change

#ifndef CS_ObjMethod_hpp
#define CS_ObjMethod_hpp

// Declare Customized obj Method here
//INN-A170001 Add Start
virtual CORBA::Long environmentVariable_Set(
                   objEnvironmentVariable_Set_out& strEnvironmentVariable_Set_out,
                   const pptObjCommonIn& strObjCommonIn,
                   const pptEnvVariableListSequence& strPptEnvVariable);

virtual CORBA::Long environmentVariable_Get(
                   objEnvironmentVariable_Get_out& strEnvironmentVariable_Get_out,
                   const pptObjCommonIn& strObjCommonIn);

virtual CORBA::Long cs_equipment_InAuditList_GetDR
(
    csObjEquipment_InAuditList_GetDR_out&   strCsObjEquipment_InAuditList_GetDR_out,
    const pptObjCommonIn&                   strObjCommonIn,
    CORBA::Boolean                          bodyFlag,
    CORBA::Boolean                          constFlag
);

virtual CORBA::Long cs_equipment_ListByOwnerDR
(
    csObjEquipment_ListByOwnerDR_out&      strCsObjEquipment_ListByOwnerDR_out,
    const pptObjCommonIn&                  strObjCommonIn,
    const objectIdentifier&                equipmentOwnerID
);

virtual CORBA::Long cs_equipment_constantsManageFlag_Get
(
    csObjEquipment_constantsManageFlag_Get_out&  strObjEquipment_constantsManageFlag_Get_out,
    const pptObjCommonIn&                        strObjCommonIn,
    const objectIdentifier&                      equipmentID
);

virtual CORBA::Long cs_recipe_compareFlag_Get(
    csObjRecipe_compareFlag_Get_out&       strCsObjRecipe_compareFlag_Get,
    const pptObjCommonIn&                  strObjCommonIn,
    const stringSequence&                  machineRecipeIDs
);

virtual CORBA::Long cs_RMSMgr_SendRecipeAuditReq
(
    csObjRMSMgr_SendRecipeAuditReq_out&         strRMSMgr_SendRecipeAuditReq_out,
    const pptObjCommonIn&                       strObjCommonIn,
    const objectIdentifier&                     equipmentID,
    const objectIdentifier&                     machineRecipeID,
    CORBA::Boolean                              bolEqpConstFlag,
    CORBA::Boolean                              bolBodyFlag
);

virtual CORBA::Long cs_RMSMgr_GetServiceManager
(
    csObjRMSMgr_GetServiceManager_out& strRMSMgr_GetServiceManager_out,
    const pptObjCommonIn&              strObjCommonIn,
    const char*                        RMSServerName,
    const char*                        RMSHostName
);

virtual CORBA::Long equipment_recipeBodyManageFlag_Get(
    objEquipment_recipeBodyManageFlag_Get_out&   strEquipment_recipeBodyManageFlag_Get_out,
    const pptObjCommonIn&                        strObjCommonIn,
    const objectIdentifier&                      equipmentID
);

virtual CORBA::Long machineRecipe_GetListForRecipeBodyManagement(
    objMachineRecipe_GetListForRecipeBodyManagement_out&       strMachineRecipe_GetListForRecipeBodyManagement_out,
    const pptObjCommonIn&                                      strObjCommonIn,
    const objMachineRecipe_GetListForRecipeBodyManagement_in&  strMachineRecipe_GetListForRecipeBodyManagement_in
);

virtual CORBA::Long cs_person_PrivilegeCheckForRMS
(
    csObjPerson_PrivilegeCheckForRMS_out&  strCsObjPerson_PrivilegeCheckForRMS,
    const pptObjCommonIn&                  strObjCommonIn,
    const objectIdentifier&                equipmentID
);

virtual CORBA::Long cs_equipmentInfo_ListByOwnerDR
(
    csObjEquipmentInfo_ListByOwnerDR_out&  strCsObjEquipmentInfo_ListByOwnerDR_out,
    const pptObjCommonIn&                  strObjCommonIn,
    const objectIdentifier&                equipmentOwnerID
);

virtual CORBA::Long cs_equipment_machine_and_physicalRecipeID_auditFlag_GetDR
(
    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out& strEquipment_machine_and_physicalRecipeID_GetDR_out,
    const pptObjCommonIn& strObjCommonIn,
    objectIdentifier equipmentID,
    CORBA::Boolean getAuditFlag
);
//INN-A170001 Add End

//Sample 
virtual CORBA::Long cs_sample_Obj(
                                 objSample_Obj_out& strSample_Obj_out,
                                 const pptObjCommonIn& strObjCommonIn ) ;
virtual CORBA::Long cs_testFunction(
								objTestFunction_Obj_out& strTestFunction_Obj_out,
                                 const pptObjCommonIn& strObjCommonIn,
                                 const char* claimMemo ) ;
								 
								 
//INN-R170002 Add Start								 
virtual CORBA::Long lot_CassetteCategory_UpdateForContaminationControl
(
    objLot_CassetteCategory_UpdateForContaminationControl_out& strLot_CassetteCategory_UpdateForContaminationControl_out,
    const pptObjCommonIn& strObjCommonIn,
    const objectIdentifier& lotID
);

virtual CORBA::Long lot_requiredCassetteCategory_GetForNextOperation
(
    objLot_requiredCassetteCategory_GetForNextOperation_out& strLot_requiredCassetteCategory_GetForNextOperation_out,
    const pptObjCommonIn& strObjCommonIn,
    const objectIdentifier& lotID
);

virtual CORBA::Long cs_lot_requiredCarrierCategory_CheckDR
(
    csObjLot_requiredCarrierCategory_CheckDR_out& strLot_requiredCarrierCategory_CheckDR_out,
    const pptObjCommonIn& strObjCommonIn,
    const csObjLot_requiredCarrierCategory_CheckDR_in& strLot_requiredCarrierCategory_CheckDR_in 
);

virtual CORBA::Long lot_BankInCancel
(
    objLot_BankInCancel_out&  strLot_BankInCancel_out,
    const pptObjCommonIn&     strObjCommonIn,
    const objectIdentifier&   lotID
);

virtual CORBA::Long lot_DBInfo_GetDR__160
(
    objLot_DBInfo_GetDR_out__160&   strLot_DBInfo_GetDR_out,
    const pptObjCommonIn&    strObjCommonIn,
    const objectIdentifier&  lotID,
    const CORBA::Boolean&    lotBasicInfoFlag,
    const CORBA::Boolean&    lotControlUseInfoFlag,
    const CORBA::Boolean&    lotFlowBatchInfoFlag,
    const CORBA::Boolean&    lotNoteFlagInfoFlag,
    const CORBA::Boolean&    lotOperationInfoFlag,
    const CORBA::Boolean&    lotOrderInfoFlag,
    const CORBA::Boolean&    lotControlJobInfoFlag,
    const CORBA::Boolean&    lotProductInfoFlag,
    const CORBA::Boolean&    lotRecipeInfoFlag,
    const CORBA::Boolean&    lotLocationInfoFlag,
    const CORBA::Boolean&    lotWipOperationInfoFlag,
    const CORBA::Boolean&    lotWaferAttributesFlag,
    const CORBA::Boolean&    lotBackupInfoFlag
);

	
virtual CORBA::Long cassette_ListGetDR__170
(
    objCassette_ListGetDR_out__170&               strCassette_ListGetDR_out,
    const pptObjCommonIn&                         strObjCommonIn,
    const objCassette_ListGetDR_in__170&          strCassette_ListGetDR_in 
);
	
virtual CORBA::Long cassette_DBInfo_GetDR__170
(
    objCassette_DBInfo_GetDR_out__170&            strCassette_DBInfo_GetDR_out,
    const pptObjCommonIn&                         strObjCommonIn,
    const objCassette_DBInfo_GetDR_in__160&       strCassette_DBInfo_GetDR_in
);

virtual CORBA::Long cs_lot_ContaminationInfo_Set
(
    csObjLot_ContaminationInfo_Set_out &strLot_ContaminationInfo_Set_out, 
	const pptObjCommonIn &strObjCommonIn, 
	const csObjLot_ContaminationInfo_Set_in &strLot_ContaminationInfo_Set_in
);

virtual CORBA::Long cs_lot_ContaminationInfo_Get
(
    csObjLot_ContaminationInfo_Get_out   &strLot_ContaminationInfo_Get_out, 
    const pptObjCommonIn   &strObjCommonIn, 
    const csObjLot_ContaminationInfo_Get_in &strLot_ContaminationInfo_Get_in
);

virtual CORBA::Long cs_lot_udata_CopyToChild
(
    csObjLot_udata_CopyToChild_out &strLot_ContaminationInfo_Set_out,
    const pptObjCommonIn &strObjCommonIn,
    const csObjLot_udata_CopyToChild_in &strLot_udata_CopyToChild_in
);

virtual CORBA::Long cs_lot_ContaminationInfo_CheckForProcess
(
    csObjLot_ContaminationInfo_CheckForProcess_out &strLot_ContaminationInfo_Set_out, 
    const pptObjCommonIn &strObjCommonIn, 
    const csObjLot_ContaminationInfo_CheckForProcess_in &strLot_ContaminationInfo_CheckForProcess_in
);

virtual CORBA::Long cs_lot_ContaminationInfo_CheckForMove
(
    csObjLot_ContaminationInfo_CheckForMove_out &strLot_ContaminationInfo_Set_out, 
    const pptObjCommonIn &strObjCommonIn, 
    const csObjLot_ContaminationInfo_CheckForMove_in &strLot_ContaminationInfo_CheckForMove_in
);

virtual CORBA::Long cs_lot_ContaminationInfo_CheckForCarrierExchange
(
    csObjLot_ContaminationInfo_CheckForCarrierExchange_out &strLot_ContaminationInfo_CheckForCarrierExchange_out, 
    const pptObjCommonIn &strObjCommonIn, 
    const csObjLot_ContaminationInfo_CheckForCarrierExchange_in &strLot_ContaminationInfo_CheckForCarrierExchange_in
);

virtual CORBA::Long cs_carrier_UsageTypeChange
(
    csObjCarrier_UsageTypeChange_out&       strCarrier_UsageTypeChange_out,
    const pptObjCommonIn&                   strObjCommonIn,
    const csObjCarrier_UsageTypeChange_in&  strCarrier_UsageTypeChange_in );


virtual CORBA::Long cs_equipment_udata_GetDR
(
    csObjEquipment_udata_GetDR_out&        strEquipment_udata_GetDR_out,
    const pptObjCommonIn&                  strObjCommonIn,
    const csObjEquipment_udata_GetDR_in&   strCsObjEquipment_udata_GetDR_in
);

virtual CORBA::Long emptyCassette_CheckCategoryForOperation(
    objEmptyCassette_CheckCategoryForOperation_out& strEmptyCassette_CheckCategoryForOperation_out,
    const pptObjCommonIn&                   strObjCommonIn,
    const pptStartCassetteSequence&         strStartCassette );

virtual CORBA::Long cs_cassetteDelivery_SearchEmptyCassetteAssignPort(
        objCassetteDelivery_SearchEmptyCassetteAssignPort_out&  strCassetteDelivery_SearchEmptyCassetteAssignPort_out,
        const pptObjCommonIn&               strObjCommonIn,
        const objectIdentifier&             lotID,
        const pptPortIDSequence&            portIDSeq,
        const char*                         strReqUsageType,
        const pptFoundCassetteSequence&     emptyCassetteSeq,
        const objectIdentifierSequence&     omitCassetteSeq,
        const objectIdentifierSequence&     omitPortIDSeq );

virtual CORBA::Long whatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq(
    objWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out&  strWhatNextLotList_to_StartCassetteForDeliveryForInternalBufferReq_out,
    const pptObjCommonIn&                                                    strObjCommonIn,
    const objectIdentifier&                                                  equipmentID,
    const objEquipment_targetPort_Pickup_out_struct&                         strEquipment_targetPort_Pickup_out,
    const pptWhatNextLotListForInternalBufferInqResult&                      strWhatNextLotListForInternalBufferInqResult,
    const CORBA::Boolean&                                                    bEqpInternalBufferInfo,
    const pptEqpInternalBufferInfoSequence&                                  strEqpInternalBufferInfoSeq );

virtual CORBA::Long cassette_CheckConditionForSLMDestCassette(
    objCassette_CheckConditionForSLMDestCassette_out&       strCassette_CheckConditionForSLMDestCassette_out,
    const pptObjCommonIn&                                   strObjCommonIn,
    const objCassette_CheckConditionForSLMDestCassette_in&  strCassette_CheckConditionForSLMDestCassette_in);

virtual CORBA::Long lot_MergeWaferLot(
    objLot_MergeWaferLot_out& strLot_MergeWaferLot_out,
    const pptObjCommonIn& strObjCommonIn,
    const objectIdentifier& parentLotID,
    const objectIdentifier& childLotID);
//INN-R170002 Add End

//INN-R170001 Add Start
virtual CORBA::Long durable_currentState_Change(
    objDurable_currentState_Change_out&             strDurable_currentState_Change_out,
    const pptObjCommonIn&                           strObjCommonIn,
    const objDurable_currentState_Change_in&        strDurable_currentState_Change_in);

//INN-R170001 Add End

//INN-C170001 Add Start 
virtual CORBA::Long durable_FillInTxPDQ034DR (
    objDurable_FillInTxPDQ034DR_out&        strDurable_FillInTxPDQ034DR_out,
    const pptObjCommonIn&                   strObjCommonIn,
    const objDurable_FillInTxPDQ034DR_in&   strDurable_FillInTxPDQ034DR_in);
//INN-C170001 Add End

//INN-R170003 Add Start
virtual CORBA::Long cs_cassette_InspectionTime_Reset(
    csObjCassette_InspectionTime_Reset_out& strCassette_InspectionTime_Reset_out,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&                 cassetteID,
    const char*                             claimMemo);

virtual CORBA::Long cs_cassette_PMTime_Reset(
    csObjCassette_PMTime_Reset_out&         strCassette_PMTime_Reset_out,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&                 cassetteID,
    const char*                             claimMemo);

virtual CORBA::Long cs_reticle_WaferCount_Reset(
    csObjReticle_WaferCount_Reset_out&      strReticle_WaferCount_Reset_out,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&                 reticleID,
    const char*                             claimMemo);

virtual CORBA::Long cs_reticle_WaferCount_Increment(
	csObjReticle_WaferCount_Increment_out&      strReticle_WaferCount_Increment_out,
	const pptObjCommonIn&                       strObjCommonIn,
    csObjReticle_WaferCount_Increment_in&       strReticle_WaferCount_Increment_in);

virtual CORBA::Long cs_reticle_WaferCount_Decrement(
	csObjReticle_WaferCount_Decrement_out&      strReticle_WaferCount_Decrement_out,
	const pptObjCommonIn&                       strObjCommonIn,
	csObjReticle_WaferCount_Decrement_in&       strReticle_WaferCount_Decrement_in);

virtual CORBA::Long cs_reticle_UsedDuration_Reset(
    csObjReticle_UsedDuration_Reset_out&    strReticle_UsedDuration_Reset_out,
    const pptObjCommonIn&                   strObjCommonIn,
    const objectIdentifier&                 reticleID,
    const char*                             claimMemo);

virtual CORBA::Long reticle_detailInfo_GetDR__170(                                                                       
    objReticle_detailInfo_GetDR_out__170&       strReticle_detailInfo_GetDR_out,                                                //DSN000101569
    const pptObjCommonIn&                       strObjCommonIn,
    const objReticle_detailInfo_GetDR_in__160&  strReticle_detailInfo_GetDR_in );	

virtual CORBA::Long cs_reticlePod_Empty_Check(
	csObjReticlePod_Empty_Check_out&      strObjReticlePod_Empty_Check_out,
	const pptObjCommonIn&                       strObjCommonIn,
	csObjReticlePod_Empty_Check_in&      strObjReticlePod_Empty_Check_in);

virtual CORBA::Long cs_userData_GetByLotOperation(
	csObjUserData_GetByLotOperation_out& strUserData_GetByLotOperation_out,
	const pptObjCommonIn& strObjCommonIn,
	const csObjUserData_GetByLotOperation_in& strUserData_GetByLotOperation_in);

virtual CORBA::Long  cassette_multiLotType_Update(
    objCassette_multiLotType_Update_out&  strCassette_multiLotType_Update_out,
    const pptObjCommonIn& strObjCommonIn,
    const objectIdentifier& cassetteID);

virtual CORBA::Long reticle_ChangeTransportState(
    objReticle_ChangeTransportState_out&   strReticle_ChangeTransportState_out, 
    const pptObjCommonIn& strObjCommonIn,  
    const objectIdentifier& stockerID,  
    const objectIdentifier& equipmentID,  
    const pptXferReticleSequence& strXferReticle);

//INN-R170003 Add End

//INN-R170084 add start
virtual CORBA::Long cs_vendorLotReserve_AddDR
(
    csObjVendorLotReserve_AddDR_out&            strVendorLotReserve_AddDR_out,
    const pptObjCommonIn&                       strObjCommonIn,
    const objectIdentifier&                     bankID,
    const char *                                lotType,
    const char *                                subLotType,
    const char *                                sourceProduct,
    const char *                                partNo,
    const pptNewLotAttributes&                  strNewLotAttributes
);

virtual CORBA::Long cs_vendorLotReserve_DelDR
(
    csObjVendorLotReserve_DelDR_out&            strVendorLotReserve_DelDR_out,
    const pptObjCommonIn&                       strObjCommonIn,
    const objectIdentifier&                     cassetteID
);

virtual CORBA::Long cs_vendorLotReserve_SelDR
(
    csObjVendorLotReserve_SelDR_out&            strVendorLotReserve_SelDR_out,
    const pptObjCommonIn&                       strObjCommonIn,
    const objectIdentifier&                     cassetteID
);
//INN-R170084 add end

//INN-R170008 Add Start
virtual CORBA::Long cs_person_SkillList_AddDR(
                                csObjPerson_SkillList_AddDR_out&         strObjPerson_SkillList_AddDR_out,
                                const pptObjCommonIn&                    strObjCommonIn,
                                const csObjPerson_SkillList_AddDR_in&    strObjPerson_SkillList_AddDR_in );

virtual CORBA::Long cs_person_SkillList_DelDR(
                                csObjPerson_SkillList_DelDR_out&         strObjPerson_SkillList_DelDR_out,
                                const pptObjCommonIn&                    strObjCommonIn,
                                const csObjPerson_SkillList_DelDR_in&    strObjPerson_SkillList_DelDR_in );

virtual CORBA::Long cs_person_SkillList_GetDR(
                                csObjPerson_SkillList_GetDR_out&       strObjPerson_SkillList_GetDR_out,
                                const pptObjCommonIn&                  strObjCommonIn,
                                const csObjPerson_SkillList_GetDR_in&  strObjPerson_SkillList_GetDR_in );

virtual CORBA::Long cs_person_SkillList_SetDR(
                                csObjPerson_SkillList_SetDR_out&       strObjPerson_SkillList_SetDR_out,
                                const pptObjCommonIn&                  strObjCommonIn,
                                const csObjPerson_SkillList_SetDR_in&  strObjPerson_SkillList_SetDR_in );


virtual CORBA::Long cs_person_PrivilegeCheckForTACertify(
                                csObjPerson_PrivilegeCheckForTACertify_out&         strObjPerson_PrivilegeCheckForTACertify_out,
                                const pptObjCommonIn&                               strObjCommonIn,
                                const csObjPerson_PrivilegeCheckForTACertify_in&    strObjPerson_PrivilegeCheckForTACertify_in );
//INN-R170008 Add End

//INN-R170002 Add Start
virtual CORBA::Long lot_SplitWaferLot(
                            objLot_SplitWaferLot_out&           strLot_SplitWaferLot_out,
                            const pptObjCommonIn&               strObjCommonIn,
                            const objectIdentifier&             parentLotID,
                            const objectIdentifierSequence&     childWaferID);

virtual CORBA::Long waferSorter_CheckConditionForAction
(
    objWaferSorter_CheckConditionForAction_out&    strWaferSorter_CheckConditionForAction_out,
    const pptObjCommonIn&                          strObjCommonIn,
    const pptUser&                                 requestUserID,
    const objectIdentifier&                        equipmentID,
    const char *                                   actionCode,
    const pptWaferSorterSlotMapSequence&           strWaferSorterSlotMapSequence,
    const char *                                   portGroup,
    const char *                                   physicalRecipeID);
//INN-R170002 Add End
//INN-R170006 Add Start
virtual CORBA::Long cs_fixture_touchCount_Set(
    csObjFixture_touchCount_Set_out&            strFixture_touchCount_Set_out,
    const pptObjCommonIn&                       strObjCommonIn,
    const csObjFixture_touchCount_Set_in&       strFixture_touchCount_Set_in );
                                
virtual CORBA::Long fixture_FillInTxPDQ002DR(
    objFixture_FillInTxPDQ002DR_out&            strFixture_FillInTxPDQ002DR_out, 
    const pptObjCommonIn&                       strObjCommonIn, 
    const objectIdentifier&                     fixtureID);

virtual CORBA::Long process_waferChamberInformation_Set(
    objProcess_waferChamberInformation_Set_out& strProcess_waferChamberInformation_Set_out,
    const pptObjCommonIn&                       strObjCommonIn,
    const pptChamberProcessLotInfoSequence&     strChamberProcessLotInfos );

virtual CORBA::Long cs_fixture_touchCount_Get(
    csObjFixture_touchCount_Get_out&         strFixture_touchCount_Get_out,
    const pptObjCommonIn&                    strObjCommonIn,
    const csObjFixture_touchCount_Get_in&    strFixture_touchCount_Get_in );

virtual CORBA::Long controlJob_startReserveInformation_Get(
    objControlJob_startReserveInformation_Get_out& strControlJob_startReserveInformation_Get_out,
    const pptObjCommonIn& strObjCommonIn,
    const objectIdentifier& controlJobID);

virtual CORBA::Long cs_wafer_userDataInfo_GetDR (
    csObjWafer_userDataInfo_GetDR_out&         strWafer_userDataInfo_GetDR_out,
    const pptObjCommonIn&                      strObjCommonIn,
    const csObjWafer_userDataInfo_GetDR_in&    strWafer_userDataInfo_GetDR_in );

virtual CORBA::Long cs_durable_userDataInfo_GetDR (
    csObjDurable_userDataInfo_GetDR_out&         strDurable_userDataInfo_GetDR_out,
    const pptObjCommonIn&                        strObjCommonIn,
    const csObjDurable_userDataInfo_GetDR_in&    strDurable_userDataInfo_GetDR_in );

//INN-R170006 Add End

//INN-R170003 Add Start
virtual CORBA::Long bank_GetLotListByQueryDR(
                            objBank_GetLotListByQueryDR_out&    strBank_GetLotListByQueryDR_out, 
                            const pptObjCommonIn&               strObjCommonIn, 
                            const objectIdentifier&             bankID);
                                                                                
//INN-R170003 Add End

//INN-R170009 Add Start
virtual CORBA::Long cs_userData_GetByOperation(
    csObjUserData_GetByOperation_out&       strUserData_GetByOperation_out,
    const pptObjCommonIn&                   strObjCommonIn,
    const csObjUserData_GetByOperation_in&  strUserData_GetByOperation_in );

virtual CORBA::Long cs_APC_LithoAvailable_CheckCondition(
    csObjAPC_LithoAvailable_CheckCondition_out&       strAPC_LithoAvailable_CheckCondition_out,
    const pptObjCommonIn&                             strObjCommonIn,
    const csObjAPC_LithoAvailable_CheckCondition_in&  strAPC_LithoAvailable_CheckCondition_in );

virtual CORBA::Long cs_APC_LithoLotDataInfo_Get(
    csObjAPC_LithoLotDataInfo_Get_out&       strAPC_LithoLotDataInfo_Get_out,
    const pptObjCommonIn&                    strObjCommonIn,
    const csObjAPC_LithoLotDataInfo_Get_in&  strAPC_LithoLotDataInfo_Get_in );

virtual CORBA::Long cs_APC_LithoContextInfo_Get(
    csObjAPC_LithoContextInfo_Get_out&       strObjAPC_lithoContextInfo_Get_out,
    const pptObjCommonIn&                              strObjCommonIn,
    const csObjAPC_LithoContextInfo_Get_in&  strObjAPC_LithoContextInfo_Get_in);
    
virtual CORBA::Long cs_APCMgr_SendLithoUsedInfoReq(
    csObjAPCMgr_SendLithoUsedInfoReq_out&       strObjAPCMgr_SendLithoUsedInfoReq_out,
    const pptObjCommonIn&                              strObjCommonIn,
    const csObjAPCMgr_SendLithoUsedInfoReq_in&  strObjAPCMgr_SendLithoUsedInfoReq_in );
    
virtual CORBA::Long cs_APCMgr_SendLithoRecommendInfoInq(
    csObjAPCMgr_SendLithoRecommendInfoInq_out&       strObjAPCMgr_SendLithoRecommendInfoInq_out,
    const pptObjCommonIn&                              strObjCommonIn,
    const csObjAPCMgr_SendLithoRecommendInfoInq_in&  strObjAPCMgr_SendLithoRecommendInfoInq_in );
    
virtual CORBA::Long cs_APCMgr_SendLithoMetrologyInfoReq(
    csObjAPCMgr_SendLithoMetrologyInfoReq_out&       strObjAPCMgr_SendLithoMetrologyInfoReq_out,
    const pptObjCommonIn&                              strObjCommonIn,
    const csObjAPCMgr_SendLithoMetrologyInfoReq_in&  strObjAPCMgr_SendLithoMetrologyInfoReq_in );
//INN-R170009 Add End

//INN-R170014 Add Start
virtual CORBA::Long cs_controlJob_BatchSize_Check
(
    csObjControlJob_BatchSize_Check_out&  strCJBatchSizeCheckOut,
	const pptObjCommonIn&                   strObjCommonIn,
    const csObjControlJob_BatchSize_Check_in&      strCJBatchSizeCheckIn
);
//INN-R170014 Add End

//INN-R170003 Add Start
virtual CORBA::Long bank_lotPreparation_Check
(
    objBank_lotPreparation_Check_out& strBank_lotPreparation_Check_out,
    const pptObjCommonIn& strObjCommonIn,
    const objectIdentifier& bankID,
    const char* lotType,
    const char* subLotType,
    const pptNewLotAttributes& strNewLotAttributes
);
virtual CORBA::Long FPC_CheckConditionForUpdate__140
(
        objFPC_CheckConditionForUpdate_out__140& strFPC_CheckConditionForUpdate_out, 
        const pptObjCommonIn&                 strObjCommonIn,
        const objectIdentifier&               lotFamilyID,
        const char *                          actionType,
        const objectIdentifier&               mainPDID,
        const char *                          mainOpeNo,
        const objectIdentifier&               orgMainPDID,
        const char *                          orgOpeNo,
        const objectIdentifier&               subMainPDID,
        const char *                          subOpeNo 
);
//INN-R170003 Add End

//INN-R170003(New Transfer State PI/PO) Add Start  
//Total 18 functions:
// -- 11 functions implement in related 11 cpp files
virtual CORBA::Long cassette_CheckConditionForOperation(
                            objCassette_CheckConditionForOperation_out& strCassette_CheckConditionForOperation_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& equipmentID,
                            const char * portGroupID,
                            const pptStartCassetteSequence& strStartCassette,
                            const char * operation );
                            
virtual CORBA::Long cassette_CheckConditionForOperationForInternalBuffer(
        objCassette_CheckConditionForOperationForInternalBuffer_out&    strCassette_CheckConditionForOperationForInternalBuffer_out,
        const pptObjCommonIn&                                           strObjCommonIn,
        const objectIdentifier&                                         equipmentID,
        const pptStartCassetteSequence&                                 strStartCassette,
        const char*                                                     operation );

virtual CORBA::Long cassette_CheckConditionForUnloading(
                            objCassette_CheckConditionForUnloading_out& strCassette_CheckConditionForUnloading_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& cassetteID);
                            
virtual CORBA::Long cassette_destinationInfo_Get(
                            objCassette_destinationInfo_Get_out& strCassette_destinationInfo_Get_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& cassetteID,
                            const objectIdentifier& lotID);  
                            
virtual CORBA::Long cassette_transferState_Change(
                            objCassette_transferState_Change_out& strCassette_transferState_Change_out,
                            const  pptObjCommonIn& strObjCommonIn,
                            const  objectIdentifier& stockerID,
                            const  objectIdentifier& equipmentID,
                            const  objectIdentifier& cassetteID,
                            const  pptXferCassette& strXferCassette,
                            const  char*            transferStatusChangeTimeStamp);

virtual CORBA::Long equipment_stockerOrder_GetByLotStatus(
                            objEquipment_stockerOrder_GetByLotStatus_out& strEquipment_stockerOrder_GetByLotStatus_out,
                            const pptObjCommonIn&         strObjCommonIn,
                            const pptLotLocationInfo&     cassetteLocationInfo,
                            const pptLotStatusInfo&       strLotStatusInfo,
                            const pptWhereNextEqpStatusSequence& strEqpStatusSeq);
                            
virtual CORBA::Long lot_equipmentOrder_GetByLotStatus(
                            objLot_equipmentOrder_GetByLotStatus_out& strLot_equipmentOrder_GetByLotStatus_out,
                            const pptObjCommonIn&     strObjCommonIn,
                            const pptLotLocationInfo& cassetteLocationInfo,
                            const pptLotStatusInfo&   lotStatus); 
                            
virtual CORBA::Long lot_STBCancel_Check(
    objLot_STBCancel_Check_out&         strLot_STBCancel_Check_out,
    const pptObjCommonIn&               strObjCommonIn,
    const objLot_STBCancel_Check_in&    strLot_STBCancel_Check_in);
    
virtual CORBA::Long whatNextLotList_to_StartCassetteForDeliveryReq(
    objWhatNextLotList_to_StartCassetteForDeliveryReq_out&  strWhatNextLotList_to_StartCassetteForDeliveryReq_out,
    const pptObjCommonIn&                                   strObjCommonIn,
    const objectIdentifier&                                 equipmentID,
    const pptPortGroupSequence&                             strPortGroup,
    const pptWhatNextLotListInqResult&                      strWhatNextLotListInqResult );
    
virtual CORBA::Long whatNextLotList_to_StartCassetteForSLMDeliveryReq(
    objWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out&  strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_out,
    const pptObjCommonIn&                                      strObjCommonIn,
    objWhatNextLotList_to_StartCassetteForSLMDeliveryReq_in&   strWhatNextLotList_to_StartCassetteForSLMDeliveryReq_in );

virtual CORBA::Long whatNextLotList_to_StartCassetteForTakeOutInDeliveryReq(
    objWhatNextLotList_to_StartCassetteForTakeOutInDeliveryReq_out& strWhatNextLotList_to_StartCassetteForTakeOutInDeliveryReq_out,
    const pptObjCommonIn& strObjCommonIn,
    const objWhatNextLotList_to_StartCassetteForTakeOutInDeliveryReq_in& strWhatNextLotList_to_StartCassetteForTakeOutInDeliveryReq_in );

// -- 6 functions implement in related 6 dr files (included by 3 sqx files)
virtual CORBA::Long cassette_FillInTxPDQ007DR(
    objCassette_FillInTxPDQ007DR_out&  strCassette_FillInTxPDQ007DR_out,
    const pptObjCommonIn&              strObjCommonIn,
    const char *                       cassetteCategory,
    CORBA::Boolean                     emptyFlag,
    const objectIdentifier&            stockerID,
    const objectIdentifier&            cassetteID,
    const char *                       cassetteStatus,   
    CORBA::Long                        maxRetrieveCount); 

virtual CORBA::Long cassette_FillInTxPDQ008DR(
    objCassette_FillInTxPDQ008DR_out&  strCassette_FillInTxPDQ008DR_out, 
    const pptObjCommonIn&              strObjCommonIn, 
    const objectIdentifier&            cassetteID);
    
virtual CORBA::Long cassette_LocationInfo_GetDR(
                            objCassette_LocationInfo_GetDR_out& strCassette_LocationInfo_GetDR_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& cassetteID );

virtual CORBA::Long equipments_productLotList_GetDR(
    objEquipments_productLotList_GetDR_out&          strEquipments_productLotList_GetDR_out,
    const pptObjCommonIn&                            strObjCommonIn,
    const objEquipments_productLotList_GetDR_in&     strEquipments_productLotList_GetDR_in );                            

virtual CORBA::Long lot_list_GetDR__160(
    objLot_list_GetDR_out__160&       strLot_list_GetDR_out,
    const pptObjCommonIn&             strObjCommonIn,
    const objLot_list_GetDR_in__160&  strLot_list_GetDR_in ); 
    
//virtual CORBA::Long cassette_ListGetDR__170(                                                                              //DSN000101569
//    objCassette_ListGetDR_out__170&       strCassette_ListGetDR_out,                                                            //DSN000101569
//    const pptObjCommonIn&                 strObjCommonIn,
//    const objCassette_ListGetDR_in__170&  strCassette_ListGetDR_in );
                                                                                                                                                                                                                              
//INN-R170003(New Transfer State PI/PO) Add End 

//INN-R170001 Add start
virtual CORBA::Long lot_waferID_Generate
(
    objLot_waferID_Generate_out&        strLot_waferID_Generate_out,
    const pptObjCommonIn&               strObjCommonIn,
    const pptNewLotAttributes&          strNewLotAttributes
);

virtual CORBA::Long lotType_lotID_Assign
(
    objLotType_lotID_Assign_out& strLotType_lotID_Assign_out,
    const pptObjCommonIn&       strObjCommonIn,
    const char *                lotType,
    const objectIdentifier&     productID,
    const char *                subLotType
);
virtual CORBA::Long cs_lotID_ControlInfo_GetDR
(
    csObjLotID_ControlInfo_GetDR_out&               strObjLotID_ControlInfo_GetDR_out,
    const pptObjCommonIn&                           strObjCommonIn,
    const csObjLotID_ControlInfo_GetDR_in&          strObjLotID_ControlInfo_GetDR_in 
);
virtual CORBA::Long cs_lotID_ControlInfo_SetDR
(
    csObjLotID_ControlInfo_SetDR_out&               strObjLotID_ControlInfo_SetDR_out,
    const pptObjCommonIn&                           strObjCommonIn,
    const csObjLotID_ControlInfo_SetDR_in&          strObjLotID_ControlInfo_SetDR_in 
);
virtual CORBA::Long cs_lotID_ControlInfo_AddDR
(
    csObjLotID_ControlInfo_AddDR_out&               strObjLotID_ControlInfo_AddDR_out,
    const pptObjCommonIn&                           strObjCommonIn,
    const csObjLotID_ControlInfo_AddDR_in&          strObjLotID_ControlInfo_AddDR_in 
);
virtual CORBA::Long lotFamily_splitNo_Create 
(
    objLotFamily_splitNo_Create_out&                strLotFamily_splitNo_Create_out,
    const pptObjCommonIn&                           strObjCommonIn,
    const objectIdentifier&                         lotID 
);

//INN-R170001 Add end
//INN-R170012 Add start
virtual CORBA::Long equipment_portOperationMode_Change
(
    objEquipment_portOperationMode_Change_out&      strEquipment_portOperationMode_Change_out,
    const pptObjCommonIn&                           strObjCommonIn,
    const objectIdentifier&                         equipmentID,
    const pptPortOperationModeSequence&             strPortOperationMode
);
//INN-R170012 Add end
//INN-A170007 add start
virtual CORBA::Long lot_CheckConditionForLoading(
    objLot_CheckConditionForLoading_out& strLot_CheckConditionForLoading_out,
    const pptObjCommonIn& strObjCommonIn,
    const objectIdentifier& equipmentID,
    const objectIdentifier& lotID);
//INN-A170007 add end

//INN-A170003 add start yangxigang
virtual CORBA::Long multiCarrierXferFillInTXLGC012InParm(
    objMultiCarrierXferFillInTXLGC012InParm_out& strMultiCarrierXferFillInTXLGC012InParm_out,
    const pptObjCommonIn& strObjCommonIn,
    const objectIdentifier& equipmentID,
    const pptStartCassetteSequence& strStartCassette
);
virtual CORBA::Long equipment_lots_WhatNextDR__140(
    objEquipment_lots_WhatNextDR_out__140&      strEquipment_lots_WhatNextDR_out,
    const pptObjCommonIn&                       strObjCommonIn,
    const objEquipment_lots_WhatNextDR_in__140& strEquipment_lots_WhatNextDR_in
);
virtual CORBA::Long durable_CheckConditionForOperation(
    objDurable_CheckConditionForOperation_out&        strDurable_CheckConditionForOperation_out,
    const pptObjCommonIn&                             strObjCommonIn,
    const objDurable_CheckConditionForOperation_in&   strDurable_CheckConditionForOperation_in
);
virtual CORBA::Long cassette_CheckConditionForLoading(
    objCassette_CheckConditionForLoading_out& strCassette_CheckConditionForLoading_out,
    const pptObjCommonIn& strObjCommonIn,
    const objectIdentifier& equipmentID,
    const objectIdentifier& portID,
    const objectIdentifier& cassetteID
);
//INN-A170003 add end
//INN-R170012 Add start
virtual CORBA::Long equipment_operationModeCombination_Check
(
    objEquipment_operationModeCombination_Check_out& strEquipment_operationModeCombination_Check_out,
    const pptObjCommonIn& strObjCommonIn,
    const objectIdentifier& equipmentID,
    const pptPortOperationModeSequence& strPortOperationModeSeq
);
//INN-R170012 Add end
//INN-R170023 add start
virtual CORBA::Long process_startReserveInformation_Get(
    objProcess_startReserveInformation_Get_out& strProcess_startReserveInformation_Get_out,
    const pptObjCommonIn& strObjCommonIn,
    const objectIdentifier& equipmentID);
//INN-R170023 add end


//INN_R170084 add start
virtual CORBA::Long cs_APC_EventQueue_AddDR
(
    csObjAPC_EventQueue_AddDR_out&              strObjAPC_EventQueue_AddDR_out,
    const pptObjCommonIn&                       strObjCommonIn,
    const csObjAPC_EventQueue_AddDR_in&         csObjAPC_EventQueue_AddDR_in
);

virtual CORBA::Long cs_APC_EventQueue_DelDR
(
    csObjAPC_EventQueue_DelDR_out&            strObjAPC_EventQueue_DelDR_out,
    const pptObjCommonIn&                     strObjCommonIn,
    const csObjAPC_EventQueue_DelDR_in&       strObjAPC_EventQueue_DelDR_in
);

virtual CORBA::Long cs_APC_LotEventQueue_Make
(
    csObjAPC_LotEventQueue_Make_out&        strObjAPC_LotEventQueue_Make_out,
    const pptObjCommonIn&                   strObjCommonIn,
    const csObjAPC_LotEventQueue_Make_in&   strObjAPC_LotEventQueue_Make_in
);
//INN_R170084 add end

//INN-R170016 Add Start
virtual CORBA::Long cs_eqpMonitorInventory_list_GetDR
(
    csObjEqpMonitorInventory_ListGetDR_out&         strEqpMonitorInventory_ListGetDR_out,
    const pptObjCommonIn&                           strObjCommonIn,
    const csObjEqpMonitorInventory_ListGetDR_in&    strEqpMonitorInventory_ListGetDR_in 
);
//INN-R170016 Add End

//INN-R170017 Add Start
virtual CORBA::Long cs_BWS_WaferList_GetDR
(
    csObjBWS_WaferList_GetDR_out&          strBWS_WaferList_GetDR_out,
    const pptObjCommonIn&                  strObjCommonIn,
    const csObjBWS_WaferList_GetDR_in&     strBWS_WaferList_GetDR_in
);

virtual CORBA::Long cs_BWS_WaferList_AddDR
(
    csObjBWS_WaferList_AddDR_out&          strBWS_WaferList_AddDR_out,
    const pptObjCommonIn&                  strObjCommonIn,
    const csObjBWS_WaferList_AddDR_in&     strBWS_WaferList_AddDR_in,
    const char*                            claimMemo
);
//INN-R170017 Add End
//INN-R170027 Add start
virtual CORBA::Long productSpecification_FillInTxPCQ015DR__160
(
    objProductSpecification_FillInTxPCQ015DR_out&               strProductSpecification_FillInTxPCQ015DR_out,
    const pptObjCommonIn&                                       strObjCommonIn,
    const objProductSpecification_FillInTxPCQ015DR_in__160&     strProductSpecification_FillInTxPCQ015DR_in
);
//INN-R170027 Add end

#endif
