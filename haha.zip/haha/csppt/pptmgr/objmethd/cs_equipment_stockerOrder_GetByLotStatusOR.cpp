#ifndef lint
static char *sccsid =  "@(#) 1.7 superpos/src/spppt/source/posppt/pptmgr/objmethd/equipment_stockerOrder_GetByLotStatus.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 10/25/07 14:00:03 [ 10/25/07 14:00:04 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cs_equipment_stockerOrder_GetByLotStatusOR.cpp
//

#include "cs_pptmgr.hpp"
#include "plot.hh"
#include "pbank.hh"
#include "pstmc.hh"

//
//[Object Function Name]: long   equipment_stockerOrder_GetByLotStatus
//
// Date        Level    Author         Note
// ----------  -------- -------------  -------------------------------------------------
// 2006-09-21  D8000028 K.Kido         Initial Release(R80) for where next improvement
// 2007-09-20  D9000084 K.Kido         stocker_FillInTxLGQ004DR ==> stocker_baseInfo_Get__090
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/07 DSIV00000099 M.Ogawa        stocker_baseInfo_Get__090 ==> stocker_baseInfo_Get__100
//
// Innotron Modification history:
// Date       DCR/PCR No   Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/15 INN-R170003  Jun Zhang      New Transfer State PI/PO.
//
//[Function Description]
// This objmethod returns stocker priority order of equipment by Lot status.
// If input parameter "strLotStatusInfo" exists,
// then search and sort the equipment's stockers by following methods.
//   "equipment_allStocker_GetByUTSPriorityDR"    ==> Get all equipment stocker.
//                                                    If the equipment UTS available, then UTS list is also returned.
//   "stocker_priorityOrder_GetByLotAvailability" ==> Sort stockers by Lot availability.
//   "stockerUTS_priorityOrder_Get"               ==> Sort UTS by Lot availability.
//
// And Lot cassette is checked following items for UTS availability.
//  1. scrap wafer should not exist.
//  2. carrier status should be available.
//  3. representative lot should be waiting.(Not hold/completed)
//  4. representative lot should not be inhibited on equipment.
//
// If input parameter "strLotStatusInfo" does NOT exists,
// then stocker information is decided by following rules.
//  1. If Lot is on Floor, set cassette current stocker.
//  2. If Lot is in bank, and the bank has some stocker, then the stocker is specified.
//  3. If Lot is in bank, but the bank does NOT have stocker, then set cassette current stocker.
//
//
//[Input Parameters]:
//  in  pptObjCommonIn    strObjCommonIn;
//  in  pptLotLocationInfo cassetteLocationInfo;
//  in  pptLotStatusInfo strLotStatusInfo;
//  in  pptWhereNextEqpStatusSequence strEqpStatusSeq;
//
//[Output Parameters]:
//
//  out objEquipment_stockerOrder_GetByLotStatus_out  strEquipment_stockerOrder_GetByLotStatus_out;
//
//  typedef struct objEquipment_stockerOrder_GetByLotStatus_out_struct {
//     pptRetCode                     strResult;
//     pptWhereNextEqpStatusSequence  strWhereNextEqpStatusSeq;
//  } objEquipment_stockerOrder_GetByLotStatus_out;
//
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//
//
CORBA::Long CS_PPTManager_i::equipment_stockerOrder_GetByLotStatus(
                            objEquipment_stockerOrder_GetByLotStatus_out& strEquipment_stockerOrder_GetByLotStatus_out,
                            const pptObjCommonIn&         strObjCommonIn,
                            const pptLotLocationInfo&     cassetteLocationInfo,
                            const pptLotStatusInfo&       strLotStatusInfo,
                            const pptWhereNextEqpStatusSequence& strEqpStatusSeq)
{
    char * methodName = NULL;
    CORBA::Long rc = RC_OK;
    try
    {
        CORBA::ULong eqpLen = 0;
        eqpLen = strEqpStatusSeq.length();
        /*****************************************/
        /*  Check cassette availability for UTS  */
        /*****************************************/
        CORBA::Boolean notCandidateForUTSFlag = FALSE;
        if( 0 != eqpLen )
        {
            /*******************************/
            /* Check the carrier status    */
            /*******************************/
            objCassette_getStatusDR_out strCassette_getStatusDR_out;
            rc = cassette_getStatusDR( strCassette_getStatusDR_out, strObjCommonIn,
                                       cassetteLocationInfo.cassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "","cassette_getStatusDR() != RC_OK", rc);
                strEquipment_stockerOrder_GetByLotStatus_out.strResult = strCassette_getStatusDR_out.strResult;
                return rc;
            }

            if( 0 != CIMFWStrCmp(strCassette_getStatusDR_out.drbl_state, SP_DRBL_STATE_AVAILABLE) )
            {
                PPT_METHODTRACE_V1("", " Cassette durable state is not available. This cassette shuld not be candidate of UTS." );
                notCandidateForUTSFlag = TRUE;
            }

            /************************************************************/
            /* Check whether the carrier contains scrap wafer or not    */
            /************************************************************/
            objectIdentifierSequence cassetteIDSeq;
            cassetteIDSeq.length(1);
            cassetteIDSeq[0] = cassetteLocationInfo.cassetteID;
            objCassette_scrapWafer_SelectDR_out  strCassette_scrapWafer_SelectDR_out;
            rc = cassette_scrapWafer_SelectDR( strCassette_scrapWafer_SelectDR_out, strObjCommonIn,
                                               cassetteIDSeq );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "cassette_scrapWafer_SelectDR() != RC_OK");
                strEquipment_stockerOrder_GetByLotStatus_out.strResult = strCassette_scrapWafer_SelectDR_out.strResult;
                return (rc);
            }

            CORBA::Long scrapCount = strCassette_scrapWafer_SelectDR_out.strLotWaferMap.length();
            if( scrapCount > 0 )
            {
                PPT_METHODTRACE_V1("", " ScrapWafer Found. This cassette shuld not be candidate of UTS." );
                notCandidateForUTSFlag = TRUE;
            }

            /***************************/
            /* Check the Lot status    */
            /***************************/
            if( FALSE == strLotStatusInfo.onFloorFlag ||
                TRUE == strLotStatusInfo.onHoldFlag )
            {
                PPT_METHODTRACE_V1("", "Hold or completed Lot is representative Lot. This cassette shuld not be candidate of UTS." );
                notCandidateForUTSFlag = TRUE;
            }
        }

        CORBA::ULong stkLen = 0 ;
        CORBA::Boolean setCurrentStockerFlag = FALSE;
        pptEqpStockerStatusSequence stockerSeq;
        pptEqpStockerStatusSequence UTSstockerSeq;

        strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq.length(eqpLen);
        for( CORBA::ULong eqpCnt = 0 ; eqpCnt < eqpLen ; eqpCnt++ )
        {
            stockerSeq.length(0);
            UTSstockerSeq.length(0);
            /***************************/
            /* Check inhibit status    */
            /***************************/
            CORBA::Boolean notCandidateForUTSByInhibitFlag = FALSE ;
            if( 0 < strEqpStatusSeq[eqpCnt].entityInhibitions.length() ||
                FALSE == strEqpStatusSeq[eqpCnt].equipmentAvailableFlag )
            {
                PPT_METHODTRACE_V1("", "### Representative Lot is inhibited on equipment. Not candidate for UTS." );
                notCandidateForUTSByInhibitFlag = TRUE;
            }

            /***********************************/
            /* Get all stocker of equipment    */
            /***********************************/
            objEquipment_allStocker_GetByUTSPriorityDR_out strEquipment_allStocker_GetByUTSPriorityDR_out;
            rc = equipment_allStocker_GetByUTSPriorityDR( strEquipment_allStocker_GetByUTSPriorityDR_out, strObjCommonIn,
                                                          strEqpStatusSeq[eqpCnt].equipmentID );

            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "equipment_allStocker_GetByUTSPriority() rc != RC_OK" );
                strEquipment_stockerOrder_GetByLotStatus_out.strResult = strEquipment_allStocker_GetByUTSPriorityDR_out.strResult;
                return rc;
            }

            /**************************************************************/
            /*  Keep UTS and stocker list for force destination decision  */
            /**************************************************************/
            if( 0 < strEquipment_allStocker_GetByUTSPriorityDR_out.UTSstockers.length() &&
                FALSE == notCandidateForUTSFlag &&
                FALSE == notCandidateForUTSByInhibitFlag )
            {
                PPT_METHODTRACE_V1("", "### The equipment has some UTS. And specified cassette is available for the equipment." );
                /***************************************/
                /*  Sort UTS sequence by Lot status    */
                /***************************************/
                objStockerUTS_priorityOrder_GetByLotAvailability_out strStockerUTS_priorityOrder_GetByLotAvailability_out;
                rc = stockerUTS_priorityOrder_GetByLotAvailability( strStockerUTS_priorityOrder_GetByLotAvailability_out, strObjCommonIn,
                                                                    strEquipment_allStocker_GetByUTSPriorityDR_out.UTSstockers,
                                                                    strLotStatusInfo.lotID );

                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "stockerUTS_priorityOrder_Get() rc != RC_OK" );
                    strEquipment_stockerOrder_GetByLotStatus_out.strResult = strStockerUTS_priorityOrder_GetByLotAvailability_out.strResult;
                    return rc;
                }

                UTSstockerSeq = strStockerUTS_priorityOrder_GetByLotAvailability_out.strEqpStockerStatus;
            }

            if( 0 < strEquipment_allStocker_GetByUTSPriorityDR_out.stockers.length() )
            {
                PPT_METHODTRACE_V1("", "### The equipment has some stocker. " );
                /*******************************************/
                /*  Sort stocker sequence by Lot status    */
                /*******************************************/
                objStocker_priorityOrder_GetByLotAvailability_out strStocker_priorityOrder_GetByLotAvailability_out;
                rc = stocker_priorityOrder_GetByLotAvailability ( strStocker_priorityOrder_GetByLotAvailability_out, strObjCommonIn,
                                                                  strEquipment_allStocker_GetByUTSPriorityDR_out.stockers,
                                                                  strLotStatusInfo.lotID );

                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "stocker_priorityOrder_GetByLotAvailability() rc != RC_OK" );
                    strEquipment_stockerOrder_GetByLotStatus_out.strResult = strStocker_priorityOrder_GetByLotAvailability_out.strResult;
                    return rc;
                }

                stockerSeq = strStocker_priorityOrder_GetByLotAvailability_out.strEqpStockerStatus;
            }

            /*************************/
            /* Set return structure  */
            /*************************/
            CORBA::ULong utsLen = UTSstockerSeq.length();
            CORBA::ULong stkLen = stockerSeq.length();

            if( 0 == utsLen + stkLen )
            {
                PPT_METHODTRACE_V1("", " ##### 0 == utsLen + stkLen " );
                /****************************************************************************************/
                /*  Even if NextUTS is full or not available, set it by force when the cassette is EI   */
                /****************************************************************************************/
                strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[eqpCnt] = strEqpStatusSeq[eqpCnt];
//INN-R170003   if ( 0 == CIMFWStrCmp( cassetteLocationInfo.transferStatus, SP_TransState_EquipmentIn ) )
                if ( 0 == CIMFWStrCmp( cassetteLocationInfo.transferStatus, SP_TransState_EquipmentOut ) )  //INN-R170003
                {
                    if( 0 < strEquipment_allStocker_GetByUTSPriorityDR_out.UTSstockers.length() &&
                        FALSE == notCandidateForUTSFlag &&
                        FALSE == notCandidateForUTSByInhibitFlag )
                    {
                        PPT_METHODTRACE_V1("", " ##### Set UTSs by force." );
                        strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[eqpCnt].strEqpStockerStatus = strEquipment_allStocker_GetByUTSPriorityDR_out.UTSstockers ;
                    }
                    /*****************************************************************************/
                    /*  If cassette is EI, then try to get Stocker from cassette location info   */
                    /*****************************************************************************/
                    else 
                    {
                        PPT_METHODTRACE_V1("", " ##### Set Stocker from Cassette related Equipment." );
                        objEquipment_stockerInfo_GetDR_out strEquipment_stockerInfo_GetDR_out;
                        rc = equipment_stockerInfo_GetDR( strEquipment_stockerInfo_GetDR_out,
                                                          strObjCommonIn,
                                                          cassetteLocationInfo.equipmentID );

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "equipment_stockerInfo_GetDR() rc != RC_OK",rc);
                            strEquipment_stockerOrder_GetByLotStatus_out.strResult = strEquipment_stockerInfo_GetDR_out.strResult;
                            return( rc );
                        }

                        if( 0 < strEquipment_stockerInfo_GetDR_out.equipmentStockerInfo.strEqpStockerStatus.length() )
                        {
                            strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[eqpCnt].strEqpStockerStatus = strEquipment_stockerInfo_GetDR_out.equipmentStockerInfo.strEqpStockerStatus ;
                        }
                    }
                }
                /******************************************/
                /*  Equipment does not have any stocker.  */
                /******************************************/
                else
                {
                    PPT_METHODTRACE_V1("", "### Equipment does not have any available stocker. Set current stocker for cassette." );
                    strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[eqpCnt].strEqpStockerStatus.length(0);
                    setCurrentStockerFlag = TRUE;
                }
            }
            else
            {
                /*********************************/
                /*  Equipment has some stocker.  */
                /*********************************/
                PPT_METHODTRACE_V1("", "### Equipment has some available stocker. " );
                strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[eqpCnt] = strEqpStatusSeq[eqpCnt];
                strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[eqpCnt].strEqpStockerStatus.length( utsLen + stkLen );
                CORBA::ULong totalCount = 0;

                for( CORBA::ULong utsCnt = 0 ; utsCnt < utsLen ; utsCnt++ )
                {
                    strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[eqpCnt].strEqpStockerStatus[totalCount++] = UTSstockerSeq[utsCnt];
                }

                char stockerPriority[32];
                for( CORBA::ULong stkCnt = 0 ; stkCnt < stkLen ; stkCnt++ )
                {
                    strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[eqpCnt].strEqpStockerStatus[totalCount] = stockerSeq[stkCnt];

                    /********************************/
                    /*  Reassign stocker priority   */
                    /********************************/
                    if( 0 != utsLen )
                    {
                        memset(stockerPriority, '\0', sizeof(stockerPriority));
                        snprintf(stockerPriority, sizeof(stockerPriority), "%d", stkCnt);
                        strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[eqpCnt].strEqpStockerStatus[totalCount].stockerPriority = CIMFWStrDup(stockerPriority);
                    }
                    totalCount++;
                }
            }
        }

        if( 0 == eqpLen )
        {
            PPT_METHODTRACE_V1("", "### Equipment is not found." );
            /*****************************/
            /* When Lot is on Floor.     */
            /*****************************/
            if( strLotStatusInfo.onFloorFlag )
            {
                if( 0 != CIMFWStrLen(cassetteLocationInfo.stockerID.identifier) )
                {
                    PPT_METHODTRACE_V1("", "### The cassette is not in Equipment. Set current stocker for cassette." );
                    strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq.length(1);
                    strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[0].strEqpStockerStatus.length(0);
                    setCurrentStockerFlag = TRUE;
                }
                else
                {
                    PPT_METHODTRACE_V1("", "### The cassette is not in Equipment, and cannot find any stockers." );
                    //Already set stockers of equipment if the Lot is on Equipment.
                }
            }
            /**********************************/
            /* When Lot is in Bank.           */
            /*   => Stay in the current Bank. */
            /**********************************/
            else /* If InventoryState is either InBank or NonProBank */
            {
                PPT_METHODTRACE_V1("", "isOnFloorFlag is TRUE" );

                PosLot_var aLot;
                PPT_CONVERT_LOTID_TO_LOT_OR(aLot,
                                            strLotStatusInfo.lotID,
                                            strEquipment_stockerOrder_GetByLotStatus_out,
                                            equipment_stockerOrder_GetByLotStatus);

                PosBank_var aBank;
                try
                {
                    aBank = aLot->getBank();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getBank)

                if(CORBA::is_nil(aBank))
                {
                    PPT_SET_MSG_RC_KEY( strEquipment_stockerOrder_GetByLotStatus_out,
                                        MSG_NOT_FOUND_BANK,
                                        RC_NOT_FOUND_BANK, "" );
                    return RC_NOT_FOUND_BANK ;
                }

                PosStorageMachine_var aStocker;
                try
                {
                    aStocker = aBank->getStorageMachine();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosBank::getStorageMachine) ;

                strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq.length(1);

                if (!CORBA::is_nil(aStocker))
                {
                    PPT_METHODTRACE_V1("", "##### Set Bank Stocker");
                    strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[0].strEqpStockerStatus.length(1);

                    PPT_SET_OBJECT_IDENTIFIER(strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[0].strEqpStockerStatus[0].stockerID,
                                              aStocker ,
                                              strLot_GetNextStockerDR_out ,
                                              equipment_stockerOrder_GetByLotStatus,
                                              PosStorageMachine )

//D9000084          objStocker_FillInTxLGQ004DR_out strStocker_FillInTxLGQ004DR_out;
//D9000084          rc = stocker_FillInTxLGQ004DR( strStocker_FillInTxLGQ004DR_out, strObjCommonIn,
//D9000084                                         strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[0].strEqpStockerStatus[0].stockerID );
//D9000084
//D9000084          if( rc != RC_OK )
//D9000084          {
//D9000084              PPT_METHODTRACE_V2(""," #### stocker_FillInTxLGQ004DR != RC_OK : rc = ", rc );
//D9000084              strEquipment_stockerOrder_GetByLotStatus_out.strResult = strStocker_FillInTxLGQ004DR_out.strResult ;
//D9000084              return rc;
//D9000084          }
//DSIV00000099//D9000084 add start
//DSIV00000099                    objStocker_baseInfo_Get_out__090 strStocker_FillInTxLGQ004DR_out;
//DSIV00000099                    objStocker_baseInfo_Get_in__090  strStocker_baseInfo_Get_in;
//DSIV00000099                    strStocker_baseInfo_Get_in.stockerID = strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[0].strEqpStockerStatus[0].stockerID;
//DSIV00000099                    rc = stocker_baseInfo_Get__090( strStocker_FillInTxLGQ004DR_out, strObjCommonIn,
//DSIV00000099                                                    strStocker_baseInfo_Get_in );
//DSIV00000099
//DSIV00000099                    if( rc != RC_OK )
//DSIV00000099                    {
//DSIV00000099                        PPT_METHODTRACE_V2(""," #### stocker_baseInfo_Get__090() != RC_OK : rc = ", rc );
//DSIV00000099                        strEquipment_stockerOrder_GetByLotStatus_out.strResult = strStocker_FillInTxLGQ004DR_out.strResult ;
//DSIV00000099                        return rc;
//DSIV00000099                    }
//DSIV00000099//D9000084 add end
//DSIV00000099 add start
                    objStocker_baseInfo_Get_out__100 strStocker_baseInfo_Get_out;
                    objStocker_baseInfo_Get_in__090  strStocker_baseInfo_Get_in;
                    strStocker_baseInfo_Get_in.stockerID = strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[0].strEqpStockerStatus[0].stockerID;
                    rc = stocker_baseInfo_Get__100( strStocker_baseInfo_Get_out, strObjCommonIn,
                                                    strStocker_baseInfo_Get_in );

                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2(""," #### stocker_baseInfo_Get__100() != RC_OK : rc = ", rc );
                        strEquipment_stockerOrder_GetByLotStatus_out.strResult = strStocker_baseInfo_Get_out.strResult ;
                        return rc;
                    }
//DSIV00000099 add end

//DSIV00000099                    strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[0].strEqpStockerStatus[0].stockerType     = strStocker_FillInTxLGQ004DR_out.strStockerInfoInqResult.stockerType ;
//DSIV00000099                    strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[0].strEqpStockerStatus[0].stockerStatus   = strStocker_FillInTxLGQ004DR_out.strStockerInfoInqResult.actualStatusCode ;
//DSIV00000099                    strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[0].strEqpStockerStatus[0].UTSFlag         = strStocker_FillInTxLGQ004DR_out.strStockerInfoInqResult.UTSFlag ;
//DSIV00000099                    strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[0].strEqpStockerStatus[0].maxUTSCapacity  = strStocker_FillInTxLGQ004DR_out.strStockerInfoInqResult.maxUTSCapacity ;
//DSIV00000099                    strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[0].strEqpStockerStatus[0].stockerPriority = CIMFWStrDup("0");
                    strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[0].strEqpStockerStatus[0].stockerType     = strStocker_baseInfo_Get_out.strStockerInfoInqResult.stockerType ;        //DSIV00000099
                    strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[0].strEqpStockerStatus[0].stockerStatus   = strStocker_baseInfo_Get_out.strStockerInfoInqResult.actualStatusCode ;   //DSIV00000099
                    strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[0].strEqpStockerStatus[0].UTSFlag         = strStocker_baseInfo_Get_out.strStockerInfoInqResult.UTSFlag ;            //DSIV00000099
                    strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[0].strEqpStockerStatus[0].maxUTSCapacity  = strStocker_baseInfo_Get_out.strStockerInfoInqResult.maxUTSCapacity ;     //DSIV00000099
                    strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[0].strEqpStockerStatus[0].stockerPriority = CIMFWStrDup("0");                                                        //DSIV00000099
                }
                else
                {
                    /**********************************************************************************************/
                    /*   Set the current Stocker if the Lot is in Bank(The bank has no stocker) and in Stocker.   */
                    /**********************************************************************************************/
                    if ( 0 != CIMFWStrLen(cassetteLocationInfo.stockerID.identifier) )
                    {
                        strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq.length(1);
                        strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[0].strEqpStockerStatus.length(0);
                        setCurrentStockerFlag = TRUE;
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "### The cassette is not in Equipment, and cannot find any stockers." );
                        //Already set stockers of equipment if the Lot is on Equipment.
                    }
                }
            }
        }

        /********************************************************************************************/
        /*  At least one equipment doesn't have stocker. Get it from cassettte related equipment.   */
        /********************************************************************************************/
        if( TRUE == setCurrentStockerFlag )
        {
            /********************************************/
            /* Get Current Machine detail information   */
            /********************************************/
            pptEqpStockerStatus aCurrentStockerInfo;
            if( 0 < CIMFWStrLen(cassetteLocationInfo.stockerID.identifier) )
            {
                PPT_METHODTRACE_V1("", "##### Set Cassette Current Stocker");
                PPT_METHODTRACE_V2(""," ### carrier current stocker ID = ", aCurrentStockerInfo.stockerID.identifier );
//D9000084                objStocker_FillInTxLGQ004DR_out strStocker_FillInTxLGQ004DR_out;
//D9000084                rc = stocker_FillInTxLGQ004DR( strStocker_FillInTxLGQ004DR_out, strObjCommonIn,
//D9000084                                               cassetteLocationInfo.stockerID );
//D9000084
//D9000084                if( rc != RC_OK )
//D9000084                {
//D9000084                    PPT_METHODTRACE_V2(""," #### stocker_FillInTxLGQ004DR != RC_OK : rc = ", rc );
//D9000084                    strEquipment_stockerOrder_GetByLotStatus_out.strResult = strStocker_FillInTxLGQ004DR_out.strResult ;
//D9000084                    return rc;
//D9000084                }
//DSIV00000099//D9000084 add start
//DSIV00000099                objStocker_baseInfo_Get_in__090 strStocker_baseInfo_Get_in;
//DSIV00000099                strStocker_baseInfo_Get_in.stockerID = cassetteLocationInfo.stockerID;
//DSIV00000099
//DSIV00000099                objStocker_baseInfo_Get_out__090 strStocker_FillInTxLGQ004DR_out;
//DSIV00000099                rc = stocker_baseInfo_Get__090( strStocker_FillInTxLGQ004DR_out,
//DSIV00000099                                                strObjCommonIn,
//DSIV00000099                                                strStocker_baseInfo_Get_in );
//DSIV00000099
//DSIV00000099                if( rc != RC_OK )
//DSIV00000099                {
//DSIV00000099                    PPT_METHODTRACE_V2(""," #### stocker_baseInfo_Get__090() != RC_OK : rc = ", rc );
//DSIV00000099                    strEquipment_stockerOrder_GetByLotStatus_out.strResult = strStocker_FillInTxLGQ004DR_out.strResult ;
//DSIV00000099                    return rc;
//DSIV00000099                }
//DSIV00000099//D9000084 add end
//DSIV00000099 add start
                objStocker_baseInfo_Get_out__100 strStocker_baseInfo_Get_out;
                objStocker_baseInfo_Get_in__090  strStocker_baseInfo_Get_in;
                strStocker_baseInfo_Get_in.stockerID = cassetteLocationInfo.stockerID;

                rc = stocker_baseInfo_Get__100( strStocker_baseInfo_Get_out,
                                                strObjCommonIn,
                                                strStocker_baseInfo_Get_in );

                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2(""," #### stocker_baseInfo_Get__100() != RC_OK : rc = ", rc );
                    strEquipment_stockerOrder_GetByLotStatus_out.strResult = strStocker_baseInfo_Get_out.strResult ;
                    return rc;
                }
//DSIV00000099 add end

                aCurrentStockerInfo.stockerID       = cassetteLocationInfo.stockerID ;
//DSIV00000099                aCurrentStockerInfo.stockerType     = strStocker_FillInTxLGQ004DR_out.strStockerInfoInqResult.stockerType ;
//DSIV00000099                aCurrentStockerInfo.stockerStatus   = strStocker_FillInTxLGQ004DR_out.strStockerInfoInqResult.actualStatusCode ;
//DSIV00000099                aCurrentStockerInfo.UTSFlag         = strStocker_FillInTxLGQ004DR_out.strStockerInfoInqResult.UTSFlag ;
//DSIV00000099                aCurrentStockerInfo.maxUTSCapacity  = strStocker_FillInTxLGQ004DR_out.strStockerInfoInqResult.maxUTSCapacity ;
//DSIV00000099                aCurrentStockerInfo.stockerPriority = CIMFWStrDup("0");
                aCurrentStockerInfo.stockerType     = strStocker_baseInfo_Get_out.strStockerInfoInqResult.stockerType ;      //DSIV00000099
                aCurrentStockerInfo.stockerStatus   = strStocker_baseInfo_Get_out.strStockerInfoInqResult.actualStatusCode ; //DSIV00000099
                aCurrentStockerInfo.UTSFlag         = strStocker_baseInfo_Get_out.strStockerInfoInqResult.UTSFlag ;          //DSIV00000099
                aCurrentStockerInfo.maxUTSCapacity  = strStocker_baseInfo_Get_out.strStockerInfoInqResult.maxUTSCapacity ;   //DSIV00000099
                aCurrentStockerInfo.stockerPriority = CIMFWStrDup("0");                                                      //DSIV00000099
            }

            /********************************************/
            /*  If stocker type is "Auto", then set it. */
            /*  Else, no stocker is set.                */
            /********************************************/
            if( 0 == CIMFWStrCmp( aCurrentStockerInfo.stockerType, SP_Stocker_Type_Auto ) )
            {
                CORBA::ULong eLen = strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq.length();
                for (CORBA::ULong i = 0 ; i < eLen ; i++)
                {
                    CORBA::ULong sLen = strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[i].strEqpStockerStatus.length();
                    if( 0 == sLen )
                    {
                        strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[i].strEqpStockerStatus.length(1);
                        strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[i].strEqpStockerStatus[0] = aCurrentStockerInfo;
                    }
                }
            }
        }

        //Debug trace
        PPT_METHODTRACE_V1("", "######## Stocker order");
        CORBA::ULong eLen = strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq.length();
        for (CORBA::ULong i = 0 ; i < eLen ; i++)
        {
            PPT_METHODTRACE_V2("", "###### eqpID      = ", strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[i].equipmentID.identifier );
            CORBA::ULong sLen = strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[i].strEqpStockerStatus.length();
            for(CORBA::ULong j = 0 ; j < sLen ; j++)
            {
                PPT_METHODTRACE_V2("", "### stockerID  = ", strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq[i].strEqpStockerStatus[j].stockerID.identifier );
            }
        }

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::equipment_stockerOrder_GetByLotStatus");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strEquipment_stockerOrder_GetByLotStatus_out, equipment_stockerOrder_GetByLotStatus, methodName)
}

