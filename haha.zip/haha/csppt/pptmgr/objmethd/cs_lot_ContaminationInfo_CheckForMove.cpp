//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_lot_ContaminationInfo_CheckForMove.cpp
//
//
#include "cs_pptmgr.hpp"
#include "plot.hh"
#include "pcas.hh"
//
// Class: CS_PPTManager
//
// Service: cs_lot_ContaminationInfo_CheckForMove()
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------  -------------- -------------------------------------------
// 2017-08-28 INN-R170002   JJ.Zhang       Contamination control
//
//[Function Description]:
//
//
//[Input Parameters]:
//  in  pptObjCommonIn      strObjCommonIn;
//  in  csObjLot_ContaminationInfo_CheckForMove_in    strLot_ContaminationInfo_CheckForMove_in
//
//[Output Parameters]:
//
//  out csObjLot_ContaminationInfo_CheckForMove_out  strLot_ContaminationInfo_Set_out;
//
//  typedef struct csObjLot_ContaminationInfo_CheckForMove_out_struct {
//    boolean          holdReqFlag;
//    any              siInfo;
//} csObjLot_ContaminationInfo_CheckForMove_out;
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::cs_lot_ContaminationInfo_CheckForMove(
    csObjLot_ContaminationInfo_CheckForMove_out&      strLot_ContaminationInfo_CheckForMove_out, 
    const pptObjCommonIn&                             strObjCommonIn, 
    const csObjLot_ContaminationInfo_CheckForMove_in& strLot_ContaminationInfo_CheckForMove_in)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_lot_ContaminationInfo_CheckForMove");
        CORBA::Long rc = RC_OK;
        strLot_ContaminationInfo_CheckForMove_out.holdReqFlag = FALSE;

        objectIdentifier lotID = strLot_ContaminationInfo_CheckForMove_in.lotID;
        PPT_METHODTRACE_V2("","lotID    --->", lotID.identifier);
        PPT_METHODTRACE_V2("","carrierID--->", strLot_ContaminationInfo_CheckForMove_in.carrierID.identifier);

        PosLot_var aPosLot;
        PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot, lotID, strLot_ContaminationInfo_CheckForMove_out, cs_lot_ContaminationInfo_CheckForMove );

        PosCassette_var aPosCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aPosCassette, strLot_ContaminationInfo_CheckForMove_in.carrierID,
                                               strLot_ContaminationInfo_CheckForMove_out,
                                               cs_lot_ContaminationInfo_CheckForMove );

        //----------------------------------------------
        // cs_lot_ContaminationInfo_Get, get udata
        //----------------------------------------------
        PPT_METHODTRACE_V1("", "call cs_lot_ContaminationInfo_Get()") ;

        csObjLot_ContaminationInfo_Get_in  strLot_ContaminationInfo_Get_in;
        strLot_ContaminationInfo_Get_in.lotID = lotID;

        csObjLot_ContaminationInfo_Get_out strLot_ContaminationInfo_Get_out;
        rc = cs_lot_ContaminationInfo_Get(strLot_ContaminationInfo_Get_out,
                                          strObjCommonIn,
                                          strLot_ContaminationInfo_Get_in);

        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "cs_lot_ContaminationInfo_Get() != RC_OK") ;
            strLot_ContaminationInfo_CheckForMove_out.strResult = strLot_ContaminationInfo_Get_out.strResult;
            return(rc);
        }

        csLotContaminationInfo& strLotContaminationInfo = strLot_ContaminationInfo_Get_out.strLotContaminationInfo;

        //----------------------------------------------
        // Check carrier category matched or not
        //----------------------------------------------
        CORBA::String_var curOpeCastCategory;
        try
        {
            curOpeCastCategory = aPosLot->getRequiredCassetteCategory();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getRequiredCassetteCategory)
        PPT_METHODTRACE_V2("", "curOpeCastCategory", curOpeCastCategory);

        CORBA::String_var castCategory;
        try
        {
            castCategory = aPosCassette->getCassetteCategory();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getCassetteCategory)
        PPT_METHODTRACE_V2("", "castCategory", castCategory);

        if( 0 < CIMFWStrLen(curOpeCastCategory) && 0 != CIMFWStrCmp(curOpeCastCategory, castCategory) )
        {
            PPT_METHODTRACE_V3("", "curOpeCastCategory != castCategory", curOpeCastCategory, castCategory );
            strLot_ContaminationInfo_CheckForMove_out.holdReqFlag = TRUE;
        }

        //----------------------------------------------
        // Check PR flag and WIP equipment
        //----------------------------------------------
        PPT_METHODTRACE_V2("", "lotPRFlag", strLotContaminationInfo.lotPRFlag);

        if( (FALSE == strLot_ContaminationInfo_CheckForMove_out.holdReqFlag )
         && (0 == CIMFWStrCmp(strLotContaminationInfo.lotPRFlag, CS_M_LOT_PR_Flag_Yes)))
        {
            /********************************/
            /*  Get queued machine List     */
            /********************************/
            PosMachineSequence* aMachineSeq = NULL;
            PosMachineSequence_var aVarMachineSeq;
            
            CORBA::Boolean bOnHold = aPosLot->isOnHold();
            if( FALSE == bOnHold )
            {
                try
                {
                    aMachineSeq = aPosLot->getQueuedMachines();
                    aVarMachineSeq = aMachineSeq;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getQueuedMachines);
            }
            else
            {
                try
                {
                    aMachineSeq = aPosLot->getHoldQueuedMachines();
                    aVarMachineSeq = aMachineSeq;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getHoldQueuedMachines)
            }
            CORBA::Long lotEqpLen = (*aMachineSeq).length();
            PPT_METHODTRACE_V2("", "lotEqpLen",lotEqpLen);

            for (CORBA::Long i=0; i<lotEqpLen; i++)
            {
                CORBA::String_var varEqpPRControl;

                SI_PPT_USERDATA_GET_STRING( (*aMachineSeq)[i], CS_S_EQP_PRControl, varEqpPRControl );
                PPT_METHODTRACE_V2("", "varEqpPRControl", varEqpPRControl);

                if( 0 == CIMFWStrCmp(varEqpPRControl, CS_PRControl_Action_AvoidPR ) )
                {
                    strLot_ContaminationInfo_CheckForMove_out.holdReqFlag = TRUE;
                    break;
                }
            }
        }

        //----------------------------------------------
        // Check lot contamination flag
        //----------------------------------------------
        if( FALSE == strLot_ContaminationInfo_CheckForMove_out.holdReqFlag )
        {
            PPT_METHODTRACE_V2("", "opeContamiInLevel", strLotContaminationInfo.opeContamiInLevel );
            PPT_METHODTRACE_V2("", "lotContamiFlag   ", strLotContaminationInfo.lotContamiFlag );

            if( 0 <  CIMFWStrLen(strLotContaminationInfo.opeContamiInLevel)
             && 0 <  CIMFWStrLen(strLotContaminationInfo.lotContamiFlag)
             && 0 != CIMFWStrCmp(strLotContaminationInfo.opeContamiInLevel, strLotContaminationInfo.lotContamiFlag) )
            {
                PPT_METHODTRACE_V1("", "opeContamiInLevel != lotContamiFlag" );
                strLot_ContaminationInfo_CheckForMove_out.holdReqFlag = TRUE;
            }
        }

        //----------------------------------------------
        // Check lot-carrier usage type
        //----------------------------------------------
        if( FALSE == strLot_ContaminationInfo_CheckForMove_out.holdReqFlag )
        {
            ProductSpecification_var aTmpProductSpecification;
            PosProductSpecification_var aProductSpecification;
            try
            {
                aTmpProductSpecification = aPosLot->getProductSpecification();
                aProductSpecification = PosProductSpecification::_narrow(aTmpProductSpecification);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification);

            if ( TRUE == CORBA::is_nil(aProductSpecification) )
            {
                PPT_METHODTRACE_V1("", "Error : Lot Product ID is NIL");
                SET_MSG_RC( strLot_ContaminationInfo_CheckForMove_out,
                            MSG_NOT_FOUND_PRODUCTSPEC,
                            RC_NOT_FOUND_PRODUCTSPEC );
                return RC_NOT_FOUND_PRODUCTSPEC;
            }

            CORBA::String_var varProdUsageType;
            CORBA::String_var varCarrierUsageType;
            SI_PPT_USERDATA_GET_STRING( aProductSpecification, CS_S_PROD_CarrierUsageType, varProdUsageType );
            SI_PPT_USERDATA_GET_STRING( aPosCassette, CS_M_CAST_UsageType, varCarrierUsageType );

            PPT_METHODTRACE_V3("", "varProdUsageType/varCarrierUsageType", varProdUsageType, varCarrierUsageType );

            if( 0 <  CIMFWStrLen(varProdUsageType) && 0 < CIMFWStrLen(varCarrierUsageType)
             && 0 != CIMFWStrCmp(varProdUsageType, varCarrierUsageType) )
            {
                PPT_METHODTRACE_V1("", "varProdUsageType != varCarrierUsageType" );
                strLot_ContaminationInfo_CheckForMove_out.holdReqFlag = TRUE;
            }
        }

        //----------------------------------------------
        // Check whether lot is on CCUH hold
        //----------------------------------------------
        if( TRUE == strLot_ContaminationInfo_CheckForMove_out.holdReqFlag )
        {
            objLot_FillInTxTRQ005DR_out strLot_FillInTxTRQ005DR_out;
            rc = lot_FillInTxTRQ005DR( strLot_FillInTxTRQ005DR_out, strObjCommonIn, lotID );
            if( rc == RC_OK )
            {
                CORBA::Long lngHoldLen = 0;
                CORBA::Long lngHoldCnt = 0;
                lngHoldLen = strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes.length();

                for( lngHoldCnt = 0; lngHoldCnt < lngHoldLen; lngHoldCnt++ )
                {
                    if( CIMFWStrCmp( strLot_FillInTxTRQ005DR_out.strLotHoldListAttributes[lngHoldCnt].reasonCodeID.identifier, CS_SP_Reason_ContaminationMismatchHold ) == 0 )
                    {
                        PPT_METHODTRACE_V1( "", "ContaminationMismatchHold record exists!" );
                        strLot_ContaminationInfo_CheckForMove_out.holdReqFlag = FALSE;
                        break;
                    }
                }
            }
            else if( rc != RC_NOT_FOUND_ENTRY )
            {
                PPT_METHODTRACE_V2( "", "lot_FillInTxTRQ005DR() rc=", rc);
                strLot_ContaminationInfo_CheckForMove_out.strResult = strLot_FillInTxTRQ005DR_out.strResult;
                return( rc );
            }
        }

        //----------------------------
        //  Return to Caller
        //----------------------------
        SET_MSG_RC(strLot_ContaminationInfo_Get_out, MSG_OK, RC_OK);
        PPT_METHODTRACE_EXIT("CS_PPTManager_i::cs_lot_ContaminationInfo_CheckForMove");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_ContaminationInfo_CheckForMove_out, cs_lot_ContaminationInfo_CheckForMove, methodName)
}
