#ifndef lint
static char *sccsid =  "@(#) 1.10 superpos/src/spppt/source/posppt/pptmgr/objmethd/environmentVariable_Set.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 8/6/08 12:14:49 [ 8/6/08 12:14:50 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: environmentVariable_Set.cpp
//

//INN-A170001 #include "pptmgr.hpp"
#include "cs_pptmgr.hpp"    //INN-A170001

// Class: PPTManager
//
// Service: environmentVariable_Set()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2001-06-11 D4000012 M.Shimizu      The first coding(R40)
// 2001-08-21          M.Shimizu      Add Environment Variable
// 2001-08-27 D4000014 K.Kido         Add Environment Variable for APC I/F
// 2001-09-04 D4000137 K.Kido         Add for TCS environment value
// 2001-09-14 D4000157
//            D4000171
//            D4000172 K.Kido         Add Environment Variable for ControlLot,MMQueryServer,BankInCancel
// 2001-10-05 P4000329 K.Kido         Rollback from DCR4000172
// 2001-10-05 D4000216 K.Kido         Add Environment Variable for EqpModeChangeReq
// 2001-10-23 D4000243 K.Kido         Add Environment Variable for lot_CheckDurationForOperation
// 2002-01-22 D4100081 Cinthia Jao    Add Environment variable for durableChangeEvent_Make
// 2002-01-22 D4100069 C.Tsuchiya     Delete Environment variable for LCFR
// 2002-02-25 D4100134 C.Tsuchiya     Delete all Environment variable data members
// 2002-02-26 D4100134(2) C.Tsuchiya  Add Environment Variables ( moved from PPTServerManager )
// 2002-02-26 D4100113 C.Tsuchiya     Add Environment Variables for Entitiy Inhibit wild card
// 2002-02-26 D4100133 C.Tsuchiya     Add Environment Variables for Bind timeout for TCS
// 2002-03-25 D4100206 C.Tsuchiya     Delete Environment Variable SP_xxx_By_SQL
// 2002-03-25 D4100208 H.Adachi       Add environment variable for Alarm List & Lot List
// 2002-04-18 D4100237 K.Matsuei      Add SmartTCS control.
// 2002-05-28 D4100281 C.Tsuchiya     Add check logic for env value and length
// 2002-06-04 D4100292 K.Kimura       Change Logic of Lot Schedule Change after checking Control Job ID.
// 2002-08-16 D4200075 K.Matsuei      Add EBrokerTCS control.
// 2002-10-04 D4200127 C.Tsuchiya     Limit maximum lot list length returned from LotListInq
// 2002-12-26 D4200245 M.Kase         Add environment variable for save/not save '*' data
// 2003-01-22 D4200265 K.Matsuei      Add environment variable : SP_ZONETYPE_NEED_FLAG_IN_CASTLIST.
// 2003-01-24 D4200273 K.Matsuei      TakeOut Xfer is supported under EqpState:NotAvailable, PortState:UnloadReq conditions.
// 2003-02-10 D4200293 K.Matsuei      Set maximum to OperationHistoryInq.
// 2003-03-04 D4200322 H.Adachi       Add environment variable : SP_CASSETTELIST_SEQLEN_DEFAULT_FOR_CASSETTE_LIST_INQ
//                                                               SP_CASSETTELIST_SEQLEN_FOR_CASSETTE_LIST_INQ
//                                                               SP_CASSETTELIST_SEQLEN_MAX_FOR_CASSETTE_LIST_INQ
//                                                               SP_RETICLELIST_SEQLEN_DEFAULT_FOR_RETICLE_LIST_INQ
//                                                               SP_RETICLELIST_SEQLEN_FOR_RETICLE_LIST_INQ
//                                                               SP_RETICLELIST_SEQLEN_MAX_FOR_RETICLE_LIST_INQ
//                                                               SP_ALARMLIST_SEQLEN_MAX_FOR_EQP_ALARM_HISTORY_INQ
// 2003-04-23 D5000058 M.Kase         Add environment variable : SP_SCREENLIMITOVER_NOTCALCULATE_FLAG
// 2003-07-04 D5000123 H.Adachi       Add environment variable : SP_PrivilegeCheck_BY_DR_FLAG
// 2003-07-10 D5000154 K.Kido         Add environment variable : SP_LOTINFO_BY_SQL
// 2003-08-15 D5000194 K.Matsuei      Add environment variable : SP_REROUTE_XFER_FLAG
// 2003-09-03 D5000178 K.Kido         Add environment variable : SP_PROHIBIT_CHARACTER
// 2003-11-19 D5100016 K.Matsuei      Add environment variable : SP_ORBIX_DEFAULT_TIMEOUT
// 2004-01-09 D5100138 K.Matsuei      Add environment variable : SP_STAYONPORT_WITH_NO_DESTINATION
// 2004-02-10 D5100065 M.Ameshita     Add environment variable : SP_SOOR_INHIBIT_CANCEL_BY_ACK
//                                                               SP_WSPC_SERVER_NAME
//                                                               SP_WSPC_HOST_NAME
// 2004-04-07 D5100232 K.Matsuei      Add environment variable : SP_DCS_SERVER_NAME
//                                                               SP_DCS_HOST_NAME
//                                                               SP_BindEverytime_DCS
//                                                               SP_TX_Timeout_DCS
//                                                               SP_DCS_Available
//                                                               SP_DCS_Ignore_OpeStart_Result
//                                                               SP_DCS_Ignore_OpeStartCancel_Result
//                                                               SP_DCS_Ignore_OpeComp_Result
// 2004-08-11 D51M0000 K.Tachibana    Add environment variable : SP_MM_SYSTEM_NAME
//                                                               SP_APC_SYSTEM_NAME
//                                                               SP_INHIBIT_WHEN_APC_RPARMADJUST_NG
//                                                               SP_INHIBIT_WHILE_APCIF_DEFINE
// 2004-10-22 D6000009 S.Yamamoto     Add environment variable : SP_HISTORY_EVENTFIFO_DISTRIBUTE
// 2004-11-08 D6000073 M.Mori         Add environment variable : SP_APCENTVAL_MAX_COUNT
// 2005-01-17 P6000221 M.Murata       Delete environment variable : BRS_HOST_NAME, BRS_SERVER_NAME
// 2005-04-11 D6000215 K.Kido         Add environment variable : SP_INHIBIT_MAX_SEQLEN_FOR_INHIBIT_LIST_INQ
// 2005-05-09 D6000222 K.Matsuei      Add environment variable : SP_RCOK_NoData_For_ListInq
// 2005-05-16 D6000275 M.Murata       Add environment variables: SP_APCHostName_ForGenIOR
//                                                               SP_APCServerName_ForGenIOR
//                                                               SP_APCMarkerName_ForGenIOR
//                                                               SP_APCPortNo_ForGenIOR
//                                                               SP_CheckExistenceFlag
// 2005-05-16 D6000313 M.Murata       Add environment variables: SP_XMSHostName_ForGenIOR
//                                                               SP_XMSServerName_ForGenIOR
//                                                               SP_XMSMarkerName_ForGenIOR
//                                                               SP_XMSPortNo_ForGenIOR
//                                                               SP_CheckExistenceFlag
// 2005-05-16 D6000316 M.Murata       Add environment variables: SP_DCSHostName_ForGenIOR
//                                                               SP_DCSServerName_ForGenIOR
//                                                               SP_DCSMarkerName_ForGenIOR
//                                                               SP_DCSPortNo_ForGenIOR
//                                                               SP_CheckExistenceFlag
// 2005-07-11 D6000379 K.Kido         Add environment variable : SP_BKUP_COUNT_SEQLEN_INQ
// 2005-08-31 D6000398 M.Kase         Add environment variable : SP_DCDEFDCSPEC_RELATION_CHECK_FLAG
// 2005-09-02 D6000389 K.Kido         Add environment variable : SP_LOTFAMILY_DUPLICATION_ALLOWABLE_FLAG
// 2005-11-01 D7000006 T.Ohsaki       Add environment variable : SP_CONTROLJOB_STATUS_CHANGE_HISTORY_MASK
// 2005-11-10 D7000026 K.Kido         Del environment variable : SP_LOTINFO_BY_SQL
// 2005-12-12 D7000096 Y.Kadowaki     Del environment variable : SP_DELIVERY_REQ_EXIST
// 2006-01-27 D7000182 H.Mutoh        Add environment variable : SP_ROLLBACK_NOTIFY_TO_APC
// 2006/02/17 D7000183 K.Matsuei      Add environment variable : SP_MINIMUM_BATCH_CONDITION_APPLY_FLAG_FOR_DELIVERY
// 2006-03-16 D7000219 M.Kase         Add environment variable : SP_CASSETTE_RELATION_CHECK_FOR_HOLD
// 2006-04-24 P7000243 S.Yamamoto     Add environment variables: SP_DR_RETRY_COUNT
//                                                               SP_DR_RETRY_INTERVAL
// 2006-10-26 D7000371 K.Kido         Add environment variable : SP_SHORTEST_QTIME_USE_FLAG
// 2006-11-06 D8000024 H.Mutoh        Add environment variable : SP_FPC_ADAPTATION_FLAG, SP_FPC_CONTINUOUS_SKIP_LIMIT
// 2006-11-09 D8000084 H.Hasegawa     Add environment variables: SP_CARRIER_BASEINFO_UPDATE_CHECK, SP_RETICLEPOD_BASEINFO_UPDATE_CHECK
// 2007-02-15 P8000082 K.Matsuei      Add environment variable : SP_MONITOR_WAIT_HOLD_NEW_LOGIC
// 2007-03-01 D8000184 K.Matsuei      Add environment variable : SP_EQP_STATUS_TRANSITION_LIMITATION
// 2007-03-09 D8000186 K.Kido         Add environment variable : SP_LOT_DELETION_CHECK_EVENT_FLAG
// 2007-03-19 D8000204 K.Kido         Add environment variable : SP_ENTITY_INHIBIT_THRESHOLD_COUNT
// 2007-04-02 D8000207 M.Murata       Add environment variable : SP_OPER_START_WAFER_FLAG_CONTROL
// 2007-04-20 D9000001 M.Murata       64bit support
// 2007-06-28 D9000003 M.Nakano       Remove environment variable : SP_OPER_START_WAFER_FLAG_CONTROL
// 2007-07-09 D9000053 K.Kido         Add environment variable : SP_EQP_MODE_CHANGE_OFFLINE_TO_ONLINE_POSSIBLE
// 2007-09-26 D9000084 K.Kido         Add environment variable : SP_ARMS_FUNC_ENABLED, SP_RSP_ON_PORT_CHECK_FLAG
//                                                               RXM_HOST_NAME, RXM_SERVER_NAME
//                                                               SP_RXMSHostName_ForGenIOR, SP_RXMSServerName_ForGenIOR, SP_RXMSMarkerName_ForGenIOR, SP_RXMSPortNo_ForGenIOR
//                                                               SP_BindEverytime_RXM, SP_TX_Timeout_RXM
// 2007-09-20 D9000079 D.Tamura       Add environment variables: SP_FLOWBATCH_CLEARED_BY_OPERSTART, SP_FLOWBATCH_CLEARED_BY_OPERCANCEL
// 2007-10-15 D9000056 H.Hotta        Add environment variable : SP_LOCK_HOLD_USE_FLAG
//                                                               SP_POSTPROC_FLAG_USE_FLAG
// 2008-02-21 P9000222 H.Hotta        Add environment variable : SP_SPLIT_LOT_REQUEUE_FLAG
// 2008-02-25 D9000175 K.Kido         Add environment variable : SP_DELIVERY_TAKE_OUTIN_ENABLE_FLAG
// 2008-07-08 DSIV00000099 M.Murata   Add environment variable : SP_SLM_SRC_CAST_PRIORITY   (SLM(Small Lot Manufacturing) Support.)
// 2008-08-06 D9000246 M.Ishino       Add environment variable : SP_FRLOTPO_MAINTENANCE
//                                                               SP_FRLOTPO_CHECK_FOR_DELETE
//                                                               SP_CHECK_FOR_DELETE_STAGE
//                                                               SP_CHECK_FOR_DELETE_SCRIPT
//                                                               SP_CHECK_FOR_DELETE_DCDEF
//                                                               SP_CHECK_FOR_DELETE_DCSPEC
//                                                               SP_CHECK_FOR_DELETE_STORAGEMACHINE
//                                                               SP_CHECK_FOR_DELETE_LOGICALRECIPE
//                                                               SP_CHECK_FOR_DELETE_MACHINERECIPE
// 2008-10-09 DSIV00000201 M.Ishino   Add environment variable : SP_POSTPROC_FOR_LOT_FLAG
//                                                               SP_ExternalPostProc_UseFlag
//                                                               SP_ExternalPostProc_UserGrp
// 2008-10-15 DSIV00000220 M.Ogawa    Add environment variable : SP_LOT_STBCANCEL
//                                                               SP_LOT_PREPARECANCEL
// 2008-10-27 DSIV00000286 H.Nonaka   Add environment variable : SP_USE_CDR_FOR_AUTO3DISPATCH
// 2008-11-27 PSIV00000455 M.Ishino   Logic change of SP_ExternalPostProc_UserGrp setup.
// 2009/10/02 DSIV00001365 R.Okano    Add environment variable : SP_WSPC_LINK_URL
// 2009-10-08 DSIV00001441 S.Yamamoto Add environment variable : SP_SCRIPTPARAMETER_CHANGE_EVENT
// 2009-10-08 DSIV00001021 H.Nonaka   Add environment variable : SP_CORRES_DEFAULT_MODE
// 2009-10-22 DSIV00001471 F.Chen     Add environment variable : SP_DC_DATA_CHECK_LEVEL
//                                                               SP_DC_DATA_CHECK_PHASE
// 2009-10-26 DSIV00001443 S.Kawabe   Add environment variable : SP_ENTITY_INHIBIT_SEARCH_CONDITION
// 2009-11-02 DSIV00001481 K.Yamaoku  Add environment variable : SP_USE_DB_TIMESTAMP
// 2010-07-05 DSIV00002162 K.Yamaoku  Add environment variable : SP_OWNER_CHANGE_MAX_COMMIT_COUNT
// 2010-07-12 DSIV00001788 S.Kawabe   Add environment variable : SP_CASSETTE_LOAD_SEQUENCE_CONDITION
// 2010-10-13 DSIV00002458 F.Chen     Add environment variable : SP_EQPSTAT_BACKUP
// 2010-10-15 PSIV00002506 F.Chen     Fix default value of environment variable : SP_USE_DB_TIMESTAMP
// 2010-10-15 DSIV00002326 N.Makino   Add environment variable : SP_DURABLEHIS_MAX_SEQLEN_FOR_DURABLEHIS_INQ
//                                                               SP_EQUIPMENTHIS_MAX_SEQLEN_FOR_EQUIPMENTHIS_INQ
// 2010-10-14 DSIV00002270 K.Yamaoku  Add environment variable : SP_POMAINT_EVENT_CREATE_TYPE
// 2011-05-18 PSIV00003221 S.Kawabe   Add environment variable : SP_BRANCH_RETURN_ACTIVE_MODULE
// 2011-08-08 DSN000015229 Yang Xia   Add environment variable : SP_DCS_PJCTRL_AVAILABLE
//                                                               SP_DCS_IGNORE_PJRPT_RESULT
//                                                               SP_PJCTRL_FUNC_ENABLED
//                                                               SP_PROCESSHIS_MAX_SEQLEN_FOR_PROCESSHIS_INQ
// 2011-10-21 DSN000022151 Qiang Wen  Add environment variable : SP_KEEP_QTIME_ON_SCHCHANGE
// 2012-02-15 DSN000033655 K.Yamaoku  Add environment variable : SP_QTIMEINFO_MERGE_RULE
// 2012-02-23 PSN000035912 K.Yamaoku  Remove environment variable : SP_PROCESSHIS_MAX_SEQLEN_FOR_PROCESSHIS_INQ
// 2012-04-18 DSN000041192 T.Ishida   Add environment variable : SP_LAGTIMEINFO_MERGE_RULE
// 2012-06-04 DSN000041621 F.Chen     Add environment variable : SP_EQP_UDATA_MODE
// 2012-06-04 DSN000041626 F.Chen     Add environment variable : SP_CTRLJOBID_GEN_BY_DISP
// 2012-06-04 DSN000041636 F.Chen     Add environment variable : SP_LAST_USED_RECIPE_UPDATE_FLAG/SP_EQPATTR_UPDATE_BY_POSTPROC
// 2012-07-25 DSN000043340 M.Ogawa    Add environment variable : SP_POSTPROC_SEARCH_SEPARATOR_CHAR
//                                    Logic change of SP_POSTPROC_FOR_LOT_FLAG setup.
// 2012-11-13 PSN000043994 Sa Guo     Add environment variable : SP_CHAMBER_CHECK_POLICY
// 2012-11-27 DSN000049350 F.Chen     Add environment variable : SP_EQP_LOCK_MODE
//                                                               SP_SORTERJOB_LOCK_FLAG
// 2013-01-29 DSN000050720 M.Ogawa    Add environment variable : SP_POSTPROC_PARALLEL_SWITCH
//                                                               SP_POSTPROC_PARALLEL_WORKER_SEARCH_RETRY
//                                                               SP_POSTPROC_PARALLEL_RETRY_SLEEP_TIME
//                                                               SP_POSTPROC_PARALLEL_ACTION_RETRY_COUNT
// 2013-02-20 PSN000068955 H.Hayashi  Add environment variable  "SP_PROPERTYSET_CREATE_ENABLED"
// 2013-05-02 DSN000075358 S.Yamamoto Add environment variable : SP_SCRIPTPARAMETER_UPDATE_MODE
// 2013-05-08 DSN000071674 C.Mo       Add environment variable : SP_LOT_OPERATION_EI_CHECK
// 2013-05-13 PSN000075397 K.Yamaoku  Add environment variable : SP_PROPERTYSET_FOR_FACTORY_USE_SYSTEM_KEY_0
// 2013-05-14 DSN000075522 H.Hayashi  Add environment variable : SP_CREATE_PROPERTYSET_FOR_NEW_LOT
// 2013-08-10 DSN000080226 W.Zhang    Add environment variable : SP_PRIVILEGECHECK_FOR_CJ
//                                                               SP_PRIVILEGECHECK_FOR_CAST
// 2013-08-23 DSN000080287 T.Fujikawa Add environment variable : SP_KEEP_QTIME_ACTION_ON_CLEAR
// 2013-09-13 DSN000081739 Sa Guo     Add environment variable : SP_EQPMONITOR_SWITCH
// 2013-09-28 DSN000075328 JJ.Zhang   Add environment variable : SP_POSTPROC_CHAINED_MODE
//                                                               SP_POSTPROC_MAX_CHAIN_EXEC
// 2013-10-28 DSN000076129 T.Itou     Add environment variable : SP_DCSPEC_FOR_PROCESS
// 2014-02-12 DSN000085024 C.Mo       Add environment variable : SP_WARNING_ON_PSM_REGISTRATION
// 2014-05-17 PSN000081348 C.Mo       Add environment variable : SP_PROCESSHOLD_ALLOW_LOTMOVEMENT
// 2014-05-22 DSN000085698 S.Wang     Add environment variable : SP_RESET_EQPMON_USED_COUNT_ON_STB
// 2014-09-12 PSN000090028 VietNQ     Add environment variable : SP_OWNER_CHANGE_DELETE_DUPLICATE_RECORD
// 2014-10-13 DSN000085793 JJ.Zhang   Add environment variable : SP_WIP_LOT_RESET_UPDATE_LEVEL
// 2014-10-22 DSN000088570 VietNQ     Remove the limitation of max time for end time of entity inhibit
// 2014-10-23 DSN000085792 Sa Guo     Add environment variable : SP_INACTIVE_QTIME_LIST
//                                                               SP_QTIME_REPLACETRIGGER_MAINPD_PRIORITY
// 2015-01-23 DSN000096227 RK.Hou     Improve the limit value of got list information by function Tx
// 2015-09-06 DSN000100527 JJ.Zhang   Add environment variable : SP_BANKINCANCEL_PRODUCT_CHECK
// 2015-09-10 DSN000096144 S.Kawabe   Add environment variable : SP_USER_PRIVILEGE_POLICY
// 2015-10-01 DSN000096141 S.Kawabe   Add environment variable : SP_PASSCOUNT_WAFERLEVEL_CONTROL
//                                                               SP_PASSCOUNT_WAFERLEVEL_EVENT_CREATION
//                                                               SP_LOT_OPERATION_MOVE_EVENT_CREATION_FOR_STB
// 2016-01-12 PSN000101301 K.Yamaoku  Add environment variable : SP_QTIME_DISPATCHPRECEDE_USE_CUSTOMFIELD
// 2016-07-26 DSN000101569 C.Mo       Add environment variable : SP_DURABLE_SUBSTATUS_TRANSITION_LIMITATION
//                                                               SP_RETRIEVE_RETICLE_DURING_LOTPROCESS
//                                                               SP_DURABLEPROCESS_FOR_NON_EMPTY_CARRIER
//                                                               SP_DURABLEPROCESS_FOR_NON_EMPTY_RETICLEPOD
// 2016-09-05 DSN000101643 R.Iriguchi Add environment variable : SP_ENCRYPT_PASSWORD
// 2017-02-27 DSN000104510 VietNQ     Add environment variable : SP_DISPATCH_CAST_CLEARED_BY_CHANGE_TO_ONLINE
// 2017-05-15 PSN000105028 S.Kawabe   Add environment variable : SP_FRLOTPO_DELETE_FOR_SCRAPPED
//                                                               SP_FRLOTPO_DELETE_FOR_EMPTIED
//                                                               SP_FRLOTPO_DELETE_FOR_SHIPPED
//                                                               SP_FRLOTPO_DELETE_FOR_STACKED
// Innotron Modification history :
// Date       Defect#     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
// 2017/09/25 INN-R170008 Menghua Yin    Add environment variable : CS_TACERTIFY_SKILL_EXP_DURATION
//                                       Add environment variable : CS_TACERTIFY_PRE_ALARM_DURATION
//
// Description:
//
// Return:
//     Long
//
// Parameter:
//    objEnvironmentVariable_Set_out& strEnvironmentVariable_Set_out
//    const pptObjCommonIn& strObjCommonIn
//    const pptEnvVariableListSequence& strPptEnvVariable
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::environmentVariable_Set(
                            objEnvironmentVariable_Set_out& strEnvironmentVariable_Set_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const pptEnvVariableListSequence& strPptEnvVariable)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::environmentVariable_Set");

        //----------------------------
        // Set SaveData Length
        //----------------------------
        CORBA::Long ppt_env_len = strPptEnvVariable.length();
        CORBA::Long i = 0;

        PPT_METHODTRACE_V2("environmentVariable_Set","strPptEnvVariable.length() = ", ppt_env_len);

        char* workptr; //D4100134

        //---------------------------------
        // Set PPTMGR Environment Variable
        //---------------------------------
        for(i = 0; i < ppt_env_len; i++ )
        {

            PPT_METHODTRACE_V3("environmentVariable_Set","Set Name Is = ", strPptEnvVariable[i].envName,i);
            PPT_METHODTRACE_V3("environmentVariable_Set","Set Value Is = ", strPptEnvVariable[i].envValue,i);

//P5100736            if(CIMFWStrCmp(strPptEnvVariable[i].envName, BRS_HOST_NAME) == 0)
//P5100736            {
//P5100736                PPT_METHODTRACE_V3("environmentVariable_Set","Set BRS_HOST_NAME = ", strPptEnvVariable[i].envValue,i);
//P5100736                //D4100134 theBRS_HOST_NAME = strPptEnvVariable[i].envValue;
//P5100736                workptr = getenv(BRS_HOST_NAME);                                          //D4100134
//P5100736                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//P5100736                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
//P5100736                continue;
//P5100736            }
//P5100736            if(CIMFWStrCmp(strPptEnvVariable[i].envName, BRS_SERVER_NAME) == 0)
//P5100736            {
//P5100736                PPT_METHODTRACE_V3("environmentVariable_Set","Set BRS_SERVER_NAME = ", strPptEnvVariable[i].envValue,i);
//P5100736                //D4100134 theBRS_SERVER_NAME = strPptEnvVariable[i].envValue;
//P5100736                workptr = getenv(BRS_SERVER_NAME);                                        //D4100134
//P5100736                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//P5100736                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
//P5100736                continue;
//P5100736            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_BindEverytime_CSS) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_BindEverytime_CSS = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_BindEverytime_CSS = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_BindEverytime_CSS);                                   //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_BindEverytime_RTD) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_BindEverytime_RTD = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_BindEverytime_RTD = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_BindEverytime_RTD);                                   //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_BindEverytime_SPC) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_BindEverytime_SPC = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_BindEverytime_SPC = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_BindEverytime_SPC);                                   //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_BindEverytime_TCS) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_BindEverytime_TCS = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_BindEverytime_TCS = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_BindEverytime_TCS);                                   //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_BindEverytime_XMS) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_BindEverytime_XMS = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_BindEverytime_XMS = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_BindEverytime_XMS);                                  //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D7000096            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DELIVERY_REQ_EXIST) == 0)
//D7000096            {
//D7000096                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DELIVERY_REQ_EXIST = ", strPptEnvVariable[i].envValue,i);
//D7000096                //D4100134 theSP_DELIVERY_REQ_EXIST = strPptEnvVariable[i].envValue;
//D7000096                workptr = getenv(SP_DELIVERY_REQ_EXIST);                                  //D4100134
//D7000096                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D7000096                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
//D7000096                continue;
//D7000096            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_E10PRIORITY_FILE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_E10PRIORITY_FILE = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_E10PRIORITY_FILE = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_E10PRIORITY_FILE);                                    //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_NOSCHEDULE_FOR_CHILDLOT) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_NOSCHEDULE_FOR_CHILDLOT = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_NOSCHEDULE_FOR_CHILDLOT = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_NOSCHEDULE_FOR_CHILDLOT);                             //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D4100206            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_WHATNEXT_BY_SQL) == 0)
//D4100206            {
//D4100206                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_WHATNEXT_BY_SQL = ", strPptEnvVariable[i].envValue,i);
//D4100206                //D4100134 theSP_WHATNEXT_BY_SQL = strPptEnvVariable[i].envValue;
//D4100206                workptr = getenv(SP_WHATNEXT_BY_SQL);                                     //D4100134
//D4100206                CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D4100206                continue;
//D4100206            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_ZONE_TYPE_FLAG) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_ZONE_TYPE_FLAG = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_ZONE_TYPE_FLAG = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_ZONE_TYPE_FLAG);                                      //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_ZONE_TYPE_INI) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_ZONE_TYPE_INI = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_ZONE_TYPE_INI = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_ZONE_TYPE_INI);                                       //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_EnvName_MaximumWafersInALot) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_EnvName_MaximumWafersInALot = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_EnvName_MaximumWafersInALot = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_EnvName_MaximumWafersInALot);                         //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D4100206            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_EqpInfo_By_SQL) == 0)
//D4100206            {
//D4100206                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_EqpInfo_By_SQL = ", strPptEnvVariable[i].envValue,i);
//D4100206                //D4100134 theSP_EqpInfo_By_SQL = strPptEnvVariable[i].envValue;
//D4100206                workptr = getenv(SP_EqpInfo_By_SQL);                                      //D4100134
//D4100206                CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D4100206                continue;
//D4100206            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_FIXTURE_SEQLEN_FOR_OPEHIS_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_FIXTURE_SEQLEN_FOR_OPEHIS_INQ = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_FIXTURE_SEQLEN_FOR_OPEHIS_INQ = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_FIXTURE_SEQLEN_FOR_OPEHIS_INQ);                       //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            //D4100069 if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_LCFR_Use_Flag) == 0)
            //D4100069 {
            //D4100069     PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_LCFR_Use_Flag = ", strPptEnvVariable[i].envValue,i);
            //D4100069     theSP_LCFR_Use_Flag = strPptEnvVariable[i].envValue;
            //D4100069     continue;
            //D4100069 }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_LOT_ON_PORT_SEQLEN_FOR_EQPINFO_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_LOT_ON_PORT_SEQLEN_FOR_EQPINFO_INQ = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_LOT_ON_PORT_SEQLEN_FOR_EQPINFO_INQ = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_LOT_ON_PORT_SEQLEN_FOR_EQPINFO_INQ);                  //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_Max_Script_Execution) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_Max_Script_Execution = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_Max_Script_Execution = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_Max_Script_Execution);                                //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_MessageQueueNeed_STRING) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_MessageQueueNeed_STRING = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_MessageQueueNeed_STRING = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_MessageQueueNeed_STRING);                             //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_PD_EQP_SEQLEN_FOR_OPELIST_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_PD_EQP_SEQLEN_FOR_OPELIST_INQ = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_PD_EQP_SEQLEN_FOR_OPELIST_INQ = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_PD_EQP_SEQLEN_FOR_OPELIST_INQ);                       //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_PORT_SEQLEN_FOR_EQPINFO_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_PORT_SEQLEN_FOR_EQPINFO_INQ = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_PORT_SEQLEN_FOR_EQPINFO_INQ = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_PORT_SEQLEN_FOR_EQPINFO_INQ);                         //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_RCPPARM_SEQLEN_FOR_OPEHIS_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RCPPARM_SEQLEN_FOR_OPEHIS_INQ = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_RCPPARM_SEQLEN_FOR_OPEHIS_INQ = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_RCPPARM_SEQLEN_FOR_OPEHIS_INQ);                       //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_RTD_Available) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RTD_Available = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_RTD_Available = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_RTD_Available);                                       //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_RTD_HOST_NAME) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RTD_HOST_NAME = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_RTD_HOST_NAME = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_RTD_HOST_NAME);                                       //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_RTD_Health_Rpt_Enforce) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RTD_Health_Rpt_Enforce = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_RTD_Health_Rpt_Enforce = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_RTD_Health_Rpt_Enforce);                              //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_RTD_Health_Rpt_Interval) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RTD_Health_Rpt_Interval = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_RTD_Health_Rpt_Interval = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_RTD_Health_Rpt_Interval);                             //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_RTD_SERVER_NAME) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RTD_SERVER_NAME = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_RTD_SERVER_NAME = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_RTD_SERVER_NAME);                                     //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_SPC_HOST_NAME) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_SPC_HOST_NAME = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_SPC_HOST_NAME = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_SPC_HOST_NAME);                                       //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_SPC_SERVER_NAME) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_SPC_SERVER_NAME = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_SPC_SERVER_NAME = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_SPC_SERVER_NAME);                                     //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_SendToTCS_In_Offline) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_SendToTCS_In_Offline = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_SendToTCS_In_Offline = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_SendToTCS_In_Offline);                                //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_TX_Timeout_CSS) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_TX_Timeout_CSS = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_TX_Timeout_CSS = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_TX_Timeout_CSS);                                      //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_TX_Timeout_RTD) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_TX_Timeout_RTD = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_TX_Timeout_RTD = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_TX_Timeout_RTD);                                      //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_TX_Timeout_SPC) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_TX_Timeout_SPC = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_TX_Timeout_SPC = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_TX_Timeout_SPC);                                      //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_TX_Timeout_TCS) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_TX_Timeout_TCS = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_TX_Timeout_TCS = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_TX_Timeout_TCS);                                      //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_TX_Timeout_XMS) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_TX_Timeout_XMS = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_TX_Timeout_XMS = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_TX_Timeout_XMS);                                      //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_XMS_HOST_NAME) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_XMS_HOST_NAME = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_XMS_HOST_NAME = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_XMS_HOST_NAME);                                       //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_XMS_SERVER_NAME) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_XMS_SERVER_NAME = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_XMS_SERVER_NAME = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_XMS_SERVER_NAME);                                     //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_PD_SEQLEN_FOR_OPELIST_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_PD_SEQLEN_FOR_OPELIST_INQ = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_PD_SEQLEN_FOR_OPELIST_INQ = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_PD_SEQLEN_FOR_OPELIST_INQ);                           //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_APC_SERVER_NAME) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_APC_SERVER_NAME = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_APC_SERVER_NAME = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_APC_SERVER_NAME);                                     //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_APC_HOST_NAME) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_APC_HOST_NAME = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_APC_HOST_NAME = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_APC_HOST_NAME);                                       //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_BindEverytime_APC) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_BindEverytime_APC = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_BindEverytime_APC = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_BindEverytime_APC);                                   //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_RETICLE_SEQLEN_FOR_OPEHIS_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RETICLE_SEQLEN_FOR_OPEHIS_INQ = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_RETICLE_SEQLEN_FOR_OPEHIS_INQ = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_RETICLE_SEQLEN_FOR_OPEHIS_INQ);                       //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, MM_CATALOG_FILE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set MM_CATALOG_FILE = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theMM_CATALOG_FILE = strPptEnvVariable[i].envValue;
                workptr = getenv(MM_CATALOG_FILE);                                        //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_LOCK_TIMEOUT) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_LOCK_TIMEOUT = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_LOCK_TIMEOUT = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_LOCK_TIMEOUT);                                        //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D4100206            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_LOTINFO_BY_SQL) == 0)
//D4100206            {
//D4100206                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_LOTINFO_BY_SQL = ", strPptEnvVariable[i].envValue,i);
//D4100206                //D4100134 theSP_LOTINFO_BY_SQL = strPptEnvVariable[i].envValue;
//D4100206                workptr = getenv(SP_LOTINFO_BY_SQL);                                      //D4100134
//D4100206                CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D4100206                continue;
//D4100206            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_MULTIPLESERVER) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_MULTIPLESERVER = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_MULTIPLESERVER = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_MULTIPLESERVER);                                      //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//Add Start 2001-08-21
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_ACTIONLIST_SEQLEN_FOR_WAFERSORTER_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_ACTIONLIST_SEQLEN_FOR_WAFERSORTER_INQ = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_ACTIONLIST_SEQLEN_FOR_WAFERSORTER_INQ = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_ACTIONLIST_SEQLEN_FOR_WAFERSORTER_INQ);               //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_BANK_SEQLEN_FOR_BANKLIST_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_BANK_SEQLEN_FOR_BANKLIST_INQ = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_BANK_SEQLEN_FOR_BANKLIST_INQ = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_BANK_SEQLEN_FOR_BANKLIST_INQ);                        //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_BIND_RETRY_COUNT_TCS) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_BIND_RETRY_COUNT_TCS = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_BIND_RETRY_COUNT_TCS = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_BIND_RETRY_COUNT_TCS);                                //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_BIND_SLEEP_TIME_TCS) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_BIND_SLEEP_TIME_TCS = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_BIND_SLEEP_TIME_TCS = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_BIND_SLEEP_TIME_TCS);                                 //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DCDEF_SEQLEN_FOR_CDHIS_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DCDEF_SEQLEN_FOR_CDHIS_INQ = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_DCDEF_SEQLEN_FOR_CDHIS_INQ = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_DCDEF_SEQLEN_FOR_CDHIS_INQ);                          //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DCITEM_SEQLEN_FOR_CDHIS_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DCITEM_SEQLEN_FOR_CDHIS_INQ = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_DCITEM_SEQLEN_FOR_CDHIS_INQ = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_DCITEM_SEQLEN_FOR_CDHIS_INQ);                         //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_LOTQTIME_SEQLEN_FOR_QRESTLOT_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_LOTQTIME_SEQLEN_FOR_QRESTLOT_INQ = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_LOTQTIME_SEQLEN_FOR_QRESTLOT_INQ = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_LOTQTIME_SEQLEN_FOR_QRESTLOT_INQ);                    //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_NEXTBANK_SEQLEN_FOR_BANKLIST_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_NEXTBANK_SEQLEN_FOR_BANKLIST_INQ = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_NEXTBANK_SEQLEN_FOR_BANKLIST_INQ = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_NEXTBANK_SEQLEN_FOR_BANKLIST_INQ);                    //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_OPEHIS_SEQLEN_FOR_OPEHIS_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_OPEHIS_SEQLEN_FOR_OPEHIS_INQ = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_OPEHIS_SEQLEN_FOR_OPEHIS_INQ = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_OPEHIS_SEQLEN_FOR_OPEHIS_INQ);                        //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_OPEHIS_SEQLEN_FOR_OPEHIS_INQ_WITH_PINPOINT) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_OPEHIS_SEQLEN_FOR_OPEHIS_INQ_WITH_PINPOINT = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_OPEHIS_SEQLEN_FOR_OPEHIS_INQ_WITH_PINPOINT = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_OPEHIS_SEQLEN_FOR_OPEHIS_INQ_WITH_PINPOINT);          //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_PORT_CATEGORY_CAPABILITY_LEN) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_PORT_CATEGORY_CAPABILITY_LEN = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_PORT_CATEGORY_CAPABILITY_LEN = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_PORT_CATEGORY_CAPABILITY_LEN);                        //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_PRODUCT_SEQLEN_FOR_PRDLST_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_PRODUCT_SEQLEN_FOR_PRDLST_INQ = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_PRODUCT_SEQLEN_FOR_PRDLST_INQ = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_PRODUCT_SEQLEN_FOR_PRDLST_INQ);                       //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_QRESTLOT_SEQLEN_FOR_QRESTLOT_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_QRESTLOT_SEQLEN_FOR_QRESTLOT_INQ = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_QRESTLOT_SEQLEN_FOR_QRESTLOT_INQ = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_QRESTLOT_SEQLEN_FOR_QRESTLOT_INQ);                    //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_RETICLEPOD_SEQLEN_FOR_RTCLSTK_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RETICLEPOD_SEQLEN_FOR_RTCLSTK_INQ = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_RETICLEPOD_SEQLEN_FOR_RTCLSTK_INQ = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_RETICLEPOD_SEQLEN_FOR_RTCLSTK_INQ);                   //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_RETICLE_SEQLEN_FOR_RTCLSTK_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RETICLE_SEQLEN_FOR_RTCLSTK_INQ = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_RETICLE_SEQLEN_FOR_RTCLSTK_INQ = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_RETICLE_SEQLEN_FOR_RTCLSTK_INQ);                      //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_SRCPRODUCT_SEQLEN_FOR_PRDLST_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_SRCPRODUCT_SEQLEN_FOR_PRDLST_INQ = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_SRCPRODUCT_SEQLEN_FOR_PRDLST_INQ = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_SRCPRODUCT_SEQLEN_FOR_PRDLST_INQ);                    //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
//D4000014 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_TX_Timeout_APC) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_TX_Timeout_APC = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_TX_Timeout_APC = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_TX_Timeout_APC);                                      //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_APC_Available) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_APC_Available = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_APC_Available = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_APC_Available);                                       //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D4000014 add end
//D4000137 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_TCS_SERVER_NAME) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_TCS_SERVER_NAME = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_TCS_SERVER_NAME = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_TCS_SERVER_NAME);                                     //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D4000137 add end
//D4000157 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_CTRLLOT_PRTYCLASS ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_CTRLLOT_PRTYCLASS = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_CTRLLOT_PRTYCLASS = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_CTRLLOT_PRTYCLASS);                                   //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D4000157 add end
//P4000329//D4000172 add start
//P4000329            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_LOT_DELETION_RESERVE_PERIOD) == 0)
//P4000329            {
//P4000329                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_LOT_DELETION_RESERVE_PERIOD = ", strPptEnvVariable[i].envValue,i);
//P4000329                theSP_LOT_DELETION_RESERVE_PERIOD = strPptEnvVariable[i].envValue;
//P4000329                continue;
//P4000329            }
//P4000329//D4000172 add end
//D4000171 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_MM_QUERY_SERVER) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_MM_QUERY_SERVER = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_MM_QUERY_SERVER = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_MM_QUERY_SERVER);                                     //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D4000171 add end
//D4000216 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_LOT_CASSETTE_ON_PORT_CHECK_FLAG) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_LOT_CASSETTE_ON_PORT_CHECK_FLAG = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_LOT_CASSETTE_ON_PORT_CHECK_FLAG= strPptEnvVariable[i].envValue;
                workptr = getenv(SP_LOT_CASSETTE_ON_PORT_CHECK_FLAG);                     //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D4000216 add end
//D4000243 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_LOT_DELETION_RESERVE_PERIOD) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_LOT_DELETION_RESERVE_PERIOD = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_LOT_DELETION_RESERVE_PERIOD = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_LOT_DELETION_RESERVE_PERIOD);                         //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D4000243 add end
//D4100081 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_CASETTE_XFER_HISTORY) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_CASETTE_XFER_HISTORY = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_CASETTE_XFER_HISTORY = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_CASETTE_XFER_HISTORY);                                //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_RETICLEPOD_XFER_HISTORY) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RETICLEPOD_XFER_HISTORY = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_RETICLEPOD_XFER_HISTORY = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_RETICLEPOD_XFER_HISTORY);                             //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_RETICLE_XFER_HISTORY) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RETICLE_XFER_HISTORY = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_RETICLE_XFER_HISTORY = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_RETICLE_XFER_HISTORY);                                //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_FIXTURE_XFER_HISTORY) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_FIXTURE_XFER_HISTORY = ", strPptEnvVariable[i].envValue,i);
                //D4100134 theSP_FIXTURE_XFER_HISTORY = strPptEnvVariable[i].envValue;
                workptr = getenv(SP_FIXTURE_XFER_HISTORY);                                //D4100134
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);                       //D4100134
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D4100081 add end

//D4100134(2) add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, EVENT_IPCKEY_MM) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set EVENT_IPCKEY_MM = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(EVENT_IPCKEY_MM);
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_TRANSACTION_TIMEOUT) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_TRANSACTION_TIMEOUT = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_TRANSACTION_TIMEOUT);
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_TRANSACTION_LOGGING) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_TRANSACTION_LOGGING = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_TRANSACTION_LOGGING);
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_ORBIX_DAEMON_PORT) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_ORBIX_DAEMON_PORT = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_ORBIX_DAEMON_PORT);
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D4100134(2) add end

//D4100113 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_ENTITY_INHIBIT_USE_WILDCARD) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_ENTITY_INHIBIT_USE_WILDCARD = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_ENTITY_INHIBIT_USE_WILDCARD);
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_WILDCARD_CHAR) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_WILDCARD_CHAR = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_WILDCARD_CHAR);
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D4100113 add end

//D4100133 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_BIND_TIMEOUT_TCS) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_BIND_TIMEOUT_TCS = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_BIND_TIMEOUT_TCS);
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D4100133 add end

//Add Start 2001-08-21

            //D4100208 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_ALARMLIST_SEQLEN_FOR_EQP_ALARM_HISTORY_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_ALARMLIST_SEQLEN_FOR_EQP_ALARM_HISTORY_INQ = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_ALARMLIST_SEQLEN_FOR_EQP_ALARM_HISTORY_INQ);
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281

                continue;
            }

            //D4100208 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_ALARMLIST_SEQLEN_DEFAULT_FOR_EQP_ALARM_HISTORY_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_ALARMLIST_SEQLEN_DEFAULT_FOR_EQP_ALARM_HISTORY_INQ = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_ALARMLIST_SEQLEN_DEFAULT_FOR_EQP_ALARM_HISTORY_INQ);
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }

            //D4100208 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_LOTLIST_SEQLEN_FOR_LOT_LIST_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_LOTLIST_SEQLEN_FOR_LOT_LIST_INQ = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_LOTLIST_SEQLEN_FOR_LOT_LIST_INQ);
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }

            //D4100208 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_LOTLIST_SEQLEN_DEFAULT_FOR_LOT_LIST_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_LOTLIST_SEQLEN_DEFAULT_FOR_LOT_LIST_INQ = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_LOTLIST_SEQLEN_DEFAULT_FOR_LOT_LIST_INQ);
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);
                if( atol(strPptEnvVariable[i].envValue) > 0 )                                                                          //D4100281
                {                                                                                                                      //D4100281
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }                                                                                                                      //D4100281
                continue;
            }
            //D4100208 Add End

//D4100237 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_SmartTCS_Available) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_SMARTTCS_AVAILABLE = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_SmartTCS_Available);
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D4100237 Add End

//D410092 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_LOT_SCHDCHANGE_RESERVE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_LOT_SCHDCHANGE_RESERVE = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_LOT_SCHDCHANGE_RESERVE);
                //D4100281 CIMFWStrCpy(workptr,strPptEnvVariable[i].envValue);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );  //D4100281
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D4100292 Add End

//D4200075 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_EBrokerTCS_Available) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_EBROKERTCS_AVAILABLE = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_EBrokerTCS_Available);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D4200075 Add End

//D4200127 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_LOTLIST_MAX_SEQLEN_FOR_LOT_LIST_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_LOTLIST_MAX_SEQLEN_FOR_LOT_LIST_INQ = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_LOTLIST_MAX_SEQLEN_FOR_LOT_LIST_INQ);
                if( atol(strPptEnvVariable[i].envValue) < 100 )
                {
//D9000001                    CIMFWStrnCpy(workptr,"100", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"100", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
//DSN000096227                else if( atol(strPptEnvVariable[i].envValue) >1000 )
//DSN000096227                {
//DSN000096227//D9000001                    CIMFWStrnCpy(workptr,"1000", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
//DSN000096227                    CIMFWStrnCpy(workptr,"1000", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
//DSN000096227                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D4200127 Add End

//D4200245 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DATAVALUE_ASTERISK_SAVEFLAG) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DATAVALUE_ASTERISK_SAVEFLAG = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_DATAVALUE_ASTERISK_SAVEFLAG);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D4200245 Add End

//D4200265 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_ZONETYPE_NEED_FLAG_IN_CASTLIST) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_ZONETYPE_NEED_FLAG_IN_CASTLIST = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_ZONETYPE_NEED_FLAG_IN_CASTLIST);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D4200265 Add End

//D4200273 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_TAKEOUT_XFER_IN_NOTAVAILABLE_STATE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_TAKEOUT_XFER_IN_NOTAVAILABLE_STATE = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_TAKEOUT_XFER_IN_NOTAVAILABLE_STATE);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D4200273 Add End

//D4200293 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_OPEHIS_MAX_SEQLEN_FOR_OPEHIS_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_OPEHIS_MAX_SEQLEN_FOR_OPEHIS_INQ = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_OPEHIS_MAX_SEQLEN_FOR_OPEHIS_INQ);
                if( atol(strPptEnvVariable[i].envValue) < 100 )
                {
//D9000001                    CIMFWStrnCpy(workptr,"100", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"100", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
//DSN000096227                else if( atol(strPptEnvVariable[i].envValue) >1000 )
//DSN000096227                {
//DSN000096227//D9000001                    CIMFWStrnCpy(workptr,"1000", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
//DSN000096227                    CIMFWStrnCpy(workptr,"1000", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
//DSN000096227                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D4200293 Add End

//D4200322 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_CASSETTELIST_SEQLEN_DEFAULT_FOR_CASSETTE_LIST_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_CASSETTELIST_SEQLEN_DEFAULT_FOR_CASSETTE_LIST_INQ = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_CASSETTELIST_SEQLEN_DEFAULT_FOR_CASSETTE_LIST_INQ);
                if ( atol(strPptEnvVariable[i].envValue) < 1 )
                {
//D9000001                    CIMFWStrnCpy(workptr, "500", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr, "500", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                else if ( atol(strPptEnvVariable[i].envValue) > 500 )
                {
//D9000001                    CIMFWStrnCpy(workptr, "500", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr, "500", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_CASSETTELIST_SEQLEN_FOR_CASSETTE_LIST_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_CASSETTELIST_SEQLEN_FOR_CASSETTE_LIST_INQ = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_CASSETTELIST_SEQLEN_FOR_CASSETTE_LIST_INQ);
                if ( atol(strPptEnvVariable[i].envValue) < 1 )
                {
//D9000001                    CIMFWStrnCpy(workptr, "500", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr, "500", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                else if ( atol(strPptEnvVariable[i].envValue) > 500 )
                {
//D9000001                    CIMFWStrnCpy(workptr, "500", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr, "500", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_CASSETTELIST_SEQLEN_MAX_FOR_CASSETTE_LIST_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_CASSETTELIST_SEQLEN_MAX_FOR_CASSETTE_LIST_INQ = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_CASSETTELIST_SEQLEN_MAX_FOR_CASSETTE_LIST_INQ);

                if ( atol(strPptEnvVariable[i].envValue) < 100 )
                {
//D9000001                    CIMFWStrnCpy(workptr, "100", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr, "100", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
//DSN000096227                else if ( atol(strPptEnvVariable[i].envValue) > 1000 )
//DSN000096227                {
//DSN000096227//D9000001                    CIMFWStrnCpy(workptr, "1000", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
//DSN000096227                    CIMFWStrnCpy(workptr, "1000", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
//DSN000096227                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_RETICLELIST_SEQLEN_DEFAULT_FOR_RETICLE_LIST_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RETICLELIST_SEQLEN_DEFAULT_FOR_RETICLE_LIST_INQ = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_RETICLELIST_SEQLEN_DEFAULT_FOR_RETICLE_LIST_INQ);
                if ( atol(strPptEnvVariable[i].envValue) < 1 )
                {
//D9000001                    CIMFWStrnCpy(workptr, "500", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr, "500", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                else if ( atol(strPptEnvVariable[i].envValue) > 500 )
                {
//D9000001                    CIMFWStrnCpy(workptr, "500", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr, "500", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_RETICLELIST_SEQLEN_FOR_RETICLE_LIST_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RETICLELIST_SEQLEN_FOR_RETICLE_LIST_INQ = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_RETICLELIST_SEQLEN_FOR_RETICLE_LIST_INQ);
                if ( atol(strPptEnvVariable[i].envValue) < 1 )
                {
//D9000001                    CIMFWStrnCpy(workptr, "500", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr, "500", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                else if ( atol(strPptEnvVariable[i].envValue) > 500 )
                {
//D9000001                    CIMFWStrnCpy(workptr, "500", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr, "500", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_RETICLELIST_SEQLEN_MAX_FOR_RETICLE_LIST_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RETICLELIST_SEQLEN_MAX_FOR_RETICLE_LIST_INQ = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_RETICLELIST_SEQLEN_MAX_FOR_RETICLE_LIST_INQ);
                if ( atol(strPptEnvVariable[i].envValue) < 100 )
                {
//D9000001                    CIMFWStrnCpy(workptr, "100", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr, "100", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
//DSN000096227                else if ( atol(strPptEnvVariable[i].envValue) > 1000 )
//DSN000096227                {
//DSN000096227//D9000001                    CIMFWStrnCpy(workptr, "1000", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
//DSN000096227                    CIMFWStrnCpy(workptr, "1000", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
//DSN000096227                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_ALARMLIST_SEQLEN_MAX_FOR_EQP_ALARM_HISTORY_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_ALARMLIST_SEQLEN_MAX_FOR_EQP_ALARM_HISTORY_INQ = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_ALARMLIST_SEQLEN_MAX_FOR_EQP_ALARM_HISTORY_INQ);
                if ( atol(strPptEnvVariable[i].envValue) < 100 )
                {
//D9000001                    CIMFWStrnCpy(workptr, "100", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr, "100", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
//DSN000096227                else if ( atol(strPptEnvVariable[i].envValue) > 1000 )
//DSN000096227                {
//DSN000096227//D9000001                    CIMFWStrnCpy(workptr, "1000", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
//DSN000096227                    CIMFWStrnCpy(workptr, "1000", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
//DSN000096227                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D4200322 Add End

//D5000058 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_SCREENLIMITOVER_NOTCALCULATE_FLAG) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_SCREENLIMITOVER_NOTCALCULATE_FLAG = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_SCREENLIMITOVER_NOTCALCULATE_FLAG);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D5000058 Add End

//D5000123 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_PrivilegeCheck_BY_DR_FLAG) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","SP_PrivilegeCheck_BY_DR_FLAG = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_PrivilegeCheck_BY_DR_FLAG);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D5000123 Add End

//D7000026 //D5000154 Add Start
//D7000026             if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_LOTINFO_BY_SQL) == 0)
//D7000026             {
//D7000026                 PPT_METHODTRACE_V3("environmentVariable_Set","SP_LOTINFO_BY_SQL = ", strPptEnvVariable[i].envValue,i);
//D7000026
//D7000026                 workptr = getenv(SP_LOTINFO_BY_SQL);
//D7000026                 CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
//D7000026                 continue;
//D7000026             }
//D7000026 //D5000154 Add End

//D5000194 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_REROUTE_XFER_FLAG) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","SP_REROUTE_XFER_FLAG = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_REROUTE_XFER_FLAG);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D5000194 Add End

//D5000178 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_PROHIBIT_CHARACTER) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","SP_PROHIBIT_CHARACTER = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_PROHIBIT_CHARACTER);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D5000178 Add End

//D5100016 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_ORBIX_DEFAULT_TIMEOUT) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","SP_ORBIX_DEFAULT_TIMEOUT = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_ORBIX_DEFAULT_TIMEOUT);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D5100016 Add End

//D5100138 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_STAYONPORT_WITH_NO_DESTINATION) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","SP_STAYONPORT_WITH_NO_DESTINATION = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv(SP_STAYONPORT_WITH_NO_DESTINATION);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D5100138 Add End

//D5100065 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_SOOR_INHIBIT_CANCEL_BY_ACK ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","SP_SOOR_INHIBIT_CANCEL_BY_ACK = ", strPptEnvVariable[i].envValue,i);

                workptr = getenv( SP_SOOR_INHIBIT_CANCEL_BY_ACK );
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_WSPC_SERVER_NAME) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_WSPC_SERVER_NAME = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_WSPC_SERVER_NAME );
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_WSPC_HOST_NAME) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_WSPC_HOST_NAME = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_WSPC_HOST_NAME);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D5100065 Add End

//D5100232 start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DCS_SERVER_NAME) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DCS_SERVER_NAME = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_DCS_SERVER_NAME);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DCS_HOST_NAME) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DCS_HOST_NAME = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_DCS_HOST_NAME);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_BindEverytime_DCS) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_BindEverytime_DCS = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_BindEverytime_DCS);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_TX_Timeout_DCS) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_TX_Timeout_DCS = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_TX_Timeout_DCS);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DCS_Available) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DCS_Available = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_DCS_Available);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DCS_Ignore_OpeStart_Result) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DCS_Ignore_OpeStart_Result = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_DCS_Ignore_OpeStart_Result);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DCS_Ignore_OpeStartCancel_Result) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DCS_Ignore_OpeStartCancel_Result = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_DCS_Ignore_OpeStartCancel_Result);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DCS_Ignore_OpeComp_Result) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DCS_Ignore_OpeComp_Result = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_DCS_Ignore_OpeComp_Result);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D5100232 end

//D51M0000 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_MM_SYSTEM_NAME) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_MM_SYSTEM_NAME = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_MM_SYSTEM_NAME);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_APC_SYSTEM_NAME) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_APC_SYSTEM_NAME = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_APC_SYSTEM_NAME);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_INHIBIT_DURATION) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_INHIBIT_DURATION = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_INHIBIT_DURATION);
//DSN000088570                if ( atol(strPptEnvVariable[i].envValue) < 1  ||
//DSN000088570                     atol(strPptEnvVariable[i].envValue) > 365   )
                if ( atol(strPptEnvVariable[i].envValue) < 1 )                                                                          //DSN88570
                {
//D9000001                    CIMFWStrnCpy(workptr, "10", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr, "10", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_INHIBIT_WHEN_APC_RPARMADJUST_NG) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_INHIBIT_WHEN_APC_RPARMADJUST_NG = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_INHIBIT_WHEN_APC_RPARMADJUST_NG);
                if ( atol(strPptEnvVariable[i].envValue) == 1 )
                {
//D9000001                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_INHIBIT_WHILE_APCIF_DEFINE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_INHIBIT_WHILE_APCIF_DEFINE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_INHIBIT_WHILE_APCIF_DEFINE);
                if ( atol(strPptEnvVariable[i].envValue) == 1 )
                {
//D9000001                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D51M0000 add end
//D6000009 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName,SP_HISTORY_EVENTFIFO_DISTRIBUTE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_HISTORY_EVENTFIFO_DISTRIBUTE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_HISTORY_EVENTFIFO_DISTRIBUTE);
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D6000009 add end
//D6000073 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_APCENTVAL_MAX_COUNT) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_APCENTVAL_MAX_COUNT = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_APCENTVAL_MAX_COUNT);
                if( atol(strPptEnvVariable[i].envValue) > 0 )
                {
//D9000001                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D6000073 add end
//D6000215 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_INHIBIT_MAX_SEQLEN_FOR_INHIBIT_LIST_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_INHIBIT_MAX_SEQLEN_FOR_INHIBIT_LIST_INQ= ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_INHIBIT_MAX_SEQLEN_FOR_INHIBIT_LIST_INQ);
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    CORBA::Long workVal = 0;
//D9000001                    workVal = atol( strPptEnvVariable[i].envValue );
                    workVal = atoi( strPptEnvVariable[i].envValue );    //D9000001
//DSN000096227                    if ( workVal > 9999 )
//DSN000096227                    {
//DSN000096227//D9000001                        CIMFWStrnCpy(workptr, "9999", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
//DSN000096227                        CIMFWStrnCpy(workptr, "9999", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
//DSN000096227                    }
//DSN000096227                    else if (workVal < 1 )
                    if (workVal < 1 ) //DSN000096227
                    {
//D9000001                        CIMFWStrnCpy(workptr, "100", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy(workptr, "100", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                    else
                    {
//D9000001                        CIMFWStrnCpy( workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy( workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,"2000", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"2000", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D6000215 add end

//D6000222 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_RCOK_NoData_For_ListInq) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RCOK_NoData_For_ListInq = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_RCOK_NoData_For_ListInq);
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    char tmpBuf[128];
                    CORBA::Long workVal = 0;
//D9000001                    workVal = atol( strPptEnvVariable[i].envValue );
                    workVal = atoi( strPptEnvVariable[i].envValue );//D9000001
                    if ( 1 != workVal && 0 != workVal )
                    {
                        sprintf(tmpBuf, "0");
                    }
                    else
                    {
                        sprintf(tmpBuf, "%d", workVal);
                    }
//D9000001                    CIMFWStrnCpy(workptr, tmpBuf, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr, tmpBuf, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D6000222 add end

//D6000275, D6000313, D6000316 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_CheckExistenceFlag) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_CheckExistenceFlag = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_CheckExistenceFlag);
                if ( CIMFWStrCmp(strPptEnvVariable[i].envValue, "0" ) == 0 )
                {
//D9000001                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D6000275, D6000313, D6000316 add end

//D6000275 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_APCHostName_ForGenIOR) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_APCHostName_ForGenIOR = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_APCHostName_ForGenIOR );
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_APCServerName_ForGenIOR) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_APCServerName_ForGenIOR = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_APCServerName_ForGenIOR );
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_APCMarkerName_ForGenIOR) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_APCMarkerName_ForGenIOR = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_APCMarkerName_ForGenIOR );
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_APCPortNo_ForGenIOR) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_APCPortNo_ForGenIOR = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_APCPortNo_ForGenIOR );
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D6000275 add end

//D6000313 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_XMSHostName_ForGenIOR) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_XMSHostName_ForGenIOR = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_XMSHostName_ForGenIOR );
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_XMSServerName_ForGenIOR) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_XMSServerName_ForGenIOR = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_XMSServerName_ForGenIOR );
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_XMSMarkerName_ForGenIOR) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_XMSMarkerName_ForGenIOR = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_XMSMarkerName_ForGenIOR );
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_XMSPortNo_ForGenIOR) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_XMSPortNo_ForGenIOR = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_XMSPortNo_ForGenIOR );
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D6000313 add end

//D6000316 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DCSHostName_ForGenIOR) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DCSHostName_ForGenIOR = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_DCSHostName_ForGenIOR );
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DCSServerName_ForGenIOR) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DCSServerName_ForGenIOR = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_DCSServerName_ForGenIOR );
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DCSMarkerName_ForGenIOR) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DCSMarkerName_ForGenIOR = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_DCSMarkerName_ForGenIOR );
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DCSPortNo_ForGenIOR) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DCSPortNo_ForGenIOR = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_DCSPortNo_ForGenIOR );
//D9000001                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                continue;
            }
//D6000316 add end

//D6000379 add start
            if(CIMFWStrCmp( strPptEnvVariable[i].envName, SP_BKUP_COUNT_SEQLEN_INQ ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_BKUP_COUNT_SEQLEN_INQ = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_BKUP_COUNT_SEQLEN_INQ);
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    CORBA::Long workVal = 0;
//D9000001                    workVal = atol( strPptEnvVariable[i].envValue );
                    workVal = atoi( strPptEnvVariable[i].envValue );//D9000001
                    if ( workVal > 100 )
                    {
//D9000001                        CIMFWStrnCpy(workptr, "100", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy(workptr, "100", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                    else if (workVal < 1 )
                    {
//D9000001                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                    else
                    {
//D9000001                        CIMFWStrnCpy( workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy( workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D6000379 add end

//D6000398 add start
            if(CIMFWStrCmp( strPptEnvVariable[i].envName, SP_DCDEFDCSPEC_RELATION_CHECK_FLAG ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DCDEFDCSPEC_RELATION_CHECK_FLAG = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_DCDEFDCSPEC_RELATION_CHECK_FLAG);
                if ( CIMFWStrCmp(strPptEnvVariable[i].envValue, "1" ) == 0 )
                {
//D9000001                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D6000398 add end

//D6000389 add start
            if(CIMFWStrCmp( strPptEnvVariable[i].envName, SP_LOTFAMILY_DUPLICATION_ALLOWABLE_FLAG) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_LOTFAMILY_DUPLICATION_ALLOWABLE_FLAG = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_LOTFAMILY_DUPLICATION_ALLOWABLE_FLAG);
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    CORBA::Long workVal = 0;
//D9000001                    workVal = atol( strPptEnvVariable[i].envValue );
                    workVal = atoi( strPptEnvVariable[i].envValue );//D9000001
                    if ( workVal == 1 )
                    {
//D9000001                        CIMFWStrnCpy( workptr, "1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy( workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                    else
                    {
//D9000001                        CIMFWStrnCpy( workptr, "0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy( workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                }
                else
                {
//D9000001                    CIMFWStrnCpy( workptr,"0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy( workptr,"0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D6000389 add end

//D7000006 add start
            if(CIMFWStrCmp( strPptEnvVariable[i].envName, SP_CONTROLJOB_STATUS_CHANGE_HISTORY_MASK ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_CONTROLJOB_STATUS_CHANGE_HISTORY_MASK = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_CONTROLJOB_STATUS_CHANGE_HISTORY_MASK);
                CORBA::ULong workVal = 0;
                CORBA::ULong counter = 0;
                workVal = CIMFWStrLen( strPptEnvVariable[i].envValue);
                if ( workVal == 5 )
                {
                    for(counter = 0; counter <workVal; counter++ )
                    {
//D9000001                        if( strPptEnvVariable[i].envValue[counter] == '0' || strPptEnvVariable[i].envValue[counter] == '1')
                        if( ((const char*)strPptEnvVariable[i].envValue)[counter] == '0' || ((const char*)strPptEnvVariable[i].envValue)[counter] == '1')//D9000001
                        {
                            continue;
                        }
                        else
                        {
                            break;
                        }
                    }
                    if(counter == workVal)
                    {
//D9000001                        CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                    else
                    {
//D9000001                        CIMFWStrnCpy(workptr,"00000", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy(workptr,"00000", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,"00000", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"00000", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D7000006 add end

//D7000182 add start
            if(CIMFWStrCmp( strPptEnvVariable[i].envName, SP_Rollback_Notify_To_APC) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_ROLLBACK_NOTIFY_TO_APC = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_Rollback_Notify_To_APC);
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    CORBA::Long workVal = 0;
//D9000001                    workVal = atol( strPptEnvVariable[i].envValue );
                    workVal = atoi( strPptEnvVariable[i].envValue );//D9000001
                    if ( workVal == 1 )
                    {
//D9000001                        CIMFWStrnCpy( workptr, "1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy( workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                    else
                    {
//D9000001                        CIMFWStrnCpy( workptr, "0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy( workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                }
                else
                {
//D9000001                    CIMFWStrnCpy( workptr,"0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy( workptr,"0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D7000182 add end

//D7000183 add start
            if(CIMFWStrCmp( strPptEnvVariable[i].envName, SP_MINIMUM_BATCH_CONDITION_APPLY_FLAG_FOR_DELIVERY ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_MINIMUM_BATCH_CONDITION_APPLY_FLAG_FOR_DELIVERY = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_MINIMUM_BATCH_CONDITION_APPLY_FLAG_FOR_DELIVERY);
                if ( CIMFWStrCmp(strPptEnvVariable[i].envValue, "1" ) == 0 )
                {
//D9000001                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D7000183 add end

//D7000219 add start
            if(CIMFWStrCmp( strPptEnvVariable[i].envName, SP_CASSETTE_RELATION_CHECK_FOR_HOLD ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_CASSETTE_RELATION_CHECK_FOR_HOLD = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_CASSETTE_RELATION_CHECK_FOR_HOLD);
                if ( CIMFWStrCmp(strPptEnvVariable[i].envValue, "0" ) == 0 )
                {
//D9000001                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D7000219 add end

//P7000243 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DR_RETRY_COUNT) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DR_RETRY_COUNT = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_DR_RETRY_COUNT );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    CORBA::Long workVal = 0;
//D9000001                    workVal = atol( strPptEnvVariable[i].envValue );
                    workVal = atoi( strPptEnvVariable[i].envValue );//D9000001
                    if ( workVal > 100 )
                    {
//D9000001                        CIMFWStrnCpy(workptr, "100", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy(workptr, "100", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                    else if (workVal < 1 )
                    {
//D9000001                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                    else
                    {
//D9000001                        CIMFWStrnCpy( workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy( workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DR_RETRY_INTERVAL) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DR_RETRY_INTERVAL = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_DR_RETRY_INTERVAL );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    CORBA::Long workVal = 0;
//D9000001                    workVal = atol( strPptEnvVariable[i].envValue );
                    workVal = atoi( strPptEnvVariable[i].envValue );//D9000001
                    if ( workVal > 60 )
                    {
//D9000001                        CIMFWStrnCpy(workptr, "60", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy(workptr, "60", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                    else if (workVal < 1 )
                    {
//D9000001                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                    else
                    {
//D9000001                        CIMFWStrnCpy( workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy( workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//P7000243 add end
//D7000371 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_SHORTEST_QTIME_USE_FLAG) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_SHORTEST_QTIME_USE_FLAG = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_SHORTEST_QTIME_USE_FLAG );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
//D9000001                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                    else if( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
//D9000001                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                    else
                    {
//D9000001                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D7000371 add end
//D8000024 add start
            if(CIMFWStrCmp( strPptEnvVariable[i].envName, SP_FPC_Adaptation_Flag) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_FPC_ADAPTATION_FLAG = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_FPC_Adaptation_Flag);
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    CORBA::Long workVal = 0;
//D9000001                    workVal = atol( strPptEnvVariable[i].envValue );
                    workVal = atoi( strPptEnvVariable[i].envValue );//D9000001
                    if ( workVal == 1 )
                    {
//D9000001                        CIMFWStrnCpy( workptr, "1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy( workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                    else
                    {
//D9000001                        CIMFWStrnCpy( workptr, "0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy( workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                }
                else
                {
//D9000001                    CIMFWStrnCpy( workptr,"0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy( workptr,"0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_FPC_ContinuousSkipLimit) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_FPC_CONTINUOUS_SKIP_LIMIT = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_FPC_ContinuousSkipLimit );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    CORBA::Long workVal = 0;
//D9000001                    workVal = atol( strPptEnvVariable[i].envValue );
                    workVal = atoi( strPptEnvVariable[i].envValue );//D9000001
                    if ( workVal > 9999 )
                    {
//D9000001                        CIMFWStrnCpy(workptr, "9999", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy(workptr, "9999", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                    else if (workVal < 1 )
                    {
//D9000001                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                    else
                    {
//D9000001                        CIMFWStrnCpy( workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy( workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,"3", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"3", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D8000024 add end
            //D8000084 Add Start
            if( CIMFWStrCmp( strPptEnvVariable[i].envName, SP_CARRIER_BASEINFO_UPDATE_CHECK ) == 0 )
            {
                PPT_METHODTRACE_V3("", "Set SP_CARRIER_BASEINFO_UPDATE_CHECK = ", strPptEnvVariable[i].envValue, i);

                workptr = getenv( SP_CARRIER_BASEINFO_UPDATE_CHECK );

                if( CIMFWStrCmp( strPptEnvVariable[i].envValue, SP_CheckFlag_On ) == 0 )
                {
//D9000001                    CIMFWStrnCpy( workptr, SP_CheckFlag_On, SP_ENV_MAX_LEN - strlen( strPptEnvVariable[i].envName ) - 2 );
                    CIMFWStrnCpy( workptr, SP_CheckFlag_On, SP_ENV_MAX_LEN - CIMFWStrLen( strPptEnvVariable[i].envName ) - 2 );  //D9000001
                }
                else
                {
//D9000001                    CIMFWStrnCpy( workptr, SP_CheckFlag_Off, SP_ENV_MAX_LEN - strlen( strPptEnvVariable[i].envName ) - 2 );
                    CIMFWStrnCpy( workptr, SP_CheckFlag_Off, SP_ENV_MAX_LEN - CIMFWStrLen( strPptEnvVariable[i].envName ) - 2 );  //D9000001
                }
                continue;
            }

            if( CIMFWStrCmp( strPptEnvVariable[i].envName, SP_RETICLEPOD_BASEINFO_UPDATE_CHECK ) == 0 )
            {
                PPT_METHODTRACE_V3("", "Set SP_RETICLEPOD_BASEINFO_UPDATE_CHECK = ", strPptEnvVariable[i].envValue, i);

                workptr = getenv( SP_RETICLEPOD_BASEINFO_UPDATE_CHECK );

                if( CIMFWStrCmp( strPptEnvVariable[i].envValue, SP_CheckFlag_On ) == 0 )
                {
//D9000001                    CIMFWStrnCpy( workptr, SP_CheckFlag_On, SP_ENV_MAX_LEN - strlen( strPptEnvVariable[i].envName ) - 2 );
                    CIMFWStrnCpy( workptr, SP_CheckFlag_On, SP_ENV_MAX_LEN - CIMFWStrLen( strPptEnvVariable[i].envName ) - 2 );  //D9000001
                }
                else
                {
//D9000001                    CIMFWStrnCpy( workptr, SP_CheckFlag_Off, SP_ENV_MAX_LEN - strlen( strPptEnvVariable[i].envName ) - 2 );
                    CIMFWStrnCpy( workptr, SP_CheckFlag_Off, SP_ENV_MAX_LEN - CIMFWStrLen( strPptEnvVariable[i].envName ) - 2 );  //D9000001
                }
                continue;
            }
            //D8000084 Add End

//P8000082 add start
            if(CIMFWStrCmp( strPptEnvVariable[i].envName, SP_MONITOR_WAIT_HOLD_NEW_LOGIC ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_MONITOR_WAIT_HOLD_NEW_LOGIC = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_MONITOR_WAIT_HOLD_NEW_LOGIC);
                if ( CIMFWStrCmp(strPptEnvVariable[i].envValue, "1" ) == 0 )
                {
//D9000001                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//P8000082 add end

//D8000184 add start
            if(CIMFWStrCmp( strPptEnvVariable[i].envName, SP_EQP_STATUS_TRANSITION_LIMITATION ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_EQP_STATUS_TRANSITION_LIMITATION = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_EQP_STATUS_TRANSITION_LIMITATION);
                if ( CIMFWStrCmp(strPptEnvVariable[i].envValue, "1" ) == 0 )
                {
//D9000001                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 )
                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D8000184 add end
//D8000186 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_LOT_DELETION_CHECK_EVENT_FLAG) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_LOT_DELETION_CHECK_EVENT_FLAG = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_LOT_DELETION_CHECK_EVENT_FLAG );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
//D9000001                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                    else if( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
//D9000001                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                    else
                    {
//D9000001                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D8000186 add end
//D8000204 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_ENTITY_INHIBIT_THRESHOLD_COUNT) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_ENTITY_INHIBIT_THRESHOLD_COUNT = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_ENTITY_INHIBIT_THRESHOLD_COUNT );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0 )
                {
                    CORBA::Long workVal = 0;
//D9000001                    workVal = atol( strPptEnvVariable[i].envValue );
                    workVal = atoi( strPptEnvVariable[i].envValue );//D9000001
                    if ( workVal <= 0 )
                    {
//D9000001                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                    else
                    {
//D9000001                        CIMFWStrnCpy( workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                        CIMFWStrnCpy( workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                    }
                }
                else
                {
//D9000001                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
                }
                continue;
            }
//D8000204 add end
//D9000003 delete start
////D8000207 add start
//            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_OPER_START_WAFER_FLAG_CONTROL) == 0)
//            {
//                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_OPER_START_WAFER_FLAG_CONTROL = ", strPptEnvVariable[i].envValue,i);
//                workptr = getenv( SP_OPER_START_WAFER_FLAG_CONTROL );
//                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
//                {
//                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
//                    {
////D9000001                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
//                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
//                    }
//                    else if( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
//                    {
////D9000001                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
//                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
//                    }
//                    else
//                    {
////D9000001                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
//                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
//                    }
//                }
//                else
//                {
////D9000001                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
//                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );  //D9000001
//                }
//                continue;
//            }
////D8000207 add end
//D9000003 delete end
//D9000053 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_EQP_MODE_CHANGE_OFFLINE_TO_ONLINE_POSSIBLE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_EQP_MODE_CHANGE_OFFLINE_TO_ONLINE_POSSIBLE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_EQP_MODE_CHANGE_OFFLINE_TO_ONLINE_POSSIBLE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0 )
                {
                    CORBA::Long workVal = 0;
                    workVal = atoi( strPptEnvVariable[i].envValue );
                    if ( workVal == 1 )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//D9000053 add end
//D9000084 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_ARMS_FUNC_ENABLED) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_ARMS_FUNC_ENABLED = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_ARMS_FUNC_ENABLED );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0 )
                {
                    CORBA::Long workVal = 0;
                    workVal = atoi( strPptEnvVariable[i].envValue );
                    if ( workVal == 1 )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_RSP_ON_PORT_CHECK_FLAG) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RSP_ON_PORT_CHECK_FLAG = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_RSP_ON_PORT_CHECK_FLAG );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0 )
                {
                    CORBA::Long workVal = 0;
                    workVal = atoi( strPptEnvVariable[i].envValue );
                    if ( workVal == 0 )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_RXM_SERVER_NAME) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set RXM_SERVER_NAME = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_RXM_SERVER_NAME );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0 )
                {
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_RXM_HOST_NAME) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RXM_HOST_NAME = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_RXM_HOST_NAME );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0 )
                {
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_RXMSHostName_ForGenIOR ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RXMSHostName_ForGenIOR = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_RXMSHostName_ForGenIOR );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0 )
                {
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_RXMSServerName_ForGenIOR ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RXMSServerName_ForGenIOR = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_RXMSServerName_ForGenIOR );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0 )
                {
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_RXMSMarkerName_ForGenIOR) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RXMSMarkerName_ForGenIOR = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_RXMSMarkerName_ForGenIOR );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0 )
                {
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_RXMSPortNo_ForGenIOR ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RXMSPortNo_ForGenIOR = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_RXMSPortNo_ForGenIOR );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0 )
                {
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_BindEverytime_RXM ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_BindEverytime_RXM = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_BindEverytime_RXM );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0 )
                {
                    CORBA::Long workVal = 0;
                    workVal = atoi( strPptEnvVariable[i].envValue );
                    if ( workVal == 1 )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_TX_Timeout_RXM) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_TX_Timeout_RXM = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_TX_Timeout_RXM );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0 )
                {
                    CORBA::Long workVal = 0;
                    workVal = atoi( strPptEnvVariable[i].envValue );
                    if ( workVal < 1 )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//D9000084 add end
//D9000079 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_FlowBatch_Cleared_By_OperStart) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_FlowBatch_Cleared_By_OperStart = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_FlowBatch_Cleared_By_OperStart );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_FlowBatch_Cleared_By_OperCancel) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_FlowBatch_Cleared_By_OperCancel = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_FlowBatch_Cleared_By_OperCancel );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//D9000079 add end
//D9000056 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_LOCK_HOLD_USE_FLAG) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_LOCK_HOLD_USE_FLAG = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_LOCK_HOLD_USE_FLAG );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0 )
                {
                    CORBA::Long workVal = 0;
                    workVal = atoi( strPptEnvVariable[i].envValue );
                    if ( workVal == 0 )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else if ( workVal == -1 )
                    {
                        CIMFWStrnCpy(workptr, "-1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr,"1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_POSTPROC_FLAG_USE_FLAG) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_POSTPROC_FLAG_USE_FLAG = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_POSTPROC_FLAG_USE_FLAG );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0 )
                {
                    CORBA::Long workVal = 0;
                    workVal = atoi( strPptEnvVariable[i].envValue );
                    if ( workVal == 1 )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr,"0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//D9000056 add end
//P9000222 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_SPLIT_LOT_REQUEUE_FLAG) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","SP_SPLIT_LOT_REQUEUE_FLAG = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_SPLIT_LOT_REQUEUE_FLAG);
                if ( CIMFWStrLen( strPptEnvVariable[i].envValue ) > 0 )
                {
                    CORBA::Long workVal = 0;
                    workVal = atoi( strPptEnvVariable[i].envValue );
                    if ( workVal == 0 )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//P9000222 add end
//D9000175 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DELIVERY_TAKE_OUTIN_ENABLE_FLAG) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DELIVERY_TAKE_OUTIN_ENABLE_FLAG = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_DELIVERY_TAKE_OUTIN_ENABLE_FLAG );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//D9000175 add end

//DSIV00000099 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_SLM_SRC_CAST_PRIORITY) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_SLM_SRC_CAST_PRIORITY = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_SLM_SRC_CAST_PRIORITY );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSIV00000099 add end
//D9000246 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_FRLOTPO_MAINTENANCE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_FRLOTPO_MAINTENANCE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_FRLOTPO_MAINTENANCE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_FRLOTPO_CHECK_FOR_DELETE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_FRLOTPO_CHECK_FOR_DELETE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_FRLOTPO_CHECK_FOR_DELETE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_CHECK_FOR_DELETE_STAGE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_CHECK_FOR_DELETE_STAGE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_CHECK_FOR_DELETE_STAGE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_CHECK_FOR_DELETE_SCRIPT) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_CHECK_FOR_DELETE_SCRIPT = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_CHECK_FOR_DELETE_SCRIPT );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_CHECK_FOR_DELETE_DCDEF) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_CHECK_FOR_DELETE_DCDEF = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_CHECK_FOR_DELETE_DCDEF );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_CHECK_FOR_DELETE_DCSPEC) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_CHECK_FOR_DELETE_DCSPEC = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_CHECK_FOR_DELETE_DCSPEC );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_CHECK_FOR_DELETE_STORAGEMACHINE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_CHECK_FOR_DELETE_STORAGEMACHINE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_CHECK_FOR_DELETE_STORAGEMACHINE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_CHECK_FOR_DELETE_LOGICALRECIPE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_CHECK_FOR_DELETE_LOGICALRECIPE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_CHECK_FOR_DELETE_LOGICALRECIPE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_CHECK_FOR_DELETE_MACHINERECIPE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_CHECK_FOR_DELETE_MACHINERECIPE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_CHECK_FOR_DELETE_MACHINERECIPE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//D9000246 add end
//DSIV00000201 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_POSTPROC_FOR_LOT_FLAG) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_POSTPROC_FOR_LOT_FLAG = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_POSTPROC_FOR_LOT_FLAG );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
//DSN000043340 Add Start
                    else if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "-1" ) )
                    {
                        CIMFWStrnCpy(workptr, "-1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
//DSN000043340 Add End
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_ExternalPostProc_UseFlag) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_ExternalPostProc_UseFlag = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_ExternalPostProc_UseFlag );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_ExternalPostProc_UserGrp) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_ExternalPostProc_UserGrp = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_ExternalPostProc_UserGrp );
//PSIV00000455                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0 )
//PSIV00000455                {
                    CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
//PSIV00000455                }
                continue;
            }
//DSIV00000201 add end
//DSIV00000220 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_LOT_STBCANCEL) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_LOT_STBCANCEL = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_LOT_STBCANCEL );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_LOT_PREPARECANCEL) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_LOT_PREPARECANCEL = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_LOT_PREPARECANCEL );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSIV00000220 add end
//DSIV00000286 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_USE_CDR_FOR_AUTO3DISPATCH) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_USE_CDR_FOR_AUTO3DISPATCH = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_USE_CDR_FOR_AUTO3DISPATCH );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSIV00000286 add end
//DSIV00001365 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_WSPC_LINK_URL) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_WSPC_LINK_URL = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_WSPC_LINK_URL);
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                continue;
            }
//DSIV00001365 add end
//DSIV00001441 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_SCRIPTPARAMETER_CHANGE_EVENT) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_SCRIPTPARAMETER_CHANGE_EVENT = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_SCRIPTPARAMETER_CHANGE_EVENT );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSIV00001441 add end
//DSIV00001021 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_CORRES_DEFAULT_MODE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_CORRES_DEFAULT_MODE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_CORRES_DEFAULT_MODE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSIV00001021 add end

//DSIV00001471 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DC_DATA_CHECK_LEVEL) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DC_DATA_CHECK_LEVEL = ", strPptEnvVariable[i].envValue, i);
                workptr = getenv( SP_DC_DATA_CHECK_LEVEL );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "2" ) )
                    {
                        CIMFWStrnCpy(workptr, "2", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DC_DATA_CHECK_PHASE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DC_DATA_CHECK_PHASE = ", strPptEnvVariable[i].envValue, i);
                workptr = getenv( SP_DC_DATA_CHECK_PHASE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSIV00001471 add end

//DSIV00001443 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_ENTITY_INHIBIT_SEARCH_CONDITION) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_ENTITY_INHIBIT_SEARCH_CONDITION = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_ENTITY_INHIBIT_SEARCH_CONDITION );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSIV00001443 add end
//DSIV00001481 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_USE_DB_TIMESTAMP) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_USE_DB_TIMESTAMP = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_USE_DB_TIMESTAMP );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
//PSIV00002506                     if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
//PSIV00002506                     {
//PSIV00002506                         CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
//PSIV00002506                     }
//PSIV00002506                     else
//PSIV00002506                     {
//PSIV00002506                         CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
//PSIV00002506                     }
//PSIV00002506 Add Start
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
//PSIV00002506 Add End
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSIV00001481 add end
//DSIV00002162 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_OWNER_CHANGE_MAX_COMMIT_COUNT) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_OWNER_CHANGE_MAX_COMMIT_COUNT = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_OWNER_CHANGE_MAX_COMMIT_COUNT );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    CORBA::Long workVal = 0;
                    workVal = atoi( strPptEnvVariable[i].envValue );
                    if ( workVal <= 0 )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy( workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSIV00002162 add end
//PSN000090028 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_OWNER_CHANGE_DELETE_DUPLICATE_RECORD) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_OWNER_CHANGE_DELETE_DUPLICATE_RECORD = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_OWNER_CHANGE_DELETE_DUPLICATE_RECORD );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//PSN000090028 add end
//DSIV00001788 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_CASSETTE_LOAD_SEQUENCE_CONDITION) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_CASSETTE_LOAD_SEQUENCE_CONDITION = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_CASSETTE_LOAD_SEQUENCE_CONDITION );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSIV00001788 add end

//DSIV00002458 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_EQPSTAT_BACKUP) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_EQPSTAT_BACKUP = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_EQPSTAT_BACKUP );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "0"
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSIV00002458 add end

//DSIV00002326 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DURABLEHIS_MAX_SEQLEN_FOR_DURABLEHIS_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DURABLEHIS_MAX_SEQLEN_FOR_DURABLEHIS_INQ = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_DURABLEHIS_MAX_SEQLEN_FOR_DURABLEHIS_INQ );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    CORBA::Long workVal = 0;
                    workVal = atoi( strPptEnvVariable[i].envValue );
                    if ( workVal == 0 && ((const char*)strPptEnvVariable[i].envValue)[0] != '0' )
                    {
                        CIMFWStrnCpy(workptr, "1000", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
//DSN000096227                    else if ( workVal > 1000 )
//DSN000096227                    {
//DSN000096227                        CIMFWStrnCpy(workptr, "1000", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
//DSN000096227                    }
                    else if ( workVal < 100 )
                    {
                        CIMFWStrnCpy(workptr, "100", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "1000"
                {
                    CIMFWStrnCpy(workptr, "1000", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_EQUIPMENTHIS_MAX_SEQLEN_FOR_EQUIPMENTHIS_INQ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_EQUIPMENTHIS_MAX_SEQLEN_FOR_EQUIPMENTHIS_INQ = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_EQUIPMENTHIS_MAX_SEQLEN_FOR_EQUIPMENTHIS_INQ );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    CORBA::Long workVal = 0;
                    workVal = atoi( strPptEnvVariable[i].envValue );
                    if ( workVal == 0 && ((const char*)strPptEnvVariable[i].envValue)[0] != '0' )
                    {
                        CIMFWStrnCpy(workptr, "1000", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
//DSN000096227                    else if ( workVal > 1000 )
//DSN000096227                    {
//DSN000096227                        CIMFWStrnCpy(workptr, "1000", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
//DSN000096227                    }
                    else if ( workVal < 100 )
                    {
                        CIMFWStrnCpy(workptr, "100", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "1000"
                {
                    CIMFWStrnCpy(workptr, "1000", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSIV00002326 add end

//DSIV00002270 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_POMAINT_EVENT_CREATE_TYPE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_POMAINT_EVENT_CREATE_TYPE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_POMAINT_EVENT_CREATE_TYPE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    CORBA::Long workVal = 0;
                    workVal = atoi( strPptEnvVariable[i].envValue );
                    if ( workVal != SP_POMaintEventCreateType_Disabled &&
                         workVal != SP_POMaintEventCreateType_ActiveLotEnabled &&
                         workVal != SP_POMaintEventCreateType_InactiveLotEnabled &&
                         workVal != SP_POMaintEventCreateType_Enabled )
                    {
                        workVal = SP_POMaintEventCreateType_Disabled;
                    }
                    char tmpBuf[30];
                    sprintf( tmpBuf, "%ld", workVal );
                    CIMFWStrnCpy(workptr, tmpBuf, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                else // Set Default SP_POMaintEventCreateType_Disabled
                {
                    char tmpBuf[30];
                    sprintf( tmpBuf, "%ld", SP_POMaintEventCreateType_Disabled );
                    CIMFWStrnCpy(workptr, tmpBuf, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSIV00002270 add end

//PSIV00003221 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_BRANCH_RETURN_ACTIVE_MODULE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_BRANCH_RETURN_ACTIVE_MODULE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_BRANCH_RETURN_ACTIVE_MODULE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//PSIV00003221 add end

//DSN000015229 Add Start
            //SP_DCS_PJCTRL_AVAILABLE
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DCS_PJCTRL_AVAILABLE) == 0)
            {
                PPT_METHODTRACE_V3("","Set SP_DCS_PJCTRL_AVAILABLE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_DCS_PJCTRL_AVAILABLE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            //SP_DCS_IGNORE_PJRPT_RESULT
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DCS_IGNORE_PJRPT_RESULT) == 0)
            {
                PPT_METHODTRACE_V3("","Set SP_DCS_IGNORE_PJRPT_RESULT = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_DCS_IGNORE_PJRPT_RESULT );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            //SP_PJCTRL_FUNC_ENABLED
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_PJCTRL_FUNC_ENABLED) == 0)
            {
                PPT_METHODTRACE_V3("","Set SP_PJCTRL_FUNC_ENABLED = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_PJCTRL_FUNC_ENABLED );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//PSN000035912            //SP_PROCESSHIS_MAX_SEQLEN_FOR_PROCESSHIS_INQ
//PSN000035912            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_PROCESSHIS_MAX_SEQLEN_FOR_PROCESSHIS_INQ) == 0)
//PSN000035912            {
//PSN000035912                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_PROCESSHIS_MAX_SEQLEN_FOR_PROCESSHIS_INQ = ", strPptEnvVariable[i].envValue,i);
//PSN000035912                workptr = getenv( SP_PROCESSHIS_MAX_SEQLEN_FOR_PROCESSHIS_INQ );
//PSN000035912                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
//PSN000035912                {
//PSN000035912                    CORBA::Long workVal = 0;
//PSN000035912                    workVal = atoi( strPptEnvVariable[i].envValue );
//PSN000035912                    if ( workVal == 0 && ((const char*)strPptEnvVariable[i].envValue)[0] != '0' )
//PSN000035912                    {
//PSN000035912                        CIMFWStrnCpy(workptr, "1000", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
//PSN000035912                    }
//PSN000035912                    else if ( workVal > 1000 )
//PSN000035912                    {
//PSN000035912                        CIMFWStrnCpy(workptr, "1000", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
//PSN000035912                    }
//PSN000035912                    else if ( workVal < 100 )
//PSN000035912                    {
//PSN000035912                        CIMFWStrnCpy(workptr, "100", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
//PSN000035912                    }
//PSN000035912                    else
//PSN000035912                    {
//PSN000035912                        CIMFWStrnCpy(workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
//PSN000035912                    }
//PSN000035912                }
//PSN000035912                else // Set Default "1000"
//PSN000035912                {
//PSN000035912                    CIMFWStrnCpy(workptr, "1000", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
//PSN000035912                }
//PSN000035912                continue;
//PSN000035912            }
//DSN000015229 Add End
//DSN000022151 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_KEEP_QTIME_ON_SCHCHANGE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_KEEP_QTIME_ON_SCHCHANGE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_KEEP_QTIME_ON_SCHCHANGE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000022151 add end
//DSN000033655 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_QTIMEINFO_MERGE_RULE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_QTIMEINFO_MERGE_RULE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_QTIMEINFO_MERGE_RULE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "2" ) )
                    {
                        CIMFWStrnCpy(workptr, "2", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000033655 add end

//DSN000041192 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_LAGTIMEINFO_MERGE_RULE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_LAGTIMEINFO_MERGE_RULE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_LAGTIMEINFO_MERGE_RULE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000041192 Add End

//DSN000041621 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_EQP_UDATA_MODE) == 0)
            {
                PPT_METHODTRACE_V3("","Set SP_EQP_UDATA_MODE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_EQP_UDATA_MODE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "-1" ) )
                    {
                        CIMFWStrnCpy(workptr, "-1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "0"
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000041621 add end

//DSN000041626 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_CTRLJOBID_GEN_BY_DISP) == 0)
            {
                PPT_METHODTRACE_V3("","Set SP_CTRLJOBID_GEN_BY_DISP = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_CTRLJOBID_GEN_BY_DISP );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "0"
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000041626 add end

//DSN000041636 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_LAST_USED_RECIPE_UPDATE_FLAG) == 0)
            {
                PPT_METHODTRACE_V3("","Set SP_LAST_USED_RECIPE_UPDATE_FLAG = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_LAST_USED_RECIPE_UPDATE_FLAG );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "0"
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_EQPATTR_UPDATE_BY_POSTPROC) == 0)
            {
                PPT_METHODTRACE_V3("","Set SP_EQPATTR_UPDATE_BY_POSTPROC = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_EQPATTR_UPDATE_BY_POSTPROC );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "0"
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000041636 add end
//DSN000043340 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_POSTPROC_SEARCH_SEPARATOR_CHAR) == 0)
            {
                PPT_METHODTRACE_V3("","Set SP_POSTPROC_SEARCH_SEPARATOR_CHAR = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(SP_POSTPROC_SEARCH_SEPARATOR_CHAR);
                CIMFWStrnCpy(workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                continue;
            }
//DSN000043340 Add End
//PSN000043994 Add Start
            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_CHAMBER_CHECK_POLICY) )
            {
                PPT_METHODTRACE_V3("", "Set SP_CHAMBER_CHECK_POLICY = ", strPptEnvVariable[i].envValue, i);
                workptr = getenv( SP_CHAMBER_CHECK_POLICY );
                if( 0 < CIMFWStrLen (strPptEnvVariable[i].envValue) )
                {
                    if( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//PSN000043994 Add End
//DSN000049350 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_EQP_LOCK_MODE) == 0)
            {
                PPT_METHODTRACE_V3("","Set SP_EQP_LOCK_MODE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_EQP_LOCK_MODE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "-1" ) )
                    {
                        CIMFWStrnCpy(workptr, "-1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "0"
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_SORTERJOB_LOCK_FLAG) == 0)
            {
                PPT_METHODTRACE_V3("","Set SP_SORTERJOB_LOCK_FLAG = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_SORTERJOB_LOCK_FLAG );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "0"
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000049350 Add End
//DSN000050720 Add Start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_POSTPROC_PARALLEL_SWITCH) == 0)
            {
                PPT_METHODTRACE_V3("","Set SP_POSTPROC_PARALLEL_SWITCH = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_POSTPROC_PARALLEL_SWITCH );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "0"
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_POSTPROC_PARALLEL_WORKER_SEARCH_RETRY) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_POSTPROC_PARALLEL_WORKER_SEARCH_RETRY = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_POSTPROC_PARALLEL_WORKER_SEARCH_RETRY );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "2" ) )
                    {
                        CIMFWStrnCpy(workptr, "2", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_POSTPROC_PARALLEL_RETRY_SLEEP_TIME) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_POSTPROC_PARALLEL_RETRY_SLEEP_TIME = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_POSTPROC_PARALLEL_RETRY_SLEEP_TIME );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0 )
                {
                    CORBA::Long workVal = 0;
                    workVal = atoi( strPptEnvVariable[i].envValue );
                    if ( workVal <= 0 )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr,"3", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_POSTPROC_PARALLEL_ACTION_RETRY_COUNT) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_POSTPROC_PARALLEL_ACTION_RETRY_COUNT = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_POSTPROC_PARALLEL_ACTION_RETRY_COUNT );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    CORBA::Long workVal = 0;
                    workVal = atoi( strPptEnvVariable[i].envValue );
                    if ( workVal <= 0 )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy( workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000050720 Add End
//PSN000068955 add start
            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_PROPERTYSET_CREATE_ENABLED) )
            {
                PPT_METHODTRACE_V3("", "Set SP_PROPERTYSET_CREATE_ENABLED = ", strPptEnvVariable[i].envValue, i);
                workptr = getenv( SP_PROPERTYSET_CREATE_ENABLED );
                if( 0 < CIMFWStrLen (strPptEnvVariable[i].envValue) )
                {
                    if( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//PSN000068955 add end
//DSN000075358 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_SCRIPTPARAMETER_UPDATE_MODE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_SCRIPTPARAMETER_UPDATE_MODE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_SCRIPTPARAMETER_UPDATE_MODE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000075358 add end
//DSN000071674 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_LOT_OPERATION_EI_CHECK) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_LOT_OPERATION_EI_CHECK = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_LOT_OPERATION_EI_CHECK );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000071674 add end
//PSN000075397 add start
            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_PROPERTYSET_FOR_FACTORY_USE_SYSTEM_KEY_0) )
            {
                PPT_METHODTRACE_V3("", "Set SP_PROPERTYSET_FOR_FACTORY_USE_SYSTEM_KEY_0 = ", strPptEnvVariable[i].envValue, i);
                workptr = getenv( SP_PROPERTYSET_FOR_FACTORY_USE_SYSTEM_KEY_0 );
                if( 0 < CIMFWStrLen (strPptEnvVariable[i].envValue) )
                {
                    if( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//PSN000075397 add end
//DSN000075522 add start
            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_CREATE_PROPERTYSET_FOR_NEW_LOT) )
            {
                PPT_METHODTRACE_V3("", "Set SP_CREATE_PROPERTYSET_FOR_NEW_LOT = ", strPptEnvVariable[i].envValue, i);
                workptr = getenv( SP_CREATE_PROPERTYSET_FOR_NEW_LOT );
                if( 0 < CIMFWStrLen (strPptEnvVariable[i].envValue) )
                {
                    if( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000075522 add end
//DSN000080287 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_KEEP_QTIME_ACTION_ON_CLEAR) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_KEEP_QTIME_ACTION_ON_CLEAR = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_KEEP_QTIME_ACTION_ON_CLEAR );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000080287 add end
//DSN000080226 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_PRIVILEGECHECK_FOR_CJ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_PRIVILEGECHECK_FOR_CJ = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_PRIVILEGECHECK_FOR_CJ );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_PRIVILEGECHECK_FOR_CAST) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_PRIVILEGECHECK_FOR_CAST = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_PRIVILEGECHECK_FOR_CAST );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000080226 add end
//DSN000081739 Add Start
            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_EQPMONITOR_SWITCH) )
            {
                PPT_METHODTRACE_V3("","Set SP_EQPMONITOR_SWITCH = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_EQPMONITOR_SWITCH );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "0"
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000081739 Add End
//DSN000075328 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_POSTPROC_CHAINED_MODE) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_POSTPROC_CHAINED_MODE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_POSTPROC_CHAINED_MODE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_POSTPROC_MAX_CHAIN_EXEC) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_POSTPROC_MAX_CHAIN_EXEC = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_POSTPROC_MAX_CHAIN_EXEC );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    CORBA::Long workVal = 0;
                    workVal = atoi( strPptEnvVariable[i].envValue );
                    if ( workVal <= 0 )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy( workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "3", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000075328 add end
//DSN000076129 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DCSPEC_FOR_PROCESS) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_DCSPEC_FOR_PROCESS = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_DCSPEC_FOR_PROCESS );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000076129 add end
//DSN000085024 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_WARNING_ON_PSM_REGISTRATION) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_WARNING_ON_PSM_REGISTRATION = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_WARNING_ON_PSM_REGISTRATION );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000085024 add end
//PSN000081348 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_PROCESSHOLD_ALLOW_LOTMOVEMENT) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_PROCESSHOLD_ALLOW_LOTMOVEMENT = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_PROCESSHOLD_ALLOW_LOTMOVEMENT );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//PSN000081348 add end
//DSN000085698 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_RESET_EQPMON_USED_COUNT_ON_STB) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_RESET_EQPMON_USED_COUNT_ON_STB = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_RESET_EQPMON_USED_COUNT_ON_STB );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "2" ) )
                    {
                        CIMFWStrnCpy(workptr, "2", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000085698 add end
//DSN000085793 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_WIP_LOT_RESET_UPDATE_LEVEL) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_WIP_LOT_RESET_UPDATE_LEVEL = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_WIP_LOT_RESET_UPDATE_LEVEL );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000085793 add end
//DSN000085792 Add Start
            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_INACTIVE_QTIME_LIST) )
            {
                PPT_METHODTRACE_V3("","Set SP_INACTIVE_QTIME_LIST = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_INACTIVE_QTIME_LIST );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "0"
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, SP_QTIME_REPLACETRIGGER_MAINPD_PRIORITY) == 0)
            {
                PPT_METHODTRACE_V3("","Set SP_QTIME_REPLACETRIGGER_MAINPD_PRIORITY = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_QTIME_REPLACETRIGGER_MAINPD_PRIORITY );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000085792 Add End
//DSN000100527 Add Start
            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_BANKINCANCEL_PRODUCT_CHECK) )
            {
                PPT_METHODTRACE_V3("","Set SP_BANKINCANCEL_PRODUCT_CHECK = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_BANKINCANCEL_PRODUCT_CHECK );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "1"
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000100527 Add End
//DSN000096144 add start
            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_USER_PRIVILEGE_POLICY) )
            {
                PPT_METHODTRACE_V3("","Set SP_USER_PRIVILEGE_POLICY = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_USER_PRIVILEGE_POLICY );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "0"
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000096144 add end
//DSN000096141 add start
            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_PASSCOUNT_WAFERLEVEL_CONTROL) )
            {
                PPT_METHODTRACE_V3("","Set SP_PASSCOUNT_WAFERLEVEL_CONTROL = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_PASSCOUNT_WAFERLEVEL_CONTROL );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "2" ) )
                    {
                        CIMFWStrnCpy(workptr, "2", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "0"
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_PASSCOUNT_WAFERLEVEL_EVENT_CREATION) )
            {
                PPT_METHODTRACE_V3("","Set SP_PASSCOUNT_WAFERLEVEL_EVENT_CREATION = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_PASSCOUNT_WAFERLEVEL_EVENT_CREATION );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "0"
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_LOT_OPERATION_MOVE_EVENT_CREATION_FOR_STB) )
            {
                PPT_METHODTRACE_V3("","Set SP_LOT_OPERATION_MOVE_EVENT_CREATION_FOR_STB = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_LOT_OPERATION_MOVE_EVENT_CREATION_FOR_STB );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "0"
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000096141 add end
//PSN000101301 add start
            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_QTIME_DISPATCHPRECEDE_USE_CUSTOMFIELD) )
            {
                PPT_METHODTRACE_V3("","Set SP_QTIME_DISPATCHPRECEDE_USE_CUSTOMFIELD = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_QTIME_DISPATCHPRECEDE_USE_CUSTOMFIELD );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "0"
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//PSN000101301 add end
//DSN000101569 add start
            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DURABLE_SUBSTATUS_TRANSITION_LIMITATION) )
            {
                PPT_METHODTRACE_V3("","Set SP_DURABLE_SUBSTATUS_TRANSITION_LIMITATION = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_DURABLE_SUBSTATUS_TRANSITION_LIMITATION );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "1"
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }

            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_RETRIEVE_RETICLE_DURING_LOTPROCESS) )
            {
                PPT_METHODTRACE_V3("","Set SP_RETRIEVE_RETICLE_DURING_LOTPROCESS = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_RETRIEVE_RETICLE_DURING_LOTPROCESS );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "0"
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }

            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DURABLEPROCESS_FOR_NON_EMPTY_CARRIER) )
            {
                PPT_METHODTRACE_V3("","Set SP_DURABLEPROCESS_FOR_NON_EMPTY_CARRIER = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_DURABLEPROCESS_FOR_NON_EMPTY_CARRIER );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "0"
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }

            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DURABLEPROCESS_FOR_NON_EMPTY_RETICLEPOD) )
            {
                PPT_METHODTRACE_V3("","Set SP_DURABLEPROCESS_FOR_NON_EMPTY_RETICLEPOD = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_DURABLEPROCESS_FOR_NON_EMPTY_RETICLEPOD );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "0"
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000101569 add end
//DSN000101643 Add Start
            if ( CIMFWStrCmp( strPptEnvVariable[i].envName, SP_ENCRYPT_PASSWORD ) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set SP_ENCRYPT_PASSWORD = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_ENCRYPT_PASSWORD );
                if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, SP_ENCRYPT_PASSWORD_ENCRYPT ) )
                {
                    CIMFWStrnCpy(workptr, SP_ENCRYPT_PASSWORD_ENCRYPT, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - CIMFWStrLen(SP_ENCRYPT_PASSWORD_ENCRYPT) - 1 );
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000101643 Add End
//DSN000104510 add start
            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_DISPATCH_CAST_CLEARED_BY_CHANGE_TO_ONLINE) )
            {
                PPT_METHODTRACE_V3("","Set SP_DISPATCH_CAST_CLEARED_BY_CHANGE_TO_ONLINE = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_DISPATCH_CAST_CLEARED_BY_CHANGE_TO_ONLINE );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "0"
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//DSN000104510 add end
//PSN000105028 add start
            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_FRLOTPO_DELETE_FOR_SCRAPPED) )
            {
                PPT_METHODTRACE_V3("","Set SP_FRLOTPO_DELETE_FOR_SCRAPPED = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_FRLOTPO_DELETE_FOR_SCRAPPED );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "1"
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_FRLOTPO_DELETE_FOR_EMPTIED) )
            {
                PPT_METHODTRACE_V3("","Set SP_FRLOTPO_DELETE_FOR_EMPTIED = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_FRLOTPO_DELETE_FOR_EMPTIED );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "1"
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_FRLOTPO_DELETE_FOR_SHIPPED) )
            {
                PPT_METHODTRACE_V3("","Set SP_FRLOTPO_DELETE_FOR_SHIPPED = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_FRLOTPO_DELETE_FOR_SHIPPED );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "1"
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if( 0 == CIMFWStrCmp(strPptEnvVariable[i].envName, SP_FRLOTPO_DELETE_FOR_STACKED) )
            {
                PPT_METHODTRACE_V3("","Set SP_FRLOTPO_DELETE_FOR_STACKED = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( SP_FRLOTPO_DELETE_FOR_STACKED );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "0" ) )
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else // Set Default "1"
                {
                    CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
//PSN000105028 add end
//INN-A170001 add start
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, CS_SP_RMS_HOST_NAME) == 0)
            {
                PPT_METHODTRACE_V3("","CS_SP_RMS_HOST_NAME = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(CS_SP_RMS_HOST_NAME);
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, CS_SP_RMS_MARKER_NAME) == 0)
            {
                PPT_METHODTRACE_V3("","CS_SP_RMS_MARKER_NAME = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(CS_SP_RMS_MARKER_NAME);
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, CS_SP_RMS_SERVER_NAME) == 0)
            {
                PPT_METHODTRACE_V3("","CS_SP_RMS_SERVER_NAME = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(CS_SP_RMS_SERVER_NAME);
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, CS_SP_BindEverytime_RMS) == 0)
            {
                PPT_METHODTRACE_V3("","CS_SP_BindEverytime_RMS = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(CS_SP_BindEverytime_RMS);
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, CS_SP_TX_TIMEOUT_RMS) == 0)
            {
                PPT_METHODTRACE_V3("","CS_SP_TX_TIMEOUT_RMS = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(CS_SP_TX_TIMEOUT_RMS);
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - strlen(strPptEnvVariable[i].envName) - 2 );
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, CS_SP_BIND_RETRY_COUNT_RMS) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set CS_SP_BIND_RETRY_COUNT_RMS = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(CS_SP_BIND_RETRY_COUNT_RMS);
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, CS_SP_BIND_SLEEP_TIME_RMS) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set CS_SP_BIND_SLEEP_TIME_RMS = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(CS_SP_BIND_SLEEP_TIME_RMS);
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                continue;
            }

            if(CIMFWStrCmp(strPptEnvVariable[i].envName, CS_SP_RMS_CHECK_ONLINE_FLAG) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set CS_SP_RMS_CHECK_ONLINE_FLAG = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv( CS_SP_RMS_CHECK_ONLINE_FLAG );
                if ( CIMFWStrLen (strPptEnvVariable[i].envValue) > 0)
                {
                    if ( 0 == CIMFWStrCmp( strPptEnvVariable[i].envValue, "1" ) )
                    {
                        CIMFWStrnCpy(workptr, "1", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                    else
                    {
                        CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                    }
                }
                else
                {
                    CIMFWStrnCpy(workptr, "0", SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                }
                continue;
            }
            if(CIMFWStrCmp(strPptEnvVariable[i].envName, CS_RMS_IGNOREAUDIT_EQPLIST) == 0)
            {
                PPT_METHODTRACE_V3("environmentVariable_Set","Set CS_RMS_IGNOREAUDIT_EQPLIST = ", strPptEnvVariable[i].envValue,i);
                workptr = getenv(CS_RMS_IGNOREAUDIT_EQPLIST);
                CIMFWStrnCpy(workptr,strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2 );
                continue;
            }
///INN-A170001 add end

//INN-R170008 Add Start
            if (CIMFWStrCmp(strPptEnvVariable[i].envName, CS_TACERTIFY_SKILL_EXP_DURATION) == 0)
			{
				PPT_METHODTRACE_V3("environmentVariable_Set", "Set CS_TACERTIFY_SKILL_EXP_DURATION = ", strPptEnvVariable[i].envValue, i);
				workptr = getenv(CS_TACERTIFY_SKILL_EXP_DURATION);
				CIMFWStrnCpy(workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2);
				continue;
			}

			if (CIMFWStrCmp(strPptEnvVariable[i].envName, CS_TACERTIFY_PRE_ALARM_DURATION) == 0)
			{
				PPT_METHODTRACE_V3("environmentVariable_Set", "Set CS_TACERTIFY_PRE_ALARM_DURATION = ", strPptEnvVariable[i].envValue, i);
				workptr = getenv(CS_TACERTIFY_PRE_ALARM_DURATION);
				CIMFWStrnCpy(workptr, strPptEnvVariable[i].envValue, SP_ENV_MAX_LEN - CIMFWStrLen(strPptEnvVariable[i].envName) - 2);
				continue;
			}
//INN-R170008 Add End
        }

        PPT_METHODTRACE_EXIT("CS_PPTManager_i::environmentVariable_Set");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strEnvironmentVariable_Set_out, environmentVariable_Set, methodName)
}
