#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/csppt/source/posppt/pptmgr/objmethd/cs_testFunction_Obj.cpp, mm_srv_90e_cspp, mm_srv_90e_cspp 7/13/07 19:54:32 [ 7/13/07 19:54:34 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView - CS PPT Manager
// Name: cs_testFunction_Obj.cpp
//
// ** Notice **
//   This is a sample code for customizing a PPT Manager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT Manager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//
// Change history:
//
// Date       Defect#   Person         Comments
// ---------- --------- -------------- -------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya      Initial Release for R5.0
//


#include "cs_pptmgr.hpp"
#include "cs_posconst.hpp"

CORBA::Long CS_PPTManager_i::cs_testFunction(
			objTestFunction_Obj_out& strTestFunction_Obj_out,
			const pptObjCommonIn& strObjCommonIn,
            const char* claimMemo )

{
	strTestFunction_Obj_out.infos.length(1);
	//strTestFunction_Obj_out.infos[0].testID           = CIMFWStrDup("TEST RESULT");
	//strTestFunction_Obj_out.infos[0].objID.identifier = CIMFWStrDup("ID");
	//strTestFunction_Obj_out.infos[0].description      = CIMFWStrDup("Result of Test Function" );

    // Test for customized return code 
    if( !CIMFWStrCmp( claimMemo, "Error" ) )
    {
        //PPT_SET_MSG_RC_KEY( strTestFunction_Obj_out, 
        //                    CS_MSG_SAMPLE_RETURN_CODE,
        //                    CS_RC_SAMPLE_RETURN_CODE , "")	;
        SET_MSG_RC( strTestFunction_Obj_out, 
                            CS_MSG_SAMPLE_RETURN_CODE,
                            CS_RC_SAMPLE_RETURN_CODE )	;

        return CS_RC_SAMPLE_RETURN_CODE;
    }

	return RC_OK;
}
