//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: cs_lot_ContaminationInfo_CheckForCarrierExchange.cpp
//
#include "cs_pptmgr.hpp"
#include "pcas.hh"
#include "plot.hh"
// Class: CS_PPTManager
//
// Service: cs_lot_ContaminationInfo_CheckForCarrierExchange()
//
// Innotron Modification history :
// Date       Defect#       Person         Comments
// ---------- ------------  -------------- -------------------------------------------
// 2017-09-11 INN-R170002   JQ.Shao        Add for contamination customization for innotron 
//
//[Function Description]:
//
//
//[Input Parameters]:
//  in  pptObjCommonIn      strObjCommonIn;
//  in  csObjLot_ContaminationInfo_CheckForCarrierExchange_in    strLot_ContaminationInfo_CheckForCarrierExchange_in
//
//[Output Parameters]:
//
//  out csObjLot_ContaminationInfo_CheckForCarrierExchange_out  strLot_ContaminationInfo_CheckForCarrierExchange_out;
//
//  typedef struct csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct {
//    boolean          matchFlag;
//    any              siInfo;
//} csObjLot_ContaminationInfo_CheckForCarrierExchange_out;
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long CS_PPTManager_i::cs_lot_ContaminationInfo_CheckForCarrierExchange(
    csObjLot_ContaminationInfo_CheckForCarrierExchange_out &strLot_ContaminationInfo_CheckForCarrierExchange_out, 
    const pptObjCommonIn &strObjCommonIn, 
    const csObjLot_ContaminationInfo_CheckForCarrierExchange_in &strLot_ContaminationInfo_CheckForCarrierExchange_in)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("CS_PPTManager_i::cs_lot_ContaminationInfo_CheckForCarrierExchange");
        CORBA::Long rc = RC_OK;

        CORBA::Long nMoveLen = strLot_ContaminationInfo_CheckForCarrierExchange_in.lotIDs.length();
        PPT_METHODTRACE_V2("", "strLot_ContaminationInfo_CheckForCarrierExchange_in.lotIDs.length",nMoveLen);

        CORBA::Long nLotInCastLen = 0;
        objCassette_GetLotList_out strCassette_GetLotList_out;
        rc = cassette_GetLotList( strCassette_GetLotList_out, strObjCommonIn, 
                                  strLot_ContaminationInfo_CheckForCarrierExchange_in.carrierID );

        if( rc == RC_NOT_FOUND_LOT)
        {
            nLotInCastLen = 0; //empty carrier
        }
        else if( rc != RC_OK)
        {
            PPT_METHODTRACE_V2("", "cassette_GetLotList() != RC_OK", rc);
            strLot_ContaminationInfo_CheckForCarrierExchange_out.strResult = strCassette_GetLotList_out.strResult;
            return(rc);
        }
        else
        {
            nLotInCastLen = strCassette_GetLotList_out.strLotListInCassetteInfo.lotID.length();
        }
        PPT_METHODTRACE_V2("","strCassette_GetLotList_out.strLotListInCassetteInfo.lotID.length", nLotInCastLen);

        PosCassette_var aPosCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aPosCassette, strLot_ContaminationInfo_CheckForCarrierExchange_in.carrierID,
                                               strLot_ContaminationInfo_CheckForCarrierExchange_out,
                                               cs_lot_ContaminationInfo_CheckForCarrierExchange );

        CORBA::String_var varCarrierUsageType;
        SI_PPT_USERDATA_GET_STRING( aPosCassette, CS_M_CAST_UsageType, varCarrierUsageType );
        PPT_METHODTRACE_V2("", "varCarrierUsageType", varCarrierUsageType );

        CORBA::String_var castCategory;
        try
        {
            castCategory = aPosCassette->getCassetteCategory();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getCassetteCategory)
        PPT_METHODTRACE_V2("", "castCategory", castCategory);

        //--------------------------------
        // Loop for source lots
        //--------------------------------
        for (CORBA::Long iCntL=0; iCntL < nMoveLen; iCntL++)
        {
            objectIdentifier lotID = strLot_ContaminationInfo_CheckForCarrierExchange_in.lotIDs[iCntL];
            PPT_METHODTRACE_V2("","lotID--->", lotID.identifier);

            PosLot_var aPosLot;
            PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot, lotID, strLot_ContaminationInfo_CheckForCarrierExchange_out, cs_lot_ContaminationInfo_CheckForCarrierExchange );
            
            CORBA::String_var varContaminationFlag;
            SI_PPT_USERDATA_GET_STRING( aPosLot, CS_M_LOT_Contamination_Flag, varContaminationFlag );

            //--------------------------------
            // Get lot usage type
            //--------------------------------
            ProductSpecification_var aTmpProductSpecification;
            PosProductSpecification_var aProductSpecification;
            try
            {
                aTmpProductSpecification = aPosLot->getProductSpecification();
                aProductSpecification = PosProductSpecification::_narrow(aTmpProductSpecification);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification);

            if ( TRUE == CORBA::is_nil(aProductSpecification) )
            {
                PPT_METHODTRACE_V1("", "Error : Lot Product ID is NIL");
                SET_MSG_RC( strLot_ContaminationInfo_CheckForCarrierExchange_out,
                            MSG_NOT_FOUND_PRODUCTSPEC,
                            RC_NOT_FOUND_PRODUCTSPEC );
                return RC_NOT_FOUND_PRODUCTSPEC;
            }

            CORBA::String_var varProdUsageType;
            SI_PPT_USERDATA_GET_STRING( aProductSpecification, CS_S_PROD_CarrierUsageType, varProdUsageType );

            PPT_METHODTRACE_V2("", "varProdUsageType", varProdUsageType );

            if( 0 <  CIMFWStrLen(varProdUsageType) && 0 < CIMFWStrLen(varCarrierUsageType)
             && 0 != CIMFWStrCmp(varProdUsageType, varCarrierUsageType) )
            {
                PPT_METHODTRACE_V1("", "varProdUsageType != varCarrierUsageType" );
                CS_PPT_SET_MSG_RC_KEY2( strLot_ContaminationInfo_CheckForCarrierExchange_out,
                                        CS_MSG_USAGE_TYPE_MISMATCH,
                                        CS_RC_USAGE_TYPE_MISMATCH,
                                        lotID.identifier,
                                        strLot_ContaminationInfo_CheckForCarrierExchange_in.carrierID.identifier );
                return CS_RC_USAGE_TYPE_MISMATCH;
            }

            objLot_processState_Get_out strLot_processState_Get_out ;
            rc = lot_processState_Get( strLot_processState_Get_out , strObjCommonIn , lotID ) ;
            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "lot_processState_Get() != RC_OK") ;
                strLot_ContaminationInfo_CheckForCarrierExchange_out.strResult = strLot_processState_Get_out.strResult ;
                return(rc);
            }

            //----------------------------------------------
            // Check carrier category matched or not
            //----------------------------------------------
            PPT_METHODTRACE_V1("", "call cs_lot_requiredCarrierCategory_CheckDR()") ;

            csObjLot_requiredCarrierCategory_CheckDR_in strLot_requiredCarrierCategory_CheckDR_in;
            strLot_requiredCarrierCategory_CheckDR_in.lotID = lotID;
            strLot_requiredCarrierCategory_CheckDR_in.carrierID = strLot_ContaminationInfo_CheckForCarrierExchange_in.carrierID;
            strLot_requiredCarrierCategory_CheckDR_in.curCastCategory = castCategory;

            csObjLot_requiredCarrierCategory_CheckDR_out strLot_requiredCarrierCategory_CheckDR_out;
            rc = cs_lot_requiredCarrierCategory_CheckDR( strLot_requiredCarrierCategory_CheckDR_out,
                                                          strObjCommonIn,
                                                          strLot_requiredCarrierCategory_CheckDR_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "cs_lot_requiredCarrierCategory_CheckDR() rc != RC_OK");
                strLot_ContaminationInfo_CheckForCarrierExchange_out.strResult = strLot_requiredCarrierCategory_CheckDR_out.strResult ;
                return( rc );
            }

            //---------------------------------------------------------------------
            // All lots in destination carrier should have same contamination Flag
            //---------------------------------------------------------------------
            for (CORBA::Long seqIx=iCntL+1; seqIx<nMoveLen; seqIx++)
            {
                PosLot_var aPosLotNext;
                PPT_CONVERT_LOTID_TO_LOT_OR( aPosLotNext, 
                                             strLot_ContaminationInfo_CheckForCarrierExchange_in.lotIDs[seqIx], 
                                             strLot_ContaminationInfo_CheckForCarrierExchange_out, 
                                             cs_lot_ContaminationInfo_CheckForCarrierExchange );

                CORBA::String_var varContaminationNextFlag;
                SI_PPT_USERDATA_GET_STRING( aPosLotNext, CS_M_LOT_Contamination_Flag, varContaminationNextFlag );

                if( 0 <  CIMFWStrLen(varContaminationFlag) && 0 < CIMFWStrLen(varContaminationNextFlag)
                 && 0 != CIMFWStrCmp(varContaminationFlag, varContaminationNextFlag) )
                {
                    PPT_METHODTRACE_V3("", "varContaminationFlag != varContaminationNextFlag", varContaminationFlag, varContaminationNextFlag );
                    CS_PPT_SET_MSG_RC_KEY2( strLot_ContaminationInfo_CheckForCarrierExchange_out,
                                            CS_MSG_NOT_SAME_CONTAMINATION,
                                            CS_RC_NOT_SAME_CONTAMINATION,
                                            lotID.identifier,
                                            strLot_ContaminationInfo_CheckForCarrierExchange_in.lotIDs[seqIx].identifier );
                    return CS_RC_NOT_SAME_CONTAMINATION;
                }
            }

            //--------------------------------
            // All Lot in Start Cassette Loop
            //--------------------------------
            for (CORBA::Long jj=0; jj<nLotInCastLen; jj++ )
            {
                PosLot_var aPosLotInDestCas;
                PPT_CONVERT_LOTID_TO_LOT_OR( aPosLotInDestCas, 
                                             strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[jj], 
                                             strLot_ContaminationInfo_CheckForCarrierExchange_out, 
                                             cs_lot_ContaminationInfo_CheckForCarrierExchange );

                CORBA::String_var varContaminationLotInDestCasFlag;
                SI_PPT_USERDATA_GET_STRING( aPosLotInDestCas, CS_M_LOT_Contamination_Flag, varContaminationLotInDestCasFlag );

                if( 0 <  CIMFWStrLen(varContaminationFlag) && 0 < CIMFWStrLen(varContaminationLotInDestCasFlag)
                 && 0 != CIMFWStrCmp(varContaminationFlag, varContaminationLotInDestCasFlag) )
                {
                    PPT_METHODTRACE_V3("", "varContaminationFlag != varContaminationLotInDestCasFlag", varContaminationFlag, varContaminationLotInDestCasFlag );
                    CS_PPT_SET_MSG_RC_KEY2( strLot_ContaminationInfo_CheckForCarrierExchange_out,
                                            CS_MSG_NOT_SAME_CONTAMINATION,
                                            CS_RC_NOT_SAME_CONTAMINATION,
                                            lotID.identifier,
                                            strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[jj].identifier );
                    return CS_RC_NOT_SAME_CONTAMINATION;
                }
            }
        }
        return rc;
    }
    CATCH_GLOBAL_EXCEPTIONS(strLot_ContaminationInfo_CheckForCarrierExchange_out, cs_lot_ContaminationInfo_CheckForCarrierExchange, methodName)
}
