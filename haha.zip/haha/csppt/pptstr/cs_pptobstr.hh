//----------------------------------------------------------------------------
//
//  Generated from cs_pptobstr.idl
//  On Thursday, October 19, 2017 5:48:35 PM GMT+07:00
//  by IBM CORBA 2.3 (hh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _cs_pptobstr_server_defined
#ifndef _cs_pptobstr_hh_included
#define _cs_pptobstr_hh_included

#ifdef _MSC_VER
#define _export export
#endif
#ifndef _USE_NAMESPACE
#define _USE_NAMESPACE
#endif

#ifndef CORBA_included
#include <corba.h>
#endif
#ifdef SIVIEW_EBROKER
extern "C" {
   #include<stdlib.h>
}
 #if defined(minor)
  #undef minor
 #endif
#endif // SIVIEW_EBROKER

#ifndef IMTRIM
#define IMTRIM
#endif

#ifndef IM_EBROKER
#define IM_EBROKER
#endif

#ifndef CIMFWEVENTS_DISABLED
#define CIMFWEVENTS_DISABLED
#endif

#ifndef DB2PW
#define DB2PW
#endif

#ifndef _AIX
#define _AIX
#endif


#ifndef CS_PPT_Object_Method_Structures_idl 
#define CS_PPT_Object_Method_Structures_idl 
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _pptobstr_hh_included
#include <pptobstr.hh>
#endif
#else
#ifndef _pptobstr_hh_included
#include "pptobstr.hh"
#endif
#endif
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _cs_pptstr_hh_included
#include <cs_pptstr.hh>
#endif
#else
#ifndef _cs_pptstr_hh_included
#include "cs_pptstr.hh"
#endif
#endif
    class  objSample_Obj_struct_var;
    struct  objSample_Obj_struct {
        typedef objSample_Obj_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       objSample_Obj_struct();
       objSample_Obj_struct(const objSample_Obj_struct&);
       objSample_Obj_struct& operator=(const objSample_Obj_struct&);
       static CORBA::Info<objSample_Obj_struct> objSample_Obj_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct objSample_Obj_struct


typedef objSample_Obj_struct* objSample_Obj_struct_vPtr;
typedef const objSample_Obj_struct* objSample_Obj_struct_cvPtr;

class  objSample_Obj_struct_var
{
    public:

    objSample_Obj_struct_var ();

    objSample_Obj_struct_var (objSample_Obj_struct *_p);

    objSample_Obj_struct_var (const objSample_Obj_struct_var &_s);

    objSample_Obj_struct_var &operator= (objSample_Obj_struct *_p);

    objSample_Obj_struct_var &operator= (const objSample_Obj_struct_var &_s);

    ~objSample_Obj_struct_var ();

    objSample_Obj_struct* operator-> ();

    const objSample_Obj_struct& in() const;
    objSample_Obj_struct& inout();
    objSample_Obj_struct*& out();
    objSample_Obj_struct* _retn();

    operator objSample_Obj_struct_cvPtr () const;

    operator objSample_Obj_struct_vPtr& ();

    operator const objSample_Obj_struct& () const;

    operator objSample_Obj_struct& ();

    protected:
    objSample_Obj_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_objSample_Obj_struct;
    typedef objSample_Obj_struct objSample_Obj_out;
    typedef objSample_Obj_struct_var objSample_Obj_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_objSample_Obj_out;
    class  objTestFunction_Obj_struct_var;
    struct  objTestFunction_Obj_struct {
        typedef objTestFunction_Obj_struct_var _var_type;
       ::pptRetCode strResult;
       ::csTestFunctionInfoSequence infos;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       objTestFunction_Obj_struct();
       objTestFunction_Obj_struct(const objTestFunction_Obj_struct&);
       objTestFunction_Obj_struct& operator=(const objTestFunction_Obj_struct&);
       static CORBA::Info<objTestFunction_Obj_struct> objTestFunction_Obj_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct objTestFunction_Obj_struct


typedef objTestFunction_Obj_struct* objTestFunction_Obj_struct_vPtr;
typedef const objTestFunction_Obj_struct* objTestFunction_Obj_struct_cvPtr;

class  objTestFunction_Obj_struct_var
{
    public:

    objTestFunction_Obj_struct_var ();

    objTestFunction_Obj_struct_var (objTestFunction_Obj_struct *_p);

    objTestFunction_Obj_struct_var (const objTestFunction_Obj_struct_var &_s);

    objTestFunction_Obj_struct_var &operator= (objTestFunction_Obj_struct *_p);

    objTestFunction_Obj_struct_var &operator= (const objTestFunction_Obj_struct_var &_s);

    ~objTestFunction_Obj_struct_var ();

    objTestFunction_Obj_struct* operator-> ();

    const objTestFunction_Obj_struct& in() const;
    objTestFunction_Obj_struct& inout();
    objTestFunction_Obj_struct*& out();
    objTestFunction_Obj_struct* _retn();

    operator objTestFunction_Obj_struct_cvPtr () const;

    operator objTestFunction_Obj_struct_vPtr& ();

    operator const objTestFunction_Obj_struct& () const;

    operator objTestFunction_Obj_struct& ();

    protected:
    objTestFunction_Obj_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_objTestFunction_Obj_struct;
    typedef objTestFunction_Obj_struct objTestFunction_Obj_out;
    typedef objTestFunction_Obj_struct_var objTestFunction_Obj_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_objTestFunction_Obj_out;
    class  csObjEquipment_InAuditList_GetDR_out_struct_var;
    struct  csObjEquipment_InAuditList_GetDR_out_struct {
        typedef csObjEquipment_InAuditList_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifierSequence EquipmentIDs;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEquipment_InAuditList_GetDR_out_struct();
       csObjEquipment_InAuditList_GetDR_out_struct(const csObjEquipment_InAuditList_GetDR_out_struct&);
       csObjEquipment_InAuditList_GetDR_out_struct& operator=(const csObjEquipment_InAuditList_GetDR_out_struct&);
       static CORBA::Info<csObjEquipment_InAuditList_GetDR_out_struct> csObjEquipment_InAuditList_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEquipment_InAuditList_GetDR_out_struct


typedef csObjEquipment_InAuditList_GetDR_out_struct* csObjEquipment_InAuditList_GetDR_out_struct_vPtr;
typedef const csObjEquipment_InAuditList_GetDR_out_struct* csObjEquipment_InAuditList_GetDR_out_struct_cvPtr;

class  csObjEquipment_InAuditList_GetDR_out_struct_var
{
    public:

    csObjEquipment_InAuditList_GetDR_out_struct_var ();

    csObjEquipment_InAuditList_GetDR_out_struct_var (csObjEquipment_InAuditList_GetDR_out_struct *_p);

    csObjEquipment_InAuditList_GetDR_out_struct_var (const csObjEquipment_InAuditList_GetDR_out_struct_var &_s);

    csObjEquipment_InAuditList_GetDR_out_struct_var &operator= (csObjEquipment_InAuditList_GetDR_out_struct *_p);

    csObjEquipment_InAuditList_GetDR_out_struct_var &operator= (const csObjEquipment_InAuditList_GetDR_out_struct_var &_s);

    ~csObjEquipment_InAuditList_GetDR_out_struct_var ();

    csObjEquipment_InAuditList_GetDR_out_struct* operator-> ();

    const csObjEquipment_InAuditList_GetDR_out_struct& in() const;
    csObjEquipment_InAuditList_GetDR_out_struct& inout();
    csObjEquipment_InAuditList_GetDR_out_struct*& out();
    csObjEquipment_InAuditList_GetDR_out_struct* _retn();

    operator csObjEquipment_InAuditList_GetDR_out_struct_cvPtr () const;

    operator csObjEquipment_InAuditList_GetDR_out_struct_vPtr& ();

    operator const csObjEquipment_InAuditList_GetDR_out_struct& () const;

    operator csObjEquipment_InAuditList_GetDR_out_struct& ();

    protected:
    csObjEquipment_InAuditList_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_InAuditList_GetDR_out_struct;
    typedef csObjEquipment_InAuditList_GetDR_out_struct csObjEquipment_InAuditList_GetDR_out;
    typedef csObjEquipment_InAuditList_GetDR_out_struct_var csObjEquipment_InAuditList_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_InAuditList_GetDR_out;
    class  csObjEquipment_ListByOwnerDR_out_struct_var;
    struct  csObjEquipment_ListByOwnerDR_out_struct {
        typedef csObjEquipment_ListByOwnerDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csEqpsByOwnerSequence strEqpsByOwners;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEquipment_ListByOwnerDR_out_struct();
       csObjEquipment_ListByOwnerDR_out_struct(const csObjEquipment_ListByOwnerDR_out_struct&);
       csObjEquipment_ListByOwnerDR_out_struct& operator=(const csObjEquipment_ListByOwnerDR_out_struct&);
       static CORBA::Info<csObjEquipment_ListByOwnerDR_out_struct> csObjEquipment_ListByOwnerDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEquipment_ListByOwnerDR_out_struct


typedef csObjEquipment_ListByOwnerDR_out_struct* csObjEquipment_ListByOwnerDR_out_struct_vPtr;
typedef const csObjEquipment_ListByOwnerDR_out_struct* csObjEquipment_ListByOwnerDR_out_struct_cvPtr;

class  csObjEquipment_ListByOwnerDR_out_struct_var
{
    public:

    csObjEquipment_ListByOwnerDR_out_struct_var ();

    csObjEquipment_ListByOwnerDR_out_struct_var (csObjEquipment_ListByOwnerDR_out_struct *_p);

    csObjEquipment_ListByOwnerDR_out_struct_var (const csObjEquipment_ListByOwnerDR_out_struct_var &_s);

    csObjEquipment_ListByOwnerDR_out_struct_var &operator= (csObjEquipment_ListByOwnerDR_out_struct *_p);

    csObjEquipment_ListByOwnerDR_out_struct_var &operator= (const csObjEquipment_ListByOwnerDR_out_struct_var &_s);

    ~csObjEquipment_ListByOwnerDR_out_struct_var ();

    csObjEquipment_ListByOwnerDR_out_struct* operator-> ();

    const csObjEquipment_ListByOwnerDR_out_struct& in() const;
    csObjEquipment_ListByOwnerDR_out_struct& inout();
    csObjEquipment_ListByOwnerDR_out_struct*& out();
    csObjEquipment_ListByOwnerDR_out_struct* _retn();

    operator csObjEquipment_ListByOwnerDR_out_struct_cvPtr () const;

    operator csObjEquipment_ListByOwnerDR_out_struct_vPtr& ();

    operator const csObjEquipment_ListByOwnerDR_out_struct& () const;

    operator csObjEquipment_ListByOwnerDR_out_struct& ();

    protected:
    csObjEquipment_ListByOwnerDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_ListByOwnerDR_out_struct;
    typedef csObjEquipment_ListByOwnerDR_out_struct csObjEquipment_ListByOwnerDR_out;
    typedef csObjEquipment_ListByOwnerDR_out_struct_var csObjEquipment_ListByOwnerDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_ListByOwnerDR_out;
    class  csObjRMSMgr_GetServiceManager_out_struct_var;
    struct  csObjRMSMgr_GetServiceManager_out_struct {
        typedef csObjRMSMgr_GetServiceManager_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::String_StructElem RMSSvcMgr;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjRMSMgr_GetServiceManager_out_struct();
       csObjRMSMgr_GetServiceManager_out_struct(const csObjRMSMgr_GetServiceManager_out_struct&);
       csObjRMSMgr_GetServiceManager_out_struct& operator=(const csObjRMSMgr_GetServiceManager_out_struct&);
       static CORBA::Info<csObjRMSMgr_GetServiceManager_out_struct> csObjRMSMgr_GetServiceManager_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjRMSMgr_GetServiceManager_out_struct


typedef csObjRMSMgr_GetServiceManager_out_struct* csObjRMSMgr_GetServiceManager_out_struct_vPtr;
typedef const csObjRMSMgr_GetServiceManager_out_struct* csObjRMSMgr_GetServiceManager_out_struct_cvPtr;

class  csObjRMSMgr_GetServiceManager_out_struct_var
{
    public:

    csObjRMSMgr_GetServiceManager_out_struct_var ();

    csObjRMSMgr_GetServiceManager_out_struct_var (csObjRMSMgr_GetServiceManager_out_struct *_p);

    csObjRMSMgr_GetServiceManager_out_struct_var (const csObjRMSMgr_GetServiceManager_out_struct_var &_s);

    csObjRMSMgr_GetServiceManager_out_struct_var &operator= (csObjRMSMgr_GetServiceManager_out_struct *_p);

    csObjRMSMgr_GetServiceManager_out_struct_var &operator= (const csObjRMSMgr_GetServiceManager_out_struct_var &_s);

    ~csObjRMSMgr_GetServiceManager_out_struct_var ();

    csObjRMSMgr_GetServiceManager_out_struct* operator-> ();

    const csObjRMSMgr_GetServiceManager_out_struct& in() const;
    csObjRMSMgr_GetServiceManager_out_struct& inout();
    csObjRMSMgr_GetServiceManager_out_struct*& out();
    csObjRMSMgr_GetServiceManager_out_struct* _retn();

    operator csObjRMSMgr_GetServiceManager_out_struct_cvPtr () const;

    operator csObjRMSMgr_GetServiceManager_out_struct_vPtr& ();

    operator const csObjRMSMgr_GetServiceManager_out_struct& () const;

    operator csObjRMSMgr_GetServiceManager_out_struct& ();

    protected:
    csObjRMSMgr_GetServiceManager_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjRMSMgr_GetServiceManager_out_struct;
    typedef csObjRMSMgr_GetServiceManager_out_struct csObjRMSMgr_GetServiceManager_out;
    typedef csObjRMSMgr_GetServiceManager_out_struct_var csObjRMSMgr_GetServiceManager_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjRMSMgr_GetServiceManager_out;
    class  csObjEquipment_constantsManageFlag_Get_out_struct_var;
    struct  csObjEquipment_constantsManageFlag_Get_out_struct {
        typedef csObjEquipment_constantsManageFlag_Get_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Boolean equipmentConstantsManageFlag;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEquipment_constantsManageFlag_Get_out_struct();
       csObjEquipment_constantsManageFlag_Get_out_struct(const csObjEquipment_constantsManageFlag_Get_out_struct&);
       csObjEquipment_constantsManageFlag_Get_out_struct& operator=(const csObjEquipment_constantsManageFlag_Get_out_struct&);
       static CORBA::Info<csObjEquipment_constantsManageFlag_Get_out_struct> csObjEquipment_constantsManageFlag_Get_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEquipment_constantsManageFlag_Get_out_struct


typedef csObjEquipment_constantsManageFlag_Get_out_struct* csObjEquipment_constantsManageFlag_Get_out_struct_vPtr;
typedef const csObjEquipment_constantsManageFlag_Get_out_struct* csObjEquipment_constantsManageFlag_Get_out_struct_cvPtr;

class  csObjEquipment_constantsManageFlag_Get_out_struct_var
{
    public:

    csObjEquipment_constantsManageFlag_Get_out_struct_var ();

    csObjEquipment_constantsManageFlag_Get_out_struct_var (csObjEquipment_constantsManageFlag_Get_out_struct *_p);

    csObjEquipment_constantsManageFlag_Get_out_struct_var (const csObjEquipment_constantsManageFlag_Get_out_struct_var &_s);

    csObjEquipment_constantsManageFlag_Get_out_struct_var &operator= (csObjEquipment_constantsManageFlag_Get_out_struct *_p);

    csObjEquipment_constantsManageFlag_Get_out_struct_var &operator= (const csObjEquipment_constantsManageFlag_Get_out_struct_var &_s);

    ~csObjEquipment_constantsManageFlag_Get_out_struct_var ();

    csObjEquipment_constantsManageFlag_Get_out_struct* operator-> ();

    const csObjEquipment_constantsManageFlag_Get_out_struct& in() const;
    csObjEquipment_constantsManageFlag_Get_out_struct& inout();
    csObjEquipment_constantsManageFlag_Get_out_struct*& out();
    csObjEquipment_constantsManageFlag_Get_out_struct* _retn();

    operator csObjEquipment_constantsManageFlag_Get_out_struct_cvPtr () const;

    operator csObjEquipment_constantsManageFlag_Get_out_struct_vPtr& ();

    operator const csObjEquipment_constantsManageFlag_Get_out_struct& () const;

    operator csObjEquipment_constantsManageFlag_Get_out_struct& ();

    protected:
    csObjEquipment_constantsManageFlag_Get_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_constantsManageFlag_Get_out_struct;
    typedef csObjEquipment_constantsManageFlag_Get_out_struct csObjEquipment_constantsManageFlag_Get_out;
    typedef csObjEquipment_constantsManageFlag_Get_out_struct_var csObjEquipment_constantsManageFlag_Get_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_constantsManageFlag_Get_out;
    class  csObjRecipe_compareFlag_Get_out_struct_var;
    struct  csObjRecipe_compareFlag_Get_out_struct {
        typedef csObjRecipe_compareFlag_Get_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csMachineRecipeInfoSequence machineRecipeInfos;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjRecipe_compareFlag_Get_out_struct();
       csObjRecipe_compareFlag_Get_out_struct(const csObjRecipe_compareFlag_Get_out_struct&);
       csObjRecipe_compareFlag_Get_out_struct& operator=(const csObjRecipe_compareFlag_Get_out_struct&);
       static CORBA::Info<csObjRecipe_compareFlag_Get_out_struct> csObjRecipe_compareFlag_Get_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjRecipe_compareFlag_Get_out_struct


typedef csObjRecipe_compareFlag_Get_out_struct* csObjRecipe_compareFlag_Get_out_struct_vPtr;
typedef const csObjRecipe_compareFlag_Get_out_struct* csObjRecipe_compareFlag_Get_out_struct_cvPtr;

class  csObjRecipe_compareFlag_Get_out_struct_var
{
    public:

    csObjRecipe_compareFlag_Get_out_struct_var ();

    csObjRecipe_compareFlag_Get_out_struct_var (csObjRecipe_compareFlag_Get_out_struct *_p);

    csObjRecipe_compareFlag_Get_out_struct_var (const csObjRecipe_compareFlag_Get_out_struct_var &_s);

    csObjRecipe_compareFlag_Get_out_struct_var &operator= (csObjRecipe_compareFlag_Get_out_struct *_p);

    csObjRecipe_compareFlag_Get_out_struct_var &operator= (const csObjRecipe_compareFlag_Get_out_struct_var &_s);

    ~csObjRecipe_compareFlag_Get_out_struct_var ();

    csObjRecipe_compareFlag_Get_out_struct* operator-> ();

    const csObjRecipe_compareFlag_Get_out_struct& in() const;
    csObjRecipe_compareFlag_Get_out_struct& inout();
    csObjRecipe_compareFlag_Get_out_struct*& out();
    csObjRecipe_compareFlag_Get_out_struct* _retn();

    operator csObjRecipe_compareFlag_Get_out_struct_cvPtr () const;

    operator csObjRecipe_compareFlag_Get_out_struct_vPtr& ();

    operator const csObjRecipe_compareFlag_Get_out_struct& () const;

    operator csObjRecipe_compareFlag_Get_out_struct& ();

    protected:
    csObjRecipe_compareFlag_Get_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjRecipe_compareFlag_Get_out_struct;
    typedef csObjRecipe_compareFlag_Get_out_struct csObjRecipe_compareFlag_Get_out;
    typedef csObjRecipe_compareFlag_Get_out_struct_var csObjRecipe_compareFlag_Get_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjRecipe_compareFlag_Get_out;
    typedef objBase_out csObjRMSMgr_SendRecipeAuditReq_out;
    typedef objBase_out_var csObjRMSMgr_SendRecipeAuditReq_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjRMSMgr_SendRecipeAuditReq_out;
    typedef objBase_out csObjPerson_PrivilegeCheckForRMS_out;
    typedef objBase_out_var csObjPerson_PrivilegeCheckForRMS_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_PrivilegeCheckForRMS_out;
    class  csObjEquipmentInfo_ListByOwnerDR_out_struct_var;
    struct  csObjEquipmentInfo_ListByOwnerDR_out_struct {
        typedef csObjEquipmentInfo_ListByOwnerDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csEqpInfosByOwnerSequence strEqpInfosByOwners;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEquipmentInfo_ListByOwnerDR_out_struct();
       csObjEquipmentInfo_ListByOwnerDR_out_struct(const csObjEquipmentInfo_ListByOwnerDR_out_struct&);
       csObjEquipmentInfo_ListByOwnerDR_out_struct& operator=(const csObjEquipmentInfo_ListByOwnerDR_out_struct&);
       static CORBA::Info<csObjEquipmentInfo_ListByOwnerDR_out_struct> csObjEquipmentInfo_ListByOwnerDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEquipmentInfo_ListByOwnerDR_out_struct


typedef csObjEquipmentInfo_ListByOwnerDR_out_struct* csObjEquipmentInfo_ListByOwnerDR_out_struct_vPtr;
typedef const csObjEquipmentInfo_ListByOwnerDR_out_struct* csObjEquipmentInfo_ListByOwnerDR_out_struct_cvPtr;

class  csObjEquipmentInfo_ListByOwnerDR_out_struct_var
{
    public:

    csObjEquipmentInfo_ListByOwnerDR_out_struct_var ();

    csObjEquipmentInfo_ListByOwnerDR_out_struct_var (csObjEquipmentInfo_ListByOwnerDR_out_struct *_p);

    csObjEquipmentInfo_ListByOwnerDR_out_struct_var (const csObjEquipmentInfo_ListByOwnerDR_out_struct_var &_s);

    csObjEquipmentInfo_ListByOwnerDR_out_struct_var &operator= (csObjEquipmentInfo_ListByOwnerDR_out_struct *_p);

    csObjEquipmentInfo_ListByOwnerDR_out_struct_var &operator= (const csObjEquipmentInfo_ListByOwnerDR_out_struct_var &_s);

    ~csObjEquipmentInfo_ListByOwnerDR_out_struct_var ();

    csObjEquipmentInfo_ListByOwnerDR_out_struct* operator-> ();

    const csObjEquipmentInfo_ListByOwnerDR_out_struct& in() const;
    csObjEquipmentInfo_ListByOwnerDR_out_struct& inout();
    csObjEquipmentInfo_ListByOwnerDR_out_struct*& out();
    csObjEquipmentInfo_ListByOwnerDR_out_struct* _retn();

    operator csObjEquipmentInfo_ListByOwnerDR_out_struct_cvPtr () const;

    operator csObjEquipmentInfo_ListByOwnerDR_out_struct_vPtr& ();

    operator const csObjEquipmentInfo_ListByOwnerDR_out_struct& () const;

    operator csObjEquipmentInfo_ListByOwnerDR_out_struct& ();

    protected:
    csObjEquipmentInfo_ListByOwnerDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipmentInfo_ListByOwnerDR_out_struct;
    typedef csObjEquipmentInfo_ListByOwnerDR_out_struct csObjEquipmentInfo_ListByOwnerDR_out;
    typedef csObjEquipmentInfo_ListByOwnerDR_out_struct_var csObjEquipmentInfo_ListByOwnerDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipmentInfo_ListByOwnerDR_out;
    class  csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var;
    struct  csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct {
        typedef csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csMandPRecipeInfoSequence strMandPRecipeInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct();
       csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct(const csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct&);
       csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct& operator=(const csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct&);
       static CORBA::Info<csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct> csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct


typedef csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct* csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_vPtr;
typedef const csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct* csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_cvPtr;

class  csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var
{
    public:

    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var ();

    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var (csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct *_p);

    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var (const csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var &_s);

    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var &operator= (csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct *_p);

    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var &operator= (const csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var &_s);

    ~csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var ();

    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct* operator-> ();

    const csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct& in() const;
    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct& inout();
    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct*& out();
    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct* _retn();

    operator csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_cvPtr () const;

    operator csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_vPtr& ();

    operator const csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct& () const;

    operator csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct& ();

    protected:
    csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct;
    typedef csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out;
    typedef csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct_var csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out;
    class  csObjCassette_InspectionTime_Reset_out_struct_var;
    struct  csObjCassette_InspectionTime_Reset_out_struct {
        typedef csObjCassette_InspectionTime_Reset_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifier cassetteID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjCassette_InspectionTime_Reset_out_struct();
       csObjCassette_InspectionTime_Reset_out_struct(const csObjCassette_InspectionTime_Reset_out_struct&);
       csObjCassette_InspectionTime_Reset_out_struct& operator=(const csObjCassette_InspectionTime_Reset_out_struct&);
       static CORBA::Info<csObjCassette_InspectionTime_Reset_out_struct> csObjCassette_InspectionTime_Reset_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjCassette_InspectionTime_Reset_out_struct


typedef csObjCassette_InspectionTime_Reset_out_struct* csObjCassette_InspectionTime_Reset_out_struct_vPtr;
typedef const csObjCassette_InspectionTime_Reset_out_struct* csObjCassette_InspectionTime_Reset_out_struct_cvPtr;

class  csObjCassette_InspectionTime_Reset_out_struct_var
{
    public:

    csObjCassette_InspectionTime_Reset_out_struct_var ();

    csObjCassette_InspectionTime_Reset_out_struct_var (csObjCassette_InspectionTime_Reset_out_struct *_p);

    csObjCassette_InspectionTime_Reset_out_struct_var (const csObjCassette_InspectionTime_Reset_out_struct_var &_s);

    csObjCassette_InspectionTime_Reset_out_struct_var &operator= (csObjCassette_InspectionTime_Reset_out_struct *_p);

    csObjCassette_InspectionTime_Reset_out_struct_var &operator= (const csObjCassette_InspectionTime_Reset_out_struct_var &_s);

    ~csObjCassette_InspectionTime_Reset_out_struct_var ();

    csObjCassette_InspectionTime_Reset_out_struct* operator-> ();

    const csObjCassette_InspectionTime_Reset_out_struct& in() const;
    csObjCassette_InspectionTime_Reset_out_struct& inout();
    csObjCassette_InspectionTime_Reset_out_struct*& out();
    csObjCassette_InspectionTime_Reset_out_struct* _retn();

    operator csObjCassette_InspectionTime_Reset_out_struct_cvPtr () const;

    operator csObjCassette_InspectionTime_Reset_out_struct_vPtr& ();

    operator const csObjCassette_InspectionTime_Reset_out_struct& () const;

    operator csObjCassette_InspectionTime_Reset_out_struct& ();

    protected:
    csObjCassette_InspectionTime_Reset_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjCassette_InspectionTime_Reset_out_struct;
    typedef csObjCassette_InspectionTime_Reset_out_struct csObjCassette_InspectionTime_Reset_out;
    typedef csObjCassette_InspectionTime_Reset_out_struct_var csObjCassette_InspectionTime_Reset_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjCassette_InspectionTime_Reset_out;
    class  csObjCassette_PMTime_Reset_out_struct_var;
    struct  csObjCassette_PMTime_Reset_out_struct {
        typedef csObjCassette_PMTime_Reset_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifier cassetteID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjCassette_PMTime_Reset_out_struct();
       csObjCassette_PMTime_Reset_out_struct(const csObjCassette_PMTime_Reset_out_struct&);
       csObjCassette_PMTime_Reset_out_struct& operator=(const csObjCassette_PMTime_Reset_out_struct&);
       static CORBA::Info<csObjCassette_PMTime_Reset_out_struct> csObjCassette_PMTime_Reset_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjCassette_PMTime_Reset_out_struct


typedef csObjCassette_PMTime_Reset_out_struct* csObjCassette_PMTime_Reset_out_struct_vPtr;
typedef const csObjCassette_PMTime_Reset_out_struct* csObjCassette_PMTime_Reset_out_struct_cvPtr;

class  csObjCassette_PMTime_Reset_out_struct_var
{
    public:

    csObjCassette_PMTime_Reset_out_struct_var ();

    csObjCassette_PMTime_Reset_out_struct_var (csObjCassette_PMTime_Reset_out_struct *_p);

    csObjCassette_PMTime_Reset_out_struct_var (const csObjCassette_PMTime_Reset_out_struct_var &_s);

    csObjCassette_PMTime_Reset_out_struct_var &operator= (csObjCassette_PMTime_Reset_out_struct *_p);

    csObjCassette_PMTime_Reset_out_struct_var &operator= (const csObjCassette_PMTime_Reset_out_struct_var &_s);

    ~csObjCassette_PMTime_Reset_out_struct_var ();

    csObjCassette_PMTime_Reset_out_struct* operator-> ();

    const csObjCassette_PMTime_Reset_out_struct& in() const;
    csObjCassette_PMTime_Reset_out_struct& inout();
    csObjCassette_PMTime_Reset_out_struct*& out();
    csObjCassette_PMTime_Reset_out_struct* _retn();

    operator csObjCassette_PMTime_Reset_out_struct_cvPtr () const;

    operator csObjCassette_PMTime_Reset_out_struct_vPtr& ();

    operator const csObjCassette_PMTime_Reset_out_struct& () const;

    operator csObjCassette_PMTime_Reset_out_struct& ();

    protected:
    csObjCassette_PMTime_Reset_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjCassette_PMTime_Reset_out_struct;
    typedef csObjCassette_PMTime_Reset_out_struct csObjCassette_PMTime_Reset_out;
    typedef csObjCassette_PMTime_Reset_out_struct_var csObjCassette_PMTime_Reset_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjCassette_PMTime_Reset_out;
    class  csObjReticle_WaferCount_Reset_out_struct_var;
    struct  csObjReticle_WaferCount_Reset_out_struct {
        typedef csObjReticle_WaferCount_Reset_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifier reticleID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjReticle_WaferCount_Reset_out_struct();
       csObjReticle_WaferCount_Reset_out_struct(const csObjReticle_WaferCount_Reset_out_struct&);
       csObjReticle_WaferCount_Reset_out_struct& operator=(const csObjReticle_WaferCount_Reset_out_struct&);
       static CORBA::Info<csObjReticle_WaferCount_Reset_out_struct> csObjReticle_WaferCount_Reset_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjReticle_WaferCount_Reset_out_struct


typedef csObjReticle_WaferCount_Reset_out_struct* csObjReticle_WaferCount_Reset_out_struct_vPtr;
typedef const csObjReticle_WaferCount_Reset_out_struct* csObjReticle_WaferCount_Reset_out_struct_cvPtr;

class  csObjReticle_WaferCount_Reset_out_struct_var
{
    public:

    csObjReticle_WaferCount_Reset_out_struct_var ();

    csObjReticle_WaferCount_Reset_out_struct_var (csObjReticle_WaferCount_Reset_out_struct *_p);

    csObjReticle_WaferCount_Reset_out_struct_var (const csObjReticle_WaferCount_Reset_out_struct_var &_s);

    csObjReticle_WaferCount_Reset_out_struct_var &operator= (csObjReticle_WaferCount_Reset_out_struct *_p);

    csObjReticle_WaferCount_Reset_out_struct_var &operator= (const csObjReticle_WaferCount_Reset_out_struct_var &_s);

    ~csObjReticle_WaferCount_Reset_out_struct_var ();

    csObjReticle_WaferCount_Reset_out_struct* operator-> ();

    const csObjReticle_WaferCount_Reset_out_struct& in() const;
    csObjReticle_WaferCount_Reset_out_struct& inout();
    csObjReticle_WaferCount_Reset_out_struct*& out();
    csObjReticle_WaferCount_Reset_out_struct* _retn();

    operator csObjReticle_WaferCount_Reset_out_struct_cvPtr () const;

    operator csObjReticle_WaferCount_Reset_out_struct_vPtr& ();

    operator const csObjReticle_WaferCount_Reset_out_struct& () const;

    operator csObjReticle_WaferCount_Reset_out_struct& ();

    protected:
    csObjReticle_WaferCount_Reset_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Reset_out_struct;
    typedef csObjReticle_WaferCount_Reset_out_struct csObjReticle_WaferCount_Reset_out;
    typedef csObjReticle_WaferCount_Reset_out_struct_var csObjReticle_WaferCount_Reset_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Reset_out;
    class  csObjReticle_UsedDuration_Reset_out_struct_var;
    struct  csObjReticle_UsedDuration_Reset_out_struct {
        typedef csObjReticle_UsedDuration_Reset_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifier reticleID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjReticle_UsedDuration_Reset_out_struct();
       csObjReticle_UsedDuration_Reset_out_struct(const csObjReticle_UsedDuration_Reset_out_struct&);
       csObjReticle_UsedDuration_Reset_out_struct& operator=(const csObjReticle_UsedDuration_Reset_out_struct&);
       static CORBA::Info<csObjReticle_UsedDuration_Reset_out_struct> csObjReticle_UsedDuration_Reset_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjReticle_UsedDuration_Reset_out_struct


typedef csObjReticle_UsedDuration_Reset_out_struct* csObjReticle_UsedDuration_Reset_out_struct_vPtr;
typedef const csObjReticle_UsedDuration_Reset_out_struct* csObjReticle_UsedDuration_Reset_out_struct_cvPtr;

class  csObjReticle_UsedDuration_Reset_out_struct_var
{
    public:

    csObjReticle_UsedDuration_Reset_out_struct_var ();

    csObjReticle_UsedDuration_Reset_out_struct_var (csObjReticle_UsedDuration_Reset_out_struct *_p);

    csObjReticle_UsedDuration_Reset_out_struct_var (const csObjReticle_UsedDuration_Reset_out_struct_var &_s);

    csObjReticle_UsedDuration_Reset_out_struct_var &operator= (csObjReticle_UsedDuration_Reset_out_struct *_p);

    csObjReticle_UsedDuration_Reset_out_struct_var &operator= (const csObjReticle_UsedDuration_Reset_out_struct_var &_s);

    ~csObjReticle_UsedDuration_Reset_out_struct_var ();

    csObjReticle_UsedDuration_Reset_out_struct* operator-> ();

    const csObjReticle_UsedDuration_Reset_out_struct& in() const;
    csObjReticle_UsedDuration_Reset_out_struct& inout();
    csObjReticle_UsedDuration_Reset_out_struct*& out();
    csObjReticle_UsedDuration_Reset_out_struct* _retn();

    operator csObjReticle_UsedDuration_Reset_out_struct_cvPtr () const;

    operator csObjReticle_UsedDuration_Reset_out_struct_vPtr& ();

    operator const csObjReticle_UsedDuration_Reset_out_struct& () const;

    operator csObjReticle_UsedDuration_Reset_out_struct& ();

    protected:
    csObjReticle_UsedDuration_Reset_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_UsedDuration_Reset_out_struct;
    typedef csObjReticle_UsedDuration_Reset_out_struct csObjReticle_UsedDuration_Reset_out;
    typedef csObjReticle_UsedDuration_Reset_out_struct_var csObjReticle_UsedDuration_Reset_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_UsedDuration_Reset_out;
    class  csObjReticle_WaferCount_Increment_out_struct_var;
    struct  csObjReticle_WaferCount_Increment_out_struct {
        typedef csObjReticle_WaferCount_Increment_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjReticle_WaferCount_Increment_out_struct();
       csObjReticle_WaferCount_Increment_out_struct(const csObjReticle_WaferCount_Increment_out_struct&);
       csObjReticle_WaferCount_Increment_out_struct& operator=(const csObjReticle_WaferCount_Increment_out_struct&);
       static CORBA::Info<csObjReticle_WaferCount_Increment_out_struct> csObjReticle_WaferCount_Increment_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjReticle_WaferCount_Increment_out_struct


typedef csObjReticle_WaferCount_Increment_out_struct* csObjReticle_WaferCount_Increment_out_struct_vPtr;
typedef const csObjReticle_WaferCount_Increment_out_struct* csObjReticle_WaferCount_Increment_out_struct_cvPtr;

class  csObjReticle_WaferCount_Increment_out_struct_var
{
    public:

    csObjReticle_WaferCount_Increment_out_struct_var ();

    csObjReticle_WaferCount_Increment_out_struct_var (csObjReticle_WaferCount_Increment_out_struct *_p);

    csObjReticle_WaferCount_Increment_out_struct_var (const csObjReticle_WaferCount_Increment_out_struct_var &_s);

    csObjReticle_WaferCount_Increment_out_struct_var &operator= (csObjReticle_WaferCount_Increment_out_struct *_p);

    csObjReticle_WaferCount_Increment_out_struct_var &operator= (const csObjReticle_WaferCount_Increment_out_struct_var &_s);

    ~csObjReticle_WaferCount_Increment_out_struct_var ();

    csObjReticle_WaferCount_Increment_out_struct* operator-> ();

    const csObjReticle_WaferCount_Increment_out_struct& in() const;
    csObjReticle_WaferCount_Increment_out_struct& inout();
    csObjReticle_WaferCount_Increment_out_struct*& out();
    csObjReticle_WaferCount_Increment_out_struct* _retn();

    operator csObjReticle_WaferCount_Increment_out_struct_cvPtr () const;

    operator csObjReticle_WaferCount_Increment_out_struct_vPtr& ();

    operator const csObjReticle_WaferCount_Increment_out_struct& () const;

    operator csObjReticle_WaferCount_Increment_out_struct& ();

    protected:
    csObjReticle_WaferCount_Increment_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Increment_out_struct;
    typedef csObjReticle_WaferCount_Increment_out_struct csObjReticle_WaferCount_Increment_out;
    typedef csObjReticle_WaferCount_Increment_out_struct_var csObjReticle_WaferCount_Increment_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Increment_out;
    class  csObjReticle_WaferCount_Increment_in_struct_var;
    struct  csObjReticle_WaferCount_Increment_in_struct {
        typedef csObjReticle_WaferCount_Increment_in_struct_var _var_type;
       ::objectIdentifier reticleID;
       ::CORBA::Long waferCount;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjReticle_WaferCount_Increment_in_struct();
       csObjReticle_WaferCount_Increment_in_struct(const csObjReticle_WaferCount_Increment_in_struct&);
       csObjReticle_WaferCount_Increment_in_struct& operator=(const csObjReticle_WaferCount_Increment_in_struct&);
       static CORBA::Info<csObjReticle_WaferCount_Increment_in_struct> csObjReticle_WaferCount_Increment_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjReticle_WaferCount_Increment_in_struct


typedef csObjReticle_WaferCount_Increment_in_struct* csObjReticle_WaferCount_Increment_in_struct_vPtr;
typedef const csObjReticle_WaferCount_Increment_in_struct* csObjReticle_WaferCount_Increment_in_struct_cvPtr;

class  csObjReticle_WaferCount_Increment_in_struct_var
{
    public:

    csObjReticle_WaferCount_Increment_in_struct_var ();

    csObjReticle_WaferCount_Increment_in_struct_var (csObjReticle_WaferCount_Increment_in_struct *_p);

    csObjReticle_WaferCount_Increment_in_struct_var (const csObjReticle_WaferCount_Increment_in_struct_var &_s);

    csObjReticle_WaferCount_Increment_in_struct_var &operator= (csObjReticle_WaferCount_Increment_in_struct *_p);

    csObjReticle_WaferCount_Increment_in_struct_var &operator= (const csObjReticle_WaferCount_Increment_in_struct_var &_s);

    ~csObjReticle_WaferCount_Increment_in_struct_var ();

    csObjReticle_WaferCount_Increment_in_struct* operator-> ();

    const csObjReticle_WaferCount_Increment_in_struct& in() const;
    csObjReticle_WaferCount_Increment_in_struct& inout();
    csObjReticle_WaferCount_Increment_in_struct*& out();
    csObjReticle_WaferCount_Increment_in_struct* _retn();

    operator csObjReticle_WaferCount_Increment_in_struct_cvPtr () const;

    operator csObjReticle_WaferCount_Increment_in_struct_vPtr& ();

    operator const csObjReticle_WaferCount_Increment_in_struct& () const;

    operator csObjReticle_WaferCount_Increment_in_struct& ();

    protected:
    csObjReticle_WaferCount_Increment_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Increment_in_struct;
    typedef csObjReticle_WaferCount_Increment_in_struct csObjReticle_WaferCount_Increment_in;
    typedef csObjReticle_WaferCount_Increment_in_struct_var csObjReticle_WaferCount_Increment_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Increment_in;
    class  csObjReticle_WaferCount_Decrement_out_struct_var;
    struct  csObjReticle_WaferCount_Decrement_out_struct {
        typedef csObjReticle_WaferCount_Decrement_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjReticle_WaferCount_Decrement_out_struct();
       csObjReticle_WaferCount_Decrement_out_struct(const csObjReticle_WaferCount_Decrement_out_struct&);
       csObjReticle_WaferCount_Decrement_out_struct& operator=(const csObjReticle_WaferCount_Decrement_out_struct&);
       static CORBA::Info<csObjReticle_WaferCount_Decrement_out_struct> csObjReticle_WaferCount_Decrement_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjReticle_WaferCount_Decrement_out_struct


typedef csObjReticle_WaferCount_Decrement_out_struct* csObjReticle_WaferCount_Decrement_out_struct_vPtr;
typedef const csObjReticle_WaferCount_Decrement_out_struct* csObjReticle_WaferCount_Decrement_out_struct_cvPtr;

class  csObjReticle_WaferCount_Decrement_out_struct_var
{
    public:

    csObjReticle_WaferCount_Decrement_out_struct_var ();

    csObjReticle_WaferCount_Decrement_out_struct_var (csObjReticle_WaferCount_Decrement_out_struct *_p);

    csObjReticle_WaferCount_Decrement_out_struct_var (const csObjReticle_WaferCount_Decrement_out_struct_var &_s);

    csObjReticle_WaferCount_Decrement_out_struct_var &operator= (csObjReticle_WaferCount_Decrement_out_struct *_p);

    csObjReticle_WaferCount_Decrement_out_struct_var &operator= (const csObjReticle_WaferCount_Decrement_out_struct_var &_s);

    ~csObjReticle_WaferCount_Decrement_out_struct_var ();

    csObjReticle_WaferCount_Decrement_out_struct* operator-> ();

    const csObjReticle_WaferCount_Decrement_out_struct& in() const;
    csObjReticle_WaferCount_Decrement_out_struct& inout();
    csObjReticle_WaferCount_Decrement_out_struct*& out();
    csObjReticle_WaferCount_Decrement_out_struct* _retn();

    operator csObjReticle_WaferCount_Decrement_out_struct_cvPtr () const;

    operator csObjReticle_WaferCount_Decrement_out_struct_vPtr& ();

    operator const csObjReticle_WaferCount_Decrement_out_struct& () const;

    operator csObjReticle_WaferCount_Decrement_out_struct& ();

    protected:
    csObjReticle_WaferCount_Decrement_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Decrement_out_struct;
    typedef csObjReticle_WaferCount_Decrement_out_struct csObjReticle_WaferCount_Decrement_out;
    typedef csObjReticle_WaferCount_Decrement_out_struct_var csObjReticle_WaferCount_Decrement_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Decrement_out;
    class  csObjReticle_WaferCount_Decrement_in_struct_var;
    struct  csObjReticle_WaferCount_Decrement_in_struct {
        typedef csObjReticle_WaferCount_Decrement_in_struct_var _var_type;
       ::objectIdentifier reticleID;
       ::CORBA::Long waferCount;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjReticle_WaferCount_Decrement_in_struct();
       csObjReticle_WaferCount_Decrement_in_struct(const csObjReticle_WaferCount_Decrement_in_struct&);
       csObjReticle_WaferCount_Decrement_in_struct& operator=(const csObjReticle_WaferCount_Decrement_in_struct&);
       static CORBA::Info<csObjReticle_WaferCount_Decrement_in_struct> csObjReticle_WaferCount_Decrement_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjReticle_WaferCount_Decrement_in_struct


typedef csObjReticle_WaferCount_Decrement_in_struct* csObjReticle_WaferCount_Decrement_in_struct_vPtr;
typedef const csObjReticle_WaferCount_Decrement_in_struct* csObjReticle_WaferCount_Decrement_in_struct_cvPtr;

class  csObjReticle_WaferCount_Decrement_in_struct_var
{
    public:

    csObjReticle_WaferCount_Decrement_in_struct_var ();

    csObjReticle_WaferCount_Decrement_in_struct_var (csObjReticle_WaferCount_Decrement_in_struct *_p);

    csObjReticle_WaferCount_Decrement_in_struct_var (const csObjReticle_WaferCount_Decrement_in_struct_var &_s);

    csObjReticle_WaferCount_Decrement_in_struct_var &operator= (csObjReticle_WaferCount_Decrement_in_struct *_p);

    csObjReticle_WaferCount_Decrement_in_struct_var &operator= (const csObjReticle_WaferCount_Decrement_in_struct_var &_s);

    ~csObjReticle_WaferCount_Decrement_in_struct_var ();

    csObjReticle_WaferCount_Decrement_in_struct* operator-> ();

    const csObjReticle_WaferCount_Decrement_in_struct& in() const;
    csObjReticle_WaferCount_Decrement_in_struct& inout();
    csObjReticle_WaferCount_Decrement_in_struct*& out();
    csObjReticle_WaferCount_Decrement_in_struct* _retn();

    operator csObjReticle_WaferCount_Decrement_in_struct_cvPtr () const;

    operator csObjReticle_WaferCount_Decrement_in_struct_vPtr& ();

    operator const csObjReticle_WaferCount_Decrement_in_struct& () const;

    operator csObjReticle_WaferCount_Decrement_in_struct& ();

    protected:
    csObjReticle_WaferCount_Decrement_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Decrement_in_struct;
    typedef csObjReticle_WaferCount_Decrement_in_struct csObjReticle_WaferCount_Decrement_in;
    typedef csObjReticle_WaferCount_Decrement_in_struct_var csObjReticle_WaferCount_Decrement_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjReticle_WaferCount_Decrement_in;
    class  csObjUserData_GetByLotOperation_out_struct_var;
    struct  csObjUserData_GetByLotOperation_out_struct {
        typedef csObjUserData_GetByLotOperation_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::pptUserDataSequence strUserDataSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjUserData_GetByLotOperation_out_struct();
       csObjUserData_GetByLotOperation_out_struct(const csObjUserData_GetByLotOperation_out_struct&);
       csObjUserData_GetByLotOperation_out_struct& operator=(const csObjUserData_GetByLotOperation_out_struct&);
       static CORBA::Info<csObjUserData_GetByLotOperation_out_struct> csObjUserData_GetByLotOperation_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjUserData_GetByLotOperation_out_struct


typedef csObjUserData_GetByLotOperation_out_struct* csObjUserData_GetByLotOperation_out_struct_vPtr;
typedef const csObjUserData_GetByLotOperation_out_struct* csObjUserData_GetByLotOperation_out_struct_cvPtr;

class  csObjUserData_GetByLotOperation_out_struct_var
{
    public:

    csObjUserData_GetByLotOperation_out_struct_var ();

    csObjUserData_GetByLotOperation_out_struct_var (csObjUserData_GetByLotOperation_out_struct *_p);

    csObjUserData_GetByLotOperation_out_struct_var (const csObjUserData_GetByLotOperation_out_struct_var &_s);

    csObjUserData_GetByLotOperation_out_struct_var &operator= (csObjUserData_GetByLotOperation_out_struct *_p);

    csObjUserData_GetByLotOperation_out_struct_var &operator= (const csObjUserData_GetByLotOperation_out_struct_var &_s);

    ~csObjUserData_GetByLotOperation_out_struct_var ();

    csObjUserData_GetByLotOperation_out_struct* operator-> ();

    const csObjUserData_GetByLotOperation_out_struct& in() const;
    csObjUserData_GetByLotOperation_out_struct& inout();
    csObjUserData_GetByLotOperation_out_struct*& out();
    csObjUserData_GetByLotOperation_out_struct* _retn();

    operator csObjUserData_GetByLotOperation_out_struct_cvPtr () const;

    operator csObjUserData_GetByLotOperation_out_struct_vPtr& ();

    operator const csObjUserData_GetByLotOperation_out_struct& () const;

    operator csObjUserData_GetByLotOperation_out_struct& ();

    protected:
    csObjUserData_GetByLotOperation_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjUserData_GetByLotOperation_out_struct;
    typedef csObjUserData_GetByLotOperation_out_struct csObjUserData_GetByLotOperation_out;
    typedef csObjUserData_GetByLotOperation_out_struct_var csObjUserData_GetByLotOperation_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjUserData_GetByLotOperation_out;
    class  csObjUserData_GetByLotOperation_in_struct_var;
    struct  csObjUserData_GetByLotOperation_in_struct {
        typedef csObjUserData_GetByLotOperation_in_struct_var _var_type;
       ::objectIdentifier lotID;
       ::stringSequence userDataNameSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjUserData_GetByLotOperation_in_struct();
       csObjUserData_GetByLotOperation_in_struct(const csObjUserData_GetByLotOperation_in_struct&);
       csObjUserData_GetByLotOperation_in_struct& operator=(const csObjUserData_GetByLotOperation_in_struct&);
       static CORBA::Info<csObjUserData_GetByLotOperation_in_struct> csObjUserData_GetByLotOperation_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjUserData_GetByLotOperation_in_struct


typedef csObjUserData_GetByLotOperation_in_struct* csObjUserData_GetByLotOperation_in_struct_vPtr;
typedef const csObjUserData_GetByLotOperation_in_struct* csObjUserData_GetByLotOperation_in_struct_cvPtr;

class  csObjUserData_GetByLotOperation_in_struct_var
{
    public:

    csObjUserData_GetByLotOperation_in_struct_var ();

    csObjUserData_GetByLotOperation_in_struct_var (csObjUserData_GetByLotOperation_in_struct *_p);

    csObjUserData_GetByLotOperation_in_struct_var (const csObjUserData_GetByLotOperation_in_struct_var &_s);

    csObjUserData_GetByLotOperation_in_struct_var &operator= (csObjUserData_GetByLotOperation_in_struct *_p);

    csObjUserData_GetByLotOperation_in_struct_var &operator= (const csObjUserData_GetByLotOperation_in_struct_var &_s);

    ~csObjUserData_GetByLotOperation_in_struct_var ();

    csObjUserData_GetByLotOperation_in_struct* operator-> ();

    const csObjUserData_GetByLotOperation_in_struct& in() const;
    csObjUserData_GetByLotOperation_in_struct& inout();
    csObjUserData_GetByLotOperation_in_struct*& out();
    csObjUserData_GetByLotOperation_in_struct* _retn();

    operator csObjUserData_GetByLotOperation_in_struct_cvPtr () const;

    operator csObjUserData_GetByLotOperation_in_struct_vPtr& ();

    operator const csObjUserData_GetByLotOperation_in_struct& () const;

    operator csObjUserData_GetByLotOperation_in_struct& ();

    protected:
    csObjUserData_GetByLotOperation_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjUserData_GetByLotOperation_in_struct;
    typedef csObjUserData_GetByLotOperation_in_struct csObjUserData_GetByLotOperation_in;
    typedef csObjUserData_GetByLotOperation_in_struct_var csObjUserData_GetByLotOperation_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjUserData_GetByLotOperation_in;
    class  csObjReticlePod_Empty_Check_out_struct_var;
    struct  csObjReticlePod_Empty_Check_out_struct {
        typedef csObjReticlePod_Empty_Check_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Boolean isEmpty;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjReticlePod_Empty_Check_out_struct();
       csObjReticlePod_Empty_Check_out_struct(const csObjReticlePod_Empty_Check_out_struct&);
       csObjReticlePod_Empty_Check_out_struct& operator=(const csObjReticlePod_Empty_Check_out_struct&);
       static CORBA::Info<csObjReticlePod_Empty_Check_out_struct> csObjReticlePod_Empty_Check_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjReticlePod_Empty_Check_out_struct


typedef csObjReticlePod_Empty_Check_out_struct* csObjReticlePod_Empty_Check_out_struct_vPtr;
typedef const csObjReticlePod_Empty_Check_out_struct* csObjReticlePod_Empty_Check_out_struct_cvPtr;

class  csObjReticlePod_Empty_Check_out_struct_var
{
    public:

    csObjReticlePod_Empty_Check_out_struct_var ();

    csObjReticlePod_Empty_Check_out_struct_var (csObjReticlePod_Empty_Check_out_struct *_p);

    csObjReticlePod_Empty_Check_out_struct_var (const csObjReticlePod_Empty_Check_out_struct_var &_s);

    csObjReticlePod_Empty_Check_out_struct_var &operator= (csObjReticlePod_Empty_Check_out_struct *_p);

    csObjReticlePod_Empty_Check_out_struct_var &operator= (const csObjReticlePod_Empty_Check_out_struct_var &_s);

    ~csObjReticlePod_Empty_Check_out_struct_var ();

    csObjReticlePod_Empty_Check_out_struct* operator-> ();

    const csObjReticlePod_Empty_Check_out_struct& in() const;
    csObjReticlePod_Empty_Check_out_struct& inout();
    csObjReticlePod_Empty_Check_out_struct*& out();
    csObjReticlePod_Empty_Check_out_struct* _retn();

    operator csObjReticlePod_Empty_Check_out_struct_cvPtr () const;

    operator csObjReticlePod_Empty_Check_out_struct_vPtr& ();

    operator const csObjReticlePod_Empty_Check_out_struct& () const;

    operator csObjReticlePod_Empty_Check_out_struct& ();

    protected:
    csObjReticlePod_Empty_Check_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjReticlePod_Empty_Check_out_struct;
    typedef csObjReticlePod_Empty_Check_out_struct csObjReticlePod_Empty_Check_out;
    typedef csObjReticlePod_Empty_Check_out_struct_var csObjReticlePod_Empty_Check_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjReticlePod_Empty_Check_out;
    class  csObjReticlePod_Empty_Check_in_struct_var;
    struct  csObjReticlePod_Empty_Check_in_struct {
        typedef csObjReticlePod_Empty_Check_in_struct_var _var_type;
       ::objectIdentifier reticlePodID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjReticlePod_Empty_Check_in_struct();
       csObjReticlePod_Empty_Check_in_struct(const csObjReticlePod_Empty_Check_in_struct&);
       csObjReticlePod_Empty_Check_in_struct& operator=(const csObjReticlePod_Empty_Check_in_struct&);
       static CORBA::Info<csObjReticlePod_Empty_Check_in_struct> csObjReticlePod_Empty_Check_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjReticlePod_Empty_Check_in_struct


typedef csObjReticlePod_Empty_Check_in_struct* csObjReticlePod_Empty_Check_in_struct_vPtr;
typedef const csObjReticlePod_Empty_Check_in_struct* csObjReticlePod_Empty_Check_in_struct_cvPtr;

class  csObjReticlePod_Empty_Check_in_struct_var
{
    public:

    csObjReticlePod_Empty_Check_in_struct_var ();

    csObjReticlePod_Empty_Check_in_struct_var (csObjReticlePod_Empty_Check_in_struct *_p);

    csObjReticlePod_Empty_Check_in_struct_var (const csObjReticlePod_Empty_Check_in_struct_var &_s);

    csObjReticlePod_Empty_Check_in_struct_var &operator= (csObjReticlePod_Empty_Check_in_struct *_p);

    csObjReticlePod_Empty_Check_in_struct_var &operator= (const csObjReticlePod_Empty_Check_in_struct_var &_s);

    ~csObjReticlePod_Empty_Check_in_struct_var ();

    csObjReticlePod_Empty_Check_in_struct* operator-> ();

    const csObjReticlePod_Empty_Check_in_struct& in() const;
    csObjReticlePod_Empty_Check_in_struct& inout();
    csObjReticlePod_Empty_Check_in_struct*& out();
    csObjReticlePod_Empty_Check_in_struct* _retn();

    operator csObjReticlePod_Empty_Check_in_struct_cvPtr () const;

    operator csObjReticlePod_Empty_Check_in_struct_vPtr& ();

    operator const csObjReticlePod_Empty_Check_in_struct& () const;

    operator csObjReticlePod_Empty_Check_in_struct& ();

    protected:
    csObjReticlePod_Empty_Check_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjReticlePod_Empty_Check_in_struct;
    typedef csObjReticlePod_Empty_Check_in_struct csObjReticlePod_Empty_Check_in;
    typedef csObjReticlePod_Empty_Check_in_struct_var csObjReticlePod_Empty_Check_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjReticlePod_Empty_Check_in;
    typedef objBase_out csObjVendorLotReserve_AddDR_out;
    typedef objBase_out_var csObjVendorLotReserve_AddDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjVendorLotReserve_AddDR_out;
    typedef objBase_out csObjVendorLotReserve_DelDR_out;
    typedef objBase_out_var csObjVendorLotReserve_DelDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjVendorLotReserve_DelDR_out;
    class  csObjVendorLotReserve_SelDR_out_struct_var;
    struct  csObjVendorLotReserve_SelDR_out_struct {
        typedef csObjVendorLotReserve_SelDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csVendorLotReserveDataSequence strVendorLotReserveDataSequence;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjVendorLotReserve_SelDR_out_struct();
       csObjVendorLotReserve_SelDR_out_struct(const csObjVendorLotReserve_SelDR_out_struct&);
       csObjVendorLotReserve_SelDR_out_struct& operator=(const csObjVendorLotReserve_SelDR_out_struct&);
       static CORBA::Info<csObjVendorLotReserve_SelDR_out_struct> csObjVendorLotReserve_SelDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjVendorLotReserve_SelDR_out_struct


typedef csObjVendorLotReserve_SelDR_out_struct* csObjVendorLotReserve_SelDR_out_struct_vPtr;
typedef const csObjVendorLotReserve_SelDR_out_struct* csObjVendorLotReserve_SelDR_out_struct_cvPtr;

class  csObjVendorLotReserve_SelDR_out_struct_var
{
    public:

    csObjVendorLotReserve_SelDR_out_struct_var ();

    csObjVendorLotReserve_SelDR_out_struct_var (csObjVendorLotReserve_SelDR_out_struct *_p);

    csObjVendorLotReserve_SelDR_out_struct_var (const csObjVendorLotReserve_SelDR_out_struct_var &_s);

    csObjVendorLotReserve_SelDR_out_struct_var &operator= (csObjVendorLotReserve_SelDR_out_struct *_p);

    csObjVendorLotReserve_SelDR_out_struct_var &operator= (const csObjVendorLotReserve_SelDR_out_struct_var &_s);

    ~csObjVendorLotReserve_SelDR_out_struct_var ();

    csObjVendorLotReserve_SelDR_out_struct* operator-> ();

    const csObjVendorLotReserve_SelDR_out_struct& in() const;
    csObjVendorLotReserve_SelDR_out_struct& inout();
    csObjVendorLotReserve_SelDR_out_struct*& out();
    csObjVendorLotReserve_SelDR_out_struct* _retn();

    operator csObjVendorLotReserve_SelDR_out_struct_cvPtr () const;

    operator csObjVendorLotReserve_SelDR_out_struct_vPtr& ();

    operator const csObjVendorLotReserve_SelDR_out_struct& () const;

    operator csObjVendorLotReserve_SelDR_out_struct& ();

    protected:
    csObjVendorLotReserve_SelDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjVendorLotReserve_SelDR_out_struct;
    typedef csObjVendorLotReserve_SelDR_out_struct csObjVendorLotReserve_SelDR_out;
    typedef csObjVendorLotReserve_SelDR_out_struct_var csObjVendorLotReserve_SelDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjVendorLotReserve_SelDR_out;
    class  csObjLot_ContaminationInfo_Get_in_struct_var;
    struct  csObjLot_ContaminationInfo_Get_in_struct {
        typedef csObjLot_ContaminationInfo_Get_in_struct_var _var_type;
       ::objectIdentifier lotID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_ContaminationInfo_Get_in_struct();
       csObjLot_ContaminationInfo_Get_in_struct(const csObjLot_ContaminationInfo_Get_in_struct&);
       csObjLot_ContaminationInfo_Get_in_struct& operator=(const csObjLot_ContaminationInfo_Get_in_struct&);
       static CORBA::Info<csObjLot_ContaminationInfo_Get_in_struct> csObjLot_ContaminationInfo_Get_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_ContaminationInfo_Get_in_struct


typedef csObjLot_ContaminationInfo_Get_in_struct* csObjLot_ContaminationInfo_Get_in_struct_vPtr;
typedef const csObjLot_ContaminationInfo_Get_in_struct* csObjLot_ContaminationInfo_Get_in_struct_cvPtr;

class  csObjLot_ContaminationInfo_Get_in_struct_var
{
    public:

    csObjLot_ContaminationInfo_Get_in_struct_var ();

    csObjLot_ContaminationInfo_Get_in_struct_var (csObjLot_ContaminationInfo_Get_in_struct *_p);

    csObjLot_ContaminationInfo_Get_in_struct_var (const csObjLot_ContaminationInfo_Get_in_struct_var &_s);

    csObjLot_ContaminationInfo_Get_in_struct_var &operator= (csObjLot_ContaminationInfo_Get_in_struct *_p);

    csObjLot_ContaminationInfo_Get_in_struct_var &operator= (const csObjLot_ContaminationInfo_Get_in_struct_var &_s);

    ~csObjLot_ContaminationInfo_Get_in_struct_var ();

    csObjLot_ContaminationInfo_Get_in_struct* operator-> ();

    const csObjLot_ContaminationInfo_Get_in_struct& in() const;
    csObjLot_ContaminationInfo_Get_in_struct& inout();
    csObjLot_ContaminationInfo_Get_in_struct*& out();
    csObjLot_ContaminationInfo_Get_in_struct* _retn();

    operator csObjLot_ContaminationInfo_Get_in_struct_cvPtr () const;

    operator csObjLot_ContaminationInfo_Get_in_struct_vPtr& ();

    operator const csObjLot_ContaminationInfo_Get_in_struct& () const;

    operator csObjLot_ContaminationInfo_Get_in_struct& ();

    protected:
    csObjLot_ContaminationInfo_Get_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_Get_in_struct;
    typedef csObjLot_ContaminationInfo_Get_in_struct csObjLot_ContaminationInfo_Get_in;
    typedef csObjLot_ContaminationInfo_Get_in_struct_var csObjLot_ContaminationInfo_Get_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_Get_in;
    class  csObjLot_ContaminationInfo_Get_out_struct_var;
    struct  csObjLot_ContaminationInfo_Get_out_struct {
        typedef csObjLot_ContaminationInfo_Get_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csLotContaminationInfo strLotContaminationInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_ContaminationInfo_Get_out_struct();
       csObjLot_ContaminationInfo_Get_out_struct(const csObjLot_ContaminationInfo_Get_out_struct&);
       csObjLot_ContaminationInfo_Get_out_struct& operator=(const csObjLot_ContaminationInfo_Get_out_struct&);
       static CORBA::Info<csObjLot_ContaminationInfo_Get_out_struct> csObjLot_ContaminationInfo_Get_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_ContaminationInfo_Get_out_struct


typedef csObjLot_ContaminationInfo_Get_out_struct* csObjLot_ContaminationInfo_Get_out_struct_vPtr;
typedef const csObjLot_ContaminationInfo_Get_out_struct* csObjLot_ContaminationInfo_Get_out_struct_cvPtr;

class  csObjLot_ContaminationInfo_Get_out_struct_var
{
    public:

    csObjLot_ContaminationInfo_Get_out_struct_var ();

    csObjLot_ContaminationInfo_Get_out_struct_var (csObjLot_ContaminationInfo_Get_out_struct *_p);

    csObjLot_ContaminationInfo_Get_out_struct_var (const csObjLot_ContaminationInfo_Get_out_struct_var &_s);

    csObjLot_ContaminationInfo_Get_out_struct_var &operator= (csObjLot_ContaminationInfo_Get_out_struct *_p);

    csObjLot_ContaminationInfo_Get_out_struct_var &operator= (const csObjLot_ContaminationInfo_Get_out_struct_var &_s);

    ~csObjLot_ContaminationInfo_Get_out_struct_var ();

    csObjLot_ContaminationInfo_Get_out_struct* operator-> ();

    const csObjLot_ContaminationInfo_Get_out_struct& in() const;
    csObjLot_ContaminationInfo_Get_out_struct& inout();
    csObjLot_ContaminationInfo_Get_out_struct*& out();
    csObjLot_ContaminationInfo_Get_out_struct* _retn();

    operator csObjLot_ContaminationInfo_Get_out_struct_cvPtr () const;

    operator csObjLot_ContaminationInfo_Get_out_struct_vPtr& ();

    operator const csObjLot_ContaminationInfo_Get_out_struct& () const;

    operator csObjLot_ContaminationInfo_Get_out_struct& ();

    protected:
    csObjLot_ContaminationInfo_Get_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_Get_out_struct;
    typedef csObjLot_ContaminationInfo_Get_out_struct csObjLot_ContaminationInfo_Get_out;
    typedef csObjLot_ContaminationInfo_Get_out_struct_var csObjLot_ContaminationInfo_Get_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_Get_out;
    class  csObjLot_ContaminationInfo_Set_in_struct_var;
    struct  csObjLot_ContaminationInfo_Set_in_struct {
        typedef csObjLot_ContaminationInfo_Set_in_struct_var _var_type;
       ::objectIdentifier lotID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_ContaminationInfo_Set_in_struct();
       csObjLot_ContaminationInfo_Set_in_struct(const csObjLot_ContaminationInfo_Set_in_struct&);
       csObjLot_ContaminationInfo_Set_in_struct& operator=(const csObjLot_ContaminationInfo_Set_in_struct&);
       static CORBA::Info<csObjLot_ContaminationInfo_Set_in_struct> csObjLot_ContaminationInfo_Set_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_ContaminationInfo_Set_in_struct


typedef csObjLot_ContaminationInfo_Set_in_struct* csObjLot_ContaminationInfo_Set_in_struct_vPtr;
typedef const csObjLot_ContaminationInfo_Set_in_struct* csObjLot_ContaminationInfo_Set_in_struct_cvPtr;

class  csObjLot_ContaminationInfo_Set_in_struct_var
{
    public:

    csObjLot_ContaminationInfo_Set_in_struct_var ();

    csObjLot_ContaminationInfo_Set_in_struct_var (csObjLot_ContaminationInfo_Set_in_struct *_p);

    csObjLot_ContaminationInfo_Set_in_struct_var (const csObjLot_ContaminationInfo_Set_in_struct_var &_s);

    csObjLot_ContaminationInfo_Set_in_struct_var &operator= (csObjLot_ContaminationInfo_Set_in_struct *_p);

    csObjLot_ContaminationInfo_Set_in_struct_var &operator= (const csObjLot_ContaminationInfo_Set_in_struct_var &_s);

    ~csObjLot_ContaminationInfo_Set_in_struct_var ();

    csObjLot_ContaminationInfo_Set_in_struct* operator-> ();

    const csObjLot_ContaminationInfo_Set_in_struct& in() const;
    csObjLot_ContaminationInfo_Set_in_struct& inout();
    csObjLot_ContaminationInfo_Set_in_struct*& out();
    csObjLot_ContaminationInfo_Set_in_struct* _retn();

    operator csObjLot_ContaminationInfo_Set_in_struct_cvPtr () const;

    operator csObjLot_ContaminationInfo_Set_in_struct_vPtr& ();

    operator const csObjLot_ContaminationInfo_Set_in_struct& () const;

    operator csObjLot_ContaminationInfo_Set_in_struct& ();

    protected:
    csObjLot_ContaminationInfo_Set_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_Set_in_struct;
    typedef csObjLot_ContaminationInfo_Set_in_struct csObjLot_ContaminationInfo_Set_in;
    typedef csObjLot_ContaminationInfo_Set_in_struct_var csObjLot_ContaminationInfo_Set_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_Set_in;
    typedef objBase_out csObjLot_ContaminationInfo_Set_out;
    typedef objBase_out_var csObjLot_ContaminationInfo_Set_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_Set_out;
    class  csObjLot_ContaminationInfo_CheckForMove_in_struct_var;
    struct  csObjLot_ContaminationInfo_CheckForMove_in_struct {
        typedef csObjLot_ContaminationInfo_CheckForMove_in_struct_var _var_type;
       ::objectIdentifier lotID;
       ::objectIdentifier carrierID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_ContaminationInfo_CheckForMove_in_struct();
       csObjLot_ContaminationInfo_CheckForMove_in_struct(const csObjLot_ContaminationInfo_CheckForMove_in_struct&);
       csObjLot_ContaminationInfo_CheckForMove_in_struct& operator=(const csObjLot_ContaminationInfo_CheckForMove_in_struct&);
       static CORBA::Info<csObjLot_ContaminationInfo_CheckForMove_in_struct> csObjLot_ContaminationInfo_CheckForMove_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_ContaminationInfo_CheckForMove_in_struct


typedef csObjLot_ContaminationInfo_CheckForMove_in_struct* csObjLot_ContaminationInfo_CheckForMove_in_struct_vPtr;
typedef const csObjLot_ContaminationInfo_CheckForMove_in_struct* csObjLot_ContaminationInfo_CheckForMove_in_struct_cvPtr;

class  csObjLot_ContaminationInfo_CheckForMove_in_struct_var
{
    public:

    csObjLot_ContaminationInfo_CheckForMove_in_struct_var ();

    csObjLot_ContaminationInfo_CheckForMove_in_struct_var (csObjLot_ContaminationInfo_CheckForMove_in_struct *_p);

    csObjLot_ContaminationInfo_CheckForMove_in_struct_var (const csObjLot_ContaminationInfo_CheckForMove_in_struct_var &_s);

    csObjLot_ContaminationInfo_CheckForMove_in_struct_var &operator= (csObjLot_ContaminationInfo_CheckForMove_in_struct *_p);

    csObjLot_ContaminationInfo_CheckForMove_in_struct_var &operator= (const csObjLot_ContaminationInfo_CheckForMove_in_struct_var &_s);

    ~csObjLot_ContaminationInfo_CheckForMove_in_struct_var ();

    csObjLot_ContaminationInfo_CheckForMove_in_struct* operator-> ();

    const csObjLot_ContaminationInfo_CheckForMove_in_struct& in() const;
    csObjLot_ContaminationInfo_CheckForMove_in_struct& inout();
    csObjLot_ContaminationInfo_CheckForMove_in_struct*& out();
    csObjLot_ContaminationInfo_CheckForMove_in_struct* _retn();

    operator csObjLot_ContaminationInfo_CheckForMove_in_struct_cvPtr () const;

    operator csObjLot_ContaminationInfo_CheckForMove_in_struct_vPtr& ();

    operator const csObjLot_ContaminationInfo_CheckForMove_in_struct& () const;

    operator csObjLot_ContaminationInfo_CheckForMove_in_struct& ();

    protected:
    csObjLot_ContaminationInfo_CheckForMove_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForMove_in_struct;
    typedef csObjLot_ContaminationInfo_CheckForMove_in_struct csObjLot_ContaminationInfo_CheckForMove_in;
    typedef csObjLot_ContaminationInfo_CheckForMove_in_struct_var csObjLot_ContaminationInfo_CheckForMove_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForMove_in;
    class  csObjLot_ContaminationInfo_CheckForMove_out_struct_var;
    struct  csObjLot_ContaminationInfo_CheckForMove_out_struct {
        typedef csObjLot_ContaminationInfo_CheckForMove_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Boolean holdReqFlag;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_ContaminationInfo_CheckForMove_out_struct();
       csObjLot_ContaminationInfo_CheckForMove_out_struct(const csObjLot_ContaminationInfo_CheckForMove_out_struct&);
       csObjLot_ContaminationInfo_CheckForMove_out_struct& operator=(const csObjLot_ContaminationInfo_CheckForMove_out_struct&);
       static CORBA::Info<csObjLot_ContaminationInfo_CheckForMove_out_struct> csObjLot_ContaminationInfo_CheckForMove_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_ContaminationInfo_CheckForMove_out_struct


typedef csObjLot_ContaminationInfo_CheckForMove_out_struct* csObjLot_ContaminationInfo_CheckForMove_out_struct_vPtr;
typedef const csObjLot_ContaminationInfo_CheckForMove_out_struct* csObjLot_ContaminationInfo_CheckForMove_out_struct_cvPtr;

class  csObjLot_ContaminationInfo_CheckForMove_out_struct_var
{
    public:

    csObjLot_ContaminationInfo_CheckForMove_out_struct_var ();

    csObjLot_ContaminationInfo_CheckForMove_out_struct_var (csObjLot_ContaminationInfo_CheckForMove_out_struct *_p);

    csObjLot_ContaminationInfo_CheckForMove_out_struct_var (const csObjLot_ContaminationInfo_CheckForMove_out_struct_var &_s);

    csObjLot_ContaminationInfo_CheckForMove_out_struct_var &operator= (csObjLot_ContaminationInfo_CheckForMove_out_struct *_p);

    csObjLot_ContaminationInfo_CheckForMove_out_struct_var &operator= (const csObjLot_ContaminationInfo_CheckForMove_out_struct_var &_s);

    ~csObjLot_ContaminationInfo_CheckForMove_out_struct_var ();

    csObjLot_ContaminationInfo_CheckForMove_out_struct* operator-> ();

    const csObjLot_ContaminationInfo_CheckForMove_out_struct& in() const;
    csObjLot_ContaminationInfo_CheckForMove_out_struct& inout();
    csObjLot_ContaminationInfo_CheckForMove_out_struct*& out();
    csObjLot_ContaminationInfo_CheckForMove_out_struct* _retn();

    operator csObjLot_ContaminationInfo_CheckForMove_out_struct_cvPtr () const;

    operator csObjLot_ContaminationInfo_CheckForMove_out_struct_vPtr& ();

    operator const csObjLot_ContaminationInfo_CheckForMove_out_struct& () const;

    operator csObjLot_ContaminationInfo_CheckForMove_out_struct& ();

    protected:
    csObjLot_ContaminationInfo_CheckForMove_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForMove_out_struct;
    typedef csObjLot_ContaminationInfo_CheckForMove_out_struct csObjLot_ContaminationInfo_CheckForMove_out;
    typedef csObjLot_ContaminationInfo_CheckForMove_out_struct_var csObjLot_ContaminationInfo_CheckForMove_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForMove_out;
    class  csObjLot_ContaminationInfo_CheckForProcess_in_struct_var;
    struct  csObjLot_ContaminationInfo_CheckForProcess_in_struct {
        typedef csObjLot_ContaminationInfo_CheckForProcess_in_struct_var _var_type;
       ::objectIdentifier equipmentID;
       ::objectIdentifier carrierID;
       ::pptLotInCassetteSequence strLotInCassette;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_ContaminationInfo_CheckForProcess_in_struct();
       csObjLot_ContaminationInfo_CheckForProcess_in_struct(const csObjLot_ContaminationInfo_CheckForProcess_in_struct&);
       csObjLot_ContaminationInfo_CheckForProcess_in_struct& operator=(const csObjLot_ContaminationInfo_CheckForProcess_in_struct&);
       static CORBA::Info<csObjLot_ContaminationInfo_CheckForProcess_in_struct> csObjLot_ContaminationInfo_CheckForProcess_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_ContaminationInfo_CheckForProcess_in_struct


typedef csObjLot_ContaminationInfo_CheckForProcess_in_struct* csObjLot_ContaminationInfo_CheckForProcess_in_struct_vPtr;
typedef const csObjLot_ContaminationInfo_CheckForProcess_in_struct* csObjLot_ContaminationInfo_CheckForProcess_in_struct_cvPtr;

class  csObjLot_ContaminationInfo_CheckForProcess_in_struct_var
{
    public:

    csObjLot_ContaminationInfo_CheckForProcess_in_struct_var ();

    csObjLot_ContaminationInfo_CheckForProcess_in_struct_var (csObjLot_ContaminationInfo_CheckForProcess_in_struct *_p);

    csObjLot_ContaminationInfo_CheckForProcess_in_struct_var (const csObjLot_ContaminationInfo_CheckForProcess_in_struct_var &_s);

    csObjLot_ContaminationInfo_CheckForProcess_in_struct_var &operator= (csObjLot_ContaminationInfo_CheckForProcess_in_struct *_p);

    csObjLot_ContaminationInfo_CheckForProcess_in_struct_var &operator= (const csObjLot_ContaminationInfo_CheckForProcess_in_struct_var &_s);

    ~csObjLot_ContaminationInfo_CheckForProcess_in_struct_var ();

    csObjLot_ContaminationInfo_CheckForProcess_in_struct* operator-> ();

    const csObjLot_ContaminationInfo_CheckForProcess_in_struct& in() const;
    csObjLot_ContaminationInfo_CheckForProcess_in_struct& inout();
    csObjLot_ContaminationInfo_CheckForProcess_in_struct*& out();
    csObjLot_ContaminationInfo_CheckForProcess_in_struct* _retn();

    operator csObjLot_ContaminationInfo_CheckForProcess_in_struct_cvPtr () const;

    operator csObjLot_ContaminationInfo_CheckForProcess_in_struct_vPtr& ();

    operator const csObjLot_ContaminationInfo_CheckForProcess_in_struct& () const;

    operator csObjLot_ContaminationInfo_CheckForProcess_in_struct& ();

    protected:
    csObjLot_ContaminationInfo_CheckForProcess_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForProcess_in_struct;
    typedef csObjLot_ContaminationInfo_CheckForProcess_in_struct csObjLot_ContaminationInfo_CheckForProcess_in;
    typedef csObjLot_ContaminationInfo_CheckForProcess_in_struct_var csObjLot_ContaminationInfo_CheckForProcess_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForProcess_in;
    class  csObjLot_ContaminationInfo_CheckForProcess_out_struct_var;
    struct  csObjLot_ContaminationInfo_CheckForProcess_out_struct {
        typedef csObjLot_ContaminationInfo_CheckForProcess_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Boolean matchFlag;
       ::objectIdentifierSequence holdLotIDs;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_ContaminationInfo_CheckForProcess_out_struct();
       csObjLot_ContaminationInfo_CheckForProcess_out_struct(const csObjLot_ContaminationInfo_CheckForProcess_out_struct&);
       csObjLot_ContaminationInfo_CheckForProcess_out_struct& operator=(const csObjLot_ContaminationInfo_CheckForProcess_out_struct&);
       static CORBA::Info<csObjLot_ContaminationInfo_CheckForProcess_out_struct> csObjLot_ContaminationInfo_CheckForProcess_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_ContaminationInfo_CheckForProcess_out_struct


typedef csObjLot_ContaminationInfo_CheckForProcess_out_struct* csObjLot_ContaminationInfo_CheckForProcess_out_struct_vPtr;
typedef const csObjLot_ContaminationInfo_CheckForProcess_out_struct* csObjLot_ContaminationInfo_CheckForProcess_out_struct_cvPtr;

class  csObjLot_ContaminationInfo_CheckForProcess_out_struct_var
{
    public:

    csObjLot_ContaminationInfo_CheckForProcess_out_struct_var ();

    csObjLot_ContaminationInfo_CheckForProcess_out_struct_var (csObjLot_ContaminationInfo_CheckForProcess_out_struct *_p);

    csObjLot_ContaminationInfo_CheckForProcess_out_struct_var (const csObjLot_ContaminationInfo_CheckForProcess_out_struct_var &_s);

    csObjLot_ContaminationInfo_CheckForProcess_out_struct_var &operator= (csObjLot_ContaminationInfo_CheckForProcess_out_struct *_p);

    csObjLot_ContaminationInfo_CheckForProcess_out_struct_var &operator= (const csObjLot_ContaminationInfo_CheckForProcess_out_struct_var &_s);

    ~csObjLot_ContaminationInfo_CheckForProcess_out_struct_var ();

    csObjLot_ContaminationInfo_CheckForProcess_out_struct* operator-> ();

    const csObjLot_ContaminationInfo_CheckForProcess_out_struct& in() const;
    csObjLot_ContaminationInfo_CheckForProcess_out_struct& inout();
    csObjLot_ContaminationInfo_CheckForProcess_out_struct*& out();
    csObjLot_ContaminationInfo_CheckForProcess_out_struct* _retn();

    operator csObjLot_ContaminationInfo_CheckForProcess_out_struct_cvPtr () const;

    operator csObjLot_ContaminationInfo_CheckForProcess_out_struct_vPtr& ();

    operator const csObjLot_ContaminationInfo_CheckForProcess_out_struct& () const;

    operator csObjLot_ContaminationInfo_CheckForProcess_out_struct& ();

    protected:
    csObjLot_ContaminationInfo_CheckForProcess_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForProcess_out_struct;
    typedef csObjLot_ContaminationInfo_CheckForProcess_out_struct csObjLot_ContaminationInfo_CheckForProcess_out;
    typedef csObjLot_ContaminationInfo_CheckForProcess_out_struct_var csObjLot_ContaminationInfo_CheckForProcess_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForProcess_out;
    class  csObjLot_udata_CopyToChild_in_struct_var;
    struct  csObjLot_udata_CopyToChild_in_struct {
        typedef csObjLot_udata_CopyToChild_in_struct_var _var_type;
       ::objectIdentifier parentLotID;
       ::objectIdentifier childLotID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_udata_CopyToChild_in_struct();
       csObjLot_udata_CopyToChild_in_struct(const csObjLot_udata_CopyToChild_in_struct&);
       csObjLot_udata_CopyToChild_in_struct& operator=(const csObjLot_udata_CopyToChild_in_struct&);
       static CORBA::Info<csObjLot_udata_CopyToChild_in_struct> csObjLot_udata_CopyToChild_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_udata_CopyToChild_in_struct


typedef csObjLot_udata_CopyToChild_in_struct* csObjLot_udata_CopyToChild_in_struct_vPtr;
typedef const csObjLot_udata_CopyToChild_in_struct* csObjLot_udata_CopyToChild_in_struct_cvPtr;

class  csObjLot_udata_CopyToChild_in_struct_var
{
    public:

    csObjLot_udata_CopyToChild_in_struct_var ();

    csObjLot_udata_CopyToChild_in_struct_var (csObjLot_udata_CopyToChild_in_struct *_p);

    csObjLot_udata_CopyToChild_in_struct_var (const csObjLot_udata_CopyToChild_in_struct_var &_s);

    csObjLot_udata_CopyToChild_in_struct_var &operator= (csObjLot_udata_CopyToChild_in_struct *_p);

    csObjLot_udata_CopyToChild_in_struct_var &operator= (const csObjLot_udata_CopyToChild_in_struct_var &_s);

    ~csObjLot_udata_CopyToChild_in_struct_var ();

    csObjLot_udata_CopyToChild_in_struct* operator-> ();

    const csObjLot_udata_CopyToChild_in_struct& in() const;
    csObjLot_udata_CopyToChild_in_struct& inout();
    csObjLot_udata_CopyToChild_in_struct*& out();
    csObjLot_udata_CopyToChild_in_struct* _retn();

    operator csObjLot_udata_CopyToChild_in_struct_cvPtr () const;

    operator csObjLot_udata_CopyToChild_in_struct_vPtr& ();

    operator const csObjLot_udata_CopyToChild_in_struct& () const;

    operator csObjLot_udata_CopyToChild_in_struct& ();

    protected:
    csObjLot_udata_CopyToChild_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_udata_CopyToChild_in_struct;
    typedef csObjLot_udata_CopyToChild_in_struct csObjLot_udata_CopyToChild_in;
    typedef csObjLot_udata_CopyToChild_in_struct_var csObjLot_udata_CopyToChild_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_udata_CopyToChild_in;
    typedef objBase_out csObjLot_udata_CopyToChild_out;
    typedef objBase_out_var csObjLot_udata_CopyToChild_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_udata_CopyToChild_out;
    class  csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var;
    struct  csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct {
        typedef csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var _var_type;
       ::objectIdentifier carrierID;
       ::objectIdentifierSequence lotIDs;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct();
       csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct(const csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct&);
       csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct& operator=(const csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct&);
       static CORBA::Info<csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct> csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct


typedef csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct* csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_vPtr;
typedef const csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct* csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_cvPtr;

class  csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var
{
    public:

    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var ();

    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var (csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct *_p);

    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var (const csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var &_s);

    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var &operator= (csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct *_p);

    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var &operator= (const csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var &_s);

    ~csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var ();

    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct* operator-> ();

    const csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct& in() const;
    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct& inout();
    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct*& out();
    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct* _retn();

    operator csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_cvPtr () const;

    operator csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_vPtr& ();

    operator const csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct& () const;

    operator csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct& ();

    protected:
    csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct;
    typedef csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct csObjLot_ContaminationInfo_CheckForCarrierExchange_in;
    typedef csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct_var csObjLot_ContaminationInfo_CheckForCarrierExchange_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForCarrierExchange_in;
    class  csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var;
    struct  csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct {
        typedef csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Boolean matchFlag;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct();
       csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct(const csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct&);
       csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct& operator=(const csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct&);
       static CORBA::Info<csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct> csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct


typedef csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct* csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_vPtr;
typedef const csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct* csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_cvPtr;

class  csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var
{
    public:

    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var ();

    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var (csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct *_p);

    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var (const csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var &_s);

    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var &operator= (csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct *_p);

    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var &operator= (const csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var &_s);

    ~csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var ();

    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct* operator-> ();

    const csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct& in() const;
    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct& inout();
    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct*& out();
    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct* _retn();

    operator csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_cvPtr () const;

    operator csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_vPtr& ();

    operator const csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct& () const;

    operator csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct& ();

    protected:
    csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct;
    typedef csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct csObjLot_ContaminationInfo_CheckForCarrierExchange_out;
    typedef csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct_var csObjLot_ContaminationInfo_CheckForCarrierExchange_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_ContaminationInfo_CheckForCarrierExchange_out;
    class  csObjEquipment_udata_GetDR_in_struct_var;
    struct  csObjEquipment_udata_GetDR_in_struct {
        typedef csObjEquipment_udata_GetDR_in_struct_var _var_type;
       ::objectIdentifier equipmentID;
       ::stringSequence udataName;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEquipment_udata_GetDR_in_struct();
       csObjEquipment_udata_GetDR_in_struct(const csObjEquipment_udata_GetDR_in_struct&);
       csObjEquipment_udata_GetDR_in_struct& operator=(const csObjEquipment_udata_GetDR_in_struct&);
       static CORBA::Info<csObjEquipment_udata_GetDR_in_struct> csObjEquipment_udata_GetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEquipment_udata_GetDR_in_struct


typedef csObjEquipment_udata_GetDR_in_struct* csObjEquipment_udata_GetDR_in_struct_vPtr;
typedef const csObjEquipment_udata_GetDR_in_struct* csObjEquipment_udata_GetDR_in_struct_cvPtr;

class  csObjEquipment_udata_GetDR_in_struct_var
{
    public:

    csObjEquipment_udata_GetDR_in_struct_var ();

    csObjEquipment_udata_GetDR_in_struct_var (csObjEquipment_udata_GetDR_in_struct *_p);

    csObjEquipment_udata_GetDR_in_struct_var (const csObjEquipment_udata_GetDR_in_struct_var &_s);

    csObjEquipment_udata_GetDR_in_struct_var &operator= (csObjEquipment_udata_GetDR_in_struct *_p);

    csObjEquipment_udata_GetDR_in_struct_var &operator= (const csObjEquipment_udata_GetDR_in_struct_var &_s);

    ~csObjEquipment_udata_GetDR_in_struct_var ();

    csObjEquipment_udata_GetDR_in_struct* operator-> ();

    const csObjEquipment_udata_GetDR_in_struct& in() const;
    csObjEquipment_udata_GetDR_in_struct& inout();
    csObjEquipment_udata_GetDR_in_struct*& out();
    csObjEquipment_udata_GetDR_in_struct* _retn();

    operator csObjEquipment_udata_GetDR_in_struct_cvPtr () const;

    operator csObjEquipment_udata_GetDR_in_struct_vPtr& ();

    operator const csObjEquipment_udata_GetDR_in_struct& () const;

    operator csObjEquipment_udata_GetDR_in_struct& ();

    protected:
    csObjEquipment_udata_GetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_udata_GetDR_in_struct;
    typedef csObjEquipment_udata_GetDR_in_struct csObjEquipment_udata_GetDR_in;
    typedef csObjEquipment_udata_GetDR_in_struct_var csObjEquipment_udata_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_udata_GetDR_in;
    class  csObjEquipment_udata_GetDR_out_struct_var;
    struct  csObjEquipment_udata_GetDR_out_struct {
        typedef csObjEquipment_udata_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::stringSequence udataValue;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEquipment_udata_GetDR_out_struct();
       csObjEquipment_udata_GetDR_out_struct(const csObjEquipment_udata_GetDR_out_struct&);
       csObjEquipment_udata_GetDR_out_struct& operator=(const csObjEquipment_udata_GetDR_out_struct&);
       static CORBA::Info<csObjEquipment_udata_GetDR_out_struct> csObjEquipment_udata_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEquipment_udata_GetDR_out_struct


typedef csObjEquipment_udata_GetDR_out_struct* csObjEquipment_udata_GetDR_out_struct_vPtr;
typedef const csObjEquipment_udata_GetDR_out_struct* csObjEquipment_udata_GetDR_out_struct_cvPtr;

class  csObjEquipment_udata_GetDR_out_struct_var
{
    public:

    csObjEquipment_udata_GetDR_out_struct_var ();

    csObjEquipment_udata_GetDR_out_struct_var (csObjEquipment_udata_GetDR_out_struct *_p);

    csObjEquipment_udata_GetDR_out_struct_var (const csObjEquipment_udata_GetDR_out_struct_var &_s);

    csObjEquipment_udata_GetDR_out_struct_var &operator= (csObjEquipment_udata_GetDR_out_struct *_p);

    csObjEquipment_udata_GetDR_out_struct_var &operator= (const csObjEquipment_udata_GetDR_out_struct_var &_s);

    ~csObjEquipment_udata_GetDR_out_struct_var ();

    csObjEquipment_udata_GetDR_out_struct* operator-> ();

    const csObjEquipment_udata_GetDR_out_struct& in() const;
    csObjEquipment_udata_GetDR_out_struct& inout();
    csObjEquipment_udata_GetDR_out_struct*& out();
    csObjEquipment_udata_GetDR_out_struct* _retn();

    operator csObjEquipment_udata_GetDR_out_struct_cvPtr () const;

    operator csObjEquipment_udata_GetDR_out_struct_vPtr& ();

    operator const csObjEquipment_udata_GetDR_out_struct& () const;

    operator csObjEquipment_udata_GetDR_out_struct& ();

    protected:
    csObjEquipment_udata_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_udata_GetDR_out_struct;
    typedef csObjEquipment_udata_GetDR_out_struct csObjEquipment_udata_GetDR_out;
    typedef csObjEquipment_udata_GetDR_out_struct_var csObjEquipment_udata_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEquipment_udata_GetDR_out;
    class  csObjCarrier_UsageTypeChange_in_struct_var;
    struct  csObjCarrier_UsageTypeChange_in_struct {
        typedef csObjCarrier_UsageTypeChange_in_struct_var _var_type;
       ::objectIdentifierSequence carrierIDs;
       ::CORBA::String_StructElem usageType;
       ::CORBA::String_StructElem claimMemo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjCarrier_UsageTypeChange_in_struct();
       csObjCarrier_UsageTypeChange_in_struct(const csObjCarrier_UsageTypeChange_in_struct&);
       csObjCarrier_UsageTypeChange_in_struct& operator=(const csObjCarrier_UsageTypeChange_in_struct&);
       static CORBA::Info<csObjCarrier_UsageTypeChange_in_struct> csObjCarrier_UsageTypeChange_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjCarrier_UsageTypeChange_in_struct


typedef csObjCarrier_UsageTypeChange_in_struct* csObjCarrier_UsageTypeChange_in_struct_vPtr;
typedef const csObjCarrier_UsageTypeChange_in_struct* csObjCarrier_UsageTypeChange_in_struct_cvPtr;

class  csObjCarrier_UsageTypeChange_in_struct_var
{
    public:

    csObjCarrier_UsageTypeChange_in_struct_var ();

    csObjCarrier_UsageTypeChange_in_struct_var (csObjCarrier_UsageTypeChange_in_struct *_p);

    csObjCarrier_UsageTypeChange_in_struct_var (const csObjCarrier_UsageTypeChange_in_struct_var &_s);

    csObjCarrier_UsageTypeChange_in_struct_var &operator= (csObjCarrier_UsageTypeChange_in_struct *_p);

    csObjCarrier_UsageTypeChange_in_struct_var &operator= (const csObjCarrier_UsageTypeChange_in_struct_var &_s);

    ~csObjCarrier_UsageTypeChange_in_struct_var ();

    csObjCarrier_UsageTypeChange_in_struct* operator-> ();

    const csObjCarrier_UsageTypeChange_in_struct& in() const;
    csObjCarrier_UsageTypeChange_in_struct& inout();
    csObjCarrier_UsageTypeChange_in_struct*& out();
    csObjCarrier_UsageTypeChange_in_struct* _retn();

    operator csObjCarrier_UsageTypeChange_in_struct_cvPtr () const;

    operator csObjCarrier_UsageTypeChange_in_struct_vPtr& ();

    operator const csObjCarrier_UsageTypeChange_in_struct& () const;

    operator csObjCarrier_UsageTypeChange_in_struct& ();

    protected:
    csObjCarrier_UsageTypeChange_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjCarrier_UsageTypeChange_in_struct;
    typedef csObjCarrier_UsageTypeChange_in_struct csObjCarrier_UsageTypeChange_in;
    typedef csObjCarrier_UsageTypeChange_in_struct_var csObjCarrier_UsageTypeChange_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjCarrier_UsageTypeChange_in;
    typedef objBase_out csObjCarrier_UsageTypeChange_out;
    typedef objBase_out_var csObjCarrier_UsageTypeChange_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjCarrier_UsageTypeChange_out;
    class  csObjLot_requiredCarrierCategory_CheckDR_in_struct_var;
    struct  csObjLot_requiredCarrierCategory_CheckDR_in_struct {
        typedef csObjLot_requiredCarrierCategory_CheckDR_in_struct_var _var_type;
       ::objectIdentifier carrierID;
       ::objectIdentifier lotID;
       ::CORBA::String_StructElem curCastCategory;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLot_requiredCarrierCategory_CheckDR_in_struct();
       csObjLot_requiredCarrierCategory_CheckDR_in_struct(const csObjLot_requiredCarrierCategory_CheckDR_in_struct&);
       csObjLot_requiredCarrierCategory_CheckDR_in_struct& operator=(const csObjLot_requiredCarrierCategory_CheckDR_in_struct&);
       static CORBA::Info<csObjLot_requiredCarrierCategory_CheckDR_in_struct> csObjLot_requiredCarrierCategory_CheckDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLot_requiredCarrierCategory_CheckDR_in_struct


typedef csObjLot_requiredCarrierCategory_CheckDR_in_struct* csObjLot_requiredCarrierCategory_CheckDR_in_struct_vPtr;
typedef const csObjLot_requiredCarrierCategory_CheckDR_in_struct* csObjLot_requiredCarrierCategory_CheckDR_in_struct_cvPtr;

class  csObjLot_requiredCarrierCategory_CheckDR_in_struct_var
{
    public:

    csObjLot_requiredCarrierCategory_CheckDR_in_struct_var ();

    csObjLot_requiredCarrierCategory_CheckDR_in_struct_var (csObjLot_requiredCarrierCategory_CheckDR_in_struct *_p);

    csObjLot_requiredCarrierCategory_CheckDR_in_struct_var (const csObjLot_requiredCarrierCategory_CheckDR_in_struct_var &_s);

    csObjLot_requiredCarrierCategory_CheckDR_in_struct_var &operator= (csObjLot_requiredCarrierCategory_CheckDR_in_struct *_p);

    csObjLot_requiredCarrierCategory_CheckDR_in_struct_var &operator= (const csObjLot_requiredCarrierCategory_CheckDR_in_struct_var &_s);

    ~csObjLot_requiredCarrierCategory_CheckDR_in_struct_var ();

    csObjLot_requiredCarrierCategory_CheckDR_in_struct* operator-> ();

    const csObjLot_requiredCarrierCategory_CheckDR_in_struct& in() const;
    csObjLot_requiredCarrierCategory_CheckDR_in_struct& inout();
    csObjLot_requiredCarrierCategory_CheckDR_in_struct*& out();
    csObjLot_requiredCarrierCategory_CheckDR_in_struct* _retn();

    operator csObjLot_requiredCarrierCategory_CheckDR_in_struct_cvPtr () const;

    operator csObjLot_requiredCarrierCategory_CheckDR_in_struct_vPtr& ();

    operator const csObjLot_requiredCarrierCategory_CheckDR_in_struct& () const;

    operator csObjLot_requiredCarrierCategory_CheckDR_in_struct& ();

    protected:
    csObjLot_requiredCarrierCategory_CheckDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_requiredCarrierCategory_CheckDR_in_struct;
    typedef csObjLot_requiredCarrierCategory_CheckDR_in_struct csObjLot_requiredCarrierCategory_CheckDR_in;
    typedef csObjLot_requiredCarrierCategory_CheckDR_in_struct_var csObjLot_requiredCarrierCategory_CheckDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_requiredCarrierCategory_CheckDR_in;
    typedef objBase_out csObjLot_requiredCarrierCategory_CheckDR_out;
    typedef objBase_out_var csObjLot_requiredCarrierCategory_CheckDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLot_requiredCarrierCategory_CheckDR_out;
    class  csObjPerson_SkillList_GetDR_out_struct_var;
    struct  csObjPerson_SkillList_GetDR_out_struct {
        typedef csObjPerson_SkillList_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csUserSkillInfo strUserSkillInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjPerson_SkillList_GetDR_out_struct();
       csObjPerson_SkillList_GetDR_out_struct(const csObjPerson_SkillList_GetDR_out_struct&);
       csObjPerson_SkillList_GetDR_out_struct& operator=(const csObjPerson_SkillList_GetDR_out_struct&);
       static CORBA::Info<csObjPerson_SkillList_GetDR_out_struct> csObjPerson_SkillList_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjPerson_SkillList_GetDR_out_struct


typedef csObjPerson_SkillList_GetDR_out_struct* csObjPerson_SkillList_GetDR_out_struct_vPtr;
typedef const csObjPerson_SkillList_GetDR_out_struct* csObjPerson_SkillList_GetDR_out_struct_cvPtr;

class  csObjPerson_SkillList_GetDR_out_struct_var
{
    public:

    csObjPerson_SkillList_GetDR_out_struct_var ();

    csObjPerson_SkillList_GetDR_out_struct_var (csObjPerson_SkillList_GetDR_out_struct *_p);

    csObjPerson_SkillList_GetDR_out_struct_var (const csObjPerson_SkillList_GetDR_out_struct_var &_s);

    csObjPerson_SkillList_GetDR_out_struct_var &operator= (csObjPerson_SkillList_GetDR_out_struct *_p);

    csObjPerson_SkillList_GetDR_out_struct_var &operator= (const csObjPerson_SkillList_GetDR_out_struct_var &_s);

    ~csObjPerson_SkillList_GetDR_out_struct_var ();

    csObjPerson_SkillList_GetDR_out_struct* operator-> ();

    const csObjPerson_SkillList_GetDR_out_struct& in() const;
    csObjPerson_SkillList_GetDR_out_struct& inout();
    csObjPerson_SkillList_GetDR_out_struct*& out();
    csObjPerson_SkillList_GetDR_out_struct* _retn();

    operator csObjPerson_SkillList_GetDR_out_struct_cvPtr () const;

    operator csObjPerson_SkillList_GetDR_out_struct_vPtr& ();

    operator const csObjPerson_SkillList_GetDR_out_struct& () const;

    operator csObjPerson_SkillList_GetDR_out_struct& ();

    protected:
    csObjPerson_SkillList_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_GetDR_out_struct;
    typedef csObjPerson_SkillList_GetDR_out_struct csObjPerson_SkillList_GetDR_out;
    typedef csObjPerson_SkillList_GetDR_out_struct_var csObjPerson_SkillList_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_GetDR_out;
    typedef objBase_out csObjPerson_SkillList_SetDR_out;
    typedef objBase_out_var csObjPerson_SkillList_SetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_SetDR_out;
    typedef objBase_out csObjPerson_SkillList_AddDR_out;
    typedef objBase_out_var csObjPerson_SkillList_AddDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_AddDR_out;
    typedef objBase_out csObjPerson_SkillList_DelDR_out;
    typedef objBase_out_var csObjPerson_SkillList_DelDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_DelDR_out;
    typedef objBase_out csObjPerson_PrivilegeCheckForTACertify_out;
    typedef objBase_out_var csObjPerson_PrivilegeCheckForTACertify_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_PrivilegeCheckForTACertify_out;
    class  csObjPerson_SkillList_GetDR_in_strcut_var;
    struct  csObjPerson_SkillList_GetDR_in_strcut {
        typedef csObjPerson_SkillList_GetDR_in_strcut_var _var_type;
       ::objectIdentifier userID;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjPerson_SkillList_GetDR_in_strcut();
       csObjPerson_SkillList_GetDR_in_strcut(const csObjPerson_SkillList_GetDR_in_strcut&);
       csObjPerson_SkillList_GetDR_in_strcut& operator=(const csObjPerson_SkillList_GetDR_in_strcut&);
       static CORBA::Info<csObjPerson_SkillList_GetDR_in_strcut> csObjPerson_SkillList_GetDR_in_strcut_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjPerson_SkillList_GetDR_in_strcut


typedef csObjPerson_SkillList_GetDR_in_strcut* csObjPerson_SkillList_GetDR_in_strcut_vPtr;
typedef const csObjPerson_SkillList_GetDR_in_strcut* csObjPerson_SkillList_GetDR_in_strcut_cvPtr;

class  csObjPerson_SkillList_GetDR_in_strcut_var
{
    public:

    csObjPerson_SkillList_GetDR_in_strcut_var ();

    csObjPerson_SkillList_GetDR_in_strcut_var (csObjPerson_SkillList_GetDR_in_strcut *_p);

    csObjPerson_SkillList_GetDR_in_strcut_var (const csObjPerson_SkillList_GetDR_in_strcut_var &_s);

    csObjPerson_SkillList_GetDR_in_strcut_var &operator= (csObjPerson_SkillList_GetDR_in_strcut *_p);

    csObjPerson_SkillList_GetDR_in_strcut_var &operator= (const csObjPerson_SkillList_GetDR_in_strcut_var &_s);

    ~csObjPerson_SkillList_GetDR_in_strcut_var ();

    csObjPerson_SkillList_GetDR_in_strcut* operator-> ();

    const csObjPerson_SkillList_GetDR_in_strcut& in() const;
    csObjPerson_SkillList_GetDR_in_strcut& inout();
    csObjPerson_SkillList_GetDR_in_strcut*& out();
    csObjPerson_SkillList_GetDR_in_strcut* _retn();

    operator csObjPerson_SkillList_GetDR_in_strcut_cvPtr () const;

    operator csObjPerson_SkillList_GetDR_in_strcut_vPtr& ();

    operator const csObjPerson_SkillList_GetDR_in_strcut& () const;

    operator csObjPerson_SkillList_GetDR_in_strcut& ();

    protected:
    csObjPerson_SkillList_GetDR_in_strcut *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_GetDR_in_strcut;
    typedef csObjPerson_SkillList_GetDR_in_strcut csObjPerson_SkillList_GetDR_in;
    typedef csObjPerson_SkillList_GetDR_in_strcut_var csObjPerson_SkillList_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_GetDR_in;
    class  csObjPerson_SkillList_AddDR_in_strcut_var;
    struct  csObjPerson_SkillList_AddDR_in_strcut {
        typedef csObjPerson_SkillList_AddDR_in_strcut_var _var_type;
       ::csUserSkillInfoSequence strUserSkillInfoSeq;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjPerson_SkillList_AddDR_in_strcut();
       csObjPerson_SkillList_AddDR_in_strcut(const csObjPerson_SkillList_AddDR_in_strcut&);
       csObjPerson_SkillList_AddDR_in_strcut& operator=(const csObjPerson_SkillList_AddDR_in_strcut&);
       static CORBA::Info<csObjPerson_SkillList_AddDR_in_strcut> csObjPerson_SkillList_AddDR_in_strcut_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjPerson_SkillList_AddDR_in_strcut


typedef csObjPerson_SkillList_AddDR_in_strcut* csObjPerson_SkillList_AddDR_in_strcut_vPtr;
typedef const csObjPerson_SkillList_AddDR_in_strcut* csObjPerson_SkillList_AddDR_in_strcut_cvPtr;

class  csObjPerson_SkillList_AddDR_in_strcut_var
{
    public:

    csObjPerson_SkillList_AddDR_in_strcut_var ();

    csObjPerson_SkillList_AddDR_in_strcut_var (csObjPerson_SkillList_AddDR_in_strcut *_p);

    csObjPerson_SkillList_AddDR_in_strcut_var (const csObjPerson_SkillList_AddDR_in_strcut_var &_s);

    csObjPerson_SkillList_AddDR_in_strcut_var &operator= (csObjPerson_SkillList_AddDR_in_strcut *_p);

    csObjPerson_SkillList_AddDR_in_strcut_var &operator= (const csObjPerson_SkillList_AddDR_in_strcut_var &_s);

    ~csObjPerson_SkillList_AddDR_in_strcut_var ();

    csObjPerson_SkillList_AddDR_in_strcut* operator-> ();

    const csObjPerson_SkillList_AddDR_in_strcut& in() const;
    csObjPerson_SkillList_AddDR_in_strcut& inout();
    csObjPerson_SkillList_AddDR_in_strcut*& out();
    csObjPerson_SkillList_AddDR_in_strcut* _retn();

    operator csObjPerson_SkillList_AddDR_in_strcut_cvPtr () const;

    operator csObjPerson_SkillList_AddDR_in_strcut_vPtr& ();

    operator const csObjPerson_SkillList_AddDR_in_strcut& () const;

    operator csObjPerson_SkillList_AddDR_in_strcut& ();

    protected:
    csObjPerson_SkillList_AddDR_in_strcut *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_AddDR_in_strcut;
    typedef csObjPerson_SkillList_AddDR_in_strcut csObjPerson_SkillList_AddDR_in;
    typedef csObjPerson_SkillList_AddDR_in_strcut_var csObjPerson_SkillList_AddDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_AddDR_in;
    class  csObjPerson_SkillList_DelDR_in_strcut_var;
    struct  csObjPerson_SkillList_DelDR_in_strcut {
        typedef csObjPerson_SkillList_DelDR_in_strcut_var _var_type;
       ::csUserSkillInfoSequence strUserSkillInfoSeq;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjPerson_SkillList_DelDR_in_strcut();
       csObjPerson_SkillList_DelDR_in_strcut(const csObjPerson_SkillList_DelDR_in_strcut&);
       csObjPerson_SkillList_DelDR_in_strcut& operator=(const csObjPerson_SkillList_DelDR_in_strcut&);
       static CORBA::Info<csObjPerson_SkillList_DelDR_in_strcut> csObjPerson_SkillList_DelDR_in_strcut_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjPerson_SkillList_DelDR_in_strcut


typedef csObjPerson_SkillList_DelDR_in_strcut* csObjPerson_SkillList_DelDR_in_strcut_vPtr;
typedef const csObjPerson_SkillList_DelDR_in_strcut* csObjPerson_SkillList_DelDR_in_strcut_cvPtr;

class  csObjPerson_SkillList_DelDR_in_strcut_var
{
    public:

    csObjPerson_SkillList_DelDR_in_strcut_var ();

    csObjPerson_SkillList_DelDR_in_strcut_var (csObjPerson_SkillList_DelDR_in_strcut *_p);

    csObjPerson_SkillList_DelDR_in_strcut_var (const csObjPerson_SkillList_DelDR_in_strcut_var &_s);

    csObjPerson_SkillList_DelDR_in_strcut_var &operator= (csObjPerson_SkillList_DelDR_in_strcut *_p);

    csObjPerson_SkillList_DelDR_in_strcut_var &operator= (const csObjPerson_SkillList_DelDR_in_strcut_var &_s);

    ~csObjPerson_SkillList_DelDR_in_strcut_var ();

    csObjPerson_SkillList_DelDR_in_strcut* operator-> ();

    const csObjPerson_SkillList_DelDR_in_strcut& in() const;
    csObjPerson_SkillList_DelDR_in_strcut& inout();
    csObjPerson_SkillList_DelDR_in_strcut*& out();
    csObjPerson_SkillList_DelDR_in_strcut* _retn();

    operator csObjPerson_SkillList_DelDR_in_strcut_cvPtr () const;

    operator csObjPerson_SkillList_DelDR_in_strcut_vPtr& ();

    operator const csObjPerson_SkillList_DelDR_in_strcut& () const;

    operator csObjPerson_SkillList_DelDR_in_strcut& ();

    protected:
    csObjPerson_SkillList_DelDR_in_strcut *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_DelDR_in_strcut;
    typedef csObjPerson_SkillList_DelDR_in_strcut csObjPerson_SkillList_DelDR_in;
    typedef csObjPerson_SkillList_DelDR_in_strcut_var csObjPerson_SkillList_DelDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_DelDR_in;
    class  csObjPerson_SkillList_SetDR_in_strcut_var;
    struct  csObjPerson_SkillList_SetDR_in_strcut {
        typedef csObjPerson_SkillList_SetDR_in_strcut_var _var_type;
       ::csUserSkillInfoSequence strUserSkillInfoSeq;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjPerson_SkillList_SetDR_in_strcut();
       csObjPerson_SkillList_SetDR_in_strcut(const csObjPerson_SkillList_SetDR_in_strcut&);
       csObjPerson_SkillList_SetDR_in_strcut& operator=(const csObjPerson_SkillList_SetDR_in_strcut&);
       static CORBA::Info<csObjPerson_SkillList_SetDR_in_strcut> csObjPerson_SkillList_SetDR_in_strcut_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjPerson_SkillList_SetDR_in_strcut


typedef csObjPerson_SkillList_SetDR_in_strcut* csObjPerson_SkillList_SetDR_in_strcut_vPtr;
typedef const csObjPerson_SkillList_SetDR_in_strcut* csObjPerson_SkillList_SetDR_in_strcut_cvPtr;

class  csObjPerson_SkillList_SetDR_in_strcut_var
{
    public:

    csObjPerson_SkillList_SetDR_in_strcut_var ();

    csObjPerson_SkillList_SetDR_in_strcut_var (csObjPerson_SkillList_SetDR_in_strcut *_p);

    csObjPerson_SkillList_SetDR_in_strcut_var (const csObjPerson_SkillList_SetDR_in_strcut_var &_s);

    csObjPerson_SkillList_SetDR_in_strcut_var &operator= (csObjPerson_SkillList_SetDR_in_strcut *_p);

    csObjPerson_SkillList_SetDR_in_strcut_var &operator= (const csObjPerson_SkillList_SetDR_in_strcut_var &_s);

    ~csObjPerson_SkillList_SetDR_in_strcut_var ();

    csObjPerson_SkillList_SetDR_in_strcut* operator-> ();

    const csObjPerson_SkillList_SetDR_in_strcut& in() const;
    csObjPerson_SkillList_SetDR_in_strcut& inout();
    csObjPerson_SkillList_SetDR_in_strcut*& out();
    csObjPerson_SkillList_SetDR_in_strcut* _retn();

    operator csObjPerson_SkillList_SetDR_in_strcut_cvPtr () const;

    operator csObjPerson_SkillList_SetDR_in_strcut_vPtr& ();

    operator const csObjPerson_SkillList_SetDR_in_strcut& () const;

    operator csObjPerson_SkillList_SetDR_in_strcut& ();

    protected:
    csObjPerson_SkillList_SetDR_in_strcut *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_SetDR_in_strcut;
    typedef csObjPerson_SkillList_SetDR_in_strcut csObjPerson_SkillList_SetDR_in;
    typedef csObjPerson_SkillList_SetDR_in_strcut_var csObjPerson_SkillList_SetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_SkillList_SetDR_in;
    class  csObjPerson_PrivilegeCheckForTACertify_in_strcut_var;
    struct  csObjPerson_PrivilegeCheckForTACertify_in_strcut {
        typedef csObjPerson_PrivilegeCheckForTACertify_in_strcut_var _var_type;
       ::objectIdentifier userID;
       ::objectIdentifier equipmentID;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjPerson_PrivilegeCheckForTACertify_in_strcut();
       csObjPerson_PrivilegeCheckForTACertify_in_strcut(const csObjPerson_PrivilegeCheckForTACertify_in_strcut&);
       csObjPerson_PrivilegeCheckForTACertify_in_strcut& operator=(const csObjPerson_PrivilegeCheckForTACertify_in_strcut&);
       static CORBA::Info<csObjPerson_PrivilegeCheckForTACertify_in_strcut> csObjPerson_PrivilegeCheckForTACertify_in_strcut_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjPerson_PrivilegeCheckForTACertify_in_strcut


typedef csObjPerson_PrivilegeCheckForTACertify_in_strcut* csObjPerson_PrivilegeCheckForTACertify_in_strcut_vPtr;
typedef const csObjPerson_PrivilegeCheckForTACertify_in_strcut* csObjPerson_PrivilegeCheckForTACertify_in_strcut_cvPtr;

class  csObjPerson_PrivilegeCheckForTACertify_in_strcut_var
{
    public:

    csObjPerson_PrivilegeCheckForTACertify_in_strcut_var ();

    csObjPerson_PrivilegeCheckForTACertify_in_strcut_var (csObjPerson_PrivilegeCheckForTACertify_in_strcut *_p);

    csObjPerson_PrivilegeCheckForTACertify_in_strcut_var (const csObjPerson_PrivilegeCheckForTACertify_in_strcut_var &_s);

    csObjPerson_PrivilegeCheckForTACertify_in_strcut_var &operator= (csObjPerson_PrivilegeCheckForTACertify_in_strcut *_p);

    csObjPerson_PrivilegeCheckForTACertify_in_strcut_var &operator= (const csObjPerson_PrivilegeCheckForTACertify_in_strcut_var &_s);

    ~csObjPerson_PrivilegeCheckForTACertify_in_strcut_var ();

    csObjPerson_PrivilegeCheckForTACertify_in_strcut* operator-> ();

    const csObjPerson_PrivilegeCheckForTACertify_in_strcut& in() const;
    csObjPerson_PrivilegeCheckForTACertify_in_strcut& inout();
    csObjPerson_PrivilegeCheckForTACertify_in_strcut*& out();
    csObjPerson_PrivilegeCheckForTACertify_in_strcut* _retn();

    operator csObjPerson_PrivilegeCheckForTACertify_in_strcut_cvPtr () const;

    operator csObjPerson_PrivilegeCheckForTACertify_in_strcut_vPtr& ();

    operator const csObjPerson_PrivilegeCheckForTACertify_in_strcut& () const;

    operator csObjPerson_PrivilegeCheckForTACertify_in_strcut& ();

    protected:
    csObjPerson_PrivilegeCheckForTACertify_in_strcut *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_PrivilegeCheckForTACertify_in_strcut;
    typedef csObjPerson_PrivilegeCheckForTACertify_in_strcut csObjPerson_PrivilegeCheckForTACertify_in;
    typedef csObjPerson_PrivilegeCheckForTACertify_in_strcut_var csObjPerson_PrivilegeCheckForTACertify_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjPerson_PrivilegeCheckForTACertify_in;
    class  csObjFixture_touchCountSet_in_struct_var;
    struct  csObjFixture_touchCountSet_in_struct {
        typedef csObjFixture_touchCountSet_in_struct_var _var_type;
       ::objectIdentifier fixtureID;
       ::csFixtureTouchCountInfo strFixtureTouchCountInfo;
       ::CORBA::String_StructElem claimMemo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjFixture_touchCountSet_in_struct();
       csObjFixture_touchCountSet_in_struct(const csObjFixture_touchCountSet_in_struct&);
       csObjFixture_touchCountSet_in_struct& operator=(const csObjFixture_touchCountSet_in_struct&);
       static CORBA::Info<csObjFixture_touchCountSet_in_struct> csObjFixture_touchCountSet_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjFixture_touchCountSet_in_struct


typedef csObjFixture_touchCountSet_in_struct* csObjFixture_touchCountSet_in_struct_vPtr;
typedef const csObjFixture_touchCountSet_in_struct* csObjFixture_touchCountSet_in_struct_cvPtr;

class  csObjFixture_touchCountSet_in_struct_var
{
    public:

    csObjFixture_touchCountSet_in_struct_var ();

    csObjFixture_touchCountSet_in_struct_var (csObjFixture_touchCountSet_in_struct *_p);

    csObjFixture_touchCountSet_in_struct_var (const csObjFixture_touchCountSet_in_struct_var &_s);

    csObjFixture_touchCountSet_in_struct_var &operator= (csObjFixture_touchCountSet_in_struct *_p);

    csObjFixture_touchCountSet_in_struct_var &operator= (const csObjFixture_touchCountSet_in_struct_var &_s);

    ~csObjFixture_touchCountSet_in_struct_var ();

    csObjFixture_touchCountSet_in_struct* operator-> ();

    const csObjFixture_touchCountSet_in_struct& in() const;
    csObjFixture_touchCountSet_in_struct& inout();
    csObjFixture_touchCountSet_in_struct*& out();
    csObjFixture_touchCountSet_in_struct* _retn();

    operator csObjFixture_touchCountSet_in_struct_cvPtr () const;

    operator csObjFixture_touchCountSet_in_struct_vPtr& ();

    operator const csObjFixture_touchCountSet_in_struct& () const;

    operator csObjFixture_touchCountSet_in_struct& ();

    protected:
    csObjFixture_touchCountSet_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjFixture_touchCountSet_in_struct;
    typedef csObjFixture_touchCountSet_in_struct csObjFixture_touchCount_Set_in;
    typedef csObjFixture_touchCountSet_in_struct_var csObjFixture_touchCount_Set_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjFixture_touchCount_Set_in;
    class  csObjFixture_touchCountSet_out_struct_var;
    struct  csObjFixture_touchCountSet_out_struct {
        typedef csObjFixture_touchCountSet_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csFixtureTouchCountInfo strFixtureTouchCountInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjFixture_touchCountSet_out_struct();
       csObjFixture_touchCountSet_out_struct(const csObjFixture_touchCountSet_out_struct&);
       csObjFixture_touchCountSet_out_struct& operator=(const csObjFixture_touchCountSet_out_struct&);
       static CORBA::Info<csObjFixture_touchCountSet_out_struct> csObjFixture_touchCountSet_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjFixture_touchCountSet_out_struct


typedef csObjFixture_touchCountSet_out_struct* csObjFixture_touchCountSet_out_struct_vPtr;
typedef const csObjFixture_touchCountSet_out_struct* csObjFixture_touchCountSet_out_struct_cvPtr;

class  csObjFixture_touchCountSet_out_struct_var
{
    public:

    csObjFixture_touchCountSet_out_struct_var ();

    csObjFixture_touchCountSet_out_struct_var (csObjFixture_touchCountSet_out_struct *_p);

    csObjFixture_touchCountSet_out_struct_var (const csObjFixture_touchCountSet_out_struct_var &_s);

    csObjFixture_touchCountSet_out_struct_var &operator= (csObjFixture_touchCountSet_out_struct *_p);

    csObjFixture_touchCountSet_out_struct_var &operator= (const csObjFixture_touchCountSet_out_struct_var &_s);

    ~csObjFixture_touchCountSet_out_struct_var ();

    csObjFixture_touchCountSet_out_struct* operator-> ();

    const csObjFixture_touchCountSet_out_struct& in() const;
    csObjFixture_touchCountSet_out_struct& inout();
    csObjFixture_touchCountSet_out_struct*& out();
    csObjFixture_touchCountSet_out_struct* _retn();

    operator csObjFixture_touchCountSet_out_struct_cvPtr () const;

    operator csObjFixture_touchCountSet_out_struct_vPtr& ();

    operator const csObjFixture_touchCountSet_out_struct& () const;

    operator csObjFixture_touchCountSet_out_struct& ();

    protected:
    csObjFixture_touchCountSet_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjFixture_touchCountSet_out_struct;
    typedef csObjFixture_touchCountSet_out_struct csObjFixture_touchCount_Set_out;
    typedef csObjFixture_touchCountSet_out_struct_var csObjFixture_touchCount_Set_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjFixture_touchCount_Set_out;
    class  csObjFixture_touchCount_Get_in_struct_var;
    struct  csObjFixture_touchCount_Get_in_struct {
        typedef csObjFixture_touchCount_Get_in_struct_var _var_type;
       ::objectIdentifier fixtureID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjFixture_touchCount_Get_in_struct();
       csObjFixture_touchCount_Get_in_struct(const csObjFixture_touchCount_Get_in_struct&);
       csObjFixture_touchCount_Get_in_struct& operator=(const csObjFixture_touchCount_Get_in_struct&);
       static CORBA::Info<csObjFixture_touchCount_Get_in_struct> csObjFixture_touchCount_Get_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjFixture_touchCount_Get_in_struct


typedef csObjFixture_touchCount_Get_in_struct* csObjFixture_touchCount_Get_in_struct_vPtr;
typedef const csObjFixture_touchCount_Get_in_struct* csObjFixture_touchCount_Get_in_struct_cvPtr;

class  csObjFixture_touchCount_Get_in_struct_var
{
    public:

    csObjFixture_touchCount_Get_in_struct_var ();

    csObjFixture_touchCount_Get_in_struct_var (csObjFixture_touchCount_Get_in_struct *_p);

    csObjFixture_touchCount_Get_in_struct_var (const csObjFixture_touchCount_Get_in_struct_var &_s);

    csObjFixture_touchCount_Get_in_struct_var &operator= (csObjFixture_touchCount_Get_in_struct *_p);

    csObjFixture_touchCount_Get_in_struct_var &operator= (const csObjFixture_touchCount_Get_in_struct_var &_s);

    ~csObjFixture_touchCount_Get_in_struct_var ();

    csObjFixture_touchCount_Get_in_struct* operator-> ();

    const csObjFixture_touchCount_Get_in_struct& in() const;
    csObjFixture_touchCount_Get_in_struct& inout();
    csObjFixture_touchCount_Get_in_struct*& out();
    csObjFixture_touchCount_Get_in_struct* _retn();

    operator csObjFixture_touchCount_Get_in_struct_cvPtr () const;

    operator csObjFixture_touchCount_Get_in_struct_vPtr& ();

    operator const csObjFixture_touchCount_Get_in_struct& () const;

    operator csObjFixture_touchCount_Get_in_struct& ();

    protected:
    csObjFixture_touchCount_Get_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjFixture_touchCount_Get_in_struct;
    typedef csObjFixture_touchCount_Get_in_struct csObjFixture_touchCount_Get_in;
    typedef csObjFixture_touchCount_Get_in_struct_var csObjFixture_touchCount_Get_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjFixture_touchCount_Get_in;
    class  csObjFixture_touchCount_Get_out_struct_var;
    struct  csObjFixture_touchCount_Get_out_struct {
        typedef csObjFixture_touchCount_Get_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csFixtureTouchCountInfo strFixtureTouchCountInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjFixture_touchCount_Get_out_struct();
       csObjFixture_touchCount_Get_out_struct(const csObjFixture_touchCount_Get_out_struct&);
       csObjFixture_touchCount_Get_out_struct& operator=(const csObjFixture_touchCount_Get_out_struct&);
       static CORBA::Info<csObjFixture_touchCount_Get_out_struct> csObjFixture_touchCount_Get_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjFixture_touchCount_Get_out_struct


typedef csObjFixture_touchCount_Get_out_struct* csObjFixture_touchCount_Get_out_struct_vPtr;
typedef const csObjFixture_touchCount_Get_out_struct* csObjFixture_touchCount_Get_out_struct_cvPtr;

class  csObjFixture_touchCount_Get_out_struct_var
{
    public:

    csObjFixture_touchCount_Get_out_struct_var ();

    csObjFixture_touchCount_Get_out_struct_var (csObjFixture_touchCount_Get_out_struct *_p);

    csObjFixture_touchCount_Get_out_struct_var (const csObjFixture_touchCount_Get_out_struct_var &_s);

    csObjFixture_touchCount_Get_out_struct_var &operator= (csObjFixture_touchCount_Get_out_struct *_p);

    csObjFixture_touchCount_Get_out_struct_var &operator= (const csObjFixture_touchCount_Get_out_struct_var &_s);

    ~csObjFixture_touchCount_Get_out_struct_var ();

    csObjFixture_touchCount_Get_out_struct* operator-> ();

    const csObjFixture_touchCount_Get_out_struct& in() const;
    csObjFixture_touchCount_Get_out_struct& inout();
    csObjFixture_touchCount_Get_out_struct*& out();
    csObjFixture_touchCount_Get_out_struct* _retn();

    operator csObjFixture_touchCount_Get_out_struct_cvPtr () const;

    operator csObjFixture_touchCount_Get_out_struct_vPtr& ();

    operator const csObjFixture_touchCount_Get_out_struct& () const;

    operator csObjFixture_touchCount_Get_out_struct& ();

    protected:
    csObjFixture_touchCount_Get_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjFixture_touchCount_Get_out_struct;
    typedef csObjFixture_touchCount_Get_out_struct csObjFixture_touchCount_Get_out;
    typedef csObjFixture_touchCount_Get_out_struct_var csObjFixture_touchCount_Get_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjFixture_touchCount_Get_out;
    class  csObjWafer_userDataInfo_GetDR_in_struct_var;
    struct  csObjWafer_userDataInfo_GetDR_in_struct {
        typedef csObjWafer_userDataInfo_GetDR_in_struct_var _var_type;
       ::objectIdentifier waferID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjWafer_userDataInfo_GetDR_in_struct();
       csObjWafer_userDataInfo_GetDR_in_struct(const csObjWafer_userDataInfo_GetDR_in_struct&);
       csObjWafer_userDataInfo_GetDR_in_struct& operator=(const csObjWafer_userDataInfo_GetDR_in_struct&);
       static CORBA::Info<csObjWafer_userDataInfo_GetDR_in_struct> csObjWafer_userDataInfo_GetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjWafer_userDataInfo_GetDR_in_struct


typedef csObjWafer_userDataInfo_GetDR_in_struct* csObjWafer_userDataInfo_GetDR_in_struct_vPtr;
typedef const csObjWafer_userDataInfo_GetDR_in_struct* csObjWafer_userDataInfo_GetDR_in_struct_cvPtr;

class  csObjWafer_userDataInfo_GetDR_in_struct_var
{
    public:

    csObjWafer_userDataInfo_GetDR_in_struct_var ();

    csObjWafer_userDataInfo_GetDR_in_struct_var (csObjWafer_userDataInfo_GetDR_in_struct *_p);

    csObjWafer_userDataInfo_GetDR_in_struct_var (const csObjWafer_userDataInfo_GetDR_in_struct_var &_s);

    csObjWafer_userDataInfo_GetDR_in_struct_var &operator= (csObjWafer_userDataInfo_GetDR_in_struct *_p);

    csObjWafer_userDataInfo_GetDR_in_struct_var &operator= (const csObjWafer_userDataInfo_GetDR_in_struct_var &_s);

    ~csObjWafer_userDataInfo_GetDR_in_struct_var ();

    csObjWafer_userDataInfo_GetDR_in_struct* operator-> ();

    const csObjWafer_userDataInfo_GetDR_in_struct& in() const;
    csObjWafer_userDataInfo_GetDR_in_struct& inout();
    csObjWafer_userDataInfo_GetDR_in_struct*& out();
    csObjWafer_userDataInfo_GetDR_in_struct* _retn();

    operator csObjWafer_userDataInfo_GetDR_in_struct_cvPtr () const;

    operator csObjWafer_userDataInfo_GetDR_in_struct_vPtr& ();

    operator const csObjWafer_userDataInfo_GetDR_in_struct& () const;

    operator csObjWafer_userDataInfo_GetDR_in_struct& ();

    protected:
    csObjWafer_userDataInfo_GetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjWafer_userDataInfo_GetDR_in_struct;
    typedef csObjWafer_userDataInfo_GetDR_in_struct csObjWafer_userDataInfo_GetDR_in;
    typedef csObjWafer_userDataInfo_GetDR_in_struct_var csObjWafer_userDataInfo_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjWafer_userDataInfo_GetDR_in;
    class  csObjWafer_userDataInfo_GetDR_out_struct_var;
    struct  csObjWafer_userDataInfo_GetDR_out_struct {
        typedef csObjWafer_userDataInfo_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::pptUserDataSequence strUserDataSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjWafer_userDataInfo_GetDR_out_struct();
       csObjWafer_userDataInfo_GetDR_out_struct(const csObjWafer_userDataInfo_GetDR_out_struct&);
       csObjWafer_userDataInfo_GetDR_out_struct& operator=(const csObjWafer_userDataInfo_GetDR_out_struct&);
       static CORBA::Info<csObjWafer_userDataInfo_GetDR_out_struct> csObjWafer_userDataInfo_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjWafer_userDataInfo_GetDR_out_struct


typedef csObjWafer_userDataInfo_GetDR_out_struct* csObjWafer_userDataInfo_GetDR_out_struct_vPtr;
typedef const csObjWafer_userDataInfo_GetDR_out_struct* csObjWafer_userDataInfo_GetDR_out_struct_cvPtr;

class  csObjWafer_userDataInfo_GetDR_out_struct_var
{
    public:

    csObjWafer_userDataInfo_GetDR_out_struct_var ();

    csObjWafer_userDataInfo_GetDR_out_struct_var (csObjWafer_userDataInfo_GetDR_out_struct *_p);

    csObjWafer_userDataInfo_GetDR_out_struct_var (const csObjWafer_userDataInfo_GetDR_out_struct_var &_s);

    csObjWafer_userDataInfo_GetDR_out_struct_var &operator= (csObjWafer_userDataInfo_GetDR_out_struct *_p);

    csObjWafer_userDataInfo_GetDR_out_struct_var &operator= (const csObjWafer_userDataInfo_GetDR_out_struct_var &_s);

    ~csObjWafer_userDataInfo_GetDR_out_struct_var ();

    csObjWafer_userDataInfo_GetDR_out_struct* operator-> ();

    const csObjWafer_userDataInfo_GetDR_out_struct& in() const;
    csObjWafer_userDataInfo_GetDR_out_struct& inout();
    csObjWafer_userDataInfo_GetDR_out_struct*& out();
    csObjWafer_userDataInfo_GetDR_out_struct* _retn();

    operator csObjWafer_userDataInfo_GetDR_out_struct_cvPtr () const;

    operator csObjWafer_userDataInfo_GetDR_out_struct_vPtr& ();

    operator const csObjWafer_userDataInfo_GetDR_out_struct& () const;

    operator csObjWafer_userDataInfo_GetDR_out_struct& ();

    protected:
    csObjWafer_userDataInfo_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjWafer_userDataInfo_GetDR_out_struct;
    typedef csObjWafer_userDataInfo_GetDR_out_struct csObjWafer_userDataInfo_GetDR_out;
    typedef csObjWafer_userDataInfo_GetDR_out_struct_var csObjWafer_userDataInfo_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjWafer_userDataInfo_GetDR_out;
    class  csObjDurable_userDataInfo_GetDR_in_struct_var;
    struct  csObjDurable_userDataInfo_GetDR_in_struct {
        typedef csObjDurable_userDataInfo_GetDR_in_struct_var _var_type;
       ::objectIdentifier durableID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjDurable_userDataInfo_GetDR_in_struct();
       csObjDurable_userDataInfo_GetDR_in_struct(const csObjDurable_userDataInfo_GetDR_in_struct&);
       csObjDurable_userDataInfo_GetDR_in_struct& operator=(const csObjDurable_userDataInfo_GetDR_in_struct&);
       static CORBA::Info<csObjDurable_userDataInfo_GetDR_in_struct> csObjDurable_userDataInfo_GetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjDurable_userDataInfo_GetDR_in_struct


typedef csObjDurable_userDataInfo_GetDR_in_struct* csObjDurable_userDataInfo_GetDR_in_struct_vPtr;
typedef const csObjDurable_userDataInfo_GetDR_in_struct* csObjDurable_userDataInfo_GetDR_in_struct_cvPtr;

class  csObjDurable_userDataInfo_GetDR_in_struct_var
{
    public:

    csObjDurable_userDataInfo_GetDR_in_struct_var ();

    csObjDurable_userDataInfo_GetDR_in_struct_var (csObjDurable_userDataInfo_GetDR_in_struct *_p);

    csObjDurable_userDataInfo_GetDR_in_struct_var (const csObjDurable_userDataInfo_GetDR_in_struct_var &_s);

    csObjDurable_userDataInfo_GetDR_in_struct_var &operator= (csObjDurable_userDataInfo_GetDR_in_struct *_p);

    csObjDurable_userDataInfo_GetDR_in_struct_var &operator= (const csObjDurable_userDataInfo_GetDR_in_struct_var &_s);

    ~csObjDurable_userDataInfo_GetDR_in_struct_var ();

    csObjDurable_userDataInfo_GetDR_in_struct* operator-> ();

    const csObjDurable_userDataInfo_GetDR_in_struct& in() const;
    csObjDurable_userDataInfo_GetDR_in_struct& inout();
    csObjDurable_userDataInfo_GetDR_in_struct*& out();
    csObjDurable_userDataInfo_GetDR_in_struct* _retn();

    operator csObjDurable_userDataInfo_GetDR_in_struct_cvPtr () const;

    operator csObjDurable_userDataInfo_GetDR_in_struct_vPtr& ();

    operator const csObjDurable_userDataInfo_GetDR_in_struct& () const;

    operator csObjDurable_userDataInfo_GetDR_in_struct& ();

    protected:
    csObjDurable_userDataInfo_GetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjDurable_userDataInfo_GetDR_in_struct;
    typedef csObjDurable_userDataInfo_GetDR_in_struct csObjDurable_userDataInfo_GetDR_in;
    typedef csObjDurable_userDataInfo_GetDR_in_struct_var csObjDurable_userDataInfo_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjDurable_userDataInfo_GetDR_in;
    class  csObjDurable_userDataInfo_GetDR_out_struct_var;
    struct  csObjDurable_userDataInfo_GetDR_out_struct {
        typedef csObjDurable_userDataInfo_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::pptUserDataSequence strUserDataSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjDurable_userDataInfo_GetDR_out_struct();
       csObjDurable_userDataInfo_GetDR_out_struct(const csObjDurable_userDataInfo_GetDR_out_struct&);
       csObjDurable_userDataInfo_GetDR_out_struct& operator=(const csObjDurable_userDataInfo_GetDR_out_struct&);
       static CORBA::Info<csObjDurable_userDataInfo_GetDR_out_struct> csObjDurable_userDataInfo_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjDurable_userDataInfo_GetDR_out_struct


typedef csObjDurable_userDataInfo_GetDR_out_struct* csObjDurable_userDataInfo_GetDR_out_struct_vPtr;
typedef const csObjDurable_userDataInfo_GetDR_out_struct* csObjDurable_userDataInfo_GetDR_out_struct_cvPtr;

class  csObjDurable_userDataInfo_GetDR_out_struct_var
{
    public:

    csObjDurable_userDataInfo_GetDR_out_struct_var ();

    csObjDurable_userDataInfo_GetDR_out_struct_var (csObjDurable_userDataInfo_GetDR_out_struct *_p);

    csObjDurable_userDataInfo_GetDR_out_struct_var (const csObjDurable_userDataInfo_GetDR_out_struct_var &_s);

    csObjDurable_userDataInfo_GetDR_out_struct_var &operator= (csObjDurable_userDataInfo_GetDR_out_struct *_p);

    csObjDurable_userDataInfo_GetDR_out_struct_var &operator= (const csObjDurable_userDataInfo_GetDR_out_struct_var &_s);

    ~csObjDurable_userDataInfo_GetDR_out_struct_var ();

    csObjDurable_userDataInfo_GetDR_out_struct* operator-> ();

    const csObjDurable_userDataInfo_GetDR_out_struct& in() const;
    csObjDurable_userDataInfo_GetDR_out_struct& inout();
    csObjDurable_userDataInfo_GetDR_out_struct*& out();
    csObjDurable_userDataInfo_GetDR_out_struct* _retn();

    operator csObjDurable_userDataInfo_GetDR_out_struct_cvPtr () const;

    operator csObjDurable_userDataInfo_GetDR_out_struct_vPtr& ();

    operator const csObjDurable_userDataInfo_GetDR_out_struct& () const;

    operator csObjDurable_userDataInfo_GetDR_out_struct& ();

    protected:
    csObjDurable_userDataInfo_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjDurable_userDataInfo_GetDR_out_struct;
    typedef csObjDurable_userDataInfo_GetDR_out_struct csObjDurable_userDataInfo_GetDR_out;
    typedef csObjDurable_userDataInfo_GetDR_out_struct_var csObjDurable_userDataInfo_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjDurable_userDataInfo_GetDR_out;
    class  csObjUserData_GetByOperation_in_struct_var;
    struct  csObjUserData_GetByOperation_in_struct {
        typedef csObjUserData_GetByOperation_in_struct_var _var_type;
       ::objectIdentifier routeID;
       ::CORBA::String_StructElem operationNumber;
       ::stringSequence userDataNameSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjUserData_GetByOperation_in_struct();
       csObjUserData_GetByOperation_in_struct(const csObjUserData_GetByOperation_in_struct&);
       csObjUserData_GetByOperation_in_struct& operator=(const csObjUserData_GetByOperation_in_struct&);
       static CORBA::Info<csObjUserData_GetByOperation_in_struct> csObjUserData_GetByOperation_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjUserData_GetByOperation_in_struct


typedef csObjUserData_GetByOperation_in_struct* csObjUserData_GetByOperation_in_struct_vPtr;
typedef const csObjUserData_GetByOperation_in_struct* csObjUserData_GetByOperation_in_struct_cvPtr;

class  csObjUserData_GetByOperation_in_struct_var
{
    public:

    csObjUserData_GetByOperation_in_struct_var ();

    csObjUserData_GetByOperation_in_struct_var (csObjUserData_GetByOperation_in_struct *_p);

    csObjUserData_GetByOperation_in_struct_var (const csObjUserData_GetByOperation_in_struct_var &_s);

    csObjUserData_GetByOperation_in_struct_var &operator= (csObjUserData_GetByOperation_in_struct *_p);

    csObjUserData_GetByOperation_in_struct_var &operator= (const csObjUserData_GetByOperation_in_struct_var &_s);

    ~csObjUserData_GetByOperation_in_struct_var ();

    csObjUserData_GetByOperation_in_struct* operator-> ();

    const csObjUserData_GetByOperation_in_struct& in() const;
    csObjUserData_GetByOperation_in_struct& inout();
    csObjUserData_GetByOperation_in_struct*& out();
    csObjUserData_GetByOperation_in_struct* _retn();

    operator csObjUserData_GetByOperation_in_struct_cvPtr () const;

    operator csObjUserData_GetByOperation_in_struct_vPtr& ();

    operator const csObjUserData_GetByOperation_in_struct& () const;

    operator csObjUserData_GetByOperation_in_struct& ();

    protected:
    csObjUserData_GetByOperation_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjUserData_GetByOperation_in_struct;
    typedef csObjUserData_GetByOperation_in_struct csObjUserData_GetByOperation_in;
    typedef csObjUserData_GetByOperation_in_struct_var csObjUserData_GetByOperation_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjUserData_GetByOperation_in;
    class  csObjUserData_GetByOperation_out_struct_var;
    struct  csObjUserData_GetByOperation_out_struct {
        typedef csObjUserData_GetByOperation_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::pptUserDataSequence strUserDataSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjUserData_GetByOperation_out_struct();
       csObjUserData_GetByOperation_out_struct(const csObjUserData_GetByOperation_out_struct&);
       csObjUserData_GetByOperation_out_struct& operator=(const csObjUserData_GetByOperation_out_struct&);
       static CORBA::Info<csObjUserData_GetByOperation_out_struct> csObjUserData_GetByOperation_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjUserData_GetByOperation_out_struct


typedef csObjUserData_GetByOperation_out_struct* csObjUserData_GetByOperation_out_struct_vPtr;
typedef const csObjUserData_GetByOperation_out_struct* csObjUserData_GetByOperation_out_struct_cvPtr;

class  csObjUserData_GetByOperation_out_struct_var
{
    public:

    csObjUserData_GetByOperation_out_struct_var ();

    csObjUserData_GetByOperation_out_struct_var (csObjUserData_GetByOperation_out_struct *_p);

    csObjUserData_GetByOperation_out_struct_var (const csObjUserData_GetByOperation_out_struct_var &_s);

    csObjUserData_GetByOperation_out_struct_var &operator= (csObjUserData_GetByOperation_out_struct *_p);

    csObjUserData_GetByOperation_out_struct_var &operator= (const csObjUserData_GetByOperation_out_struct_var &_s);

    ~csObjUserData_GetByOperation_out_struct_var ();

    csObjUserData_GetByOperation_out_struct* operator-> ();

    const csObjUserData_GetByOperation_out_struct& in() const;
    csObjUserData_GetByOperation_out_struct& inout();
    csObjUserData_GetByOperation_out_struct*& out();
    csObjUserData_GetByOperation_out_struct* _retn();

    operator csObjUserData_GetByOperation_out_struct_cvPtr () const;

    operator csObjUserData_GetByOperation_out_struct_vPtr& ();

    operator const csObjUserData_GetByOperation_out_struct& () const;

    operator csObjUserData_GetByOperation_out_struct& ();

    protected:
    csObjUserData_GetByOperation_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjUserData_GetByOperation_out_struct;
    typedef csObjUserData_GetByOperation_out_struct csObjUserData_GetByOperation_out;
    typedef csObjUserData_GetByOperation_out_struct_var csObjUserData_GetByOperation_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjUserData_GetByOperation_out;
    class  csObjAPC_LithoAvailable_CheckCondition_in_struct_var;
    struct  csObjAPC_LithoAvailable_CheckCondition_in_struct {
        typedef csObjAPC_LithoAvailable_CheckCondition_in_struct_var _var_type;
       ::objectIdentifier equipmentID;
       ::objectIdentifier routeID;
       ::CORBA::String_StructElem operationNumber;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPC_LithoAvailable_CheckCondition_in_struct();
       csObjAPC_LithoAvailable_CheckCondition_in_struct(const csObjAPC_LithoAvailable_CheckCondition_in_struct&);
       csObjAPC_LithoAvailable_CheckCondition_in_struct& operator=(const csObjAPC_LithoAvailable_CheckCondition_in_struct&);
       static CORBA::Info<csObjAPC_LithoAvailable_CheckCondition_in_struct> csObjAPC_LithoAvailable_CheckCondition_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPC_LithoAvailable_CheckCondition_in_struct


typedef csObjAPC_LithoAvailable_CheckCondition_in_struct* csObjAPC_LithoAvailable_CheckCondition_in_struct_vPtr;
typedef const csObjAPC_LithoAvailable_CheckCondition_in_struct* csObjAPC_LithoAvailable_CheckCondition_in_struct_cvPtr;

class  csObjAPC_LithoAvailable_CheckCondition_in_struct_var
{
    public:

    csObjAPC_LithoAvailable_CheckCondition_in_struct_var ();

    csObjAPC_LithoAvailable_CheckCondition_in_struct_var (csObjAPC_LithoAvailable_CheckCondition_in_struct *_p);

    csObjAPC_LithoAvailable_CheckCondition_in_struct_var (const csObjAPC_LithoAvailable_CheckCondition_in_struct_var &_s);

    csObjAPC_LithoAvailable_CheckCondition_in_struct_var &operator= (csObjAPC_LithoAvailable_CheckCondition_in_struct *_p);

    csObjAPC_LithoAvailable_CheckCondition_in_struct_var &operator= (const csObjAPC_LithoAvailable_CheckCondition_in_struct_var &_s);

    ~csObjAPC_LithoAvailable_CheckCondition_in_struct_var ();

    csObjAPC_LithoAvailable_CheckCondition_in_struct* operator-> ();

    const csObjAPC_LithoAvailable_CheckCondition_in_struct& in() const;
    csObjAPC_LithoAvailable_CheckCondition_in_struct& inout();
    csObjAPC_LithoAvailable_CheckCondition_in_struct*& out();
    csObjAPC_LithoAvailable_CheckCondition_in_struct* _retn();

    operator csObjAPC_LithoAvailable_CheckCondition_in_struct_cvPtr () const;

    operator csObjAPC_LithoAvailable_CheckCondition_in_struct_vPtr& ();

    operator const csObjAPC_LithoAvailable_CheckCondition_in_struct& () const;

    operator csObjAPC_LithoAvailable_CheckCondition_in_struct& ();

    protected:
    csObjAPC_LithoAvailable_CheckCondition_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoAvailable_CheckCondition_in_struct;
    typedef csObjAPC_LithoAvailable_CheckCondition_in_struct csObjAPC_LithoAvailable_CheckCondition_in;
    typedef csObjAPC_LithoAvailable_CheckCondition_in_struct_var csObjAPC_LithoAvailable_CheckCondition_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoAvailable_CheckCondition_in;
    class  csObjAPC_LithoAvailable_CheckCondition_out_struct_var;
    struct  csObjAPC_LithoAvailable_CheckCondition_out_struct {
        typedef csObjAPC_LithoAvailable_CheckCondition_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::String_StructElem inquireType;
       ::CORBA::Boolean recommendFlag;
       ::CORBA::Boolean usedFlag;
       ::CORBA::Boolean metrologyFlag;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPC_LithoAvailable_CheckCondition_out_struct();
       csObjAPC_LithoAvailable_CheckCondition_out_struct(const csObjAPC_LithoAvailable_CheckCondition_out_struct&);
       csObjAPC_LithoAvailable_CheckCondition_out_struct& operator=(const csObjAPC_LithoAvailable_CheckCondition_out_struct&);
       static CORBA::Info<csObjAPC_LithoAvailable_CheckCondition_out_struct> csObjAPC_LithoAvailable_CheckCondition_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPC_LithoAvailable_CheckCondition_out_struct


typedef csObjAPC_LithoAvailable_CheckCondition_out_struct* csObjAPC_LithoAvailable_CheckCondition_out_struct_vPtr;
typedef const csObjAPC_LithoAvailable_CheckCondition_out_struct* csObjAPC_LithoAvailable_CheckCondition_out_struct_cvPtr;

class  csObjAPC_LithoAvailable_CheckCondition_out_struct_var
{
    public:

    csObjAPC_LithoAvailable_CheckCondition_out_struct_var ();

    csObjAPC_LithoAvailable_CheckCondition_out_struct_var (csObjAPC_LithoAvailable_CheckCondition_out_struct *_p);

    csObjAPC_LithoAvailable_CheckCondition_out_struct_var (const csObjAPC_LithoAvailable_CheckCondition_out_struct_var &_s);

    csObjAPC_LithoAvailable_CheckCondition_out_struct_var &operator= (csObjAPC_LithoAvailable_CheckCondition_out_struct *_p);

    csObjAPC_LithoAvailable_CheckCondition_out_struct_var &operator= (const csObjAPC_LithoAvailable_CheckCondition_out_struct_var &_s);

    ~csObjAPC_LithoAvailable_CheckCondition_out_struct_var ();

    csObjAPC_LithoAvailable_CheckCondition_out_struct* operator-> ();

    const csObjAPC_LithoAvailable_CheckCondition_out_struct& in() const;
    csObjAPC_LithoAvailable_CheckCondition_out_struct& inout();
    csObjAPC_LithoAvailable_CheckCondition_out_struct*& out();
    csObjAPC_LithoAvailable_CheckCondition_out_struct* _retn();

    operator csObjAPC_LithoAvailable_CheckCondition_out_struct_cvPtr () const;

    operator csObjAPC_LithoAvailable_CheckCondition_out_struct_vPtr& ();

    operator const csObjAPC_LithoAvailable_CheckCondition_out_struct& () const;

    operator csObjAPC_LithoAvailable_CheckCondition_out_struct& ();

    protected:
    csObjAPC_LithoAvailable_CheckCondition_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoAvailable_CheckCondition_out_struct;
    typedef csObjAPC_LithoAvailable_CheckCondition_out_struct csObjAPC_LithoAvailable_CheckCondition_out;
    typedef csObjAPC_LithoAvailable_CheckCondition_out_struct_var csObjAPC_LithoAvailable_CheckCondition_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoAvailable_CheckCondition_out;
    class  csObjAPC_LithoLotDataInfo_Get_in_struct_var;
    struct  csObjAPC_LithoLotDataInfo_Get_in_struct {
        typedef csObjAPC_LithoLotDataInfo_Get_in_struct_var _var_type;
       ::objectIdentifier lotID;
       ::objectIdentifier routeID;
       ::CORBA::String_StructElem operationNumber;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPC_LithoLotDataInfo_Get_in_struct();
       csObjAPC_LithoLotDataInfo_Get_in_struct(const csObjAPC_LithoLotDataInfo_Get_in_struct&);
       csObjAPC_LithoLotDataInfo_Get_in_struct& operator=(const csObjAPC_LithoLotDataInfo_Get_in_struct&);
       static CORBA::Info<csObjAPC_LithoLotDataInfo_Get_in_struct> csObjAPC_LithoLotDataInfo_Get_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPC_LithoLotDataInfo_Get_in_struct


typedef csObjAPC_LithoLotDataInfo_Get_in_struct* csObjAPC_LithoLotDataInfo_Get_in_struct_vPtr;
typedef const csObjAPC_LithoLotDataInfo_Get_in_struct* csObjAPC_LithoLotDataInfo_Get_in_struct_cvPtr;

class  csObjAPC_LithoLotDataInfo_Get_in_struct_var
{
    public:

    csObjAPC_LithoLotDataInfo_Get_in_struct_var ();

    csObjAPC_LithoLotDataInfo_Get_in_struct_var (csObjAPC_LithoLotDataInfo_Get_in_struct *_p);

    csObjAPC_LithoLotDataInfo_Get_in_struct_var (const csObjAPC_LithoLotDataInfo_Get_in_struct_var &_s);

    csObjAPC_LithoLotDataInfo_Get_in_struct_var &operator= (csObjAPC_LithoLotDataInfo_Get_in_struct *_p);

    csObjAPC_LithoLotDataInfo_Get_in_struct_var &operator= (const csObjAPC_LithoLotDataInfo_Get_in_struct_var &_s);

    ~csObjAPC_LithoLotDataInfo_Get_in_struct_var ();

    csObjAPC_LithoLotDataInfo_Get_in_struct* operator-> ();

    const csObjAPC_LithoLotDataInfo_Get_in_struct& in() const;
    csObjAPC_LithoLotDataInfo_Get_in_struct& inout();
    csObjAPC_LithoLotDataInfo_Get_in_struct*& out();
    csObjAPC_LithoLotDataInfo_Get_in_struct* _retn();

    operator csObjAPC_LithoLotDataInfo_Get_in_struct_cvPtr () const;

    operator csObjAPC_LithoLotDataInfo_Get_in_struct_vPtr& ();

    operator const csObjAPC_LithoLotDataInfo_Get_in_struct& () const;

    operator csObjAPC_LithoLotDataInfo_Get_in_struct& ();

    protected:
    csObjAPC_LithoLotDataInfo_Get_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoLotDataInfo_Get_in_struct;
    typedef csObjAPC_LithoLotDataInfo_Get_in_struct csObjAPC_LithoLotDataInfo_Get_in;
    typedef csObjAPC_LithoLotDataInfo_Get_in_struct_var csObjAPC_LithoLotDataInfo_Get_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoLotDataInfo_Get_in;
    class  csObjAPC_LithoLotDataInfo_Get_out_struct_var;
    struct  csObjAPC_LithoLotDataInfo_Get_out_struct {
        typedef csObjAPC_LithoLotDataInfo_Get_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csLithoLotDataInfo strLithoLotDataInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPC_LithoLotDataInfo_Get_out_struct();
       csObjAPC_LithoLotDataInfo_Get_out_struct(const csObjAPC_LithoLotDataInfo_Get_out_struct&);
       csObjAPC_LithoLotDataInfo_Get_out_struct& operator=(const csObjAPC_LithoLotDataInfo_Get_out_struct&);
       static CORBA::Info<csObjAPC_LithoLotDataInfo_Get_out_struct> csObjAPC_LithoLotDataInfo_Get_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPC_LithoLotDataInfo_Get_out_struct


typedef csObjAPC_LithoLotDataInfo_Get_out_struct* csObjAPC_LithoLotDataInfo_Get_out_struct_vPtr;
typedef const csObjAPC_LithoLotDataInfo_Get_out_struct* csObjAPC_LithoLotDataInfo_Get_out_struct_cvPtr;

class  csObjAPC_LithoLotDataInfo_Get_out_struct_var
{
    public:

    csObjAPC_LithoLotDataInfo_Get_out_struct_var ();

    csObjAPC_LithoLotDataInfo_Get_out_struct_var (csObjAPC_LithoLotDataInfo_Get_out_struct *_p);

    csObjAPC_LithoLotDataInfo_Get_out_struct_var (const csObjAPC_LithoLotDataInfo_Get_out_struct_var &_s);

    csObjAPC_LithoLotDataInfo_Get_out_struct_var &operator= (csObjAPC_LithoLotDataInfo_Get_out_struct *_p);

    csObjAPC_LithoLotDataInfo_Get_out_struct_var &operator= (const csObjAPC_LithoLotDataInfo_Get_out_struct_var &_s);

    ~csObjAPC_LithoLotDataInfo_Get_out_struct_var ();

    csObjAPC_LithoLotDataInfo_Get_out_struct* operator-> ();

    const csObjAPC_LithoLotDataInfo_Get_out_struct& in() const;
    csObjAPC_LithoLotDataInfo_Get_out_struct& inout();
    csObjAPC_LithoLotDataInfo_Get_out_struct*& out();
    csObjAPC_LithoLotDataInfo_Get_out_struct* _retn();

    operator csObjAPC_LithoLotDataInfo_Get_out_struct_cvPtr () const;

    operator csObjAPC_LithoLotDataInfo_Get_out_struct_vPtr& ();

    operator const csObjAPC_LithoLotDataInfo_Get_out_struct& () const;

    operator csObjAPC_LithoLotDataInfo_Get_out_struct& ();

    protected:
    csObjAPC_LithoLotDataInfo_Get_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoLotDataInfo_Get_out_struct;
    typedef csObjAPC_LithoLotDataInfo_Get_out_struct csObjAPC_LithoLotDataInfo_Get_out;
    typedef csObjAPC_LithoLotDataInfo_Get_out_struct_var csObjAPC_LithoLotDataInfo_Get_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoLotDataInfo_Get_out;
    class  csObjAPC_LithoContextInfo_Get_in_struct_var;
    struct  csObjAPC_LithoContextInfo_Get_in_struct {
        typedef csObjAPC_LithoContextInfo_Get_in_struct_var _var_type;
       ::objectIdentifier equipmentID;
       ::pptLotInCassette strLotInCassette;
       ::CORBA::String_StructElem action;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPC_LithoContextInfo_Get_in_struct();
       csObjAPC_LithoContextInfo_Get_in_struct(const csObjAPC_LithoContextInfo_Get_in_struct&);
       csObjAPC_LithoContextInfo_Get_in_struct& operator=(const csObjAPC_LithoContextInfo_Get_in_struct&);
       static CORBA::Info<csObjAPC_LithoContextInfo_Get_in_struct> csObjAPC_LithoContextInfo_Get_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPC_LithoContextInfo_Get_in_struct


typedef csObjAPC_LithoContextInfo_Get_in_struct* csObjAPC_LithoContextInfo_Get_in_struct_vPtr;
typedef const csObjAPC_LithoContextInfo_Get_in_struct* csObjAPC_LithoContextInfo_Get_in_struct_cvPtr;

class  csObjAPC_LithoContextInfo_Get_in_struct_var
{
    public:

    csObjAPC_LithoContextInfo_Get_in_struct_var ();

    csObjAPC_LithoContextInfo_Get_in_struct_var (csObjAPC_LithoContextInfo_Get_in_struct *_p);

    csObjAPC_LithoContextInfo_Get_in_struct_var (const csObjAPC_LithoContextInfo_Get_in_struct_var &_s);

    csObjAPC_LithoContextInfo_Get_in_struct_var &operator= (csObjAPC_LithoContextInfo_Get_in_struct *_p);

    csObjAPC_LithoContextInfo_Get_in_struct_var &operator= (const csObjAPC_LithoContextInfo_Get_in_struct_var &_s);

    ~csObjAPC_LithoContextInfo_Get_in_struct_var ();

    csObjAPC_LithoContextInfo_Get_in_struct* operator-> ();

    const csObjAPC_LithoContextInfo_Get_in_struct& in() const;
    csObjAPC_LithoContextInfo_Get_in_struct& inout();
    csObjAPC_LithoContextInfo_Get_in_struct*& out();
    csObjAPC_LithoContextInfo_Get_in_struct* _retn();

    operator csObjAPC_LithoContextInfo_Get_in_struct_cvPtr () const;

    operator csObjAPC_LithoContextInfo_Get_in_struct_vPtr& ();

    operator const csObjAPC_LithoContextInfo_Get_in_struct& () const;

    operator csObjAPC_LithoContextInfo_Get_in_struct& ();

    protected:
    csObjAPC_LithoContextInfo_Get_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoContextInfo_Get_in_struct;
    typedef csObjAPC_LithoContextInfo_Get_in_struct csObjAPC_LithoContextInfo_Get_in;
    typedef csObjAPC_LithoContextInfo_Get_in_struct_var csObjAPC_LithoContextInfo_Get_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoContextInfo_Get_in;
    class  csObjAPC_LithoContextInfo_Get_out_struct_var;
    struct  csObjAPC_LithoContextInfo_Get_out_struct {
        typedef csObjAPC_LithoContextInfo_Get_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csAPCLithoContextInfo strAPCLithoContextInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPC_LithoContextInfo_Get_out_struct();
       csObjAPC_LithoContextInfo_Get_out_struct(const csObjAPC_LithoContextInfo_Get_out_struct&);
       csObjAPC_LithoContextInfo_Get_out_struct& operator=(const csObjAPC_LithoContextInfo_Get_out_struct&);
       static CORBA::Info<csObjAPC_LithoContextInfo_Get_out_struct> csObjAPC_LithoContextInfo_Get_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPC_LithoContextInfo_Get_out_struct


typedef csObjAPC_LithoContextInfo_Get_out_struct* csObjAPC_LithoContextInfo_Get_out_struct_vPtr;
typedef const csObjAPC_LithoContextInfo_Get_out_struct* csObjAPC_LithoContextInfo_Get_out_struct_cvPtr;

class  csObjAPC_LithoContextInfo_Get_out_struct_var
{
    public:

    csObjAPC_LithoContextInfo_Get_out_struct_var ();

    csObjAPC_LithoContextInfo_Get_out_struct_var (csObjAPC_LithoContextInfo_Get_out_struct *_p);

    csObjAPC_LithoContextInfo_Get_out_struct_var (const csObjAPC_LithoContextInfo_Get_out_struct_var &_s);

    csObjAPC_LithoContextInfo_Get_out_struct_var &operator= (csObjAPC_LithoContextInfo_Get_out_struct *_p);

    csObjAPC_LithoContextInfo_Get_out_struct_var &operator= (const csObjAPC_LithoContextInfo_Get_out_struct_var &_s);

    ~csObjAPC_LithoContextInfo_Get_out_struct_var ();

    csObjAPC_LithoContextInfo_Get_out_struct* operator-> ();

    const csObjAPC_LithoContextInfo_Get_out_struct& in() const;
    csObjAPC_LithoContextInfo_Get_out_struct& inout();
    csObjAPC_LithoContextInfo_Get_out_struct*& out();
    csObjAPC_LithoContextInfo_Get_out_struct* _retn();

    operator csObjAPC_LithoContextInfo_Get_out_struct_cvPtr () const;

    operator csObjAPC_LithoContextInfo_Get_out_struct_vPtr& ();

    operator const csObjAPC_LithoContextInfo_Get_out_struct& () const;

    operator csObjAPC_LithoContextInfo_Get_out_struct& ();

    protected:
    csObjAPC_LithoContextInfo_Get_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoContextInfo_Get_out_struct;
    typedef csObjAPC_LithoContextInfo_Get_out_struct csObjAPC_LithoContextInfo_Get_out;
    typedef csObjAPC_LithoContextInfo_Get_out_struct_var csObjAPC_LithoContextInfo_Get_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LithoContextInfo_Get_out;
    class  csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var;
    struct  csObjAPCMgr_SendLithoUsedInfoReq_in_struct {
        typedef csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var _var_type;
       ::objectIdentifier equipmentID;
       ::pptStartCassetteSequence strStartCassette;
       ::CORBA::String_StructElem action;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPCMgr_SendLithoUsedInfoReq_in_struct();
       csObjAPCMgr_SendLithoUsedInfoReq_in_struct(const csObjAPCMgr_SendLithoUsedInfoReq_in_struct&);
       csObjAPCMgr_SendLithoUsedInfoReq_in_struct& operator=(const csObjAPCMgr_SendLithoUsedInfoReq_in_struct&);
       static CORBA::Info<csObjAPCMgr_SendLithoUsedInfoReq_in_struct> csObjAPCMgr_SendLithoUsedInfoReq_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPCMgr_SendLithoUsedInfoReq_in_struct


typedef csObjAPCMgr_SendLithoUsedInfoReq_in_struct* csObjAPCMgr_SendLithoUsedInfoReq_in_struct_vPtr;
typedef const csObjAPCMgr_SendLithoUsedInfoReq_in_struct* csObjAPCMgr_SendLithoUsedInfoReq_in_struct_cvPtr;

class  csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var
{
    public:

    csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var ();

    csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var (csObjAPCMgr_SendLithoUsedInfoReq_in_struct *_p);

    csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var (const csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var &_s);

    csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var &operator= (csObjAPCMgr_SendLithoUsedInfoReq_in_struct *_p);

    csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var &operator= (const csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var &_s);

    ~csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var ();

    csObjAPCMgr_SendLithoUsedInfoReq_in_struct* operator-> ();

    const csObjAPCMgr_SendLithoUsedInfoReq_in_struct& in() const;
    csObjAPCMgr_SendLithoUsedInfoReq_in_struct& inout();
    csObjAPCMgr_SendLithoUsedInfoReq_in_struct*& out();
    csObjAPCMgr_SendLithoUsedInfoReq_in_struct* _retn();

    operator csObjAPCMgr_SendLithoUsedInfoReq_in_struct_cvPtr () const;

    operator csObjAPCMgr_SendLithoUsedInfoReq_in_struct_vPtr& ();

    operator const csObjAPCMgr_SendLithoUsedInfoReq_in_struct& () const;

    operator csObjAPCMgr_SendLithoUsedInfoReq_in_struct& ();

    protected:
    csObjAPCMgr_SendLithoUsedInfoReq_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoUsedInfoReq_in_struct;
    typedef csObjAPCMgr_SendLithoUsedInfoReq_in_struct csObjAPCMgr_SendLithoUsedInfoReq_in;
    typedef csObjAPCMgr_SendLithoUsedInfoReq_in_struct_var csObjAPCMgr_SendLithoUsedInfoReq_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoUsedInfoReq_in;
    class  csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var;
    struct  csObjAPCMgr_SendLithoUsedInfoReq_out_struct {
        typedef csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPCMgr_SendLithoUsedInfoReq_out_struct();
       csObjAPCMgr_SendLithoUsedInfoReq_out_struct(const csObjAPCMgr_SendLithoUsedInfoReq_out_struct&);
       csObjAPCMgr_SendLithoUsedInfoReq_out_struct& operator=(const csObjAPCMgr_SendLithoUsedInfoReq_out_struct&);
       static CORBA::Info<csObjAPCMgr_SendLithoUsedInfoReq_out_struct> csObjAPCMgr_SendLithoUsedInfoReq_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPCMgr_SendLithoUsedInfoReq_out_struct


typedef csObjAPCMgr_SendLithoUsedInfoReq_out_struct* csObjAPCMgr_SendLithoUsedInfoReq_out_struct_vPtr;
typedef const csObjAPCMgr_SendLithoUsedInfoReq_out_struct* csObjAPCMgr_SendLithoUsedInfoReq_out_struct_cvPtr;

class  csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var
{
    public:

    csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var ();

    csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var (csObjAPCMgr_SendLithoUsedInfoReq_out_struct *_p);

    csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var (const csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var &_s);

    csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var &operator= (csObjAPCMgr_SendLithoUsedInfoReq_out_struct *_p);

    csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var &operator= (const csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var &_s);

    ~csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var ();

    csObjAPCMgr_SendLithoUsedInfoReq_out_struct* operator-> ();

    const csObjAPCMgr_SendLithoUsedInfoReq_out_struct& in() const;
    csObjAPCMgr_SendLithoUsedInfoReq_out_struct& inout();
    csObjAPCMgr_SendLithoUsedInfoReq_out_struct*& out();
    csObjAPCMgr_SendLithoUsedInfoReq_out_struct* _retn();

    operator csObjAPCMgr_SendLithoUsedInfoReq_out_struct_cvPtr () const;

    operator csObjAPCMgr_SendLithoUsedInfoReq_out_struct_vPtr& ();

    operator const csObjAPCMgr_SendLithoUsedInfoReq_out_struct& () const;

    operator csObjAPCMgr_SendLithoUsedInfoReq_out_struct& ();

    protected:
    csObjAPCMgr_SendLithoUsedInfoReq_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoUsedInfoReq_out_struct;
    typedef csObjAPCMgr_SendLithoUsedInfoReq_out_struct csObjAPCMgr_SendLithoUsedInfoReq_out;
    typedef csObjAPCMgr_SendLithoUsedInfoReq_out_struct_var csObjAPCMgr_SendLithoUsedInfoReq_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoUsedInfoReq_out;
    class  csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var;
    struct  csObjAPCMgr_SendLithoRecommendInfoInq_in_struct {
        typedef csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var _var_type;
       ::objectIdentifier equipmentID;
       ::pptStartCassetteSequence strStartCassette;
       ::CORBA::String_StructElem action;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPCMgr_SendLithoRecommendInfoInq_in_struct();
       csObjAPCMgr_SendLithoRecommendInfoInq_in_struct(const csObjAPCMgr_SendLithoRecommendInfoInq_in_struct&);
       csObjAPCMgr_SendLithoRecommendInfoInq_in_struct& operator=(const csObjAPCMgr_SendLithoRecommendInfoInq_in_struct&);
       static CORBA::Info<csObjAPCMgr_SendLithoRecommendInfoInq_in_struct> csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPCMgr_SendLithoRecommendInfoInq_in_struct


typedef csObjAPCMgr_SendLithoRecommendInfoInq_in_struct* csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_vPtr;
typedef const csObjAPCMgr_SendLithoRecommendInfoInq_in_struct* csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_cvPtr;

class  csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var
{
    public:

    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var ();

    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var (csObjAPCMgr_SendLithoRecommendInfoInq_in_struct *_p);

    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var (const csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var &_s);

    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var &operator= (csObjAPCMgr_SendLithoRecommendInfoInq_in_struct *_p);

    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var &operator= (const csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var &_s);

    ~csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var ();

    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct* operator-> ();

    const csObjAPCMgr_SendLithoRecommendInfoInq_in_struct& in() const;
    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct& inout();
    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct*& out();
    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct* _retn();

    operator csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_cvPtr () const;

    operator csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_vPtr& ();

    operator const csObjAPCMgr_SendLithoRecommendInfoInq_in_struct& () const;

    operator csObjAPCMgr_SendLithoRecommendInfoInq_in_struct& ();

    protected:
    csObjAPCMgr_SendLithoRecommendInfoInq_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoRecommendInfoInq_in_struct;
    typedef csObjAPCMgr_SendLithoRecommendInfoInq_in_struct csObjAPCMgr_SendLithoRecommendInfoInq_in;
    typedef csObjAPCMgr_SendLithoRecommendInfoInq_in_struct_var csObjAPCMgr_SendLithoRecommendInfoInq_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoRecommendInfoInq_in;
    class  csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var;
    struct  csObjAPCMgr_SendLithoRecommendInfoInq_out_struct {
        typedef csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::pptStartCassetteSequence strStartCassette;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPCMgr_SendLithoRecommendInfoInq_out_struct();
       csObjAPCMgr_SendLithoRecommendInfoInq_out_struct(const csObjAPCMgr_SendLithoRecommendInfoInq_out_struct&);
       csObjAPCMgr_SendLithoRecommendInfoInq_out_struct& operator=(const csObjAPCMgr_SendLithoRecommendInfoInq_out_struct&);
       static CORBA::Info<csObjAPCMgr_SendLithoRecommendInfoInq_out_struct> csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPCMgr_SendLithoRecommendInfoInq_out_struct


typedef csObjAPCMgr_SendLithoRecommendInfoInq_out_struct* csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_vPtr;
typedef const csObjAPCMgr_SendLithoRecommendInfoInq_out_struct* csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_cvPtr;

class  csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var
{
    public:

    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var ();

    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var (csObjAPCMgr_SendLithoRecommendInfoInq_out_struct *_p);

    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var (const csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var &_s);

    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var &operator= (csObjAPCMgr_SendLithoRecommendInfoInq_out_struct *_p);

    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var &operator= (const csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var &_s);

    ~csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var ();

    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct* operator-> ();

    const csObjAPCMgr_SendLithoRecommendInfoInq_out_struct& in() const;
    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct& inout();
    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct*& out();
    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct* _retn();

    operator csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_cvPtr () const;

    operator csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_vPtr& ();

    operator const csObjAPCMgr_SendLithoRecommendInfoInq_out_struct& () const;

    operator csObjAPCMgr_SendLithoRecommendInfoInq_out_struct& ();

    protected:
    csObjAPCMgr_SendLithoRecommendInfoInq_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoRecommendInfoInq_out_struct;
    typedef csObjAPCMgr_SendLithoRecommendInfoInq_out_struct csObjAPCMgr_SendLithoRecommendInfoInq_out;
    typedef csObjAPCMgr_SendLithoRecommendInfoInq_out_struct_var csObjAPCMgr_SendLithoRecommendInfoInq_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoRecommendInfoInq_out;
    class  csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var;
    struct  csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct {
        typedef csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var _var_type;
       ::objectIdentifier equipmentID;
       ::pptStartCassetteSequence strStartCassette;
       ::CORBA::String_StructElem action;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct();
       csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct(const csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct&);
       csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct& operator=(const csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct&);
       static CORBA::Info<csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct> csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct


typedef csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct* csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_vPtr;
typedef const csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct* csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_cvPtr;

class  csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var
{
    public:

    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var ();

    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var (csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct *_p);

    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var (const csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var &_s);

    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var &operator= (csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct *_p);

    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var &operator= (const csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var &_s);

    ~csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var ();

    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct* operator-> ();

    const csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct& in() const;
    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct& inout();
    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct*& out();
    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct* _retn();

    operator csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_cvPtr () const;

    operator csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_vPtr& ();

    operator const csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct& () const;

    operator csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct& ();

    protected:
    csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct;
    typedef csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct csObjAPCMgr_SendLithoMetrologyInfoReq_in;
    typedef csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct_var csObjAPCMgr_SendLithoMetrologyInfoReq_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoMetrologyInfoReq_in;
    class  csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var;
    struct  csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct {
        typedef csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct();
       csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct(const csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct&);
       csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct& operator=(const csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct&);
       static CORBA::Info<csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct> csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct


typedef csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct* csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_vPtr;
typedef const csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct* csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_cvPtr;

class  csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var
{
    public:

    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var ();

    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var (csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct *_p);

    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var (const csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var &_s);

    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var &operator= (csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct *_p);

    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var &operator= (const csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var &_s);

    ~csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var ();

    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct* operator-> ();

    const csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct& in() const;
    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct& inout();
    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct*& out();
    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct* _retn();

    operator csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_cvPtr () const;

    operator csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_vPtr& ();

    operator const csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct& () const;

    operator csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct& ();

    protected:
    csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct;
    typedef csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct csObjAPCMgr_SendLithoMetrologyInfoReq_out;
    typedef csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct_var csObjAPCMgr_SendLithoMetrologyInfoReq_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPCMgr_SendLithoMetrologyInfoReq_out;
    class  csObjControlJob_BatchSize_Check_out_struct_var;
    struct  csObjControlJob_BatchSize_Check_out_struct {
        typedef csObjControlJob_BatchSize_Check_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjControlJob_BatchSize_Check_out_struct();
       csObjControlJob_BatchSize_Check_out_struct(const csObjControlJob_BatchSize_Check_out_struct&);
       csObjControlJob_BatchSize_Check_out_struct& operator=(const csObjControlJob_BatchSize_Check_out_struct&);
       static CORBA::Info<csObjControlJob_BatchSize_Check_out_struct> csObjControlJob_BatchSize_Check_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjControlJob_BatchSize_Check_out_struct


typedef csObjControlJob_BatchSize_Check_out_struct* csObjControlJob_BatchSize_Check_out_struct_vPtr;
typedef const csObjControlJob_BatchSize_Check_out_struct* csObjControlJob_BatchSize_Check_out_struct_cvPtr;

class  csObjControlJob_BatchSize_Check_out_struct_var
{
    public:

    csObjControlJob_BatchSize_Check_out_struct_var ();

    csObjControlJob_BatchSize_Check_out_struct_var (csObjControlJob_BatchSize_Check_out_struct *_p);

    csObjControlJob_BatchSize_Check_out_struct_var (const csObjControlJob_BatchSize_Check_out_struct_var &_s);

    csObjControlJob_BatchSize_Check_out_struct_var &operator= (csObjControlJob_BatchSize_Check_out_struct *_p);

    csObjControlJob_BatchSize_Check_out_struct_var &operator= (const csObjControlJob_BatchSize_Check_out_struct_var &_s);

    ~csObjControlJob_BatchSize_Check_out_struct_var ();

    csObjControlJob_BatchSize_Check_out_struct* operator-> ();

    const csObjControlJob_BatchSize_Check_out_struct& in() const;
    csObjControlJob_BatchSize_Check_out_struct& inout();
    csObjControlJob_BatchSize_Check_out_struct*& out();
    csObjControlJob_BatchSize_Check_out_struct* _retn();

    operator csObjControlJob_BatchSize_Check_out_struct_cvPtr () const;

    operator csObjControlJob_BatchSize_Check_out_struct_vPtr& ();

    operator const csObjControlJob_BatchSize_Check_out_struct& () const;

    operator csObjControlJob_BatchSize_Check_out_struct& ();

    protected:
    csObjControlJob_BatchSize_Check_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjControlJob_BatchSize_Check_out_struct;
    typedef csObjControlJob_BatchSize_Check_out_struct csObjControlJob_BatchSize_Check_out;
    typedef csObjControlJob_BatchSize_Check_out_struct_var csObjControlJob_BatchSize_Check_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjControlJob_BatchSize_Check_out;
    class  csObjControlJob_BatchSize_Check_in_struct_var;
    struct  csObjControlJob_BatchSize_Check_in_struct {
        typedef csObjControlJob_BatchSize_Check_in_struct_var _var_type;
       ::pptStartCassetteSequence strStartCassette;
       ::CORBA::Boolean skipBatchSizeFlag;
       ::CORBA::Boolean skipWaferCountFlag;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjControlJob_BatchSize_Check_in_struct();
       csObjControlJob_BatchSize_Check_in_struct(const csObjControlJob_BatchSize_Check_in_struct&);
       csObjControlJob_BatchSize_Check_in_struct& operator=(const csObjControlJob_BatchSize_Check_in_struct&);
       static CORBA::Info<csObjControlJob_BatchSize_Check_in_struct> csObjControlJob_BatchSize_Check_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjControlJob_BatchSize_Check_in_struct


typedef csObjControlJob_BatchSize_Check_in_struct* csObjControlJob_BatchSize_Check_in_struct_vPtr;
typedef const csObjControlJob_BatchSize_Check_in_struct* csObjControlJob_BatchSize_Check_in_struct_cvPtr;

class  csObjControlJob_BatchSize_Check_in_struct_var
{
    public:

    csObjControlJob_BatchSize_Check_in_struct_var ();

    csObjControlJob_BatchSize_Check_in_struct_var (csObjControlJob_BatchSize_Check_in_struct *_p);

    csObjControlJob_BatchSize_Check_in_struct_var (const csObjControlJob_BatchSize_Check_in_struct_var &_s);

    csObjControlJob_BatchSize_Check_in_struct_var &operator= (csObjControlJob_BatchSize_Check_in_struct *_p);

    csObjControlJob_BatchSize_Check_in_struct_var &operator= (const csObjControlJob_BatchSize_Check_in_struct_var &_s);

    ~csObjControlJob_BatchSize_Check_in_struct_var ();

    csObjControlJob_BatchSize_Check_in_struct* operator-> ();

    const csObjControlJob_BatchSize_Check_in_struct& in() const;
    csObjControlJob_BatchSize_Check_in_struct& inout();
    csObjControlJob_BatchSize_Check_in_struct*& out();
    csObjControlJob_BatchSize_Check_in_struct* _retn();

    operator csObjControlJob_BatchSize_Check_in_struct_cvPtr () const;

    operator csObjControlJob_BatchSize_Check_in_struct_vPtr& ();

    operator const csObjControlJob_BatchSize_Check_in_struct& () const;

    operator csObjControlJob_BatchSize_Check_in_struct& ();

    protected:
    csObjControlJob_BatchSize_Check_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjControlJob_BatchSize_Check_in_struct;
    typedef csObjControlJob_BatchSize_Check_in_struct csObjControlJob_BatchSize_Check_in;
    typedef csObjControlJob_BatchSize_Check_in_struct_var csObjControlJob_BatchSize_Check_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjControlJob_BatchSize_Check_in;
    class  csObjLotID_ControlInfo_GetDR_in_struct_var;
    struct  csObjLotID_ControlInfo_GetDR_in_struct {
        typedef csObjLotID_ControlInfo_GetDR_in_struct_var _var_type;
       ::CORBA::String_StructElem leadingChar;
       ::CORBA::String_StructElem year;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLotID_ControlInfo_GetDR_in_struct();
       csObjLotID_ControlInfo_GetDR_in_struct(const csObjLotID_ControlInfo_GetDR_in_struct&);
       csObjLotID_ControlInfo_GetDR_in_struct& operator=(const csObjLotID_ControlInfo_GetDR_in_struct&);
       static CORBA::Info<csObjLotID_ControlInfo_GetDR_in_struct> csObjLotID_ControlInfo_GetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csObjLotID_ControlInfo_GetDR_in_struct


typedef csObjLotID_ControlInfo_GetDR_in_struct* csObjLotID_ControlInfo_GetDR_in_struct_vPtr;
typedef const csObjLotID_ControlInfo_GetDR_in_struct* csObjLotID_ControlInfo_GetDR_in_struct_cvPtr;

class  csObjLotID_ControlInfo_GetDR_in_struct_var
{
    public:

    csObjLotID_ControlInfo_GetDR_in_struct_var ();

    csObjLotID_ControlInfo_GetDR_in_struct_var (csObjLotID_ControlInfo_GetDR_in_struct *_p);

    csObjLotID_ControlInfo_GetDR_in_struct_var (const csObjLotID_ControlInfo_GetDR_in_struct_var &_s);

    csObjLotID_ControlInfo_GetDR_in_struct_var &operator= (csObjLotID_ControlInfo_GetDR_in_struct *_p);

    csObjLotID_ControlInfo_GetDR_in_struct_var &operator= (const csObjLotID_ControlInfo_GetDR_in_struct_var &_s);

    ~csObjLotID_ControlInfo_GetDR_in_struct_var ();

    csObjLotID_ControlInfo_GetDR_in_struct* operator-> ();

    const csObjLotID_ControlInfo_GetDR_in_struct& in() const;
    csObjLotID_ControlInfo_GetDR_in_struct& inout();
    csObjLotID_ControlInfo_GetDR_in_struct*& out();
    csObjLotID_ControlInfo_GetDR_in_struct* _retn();

    operator csObjLotID_ControlInfo_GetDR_in_struct_cvPtr () const;

    operator csObjLotID_ControlInfo_GetDR_in_struct_vPtr& ();

    operator const csObjLotID_ControlInfo_GetDR_in_struct& () const;

    operator csObjLotID_ControlInfo_GetDR_in_struct& ();

    protected:
    csObjLotID_ControlInfo_GetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_GetDR_in_struct;
    typedef csObjLotID_ControlInfo_GetDR_in_struct csObjLotID_ControlInfo_GetDR_in;
    typedef csObjLotID_ControlInfo_GetDR_in_struct_var csObjLotID_ControlInfo_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_GetDR_in;
    class  csObjLotID_ControlInfo_GetDR_out_struct_var;
    struct  csObjLotID_ControlInfo_GetDR_out_struct {
        typedef csObjLotID_ControlInfo_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::String_StructElem leadingChar;
       ::CORBA::Long lastUsedNumber;
       ::CORBA::String_StructElem year;
       ::CORBA::String_StructElem subChar;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLotID_ControlInfo_GetDR_out_struct();
       csObjLotID_ControlInfo_GetDR_out_struct(const csObjLotID_ControlInfo_GetDR_out_struct&);
       csObjLotID_ControlInfo_GetDR_out_struct& operator=(const csObjLotID_ControlInfo_GetDR_out_struct&);
       static CORBA::Info<csObjLotID_ControlInfo_GetDR_out_struct> csObjLotID_ControlInfo_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjLotID_ControlInfo_GetDR_out_struct


typedef csObjLotID_ControlInfo_GetDR_out_struct* csObjLotID_ControlInfo_GetDR_out_struct_vPtr;
typedef const csObjLotID_ControlInfo_GetDR_out_struct* csObjLotID_ControlInfo_GetDR_out_struct_cvPtr;

class  csObjLotID_ControlInfo_GetDR_out_struct_var
{
    public:

    csObjLotID_ControlInfo_GetDR_out_struct_var ();

    csObjLotID_ControlInfo_GetDR_out_struct_var (csObjLotID_ControlInfo_GetDR_out_struct *_p);

    csObjLotID_ControlInfo_GetDR_out_struct_var (const csObjLotID_ControlInfo_GetDR_out_struct_var &_s);

    csObjLotID_ControlInfo_GetDR_out_struct_var &operator= (csObjLotID_ControlInfo_GetDR_out_struct *_p);

    csObjLotID_ControlInfo_GetDR_out_struct_var &operator= (const csObjLotID_ControlInfo_GetDR_out_struct_var &_s);

    ~csObjLotID_ControlInfo_GetDR_out_struct_var ();

    csObjLotID_ControlInfo_GetDR_out_struct* operator-> ();

    const csObjLotID_ControlInfo_GetDR_out_struct& in() const;
    csObjLotID_ControlInfo_GetDR_out_struct& inout();
    csObjLotID_ControlInfo_GetDR_out_struct*& out();
    csObjLotID_ControlInfo_GetDR_out_struct* _retn();

    operator csObjLotID_ControlInfo_GetDR_out_struct_cvPtr () const;

    operator csObjLotID_ControlInfo_GetDR_out_struct_vPtr& ();

    operator const csObjLotID_ControlInfo_GetDR_out_struct& () const;

    operator csObjLotID_ControlInfo_GetDR_out_struct& ();

    protected:
    csObjLotID_ControlInfo_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_GetDR_out_struct;
    typedef csObjLotID_ControlInfo_GetDR_out_struct csObjLotID_ControlInfo_GetDR_out;
    typedef csObjLotID_ControlInfo_GetDR_out_struct_var csObjLotID_ControlInfo_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_GetDR_out;
    class  csObjLotID_ControlInfo_SetDR_in_struct_var;
    struct  csObjLotID_ControlInfo_SetDR_in_struct {
        typedef csObjLotID_ControlInfo_SetDR_in_struct_var _var_type;
       ::CORBA::String_StructElem leadingChar;
       ::CORBA::Long lastUsedNumber;
       ::CORBA::String_StructElem year;
       ::CORBA::String_StructElem subChar;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLotID_ControlInfo_SetDR_in_struct();
       csObjLotID_ControlInfo_SetDR_in_struct(const csObjLotID_ControlInfo_SetDR_in_struct&);
       csObjLotID_ControlInfo_SetDR_in_struct& operator=(const csObjLotID_ControlInfo_SetDR_in_struct&);
       static CORBA::Info<csObjLotID_ControlInfo_SetDR_in_struct> csObjLotID_ControlInfo_SetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csObjLotID_ControlInfo_SetDR_in_struct


typedef csObjLotID_ControlInfo_SetDR_in_struct* csObjLotID_ControlInfo_SetDR_in_struct_vPtr;
typedef const csObjLotID_ControlInfo_SetDR_in_struct* csObjLotID_ControlInfo_SetDR_in_struct_cvPtr;

class  csObjLotID_ControlInfo_SetDR_in_struct_var
{
    public:

    csObjLotID_ControlInfo_SetDR_in_struct_var ();

    csObjLotID_ControlInfo_SetDR_in_struct_var (csObjLotID_ControlInfo_SetDR_in_struct *_p);

    csObjLotID_ControlInfo_SetDR_in_struct_var (const csObjLotID_ControlInfo_SetDR_in_struct_var &_s);

    csObjLotID_ControlInfo_SetDR_in_struct_var &operator= (csObjLotID_ControlInfo_SetDR_in_struct *_p);

    csObjLotID_ControlInfo_SetDR_in_struct_var &operator= (const csObjLotID_ControlInfo_SetDR_in_struct_var &_s);

    ~csObjLotID_ControlInfo_SetDR_in_struct_var ();

    csObjLotID_ControlInfo_SetDR_in_struct* operator-> ();

    const csObjLotID_ControlInfo_SetDR_in_struct& in() const;
    csObjLotID_ControlInfo_SetDR_in_struct& inout();
    csObjLotID_ControlInfo_SetDR_in_struct*& out();
    csObjLotID_ControlInfo_SetDR_in_struct* _retn();

    operator csObjLotID_ControlInfo_SetDR_in_struct_cvPtr () const;

    operator csObjLotID_ControlInfo_SetDR_in_struct_vPtr& ();

    operator const csObjLotID_ControlInfo_SetDR_in_struct& () const;

    operator csObjLotID_ControlInfo_SetDR_in_struct& ();

    protected:
    csObjLotID_ControlInfo_SetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_SetDR_in_struct;
    typedef csObjLotID_ControlInfo_SetDR_in_struct csObjLotID_ControlInfo_SetDR_in;
    typedef csObjLotID_ControlInfo_SetDR_in_struct_var csObjLotID_ControlInfo_SetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_SetDR_in;
    typedef objBase_out csObjLotID_ControlInfo_SetDR_out;
    typedef objBase_out_var csObjLotID_ControlInfo_SetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_SetDR_out;
    class  csObjLotID_ControlInfo_AddDR_in_struct_var;
    struct  csObjLotID_ControlInfo_AddDR_in_struct {
        typedef csObjLotID_ControlInfo_AddDR_in_struct_var _var_type;
       ::CORBA::String_StructElem leadingChar;
       ::CORBA::Long lastUsedNumber;
       ::CORBA::String_StructElem year;
       ::CORBA::String_StructElem subChar;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjLotID_ControlInfo_AddDR_in_struct();
       csObjLotID_ControlInfo_AddDR_in_struct(const csObjLotID_ControlInfo_AddDR_in_struct&);
       csObjLotID_ControlInfo_AddDR_in_struct& operator=(const csObjLotID_ControlInfo_AddDR_in_struct&);
       static CORBA::Info<csObjLotID_ControlInfo_AddDR_in_struct> csObjLotID_ControlInfo_AddDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csObjLotID_ControlInfo_AddDR_in_struct


typedef csObjLotID_ControlInfo_AddDR_in_struct* csObjLotID_ControlInfo_AddDR_in_struct_vPtr;
typedef const csObjLotID_ControlInfo_AddDR_in_struct* csObjLotID_ControlInfo_AddDR_in_struct_cvPtr;

class  csObjLotID_ControlInfo_AddDR_in_struct_var
{
    public:

    csObjLotID_ControlInfo_AddDR_in_struct_var ();

    csObjLotID_ControlInfo_AddDR_in_struct_var (csObjLotID_ControlInfo_AddDR_in_struct *_p);

    csObjLotID_ControlInfo_AddDR_in_struct_var (const csObjLotID_ControlInfo_AddDR_in_struct_var &_s);

    csObjLotID_ControlInfo_AddDR_in_struct_var &operator= (csObjLotID_ControlInfo_AddDR_in_struct *_p);

    csObjLotID_ControlInfo_AddDR_in_struct_var &operator= (const csObjLotID_ControlInfo_AddDR_in_struct_var &_s);

    ~csObjLotID_ControlInfo_AddDR_in_struct_var ();

    csObjLotID_ControlInfo_AddDR_in_struct* operator-> ();

    const csObjLotID_ControlInfo_AddDR_in_struct& in() const;
    csObjLotID_ControlInfo_AddDR_in_struct& inout();
    csObjLotID_ControlInfo_AddDR_in_struct*& out();
    csObjLotID_ControlInfo_AddDR_in_struct* _retn();

    operator csObjLotID_ControlInfo_AddDR_in_struct_cvPtr () const;

    operator csObjLotID_ControlInfo_AddDR_in_struct_vPtr& ();

    operator const csObjLotID_ControlInfo_AddDR_in_struct& () const;

    operator csObjLotID_ControlInfo_AddDR_in_struct& ();

    protected:
    csObjLotID_ControlInfo_AddDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_AddDR_in_struct;
    typedef csObjLotID_ControlInfo_AddDR_in_struct csObjLotID_ControlInfo_AddDR_in;
    typedef csObjLotID_ControlInfo_AddDR_in_struct_var csObjLotID_ControlInfo_AddDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_AddDR_in;
    typedef objBase_out csObjLotID_ControlInfo_AddDR_out;
    typedef objBase_out_var csObjLotID_ControlInfo_AddDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjLotID_ControlInfo_AddDR_out;
    class  csObjBWS_Config_GetDR_in_struct_var;
    struct  csObjBWS_Config_GetDR_in_struct {
        typedef csObjBWS_Config_GetDR_in_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::CORBA::String_StructElem zoneID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWS_Config_GetDR_in_struct();
       csObjBWS_Config_GetDR_in_struct(const csObjBWS_Config_GetDR_in_struct&);
       csObjBWS_Config_GetDR_in_struct& operator=(const csObjBWS_Config_GetDR_in_struct&);
       static CORBA::Info<csObjBWS_Config_GetDR_in_struct> csObjBWS_Config_GetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWS_Config_GetDR_in_struct


typedef csObjBWS_Config_GetDR_in_struct* csObjBWS_Config_GetDR_in_struct_vPtr;
typedef const csObjBWS_Config_GetDR_in_struct* csObjBWS_Config_GetDR_in_struct_cvPtr;

class  csObjBWS_Config_GetDR_in_struct_var
{
    public:

    csObjBWS_Config_GetDR_in_struct_var ();

    csObjBWS_Config_GetDR_in_struct_var (csObjBWS_Config_GetDR_in_struct *_p);

    csObjBWS_Config_GetDR_in_struct_var (const csObjBWS_Config_GetDR_in_struct_var &_s);

    csObjBWS_Config_GetDR_in_struct_var &operator= (csObjBWS_Config_GetDR_in_struct *_p);

    csObjBWS_Config_GetDR_in_struct_var &operator= (const csObjBWS_Config_GetDR_in_struct_var &_s);

    ~csObjBWS_Config_GetDR_in_struct_var ();

    csObjBWS_Config_GetDR_in_struct* operator-> ();

    const csObjBWS_Config_GetDR_in_struct& in() const;
    csObjBWS_Config_GetDR_in_struct& inout();
    csObjBWS_Config_GetDR_in_struct*& out();
    csObjBWS_Config_GetDR_in_struct* _retn();

    operator csObjBWS_Config_GetDR_in_struct_cvPtr () const;

    operator csObjBWS_Config_GetDR_in_struct_vPtr& ();

    operator const csObjBWS_Config_GetDR_in_struct& () const;

    operator csObjBWS_Config_GetDR_in_struct& ();

    protected:
    csObjBWS_Config_GetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_GetDR_in_struct;
    typedef csObjBWS_Config_GetDR_in_struct csObjBWS_Config_GetDR_in;
    typedef csObjBWS_Config_GetDR_in_struct_var csObjBWS_Config_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_GetDR_in;
    class  csObjBWS_Config_GetDR_out_struct_var;
    struct  csObjBWS_Config_GetDR_out_struct {
        typedef csObjBWS_Config_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csBWSConfigInfoSequence strBWSConfigInfoSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWS_Config_GetDR_out_struct();
       csObjBWS_Config_GetDR_out_struct(const csObjBWS_Config_GetDR_out_struct&);
       csObjBWS_Config_GetDR_out_struct& operator=(const csObjBWS_Config_GetDR_out_struct&);
       static CORBA::Info<csObjBWS_Config_GetDR_out_struct> csObjBWS_Config_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWS_Config_GetDR_out_struct


typedef csObjBWS_Config_GetDR_out_struct* csObjBWS_Config_GetDR_out_struct_vPtr;
typedef const csObjBWS_Config_GetDR_out_struct* csObjBWS_Config_GetDR_out_struct_cvPtr;

class  csObjBWS_Config_GetDR_out_struct_var
{
    public:

    csObjBWS_Config_GetDR_out_struct_var ();

    csObjBWS_Config_GetDR_out_struct_var (csObjBWS_Config_GetDR_out_struct *_p);

    csObjBWS_Config_GetDR_out_struct_var (const csObjBWS_Config_GetDR_out_struct_var &_s);

    csObjBWS_Config_GetDR_out_struct_var &operator= (csObjBWS_Config_GetDR_out_struct *_p);

    csObjBWS_Config_GetDR_out_struct_var &operator= (const csObjBWS_Config_GetDR_out_struct_var &_s);

    ~csObjBWS_Config_GetDR_out_struct_var ();

    csObjBWS_Config_GetDR_out_struct* operator-> ();

    const csObjBWS_Config_GetDR_out_struct& in() const;
    csObjBWS_Config_GetDR_out_struct& inout();
    csObjBWS_Config_GetDR_out_struct*& out();
    csObjBWS_Config_GetDR_out_struct* _retn();

    operator csObjBWS_Config_GetDR_out_struct_cvPtr () const;

    operator csObjBWS_Config_GetDR_out_struct_vPtr& ();

    operator const csObjBWS_Config_GetDR_out_struct& () const;

    operator csObjBWS_Config_GetDR_out_struct& ();

    protected:
    csObjBWS_Config_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_GetDR_out_struct;
    typedef csObjBWS_Config_GetDR_out_struct csObjBWS_Config_GetDR_out;
    typedef csObjBWS_Config_GetDR_out_struct_var csObjBWS_Config_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_GetDR_out;
    class  csObjBWS_Config_AddDR_in_struct_var;
    struct  csObjBWS_Config_AddDR_in_struct {
        typedef csObjBWS_Config_AddDR_in_struct_var _var_type;
       ::csBWSConfigInfo strBWSConfigInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWS_Config_AddDR_in_struct();
       csObjBWS_Config_AddDR_in_struct(const csObjBWS_Config_AddDR_in_struct&);
       csObjBWS_Config_AddDR_in_struct& operator=(const csObjBWS_Config_AddDR_in_struct&);
       static CORBA::Info<csObjBWS_Config_AddDR_in_struct> csObjBWS_Config_AddDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWS_Config_AddDR_in_struct


typedef csObjBWS_Config_AddDR_in_struct* csObjBWS_Config_AddDR_in_struct_vPtr;
typedef const csObjBWS_Config_AddDR_in_struct* csObjBWS_Config_AddDR_in_struct_cvPtr;

class  csObjBWS_Config_AddDR_in_struct_var
{
    public:

    csObjBWS_Config_AddDR_in_struct_var ();

    csObjBWS_Config_AddDR_in_struct_var (csObjBWS_Config_AddDR_in_struct *_p);

    csObjBWS_Config_AddDR_in_struct_var (const csObjBWS_Config_AddDR_in_struct_var &_s);

    csObjBWS_Config_AddDR_in_struct_var &operator= (csObjBWS_Config_AddDR_in_struct *_p);

    csObjBWS_Config_AddDR_in_struct_var &operator= (const csObjBWS_Config_AddDR_in_struct_var &_s);

    ~csObjBWS_Config_AddDR_in_struct_var ();

    csObjBWS_Config_AddDR_in_struct* operator-> ();

    const csObjBWS_Config_AddDR_in_struct& in() const;
    csObjBWS_Config_AddDR_in_struct& inout();
    csObjBWS_Config_AddDR_in_struct*& out();
    csObjBWS_Config_AddDR_in_struct* _retn();

    operator csObjBWS_Config_AddDR_in_struct_cvPtr () const;

    operator csObjBWS_Config_AddDR_in_struct_vPtr& ();

    operator const csObjBWS_Config_AddDR_in_struct& () const;

    operator csObjBWS_Config_AddDR_in_struct& ();

    protected:
    csObjBWS_Config_AddDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_AddDR_in_struct;
    typedef csObjBWS_Config_AddDR_in_struct csObjBWS_Config_AddDR_in;
    typedef csObjBWS_Config_AddDR_in_struct_var csObjBWS_Config_AddDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_AddDR_in;
    typedef objBase_out csObjBWS_Config_AddDR_out;
    typedef objBase_out_var csObjBWS_Config_AddDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_AddDR_out;
    class  csObjBWS_Config_DeleteDR_in_struct_var;
    struct  csObjBWS_Config_DeleteDR_in_struct {
        typedef csObjBWS_Config_DeleteDR_in_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::CORBA::String_StructElem zoneID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWS_Config_DeleteDR_in_struct();
       csObjBWS_Config_DeleteDR_in_struct(const csObjBWS_Config_DeleteDR_in_struct&);
       csObjBWS_Config_DeleteDR_in_struct& operator=(const csObjBWS_Config_DeleteDR_in_struct&);
       static CORBA::Info<csObjBWS_Config_DeleteDR_in_struct> csObjBWS_Config_DeleteDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWS_Config_DeleteDR_in_struct


typedef csObjBWS_Config_DeleteDR_in_struct* csObjBWS_Config_DeleteDR_in_struct_vPtr;
typedef const csObjBWS_Config_DeleteDR_in_struct* csObjBWS_Config_DeleteDR_in_struct_cvPtr;

class  csObjBWS_Config_DeleteDR_in_struct_var
{
    public:

    csObjBWS_Config_DeleteDR_in_struct_var ();

    csObjBWS_Config_DeleteDR_in_struct_var (csObjBWS_Config_DeleteDR_in_struct *_p);

    csObjBWS_Config_DeleteDR_in_struct_var (const csObjBWS_Config_DeleteDR_in_struct_var &_s);

    csObjBWS_Config_DeleteDR_in_struct_var &operator= (csObjBWS_Config_DeleteDR_in_struct *_p);

    csObjBWS_Config_DeleteDR_in_struct_var &operator= (const csObjBWS_Config_DeleteDR_in_struct_var &_s);

    ~csObjBWS_Config_DeleteDR_in_struct_var ();

    csObjBWS_Config_DeleteDR_in_struct* operator-> ();

    const csObjBWS_Config_DeleteDR_in_struct& in() const;
    csObjBWS_Config_DeleteDR_in_struct& inout();
    csObjBWS_Config_DeleteDR_in_struct*& out();
    csObjBWS_Config_DeleteDR_in_struct* _retn();

    operator csObjBWS_Config_DeleteDR_in_struct_cvPtr () const;

    operator csObjBWS_Config_DeleteDR_in_struct_vPtr& ();

    operator const csObjBWS_Config_DeleteDR_in_struct& () const;

    operator csObjBWS_Config_DeleteDR_in_struct& ();

    protected:
    csObjBWS_Config_DeleteDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_DeleteDR_in_struct;
    typedef csObjBWS_Config_DeleteDR_in_struct csObjBWS_Config_DeleteDR_in;
    typedef csObjBWS_Config_DeleteDR_in_struct_var csObjBWS_Config_DeleteDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_DeleteDR_in;
    typedef objBase_out csObjBWS_Config_DeleteDR_out;
    typedef objBase_out_var csObjBWS_Config_DeleteDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_Config_DeleteDR_out;
    typedef objBase_out csObjAPC_EventQueue_AddDR_out;
    typedef objBase_out_var csObjAPC_EventQueue_AddDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_EventQueue_AddDR_out;
    class  csObjAPC_EventQueue_AddDR_in_struct_var;
    struct  csObjAPC_EventQueue_AddDR_in_struct {
        typedef csObjAPC_EventQueue_AddDR_in_struct_var _var_type;
       ::csAPCEventQueueSequence strAPCEventQueueSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPC_EventQueue_AddDR_in_struct();
       csObjAPC_EventQueue_AddDR_in_struct(const csObjAPC_EventQueue_AddDR_in_struct&);
       csObjAPC_EventQueue_AddDR_in_struct& operator=(const csObjAPC_EventQueue_AddDR_in_struct&);
       static CORBA::Info<csObjAPC_EventQueue_AddDR_in_struct> csObjAPC_EventQueue_AddDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPC_EventQueue_AddDR_in_struct


typedef csObjAPC_EventQueue_AddDR_in_struct* csObjAPC_EventQueue_AddDR_in_struct_vPtr;
typedef const csObjAPC_EventQueue_AddDR_in_struct* csObjAPC_EventQueue_AddDR_in_struct_cvPtr;

class  csObjAPC_EventQueue_AddDR_in_struct_var
{
    public:

    csObjAPC_EventQueue_AddDR_in_struct_var ();

    csObjAPC_EventQueue_AddDR_in_struct_var (csObjAPC_EventQueue_AddDR_in_struct *_p);

    csObjAPC_EventQueue_AddDR_in_struct_var (const csObjAPC_EventQueue_AddDR_in_struct_var &_s);

    csObjAPC_EventQueue_AddDR_in_struct_var &operator= (csObjAPC_EventQueue_AddDR_in_struct *_p);

    csObjAPC_EventQueue_AddDR_in_struct_var &operator= (const csObjAPC_EventQueue_AddDR_in_struct_var &_s);

    ~csObjAPC_EventQueue_AddDR_in_struct_var ();

    csObjAPC_EventQueue_AddDR_in_struct* operator-> ();

    const csObjAPC_EventQueue_AddDR_in_struct& in() const;
    csObjAPC_EventQueue_AddDR_in_struct& inout();
    csObjAPC_EventQueue_AddDR_in_struct*& out();
    csObjAPC_EventQueue_AddDR_in_struct* _retn();

    operator csObjAPC_EventQueue_AddDR_in_struct_cvPtr () const;

    operator csObjAPC_EventQueue_AddDR_in_struct_vPtr& ();

    operator const csObjAPC_EventQueue_AddDR_in_struct& () const;

    operator csObjAPC_EventQueue_AddDR_in_struct& ();

    protected:
    csObjAPC_EventQueue_AddDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_EventQueue_AddDR_in_struct;
    typedef csObjAPC_EventQueue_AddDR_in_struct csObjAPC_EventQueue_AddDR_in;
    typedef csObjAPC_EventQueue_AddDR_in_struct_var csObjAPC_EventQueue_AddDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_EventQueue_AddDR_in;
    typedef objBase_out csObjAPC_EventQueue_DelDR_out;
    typedef objBase_out_var csObjAPC_EventQueue_DelDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_EventQueue_DelDR_out;
    class  csObjAPC_EventQueue_DelDR_in_struct_var;
    struct  csObjAPC_EventQueue_DelDR_in_struct {
        typedef csObjAPC_EventQueue_DelDR_in_struct_var _var_type;
       ::csAPCEventQueueSequence strAPCEventQueueSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPC_EventQueue_DelDR_in_struct();
       csObjAPC_EventQueue_DelDR_in_struct(const csObjAPC_EventQueue_DelDR_in_struct&);
       csObjAPC_EventQueue_DelDR_in_struct& operator=(const csObjAPC_EventQueue_DelDR_in_struct&);
       static CORBA::Info<csObjAPC_EventQueue_DelDR_in_struct> csObjAPC_EventQueue_DelDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPC_EventQueue_DelDR_in_struct


typedef csObjAPC_EventQueue_DelDR_in_struct* csObjAPC_EventQueue_DelDR_in_struct_vPtr;
typedef const csObjAPC_EventQueue_DelDR_in_struct* csObjAPC_EventQueue_DelDR_in_struct_cvPtr;

class  csObjAPC_EventQueue_DelDR_in_struct_var
{
    public:

    csObjAPC_EventQueue_DelDR_in_struct_var ();

    csObjAPC_EventQueue_DelDR_in_struct_var (csObjAPC_EventQueue_DelDR_in_struct *_p);

    csObjAPC_EventQueue_DelDR_in_struct_var (const csObjAPC_EventQueue_DelDR_in_struct_var &_s);

    csObjAPC_EventQueue_DelDR_in_struct_var &operator= (csObjAPC_EventQueue_DelDR_in_struct *_p);

    csObjAPC_EventQueue_DelDR_in_struct_var &operator= (const csObjAPC_EventQueue_DelDR_in_struct_var &_s);

    ~csObjAPC_EventQueue_DelDR_in_struct_var ();

    csObjAPC_EventQueue_DelDR_in_struct* operator-> ();

    const csObjAPC_EventQueue_DelDR_in_struct& in() const;
    csObjAPC_EventQueue_DelDR_in_struct& inout();
    csObjAPC_EventQueue_DelDR_in_struct*& out();
    csObjAPC_EventQueue_DelDR_in_struct* _retn();

    operator csObjAPC_EventQueue_DelDR_in_struct_cvPtr () const;

    operator csObjAPC_EventQueue_DelDR_in_struct_vPtr& ();

    operator const csObjAPC_EventQueue_DelDR_in_struct& () const;

    operator csObjAPC_EventQueue_DelDR_in_struct& ();

    protected:
    csObjAPC_EventQueue_DelDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_EventQueue_DelDR_in_struct;
    typedef csObjAPC_EventQueue_DelDR_in_struct csObjAPC_EventQueue_DelDR_in;
    typedef csObjAPC_EventQueue_DelDR_in_struct_var csObjAPC_EventQueue_DelDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_EventQueue_DelDR_in;
    class  csObjAPC_LotEventQueue_Make_in_struct_var;
    struct  csObjAPC_LotEventQueue_Make_in_struct {
        typedef csObjAPC_LotEventQueue_Make_in_struct_var _var_type;
       ::objectIdentifier equipmentID;
       ::objectIdentifier controlJobID;
       ::pptStartCassetteSequence strStartCassette;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPC_LotEventQueue_Make_in_struct();
       csObjAPC_LotEventQueue_Make_in_struct(const csObjAPC_LotEventQueue_Make_in_struct&);
       csObjAPC_LotEventQueue_Make_in_struct& operator=(const csObjAPC_LotEventQueue_Make_in_struct&);
       static CORBA::Info<csObjAPC_LotEventQueue_Make_in_struct> csObjAPC_LotEventQueue_Make_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPC_LotEventQueue_Make_in_struct


typedef csObjAPC_LotEventQueue_Make_in_struct* csObjAPC_LotEventQueue_Make_in_struct_vPtr;
typedef const csObjAPC_LotEventQueue_Make_in_struct* csObjAPC_LotEventQueue_Make_in_struct_cvPtr;

class  csObjAPC_LotEventQueue_Make_in_struct_var
{
    public:

    csObjAPC_LotEventQueue_Make_in_struct_var ();

    csObjAPC_LotEventQueue_Make_in_struct_var (csObjAPC_LotEventQueue_Make_in_struct *_p);

    csObjAPC_LotEventQueue_Make_in_struct_var (const csObjAPC_LotEventQueue_Make_in_struct_var &_s);

    csObjAPC_LotEventQueue_Make_in_struct_var &operator= (csObjAPC_LotEventQueue_Make_in_struct *_p);

    csObjAPC_LotEventQueue_Make_in_struct_var &operator= (const csObjAPC_LotEventQueue_Make_in_struct_var &_s);

    ~csObjAPC_LotEventQueue_Make_in_struct_var ();

    csObjAPC_LotEventQueue_Make_in_struct* operator-> ();

    const csObjAPC_LotEventQueue_Make_in_struct& in() const;
    csObjAPC_LotEventQueue_Make_in_struct& inout();
    csObjAPC_LotEventQueue_Make_in_struct*& out();
    csObjAPC_LotEventQueue_Make_in_struct* _retn();

    operator csObjAPC_LotEventQueue_Make_in_struct_cvPtr () const;

    operator csObjAPC_LotEventQueue_Make_in_struct_vPtr& ();

    operator const csObjAPC_LotEventQueue_Make_in_struct& () const;

    operator csObjAPC_LotEventQueue_Make_in_struct& ();

    protected:
    csObjAPC_LotEventQueue_Make_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LotEventQueue_Make_in_struct;
    typedef csObjAPC_LotEventQueue_Make_in_struct csObjAPC_LotEventQueue_Make_in;
    typedef csObjAPC_LotEventQueue_Make_in_struct_var csObjAPC_LotEventQueue_Make_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LotEventQueue_Make_in;
    class  csObjAPC_LotEventQueue_Make_out_struct_var;
    struct  csObjAPC_LotEventQueue_Make_out_struct {
        typedef csObjAPC_LotEventQueue_Make_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjAPC_LotEventQueue_Make_out_struct();
       csObjAPC_LotEventQueue_Make_out_struct(const csObjAPC_LotEventQueue_Make_out_struct&);
       csObjAPC_LotEventQueue_Make_out_struct& operator=(const csObjAPC_LotEventQueue_Make_out_struct&);
       static CORBA::Info<csObjAPC_LotEventQueue_Make_out_struct> csObjAPC_LotEventQueue_Make_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjAPC_LotEventQueue_Make_out_struct


typedef csObjAPC_LotEventQueue_Make_out_struct* csObjAPC_LotEventQueue_Make_out_struct_vPtr;
typedef const csObjAPC_LotEventQueue_Make_out_struct* csObjAPC_LotEventQueue_Make_out_struct_cvPtr;

class  csObjAPC_LotEventQueue_Make_out_struct_var
{
    public:

    csObjAPC_LotEventQueue_Make_out_struct_var ();

    csObjAPC_LotEventQueue_Make_out_struct_var (csObjAPC_LotEventQueue_Make_out_struct *_p);

    csObjAPC_LotEventQueue_Make_out_struct_var (const csObjAPC_LotEventQueue_Make_out_struct_var &_s);

    csObjAPC_LotEventQueue_Make_out_struct_var &operator= (csObjAPC_LotEventQueue_Make_out_struct *_p);

    csObjAPC_LotEventQueue_Make_out_struct_var &operator= (const csObjAPC_LotEventQueue_Make_out_struct_var &_s);

    ~csObjAPC_LotEventQueue_Make_out_struct_var ();

    csObjAPC_LotEventQueue_Make_out_struct* operator-> ();

    const csObjAPC_LotEventQueue_Make_out_struct& in() const;
    csObjAPC_LotEventQueue_Make_out_struct& inout();
    csObjAPC_LotEventQueue_Make_out_struct*& out();
    csObjAPC_LotEventQueue_Make_out_struct* _retn();

    operator csObjAPC_LotEventQueue_Make_out_struct_cvPtr () const;

    operator csObjAPC_LotEventQueue_Make_out_struct_vPtr& ();

    operator const csObjAPC_LotEventQueue_Make_out_struct& () const;

    operator csObjAPC_LotEventQueue_Make_out_struct& ();

    protected:
    csObjAPC_LotEventQueue_Make_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LotEventQueue_Make_out_struct;
    typedef csObjAPC_LotEventQueue_Make_out_struct csObjAPC_LotEventQueue_Make_out;
    typedef csObjAPC_LotEventQueue_Make_out_struct_var csObjAPC_LotEventQueue_Make_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjAPC_LotEventQueue_Make_out;
    typedef csBWSWaferListInqInParm csObjBWS_WaferList_GetDR_in;
    typedef csBWSWaferListInqInParm_var csObjBWS_WaferList_GetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferList_GetDR_in;
    class  csObjBWS_WaferList_GetDR_out_struct_var;
    struct  csObjBWS_WaferList_GetDR_out_struct {
        typedef csObjBWS_WaferList_GetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csBWSDataSequence strBWSDataSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWS_WaferList_GetDR_out_struct();
       csObjBWS_WaferList_GetDR_out_struct(const csObjBWS_WaferList_GetDR_out_struct&);
       csObjBWS_WaferList_GetDR_out_struct& operator=(const csObjBWS_WaferList_GetDR_out_struct&);
       static CORBA::Info<csObjBWS_WaferList_GetDR_out_struct> csObjBWS_WaferList_GetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWS_WaferList_GetDR_out_struct


typedef csObjBWS_WaferList_GetDR_out_struct* csObjBWS_WaferList_GetDR_out_struct_vPtr;
typedef const csObjBWS_WaferList_GetDR_out_struct* csObjBWS_WaferList_GetDR_out_struct_cvPtr;

class  csObjBWS_WaferList_GetDR_out_struct_var
{
    public:

    csObjBWS_WaferList_GetDR_out_struct_var ();

    csObjBWS_WaferList_GetDR_out_struct_var (csObjBWS_WaferList_GetDR_out_struct *_p);

    csObjBWS_WaferList_GetDR_out_struct_var (const csObjBWS_WaferList_GetDR_out_struct_var &_s);

    csObjBWS_WaferList_GetDR_out_struct_var &operator= (csObjBWS_WaferList_GetDR_out_struct *_p);

    csObjBWS_WaferList_GetDR_out_struct_var &operator= (const csObjBWS_WaferList_GetDR_out_struct_var &_s);

    ~csObjBWS_WaferList_GetDR_out_struct_var ();

    csObjBWS_WaferList_GetDR_out_struct* operator-> ();

    const csObjBWS_WaferList_GetDR_out_struct& in() const;
    csObjBWS_WaferList_GetDR_out_struct& inout();
    csObjBWS_WaferList_GetDR_out_struct*& out();
    csObjBWS_WaferList_GetDR_out_struct* _retn();

    operator csObjBWS_WaferList_GetDR_out_struct_cvPtr () const;

    operator csObjBWS_WaferList_GetDR_out_struct_vPtr& ();

    operator const csObjBWS_WaferList_GetDR_out_struct& () const;

    operator csObjBWS_WaferList_GetDR_out_struct& ();

    protected:
    csObjBWS_WaferList_GetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferList_GetDR_out_struct;
    typedef csObjBWS_WaferList_GetDR_out_struct csObjBWS_WaferList_GetDR_out;
    typedef csObjBWS_WaferList_GetDR_out_struct_var csObjBWS_WaferList_GetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferList_GetDR_out;
    class  csObjBWS_WaferList_AddDR_in_struct_var;
    struct  csObjBWS_WaferList_AddDR_in_struct {
        typedef csObjBWS_WaferList_AddDR_in_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::CORBA::String_StructElem zoneID;
       ::csBWSWaferDataSequence strBWSWaferDataSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWS_WaferList_AddDR_in_struct();
       csObjBWS_WaferList_AddDR_in_struct(const csObjBWS_WaferList_AddDR_in_struct&);
       csObjBWS_WaferList_AddDR_in_struct& operator=(const csObjBWS_WaferList_AddDR_in_struct&);
       static CORBA::Info<csObjBWS_WaferList_AddDR_in_struct> csObjBWS_WaferList_AddDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWS_WaferList_AddDR_in_struct


typedef csObjBWS_WaferList_AddDR_in_struct* csObjBWS_WaferList_AddDR_in_struct_vPtr;
typedef const csObjBWS_WaferList_AddDR_in_struct* csObjBWS_WaferList_AddDR_in_struct_cvPtr;

class  csObjBWS_WaferList_AddDR_in_struct_var
{
    public:

    csObjBWS_WaferList_AddDR_in_struct_var ();

    csObjBWS_WaferList_AddDR_in_struct_var (csObjBWS_WaferList_AddDR_in_struct *_p);

    csObjBWS_WaferList_AddDR_in_struct_var (const csObjBWS_WaferList_AddDR_in_struct_var &_s);

    csObjBWS_WaferList_AddDR_in_struct_var &operator= (csObjBWS_WaferList_AddDR_in_struct *_p);

    csObjBWS_WaferList_AddDR_in_struct_var &operator= (const csObjBWS_WaferList_AddDR_in_struct_var &_s);

    ~csObjBWS_WaferList_AddDR_in_struct_var ();

    csObjBWS_WaferList_AddDR_in_struct* operator-> ();

    const csObjBWS_WaferList_AddDR_in_struct& in() const;
    csObjBWS_WaferList_AddDR_in_struct& inout();
    csObjBWS_WaferList_AddDR_in_struct*& out();
    csObjBWS_WaferList_AddDR_in_struct* _retn();

    operator csObjBWS_WaferList_AddDR_in_struct_cvPtr () const;

    operator csObjBWS_WaferList_AddDR_in_struct_vPtr& ();

    operator const csObjBWS_WaferList_AddDR_in_struct& () const;

    operator csObjBWS_WaferList_AddDR_in_struct& ();

    protected:
    csObjBWS_WaferList_AddDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferList_AddDR_in_struct;
    typedef csObjBWS_WaferList_AddDR_in_struct csObjBWS_WaferList_AddDR_in;
    typedef csObjBWS_WaferList_AddDR_in_struct_var csObjBWS_WaferList_AddDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferList_AddDR_in;
    typedef objBase_out csObjBWS_WaferList_AddDR_out;
    typedef objBase_out_var csObjBWS_WaferList_AddDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferList_AddDR_out;
    class  csObjBWS_WaferList_DeleteDR_in_struct_var;
    struct  csObjBWS_WaferList_DeleteDR_in_struct {
        typedef csObjBWS_WaferList_DeleteDR_in_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::CORBA::String_StructElem zoneID;
       ::objectIdentifierSequence waferIDs;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjBWS_WaferList_DeleteDR_in_struct();
       csObjBWS_WaferList_DeleteDR_in_struct(const csObjBWS_WaferList_DeleteDR_in_struct&);
       csObjBWS_WaferList_DeleteDR_in_struct& operator=(const csObjBWS_WaferList_DeleteDR_in_struct&);
       static CORBA::Info<csObjBWS_WaferList_DeleteDR_in_struct> csObjBWS_WaferList_DeleteDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjBWS_WaferList_DeleteDR_in_struct


typedef csObjBWS_WaferList_DeleteDR_in_struct* csObjBWS_WaferList_DeleteDR_in_struct_vPtr;
typedef const csObjBWS_WaferList_DeleteDR_in_struct* csObjBWS_WaferList_DeleteDR_in_struct_cvPtr;

class  csObjBWS_WaferList_DeleteDR_in_struct_var
{
    public:

    csObjBWS_WaferList_DeleteDR_in_struct_var ();

    csObjBWS_WaferList_DeleteDR_in_struct_var (csObjBWS_WaferList_DeleteDR_in_struct *_p);

    csObjBWS_WaferList_DeleteDR_in_struct_var (const csObjBWS_WaferList_DeleteDR_in_struct_var &_s);

    csObjBWS_WaferList_DeleteDR_in_struct_var &operator= (csObjBWS_WaferList_DeleteDR_in_struct *_p);

    csObjBWS_WaferList_DeleteDR_in_struct_var &operator= (const csObjBWS_WaferList_DeleteDR_in_struct_var &_s);

    ~csObjBWS_WaferList_DeleteDR_in_struct_var ();

    csObjBWS_WaferList_DeleteDR_in_struct* operator-> ();

    const csObjBWS_WaferList_DeleteDR_in_struct& in() const;
    csObjBWS_WaferList_DeleteDR_in_struct& inout();
    csObjBWS_WaferList_DeleteDR_in_struct*& out();
    csObjBWS_WaferList_DeleteDR_in_struct* _retn();

    operator csObjBWS_WaferList_DeleteDR_in_struct_cvPtr () const;

    operator csObjBWS_WaferList_DeleteDR_in_struct_vPtr& ();

    operator const csObjBWS_WaferList_DeleteDR_in_struct& () const;

    operator csObjBWS_WaferList_DeleteDR_in_struct& ();

    protected:
    csObjBWS_WaferList_DeleteDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferList_DeleteDR_in_struct;
    typedef csObjBWS_WaferList_DeleteDR_in_struct csObjBWS_WaferList_DeleteDR_in;
    typedef csObjBWS_WaferList_DeleteDR_in_struct_var csObjBWS_WaferList_DeleteDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferList_DeleteDR_in;
    typedef objBase_out csObjBWS_WaferList_DeleteDR_out;
    typedef objBase_out_var csObjBWS_WaferList_DeleteDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjBWS_WaferList_DeleteDR_out;
    class  csObjEqpMonitorInventory_ListGetDR_in_struct_var;
    struct  csObjEqpMonitorInventory_ListGetDR_in_struct {
        typedef csObjEqpMonitorInventory_ListGetDR_in_struct_var _var_type;
       ::CORBA::String_StructElem npwType;
       ::CORBA::String_StructElem productID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEqpMonitorInventory_ListGetDR_in_struct();
       csObjEqpMonitorInventory_ListGetDR_in_struct(const csObjEqpMonitorInventory_ListGetDR_in_struct&);
       csObjEqpMonitorInventory_ListGetDR_in_struct& operator=(const csObjEqpMonitorInventory_ListGetDR_in_struct&);
       static CORBA::Info<csObjEqpMonitorInventory_ListGetDR_in_struct> csObjEqpMonitorInventory_ListGetDR_in_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csObjEqpMonitorInventory_ListGetDR_in_struct


typedef csObjEqpMonitorInventory_ListGetDR_in_struct* csObjEqpMonitorInventory_ListGetDR_in_struct_vPtr;
typedef const csObjEqpMonitorInventory_ListGetDR_in_struct* csObjEqpMonitorInventory_ListGetDR_in_struct_cvPtr;

class  csObjEqpMonitorInventory_ListGetDR_in_struct_var
{
    public:

    csObjEqpMonitorInventory_ListGetDR_in_struct_var ();

    csObjEqpMonitorInventory_ListGetDR_in_struct_var (csObjEqpMonitorInventory_ListGetDR_in_struct *_p);

    csObjEqpMonitorInventory_ListGetDR_in_struct_var (const csObjEqpMonitorInventory_ListGetDR_in_struct_var &_s);

    csObjEqpMonitorInventory_ListGetDR_in_struct_var &operator= (csObjEqpMonitorInventory_ListGetDR_in_struct *_p);

    csObjEqpMonitorInventory_ListGetDR_in_struct_var &operator= (const csObjEqpMonitorInventory_ListGetDR_in_struct_var &_s);

    ~csObjEqpMonitorInventory_ListGetDR_in_struct_var ();

    csObjEqpMonitorInventory_ListGetDR_in_struct* operator-> ();

    const csObjEqpMonitorInventory_ListGetDR_in_struct& in() const;
    csObjEqpMonitorInventory_ListGetDR_in_struct& inout();
    csObjEqpMonitorInventory_ListGetDR_in_struct*& out();
    csObjEqpMonitorInventory_ListGetDR_in_struct* _retn();

    operator csObjEqpMonitorInventory_ListGetDR_in_struct_cvPtr () const;

    operator csObjEqpMonitorInventory_ListGetDR_in_struct_vPtr& ();

    operator const csObjEqpMonitorInventory_ListGetDR_in_struct& () const;

    operator csObjEqpMonitorInventory_ListGetDR_in_struct& ();

    protected:
    csObjEqpMonitorInventory_ListGetDR_in_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitorInventory_ListGetDR_in_struct;
    typedef csObjEqpMonitorInventory_ListGetDR_in_struct csObjEqpMonitorInventory_ListGetDR_in;
    typedef csObjEqpMonitorInventory_ListGetDR_in_struct_var csObjEqpMonitorInventory_ListGetDR_in_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitorInventory_ListGetDR_in;
    class  csObjEqpMonitorInventory_ListGetDR_out_struct_var;
    struct  csObjEqpMonitorInventory_ListGetDR_out_struct {
        typedef csObjEqpMonitorInventory_ListGetDR_out_struct_var _var_type;
       ::pptRetCode strResult;
       ::csEqpMonitorInventoryInfoSequence strEqpMonitorInventoryInfoSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csObjEqpMonitorInventory_ListGetDR_out_struct();
       csObjEqpMonitorInventory_ListGetDR_out_struct(const csObjEqpMonitorInventory_ListGetDR_out_struct&);
       csObjEqpMonitorInventory_ListGetDR_out_struct& operator=(const csObjEqpMonitorInventory_ListGetDR_out_struct&);
       static CORBA::Info<csObjEqpMonitorInventory_ListGetDR_out_struct> csObjEqpMonitorInventory_ListGetDR_out_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csObjEqpMonitorInventory_ListGetDR_out_struct


typedef csObjEqpMonitorInventory_ListGetDR_out_struct* csObjEqpMonitorInventory_ListGetDR_out_struct_vPtr;
typedef const csObjEqpMonitorInventory_ListGetDR_out_struct* csObjEqpMonitorInventory_ListGetDR_out_struct_cvPtr;

class  csObjEqpMonitorInventory_ListGetDR_out_struct_var
{
    public:

    csObjEqpMonitorInventory_ListGetDR_out_struct_var ();

    csObjEqpMonitorInventory_ListGetDR_out_struct_var (csObjEqpMonitorInventory_ListGetDR_out_struct *_p);

    csObjEqpMonitorInventory_ListGetDR_out_struct_var (const csObjEqpMonitorInventory_ListGetDR_out_struct_var &_s);

    csObjEqpMonitorInventory_ListGetDR_out_struct_var &operator= (csObjEqpMonitorInventory_ListGetDR_out_struct *_p);

    csObjEqpMonitorInventory_ListGetDR_out_struct_var &operator= (const csObjEqpMonitorInventory_ListGetDR_out_struct_var &_s);

    ~csObjEqpMonitorInventory_ListGetDR_out_struct_var ();

    csObjEqpMonitorInventory_ListGetDR_out_struct* operator-> ();

    const csObjEqpMonitorInventory_ListGetDR_out_struct& in() const;
    csObjEqpMonitorInventory_ListGetDR_out_struct& inout();
    csObjEqpMonitorInventory_ListGetDR_out_struct*& out();
    csObjEqpMonitorInventory_ListGetDR_out_struct* _retn();

    operator csObjEqpMonitorInventory_ListGetDR_out_struct_cvPtr () const;

    operator csObjEqpMonitorInventory_ListGetDR_out_struct_vPtr& ();

    operator const csObjEqpMonitorInventory_ListGetDR_out_struct& () const;

    operator csObjEqpMonitorInventory_ListGetDR_out_struct& ();

    protected:
    csObjEqpMonitorInventory_ListGetDR_out_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitorInventory_ListGetDR_out_struct;
    typedef csObjEqpMonitorInventory_ListGetDR_out_struct csObjEqpMonitorInventory_ListGetDR_out;
    typedef csObjEqpMonitorInventory_ListGetDR_out_struct_var csObjEqpMonitorInventory_ListGetDR_out_var;
    extern  ::CORBA::TypeCode_ptr _tc_csObjEqpMonitorInventory_ListGetDR_out;
#endif   
/*
 * Guard codes of CORBA::Any operators.
 */
#ifdef __NOTUSE_ANYOPERATOR__
#define __NOTUSE_cs_pptobstr_ANYOPERATOR__
#endif //__NOTUSE_ANYOPERATOR__

#ifdef __USE_cs_pptobstr_ANYOPERATOR__
#undef __NOTUSE_cs_pptobstr_ANYOPERATOR__
#endif //__USE_cs_pptobstr_ANYOPERATOR__
#ifndef __NOTUSE_cs_pptobstr_ANYOPERATOR__
#define _DCL_ANYOPS_objSample_Obj_struct
#define _DCL_ANYOPS_objTestFunction_Obj_struct
#define _DCL_ANYOPS_csObjEquipment_InAuditList_GetDR_out_struct
#define _DCL_ANYOPS_csObjEquipment_ListByOwnerDR_out_struct
#define _DCL_ANYOPS_csObjRMSMgr_GetServiceManager_out_struct
#define _DCL_ANYOPS_csObjEquipment_constantsManageFlag_Get_out_struct
#define _DCL_ANYOPS_csObjRecipe_compareFlag_Get_out_struct
#define _DCL_ANYOPS_csObjEquipmentInfo_ListByOwnerDR_out_struct
#define _DCL_ANYOPS_csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct
#define _DCL_ANYOPS_csObjCassette_InspectionTime_Reset_out_struct
#define _DCL_ANYOPS_csObjCassette_PMTime_Reset_out_struct
#define _DCL_ANYOPS_csObjReticle_WaferCount_Reset_out_struct
#define _DCL_ANYOPS_csObjReticle_UsedDuration_Reset_out_struct
#define _DCL_ANYOPS_csObjReticle_WaferCount_Increment_out_struct
#define _DCL_ANYOPS_csObjReticle_WaferCount_Increment_in_struct
#define _DCL_ANYOPS_csObjReticle_WaferCount_Decrement_out_struct
#define _DCL_ANYOPS_csObjReticle_WaferCount_Decrement_in_struct
#define _DCL_ANYOPS_csObjUserData_GetByLotOperation_out_struct
#define _DCL_ANYOPS_csObjUserData_GetByLotOperation_in_struct
#define _DCL_ANYOPS_csObjReticlePod_Empty_Check_out_struct
#define _DCL_ANYOPS_csObjReticlePod_Empty_Check_in_struct
#define _DCL_ANYOPS_csObjVendorLotReserve_SelDR_out_struct
#define _DCL_ANYOPS_csObjLot_ContaminationInfo_Get_in_struct
#define _DCL_ANYOPS_csObjLot_ContaminationInfo_Get_out_struct
#define _DCL_ANYOPS_csObjLot_ContaminationInfo_Set_in_struct
#define _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForMove_in_struct
#define _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForMove_out_struct
#define _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForProcess_in_struct
#define _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForProcess_out_struct
#define _DCL_ANYOPS_csObjLot_udata_CopyToChild_in_struct
#define _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct
#define _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct
#define _DCL_ANYOPS_csObjEquipment_udata_GetDR_in_struct
#define _DCL_ANYOPS_csObjEquipment_udata_GetDR_out_struct
#define _DCL_ANYOPS_csObjCarrier_UsageTypeChange_in_struct
#define _DCL_ANYOPS_csObjLot_requiredCarrierCategory_CheckDR_in_struct
#define _DCL_ANYOPS_csObjPerson_SkillList_GetDR_out_struct
#define _DCL_ANYOPS_csObjPerson_SkillList_GetDR_in_strcut
#define _DCL_ANYOPS_csObjPerson_SkillList_AddDR_in_strcut
#define _DCL_ANYOPS_csObjPerson_SkillList_DelDR_in_strcut
#define _DCL_ANYOPS_csObjPerson_SkillList_SetDR_in_strcut
#define _DCL_ANYOPS_csObjPerson_PrivilegeCheckForTACertify_in_strcut
#define _DCL_ANYOPS_csObjFixture_touchCountSet_in_struct
#define _DCL_ANYOPS_csObjFixture_touchCountSet_out_struct
#define _DCL_ANYOPS_csObjFixture_touchCount_Get_in_struct
#define _DCL_ANYOPS_csObjFixture_touchCount_Get_out_struct
#define _DCL_ANYOPS_csObjWafer_userDataInfo_GetDR_in_struct
#define _DCL_ANYOPS_csObjWafer_userDataInfo_GetDR_out_struct
#define _DCL_ANYOPS_csObjDurable_userDataInfo_GetDR_in_struct
#define _DCL_ANYOPS_csObjDurable_userDataInfo_GetDR_out_struct
#define _DCL_ANYOPS_csObjUserData_GetByOperation_in_struct
#define _DCL_ANYOPS_csObjUserData_GetByOperation_out_struct
#define _DCL_ANYOPS_csObjAPC_LithoAvailable_CheckCondition_in_struct
#define _DCL_ANYOPS_csObjAPC_LithoAvailable_CheckCondition_out_struct
#define _DCL_ANYOPS_csObjAPC_LithoLotDataInfo_Get_in_struct
#define _DCL_ANYOPS_csObjAPC_LithoLotDataInfo_Get_out_struct
#define _DCL_ANYOPS_csObjAPC_LithoContextInfo_Get_in_struct
#define _DCL_ANYOPS_csObjAPC_LithoContextInfo_Get_out_struct
#define _DCL_ANYOPS_csObjAPCMgr_SendLithoUsedInfoReq_in_struct
#define _DCL_ANYOPS_csObjAPCMgr_SendLithoUsedInfoReq_out_struct
#define _DCL_ANYOPS_csObjAPCMgr_SendLithoRecommendInfoInq_in_struct
#define _DCL_ANYOPS_csObjAPCMgr_SendLithoRecommendInfoInq_out_struct
#define _DCL_ANYOPS_csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct
#define _DCL_ANYOPS_csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct
#define _DCL_ANYOPS_csObjControlJob_BatchSize_Check_out_struct
#define _DCL_ANYOPS_csObjControlJob_BatchSize_Check_in_struct
#define _DCL_ANYOPS_csObjLotID_ControlInfo_GetDR_in_struct
#define _DCL_ANYOPS_csObjLotID_ControlInfo_GetDR_out_struct
#define _DCL_ANYOPS_csObjLotID_ControlInfo_SetDR_in_struct
#define _DCL_ANYOPS_csObjLotID_ControlInfo_AddDR_in_struct
#define _DCL_ANYOPS_csObjBWS_Config_GetDR_in_struct
#define _DCL_ANYOPS_csObjBWS_Config_GetDR_out_struct
#define _DCL_ANYOPS_csObjBWS_Config_AddDR_in_struct
#define _DCL_ANYOPS_csObjBWS_Config_DeleteDR_in_struct
#define _DCL_ANYOPS_csObjAPC_EventQueue_AddDR_in_struct
#define _DCL_ANYOPS_csObjAPC_EventQueue_DelDR_in_struct
#define _DCL_ANYOPS_csObjAPC_LotEventQueue_Make_in_struct
#define _DCL_ANYOPS_csObjAPC_LotEventQueue_Make_out_struct
#define _DCL_ANYOPS_csObjBWS_WaferList_GetDR_out_struct
#define _DCL_ANYOPS_csObjBWS_WaferList_AddDR_in_struct
#define _DCL_ANYOPS_csObjBWS_WaferList_DeleteDR_in_struct
#define _DCL_ANYOPS_csObjEqpMonitorInventory_ListGetDR_in_struct
#define _DCL_ANYOPS_csObjEqpMonitorInventory_ListGetDR_out_struct
#endif //__NOTUSE_cs_pptobstr_ANYOPERATOR__

/*
 * Overloaded CORBA::Any operators.
 */
#ifdef _DCL_ANYOPS_objSample_Obj_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::objSample_Obj_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::objSample_Obj_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::objSample_Obj_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::objSample_Obj_struct*& _data);
#endif
#endif // _DCL_ANYOPS_objSample_Obj_struct
#ifdef _DCL_ANYOPS_objTestFunction_Obj_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::objTestFunction_Obj_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::objTestFunction_Obj_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::objTestFunction_Obj_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::objTestFunction_Obj_struct*& _data);
#endif
#endif // _DCL_ANYOPS_objTestFunction_Obj_struct
#ifdef _DCL_ANYOPS_csObjEquipment_InAuditList_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEquipment_InAuditList_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEquipment_InAuditList_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEquipment_InAuditList_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEquipment_InAuditList_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEquipment_InAuditList_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjEquipment_ListByOwnerDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEquipment_ListByOwnerDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEquipment_ListByOwnerDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEquipment_ListByOwnerDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEquipment_ListByOwnerDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEquipment_ListByOwnerDR_out_struct
#ifdef _DCL_ANYOPS_csObjRMSMgr_GetServiceManager_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjRMSMgr_GetServiceManager_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjRMSMgr_GetServiceManager_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjRMSMgr_GetServiceManager_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjRMSMgr_GetServiceManager_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjRMSMgr_GetServiceManager_out_struct
#ifdef _DCL_ANYOPS_csObjEquipment_constantsManageFlag_Get_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEquipment_constantsManageFlag_Get_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEquipment_constantsManageFlag_Get_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEquipment_constantsManageFlag_Get_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEquipment_constantsManageFlag_Get_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEquipment_constantsManageFlag_Get_out_struct
#ifdef _DCL_ANYOPS_csObjRecipe_compareFlag_Get_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjRecipe_compareFlag_Get_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjRecipe_compareFlag_Get_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjRecipe_compareFlag_Get_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjRecipe_compareFlag_Get_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjRecipe_compareFlag_Get_out_struct
#ifdef _DCL_ANYOPS_csObjEquipmentInfo_ListByOwnerDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEquipmentInfo_ListByOwnerDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEquipmentInfo_ListByOwnerDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEquipmentInfo_ListByOwnerDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEquipmentInfo_ListByOwnerDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEquipmentInfo_ListByOwnerDR_out_struct
#ifdef _DCL_ANYOPS_csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEquipment_machine_and_physicalRecipeID_auditFlag_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjCassette_InspectionTime_Reset_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjCassette_InspectionTime_Reset_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjCassette_InspectionTime_Reset_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjCassette_InspectionTime_Reset_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjCassette_InspectionTime_Reset_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjCassette_InspectionTime_Reset_out_struct
#ifdef _DCL_ANYOPS_csObjCassette_PMTime_Reset_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjCassette_PMTime_Reset_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjCassette_PMTime_Reset_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjCassette_PMTime_Reset_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjCassette_PMTime_Reset_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjCassette_PMTime_Reset_out_struct
#ifdef _DCL_ANYOPS_csObjReticle_WaferCount_Reset_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjReticle_WaferCount_Reset_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjReticle_WaferCount_Reset_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjReticle_WaferCount_Reset_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjReticle_WaferCount_Reset_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjReticle_WaferCount_Reset_out_struct
#ifdef _DCL_ANYOPS_csObjReticle_UsedDuration_Reset_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjReticle_UsedDuration_Reset_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjReticle_UsedDuration_Reset_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjReticle_UsedDuration_Reset_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjReticle_UsedDuration_Reset_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjReticle_UsedDuration_Reset_out_struct
#ifdef _DCL_ANYOPS_csObjReticle_WaferCount_Increment_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjReticle_WaferCount_Increment_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjReticle_WaferCount_Increment_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjReticle_WaferCount_Increment_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjReticle_WaferCount_Increment_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjReticle_WaferCount_Increment_out_struct
#ifdef _DCL_ANYOPS_csObjReticle_WaferCount_Increment_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjReticle_WaferCount_Increment_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjReticle_WaferCount_Increment_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjReticle_WaferCount_Increment_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjReticle_WaferCount_Increment_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjReticle_WaferCount_Increment_in_struct
#ifdef _DCL_ANYOPS_csObjReticle_WaferCount_Decrement_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjReticle_WaferCount_Decrement_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjReticle_WaferCount_Decrement_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjReticle_WaferCount_Decrement_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjReticle_WaferCount_Decrement_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjReticle_WaferCount_Decrement_out_struct
#ifdef _DCL_ANYOPS_csObjReticle_WaferCount_Decrement_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjReticle_WaferCount_Decrement_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjReticle_WaferCount_Decrement_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjReticle_WaferCount_Decrement_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjReticle_WaferCount_Decrement_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjReticle_WaferCount_Decrement_in_struct
#ifdef _DCL_ANYOPS_csObjUserData_GetByLotOperation_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjUserData_GetByLotOperation_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjUserData_GetByLotOperation_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjUserData_GetByLotOperation_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjUserData_GetByLotOperation_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjUserData_GetByLotOperation_out_struct
#ifdef _DCL_ANYOPS_csObjUserData_GetByLotOperation_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjUserData_GetByLotOperation_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjUserData_GetByLotOperation_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjUserData_GetByLotOperation_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjUserData_GetByLotOperation_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjUserData_GetByLotOperation_in_struct
#ifdef _DCL_ANYOPS_csObjReticlePod_Empty_Check_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjReticlePod_Empty_Check_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjReticlePod_Empty_Check_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjReticlePod_Empty_Check_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjReticlePod_Empty_Check_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjReticlePod_Empty_Check_out_struct
#ifdef _DCL_ANYOPS_csObjReticlePod_Empty_Check_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjReticlePod_Empty_Check_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjReticlePod_Empty_Check_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjReticlePod_Empty_Check_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjReticlePod_Empty_Check_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjReticlePod_Empty_Check_in_struct
#ifdef _DCL_ANYOPS_csObjVendorLotReserve_SelDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjVendorLotReserve_SelDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjVendorLotReserve_SelDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjVendorLotReserve_SelDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjVendorLotReserve_SelDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjVendorLotReserve_SelDR_out_struct
#ifdef _DCL_ANYOPS_csObjLot_ContaminationInfo_Get_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_Get_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_ContaminationInfo_Get_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_ContaminationInfo_Get_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_Get_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_ContaminationInfo_Get_in_struct
#ifdef _DCL_ANYOPS_csObjLot_ContaminationInfo_Get_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_Get_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_ContaminationInfo_Get_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_ContaminationInfo_Get_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_Get_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_ContaminationInfo_Get_out_struct
#ifdef _DCL_ANYOPS_csObjLot_ContaminationInfo_Set_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_Set_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_ContaminationInfo_Set_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_ContaminationInfo_Set_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_Set_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_ContaminationInfo_Set_in_struct
#ifdef _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForMove_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForMove_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForMove_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForMove_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForMove_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForMove_in_struct
#ifdef _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForMove_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForMove_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForMove_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForMove_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForMove_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForMove_out_struct
#ifdef _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForProcess_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForProcess_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForProcess_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForProcess_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForProcess_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForProcess_in_struct
#ifdef _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForProcess_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForProcess_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForProcess_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForProcess_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForProcess_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForProcess_out_struct
#ifdef _DCL_ANYOPS_csObjLot_udata_CopyToChild_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_udata_CopyToChild_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_udata_CopyToChild_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_udata_CopyToChild_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_udata_CopyToChild_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_udata_CopyToChild_in_struct
#ifdef _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForCarrierExchange_in_struct
#ifdef _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_ContaminationInfo_CheckForCarrierExchange_out_struct
#ifdef _DCL_ANYOPS_csObjEquipment_udata_GetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEquipment_udata_GetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEquipment_udata_GetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEquipment_udata_GetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEquipment_udata_GetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEquipment_udata_GetDR_in_struct
#ifdef _DCL_ANYOPS_csObjEquipment_udata_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEquipment_udata_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEquipment_udata_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEquipment_udata_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEquipment_udata_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEquipment_udata_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjCarrier_UsageTypeChange_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjCarrier_UsageTypeChange_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjCarrier_UsageTypeChange_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjCarrier_UsageTypeChange_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjCarrier_UsageTypeChange_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjCarrier_UsageTypeChange_in_struct
#ifdef _DCL_ANYOPS_csObjLot_requiredCarrierCategory_CheckDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLot_requiredCarrierCategory_CheckDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLot_requiredCarrierCategory_CheckDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLot_requiredCarrierCategory_CheckDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLot_requiredCarrierCategory_CheckDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLot_requiredCarrierCategory_CheckDR_in_struct
#ifdef _DCL_ANYOPS_csObjPerson_SkillList_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjPerson_SkillList_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjPerson_SkillList_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjPerson_SkillList_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjPerson_SkillList_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjPerson_SkillList_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjPerson_SkillList_GetDR_in_strcut
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjPerson_SkillList_GetDR_in_strcut &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjPerson_SkillList_GetDR_in_strcut *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjPerson_SkillList_GetDR_in_strcut*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjPerson_SkillList_GetDR_in_strcut*& _data);
#endif
#endif // _DCL_ANYOPS_csObjPerson_SkillList_GetDR_in_strcut
#ifdef _DCL_ANYOPS_csObjPerson_SkillList_AddDR_in_strcut
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjPerson_SkillList_AddDR_in_strcut &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjPerson_SkillList_AddDR_in_strcut *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjPerson_SkillList_AddDR_in_strcut*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjPerson_SkillList_AddDR_in_strcut*& _data);
#endif
#endif // _DCL_ANYOPS_csObjPerson_SkillList_AddDR_in_strcut
#ifdef _DCL_ANYOPS_csObjPerson_SkillList_DelDR_in_strcut
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjPerson_SkillList_DelDR_in_strcut &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjPerson_SkillList_DelDR_in_strcut *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjPerson_SkillList_DelDR_in_strcut*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjPerson_SkillList_DelDR_in_strcut*& _data);
#endif
#endif // _DCL_ANYOPS_csObjPerson_SkillList_DelDR_in_strcut
#ifdef _DCL_ANYOPS_csObjPerson_SkillList_SetDR_in_strcut
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjPerson_SkillList_SetDR_in_strcut &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjPerson_SkillList_SetDR_in_strcut *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjPerson_SkillList_SetDR_in_strcut*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjPerson_SkillList_SetDR_in_strcut*& _data);
#endif
#endif // _DCL_ANYOPS_csObjPerson_SkillList_SetDR_in_strcut
#ifdef _DCL_ANYOPS_csObjPerson_PrivilegeCheckForTACertify_in_strcut
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjPerson_PrivilegeCheckForTACertify_in_strcut &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjPerson_PrivilegeCheckForTACertify_in_strcut *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjPerson_PrivilegeCheckForTACertify_in_strcut*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjPerson_PrivilegeCheckForTACertify_in_strcut*& _data);
#endif
#endif // _DCL_ANYOPS_csObjPerson_PrivilegeCheckForTACertify_in_strcut
#ifdef _DCL_ANYOPS_csObjFixture_touchCountSet_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjFixture_touchCountSet_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjFixture_touchCountSet_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjFixture_touchCountSet_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjFixture_touchCountSet_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjFixture_touchCountSet_in_struct
#ifdef _DCL_ANYOPS_csObjFixture_touchCountSet_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjFixture_touchCountSet_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjFixture_touchCountSet_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjFixture_touchCountSet_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjFixture_touchCountSet_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjFixture_touchCountSet_out_struct
#ifdef _DCL_ANYOPS_csObjFixture_touchCount_Get_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjFixture_touchCount_Get_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjFixture_touchCount_Get_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjFixture_touchCount_Get_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjFixture_touchCount_Get_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjFixture_touchCount_Get_in_struct
#ifdef _DCL_ANYOPS_csObjFixture_touchCount_Get_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjFixture_touchCount_Get_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjFixture_touchCount_Get_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjFixture_touchCount_Get_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjFixture_touchCount_Get_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjFixture_touchCount_Get_out_struct
#ifdef _DCL_ANYOPS_csObjWafer_userDataInfo_GetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjWafer_userDataInfo_GetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjWafer_userDataInfo_GetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjWafer_userDataInfo_GetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjWafer_userDataInfo_GetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjWafer_userDataInfo_GetDR_in_struct
#ifdef _DCL_ANYOPS_csObjWafer_userDataInfo_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjWafer_userDataInfo_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjWafer_userDataInfo_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjWafer_userDataInfo_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjWafer_userDataInfo_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjWafer_userDataInfo_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjDurable_userDataInfo_GetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjDurable_userDataInfo_GetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjDurable_userDataInfo_GetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjDurable_userDataInfo_GetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjDurable_userDataInfo_GetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjDurable_userDataInfo_GetDR_in_struct
#ifdef _DCL_ANYOPS_csObjDurable_userDataInfo_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjDurable_userDataInfo_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjDurable_userDataInfo_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjDurable_userDataInfo_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjDurable_userDataInfo_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjDurable_userDataInfo_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjUserData_GetByOperation_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjUserData_GetByOperation_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjUserData_GetByOperation_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjUserData_GetByOperation_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjUserData_GetByOperation_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjUserData_GetByOperation_in_struct
#ifdef _DCL_ANYOPS_csObjUserData_GetByOperation_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjUserData_GetByOperation_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjUserData_GetByOperation_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjUserData_GetByOperation_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjUserData_GetByOperation_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjUserData_GetByOperation_out_struct
#ifdef _DCL_ANYOPS_csObjAPC_LithoAvailable_CheckCondition_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPC_LithoAvailable_CheckCondition_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPC_LithoAvailable_CheckCondition_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPC_LithoAvailable_CheckCondition_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPC_LithoAvailable_CheckCondition_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPC_LithoAvailable_CheckCondition_in_struct
#ifdef _DCL_ANYOPS_csObjAPC_LithoAvailable_CheckCondition_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPC_LithoAvailable_CheckCondition_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPC_LithoAvailable_CheckCondition_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPC_LithoAvailable_CheckCondition_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPC_LithoAvailable_CheckCondition_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPC_LithoAvailable_CheckCondition_out_struct
#ifdef _DCL_ANYOPS_csObjAPC_LithoLotDataInfo_Get_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPC_LithoLotDataInfo_Get_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPC_LithoLotDataInfo_Get_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPC_LithoLotDataInfo_Get_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPC_LithoLotDataInfo_Get_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPC_LithoLotDataInfo_Get_in_struct
#ifdef _DCL_ANYOPS_csObjAPC_LithoLotDataInfo_Get_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPC_LithoLotDataInfo_Get_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPC_LithoLotDataInfo_Get_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPC_LithoLotDataInfo_Get_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPC_LithoLotDataInfo_Get_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPC_LithoLotDataInfo_Get_out_struct
#ifdef _DCL_ANYOPS_csObjAPC_LithoContextInfo_Get_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPC_LithoContextInfo_Get_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPC_LithoContextInfo_Get_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPC_LithoContextInfo_Get_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPC_LithoContextInfo_Get_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPC_LithoContextInfo_Get_in_struct
#ifdef _DCL_ANYOPS_csObjAPC_LithoContextInfo_Get_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPC_LithoContextInfo_Get_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPC_LithoContextInfo_Get_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPC_LithoContextInfo_Get_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPC_LithoContextInfo_Get_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPC_LithoContextInfo_Get_out_struct
#ifdef _DCL_ANYOPS_csObjAPCMgr_SendLithoUsedInfoReq_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoUsedInfoReq_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPCMgr_SendLithoUsedInfoReq_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPCMgr_SendLithoUsedInfoReq_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoUsedInfoReq_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPCMgr_SendLithoUsedInfoReq_in_struct
#ifdef _DCL_ANYOPS_csObjAPCMgr_SendLithoUsedInfoReq_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoUsedInfoReq_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPCMgr_SendLithoUsedInfoReq_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPCMgr_SendLithoUsedInfoReq_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoUsedInfoReq_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPCMgr_SendLithoUsedInfoReq_out_struct
#ifdef _DCL_ANYOPS_csObjAPCMgr_SendLithoRecommendInfoInq_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoRecommendInfoInq_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPCMgr_SendLithoRecommendInfoInq_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPCMgr_SendLithoRecommendInfoInq_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoRecommendInfoInq_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPCMgr_SendLithoRecommendInfoInq_in_struct
#ifdef _DCL_ANYOPS_csObjAPCMgr_SendLithoRecommendInfoInq_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoRecommendInfoInq_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPCMgr_SendLithoRecommendInfoInq_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPCMgr_SendLithoRecommendInfoInq_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoRecommendInfoInq_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPCMgr_SendLithoRecommendInfoInq_out_struct
#ifdef _DCL_ANYOPS_csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPCMgr_SendLithoMetrologyInfoReq_in_struct
#ifdef _DCL_ANYOPS_csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPCMgr_SendLithoMetrologyInfoReq_out_struct
#ifdef _DCL_ANYOPS_csObjControlJob_BatchSize_Check_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjControlJob_BatchSize_Check_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjControlJob_BatchSize_Check_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjControlJob_BatchSize_Check_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjControlJob_BatchSize_Check_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjControlJob_BatchSize_Check_out_struct
#ifdef _DCL_ANYOPS_csObjControlJob_BatchSize_Check_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjControlJob_BatchSize_Check_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjControlJob_BatchSize_Check_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjControlJob_BatchSize_Check_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjControlJob_BatchSize_Check_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjControlJob_BatchSize_Check_in_struct
#ifdef _DCL_ANYOPS_csObjLotID_ControlInfo_GetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLotID_ControlInfo_GetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLotID_ControlInfo_GetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLotID_ControlInfo_GetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLotID_ControlInfo_GetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLotID_ControlInfo_GetDR_in_struct
#ifdef _DCL_ANYOPS_csObjLotID_ControlInfo_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLotID_ControlInfo_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLotID_ControlInfo_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLotID_ControlInfo_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLotID_ControlInfo_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLotID_ControlInfo_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjLotID_ControlInfo_SetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLotID_ControlInfo_SetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLotID_ControlInfo_SetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLotID_ControlInfo_SetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLotID_ControlInfo_SetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLotID_ControlInfo_SetDR_in_struct
#ifdef _DCL_ANYOPS_csObjLotID_ControlInfo_AddDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjLotID_ControlInfo_AddDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjLotID_ControlInfo_AddDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjLotID_ControlInfo_AddDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjLotID_ControlInfo_AddDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjLotID_ControlInfo_AddDR_in_struct
#ifdef _DCL_ANYOPS_csObjBWS_Config_GetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWS_Config_GetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWS_Config_GetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWS_Config_GetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWS_Config_GetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWS_Config_GetDR_in_struct
#ifdef _DCL_ANYOPS_csObjBWS_Config_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWS_Config_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWS_Config_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWS_Config_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWS_Config_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWS_Config_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjBWS_Config_AddDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWS_Config_AddDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWS_Config_AddDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWS_Config_AddDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWS_Config_AddDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWS_Config_AddDR_in_struct
#ifdef _DCL_ANYOPS_csObjBWS_Config_DeleteDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWS_Config_DeleteDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWS_Config_DeleteDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWS_Config_DeleteDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWS_Config_DeleteDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWS_Config_DeleteDR_in_struct
#ifdef _DCL_ANYOPS_csObjAPC_EventQueue_AddDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPC_EventQueue_AddDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPC_EventQueue_AddDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPC_EventQueue_AddDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPC_EventQueue_AddDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPC_EventQueue_AddDR_in_struct
#ifdef _DCL_ANYOPS_csObjAPC_EventQueue_DelDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPC_EventQueue_DelDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPC_EventQueue_DelDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPC_EventQueue_DelDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPC_EventQueue_DelDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPC_EventQueue_DelDR_in_struct
#ifdef _DCL_ANYOPS_csObjAPC_LotEventQueue_Make_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPC_LotEventQueue_Make_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPC_LotEventQueue_Make_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPC_LotEventQueue_Make_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPC_LotEventQueue_Make_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPC_LotEventQueue_Make_in_struct
#ifdef _DCL_ANYOPS_csObjAPC_LotEventQueue_Make_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjAPC_LotEventQueue_Make_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjAPC_LotEventQueue_Make_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjAPC_LotEventQueue_Make_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjAPC_LotEventQueue_Make_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjAPC_LotEventQueue_Make_out_struct
#ifdef _DCL_ANYOPS_csObjBWS_WaferList_GetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWS_WaferList_GetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWS_WaferList_GetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWS_WaferList_GetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWS_WaferList_GetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWS_WaferList_GetDR_out_struct
#ifdef _DCL_ANYOPS_csObjBWS_WaferList_AddDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWS_WaferList_AddDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWS_WaferList_AddDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWS_WaferList_AddDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWS_WaferList_AddDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWS_WaferList_AddDR_in_struct
#ifdef _DCL_ANYOPS_csObjBWS_WaferList_DeleteDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjBWS_WaferList_DeleteDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjBWS_WaferList_DeleteDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjBWS_WaferList_DeleteDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjBWS_WaferList_DeleteDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjBWS_WaferList_DeleteDR_in_struct
#ifdef _DCL_ANYOPS_csObjEqpMonitorInventory_ListGetDR_in_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEqpMonitorInventory_ListGetDR_in_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEqpMonitorInventory_ListGetDR_in_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEqpMonitorInventory_ListGetDR_in_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEqpMonitorInventory_ListGetDR_in_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEqpMonitorInventory_ListGetDR_in_struct
#ifdef _DCL_ANYOPS_csObjEqpMonitorInventory_ListGetDR_out_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csObjEqpMonitorInventory_ListGetDR_out_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csObjEqpMonitorInventory_ListGetDR_out_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csObjEqpMonitorInventory_ListGetDR_out_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csObjEqpMonitorInventory_ListGetDR_out_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csObjEqpMonitorInventory_ListGetDR_out_struct

#endif /* _cs_pptobstr_hh_included */

#endif /* _cs_pptobstr_server_defined */
