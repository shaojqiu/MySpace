//----------------------------------------------------------------------------
//
//  Generated from cs_pptstr.idl
//  On Thursday, October 19, 2017 5:48:39 PM GMT+07:00
//  by IBM CORBA 2.3 (hh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _cs_pptstr_server_defined
#ifndef _cs_pptstr_hh_included
#define _cs_pptstr_hh_included

#ifdef _MSC_VER
#define _export export
#endif
#ifndef _USE_NAMESPACE
#define _USE_NAMESPACE
#endif

#ifndef CORBA_included
#include <corba.h>
#endif
#ifdef SIVIEW_EBROKER
extern "C" {
   #include<stdlib.h>
}
 #if defined(minor)
  #undef minor
 #endif
#endif // SIVIEW_EBROKER

#ifndef IMTRIM
#define IMTRIM
#endif

#ifndef IM_EBROKER
#define IM_EBROKER
#endif

#ifndef CIMFWEVENTS_DISABLED
#define CIMFWEVENTS_DISABLED
#endif

#ifndef DB2PW
#define DB2PW
#endif

#ifndef _AIX
#define _AIX
#endif


#ifndef CS_PPTSTR_IDL 
#define CS_PPTSTR_IDL 
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _fwcommon_hh_included
#include <fwcommon.hh>
#endif
#else
#ifndef _fwcommon_hh_included
#include "fwcommon.hh"
#endif
#endif
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _pptstr_hh_included
#include <pptstr.hh>
#endif
#else
#ifndef _pptstr_hh_included
#include "pptstr.hh"
#endif
#endif
    class  csTestFunctionInfo_struct_var;
    struct  csTestFunctionInfo_struct {
        typedef csTestFunctionInfo_struct_var _var_type;
       ::CORBA::String_StructElem inquireType;
       ::CORBA::Boolean recommendFlag;
       ::CORBA::Boolean usedFlag;
       ::CORBA::Boolean metrologyFlag;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csTestFunctionInfo_struct();
       csTestFunctionInfo_struct(const csTestFunctionInfo_struct&);
       csTestFunctionInfo_struct& operator=(const csTestFunctionInfo_struct&);
       static CORBA::Info<csTestFunctionInfo_struct> csTestFunctionInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csTestFunctionInfo_struct


typedef csTestFunctionInfo_struct* csTestFunctionInfo_struct_vPtr;
typedef const csTestFunctionInfo_struct* csTestFunctionInfo_struct_cvPtr;

class  csTestFunctionInfo_struct_var
{
    public:

    csTestFunctionInfo_struct_var ();

    csTestFunctionInfo_struct_var (csTestFunctionInfo_struct *_p);

    csTestFunctionInfo_struct_var (const csTestFunctionInfo_struct_var &_s);

    csTestFunctionInfo_struct_var &operator= (csTestFunctionInfo_struct *_p);

    csTestFunctionInfo_struct_var &operator= (const csTestFunctionInfo_struct_var &_s);

    ~csTestFunctionInfo_struct_var ();

    csTestFunctionInfo_struct* operator-> ();

    const csTestFunctionInfo_struct& in() const;
    csTestFunctionInfo_struct& inout();
    csTestFunctionInfo_struct*& out();
    csTestFunctionInfo_struct* _retn();

    operator csTestFunctionInfo_struct_cvPtr () const;

    operator csTestFunctionInfo_struct_vPtr& ();

    operator const csTestFunctionInfo_struct& () const;

    operator csTestFunctionInfo_struct& ();

    protected:
    csTestFunctionInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csTestFunctionInfo_struct;
    typedef csTestFunctionInfo_struct csTestFunctionInfo;
    typedef csTestFunctionInfo_struct_var csTestFunctionInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csTestFunctionInfo;
class  _IDL_SEQ_csTestFunctionInfoSequence_0_var;
class  _IDL_SEQ_csTestFunctionInfoSequence_0 {
    public:
        typedef _IDL_SEQ_csTestFunctionInfoSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csTestFunctionInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csTestFunctionInfoSequence_0 ();
    _IDL_SEQ_csTestFunctionInfoSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csTestFunctionInfoSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csTestFunctionInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csTestFunctionInfoSequence_0 (const _IDL_SEQ_csTestFunctionInfoSequence_0&);

    ~_IDL_SEQ_csTestFunctionInfoSequence_0 ();

    _IDL_SEQ_csTestFunctionInfoSequence_0& operator= (const _IDL_SEQ_csTestFunctionInfoSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csTestFunctionInfo& operator [] (::CORBA::ULong indx);
    const csTestFunctionInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csTestFunctionInfo* get_buffer (::CORBA::Boolean orphan=0);
    const csTestFunctionInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csTestFunctionInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csTestFunctionInfo* src, csTestFunctionInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csTestFunctionInfo* data); 
  public:

    static csTestFunctionInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csTestFunctionInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csTestFunctionInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csTestFunctionInfoSequence_0> csTestFunctionInfoSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csTestFunctionInfoSequence_0* _IDL_SEQ_csTestFunctionInfoSequence_0_vPtr;
typedef const _IDL_SEQ_csTestFunctionInfoSequence_0* _IDL_SEQ_csTestFunctionInfoSequence_0_cvPtr;

class  _IDL_SEQ_csTestFunctionInfoSequence_0_var
{
    public:

    _IDL_SEQ_csTestFunctionInfoSequence_0_var ();

    _IDL_SEQ_csTestFunctionInfoSequence_0_var (_IDL_SEQ_csTestFunctionInfoSequence_0 *_p);

    _IDL_SEQ_csTestFunctionInfoSequence_0_var (const _IDL_SEQ_csTestFunctionInfoSequence_0_var &_s);

    _IDL_SEQ_csTestFunctionInfoSequence_0_var &operator= (_IDL_SEQ_csTestFunctionInfoSequence_0 *_p);

    _IDL_SEQ_csTestFunctionInfoSequence_0_var &operator= (const _IDL_SEQ_csTestFunctionInfoSequence_0_var &_s);

    ~_IDL_SEQ_csTestFunctionInfoSequence_0_var ();

    _IDL_SEQ_csTestFunctionInfoSequence_0* operator-> ();

    operator _IDL_SEQ_csTestFunctionInfoSequence_0_cvPtr () const;

    operator _IDL_SEQ_csTestFunctionInfoSequence_0_vPtr& ();

    operator _IDL_SEQ_csTestFunctionInfoSequence_0() const;

    const csTestFunctionInfo& operator[] (::CORBA::ULong index) const;
    csTestFunctionInfo& operator[] (::CORBA::ULong index);
    const csTestFunctionInfo& operator[] (int index) const;
    csTestFunctionInfo& operator[] (int index);
    const _IDL_SEQ_csTestFunctionInfoSequence_0& in() const;
    _IDL_SEQ_csTestFunctionInfoSequence_0& inout();
    _IDL_SEQ_csTestFunctionInfoSequence_0*& out();
    _IDL_SEQ_csTestFunctionInfoSequence_0* _retn();

    protected:
    _IDL_SEQ_csTestFunctionInfoSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csTestFunctionInfoSequence_0 _csTestFunctionInfoSequence_seq;
    typedef _IDL_SEQ_csTestFunctionInfoSequence_0 _csTestFunctionInfoSequence_seq_1;
    typedef _IDL_SEQ_csTestFunctionInfoSequence_0 csTestFunctionInfoSequence;
    typedef _IDL_SEQ_csTestFunctionInfoSequence_0_var csTestFunctionInfoSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csTestFunctionInfoSequence;
    class  csTestFunctionResult_struct_var;
    struct  csTestFunctionResult_struct {
        typedef csTestFunctionResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::csTestFunctionInfoSequence infos;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csTestFunctionResult_struct();
       csTestFunctionResult_struct(const csTestFunctionResult_struct&);
       csTestFunctionResult_struct& operator=(const csTestFunctionResult_struct&);
       static CORBA::Info<csTestFunctionResult_struct> csTestFunctionResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csTestFunctionResult_struct


typedef csTestFunctionResult_struct* csTestFunctionResult_struct_vPtr;
typedef const csTestFunctionResult_struct* csTestFunctionResult_struct_cvPtr;

class  csTestFunctionResult_struct_var
{
    public:

    csTestFunctionResult_struct_var ();

    csTestFunctionResult_struct_var (csTestFunctionResult_struct *_p);

    csTestFunctionResult_struct_var (const csTestFunctionResult_struct_var &_s);

    csTestFunctionResult_struct_var &operator= (csTestFunctionResult_struct *_p);

    csTestFunctionResult_struct_var &operator= (const csTestFunctionResult_struct_var &_s);

    ~csTestFunctionResult_struct_var ();

    csTestFunctionResult_struct* operator-> ();

    const csTestFunctionResult_struct& in() const;
    csTestFunctionResult_struct& inout();
    csTestFunctionResult_struct*& out();
    csTestFunctionResult_struct* _retn();

    operator csTestFunctionResult_struct_cvPtr () const;

    operator csTestFunctionResult_struct_vPtr& ();

    operator const csTestFunctionResult_struct& () const;

    operator csTestFunctionResult_struct& ();

    protected:
    csTestFunctionResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csTestFunctionResult_struct;
    typedef csTestFunctionResult_struct csTestFunctionResult;
    typedef csTestFunctionResult_struct_var csTestFunctionResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csTestFunctionResult;
    class  csEqpInAuditListInqResult_struct_var;
    struct  csEqpInAuditListInqResult_struct {
        typedef csEqpInAuditListInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifierSequence EquipmentIDs;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpInAuditListInqResult_struct();
       csEqpInAuditListInqResult_struct(const csEqpInAuditListInqResult_struct&);
       csEqpInAuditListInqResult_struct& operator=(const csEqpInAuditListInqResult_struct&);
       static CORBA::Info<csEqpInAuditListInqResult_struct> csEqpInAuditListInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpInAuditListInqResult_struct


typedef csEqpInAuditListInqResult_struct* csEqpInAuditListInqResult_struct_vPtr;
typedef const csEqpInAuditListInqResult_struct* csEqpInAuditListInqResult_struct_cvPtr;

class  csEqpInAuditListInqResult_struct_var
{
    public:

    csEqpInAuditListInqResult_struct_var ();

    csEqpInAuditListInqResult_struct_var (csEqpInAuditListInqResult_struct *_p);

    csEqpInAuditListInqResult_struct_var (const csEqpInAuditListInqResult_struct_var &_s);

    csEqpInAuditListInqResult_struct_var &operator= (csEqpInAuditListInqResult_struct *_p);

    csEqpInAuditListInqResult_struct_var &operator= (const csEqpInAuditListInqResult_struct_var &_s);

    ~csEqpInAuditListInqResult_struct_var ();

    csEqpInAuditListInqResult_struct* operator-> ();

    const csEqpInAuditListInqResult_struct& in() const;
    csEqpInAuditListInqResult_struct& inout();
    csEqpInAuditListInqResult_struct*& out();
    csEqpInAuditListInqResult_struct* _retn();

    operator csEqpInAuditListInqResult_struct_cvPtr () const;

    operator csEqpInAuditListInqResult_struct_vPtr& ();

    operator const csEqpInAuditListInqResult_struct& () const;

    operator csEqpInAuditListInqResult_struct& ();

    protected:
    csEqpInAuditListInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpInAuditListInqResult_struct;
    typedef csEqpInAuditListInqResult_struct csEqpInAuditListInqResult;
    typedef csEqpInAuditListInqResult_struct_var csEqpInAuditListInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpInAuditListInqResult;
    typedef pptBaseResult csPrivilegeCheckForRMSReqResult;
    typedef pptBaseResult_var csPrivilegeCheckForRMSReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csPrivilegeCheckForRMSReqResult;
    class  csEqpsByOwner_struct_var;
    struct  csEqpsByOwner_struct {
        typedef csEqpsByOwner_struct_var _var_type;
       ::objectIdentifier equipmentOwnerID;
       ::objectIdentifierSequence equipmentIDs;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpsByOwner_struct();
       csEqpsByOwner_struct(const csEqpsByOwner_struct&);
       csEqpsByOwner_struct& operator=(const csEqpsByOwner_struct&);
       static CORBA::Info<csEqpsByOwner_struct> csEqpsByOwner_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpsByOwner_struct


typedef csEqpsByOwner_struct* csEqpsByOwner_struct_vPtr;
typedef const csEqpsByOwner_struct* csEqpsByOwner_struct_cvPtr;

class  csEqpsByOwner_struct_var
{
    public:

    csEqpsByOwner_struct_var ();

    csEqpsByOwner_struct_var (csEqpsByOwner_struct *_p);

    csEqpsByOwner_struct_var (const csEqpsByOwner_struct_var &_s);

    csEqpsByOwner_struct_var &operator= (csEqpsByOwner_struct *_p);

    csEqpsByOwner_struct_var &operator= (const csEqpsByOwner_struct_var &_s);

    ~csEqpsByOwner_struct_var ();

    csEqpsByOwner_struct* operator-> ();

    const csEqpsByOwner_struct& in() const;
    csEqpsByOwner_struct& inout();
    csEqpsByOwner_struct*& out();
    csEqpsByOwner_struct* _retn();

    operator csEqpsByOwner_struct_cvPtr () const;

    operator csEqpsByOwner_struct_vPtr& ();

    operator const csEqpsByOwner_struct& () const;

    operator csEqpsByOwner_struct& ();

    protected:
    csEqpsByOwner_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpsByOwner_struct;
    typedef csEqpsByOwner_struct csEqpsByOwner;
    typedef csEqpsByOwner_struct_var csEqpsByOwner_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpsByOwner;
class  _IDL_SEQ_csEqpsByOwnerSequence_0_var;
class  _IDL_SEQ_csEqpsByOwnerSequence_0 {
    public:
        typedef _IDL_SEQ_csEqpsByOwnerSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csEqpsByOwner *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csEqpsByOwnerSequence_0 ();
    _IDL_SEQ_csEqpsByOwnerSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csEqpsByOwnerSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csEqpsByOwner* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csEqpsByOwnerSequence_0 (const _IDL_SEQ_csEqpsByOwnerSequence_0&);

    ~_IDL_SEQ_csEqpsByOwnerSequence_0 ();

    _IDL_SEQ_csEqpsByOwnerSequence_0& operator= (const _IDL_SEQ_csEqpsByOwnerSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csEqpsByOwner& operator [] (::CORBA::ULong indx);
    const csEqpsByOwner& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csEqpsByOwner* get_buffer (::CORBA::Boolean orphan=0);
    const csEqpsByOwner* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csEqpsByOwner* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csEqpsByOwner* src, csEqpsByOwner* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csEqpsByOwner* data); 
  public:

    static csEqpsByOwner* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csEqpsByOwner* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csEqpsByOwner* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csEqpsByOwnerSequence_0> csEqpsByOwnerSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csEqpsByOwnerSequence_0* _IDL_SEQ_csEqpsByOwnerSequence_0_vPtr;
typedef const _IDL_SEQ_csEqpsByOwnerSequence_0* _IDL_SEQ_csEqpsByOwnerSequence_0_cvPtr;

class  _IDL_SEQ_csEqpsByOwnerSequence_0_var
{
    public:

    _IDL_SEQ_csEqpsByOwnerSequence_0_var ();

    _IDL_SEQ_csEqpsByOwnerSequence_0_var (_IDL_SEQ_csEqpsByOwnerSequence_0 *_p);

    _IDL_SEQ_csEqpsByOwnerSequence_0_var (const _IDL_SEQ_csEqpsByOwnerSequence_0_var &_s);

    _IDL_SEQ_csEqpsByOwnerSequence_0_var &operator= (_IDL_SEQ_csEqpsByOwnerSequence_0 *_p);

    _IDL_SEQ_csEqpsByOwnerSequence_0_var &operator= (const _IDL_SEQ_csEqpsByOwnerSequence_0_var &_s);

    ~_IDL_SEQ_csEqpsByOwnerSequence_0_var ();

    _IDL_SEQ_csEqpsByOwnerSequence_0* operator-> ();

    operator _IDL_SEQ_csEqpsByOwnerSequence_0_cvPtr () const;

    operator _IDL_SEQ_csEqpsByOwnerSequence_0_vPtr& ();

    operator _IDL_SEQ_csEqpsByOwnerSequence_0() const;

    const csEqpsByOwner& operator[] (::CORBA::ULong index) const;
    csEqpsByOwner& operator[] (::CORBA::ULong index);
    const csEqpsByOwner& operator[] (int index) const;
    csEqpsByOwner& operator[] (int index);
    const _IDL_SEQ_csEqpsByOwnerSequence_0& in() const;
    _IDL_SEQ_csEqpsByOwnerSequence_0& inout();
    _IDL_SEQ_csEqpsByOwnerSequence_0*& out();
    _IDL_SEQ_csEqpsByOwnerSequence_0* _retn();

    protected:
    _IDL_SEQ_csEqpsByOwnerSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csEqpsByOwnerSequence_0 _csEqpsByOwnerSequence_seq;
    typedef _IDL_SEQ_csEqpsByOwnerSequence_0 _csEqpsByOwnerSequence_seq_1;
    typedef _IDL_SEQ_csEqpsByOwnerSequence_0 csEqpsByOwnerSequence;
    typedef _IDL_SEQ_csEqpsByOwnerSequence_0_var csEqpsByOwnerSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpsByOwnerSequence;
    class  csEqpListByOwnerInqResult_struct_var;
    struct  csEqpListByOwnerInqResult_struct {
        typedef csEqpListByOwnerInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::csEqpsByOwnerSequence strEqpsByOwners;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpListByOwnerInqResult_struct();
       csEqpListByOwnerInqResult_struct(const csEqpListByOwnerInqResult_struct&);
       csEqpListByOwnerInqResult_struct& operator=(const csEqpListByOwnerInqResult_struct&);
       static CORBA::Info<csEqpListByOwnerInqResult_struct> csEqpListByOwnerInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpListByOwnerInqResult_struct


typedef csEqpListByOwnerInqResult_struct* csEqpListByOwnerInqResult_struct_vPtr;
typedef const csEqpListByOwnerInqResult_struct* csEqpListByOwnerInqResult_struct_cvPtr;

class  csEqpListByOwnerInqResult_struct_var
{
    public:

    csEqpListByOwnerInqResult_struct_var ();

    csEqpListByOwnerInqResult_struct_var (csEqpListByOwnerInqResult_struct *_p);

    csEqpListByOwnerInqResult_struct_var (const csEqpListByOwnerInqResult_struct_var &_s);

    csEqpListByOwnerInqResult_struct_var &operator= (csEqpListByOwnerInqResult_struct *_p);

    csEqpListByOwnerInqResult_struct_var &operator= (const csEqpListByOwnerInqResult_struct_var &_s);

    ~csEqpListByOwnerInqResult_struct_var ();

    csEqpListByOwnerInqResult_struct* operator-> ();

    const csEqpListByOwnerInqResult_struct& in() const;
    csEqpListByOwnerInqResult_struct& inout();
    csEqpListByOwnerInqResult_struct*& out();
    csEqpListByOwnerInqResult_struct* _retn();

    operator csEqpListByOwnerInqResult_struct_cvPtr () const;

    operator csEqpListByOwnerInqResult_struct_vPtr& ();

    operator const csEqpListByOwnerInqResult_struct& () const;

    operator csEqpListByOwnerInqResult_struct& ();

    protected:
    csEqpListByOwnerInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpListByOwnerInqResult_struct;
    typedef csEqpListByOwnerInqResult_struct csEqpListByOwnerInqResult;
    typedef csEqpListByOwnerInqResult_struct_var csEqpListByOwnerInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpListByOwnerInqResult;
    class  csEqpRMSFlgInqResult_struct_var;
    struct  csEqpRMSFlgInqResult_struct {
        typedef csEqpRMSFlgInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::Boolean theRMSBodyFlag;
       ::CORBA::Boolean theRMSConstFlag;
       ::CORBA::Boolean theRMSTotalFlag;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpRMSFlgInqResult_struct();
       csEqpRMSFlgInqResult_struct(const csEqpRMSFlgInqResult_struct&);
       csEqpRMSFlgInqResult_struct& operator=(const csEqpRMSFlgInqResult_struct&);
       static CORBA::Info<csEqpRMSFlgInqResult_struct> csEqpRMSFlgInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpRMSFlgInqResult_struct


typedef csEqpRMSFlgInqResult_struct* csEqpRMSFlgInqResult_struct_vPtr;
typedef const csEqpRMSFlgInqResult_struct* csEqpRMSFlgInqResult_struct_cvPtr;

class  csEqpRMSFlgInqResult_struct_var
{
    public:

    csEqpRMSFlgInqResult_struct_var ();

    csEqpRMSFlgInqResult_struct_var (csEqpRMSFlgInqResult_struct *_p);

    csEqpRMSFlgInqResult_struct_var (const csEqpRMSFlgInqResult_struct_var &_s);

    csEqpRMSFlgInqResult_struct_var &operator= (csEqpRMSFlgInqResult_struct *_p);

    csEqpRMSFlgInqResult_struct_var &operator= (const csEqpRMSFlgInqResult_struct_var &_s);

    ~csEqpRMSFlgInqResult_struct_var ();

    csEqpRMSFlgInqResult_struct* operator-> ();

    const csEqpRMSFlgInqResult_struct& in() const;
    csEqpRMSFlgInqResult_struct& inout();
    csEqpRMSFlgInqResult_struct*& out();
    csEqpRMSFlgInqResult_struct* _retn();

    operator csEqpRMSFlgInqResult_struct_cvPtr () const;

    operator csEqpRMSFlgInqResult_struct_vPtr& ();

    operator const csEqpRMSFlgInqResult_struct& () const;

    operator csEqpRMSFlgInqResult_struct& ();

    protected:
    csEqpRMSFlgInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpRMSFlgInqResult_struct;
    typedef csEqpRMSFlgInqResult_struct csEqpRMSFlgInqResult;
    typedef csEqpRMSFlgInqResult_struct_var csEqpRMSFlgInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpRMSFlgInqResult;
    class  csMachineRecipeInfo_struct_var;
    struct  csMachineRecipeInfo_struct {
        typedef csMachineRecipeInfo_struct_var _var_type;
       ::CORBA::String_StructElem machineRecipeID;
       ::CORBA::Boolean recipeCompareFlag;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csMachineRecipeInfo_struct();
       csMachineRecipeInfo_struct(const csMachineRecipeInfo_struct&);
       csMachineRecipeInfo_struct& operator=(const csMachineRecipeInfo_struct&);
       static CORBA::Info<csMachineRecipeInfo_struct> csMachineRecipeInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csMachineRecipeInfo_struct


typedef csMachineRecipeInfo_struct* csMachineRecipeInfo_struct_vPtr;
typedef const csMachineRecipeInfo_struct* csMachineRecipeInfo_struct_cvPtr;

class  csMachineRecipeInfo_struct_var
{
    public:

    csMachineRecipeInfo_struct_var ();

    csMachineRecipeInfo_struct_var (csMachineRecipeInfo_struct *_p);

    csMachineRecipeInfo_struct_var (const csMachineRecipeInfo_struct_var &_s);

    csMachineRecipeInfo_struct_var &operator= (csMachineRecipeInfo_struct *_p);

    csMachineRecipeInfo_struct_var &operator= (const csMachineRecipeInfo_struct_var &_s);

    ~csMachineRecipeInfo_struct_var ();

    csMachineRecipeInfo_struct* operator-> ();

    const csMachineRecipeInfo_struct& in() const;
    csMachineRecipeInfo_struct& inout();
    csMachineRecipeInfo_struct*& out();
    csMachineRecipeInfo_struct* _retn();

    operator csMachineRecipeInfo_struct_cvPtr () const;

    operator csMachineRecipeInfo_struct_vPtr& ();

    operator const csMachineRecipeInfo_struct& () const;

    operator csMachineRecipeInfo_struct& ();

    protected:
    csMachineRecipeInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csMachineRecipeInfo_struct;
    typedef csMachineRecipeInfo_struct csMachineRecipeInfo;
    typedef csMachineRecipeInfo_struct_var csMachineRecipeInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csMachineRecipeInfo;
class  _IDL_SEQ_csMachineRecipeInfoSequence_0_var;
class  _IDL_SEQ_csMachineRecipeInfoSequence_0 {
    public:
        typedef _IDL_SEQ_csMachineRecipeInfoSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csMachineRecipeInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csMachineRecipeInfoSequence_0 ();
    _IDL_SEQ_csMachineRecipeInfoSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csMachineRecipeInfoSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csMachineRecipeInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csMachineRecipeInfoSequence_0 (const _IDL_SEQ_csMachineRecipeInfoSequence_0&);

    ~_IDL_SEQ_csMachineRecipeInfoSequence_0 ();

    _IDL_SEQ_csMachineRecipeInfoSequence_0& operator= (const _IDL_SEQ_csMachineRecipeInfoSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csMachineRecipeInfo& operator [] (::CORBA::ULong indx);
    const csMachineRecipeInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csMachineRecipeInfo* get_buffer (::CORBA::Boolean orphan=0);
    const csMachineRecipeInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csMachineRecipeInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csMachineRecipeInfo* src, csMachineRecipeInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csMachineRecipeInfo* data); 
  public:

    static csMachineRecipeInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csMachineRecipeInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csMachineRecipeInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csMachineRecipeInfoSequence_0> csMachineRecipeInfoSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csMachineRecipeInfoSequence_0* _IDL_SEQ_csMachineRecipeInfoSequence_0_vPtr;
typedef const _IDL_SEQ_csMachineRecipeInfoSequence_0* _IDL_SEQ_csMachineRecipeInfoSequence_0_cvPtr;

class  _IDL_SEQ_csMachineRecipeInfoSequence_0_var
{
    public:

    _IDL_SEQ_csMachineRecipeInfoSequence_0_var ();

    _IDL_SEQ_csMachineRecipeInfoSequence_0_var (_IDL_SEQ_csMachineRecipeInfoSequence_0 *_p);

    _IDL_SEQ_csMachineRecipeInfoSequence_0_var (const _IDL_SEQ_csMachineRecipeInfoSequence_0_var &_s);

    _IDL_SEQ_csMachineRecipeInfoSequence_0_var &operator= (_IDL_SEQ_csMachineRecipeInfoSequence_0 *_p);

    _IDL_SEQ_csMachineRecipeInfoSequence_0_var &operator= (const _IDL_SEQ_csMachineRecipeInfoSequence_0_var &_s);

    ~_IDL_SEQ_csMachineRecipeInfoSequence_0_var ();

    _IDL_SEQ_csMachineRecipeInfoSequence_0* operator-> ();

    operator _IDL_SEQ_csMachineRecipeInfoSequence_0_cvPtr () const;

    operator _IDL_SEQ_csMachineRecipeInfoSequence_0_vPtr& ();

    operator _IDL_SEQ_csMachineRecipeInfoSequence_0() const;

    const csMachineRecipeInfo& operator[] (::CORBA::ULong index) const;
    csMachineRecipeInfo& operator[] (::CORBA::ULong index);
    const csMachineRecipeInfo& operator[] (int index) const;
    csMachineRecipeInfo& operator[] (int index);
    const _IDL_SEQ_csMachineRecipeInfoSequence_0& in() const;
    _IDL_SEQ_csMachineRecipeInfoSequence_0& inout();
    _IDL_SEQ_csMachineRecipeInfoSequence_0*& out();
    _IDL_SEQ_csMachineRecipeInfoSequence_0* _retn();

    protected:
    _IDL_SEQ_csMachineRecipeInfoSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csMachineRecipeInfoSequence_0 _csMachineRecipeInfoSequence_seq;
    typedef _IDL_SEQ_csMachineRecipeInfoSequence_0 _csMachineRecipeInfoSequence_seq_1;
    typedef _IDL_SEQ_csMachineRecipeInfoSequence_0 csMachineRecipeInfoSequence;
    typedef _IDL_SEQ_csMachineRecipeInfoSequence_0_var csMachineRecipeInfoSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csMachineRecipeInfoSequence;
    class  csRecipeCompareFlagInqResult_struct_var;
    struct  csRecipeCompareFlagInqResult_struct {
        typedef csRecipeCompareFlagInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::csMachineRecipeInfoSequence machineRecipeInfos;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csRecipeCompareFlagInqResult_struct();
       csRecipeCompareFlagInqResult_struct(const csRecipeCompareFlagInqResult_struct&);
       csRecipeCompareFlagInqResult_struct& operator=(const csRecipeCompareFlagInqResult_struct&);
       static CORBA::Info<csRecipeCompareFlagInqResult_struct> csRecipeCompareFlagInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csRecipeCompareFlagInqResult_struct


typedef csRecipeCompareFlagInqResult_struct* csRecipeCompareFlagInqResult_struct_vPtr;
typedef const csRecipeCompareFlagInqResult_struct* csRecipeCompareFlagInqResult_struct_cvPtr;

class  csRecipeCompareFlagInqResult_struct_var
{
    public:

    csRecipeCompareFlagInqResult_struct_var ();

    csRecipeCompareFlagInqResult_struct_var (csRecipeCompareFlagInqResult_struct *_p);

    csRecipeCompareFlagInqResult_struct_var (const csRecipeCompareFlagInqResult_struct_var &_s);

    csRecipeCompareFlagInqResult_struct_var &operator= (csRecipeCompareFlagInqResult_struct *_p);

    csRecipeCompareFlagInqResult_struct_var &operator= (const csRecipeCompareFlagInqResult_struct_var &_s);

    ~csRecipeCompareFlagInqResult_struct_var ();

    csRecipeCompareFlagInqResult_struct* operator-> ();

    const csRecipeCompareFlagInqResult_struct& in() const;
    csRecipeCompareFlagInqResult_struct& inout();
    csRecipeCompareFlagInqResult_struct*& out();
    csRecipeCompareFlagInqResult_struct* _retn();

    operator csRecipeCompareFlagInqResult_struct_cvPtr () const;

    operator csRecipeCompareFlagInqResult_struct_vPtr& ();

    operator const csRecipeCompareFlagInqResult_struct& () const;

    operator csRecipeCompareFlagInqResult_struct& ();

    protected:
    csRecipeCompareFlagInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csRecipeCompareFlagInqResult_struct;
    typedef csRecipeCompareFlagInqResult_struct csRecipeCompareFlagInqResult;
    typedef csRecipeCompareFlagInqResult_struct_var csRecipeCompareFlagInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csRecipeCompareFlagInqResult;
    typedef pptBaseResult csRecipeAuditReqResult;
    typedef pptBaseResult_var csRecipeAuditReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csRecipeAuditReqResult;
    class  csEqpInfo4RMS_struct_var;
    struct  csEqpInfo4RMS_struct {
        typedef csEqpInfo4RMS_struct_var _var_type;
       ::objectIdentifier equipmentID;
       ::CORBA::String_StructElem strEqpType;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpInfo4RMS_struct();
       csEqpInfo4RMS_struct(const csEqpInfo4RMS_struct&);
       csEqpInfo4RMS_struct& operator=(const csEqpInfo4RMS_struct&);
       static CORBA::Info<csEqpInfo4RMS_struct> csEqpInfo4RMS_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpInfo4RMS_struct


typedef csEqpInfo4RMS_struct* csEqpInfo4RMS_struct_vPtr;
typedef const csEqpInfo4RMS_struct* csEqpInfo4RMS_struct_cvPtr;

class  csEqpInfo4RMS_struct_var
{
    public:

    csEqpInfo4RMS_struct_var ();

    csEqpInfo4RMS_struct_var (csEqpInfo4RMS_struct *_p);

    csEqpInfo4RMS_struct_var (const csEqpInfo4RMS_struct_var &_s);

    csEqpInfo4RMS_struct_var &operator= (csEqpInfo4RMS_struct *_p);

    csEqpInfo4RMS_struct_var &operator= (const csEqpInfo4RMS_struct_var &_s);

    ~csEqpInfo4RMS_struct_var ();

    csEqpInfo4RMS_struct* operator-> ();

    const csEqpInfo4RMS_struct& in() const;
    csEqpInfo4RMS_struct& inout();
    csEqpInfo4RMS_struct*& out();
    csEqpInfo4RMS_struct* _retn();

    operator csEqpInfo4RMS_struct_cvPtr () const;

    operator csEqpInfo4RMS_struct_vPtr& ();

    operator const csEqpInfo4RMS_struct& () const;

    operator csEqpInfo4RMS_struct& ();

    protected:
    csEqpInfo4RMS_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpInfo4RMS_struct;
    typedef csEqpInfo4RMS_struct csEqpInfo4RMS;
    typedef csEqpInfo4RMS_struct_var csEqpInfo4RMS_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpInfo4RMS;
class  _IDL_SEQ_csEqpInfo4RMSSequence_0_var;
class  _IDL_SEQ_csEqpInfo4RMSSequence_0 {
    public:
        typedef _IDL_SEQ_csEqpInfo4RMSSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csEqpInfo4RMS *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csEqpInfo4RMSSequence_0 ();
    _IDL_SEQ_csEqpInfo4RMSSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csEqpInfo4RMSSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csEqpInfo4RMS* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csEqpInfo4RMSSequence_0 (const _IDL_SEQ_csEqpInfo4RMSSequence_0&);

    ~_IDL_SEQ_csEqpInfo4RMSSequence_0 ();

    _IDL_SEQ_csEqpInfo4RMSSequence_0& operator= (const _IDL_SEQ_csEqpInfo4RMSSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csEqpInfo4RMS& operator [] (::CORBA::ULong indx);
    const csEqpInfo4RMS& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csEqpInfo4RMS* get_buffer (::CORBA::Boolean orphan=0);
    const csEqpInfo4RMS* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csEqpInfo4RMS* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csEqpInfo4RMS* src, csEqpInfo4RMS* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csEqpInfo4RMS* data); 
  public:

    static csEqpInfo4RMS* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csEqpInfo4RMS* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csEqpInfo4RMS* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csEqpInfo4RMSSequence_0> csEqpInfo4RMSSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csEqpInfo4RMSSequence_0* _IDL_SEQ_csEqpInfo4RMSSequence_0_vPtr;
typedef const _IDL_SEQ_csEqpInfo4RMSSequence_0* _IDL_SEQ_csEqpInfo4RMSSequence_0_cvPtr;

class  _IDL_SEQ_csEqpInfo4RMSSequence_0_var
{
    public:

    _IDL_SEQ_csEqpInfo4RMSSequence_0_var ();

    _IDL_SEQ_csEqpInfo4RMSSequence_0_var (_IDL_SEQ_csEqpInfo4RMSSequence_0 *_p);

    _IDL_SEQ_csEqpInfo4RMSSequence_0_var (const _IDL_SEQ_csEqpInfo4RMSSequence_0_var &_s);

    _IDL_SEQ_csEqpInfo4RMSSequence_0_var &operator= (_IDL_SEQ_csEqpInfo4RMSSequence_0 *_p);

    _IDL_SEQ_csEqpInfo4RMSSequence_0_var &operator= (const _IDL_SEQ_csEqpInfo4RMSSequence_0_var &_s);

    ~_IDL_SEQ_csEqpInfo4RMSSequence_0_var ();

    _IDL_SEQ_csEqpInfo4RMSSequence_0* operator-> ();

    operator _IDL_SEQ_csEqpInfo4RMSSequence_0_cvPtr () const;

    operator _IDL_SEQ_csEqpInfo4RMSSequence_0_vPtr& ();

    operator _IDL_SEQ_csEqpInfo4RMSSequence_0() const;

    const csEqpInfo4RMS& operator[] (::CORBA::ULong index) const;
    csEqpInfo4RMS& operator[] (::CORBA::ULong index);
    const csEqpInfo4RMS& operator[] (int index) const;
    csEqpInfo4RMS& operator[] (int index);
    const _IDL_SEQ_csEqpInfo4RMSSequence_0& in() const;
    _IDL_SEQ_csEqpInfo4RMSSequence_0& inout();
    _IDL_SEQ_csEqpInfo4RMSSequence_0*& out();
    _IDL_SEQ_csEqpInfo4RMSSequence_0* _retn();

    protected:
    _IDL_SEQ_csEqpInfo4RMSSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csEqpInfo4RMSSequence_0 _csEqpInfo4RMSSequence_seq;
    typedef _IDL_SEQ_csEqpInfo4RMSSequence_0 _csEqpInfo4RMSSequence_seq_1;
    typedef _IDL_SEQ_csEqpInfo4RMSSequence_0 csEqpInfo4RMSSequence;
    typedef _IDL_SEQ_csEqpInfo4RMSSequence_0_var csEqpInfo4RMSSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpInfo4RMSSequence;
    class  csEqpInfosByOwner_struct_var;
    struct  csEqpInfosByOwner_struct {
        typedef csEqpInfosByOwner_struct_var _var_type;
       ::objectIdentifier equipmentOwnerID;
       ::csEqpInfo4RMSSequence strEqpInfos;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpInfosByOwner_struct();
       csEqpInfosByOwner_struct(const csEqpInfosByOwner_struct&);
       csEqpInfosByOwner_struct& operator=(const csEqpInfosByOwner_struct&);
       static CORBA::Info<csEqpInfosByOwner_struct> csEqpInfosByOwner_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpInfosByOwner_struct


typedef csEqpInfosByOwner_struct* csEqpInfosByOwner_struct_vPtr;
typedef const csEqpInfosByOwner_struct* csEqpInfosByOwner_struct_cvPtr;

class  csEqpInfosByOwner_struct_var
{
    public:

    csEqpInfosByOwner_struct_var ();

    csEqpInfosByOwner_struct_var (csEqpInfosByOwner_struct *_p);

    csEqpInfosByOwner_struct_var (const csEqpInfosByOwner_struct_var &_s);

    csEqpInfosByOwner_struct_var &operator= (csEqpInfosByOwner_struct *_p);

    csEqpInfosByOwner_struct_var &operator= (const csEqpInfosByOwner_struct_var &_s);

    ~csEqpInfosByOwner_struct_var ();

    csEqpInfosByOwner_struct* operator-> ();

    const csEqpInfosByOwner_struct& in() const;
    csEqpInfosByOwner_struct& inout();
    csEqpInfosByOwner_struct*& out();
    csEqpInfosByOwner_struct* _retn();

    operator csEqpInfosByOwner_struct_cvPtr () const;

    operator csEqpInfosByOwner_struct_vPtr& ();

    operator const csEqpInfosByOwner_struct& () const;

    operator csEqpInfosByOwner_struct& ();

    protected:
    csEqpInfosByOwner_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpInfosByOwner_struct;
    typedef csEqpInfosByOwner_struct csEqpInfosByOwner;
    typedef csEqpInfosByOwner_struct_var csEqpInfosByOwner_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpInfosByOwner;
class  _IDL_SEQ_csEqpInfosByOwnerSequence_0_var;
class  _IDL_SEQ_csEqpInfosByOwnerSequence_0 {
    public:
        typedef _IDL_SEQ_csEqpInfosByOwnerSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csEqpInfosByOwner *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csEqpInfosByOwnerSequence_0 ();
    _IDL_SEQ_csEqpInfosByOwnerSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csEqpInfosByOwnerSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csEqpInfosByOwner* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csEqpInfosByOwnerSequence_0 (const _IDL_SEQ_csEqpInfosByOwnerSequence_0&);

    ~_IDL_SEQ_csEqpInfosByOwnerSequence_0 ();

    _IDL_SEQ_csEqpInfosByOwnerSequence_0& operator= (const _IDL_SEQ_csEqpInfosByOwnerSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csEqpInfosByOwner& operator [] (::CORBA::ULong indx);
    const csEqpInfosByOwner& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csEqpInfosByOwner* get_buffer (::CORBA::Boolean orphan=0);
    const csEqpInfosByOwner* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csEqpInfosByOwner* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csEqpInfosByOwner* src, csEqpInfosByOwner* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csEqpInfosByOwner* data); 
  public:

    static csEqpInfosByOwner* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csEqpInfosByOwner* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csEqpInfosByOwner* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csEqpInfosByOwnerSequence_0> csEqpInfosByOwnerSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csEqpInfosByOwnerSequence_0* _IDL_SEQ_csEqpInfosByOwnerSequence_0_vPtr;
typedef const _IDL_SEQ_csEqpInfosByOwnerSequence_0* _IDL_SEQ_csEqpInfosByOwnerSequence_0_cvPtr;

class  _IDL_SEQ_csEqpInfosByOwnerSequence_0_var
{
    public:

    _IDL_SEQ_csEqpInfosByOwnerSequence_0_var ();

    _IDL_SEQ_csEqpInfosByOwnerSequence_0_var (_IDL_SEQ_csEqpInfosByOwnerSequence_0 *_p);

    _IDL_SEQ_csEqpInfosByOwnerSequence_0_var (const _IDL_SEQ_csEqpInfosByOwnerSequence_0_var &_s);

    _IDL_SEQ_csEqpInfosByOwnerSequence_0_var &operator= (_IDL_SEQ_csEqpInfosByOwnerSequence_0 *_p);

    _IDL_SEQ_csEqpInfosByOwnerSequence_0_var &operator= (const _IDL_SEQ_csEqpInfosByOwnerSequence_0_var &_s);

    ~_IDL_SEQ_csEqpInfosByOwnerSequence_0_var ();

    _IDL_SEQ_csEqpInfosByOwnerSequence_0* operator-> ();

    operator _IDL_SEQ_csEqpInfosByOwnerSequence_0_cvPtr () const;

    operator _IDL_SEQ_csEqpInfosByOwnerSequence_0_vPtr& ();

    operator _IDL_SEQ_csEqpInfosByOwnerSequence_0() const;

    const csEqpInfosByOwner& operator[] (::CORBA::ULong index) const;
    csEqpInfosByOwner& operator[] (::CORBA::ULong index);
    const csEqpInfosByOwner& operator[] (int index) const;
    csEqpInfosByOwner& operator[] (int index);
    const _IDL_SEQ_csEqpInfosByOwnerSequence_0& in() const;
    _IDL_SEQ_csEqpInfosByOwnerSequence_0& inout();
    _IDL_SEQ_csEqpInfosByOwnerSequence_0*& out();
    _IDL_SEQ_csEqpInfosByOwnerSequence_0* _retn();

    protected:
    _IDL_SEQ_csEqpInfosByOwnerSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csEqpInfosByOwnerSequence_0 _csEqpInfosByOwnerSequence_seq;
    typedef _IDL_SEQ_csEqpInfosByOwnerSequence_0 _csEqpInfosByOwnerSequence_seq_1;
    typedef _IDL_SEQ_csEqpInfosByOwnerSequence_0 csEqpInfosByOwnerSequence;
    typedef _IDL_SEQ_csEqpInfosByOwnerSequence_0_var csEqpInfosByOwnerSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpInfosByOwnerSequence;
    class  csEqpInfoListByOwnerInqResult_struct_var;
    struct  csEqpInfoListByOwnerInqResult_struct {
        typedef csEqpInfoListByOwnerInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::csEqpInfosByOwnerSequence strEqpInfosByOwners;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpInfoListByOwnerInqResult_struct();
       csEqpInfoListByOwnerInqResult_struct(const csEqpInfoListByOwnerInqResult_struct&);
       csEqpInfoListByOwnerInqResult_struct& operator=(const csEqpInfoListByOwnerInqResult_struct&);
       static CORBA::Info<csEqpInfoListByOwnerInqResult_struct> csEqpInfoListByOwnerInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpInfoListByOwnerInqResult_struct


typedef csEqpInfoListByOwnerInqResult_struct* csEqpInfoListByOwnerInqResult_struct_vPtr;
typedef const csEqpInfoListByOwnerInqResult_struct* csEqpInfoListByOwnerInqResult_struct_cvPtr;

class  csEqpInfoListByOwnerInqResult_struct_var
{
    public:

    csEqpInfoListByOwnerInqResult_struct_var ();

    csEqpInfoListByOwnerInqResult_struct_var (csEqpInfoListByOwnerInqResult_struct *_p);

    csEqpInfoListByOwnerInqResult_struct_var (const csEqpInfoListByOwnerInqResult_struct_var &_s);

    csEqpInfoListByOwnerInqResult_struct_var &operator= (csEqpInfoListByOwnerInqResult_struct *_p);

    csEqpInfoListByOwnerInqResult_struct_var &operator= (const csEqpInfoListByOwnerInqResult_struct_var &_s);

    ~csEqpInfoListByOwnerInqResult_struct_var ();

    csEqpInfoListByOwnerInqResult_struct* operator-> ();

    const csEqpInfoListByOwnerInqResult_struct& in() const;
    csEqpInfoListByOwnerInqResult_struct& inout();
    csEqpInfoListByOwnerInqResult_struct*& out();
    csEqpInfoListByOwnerInqResult_struct* _retn();

    operator csEqpInfoListByOwnerInqResult_struct_cvPtr () const;

    operator csEqpInfoListByOwnerInqResult_struct_vPtr& ();

    operator const csEqpInfoListByOwnerInqResult_struct& () const;

    operator csEqpInfoListByOwnerInqResult_struct& ();

    protected:
    csEqpInfoListByOwnerInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpInfoListByOwnerInqResult_struct;
    typedef csEqpInfoListByOwnerInqResult_struct csEqpInfoListByOwnerInqResult;
    typedef csEqpInfoListByOwnerInqResult_struct_var csEqpInfoListByOwnerInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpInfoListByOwnerInqResult;
    class  csMandPRecipeInfo_struct_var;
    struct  csMandPRecipeInfo_struct {
        typedef csMandPRecipeInfo_struct_var _var_type;
       ::objectIdentifier machineRecipeID;
       ::CORBA::String_StructElem physicalRecipeID;
       ::CORBA::String_StructElem auditFlag;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csMandPRecipeInfo_struct();
       csMandPRecipeInfo_struct(const csMandPRecipeInfo_struct&);
       csMandPRecipeInfo_struct& operator=(const csMandPRecipeInfo_struct&);
       static CORBA::Info<csMandPRecipeInfo_struct> csMandPRecipeInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csMandPRecipeInfo_struct


typedef csMandPRecipeInfo_struct* csMandPRecipeInfo_struct_vPtr;
typedef const csMandPRecipeInfo_struct* csMandPRecipeInfo_struct_cvPtr;

class  csMandPRecipeInfo_struct_var
{
    public:

    csMandPRecipeInfo_struct_var ();

    csMandPRecipeInfo_struct_var (csMandPRecipeInfo_struct *_p);

    csMandPRecipeInfo_struct_var (const csMandPRecipeInfo_struct_var &_s);

    csMandPRecipeInfo_struct_var &operator= (csMandPRecipeInfo_struct *_p);

    csMandPRecipeInfo_struct_var &operator= (const csMandPRecipeInfo_struct_var &_s);

    ~csMandPRecipeInfo_struct_var ();

    csMandPRecipeInfo_struct* operator-> ();

    const csMandPRecipeInfo_struct& in() const;
    csMandPRecipeInfo_struct& inout();
    csMandPRecipeInfo_struct*& out();
    csMandPRecipeInfo_struct* _retn();

    operator csMandPRecipeInfo_struct_cvPtr () const;

    operator csMandPRecipeInfo_struct_vPtr& ();

    operator const csMandPRecipeInfo_struct& () const;

    operator csMandPRecipeInfo_struct& ();

    protected:
    csMandPRecipeInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csMandPRecipeInfo_struct;
    typedef csMandPRecipeInfo_struct csMandPRecipeInfo;
    typedef csMandPRecipeInfo_struct_var csMandPRecipeInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csMandPRecipeInfo;
class  _IDL_SEQ_csMandPRecipeInfoSequence_0_var;
class  _IDL_SEQ_csMandPRecipeInfoSequence_0 {
    public:
        typedef _IDL_SEQ_csMandPRecipeInfoSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csMandPRecipeInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csMandPRecipeInfoSequence_0 ();
    _IDL_SEQ_csMandPRecipeInfoSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csMandPRecipeInfoSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csMandPRecipeInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csMandPRecipeInfoSequence_0 (const _IDL_SEQ_csMandPRecipeInfoSequence_0&);

    ~_IDL_SEQ_csMandPRecipeInfoSequence_0 ();

    _IDL_SEQ_csMandPRecipeInfoSequence_0& operator= (const _IDL_SEQ_csMandPRecipeInfoSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csMandPRecipeInfo& operator [] (::CORBA::ULong indx);
    const csMandPRecipeInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csMandPRecipeInfo* get_buffer (::CORBA::Boolean orphan=0);
    const csMandPRecipeInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csMandPRecipeInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csMandPRecipeInfo* src, csMandPRecipeInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csMandPRecipeInfo* data); 
  public:

    static csMandPRecipeInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csMandPRecipeInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csMandPRecipeInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csMandPRecipeInfoSequence_0> csMandPRecipeInfoSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csMandPRecipeInfoSequence_0* _IDL_SEQ_csMandPRecipeInfoSequence_0_vPtr;
typedef const _IDL_SEQ_csMandPRecipeInfoSequence_0* _IDL_SEQ_csMandPRecipeInfoSequence_0_cvPtr;

class  _IDL_SEQ_csMandPRecipeInfoSequence_0_var
{
    public:

    _IDL_SEQ_csMandPRecipeInfoSequence_0_var ();

    _IDL_SEQ_csMandPRecipeInfoSequence_0_var (_IDL_SEQ_csMandPRecipeInfoSequence_0 *_p);

    _IDL_SEQ_csMandPRecipeInfoSequence_0_var (const _IDL_SEQ_csMandPRecipeInfoSequence_0_var &_s);

    _IDL_SEQ_csMandPRecipeInfoSequence_0_var &operator= (_IDL_SEQ_csMandPRecipeInfoSequence_0 *_p);

    _IDL_SEQ_csMandPRecipeInfoSequence_0_var &operator= (const _IDL_SEQ_csMandPRecipeInfoSequence_0_var &_s);

    ~_IDL_SEQ_csMandPRecipeInfoSequence_0_var ();

    _IDL_SEQ_csMandPRecipeInfoSequence_0* operator-> ();

    operator _IDL_SEQ_csMandPRecipeInfoSequence_0_cvPtr () const;

    operator _IDL_SEQ_csMandPRecipeInfoSequence_0_vPtr& ();

    operator _IDL_SEQ_csMandPRecipeInfoSequence_0() const;

    const csMandPRecipeInfo& operator[] (::CORBA::ULong index) const;
    csMandPRecipeInfo& operator[] (::CORBA::ULong index);
    const csMandPRecipeInfo& operator[] (int index) const;
    csMandPRecipeInfo& operator[] (int index);
    const _IDL_SEQ_csMandPRecipeInfoSequence_0& in() const;
    _IDL_SEQ_csMandPRecipeInfoSequence_0& inout();
    _IDL_SEQ_csMandPRecipeInfoSequence_0*& out();
    _IDL_SEQ_csMandPRecipeInfoSequence_0* _retn();

    protected:
    _IDL_SEQ_csMandPRecipeInfoSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csMandPRecipeInfoSequence_0 _csMandPRecipeInfoSequence_seq;
    typedef _IDL_SEQ_csMandPRecipeInfoSequence_0 _csMandPRecipeInfoSequence_seq_1;
    typedef _IDL_SEQ_csMandPRecipeInfoSequence_0 csMandPRecipeInfoSequence;
    typedef _IDL_SEQ_csMandPRecipeInfoSequence_0_var csMandPRecipeInfoSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csMandPRecipeInfoSequence;
    class  csEqpRelatedRecipeIDAuditFlagListInqResult_struct_var;
    struct  csEqpRelatedRecipeIDAuditFlagListInqResult_struct {
        typedef csEqpRelatedRecipeIDAuditFlagListInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::String_StructElem multiRecipeCapability;
       ::csMandPRecipeInfoSequence strMandPRecipeInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpRelatedRecipeIDAuditFlagListInqResult_struct();
       csEqpRelatedRecipeIDAuditFlagListInqResult_struct(const csEqpRelatedRecipeIDAuditFlagListInqResult_struct&);
       csEqpRelatedRecipeIDAuditFlagListInqResult_struct& operator=(const csEqpRelatedRecipeIDAuditFlagListInqResult_struct&);
       static CORBA::Info<csEqpRelatedRecipeIDAuditFlagListInqResult_struct> csEqpRelatedRecipeIDAuditFlagListInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpRelatedRecipeIDAuditFlagListInqResult_struct


typedef csEqpRelatedRecipeIDAuditFlagListInqResult_struct* csEqpRelatedRecipeIDAuditFlagListInqResult_struct_vPtr;
typedef const csEqpRelatedRecipeIDAuditFlagListInqResult_struct* csEqpRelatedRecipeIDAuditFlagListInqResult_struct_cvPtr;

class  csEqpRelatedRecipeIDAuditFlagListInqResult_struct_var
{
    public:

    csEqpRelatedRecipeIDAuditFlagListInqResult_struct_var ();

    csEqpRelatedRecipeIDAuditFlagListInqResult_struct_var (csEqpRelatedRecipeIDAuditFlagListInqResult_struct *_p);

    csEqpRelatedRecipeIDAuditFlagListInqResult_struct_var (const csEqpRelatedRecipeIDAuditFlagListInqResult_struct_var &_s);

    csEqpRelatedRecipeIDAuditFlagListInqResult_struct_var &operator= (csEqpRelatedRecipeIDAuditFlagListInqResult_struct *_p);

    csEqpRelatedRecipeIDAuditFlagListInqResult_struct_var &operator= (const csEqpRelatedRecipeIDAuditFlagListInqResult_struct_var &_s);

    ~csEqpRelatedRecipeIDAuditFlagListInqResult_struct_var ();

    csEqpRelatedRecipeIDAuditFlagListInqResult_struct* operator-> ();

    const csEqpRelatedRecipeIDAuditFlagListInqResult_struct& in() const;
    csEqpRelatedRecipeIDAuditFlagListInqResult_struct& inout();
    csEqpRelatedRecipeIDAuditFlagListInqResult_struct*& out();
    csEqpRelatedRecipeIDAuditFlagListInqResult_struct* _retn();

    operator csEqpRelatedRecipeIDAuditFlagListInqResult_struct_cvPtr () const;

    operator csEqpRelatedRecipeIDAuditFlagListInqResult_struct_vPtr& ();

    operator const csEqpRelatedRecipeIDAuditFlagListInqResult_struct& () const;

    operator csEqpRelatedRecipeIDAuditFlagListInqResult_struct& ();

    protected:
    csEqpRelatedRecipeIDAuditFlagListInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpRelatedRecipeIDAuditFlagListInqResult_struct;
    typedef csEqpRelatedRecipeIDAuditFlagListInqResult_struct csEqpRelatedRecipeIDAuditFlagListInqResult;
    typedef csEqpRelatedRecipeIDAuditFlagListInqResult_struct_var csEqpRelatedRecipeIDAuditFlagListInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpRelatedRecipeIDAuditFlagListInqResult;
    class  csCassetteInspectionTimeResetReqResult_struct_var;
    struct  csCassetteInspectionTimeResetReqResult_struct {
        typedef csCassetteInspectionTimeResetReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifier cassetteID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csCassetteInspectionTimeResetReqResult_struct();
       csCassetteInspectionTimeResetReqResult_struct(const csCassetteInspectionTimeResetReqResult_struct&);
       csCassetteInspectionTimeResetReqResult_struct& operator=(const csCassetteInspectionTimeResetReqResult_struct&);
       static CORBA::Info<csCassetteInspectionTimeResetReqResult_struct> csCassetteInspectionTimeResetReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csCassetteInspectionTimeResetReqResult_struct


typedef csCassetteInspectionTimeResetReqResult_struct* csCassetteInspectionTimeResetReqResult_struct_vPtr;
typedef const csCassetteInspectionTimeResetReqResult_struct* csCassetteInspectionTimeResetReqResult_struct_cvPtr;

class  csCassetteInspectionTimeResetReqResult_struct_var
{
    public:

    csCassetteInspectionTimeResetReqResult_struct_var ();

    csCassetteInspectionTimeResetReqResult_struct_var (csCassetteInspectionTimeResetReqResult_struct *_p);

    csCassetteInspectionTimeResetReqResult_struct_var (const csCassetteInspectionTimeResetReqResult_struct_var &_s);

    csCassetteInspectionTimeResetReqResult_struct_var &operator= (csCassetteInspectionTimeResetReqResult_struct *_p);

    csCassetteInspectionTimeResetReqResult_struct_var &operator= (const csCassetteInspectionTimeResetReqResult_struct_var &_s);

    ~csCassetteInspectionTimeResetReqResult_struct_var ();

    csCassetteInspectionTimeResetReqResult_struct* operator-> ();

    const csCassetteInspectionTimeResetReqResult_struct& in() const;
    csCassetteInspectionTimeResetReqResult_struct& inout();
    csCassetteInspectionTimeResetReqResult_struct*& out();
    csCassetteInspectionTimeResetReqResult_struct* _retn();

    operator csCassetteInspectionTimeResetReqResult_struct_cvPtr () const;

    operator csCassetteInspectionTimeResetReqResult_struct_vPtr& ();

    operator const csCassetteInspectionTimeResetReqResult_struct& () const;

    operator csCassetteInspectionTimeResetReqResult_struct& ();

    protected:
    csCassetteInspectionTimeResetReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csCassetteInspectionTimeResetReqResult_struct;
    typedef csCassetteInspectionTimeResetReqResult_struct csCassetteInspectionTimeResetReqResult;
    typedef csCassetteInspectionTimeResetReqResult_struct_var csCassetteInspectionTimeResetReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csCassetteInspectionTimeResetReqResult;
    class  csCassettePMTimeResetReqResult_struct_var;
    struct  csCassettePMTimeResetReqResult_struct {
        typedef csCassettePMTimeResetReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifier cassetteID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csCassettePMTimeResetReqResult_struct();
       csCassettePMTimeResetReqResult_struct(const csCassettePMTimeResetReqResult_struct&);
       csCassettePMTimeResetReqResult_struct& operator=(const csCassettePMTimeResetReqResult_struct&);
       static CORBA::Info<csCassettePMTimeResetReqResult_struct> csCassettePMTimeResetReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csCassettePMTimeResetReqResult_struct


typedef csCassettePMTimeResetReqResult_struct* csCassettePMTimeResetReqResult_struct_vPtr;
typedef const csCassettePMTimeResetReqResult_struct* csCassettePMTimeResetReqResult_struct_cvPtr;

class  csCassettePMTimeResetReqResult_struct_var
{
    public:

    csCassettePMTimeResetReqResult_struct_var ();

    csCassettePMTimeResetReqResult_struct_var (csCassettePMTimeResetReqResult_struct *_p);

    csCassettePMTimeResetReqResult_struct_var (const csCassettePMTimeResetReqResult_struct_var &_s);

    csCassettePMTimeResetReqResult_struct_var &operator= (csCassettePMTimeResetReqResult_struct *_p);

    csCassettePMTimeResetReqResult_struct_var &operator= (const csCassettePMTimeResetReqResult_struct_var &_s);

    ~csCassettePMTimeResetReqResult_struct_var ();

    csCassettePMTimeResetReqResult_struct* operator-> ();

    const csCassettePMTimeResetReqResult_struct& in() const;
    csCassettePMTimeResetReqResult_struct& inout();
    csCassettePMTimeResetReqResult_struct*& out();
    csCassettePMTimeResetReqResult_struct* _retn();

    operator csCassettePMTimeResetReqResult_struct_cvPtr () const;

    operator csCassettePMTimeResetReqResult_struct_vPtr& ();

    operator const csCassettePMTimeResetReqResult_struct& () const;

    operator csCassettePMTimeResetReqResult_struct& ();

    protected:
    csCassettePMTimeResetReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csCassettePMTimeResetReqResult_struct;
    typedef csCassettePMTimeResetReqResult_struct csCassettePMTimeResetReqResult;
    typedef csCassettePMTimeResetReqResult_struct_var csCassettePMTimeResetReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csCassettePMTimeResetReqResult;
    class  csReticleWaferCountResetReqResult_struct_var;
    struct  csReticleWaferCountResetReqResult_struct {
        typedef csReticleWaferCountResetReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifier reticleID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csReticleWaferCountResetReqResult_struct();
       csReticleWaferCountResetReqResult_struct(const csReticleWaferCountResetReqResult_struct&);
       csReticleWaferCountResetReqResult_struct& operator=(const csReticleWaferCountResetReqResult_struct&);
       static CORBA::Info<csReticleWaferCountResetReqResult_struct> csReticleWaferCountResetReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csReticleWaferCountResetReqResult_struct


typedef csReticleWaferCountResetReqResult_struct* csReticleWaferCountResetReqResult_struct_vPtr;
typedef const csReticleWaferCountResetReqResult_struct* csReticleWaferCountResetReqResult_struct_cvPtr;

class  csReticleWaferCountResetReqResult_struct_var
{
    public:

    csReticleWaferCountResetReqResult_struct_var ();

    csReticleWaferCountResetReqResult_struct_var (csReticleWaferCountResetReqResult_struct *_p);

    csReticleWaferCountResetReqResult_struct_var (const csReticleWaferCountResetReqResult_struct_var &_s);

    csReticleWaferCountResetReqResult_struct_var &operator= (csReticleWaferCountResetReqResult_struct *_p);

    csReticleWaferCountResetReqResult_struct_var &operator= (const csReticleWaferCountResetReqResult_struct_var &_s);

    ~csReticleWaferCountResetReqResult_struct_var ();

    csReticleWaferCountResetReqResult_struct* operator-> ();

    const csReticleWaferCountResetReqResult_struct& in() const;
    csReticleWaferCountResetReqResult_struct& inout();
    csReticleWaferCountResetReqResult_struct*& out();
    csReticleWaferCountResetReqResult_struct* _retn();

    operator csReticleWaferCountResetReqResult_struct_cvPtr () const;

    operator csReticleWaferCountResetReqResult_struct_vPtr& ();

    operator const csReticleWaferCountResetReqResult_struct& () const;

    operator csReticleWaferCountResetReqResult_struct& ();

    protected:
    csReticleWaferCountResetReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csReticleWaferCountResetReqResult_struct;
    typedef csReticleWaferCountResetReqResult_struct csReticleWaferCountResetReqResult;
    typedef csReticleWaferCountResetReqResult_struct_var csReticleWaferCountResetReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csReticleWaferCountResetReqResult;
    class  csReticleUsedDurationResetReqResult_struct_var;
    struct  csReticleUsedDurationResetReqResult_struct {
        typedef csReticleUsedDurationResetReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifier reticleID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csReticleUsedDurationResetReqResult_struct();
       csReticleUsedDurationResetReqResult_struct(const csReticleUsedDurationResetReqResult_struct&);
       csReticleUsedDurationResetReqResult_struct& operator=(const csReticleUsedDurationResetReqResult_struct&);
       static CORBA::Info<csReticleUsedDurationResetReqResult_struct> csReticleUsedDurationResetReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csReticleUsedDurationResetReqResult_struct


typedef csReticleUsedDurationResetReqResult_struct* csReticleUsedDurationResetReqResult_struct_vPtr;
typedef const csReticleUsedDurationResetReqResult_struct* csReticleUsedDurationResetReqResult_struct_cvPtr;

class  csReticleUsedDurationResetReqResult_struct_var
{
    public:

    csReticleUsedDurationResetReqResult_struct_var ();

    csReticleUsedDurationResetReqResult_struct_var (csReticleUsedDurationResetReqResult_struct *_p);

    csReticleUsedDurationResetReqResult_struct_var (const csReticleUsedDurationResetReqResult_struct_var &_s);

    csReticleUsedDurationResetReqResult_struct_var &operator= (csReticleUsedDurationResetReqResult_struct *_p);

    csReticleUsedDurationResetReqResult_struct_var &operator= (const csReticleUsedDurationResetReqResult_struct_var &_s);

    ~csReticleUsedDurationResetReqResult_struct_var ();

    csReticleUsedDurationResetReqResult_struct* operator-> ();

    const csReticleUsedDurationResetReqResult_struct& in() const;
    csReticleUsedDurationResetReqResult_struct& inout();
    csReticleUsedDurationResetReqResult_struct*& out();
    csReticleUsedDurationResetReqResult_struct* _retn();

    operator csReticleUsedDurationResetReqResult_struct_cvPtr () const;

    operator csReticleUsedDurationResetReqResult_struct_vPtr& ();

    operator const csReticleUsedDurationResetReqResult_struct& () const;

    operator csReticleUsedDurationResetReqResult_struct& ();

    protected:
    csReticleUsedDurationResetReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csReticleUsedDurationResetReqResult_struct;
    typedef csReticleUsedDurationResetReqResult_struct csReticleUsedDurationResetReqResult;
    typedef csReticleUsedDurationResetReqResult_struct_var csReticleUsedDurationResetReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csReticleUsedDurationResetReqResult;
    typedef pptBaseResult csVendorLotReserveReqResult;
    typedef pptBaseResult_var csVendorLotReserveReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csVendorLotReserveReqResult;
    typedef pptBaseResult csVendorLotReserveCancelReqResult;
    typedef pptBaseResult_var csVendorLotReserveCancelReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csVendorLotReserveCancelReqResult;
    class  csVendorLotReserveData_struct_var;
    struct  csVendorLotReserveData_struct {
        typedef csVendorLotReserveData_struct_var _var_type;
       ::objectIdentifier bankID;
       ::CORBA::String_StructElem lotType;
       ::CORBA::String_StructElem subLotType;
       ::CORBA::String_StructElem sourceProduct;
       ::CORBA::String_StructElem partNo;
       ::pptNewLotAttributes strNewLotAttributes;
       ::CORBA::String_StructElem claimedUserID;
       ::CORBA::String_StructElem claimedTimeStamp;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csVendorLotReserveData_struct();
       csVendorLotReserveData_struct(const csVendorLotReserveData_struct&);
       csVendorLotReserveData_struct& operator=(const csVendorLotReserveData_struct&);
       static CORBA::Info<csVendorLotReserveData_struct> csVendorLotReserveData_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csVendorLotReserveData_struct


typedef csVendorLotReserveData_struct* csVendorLotReserveData_struct_vPtr;
typedef const csVendorLotReserveData_struct* csVendorLotReserveData_struct_cvPtr;

class  csVendorLotReserveData_struct_var
{
    public:

    csVendorLotReserveData_struct_var ();

    csVendorLotReserveData_struct_var (csVendorLotReserveData_struct *_p);

    csVendorLotReserveData_struct_var (const csVendorLotReserveData_struct_var &_s);

    csVendorLotReserveData_struct_var &operator= (csVendorLotReserveData_struct *_p);

    csVendorLotReserveData_struct_var &operator= (const csVendorLotReserveData_struct_var &_s);

    ~csVendorLotReserveData_struct_var ();

    csVendorLotReserveData_struct* operator-> ();

    const csVendorLotReserveData_struct& in() const;
    csVendorLotReserveData_struct& inout();
    csVendorLotReserveData_struct*& out();
    csVendorLotReserveData_struct* _retn();

    operator csVendorLotReserveData_struct_cvPtr () const;

    operator csVendorLotReserveData_struct_vPtr& ();

    operator const csVendorLotReserveData_struct& () const;

    operator csVendorLotReserveData_struct& ();

    protected:
    csVendorLotReserveData_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csVendorLotReserveData_struct;
    typedef csVendorLotReserveData_struct csVendorLotReserveData;
    typedef csVendorLotReserveData_struct_var csVendorLotReserveData_var;
    extern  ::CORBA::TypeCode_ptr _tc_csVendorLotReserveData;
class  _IDL_SEQ_csVendorLotReserveDataSequence_0_var;
class  _IDL_SEQ_csVendorLotReserveDataSequence_0 {
    public:
        typedef _IDL_SEQ_csVendorLotReserveDataSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csVendorLotReserveData *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csVendorLotReserveDataSequence_0 ();
    _IDL_SEQ_csVendorLotReserveDataSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csVendorLotReserveDataSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csVendorLotReserveData* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csVendorLotReserveDataSequence_0 (const _IDL_SEQ_csVendorLotReserveDataSequence_0&);

    ~_IDL_SEQ_csVendorLotReserveDataSequence_0 ();

    _IDL_SEQ_csVendorLotReserveDataSequence_0& operator= (const _IDL_SEQ_csVendorLotReserveDataSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csVendorLotReserveData& operator [] (::CORBA::ULong indx);
    const csVendorLotReserveData& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csVendorLotReserveData* get_buffer (::CORBA::Boolean orphan=0);
    const csVendorLotReserveData* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csVendorLotReserveData* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csVendorLotReserveData* src, csVendorLotReserveData* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csVendorLotReserveData* data); 
  public:

    static csVendorLotReserveData* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csVendorLotReserveData* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csVendorLotReserveData* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csVendorLotReserveDataSequence_0> csVendorLotReserveDataSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csVendorLotReserveDataSequence_0* _IDL_SEQ_csVendorLotReserveDataSequence_0_vPtr;
typedef const _IDL_SEQ_csVendorLotReserveDataSequence_0* _IDL_SEQ_csVendorLotReserveDataSequence_0_cvPtr;

class  _IDL_SEQ_csVendorLotReserveDataSequence_0_var
{
    public:

    _IDL_SEQ_csVendorLotReserveDataSequence_0_var ();

    _IDL_SEQ_csVendorLotReserveDataSequence_0_var (_IDL_SEQ_csVendorLotReserveDataSequence_0 *_p);

    _IDL_SEQ_csVendorLotReserveDataSequence_0_var (const _IDL_SEQ_csVendorLotReserveDataSequence_0_var &_s);

    _IDL_SEQ_csVendorLotReserveDataSequence_0_var &operator= (_IDL_SEQ_csVendorLotReserveDataSequence_0 *_p);

    _IDL_SEQ_csVendorLotReserveDataSequence_0_var &operator= (const _IDL_SEQ_csVendorLotReserveDataSequence_0_var &_s);

    ~_IDL_SEQ_csVendorLotReserveDataSequence_0_var ();

    _IDL_SEQ_csVendorLotReserveDataSequence_0* operator-> ();

    operator _IDL_SEQ_csVendorLotReserveDataSequence_0_cvPtr () const;

    operator _IDL_SEQ_csVendorLotReserveDataSequence_0_vPtr& ();

    operator _IDL_SEQ_csVendorLotReserveDataSequence_0() const;

    const csVendorLotReserveData& operator[] (::CORBA::ULong index) const;
    csVendorLotReserveData& operator[] (::CORBA::ULong index);
    const csVendorLotReserveData& operator[] (int index) const;
    csVendorLotReserveData& operator[] (int index);
    const _IDL_SEQ_csVendorLotReserveDataSequence_0& in() const;
    _IDL_SEQ_csVendorLotReserveDataSequence_0& inout();
    _IDL_SEQ_csVendorLotReserveDataSequence_0*& out();
    _IDL_SEQ_csVendorLotReserveDataSequence_0* _retn();

    protected:
    _IDL_SEQ_csVendorLotReserveDataSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csVendorLotReserveDataSequence_0 _csVendorLotReserveDataSequence_seq;
    typedef _IDL_SEQ_csVendorLotReserveDataSequence_0 _csVendorLotReserveDataSequence_seq_1;
    typedef _IDL_SEQ_csVendorLotReserveDataSequence_0 csVendorLotReserveDataSequence;
    typedef _IDL_SEQ_csVendorLotReserveDataSequence_0_var csVendorLotReserveDataSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csVendorLotReserveDataSequence;
    class  csVendorLotReserveListInqResult_struct_var;
    struct  csVendorLotReserveListInqResult_struct {
        typedef csVendorLotReserveListInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::csVendorLotReserveDataSequence strVendorLotReserveDataSequence;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csVendorLotReserveListInqResult_struct();
       csVendorLotReserveListInqResult_struct(const csVendorLotReserveListInqResult_struct&);
       csVendorLotReserveListInqResult_struct& operator=(const csVendorLotReserveListInqResult_struct&);
       static CORBA::Info<csVendorLotReserveListInqResult_struct> csVendorLotReserveListInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csVendorLotReserveListInqResult_struct


typedef csVendorLotReserveListInqResult_struct* csVendorLotReserveListInqResult_struct_vPtr;
typedef const csVendorLotReserveListInqResult_struct* csVendorLotReserveListInqResult_struct_cvPtr;

class  csVendorLotReserveListInqResult_struct_var
{
    public:

    csVendorLotReserveListInqResult_struct_var ();

    csVendorLotReserveListInqResult_struct_var (csVendorLotReserveListInqResult_struct *_p);

    csVendorLotReserveListInqResult_struct_var (const csVendorLotReserveListInqResult_struct_var &_s);

    csVendorLotReserveListInqResult_struct_var &operator= (csVendorLotReserveListInqResult_struct *_p);

    csVendorLotReserveListInqResult_struct_var &operator= (const csVendorLotReserveListInqResult_struct_var &_s);

    ~csVendorLotReserveListInqResult_struct_var ();

    csVendorLotReserveListInqResult_struct* operator-> ();

    const csVendorLotReserveListInqResult_struct& in() const;
    csVendorLotReserveListInqResult_struct& inout();
    csVendorLotReserveListInqResult_struct*& out();
    csVendorLotReserveListInqResult_struct* _retn();

    operator csVendorLotReserveListInqResult_struct_cvPtr () const;

    operator csVendorLotReserveListInqResult_struct_vPtr& ();

    operator const csVendorLotReserveListInqResult_struct& () const;

    operator csVendorLotReserveListInqResult_struct& ();

    protected:
    csVendorLotReserveListInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csVendorLotReserveListInqResult_struct;
    typedef csVendorLotReserveListInqResult_struct csVendorLotReserveListInqResult;
    typedef csVendorLotReserveListInqResult_struct_var csVendorLotReserveListInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csVendorLotReserveListInqResult;
    class  cspptCassettePmInfo_siInfo_struct_var;
    struct  cspptCassettePmInfo_siInfo_struct {
        typedef cspptCassettePmInfo_siInfo_struct_var _var_type;
       ::CORBA::String_StructElem lastPMTimeStamp;
       ::CORBA::String_StructElem lastInspectionTimeStamp;
       ::CORBA::Long intervalBetweenInspection;
       ::CORBA::Long passageTimeFromLastInspection;
       ::CORBA::Long passageTimeFromLastPM;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       cspptCassettePmInfo_siInfo_struct();
       cspptCassettePmInfo_siInfo_struct(const cspptCassettePmInfo_siInfo_struct&);
       cspptCassettePmInfo_siInfo_struct& operator=(const cspptCassettePmInfo_siInfo_struct&);
       static CORBA::Info<cspptCassettePmInfo_siInfo_struct> cspptCassettePmInfo_siInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct cspptCassettePmInfo_siInfo_struct


typedef cspptCassettePmInfo_siInfo_struct* cspptCassettePmInfo_siInfo_struct_vPtr;
typedef const cspptCassettePmInfo_siInfo_struct* cspptCassettePmInfo_siInfo_struct_cvPtr;

class  cspptCassettePmInfo_siInfo_struct_var
{
    public:

    cspptCassettePmInfo_siInfo_struct_var ();

    cspptCassettePmInfo_siInfo_struct_var (cspptCassettePmInfo_siInfo_struct *_p);

    cspptCassettePmInfo_siInfo_struct_var (const cspptCassettePmInfo_siInfo_struct_var &_s);

    cspptCassettePmInfo_siInfo_struct_var &operator= (cspptCassettePmInfo_siInfo_struct *_p);

    cspptCassettePmInfo_siInfo_struct_var &operator= (const cspptCassettePmInfo_siInfo_struct_var &_s);

    ~cspptCassettePmInfo_siInfo_struct_var ();

    cspptCassettePmInfo_siInfo_struct* operator-> ();

    const cspptCassettePmInfo_siInfo_struct& in() const;
    cspptCassettePmInfo_siInfo_struct& inout();
    cspptCassettePmInfo_siInfo_struct*& out();
    cspptCassettePmInfo_siInfo_struct* _retn();

    operator cspptCassettePmInfo_siInfo_struct_cvPtr () const;

    operator cspptCassettePmInfo_siInfo_struct_vPtr& ();

    operator const cspptCassettePmInfo_siInfo_struct& () const;

    operator cspptCassettePmInfo_siInfo_struct& ();

    protected:
    cspptCassettePmInfo_siInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_cspptCassettePmInfo_siInfo_struct;
    typedef cspptCassettePmInfo_siInfo_struct cspptCassettePmInfo_siInfo;
    typedef cspptCassettePmInfo_siInfo_struct_var cspptCassettePmInfo_siInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_cspptCassettePmInfo_siInfo;
    class  cspptReticlePmInfo_siInfo_struct_var;
    struct  cspptReticlePmInfo_siInfo_struct {
        typedef cspptReticlePmInfo_siInfo_struct_var _var_type;
       ::CORBA::String_StructElem lastRepairTimeStamp;
       ::CORBA::String_StructElem lastInspectionTimeStamp;
       ::CORBA::Long intervalBetweenInspection;
       ::CORBA::Long passageTimeFromLastInspection;
       ::CORBA::Long usedWaferCount;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       cspptReticlePmInfo_siInfo_struct();
       cspptReticlePmInfo_siInfo_struct(const cspptReticlePmInfo_siInfo_struct&);
       cspptReticlePmInfo_siInfo_struct& operator=(const cspptReticlePmInfo_siInfo_struct&);
       static CORBA::Info<cspptReticlePmInfo_siInfo_struct> cspptReticlePmInfo_siInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct cspptReticlePmInfo_siInfo_struct


typedef cspptReticlePmInfo_siInfo_struct* cspptReticlePmInfo_siInfo_struct_vPtr;
typedef const cspptReticlePmInfo_siInfo_struct* cspptReticlePmInfo_siInfo_struct_cvPtr;

class  cspptReticlePmInfo_siInfo_struct_var
{
    public:

    cspptReticlePmInfo_siInfo_struct_var ();

    cspptReticlePmInfo_siInfo_struct_var (cspptReticlePmInfo_siInfo_struct *_p);

    cspptReticlePmInfo_siInfo_struct_var (const cspptReticlePmInfo_siInfo_struct_var &_s);

    cspptReticlePmInfo_siInfo_struct_var &operator= (cspptReticlePmInfo_siInfo_struct *_p);

    cspptReticlePmInfo_siInfo_struct_var &operator= (const cspptReticlePmInfo_siInfo_struct_var &_s);

    ~cspptReticlePmInfo_siInfo_struct_var ();

    cspptReticlePmInfo_siInfo_struct* operator-> ();

    const cspptReticlePmInfo_siInfo_struct& in() const;
    cspptReticlePmInfo_siInfo_struct& inout();
    cspptReticlePmInfo_siInfo_struct*& out();
    cspptReticlePmInfo_siInfo_struct* _retn();

    operator cspptReticlePmInfo_siInfo_struct_cvPtr () const;

    operator cspptReticlePmInfo_siInfo_struct_vPtr& ();

    operator const cspptReticlePmInfo_siInfo_struct& () const;

    operator cspptReticlePmInfo_siInfo_struct& ();

    protected:
    cspptReticlePmInfo_siInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_cspptReticlePmInfo_siInfo_struct;
    typedef cspptReticlePmInfo_siInfo_struct cspptReticlePmInfo_siInfo;
    typedef cspptReticlePmInfo_siInfo_struct_var cspptReticlePmInfo_siInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_cspptReticlePmInfo_siInfo;
    class  csStartDurablesReservationReqInParam_siInfo_struct_var;
    struct  csStartDurablesReservationReqInParam_siInfo_struct {
        typedef csStartDurablesReservationReqInParam_siInfo_struct_var _var_type;
       ::objectIdentifier durableControlJobID;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csStartDurablesReservationReqInParam_siInfo_struct();
       csStartDurablesReservationReqInParam_siInfo_struct(const csStartDurablesReservationReqInParam_siInfo_struct&);
       csStartDurablesReservationReqInParam_siInfo_struct& operator=(const csStartDurablesReservationReqInParam_siInfo_struct&);
       static CORBA::Info<csStartDurablesReservationReqInParam_siInfo_struct> csStartDurablesReservationReqInParam_siInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csStartDurablesReservationReqInParam_siInfo_struct


typedef csStartDurablesReservationReqInParam_siInfo_struct* csStartDurablesReservationReqInParam_siInfo_struct_vPtr;
typedef const csStartDurablesReservationReqInParam_siInfo_struct* csStartDurablesReservationReqInParam_siInfo_struct_cvPtr;

class  csStartDurablesReservationReqInParam_siInfo_struct_var
{
    public:

    csStartDurablesReservationReqInParam_siInfo_struct_var ();

    csStartDurablesReservationReqInParam_siInfo_struct_var (csStartDurablesReservationReqInParam_siInfo_struct *_p);

    csStartDurablesReservationReqInParam_siInfo_struct_var (const csStartDurablesReservationReqInParam_siInfo_struct_var &_s);

    csStartDurablesReservationReqInParam_siInfo_struct_var &operator= (csStartDurablesReservationReqInParam_siInfo_struct *_p);

    csStartDurablesReservationReqInParam_siInfo_struct_var &operator= (const csStartDurablesReservationReqInParam_siInfo_struct_var &_s);

    ~csStartDurablesReservationReqInParam_siInfo_struct_var ();

    csStartDurablesReservationReqInParam_siInfo_struct* operator-> ();

    const csStartDurablesReservationReqInParam_siInfo_struct& in() const;
    csStartDurablesReservationReqInParam_siInfo_struct& inout();
    csStartDurablesReservationReqInParam_siInfo_struct*& out();
    csStartDurablesReservationReqInParam_siInfo_struct* _retn();

    operator csStartDurablesReservationReqInParam_siInfo_struct_cvPtr () const;

    operator csStartDurablesReservationReqInParam_siInfo_struct_vPtr& ();

    operator const csStartDurablesReservationReqInParam_siInfo_struct& () const;

    operator csStartDurablesReservationReqInParam_siInfo_struct& ();

    protected:
    csStartDurablesReservationReqInParam_siInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csStartDurablesReservationReqInParam_siInfo_struct;
    typedef csStartDurablesReservationReqInParam_siInfo_struct csStartDurablesReservationReqInParam_siInfo;
    typedef csStartDurablesReservationReqInParam_siInfo_struct_var csStartDurablesReservationReqInParam_siInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csStartDurablesReservationReqInParam_siInfo;
    class  csLotInfo_siInfo_struct_var;
    struct  csLotInfo_siInfo_struct {
        typedef csLotInfo_siInfo_struct_var _var_type;
       ::CORBA::String_StructElem contamiFlag;
       ::CORBA::String_StructElem contamiInLevel;
       ::CORBA::String_StructElem prFlag;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csLotInfo_siInfo_struct();
       csLotInfo_siInfo_struct(const csLotInfo_siInfo_struct&);
       csLotInfo_siInfo_struct& operator=(const csLotInfo_siInfo_struct&);
       static CORBA::Info<csLotInfo_siInfo_struct> csLotInfo_siInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csLotInfo_siInfo_struct


typedef csLotInfo_siInfo_struct* csLotInfo_siInfo_struct_vPtr;
typedef const csLotInfo_siInfo_struct* csLotInfo_siInfo_struct_cvPtr;

class  csLotInfo_siInfo_struct_var
{
    public:

    csLotInfo_siInfo_struct_var ();

    csLotInfo_siInfo_struct_var (csLotInfo_siInfo_struct *_p);

    csLotInfo_siInfo_struct_var (const csLotInfo_siInfo_struct_var &_s);

    csLotInfo_siInfo_struct_var &operator= (csLotInfo_siInfo_struct *_p);

    csLotInfo_siInfo_struct_var &operator= (const csLotInfo_siInfo_struct_var &_s);

    ~csLotInfo_siInfo_struct_var ();

    csLotInfo_siInfo_struct* operator-> ();

    const csLotInfo_siInfo_struct& in() const;
    csLotInfo_siInfo_struct& inout();
    csLotInfo_siInfo_struct*& out();
    csLotInfo_siInfo_struct* _retn();

    operator csLotInfo_siInfo_struct_cvPtr () const;

    operator csLotInfo_siInfo_struct_vPtr& ();

    operator const csLotInfo_siInfo_struct& () const;

    operator csLotInfo_siInfo_struct& ();

    protected:
    csLotInfo_siInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csLotInfo_siInfo_struct;
    typedef csLotInfo_siInfo_struct csLotInfo_siInfo;
    typedef csLotInfo_siInfo_struct_var csLotInfo_siInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csLotInfo_siInfo;
    class  csCassetteStatusInqResult_siInfo_struct_var;
    struct  csCassetteStatusInqResult_siInfo_struct {
        typedef csCassetteStatusInqResult_siInfo_struct_var _var_type;
       ::CORBA::String_StructElem usageType;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csCassetteStatusInqResult_siInfo_struct();
       csCassetteStatusInqResult_siInfo_struct(const csCassetteStatusInqResult_siInfo_struct&);
       csCassetteStatusInqResult_siInfo_struct& operator=(const csCassetteStatusInqResult_siInfo_struct&);
       static CORBA::Info<csCassetteStatusInqResult_siInfo_struct> csCassetteStatusInqResult_siInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csCassetteStatusInqResult_siInfo_struct


typedef csCassetteStatusInqResult_siInfo_struct* csCassetteStatusInqResult_siInfo_struct_vPtr;
typedef const csCassetteStatusInqResult_siInfo_struct* csCassetteStatusInqResult_siInfo_struct_cvPtr;

class  csCassetteStatusInqResult_siInfo_struct_var
{
    public:

    csCassetteStatusInqResult_siInfo_struct_var ();

    csCassetteStatusInqResult_siInfo_struct_var (csCassetteStatusInqResult_siInfo_struct *_p);

    csCassetteStatusInqResult_siInfo_struct_var (const csCassetteStatusInqResult_siInfo_struct_var &_s);

    csCassetteStatusInqResult_siInfo_struct_var &operator= (csCassetteStatusInqResult_siInfo_struct *_p);

    csCassetteStatusInqResult_siInfo_struct_var &operator= (const csCassetteStatusInqResult_siInfo_struct_var &_s);

    ~csCassetteStatusInqResult_siInfo_struct_var ();

    csCassetteStatusInqResult_siInfo_struct* operator-> ();

    const csCassetteStatusInqResult_siInfo_struct& in() const;
    csCassetteStatusInqResult_siInfo_struct& inout();
    csCassetteStatusInqResult_siInfo_struct*& out();
    csCassetteStatusInqResult_siInfo_struct* _retn();

    operator csCassetteStatusInqResult_siInfo_struct_cvPtr () const;

    operator csCassetteStatusInqResult_siInfo_struct_vPtr& ();

    operator const csCassetteStatusInqResult_siInfo_struct& () const;

    operator csCassetteStatusInqResult_siInfo_struct& ();

    protected:
    csCassetteStatusInqResult_siInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csCassetteStatusInqResult_siInfo_struct;
    typedef csCassetteStatusInqResult_siInfo_struct csCassetteStatusInqResult_siInfo;
    typedef csCassetteStatusInqResult_siInfo_struct_var csCassetteStatusInqResult_siInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csCassetteStatusInqResult_siInfo;
    typedef csCassetteStatusInqResult_siInfo csFoundCassette_siInfo;
    typedef csCassetteStatusInqResult_siInfo_var csFoundCassette_siInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csFoundCassette_siInfo;
    class  csLotContaminationInfo_struct_var;
    struct  csLotContaminationInfo_struct {
        typedef csLotContaminationInfo_struct_var _var_type;
       ::objectIdentifier lotID;
       ::CORBA::Boolean operationStartFlag;
       ::CORBA::String_StructElem lotContamiFlag;
       ::CORBA::String_StructElem lotPRFlag;
       ::CORBA::String_StructElem opeContamiInLevel;
       ::CORBA::String_StructElem opeContamiOutLevel;
       ::CORBA::String_StructElem opePRControl;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csLotContaminationInfo_struct();
       csLotContaminationInfo_struct(const csLotContaminationInfo_struct&);
       csLotContaminationInfo_struct& operator=(const csLotContaminationInfo_struct&);
       static CORBA::Info<csLotContaminationInfo_struct> csLotContaminationInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csLotContaminationInfo_struct


typedef csLotContaminationInfo_struct* csLotContaminationInfo_struct_vPtr;
typedef const csLotContaminationInfo_struct* csLotContaminationInfo_struct_cvPtr;

class  csLotContaminationInfo_struct_var
{
    public:

    csLotContaminationInfo_struct_var ();

    csLotContaminationInfo_struct_var (csLotContaminationInfo_struct *_p);

    csLotContaminationInfo_struct_var (const csLotContaminationInfo_struct_var &_s);

    csLotContaminationInfo_struct_var &operator= (csLotContaminationInfo_struct *_p);

    csLotContaminationInfo_struct_var &operator= (const csLotContaminationInfo_struct_var &_s);

    ~csLotContaminationInfo_struct_var ();

    csLotContaminationInfo_struct* operator-> ();

    const csLotContaminationInfo_struct& in() const;
    csLotContaminationInfo_struct& inout();
    csLotContaminationInfo_struct*& out();
    csLotContaminationInfo_struct* _retn();

    operator csLotContaminationInfo_struct_cvPtr () const;

    operator csLotContaminationInfo_struct_vPtr& ();

    operator const csLotContaminationInfo_struct& () const;

    operator csLotContaminationInfo_struct& ();

    protected:
    csLotContaminationInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csLotContaminationInfo_struct;
    typedef csLotContaminationInfo_struct csLotContaminationInfo;
    typedef csLotContaminationInfo_struct_var csLotContaminationInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csLotContaminationInfo;
class  _IDL_SEQ_csLotContaminationInfoSequence_0_var;
class  _IDL_SEQ_csLotContaminationInfoSequence_0 {
    public:
        typedef _IDL_SEQ_csLotContaminationInfoSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csLotContaminationInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csLotContaminationInfoSequence_0 ();
    _IDL_SEQ_csLotContaminationInfoSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csLotContaminationInfoSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csLotContaminationInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csLotContaminationInfoSequence_0 (const _IDL_SEQ_csLotContaminationInfoSequence_0&);

    ~_IDL_SEQ_csLotContaminationInfoSequence_0 ();

    _IDL_SEQ_csLotContaminationInfoSequence_0& operator= (const _IDL_SEQ_csLotContaminationInfoSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csLotContaminationInfo& operator [] (::CORBA::ULong indx);
    const csLotContaminationInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csLotContaminationInfo* get_buffer (::CORBA::Boolean orphan=0);
    const csLotContaminationInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csLotContaminationInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csLotContaminationInfo* src, csLotContaminationInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csLotContaminationInfo* data); 
  public:

    static csLotContaminationInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csLotContaminationInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csLotContaminationInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csLotContaminationInfoSequence_0> csLotContaminationInfoSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csLotContaminationInfoSequence_0* _IDL_SEQ_csLotContaminationInfoSequence_0_vPtr;
typedef const _IDL_SEQ_csLotContaminationInfoSequence_0* _IDL_SEQ_csLotContaminationInfoSequence_0_cvPtr;

class  _IDL_SEQ_csLotContaminationInfoSequence_0_var
{
    public:

    _IDL_SEQ_csLotContaminationInfoSequence_0_var ();

    _IDL_SEQ_csLotContaminationInfoSequence_0_var (_IDL_SEQ_csLotContaminationInfoSequence_0 *_p);

    _IDL_SEQ_csLotContaminationInfoSequence_0_var (const _IDL_SEQ_csLotContaminationInfoSequence_0_var &_s);

    _IDL_SEQ_csLotContaminationInfoSequence_0_var &operator= (_IDL_SEQ_csLotContaminationInfoSequence_0 *_p);

    _IDL_SEQ_csLotContaminationInfoSequence_0_var &operator= (const _IDL_SEQ_csLotContaminationInfoSequence_0_var &_s);

    ~_IDL_SEQ_csLotContaminationInfoSequence_0_var ();

    _IDL_SEQ_csLotContaminationInfoSequence_0* operator-> ();

    operator _IDL_SEQ_csLotContaminationInfoSequence_0_cvPtr () const;

    operator _IDL_SEQ_csLotContaminationInfoSequence_0_vPtr& ();

    operator _IDL_SEQ_csLotContaminationInfoSequence_0() const;

    const csLotContaminationInfo& operator[] (::CORBA::ULong index) const;
    csLotContaminationInfo& operator[] (::CORBA::ULong index);
    const csLotContaminationInfo& operator[] (int index) const;
    csLotContaminationInfo& operator[] (int index);
    const _IDL_SEQ_csLotContaminationInfoSequence_0& in() const;
    _IDL_SEQ_csLotContaminationInfoSequence_0& inout();
    _IDL_SEQ_csLotContaminationInfoSequence_0*& out();
    _IDL_SEQ_csLotContaminationInfoSequence_0* _retn();

    protected:
    _IDL_SEQ_csLotContaminationInfoSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csLotContaminationInfoSequence_0 _csLotContaminationInfoSequence_seq;
    typedef _IDL_SEQ_csLotContaminationInfoSequence_0 _csLotContaminationInfoSequence_seq_1;
    typedef _IDL_SEQ_csLotContaminationInfoSequence_0 csLotContaminationInfoSequence;
    typedef _IDL_SEQ_csLotContaminationInfoSequence_0_var csLotContaminationInfoSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csLotContaminationInfoSequence;
    class  csCassetteDeliveryReqResult_siInfo_struct_var;
    struct  csCassetteDeliveryReqResult_siInfo_struct {
        typedef csCassetteDeliveryReqResult_siInfo_struct_var _var_type;
       ::objectIdentifierSequence holdLotIDs;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csCassetteDeliveryReqResult_siInfo_struct();
       csCassetteDeliveryReqResult_siInfo_struct(const csCassetteDeliveryReqResult_siInfo_struct&);
       csCassetteDeliveryReqResult_siInfo_struct& operator=(const csCassetteDeliveryReqResult_siInfo_struct&);
       static CORBA::Info<csCassetteDeliveryReqResult_siInfo_struct> csCassetteDeliveryReqResult_siInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csCassetteDeliveryReqResult_siInfo_struct


typedef csCassetteDeliveryReqResult_siInfo_struct* csCassetteDeliveryReqResult_siInfo_struct_vPtr;
typedef const csCassetteDeliveryReqResult_siInfo_struct* csCassetteDeliveryReqResult_siInfo_struct_cvPtr;

class  csCassetteDeliveryReqResult_siInfo_struct_var
{
    public:

    csCassetteDeliveryReqResult_siInfo_struct_var ();

    csCassetteDeliveryReqResult_siInfo_struct_var (csCassetteDeliveryReqResult_siInfo_struct *_p);

    csCassetteDeliveryReqResult_siInfo_struct_var (const csCassetteDeliveryReqResult_siInfo_struct_var &_s);

    csCassetteDeliveryReqResult_siInfo_struct_var &operator= (csCassetteDeliveryReqResult_siInfo_struct *_p);

    csCassetteDeliveryReqResult_siInfo_struct_var &operator= (const csCassetteDeliveryReqResult_siInfo_struct_var &_s);

    ~csCassetteDeliveryReqResult_siInfo_struct_var ();

    csCassetteDeliveryReqResult_siInfo_struct* operator-> ();

    const csCassetteDeliveryReqResult_siInfo_struct& in() const;
    csCassetteDeliveryReqResult_siInfo_struct& inout();
    csCassetteDeliveryReqResult_siInfo_struct*& out();
    csCassetteDeliveryReqResult_siInfo_struct* _retn();

    operator csCassetteDeliveryReqResult_siInfo_struct_cvPtr () const;

    operator csCassetteDeliveryReqResult_siInfo_struct_vPtr& ();

    operator const csCassetteDeliveryReqResult_siInfo_struct& () const;

    operator csCassetteDeliveryReqResult_siInfo_struct& ();

    protected:
    csCassetteDeliveryReqResult_siInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csCassetteDeliveryReqResult_siInfo_struct;
    typedef csCassetteDeliveryReqResult_siInfo_struct csCassetteDeliveryReqResult_siInfo;
    typedef csCassetteDeliveryReqResult_siInfo_struct_var csCassetteDeliveryReqResult_siInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csCassetteDeliveryReqResult_siInfo;
    typedef csCassetteDeliveryReqResult_siInfo csCassetteDeliveryForInternalBufferReqResult_siInfo;
    typedef csCassetteDeliveryReqResult_siInfo_var csCassetteDeliveryForInternalBufferReqResult_siInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csCassetteDeliveryForInternalBufferReqResult_siInfo;
    typedef csCassetteDeliveryReqResult_siInfo csSLMCassetteDeliveryReqResult_siInfo;
    typedef csCassetteDeliveryReqResult_siInfo_var csSLMCassetteDeliveryReqResult_siInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csSLMCassetteDeliveryReqResult_siInfo;
    class  csStartLotsReservationReqResult_siInfo_struct_var;
    struct  csStartLotsReservationReqResult_siInfo_struct {
        typedef csStartLotsReservationReqResult_siInfo_struct_var _var_type;
       ::objectIdentifierSequence holdLotIDs;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csStartLotsReservationReqResult_siInfo_struct();
       csStartLotsReservationReqResult_siInfo_struct(const csStartLotsReservationReqResult_siInfo_struct&);
       csStartLotsReservationReqResult_siInfo_struct& operator=(const csStartLotsReservationReqResult_siInfo_struct&);
       static CORBA::Info<csStartLotsReservationReqResult_siInfo_struct> csStartLotsReservationReqResult_siInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csStartLotsReservationReqResult_siInfo_struct


typedef csStartLotsReservationReqResult_siInfo_struct* csStartLotsReservationReqResult_siInfo_struct_vPtr;
typedef const csStartLotsReservationReqResult_siInfo_struct* csStartLotsReservationReqResult_siInfo_struct_cvPtr;

class  csStartLotsReservationReqResult_siInfo_struct_var
{
    public:

    csStartLotsReservationReqResult_siInfo_struct_var ();

    csStartLotsReservationReqResult_siInfo_struct_var (csStartLotsReservationReqResult_siInfo_struct *_p);

    csStartLotsReservationReqResult_siInfo_struct_var (const csStartLotsReservationReqResult_siInfo_struct_var &_s);

    csStartLotsReservationReqResult_siInfo_struct_var &operator= (csStartLotsReservationReqResult_siInfo_struct *_p);

    csStartLotsReservationReqResult_siInfo_struct_var &operator= (const csStartLotsReservationReqResult_siInfo_struct_var &_s);

    ~csStartLotsReservationReqResult_siInfo_struct_var ();

    csStartLotsReservationReqResult_siInfo_struct* operator-> ();

    const csStartLotsReservationReqResult_siInfo_struct& in() const;
    csStartLotsReservationReqResult_siInfo_struct& inout();
    csStartLotsReservationReqResult_siInfo_struct*& out();
    csStartLotsReservationReqResult_siInfo_struct* _retn();

    operator csStartLotsReservationReqResult_siInfo_struct_cvPtr () const;

    operator csStartLotsReservationReqResult_siInfo_struct_vPtr& ();

    operator const csStartLotsReservationReqResult_siInfo_struct& () const;

    operator csStartLotsReservationReqResult_siInfo_struct& ();

    protected:
    csStartLotsReservationReqResult_siInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csStartLotsReservationReqResult_siInfo_struct;
    typedef csStartLotsReservationReqResult_siInfo_struct csStartLotsReservationReqResult_siInfo;
    typedef csStartLotsReservationReqResult_siInfo_struct_var csStartLotsReservationReqResult_siInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csStartLotsReservationReqResult_siInfo;
    typedef csStartLotsReservationReqResult_siInfo csStartLotsReservationForInternalBufferReqResult_siInfo;
    typedef csStartLotsReservationReqResult_siInfo_var csStartLotsReservationForInternalBufferReqResult_siInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csStartLotsReservationForInternalBufferReqResult_siInfo;
    typedef csStartLotsReservationReqResult_siInfo csSLMStartLotsReservationReqResult_siInfo;
    typedef csStartLotsReservationReqResult_siInfo_var csSLMStartLotsReservationReqResult_siInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csSLMStartLotsReservationReqResult_siInfo;
    class  csCarrierUsageTypeChangeReqInParm_struct_var;
    struct  csCarrierUsageTypeChangeReqInParm_struct {
        typedef csCarrierUsageTypeChangeReqInParm_struct_var _var_type;
       ::objectIdentifierSequence carrierIDs;
       ::CORBA::String_StructElem usageType;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csCarrierUsageTypeChangeReqInParm_struct();
       csCarrierUsageTypeChangeReqInParm_struct(const csCarrierUsageTypeChangeReqInParm_struct&);
       csCarrierUsageTypeChangeReqInParm_struct& operator=(const csCarrierUsageTypeChangeReqInParm_struct&);
       static CORBA::Info<csCarrierUsageTypeChangeReqInParm_struct> csCarrierUsageTypeChangeReqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csCarrierUsageTypeChangeReqInParm_struct


typedef csCarrierUsageTypeChangeReqInParm_struct* csCarrierUsageTypeChangeReqInParm_struct_vPtr;
typedef const csCarrierUsageTypeChangeReqInParm_struct* csCarrierUsageTypeChangeReqInParm_struct_cvPtr;

class  csCarrierUsageTypeChangeReqInParm_struct_var
{
    public:

    csCarrierUsageTypeChangeReqInParm_struct_var ();

    csCarrierUsageTypeChangeReqInParm_struct_var (csCarrierUsageTypeChangeReqInParm_struct *_p);

    csCarrierUsageTypeChangeReqInParm_struct_var (const csCarrierUsageTypeChangeReqInParm_struct_var &_s);

    csCarrierUsageTypeChangeReqInParm_struct_var &operator= (csCarrierUsageTypeChangeReqInParm_struct *_p);

    csCarrierUsageTypeChangeReqInParm_struct_var &operator= (const csCarrierUsageTypeChangeReqInParm_struct_var &_s);

    ~csCarrierUsageTypeChangeReqInParm_struct_var ();

    csCarrierUsageTypeChangeReqInParm_struct* operator-> ();

    const csCarrierUsageTypeChangeReqInParm_struct& in() const;
    csCarrierUsageTypeChangeReqInParm_struct& inout();
    csCarrierUsageTypeChangeReqInParm_struct*& out();
    csCarrierUsageTypeChangeReqInParm_struct* _retn();

    operator csCarrierUsageTypeChangeReqInParm_struct_cvPtr () const;

    operator csCarrierUsageTypeChangeReqInParm_struct_vPtr& ();

    operator const csCarrierUsageTypeChangeReqInParm_struct& () const;

    operator csCarrierUsageTypeChangeReqInParm_struct& ();

    protected:
    csCarrierUsageTypeChangeReqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csCarrierUsageTypeChangeReqInParm_struct;
    typedef csCarrierUsageTypeChangeReqInParm_struct csCarrierUsageTypeChangeReqInParm;
    typedef csCarrierUsageTypeChangeReqInParm_struct_var csCarrierUsageTypeChangeReqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csCarrierUsageTypeChangeReqInParm;
    typedef pptBaseResult csCarrierUsageTypeChangeReqResult;
    typedef pptBaseResult_var csCarrierUsageTypeChangeReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csCarrierUsageTypeChangeReqResult;
    class  csSkill_struct_var;
    struct  csSkill_struct {
        typedef csSkill_struct_var _var_type;
       ::CORBA::String_StructElem skillID;
       ::CORBA::String_StructElem skillDesc;
       ::CORBA::String_StructElem certifiedDate;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csSkill_struct();
       csSkill_struct(const csSkill_struct&);
       csSkill_struct& operator=(const csSkill_struct&);
       static CORBA::Info<csSkill_struct> csSkill_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csSkill_struct


typedef csSkill_struct* csSkill_struct_vPtr;
typedef const csSkill_struct* csSkill_struct_cvPtr;

class  csSkill_struct_var
{
    public:

    csSkill_struct_var ();

    csSkill_struct_var (csSkill_struct *_p);

    csSkill_struct_var (const csSkill_struct_var &_s);

    csSkill_struct_var &operator= (csSkill_struct *_p);

    csSkill_struct_var &operator= (const csSkill_struct_var &_s);

    ~csSkill_struct_var ();

    csSkill_struct* operator-> ();

    const csSkill_struct& in() const;
    csSkill_struct& inout();
    csSkill_struct*& out();
    csSkill_struct* _retn();

    operator csSkill_struct_cvPtr () const;

    operator csSkill_struct_vPtr& ();

    operator const csSkill_struct& () const;

    operator csSkill_struct& ();

    protected:
    csSkill_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csSkill_struct;
    typedef csSkill_struct csSkill;
    typedef csSkill_struct_var csSkill_var;
    extern  ::CORBA::TypeCode_ptr _tc_csSkill;
class  _IDL_SEQ_csSkillSequence_0_var;
class  _IDL_SEQ_csSkillSequence_0 {
    public:
        typedef _IDL_SEQ_csSkillSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csSkill *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csSkillSequence_0 ();
    _IDL_SEQ_csSkillSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csSkillSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csSkill* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csSkillSequence_0 (const _IDL_SEQ_csSkillSequence_0&);

    ~_IDL_SEQ_csSkillSequence_0 ();

    _IDL_SEQ_csSkillSequence_0& operator= (const _IDL_SEQ_csSkillSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csSkill& operator [] (::CORBA::ULong indx);
    const csSkill& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csSkill* get_buffer (::CORBA::Boolean orphan=0);
    const csSkill* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csSkill* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csSkill* src, csSkill* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csSkill* data); 
  public:

    static csSkill* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csSkill* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csSkill* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csSkillSequence_0> csSkillSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csSkillSequence_0* _IDL_SEQ_csSkillSequence_0_vPtr;
typedef const _IDL_SEQ_csSkillSequence_0* _IDL_SEQ_csSkillSequence_0_cvPtr;

class  _IDL_SEQ_csSkillSequence_0_var
{
    public:

    _IDL_SEQ_csSkillSequence_0_var ();

    _IDL_SEQ_csSkillSequence_0_var (_IDL_SEQ_csSkillSequence_0 *_p);

    _IDL_SEQ_csSkillSequence_0_var (const _IDL_SEQ_csSkillSequence_0_var &_s);

    _IDL_SEQ_csSkillSequence_0_var &operator= (_IDL_SEQ_csSkillSequence_0 *_p);

    _IDL_SEQ_csSkillSequence_0_var &operator= (const _IDL_SEQ_csSkillSequence_0_var &_s);

    ~_IDL_SEQ_csSkillSequence_0_var ();

    _IDL_SEQ_csSkillSequence_0* operator-> ();

    operator _IDL_SEQ_csSkillSequence_0_cvPtr () const;

    operator _IDL_SEQ_csSkillSequence_0_vPtr& ();

    operator _IDL_SEQ_csSkillSequence_0() const;

    const csSkill& operator[] (::CORBA::ULong index) const;
    csSkill& operator[] (::CORBA::ULong index);
    const csSkill& operator[] (int index) const;
    csSkill& operator[] (int index);
    const _IDL_SEQ_csSkillSequence_0& in() const;
    _IDL_SEQ_csSkillSequence_0& inout();
    _IDL_SEQ_csSkillSequence_0*& out();
    _IDL_SEQ_csSkillSequence_0* _retn();

    protected:
    _IDL_SEQ_csSkillSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csSkillSequence_0 _csSkillSequence_seq;
    typedef _IDL_SEQ_csSkillSequence_0 _csSkillSequence_seq_1;
    typedef _IDL_SEQ_csSkillSequence_0 csSkillSequence;
    typedef _IDL_SEQ_csSkillSequence_0_var csSkillSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csSkillSequence;
    class  csUserSkillInfo_struct_var;
    struct  csUserSkillInfo_struct {
        typedef csUserSkillInfo_struct_var _var_type;
       ::objectIdentifier userID;
       ::csSkillSequence strSkillInfo;
       ::CORBA::String_StructElem requiredCertication;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csUserSkillInfo_struct();
       csUserSkillInfo_struct(const csUserSkillInfo_struct&);
       csUserSkillInfo_struct& operator=(const csUserSkillInfo_struct&);
       static CORBA::Info<csUserSkillInfo_struct> csUserSkillInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csUserSkillInfo_struct


typedef csUserSkillInfo_struct* csUserSkillInfo_struct_vPtr;
typedef const csUserSkillInfo_struct* csUserSkillInfo_struct_cvPtr;

class  csUserSkillInfo_struct_var
{
    public:

    csUserSkillInfo_struct_var ();

    csUserSkillInfo_struct_var (csUserSkillInfo_struct *_p);

    csUserSkillInfo_struct_var (const csUserSkillInfo_struct_var &_s);

    csUserSkillInfo_struct_var &operator= (csUserSkillInfo_struct *_p);

    csUserSkillInfo_struct_var &operator= (const csUserSkillInfo_struct_var &_s);

    ~csUserSkillInfo_struct_var ();

    csUserSkillInfo_struct* operator-> ();

    const csUserSkillInfo_struct& in() const;
    csUserSkillInfo_struct& inout();
    csUserSkillInfo_struct*& out();
    csUserSkillInfo_struct* _retn();

    operator csUserSkillInfo_struct_cvPtr () const;

    operator csUserSkillInfo_struct_vPtr& ();

    operator const csUserSkillInfo_struct& () const;

    operator csUserSkillInfo_struct& ();

    protected:
    csUserSkillInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csUserSkillInfo_struct;
    typedef csUserSkillInfo_struct csUserSkillInfo;
    typedef csUserSkillInfo_struct_var csUserSkillInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csUserSkillInfo;
class  _IDL_SEQ_csUserSkillInfoSequence_0_var;
class  _IDL_SEQ_csUserSkillInfoSequence_0 {
    public:
        typedef _IDL_SEQ_csUserSkillInfoSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csUserSkillInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csUserSkillInfoSequence_0 ();
    _IDL_SEQ_csUserSkillInfoSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csUserSkillInfoSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csUserSkillInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csUserSkillInfoSequence_0 (const _IDL_SEQ_csUserSkillInfoSequence_0&);

    ~_IDL_SEQ_csUserSkillInfoSequence_0 ();

    _IDL_SEQ_csUserSkillInfoSequence_0& operator= (const _IDL_SEQ_csUserSkillInfoSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csUserSkillInfo& operator [] (::CORBA::ULong indx);
    const csUserSkillInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csUserSkillInfo* get_buffer (::CORBA::Boolean orphan=0);
    const csUserSkillInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csUserSkillInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csUserSkillInfo* src, csUserSkillInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csUserSkillInfo* data); 
  public:

    static csUserSkillInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csUserSkillInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csUserSkillInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csUserSkillInfoSequence_0> csUserSkillInfoSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csUserSkillInfoSequence_0* _IDL_SEQ_csUserSkillInfoSequence_0_vPtr;
typedef const _IDL_SEQ_csUserSkillInfoSequence_0* _IDL_SEQ_csUserSkillInfoSequence_0_cvPtr;

class  _IDL_SEQ_csUserSkillInfoSequence_0_var
{
    public:

    _IDL_SEQ_csUserSkillInfoSequence_0_var ();

    _IDL_SEQ_csUserSkillInfoSequence_0_var (_IDL_SEQ_csUserSkillInfoSequence_0 *_p);

    _IDL_SEQ_csUserSkillInfoSequence_0_var (const _IDL_SEQ_csUserSkillInfoSequence_0_var &_s);

    _IDL_SEQ_csUserSkillInfoSequence_0_var &operator= (_IDL_SEQ_csUserSkillInfoSequence_0 *_p);

    _IDL_SEQ_csUserSkillInfoSequence_0_var &operator= (const _IDL_SEQ_csUserSkillInfoSequence_0_var &_s);

    ~_IDL_SEQ_csUserSkillInfoSequence_0_var ();

    _IDL_SEQ_csUserSkillInfoSequence_0* operator-> ();

    operator _IDL_SEQ_csUserSkillInfoSequence_0_cvPtr () const;

    operator _IDL_SEQ_csUserSkillInfoSequence_0_vPtr& ();

    operator _IDL_SEQ_csUserSkillInfoSequence_0() const;

    const csUserSkillInfo& operator[] (::CORBA::ULong index) const;
    csUserSkillInfo& operator[] (::CORBA::ULong index);
    const csUserSkillInfo& operator[] (int index) const;
    csUserSkillInfo& operator[] (int index);
    const _IDL_SEQ_csUserSkillInfoSequence_0& in() const;
    _IDL_SEQ_csUserSkillInfoSequence_0& inout();
    _IDL_SEQ_csUserSkillInfoSequence_0*& out();
    _IDL_SEQ_csUserSkillInfoSequence_0* _retn();

    protected:
    _IDL_SEQ_csUserSkillInfoSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csUserSkillInfoSequence_0 _csUserSkillInfoSequence_seq;
    typedef _IDL_SEQ_csUserSkillInfoSequence_0 _csUserSkillInfoSequence_seq_1;
    typedef _IDL_SEQ_csUserSkillInfoSequence_0 csUserSkillInfoSequence;
    typedef _IDL_SEQ_csUserSkillInfoSequence_0_var csUserSkillInfoSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csUserSkillInfoSequence;
    class  csEqpTypeRequiredSkill_struct_var;
    struct  csEqpTypeRequiredSkill_struct {
        typedef csEqpTypeRequiredSkill_struct_var _var_type;
       ::CORBA::String_StructElem eqpType;
       ::CORBA::String_StructElem eqpTypeDesc;
       ::stringSequence strRequiredSkill;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpTypeRequiredSkill_struct();
       csEqpTypeRequiredSkill_struct(const csEqpTypeRequiredSkill_struct&);
       csEqpTypeRequiredSkill_struct& operator=(const csEqpTypeRequiredSkill_struct&);
       static CORBA::Info<csEqpTypeRequiredSkill_struct> csEqpTypeRequiredSkill_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpTypeRequiredSkill_struct


typedef csEqpTypeRequiredSkill_struct* csEqpTypeRequiredSkill_struct_vPtr;
typedef const csEqpTypeRequiredSkill_struct* csEqpTypeRequiredSkill_struct_cvPtr;

class  csEqpTypeRequiredSkill_struct_var
{
    public:

    csEqpTypeRequiredSkill_struct_var ();

    csEqpTypeRequiredSkill_struct_var (csEqpTypeRequiredSkill_struct *_p);

    csEqpTypeRequiredSkill_struct_var (const csEqpTypeRequiredSkill_struct_var &_s);

    csEqpTypeRequiredSkill_struct_var &operator= (csEqpTypeRequiredSkill_struct *_p);

    csEqpTypeRequiredSkill_struct_var &operator= (const csEqpTypeRequiredSkill_struct_var &_s);

    ~csEqpTypeRequiredSkill_struct_var ();

    csEqpTypeRequiredSkill_struct* operator-> ();

    const csEqpTypeRequiredSkill_struct& in() const;
    csEqpTypeRequiredSkill_struct& inout();
    csEqpTypeRequiredSkill_struct*& out();
    csEqpTypeRequiredSkill_struct* _retn();

    operator csEqpTypeRequiredSkill_struct_cvPtr () const;

    operator csEqpTypeRequiredSkill_struct_vPtr& ();

    operator const csEqpTypeRequiredSkill_struct& () const;

    operator csEqpTypeRequiredSkill_struct& ();

    protected:
    csEqpTypeRequiredSkill_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpTypeRequiredSkill_struct;
    typedef csEqpTypeRequiredSkill_struct csEqpTypeRequiredSkill;
    typedef csEqpTypeRequiredSkill_struct_var csEqpTypeRequiredSkill_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpTypeRequiredSkill;
class  _IDL_SEQ_csEqpTypeRequiredSkillSequence_0_var;
class  _IDL_SEQ_csEqpTypeRequiredSkillSequence_0 {
    public:
        typedef _IDL_SEQ_csEqpTypeRequiredSkillSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csEqpTypeRequiredSkill *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csEqpTypeRequiredSkillSequence_0 ();
    _IDL_SEQ_csEqpTypeRequiredSkillSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csEqpTypeRequiredSkillSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csEqpTypeRequiredSkill* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csEqpTypeRequiredSkillSequence_0 (const _IDL_SEQ_csEqpTypeRequiredSkillSequence_0&);

    ~_IDL_SEQ_csEqpTypeRequiredSkillSequence_0 ();

    _IDL_SEQ_csEqpTypeRequiredSkillSequence_0& operator= (const _IDL_SEQ_csEqpTypeRequiredSkillSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csEqpTypeRequiredSkill& operator [] (::CORBA::ULong indx);
    const csEqpTypeRequiredSkill& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csEqpTypeRequiredSkill* get_buffer (::CORBA::Boolean orphan=0);
    const csEqpTypeRequiredSkill* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csEqpTypeRequiredSkill* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csEqpTypeRequiredSkill* src, csEqpTypeRequiredSkill* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csEqpTypeRequiredSkill* data); 
  public:

    static csEqpTypeRequiredSkill* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csEqpTypeRequiredSkill* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csEqpTypeRequiredSkill* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csEqpTypeRequiredSkillSequence_0> csEqpTypeRequiredSkillSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csEqpTypeRequiredSkillSequence_0* _IDL_SEQ_csEqpTypeRequiredSkillSequence_0_vPtr;
typedef const _IDL_SEQ_csEqpTypeRequiredSkillSequence_0* _IDL_SEQ_csEqpTypeRequiredSkillSequence_0_cvPtr;

class  _IDL_SEQ_csEqpTypeRequiredSkillSequence_0_var
{
    public:

    _IDL_SEQ_csEqpTypeRequiredSkillSequence_0_var ();

    _IDL_SEQ_csEqpTypeRequiredSkillSequence_0_var (_IDL_SEQ_csEqpTypeRequiredSkillSequence_0 *_p);

    _IDL_SEQ_csEqpTypeRequiredSkillSequence_0_var (const _IDL_SEQ_csEqpTypeRequiredSkillSequence_0_var &_s);

    _IDL_SEQ_csEqpTypeRequiredSkillSequence_0_var &operator= (_IDL_SEQ_csEqpTypeRequiredSkillSequence_0 *_p);

    _IDL_SEQ_csEqpTypeRequiredSkillSequence_0_var &operator= (const _IDL_SEQ_csEqpTypeRequiredSkillSequence_0_var &_s);

    ~_IDL_SEQ_csEqpTypeRequiredSkillSequence_0_var ();

    _IDL_SEQ_csEqpTypeRequiredSkillSequence_0* operator-> ();

    operator _IDL_SEQ_csEqpTypeRequiredSkillSequence_0_cvPtr () const;

    operator _IDL_SEQ_csEqpTypeRequiredSkillSequence_0_vPtr& ();

    operator _IDL_SEQ_csEqpTypeRequiredSkillSequence_0() const;

    const csEqpTypeRequiredSkill& operator[] (::CORBA::ULong index) const;
    csEqpTypeRequiredSkill& operator[] (::CORBA::ULong index);
    const csEqpTypeRequiredSkill& operator[] (int index) const;
    csEqpTypeRequiredSkill& operator[] (int index);
    const _IDL_SEQ_csEqpTypeRequiredSkillSequence_0& in() const;
    _IDL_SEQ_csEqpTypeRequiredSkillSequence_0& inout();
    _IDL_SEQ_csEqpTypeRequiredSkillSequence_0*& out();
    _IDL_SEQ_csEqpTypeRequiredSkillSequence_0* _retn();

    protected:
    _IDL_SEQ_csEqpTypeRequiredSkillSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csEqpTypeRequiredSkillSequence_0 _csEqpTypeRequiredSkillSequence_seq;
    typedef _IDL_SEQ_csEqpTypeRequiredSkillSequence_0 _csEqpTypeRequiredSkillSequence_seq_1;
    typedef _IDL_SEQ_csEqpTypeRequiredSkillSequence_0 csEqpTypeRequiredSkillSequence;
    typedef _IDL_SEQ_csEqpTypeRequiredSkillSequence_0_var csEqpTypeRequiredSkillSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpTypeRequiredSkillSequence;
    class  csUserCertifiedEqpTypeSkillInqResult_struct_var;
    struct  csUserCertifiedEqpTypeSkillInqResult_struct {
        typedef csUserCertifiedEqpTypeSkillInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::csEqpTypeRequiredSkillSequence strEqpTypeRequiredSkillSeq;
       ::csUserSkillInfoSequence strUserSkillInfoSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csUserCertifiedEqpTypeSkillInqResult_struct();
       csUserCertifiedEqpTypeSkillInqResult_struct(const csUserCertifiedEqpTypeSkillInqResult_struct&);
       csUserCertifiedEqpTypeSkillInqResult_struct& operator=(const csUserCertifiedEqpTypeSkillInqResult_struct&);
       static CORBA::Info<csUserCertifiedEqpTypeSkillInqResult_struct> csUserCertifiedEqpTypeSkillInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csUserCertifiedEqpTypeSkillInqResult_struct


typedef csUserCertifiedEqpTypeSkillInqResult_struct* csUserCertifiedEqpTypeSkillInqResult_struct_vPtr;
typedef const csUserCertifiedEqpTypeSkillInqResult_struct* csUserCertifiedEqpTypeSkillInqResult_struct_cvPtr;

class  csUserCertifiedEqpTypeSkillInqResult_struct_var
{
    public:

    csUserCertifiedEqpTypeSkillInqResult_struct_var ();

    csUserCertifiedEqpTypeSkillInqResult_struct_var (csUserCertifiedEqpTypeSkillInqResult_struct *_p);

    csUserCertifiedEqpTypeSkillInqResult_struct_var (const csUserCertifiedEqpTypeSkillInqResult_struct_var &_s);

    csUserCertifiedEqpTypeSkillInqResult_struct_var &operator= (csUserCertifiedEqpTypeSkillInqResult_struct *_p);

    csUserCertifiedEqpTypeSkillInqResult_struct_var &operator= (const csUserCertifiedEqpTypeSkillInqResult_struct_var &_s);

    ~csUserCertifiedEqpTypeSkillInqResult_struct_var ();

    csUserCertifiedEqpTypeSkillInqResult_struct* operator-> ();

    const csUserCertifiedEqpTypeSkillInqResult_struct& in() const;
    csUserCertifiedEqpTypeSkillInqResult_struct& inout();
    csUserCertifiedEqpTypeSkillInqResult_struct*& out();
    csUserCertifiedEqpTypeSkillInqResult_struct* _retn();

    operator csUserCertifiedEqpTypeSkillInqResult_struct_cvPtr () const;

    operator csUserCertifiedEqpTypeSkillInqResult_struct_vPtr& ();

    operator const csUserCertifiedEqpTypeSkillInqResult_struct& () const;

    operator csUserCertifiedEqpTypeSkillInqResult_struct& ();

    protected:
    csUserCertifiedEqpTypeSkillInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csUserCertifiedEqpTypeSkillInqResult_struct;
    typedef csUserCertifiedEqpTypeSkillInqResult_struct csUserCertifiedEqpTypeSkillInqResult;
    typedef csUserCertifiedEqpTypeSkillInqResult_struct_var csUserCertifiedEqpTypeSkillInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csUserCertifiedEqpTypeSkillInqResult;
    typedef pptBaseResult csUserCertifyCheckInqResult;
    typedef pptBaseResult_var csUserCertifyCheckInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csUserCertifyCheckInqResult;
    typedef pptBaseResult csUserCertifiedSkillDeleteReqResult;
    typedef pptBaseResult_var csUserCertifiedSkillDeleteReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csUserCertifiedSkillDeleteReqResult;
    typedef pptBaseResult csUserCertifiedSkillUpdateReqResult;
    typedef pptBaseResult_var csUserCertifiedSkillUpdateReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csUserCertifiedSkillUpdateReqResult;
    class  csUserCertifyCheckInqInParm_struct_var;
    struct  csUserCertifyCheckInqInParm_struct {
        typedef csUserCertifyCheckInqInParm_struct_var _var_type;
       ::objectIdentifier userID;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csUserCertifyCheckInqInParm_struct();
       csUserCertifyCheckInqInParm_struct(const csUserCertifyCheckInqInParm_struct&);
       csUserCertifyCheckInqInParm_struct& operator=(const csUserCertifyCheckInqInParm_struct&);
       static CORBA::Info<csUserCertifyCheckInqInParm_struct> csUserCertifyCheckInqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csUserCertifyCheckInqInParm_struct


typedef csUserCertifyCheckInqInParm_struct* csUserCertifyCheckInqInParm_struct_vPtr;
typedef const csUserCertifyCheckInqInParm_struct* csUserCertifyCheckInqInParm_struct_cvPtr;

class  csUserCertifyCheckInqInParm_struct_var
{
    public:

    csUserCertifyCheckInqInParm_struct_var ();

    csUserCertifyCheckInqInParm_struct_var (csUserCertifyCheckInqInParm_struct *_p);

    csUserCertifyCheckInqInParm_struct_var (const csUserCertifyCheckInqInParm_struct_var &_s);

    csUserCertifyCheckInqInParm_struct_var &operator= (csUserCertifyCheckInqInParm_struct *_p);

    csUserCertifyCheckInqInParm_struct_var &operator= (const csUserCertifyCheckInqInParm_struct_var &_s);

    ~csUserCertifyCheckInqInParm_struct_var ();

    csUserCertifyCheckInqInParm_struct* operator-> ();

    const csUserCertifyCheckInqInParm_struct& in() const;
    csUserCertifyCheckInqInParm_struct& inout();
    csUserCertifyCheckInqInParm_struct*& out();
    csUserCertifyCheckInqInParm_struct* _retn();

    operator csUserCertifyCheckInqInParm_struct_cvPtr () const;

    operator csUserCertifyCheckInqInParm_struct_vPtr& ();

    operator const csUserCertifyCheckInqInParm_struct& () const;

    operator csUserCertifyCheckInqInParm_struct& ();

    protected:
    csUserCertifyCheckInqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csUserCertifyCheckInqInParm_struct;
    typedef csUserCertifyCheckInqInParm_struct csUserCertifyCheckInqInParm;
    typedef csUserCertifyCheckInqInParm_struct_var csUserCertifyCheckInqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csUserCertifyCheckInqInParm;
    class  csUserCertifiedSkillUpdateReqInParm_struct_var;
    struct  csUserCertifiedSkillUpdateReqInParm_struct {
        typedef csUserCertifiedSkillUpdateReqInParm_struct_var _var_type;
       ::csUserSkillInfoSequence strUserSkillInfoSeq;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csUserCertifiedSkillUpdateReqInParm_struct();
       csUserCertifiedSkillUpdateReqInParm_struct(const csUserCertifiedSkillUpdateReqInParm_struct&);
       csUserCertifiedSkillUpdateReqInParm_struct& operator=(const csUserCertifiedSkillUpdateReqInParm_struct&);
       static CORBA::Info<csUserCertifiedSkillUpdateReqInParm_struct> csUserCertifiedSkillUpdateReqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csUserCertifiedSkillUpdateReqInParm_struct


typedef csUserCertifiedSkillUpdateReqInParm_struct* csUserCertifiedSkillUpdateReqInParm_struct_vPtr;
typedef const csUserCertifiedSkillUpdateReqInParm_struct* csUserCertifiedSkillUpdateReqInParm_struct_cvPtr;

class  csUserCertifiedSkillUpdateReqInParm_struct_var
{
    public:

    csUserCertifiedSkillUpdateReqInParm_struct_var ();

    csUserCertifiedSkillUpdateReqInParm_struct_var (csUserCertifiedSkillUpdateReqInParm_struct *_p);

    csUserCertifiedSkillUpdateReqInParm_struct_var (const csUserCertifiedSkillUpdateReqInParm_struct_var &_s);

    csUserCertifiedSkillUpdateReqInParm_struct_var &operator= (csUserCertifiedSkillUpdateReqInParm_struct *_p);

    csUserCertifiedSkillUpdateReqInParm_struct_var &operator= (const csUserCertifiedSkillUpdateReqInParm_struct_var &_s);

    ~csUserCertifiedSkillUpdateReqInParm_struct_var ();

    csUserCertifiedSkillUpdateReqInParm_struct* operator-> ();

    const csUserCertifiedSkillUpdateReqInParm_struct& in() const;
    csUserCertifiedSkillUpdateReqInParm_struct& inout();
    csUserCertifiedSkillUpdateReqInParm_struct*& out();
    csUserCertifiedSkillUpdateReqInParm_struct* _retn();

    operator csUserCertifiedSkillUpdateReqInParm_struct_cvPtr () const;

    operator csUserCertifiedSkillUpdateReqInParm_struct_vPtr& ();

    operator const csUserCertifiedSkillUpdateReqInParm_struct& () const;

    operator csUserCertifiedSkillUpdateReqInParm_struct& ();

    protected:
    csUserCertifiedSkillUpdateReqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csUserCertifiedSkillUpdateReqInParm_struct;
    typedef csUserCertifiedSkillUpdateReqInParm_struct csUserCertifiedSkillUpdateReqInParm;
    typedef csUserCertifiedSkillUpdateReqInParm_struct_var csUserCertifiedSkillUpdateReqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csUserCertifiedSkillUpdateReqInParm;
    class  csUserCertifiedSkillDeleteReqInParm_struct_var;
    struct  csUserCertifiedSkillDeleteReqInParm_struct {
        typedef csUserCertifiedSkillDeleteReqInParm_struct_var _var_type;
       ::csUserSkillInfoSequence strUserSkillInfoSeq;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csUserCertifiedSkillDeleteReqInParm_struct();
       csUserCertifiedSkillDeleteReqInParm_struct(const csUserCertifiedSkillDeleteReqInParm_struct&);
       csUserCertifiedSkillDeleteReqInParm_struct& operator=(const csUserCertifiedSkillDeleteReqInParm_struct&);
       static CORBA::Info<csUserCertifiedSkillDeleteReqInParm_struct> csUserCertifiedSkillDeleteReqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csUserCertifiedSkillDeleteReqInParm_struct


typedef csUserCertifiedSkillDeleteReqInParm_struct* csUserCertifiedSkillDeleteReqInParm_struct_vPtr;
typedef const csUserCertifiedSkillDeleteReqInParm_struct* csUserCertifiedSkillDeleteReqInParm_struct_cvPtr;

class  csUserCertifiedSkillDeleteReqInParm_struct_var
{
    public:

    csUserCertifiedSkillDeleteReqInParm_struct_var ();

    csUserCertifiedSkillDeleteReqInParm_struct_var (csUserCertifiedSkillDeleteReqInParm_struct *_p);

    csUserCertifiedSkillDeleteReqInParm_struct_var (const csUserCertifiedSkillDeleteReqInParm_struct_var &_s);

    csUserCertifiedSkillDeleteReqInParm_struct_var &operator= (csUserCertifiedSkillDeleteReqInParm_struct *_p);

    csUserCertifiedSkillDeleteReqInParm_struct_var &operator= (const csUserCertifiedSkillDeleteReqInParm_struct_var &_s);

    ~csUserCertifiedSkillDeleteReqInParm_struct_var ();

    csUserCertifiedSkillDeleteReqInParm_struct* operator-> ();

    const csUserCertifiedSkillDeleteReqInParm_struct& in() const;
    csUserCertifiedSkillDeleteReqInParm_struct& inout();
    csUserCertifiedSkillDeleteReqInParm_struct*& out();
    csUserCertifiedSkillDeleteReqInParm_struct* _retn();

    operator csUserCertifiedSkillDeleteReqInParm_struct_cvPtr () const;

    operator csUserCertifiedSkillDeleteReqInParm_struct_vPtr& ();

    operator const csUserCertifiedSkillDeleteReqInParm_struct& () const;

    operator csUserCertifiedSkillDeleteReqInParm_struct& ();

    protected:
    csUserCertifiedSkillDeleteReqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csUserCertifiedSkillDeleteReqInParm_struct;
    typedef csUserCertifiedSkillDeleteReqInParm_struct csUserCertifiedSkillDeleteReqInParm;
    typedef csUserCertifiedSkillDeleteReqInParm_struct_var csUserCertifiedSkillDeleteReqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csUserCertifiedSkillDeleteReqInParm;
    class  csUserCertifiedEqpTypeSkillInqInParm_struct_var;
    struct  csUserCertifiedEqpTypeSkillInqInParm_struct {
        typedef csUserCertifiedEqpTypeSkillInqInParm_struct_var _var_type;
       ::objectIdentifier userID;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csUserCertifiedEqpTypeSkillInqInParm_struct();
       csUserCertifiedEqpTypeSkillInqInParm_struct(const csUserCertifiedEqpTypeSkillInqInParm_struct&);
       csUserCertifiedEqpTypeSkillInqInParm_struct& operator=(const csUserCertifiedEqpTypeSkillInqInParm_struct&);
       static CORBA::Info<csUserCertifiedEqpTypeSkillInqInParm_struct> csUserCertifiedEqpTypeSkillInqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csUserCertifiedEqpTypeSkillInqInParm_struct


typedef csUserCertifiedEqpTypeSkillInqInParm_struct* csUserCertifiedEqpTypeSkillInqInParm_struct_vPtr;
typedef const csUserCertifiedEqpTypeSkillInqInParm_struct* csUserCertifiedEqpTypeSkillInqInParm_struct_cvPtr;

class  csUserCertifiedEqpTypeSkillInqInParm_struct_var
{
    public:

    csUserCertifiedEqpTypeSkillInqInParm_struct_var ();

    csUserCertifiedEqpTypeSkillInqInParm_struct_var (csUserCertifiedEqpTypeSkillInqInParm_struct *_p);

    csUserCertifiedEqpTypeSkillInqInParm_struct_var (const csUserCertifiedEqpTypeSkillInqInParm_struct_var &_s);

    csUserCertifiedEqpTypeSkillInqInParm_struct_var &operator= (csUserCertifiedEqpTypeSkillInqInParm_struct *_p);

    csUserCertifiedEqpTypeSkillInqInParm_struct_var &operator= (const csUserCertifiedEqpTypeSkillInqInParm_struct_var &_s);

    ~csUserCertifiedEqpTypeSkillInqInParm_struct_var ();

    csUserCertifiedEqpTypeSkillInqInParm_struct* operator-> ();

    const csUserCertifiedEqpTypeSkillInqInParm_struct& in() const;
    csUserCertifiedEqpTypeSkillInqInParm_struct& inout();
    csUserCertifiedEqpTypeSkillInqInParm_struct*& out();
    csUserCertifiedEqpTypeSkillInqInParm_struct* _retn();

    operator csUserCertifiedEqpTypeSkillInqInParm_struct_cvPtr () const;

    operator csUserCertifiedEqpTypeSkillInqInParm_struct_vPtr& ();

    operator const csUserCertifiedEqpTypeSkillInqInParm_struct& () const;

    operator csUserCertifiedEqpTypeSkillInqInParm_struct& ();

    protected:
    csUserCertifiedEqpTypeSkillInqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csUserCertifiedEqpTypeSkillInqInParm_struct;
    typedef csUserCertifiedEqpTypeSkillInqInParm_struct csUserCertifiedEqpTypeSkillInqInParm;
    typedef csUserCertifiedEqpTypeSkillInqInParm_struct_var csUserCertifiedEqpTypeSkillInqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csUserCertifiedEqpTypeSkillInqInParm;
    class  csFixtureTouchCountInfo_struct_var;
    struct  csFixtureTouchCountInfo_struct {
        typedef csFixtureTouchCountInfo_struct_var _var_type;
       ::CORBA::Long touchCount;
       ::CORBA::Long accumTouchCount;
       ::CORBA::Boolean touchCountCheck;
       ::CORBA::Long warningTouchCount;
       ::CORBA::Long maxTouchCount;
       ::CORBA::String_StructElem touchCountStatus;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csFixtureTouchCountInfo_struct();
       csFixtureTouchCountInfo_struct(const csFixtureTouchCountInfo_struct&);
       csFixtureTouchCountInfo_struct& operator=(const csFixtureTouchCountInfo_struct&);
       static CORBA::Info<csFixtureTouchCountInfo_struct> csFixtureTouchCountInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csFixtureTouchCountInfo_struct


typedef csFixtureTouchCountInfo_struct* csFixtureTouchCountInfo_struct_vPtr;
typedef const csFixtureTouchCountInfo_struct* csFixtureTouchCountInfo_struct_cvPtr;

class  csFixtureTouchCountInfo_struct_var
{
    public:

    csFixtureTouchCountInfo_struct_var ();

    csFixtureTouchCountInfo_struct_var (csFixtureTouchCountInfo_struct *_p);

    csFixtureTouchCountInfo_struct_var (const csFixtureTouchCountInfo_struct_var &_s);

    csFixtureTouchCountInfo_struct_var &operator= (csFixtureTouchCountInfo_struct *_p);

    csFixtureTouchCountInfo_struct_var &operator= (const csFixtureTouchCountInfo_struct_var &_s);

    ~csFixtureTouchCountInfo_struct_var ();

    csFixtureTouchCountInfo_struct* operator-> ();

    const csFixtureTouchCountInfo_struct& in() const;
    csFixtureTouchCountInfo_struct& inout();
    csFixtureTouchCountInfo_struct*& out();
    csFixtureTouchCountInfo_struct* _retn();

    operator csFixtureTouchCountInfo_struct_cvPtr () const;

    operator csFixtureTouchCountInfo_struct_vPtr& ();

    operator const csFixtureTouchCountInfo_struct& () const;

    operator csFixtureTouchCountInfo_struct& ();

    protected:
    csFixtureTouchCountInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csFixtureTouchCountInfo_struct;
    typedef csFixtureTouchCountInfo_struct csFixtureTouchCountInfo;
    typedef csFixtureTouchCountInfo_struct_var csFixtureTouchCountInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csFixtureTouchCountInfo;
    class  csFixtureTouchCountRptInParm_struct_var;
    struct  csFixtureTouchCountRptInParm_struct {
        typedef csFixtureTouchCountRptInParm_struct_var _var_type;
       ::objectIdentifier fixtureID;
       ::csFixtureTouchCountInfo strFixtureTouchCountInfo;
       ::CORBA::String_StructElem claimMemo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csFixtureTouchCountRptInParm_struct();
       csFixtureTouchCountRptInParm_struct(const csFixtureTouchCountRptInParm_struct&);
       csFixtureTouchCountRptInParm_struct& operator=(const csFixtureTouchCountRptInParm_struct&);
       static CORBA::Info<csFixtureTouchCountRptInParm_struct> csFixtureTouchCountRptInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csFixtureTouchCountRptInParm_struct


typedef csFixtureTouchCountRptInParm_struct* csFixtureTouchCountRptInParm_struct_vPtr;
typedef const csFixtureTouchCountRptInParm_struct* csFixtureTouchCountRptInParm_struct_cvPtr;

class  csFixtureTouchCountRptInParm_struct_var
{
    public:

    csFixtureTouchCountRptInParm_struct_var ();

    csFixtureTouchCountRptInParm_struct_var (csFixtureTouchCountRptInParm_struct *_p);

    csFixtureTouchCountRptInParm_struct_var (const csFixtureTouchCountRptInParm_struct_var &_s);

    csFixtureTouchCountRptInParm_struct_var &operator= (csFixtureTouchCountRptInParm_struct *_p);

    csFixtureTouchCountRptInParm_struct_var &operator= (const csFixtureTouchCountRptInParm_struct_var &_s);

    ~csFixtureTouchCountRptInParm_struct_var ();

    csFixtureTouchCountRptInParm_struct* operator-> ();

    const csFixtureTouchCountRptInParm_struct& in() const;
    csFixtureTouchCountRptInParm_struct& inout();
    csFixtureTouchCountRptInParm_struct*& out();
    csFixtureTouchCountRptInParm_struct* _retn();

    operator csFixtureTouchCountRptInParm_struct_cvPtr () const;

    operator csFixtureTouchCountRptInParm_struct_vPtr& ();

    operator const csFixtureTouchCountRptInParm_struct& () const;

    operator csFixtureTouchCountRptInParm_struct& ();

    protected:
    csFixtureTouchCountRptInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csFixtureTouchCountRptInParm_struct;
    typedef csFixtureTouchCountRptInParm_struct csFixtureTouchCountRptInParm;
    typedef csFixtureTouchCountRptInParm_struct_var csFixtureTouchCountRptInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csFixtureTouchCountRptInParm;
    class  csFixtureTouchCountRptResult_struct_var;
    struct  csFixtureTouchCountRptResult_struct {
        typedef csFixtureTouchCountRptResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::csFixtureTouchCountInfo strFixtureTouchCountInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csFixtureTouchCountRptResult_struct();
       csFixtureTouchCountRptResult_struct(const csFixtureTouchCountRptResult_struct&);
       csFixtureTouchCountRptResult_struct& operator=(const csFixtureTouchCountRptResult_struct&);
       static CORBA::Info<csFixtureTouchCountRptResult_struct> csFixtureTouchCountRptResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csFixtureTouchCountRptResult_struct


typedef csFixtureTouchCountRptResult_struct* csFixtureTouchCountRptResult_struct_vPtr;
typedef const csFixtureTouchCountRptResult_struct* csFixtureTouchCountRptResult_struct_cvPtr;

class  csFixtureTouchCountRptResult_struct_var
{
    public:

    csFixtureTouchCountRptResult_struct_var ();

    csFixtureTouchCountRptResult_struct_var (csFixtureTouchCountRptResult_struct *_p);

    csFixtureTouchCountRptResult_struct_var (const csFixtureTouchCountRptResult_struct_var &_s);

    csFixtureTouchCountRptResult_struct_var &operator= (csFixtureTouchCountRptResult_struct *_p);

    csFixtureTouchCountRptResult_struct_var &operator= (const csFixtureTouchCountRptResult_struct_var &_s);

    ~csFixtureTouchCountRptResult_struct_var ();

    csFixtureTouchCountRptResult_struct* operator-> ();

    const csFixtureTouchCountRptResult_struct& in() const;
    csFixtureTouchCountRptResult_struct& inout();
    csFixtureTouchCountRptResult_struct*& out();
    csFixtureTouchCountRptResult_struct* _retn();

    operator csFixtureTouchCountRptResult_struct_cvPtr () const;

    operator csFixtureTouchCountRptResult_struct_vPtr& ();

    operator const csFixtureTouchCountRptResult_struct& () const;

    operator csFixtureTouchCountRptResult_struct& ();

    protected:
    csFixtureTouchCountRptResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csFixtureTouchCountRptResult_struct;
    typedef csFixtureTouchCountRptResult_struct csFixtureTouchCountRptResult;
    typedef csFixtureTouchCountRptResult_struct_var csFixtureTouchCountRptResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csFixtureTouchCountRptResult;
    typedef csFixtureTouchCountInfo csFixtureStatusInqResult_siInfo;
    typedef csFixtureTouchCountInfo_var csFixtureStatusInqResult_siInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csFixtureStatusInqResult_siInfo;
    class  csChamberProcessWafer_siInfo_struct_var;
    struct  csChamberProcessWafer_siInfo_struct {
        typedef csChamberProcessWafer_siInfo_struct_var _var_type;
       ::objectIdentifierSequence fixtureIDs;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csChamberProcessWafer_siInfo_struct();
       csChamberProcessWafer_siInfo_struct(const csChamberProcessWafer_siInfo_struct&);
       csChamberProcessWafer_siInfo_struct& operator=(const csChamberProcessWafer_siInfo_struct&);
       static CORBA::Info<csChamberProcessWafer_siInfo_struct> csChamberProcessWafer_siInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csChamberProcessWafer_siInfo_struct


typedef csChamberProcessWafer_siInfo_struct* csChamberProcessWafer_siInfo_struct_vPtr;
typedef const csChamberProcessWafer_siInfo_struct* csChamberProcessWafer_siInfo_struct_cvPtr;

class  csChamberProcessWafer_siInfo_struct_var
{
    public:

    csChamberProcessWafer_siInfo_struct_var ();

    csChamberProcessWafer_siInfo_struct_var (csChamberProcessWafer_siInfo_struct *_p);

    csChamberProcessWafer_siInfo_struct_var (const csChamberProcessWafer_siInfo_struct_var &_s);

    csChamberProcessWafer_siInfo_struct_var &operator= (csChamberProcessWafer_siInfo_struct *_p);

    csChamberProcessWafer_siInfo_struct_var &operator= (const csChamberProcessWafer_siInfo_struct_var &_s);

    ~csChamberProcessWafer_siInfo_struct_var ();

    csChamberProcessWafer_siInfo_struct* operator-> ();

    const csChamberProcessWafer_siInfo_struct& in() const;
    csChamberProcessWafer_siInfo_struct& inout();
    csChamberProcessWafer_siInfo_struct*& out();
    csChamberProcessWafer_siInfo_struct* _retn();

    operator csChamberProcessWafer_siInfo_struct_cvPtr () const;

    operator csChamberProcessWafer_siInfo_struct_vPtr& ();

    operator const csChamberProcessWafer_siInfo_struct& () const;

    operator csChamberProcessWafer_siInfo_struct& ();

    protected:
    csChamberProcessWafer_siInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csChamberProcessWafer_siInfo_struct;
    typedef csChamberProcessWafer_siInfo_struct csChamberProcessWafer_siInfo;
    typedef csChamberProcessWafer_siInfo_struct_var csChamberProcessWafer_siInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csChamberProcessWafer_siInfo;
    class  csLithoITMLayerFlag_struct_var;
    struct  csLithoITMLayerFlag_struct {
        typedef csLithoITMLayerFlag_struct_var _var_type;
       ::objectIdentifier photolayer;
       ::CORBA::String_StructElem ITMLayerFlag;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csLithoITMLayerFlag_struct();
       csLithoITMLayerFlag_struct(const csLithoITMLayerFlag_struct&);
       csLithoITMLayerFlag_struct& operator=(const csLithoITMLayerFlag_struct&);
       static CORBA::Info<csLithoITMLayerFlag_struct> csLithoITMLayerFlag_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csLithoITMLayerFlag_struct


typedef csLithoITMLayerFlag_struct* csLithoITMLayerFlag_struct_vPtr;
typedef const csLithoITMLayerFlag_struct* csLithoITMLayerFlag_struct_cvPtr;

class  csLithoITMLayerFlag_struct_var
{
    public:

    csLithoITMLayerFlag_struct_var ();

    csLithoITMLayerFlag_struct_var (csLithoITMLayerFlag_struct *_p);

    csLithoITMLayerFlag_struct_var (const csLithoITMLayerFlag_struct_var &_s);

    csLithoITMLayerFlag_struct_var &operator= (csLithoITMLayerFlag_struct *_p);

    csLithoITMLayerFlag_struct_var &operator= (const csLithoITMLayerFlag_struct_var &_s);

    ~csLithoITMLayerFlag_struct_var ();

    csLithoITMLayerFlag_struct* operator-> ();

    const csLithoITMLayerFlag_struct& in() const;
    csLithoITMLayerFlag_struct& inout();
    csLithoITMLayerFlag_struct*& out();
    csLithoITMLayerFlag_struct* _retn();

    operator csLithoITMLayerFlag_struct_cvPtr () const;

    operator csLithoITMLayerFlag_struct_vPtr& ();

    operator const csLithoITMLayerFlag_struct& () const;

    operator csLithoITMLayerFlag_struct& ();

    protected:
    csLithoITMLayerFlag_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csLithoITMLayerFlag_struct;
    typedef csLithoITMLayerFlag_struct csLithoITMLayerFlag;
    typedef csLithoITMLayerFlag_struct_var csLithoITMLayerFlag_var;
    extern  ::CORBA::TypeCode_ptr _tc_csLithoITMLayerFlag;
class  _IDL_SEQ_csLithoITMLayerFlagSequence_0_var;
class  _IDL_SEQ_csLithoITMLayerFlagSequence_0 {
    public:
        typedef _IDL_SEQ_csLithoITMLayerFlagSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csLithoITMLayerFlag *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csLithoITMLayerFlagSequence_0 ();
    _IDL_SEQ_csLithoITMLayerFlagSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csLithoITMLayerFlagSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csLithoITMLayerFlag* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csLithoITMLayerFlagSequence_0 (const _IDL_SEQ_csLithoITMLayerFlagSequence_0&);

    ~_IDL_SEQ_csLithoITMLayerFlagSequence_0 ();

    _IDL_SEQ_csLithoITMLayerFlagSequence_0& operator= (const _IDL_SEQ_csLithoITMLayerFlagSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csLithoITMLayerFlag& operator [] (::CORBA::ULong indx);
    const csLithoITMLayerFlag& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csLithoITMLayerFlag* get_buffer (::CORBA::Boolean orphan=0);
    const csLithoITMLayerFlag* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csLithoITMLayerFlag* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csLithoITMLayerFlag* src, csLithoITMLayerFlag* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csLithoITMLayerFlag* data); 
  public:

    static csLithoITMLayerFlag* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csLithoITMLayerFlag* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csLithoITMLayerFlag* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csLithoITMLayerFlagSequence_0> csLithoITMLayerFlagSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csLithoITMLayerFlagSequence_0* _IDL_SEQ_csLithoITMLayerFlagSequence_0_vPtr;
typedef const _IDL_SEQ_csLithoITMLayerFlagSequence_0* _IDL_SEQ_csLithoITMLayerFlagSequence_0_cvPtr;

class  _IDL_SEQ_csLithoITMLayerFlagSequence_0_var
{
    public:

    _IDL_SEQ_csLithoITMLayerFlagSequence_0_var ();

    _IDL_SEQ_csLithoITMLayerFlagSequence_0_var (_IDL_SEQ_csLithoITMLayerFlagSequence_0 *_p);

    _IDL_SEQ_csLithoITMLayerFlagSequence_0_var (const _IDL_SEQ_csLithoITMLayerFlagSequence_0_var &_s);

    _IDL_SEQ_csLithoITMLayerFlagSequence_0_var &operator= (_IDL_SEQ_csLithoITMLayerFlagSequence_0 *_p);

    _IDL_SEQ_csLithoITMLayerFlagSequence_0_var &operator= (const _IDL_SEQ_csLithoITMLayerFlagSequence_0_var &_s);

    ~_IDL_SEQ_csLithoITMLayerFlagSequence_0_var ();

    _IDL_SEQ_csLithoITMLayerFlagSequence_0* operator-> ();

    operator _IDL_SEQ_csLithoITMLayerFlagSequence_0_cvPtr () const;

    operator _IDL_SEQ_csLithoITMLayerFlagSequence_0_vPtr& ();

    operator _IDL_SEQ_csLithoITMLayerFlagSequence_0() const;

    const csLithoITMLayerFlag& operator[] (::CORBA::ULong index) const;
    csLithoITMLayerFlag& operator[] (::CORBA::ULong index);
    const csLithoITMLayerFlag& operator[] (int index) const;
    csLithoITMLayerFlag& operator[] (int index);
    const _IDL_SEQ_csLithoITMLayerFlagSequence_0& in() const;
    _IDL_SEQ_csLithoITMLayerFlagSequence_0& inout();
    _IDL_SEQ_csLithoITMLayerFlagSequence_0*& out();
    _IDL_SEQ_csLithoITMLayerFlagSequence_0* _retn();

    protected:
    _IDL_SEQ_csLithoITMLayerFlagSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csLithoITMLayerFlagSequence_0 _csLithoITMLayerFlagSequence_seq;
    typedef _IDL_SEQ_csLithoITMLayerFlagSequence_0 _csLithoITMLayerFlagSequence_seq_1;
    typedef _IDL_SEQ_csLithoITMLayerFlagSequence_0 csLithoITMLayerFlagSequence;
    typedef _IDL_SEQ_csLithoITMLayerFlagSequence_0_var csLithoITMLayerFlagSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csLithoITMLayerFlagSequence;
    class  csLithoWaferData_struct_var;
    struct  csLithoWaferData_struct {
        typedef csLithoWaferData_struct_var _var_type;
       ::objectIdentifier waferID;
       ::CORBA::Long slotNo;
       ::CORBA::Long chuckID;
       ::CORBA::Long reworkCount;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csLithoWaferData_struct();
       csLithoWaferData_struct(const csLithoWaferData_struct&);
       csLithoWaferData_struct& operator=(const csLithoWaferData_struct&);
       static CORBA::Info<csLithoWaferData_struct> csLithoWaferData_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csLithoWaferData_struct


typedef csLithoWaferData_struct* csLithoWaferData_struct_vPtr;
typedef const csLithoWaferData_struct* csLithoWaferData_struct_cvPtr;

class  csLithoWaferData_struct_var
{
    public:

    csLithoWaferData_struct_var ();

    csLithoWaferData_struct_var (csLithoWaferData_struct *_p);

    csLithoWaferData_struct_var (const csLithoWaferData_struct_var &_s);

    csLithoWaferData_struct_var &operator= (csLithoWaferData_struct *_p);

    csLithoWaferData_struct_var &operator= (const csLithoWaferData_struct_var &_s);

    ~csLithoWaferData_struct_var ();

    csLithoWaferData_struct* operator-> ();

    const csLithoWaferData_struct& in() const;
    csLithoWaferData_struct& inout();
    csLithoWaferData_struct*& out();
    csLithoWaferData_struct* _retn();

    operator csLithoWaferData_struct_cvPtr () const;

    operator csLithoWaferData_struct_vPtr& ();

    operator const csLithoWaferData_struct& () const;

    operator csLithoWaferData_struct& ();

    protected:
    csLithoWaferData_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csLithoWaferData_struct;
    typedef csLithoWaferData_struct csLithoWaferData;
    typedef csLithoWaferData_struct_var csLithoWaferData_var;
    extern  ::CORBA::TypeCode_ptr _tc_csLithoWaferData;
class  _IDL_SEQ_csLithoWaferDataSequence_0_var;
class  _IDL_SEQ_csLithoWaferDataSequence_0 {
    public:
        typedef _IDL_SEQ_csLithoWaferDataSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csLithoWaferData *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csLithoWaferDataSequence_0 ();
    _IDL_SEQ_csLithoWaferDataSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csLithoWaferDataSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csLithoWaferData* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csLithoWaferDataSequence_0 (const _IDL_SEQ_csLithoWaferDataSequence_0&);

    ~_IDL_SEQ_csLithoWaferDataSequence_0 ();

    _IDL_SEQ_csLithoWaferDataSequence_0& operator= (const _IDL_SEQ_csLithoWaferDataSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csLithoWaferData& operator [] (::CORBA::ULong indx);
    const csLithoWaferData& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csLithoWaferData* get_buffer (::CORBA::Boolean orphan=0);
    const csLithoWaferData* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csLithoWaferData* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csLithoWaferData* src, csLithoWaferData* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csLithoWaferData* data); 
  public:

    static csLithoWaferData* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csLithoWaferData* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csLithoWaferData* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csLithoWaferDataSequence_0> csLithoWaferDataSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csLithoWaferDataSequence_0* _IDL_SEQ_csLithoWaferDataSequence_0_vPtr;
typedef const _IDL_SEQ_csLithoWaferDataSequence_0* _IDL_SEQ_csLithoWaferDataSequence_0_cvPtr;

class  _IDL_SEQ_csLithoWaferDataSequence_0_var
{
    public:

    _IDL_SEQ_csLithoWaferDataSequence_0_var ();

    _IDL_SEQ_csLithoWaferDataSequence_0_var (_IDL_SEQ_csLithoWaferDataSequence_0 *_p);

    _IDL_SEQ_csLithoWaferDataSequence_0_var (const _IDL_SEQ_csLithoWaferDataSequence_0_var &_s);

    _IDL_SEQ_csLithoWaferDataSequence_0_var &operator= (_IDL_SEQ_csLithoWaferDataSequence_0 *_p);

    _IDL_SEQ_csLithoWaferDataSequence_0_var &operator= (const _IDL_SEQ_csLithoWaferDataSequence_0_var &_s);

    ~_IDL_SEQ_csLithoWaferDataSequence_0_var ();

    _IDL_SEQ_csLithoWaferDataSequence_0* operator-> ();

    operator _IDL_SEQ_csLithoWaferDataSequence_0_cvPtr () const;

    operator _IDL_SEQ_csLithoWaferDataSequence_0_vPtr& ();

    operator _IDL_SEQ_csLithoWaferDataSequence_0() const;

    const csLithoWaferData& operator[] (::CORBA::ULong index) const;
    csLithoWaferData& operator[] (::CORBA::ULong index);
    const csLithoWaferData& operator[] (int index) const;
    csLithoWaferData& operator[] (int index);
    const _IDL_SEQ_csLithoWaferDataSequence_0& in() const;
    _IDL_SEQ_csLithoWaferDataSequence_0& inout();
    _IDL_SEQ_csLithoWaferDataSequence_0*& out();
    _IDL_SEQ_csLithoWaferDataSequence_0* _retn();

    protected:
    _IDL_SEQ_csLithoWaferDataSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csLithoWaferDataSequence_0 _csLithoWaferDataSequence_seq;
    typedef _IDL_SEQ_csLithoWaferDataSequence_0 _csLithoWaferDataSequence_seq_1;
    typedef _IDL_SEQ_csLithoWaferDataSequence_0 csLithoWaferDataSequence;
    typedef _IDL_SEQ_csLithoWaferDataSequence_0_var csLithoWaferDataSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csLithoWaferDataSequence;
    class  csLithoLotDataInfo_struct_var;
    struct  csLithoLotDataInfo_struct {
        typedef csLithoLotDataInfo_struct_var _var_type;
       ::objectIdentifier lotID;
       ::csLithoWaferDataSequence strWaferDataSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csLithoLotDataInfo_struct();
       csLithoLotDataInfo_struct(const csLithoLotDataInfo_struct&);
       csLithoLotDataInfo_struct& operator=(const csLithoLotDataInfo_struct&);
       static CORBA::Info<csLithoLotDataInfo_struct> csLithoLotDataInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csLithoLotDataInfo_struct


typedef csLithoLotDataInfo_struct* csLithoLotDataInfo_struct_vPtr;
typedef const csLithoLotDataInfo_struct* csLithoLotDataInfo_struct_cvPtr;

class  csLithoLotDataInfo_struct_var
{
    public:

    csLithoLotDataInfo_struct_var ();

    csLithoLotDataInfo_struct_var (csLithoLotDataInfo_struct *_p);

    csLithoLotDataInfo_struct_var (const csLithoLotDataInfo_struct_var &_s);

    csLithoLotDataInfo_struct_var &operator= (csLithoLotDataInfo_struct *_p);

    csLithoLotDataInfo_struct_var &operator= (const csLithoLotDataInfo_struct_var &_s);

    ~csLithoLotDataInfo_struct_var ();

    csLithoLotDataInfo_struct* operator-> ();

    const csLithoLotDataInfo_struct& in() const;
    csLithoLotDataInfo_struct& inout();
    csLithoLotDataInfo_struct*& out();
    csLithoLotDataInfo_struct* _retn();

    operator csLithoLotDataInfo_struct_cvPtr () const;

    operator csLithoLotDataInfo_struct_vPtr& ();

    operator const csLithoLotDataInfo_struct& () const;

    operator csLithoLotDataInfo_struct& ();

    protected:
    csLithoLotDataInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csLithoLotDataInfo_struct;
    typedef csLithoLotDataInfo_struct csLithoLotDataInfo;
    typedef csLithoLotDataInfo_struct_var csLithoLotDataInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csLithoLotDataInfo;
    class  csLithoLDExtend_struct_var;
    struct  csLithoLDExtend_struct {
        typedef csLithoLDExtend_struct_var _var_type;
       ::CORBA::String_StructElem name;
       ::CORBA::String_StructElem value;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csLithoLDExtend_struct();
       csLithoLDExtend_struct(const csLithoLDExtend_struct&);
       csLithoLDExtend_struct& operator=(const csLithoLDExtend_struct&);
       static CORBA::Info<csLithoLDExtend_struct> csLithoLDExtend_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csLithoLDExtend_struct


typedef csLithoLDExtend_struct* csLithoLDExtend_struct_vPtr;
typedef const csLithoLDExtend_struct* csLithoLDExtend_struct_cvPtr;

class  csLithoLDExtend_struct_var
{
    public:

    csLithoLDExtend_struct_var ();

    csLithoLDExtend_struct_var (csLithoLDExtend_struct *_p);

    csLithoLDExtend_struct_var (const csLithoLDExtend_struct_var &_s);

    csLithoLDExtend_struct_var &operator= (csLithoLDExtend_struct *_p);

    csLithoLDExtend_struct_var &operator= (const csLithoLDExtend_struct_var &_s);

    ~csLithoLDExtend_struct_var ();

    csLithoLDExtend_struct* operator-> ();

    const csLithoLDExtend_struct& in() const;
    csLithoLDExtend_struct& inout();
    csLithoLDExtend_struct*& out();
    csLithoLDExtend_struct* _retn();

    operator csLithoLDExtend_struct_cvPtr () const;

    operator csLithoLDExtend_struct_vPtr& ();

    operator const csLithoLDExtend_struct& () const;

    operator csLithoLDExtend_struct& ();

    protected:
    csLithoLDExtend_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csLithoLDExtend_struct;
    typedef csLithoLDExtend_struct csLithoLDExtend;
    typedef csLithoLDExtend_struct_var csLithoLDExtend_var;
    extern  ::CORBA::TypeCode_ptr _tc_csLithoLDExtend;
class  _IDL_SEQ_csLithoLDExtendSequence_0_var;
class  _IDL_SEQ_csLithoLDExtendSequence_0 {
    public:
        typedef _IDL_SEQ_csLithoLDExtendSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csLithoLDExtend *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csLithoLDExtendSequence_0 ();
    _IDL_SEQ_csLithoLDExtendSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csLithoLDExtendSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csLithoLDExtend* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csLithoLDExtendSequence_0 (const _IDL_SEQ_csLithoLDExtendSequence_0&);

    ~_IDL_SEQ_csLithoLDExtendSequence_0 ();

    _IDL_SEQ_csLithoLDExtendSequence_0& operator= (const _IDL_SEQ_csLithoLDExtendSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csLithoLDExtend& operator [] (::CORBA::ULong indx);
    const csLithoLDExtend& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csLithoLDExtend* get_buffer (::CORBA::Boolean orphan=0);
    const csLithoLDExtend* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csLithoLDExtend* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csLithoLDExtend* src, csLithoLDExtend* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csLithoLDExtend* data); 
  public:

    static csLithoLDExtend* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csLithoLDExtend* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csLithoLDExtend* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csLithoLDExtendSequence_0> csLithoLDExtendSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csLithoLDExtendSequence_0* _IDL_SEQ_csLithoLDExtendSequence_0_vPtr;
typedef const _IDL_SEQ_csLithoLDExtendSequence_0* _IDL_SEQ_csLithoLDExtendSequence_0_cvPtr;

class  _IDL_SEQ_csLithoLDExtendSequence_0_var
{
    public:

    _IDL_SEQ_csLithoLDExtendSequence_0_var ();

    _IDL_SEQ_csLithoLDExtendSequence_0_var (_IDL_SEQ_csLithoLDExtendSequence_0 *_p);

    _IDL_SEQ_csLithoLDExtendSequence_0_var (const _IDL_SEQ_csLithoLDExtendSequence_0_var &_s);

    _IDL_SEQ_csLithoLDExtendSequence_0_var &operator= (_IDL_SEQ_csLithoLDExtendSequence_0 *_p);

    _IDL_SEQ_csLithoLDExtendSequence_0_var &operator= (const _IDL_SEQ_csLithoLDExtendSequence_0_var &_s);

    ~_IDL_SEQ_csLithoLDExtendSequence_0_var ();

    _IDL_SEQ_csLithoLDExtendSequence_0* operator-> ();

    operator _IDL_SEQ_csLithoLDExtendSequence_0_cvPtr () const;

    operator _IDL_SEQ_csLithoLDExtendSequence_0_vPtr& ();

    operator _IDL_SEQ_csLithoLDExtendSequence_0() const;

    const csLithoLDExtend& operator[] (::CORBA::ULong index) const;
    csLithoLDExtend& operator[] (::CORBA::ULong index);
    const csLithoLDExtend& operator[] (int index) const;
    csLithoLDExtend& operator[] (int index);
    const _IDL_SEQ_csLithoLDExtendSequence_0& in() const;
    _IDL_SEQ_csLithoLDExtendSequence_0& inout();
    _IDL_SEQ_csLithoLDExtendSequence_0*& out();
    _IDL_SEQ_csLithoLDExtendSequence_0* _retn();

    protected:
    _IDL_SEQ_csLithoLDExtendSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csLithoLDExtendSequence_0 _csLithoLDExtendSequence_seq;
    typedef _IDL_SEQ_csLithoLDExtendSequence_0 _csLithoLDExtendSequence_seq_1;
    typedef _IDL_SEQ_csLithoLDExtendSequence_0 csLithoLDExtendSequence;
    typedef _IDL_SEQ_csLithoLDExtendSequence_0_var csLithoLDExtendSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csLithoLDExtendSequence;
    class  csAPCLithoContextInfo_struct_var;
    struct  csAPCLithoContextInfo_struct {
        typedef csAPCLithoContextInfo_struct_var _var_type;
       ::CORBA::String_StructElem controlJobType;
       ::CORBA::String_StructElem transactionID;
       ::CORBA::String_StructElem recommendTransactionID;
       ::CORBA::String_StructElem usedTransactionID;
       ::CORBA::String_StructElem lotID;
       ::CORBA::String_StructElem lotType;
       ::CORBA::String_StructElem partID;
       ::CORBA::String_StructElem layer;
       ::CORBA::String_StructElem routeGroup;
       ::CORBA::String_StructElem reticleID;
       ::CORBA::String_StructElem processEquipmentType;
       ::CORBA::String_StructElem processEquipmentID;
       ::CORBA::String_StructElem recommendMode;
       ::CORBA::String_StructElem routeID;
       ::CORBA::String_StructElem operationNumber;
       ::CORBA::Boolean reworkLotFlag;
       ::CORBA::String_StructElem parentLotID;
       ::CORBA::String_StructElem preToolID;
       ::CORBA::Boolean sendAheadFlag;
       ::CORBA::String_StructElem ParameterNames;
       ::CORBA::String_StructElem availableSubUnit;
       ::CORBA::Boolean opeStartRecommendFlag;
       ::CORBA::String_StructElem feedForward1;
       ::CORBA::String_StructElem feedForward2;
       ::CORBA::String_StructElem feedForward3;
       ::CORBA::String_StructElem feedForward4;
       ::csLithoLDExtendSequence extends;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csAPCLithoContextInfo_struct();
       csAPCLithoContextInfo_struct(const csAPCLithoContextInfo_struct&);
       csAPCLithoContextInfo_struct& operator=(const csAPCLithoContextInfo_struct&);
       static CORBA::Info<csAPCLithoContextInfo_struct> csAPCLithoContextInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csAPCLithoContextInfo_struct


typedef csAPCLithoContextInfo_struct* csAPCLithoContextInfo_struct_vPtr;
typedef const csAPCLithoContextInfo_struct* csAPCLithoContextInfo_struct_cvPtr;

class  csAPCLithoContextInfo_struct_var
{
    public:

    csAPCLithoContextInfo_struct_var ();

    csAPCLithoContextInfo_struct_var (csAPCLithoContextInfo_struct *_p);

    csAPCLithoContextInfo_struct_var (const csAPCLithoContextInfo_struct_var &_s);

    csAPCLithoContextInfo_struct_var &operator= (csAPCLithoContextInfo_struct *_p);

    csAPCLithoContextInfo_struct_var &operator= (const csAPCLithoContextInfo_struct_var &_s);

    ~csAPCLithoContextInfo_struct_var ();

    csAPCLithoContextInfo_struct* operator-> ();

    const csAPCLithoContextInfo_struct& in() const;
    csAPCLithoContextInfo_struct& inout();
    csAPCLithoContextInfo_struct*& out();
    csAPCLithoContextInfo_struct* _retn();

    operator csAPCLithoContextInfo_struct_cvPtr () const;

    operator csAPCLithoContextInfo_struct_vPtr& ();

    operator const csAPCLithoContextInfo_struct& () const;

    operator csAPCLithoContextInfo_struct& ();

    protected:
    csAPCLithoContextInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csAPCLithoContextInfo_struct;
    typedef csAPCLithoContextInfo_struct csAPCLithoContextInfo;
    typedef csAPCLithoContextInfo_struct_var csAPCLithoContextInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csAPCLithoContextInfo;
    class  csLotInCassette_siInfo_struct_var;
    struct  csLotInCassette_siInfo_struct {
        typedef csLotInCassette_siInfo_struct_var _var_type;
       ::CORBA::String_StructElem stageID;
       ::CORBA::String_StructElem CJReserveUserID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csLotInCassette_siInfo_struct();
       csLotInCassette_siInfo_struct(const csLotInCassette_siInfo_struct&);
       csLotInCassette_siInfo_struct& operator=(const csLotInCassette_siInfo_struct&);
       static CORBA::Info<csLotInCassette_siInfo_struct> csLotInCassette_siInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csLotInCassette_siInfo_struct


typedef csLotInCassette_siInfo_struct* csLotInCassette_siInfo_struct_vPtr;
typedef const csLotInCassette_siInfo_struct* csLotInCassette_siInfo_struct_cvPtr;

class  csLotInCassette_siInfo_struct_var
{
    public:

    csLotInCassette_siInfo_struct_var ();

    csLotInCassette_siInfo_struct_var (csLotInCassette_siInfo_struct *_p);

    csLotInCassette_siInfo_struct_var (const csLotInCassette_siInfo_struct_var &_s);

    csLotInCassette_siInfo_struct_var &operator= (csLotInCassette_siInfo_struct *_p);

    csLotInCassette_siInfo_struct_var &operator= (const csLotInCassette_siInfo_struct_var &_s);

    ~csLotInCassette_siInfo_struct_var ();

    csLotInCassette_siInfo_struct* operator-> ();

    const csLotInCassette_siInfo_struct& in() const;
    csLotInCassette_siInfo_struct& inout();
    csLotInCassette_siInfo_struct*& out();
    csLotInCassette_siInfo_struct* _retn();

    operator csLotInCassette_siInfo_struct_cvPtr () const;

    operator csLotInCassette_siInfo_struct_vPtr& ();

    operator const csLotInCassette_siInfo_struct& () const;

    operator csLotInCassette_siInfo_struct& ();

    protected:
    csLotInCassette_siInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csLotInCassette_siInfo_struct;
    typedef csLotInCassette_siInfo_struct csLotInCassette_siInfo;
    typedef csLotInCassette_siInfo_struct_var csLotInCassette_siInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csLotInCassette_siInfo;
    class  csLotWafer_siInfo_struct_var;
    struct  csLotWafer_siInfo_struct {
        typedef csLotWafer_siInfo_struct_var _var_type;
       ::CORBA::Long touchCountByFixture;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csLotWafer_siInfo_struct();
       csLotWafer_siInfo_struct(const csLotWafer_siInfo_struct&);
       csLotWafer_siInfo_struct& operator=(const csLotWafer_siInfo_struct&);
       static CORBA::Info<csLotWafer_siInfo_struct> csLotWafer_siInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csLotWafer_siInfo_struct


typedef csLotWafer_siInfo_struct* csLotWafer_siInfo_struct_vPtr;
typedef const csLotWafer_siInfo_struct* csLotWafer_siInfo_struct_cvPtr;

class  csLotWafer_siInfo_struct_var
{
    public:

    csLotWafer_siInfo_struct_var ();

    csLotWafer_siInfo_struct_var (csLotWafer_siInfo_struct *_p);

    csLotWafer_siInfo_struct_var (const csLotWafer_siInfo_struct_var &_s);

    csLotWafer_siInfo_struct_var &operator= (csLotWafer_siInfo_struct *_p);

    csLotWafer_siInfo_struct_var &operator= (const csLotWafer_siInfo_struct_var &_s);

    ~csLotWafer_siInfo_struct_var ();

    csLotWafer_siInfo_struct* operator-> ();

    const csLotWafer_siInfo_struct& in() const;
    csLotWafer_siInfo_struct& inout();
    csLotWafer_siInfo_struct*& out();
    csLotWafer_siInfo_struct* _retn();

    operator csLotWafer_siInfo_struct_cvPtr () const;

    operator csLotWafer_siInfo_struct_vPtr& ();

    operator const csLotWafer_siInfo_struct& () const;

    operator csLotWafer_siInfo_struct& ();

    protected:
    csLotWafer_siInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csLotWafer_siInfo_struct;
    typedef csLotWafer_siInfo_struct csLotWafer_siInfo;
    typedef csLotWafer_siInfo_struct_var csLotWafer_siInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csLotWafer_siInfo;
    class  csEqpInfoForDurableDeliveryWatchdog_struct_var;
    struct  csEqpInfoForDurableDeliveryWatchdog_struct {
        typedef csEqpInfoForDurableDeliveryWatchdog_struct_var _var_type;
       ::objectIdentifier equipmentID;
       ::CORBA::String_StructElem category;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpInfoForDurableDeliveryWatchdog_struct();
       csEqpInfoForDurableDeliveryWatchdog_struct(const csEqpInfoForDurableDeliveryWatchdog_struct&);
       csEqpInfoForDurableDeliveryWatchdog_struct& operator=(const csEqpInfoForDurableDeliveryWatchdog_struct&);
       static CORBA::Info<csEqpInfoForDurableDeliveryWatchdog_struct> csEqpInfoForDurableDeliveryWatchdog_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpInfoForDurableDeliveryWatchdog_struct


typedef csEqpInfoForDurableDeliveryWatchdog_struct* csEqpInfoForDurableDeliveryWatchdog_struct_vPtr;
typedef const csEqpInfoForDurableDeliveryWatchdog_struct* csEqpInfoForDurableDeliveryWatchdog_struct_cvPtr;

class  csEqpInfoForDurableDeliveryWatchdog_struct_var
{
    public:

    csEqpInfoForDurableDeliveryWatchdog_struct_var ();

    csEqpInfoForDurableDeliveryWatchdog_struct_var (csEqpInfoForDurableDeliveryWatchdog_struct *_p);

    csEqpInfoForDurableDeliveryWatchdog_struct_var (const csEqpInfoForDurableDeliveryWatchdog_struct_var &_s);

    csEqpInfoForDurableDeliveryWatchdog_struct_var &operator= (csEqpInfoForDurableDeliveryWatchdog_struct *_p);

    csEqpInfoForDurableDeliveryWatchdog_struct_var &operator= (const csEqpInfoForDurableDeliveryWatchdog_struct_var &_s);

    ~csEqpInfoForDurableDeliveryWatchdog_struct_var ();

    csEqpInfoForDurableDeliveryWatchdog_struct* operator-> ();

    const csEqpInfoForDurableDeliveryWatchdog_struct& in() const;
    csEqpInfoForDurableDeliveryWatchdog_struct& inout();
    csEqpInfoForDurableDeliveryWatchdog_struct*& out();
    csEqpInfoForDurableDeliveryWatchdog_struct* _retn();

    operator csEqpInfoForDurableDeliveryWatchdog_struct_cvPtr () const;

    operator csEqpInfoForDurableDeliveryWatchdog_struct_vPtr& ();

    operator const csEqpInfoForDurableDeliveryWatchdog_struct& () const;

    operator csEqpInfoForDurableDeliveryWatchdog_struct& ();

    protected:
    csEqpInfoForDurableDeliveryWatchdog_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpInfoForDurableDeliveryWatchdog_struct;
    typedef csEqpInfoForDurableDeliveryWatchdog_struct csEqpInfoForDurableDeliveryWatchdog;
    typedef csEqpInfoForDurableDeliveryWatchdog_struct_var csEqpInfoForDurableDeliveryWatchdog_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpInfoForDurableDeliveryWatchdog;
class  _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0_var;
class  _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0 {
    public:
        typedef _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csEqpInfoForDurableDeliveryWatchdog *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0 ();
    _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csEqpInfoForDurableDeliveryWatchdog* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0 (const _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0&);

    ~_IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0 ();

    _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0& operator= (const _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csEqpInfoForDurableDeliveryWatchdog& operator [] (::CORBA::ULong indx);
    const csEqpInfoForDurableDeliveryWatchdog& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csEqpInfoForDurableDeliveryWatchdog* get_buffer (::CORBA::Boolean orphan=0);
    const csEqpInfoForDurableDeliveryWatchdog* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csEqpInfoForDurableDeliveryWatchdog* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csEqpInfoForDurableDeliveryWatchdog* src, csEqpInfoForDurableDeliveryWatchdog* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csEqpInfoForDurableDeliveryWatchdog* data); 
  public:

    static csEqpInfoForDurableDeliveryWatchdog* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csEqpInfoForDurableDeliveryWatchdog* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csEqpInfoForDurableDeliveryWatchdog* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0> csEqpInfoForDurableDeliveryWatchdogSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0* _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0_vPtr;
typedef const _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0* _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0_cvPtr;

class  _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0_var
{
    public:

    _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0_var ();

    _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0_var (_IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0 *_p);

    _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0_var (const _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0_var &_s);

    _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0_var &operator= (_IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0 *_p);

    _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0_var &operator= (const _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0_var &_s);

    ~_IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0_var ();

    _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0* operator-> ();

    operator _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0_cvPtr () const;

    operator _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0_vPtr& ();

    operator _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0() const;

    const csEqpInfoForDurableDeliveryWatchdog& operator[] (::CORBA::ULong index) const;
    csEqpInfoForDurableDeliveryWatchdog& operator[] (::CORBA::ULong index);
    const csEqpInfoForDurableDeliveryWatchdog& operator[] (int index) const;
    csEqpInfoForDurableDeliveryWatchdog& operator[] (int index);
    const _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0& in() const;
    _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0& inout();
    _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0*& out();
    _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0* _retn();

    protected:
    _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0 _csEqpInfoForDurableDeliveryWatchdogSequence_seq;
    typedef _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0 _csEqpInfoForDurableDeliveryWatchdogSequence_seq_1;
    typedef _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0 csEqpInfoForDurableDeliveryWatchdogSequence;
    typedef _IDL_SEQ_csEqpInfoForDurableDeliveryWatchdogSequence_0_var csEqpInfoForDurableDeliveryWatchdogSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpInfoForDurableDeliveryWatchdogSequence;
    typedef pptBaseResult csLotComplicatedHoldReqResult;
    typedef pptBaseResult_var csLotComplicatedHoldReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csLotComplicatedHoldReqResult;
    class  csFutureHoldInfo_struct_var;
    struct  csFutureHoldInfo_struct {
        typedef csFutureHoldInfo_struct_var _var_type;
       ::objectIdentifier routeID;
       ::CORBA::String_StructElem operationNumber;
       ::CORBA::Boolean postFlag;
       ::CORBA::Boolean singleTriggerFlag;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csFutureHoldInfo_struct();
       csFutureHoldInfo_struct(const csFutureHoldInfo_struct&);
       csFutureHoldInfo_struct& operator=(const csFutureHoldInfo_struct&);
       static CORBA::Info<csFutureHoldInfo_struct> csFutureHoldInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csFutureHoldInfo_struct


typedef csFutureHoldInfo_struct* csFutureHoldInfo_struct_vPtr;
typedef const csFutureHoldInfo_struct* csFutureHoldInfo_struct_cvPtr;

class  csFutureHoldInfo_struct_var
{
    public:

    csFutureHoldInfo_struct_var ();

    csFutureHoldInfo_struct_var (csFutureHoldInfo_struct *_p);

    csFutureHoldInfo_struct_var (const csFutureHoldInfo_struct_var &_s);

    csFutureHoldInfo_struct_var &operator= (csFutureHoldInfo_struct *_p);

    csFutureHoldInfo_struct_var &operator= (const csFutureHoldInfo_struct_var &_s);

    ~csFutureHoldInfo_struct_var ();

    csFutureHoldInfo_struct* operator-> ();

    const csFutureHoldInfo_struct& in() const;
    csFutureHoldInfo_struct& inout();
    csFutureHoldInfo_struct*& out();
    csFutureHoldInfo_struct* _retn();

    operator csFutureHoldInfo_struct_cvPtr () const;

    operator csFutureHoldInfo_struct_vPtr& ();

    operator const csFutureHoldInfo_struct& () const;

    operator csFutureHoldInfo_struct& ();

    protected:
    csFutureHoldInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csFutureHoldInfo_struct;
    typedef csFutureHoldInfo_struct csFutureHoldInfo;
    typedef csFutureHoldInfo_struct_var csFutureHoldInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csFutureHoldInfo;
    class  csLotComplicatedHoldReqInParam_struct_var;
    struct  csLotComplicatedHoldReqInParam_struct {
        typedef csLotComplicatedHoldReqInParam_struct_var _var_type;
       ::objectIdentifierSequence lotIDs;
       ::objectIdentifier reasonCode;
       ::CORBA::String_StructElem action;
       ::objectIdentifier relatedLotID;
       ::csFutureHoldInfo strFutureHoldInfo;
       ::CORBA::String_StructElem claimMemo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csLotComplicatedHoldReqInParam_struct();
       csLotComplicatedHoldReqInParam_struct(const csLotComplicatedHoldReqInParam_struct&);
       csLotComplicatedHoldReqInParam_struct& operator=(const csLotComplicatedHoldReqInParam_struct&);
       static CORBA::Info<csLotComplicatedHoldReqInParam_struct> csLotComplicatedHoldReqInParam_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csLotComplicatedHoldReqInParam_struct


typedef csLotComplicatedHoldReqInParam_struct* csLotComplicatedHoldReqInParam_struct_vPtr;
typedef const csLotComplicatedHoldReqInParam_struct* csLotComplicatedHoldReqInParam_struct_cvPtr;

class  csLotComplicatedHoldReqInParam_struct_var
{
    public:

    csLotComplicatedHoldReqInParam_struct_var ();

    csLotComplicatedHoldReqInParam_struct_var (csLotComplicatedHoldReqInParam_struct *_p);

    csLotComplicatedHoldReqInParam_struct_var (const csLotComplicatedHoldReqInParam_struct_var &_s);

    csLotComplicatedHoldReqInParam_struct_var &operator= (csLotComplicatedHoldReqInParam_struct *_p);

    csLotComplicatedHoldReqInParam_struct_var &operator= (const csLotComplicatedHoldReqInParam_struct_var &_s);

    ~csLotComplicatedHoldReqInParam_struct_var ();

    csLotComplicatedHoldReqInParam_struct* operator-> ();

    const csLotComplicatedHoldReqInParam_struct& in() const;
    csLotComplicatedHoldReqInParam_struct& inout();
    csLotComplicatedHoldReqInParam_struct*& out();
    csLotComplicatedHoldReqInParam_struct* _retn();

    operator csLotComplicatedHoldReqInParam_struct_cvPtr () const;

    operator csLotComplicatedHoldReqInParam_struct_vPtr& ();

    operator const csLotComplicatedHoldReqInParam_struct& () const;

    operator csLotComplicatedHoldReqInParam_struct& ();

    protected:
    csLotComplicatedHoldReqInParam_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csLotComplicatedHoldReqInParam_struct;
    typedef csLotComplicatedHoldReqInParam_struct csLotComplicatedHoldReqInParam;
    typedef csLotComplicatedHoldReqInParam_struct_var csLotComplicatedHoldReqInParam_var;
    extern  ::CORBA::TypeCode_ptr _tc_csLotComplicatedHoldReqInParam;
    class  csAPCEventQueue_struct_var;
    struct  csAPCEventQueue_struct {
        typedef csAPCEventQueue_struct_var _var_type;
       ::CORBA::String_StructElem eventID;
       ::objectIdentifier lotID;
       ::objectIdentifier controlJobID;
       ::CORBA::String_StructElem eventTime;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csAPCEventQueue_struct();
       csAPCEventQueue_struct(const csAPCEventQueue_struct&);
       csAPCEventQueue_struct& operator=(const csAPCEventQueue_struct&);
       static CORBA::Info<csAPCEventQueue_struct> csAPCEventQueue_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csAPCEventQueue_struct


typedef csAPCEventQueue_struct* csAPCEventQueue_struct_vPtr;
typedef const csAPCEventQueue_struct* csAPCEventQueue_struct_cvPtr;

class  csAPCEventQueue_struct_var
{
    public:

    csAPCEventQueue_struct_var ();

    csAPCEventQueue_struct_var (csAPCEventQueue_struct *_p);

    csAPCEventQueue_struct_var (const csAPCEventQueue_struct_var &_s);

    csAPCEventQueue_struct_var &operator= (csAPCEventQueue_struct *_p);

    csAPCEventQueue_struct_var &operator= (const csAPCEventQueue_struct_var &_s);

    ~csAPCEventQueue_struct_var ();

    csAPCEventQueue_struct* operator-> ();

    const csAPCEventQueue_struct& in() const;
    csAPCEventQueue_struct& inout();
    csAPCEventQueue_struct*& out();
    csAPCEventQueue_struct* _retn();

    operator csAPCEventQueue_struct_cvPtr () const;

    operator csAPCEventQueue_struct_vPtr& ();

    operator const csAPCEventQueue_struct& () const;

    operator csAPCEventQueue_struct& ();

    protected:
    csAPCEventQueue_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csAPCEventQueue_struct;
    typedef csAPCEventQueue_struct csAPCEventQueue;
    typedef csAPCEventQueue_struct_var csAPCEventQueue_var;
    extern  ::CORBA::TypeCode_ptr _tc_csAPCEventQueue;
class  _IDL_SEQ_csAPCEventQueueSequence_0_var;
class  _IDL_SEQ_csAPCEventQueueSequence_0 {
    public:
        typedef _IDL_SEQ_csAPCEventQueueSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csAPCEventQueue *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csAPCEventQueueSequence_0 ();
    _IDL_SEQ_csAPCEventQueueSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csAPCEventQueueSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csAPCEventQueue* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csAPCEventQueueSequence_0 (const _IDL_SEQ_csAPCEventQueueSequence_0&);

    ~_IDL_SEQ_csAPCEventQueueSequence_0 ();

    _IDL_SEQ_csAPCEventQueueSequence_0& operator= (const _IDL_SEQ_csAPCEventQueueSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csAPCEventQueue& operator [] (::CORBA::ULong indx);
    const csAPCEventQueue& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csAPCEventQueue* get_buffer (::CORBA::Boolean orphan=0);
    const csAPCEventQueue* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csAPCEventQueue* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csAPCEventQueue* src, csAPCEventQueue* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csAPCEventQueue* data); 
  public:

    static csAPCEventQueue* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csAPCEventQueue* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csAPCEventQueue* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csAPCEventQueueSequence_0> csAPCEventQueueSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csAPCEventQueueSequence_0* _IDL_SEQ_csAPCEventQueueSequence_0_vPtr;
typedef const _IDL_SEQ_csAPCEventQueueSequence_0* _IDL_SEQ_csAPCEventQueueSequence_0_cvPtr;

class  _IDL_SEQ_csAPCEventQueueSequence_0_var
{
    public:

    _IDL_SEQ_csAPCEventQueueSequence_0_var ();

    _IDL_SEQ_csAPCEventQueueSequence_0_var (_IDL_SEQ_csAPCEventQueueSequence_0 *_p);

    _IDL_SEQ_csAPCEventQueueSequence_0_var (const _IDL_SEQ_csAPCEventQueueSequence_0_var &_s);

    _IDL_SEQ_csAPCEventQueueSequence_0_var &operator= (_IDL_SEQ_csAPCEventQueueSequence_0 *_p);

    _IDL_SEQ_csAPCEventQueueSequence_0_var &operator= (const _IDL_SEQ_csAPCEventQueueSequence_0_var &_s);

    ~_IDL_SEQ_csAPCEventQueueSequence_0_var ();

    _IDL_SEQ_csAPCEventQueueSequence_0* operator-> ();

    operator _IDL_SEQ_csAPCEventQueueSequence_0_cvPtr () const;

    operator _IDL_SEQ_csAPCEventQueueSequence_0_vPtr& ();

    operator _IDL_SEQ_csAPCEventQueueSequence_0() const;

    const csAPCEventQueue& operator[] (::CORBA::ULong index) const;
    csAPCEventQueue& operator[] (::CORBA::ULong index);
    const csAPCEventQueue& operator[] (int index) const;
    csAPCEventQueue& operator[] (int index);
    const _IDL_SEQ_csAPCEventQueueSequence_0& in() const;
    _IDL_SEQ_csAPCEventQueueSequence_0& inout();
    _IDL_SEQ_csAPCEventQueueSequence_0*& out();
    _IDL_SEQ_csAPCEventQueueSequence_0* _retn();

    protected:
    _IDL_SEQ_csAPCEventQueueSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csAPCEventQueueSequence_0 _csAPCEventQueueSequence_seq;
    typedef _IDL_SEQ_csAPCEventQueueSequence_0 _csAPCEventQueueSequence_seq_1;
    typedef _IDL_SEQ_csAPCEventQueueSequence_0 csAPCEventQueueSequence;
    typedef _IDL_SEQ_csAPCEventQueueSequence_0_var csAPCEventQueueSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csAPCEventQueueSequence;
    class  csEqpMonitorInventoryInfo_struct_var;
    struct  csEqpMonitorInventoryInfo_struct {
        typedef csEqpMonitorInventoryInfo_struct_var _var_type;
       ::CORBA::String_StructElem productID;
       ::CORBA::String_StructElem subLotType;
       ::CORBA::String_StructElem npwType;
       ::CORBA::String_StructElem routeID;
       ::CORBA::String_StructElem startBankID;
       ::CORBA::String_StructElem startBWSID;
       ::stringSequence startBWSIDSeq;
       ::CORBA::String_StructElem endBankID;
       ::CORBA::String_StructElem endBWSID;
       ::CORBA::Long targetQty;
       ::CORBA::Long currentQty;
       ::CORBA::Long currentSourceQty;
       ::CORBA::Long useCountLimit;
       ::CORBA::Boolean autoSTB;
       ::CORBA::String_StructElem message;
       ::CORBA::String_StructElem claimUserID;
       ::CORBA::String_StructElem claimTime;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpMonitorInventoryInfo_struct();
       csEqpMonitorInventoryInfo_struct(const csEqpMonitorInventoryInfo_struct&);
       csEqpMonitorInventoryInfo_struct& operator=(const csEqpMonitorInventoryInfo_struct&);
       static CORBA::Info<csEqpMonitorInventoryInfo_struct> csEqpMonitorInventoryInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpMonitorInventoryInfo_struct


typedef csEqpMonitorInventoryInfo_struct* csEqpMonitorInventoryInfo_struct_vPtr;
typedef const csEqpMonitorInventoryInfo_struct* csEqpMonitorInventoryInfo_struct_cvPtr;

class  csEqpMonitorInventoryInfo_struct_var
{
    public:

    csEqpMonitorInventoryInfo_struct_var ();

    csEqpMonitorInventoryInfo_struct_var (csEqpMonitorInventoryInfo_struct *_p);

    csEqpMonitorInventoryInfo_struct_var (const csEqpMonitorInventoryInfo_struct_var &_s);

    csEqpMonitorInventoryInfo_struct_var &operator= (csEqpMonitorInventoryInfo_struct *_p);

    csEqpMonitorInventoryInfo_struct_var &operator= (const csEqpMonitorInventoryInfo_struct_var &_s);

    ~csEqpMonitorInventoryInfo_struct_var ();

    csEqpMonitorInventoryInfo_struct* operator-> ();

    const csEqpMonitorInventoryInfo_struct& in() const;
    csEqpMonitorInventoryInfo_struct& inout();
    csEqpMonitorInventoryInfo_struct*& out();
    csEqpMonitorInventoryInfo_struct* _retn();

    operator csEqpMonitorInventoryInfo_struct_cvPtr () const;

    operator csEqpMonitorInventoryInfo_struct_vPtr& ();

    operator const csEqpMonitorInventoryInfo_struct& () const;

    operator csEqpMonitorInventoryInfo_struct& ();

    protected:
    csEqpMonitorInventoryInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorInventoryInfo_struct;
    typedef csEqpMonitorInventoryInfo_struct csEqpMonitorInventoryInfo;
    typedef csEqpMonitorInventoryInfo_struct_var csEqpMonitorInventoryInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorInventoryInfo;
class  _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0_var;
class  _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0 {
    public:
        typedef _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csEqpMonitorInventoryInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0 ();
    _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csEqpMonitorInventoryInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0 (const _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0&);

    ~_IDL_SEQ_csEqpMonitorInventoryInfoSequence_0 ();

    _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0& operator= (const _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csEqpMonitorInventoryInfo& operator [] (::CORBA::ULong indx);
    const csEqpMonitorInventoryInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csEqpMonitorInventoryInfo* get_buffer (::CORBA::Boolean orphan=0);
    const csEqpMonitorInventoryInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csEqpMonitorInventoryInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csEqpMonitorInventoryInfo* src, csEqpMonitorInventoryInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csEqpMonitorInventoryInfo* data); 
  public:

    static csEqpMonitorInventoryInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csEqpMonitorInventoryInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csEqpMonitorInventoryInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csEqpMonitorInventoryInfoSequence_0> csEqpMonitorInventoryInfoSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0* _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0_vPtr;
typedef const _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0* _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0_cvPtr;

class  _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0_var
{
    public:

    _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0_var ();

    _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0_var (_IDL_SEQ_csEqpMonitorInventoryInfoSequence_0 *_p);

    _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0_var (const _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0_var &_s);

    _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0_var &operator= (_IDL_SEQ_csEqpMonitorInventoryInfoSequence_0 *_p);

    _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0_var &operator= (const _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0_var &_s);

    ~_IDL_SEQ_csEqpMonitorInventoryInfoSequence_0_var ();

    _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0* operator-> ();

    operator _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0_cvPtr () const;

    operator _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0_vPtr& ();

    operator _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0() const;

    const csEqpMonitorInventoryInfo& operator[] (::CORBA::ULong index) const;
    csEqpMonitorInventoryInfo& operator[] (::CORBA::ULong index);
    const csEqpMonitorInventoryInfo& operator[] (int index) const;
    csEqpMonitorInventoryInfo& operator[] (int index);
    const _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0& in() const;
    _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0& inout();
    _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0*& out();
    _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0* _retn();

    protected:
    _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0 _csEqpMonitorInventoryInfoSequence_seq;
    typedef _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0 _csEqpMonitorInventoryInfoSequence_seq_1;
    typedef _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0 csEqpMonitorInventoryInfoSequence;
    typedef _IDL_SEQ_csEqpMonitorInventoryInfoSequence_0_var csEqpMonitorInventoryInfoSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorInventoryInfoSequence;
    class  csEqpMonitorInventoryListInqInParm_struct_var;
    struct  csEqpMonitorInventoryListInqInParm_struct {
        typedef csEqpMonitorInventoryListInqInParm_struct_var _var_type;
       ::CORBA::String_StructElem npwType;
       ::CORBA::String_StructElem productID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpMonitorInventoryListInqInParm_struct();
       csEqpMonitorInventoryListInqInParm_struct(const csEqpMonitorInventoryListInqInParm_struct&);
       csEqpMonitorInventoryListInqInParm_struct& operator=(const csEqpMonitorInventoryListInqInParm_struct&);
       static CORBA::Info<csEqpMonitorInventoryListInqInParm_struct> csEqpMonitorInventoryListInqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csEqpMonitorInventoryListInqInParm_struct


typedef csEqpMonitorInventoryListInqInParm_struct* csEqpMonitorInventoryListInqInParm_struct_vPtr;
typedef const csEqpMonitorInventoryListInqInParm_struct* csEqpMonitorInventoryListInqInParm_struct_cvPtr;

class  csEqpMonitorInventoryListInqInParm_struct_var
{
    public:

    csEqpMonitorInventoryListInqInParm_struct_var ();

    csEqpMonitorInventoryListInqInParm_struct_var (csEqpMonitorInventoryListInqInParm_struct *_p);

    csEqpMonitorInventoryListInqInParm_struct_var (const csEqpMonitorInventoryListInqInParm_struct_var &_s);

    csEqpMonitorInventoryListInqInParm_struct_var &operator= (csEqpMonitorInventoryListInqInParm_struct *_p);

    csEqpMonitorInventoryListInqInParm_struct_var &operator= (const csEqpMonitorInventoryListInqInParm_struct_var &_s);

    ~csEqpMonitorInventoryListInqInParm_struct_var ();

    csEqpMonitorInventoryListInqInParm_struct* operator-> ();

    const csEqpMonitorInventoryListInqInParm_struct& in() const;
    csEqpMonitorInventoryListInqInParm_struct& inout();
    csEqpMonitorInventoryListInqInParm_struct*& out();
    csEqpMonitorInventoryListInqInParm_struct* _retn();

    operator csEqpMonitorInventoryListInqInParm_struct_cvPtr () const;

    operator csEqpMonitorInventoryListInqInParm_struct_vPtr& ();

    operator const csEqpMonitorInventoryListInqInParm_struct& () const;

    operator csEqpMonitorInventoryListInqInParm_struct& ();

    protected:
    csEqpMonitorInventoryListInqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorInventoryListInqInParm_struct;
    typedef csEqpMonitorInventoryListInqInParm_struct csEqpMonitorInventoryListInqInParm;
    typedef csEqpMonitorInventoryListInqInParm_struct_var csEqpMonitorInventoryListInqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorInventoryListInqInParm;
    class  csEqpMonitorInventoryListInqResult_struct_var;
    struct  csEqpMonitorInventoryListInqResult_struct {
        typedef csEqpMonitorInventoryListInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::CORBA::String_StructElem npwType;
       ::csEqpMonitorInventoryInfoSequence strEqpMonitorInventoryInfoSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpMonitorInventoryListInqResult_struct();
       csEqpMonitorInventoryListInqResult_struct(const csEqpMonitorInventoryListInqResult_struct&);
       csEqpMonitorInventoryListInqResult_struct& operator=(const csEqpMonitorInventoryListInqResult_struct&);
       static CORBA::Info<csEqpMonitorInventoryListInqResult_struct> csEqpMonitorInventoryListInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpMonitorInventoryListInqResult_struct


typedef csEqpMonitorInventoryListInqResult_struct* csEqpMonitorInventoryListInqResult_struct_vPtr;
typedef const csEqpMonitorInventoryListInqResult_struct* csEqpMonitorInventoryListInqResult_struct_cvPtr;

class  csEqpMonitorInventoryListInqResult_struct_var
{
    public:

    csEqpMonitorInventoryListInqResult_struct_var ();

    csEqpMonitorInventoryListInqResult_struct_var (csEqpMonitorInventoryListInqResult_struct *_p);

    csEqpMonitorInventoryListInqResult_struct_var (const csEqpMonitorInventoryListInqResult_struct_var &_s);

    csEqpMonitorInventoryListInqResult_struct_var &operator= (csEqpMonitorInventoryListInqResult_struct *_p);

    csEqpMonitorInventoryListInqResult_struct_var &operator= (const csEqpMonitorInventoryListInqResult_struct_var &_s);

    ~csEqpMonitorInventoryListInqResult_struct_var ();

    csEqpMonitorInventoryListInqResult_struct* operator-> ();

    const csEqpMonitorInventoryListInqResult_struct& in() const;
    csEqpMonitorInventoryListInqResult_struct& inout();
    csEqpMonitorInventoryListInqResult_struct*& out();
    csEqpMonitorInventoryListInqResult_struct* _retn();

    operator csEqpMonitorInventoryListInqResult_struct_cvPtr () const;

    operator csEqpMonitorInventoryListInqResult_struct_vPtr& ();

    operator const csEqpMonitorInventoryListInqResult_struct& () const;

    operator csEqpMonitorInventoryListInqResult_struct& ();

    protected:
    csEqpMonitorInventoryListInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorInventoryListInqResult_struct;
    typedef csEqpMonitorInventoryListInqResult_struct csEqpMonitorInventoryListInqResult;
    typedef csEqpMonitorInventoryListInqResult_struct_var csEqpMonitorInventoryListInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorInventoryListInqResult;
    class  csEqpMonitorInventoryUpdateReqInParm_struct_var;
    struct  csEqpMonitorInventoryUpdateReqInParm_struct {
        typedef csEqpMonitorInventoryUpdateReqInParm_struct_var _var_type;
       ::CORBA::String_StructElem actionCode;
       ::csEqpMonitorInventoryInfo strEqpMonitorInventoryInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpMonitorInventoryUpdateReqInParm_struct();
       csEqpMonitorInventoryUpdateReqInParm_struct(const csEqpMonitorInventoryUpdateReqInParm_struct&);
       csEqpMonitorInventoryUpdateReqInParm_struct& operator=(const csEqpMonitorInventoryUpdateReqInParm_struct&);
       static CORBA::Info<csEqpMonitorInventoryUpdateReqInParm_struct> csEqpMonitorInventoryUpdateReqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpMonitorInventoryUpdateReqInParm_struct


typedef csEqpMonitorInventoryUpdateReqInParm_struct* csEqpMonitorInventoryUpdateReqInParm_struct_vPtr;
typedef const csEqpMonitorInventoryUpdateReqInParm_struct* csEqpMonitorInventoryUpdateReqInParm_struct_cvPtr;

class  csEqpMonitorInventoryUpdateReqInParm_struct_var
{
    public:

    csEqpMonitorInventoryUpdateReqInParm_struct_var ();

    csEqpMonitorInventoryUpdateReqInParm_struct_var (csEqpMonitorInventoryUpdateReqInParm_struct *_p);

    csEqpMonitorInventoryUpdateReqInParm_struct_var (const csEqpMonitorInventoryUpdateReqInParm_struct_var &_s);

    csEqpMonitorInventoryUpdateReqInParm_struct_var &operator= (csEqpMonitorInventoryUpdateReqInParm_struct *_p);

    csEqpMonitorInventoryUpdateReqInParm_struct_var &operator= (const csEqpMonitorInventoryUpdateReqInParm_struct_var &_s);

    ~csEqpMonitorInventoryUpdateReqInParm_struct_var ();

    csEqpMonitorInventoryUpdateReqInParm_struct* operator-> ();

    const csEqpMonitorInventoryUpdateReqInParm_struct& in() const;
    csEqpMonitorInventoryUpdateReqInParm_struct& inout();
    csEqpMonitorInventoryUpdateReqInParm_struct*& out();
    csEqpMonitorInventoryUpdateReqInParm_struct* _retn();

    operator csEqpMonitorInventoryUpdateReqInParm_struct_cvPtr () const;

    operator csEqpMonitorInventoryUpdateReqInParm_struct_vPtr& ();

    operator const csEqpMonitorInventoryUpdateReqInParm_struct& () const;

    operator csEqpMonitorInventoryUpdateReqInParm_struct& ();

    protected:
    csEqpMonitorInventoryUpdateReqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorInventoryUpdateReqInParm_struct;
    typedef csEqpMonitorInventoryUpdateReqInParm_struct csEqpMonitorInventoryUpdateReqInParm;
    typedef csEqpMonitorInventoryUpdateReqInParm_struct_var csEqpMonitorInventoryUpdateReqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorInventoryUpdateReqInParm;
    typedef pptBaseResult csEqpMonitorInventoryUpdateReqResult;
    typedef pptBaseResult_var csEqpMonitorInventoryUpdateReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorInventoryUpdateReqResult;
    class  csBWSInfoForSTB_struct_var;
    struct  csBWSInfoForSTB_struct {
        typedef csBWSInfoForSTB_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::pptEqpPortStatusSequence strEqpPortStatus;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csBWSInfoForSTB_struct();
       csBWSInfoForSTB_struct(const csBWSInfoForSTB_struct&);
       csBWSInfoForSTB_struct& operator=(const csBWSInfoForSTB_struct&);
       static CORBA::Info<csBWSInfoForSTB_struct> csBWSInfoForSTB_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csBWSInfoForSTB_struct


typedef csBWSInfoForSTB_struct* csBWSInfoForSTB_struct_vPtr;
typedef const csBWSInfoForSTB_struct* csBWSInfoForSTB_struct_cvPtr;

class  csBWSInfoForSTB_struct_var
{
    public:

    csBWSInfoForSTB_struct_var ();

    csBWSInfoForSTB_struct_var (csBWSInfoForSTB_struct *_p);

    csBWSInfoForSTB_struct_var (const csBWSInfoForSTB_struct_var &_s);

    csBWSInfoForSTB_struct_var &operator= (csBWSInfoForSTB_struct *_p);

    csBWSInfoForSTB_struct_var &operator= (const csBWSInfoForSTB_struct_var &_s);

    ~csBWSInfoForSTB_struct_var ();

    csBWSInfoForSTB_struct* operator-> ();

    const csBWSInfoForSTB_struct& in() const;
    csBWSInfoForSTB_struct& inout();
    csBWSInfoForSTB_struct*& out();
    csBWSInfoForSTB_struct* _retn();

    operator csBWSInfoForSTB_struct_cvPtr () const;

    operator csBWSInfoForSTB_struct_vPtr& ();

    operator const csBWSInfoForSTB_struct& () const;

    operator csBWSInfoForSTB_struct& ();

    protected:
    csBWSInfoForSTB_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csBWSInfoForSTB_struct;
    typedef csBWSInfoForSTB_struct csBWSInfoForSTB;
    typedef csBWSInfoForSTB_struct_var csBWSInfoForSTB_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSInfoForSTB;
class  _IDL_SEQ_csBWSInfoForSTBSequence_0_var;
class  _IDL_SEQ_csBWSInfoForSTBSequence_0 {
    public:
        typedef _IDL_SEQ_csBWSInfoForSTBSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csBWSInfoForSTB *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csBWSInfoForSTBSequence_0 ();
    _IDL_SEQ_csBWSInfoForSTBSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csBWSInfoForSTBSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csBWSInfoForSTB* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csBWSInfoForSTBSequence_0 (const _IDL_SEQ_csBWSInfoForSTBSequence_0&);

    ~_IDL_SEQ_csBWSInfoForSTBSequence_0 ();

    _IDL_SEQ_csBWSInfoForSTBSequence_0& operator= (const _IDL_SEQ_csBWSInfoForSTBSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csBWSInfoForSTB& operator [] (::CORBA::ULong indx);
    const csBWSInfoForSTB& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csBWSInfoForSTB* get_buffer (::CORBA::Boolean orphan=0);
    const csBWSInfoForSTB* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csBWSInfoForSTB* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csBWSInfoForSTB* src, csBWSInfoForSTB* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csBWSInfoForSTB* data); 
  public:

    static csBWSInfoForSTB* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csBWSInfoForSTB* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csBWSInfoForSTB* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csBWSInfoForSTBSequence_0> csBWSInfoForSTBSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csBWSInfoForSTBSequence_0* _IDL_SEQ_csBWSInfoForSTBSequence_0_vPtr;
typedef const _IDL_SEQ_csBWSInfoForSTBSequence_0* _IDL_SEQ_csBWSInfoForSTBSequence_0_cvPtr;

class  _IDL_SEQ_csBWSInfoForSTBSequence_0_var
{
    public:

    _IDL_SEQ_csBWSInfoForSTBSequence_0_var ();

    _IDL_SEQ_csBWSInfoForSTBSequence_0_var (_IDL_SEQ_csBWSInfoForSTBSequence_0 *_p);

    _IDL_SEQ_csBWSInfoForSTBSequence_0_var (const _IDL_SEQ_csBWSInfoForSTBSequence_0_var &_s);

    _IDL_SEQ_csBWSInfoForSTBSequence_0_var &operator= (_IDL_SEQ_csBWSInfoForSTBSequence_0 *_p);

    _IDL_SEQ_csBWSInfoForSTBSequence_0_var &operator= (const _IDL_SEQ_csBWSInfoForSTBSequence_0_var &_s);

    ~_IDL_SEQ_csBWSInfoForSTBSequence_0_var ();

    _IDL_SEQ_csBWSInfoForSTBSequence_0* operator-> ();

    operator _IDL_SEQ_csBWSInfoForSTBSequence_0_cvPtr () const;

    operator _IDL_SEQ_csBWSInfoForSTBSequence_0_vPtr& ();

    operator _IDL_SEQ_csBWSInfoForSTBSequence_0() const;

    const csBWSInfoForSTB& operator[] (::CORBA::ULong index) const;
    csBWSInfoForSTB& operator[] (::CORBA::ULong index);
    const csBWSInfoForSTB& operator[] (int index) const;
    csBWSInfoForSTB& operator[] (int index);
    const _IDL_SEQ_csBWSInfoForSTBSequence_0& in() const;
    _IDL_SEQ_csBWSInfoForSTBSequence_0& inout();
    _IDL_SEQ_csBWSInfoForSTBSequence_0*& out();
    _IDL_SEQ_csBWSInfoForSTBSequence_0* _retn();

    protected:
    _IDL_SEQ_csBWSInfoForSTBSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csBWSInfoForSTBSequence_0 _csBWSInfoForSTBSequence_seq;
    typedef _IDL_SEQ_csBWSInfoForSTBSequence_0 _csBWSInfoForSTBSequence_seq_1;
    typedef _IDL_SEQ_csBWSInfoForSTBSequence_0 csBWSInfoForSTBSequence;
    typedef _IDL_SEQ_csBWSInfoForSTBSequence_0_var csBWSInfoForSTBSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSInfoForSTBSequence;
    class  csEqpMonitorSourceCandidateInfoInqInParm_struct_var;
    struct  csEqpMonitorSourceCandidateInfoInqInParm_struct {
        typedef csEqpMonitorSourceCandidateInfoInqInParm_struct_var _var_type;
       ::CORBA::String_StructElem npwType;
       ::objectIdentifier productID;
       ::CORBA::String_StructElem subLotType;
       ::objectIdentifier eqpMonitorID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpMonitorSourceCandidateInfoInqInParm_struct();
       csEqpMonitorSourceCandidateInfoInqInParm_struct(const csEqpMonitorSourceCandidateInfoInqInParm_struct&);
       csEqpMonitorSourceCandidateInfoInqInParm_struct& operator=(const csEqpMonitorSourceCandidateInfoInqInParm_struct&);
       static CORBA::Info<csEqpMonitorSourceCandidateInfoInqInParm_struct> csEqpMonitorSourceCandidateInfoInqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpMonitorSourceCandidateInfoInqInParm_struct


typedef csEqpMonitorSourceCandidateInfoInqInParm_struct* csEqpMonitorSourceCandidateInfoInqInParm_struct_vPtr;
typedef const csEqpMonitorSourceCandidateInfoInqInParm_struct* csEqpMonitorSourceCandidateInfoInqInParm_struct_cvPtr;

class  csEqpMonitorSourceCandidateInfoInqInParm_struct_var
{
    public:

    csEqpMonitorSourceCandidateInfoInqInParm_struct_var ();

    csEqpMonitorSourceCandidateInfoInqInParm_struct_var (csEqpMonitorSourceCandidateInfoInqInParm_struct *_p);

    csEqpMonitorSourceCandidateInfoInqInParm_struct_var (const csEqpMonitorSourceCandidateInfoInqInParm_struct_var &_s);

    csEqpMonitorSourceCandidateInfoInqInParm_struct_var &operator= (csEqpMonitorSourceCandidateInfoInqInParm_struct *_p);

    csEqpMonitorSourceCandidateInfoInqInParm_struct_var &operator= (const csEqpMonitorSourceCandidateInfoInqInParm_struct_var &_s);

    ~csEqpMonitorSourceCandidateInfoInqInParm_struct_var ();

    csEqpMonitorSourceCandidateInfoInqInParm_struct* operator-> ();

    const csEqpMonitorSourceCandidateInfoInqInParm_struct& in() const;
    csEqpMonitorSourceCandidateInfoInqInParm_struct& inout();
    csEqpMonitorSourceCandidateInfoInqInParm_struct*& out();
    csEqpMonitorSourceCandidateInfoInqInParm_struct* _retn();

    operator csEqpMonitorSourceCandidateInfoInqInParm_struct_cvPtr () const;

    operator csEqpMonitorSourceCandidateInfoInqInParm_struct_vPtr& ();

    operator const csEqpMonitorSourceCandidateInfoInqInParm_struct& () const;

    operator csEqpMonitorSourceCandidateInfoInqInParm_struct& ();

    protected:
    csEqpMonitorSourceCandidateInfoInqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorSourceCandidateInfoInqInParm_struct;
    typedef csEqpMonitorSourceCandidateInfoInqInParm_struct csEqpMonitorSourceCandidateInfoInqInParm;
    typedef csEqpMonitorSourceCandidateInfoInqInParm_struct_var csEqpMonitorSourceCandidateInfoInqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorSourceCandidateInfoInqInParm;
    class  csSourceProductInBWS_struct_var;
    struct  csSourceProductInBWS_struct {
        typedef csSourceProductInBWS_struct_var _var_type;
       ::objectIdentifier sourceProductID;
       ::CORBA::String_StructElem subLotType;
       ::objectIdentifier routeID;
       ::objectIdentifier startBankID;
       ::CORBA::Long availableWaferQty;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csSourceProductInBWS_struct();
       csSourceProductInBWS_struct(const csSourceProductInBWS_struct&);
       csSourceProductInBWS_struct& operator=(const csSourceProductInBWS_struct&);
       static CORBA::Info<csSourceProductInBWS_struct> csSourceProductInBWS_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csSourceProductInBWS_struct


typedef csSourceProductInBWS_struct* csSourceProductInBWS_struct_vPtr;
typedef const csSourceProductInBWS_struct* csSourceProductInBWS_struct_cvPtr;

class  csSourceProductInBWS_struct_var
{
    public:

    csSourceProductInBWS_struct_var ();

    csSourceProductInBWS_struct_var (csSourceProductInBWS_struct *_p);

    csSourceProductInBWS_struct_var (const csSourceProductInBWS_struct_var &_s);

    csSourceProductInBWS_struct_var &operator= (csSourceProductInBWS_struct *_p);

    csSourceProductInBWS_struct_var &operator= (const csSourceProductInBWS_struct_var &_s);

    ~csSourceProductInBWS_struct_var ();

    csSourceProductInBWS_struct* operator-> ();

    const csSourceProductInBWS_struct& in() const;
    csSourceProductInBWS_struct& inout();
    csSourceProductInBWS_struct*& out();
    csSourceProductInBWS_struct* _retn();

    operator csSourceProductInBWS_struct_cvPtr () const;

    operator csSourceProductInBWS_struct_vPtr& ();

    operator const csSourceProductInBWS_struct& () const;

    operator csSourceProductInBWS_struct& ();

    protected:
    csSourceProductInBWS_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csSourceProductInBWS_struct;
    typedef csSourceProductInBWS_struct csSourceProductInBWS;
    typedef csSourceProductInBWS_struct_var csSourceProductInBWS_var;
    extern  ::CORBA::TypeCode_ptr _tc_csSourceProductInBWS;
class  _IDL_SEQ_csSourceProductInBWSSequence_0_var;
class  _IDL_SEQ_csSourceProductInBWSSequence_0 {
    public:
        typedef _IDL_SEQ_csSourceProductInBWSSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csSourceProductInBWS *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csSourceProductInBWSSequence_0 ();
    _IDL_SEQ_csSourceProductInBWSSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csSourceProductInBWSSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csSourceProductInBWS* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csSourceProductInBWSSequence_0 (const _IDL_SEQ_csSourceProductInBWSSequence_0&);

    ~_IDL_SEQ_csSourceProductInBWSSequence_0 ();

    _IDL_SEQ_csSourceProductInBWSSequence_0& operator= (const _IDL_SEQ_csSourceProductInBWSSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csSourceProductInBWS& operator [] (::CORBA::ULong indx);
    const csSourceProductInBWS& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csSourceProductInBWS* get_buffer (::CORBA::Boolean orphan=0);
    const csSourceProductInBWS* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csSourceProductInBWS* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csSourceProductInBWS* src, csSourceProductInBWS* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csSourceProductInBWS* data); 
  public:

    static csSourceProductInBWS* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csSourceProductInBWS* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csSourceProductInBWS* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csSourceProductInBWSSequence_0> csSourceProductInBWSSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csSourceProductInBWSSequence_0* _IDL_SEQ_csSourceProductInBWSSequence_0_vPtr;
typedef const _IDL_SEQ_csSourceProductInBWSSequence_0* _IDL_SEQ_csSourceProductInBWSSequence_0_cvPtr;

class  _IDL_SEQ_csSourceProductInBWSSequence_0_var
{
    public:

    _IDL_SEQ_csSourceProductInBWSSequence_0_var ();

    _IDL_SEQ_csSourceProductInBWSSequence_0_var (_IDL_SEQ_csSourceProductInBWSSequence_0 *_p);

    _IDL_SEQ_csSourceProductInBWSSequence_0_var (const _IDL_SEQ_csSourceProductInBWSSequence_0_var &_s);

    _IDL_SEQ_csSourceProductInBWSSequence_0_var &operator= (_IDL_SEQ_csSourceProductInBWSSequence_0 *_p);

    _IDL_SEQ_csSourceProductInBWSSequence_0_var &operator= (const _IDL_SEQ_csSourceProductInBWSSequence_0_var &_s);

    ~_IDL_SEQ_csSourceProductInBWSSequence_0_var ();

    _IDL_SEQ_csSourceProductInBWSSequence_0* operator-> ();

    operator _IDL_SEQ_csSourceProductInBWSSequence_0_cvPtr () const;

    operator _IDL_SEQ_csSourceProductInBWSSequence_0_vPtr& ();

    operator _IDL_SEQ_csSourceProductInBWSSequence_0() const;

    const csSourceProductInBWS& operator[] (::CORBA::ULong index) const;
    csSourceProductInBWS& operator[] (::CORBA::ULong index);
    const csSourceProductInBWS& operator[] (int index) const;
    csSourceProductInBWS& operator[] (int index);
    const _IDL_SEQ_csSourceProductInBWSSequence_0& in() const;
    _IDL_SEQ_csSourceProductInBWSSequence_0& inout();
    _IDL_SEQ_csSourceProductInBWSSequence_0*& out();
    _IDL_SEQ_csSourceProductInBWSSequence_0* _retn();

    protected:
    _IDL_SEQ_csSourceProductInBWSSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csSourceProductInBWSSequence_0 _csSourceProductInBWSSequence_seq;
    typedef _IDL_SEQ_csSourceProductInBWSSequence_0 _csSourceProductInBWSSequence_seq_1;
    typedef _IDL_SEQ_csSourceProductInBWSSequence_0 csSourceProductInBWSSequence;
    typedef _IDL_SEQ_csSourceProductInBWSSequence_0_var csSourceProductInBWSSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csSourceProductInBWSSequence;
    class  csEqpMonitorSourceCandidateInfoInqResult_struct_var;
    struct  csEqpMonitorSourceCandidateInfoInqResult_struct {
        typedef csEqpMonitorSourceCandidateInfoInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::csEqpMonitorInventoryInfo strEqpMonitorInventoryInfo;
       ::csBWSInfoForSTBSequence strBWSInfoForSTBSeq;
       ::csSourceProductInBWSSequence sourceProductSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpMonitorSourceCandidateInfoInqResult_struct();
       csEqpMonitorSourceCandidateInfoInqResult_struct(const csEqpMonitorSourceCandidateInfoInqResult_struct&);
       csEqpMonitorSourceCandidateInfoInqResult_struct& operator=(const csEqpMonitorSourceCandidateInfoInqResult_struct&);
       static CORBA::Info<csEqpMonitorSourceCandidateInfoInqResult_struct> csEqpMonitorSourceCandidateInfoInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpMonitorSourceCandidateInfoInqResult_struct


typedef csEqpMonitorSourceCandidateInfoInqResult_struct* csEqpMonitorSourceCandidateInfoInqResult_struct_vPtr;
typedef const csEqpMonitorSourceCandidateInfoInqResult_struct* csEqpMonitorSourceCandidateInfoInqResult_struct_cvPtr;

class  csEqpMonitorSourceCandidateInfoInqResult_struct_var
{
    public:

    csEqpMonitorSourceCandidateInfoInqResult_struct_var ();

    csEqpMonitorSourceCandidateInfoInqResult_struct_var (csEqpMonitorSourceCandidateInfoInqResult_struct *_p);

    csEqpMonitorSourceCandidateInfoInqResult_struct_var (const csEqpMonitorSourceCandidateInfoInqResult_struct_var &_s);

    csEqpMonitorSourceCandidateInfoInqResult_struct_var &operator= (csEqpMonitorSourceCandidateInfoInqResult_struct *_p);

    csEqpMonitorSourceCandidateInfoInqResult_struct_var &operator= (const csEqpMonitorSourceCandidateInfoInqResult_struct_var &_s);

    ~csEqpMonitorSourceCandidateInfoInqResult_struct_var ();

    csEqpMonitorSourceCandidateInfoInqResult_struct* operator-> ();

    const csEqpMonitorSourceCandidateInfoInqResult_struct& in() const;
    csEqpMonitorSourceCandidateInfoInqResult_struct& inout();
    csEqpMonitorSourceCandidateInfoInqResult_struct*& out();
    csEqpMonitorSourceCandidateInfoInqResult_struct* _retn();

    operator csEqpMonitorSourceCandidateInfoInqResult_struct_cvPtr () const;

    operator csEqpMonitorSourceCandidateInfoInqResult_struct_vPtr& ();

    operator const csEqpMonitorSourceCandidateInfoInqResult_struct& () const;

    operator csEqpMonitorSourceCandidateInfoInqResult_struct& ();

    protected:
    csEqpMonitorSourceCandidateInfoInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorSourceCandidateInfoInqResult_struct;
    typedef csEqpMonitorSourceCandidateInfoInqResult_struct csEqpMonitorSourceCandidateInfoInqResult;
    typedef csEqpMonitorSourceCandidateInfoInqResult_struct_var csEqpMonitorSourceCandidateInfoInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorSourceCandidateInfoInqResult;
    class  csBWSWaferOutAndSTBReqInParm_struct_var;
    struct  csBWSWaferOutAndSTBReqInParm_struct {
        typedef csBWSWaferOutAndSTBReqInParm_struct_var _var_type;
       ::CORBA::String_StructElem npwType;
       ::objectIdentifier productID;
       ::CORBA::String_StructElem subLotType;
       ::objectIdentifier eqpMonitorID;
       ::objectIdentifier BWSID;
       ::objectIdentifier portID;
       ::objectIdentifier carrierID;
       ::CORBA::Boolean forceExecute;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csBWSWaferOutAndSTBReqInParm_struct();
       csBWSWaferOutAndSTBReqInParm_struct(const csBWSWaferOutAndSTBReqInParm_struct&);
       csBWSWaferOutAndSTBReqInParm_struct& operator=(const csBWSWaferOutAndSTBReqInParm_struct&);
       static CORBA::Info<csBWSWaferOutAndSTBReqInParm_struct> csBWSWaferOutAndSTBReqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csBWSWaferOutAndSTBReqInParm_struct


typedef csBWSWaferOutAndSTBReqInParm_struct* csBWSWaferOutAndSTBReqInParm_struct_vPtr;
typedef const csBWSWaferOutAndSTBReqInParm_struct* csBWSWaferOutAndSTBReqInParm_struct_cvPtr;

class  csBWSWaferOutAndSTBReqInParm_struct_var
{
    public:

    csBWSWaferOutAndSTBReqInParm_struct_var ();

    csBWSWaferOutAndSTBReqInParm_struct_var (csBWSWaferOutAndSTBReqInParm_struct *_p);

    csBWSWaferOutAndSTBReqInParm_struct_var (const csBWSWaferOutAndSTBReqInParm_struct_var &_s);

    csBWSWaferOutAndSTBReqInParm_struct_var &operator= (csBWSWaferOutAndSTBReqInParm_struct *_p);

    csBWSWaferOutAndSTBReqInParm_struct_var &operator= (const csBWSWaferOutAndSTBReqInParm_struct_var &_s);

    ~csBWSWaferOutAndSTBReqInParm_struct_var ();

    csBWSWaferOutAndSTBReqInParm_struct* operator-> ();

    const csBWSWaferOutAndSTBReqInParm_struct& in() const;
    csBWSWaferOutAndSTBReqInParm_struct& inout();
    csBWSWaferOutAndSTBReqInParm_struct*& out();
    csBWSWaferOutAndSTBReqInParm_struct* _retn();

    operator csBWSWaferOutAndSTBReqInParm_struct_cvPtr () const;

    operator csBWSWaferOutAndSTBReqInParm_struct_vPtr& ();

    operator const csBWSWaferOutAndSTBReqInParm_struct& () const;

    operator csBWSWaferOutAndSTBReqInParm_struct& ();

    protected:
    csBWSWaferOutAndSTBReqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csBWSWaferOutAndSTBReqInParm_struct;
    typedef csBWSWaferOutAndSTBReqInParm_struct csBWSWaferOutAndSTBReqInParm;
    typedef csBWSWaferOutAndSTBReqInParm_struct_var csBWSWaferOutAndSTBReqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSWaferOutAndSTBReqInParm;
    typedef pptBaseResult csBWSWaferOutAndSTBReqResult;
    typedef pptBaseResult_var csBWSWaferOutAndSTBReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSWaferOutAndSTBReqResult;
    class  csEqpMonitorLotSTBReqInParm_struct_var;
    struct  csEqpMonitorLotSTBReqInParm_struct {
        typedef csEqpMonitorLotSTBReqInParm_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::objectIdentifier carrierID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpMonitorLotSTBReqInParm_struct();
       csEqpMonitorLotSTBReqInParm_struct(const csEqpMonitorLotSTBReqInParm_struct&);
       csEqpMonitorLotSTBReqInParm_struct& operator=(const csEqpMonitorLotSTBReqInParm_struct&);
       static CORBA::Info<csEqpMonitorLotSTBReqInParm_struct> csEqpMonitorLotSTBReqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpMonitorLotSTBReqInParm_struct


typedef csEqpMonitorLotSTBReqInParm_struct* csEqpMonitorLotSTBReqInParm_struct_vPtr;
typedef const csEqpMonitorLotSTBReqInParm_struct* csEqpMonitorLotSTBReqInParm_struct_cvPtr;

class  csEqpMonitorLotSTBReqInParm_struct_var
{
    public:

    csEqpMonitorLotSTBReqInParm_struct_var ();

    csEqpMonitorLotSTBReqInParm_struct_var (csEqpMonitorLotSTBReqInParm_struct *_p);

    csEqpMonitorLotSTBReqInParm_struct_var (const csEqpMonitorLotSTBReqInParm_struct_var &_s);

    csEqpMonitorLotSTBReqInParm_struct_var &operator= (csEqpMonitorLotSTBReqInParm_struct *_p);

    csEqpMonitorLotSTBReqInParm_struct_var &operator= (const csEqpMonitorLotSTBReqInParm_struct_var &_s);

    ~csEqpMonitorLotSTBReqInParm_struct_var ();

    csEqpMonitorLotSTBReqInParm_struct* operator-> ();

    const csEqpMonitorLotSTBReqInParm_struct& in() const;
    csEqpMonitorLotSTBReqInParm_struct& inout();
    csEqpMonitorLotSTBReqInParm_struct*& out();
    csEqpMonitorLotSTBReqInParm_struct* _retn();

    operator csEqpMonitorLotSTBReqInParm_struct_cvPtr () const;

    operator csEqpMonitorLotSTBReqInParm_struct_vPtr& ();

    operator const csEqpMonitorLotSTBReqInParm_struct& () const;

    operator csEqpMonitorLotSTBReqInParm_struct& ();

    protected:
    csEqpMonitorLotSTBReqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorLotSTBReqInParm_struct;
    typedef csEqpMonitorLotSTBReqInParm_struct csEqpMonitorLotSTBReqInParm;
    typedef csEqpMonitorLotSTBReqInParm_struct_var csEqpMonitorLotSTBReqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorLotSTBReqInParm;
    typedef pptBaseResult csEqpMonitorLotSTBReqResult;
    typedef pptBaseResult_var csEqpMonitorLotSTBReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorLotSTBReqResult;
    class  csNPWSTB_SlotMap_struct_var;
    struct  csNPWSTB_SlotMap_struct {
        typedef csNPWSTB_SlotMap_struct_var _var_type;
       ::objectIdentifier carrierID;
       ::CORBA::Long slotNumber;
       ::objectIdentifier waferID;
       ::objectIdentifier lotID;
       ::objectIdentifier productID;
       ::objectIdentifier destProductID;
       ::CORBA::String_StructElem subLotType;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csNPWSTB_SlotMap_struct();
       csNPWSTB_SlotMap_struct(const csNPWSTB_SlotMap_struct&);
       csNPWSTB_SlotMap_struct& operator=(const csNPWSTB_SlotMap_struct&);
       static CORBA::Info<csNPWSTB_SlotMap_struct> csNPWSTB_SlotMap_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csNPWSTB_SlotMap_struct


typedef csNPWSTB_SlotMap_struct* csNPWSTB_SlotMap_struct_vPtr;
typedef const csNPWSTB_SlotMap_struct* csNPWSTB_SlotMap_struct_cvPtr;

class  csNPWSTB_SlotMap_struct_var
{
    public:

    csNPWSTB_SlotMap_struct_var ();

    csNPWSTB_SlotMap_struct_var (csNPWSTB_SlotMap_struct *_p);

    csNPWSTB_SlotMap_struct_var (const csNPWSTB_SlotMap_struct_var &_s);

    csNPWSTB_SlotMap_struct_var &operator= (csNPWSTB_SlotMap_struct *_p);

    csNPWSTB_SlotMap_struct_var &operator= (const csNPWSTB_SlotMap_struct_var &_s);

    ~csNPWSTB_SlotMap_struct_var ();

    csNPWSTB_SlotMap_struct* operator-> ();

    const csNPWSTB_SlotMap_struct& in() const;
    csNPWSTB_SlotMap_struct& inout();
    csNPWSTB_SlotMap_struct*& out();
    csNPWSTB_SlotMap_struct* _retn();

    operator csNPWSTB_SlotMap_struct_cvPtr () const;

    operator csNPWSTB_SlotMap_struct_vPtr& ();

    operator const csNPWSTB_SlotMap_struct& () const;

    operator csNPWSTB_SlotMap_struct& ();

    protected:
    csNPWSTB_SlotMap_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csNPWSTB_SlotMap_struct;
    typedef csNPWSTB_SlotMap_struct csNPWSTB_SlotMap;
    typedef csNPWSTB_SlotMap_struct_var csNPWSTB_SlotMap_var;
    extern  ::CORBA::TypeCode_ptr _tc_csNPWSTB_SlotMap;
class  _IDL_SEQ_csNPWSTB_SlotMapSequence_0_var;
class  _IDL_SEQ_csNPWSTB_SlotMapSequence_0 {
    public:
        typedef _IDL_SEQ_csNPWSTB_SlotMapSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csNPWSTB_SlotMap *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csNPWSTB_SlotMapSequence_0 ();
    _IDL_SEQ_csNPWSTB_SlotMapSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csNPWSTB_SlotMapSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csNPWSTB_SlotMap* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csNPWSTB_SlotMapSequence_0 (const _IDL_SEQ_csNPWSTB_SlotMapSequence_0&);

    ~_IDL_SEQ_csNPWSTB_SlotMapSequence_0 ();

    _IDL_SEQ_csNPWSTB_SlotMapSequence_0& operator= (const _IDL_SEQ_csNPWSTB_SlotMapSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csNPWSTB_SlotMap& operator [] (::CORBA::ULong indx);
    const csNPWSTB_SlotMap& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csNPWSTB_SlotMap* get_buffer (::CORBA::Boolean orphan=0);
    const csNPWSTB_SlotMap* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csNPWSTB_SlotMap* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csNPWSTB_SlotMap* src, csNPWSTB_SlotMap* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csNPWSTB_SlotMap* data); 
  public:

    static csNPWSTB_SlotMap* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csNPWSTB_SlotMap* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csNPWSTB_SlotMap* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csNPWSTB_SlotMapSequence_0> csNPWSTB_SlotMapSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csNPWSTB_SlotMapSequence_0* _IDL_SEQ_csNPWSTB_SlotMapSequence_0_vPtr;
typedef const _IDL_SEQ_csNPWSTB_SlotMapSequence_0* _IDL_SEQ_csNPWSTB_SlotMapSequence_0_cvPtr;

class  _IDL_SEQ_csNPWSTB_SlotMapSequence_0_var
{
    public:

    _IDL_SEQ_csNPWSTB_SlotMapSequence_0_var ();

    _IDL_SEQ_csNPWSTB_SlotMapSequence_0_var (_IDL_SEQ_csNPWSTB_SlotMapSequence_0 *_p);

    _IDL_SEQ_csNPWSTB_SlotMapSequence_0_var (const _IDL_SEQ_csNPWSTB_SlotMapSequence_0_var &_s);

    _IDL_SEQ_csNPWSTB_SlotMapSequence_0_var &operator= (_IDL_SEQ_csNPWSTB_SlotMapSequence_0 *_p);

    _IDL_SEQ_csNPWSTB_SlotMapSequence_0_var &operator= (const _IDL_SEQ_csNPWSTB_SlotMapSequence_0_var &_s);

    ~_IDL_SEQ_csNPWSTB_SlotMapSequence_0_var ();

    _IDL_SEQ_csNPWSTB_SlotMapSequence_0* operator-> ();

    operator _IDL_SEQ_csNPWSTB_SlotMapSequence_0_cvPtr () const;

    operator _IDL_SEQ_csNPWSTB_SlotMapSequence_0_vPtr& ();

    operator _IDL_SEQ_csNPWSTB_SlotMapSequence_0() const;

    const csNPWSTB_SlotMap& operator[] (::CORBA::ULong index) const;
    csNPWSTB_SlotMap& operator[] (::CORBA::ULong index);
    const csNPWSTB_SlotMap& operator[] (int index) const;
    csNPWSTB_SlotMap& operator[] (int index);
    const _IDL_SEQ_csNPWSTB_SlotMapSequence_0& in() const;
    _IDL_SEQ_csNPWSTB_SlotMapSequence_0& inout();
    _IDL_SEQ_csNPWSTB_SlotMapSequence_0*& out();
    _IDL_SEQ_csNPWSTB_SlotMapSequence_0* _retn();

    protected:
    _IDL_SEQ_csNPWSTB_SlotMapSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csNPWSTB_SlotMapSequence_0 _csNPWSTB_SlotMapSequence_seq;
    typedef _IDL_SEQ_csNPWSTB_SlotMapSequence_0 _csNPWSTB_SlotMapSequence_seq_1;
    typedef _IDL_SEQ_csNPWSTB_SlotMapSequence_0 csNPWSTB_SlotMapSequence;
    typedef _IDL_SEQ_csNPWSTB_SlotMapSequence_0_var csNPWSTB_SlotMapSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csNPWSTB_SlotMapSequence;
    class  csEqpMonitorSubInfo_struct_var;
    struct  csEqpMonitorSubInfo_struct {
        typedef csEqpMonitorSubInfo_struct_var _var_type;
       ::objectIdentifier eqpMonitorID;
       ::CORBA::Long slotNumber;
       ::objectIdentifier productID;
       ::CORBA::Long castSeqNo;
       ::objectIdentifier subRouteID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpMonitorSubInfo_struct();
       csEqpMonitorSubInfo_struct(const csEqpMonitorSubInfo_struct&);
       csEqpMonitorSubInfo_struct& operator=(const csEqpMonitorSubInfo_struct&);
       static CORBA::Info<csEqpMonitorSubInfo_struct> csEqpMonitorSubInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpMonitorSubInfo_struct


typedef csEqpMonitorSubInfo_struct* csEqpMonitorSubInfo_struct_vPtr;
typedef const csEqpMonitorSubInfo_struct* csEqpMonitorSubInfo_struct_cvPtr;

class  csEqpMonitorSubInfo_struct_var
{
    public:

    csEqpMonitorSubInfo_struct_var ();

    csEqpMonitorSubInfo_struct_var (csEqpMonitorSubInfo_struct *_p);

    csEqpMonitorSubInfo_struct_var (const csEqpMonitorSubInfo_struct_var &_s);

    csEqpMonitorSubInfo_struct_var &operator= (csEqpMonitorSubInfo_struct *_p);

    csEqpMonitorSubInfo_struct_var &operator= (const csEqpMonitorSubInfo_struct_var &_s);

    ~csEqpMonitorSubInfo_struct_var ();

    csEqpMonitorSubInfo_struct* operator-> ();

    const csEqpMonitorSubInfo_struct& in() const;
    csEqpMonitorSubInfo_struct& inout();
    csEqpMonitorSubInfo_struct*& out();
    csEqpMonitorSubInfo_struct* _retn();

    operator csEqpMonitorSubInfo_struct_cvPtr () const;

    operator csEqpMonitorSubInfo_struct_vPtr& ();

    operator const csEqpMonitorSubInfo_struct& () const;

    operator csEqpMonitorSubInfo_struct& ();

    protected:
    csEqpMonitorSubInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorSubInfo_struct;
    typedef csEqpMonitorSubInfo_struct csEqpMonitorSubInfo;
    typedef csEqpMonitorSubInfo_struct_var csEqpMonitorSubInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorSubInfo;
class  _IDL_SEQ_csEqpMonitorSubInfoSequence_0_var;
class  _IDL_SEQ_csEqpMonitorSubInfoSequence_0 {
    public:
        typedef _IDL_SEQ_csEqpMonitorSubInfoSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csEqpMonitorSubInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csEqpMonitorSubInfoSequence_0 ();
    _IDL_SEQ_csEqpMonitorSubInfoSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csEqpMonitorSubInfoSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csEqpMonitorSubInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csEqpMonitorSubInfoSequence_0 (const _IDL_SEQ_csEqpMonitorSubInfoSequence_0&);

    ~_IDL_SEQ_csEqpMonitorSubInfoSequence_0 ();

    _IDL_SEQ_csEqpMonitorSubInfoSequence_0& operator= (const _IDL_SEQ_csEqpMonitorSubInfoSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csEqpMonitorSubInfo& operator [] (::CORBA::ULong indx);
    const csEqpMonitorSubInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csEqpMonitorSubInfo* get_buffer (::CORBA::Boolean orphan=0);
    const csEqpMonitorSubInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csEqpMonitorSubInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csEqpMonitorSubInfo* src, csEqpMonitorSubInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csEqpMonitorSubInfo* data); 
  public:

    static csEqpMonitorSubInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csEqpMonitorSubInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csEqpMonitorSubInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csEqpMonitorSubInfoSequence_0> csEqpMonitorSubInfoSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csEqpMonitorSubInfoSequence_0* _IDL_SEQ_csEqpMonitorSubInfoSequence_0_vPtr;
typedef const _IDL_SEQ_csEqpMonitorSubInfoSequence_0* _IDL_SEQ_csEqpMonitorSubInfoSequence_0_cvPtr;

class  _IDL_SEQ_csEqpMonitorSubInfoSequence_0_var
{
    public:

    _IDL_SEQ_csEqpMonitorSubInfoSequence_0_var ();

    _IDL_SEQ_csEqpMonitorSubInfoSequence_0_var (_IDL_SEQ_csEqpMonitorSubInfoSequence_0 *_p);

    _IDL_SEQ_csEqpMonitorSubInfoSequence_0_var (const _IDL_SEQ_csEqpMonitorSubInfoSequence_0_var &_s);

    _IDL_SEQ_csEqpMonitorSubInfoSequence_0_var &operator= (_IDL_SEQ_csEqpMonitorSubInfoSequence_0 *_p);

    _IDL_SEQ_csEqpMonitorSubInfoSequence_0_var &operator= (const _IDL_SEQ_csEqpMonitorSubInfoSequence_0_var &_s);

    ~_IDL_SEQ_csEqpMonitorSubInfoSequence_0_var ();

    _IDL_SEQ_csEqpMonitorSubInfoSequence_0* operator-> ();

    operator _IDL_SEQ_csEqpMonitorSubInfoSequence_0_cvPtr () const;

    operator _IDL_SEQ_csEqpMonitorSubInfoSequence_0_vPtr& ();

    operator _IDL_SEQ_csEqpMonitorSubInfoSequence_0() const;

    const csEqpMonitorSubInfo& operator[] (::CORBA::ULong index) const;
    csEqpMonitorSubInfo& operator[] (::CORBA::ULong index);
    const csEqpMonitorSubInfo& operator[] (int index) const;
    csEqpMonitorSubInfo& operator[] (int index);
    const _IDL_SEQ_csEqpMonitorSubInfoSequence_0& in() const;
    _IDL_SEQ_csEqpMonitorSubInfoSequence_0& inout();
    _IDL_SEQ_csEqpMonitorSubInfoSequence_0*& out();
    _IDL_SEQ_csEqpMonitorSubInfoSequence_0* _retn();

    protected:
    _IDL_SEQ_csEqpMonitorSubInfoSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csEqpMonitorSubInfoSequence_0 _csEqpMonitorSubInfoSequence_seq;
    typedef _IDL_SEQ_csEqpMonitorSubInfoSequence_0 _csEqpMonitorSubInfoSequence_seq_1;
    typedef _IDL_SEQ_csEqpMonitorSubInfoSequence_0 csEqpMonitorSubInfoSequence;
    typedef _IDL_SEQ_csEqpMonitorSubInfoSequence_0_var csEqpMonitorSubInfoSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorSubInfoSequence;
    class  csEqpMonitorDetailInfo_struct_var;
    struct  csEqpMonitorDetailInfo_struct {
        typedef csEqpMonitorDetailInfo_struct_var _var_type;
       ::objectIdentifier eqpMonitorID;
       ::objectIdentifier equipmentID;
       ::objectIdentifier chamberID;
       ::CORBA::String_StructElem description;
       ::CORBA::String_StructElem monitorType;
       ::CORBA::String_StructElem scheduleType;
       ::pptEqpMonitorProductInfoSequence strEqpMonitorProductInfoSeq;
       ::CORBA::String_StructElem startTimeStamp;
       ::CORBA::Long executionInterval;
       ::CORBA::Long warningInterval;
       ::CORBA::Long expirationInterval;
       ::CORBA::Boolean standAloneFlag;
       ::CORBA::Boolean kitFlag;
       ::CORBA::Long maxRetryCount;
       ::pptEqpStatus eqpStateAtStart;
       ::pptEqpStatus eqpStateAtPassed;
       ::pptEqpStatus eqpStateAtFailed;
       ::pptEqpMonitorActionInfoSequence strEqpMonitorActionInfoSeq;
       ::CORBA::String_StructElem monitorStatus;
       ::CORBA::String_StructElem warningTime;
       ::CORBA::String_StructElem expirationTime;
       ::CORBA::String_StructElem nextExecutionTime;
       ::CORBA::String_StructElem scheduleBaseTimeStamp;
       ::CORBA::Long scheduleAdjustment;
       ::CORBA::String_StructElem lastMonitorTimeStamp;
       ::CORBA::String_StructElem lastMonitorResult;
       ::CORBA::String_StructElem lastMonitorPassedTimeStamp;
       ::CORBA::String_StructElem lastClaimedTimeStamp;
       ::objectIdentifier lastClaimedUser;
       ::csEqpMonitorSubInfoSequence strEqpMonitorSubInfoSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpMonitorDetailInfo_struct();
       csEqpMonitorDetailInfo_struct(const csEqpMonitorDetailInfo_struct&);
       csEqpMonitorDetailInfo_struct& operator=(const csEqpMonitorDetailInfo_struct&);
       static CORBA::Info<csEqpMonitorDetailInfo_struct> csEqpMonitorDetailInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpMonitorDetailInfo_struct


typedef csEqpMonitorDetailInfo_struct* csEqpMonitorDetailInfo_struct_vPtr;
typedef const csEqpMonitorDetailInfo_struct* csEqpMonitorDetailInfo_struct_cvPtr;

class  csEqpMonitorDetailInfo_struct_var
{
    public:

    csEqpMonitorDetailInfo_struct_var ();

    csEqpMonitorDetailInfo_struct_var (csEqpMonitorDetailInfo_struct *_p);

    csEqpMonitorDetailInfo_struct_var (const csEqpMonitorDetailInfo_struct_var &_s);

    csEqpMonitorDetailInfo_struct_var &operator= (csEqpMonitorDetailInfo_struct *_p);

    csEqpMonitorDetailInfo_struct_var &operator= (const csEqpMonitorDetailInfo_struct_var &_s);

    ~csEqpMonitorDetailInfo_struct_var ();

    csEqpMonitorDetailInfo_struct* operator-> ();

    const csEqpMonitorDetailInfo_struct& in() const;
    csEqpMonitorDetailInfo_struct& inout();
    csEqpMonitorDetailInfo_struct*& out();
    csEqpMonitorDetailInfo_struct* _retn();

    operator csEqpMonitorDetailInfo_struct_cvPtr () const;

    operator csEqpMonitorDetailInfo_struct_vPtr& ();

    operator const csEqpMonitorDetailInfo_struct& () const;

    operator csEqpMonitorDetailInfo_struct& ();

    protected:
    csEqpMonitorDetailInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorDetailInfo_struct;
    typedef csEqpMonitorDetailInfo_struct csEqpMonitorDetailInfo;
    typedef csEqpMonitorDetailInfo_struct_var csEqpMonitorDetailInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorDetailInfo;
class  _IDL_SEQ_csEqpMonitorDetailInfoSequence_0_var;
class  _IDL_SEQ_csEqpMonitorDetailInfoSequence_0 {
    public:
        typedef _IDL_SEQ_csEqpMonitorDetailInfoSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csEqpMonitorDetailInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csEqpMonitorDetailInfoSequence_0 ();
    _IDL_SEQ_csEqpMonitorDetailInfoSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csEqpMonitorDetailInfoSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csEqpMonitorDetailInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csEqpMonitorDetailInfoSequence_0 (const _IDL_SEQ_csEqpMonitorDetailInfoSequence_0&);

    ~_IDL_SEQ_csEqpMonitorDetailInfoSequence_0 ();

    _IDL_SEQ_csEqpMonitorDetailInfoSequence_0& operator= (const _IDL_SEQ_csEqpMonitorDetailInfoSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csEqpMonitorDetailInfo& operator [] (::CORBA::ULong indx);
    const csEqpMonitorDetailInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csEqpMonitorDetailInfo* get_buffer (::CORBA::Boolean orphan=0);
    const csEqpMonitorDetailInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csEqpMonitorDetailInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csEqpMonitorDetailInfo* src, csEqpMonitorDetailInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csEqpMonitorDetailInfo* data); 
  public:

    static csEqpMonitorDetailInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csEqpMonitorDetailInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csEqpMonitorDetailInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csEqpMonitorDetailInfoSequence_0> csEqpMonitorDetailInfoSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csEqpMonitorDetailInfoSequence_0* _IDL_SEQ_csEqpMonitorDetailInfoSequence_0_vPtr;
typedef const _IDL_SEQ_csEqpMonitorDetailInfoSequence_0* _IDL_SEQ_csEqpMonitorDetailInfoSequence_0_cvPtr;

class  _IDL_SEQ_csEqpMonitorDetailInfoSequence_0_var
{
    public:

    _IDL_SEQ_csEqpMonitorDetailInfoSequence_0_var ();

    _IDL_SEQ_csEqpMonitorDetailInfoSequence_0_var (_IDL_SEQ_csEqpMonitorDetailInfoSequence_0 *_p);

    _IDL_SEQ_csEqpMonitorDetailInfoSequence_0_var (const _IDL_SEQ_csEqpMonitorDetailInfoSequence_0_var &_s);

    _IDL_SEQ_csEqpMonitorDetailInfoSequence_0_var &operator= (_IDL_SEQ_csEqpMonitorDetailInfoSequence_0 *_p);

    _IDL_SEQ_csEqpMonitorDetailInfoSequence_0_var &operator= (const _IDL_SEQ_csEqpMonitorDetailInfoSequence_0_var &_s);

    ~_IDL_SEQ_csEqpMonitorDetailInfoSequence_0_var ();

    _IDL_SEQ_csEqpMonitorDetailInfoSequence_0* operator-> ();

    operator _IDL_SEQ_csEqpMonitorDetailInfoSequence_0_cvPtr () const;

    operator _IDL_SEQ_csEqpMonitorDetailInfoSequence_0_vPtr& ();

    operator _IDL_SEQ_csEqpMonitorDetailInfoSequence_0() const;

    const csEqpMonitorDetailInfo& operator[] (::CORBA::ULong index) const;
    csEqpMonitorDetailInfo& operator[] (::CORBA::ULong index);
    const csEqpMonitorDetailInfo& operator[] (int index) const;
    csEqpMonitorDetailInfo& operator[] (int index);
    const _IDL_SEQ_csEqpMonitorDetailInfoSequence_0& in() const;
    _IDL_SEQ_csEqpMonitorDetailInfoSequence_0& inout();
    _IDL_SEQ_csEqpMonitorDetailInfoSequence_0*& out();
    _IDL_SEQ_csEqpMonitorDetailInfoSequence_0* _retn();

    protected:
    _IDL_SEQ_csEqpMonitorDetailInfoSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csEqpMonitorDetailInfoSequence_0 _csEqpMonitorDetailInfoSequence_seq;
    typedef _IDL_SEQ_csEqpMonitorDetailInfoSequence_0 _csEqpMonitorDetailInfoSequence_seq_1;
    typedef _IDL_SEQ_csEqpMonitorDetailInfoSequence_0 csEqpMonitorDetailInfoSequence;
    typedef _IDL_SEQ_csEqpMonitorDetailInfoSequence_0_var csEqpMonitorDetailInfoSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorDetailInfoSequence;
    class  csEqpMonitorListInqResult_struct_var;
    struct  csEqpMonitorListInqResult_struct {
        typedef csEqpMonitorListInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::csEqpMonitorDetailInfoSequence strEqpMonitorDetailInfoSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpMonitorListInqResult_struct();
       csEqpMonitorListInqResult_struct(const csEqpMonitorListInqResult_struct&);
       csEqpMonitorListInqResult_struct& operator=(const csEqpMonitorListInqResult_struct&);
       static CORBA::Info<csEqpMonitorListInqResult_struct> csEqpMonitorListInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpMonitorListInqResult_struct


typedef csEqpMonitorListInqResult_struct* csEqpMonitorListInqResult_struct_vPtr;
typedef const csEqpMonitorListInqResult_struct* csEqpMonitorListInqResult_struct_cvPtr;

class  csEqpMonitorListInqResult_struct_var
{
    public:

    csEqpMonitorListInqResult_struct_var ();

    csEqpMonitorListInqResult_struct_var (csEqpMonitorListInqResult_struct *_p);

    csEqpMonitorListInqResult_struct_var (const csEqpMonitorListInqResult_struct_var &_s);

    csEqpMonitorListInqResult_struct_var &operator= (csEqpMonitorListInqResult_struct *_p);

    csEqpMonitorListInqResult_struct_var &operator= (const csEqpMonitorListInqResult_struct_var &_s);

    ~csEqpMonitorListInqResult_struct_var ();

    csEqpMonitorListInqResult_struct* operator-> ();

    const csEqpMonitorListInqResult_struct& in() const;
    csEqpMonitorListInqResult_struct& inout();
    csEqpMonitorListInqResult_struct*& out();
    csEqpMonitorListInqResult_struct* _retn();

    operator csEqpMonitorListInqResult_struct_cvPtr () const;

    operator csEqpMonitorListInqResult_struct_vPtr& ();

    operator const csEqpMonitorListInqResult_struct& () const;

    operator csEqpMonitorListInqResult_struct& ();

    protected:
    csEqpMonitorListInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorListInqResult_struct;
    typedef csEqpMonitorListInqResult_struct csEqpMonitorListInqResult;
    typedef csEqpMonitorListInqResult_struct_var csEqpMonitorListInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorListInqResult;
    class  csEqpMonitorUpdateReqInParm_struct_var;
    struct  csEqpMonitorUpdateReqInParm_struct {
        typedef csEqpMonitorUpdateReqInParm_struct_var _var_type;
       ::CORBA::String_StructElem actionType;
       ::objectIdentifier eqpMonitorID;
       ::objectIdentifier equipmentID;
       ::objectIdentifier chamberID;
       ::CORBA::String_StructElem description;
       ::CORBA::String_StructElem monitorType;
       ::CORBA::String_StructElem scheduleType;
       ::pptEqpMonitorProductInfoSequence strEqpMonitorProductInfoSeq;
       ::CORBA::String_StructElem startTimeStamp;
       ::CORBA::Long executionInterval;
       ::CORBA::Long warningInterval;
       ::CORBA::Long expirationInterval;
       ::CORBA::Boolean standAloneFlag;
       ::CORBA::Boolean kitFlag;
       ::CORBA::Long maxRetryCount;
       ::pptEqpStatus eqpStateAtStart;
       ::pptEqpStatus eqpStateAtPassed;
       ::pptEqpStatus eqpStateAtFailed;
       ::pptEqpMonitorActionInfoSequence strEqpMonitorActionInfoSeq;
       ::csEqpMonitorSubInfoSequence strEqpMonitorSubInfoSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpMonitorUpdateReqInParm_struct();
       csEqpMonitorUpdateReqInParm_struct(const csEqpMonitorUpdateReqInParm_struct&);
       csEqpMonitorUpdateReqInParm_struct& operator=(const csEqpMonitorUpdateReqInParm_struct&);
       static CORBA::Info<csEqpMonitorUpdateReqInParm_struct> csEqpMonitorUpdateReqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpMonitorUpdateReqInParm_struct


typedef csEqpMonitorUpdateReqInParm_struct* csEqpMonitorUpdateReqInParm_struct_vPtr;
typedef const csEqpMonitorUpdateReqInParm_struct* csEqpMonitorUpdateReqInParm_struct_cvPtr;

class  csEqpMonitorUpdateReqInParm_struct_var
{
    public:

    csEqpMonitorUpdateReqInParm_struct_var ();

    csEqpMonitorUpdateReqInParm_struct_var (csEqpMonitorUpdateReqInParm_struct *_p);

    csEqpMonitorUpdateReqInParm_struct_var (const csEqpMonitorUpdateReqInParm_struct_var &_s);

    csEqpMonitorUpdateReqInParm_struct_var &operator= (csEqpMonitorUpdateReqInParm_struct *_p);

    csEqpMonitorUpdateReqInParm_struct_var &operator= (const csEqpMonitorUpdateReqInParm_struct_var &_s);

    ~csEqpMonitorUpdateReqInParm_struct_var ();

    csEqpMonitorUpdateReqInParm_struct* operator-> ();

    const csEqpMonitorUpdateReqInParm_struct& in() const;
    csEqpMonitorUpdateReqInParm_struct& inout();
    csEqpMonitorUpdateReqInParm_struct*& out();
    csEqpMonitorUpdateReqInParm_struct* _retn();

    operator csEqpMonitorUpdateReqInParm_struct_cvPtr () const;

    operator csEqpMonitorUpdateReqInParm_struct_vPtr& ();

    operator const csEqpMonitorUpdateReqInParm_struct& () const;

    operator csEqpMonitorUpdateReqInParm_struct& ();

    protected:
    csEqpMonitorUpdateReqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorUpdateReqInParm_struct;
    typedef csEqpMonitorUpdateReqInParm_struct csEqpMonitorUpdateReqInParm;
    typedef csEqpMonitorUpdateReqInParm_struct_var csEqpMonitorUpdateReqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorUpdateReqInParm;
    class  csLotListAttributes_siInfo_struct_var;
    struct  csLotListAttributes_siInfo_struct {
        typedef csLotListAttributes_siInfo_struct_var _var_type;
       ::CORBA::String_StructElem monitorPrepID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csLotListAttributes_siInfo_struct();
       csLotListAttributes_siInfo_struct(const csLotListAttributes_siInfo_struct&);
       csLotListAttributes_siInfo_struct& operator=(const csLotListAttributes_siInfo_struct&);
       static CORBA::Info<csLotListAttributes_siInfo_struct> csLotListAttributes_siInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csLotListAttributes_siInfo_struct


typedef csLotListAttributes_siInfo_struct* csLotListAttributes_siInfo_struct_vPtr;
typedef const csLotListAttributes_siInfo_struct* csLotListAttributes_siInfo_struct_cvPtr;

class  csLotListAttributes_siInfo_struct_var
{
    public:

    csLotListAttributes_siInfo_struct_var ();

    csLotListAttributes_siInfo_struct_var (csLotListAttributes_siInfo_struct *_p);

    csLotListAttributes_siInfo_struct_var (const csLotListAttributes_siInfo_struct_var &_s);

    csLotListAttributes_siInfo_struct_var &operator= (csLotListAttributes_siInfo_struct *_p);

    csLotListAttributes_siInfo_struct_var &operator= (const csLotListAttributes_siInfo_struct_var &_s);

    ~csLotListAttributes_siInfo_struct_var ();

    csLotListAttributes_siInfo_struct* operator-> ();

    const csLotListAttributes_siInfo_struct& in() const;
    csLotListAttributes_siInfo_struct& inout();
    csLotListAttributes_siInfo_struct*& out();
    csLotListAttributes_siInfo_struct* _retn();

    operator csLotListAttributes_siInfo_struct_cvPtr () const;

    operator csLotListAttributes_siInfo_struct_vPtr& ();

    operator const csLotListAttributes_siInfo_struct& () const;

    operator csLotListAttributes_siInfo_struct& ();

    protected:
    csLotListAttributes_siInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csLotListAttributes_siInfo_struct;
    typedef csLotListAttributes_siInfo_struct csLotListAttributes_siInfo;
    typedef csLotListAttributes_siInfo_struct_var csLotListAttributes_siInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csLotListAttributes_siInfo;
    class  csWhatNextAttributes_siInfo_struct_var;
    struct  csWhatNextAttributes_siInfo_struct {
        typedef csWhatNextAttributes_siInfo_struct_var _var_type;
       ::CORBA::String_StructElem monitorPrepID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csWhatNextAttributes_siInfo_struct();
       csWhatNextAttributes_siInfo_struct(const csWhatNextAttributes_siInfo_struct&);
       csWhatNextAttributes_siInfo_struct& operator=(const csWhatNextAttributes_siInfo_struct&);
       static CORBA::Info<csWhatNextAttributes_siInfo_struct> csWhatNextAttributes_siInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csWhatNextAttributes_siInfo_struct


typedef csWhatNextAttributes_siInfo_struct* csWhatNextAttributes_siInfo_struct_vPtr;
typedef const csWhatNextAttributes_siInfo_struct* csWhatNextAttributes_siInfo_struct_cvPtr;

class  csWhatNextAttributes_siInfo_struct_var
{
    public:

    csWhatNextAttributes_siInfo_struct_var ();

    csWhatNextAttributes_siInfo_struct_var (csWhatNextAttributes_siInfo_struct *_p);

    csWhatNextAttributes_siInfo_struct_var (const csWhatNextAttributes_siInfo_struct_var &_s);

    csWhatNextAttributes_siInfo_struct_var &operator= (csWhatNextAttributes_siInfo_struct *_p);

    csWhatNextAttributes_siInfo_struct_var &operator= (const csWhatNextAttributes_siInfo_struct_var &_s);

    ~csWhatNextAttributes_siInfo_struct_var ();

    csWhatNextAttributes_siInfo_struct* operator-> ();

    const csWhatNextAttributes_siInfo_struct& in() const;
    csWhatNextAttributes_siInfo_struct& inout();
    csWhatNextAttributes_siInfo_struct*& out();
    csWhatNextAttributes_siInfo_struct* _retn();

    operator csWhatNextAttributes_siInfo_struct_cvPtr () const;

    operator csWhatNextAttributes_siInfo_struct_vPtr& ();

    operator const csWhatNextAttributes_siInfo_struct& () const;

    operator csWhatNextAttributes_siInfo_struct& ();

    protected:
    csWhatNextAttributes_siInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csWhatNextAttributes_siInfo_struct;
    typedef csWhatNextAttributes_siInfo_struct csWhatNextAttributes_siInfo;
    typedef csWhatNextAttributes_siInfo_struct_var csWhatNextAttributes_siInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csWhatNextAttributes_siInfo;
    class  csEqpMonitorLotAllBranchReqInParm_struct_var;
    struct  csEqpMonitorLotAllBranchReqInParm_struct {
        typedef csEqpMonitorLotAllBranchReqInParm_struct_var _var_type;
       ::objectIdentifier eqpMonitorID;
       ::objectIdentifier carrierID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpMonitorLotAllBranchReqInParm_struct();
       csEqpMonitorLotAllBranchReqInParm_struct(const csEqpMonitorLotAllBranchReqInParm_struct&);
       csEqpMonitorLotAllBranchReqInParm_struct& operator=(const csEqpMonitorLotAllBranchReqInParm_struct&);
       static CORBA::Info<csEqpMonitorLotAllBranchReqInParm_struct> csEqpMonitorLotAllBranchReqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpMonitorLotAllBranchReqInParm_struct


typedef csEqpMonitorLotAllBranchReqInParm_struct* csEqpMonitorLotAllBranchReqInParm_struct_vPtr;
typedef const csEqpMonitorLotAllBranchReqInParm_struct* csEqpMonitorLotAllBranchReqInParm_struct_cvPtr;

class  csEqpMonitorLotAllBranchReqInParm_struct_var
{
    public:

    csEqpMonitorLotAllBranchReqInParm_struct_var ();

    csEqpMonitorLotAllBranchReqInParm_struct_var (csEqpMonitorLotAllBranchReqInParm_struct *_p);

    csEqpMonitorLotAllBranchReqInParm_struct_var (const csEqpMonitorLotAllBranchReqInParm_struct_var &_s);

    csEqpMonitorLotAllBranchReqInParm_struct_var &operator= (csEqpMonitorLotAllBranchReqInParm_struct *_p);

    csEqpMonitorLotAllBranchReqInParm_struct_var &operator= (const csEqpMonitorLotAllBranchReqInParm_struct_var &_s);

    ~csEqpMonitorLotAllBranchReqInParm_struct_var ();

    csEqpMonitorLotAllBranchReqInParm_struct* operator-> ();

    const csEqpMonitorLotAllBranchReqInParm_struct& in() const;
    csEqpMonitorLotAllBranchReqInParm_struct& inout();
    csEqpMonitorLotAllBranchReqInParm_struct*& out();
    csEqpMonitorLotAllBranchReqInParm_struct* _retn();

    operator csEqpMonitorLotAllBranchReqInParm_struct_cvPtr () const;

    operator csEqpMonitorLotAllBranchReqInParm_struct_vPtr& ();

    operator const csEqpMonitorLotAllBranchReqInParm_struct& () const;

    operator csEqpMonitorLotAllBranchReqInParm_struct& ();

    protected:
    csEqpMonitorLotAllBranchReqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorLotAllBranchReqInParm_struct;
    typedef csEqpMonitorLotAllBranchReqInParm_struct csEqpMonitorLotAllBranchReqInParm;
    typedef csEqpMonitorLotAllBranchReqInParm_struct_var csEqpMonitorLotAllBranchReqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorLotAllBranchReqInParm;
    typedef pptBaseResult csEqpMonitorLotAllBranchReqResult;
    typedef pptBaseResult_var csEqpMonitorLotAllBranchReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorLotAllBranchReqResult;
    class  csEqpMonitorLotPrepareIDResetReqInParm_struct_var;
    struct  csEqpMonitorLotPrepareIDResetReqInParm_struct {
        typedef csEqpMonitorLotPrepareIDResetReqInParm_struct_var _var_type;
       ::objectIdentifier eqpMonitorID;
       ::objectIdentifier carrierID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csEqpMonitorLotPrepareIDResetReqInParm_struct();
       csEqpMonitorLotPrepareIDResetReqInParm_struct(const csEqpMonitorLotPrepareIDResetReqInParm_struct&);
       csEqpMonitorLotPrepareIDResetReqInParm_struct& operator=(const csEqpMonitorLotPrepareIDResetReqInParm_struct&);
       static CORBA::Info<csEqpMonitorLotPrepareIDResetReqInParm_struct> csEqpMonitorLotPrepareIDResetReqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csEqpMonitorLotPrepareIDResetReqInParm_struct


typedef csEqpMonitorLotPrepareIDResetReqInParm_struct* csEqpMonitorLotPrepareIDResetReqInParm_struct_vPtr;
typedef const csEqpMonitorLotPrepareIDResetReqInParm_struct* csEqpMonitorLotPrepareIDResetReqInParm_struct_cvPtr;

class  csEqpMonitorLotPrepareIDResetReqInParm_struct_var
{
    public:

    csEqpMonitorLotPrepareIDResetReqInParm_struct_var ();

    csEqpMonitorLotPrepareIDResetReqInParm_struct_var (csEqpMonitorLotPrepareIDResetReqInParm_struct *_p);

    csEqpMonitorLotPrepareIDResetReqInParm_struct_var (const csEqpMonitorLotPrepareIDResetReqInParm_struct_var &_s);

    csEqpMonitorLotPrepareIDResetReqInParm_struct_var &operator= (csEqpMonitorLotPrepareIDResetReqInParm_struct *_p);

    csEqpMonitorLotPrepareIDResetReqInParm_struct_var &operator= (const csEqpMonitorLotPrepareIDResetReqInParm_struct_var &_s);

    ~csEqpMonitorLotPrepareIDResetReqInParm_struct_var ();

    csEqpMonitorLotPrepareIDResetReqInParm_struct* operator-> ();

    const csEqpMonitorLotPrepareIDResetReqInParm_struct& in() const;
    csEqpMonitorLotPrepareIDResetReqInParm_struct& inout();
    csEqpMonitorLotPrepareIDResetReqInParm_struct*& out();
    csEqpMonitorLotPrepareIDResetReqInParm_struct* _retn();

    operator csEqpMonitorLotPrepareIDResetReqInParm_struct_cvPtr () const;

    operator csEqpMonitorLotPrepareIDResetReqInParm_struct_vPtr& ();

    operator const csEqpMonitorLotPrepareIDResetReqInParm_struct& () const;

    operator csEqpMonitorLotPrepareIDResetReqInParm_struct& ();

    protected:
    csEqpMonitorLotPrepareIDResetReqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorLotPrepareIDResetReqInParm_struct;
    typedef csEqpMonitorLotPrepareIDResetReqInParm_struct csEqpMonitorLotPrepareIDResetReqInParm;
    typedef csEqpMonitorLotPrepareIDResetReqInParm_struct_var csEqpMonitorLotPrepareIDResetReqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorLotPrepareIDResetReqInParm;
    typedef pptBaseResult csEqpMonitorLotPrepareIDResetReqResult;
    typedef pptBaseResult_var csEqpMonitorLotPrepareIDResetReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csEqpMonitorLotPrepareIDResetReqResult;
    class  csDowngradeItemListInqResult_struct_var;
    struct  csDowngradeItemListInqResult_struct {
        typedef csDowngradeItemListInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::objectIdentifier dcDefID;
       ::stringSequence selectedDCItems;
       ::pptDCItemSequence strDCItems;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csDowngradeItemListInqResult_struct();
       csDowngradeItemListInqResult_struct(const csDowngradeItemListInqResult_struct&);
       csDowngradeItemListInqResult_struct& operator=(const csDowngradeItemListInqResult_struct&);
       static CORBA::Info<csDowngradeItemListInqResult_struct> csDowngradeItemListInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csDowngradeItemListInqResult_struct


typedef csDowngradeItemListInqResult_struct* csDowngradeItemListInqResult_struct_vPtr;
typedef const csDowngradeItemListInqResult_struct* csDowngradeItemListInqResult_struct_cvPtr;

class  csDowngradeItemListInqResult_struct_var
{
    public:

    csDowngradeItemListInqResult_struct_var ();

    csDowngradeItemListInqResult_struct_var (csDowngradeItemListInqResult_struct *_p);

    csDowngradeItemListInqResult_struct_var (const csDowngradeItemListInqResult_struct_var &_s);

    csDowngradeItemListInqResult_struct_var &operator= (csDowngradeItemListInqResult_struct *_p);

    csDowngradeItemListInqResult_struct_var &operator= (const csDowngradeItemListInqResult_struct_var &_s);

    ~csDowngradeItemListInqResult_struct_var ();

    csDowngradeItemListInqResult_struct* operator-> ();

    const csDowngradeItemListInqResult_struct& in() const;
    csDowngradeItemListInqResult_struct& inout();
    csDowngradeItemListInqResult_struct*& out();
    csDowngradeItemListInqResult_struct* _retn();

    operator csDowngradeItemListInqResult_struct_cvPtr () const;

    operator csDowngradeItemListInqResult_struct_vPtr& ();

    operator const csDowngradeItemListInqResult_struct& () const;

    operator csDowngradeItemListInqResult_struct& ();

    protected:
    csDowngradeItemListInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csDowngradeItemListInqResult_struct;
    typedef csDowngradeItemListInqResult_struct csDowngradeItemListInqResult;
    typedef csDowngradeItemListInqResult_struct_var csDowngradeItemListInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csDowngradeItemListInqResult;
    class  csDowngradeItemUpdateReqInParm_struct_var;
    struct  csDowngradeItemUpdateReqInParm_struct {
        typedef csDowngradeItemUpdateReqInParm_struct_var _var_type;
       ::objectIdentifier dcDefID;
       ::stringSequence selectedDCItems;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csDowngradeItemUpdateReqInParm_struct();
       csDowngradeItemUpdateReqInParm_struct(const csDowngradeItemUpdateReqInParm_struct&);
       csDowngradeItemUpdateReqInParm_struct& operator=(const csDowngradeItemUpdateReqInParm_struct&);
       static CORBA::Info<csDowngradeItemUpdateReqInParm_struct> csDowngradeItemUpdateReqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csDowngradeItemUpdateReqInParm_struct


typedef csDowngradeItemUpdateReqInParm_struct* csDowngradeItemUpdateReqInParm_struct_vPtr;
typedef const csDowngradeItemUpdateReqInParm_struct* csDowngradeItemUpdateReqInParm_struct_cvPtr;

class  csDowngradeItemUpdateReqInParm_struct_var
{
    public:

    csDowngradeItemUpdateReqInParm_struct_var ();

    csDowngradeItemUpdateReqInParm_struct_var (csDowngradeItemUpdateReqInParm_struct *_p);

    csDowngradeItemUpdateReqInParm_struct_var (const csDowngradeItemUpdateReqInParm_struct_var &_s);

    csDowngradeItemUpdateReqInParm_struct_var &operator= (csDowngradeItemUpdateReqInParm_struct *_p);

    csDowngradeItemUpdateReqInParm_struct_var &operator= (const csDowngradeItemUpdateReqInParm_struct_var &_s);

    ~csDowngradeItemUpdateReqInParm_struct_var ();

    csDowngradeItemUpdateReqInParm_struct* operator-> ();

    const csDowngradeItemUpdateReqInParm_struct& in() const;
    csDowngradeItemUpdateReqInParm_struct& inout();
    csDowngradeItemUpdateReqInParm_struct*& out();
    csDowngradeItemUpdateReqInParm_struct* _retn();

    operator csDowngradeItemUpdateReqInParm_struct_cvPtr () const;

    operator csDowngradeItemUpdateReqInParm_struct_vPtr& ();

    operator const csDowngradeItemUpdateReqInParm_struct& () const;

    operator csDowngradeItemUpdateReqInParm_struct& ();

    protected:
    csDowngradeItemUpdateReqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csDowngradeItemUpdateReqInParm_struct;
    typedef csDowngradeItemUpdateReqInParm_struct csDowngradeItemUpdateReqInParm;
    typedef csDowngradeItemUpdateReqInParm_struct_var csDowngradeItemUpdateReqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csDowngradeItemUpdateReqInParm;
    typedef pptBaseResult csDowngradeItemUpdateReqResult;
    typedef pptBaseResult_var csDowngradeItemUpdateReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csDowngradeItemUpdateReqResult;
    class  csDowngradeSettingInfo_struct_var;
    struct  csDowngradeSettingInfo_struct {
        typedef csDowngradeSettingInfo_struct_var _var_type;
       ::CORBA::Long seqNo;
       ::CORBA::String_StructElem productID;
       ::CORBA::String_StructElem dwgGroductID;
       ::CORBA::String_StructElem grade;
       ::CORBA::String_StructElem endBank;
       ::CORBA::String_StructElem dataValue1;
       ::CORBA::String_StructElem dataValue2;
       ::CORBA::String_StructElem dataValue3;
       ::CORBA::String_StructElem dataValue4;
       ::CORBA::String_StructElem dataValue5;
       ::CORBA::String_StructElem dataValue6;
       ::CORBA::String_StructElem dataValue7;
       ::CORBA::String_StructElem dataValue8;
       ::CORBA::String_StructElem dataValue9;
       ::CORBA::String_StructElem dataValue10;
       ::CORBA::String_StructElem dataValue11;
       ::CORBA::String_StructElem dataValue12;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csDowngradeSettingInfo_struct();
       csDowngradeSettingInfo_struct(const csDowngradeSettingInfo_struct&);
       csDowngradeSettingInfo_struct& operator=(const csDowngradeSettingInfo_struct&);
       static CORBA::Info<csDowngradeSettingInfo_struct> csDowngradeSettingInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csDowngradeSettingInfo_struct


typedef csDowngradeSettingInfo_struct* csDowngradeSettingInfo_struct_vPtr;
typedef const csDowngradeSettingInfo_struct* csDowngradeSettingInfo_struct_cvPtr;

class  csDowngradeSettingInfo_struct_var
{
    public:

    csDowngradeSettingInfo_struct_var ();

    csDowngradeSettingInfo_struct_var (csDowngradeSettingInfo_struct *_p);

    csDowngradeSettingInfo_struct_var (const csDowngradeSettingInfo_struct_var &_s);

    csDowngradeSettingInfo_struct_var &operator= (csDowngradeSettingInfo_struct *_p);

    csDowngradeSettingInfo_struct_var &operator= (const csDowngradeSettingInfo_struct_var &_s);

    ~csDowngradeSettingInfo_struct_var ();

    csDowngradeSettingInfo_struct* operator-> ();

    const csDowngradeSettingInfo_struct& in() const;
    csDowngradeSettingInfo_struct& inout();
    csDowngradeSettingInfo_struct*& out();
    csDowngradeSettingInfo_struct* _retn();

    operator csDowngradeSettingInfo_struct_cvPtr () const;

    operator csDowngradeSettingInfo_struct_vPtr& ();

    operator const csDowngradeSettingInfo_struct& () const;

    operator csDowngradeSettingInfo_struct& ();

    protected:
    csDowngradeSettingInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csDowngradeSettingInfo_struct;
    typedef csDowngradeSettingInfo_struct csDowngradeSettingInfo;
    typedef csDowngradeSettingInfo_struct_var csDowngradeSettingInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csDowngradeSettingInfo;
class  _IDL_SEQ_csDowngradeSettingInfoSequence_0_var;
class  _IDL_SEQ_csDowngradeSettingInfoSequence_0 {
    public:
        typedef _IDL_SEQ_csDowngradeSettingInfoSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csDowngradeSettingInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csDowngradeSettingInfoSequence_0 ();
    _IDL_SEQ_csDowngradeSettingInfoSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csDowngradeSettingInfoSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csDowngradeSettingInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csDowngradeSettingInfoSequence_0 (const _IDL_SEQ_csDowngradeSettingInfoSequence_0&);

    ~_IDL_SEQ_csDowngradeSettingInfoSequence_0 ();

    _IDL_SEQ_csDowngradeSettingInfoSequence_0& operator= (const _IDL_SEQ_csDowngradeSettingInfoSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csDowngradeSettingInfo& operator [] (::CORBA::ULong indx);
    const csDowngradeSettingInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csDowngradeSettingInfo* get_buffer (::CORBA::Boolean orphan=0);
    const csDowngradeSettingInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csDowngradeSettingInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csDowngradeSettingInfo* src, csDowngradeSettingInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csDowngradeSettingInfo* data); 
  public:

    static csDowngradeSettingInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csDowngradeSettingInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csDowngradeSettingInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csDowngradeSettingInfoSequence_0> csDowngradeSettingInfoSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csDowngradeSettingInfoSequence_0* _IDL_SEQ_csDowngradeSettingInfoSequence_0_vPtr;
typedef const _IDL_SEQ_csDowngradeSettingInfoSequence_0* _IDL_SEQ_csDowngradeSettingInfoSequence_0_cvPtr;

class  _IDL_SEQ_csDowngradeSettingInfoSequence_0_var
{
    public:

    _IDL_SEQ_csDowngradeSettingInfoSequence_0_var ();

    _IDL_SEQ_csDowngradeSettingInfoSequence_0_var (_IDL_SEQ_csDowngradeSettingInfoSequence_0 *_p);

    _IDL_SEQ_csDowngradeSettingInfoSequence_0_var (const _IDL_SEQ_csDowngradeSettingInfoSequence_0_var &_s);

    _IDL_SEQ_csDowngradeSettingInfoSequence_0_var &operator= (_IDL_SEQ_csDowngradeSettingInfoSequence_0 *_p);

    _IDL_SEQ_csDowngradeSettingInfoSequence_0_var &operator= (const _IDL_SEQ_csDowngradeSettingInfoSequence_0_var &_s);

    ~_IDL_SEQ_csDowngradeSettingInfoSequence_0_var ();

    _IDL_SEQ_csDowngradeSettingInfoSequence_0* operator-> ();

    operator _IDL_SEQ_csDowngradeSettingInfoSequence_0_cvPtr () const;

    operator _IDL_SEQ_csDowngradeSettingInfoSequence_0_vPtr& ();

    operator _IDL_SEQ_csDowngradeSettingInfoSequence_0() const;

    const csDowngradeSettingInfo& operator[] (::CORBA::ULong index) const;
    csDowngradeSettingInfo& operator[] (::CORBA::ULong index);
    const csDowngradeSettingInfo& operator[] (int index) const;
    csDowngradeSettingInfo& operator[] (int index);
    const _IDL_SEQ_csDowngradeSettingInfoSequence_0& in() const;
    _IDL_SEQ_csDowngradeSettingInfoSequence_0& inout();
    _IDL_SEQ_csDowngradeSettingInfoSequence_0*& out();
    _IDL_SEQ_csDowngradeSettingInfoSequence_0* _retn();

    protected:
    _IDL_SEQ_csDowngradeSettingInfoSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csDowngradeSettingInfoSequence_0 _csDowngradeSettingInfoSequence_seq;
    typedef _IDL_SEQ_csDowngradeSettingInfoSequence_0 _csDowngradeSettingInfoSequence_seq_1;
    typedef _IDL_SEQ_csDowngradeSettingInfoSequence_0 csDowngradeSettingInfoSequence;
    typedef _IDL_SEQ_csDowngradeSettingInfoSequence_0_var csDowngradeSettingInfoSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csDowngradeSettingInfoSequence;
    class  csDowngradeSettingListInqInParm_struct_var;
    struct  csDowngradeSettingListInqInParm_struct {
        typedef csDowngradeSettingListInqInParm_struct_var _var_type;
       ::CORBA::String_StructElem productID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csDowngradeSettingListInqInParm_struct();
       csDowngradeSettingListInqInParm_struct(const csDowngradeSettingListInqInParm_struct&);
       csDowngradeSettingListInqInParm_struct& operator=(const csDowngradeSettingListInqInParm_struct&);
       static CORBA::Info<csDowngradeSettingListInqInParm_struct> csDowngradeSettingListInqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csDowngradeSettingListInqInParm_struct


typedef csDowngradeSettingListInqInParm_struct* csDowngradeSettingListInqInParm_struct_vPtr;
typedef const csDowngradeSettingListInqInParm_struct* csDowngradeSettingListInqInParm_struct_cvPtr;

class  csDowngradeSettingListInqInParm_struct_var
{
    public:

    csDowngradeSettingListInqInParm_struct_var ();

    csDowngradeSettingListInqInParm_struct_var (csDowngradeSettingListInqInParm_struct *_p);

    csDowngradeSettingListInqInParm_struct_var (const csDowngradeSettingListInqInParm_struct_var &_s);

    csDowngradeSettingListInqInParm_struct_var &operator= (csDowngradeSettingListInqInParm_struct *_p);

    csDowngradeSettingListInqInParm_struct_var &operator= (const csDowngradeSettingListInqInParm_struct_var &_s);

    ~csDowngradeSettingListInqInParm_struct_var ();

    csDowngradeSettingListInqInParm_struct* operator-> ();

    const csDowngradeSettingListInqInParm_struct& in() const;
    csDowngradeSettingListInqInParm_struct& inout();
    csDowngradeSettingListInqInParm_struct*& out();
    csDowngradeSettingListInqInParm_struct* _retn();

    operator csDowngradeSettingListInqInParm_struct_cvPtr () const;

    operator csDowngradeSettingListInqInParm_struct_vPtr& ();

    operator const csDowngradeSettingListInqInParm_struct& () const;

    operator csDowngradeSettingListInqInParm_struct& ();

    protected:
    csDowngradeSettingListInqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csDowngradeSettingListInqInParm_struct;
    typedef csDowngradeSettingListInqInParm_struct csDowngradeSettingListInqInParm;
    typedef csDowngradeSettingListInqInParm_struct_var csDowngradeSettingListInqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csDowngradeSettingListInqInParm;
    class  csDowngradeSettingListInqResult_struct_var;
    struct  csDowngradeSettingListInqResult_struct {
        typedef csDowngradeSettingListInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::csDowngradeSettingInfoSequence strDowngradeSettingInfoSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csDowngradeSettingListInqResult_struct();
       csDowngradeSettingListInqResult_struct(const csDowngradeSettingListInqResult_struct&);
       csDowngradeSettingListInqResult_struct& operator=(const csDowngradeSettingListInqResult_struct&);
       static CORBA::Info<csDowngradeSettingListInqResult_struct> csDowngradeSettingListInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csDowngradeSettingListInqResult_struct


typedef csDowngradeSettingListInqResult_struct* csDowngradeSettingListInqResult_struct_vPtr;
typedef const csDowngradeSettingListInqResult_struct* csDowngradeSettingListInqResult_struct_cvPtr;

class  csDowngradeSettingListInqResult_struct_var
{
    public:

    csDowngradeSettingListInqResult_struct_var ();

    csDowngradeSettingListInqResult_struct_var (csDowngradeSettingListInqResult_struct *_p);

    csDowngradeSettingListInqResult_struct_var (const csDowngradeSettingListInqResult_struct_var &_s);

    csDowngradeSettingListInqResult_struct_var &operator= (csDowngradeSettingListInqResult_struct *_p);

    csDowngradeSettingListInqResult_struct_var &operator= (const csDowngradeSettingListInqResult_struct_var &_s);

    ~csDowngradeSettingListInqResult_struct_var ();

    csDowngradeSettingListInqResult_struct* operator-> ();

    const csDowngradeSettingListInqResult_struct& in() const;
    csDowngradeSettingListInqResult_struct& inout();
    csDowngradeSettingListInqResult_struct*& out();
    csDowngradeSettingListInqResult_struct* _retn();

    operator csDowngradeSettingListInqResult_struct_cvPtr () const;

    operator csDowngradeSettingListInqResult_struct_vPtr& ();

    operator const csDowngradeSettingListInqResult_struct& () const;

    operator csDowngradeSettingListInqResult_struct& ();

    protected:
    csDowngradeSettingListInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csDowngradeSettingListInqResult_struct;
    typedef csDowngradeSettingListInqResult_struct csDowngradeSettingListInqResult;
    typedef csDowngradeSettingListInqResult_struct_var csDowngradeSettingListInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csDowngradeSettingListInqResult;
    class  csDowngradeSettingUpdateReqInParm_struct_var;
    struct  csDowngradeSettingUpdateReqInParm_struct {
        typedef csDowngradeSettingUpdateReqInParm_struct_var _var_type;
       ::objectIdentifier dcDefID;
       ::csDowngradeSettingInfoSequence strDowngradeSettingInfoSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csDowngradeSettingUpdateReqInParm_struct();
       csDowngradeSettingUpdateReqInParm_struct(const csDowngradeSettingUpdateReqInParm_struct&);
       csDowngradeSettingUpdateReqInParm_struct& operator=(const csDowngradeSettingUpdateReqInParm_struct&);
       static CORBA::Info<csDowngradeSettingUpdateReqInParm_struct> csDowngradeSettingUpdateReqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csDowngradeSettingUpdateReqInParm_struct


typedef csDowngradeSettingUpdateReqInParm_struct* csDowngradeSettingUpdateReqInParm_struct_vPtr;
typedef const csDowngradeSettingUpdateReqInParm_struct* csDowngradeSettingUpdateReqInParm_struct_cvPtr;

class  csDowngradeSettingUpdateReqInParm_struct_var
{
    public:

    csDowngradeSettingUpdateReqInParm_struct_var ();

    csDowngradeSettingUpdateReqInParm_struct_var (csDowngradeSettingUpdateReqInParm_struct *_p);

    csDowngradeSettingUpdateReqInParm_struct_var (const csDowngradeSettingUpdateReqInParm_struct_var &_s);

    csDowngradeSettingUpdateReqInParm_struct_var &operator= (csDowngradeSettingUpdateReqInParm_struct *_p);

    csDowngradeSettingUpdateReqInParm_struct_var &operator= (const csDowngradeSettingUpdateReqInParm_struct_var &_s);

    ~csDowngradeSettingUpdateReqInParm_struct_var ();

    csDowngradeSettingUpdateReqInParm_struct* operator-> ();

    const csDowngradeSettingUpdateReqInParm_struct& in() const;
    csDowngradeSettingUpdateReqInParm_struct& inout();
    csDowngradeSettingUpdateReqInParm_struct*& out();
    csDowngradeSettingUpdateReqInParm_struct* _retn();

    operator csDowngradeSettingUpdateReqInParm_struct_cvPtr () const;

    operator csDowngradeSettingUpdateReqInParm_struct_vPtr& ();

    operator const csDowngradeSettingUpdateReqInParm_struct& () const;

    operator csDowngradeSettingUpdateReqInParm_struct& ();

    protected:
    csDowngradeSettingUpdateReqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csDowngradeSettingUpdateReqInParm_struct;
    typedef csDowngradeSettingUpdateReqInParm_struct csDowngradeSettingUpdateReqInParm;
    typedef csDowngradeSettingUpdateReqInParm_struct_var csDowngradeSettingUpdateReqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csDowngradeSettingUpdateReqInParm;
    typedef pptBaseResult csDowngradeSettingUpdateReqResult;
    typedef pptBaseResult_var csDowngradeSettingUpdateReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csDowngradeSettingUpdateReqResult;
    class  csZoneConfigInfo_struct_var;
    struct  csZoneConfigInfo_struct {
        typedef csZoneConfigInfo_struct_var _var_type;
       ::CORBA::String_StructElem zoneID;
       ::CORBA::Long maxCapacity;
       ::CORBA::Long availableCapacity;
       ::CORBA::String_StructElem claimTime;
       ::objectIdentifier claimUserID;
       ::CORBA::String_StructElem claimMemo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csZoneConfigInfo_struct();
       csZoneConfigInfo_struct(const csZoneConfigInfo_struct&);
       csZoneConfigInfo_struct& operator=(const csZoneConfigInfo_struct&);
       static CORBA::Info<csZoneConfigInfo_struct> csZoneConfigInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csZoneConfigInfo_struct


typedef csZoneConfigInfo_struct* csZoneConfigInfo_struct_vPtr;
typedef const csZoneConfigInfo_struct* csZoneConfigInfo_struct_cvPtr;

class  csZoneConfigInfo_struct_var
{
    public:

    csZoneConfigInfo_struct_var ();

    csZoneConfigInfo_struct_var (csZoneConfigInfo_struct *_p);

    csZoneConfigInfo_struct_var (const csZoneConfigInfo_struct_var &_s);

    csZoneConfigInfo_struct_var &operator= (csZoneConfigInfo_struct *_p);

    csZoneConfigInfo_struct_var &operator= (const csZoneConfigInfo_struct_var &_s);

    ~csZoneConfigInfo_struct_var ();

    csZoneConfigInfo_struct* operator-> ();

    const csZoneConfigInfo_struct& in() const;
    csZoneConfigInfo_struct& inout();
    csZoneConfigInfo_struct*& out();
    csZoneConfigInfo_struct* _retn();

    operator csZoneConfigInfo_struct_cvPtr () const;

    operator csZoneConfigInfo_struct_vPtr& ();

    operator const csZoneConfigInfo_struct& () const;

    operator csZoneConfigInfo_struct& ();

    protected:
    csZoneConfigInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csZoneConfigInfo_struct;
    typedef csZoneConfigInfo_struct csZoneConfigInfo;
    typedef csZoneConfigInfo_struct_var csZoneConfigInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csZoneConfigInfo;
class  _IDL_SEQ_csZoneConfigInfoSequence_0_var;
class  _IDL_SEQ_csZoneConfigInfoSequence_0 {
    public:
        typedef _IDL_SEQ_csZoneConfigInfoSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csZoneConfigInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csZoneConfigInfoSequence_0 ();
    _IDL_SEQ_csZoneConfigInfoSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csZoneConfigInfoSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csZoneConfigInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csZoneConfigInfoSequence_0 (const _IDL_SEQ_csZoneConfigInfoSequence_0&);

    ~_IDL_SEQ_csZoneConfigInfoSequence_0 ();

    _IDL_SEQ_csZoneConfigInfoSequence_0& operator= (const _IDL_SEQ_csZoneConfigInfoSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csZoneConfigInfo& operator [] (::CORBA::ULong indx);
    const csZoneConfigInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csZoneConfigInfo* get_buffer (::CORBA::Boolean orphan=0);
    const csZoneConfigInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csZoneConfigInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csZoneConfigInfo* src, csZoneConfigInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csZoneConfigInfo* data); 
  public:

    static csZoneConfigInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csZoneConfigInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csZoneConfigInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csZoneConfigInfoSequence_0> csZoneConfigInfoSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csZoneConfigInfoSequence_0* _IDL_SEQ_csZoneConfigInfoSequence_0_vPtr;
typedef const _IDL_SEQ_csZoneConfigInfoSequence_0* _IDL_SEQ_csZoneConfigInfoSequence_0_cvPtr;

class  _IDL_SEQ_csZoneConfigInfoSequence_0_var
{
    public:

    _IDL_SEQ_csZoneConfigInfoSequence_0_var ();

    _IDL_SEQ_csZoneConfigInfoSequence_0_var (_IDL_SEQ_csZoneConfigInfoSequence_0 *_p);

    _IDL_SEQ_csZoneConfigInfoSequence_0_var (const _IDL_SEQ_csZoneConfigInfoSequence_0_var &_s);

    _IDL_SEQ_csZoneConfigInfoSequence_0_var &operator= (_IDL_SEQ_csZoneConfigInfoSequence_0 *_p);

    _IDL_SEQ_csZoneConfigInfoSequence_0_var &operator= (const _IDL_SEQ_csZoneConfigInfoSequence_0_var &_s);

    ~_IDL_SEQ_csZoneConfigInfoSequence_0_var ();

    _IDL_SEQ_csZoneConfigInfoSequence_0* operator-> ();

    operator _IDL_SEQ_csZoneConfigInfoSequence_0_cvPtr () const;

    operator _IDL_SEQ_csZoneConfigInfoSequence_0_vPtr& ();

    operator _IDL_SEQ_csZoneConfigInfoSequence_0() const;

    const csZoneConfigInfo& operator[] (::CORBA::ULong index) const;
    csZoneConfigInfo& operator[] (::CORBA::ULong index);
    const csZoneConfigInfo& operator[] (int index) const;
    csZoneConfigInfo& operator[] (int index);
    const _IDL_SEQ_csZoneConfigInfoSequence_0& in() const;
    _IDL_SEQ_csZoneConfigInfoSequence_0& inout();
    _IDL_SEQ_csZoneConfigInfoSequence_0*& out();
    _IDL_SEQ_csZoneConfigInfoSequence_0* _retn();

    protected:
    _IDL_SEQ_csZoneConfigInfoSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csZoneConfigInfoSequence_0 _csZoneConfigInfoSequence_seq;
    typedef _IDL_SEQ_csZoneConfigInfoSequence_0 _csZoneConfigInfoSequence_seq_1;
    typedef _IDL_SEQ_csZoneConfigInfoSequence_0 csZoneConfigInfoSequence;
    typedef _IDL_SEQ_csZoneConfigInfoSequence_0_var csZoneConfigInfoSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csZoneConfigInfoSequence;
    class  csBWSConfigInfo_struct_var;
    struct  csBWSConfigInfo_struct {
        typedef csBWSConfigInfo_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::CORBA::Long maxCapacity;
       ::CORBA::Long availableCapacity;
       ::csZoneConfigInfoSequence strZoneConfigInfoSeq;
       ::CORBA::String_StructElem claimTime;
       ::objectIdentifier claimUserID;
       ::CORBA::String_StructElem claimMemo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csBWSConfigInfo_struct();
       csBWSConfigInfo_struct(const csBWSConfigInfo_struct&);
       csBWSConfigInfo_struct& operator=(const csBWSConfigInfo_struct&);
       static CORBA::Info<csBWSConfigInfo_struct> csBWSConfigInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csBWSConfigInfo_struct


typedef csBWSConfigInfo_struct* csBWSConfigInfo_struct_vPtr;
typedef const csBWSConfigInfo_struct* csBWSConfigInfo_struct_cvPtr;

class  csBWSConfigInfo_struct_var
{
    public:

    csBWSConfigInfo_struct_var ();

    csBWSConfigInfo_struct_var (csBWSConfigInfo_struct *_p);

    csBWSConfigInfo_struct_var (const csBWSConfigInfo_struct_var &_s);

    csBWSConfigInfo_struct_var &operator= (csBWSConfigInfo_struct *_p);

    csBWSConfigInfo_struct_var &operator= (const csBWSConfigInfo_struct_var &_s);

    ~csBWSConfigInfo_struct_var ();

    csBWSConfigInfo_struct* operator-> ();

    const csBWSConfigInfo_struct& in() const;
    csBWSConfigInfo_struct& inout();
    csBWSConfigInfo_struct*& out();
    csBWSConfigInfo_struct* _retn();

    operator csBWSConfigInfo_struct_cvPtr () const;

    operator csBWSConfigInfo_struct_vPtr& ();

    operator const csBWSConfigInfo_struct& () const;

    operator csBWSConfigInfo_struct& ();

    protected:
    csBWSConfigInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csBWSConfigInfo_struct;
    typedef csBWSConfigInfo_struct csBWSConfigInfo;
    typedef csBWSConfigInfo_struct_var csBWSConfigInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSConfigInfo;
class  _IDL_SEQ_csBWSConfigInfoSequence_0_var;
class  _IDL_SEQ_csBWSConfigInfoSequence_0 {
    public:
        typedef _IDL_SEQ_csBWSConfigInfoSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csBWSConfigInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csBWSConfigInfoSequence_0 ();
    _IDL_SEQ_csBWSConfigInfoSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csBWSConfigInfoSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csBWSConfigInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csBWSConfigInfoSequence_0 (const _IDL_SEQ_csBWSConfigInfoSequence_0&);

    ~_IDL_SEQ_csBWSConfigInfoSequence_0 ();

    _IDL_SEQ_csBWSConfigInfoSequence_0& operator= (const _IDL_SEQ_csBWSConfigInfoSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csBWSConfigInfo& operator [] (::CORBA::ULong indx);
    const csBWSConfigInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csBWSConfigInfo* get_buffer (::CORBA::Boolean orphan=0);
    const csBWSConfigInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csBWSConfigInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csBWSConfigInfo* src, csBWSConfigInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csBWSConfigInfo* data); 
  public:

    static csBWSConfigInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csBWSConfigInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csBWSConfigInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csBWSConfigInfoSequence_0> csBWSConfigInfoSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csBWSConfigInfoSequence_0* _IDL_SEQ_csBWSConfigInfoSequence_0_vPtr;
typedef const _IDL_SEQ_csBWSConfigInfoSequence_0* _IDL_SEQ_csBWSConfigInfoSequence_0_cvPtr;

class  _IDL_SEQ_csBWSConfigInfoSequence_0_var
{
    public:

    _IDL_SEQ_csBWSConfigInfoSequence_0_var ();

    _IDL_SEQ_csBWSConfigInfoSequence_0_var (_IDL_SEQ_csBWSConfigInfoSequence_0 *_p);

    _IDL_SEQ_csBWSConfigInfoSequence_0_var (const _IDL_SEQ_csBWSConfigInfoSequence_0_var &_s);

    _IDL_SEQ_csBWSConfigInfoSequence_0_var &operator= (_IDL_SEQ_csBWSConfigInfoSequence_0 *_p);

    _IDL_SEQ_csBWSConfigInfoSequence_0_var &operator= (const _IDL_SEQ_csBWSConfigInfoSequence_0_var &_s);

    ~_IDL_SEQ_csBWSConfigInfoSequence_0_var ();

    _IDL_SEQ_csBWSConfigInfoSequence_0* operator-> ();

    operator _IDL_SEQ_csBWSConfigInfoSequence_0_cvPtr () const;

    operator _IDL_SEQ_csBWSConfigInfoSequence_0_vPtr& ();

    operator _IDL_SEQ_csBWSConfigInfoSequence_0() const;

    const csBWSConfigInfo& operator[] (::CORBA::ULong index) const;
    csBWSConfigInfo& operator[] (::CORBA::ULong index);
    const csBWSConfigInfo& operator[] (int index) const;
    csBWSConfigInfo& operator[] (int index);
    const _IDL_SEQ_csBWSConfigInfoSequence_0& in() const;
    _IDL_SEQ_csBWSConfigInfoSequence_0& inout();
    _IDL_SEQ_csBWSConfigInfoSequence_0*& out();
    _IDL_SEQ_csBWSConfigInfoSequence_0* _retn();

    protected:
    _IDL_SEQ_csBWSConfigInfoSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csBWSConfigInfoSequence_0 _csBWSConfigInfoSequence_seq;
    typedef _IDL_SEQ_csBWSConfigInfoSequence_0 _csBWSConfigInfoSequence_seq_1;
    typedef _IDL_SEQ_csBWSConfigInfoSequence_0 csBWSConfigInfoSequence;
    typedef _IDL_SEQ_csBWSConfigInfoSequence_0_var csBWSConfigInfoSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSConfigInfoSequence;
    class  csBWSConfigInfoInqInParm_struct_var;
    struct  csBWSConfigInfoInqInParm_struct {
        typedef csBWSConfigInfoInqInParm_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::CORBA::String_StructElem zoneID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csBWSConfigInfoInqInParm_struct();
       csBWSConfigInfoInqInParm_struct(const csBWSConfigInfoInqInParm_struct&);
       csBWSConfigInfoInqInParm_struct& operator=(const csBWSConfigInfoInqInParm_struct&);
       static CORBA::Info<csBWSConfigInfoInqInParm_struct> csBWSConfigInfoInqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csBWSConfigInfoInqInParm_struct


typedef csBWSConfigInfoInqInParm_struct* csBWSConfigInfoInqInParm_struct_vPtr;
typedef const csBWSConfigInfoInqInParm_struct* csBWSConfigInfoInqInParm_struct_cvPtr;

class  csBWSConfigInfoInqInParm_struct_var
{
    public:

    csBWSConfigInfoInqInParm_struct_var ();

    csBWSConfigInfoInqInParm_struct_var (csBWSConfigInfoInqInParm_struct *_p);

    csBWSConfigInfoInqInParm_struct_var (const csBWSConfigInfoInqInParm_struct_var &_s);

    csBWSConfigInfoInqInParm_struct_var &operator= (csBWSConfigInfoInqInParm_struct *_p);

    csBWSConfigInfoInqInParm_struct_var &operator= (const csBWSConfigInfoInqInParm_struct_var &_s);

    ~csBWSConfigInfoInqInParm_struct_var ();

    csBWSConfigInfoInqInParm_struct* operator-> ();

    const csBWSConfigInfoInqInParm_struct& in() const;
    csBWSConfigInfoInqInParm_struct& inout();
    csBWSConfigInfoInqInParm_struct*& out();
    csBWSConfigInfoInqInParm_struct* _retn();

    operator csBWSConfigInfoInqInParm_struct_cvPtr () const;

    operator csBWSConfigInfoInqInParm_struct_vPtr& ();

    operator const csBWSConfigInfoInqInParm_struct& () const;

    operator csBWSConfigInfoInqInParm_struct& ();

    protected:
    csBWSConfigInfoInqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csBWSConfigInfoInqInParm_struct;
    typedef csBWSConfigInfoInqInParm_struct csBWSConfigInfoInqInParm;
    typedef csBWSConfigInfoInqInParm_struct_var csBWSConfigInfoInqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSConfigInfoInqInParm;
    class  csBWSConfigInfoInqResult_struct_var;
    struct  csBWSConfigInfoInqResult_struct {
        typedef csBWSConfigInfoInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::csBWSConfigInfoSequence strBWSConfigInfoSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csBWSConfigInfoInqResult_struct();
       csBWSConfigInfoInqResult_struct(const csBWSConfigInfoInqResult_struct&);
       csBWSConfigInfoInqResult_struct& operator=(const csBWSConfigInfoInqResult_struct&);
       static CORBA::Info<csBWSConfigInfoInqResult_struct> csBWSConfigInfoInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csBWSConfigInfoInqResult_struct


typedef csBWSConfigInfoInqResult_struct* csBWSConfigInfoInqResult_struct_vPtr;
typedef const csBWSConfigInfoInqResult_struct* csBWSConfigInfoInqResult_struct_cvPtr;

class  csBWSConfigInfoInqResult_struct_var
{
    public:

    csBWSConfigInfoInqResult_struct_var ();

    csBWSConfigInfoInqResult_struct_var (csBWSConfigInfoInqResult_struct *_p);

    csBWSConfigInfoInqResult_struct_var (const csBWSConfigInfoInqResult_struct_var &_s);

    csBWSConfigInfoInqResult_struct_var &operator= (csBWSConfigInfoInqResult_struct *_p);

    csBWSConfigInfoInqResult_struct_var &operator= (const csBWSConfigInfoInqResult_struct_var &_s);

    ~csBWSConfigInfoInqResult_struct_var ();

    csBWSConfigInfoInqResult_struct* operator-> ();

    const csBWSConfigInfoInqResult_struct& in() const;
    csBWSConfigInfoInqResult_struct& inout();
    csBWSConfigInfoInqResult_struct*& out();
    csBWSConfigInfoInqResult_struct* _retn();

    operator csBWSConfigInfoInqResult_struct_cvPtr () const;

    operator csBWSConfigInfoInqResult_struct_vPtr& ();

    operator const csBWSConfigInfoInqResult_struct& () const;

    operator csBWSConfigInfoInqResult_struct& ();

    protected:
    csBWSConfigInfoInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csBWSConfigInfoInqResult_struct;
    typedef csBWSConfigInfoInqResult_struct csBWSConfigInfoInqResult;
    typedef csBWSConfigInfoInqResult_struct_var csBWSConfigInfoInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSConfigInfoInqResult;
    class  csBWSConfigChangeReqInParm_struct_var;
    struct  csBWSConfigChangeReqInParm_struct {
        typedef csBWSConfigChangeReqInParm_struct_var _var_type;
       ::CORBA::String_StructElem actionType;
       ::csBWSConfigInfoSequence strBWSConfigInfoSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csBWSConfigChangeReqInParm_struct();
       csBWSConfigChangeReqInParm_struct(const csBWSConfigChangeReqInParm_struct&);
       csBWSConfigChangeReqInParm_struct& operator=(const csBWSConfigChangeReqInParm_struct&);
       static CORBA::Info<csBWSConfigChangeReqInParm_struct> csBWSConfigChangeReqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csBWSConfigChangeReqInParm_struct


typedef csBWSConfigChangeReqInParm_struct* csBWSConfigChangeReqInParm_struct_vPtr;
typedef const csBWSConfigChangeReqInParm_struct* csBWSConfigChangeReqInParm_struct_cvPtr;

class  csBWSConfigChangeReqInParm_struct_var
{
    public:

    csBWSConfigChangeReqInParm_struct_var ();

    csBWSConfigChangeReqInParm_struct_var (csBWSConfigChangeReqInParm_struct *_p);

    csBWSConfigChangeReqInParm_struct_var (const csBWSConfigChangeReqInParm_struct_var &_s);

    csBWSConfigChangeReqInParm_struct_var &operator= (csBWSConfigChangeReqInParm_struct *_p);

    csBWSConfigChangeReqInParm_struct_var &operator= (const csBWSConfigChangeReqInParm_struct_var &_s);

    ~csBWSConfigChangeReqInParm_struct_var ();

    csBWSConfigChangeReqInParm_struct* operator-> ();

    const csBWSConfigChangeReqInParm_struct& in() const;
    csBWSConfigChangeReqInParm_struct& inout();
    csBWSConfigChangeReqInParm_struct*& out();
    csBWSConfigChangeReqInParm_struct* _retn();

    operator csBWSConfigChangeReqInParm_struct_cvPtr () const;

    operator csBWSConfigChangeReqInParm_struct_vPtr& ();

    operator const csBWSConfigChangeReqInParm_struct& () const;

    operator csBWSConfigChangeReqInParm_struct& ();

    protected:
    csBWSConfigChangeReqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csBWSConfigChangeReqInParm_struct;
    typedef csBWSConfigChangeReqInParm_struct csBWSConfigChangeReqInParm;
    typedef csBWSConfigChangeReqInParm_struct_var csBWSConfigChangeReqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSConfigChangeReqInParm;
    typedef pptBaseResult csBWSConfigChangeReqResult;
    typedef pptBaseResult_var csBWSConfigChangeReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSConfigChangeReqResult;
    class  csZoneWaferCount_struct_var;
    struct  csZoneWaferCount_struct {
        typedef csZoneWaferCount_struct_var _var_type;
       ::CORBA::String_StructElem zoneID;
       ::CORBA::Long waferCount;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csZoneWaferCount_struct();
       csZoneWaferCount_struct(const csZoneWaferCount_struct&);
       csZoneWaferCount_struct& operator=(const csZoneWaferCount_struct&);
       static CORBA::Info<csZoneWaferCount_struct> csZoneWaferCount_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
   }; // struct csZoneWaferCount_struct


typedef csZoneWaferCount_struct* csZoneWaferCount_struct_vPtr;
typedef const csZoneWaferCount_struct* csZoneWaferCount_struct_cvPtr;

class  csZoneWaferCount_struct_var
{
    public:

    csZoneWaferCount_struct_var ();

    csZoneWaferCount_struct_var (csZoneWaferCount_struct *_p);

    csZoneWaferCount_struct_var (const csZoneWaferCount_struct_var &_s);

    csZoneWaferCount_struct_var &operator= (csZoneWaferCount_struct *_p);

    csZoneWaferCount_struct_var &operator= (const csZoneWaferCount_struct_var &_s);

    ~csZoneWaferCount_struct_var ();

    csZoneWaferCount_struct* operator-> ();

    const csZoneWaferCount_struct& in() const;
    csZoneWaferCount_struct& inout();
    csZoneWaferCount_struct*& out();
    csZoneWaferCount_struct* _retn();

    operator csZoneWaferCount_struct_cvPtr () const;

    operator csZoneWaferCount_struct_vPtr& ();

    operator const csZoneWaferCount_struct& () const;

    operator csZoneWaferCount_struct& ();

    protected:
    csZoneWaferCount_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csZoneWaferCount_struct;
    typedef csZoneWaferCount_struct csZoneWaferCount;
    typedef csZoneWaferCount_struct_var csZoneWaferCount_var;
    extern  ::CORBA::TypeCode_ptr _tc_csZoneWaferCount;
class  _IDL_SEQ_csZoneWaferCountSequence_0_var;
class  _IDL_SEQ_csZoneWaferCountSequence_0 {
    public:
        typedef _IDL_SEQ_csZoneWaferCountSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csZoneWaferCount *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csZoneWaferCountSequence_0 ();
    _IDL_SEQ_csZoneWaferCountSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csZoneWaferCountSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csZoneWaferCount* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csZoneWaferCountSequence_0 (const _IDL_SEQ_csZoneWaferCountSequence_0&);

    ~_IDL_SEQ_csZoneWaferCountSequence_0 ();

    _IDL_SEQ_csZoneWaferCountSequence_0& operator= (const _IDL_SEQ_csZoneWaferCountSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csZoneWaferCount& operator [] (::CORBA::ULong indx);
    const csZoneWaferCount& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csZoneWaferCount* get_buffer (::CORBA::Boolean orphan=0);
    const csZoneWaferCount* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csZoneWaferCount* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csZoneWaferCount* src, csZoneWaferCount* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csZoneWaferCount* data); 
  public:

    static csZoneWaferCount* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csZoneWaferCount* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csZoneWaferCount* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csZoneWaferCountSequence_0> csZoneWaferCountSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csZoneWaferCountSequence_0* _IDL_SEQ_csZoneWaferCountSequence_0_vPtr;
typedef const _IDL_SEQ_csZoneWaferCountSequence_0* _IDL_SEQ_csZoneWaferCountSequence_0_cvPtr;

class  _IDL_SEQ_csZoneWaferCountSequence_0_var
{
    public:

    _IDL_SEQ_csZoneWaferCountSequence_0_var ();

    _IDL_SEQ_csZoneWaferCountSequence_0_var (_IDL_SEQ_csZoneWaferCountSequence_0 *_p);

    _IDL_SEQ_csZoneWaferCountSequence_0_var (const _IDL_SEQ_csZoneWaferCountSequence_0_var &_s);

    _IDL_SEQ_csZoneWaferCountSequence_0_var &operator= (_IDL_SEQ_csZoneWaferCountSequence_0 *_p);

    _IDL_SEQ_csZoneWaferCountSequence_0_var &operator= (const _IDL_SEQ_csZoneWaferCountSequence_0_var &_s);

    ~_IDL_SEQ_csZoneWaferCountSequence_0_var ();

    _IDL_SEQ_csZoneWaferCountSequence_0* operator-> ();

    operator _IDL_SEQ_csZoneWaferCountSequence_0_cvPtr () const;

    operator _IDL_SEQ_csZoneWaferCountSequence_0_vPtr& ();

    operator _IDL_SEQ_csZoneWaferCountSequence_0() const;

    const csZoneWaferCount& operator[] (::CORBA::ULong index) const;
    csZoneWaferCount& operator[] (::CORBA::ULong index);
    const csZoneWaferCount& operator[] (int index) const;
    csZoneWaferCount& operator[] (int index);
    const _IDL_SEQ_csZoneWaferCountSequence_0& in() const;
    _IDL_SEQ_csZoneWaferCountSequence_0& inout();
    _IDL_SEQ_csZoneWaferCountSequence_0*& out();
    _IDL_SEQ_csZoneWaferCountSequence_0* _retn();

    protected:
    _IDL_SEQ_csZoneWaferCountSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csZoneWaferCountSequence_0 _csZoneWaferCountSequence_seq;
    typedef _IDL_SEQ_csZoneWaferCountSequence_0 _csZoneWaferCountSequence_seq_1;
    typedef _IDL_SEQ_csZoneWaferCountSequence_0 csZoneWaferCountSequence;
    typedef _IDL_SEQ_csZoneWaferCountSequence_0_var csZoneWaferCountSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csZoneWaferCountSequence;
    class  csBWS_WaferCount_struct_var;
    struct  csBWS_WaferCount_struct {
        typedef csBWS_WaferCount_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::CORBA::Long waferCount;
       ::csZoneWaferCountSequence strZoneWaferCountSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csBWS_WaferCount_struct();
       csBWS_WaferCount_struct(const csBWS_WaferCount_struct&);
       csBWS_WaferCount_struct& operator=(const csBWS_WaferCount_struct&);
       static CORBA::Info<csBWS_WaferCount_struct> csBWS_WaferCount_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csBWS_WaferCount_struct


typedef csBWS_WaferCount_struct* csBWS_WaferCount_struct_vPtr;
typedef const csBWS_WaferCount_struct* csBWS_WaferCount_struct_cvPtr;

class  csBWS_WaferCount_struct_var
{
    public:

    csBWS_WaferCount_struct_var ();

    csBWS_WaferCount_struct_var (csBWS_WaferCount_struct *_p);

    csBWS_WaferCount_struct_var (const csBWS_WaferCount_struct_var &_s);

    csBWS_WaferCount_struct_var &operator= (csBWS_WaferCount_struct *_p);

    csBWS_WaferCount_struct_var &operator= (const csBWS_WaferCount_struct_var &_s);

    ~csBWS_WaferCount_struct_var ();

    csBWS_WaferCount_struct* operator-> ();

    const csBWS_WaferCount_struct& in() const;
    csBWS_WaferCount_struct& inout();
    csBWS_WaferCount_struct*& out();
    csBWS_WaferCount_struct* _retn();

    operator csBWS_WaferCount_struct_cvPtr () const;

    operator csBWS_WaferCount_struct_vPtr& ();

    operator const csBWS_WaferCount_struct& () const;

    operator csBWS_WaferCount_struct& ();

    protected:
    csBWS_WaferCount_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csBWS_WaferCount_struct;
    typedef csBWS_WaferCount_struct csBWSWaferCount;
    typedef csBWS_WaferCount_struct_var csBWSWaferCount_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSWaferCount;
class  _IDL_SEQ_csBWSWaferCountSequence_0_var;
class  _IDL_SEQ_csBWSWaferCountSequence_0 {
    public:
        typedef _IDL_SEQ_csBWSWaferCountSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csBWSWaferCount *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csBWSWaferCountSequence_0 ();
    _IDL_SEQ_csBWSWaferCountSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csBWSWaferCountSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csBWSWaferCount* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csBWSWaferCountSequence_0 (const _IDL_SEQ_csBWSWaferCountSequence_0&);

    ~_IDL_SEQ_csBWSWaferCountSequence_0 ();

    _IDL_SEQ_csBWSWaferCountSequence_0& operator= (const _IDL_SEQ_csBWSWaferCountSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csBWSWaferCount& operator [] (::CORBA::ULong indx);
    const csBWSWaferCount& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csBWSWaferCount* get_buffer (::CORBA::Boolean orphan=0);
    const csBWSWaferCount* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csBWSWaferCount* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csBWSWaferCount* src, csBWSWaferCount* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csBWSWaferCount* data); 
  public:

    static csBWSWaferCount* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csBWSWaferCount* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csBWSWaferCount* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csBWSWaferCountSequence_0> csBWSWaferCountSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csBWSWaferCountSequence_0* _IDL_SEQ_csBWSWaferCountSequence_0_vPtr;
typedef const _IDL_SEQ_csBWSWaferCountSequence_0* _IDL_SEQ_csBWSWaferCountSequence_0_cvPtr;

class  _IDL_SEQ_csBWSWaferCountSequence_0_var
{
    public:

    _IDL_SEQ_csBWSWaferCountSequence_0_var ();

    _IDL_SEQ_csBWSWaferCountSequence_0_var (_IDL_SEQ_csBWSWaferCountSequence_0 *_p);

    _IDL_SEQ_csBWSWaferCountSequence_0_var (const _IDL_SEQ_csBWSWaferCountSequence_0_var &_s);

    _IDL_SEQ_csBWSWaferCountSequence_0_var &operator= (_IDL_SEQ_csBWSWaferCountSequence_0 *_p);

    _IDL_SEQ_csBWSWaferCountSequence_0_var &operator= (const _IDL_SEQ_csBWSWaferCountSequence_0_var &_s);

    ~_IDL_SEQ_csBWSWaferCountSequence_0_var ();

    _IDL_SEQ_csBWSWaferCountSequence_0* operator-> ();

    operator _IDL_SEQ_csBWSWaferCountSequence_0_cvPtr () const;

    operator _IDL_SEQ_csBWSWaferCountSequence_0_vPtr& ();

    operator _IDL_SEQ_csBWSWaferCountSequence_0() const;

    const csBWSWaferCount& operator[] (::CORBA::ULong index) const;
    csBWSWaferCount& operator[] (::CORBA::ULong index);
    const csBWSWaferCount& operator[] (int index) const;
    csBWSWaferCount& operator[] (int index);
    const _IDL_SEQ_csBWSWaferCountSequence_0& in() const;
    _IDL_SEQ_csBWSWaferCountSequence_0& inout();
    _IDL_SEQ_csBWSWaferCountSequence_0*& out();
    _IDL_SEQ_csBWSWaferCountSequence_0* _retn();

    protected:
    _IDL_SEQ_csBWSWaferCountSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csBWSWaferCountSequence_0 _csBWSWaferCountSequence_seq;
    typedef _IDL_SEQ_csBWSWaferCountSequence_0 _csBWSWaferCountSequence_seq_1;
    typedef _IDL_SEQ_csBWSWaferCountSequence_0 csBWSWaferCountSequence;
    typedef _IDL_SEQ_csBWSWaferCountSequence_0_var csBWSWaferCountSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSWaferCountSequence;
    class  csBWSWaferData_struct_var;
    struct  csBWSWaferData_struct {
        typedef csBWSWaferData_struct_var _var_type;
       ::objectIdentifier waferID;
       ::CORBA::String_StructElem waferGradeID;
       ::objectIdentifier lotID;
       ::objectIdentifier bankID;
       ::objectIdentifier productID;
       ::CORBA::String_StructElem subLotType;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csBWSWaferData_struct();
       csBWSWaferData_struct(const csBWSWaferData_struct&);
       csBWSWaferData_struct& operator=(const csBWSWaferData_struct&);
       static CORBA::Info<csBWSWaferData_struct> csBWSWaferData_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csBWSWaferData_struct


typedef csBWSWaferData_struct* csBWSWaferData_struct_vPtr;
typedef const csBWSWaferData_struct* csBWSWaferData_struct_cvPtr;

class  csBWSWaferData_struct_var
{
    public:

    csBWSWaferData_struct_var ();

    csBWSWaferData_struct_var (csBWSWaferData_struct *_p);

    csBWSWaferData_struct_var (const csBWSWaferData_struct_var &_s);

    csBWSWaferData_struct_var &operator= (csBWSWaferData_struct *_p);

    csBWSWaferData_struct_var &operator= (const csBWSWaferData_struct_var &_s);

    ~csBWSWaferData_struct_var ();

    csBWSWaferData_struct* operator-> ();

    const csBWSWaferData_struct& in() const;
    csBWSWaferData_struct& inout();
    csBWSWaferData_struct*& out();
    csBWSWaferData_struct* _retn();

    operator csBWSWaferData_struct_cvPtr () const;

    operator csBWSWaferData_struct_vPtr& ();

    operator const csBWSWaferData_struct& () const;

    operator csBWSWaferData_struct& ();

    protected:
    csBWSWaferData_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csBWSWaferData_struct;
    typedef csBWSWaferData_struct csBWSWaferData;
    typedef csBWSWaferData_struct_var csBWSWaferData_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSWaferData;
    class  csBWSWaferListInqInParm_struct_var;
    struct  csBWSWaferListInqInParm_struct {
        typedef csBWSWaferListInqInParm_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::CORBA::Long lSearchType;
       ::CORBA::String_StructElem zoneID;
       ::csBWSWaferData strBWSWaferData;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csBWSWaferListInqInParm_struct();
       csBWSWaferListInqInParm_struct(const csBWSWaferListInqInParm_struct&);
       csBWSWaferListInqInParm_struct& operator=(const csBWSWaferListInqInParm_struct&);
       static CORBA::Info<csBWSWaferListInqInParm_struct> csBWSWaferListInqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csBWSWaferListInqInParm_struct


typedef csBWSWaferListInqInParm_struct* csBWSWaferListInqInParm_struct_vPtr;
typedef const csBWSWaferListInqInParm_struct* csBWSWaferListInqInParm_struct_cvPtr;

class  csBWSWaferListInqInParm_struct_var
{
    public:

    csBWSWaferListInqInParm_struct_var ();

    csBWSWaferListInqInParm_struct_var (csBWSWaferListInqInParm_struct *_p);

    csBWSWaferListInqInParm_struct_var (const csBWSWaferListInqInParm_struct_var &_s);

    csBWSWaferListInqInParm_struct_var &operator= (csBWSWaferListInqInParm_struct *_p);

    csBWSWaferListInqInParm_struct_var &operator= (const csBWSWaferListInqInParm_struct_var &_s);

    ~csBWSWaferListInqInParm_struct_var ();

    csBWSWaferListInqInParm_struct* operator-> ();

    const csBWSWaferListInqInParm_struct& in() const;
    csBWSWaferListInqInParm_struct& inout();
    csBWSWaferListInqInParm_struct*& out();
    csBWSWaferListInqInParm_struct* _retn();

    operator csBWSWaferListInqInParm_struct_cvPtr () const;

    operator csBWSWaferListInqInParm_struct_vPtr& ();

    operator const csBWSWaferListInqInParm_struct& () const;

    operator csBWSWaferListInqInParm_struct& ();

    protected:
    csBWSWaferListInqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csBWSWaferListInqInParm_struct;
    typedef csBWSWaferListInqInParm_struct csBWSWaferListInqInParm;
    typedef csBWSWaferListInqInParm_struct_var csBWSWaferListInqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSWaferListInqInParm;
class  _IDL_SEQ_csBWSWaferDataSequence_0_var;
class  _IDL_SEQ_csBWSWaferDataSequence_0 {
    public:
        typedef _IDL_SEQ_csBWSWaferDataSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csBWSWaferData *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csBWSWaferDataSequence_0 ();
    _IDL_SEQ_csBWSWaferDataSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csBWSWaferDataSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csBWSWaferData* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csBWSWaferDataSequence_0 (const _IDL_SEQ_csBWSWaferDataSequence_0&);

    ~_IDL_SEQ_csBWSWaferDataSequence_0 ();

    _IDL_SEQ_csBWSWaferDataSequence_0& operator= (const _IDL_SEQ_csBWSWaferDataSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csBWSWaferData& operator [] (::CORBA::ULong indx);
    const csBWSWaferData& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csBWSWaferData* get_buffer (::CORBA::Boolean orphan=0);
    const csBWSWaferData* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csBWSWaferData* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csBWSWaferData* src, csBWSWaferData* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csBWSWaferData* data); 
  public:

    static csBWSWaferData* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csBWSWaferData* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csBWSWaferData* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csBWSWaferDataSequence_0> csBWSWaferDataSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csBWSWaferDataSequence_0* _IDL_SEQ_csBWSWaferDataSequence_0_vPtr;
typedef const _IDL_SEQ_csBWSWaferDataSequence_0* _IDL_SEQ_csBWSWaferDataSequence_0_cvPtr;

class  _IDL_SEQ_csBWSWaferDataSequence_0_var
{
    public:

    _IDL_SEQ_csBWSWaferDataSequence_0_var ();

    _IDL_SEQ_csBWSWaferDataSequence_0_var (_IDL_SEQ_csBWSWaferDataSequence_0 *_p);

    _IDL_SEQ_csBWSWaferDataSequence_0_var (const _IDL_SEQ_csBWSWaferDataSequence_0_var &_s);

    _IDL_SEQ_csBWSWaferDataSequence_0_var &operator= (_IDL_SEQ_csBWSWaferDataSequence_0 *_p);

    _IDL_SEQ_csBWSWaferDataSequence_0_var &operator= (const _IDL_SEQ_csBWSWaferDataSequence_0_var &_s);

    ~_IDL_SEQ_csBWSWaferDataSequence_0_var ();

    _IDL_SEQ_csBWSWaferDataSequence_0* operator-> ();

    operator _IDL_SEQ_csBWSWaferDataSequence_0_cvPtr () const;

    operator _IDL_SEQ_csBWSWaferDataSequence_0_vPtr& ();

    operator _IDL_SEQ_csBWSWaferDataSequence_0() const;

    const csBWSWaferData& operator[] (::CORBA::ULong index) const;
    csBWSWaferData& operator[] (::CORBA::ULong index);
    const csBWSWaferData& operator[] (int index) const;
    csBWSWaferData& operator[] (int index);
    const _IDL_SEQ_csBWSWaferDataSequence_0& in() const;
    _IDL_SEQ_csBWSWaferDataSequence_0& inout();
    _IDL_SEQ_csBWSWaferDataSequence_0*& out();
    _IDL_SEQ_csBWSWaferDataSequence_0* _retn();

    protected:
    _IDL_SEQ_csBWSWaferDataSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csBWSWaferDataSequence_0 _csBWSWaferDataSequence_seq;
    typedef _IDL_SEQ_csBWSWaferDataSequence_0 _csBWSWaferDataSequence_seq_1;
    typedef _IDL_SEQ_csBWSWaferDataSequence_0 csBWSWaferDataSequence;
    typedef _IDL_SEQ_csBWSWaferDataSequence_0_var csBWSWaferDataSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSWaferDataSequence;
    class  csBWSZoneData_struct_var;
    struct  csBWSZoneData_struct {
        typedef csBWSZoneData_struct_var _var_type;
       ::CORBA::String_StructElem zoneID;
       ::csBWSWaferDataSequence strBWSWaferDataSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csBWSZoneData_struct();
       csBWSZoneData_struct(const csBWSZoneData_struct&);
       csBWSZoneData_struct& operator=(const csBWSZoneData_struct&);
       static CORBA::Info<csBWSZoneData_struct> csBWSZoneData_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csBWSZoneData_struct


typedef csBWSZoneData_struct* csBWSZoneData_struct_vPtr;
typedef const csBWSZoneData_struct* csBWSZoneData_struct_cvPtr;

class  csBWSZoneData_struct_var
{
    public:

    csBWSZoneData_struct_var ();

    csBWSZoneData_struct_var (csBWSZoneData_struct *_p);

    csBWSZoneData_struct_var (const csBWSZoneData_struct_var &_s);

    csBWSZoneData_struct_var &operator= (csBWSZoneData_struct *_p);

    csBWSZoneData_struct_var &operator= (const csBWSZoneData_struct_var &_s);

    ~csBWSZoneData_struct_var ();

    csBWSZoneData_struct* operator-> ();

    const csBWSZoneData_struct& in() const;
    csBWSZoneData_struct& inout();
    csBWSZoneData_struct*& out();
    csBWSZoneData_struct* _retn();

    operator csBWSZoneData_struct_cvPtr () const;

    operator csBWSZoneData_struct_vPtr& ();

    operator const csBWSZoneData_struct& () const;

    operator csBWSZoneData_struct& ();

    protected:
    csBWSZoneData_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csBWSZoneData_struct;
    typedef csBWSZoneData_struct csBWSZoneData;
    typedef csBWSZoneData_struct_var csBWSZoneData_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSZoneData;
class  _IDL_SEQ_csBWSZoneDataSequence_0_var;
class  _IDL_SEQ_csBWSZoneDataSequence_0 {
    public:
        typedef _IDL_SEQ_csBWSZoneDataSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csBWSZoneData *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csBWSZoneDataSequence_0 ();
    _IDL_SEQ_csBWSZoneDataSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csBWSZoneDataSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csBWSZoneData* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csBWSZoneDataSequence_0 (const _IDL_SEQ_csBWSZoneDataSequence_0&);

    ~_IDL_SEQ_csBWSZoneDataSequence_0 ();

    _IDL_SEQ_csBWSZoneDataSequence_0& operator= (const _IDL_SEQ_csBWSZoneDataSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csBWSZoneData& operator [] (::CORBA::ULong indx);
    const csBWSZoneData& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csBWSZoneData* get_buffer (::CORBA::Boolean orphan=0);
    const csBWSZoneData* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csBWSZoneData* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csBWSZoneData* src, csBWSZoneData* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csBWSZoneData* data); 
  public:

    static csBWSZoneData* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csBWSZoneData* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csBWSZoneData* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csBWSZoneDataSequence_0> csBWSZoneDataSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csBWSZoneDataSequence_0* _IDL_SEQ_csBWSZoneDataSequence_0_vPtr;
typedef const _IDL_SEQ_csBWSZoneDataSequence_0* _IDL_SEQ_csBWSZoneDataSequence_0_cvPtr;

class  _IDL_SEQ_csBWSZoneDataSequence_0_var
{
    public:

    _IDL_SEQ_csBWSZoneDataSequence_0_var ();

    _IDL_SEQ_csBWSZoneDataSequence_0_var (_IDL_SEQ_csBWSZoneDataSequence_0 *_p);

    _IDL_SEQ_csBWSZoneDataSequence_0_var (const _IDL_SEQ_csBWSZoneDataSequence_0_var &_s);

    _IDL_SEQ_csBWSZoneDataSequence_0_var &operator= (_IDL_SEQ_csBWSZoneDataSequence_0 *_p);

    _IDL_SEQ_csBWSZoneDataSequence_0_var &operator= (const _IDL_SEQ_csBWSZoneDataSequence_0_var &_s);

    ~_IDL_SEQ_csBWSZoneDataSequence_0_var ();

    _IDL_SEQ_csBWSZoneDataSequence_0* operator-> ();

    operator _IDL_SEQ_csBWSZoneDataSequence_0_cvPtr () const;

    operator _IDL_SEQ_csBWSZoneDataSequence_0_vPtr& ();

    operator _IDL_SEQ_csBWSZoneDataSequence_0() const;

    const csBWSZoneData& operator[] (::CORBA::ULong index) const;
    csBWSZoneData& operator[] (::CORBA::ULong index);
    const csBWSZoneData& operator[] (int index) const;
    csBWSZoneData& operator[] (int index);
    const _IDL_SEQ_csBWSZoneDataSequence_0& in() const;
    _IDL_SEQ_csBWSZoneDataSequence_0& inout();
    _IDL_SEQ_csBWSZoneDataSequence_0*& out();
    _IDL_SEQ_csBWSZoneDataSequence_0* _retn();

    protected:
    _IDL_SEQ_csBWSZoneDataSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csBWSZoneDataSequence_0 _csBWSZoneDataSequence_seq;
    typedef _IDL_SEQ_csBWSZoneDataSequence_0 _csBWSZoneDataSequence_seq_1;
    typedef _IDL_SEQ_csBWSZoneDataSequence_0 csBWSZoneDataSequence;
    typedef _IDL_SEQ_csBWSZoneDataSequence_0_var csBWSZoneDataSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSZoneDataSequence;
    class  csBWSData_struct_var;
    struct  csBWSData_struct {
        typedef csBWSData_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::csBWSZoneDataSequence strBWSZoneDataSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csBWSData_struct();
       csBWSData_struct(const csBWSData_struct&);
       csBWSData_struct& operator=(const csBWSData_struct&);
       static CORBA::Info<csBWSData_struct> csBWSData_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csBWSData_struct


typedef csBWSData_struct* csBWSData_struct_vPtr;
typedef const csBWSData_struct* csBWSData_struct_cvPtr;

class  csBWSData_struct_var
{
    public:

    csBWSData_struct_var ();

    csBWSData_struct_var (csBWSData_struct *_p);

    csBWSData_struct_var (const csBWSData_struct_var &_s);

    csBWSData_struct_var &operator= (csBWSData_struct *_p);

    csBWSData_struct_var &operator= (const csBWSData_struct_var &_s);

    ~csBWSData_struct_var ();

    csBWSData_struct* operator-> ();

    const csBWSData_struct& in() const;
    csBWSData_struct& inout();
    csBWSData_struct*& out();
    csBWSData_struct* _retn();

    operator csBWSData_struct_cvPtr () const;

    operator csBWSData_struct_vPtr& ();

    operator const csBWSData_struct& () const;

    operator csBWSData_struct& ();

    protected:
    csBWSData_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csBWSData_struct;
    typedef csBWSData_struct csBWSData;
    typedef csBWSData_struct_var csBWSData_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSData;
class  _IDL_SEQ_csBWSDataSequence_0_var;
class  _IDL_SEQ_csBWSDataSequence_0 {
    public:
        typedef _IDL_SEQ_csBWSDataSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csBWSData *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csBWSDataSequence_0 ();
    _IDL_SEQ_csBWSDataSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csBWSDataSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csBWSData* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csBWSDataSequence_0 (const _IDL_SEQ_csBWSDataSequence_0&);

    ~_IDL_SEQ_csBWSDataSequence_0 ();

    _IDL_SEQ_csBWSDataSequence_0& operator= (const _IDL_SEQ_csBWSDataSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csBWSData& operator [] (::CORBA::ULong indx);
    const csBWSData& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csBWSData* get_buffer (::CORBA::Boolean orphan=0);
    const csBWSData* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csBWSData* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csBWSData* src, csBWSData* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csBWSData* data); 
  public:

    static csBWSData* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csBWSData* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csBWSData* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csBWSDataSequence_0> csBWSDataSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csBWSDataSequence_0* _IDL_SEQ_csBWSDataSequence_0_vPtr;
typedef const _IDL_SEQ_csBWSDataSequence_0* _IDL_SEQ_csBWSDataSequence_0_cvPtr;

class  _IDL_SEQ_csBWSDataSequence_0_var
{
    public:

    _IDL_SEQ_csBWSDataSequence_0_var ();

    _IDL_SEQ_csBWSDataSequence_0_var (_IDL_SEQ_csBWSDataSequence_0 *_p);

    _IDL_SEQ_csBWSDataSequence_0_var (const _IDL_SEQ_csBWSDataSequence_0_var &_s);

    _IDL_SEQ_csBWSDataSequence_0_var &operator= (_IDL_SEQ_csBWSDataSequence_0 *_p);

    _IDL_SEQ_csBWSDataSequence_0_var &operator= (const _IDL_SEQ_csBWSDataSequence_0_var &_s);

    ~_IDL_SEQ_csBWSDataSequence_0_var ();

    _IDL_SEQ_csBWSDataSequence_0* operator-> ();

    operator _IDL_SEQ_csBWSDataSequence_0_cvPtr () const;

    operator _IDL_SEQ_csBWSDataSequence_0_vPtr& ();

    operator _IDL_SEQ_csBWSDataSequence_0() const;

    const csBWSData& operator[] (::CORBA::ULong index) const;
    csBWSData& operator[] (::CORBA::ULong index);
    const csBWSData& operator[] (int index) const;
    csBWSData& operator[] (int index);
    const _IDL_SEQ_csBWSDataSequence_0& in() const;
    _IDL_SEQ_csBWSDataSequence_0& inout();
    _IDL_SEQ_csBWSDataSequence_0*& out();
    _IDL_SEQ_csBWSDataSequence_0* _retn();

    protected:
    _IDL_SEQ_csBWSDataSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csBWSDataSequence_0 _csBWSDataSequence_seq;
    typedef _IDL_SEQ_csBWSDataSequence_0 _csBWSDataSequence_seq_1;
    typedef _IDL_SEQ_csBWSDataSequence_0 csBWSDataSequence;
    typedef _IDL_SEQ_csBWSDataSequence_0_var csBWSDataSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSDataSequence;
    class  csBWSWaferListInqResult_struct_var;
    struct  csBWSWaferListInqResult_struct {
        typedef csBWSWaferListInqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::csBWSDataSequence strBWSDataSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csBWSWaferListInqResult_struct();
       csBWSWaferListInqResult_struct(const csBWSWaferListInqResult_struct&);
       csBWSWaferListInqResult_struct& operator=(const csBWSWaferListInqResult_struct&);
       static CORBA::Info<csBWSWaferListInqResult_struct> csBWSWaferListInqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csBWSWaferListInqResult_struct


typedef csBWSWaferListInqResult_struct* csBWSWaferListInqResult_struct_vPtr;
typedef const csBWSWaferListInqResult_struct* csBWSWaferListInqResult_struct_cvPtr;

class  csBWSWaferListInqResult_struct_var
{
    public:

    csBWSWaferListInqResult_struct_var ();

    csBWSWaferListInqResult_struct_var (csBWSWaferListInqResult_struct *_p);

    csBWSWaferListInqResult_struct_var (const csBWSWaferListInqResult_struct_var &_s);

    csBWSWaferListInqResult_struct_var &operator= (csBWSWaferListInqResult_struct *_p);

    csBWSWaferListInqResult_struct_var &operator= (const csBWSWaferListInqResult_struct_var &_s);

    ~csBWSWaferListInqResult_struct_var ();

    csBWSWaferListInqResult_struct* operator-> ();

    const csBWSWaferListInqResult_struct& in() const;
    csBWSWaferListInqResult_struct& inout();
    csBWSWaferListInqResult_struct*& out();
    csBWSWaferListInqResult_struct* _retn();

    operator csBWSWaferListInqResult_struct_cvPtr () const;

    operator csBWSWaferListInqResult_struct_vPtr& ();

    operator const csBWSWaferListInqResult_struct& () const;

    operator csBWSWaferListInqResult_struct& ();

    protected:
    csBWSWaferListInqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csBWSWaferListInqResult_struct;
    typedef csBWSWaferListInqResult_struct csBWSWaferListInqResult;
    typedef csBWSWaferListInqResult_struct_var csBWSWaferListInqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSWaferListInqResult;
    class  csBWSInventoryReqInParm_struct_var;
    struct  csBWSInventoryReqInParm_struct {
        typedef csBWSInventoryReqInParm_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::CORBA::String_StructElem zoneID;
       ::objectIdentifier waferID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csBWSInventoryReqInParm_struct();
       csBWSInventoryReqInParm_struct(const csBWSInventoryReqInParm_struct&);
       csBWSInventoryReqInParm_struct& operator=(const csBWSInventoryReqInParm_struct&);
       static CORBA::Info<csBWSInventoryReqInParm_struct> csBWSInventoryReqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csBWSInventoryReqInParm_struct


typedef csBWSInventoryReqInParm_struct* csBWSInventoryReqInParm_struct_vPtr;
typedef const csBWSInventoryReqInParm_struct* csBWSInventoryReqInParm_struct_cvPtr;

class  csBWSInventoryReqInParm_struct_var
{
    public:

    csBWSInventoryReqInParm_struct_var ();

    csBWSInventoryReqInParm_struct_var (csBWSInventoryReqInParm_struct *_p);

    csBWSInventoryReqInParm_struct_var (const csBWSInventoryReqInParm_struct_var &_s);

    csBWSInventoryReqInParm_struct_var &operator= (csBWSInventoryReqInParm_struct *_p);

    csBWSInventoryReqInParm_struct_var &operator= (const csBWSInventoryReqInParm_struct_var &_s);

    ~csBWSInventoryReqInParm_struct_var ();

    csBWSInventoryReqInParm_struct* operator-> ();

    const csBWSInventoryReqInParm_struct& in() const;
    csBWSInventoryReqInParm_struct& inout();
    csBWSInventoryReqInParm_struct*& out();
    csBWSInventoryReqInParm_struct* _retn();

    operator csBWSInventoryReqInParm_struct_cvPtr () const;

    operator csBWSInventoryReqInParm_struct_vPtr& ();

    operator const csBWSInventoryReqInParm_struct& () const;

    operator csBWSInventoryReqInParm_struct& ();

    protected:
    csBWSInventoryReqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csBWSInventoryReqInParm_struct;
    typedef csBWSInventoryReqInParm_struct csBWSInventoryReqInParm;
    typedef csBWSInventoryReqInParm_struct_var csBWSInventoryReqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSInventoryReqInParm;
    class  csZoneInventoryInfo_struct_var;
    struct  csZoneInventoryInfo_struct {
        typedef csZoneInventoryInfo_struct_var _var_type;
       ::CORBA::String_StructElem zoneID;
       ::CORBA::Long usedCapacity;
       ::pptWaferSequence waferIDs;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csZoneInventoryInfo_struct();
       csZoneInventoryInfo_struct(const csZoneInventoryInfo_struct&);
       csZoneInventoryInfo_struct& operator=(const csZoneInventoryInfo_struct&);
       static CORBA::Info<csZoneInventoryInfo_struct> csZoneInventoryInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csZoneInventoryInfo_struct


typedef csZoneInventoryInfo_struct* csZoneInventoryInfo_struct_vPtr;
typedef const csZoneInventoryInfo_struct* csZoneInventoryInfo_struct_cvPtr;

class  csZoneInventoryInfo_struct_var
{
    public:

    csZoneInventoryInfo_struct_var ();

    csZoneInventoryInfo_struct_var (csZoneInventoryInfo_struct *_p);

    csZoneInventoryInfo_struct_var (const csZoneInventoryInfo_struct_var &_s);

    csZoneInventoryInfo_struct_var &operator= (csZoneInventoryInfo_struct *_p);

    csZoneInventoryInfo_struct_var &operator= (const csZoneInventoryInfo_struct_var &_s);

    ~csZoneInventoryInfo_struct_var ();

    csZoneInventoryInfo_struct* operator-> ();

    const csZoneInventoryInfo_struct& in() const;
    csZoneInventoryInfo_struct& inout();
    csZoneInventoryInfo_struct*& out();
    csZoneInventoryInfo_struct* _retn();

    operator csZoneInventoryInfo_struct_cvPtr () const;

    operator csZoneInventoryInfo_struct_vPtr& ();

    operator const csZoneInventoryInfo_struct& () const;

    operator csZoneInventoryInfo_struct& ();

    protected:
    csZoneInventoryInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csZoneInventoryInfo_struct;
    typedef csZoneInventoryInfo_struct csZoneInventoryInfo;
    typedef csZoneInventoryInfo_struct_var csZoneInventoryInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csZoneInventoryInfo;
class  _IDL_SEQ_csZoneInventoryInfoSequence_0_var;
class  _IDL_SEQ_csZoneInventoryInfoSequence_0 {
    public:
        typedef _IDL_SEQ_csZoneInventoryInfoSequence_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    csZoneInventoryInfo *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_csZoneInventoryInfoSequence_0 ();
    _IDL_SEQ_csZoneInventoryInfoSequence_0 (::CORBA::ULong max);
    _IDL_SEQ_csZoneInventoryInfoSequence_0 (::CORBA::ULong max, ::CORBA::ULong length, csZoneInventoryInfo* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_csZoneInventoryInfoSequence_0 (const _IDL_SEQ_csZoneInventoryInfoSequence_0&);

    ~_IDL_SEQ_csZoneInventoryInfoSequence_0 ();

    _IDL_SEQ_csZoneInventoryInfoSequence_0& operator= (const _IDL_SEQ_csZoneInventoryInfoSequence_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    csZoneInventoryInfo& operator [] (::CORBA::ULong indx);
    const csZoneInventoryInfo& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    csZoneInventoryInfo* get_buffer (::CORBA::Boolean orphan=0);
    const csZoneInventoryInfo* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, csZoneInventoryInfo* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, csZoneInventoryInfo* src, csZoneInventoryInfo* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, csZoneInventoryInfo* data); 
  public:

    static csZoneInventoryInfo* SOMLINK allocbuf(::CORBA::ULong nelems);
    static csZoneInventoryInfo* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(csZoneInventoryInfo* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_csZoneInventoryInfoSequence_0> csZoneInventoryInfoSequence_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_csZoneInventoryInfoSequence_0* _IDL_SEQ_csZoneInventoryInfoSequence_0_vPtr;
typedef const _IDL_SEQ_csZoneInventoryInfoSequence_0* _IDL_SEQ_csZoneInventoryInfoSequence_0_cvPtr;

class  _IDL_SEQ_csZoneInventoryInfoSequence_0_var
{
    public:

    _IDL_SEQ_csZoneInventoryInfoSequence_0_var ();

    _IDL_SEQ_csZoneInventoryInfoSequence_0_var (_IDL_SEQ_csZoneInventoryInfoSequence_0 *_p);

    _IDL_SEQ_csZoneInventoryInfoSequence_0_var (const _IDL_SEQ_csZoneInventoryInfoSequence_0_var &_s);

    _IDL_SEQ_csZoneInventoryInfoSequence_0_var &operator= (_IDL_SEQ_csZoneInventoryInfoSequence_0 *_p);

    _IDL_SEQ_csZoneInventoryInfoSequence_0_var &operator= (const _IDL_SEQ_csZoneInventoryInfoSequence_0_var &_s);

    ~_IDL_SEQ_csZoneInventoryInfoSequence_0_var ();

    _IDL_SEQ_csZoneInventoryInfoSequence_0* operator-> ();

    operator _IDL_SEQ_csZoneInventoryInfoSequence_0_cvPtr () const;

    operator _IDL_SEQ_csZoneInventoryInfoSequence_0_vPtr& ();

    operator _IDL_SEQ_csZoneInventoryInfoSequence_0() const;

    const csZoneInventoryInfo& operator[] (::CORBA::ULong index) const;
    csZoneInventoryInfo& operator[] (::CORBA::ULong index);
    const csZoneInventoryInfo& operator[] (int index) const;
    csZoneInventoryInfo& operator[] (int index);
    const _IDL_SEQ_csZoneInventoryInfoSequence_0& in() const;
    _IDL_SEQ_csZoneInventoryInfoSequence_0& inout();
    _IDL_SEQ_csZoneInventoryInfoSequence_0*& out();
    _IDL_SEQ_csZoneInventoryInfoSequence_0* _retn();

    protected:
    _IDL_SEQ_csZoneInventoryInfoSequence_0 *_ptr;
};

    typedef _IDL_SEQ_csZoneInventoryInfoSequence_0 _csZoneInventoryInfoSequence_seq;
    typedef _IDL_SEQ_csZoneInventoryInfoSequence_0 _csZoneInventoryInfoSequence_seq_1;
    typedef _IDL_SEQ_csZoneInventoryInfoSequence_0 csZoneInventoryInfoSequence;
    typedef _IDL_SEQ_csZoneInventoryInfoSequence_0_var csZoneInventoryInfoSequence_var;
    extern  ::CORBA::TypeCode_ptr _tc_csZoneInventoryInfoSequence;
    class  csBWSInventoryInfo_struct_var;
    struct  csBWSInventoryInfo_struct {
        typedef csBWSInventoryInfo_struct_var _var_type;
       ::objectIdentifier BWSID;
       ::CORBA::Long usedCapacity;
       ::csZoneInventoryInfoSequence strZoneInvInfoSeq;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csBWSInventoryInfo_struct();
       csBWSInventoryInfo_struct(const csBWSInventoryInfo_struct&);
       csBWSInventoryInfo_struct& operator=(const csBWSInventoryInfo_struct&);
       static CORBA::Info<csBWSInventoryInfo_struct> csBWSInventoryInfo_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csBWSInventoryInfo_struct


typedef csBWSInventoryInfo_struct* csBWSInventoryInfo_struct_vPtr;
typedef const csBWSInventoryInfo_struct* csBWSInventoryInfo_struct_cvPtr;

class  csBWSInventoryInfo_struct_var
{
    public:

    csBWSInventoryInfo_struct_var ();

    csBWSInventoryInfo_struct_var (csBWSInventoryInfo_struct *_p);

    csBWSInventoryInfo_struct_var (const csBWSInventoryInfo_struct_var &_s);

    csBWSInventoryInfo_struct_var &operator= (csBWSInventoryInfo_struct *_p);

    csBWSInventoryInfo_struct_var &operator= (const csBWSInventoryInfo_struct_var &_s);

    ~csBWSInventoryInfo_struct_var ();

    csBWSInventoryInfo_struct* operator-> ();

    const csBWSInventoryInfo_struct& in() const;
    csBWSInventoryInfo_struct& inout();
    csBWSInventoryInfo_struct*& out();
    csBWSInventoryInfo_struct* _retn();

    operator csBWSInventoryInfo_struct_cvPtr () const;

    operator csBWSInventoryInfo_struct_vPtr& ();

    operator const csBWSInventoryInfo_struct& () const;

    operator csBWSInventoryInfo_struct& ();

    protected:
    csBWSInventoryInfo_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csBWSInventoryInfo_struct;
    typedef csBWSInventoryInfo_struct csBWSInventoryInfo;
    typedef csBWSInventoryInfo_struct_var csBWSInventoryInfo_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSInventoryInfo;
    class  csBWSInventoryReqResult_struct_var;
    struct  csBWSInventoryReqResult_struct {
        typedef csBWSInventoryReqResult_struct_var _var_type;
       ::pptRetCode strResult;
       ::csBWSInventoryInfo strBWSInventoryInfo;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csBWSInventoryReqResult_struct();
       csBWSInventoryReqResult_struct(const csBWSInventoryReqResult_struct&);
       csBWSInventoryReqResult_struct& operator=(const csBWSInventoryReqResult_struct&);
       static CORBA::Info<csBWSInventoryReqResult_struct> csBWSInventoryReqResult_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csBWSInventoryReqResult_struct


typedef csBWSInventoryReqResult_struct* csBWSInventoryReqResult_struct_vPtr;
typedef const csBWSInventoryReqResult_struct* csBWSInventoryReqResult_struct_cvPtr;

class  csBWSInventoryReqResult_struct_var
{
    public:

    csBWSInventoryReqResult_struct_var ();

    csBWSInventoryReqResult_struct_var (csBWSInventoryReqResult_struct *_p);

    csBWSInventoryReqResult_struct_var (const csBWSInventoryReqResult_struct_var &_s);

    csBWSInventoryReqResult_struct_var &operator= (csBWSInventoryReqResult_struct *_p);

    csBWSInventoryReqResult_struct_var &operator= (const csBWSInventoryReqResult_struct_var &_s);

    ~csBWSInventoryReqResult_struct_var ();

    csBWSInventoryReqResult_struct* operator-> ();

    const csBWSInventoryReqResult_struct& in() const;
    csBWSInventoryReqResult_struct& inout();
    csBWSInventoryReqResult_struct*& out();
    csBWSInventoryReqResult_struct* _retn();

    operator csBWSInventoryReqResult_struct_cvPtr () const;

    operator csBWSInventoryReqResult_struct_vPtr& ();

    operator const csBWSInventoryReqResult_struct& () const;

    operator csBWSInventoryReqResult_struct& ();

    protected:
    csBWSInventoryReqResult_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csBWSInventoryReqResult_struct;
    typedef csBWSInventoryReqResult_struct csBWSInventoryReqResult;
    typedef csBWSInventoryReqResult_struct_var csBWSInventoryReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csBWSInventoryReqResult;
    typedef pptBaseResult csNPWProductChangeReqResult;
    typedef pptBaseResult_var csNPWProductChangeReqResult_var;
    extern  ::CORBA::TypeCode_ptr _tc_csNPWProductChangeReqResult;
    class  csNPWProductChangeReqInParm_struct_var;
    struct  csNPWProductChangeReqInParm_struct {
        typedef csNPWProductChangeReqInParm_struct_var _var_type;
       ::objectIdentifier orgProductID;
       ::objectIdentifier productID;
       ::objectIdentifier lotID;
       ::CORBA::Any siInfo;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       csNPWProductChangeReqInParm_struct();
       csNPWProductChangeReqInParm_struct(const csNPWProductChangeReqInParm_struct&);
       csNPWProductChangeReqInParm_struct& operator=(const csNPWProductChangeReqInParm_struct&);
       static CORBA::Info<csNPWProductChangeReqInParm_struct> csNPWProductChangeReqInParm_struct_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct csNPWProductChangeReqInParm_struct


typedef csNPWProductChangeReqInParm_struct* csNPWProductChangeReqInParm_struct_vPtr;
typedef const csNPWProductChangeReqInParm_struct* csNPWProductChangeReqInParm_struct_cvPtr;

class  csNPWProductChangeReqInParm_struct_var
{
    public:

    csNPWProductChangeReqInParm_struct_var ();

    csNPWProductChangeReqInParm_struct_var (csNPWProductChangeReqInParm_struct *_p);

    csNPWProductChangeReqInParm_struct_var (const csNPWProductChangeReqInParm_struct_var &_s);

    csNPWProductChangeReqInParm_struct_var &operator= (csNPWProductChangeReqInParm_struct *_p);

    csNPWProductChangeReqInParm_struct_var &operator= (const csNPWProductChangeReqInParm_struct_var &_s);

    ~csNPWProductChangeReqInParm_struct_var ();

    csNPWProductChangeReqInParm_struct* operator-> ();

    const csNPWProductChangeReqInParm_struct& in() const;
    csNPWProductChangeReqInParm_struct& inout();
    csNPWProductChangeReqInParm_struct*& out();
    csNPWProductChangeReqInParm_struct* _retn();

    operator csNPWProductChangeReqInParm_struct_cvPtr () const;

    operator csNPWProductChangeReqInParm_struct_vPtr& ();

    operator const csNPWProductChangeReqInParm_struct& () const;

    operator csNPWProductChangeReqInParm_struct& ();

    protected:
    csNPWProductChangeReqInParm_struct *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_csNPWProductChangeReqInParm_struct;
    typedef csNPWProductChangeReqInParm_struct csNPWProductChangeReqInParm;
    typedef csNPWProductChangeReqInParm_struct_var csNPWProductChangeReqInParm_var;
    extern  ::CORBA::TypeCode_ptr _tc_csNPWProductChangeReqInParm;
#endif   
/*
 * Guard codes of CORBA::Any operators.
 */
#ifdef __NOTUSE_ANYOPERATOR__
#define __NOTUSE_cs_pptstr_ANYOPERATOR__
#endif //__NOTUSE_ANYOPERATOR__

#ifdef __USE_cs_pptstr_ANYOPERATOR__
#undef __NOTUSE_cs_pptstr_ANYOPERATOR__
#endif //__USE_cs_pptstr_ANYOPERATOR__
#ifndef __NOTUSE_cs_pptstr_ANYOPERATOR__
#define _DCL_ANYOPS_csTestFunctionInfo_struct
#define _DCL_ANYOPS_csTestFunctionInfoSequence
#define _DCL_ANYOPS_csTestFunctionResult_struct
#define _DCL_ANYOPS_csEqpInAuditListInqResult_struct
#define _DCL_ANYOPS_csEqpsByOwner_struct
#define _DCL_ANYOPS_csEqpsByOwnerSequence
#define _DCL_ANYOPS_csEqpListByOwnerInqResult_struct
#define _DCL_ANYOPS_csEqpRMSFlgInqResult_struct
#define _DCL_ANYOPS_csMachineRecipeInfo_struct
#define _DCL_ANYOPS_csMachineRecipeInfoSequence
#define _DCL_ANYOPS_csRecipeCompareFlagInqResult_struct
#define _DCL_ANYOPS_csEqpInfo4RMS_struct
#define _DCL_ANYOPS_csEqpInfo4RMSSequence
#define _DCL_ANYOPS_csEqpInfosByOwner_struct
#define _DCL_ANYOPS_csEqpInfosByOwnerSequence
#define _DCL_ANYOPS_csEqpInfoListByOwnerInqResult_struct
#define _DCL_ANYOPS_csMandPRecipeInfo_struct
#define _DCL_ANYOPS_csMandPRecipeInfoSequence
#define _DCL_ANYOPS_csEqpRelatedRecipeIDAuditFlagListInqResult_struct
#define _DCL_ANYOPS_csCassetteInspectionTimeResetReqResult_struct
#define _DCL_ANYOPS_csCassettePMTimeResetReqResult_struct
#define _DCL_ANYOPS_csReticleWaferCountResetReqResult_struct
#define _DCL_ANYOPS_csReticleUsedDurationResetReqResult_struct
#define _DCL_ANYOPS_csVendorLotReserveData_struct
#define _DCL_ANYOPS_csVendorLotReserveDataSequence
#define _DCL_ANYOPS_csVendorLotReserveListInqResult_struct
#define _DCL_ANYOPS_cspptCassettePmInfo_siInfo_struct
#define _DCL_ANYOPS_cspptReticlePmInfo_siInfo_struct
#define _DCL_ANYOPS_csStartDurablesReservationReqInParam_siInfo_struct
#define _DCL_ANYOPS_csLotInfo_siInfo_struct
#define _DCL_ANYOPS_csCassetteStatusInqResult_siInfo_struct
#define _DCL_ANYOPS_csLotContaminationInfo_struct
#define _DCL_ANYOPS_csLotContaminationInfoSequence
#define _DCL_ANYOPS_csCassetteDeliveryReqResult_siInfo_struct
#define _DCL_ANYOPS_csStartLotsReservationReqResult_siInfo_struct
#define _DCL_ANYOPS_csCarrierUsageTypeChangeReqInParm_struct
#define _DCL_ANYOPS_csSkill_struct
#define _DCL_ANYOPS_csSkillSequence
#define _DCL_ANYOPS_csUserSkillInfo_struct
#define _DCL_ANYOPS_csUserSkillInfoSequence
#define _DCL_ANYOPS_csEqpTypeRequiredSkill_struct
#define _DCL_ANYOPS_csEqpTypeRequiredSkillSequence
#define _DCL_ANYOPS_csUserCertifiedEqpTypeSkillInqResult_struct
#define _DCL_ANYOPS_csUserCertifyCheckInqInParm_struct
#define _DCL_ANYOPS_csUserCertifiedSkillUpdateReqInParm_struct
#define _DCL_ANYOPS_csUserCertifiedSkillDeleteReqInParm_struct
#define _DCL_ANYOPS_csUserCertifiedEqpTypeSkillInqInParm_struct
#define _DCL_ANYOPS_csFixtureTouchCountInfo_struct
#define _DCL_ANYOPS_csFixtureTouchCountRptInParm_struct
#define _DCL_ANYOPS_csFixtureTouchCountRptResult_struct
#define _DCL_ANYOPS_csChamberProcessWafer_siInfo_struct
#define _DCL_ANYOPS_csLithoITMLayerFlag_struct
#define _DCL_ANYOPS_csLithoITMLayerFlagSequence
#define _DCL_ANYOPS_csLithoWaferData_struct
#define _DCL_ANYOPS_csLithoWaferDataSequence
#define _DCL_ANYOPS_csLithoLotDataInfo_struct
#define _DCL_ANYOPS_csLithoLDExtend_struct
#define _DCL_ANYOPS_csLithoLDExtendSequence
#define _DCL_ANYOPS_csAPCLithoContextInfo_struct
#define _DCL_ANYOPS_csLotInCassette_siInfo_struct
#define _DCL_ANYOPS_csLotWafer_siInfo_struct
#define _DCL_ANYOPS_csEqpInfoForDurableDeliveryWatchdog_struct
#define _DCL_ANYOPS_csEqpInfoForDurableDeliveryWatchdogSequence
#define _DCL_ANYOPS_csFutureHoldInfo_struct
#define _DCL_ANYOPS_csLotComplicatedHoldReqInParam_struct
#define _DCL_ANYOPS_csAPCEventQueue_struct
#define _DCL_ANYOPS_csAPCEventQueueSequence
#define _DCL_ANYOPS_csEqpMonitorInventoryInfo_struct
#define _DCL_ANYOPS_csEqpMonitorInventoryInfoSequence
#define _DCL_ANYOPS_csEqpMonitorInventoryListInqInParm_struct
#define _DCL_ANYOPS_csEqpMonitorInventoryListInqResult_struct
#define _DCL_ANYOPS_csEqpMonitorInventoryUpdateReqInParm_struct
#define _DCL_ANYOPS_csBWSInfoForSTB_struct
#define _DCL_ANYOPS_csBWSInfoForSTBSequence
#define _DCL_ANYOPS_csEqpMonitorSourceCandidateInfoInqInParm_struct
#define _DCL_ANYOPS_csSourceProductInBWS_struct
#define _DCL_ANYOPS_csSourceProductInBWSSequence
#define _DCL_ANYOPS_csEqpMonitorSourceCandidateInfoInqResult_struct
#define _DCL_ANYOPS_csBWSWaferOutAndSTBReqInParm_struct
#define _DCL_ANYOPS_csEqpMonitorLotSTBReqInParm_struct
#define _DCL_ANYOPS_csNPWSTB_SlotMap_struct
#define _DCL_ANYOPS_csNPWSTB_SlotMapSequence
#define _DCL_ANYOPS_csEqpMonitorSubInfo_struct
#define _DCL_ANYOPS_csEqpMonitorSubInfoSequence
#define _DCL_ANYOPS_csEqpMonitorDetailInfo_struct
#define _DCL_ANYOPS_csEqpMonitorDetailInfoSequence
#define _DCL_ANYOPS_csEqpMonitorListInqResult_struct
#define _DCL_ANYOPS_csEqpMonitorUpdateReqInParm_struct
#define _DCL_ANYOPS_csLotListAttributes_siInfo_struct
#define _DCL_ANYOPS_csWhatNextAttributes_siInfo_struct
#define _DCL_ANYOPS_csEqpMonitorLotAllBranchReqInParm_struct
#define _DCL_ANYOPS_csEqpMonitorLotPrepareIDResetReqInParm_struct
#define _DCL_ANYOPS_csDowngradeItemListInqResult_struct
#define _DCL_ANYOPS_csDowngradeItemUpdateReqInParm_struct
#define _DCL_ANYOPS_csDowngradeSettingInfo_struct
#define _DCL_ANYOPS_csDowngradeSettingInfoSequence
#define _DCL_ANYOPS_csDowngradeSettingListInqInParm_struct
#define _DCL_ANYOPS_csDowngradeSettingListInqResult_struct
#define _DCL_ANYOPS_csDowngradeSettingUpdateReqInParm_struct
#define _DCL_ANYOPS_csZoneConfigInfo_struct
#define _DCL_ANYOPS_csZoneConfigInfoSequence
#define _DCL_ANYOPS_csBWSConfigInfo_struct
#define _DCL_ANYOPS_csBWSConfigInfoSequence
#define _DCL_ANYOPS_csBWSConfigInfoInqInParm_struct
#define _DCL_ANYOPS_csBWSConfigInfoInqResult_struct
#define _DCL_ANYOPS_csBWSConfigChangeReqInParm_struct
#define _DCL_ANYOPS_csZoneWaferCount_struct
#define _DCL_ANYOPS_csZoneWaferCountSequence
#define _DCL_ANYOPS_csBWS_WaferCount_struct
#define _DCL_ANYOPS_csBWSWaferCountSequence
#define _DCL_ANYOPS_csBWSWaferData_struct
#define _DCL_ANYOPS_csBWSWaferListInqInParm_struct
#define _DCL_ANYOPS_csBWSWaferDataSequence
#define _DCL_ANYOPS_csBWSZoneData_struct
#define _DCL_ANYOPS_csBWSZoneDataSequence
#define _DCL_ANYOPS_csBWSData_struct
#define _DCL_ANYOPS_csBWSDataSequence
#define _DCL_ANYOPS_csBWSWaferListInqResult_struct
#define _DCL_ANYOPS_csBWSInventoryReqInParm_struct
#define _DCL_ANYOPS_csZoneInventoryInfo_struct
#define _DCL_ANYOPS_csZoneInventoryInfoSequence
#define _DCL_ANYOPS_csBWSInventoryInfo_struct
#define _DCL_ANYOPS_csBWSInventoryReqResult_struct
#define _DCL_ANYOPS_csNPWProductChangeReqInParm_struct
#endif //__NOTUSE_cs_pptstr_ANYOPERATOR__

/*
 * Overloaded CORBA::Any operators.
 */
#ifdef _DCL_ANYOPS_csTestFunctionInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csTestFunctionInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csTestFunctionInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csTestFunctionInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csTestFunctionInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csTestFunctionInfo_struct
#ifdef _DCL_ANYOPS_csTestFunctionInfoSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csTestFunctionInfoSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csTestFunctionInfoSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csTestFunctionInfoSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csTestFunctionInfoSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csTestFunctionInfoSequence
#ifdef _DCL_ANYOPS_csTestFunctionResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csTestFunctionResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csTestFunctionResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csTestFunctionResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csTestFunctionResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csTestFunctionResult_struct
#ifdef _DCL_ANYOPS_csEqpInAuditListInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpInAuditListInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpInAuditListInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpInAuditListInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpInAuditListInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpInAuditListInqResult_struct
#ifdef _DCL_ANYOPS_csEqpsByOwner_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpsByOwner_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpsByOwner_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpsByOwner_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpsByOwner_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpsByOwner_struct
#ifdef _DCL_ANYOPS_csEqpsByOwnerSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpsByOwnerSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpsByOwnerSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpsByOwnerSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpsByOwnerSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpsByOwnerSequence
#ifdef _DCL_ANYOPS_csEqpListByOwnerInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpListByOwnerInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpListByOwnerInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpListByOwnerInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpListByOwnerInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpListByOwnerInqResult_struct
#ifdef _DCL_ANYOPS_csEqpRMSFlgInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpRMSFlgInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpRMSFlgInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpRMSFlgInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpRMSFlgInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpRMSFlgInqResult_struct
#ifdef _DCL_ANYOPS_csMachineRecipeInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csMachineRecipeInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csMachineRecipeInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csMachineRecipeInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csMachineRecipeInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csMachineRecipeInfo_struct
#ifdef _DCL_ANYOPS_csMachineRecipeInfoSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csMachineRecipeInfoSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csMachineRecipeInfoSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csMachineRecipeInfoSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csMachineRecipeInfoSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csMachineRecipeInfoSequence
#ifdef _DCL_ANYOPS_csRecipeCompareFlagInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csRecipeCompareFlagInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csRecipeCompareFlagInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csRecipeCompareFlagInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csRecipeCompareFlagInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csRecipeCompareFlagInqResult_struct
#ifdef _DCL_ANYOPS_csEqpInfo4RMS_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpInfo4RMS_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpInfo4RMS_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpInfo4RMS_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpInfo4RMS_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpInfo4RMS_struct
#ifdef _DCL_ANYOPS_csEqpInfo4RMSSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpInfo4RMSSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpInfo4RMSSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpInfo4RMSSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpInfo4RMSSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpInfo4RMSSequence
#ifdef _DCL_ANYOPS_csEqpInfosByOwner_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpInfosByOwner_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpInfosByOwner_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpInfosByOwner_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpInfosByOwner_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpInfosByOwner_struct
#ifdef _DCL_ANYOPS_csEqpInfosByOwnerSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpInfosByOwnerSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpInfosByOwnerSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpInfosByOwnerSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpInfosByOwnerSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpInfosByOwnerSequence
#ifdef _DCL_ANYOPS_csEqpInfoListByOwnerInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpInfoListByOwnerInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpInfoListByOwnerInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpInfoListByOwnerInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpInfoListByOwnerInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpInfoListByOwnerInqResult_struct
#ifdef _DCL_ANYOPS_csMandPRecipeInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csMandPRecipeInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csMandPRecipeInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csMandPRecipeInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csMandPRecipeInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csMandPRecipeInfo_struct
#ifdef _DCL_ANYOPS_csMandPRecipeInfoSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csMandPRecipeInfoSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csMandPRecipeInfoSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csMandPRecipeInfoSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csMandPRecipeInfoSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csMandPRecipeInfoSequence
#ifdef _DCL_ANYOPS_csEqpRelatedRecipeIDAuditFlagListInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpRelatedRecipeIDAuditFlagListInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpRelatedRecipeIDAuditFlagListInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpRelatedRecipeIDAuditFlagListInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpRelatedRecipeIDAuditFlagListInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpRelatedRecipeIDAuditFlagListInqResult_struct
#ifdef _DCL_ANYOPS_csCassetteInspectionTimeResetReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csCassetteInspectionTimeResetReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csCassetteInspectionTimeResetReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csCassetteInspectionTimeResetReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csCassetteInspectionTimeResetReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csCassetteInspectionTimeResetReqResult_struct
#ifdef _DCL_ANYOPS_csCassettePMTimeResetReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csCassettePMTimeResetReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csCassettePMTimeResetReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csCassettePMTimeResetReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csCassettePMTimeResetReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csCassettePMTimeResetReqResult_struct
#ifdef _DCL_ANYOPS_csReticleWaferCountResetReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csReticleWaferCountResetReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csReticleWaferCountResetReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csReticleWaferCountResetReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csReticleWaferCountResetReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csReticleWaferCountResetReqResult_struct
#ifdef _DCL_ANYOPS_csReticleUsedDurationResetReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csReticleUsedDurationResetReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csReticleUsedDurationResetReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csReticleUsedDurationResetReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csReticleUsedDurationResetReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csReticleUsedDurationResetReqResult_struct
#ifdef _DCL_ANYOPS_csVendorLotReserveData_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csVendorLotReserveData_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csVendorLotReserveData_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csVendorLotReserveData_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csVendorLotReserveData_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csVendorLotReserveData_struct
#ifdef _DCL_ANYOPS_csVendorLotReserveDataSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csVendorLotReserveDataSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csVendorLotReserveDataSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csVendorLotReserveDataSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csVendorLotReserveDataSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csVendorLotReserveDataSequence
#ifdef _DCL_ANYOPS_csVendorLotReserveListInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csVendorLotReserveListInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csVendorLotReserveListInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csVendorLotReserveListInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csVendorLotReserveListInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csVendorLotReserveListInqResult_struct
#ifdef _DCL_ANYOPS_cspptCassettePmInfo_siInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::cspptCassettePmInfo_siInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::cspptCassettePmInfo_siInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::cspptCassettePmInfo_siInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::cspptCassettePmInfo_siInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_cspptCassettePmInfo_siInfo_struct
#ifdef _DCL_ANYOPS_cspptReticlePmInfo_siInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::cspptReticlePmInfo_siInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::cspptReticlePmInfo_siInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::cspptReticlePmInfo_siInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::cspptReticlePmInfo_siInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_cspptReticlePmInfo_siInfo_struct
#ifdef _DCL_ANYOPS_csStartDurablesReservationReqInParam_siInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csStartDurablesReservationReqInParam_siInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csStartDurablesReservationReqInParam_siInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csStartDurablesReservationReqInParam_siInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csStartDurablesReservationReqInParam_siInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csStartDurablesReservationReqInParam_siInfo_struct
#ifdef _DCL_ANYOPS_csLotInfo_siInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csLotInfo_siInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csLotInfo_siInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csLotInfo_siInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csLotInfo_siInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csLotInfo_siInfo_struct
#ifdef _DCL_ANYOPS_csCassetteStatusInqResult_siInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csCassetteStatusInqResult_siInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csCassetteStatusInqResult_siInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csCassetteStatusInqResult_siInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csCassetteStatusInqResult_siInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csCassetteStatusInqResult_siInfo_struct
#ifdef _DCL_ANYOPS_csLotContaminationInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csLotContaminationInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csLotContaminationInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csLotContaminationInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csLotContaminationInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csLotContaminationInfo_struct
#ifdef _DCL_ANYOPS_csLotContaminationInfoSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csLotContaminationInfoSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csLotContaminationInfoSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csLotContaminationInfoSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csLotContaminationInfoSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csLotContaminationInfoSequence
#ifdef _DCL_ANYOPS_csCassetteDeliveryReqResult_siInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csCassetteDeliveryReqResult_siInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csCassetteDeliveryReqResult_siInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csCassetteDeliveryReqResult_siInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csCassetteDeliveryReqResult_siInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csCassetteDeliveryReqResult_siInfo_struct
#ifdef _DCL_ANYOPS_csStartLotsReservationReqResult_siInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csStartLotsReservationReqResult_siInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csStartLotsReservationReqResult_siInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csStartLotsReservationReqResult_siInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csStartLotsReservationReqResult_siInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csStartLotsReservationReqResult_siInfo_struct
#ifdef _DCL_ANYOPS_csCarrierUsageTypeChangeReqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csCarrierUsageTypeChangeReqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csCarrierUsageTypeChangeReqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csCarrierUsageTypeChangeReqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csCarrierUsageTypeChangeReqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csCarrierUsageTypeChangeReqInParm_struct
#ifdef _DCL_ANYOPS_csSkill_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csSkill_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csSkill_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csSkill_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csSkill_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csSkill_struct
#ifdef _DCL_ANYOPS_csSkillSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csSkillSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csSkillSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csSkillSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csSkillSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csSkillSequence
#ifdef _DCL_ANYOPS_csUserSkillInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csUserSkillInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csUserSkillInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csUserSkillInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csUserSkillInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csUserSkillInfo_struct
#ifdef _DCL_ANYOPS_csUserSkillInfoSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csUserSkillInfoSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csUserSkillInfoSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csUserSkillInfoSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csUserSkillInfoSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csUserSkillInfoSequence
#ifdef _DCL_ANYOPS_csEqpTypeRequiredSkill_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpTypeRequiredSkill_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpTypeRequiredSkill_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpTypeRequiredSkill_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpTypeRequiredSkill_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpTypeRequiredSkill_struct
#ifdef _DCL_ANYOPS_csEqpTypeRequiredSkillSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpTypeRequiredSkillSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpTypeRequiredSkillSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpTypeRequiredSkillSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpTypeRequiredSkillSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpTypeRequiredSkillSequence
#ifdef _DCL_ANYOPS_csUserCertifiedEqpTypeSkillInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csUserCertifiedEqpTypeSkillInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csUserCertifiedEqpTypeSkillInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csUserCertifiedEqpTypeSkillInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csUserCertifiedEqpTypeSkillInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csUserCertifiedEqpTypeSkillInqResult_struct
#ifdef _DCL_ANYOPS_csUserCertifyCheckInqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csUserCertifyCheckInqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csUserCertifyCheckInqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csUserCertifyCheckInqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csUserCertifyCheckInqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csUserCertifyCheckInqInParm_struct
#ifdef _DCL_ANYOPS_csUserCertifiedSkillUpdateReqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csUserCertifiedSkillUpdateReqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csUserCertifiedSkillUpdateReqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csUserCertifiedSkillUpdateReqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csUserCertifiedSkillUpdateReqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csUserCertifiedSkillUpdateReqInParm_struct
#ifdef _DCL_ANYOPS_csUserCertifiedSkillDeleteReqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csUserCertifiedSkillDeleteReqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csUserCertifiedSkillDeleteReqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csUserCertifiedSkillDeleteReqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csUserCertifiedSkillDeleteReqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csUserCertifiedSkillDeleteReqInParm_struct
#ifdef _DCL_ANYOPS_csUserCertifiedEqpTypeSkillInqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csUserCertifiedEqpTypeSkillInqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csUserCertifiedEqpTypeSkillInqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csUserCertifiedEqpTypeSkillInqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csUserCertifiedEqpTypeSkillInqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csUserCertifiedEqpTypeSkillInqInParm_struct
#ifdef _DCL_ANYOPS_csFixtureTouchCountInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csFixtureTouchCountInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csFixtureTouchCountInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csFixtureTouchCountInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csFixtureTouchCountInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csFixtureTouchCountInfo_struct
#ifdef _DCL_ANYOPS_csFixtureTouchCountRptInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csFixtureTouchCountRptInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csFixtureTouchCountRptInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csFixtureTouchCountRptInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csFixtureTouchCountRptInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csFixtureTouchCountRptInParm_struct
#ifdef _DCL_ANYOPS_csFixtureTouchCountRptResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csFixtureTouchCountRptResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csFixtureTouchCountRptResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csFixtureTouchCountRptResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csFixtureTouchCountRptResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csFixtureTouchCountRptResult_struct
#ifdef _DCL_ANYOPS_csChamberProcessWafer_siInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csChamberProcessWafer_siInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csChamberProcessWafer_siInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csChamberProcessWafer_siInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csChamberProcessWafer_siInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csChamberProcessWafer_siInfo_struct
#ifdef _DCL_ANYOPS_csLithoITMLayerFlag_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csLithoITMLayerFlag_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csLithoITMLayerFlag_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csLithoITMLayerFlag_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csLithoITMLayerFlag_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csLithoITMLayerFlag_struct
#ifdef _DCL_ANYOPS_csLithoITMLayerFlagSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csLithoITMLayerFlagSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csLithoITMLayerFlagSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csLithoITMLayerFlagSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csLithoITMLayerFlagSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csLithoITMLayerFlagSequence
#ifdef _DCL_ANYOPS_csLithoWaferData_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csLithoWaferData_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csLithoWaferData_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csLithoWaferData_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csLithoWaferData_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csLithoWaferData_struct
#ifdef _DCL_ANYOPS_csLithoWaferDataSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csLithoWaferDataSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csLithoWaferDataSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csLithoWaferDataSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csLithoWaferDataSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csLithoWaferDataSequence
#ifdef _DCL_ANYOPS_csLithoLotDataInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csLithoLotDataInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csLithoLotDataInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csLithoLotDataInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csLithoLotDataInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csLithoLotDataInfo_struct
#ifdef _DCL_ANYOPS_csLithoLDExtend_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csLithoLDExtend_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csLithoLDExtend_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csLithoLDExtend_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csLithoLDExtend_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csLithoLDExtend_struct
#ifdef _DCL_ANYOPS_csLithoLDExtendSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csLithoLDExtendSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csLithoLDExtendSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csLithoLDExtendSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csLithoLDExtendSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csLithoLDExtendSequence
#ifdef _DCL_ANYOPS_csAPCLithoContextInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csAPCLithoContextInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csAPCLithoContextInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csAPCLithoContextInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csAPCLithoContextInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csAPCLithoContextInfo_struct
#ifdef _DCL_ANYOPS_csLotInCassette_siInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csLotInCassette_siInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csLotInCassette_siInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csLotInCassette_siInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csLotInCassette_siInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csLotInCassette_siInfo_struct
#ifdef _DCL_ANYOPS_csLotWafer_siInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csLotWafer_siInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csLotWafer_siInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csLotWafer_siInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csLotWafer_siInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csLotWafer_siInfo_struct
#ifdef _DCL_ANYOPS_csEqpInfoForDurableDeliveryWatchdog_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpInfoForDurableDeliveryWatchdog_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpInfoForDurableDeliveryWatchdog_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpInfoForDurableDeliveryWatchdog_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpInfoForDurableDeliveryWatchdog_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpInfoForDurableDeliveryWatchdog_struct
#ifdef _DCL_ANYOPS_csEqpInfoForDurableDeliveryWatchdogSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpInfoForDurableDeliveryWatchdogSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpInfoForDurableDeliveryWatchdogSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpInfoForDurableDeliveryWatchdogSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpInfoForDurableDeliveryWatchdogSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpInfoForDurableDeliveryWatchdogSequence
#ifdef _DCL_ANYOPS_csFutureHoldInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csFutureHoldInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csFutureHoldInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csFutureHoldInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csFutureHoldInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csFutureHoldInfo_struct
#ifdef _DCL_ANYOPS_csLotComplicatedHoldReqInParam_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csLotComplicatedHoldReqInParam_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csLotComplicatedHoldReqInParam_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csLotComplicatedHoldReqInParam_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csLotComplicatedHoldReqInParam_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csLotComplicatedHoldReqInParam_struct
#ifdef _DCL_ANYOPS_csAPCEventQueue_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csAPCEventQueue_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csAPCEventQueue_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csAPCEventQueue_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csAPCEventQueue_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csAPCEventQueue_struct
#ifdef _DCL_ANYOPS_csAPCEventQueueSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csAPCEventQueueSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csAPCEventQueueSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csAPCEventQueueSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csAPCEventQueueSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csAPCEventQueueSequence
#ifdef _DCL_ANYOPS_csEqpMonitorInventoryInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpMonitorInventoryInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpMonitorInventoryInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpMonitorInventoryInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpMonitorInventoryInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpMonitorInventoryInfo_struct
#ifdef _DCL_ANYOPS_csEqpMonitorInventoryInfoSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpMonitorInventoryInfoSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpMonitorInventoryInfoSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpMonitorInventoryInfoSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpMonitorInventoryInfoSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpMonitorInventoryInfoSequence
#ifdef _DCL_ANYOPS_csEqpMonitorInventoryListInqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpMonitorInventoryListInqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpMonitorInventoryListInqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpMonitorInventoryListInqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpMonitorInventoryListInqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpMonitorInventoryListInqInParm_struct
#ifdef _DCL_ANYOPS_csEqpMonitorInventoryListInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpMonitorInventoryListInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpMonitorInventoryListInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpMonitorInventoryListInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpMonitorInventoryListInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpMonitorInventoryListInqResult_struct
#ifdef _DCL_ANYOPS_csEqpMonitorInventoryUpdateReqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpMonitorInventoryUpdateReqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpMonitorInventoryUpdateReqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpMonitorInventoryUpdateReqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpMonitorInventoryUpdateReqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpMonitorInventoryUpdateReqInParm_struct
#ifdef _DCL_ANYOPS_csBWSInfoForSTB_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSInfoForSTB_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSInfoForSTB_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSInfoForSTB_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSInfoForSTB_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSInfoForSTB_struct
#ifdef _DCL_ANYOPS_csBWSInfoForSTBSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSInfoForSTBSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSInfoForSTBSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSInfoForSTBSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSInfoForSTBSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSInfoForSTBSequence
#ifdef _DCL_ANYOPS_csEqpMonitorSourceCandidateInfoInqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpMonitorSourceCandidateInfoInqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpMonitorSourceCandidateInfoInqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpMonitorSourceCandidateInfoInqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpMonitorSourceCandidateInfoInqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpMonitorSourceCandidateInfoInqInParm_struct
#ifdef _DCL_ANYOPS_csSourceProductInBWS_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csSourceProductInBWS_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csSourceProductInBWS_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csSourceProductInBWS_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csSourceProductInBWS_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csSourceProductInBWS_struct
#ifdef _DCL_ANYOPS_csSourceProductInBWSSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csSourceProductInBWSSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csSourceProductInBWSSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csSourceProductInBWSSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csSourceProductInBWSSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csSourceProductInBWSSequence
#ifdef _DCL_ANYOPS_csEqpMonitorSourceCandidateInfoInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpMonitorSourceCandidateInfoInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpMonitorSourceCandidateInfoInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpMonitorSourceCandidateInfoInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpMonitorSourceCandidateInfoInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpMonitorSourceCandidateInfoInqResult_struct
#ifdef _DCL_ANYOPS_csBWSWaferOutAndSTBReqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSWaferOutAndSTBReqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSWaferOutAndSTBReqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSWaferOutAndSTBReqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSWaferOutAndSTBReqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSWaferOutAndSTBReqInParm_struct
#ifdef _DCL_ANYOPS_csEqpMonitorLotSTBReqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpMonitorLotSTBReqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpMonitorLotSTBReqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpMonitorLotSTBReqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpMonitorLotSTBReqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpMonitorLotSTBReqInParm_struct
#ifdef _DCL_ANYOPS_csNPWSTB_SlotMap_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csNPWSTB_SlotMap_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csNPWSTB_SlotMap_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csNPWSTB_SlotMap_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csNPWSTB_SlotMap_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csNPWSTB_SlotMap_struct
#ifdef _DCL_ANYOPS_csNPWSTB_SlotMapSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csNPWSTB_SlotMapSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csNPWSTB_SlotMapSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csNPWSTB_SlotMapSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csNPWSTB_SlotMapSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csNPWSTB_SlotMapSequence
#ifdef _DCL_ANYOPS_csEqpMonitorSubInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpMonitorSubInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpMonitorSubInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpMonitorSubInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpMonitorSubInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpMonitorSubInfo_struct
#ifdef _DCL_ANYOPS_csEqpMonitorSubInfoSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpMonitorSubInfoSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpMonitorSubInfoSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpMonitorSubInfoSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpMonitorSubInfoSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpMonitorSubInfoSequence
#ifdef _DCL_ANYOPS_csEqpMonitorDetailInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpMonitorDetailInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpMonitorDetailInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpMonitorDetailInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpMonitorDetailInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpMonitorDetailInfo_struct
#ifdef _DCL_ANYOPS_csEqpMonitorDetailInfoSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpMonitorDetailInfoSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpMonitorDetailInfoSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpMonitorDetailInfoSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpMonitorDetailInfoSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpMonitorDetailInfoSequence
#ifdef _DCL_ANYOPS_csEqpMonitorListInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpMonitorListInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpMonitorListInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpMonitorListInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpMonitorListInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpMonitorListInqResult_struct
#ifdef _DCL_ANYOPS_csEqpMonitorUpdateReqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpMonitorUpdateReqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpMonitorUpdateReqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpMonitorUpdateReqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpMonitorUpdateReqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpMonitorUpdateReqInParm_struct
#ifdef _DCL_ANYOPS_csLotListAttributes_siInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csLotListAttributes_siInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csLotListAttributes_siInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csLotListAttributes_siInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csLotListAttributes_siInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csLotListAttributes_siInfo_struct
#ifdef _DCL_ANYOPS_csWhatNextAttributes_siInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csWhatNextAttributes_siInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csWhatNextAttributes_siInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csWhatNextAttributes_siInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csWhatNextAttributes_siInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csWhatNextAttributes_siInfo_struct
#ifdef _DCL_ANYOPS_csEqpMonitorLotAllBranchReqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpMonitorLotAllBranchReqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpMonitorLotAllBranchReqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpMonitorLotAllBranchReqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpMonitorLotAllBranchReqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpMonitorLotAllBranchReqInParm_struct
#ifdef _DCL_ANYOPS_csEqpMonitorLotPrepareIDResetReqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csEqpMonitorLotPrepareIDResetReqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csEqpMonitorLotPrepareIDResetReqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csEqpMonitorLotPrepareIDResetReqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csEqpMonitorLotPrepareIDResetReqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csEqpMonitorLotPrepareIDResetReqInParm_struct
#ifdef _DCL_ANYOPS_csDowngradeItemListInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csDowngradeItemListInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csDowngradeItemListInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csDowngradeItemListInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csDowngradeItemListInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csDowngradeItemListInqResult_struct
#ifdef _DCL_ANYOPS_csDowngradeItemUpdateReqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csDowngradeItemUpdateReqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csDowngradeItemUpdateReqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csDowngradeItemUpdateReqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csDowngradeItemUpdateReqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csDowngradeItemUpdateReqInParm_struct
#ifdef _DCL_ANYOPS_csDowngradeSettingInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csDowngradeSettingInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csDowngradeSettingInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csDowngradeSettingInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csDowngradeSettingInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csDowngradeSettingInfo_struct
#ifdef _DCL_ANYOPS_csDowngradeSettingInfoSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csDowngradeSettingInfoSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csDowngradeSettingInfoSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csDowngradeSettingInfoSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csDowngradeSettingInfoSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csDowngradeSettingInfoSequence
#ifdef _DCL_ANYOPS_csDowngradeSettingListInqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csDowngradeSettingListInqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csDowngradeSettingListInqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csDowngradeSettingListInqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csDowngradeSettingListInqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csDowngradeSettingListInqInParm_struct
#ifdef _DCL_ANYOPS_csDowngradeSettingListInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csDowngradeSettingListInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csDowngradeSettingListInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csDowngradeSettingListInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csDowngradeSettingListInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csDowngradeSettingListInqResult_struct
#ifdef _DCL_ANYOPS_csDowngradeSettingUpdateReqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csDowngradeSettingUpdateReqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csDowngradeSettingUpdateReqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csDowngradeSettingUpdateReqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csDowngradeSettingUpdateReqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csDowngradeSettingUpdateReqInParm_struct
#ifdef _DCL_ANYOPS_csZoneConfigInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csZoneConfigInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csZoneConfigInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csZoneConfigInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csZoneConfigInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csZoneConfigInfo_struct
#ifdef _DCL_ANYOPS_csZoneConfigInfoSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csZoneConfigInfoSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csZoneConfigInfoSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csZoneConfigInfoSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csZoneConfigInfoSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csZoneConfigInfoSequence
#ifdef _DCL_ANYOPS_csBWSConfigInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSConfigInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSConfigInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSConfigInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSConfigInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSConfigInfo_struct
#ifdef _DCL_ANYOPS_csBWSConfigInfoSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSConfigInfoSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSConfigInfoSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSConfigInfoSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSConfigInfoSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSConfigInfoSequence
#ifdef _DCL_ANYOPS_csBWSConfigInfoInqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSConfigInfoInqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSConfigInfoInqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSConfigInfoInqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSConfigInfoInqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSConfigInfoInqInParm_struct
#ifdef _DCL_ANYOPS_csBWSConfigInfoInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSConfigInfoInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSConfigInfoInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSConfigInfoInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSConfigInfoInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSConfigInfoInqResult_struct
#ifdef _DCL_ANYOPS_csBWSConfigChangeReqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSConfigChangeReqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSConfigChangeReqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSConfigChangeReqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSConfigChangeReqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSConfigChangeReqInParm_struct
#ifdef _DCL_ANYOPS_csZoneWaferCount_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csZoneWaferCount_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csZoneWaferCount_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csZoneWaferCount_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csZoneWaferCount_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csZoneWaferCount_struct
#ifdef _DCL_ANYOPS_csZoneWaferCountSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csZoneWaferCountSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csZoneWaferCountSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csZoneWaferCountSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csZoneWaferCountSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csZoneWaferCountSequence
#ifdef _DCL_ANYOPS_csBWS_WaferCount_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWS_WaferCount_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWS_WaferCount_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWS_WaferCount_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWS_WaferCount_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csBWS_WaferCount_struct
#ifdef _DCL_ANYOPS_csBWSWaferCountSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSWaferCountSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSWaferCountSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSWaferCountSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSWaferCountSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSWaferCountSequence
#ifdef _DCL_ANYOPS_csBWSWaferData_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSWaferData_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSWaferData_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSWaferData_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSWaferData_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSWaferData_struct
#ifdef _DCL_ANYOPS_csBWSWaferListInqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSWaferListInqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSWaferListInqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSWaferListInqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSWaferListInqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSWaferListInqInParm_struct
#ifdef _DCL_ANYOPS_csBWSWaferDataSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSWaferDataSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSWaferDataSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSWaferDataSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSWaferDataSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSWaferDataSequence
#ifdef _DCL_ANYOPS_csBWSZoneData_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSZoneData_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSZoneData_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSZoneData_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSZoneData_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSZoneData_struct
#ifdef _DCL_ANYOPS_csBWSZoneDataSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSZoneDataSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSZoneDataSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSZoneDataSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSZoneDataSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSZoneDataSequence
#ifdef _DCL_ANYOPS_csBWSData_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSData_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSData_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSData_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSData_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSData_struct
#ifdef _DCL_ANYOPS_csBWSDataSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSDataSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSDataSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSDataSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSDataSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSDataSequence
#ifdef _DCL_ANYOPS_csBWSWaferListInqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSWaferListInqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSWaferListInqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSWaferListInqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSWaferListInqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSWaferListInqResult_struct
#ifdef _DCL_ANYOPS_csBWSInventoryReqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSInventoryReqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSInventoryReqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSInventoryReqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSInventoryReqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSInventoryReqInParm_struct
#ifdef _DCL_ANYOPS_csZoneInventoryInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csZoneInventoryInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csZoneInventoryInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csZoneInventoryInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csZoneInventoryInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csZoneInventoryInfo_struct
#ifdef _DCL_ANYOPS_csZoneInventoryInfoSequence
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csZoneInventoryInfoSequence &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csZoneInventoryInfoSequence *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csZoneInventoryInfoSequence*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csZoneInventoryInfoSequence*& _data);
#endif
#endif // _DCL_ANYOPS_csZoneInventoryInfoSequence
#ifdef _DCL_ANYOPS_csBWSInventoryInfo_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSInventoryInfo_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSInventoryInfo_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSInventoryInfo_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSInventoryInfo_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSInventoryInfo_struct
#ifdef _DCL_ANYOPS_csBWSInventoryReqResult_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csBWSInventoryReqResult_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csBWSInventoryReqResult_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csBWSInventoryReqResult_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csBWSInventoryReqResult_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csBWSInventoryReqResult_struct
#ifdef _DCL_ANYOPS_csNPWProductChangeReqInParm_struct
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::csNPWProductChangeReqInParm_struct &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::csNPWProductChangeReqInParm_struct *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::csNPWProductChangeReqInParm_struct*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::csNPWProductChangeReqInParm_struct*& _data);
#endif
#endif // _DCL_ANYOPS_csNPWProductChangeReqInParm_struct

#endif /* _cs_pptstr_hh_included */

#endif /* _cs_pptstr_server_defined */
