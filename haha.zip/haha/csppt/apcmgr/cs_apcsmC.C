//----------------------------------------------------------------------------
//
//  Generated from cs_apcsm.idl
//  On Thursday, October 19, 2017 5:49:49 PM GMT+07:00
//  by IBM CORBA 2.3 (uc) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _cs_apcsm_bindings_defined
#define _cs_apcsm_bindings_defined
#endif 
#ifdef SOMCBNOLOCALINCLUDES
#include <cs_apcsm.hh>
#else
#include "cs_apcsm.hh"
#endif
#ifdef SIVIEW_EBROKER
 #ifdef linux
  #include <new>
 #else
  #include <new.h>
 #endif
#endif


#ifdef _AIX
#ifndef _UNIX
#define _UNIX
#endif
#endif
#include <private/wasdpriv.h>
#include <assert.h>

enum BoundaryCheckMode { BCM_None, BCM_Logging, BCM_Exception, BCM_Assertion };

#define SOMD_BOUNDARY_CHECK_ERROR(checkMode,index,maxlength)\
    switch(checkMode)\
    {\
    case BCM_Logging:\
            somdLogMsg( __FILE__, __LINE__,SOMRAS_EL_SEVERITY_ERROR,"",WASMessage(WASL_MSG_6S, WASLog::WASLogSvcCatalogName)<<"Boundary check error at " << __FUNCTION__ << ". index:" << index << ", "  #maxlength " :" << maxlength );\
            break;\
    case BCM_Exception:\
            throw CORBA::BAD_PARAM(SOMDMINOR_BAD_PARAM_OTHER,CORBA::COMPLETED_NO);\
            break;\
    case BCM_Assertion:\
            assert( index < maxlength );\
            break;\
    case BCM_None:\
    default:\
            break;\
    }\

static BoundaryCheckMode boundaryCheck_Maximum = BCM_None;
static BoundaryCheckMode boundaryCheck_Length = BCM_None;

static void __cs_apcsm_initialize()
{
    class __cs_apcsm_initializer
    {
    public:
        __cs_apcsm_initializer()
        {
            boundaryCheck_Length = (BoundaryCheckMode)WasGetParmInt("com.ibm.CORBA.actionForBoundaryCheckOfSequenceLength", (int)BCM_None );
            boundaryCheck_Maximum = (BoundaryCheckMode)WasGetParmInt("com.ibm.CORBA.actionForBoundaryCheckOfSequenceMaxLength", (int)BCM_Logging );
        }
    };
    static __cs_apcsm_initializer initialize;
}


#ifdef _DCL_LithoR2RWebServiceSoap
::CORBA::Object_ptr SOMLINK LithoR2RWebServiceSoap_getBase(void *p){ return(LithoR2RWebServiceSoap_ptr) p; }
::LithoR2RWebServiceSoap_ptr SOMLINK LithoR2RWebServiceSoap_aux_duplicate(::LithoR2RWebServiceSoap_ptr o) { return LithoR2RWebServiceSoap::_duplicate(o); }
::LithoR2RWebServiceSoap_ptr SOMLINK LithoR2RWebServiceSoap_aux_narrow(::CORBA::Object_ptr  o) { return LithoR2RWebServiceSoap::_narrow(o); }
::LithoR2RWebServiceSoap_ptr SOMLINK LithoR2RWebServiceSoap_aux_nil(){ return LithoR2RWebServiceSoap::_nil(); }
const char* SOMLINK LithoR2RWebServiceSoap_aux_CN() { return LithoR2RWebServiceSoap::LithoR2RWebServiceSoap_CN; }


LithoR2RWebServiceSoap_StructElem::LithoR2RWebServiceSoap_StructElem () { 
   _ptr = ::LithoR2RWebServiceSoap::_nil();
}

LithoR2RWebServiceSoap_StructElem::LithoR2RWebServiceSoap_StructElem (const ::LithoR2RWebServiceSoap_StructElem &s) { 
   _ptr = ::LithoR2RWebServiceSoap::_duplicate (s._ptr); 
}

LithoR2RWebServiceSoap_StructElem::~LithoR2RWebServiceSoap_StructElem () {
   ::CORBA::release((::CORBA::Object_ptr)_ptr);
}

LithoR2RWebServiceSoap_StructElem& LithoR2RWebServiceSoap_StructElem::operator= (::LithoR2RWebServiceSoap_ptr p) {
   if (_ptr)
      ::CORBA::release ((::CORBA::Object_ptr)_ptr);
    _ptr = p;
    return *this;
 }

LithoR2RWebServiceSoap_StructElem& LithoR2RWebServiceSoap_StructElem::operator= (::LithoR2RWebServiceSoap_var v) {
   if (_ptr)
      ::CORBA::release ((::CORBA::Object_ptr)_ptr);
    _ptr = ::LithoR2RWebServiceSoap::_duplicate(v);
    return *this;
 }

LithoR2RWebServiceSoap_StructElem& LithoR2RWebServiceSoap_StructElem::operator= (const ::LithoR2RWebServiceSoap_StructElem &s) {
   if (this == &s) return *this;
   if (_ptr)
      ::CORBA::release ((::CORBA::Object_ptr)_ptr);
   _ptr = ::LithoR2RWebServiceSoap::_duplicate (s._ptr);
   return *this;
}

LithoR2RWebServiceSoap_StructElem::operator ::CORBA::Object_ptr() const {
   return (::CORBA::Object_ptr)_ptr;
}
LithoR2RWebServiceSoap_StructElem::operator LithoR2RWebServiceSoap_ptr () const {
   return _ptr;
}

LithoR2RWebServiceSoap_SeqElem::LithoR2RWebServiceSoap_SeqElem (::LithoR2RWebServiceSoap_ptr* p, unsigned char rel) {
   _ptr = p;
   _release = rel;
}

LithoR2RWebServiceSoap_SeqElem& LithoR2RWebServiceSoap_SeqElem::operator= (::LithoR2RWebServiceSoap_ptr p) {
   if (!_ptr)
      return *this;
   if (*(_ptr) && _release)
      ::CORBA::release ((::CORBA::Object_ptr)(*_ptr));
   *(_ptr) = p;
   return *this;
}

LithoR2RWebServiceSoap_SeqElem& LithoR2RWebServiceSoap_SeqElem::operator= (::LithoR2RWebServiceSoap_var v) {
   if (*(_ptr) && _release)
      ::CORBA::release ((::CORBA::Object_ptr)(*_ptr));
    (*_ptr) = ::LithoR2RWebServiceSoap::_duplicate(v);
    return *this;
 }

LithoR2RWebServiceSoap_SeqElem& LithoR2RWebServiceSoap_SeqElem::operator= (const ::LithoR2RWebServiceSoap_SeqElem &s) {
   if ((this == &s) || !_ptr || !s._ptr)
      return *this;
   if (*(_ptr) && _release)
      ::CORBA::release (( ::CORBA::Object_ptr)(*_ptr));
   *(_ptr) = ::LithoR2RWebServiceSoap::_duplicate(*(s._ptr));
   return *this;
}

LithoR2RWebServiceSoap_SeqElem::operator ::LithoR2RWebServiceSoap_ptr () const {
   if (!_ptr)
      return ::LithoR2RWebServiceSoap::_nil();
   return *_ptr;
}

::LithoR2RWebServiceSoap_ptr LithoR2RWebServiceSoap_SeqElem::operator -> () const {
   if (!_ptr)
      return ::LithoR2RWebServiceSoap::_nil();
   return *_ptr;
}


const char* LithoR2RWebServiceSoap::LithoR2RWebServiceSoap_CN = "LithoR2RWebServiceSoap";
const char* LithoR2RWebServiceSoap::LithoR2RWebServiceSoap_RID = "IDL:LithoR2RWebServiceSoap:1.0";

void * LithoR2RWebServiceSoap::_deref() { return (void *)this; }
LithoR2RWebServiceSoap::LithoR2RWebServiceSoap()
{}
LithoR2RWebServiceSoap::~LithoR2RWebServiceSoap()
{}
LithoR2RWebServiceSoap_ptr LithoR2RWebServiceSoap::_nil () { return (LithoR2RWebServiceSoap_ptr) ((void*)CORBA::Object::_nil()); }
::LithoR2RWebServiceSoap_ptr  LithoR2RWebServiceSoap::_duplicate(::LithoR2RWebServiceSoap_ptr obj)
{
   if (!::CORBA::is_nil((::CORBA::Object_ptr)obj))
      obj->_incref();
   return obj;
}

#ifdef _MSC_VER
#pragma warning(disable:4101)
#endif
::LithoR2RWebServiceSoap_ptr LithoR2RWebServiceSoap::_narrow (::CORBA::Object_ptr obj) 
{
try {
    if ( ! obj)
        return ::LithoR2RWebServiceSoap::_nil();
    ::LithoR2RWebServiceSoap_ptr casted = (::LithoR2RWebServiceSoap_ptr)(obj->_has_ancestor(::LithoR2RWebServiceSoap::LithoR2RWebServiceSoap_CN));
    if (casted) return _duplicate(casted);
    /* use ORB implementation of narrow*/
    if (obj->_is_a(::LithoR2RWebServiceSoap::LithoR2RWebServiceSoap_RID)) {
        ::CORBA::Object_ptr newproxy = ::CORBA::ORB::rebuild_proxy(obj, ::LithoR2RWebServiceSoap::LithoR2RWebServiceSoap_CN);
        return (::LithoR2RWebServiceSoap_ptr)(newproxy->_has_ancestor(::LithoR2RWebServiceSoap::LithoR2RWebServiceSoap_CN));
    }
} catch(::CORBA::SystemException &e){ 
    throw;
} catch(...) {
    ::CORBA::UNKNOWN _unknown_except(SOMDERROR_Unknown, ::CORBA::COMPLETED_NO);
    throw _unknown_except;
}
#ifdef _MSC_VER
#pragma warning(default:4101)
#endif
    return ::LithoR2RWebServiceSoap::_nil();
}

#ifndef _MSC_VER
::LithoR2RWebServiceSoap_ptr LithoR2RWebServiceSoap::_self()
{
    ::CORBA::Object_ptr _temp = _localReference();
    if ( !::CORBA::is_nil(_temp) ) {
        ::CORBA::Object_var _localProxy = _temp;
        if ( _localProxy == (::CORBA::Object_ptr)this) return this;
        ::LithoR2RWebServiceSoap_ptr _casted = (::LithoR2RWebServiceSoap_ptr)_localProxy->_has_ancestor(::LithoR2RWebServiceSoap::LithoR2RWebServiceSoap_CN);
        if ( _casted ) return _casted;
    }
    ::CORBA::INV_OBJREF _tmpexcept(0, ::CORBA::COMPLETED_NO);
    throw _tmpexcept;
}
::LithoR2RWebServiceSoap_ptr LithoR2RWebServiceSoap::_this()
{
    return _duplicate(_self());
}
#endif /* _MSC_VER */

void* LithoR2RWebServiceSoap::_has_ancestor(const char* classname)
{
::CORBA::Long _code = ::CORBA::_somd_hash_string(classname);
/* testing 2 ancestors */
if ( _code == 0x71f6f34 && !strcmp(classname, ::CORBA::Object::Object_CN)){
    /* CORBA::Object */ return (void *)(::CORBA::Object_ptr)this;
}
else if ( _code == 0xba32b30 && !strcmp(classname, ::LithoR2RWebServiceSoap::LithoR2RWebServiceSoap_CN)){
    /* "LithoR2RWebServiceSoap" */
    return (void *)(::LithoR2RWebServiceSoap_ptr)this;
}
return 0;
}


::Innotron_Recomd_Result*  LithoR2RWebServiceSoap::_req_Recommend_Request(const ::Innotron_Recomd_Request& objRequest, ::CORBA::Request &_req, ::CORBA::Environment &env)
{
   ::Innotron_Recomd_Result* * _noresult = 0;
 try {

      objRequest.encodeOp(_req);
   _req.invoke(env);
  ::Innotron_Recomd_Result *_result= new ::Innotron_Recomd_Result;
  (*_result).decodeOp(_req);
    if ( !_req.local())
        ::CORBA::RequestInterceptor::run_client_filters(&_req);
    return _result;
  }
  catch(::CORBA::SystemException &sys_ex) {
      if ( !_req.local())
          ::CORBA::RequestInterceptor::run_client_exception_filters(&_req, sys_ex);
      else throw;
  }
   // not reached
   return *_noresult;
}

::Innotron_Recomd_Result*  LithoR2RWebServiceSoap_ORBProxy::Recommend_Request(const ::Innotron_Recomd_Request& objRequest, ::CORBA::Environment &env)
{
  ::CORBA::Request _req(this, "Recommend_Request", 0);
    return _req_Recommend_Request( objRequest, _req, env);
}

::Innotron_Used_Result*  LithoR2RWebServiceSoap::_req_Used_Request(const ::Innotron_Used_Request& objRequest, ::CORBA::Request &_req, ::CORBA::Environment &env)
{
   ::Innotron_Used_Result* * _noresult = 0;
 try {

      objRequest.encodeOp(_req);
   _req.invoke(env);
  ::Innotron_Used_Result *_result= new ::Innotron_Used_Result;
  (*_result).decodeOp(_req);
    if ( !_req.local())
        ::CORBA::RequestInterceptor::run_client_filters(&_req);
    return _result;
  }
  catch(::CORBA::SystemException &sys_ex) {
      if ( !_req.local())
          ::CORBA::RequestInterceptor::run_client_exception_filters(&_req, sys_ex);
      else throw;
  }
   // not reached
   return *_noresult;
}

::Innotron_Used_Result*  LithoR2RWebServiceSoap_ORBProxy::Used_Request(const ::Innotron_Used_Request& objRequest, ::CORBA::Environment &env)
{
  ::CORBA::Request _req(this, "Used_Request", 0);
    return _req_Used_Request( objRequest, _req, env);
}

::Innotron_Met_Result*  LithoR2RWebServiceSoap::_req_Metrology_Request(const ::Innotron_Met_Request& objRequest, ::CORBA::Request &_req, ::CORBA::Environment &env)
{
   ::Innotron_Met_Result* * _noresult = 0;
 try {

      objRequest.encodeOp(_req);
   _req.invoke(env);
  ::Innotron_Met_Result *_result= new ::Innotron_Met_Result;
  (*_result).decodeOp(_req);
    if ( !_req.local())
        ::CORBA::RequestInterceptor::run_client_filters(&_req);
    return _result;
  }
  catch(::CORBA::SystemException &sys_ex) {
      if ( !_req.local())
          ::CORBA::RequestInterceptor::run_client_exception_filters(&_req, sys_ex);
      else throw;
  }
   // not reached
   return *_noresult;
}

::Innotron_Met_Result*  LithoR2RWebServiceSoap_ORBProxy::Metrology_Request(const ::Innotron_Met_Request& objRequest, ::CORBA::Environment &env)
{
  ::CORBA::Request _req(this, "Metrology_Request", 0);
    return _req_Metrology_Request( objRequest, _req, env);
}

void * LithoR2RWebServiceSoap::_SOMThis(const char *&ifname){
    ifname = ::LithoR2RWebServiceSoap::LithoR2RWebServiceSoap_CN;
    return this;
}
LithoR2RWebServiceSoap_var::LithoR2RWebServiceSoap_var () { _ptr = ::LithoR2RWebServiceSoap_aux_nil (); }

LithoR2RWebServiceSoap_var::LithoR2RWebServiceSoap_var (LithoR2RWebServiceSoap *p) { _ptr = p; }

LithoR2RWebServiceSoap_var::LithoR2RWebServiceSoap_var (const LithoR2RWebServiceSoap_var &s) {
  _ptr = ::LithoR2RWebServiceSoap_aux_duplicate (s._ptr);
}
LithoR2RWebServiceSoap_var::LithoR2RWebServiceSoap_var (const LithoR2RWebServiceSoap_StructElem &s) {
  _ptr = ::LithoR2RWebServiceSoap_aux_nil ();
  operator=(s);
}
LithoR2RWebServiceSoap_var::LithoR2RWebServiceSoap_var (const LithoR2RWebServiceSoap_SeqElem &s) {
  _ptr = ::LithoR2RWebServiceSoap_aux_nil ();
  operator=(s);
}
LithoR2RWebServiceSoap_var::~LithoR2RWebServiceSoap_var () { ::CORBA::release ((::CORBA::Object_ptr)_ptr); }

::LithoR2RWebServiceSoap_var& LithoR2RWebServiceSoap_var::operator= (const ::LithoR2RWebServiceSoap_StructElem &s) {
  if (_ptr)
     ::CORBA::release ((::CORBA::Object_ptr)_ptr);
  _ptr = ::LithoR2RWebServiceSoap::_duplicate (s._ptr);
  return *this;
}
::LithoR2RWebServiceSoap_var& LithoR2RWebServiceSoap_var::operator= (const ::LithoR2RWebServiceSoap_SeqElem &s) {
  if (_ptr)
     ::CORBA::release ((::CORBA::Object_ptr)_ptr);
  _ptr = ::LithoR2RWebServiceSoap::_duplicate (s);
  return *this;
}
::LithoR2RWebServiceSoap_var& LithoR2RWebServiceSoap_var::operator= (::LithoR2RWebServiceSoap *p) {
  if (_ptr == p)
     return *this;
  if (_ptr)
     ::CORBA::release ((::CORBA::Object_ptr)_ptr);
  _ptr = p;
  return *this;
}

::LithoR2RWebServiceSoap_var& LithoR2RWebServiceSoap_var::operator= (const ::LithoR2RWebServiceSoap_var &s) {
  if (this == &s) return *this;
  if (_ptr)
     ::CORBA::release ((::CORBA::Object_ptr)_ptr);
  _ptr = ::LithoR2RWebServiceSoap::_duplicate (s._ptr);
  return *this;
}
::LithoR2RWebServiceSoap_ptr LithoR2RWebServiceSoap_var::in () const { return _ptr; }
::LithoR2RWebServiceSoap_ptr& LithoR2RWebServiceSoap_var::inout () { return _ptr; }
::LithoR2RWebServiceSoap_ptr& LithoR2RWebServiceSoap_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     ::CORBA::release ((::CORBA::Object_ptr)_ptr);
  _ptr = ::LithoR2RWebServiceSoap_aux_nil ();
  return _ptr;}
::LithoR2RWebServiceSoap_ptr LithoR2RWebServiceSoap_var::_retn () {
  // yield ownership of managed object reference
  LithoR2RWebServiceSoap_ptr ret = _ptr;
  _ptr = ::LithoR2RWebServiceSoap_aux_nil ();
  return ret;}
LithoR2RWebServiceSoap_ptr LithoR2RWebServiceSoap_var::operator-> () { return _ptr; };
LithoR2RWebServiceSoap_var::operator LithoR2RWebServiceSoap_ptr& () { return _ptr; };
LithoR2RWebServiceSoap_var::operator const LithoR2RWebServiceSoap_ptr& () const { return _ptr; };


#ifdef _MSC_VER
#pragma warning(disable:4250)
#endif
LithoR2RWebServiceSoapBOAImpl::LithoR2RWebServiceSoapBOAImpl() {
  if ( !m_classname 
       || !strcmp(m_classname, ::CORBA::Object::Object_CN)) {
       m_classname = (char*)LithoR2RWebServiceSoap::LithoR2RWebServiceSoap_CN;
       m_target_type_id = (char*)LithoR2RWebServiceSoap::LithoR2RWebServiceSoap_RID; 
       if (m_dispatcher) delete (::CORBA::SOMDDispatcher*) m_dispatcher; // out with the old,
       m_dispatcher = (::CORBA::SOMDDispatcher*) new LithoR2RWebServiceSoap_Dispatcher(this); // in with the new
    }
}

LithoR2RWebServiceSoapBOAImpl::~LithoR2RWebServiceSoapBOAImpl()
{ 
  if (m_dispatcher) delete (::CORBA::SOMDDispatcher*) m_dispatcher; 
  m_dispatcher = 0;
}

LithoR2RWebServiceSoapBOAImpl& LithoR2RWebServiceSoapBOAImpl::operator= (const LithoR2RWebServiceSoapBOAImpl &s) 
{
  return *this;
}

LithoR2RWebServiceSoapBOAImpl::LithoR2RWebServiceSoapBOAImpl (const LithoR2RWebServiceSoapBOAImpl &s)
{
  if (m_dispatcher) delete (::CORBA::SOMDDispatcher*) m_dispatcher;
  m_dispatcher = (::CORBA::SOMDDispatcher*) new LithoR2RWebServiceSoap_Dispatcher (this);
}
#ifdef _MSC_VER
#pragma warning(default:4250)
#endif
LithoR2RWebServiceSoap_Dispatcher::LithoR2RWebServiceSoap_Dispatcher (::CORBA::Object_ptr target) : 
#ifndef _MSC_VER
  ::CORBA::
#endif
           SOMDDispatcher(target )
{
}
LithoR2RWebServiceSoap_Dispatcher::LithoR2RWebServiceSoap_Dispatcher ()
{
}
#ifndef LithoR2RWebServiceSoap_dispatcher

::CORBA::Boolean LithoR2RWebServiceSoap_Dispatcher::dispatch (::CORBA::Request &r)
{
   return 0;
}

#endif

LithoR2RWebServiceSoap_ORBProxy::LithoR2RWebServiceSoap_ORBProxy () { 
  m_classname = (char*)
                       LithoR2RWebServiceSoap::
                       LithoR2RWebServiceSoap_CN;
}
LithoR2RWebServiceSoapProxyFactory::LithoR2RWebServiceSoapProxyFactory (::CORBA::Boolean is_default) :
#ifndef _MSC_VER
  ::CORBA::
#endif
           SOMDProxyFactory (LithoR2RWebServiceSoap::LithoR2RWebServiceSoap_CN, is_default) 
{ }
::CORBA::Object_ptr LithoR2RWebServiceSoapProxyFactory::create_proxy (const char *classname)
{
   return  new class ::LithoR2RWebServiceSoap_ORBProxy();
}

::CORBA::Object_ptr LithoR2RWebServiceSoapProxyFactory::asObject(void *obj) {
   return  (::CORBA::Object_ptr) (::LithoR2RWebServiceSoap_ptr)obj;
}

LithoR2RWebServiceSoapProxyFactory _LithoR2RWebServiceSoapProxyFactory(1);


#endif // _DCL_LithoR2RWebServiceSoap
/*
 * TypeCode constants
 */
#ifdef _DCL_LithoR2RWebServiceSoap
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_LithoR2RWebServiceSoap = NULL;
#else
::CORBA::TypeCode_ptr _tc_LithoR2RWebServiceSoap =NULL;
#endif // _USE_NAMESPACE
#endif
static void __cs_apcsm_emit_tc(::CORBA::ORB_ptr _orb)
{ 

#ifdef _DCL_LithoR2RWebServiceSoap
::CORBA::TypeCode_ptr _tmp_tc__LithoR2RWebServiceSoap = _orb->create_interface_tc("IDL:LithoR2RWebServiceSoap:1.0", "LithoR2RWebServiceSoap", 0);
_tc_LithoR2RWebServiceSoap = _tmp_tc__LithoR2RWebServiceSoap;
#endif
}
static ::CORBA::TypeCodeInitStruct __cs_apcsm_TypeCodeInitStruct = { __cs_apcsm_emit_tc, 0 , "cs_apcsm"};
static ::CORBA::TypeCodeInitializer __cs_apcsm_TypeCodeInitializer(&__cs_apcsm_TypeCodeInitStruct);
/*
 * Overloaded CORBA::Any operators.
 */
#ifndef _Anyops_for_LithoR2RWebServiceSoap
#define _Anyops_for_LithoR2RWebServiceSoap
void operator <<= (::CORBA::Any& _any, ::LithoR2RWebServiceSoap_ptr _data)
{
   _any.replace(::_tc_LithoR2RWebServiceSoap, (void*)_data);
}
void operator <<= (::CORBA::Any& _any, ::LithoR2RWebServiceSoap_ptr* _data)
{
   _any.replace(::_tc_LithoR2RWebServiceSoap, (void*)*_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::LithoR2RWebServiceSoap_ptr& _data)
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_LithoR2RWebServiceSoap)) {
     _data = (::LithoR2RWebServiceSoap_ptr)(_any.value());
      return 1;
   }
   else return 0;
}
#endif // _Anyops_for_LithoR2RWebServiceSoap
