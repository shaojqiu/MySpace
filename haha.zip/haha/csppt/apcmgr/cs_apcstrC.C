//----------------------------------------------------------------------------
//
//  Generated from cs_apcstr.idl
//  On Thursday, October 19, 2017 5:49:46 PM GMT+07:00
//  by IBM CORBA 2.3 (uc) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _cs_apcstr_bindings_defined
#define _cs_apcstr_bindings_defined
#endif 
#ifdef SOMCBNOLOCALINCLUDES
#include <cs_apcstr.hh>
#else
#include "cs_apcstr.hh"
#endif
#ifdef SIVIEW_EBROKER
 #ifdef linux
  #include <new>
 #else
  #include <new.h>
 #endif
#endif


#ifdef _AIX
#ifndef _UNIX
#define _UNIX
#endif
#endif
#include <private/wasdpriv.h>
#include <assert.h>

enum BoundaryCheckMode { BCM_None, BCM_Logging, BCM_Exception, BCM_Assertion };

#define SOMD_BOUNDARY_CHECK_ERROR(checkMode,index,maxlength)\
    switch(checkMode)\
    {\
    case BCM_Logging:\
            somdLogMsg( __FILE__, __LINE__,SOMRAS_EL_SEVERITY_ERROR,"",WASMessage(WASL_MSG_6S, WASLog::WASLogSvcCatalogName)<<"Boundary check error at " << __FUNCTION__ << ". index:" << index << ", "  #maxlength " :" << maxlength );\
            break;\
    case BCM_Exception:\
            throw CORBA::BAD_PARAM(SOMDMINOR_BAD_PARAM_OTHER,CORBA::COMPLETED_NO);\
            break;\
    case BCM_Assertion:\
            assert( index < maxlength );\
            break;\
    case BCM_None:\
    default:\
            break;\
    }\

static BoundaryCheckMode boundaryCheck_Maximum = BCM_None;
static BoundaryCheckMode boundaryCheck_Length = BCM_None;

static void __cs_apcstr_initialize()
{
    class __cs_apcstr_initializer
    {
    public:
        __cs_apcstr_initializer()
        {
            boundaryCheck_Length = (BoundaryCheckMode)WasGetParmInt("com.ibm.CORBA.actionForBoundaryCheckOfSequenceLength", (int)BCM_None );
            boundaryCheck_Maximum = (BoundaryCheckMode)WasGetParmInt("com.ibm.CORBA.actionForBoundaryCheckOfSequenceMaxLength", (int)BCM_Logging );
        }
    };
    static __cs_apcstr_initializer initialize;
}


const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_CONTROLJOBTYPEArray_1::__stubcode_version;
_IDL_SEQ_CONTROLJOBTYPEArray_1::_IDL_SEQ_CONTROLJOBTYPEArray_1()
{
  _defaultInit();
}
_IDL_SEQ_CONTROLJOBTYPEArray_1::_IDL_SEQ_CONTROLJOBTYPEArray_1 (const ::_IDL_SEQ_CONTROLJOBTYPEArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_CONTROLJOBTYPEArray_1::_IDL_SEQ_CONTROLJOBTYPEArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_CONTROLJOBTYPEArray_1::~_IDL_SEQ_CONTROLJOBTYPEArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_CONTROLJOBTYPEArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_CONTROLJOBTYPEArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_CONTROLJOBTYPEArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_CONTROLJOBTYPEArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_CONTROLJOBTYPEArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_CONTROLJOBTYPEArray_1& _IDL_SEQ_CONTROLJOBTYPEArray_1::operator= (const ::_IDL_SEQ_CONTROLJOBTYPEArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_CONTROLJOBTYPEArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_CONTROLJOBTYPEArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_CONTROLJOBTYPEArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_CONTROLJOBTYPEArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_CONTROLJOBTYPEArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_CONTROLJOBTYPEArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_CONTROLJOBTYPEArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_CONTROLJOBTYPEArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_CONTROLJOBTYPEArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_CONTROLJOBTYPEArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_CONTROLJOBTYPEArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_CONTROLJOBTYPEArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_CONTROLJOBTYPEArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_CONTROLJOBTYPEArray_1_var::_IDL_SEQ_CONTROLJOBTYPEArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_CONTROLJOBTYPEArray_1_var::_IDL_SEQ_CONTROLJOBTYPEArray_1_var (::_IDL_SEQ_CONTROLJOBTYPEArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_CONTROLJOBTYPEArray_1_var::_IDL_SEQ_CONTROLJOBTYPEArray_1_var (const ::_IDL_SEQ_CONTROLJOBTYPEArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_CONTROLJOBTYPEArray_1 (*(_s._ptr));
    }

_IDL_SEQ_CONTROLJOBTYPEArray_1_var& _IDL_SEQ_CONTROLJOBTYPEArray_1_var::operator= (::_IDL_SEQ_CONTROLJOBTYPEArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_CONTROLJOBTYPEArray_1_var& _IDL_SEQ_CONTROLJOBTYPEArray_1_var::operator= (const ::_IDL_SEQ_CONTROLJOBTYPEArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_CONTROLJOBTYPEArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_CONTROLJOBTYPEArray_1_var::~_IDL_SEQ_CONTROLJOBTYPEArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_CONTROLJOBTYPEArray_1 * _IDL_SEQ_CONTROLJOBTYPEArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_CONTROLJOBTYPEArray_1_var::operator ::_IDL_SEQ_CONTROLJOBTYPEArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_CONTROLJOBTYPEArray_1_var::operator ::_IDL_SEQ_CONTROLJOBTYPEArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_CONTROLJOBTYPEArray_1_var::operator _IDL_SEQ_CONTROLJOBTYPEArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_CONTROLJOBTYPEArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_CONTROLJOBTYPEArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_CONTROLJOBTYPEArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_CONTROLJOBTYPEArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_CONTROLJOBTYPEArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_CONTROLJOBTYPEArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_CONTROLJOBTYPEArray_1& _IDL_SEQ_CONTROLJOBTYPEArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_CONTROLJOBTYPEArray_1& _IDL_SEQ_CONTROLJOBTYPEArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_CONTROLJOBTYPEArray_1*& _IDL_SEQ_CONTROLJOBTYPEArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_CONTROLJOBTYPEArray_1* _IDL_SEQ_CONTROLJOBTYPEArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_CONTROLJOBTYPEArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_CONTROLJOBTYPEArray_1 > _IDL_SEQ_CONTROLJOBTYPEArray_1::CONTROLJOBTYPEArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_TRANSACTIONIDArray_1::__stubcode_version;
_IDL_SEQ_TRANSACTIONIDArray_1::_IDL_SEQ_TRANSACTIONIDArray_1()
{
  _defaultInit();
}
_IDL_SEQ_TRANSACTIONIDArray_1::_IDL_SEQ_TRANSACTIONIDArray_1 (const ::_IDL_SEQ_TRANSACTIONIDArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_TRANSACTIONIDArray_1::_IDL_SEQ_TRANSACTIONIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_TRANSACTIONIDArray_1::~_IDL_SEQ_TRANSACTIONIDArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_TRANSACTIONIDArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_TRANSACTIONIDArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_TRANSACTIONIDArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_TRANSACTIONIDArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_TRANSACTIONIDArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_TRANSACTIONIDArray_1& _IDL_SEQ_TRANSACTIONIDArray_1::operator= (const ::_IDL_SEQ_TRANSACTIONIDArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_TRANSACTIONIDArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_TRANSACTIONIDArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_TRANSACTIONIDArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_TRANSACTIONIDArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_TRANSACTIONIDArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_TRANSACTIONIDArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_TRANSACTIONIDArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_TRANSACTIONIDArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_TRANSACTIONIDArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_TRANSACTIONIDArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_TRANSACTIONIDArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_TRANSACTIONIDArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_TRANSACTIONIDArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_TRANSACTIONIDArray_1_var::_IDL_SEQ_TRANSACTIONIDArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_TRANSACTIONIDArray_1_var::_IDL_SEQ_TRANSACTIONIDArray_1_var (::_IDL_SEQ_TRANSACTIONIDArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_TRANSACTIONIDArray_1_var::_IDL_SEQ_TRANSACTIONIDArray_1_var (const ::_IDL_SEQ_TRANSACTIONIDArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_TRANSACTIONIDArray_1 (*(_s._ptr));
    }

_IDL_SEQ_TRANSACTIONIDArray_1_var& _IDL_SEQ_TRANSACTIONIDArray_1_var::operator= (::_IDL_SEQ_TRANSACTIONIDArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_TRANSACTIONIDArray_1_var& _IDL_SEQ_TRANSACTIONIDArray_1_var::operator= (const ::_IDL_SEQ_TRANSACTIONIDArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_TRANSACTIONIDArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_TRANSACTIONIDArray_1_var::~_IDL_SEQ_TRANSACTIONIDArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_TRANSACTIONIDArray_1 * _IDL_SEQ_TRANSACTIONIDArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_TRANSACTIONIDArray_1_var::operator ::_IDL_SEQ_TRANSACTIONIDArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_TRANSACTIONIDArray_1_var::operator ::_IDL_SEQ_TRANSACTIONIDArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_TRANSACTIONIDArray_1_var::operator _IDL_SEQ_TRANSACTIONIDArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_TRANSACTIONIDArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_TRANSACTIONIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_TRANSACTIONIDArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_TRANSACTIONIDArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_TRANSACTIONIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_TRANSACTIONIDArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_TRANSACTIONIDArray_1& _IDL_SEQ_TRANSACTIONIDArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_TRANSACTIONIDArray_1& _IDL_SEQ_TRANSACTIONIDArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_TRANSACTIONIDArray_1*& _IDL_SEQ_TRANSACTIONIDArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_TRANSACTIONIDArray_1* _IDL_SEQ_TRANSACTIONIDArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_TRANSACTIONIDArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_TRANSACTIONIDArray_1 > _IDL_SEQ_TRANSACTIONIDArray_1::TRANSACTIONIDArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_LOTIDArray_1::__stubcode_version;
_IDL_SEQ_LOTIDArray_1::_IDL_SEQ_LOTIDArray_1()
{
  _defaultInit();
}
_IDL_SEQ_LOTIDArray_1::_IDL_SEQ_LOTIDArray_1 (const ::_IDL_SEQ_LOTIDArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_LOTIDArray_1::_IDL_SEQ_LOTIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_LOTIDArray_1::~_IDL_SEQ_LOTIDArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_LOTIDArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_LOTIDArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_LOTIDArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_LOTIDArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_LOTIDArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_LOTIDArray_1& _IDL_SEQ_LOTIDArray_1::operator= (const ::_IDL_SEQ_LOTIDArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_LOTIDArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_LOTIDArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_LOTIDArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_LOTIDArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_LOTIDArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_LOTIDArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_LOTIDArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_LOTIDArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_LOTIDArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_LOTIDArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_LOTIDArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_LOTIDArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_LOTIDArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_LOTIDArray_1_var::_IDL_SEQ_LOTIDArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_LOTIDArray_1_var::_IDL_SEQ_LOTIDArray_1_var (::_IDL_SEQ_LOTIDArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_LOTIDArray_1_var::_IDL_SEQ_LOTIDArray_1_var (const ::_IDL_SEQ_LOTIDArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_LOTIDArray_1 (*(_s._ptr));
    }

_IDL_SEQ_LOTIDArray_1_var& _IDL_SEQ_LOTIDArray_1_var::operator= (::_IDL_SEQ_LOTIDArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_LOTIDArray_1_var& _IDL_SEQ_LOTIDArray_1_var::operator= (const ::_IDL_SEQ_LOTIDArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_LOTIDArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_LOTIDArray_1_var::~_IDL_SEQ_LOTIDArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_LOTIDArray_1 * _IDL_SEQ_LOTIDArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_LOTIDArray_1_var::operator ::_IDL_SEQ_LOTIDArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_LOTIDArray_1_var::operator ::_IDL_SEQ_LOTIDArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_LOTIDArray_1_var::operator _IDL_SEQ_LOTIDArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_LOTIDArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_LOTIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_LOTIDArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_LOTIDArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_LOTIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_LOTIDArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_LOTIDArray_1& _IDL_SEQ_LOTIDArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_LOTIDArray_1& _IDL_SEQ_LOTIDArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_LOTIDArray_1*& _IDL_SEQ_LOTIDArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_LOTIDArray_1* _IDL_SEQ_LOTIDArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_LOTIDArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_LOTIDArray_1 > _IDL_SEQ_LOTIDArray_1::LOTIDArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_LOTTYPEArray_1::__stubcode_version;
_IDL_SEQ_LOTTYPEArray_1::_IDL_SEQ_LOTTYPEArray_1()
{
  _defaultInit();
}
_IDL_SEQ_LOTTYPEArray_1::_IDL_SEQ_LOTTYPEArray_1 (const ::_IDL_SEQ_LOTTYPEArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_LOTTYPEArray_1::_IDL_SEQ_LOTTYPEArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_LOTTYPEArray_1::~_IDL_SEQ_LOTTYPEArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_LOTTYPEArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_LOTTYPEArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_LOTTYPEArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_LOTTYPEArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_LOTTYPEArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_LOTTYPEArray_1& _IDL_SEQ_LOTTYPEArray_1::operator= (const ::_IDL_SEQ_LOTTYPEArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_LOTTYPEArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_LOTTYPEArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_LOTTYPEArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_LOTTYPEArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_LOTTYPEArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_LOTTYPEArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_LOTTYPEArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_LOTTYPEArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_LOTTYPEArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_LOTTYPEArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_LOTTYPEArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_LOTTYPEArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_LOTTYPEArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_LOTTYPEArray_1_var::_IDL_SEQ_LOTTYPEArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_LOTTYPEArray_1_var::_IDL_SEQ_LOTTYPEArray_1_var (::_IDL_SEQ_LOTTYPEArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_LOTTYPEArray_1_var::_IDL_SEQ_LOTTYPEArray_1_var (const ::_IDL_SEQ_LOTTYPEArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_LOTTYPEArray_1 (*(_s._ptr));
    }

_IDL_SEQ_LOTTYPEArray_1_var& _IDL_SEQ_LOTTYPEArray_1_var::operator= (::_IDL_SEQ_LOTTYPEArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_LOTTYPEArray_1_var& _IDL_SEQ_LOTTYPEArray_1_var::operator= (const ::_IDL_SEQ_LOTTYPEArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_LOTTYPEArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_LOTTYPEArray_1_var::~_IDL_SEQ_LOTTYPEArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_LOTTYPEArray_1 * _IDL_SEQ_LOTTYPEArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_LOTTYPEArray_1_var::operator ::_IDL_SEQ_LOTTYPEArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_LOTTYPEArray_1_var::operator ::_IDL_SEQ_LOTTYPEArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_LOTTYPEArray_1_var::operator _IDL_SEQ_LOTTYPEArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_LOTTYPEArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_LOTTYPEArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_LOTTYPEArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_LOTTYPEArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_LOTTYPEArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_LOTTYPEArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_LOTTYPEArray_1& _IDL_SEQ_LOTTYPEArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_LOTTYPEArray_1& _IDL_SEQ_LOTTYPEArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_LOTTYPEArray_1*& _IDL_SEQ_LOTTYPEArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_LOTTYPEArray_1* _IDL_SEQ_LOTTYPEArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_LOTTYPEArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_LOTTYPEArray_1 > _IDL_SEQ_LOTTYPEArray_1::LOTTYPEArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_PARTIDArray_1::__stubcode_version;
_IDL_SEQ_PARTIDArray_1::_IDL_SEQ_PARTIDArray_1()
{
  _defaultInit();
}
_IDL_SEQ_PARTIDArray_1::_IDL_SEQ_PARTIDArray_1 (const ::_IDL_SEQ_PARTIDArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_PARTIDArray_1::_IDL_SEQ_PARTIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_PARTIDArray_1::~_IDL_SEQ_PARTIDArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_PARTIDArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_PARTIDArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_PARTIDArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_PARTIDArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_PARTIDArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_PARTIDArray_1& _IDL_SEQ_PARTIDArray_1::operator= (const ::_IDL_SEQ_PARTIDArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_PARTIDArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_PARTIDArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_PARTIDArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_PARTIDArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_PARTIDArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_PARTIDArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_PARTIDArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_PARTIDArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_PARTIDArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_PARTIDArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_PARTIDArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_PARTIDArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_PARTIDArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_PARTIDArray_1_var::_IDL_SEQ_PARTIDArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_PARTIDArray_1_var::_IDL_SEQ_PARTIDArray_1_var (::_IDL_SEQ_PARTIDArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_PARTIDArray_1_var::_IDL_SEQ_PARTIDArray_1_var (const ::_IDL_SEQ_PARTIDArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_PARTIDArray_1 (*(_s._ptr));
    }

_IDL_SEQ_PARTIDArray_1_var& _IDL_SEQ_PARTIDArray_1_var::operator= (::_IDL_SEQ_PARTIDArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_PARTIDArray_1_var& _IDL_SEQ_PARTIDArray_1_var::operator= (const ::_IDL_SEQ_PARTIDArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_PARTIDArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_PARTIDArray_1_var::~_IDL_SEQ_PARTIDArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_PARTIDArray_1 * _IDL_SEQ_PARTIDArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_PARTIDArray_1_var::operator ::_IDL_SEQ_PARTIDArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_PARTIDArray_1_var::operator ::_IDL_SEQ_PARTIDArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_PARTIDArray_1_var::operator _IDL_SEQ_PARTIDArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_PARTIDArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_PARTIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_PARTIDArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_PARTIDArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_PARTIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_PARTIDArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_PARTIDArray_1& _IDL_SEQ_PARTIDArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_PARTIDArray_1& _IDL_SEQ_PARTIDArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_PARTIDArray_1*& _IDL_SEQ_PARTIDArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_PARTIDArray_1* _IDL_SEQ_PARTIDArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_PARTIDArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_PARTIDArray_1 > _IDL_SEQ_PARTIDArray_1::PARTIDArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_LAYERArray_1::__stubcode_version;
_IDL_SEQ_LAYERArray_1::_IDL_SEQ_LAYERArray_1()
{
  _defaultInit();
}
_IDL_SEQ_LAYERArray_1::_IDL_SEQ_LAYERArray_1 (const ::_IDL_SEQ_LAYERArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_LAYERArray_1::_IDL_SEQ_LAYERArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_LAYERArray_1::~_IDL_SEQ_LAYERArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_LAYERArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_LAYERArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_LAYERArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_LAYERArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_LAYERArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_LAYERArray_1& _IDL_SEQ_LAYERArray_1::operator= (const ::_IDL_SEQ_LAYERArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_LAYERArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_LAYERArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_LAYERArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_LAYERArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_LAYERArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_LAYERArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_LAYERArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_LAYERArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_LAYERArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_LAYERArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_LAYERArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_LAYERArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_LAYERArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_LAYERArray_1_var::_IDL_SEQ_LAYERArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_LAYERArray_1_var::_IDL_SEQ_LAYERArray_1_var (::_IDL_SEQ_LAYERArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_LAYERArray_1_var::_IDL_SEQ_LAYERArray_1_var (const ::_IDL_SEQ_LAYERArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_LAYERArray_1 (*(_s._ptr));
    }

_IDL_SEQ_LAYERArray_1_var& _IDL_SEQ_LAYERArray_1_var::operator= (::_IDL_SEQ_LAYERArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_LAYERArray_1_var& _IDL_SEQ_LAYERArray_1_var::operator= (const ::_IDL_SEQ_LAYERArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_LAYERArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_LAYERArray_1_var::~_IDL_SEQ_LAYERArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_LAYERArray_1 * _IDL_SEQ_LAYERArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_LAYERArray_1_var::operator ::_IDL_SEQ_LAYERArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_LAYERArray_1_var::operator ::_IDL_SEQ_LAYERArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_LAYERArray_1_var::operator _IDL_SEQ_LAYERArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_LAYERArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_LAYERArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_LAYERArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_LAYERArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_LAYERArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_LAYERArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_LAYERArray_1& _IDL_SEQ_LAYERArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_LAYERArray_1& _IDL_SEQ_LAYERArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_LAYERArray_1*& _IDL_SEQ_LAYERArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_LAYERArray_1* _IDL_SEQ_LAYERArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_LAYERArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_LAYERArray_1 > _IDL_SEQ_LAYERArray_1::LAYERArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_ROUTEArray_1::__stubcode_version;
_IDL_SEQ_ROUTEArray_1::_IDL_SEQ_ROUTEArray_1()
{
  _defaultInit();
}
_IDL_SEQ_ROUTEArray_1::_IDL_SEQ_ROUTEArray_1 (const ::_IDL_SEQ_ROUTEArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_ROUTEArray_1::_IDL_SEQ_ROUTEArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_ROUTEArray_1::~_IDL_SEQ_ROUTEArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_ROUTEArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_ROUTEArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_ROUTEArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_ROUTEArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_ROUTEArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_ROUTEArray_1& _IDL_SEQ_ROUTEArray_1::operator= (const ::_IDL_SEQ_ROUTEArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_ROUTEArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_ROUTEArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_ROUTEArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_ROUTEArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_ROUTEArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_ROUTEArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_ROUTEArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_ROUTEArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_ROUTEArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_ROUTEArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_ROUTEArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_ROUTEArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_ROUTEArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_ROUTEArray_1_var::_IDL_SEQ_ROUTEArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_ROUTEArray_1_var::_IDL_SEQ_ROUTEArray_1_var (::_IDL_SEQ_ROUTEArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_ROUTEArray_1_var::_IDL_SEQ_ROUTEArray_1_var (const ::_IDL_SEQ_ROUTEArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_ROUTEArray_1 (*(_s._ptr));
    }

_IDL_SEQ_ROUTEArray_1_var& _IDL_SEQ_ROUTEArray_1_var::operator= (::_IDL_SEQ_ROUTEArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_ROUTEArray_1_var& _IDL_SEQ_ROUTEArray_1_var::operator= (const ::_IDL_SEQ_ROUTEArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_ROUTEArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_ROUTEArray_1_var::~_IDL_SEQ_ROUTEArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_ROUTEArray_1 * _IDL_SEQ_ROUTEArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_ROUTEArray_1_var::operator ::_IDL_SEQ_ROUTEArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_ROUTEArray_1_var::operator ::_IDL_SEQ_ROUTEArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_ROUTEArray_1_var::operator _IDL_SEQ_ROUTEArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_ROUTEArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_ROUTEArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_ROUTEArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_ROUTEArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_ROUTEArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_ROUTEArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_ROUTEArray_1& _IDL_SEQ_ROUTEArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_ROUTEArray_1& _IDL_SEQ_ROUTEArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_ROUTEArray_1*& _IDL_SEQ_ROUTEArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_ROUTEArray_1* _IDL_SEQ_ROUTEArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_ROUTEArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_ROUTEArray_1 > _IDL_SEQ_ROUTEArray_1::ROUTEArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_ROUTEGROUPArray_1::__stubcode_version;
_IDL_SEQ_ROUTEGROUPArray_1::_IDL_SEQ_ROUTEGROUPArray_1()
{
  _defaultInit();
}
_IDL_SEQ_ROUTEGROUPArray_1::_IDL_SEQ_ROUTEGROUPArray_1 (const ::_IDL_SEQ_ROUTEGROUPArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_ROUTEGROUPArray_1::_IDL_SEQ_ROUTEGROUPArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_ROUTEGROUPArray_1::~_IDL_SEQ_ROUTEGROUPArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_ROUTEGROUPArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_ROUTEGROUPArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_ROUTEGROUPArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_ROUTEGROUPArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_ROUTEGROUPArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_ROUTEGROUPArray_1& _IDL_SEQ_ROUTEGROUPArray_1::operator= (const ::_IDL_SEQ_ROUTEGROUPArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_ROUTEGROUPArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_ROUTEGROUPArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_ROUTEGROUPArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_ROUTEGROUPArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_ROUTEGROUPArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_ROUTEGROUPArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_ROUTEGROUPArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_ROUTEGROUPArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_ROUTEGROUPArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_ROUTEGROUPArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_ROUTEGROUPArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_ROUTEGROUPArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_ROUTEGROUPArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_ROUTEGROUPArray_1_var::_IDL_SEQ_ROUTEGROUPArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_ROUTEGROUPArray_1_var::_IDL_SEQ_ROUTEGROUPArray_1_var (::_IDL_SEQ_ROUTEGROUPArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_ROUTEGROUPArray_1_var::_IDL_SEQ_ROUTEGROUPArray_1_var (const ::_IDL_SEQ_ROUTEGROUPArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_ROUTEGROUPArray_1 (*(_s._ptr));
    }

_IDL_SEQ_ROUTEGROUPArray_1_var& _IDL_SEQ_ROUTEGROUPArray_1_var::operator= (::_IDL_SEQ_ROUTEGROUPArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_ROUTEGROUPArray_1_var& _IDL_SEQ_ROUTEGROUPArray_1_var::operator= (const ::_IDL_SEQ_ROUTEGROUPArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_ROUTEGROUPArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_ROUTEGROUPArray_1_var::~_IDL_SEQ_ROUTEGROUPArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_ROUTEGROUPArray_1 * _IDL_SEQ_ROUTEGROUPArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_ROUTEGROUPArray_1_var::operator ::_IDL_SEQ_ROUTEGROUPArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_ROUTEGROUPArray_1_var::operator ::_IDL_SEQ_ROUTEGROUPArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_ROUTEGROUPArray_1_var::operator _IDL_SEQ_ROUTEGROUPArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_ROUTEGROUPArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_ROUTEGROUPArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_ROUTEGROUPArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_ROUTEGROUPArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_ROUTEGROUPArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_ROUTEGROUPArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_ROUTEGROUPArray_1& _IDL_SEQ_ROUTEGROUPArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_ROUTEGROUPArray_1& _IDL_SEQ_ROUTEGROUPArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_ROUTEGROUPArray_1*& _IDL_SEQ_ROUTEGROUPArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_ROUTEGROUPArray_1* _IDL_SEQ_ROUTEGROUPArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_ROUTEGROUPArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_ROUTEGROUPArray_1 > _IDL_SEQ_ROUTEGROUPArray_1::ROUTEGROUPArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_OPERATIONArray_1::__stubcode_version;
_IDL_SEQ_OPERATIONArray_1::_IDL_SEQ_OPERATIONArray_1()
{
  _defaultInit();
}
_IDL_SEQ_OPERATIONArray_1::_IDL_SEQ_OPERATIONArray_1 (const ::_IDL_SEQ_OPERATIONArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_OPERATIONArray_1::_IDL_SEQ_OPERATIONArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_OPERATIONArray_1::~_IDL_SEQ_OPERATIONArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_OPERATIONArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_OPERATIONArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_OPERATIONArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_OPERATIONArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_OPERATIONArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_OPERATIONArray_1& _IDL_SEQ_OPERATIONArray_1::operator= (const ::_IDL_SEQ_OPERATIONArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_OPERATIONArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_OPERATIONArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_OPERATIONArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_OPERATIONArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_OPERATIONArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_OPERATIONArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_OPERATIONArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_OPERATIONArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_OPERATIONArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_OPERATIONArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_OPERATIONArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_OPERATIONArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_OPERATIONArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_OPERATIONArray_1_var::_IDL_SEQ_OPERATIONArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_OPERATIONArray_1_var::_IDL_SEQ_OPERATIONArray_1_var (::_IDL_SEQ_OPERATIONArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_OPERATIONArray_1_var::_IDL_SEQ_OPERATIONArray_1_var (const ::_IDL_SEQ_OPERATIONArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_OPERATIONArray_1 (*(_s._ptr));
    }

_IDL_SEQ_OPERATIONArray_1_var& _IDL_SEQ_OPERATIONArray_1_var::operator= (::_IDL_SEQ_OPERATIONArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_OPERATIONArray_1_var& _IDL_SEQ_OPERATIONArray_1_var::operator= (const ::_IDL_SEQ_OPERATIONArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_OPERATIONArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_OPERATIONArray_1_var::~_IDL_SEQ_OPERATIONArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_OPERATIONArray_1 * _IDL_SEQ_OPERATIONArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_OPERATIONArray_1_var::operator ::_IDL_SEQ_OPERATIONArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_OPERATIONArray_1_var::operator ::_IDL_SEQ_OPERATIONArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_OPERATIONArray_1_var::operator _IDL_SEQ_OPERATIONArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_OPERATIONArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_OPERATIONArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_OPERATIONArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_OPERATIONArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_OPERATIONArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_OPERATIONArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_OPERATIONArray_1& _IDL_SEQ_OPERATIONArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_OPERATIONArray_1& _IDL_SEQ_OPERATIONArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_OPERATIONArray_1*& _IDL_SEQ_OPERATIONArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_OPERATIONArray_1* _IDL_SEQ_OPERATIONArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_OPERATIONArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_OPERATIONArray_1 > _IDL_SEQ_OPERATIONArray_1::OPERATIONArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_RETICLEIDArray_1::__stubcode_version;
_IDL_SEQ_RETICLEIDArray_1::_IDL_SEQ_RETICLEIDArray_1()
{
  _defaultInit();
}
_IDL_SEQ_RETICLEIDArray_1::_IDL_SEQ_RETICLEIDArray_1 (const ::_IDL_SEQ_RETICLEIDArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_RETICLEIDArray_1::_IDL_SEQ_RETICLEIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_RETICLEIDArray_1::~_IDL_SEQ_RETICLEIDArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_RETICLEIDArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_RETICLEIDArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_RETICLEIDArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_RETICLEIDArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_RETICLEIDArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_RETICLEIDArray_1& _IDL_SEQ_RETICLEIDArray_1::operator= (const ::_IDL_SEQ_RETICLEIDArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_RETICLEIDArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_RETICLEIDArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_RETICLEIDArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_RETICLEIDArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_RETICLEIDArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_RETICLEIDArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_RETICLEIDArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_RETICLEIDArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_RETICLEIDArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_RETICLEIDArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_RETICLEIDArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_RETICLEIDArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_RETICLEIDArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_RETICLEIDArray_1_var::_IDL_SEQ_RETICLEIDArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_RETICLEIDArray_1_var::_IDL_SEQ_RETICLEIDArray_1_var (::_IDL_SEQ_RETICLEIDArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_RETICLEIDArray_1_var::_IDL_SEQ_RETICLEIDArray_1_var (const ::_IDL_SEQ_RETICLEIDArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_RETICLEIDArray_1 (*(_s._ptr));
    }

_IDL_SEQ_RETICLEIDArray_1_var& _IDL_SEQ_RETICLEIDArray_1_var::operator= (::_IDL_SEQ_RETICLEIDArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_RETICLEIDArray_1_var& _IDL_SEQ_RETICLEIDArray_1_var::operator= (const ::_IDL_SEQ_RETICLEIDArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_RETICLEIDArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_RETICLEIDArray_1_var::~_IDL_SEQ_RETICLEIDArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_RETICLEIDArray_1 * _IDL_SEQ_RETICLEIDArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_RETICLEIDArray_1_var::operator ::_IDL_SEQ_RETICLEIDArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_RETICLEIDArray_1_var::operator ::_IDL_SEQ_RETICLEIDArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_RETICLEIDArray_1_var::operator _IDL_SEQ_RETICLEIDArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_RETICLEIDArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_RETICLEIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_RETICLEIDArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_RETICLEIDArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_RETICLEIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_RETICLEIDArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_RETICLEIDArray_1& _IDL_SEQ_RETICLEIDArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_RETICLEIDArray_1& _IDL_SEQ_RETICLEIDArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_RETICLEIDArray_1*& _IDL_SEQ_RETICLEIDArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_RETICLEIDArray_1* _IDL_SEQ_RETICLEIDArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_RETICLEIDArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_RETICLEIDArray_1 > _IDL_SEQ_RETICLEIDArray_1::RETICLEIDArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_PROCESSEQUIPTYPEArray_1::__stubcode_version;
_IDL_SEQ_PROCESSEQUIPTYPEArray_1::_IDL_SEQ_PROCESSEQUIPTYPEArray_1()
{
  _defaultInit();
}
_IDL_SEQ_PROCESSEQUIPTYPEArray_1::_IDL_SEQ_PROCESSEQUIPTYPEArray_1 (const ::_IDL_SEQ_PROCESSEQUIPTYPEArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_PROCESSEQUIPTYPEArray_1::_IDL_SEQ_PROCESSEQUIPTYPEArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_PROCESSEQUIPTYPEArray_1::~_IDL_SEQ_PROCESSEQUIPTYPEArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_PROCESSEQUIPTYPEArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_PROCESSEQUIPTYPEArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_PROCESSEQUIPTYPEArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_PROCESSEQUIPTYPEArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_PROCESSEQUIPTYPEArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_PROCESSEQUIPTYPEArray_1& _IDL_SEQ_PROCESSEQUIPTYPEArray_1::operator= (const ::_IDL_SEQ_PROCESSEQUIPTYPEArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_PROCESSEQUIPTYPEArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_PROCESSEQUIPTYPEArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_PROCESSEQUIPTYPEArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_PROCESSEQUIPTYPEArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_PROCESSEQUIPTYPEArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_PROCESSEQUIPTYPEArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_PROCESSEQUIPTYPEArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_PROCESSEQUIPTYPEArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_PROCESSEQUIPTYPEArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_PROCESSEQUIPTYPEArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_PROCESSEQUIPTYPEArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_PROCESSEQUIPTYPEArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_PROCESSEQUIPTYPEArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_PROCESSEQUIPTYPEArray_1_var::_IDL_SEQ_PROCESSEQUIPTYPEArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_PROCESSEQUIPTYPEArray_1_var::_IDL_SEQ_PROCESSEQUIPTYPEArray_1_var (::_IDL_SEQ_PROCESSEQUIPTYPEArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_PROCESSEQUIPTYPEArray_1_var::_IDL_SEQ_PROCESSEQUIPTYPEArray_1_var (const ::_IDL_SEQ_PROCESSEQUIPTYPEArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_PROCESSEQUIPTYPEArray_1 (*(_s._ptr));
    }

_IDL_SEQ_PROCESSEQUIPTYPEArray_1_var& _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var::operator= (::_IDL_SEQ_PROCESSEQUIPTYPEArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_PROCESSEQUIPTYPEArray_1_var& _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var::operator= (const ::_IDL_SEQ_PROCESSEQUIPTYPEArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_PROCESSEQUIPTYPEArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_PROCESSEQUIPTYPEArray_1_var::~_IDL_SEQ_PROCESSEQUIPTYPEArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_PROCESSEQUIPTYPEArray_1 * _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_PROCESSEQUIPTYPEArray_1_var::operator ::_IDL_SEQ_PROCESSEQUIPTYPEArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_PROCESSEQUIPTYPEArray_1_var::operator ::_IDL_SEQ_PROCESSEQUIPTYPEArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_PROCESSEQUIPTYPEArray_1_var::operator _IDL_SEQ_PROCESSEQUIPTYPEArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_PROCESSEQUIPTYPEArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_PROCESSEQUIPTYPEArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_PROCESSEQUIPTYPEArray_1& _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_PROCESSEQUIPTYPEArray_1& _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_PROCESSEQUIPTYPEArray_1*& _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_PROCESSEQUIPTYPEArray_1* _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_PROCESSEQUIPTYPEArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_PROCESSEQUIPTYPEArray_1 > _IDL_SEQ_PROCESSEQUIPTYPEArray_1::PROCESSEQUIPTYPEArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_PROCESSEQUIPIDArray_1::__stubcode_version;
_IDL_SEQ_PROCESSEQUIPIDArray_1::_IDL_SEQ_PROCESSEQUIPIDArray_1()
{
  _defaultInit();
}
_IDL_SEQ_PROCESSEQUIPIDArray_1::_IDL_SEQ_PROCESSEQUIPIDArray_1 (const ::_IDL_SEQ_PROCESSEQUIPIDArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_PROCESSEQUIPIDArray_1::_IDL_SEQ_PROCESSEQUIPIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_PROCESSEQUIPIDArray_1::~_IDL_SEQ_PROCESSEQUIPIDArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_PROCESSEQUIPIDArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_PROCESSEQUIPIDArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_PROCESSEQUIPIDArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_PROCESSEQUIPIDArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_PROCESSEQUIPIDArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_PROCESSEQUIPIDArray_1& _IDL_SEQ_PROCESSEQUIPIDArray_1::operator= (const ::_IDL_SEQ_PROCESSEQUIPIDArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_PROCESSEQUIPIDArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_PROCESSEQUIPIDArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_PROCESSEQUIPIDArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_PROCESSEQUIPIDArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_PROCESSEQUIPIDArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_PROCESSEQUIPIDArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_PROCESSEQUIPIDArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_PROCESSEQUIPIDArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_PROCESSEQUIPIDArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_PROCESSEQUIPIDArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_PROCESSEQUIPIDArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_PROCESSEQUIPIDArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_PROCESSEQUIPIDArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_PROCESSEQUIPIDArray_1_var::_IDL_SEQ_PROCESSEQUIPIDArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_PROCESSEQUIPIDArray_1_var::_IDL_SEQ_PROCESSEQUIPIDArray_1_var (::_IDL_SEQ_PROCESSEQUIPIDArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_PROCESSEQUIPIDArray_1_var::_IDL_SEQ_PROCESSEQUIPIDArray_1_var (const ::_IDL_SEQ_PROCESSEQUIPIDArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_PROCESSEQUIPIDArray_1 (*(_s._ptr));
    }

_IDL_SEQ_PROCESSEQUIPIDArray_1_var& _IDL_SEQ_PROCESSEQUIPIDArray_1_var::operator= (::_IDL_SEQ_PROCESSEQUIPIDArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_PROCESSEQUIPIDArray_1_var& _IDL_SEQ_PROCESSEQUIPIDArray_1_var::operator= (const ::_IDL_SEQ_PROCESSEQUIPIDArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_PROCESSEQUIPIDArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_PROCESSEQUIPIDArray_1_var::~_IDL_SEQ_PROCESSEQUIPIDArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_PROCESSEQUIPIDArray_1 * _IDL_SEQ_PROCESSEQUIPIDArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_PROCESSEQUIPIDArray_1_var::operator ::_IDL_SEQ_PROCESSEQUIPIDArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_PROCESSEQUIPIDArray_1_var::operator ::_IDL_SEQ_PROCESSEQUIPIDArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_PROCESSEQUIPIDArray_1_var::operator _IDL_SEQ_PROCESSEQUIPIDArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_PROCESSEQUIPIDArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_PROCESSEQUIPIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_PROCESSEQUIPIDArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_PROCESSEQUIPIDArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_PROCESSEQUIPIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_PROCESSEQUIPIDArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_PROCESSEQUIPIDArray_1& _IDL_SEQ_PROCESSEQUIPIDArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_PROCESSEQUIPIDArray_1& _IDL_SEQ_PROCESSEQUIPIDArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_PROCESSEQUIPIDArray_1*& _IDL_SEQ_PROCESSEQUIPIDArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_PROCESSEQUIPIDArray_1* _IDL_SEQ_PROCESSEQUIPIDArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_PROCESSEQUIPIDArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_PROCESSEQUIPIDArray_1 > _IDL_SEQ_PROCESSEQUIPIDArray_1::PROCESSEQUIPIDArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_RECOMMENDMODEArray_1::__stubcode_version;
_IDL_SEQ_RECOMMENDMODEArray_1::_IDL_SEQ_RECOMMENDMODEArray_1()
{
  _defaultInit();
}
_IDL_SEQ_RECOMMENDMODEArray_1::_IDL_SEQ_RECOMMENDMODEArray_1 (const ::_IDL_SEQ_RECOMMENDMODEArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_RECOMMENDMODEArray_1::_IDL_SEQ_RECOMMENDMODEArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_RECOMMENDMODEArray_1::~_IDL_SEQ_RECOMMENDMODEArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_RECOMMENDMODEArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_RECOMMENDMODEArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_RECOMMENDMODEArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_RECOMMENDMODEArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_RECOMMENDMODEArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_RECOMMENDMODEArray_1& _IDL_SEQ_RECOMMENDMODEArray_1::operator= (const ::_IDL_SEQ_RECOMMENDMODEArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_RECOMMENDMODEArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_RECOMMENDMODEArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_RECOMMENDMODEArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_RECOMMENDMODEArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_RECOMMENDMODEArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_RECOMMENDMODEArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_RECOMMENDMODEArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_RECOMMENDMODEArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_RECOMMENDMODEArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_RECOMMENDMODEArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_RECOMMENDMODEArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_RECOMMENDMODEArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_RECOMMENDMODEArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_RECOMMENDMODEArray_1_var::_IDL_SEQ_RECOMMENDMODEArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_RECOMMENDMODEArray_1_var::_IDL_SEQ_RECOMMENDMODEArray_1_var (::_IDL_SEQ_RECOMMENDMODEArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_RECOMMENDMODEArray_1_var::_IDL_SEQ_RECOMMENDMODEArray_1_var (const ::_IDL_SEQ_RECOMMENDMODEArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_RECOMMENDMODEArray_1 (*(_s._ptr));
    }

_IDL_SEQ_RECOMMENDMODEArray_1_var& _IDL_SEQ_RECOMMENDMODEArray_1_var::operator= (::_IDL_SEQ_RECOMMENDMODEArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_RECOMMENDMODEArray_1_var& _IDL_SEQ_RECOMMENDMODEArray_1_var::operator= (const ::_IDL_SEQ_RECOMMENDMODEArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_RECOMMENDMODEArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_RECOMMENDMODEArray_1_var::~_IDL_SEQ_RECOMMENDMODEArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_RECOMMENDMODEArray_1 * _IDL_SEQ_RECOMMENDMODEArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_RECOMMENDMODEArray_1_var::operator ::_IDL_SEQ_RECOMMENDMODEArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_RECOMMENDMODEArray_1_var::operator ::_IDL_SEQ_RECOMMENDMODEArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_RECOMMENDMODEArray_1_var::operator _IDL_SEQ_RECOMMENDMODEArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_RECOMMENDMODEArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_RECOMMENDMODEArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_RECOMMENDMODEArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_RECOMMENDMODEArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_RECOMMENDMODEArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_RECOMMENDMODEArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_RECOMMENDMODEArray_1& _IDL_SEQ_RECOMMENDMODEArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_RECOMMENDMODEArray_1& _IDL_SEQ_RECOMMENDMODEArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_RECOMMENDMODEArray_1*& _IDL_SEQ_RECOMMENDMODEArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_RECOMMENDMODEArray_1* _IDL_SEQ_RECOMMENDMODEArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_RECOMMENDMODEArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_RECOMMENDMODEArray_1 > _IDL_SEQ_RECOMMENDMODEArray_1::RECOMMENDMODEArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_REWORKArray_1::__stubcode_version;
_IDL_SEQ_REWORKArray_1::_IDL_SEQ_REWORKArray_1()
{
  _defaultInit();
}
_IDL_SEQ_REWORKArray_1::_IDL_SEQ_REWORKArray_1 (const ::_IDL_SEQ_REWORKArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_REWORKArray_1::_IDL_SEQ_REWORKArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_REWORKArray_1::~_IDL_SEQ_REWORKArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_REWORKArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_REWORKArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_REWORKArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_REWORKArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_REWORKArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_REWORKArray_1& _IDL_SEQ_REWORKArray_1::operator= (const ::_IDL_SEQ_REWORKArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_REWORKArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_REWORKArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_REWORKArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_REWORKArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_REWORKArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_REWORKArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_REWORKArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_REWORKArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_REWORKArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_REWORKArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_REWORKArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_REWORKArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_REWORKArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_REWORKArray_1_var::_IDL_SEQ_REWORKArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_REWORKArray_1_var::_IDL_SEQ_REWORKArray_1_var (::_IDL_SEQ_REWORKArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_REWORKArray_1_var::_IDL_SEQ_REWORKArray_1_var (const ::_IDL_SEQ_REWORKArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_REWORKArray_1 (*(_s._ptr));
    }

_IDL_SEQ_REWORKArray_1_var& _IDL_SEQ_REWORKArray_1_var::operator= (::_IDL_SEQ_REWORKArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_REWORKArray_1_var& _IDL_SEQ_REWORKArray_1_var::operator= (const ::_IDL_SEQ_REWORKArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_REWORKArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_REWORKArray_1_var::~_IDL_SEQ_REWORKArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_REWORKArray_1 * _IDL_SEQ_REWORKArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_REWORKArray_1_var::operator ::_IDL_SEQ_REWORKArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_REWORKArray_1_var::operator ::_IDL_SEQ_REWORKArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_REWORKArray_1_var::operator _IDL_SEQ_REWORKArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_REWORKArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_REWORKArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_REWORKArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_REWORKArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_REWORKArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_REWORKArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_REWORKArray_1& _IDL_SEQ_REWORKArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_REWORKArray_1& _IDL_SEQ_REWORKArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_REWORKArray_1*& _IDL_SEQ_REWORKArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_REWORKArray_1* _IDL_SEQ_REWORKArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_REWORKArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_REWORKArray_1 > _IDL_SEQ_REWORKArray_1::REWORKArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_PARENTLOTIDArray_1::__stubcode_version;
_IDL_SEQ_PARENTLOTIDArray_1::_IDL_SEQ_PARENTLOTIDArray_1()
{
  _defaultInit();
}
_IDL_SEQ_PARENTLOTIDArray_1::_IDL_SEQ_PARENTLOTIDArray_1 (const ::_IDL_SEQ_PARENTLOTIDArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_PARENTLOTIDArray_1::_IDL_SEQ_PARENTLOTIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_PARENTLOTIDArray_1::~_IDL_SEQ_PARENTLOTIDArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_PARENTLOTIDArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_PARENTLOTIDArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_PARENTLOTIDArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_PARENTLOTIDArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_PARENTLOTIDArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_PARENTLOTIDArray_1& _IDL_SEQ_PARENTLOTIDArray_1::operator= (const ::_IDL_SEQ_PARENTLOTIDArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_PARENTLOTIDArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_PARENTLOTIDArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_PARENTLOTIDArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_PARENTLOTIDArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_PARENTLOTIDArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_PARENTLOTIDArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_PARENTLOTIDArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_PARENTLOTIDArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_PARENTLOTIDArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_PARENTLOTIDArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_PARENTLOTIDArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_PARENTLOTIDArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_PARENTLOTIDArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_PARENTLOTIDArray_1_var::_IDL_SEQ_PARENTLOTIDArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_PARENTLOTIDArray_1_var::_IDL_SEQ_PARENTLOTIDArray_1_var (::_IDL_SEQ_PARENTLOTIDArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_PARENTLOTIDArray_1_var::_IDL_SEQ_PARENTLOTIDArray_1_var (const ::_IDL_SEQ_PARENTLOTIDArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_PARENTLOTIDArray_1 (*(_s._ptr));
    }

_IDL_SEQ_PARENTLOTIDArray_1_var& _IDL_SEQ_PARENTLOTIDArray_1_var::operator= (::_IDL_SEQ_PARENTLOTIDArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_PARENTLOTIDArray_1_var& _IDL_SEQ_PARENTLOTIDArray_1_var::operator= (const ::_IDL_SEQ_PARENTLOTIDArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_PARENTLOTIDArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_PARENTLOTIDArray_1_var::~_IDL_SEQ_PARENTLOTIDArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_PARENTLOTIDArray_1 * _IDL_SEQ_PARENTLOTIDArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_PARENTLOTIDArray_1_var::operator ::_IDL_SEQ_PARENTLOTIDArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_PARENTLOTIDArray_1_var::operator ::_IDL_SEQ_PARENTLOTIDArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_PARENTLOTIDArray_1_var::operator _IDL_SEQ_PARENTLOTIDArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_PARENTLOTIDArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_PARENTLOTIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_PARENTLOTIDArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_PARENTLOTIDArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_PARENTLOTIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_PARENTLOTIDArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_PARENTLOTIDArray_1& _IDL_SEQ_PARENTLOTIDArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_PARENTLOTIDArray_1& _IDL_SEQ_PARENTLOTIDArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_PARENTLOTIDArray_1*& _IDL_SEQ_PARENTLOTIDArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_PARENTLOTIDArray_1* _IDL_SEQ_PARENTLOTIDArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_PARENTLOTIDArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_PARENTLOTIDArray_1 > _IDL_SEQ_PARENTLOTIDArray_1::PARENTLOTIDArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_PRETOOLArray_1::__stubcode_version;
_IDL_SEQ_PRETOOLArray_1::_IDL_SEQ_PRETOOLArray_1()
{
  _defaultInit();
}
_IDL_SEQ_PRETOOLArray_1::_IDL_SEQ_PRETOOLArray_1 (const ::_IDL_SEQ_PRETOOLArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_PRETOOLArray_1::_IDL_SEQ_PRETOOLArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_PRETOOLArray_1::~_IDL_SEQ_PRETOOLArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_PRETOOLArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_PRETOOLArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_PRETOOLArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_PRETOOLArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_PRETOOLArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_PRETOOLArray_1& _IDL_SEQ_PRETOOLArray_1::operator= (const ::_IDL_SEQ_PRETOOLArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_PRETOOLArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_PRETOOLArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_PRETOOLArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_PRETOOLArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_PRETOOLArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_PRETOOLArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_PRETOOLArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_PRETOOLArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_PRETOOLArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_PRETOOLArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_PRETOOLArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_PRETOOLArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_PRETOOLArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_PRETOOLArray_1_var::_IDL_SEQ_PRETOOLArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_PRETOOLArray_1_var::_IDL_SEQ_PRETOOLArray_1_var (::_IDL_SEQ_PRETOOLArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_PRETOOLArray_1_var::_IDL_SEQ_PRETOOLArray_1_var (const ::_IDL_SEQ_PRETOOLArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_PRETOOLArray_1 (*(_s._ptr));
    }

_IDL_SEQ_PRETOOLArray_1_var& _IDL_SEQ_PRETOOLArray_1_var::operator= (::_IDL_SEQ_PRETOOLArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_PRETOOLArray_1_var& _IDL_SEQ_PRETOOLArray_1_var::operator= (const ::_IDL_SEQ_PRETOOLArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_PRETOOLArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_PRETOOLArray_1_var::~_IDL_SEQ_PRETOOLArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_PRETOOLArray_1 * _IDL_SEQ_PRETOOLArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_PRETOOLArray_1_var::operator ::_IDL_SEQ_PRETOOLArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_PRETOOLArray_1_var::operator ::_IDL_SEQ_PRETOOLArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_PRETOOLArray_1_var::operator _IDL_SEQ_PRETOOLArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_PRETOOLArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_PRETOOLArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_PRETOOLArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_PRETOOLArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_PRETOOLArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_PRETOOLArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_PRETOOLArray_1& _IDL_SEQ_PRETOOLArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_PRETOOLArray_1& _IDL_SEQ_PRETOOLArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_PRETOOLArray_1*& _IDL_SEQ_PRETOOLArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_PRETOOLArray_1* _IDL_SEQ_PRETOOLArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_PRETOOLArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_PRETOOLArray_1 > _IDL_SEQ_PRETOOLArray_1::PRETOOLArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_SENDAHEADArray_1::__stubcode_version;
_IDL_SEQ_SENDAHEADArray_1::_IDL_SEQ_SENDAHEADArray_1()
{
  _defaultInit();
}
_IDL_SEQ_SENDAHEADArray_1::_IDL_SEQ_SENDAHEADArray_1 (const ::_IDL_SEQ_SENDAHEADArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_SENDAHEADArray_1::_IDL_SEQ_SENDAHEADArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_SENDAHEADArray_1::~_IDL_SEQ_SENDAHEADArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_SENDAHEADArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_SENDAHEADArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_SENDAHEADArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_SENDAHEADArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_SENDAHEADArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_SENDAHEADArray_1& _IDL_SEQ_SENDAHEADArray_1::operator= (const ::_IDL_SEQ_SENDAHEADArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_SENDAHEADArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_SENDAHEADArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_SENDAHEADArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_SENDAHEADArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_SENDAHEADArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_SENDAHEADArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_SENDAHEADArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_SENDAHEADArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_SENDAHEADArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_SENDAHEADArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_SENDAHEADArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_SENDAHEADArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_SENDAHEADArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_SENDAHEADArray_1_var::_IDL_SEQ_SENDAHEADArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_SENDAHEADArray_1_var::_IDL_SEQ_SENDAHEADArray_1_var (::_IDL_SEQ_SENDAHEADArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_SENDAHEADArray_1_var::_IDL_SEQ_SENDAHEADArray_1_var (const ::_IDL_SEQ_SENDAHEADArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_SENDAHEADArray_1 (*(_s._ptr));
    }

_IDL_SEQ_SENDAHEADArray_1_var& _IDL_SEQ_SENDAHEADArray_1_var::operator= (::_IDL_SEQ_SENDAHEADArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_SENDAHEADArray_1_var& _IDL_SEQ_SENDAHEADArray_1_var::operator= (const ::_IDL_SEQ_SENDAHEADArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_SENDAHEADArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_SENDAHEADArray_1_var::~_IDL_SEQ_SENDAHEADArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_SENDAHEADArray_1 * _IDL_SEQ_SENDAHEADArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_SENDAHEADArray_1_var::operator ::_IDL_SEQ_SENDAHEADArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_SENDAHEADArray_1_var::operator ::_IDL_SEQ_SENDAHEADArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_SENDAHEADArray_1_var::operator _IDL_SEQ_SENDAHEADArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_SENDAHEADArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_SENDAHEADArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_SENDAHEADArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_SENDAHEADArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_SENDAHEADArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_SENDAHEADArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_SENDAHEADArray_1& _IDL_SEQ_SENDAHEADArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_SENDAHEADArray_1& _IDL_SEQ_SENDAHEADArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_SENDAHEADArray_1*& _IDL_SEQ_SENDAHEADArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_SENDAHEADArray_1* _IDL_SEQ_SENDAHEADArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_SENDAHEADArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_SENDAHEADArray_1 > _IDL_SEQ_SENDAHEADArray_1::SENDAHEADArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_SENDAHEADVALUESArray_1::__stubcode_version;
_IDL_SEQ_SENDAHEADVALUESArray_1::_IDL_SEQ_SENDAHEADVALUESArray_1()
{
  _defaultInit();
}
_IDL_SEQ_SENDAHEADVALUESArray_1::_IDL_SEQ_SENDAHEADVALUESArray_1 (const ::_IDL_SEQ_SENDAHEADVALUESArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_SENDAHEADVALUESArray_1::_IDL_SEQ_SENDAHEADVALUESArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_SENDAHEADVALUESArray_1::~_IDL_SEQ_SENDAHEADVALUESArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_SENDAHEADVALUESArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_SENDAHEADVALUESArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_SENDAHEADVALUESArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_SENDAHEADVALUESArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_SENDAHEADVALUESArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_SENDAHEADVALUESArray_1& _IDL_SEQ_SENDAHEADVALUESArray_1::operator= (const ::_IDL_SEQ_SENDAHEADVALUESArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_SENDAHEADVALUESArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_SENDAHEADVALUESArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_SENDAHEADVALUESArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_SENDAHEADVALUESArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_SENDAHEADVALUESArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_SENDAHEADVALUESArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_SENDAHEADVALUESArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_SENDAHEADVALUESArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_SENDAHEADVALUESArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_SENDAHEADVALUESArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_SENDAHEADVALUESArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_SENDAHEADVALUESArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_SENDAHEADVALUESArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_SENDAHEADVALUESArray_1_var::_IDL_SEQ_SENDAHEADVALUESArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_SENDAHEADVALUESArray_1_var::_IDL_SEQ_SENDAHEADVALUESArray_1_var (::_IDL_SEQ_SENDAHEADVALUESArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_SENDAHEADVALUESArray_1_var::_IDL_SEQ_SENDAHEADVALUESArray_1_var (const ::_IDL_SEQ_SENDAHEADVALUESArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_SENDAHEADVALUESArray_1 (*(_s._ptr));
    }

_IDL_SEQ_SENDAHEADVALUESArray_1_var& _IDL_SEQ_SENDAHEADVALUESArray_1_var::operator= (::_IDL_SEQ_SENDAHEADVALUESArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_SENDAHEADVALUESArray_1_var& _IDL_SEQ_SENDAHEADVALUESArray_1_var::operator= (const ::_IDL_SEQ_SENDAHEADVALUESArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_SENDAHEADVALUESArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_SENDAHEADVALUESArray_1_var::~_IDL_SEQ_SENDAHEADVALUESArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_SENDAHEADVALUESArray_1 * _IDL_SEQ_SENDAHEADVALUESArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_SENDAHEADVALUESArray_1_var::operator ::_IDL_SEQ_SENDAHEADVALUESArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_SENDAHEADVALUESArray_1_var::operator ::_IDL_SEQ_SENDAHEADVALUESArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_SENDAHEADVALUESArray_1_var::operator _IDL_SEQ_SENDAHEADVALUESArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_SENDAHEADVALUESArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_SENDAHEADVALUESArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_SENDAHEADVALUESArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_SENDAHEADVALUESArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_SENDAHEADVALUESArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_SENDAHEADVALUESArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_SENDAHEADVALUESArray_1& _IDL_SEQ_SENDAHEADVALUESArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_SENDAHEADVALUESArray_1& _IDL_SEQ_SENDAHEADVALUESArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_SENDAHEADVALUESArray_1*& _IDL_SEQ_SENDAHEADVALUESArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_SENDAHEADVALUESArray_1* _IDL_SEQ_SENDAHEADVALUESArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_SENDAHEADVALUESArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_SENDAHEADVALUESArray_1 > _IDL_SEQ_SENDAHEADVALUESArray_1::SENDAHEADVALUESArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_AVAILABLE_SUBUNITArray_1::__stubcode_version;
_IDL_SEQ_AVAILABLE_SUBUNITArray_1::_IDL_SEQ_AVAILABLE_SUBUNITArray_1()
{
  _defaultInit();
}
_IDL_SEQ_AVAILABLE_SUBUNITArray_1::_IDL_SEQ_AVAILABLE_SUBUNITArray_1 (const ::_IDL_SEQ_AVAILABLE_SUBUNITArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_AVAILABLE_SUBUNITArray_1::_IDL_SEQ_AVAILABLE_SUBUNITArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_AVAILABLE_SUBUNITArray_1::~_IDL_SEQ_AVAILABLE_SUBUNITArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_AVAILABLE_SUBUNITArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_AVAILABLE_SUBUNITArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_AVAILABLE_SUBUNITArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_AVAILABLE_SUBUNITArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_AVAILABLE_SUBUNITArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_AVAILABLE_SUBUNITArray_1& _IDL_SEQ_AVAILABLE_SUBUNITArray_1::operator= (const ::_IDL_SEQ_AVAILABLE_SUBUNITArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_AVAILABLE_SUBUNITArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_AVAILABLE_SUBUNITArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_AVAILABLE_SUBUNITArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_AVAILABLE_SUBUNITArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_AVAILABLE_SUBUNITArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_AVAILABLE_SUBUNITArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_AVAILABLE_SUBUNITArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_AVAILABLE_SUBUNITArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_AVAILABLE_SUBUNITArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_AVAILABLE_SUBUNITArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_AVAILABLE_SUBUNITArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_AVAILABLE_SUBUNITArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_AVAILABLE_SUBUNITArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_AVAILABLE_SUBUNITArray_1_var::_IDL_SEQ_AVAILABLE_SUBUNITArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_AVAILABLE_SUBUNITArray_1_var::_IDL_SEQ_AVAILABLE_SUBUNITArray_1_var (::_IDL_SEQ_AVAILABLE_SUBUNITArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_AVAILABLE_SUBUNITArray_1_var::_IDL_SEQ_AVAILABLE_SUBUNITArray_1_var (const ::_IDL_SEQ_AVAILABLE_SUBUNITArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_AVAILABLE_SUBUNITArray_1 (*(_s._ptr));
    }

_IDL_SEQ_AVAILABLE_SUBUNITArray_1_var& _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var::operator= (::_IDL_SEQ_AVAILABLE_SUBUNITArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_AVAILABLE_SUBUNITArray_1_var& _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var::operator= (const ::_IDL_SEQ_AVAILABLE_SUBUNITArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_AVAILABLE_SUBUNITArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_AVAILABLE_SUBUNITArray_1_var::~_IDL_SEQ_AVAILABLE_SUBUNITArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_AVAILABLE_SUBUNITArray_1 * _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_AVAILABLE_SUBUNITArray_1_var::operator ::_IDL_SEQ_AVAILABLE_SUBUNITArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_AVAILABLE_SUBUNITArray_1_var::operator ::_IDL_SEQ_AVAILABLE_SUBUNITArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_AVAILABLE_SUBUNITArray_1_var::operator _IDL_SEQ_AVAILABLE_SUBUNITArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_AVAILABLE_SUBUNITArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_AVAILABLE_SUBUNITArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_AVAILABLE_SUBUNITArray_1& _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_AVAILABLE_SUBUNITArray_1& _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_AVAILABLE_SUBUNITArray_1*& _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_AVAILABLE_SUBUNITArray_1* _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_AVAILABLE_SUBUNITArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_AVAILABLE_SUBUNITArray_1 > _IDL_SEQ_AVAILABLE_SUBUNITArray_1::AVAILABLE_SUBUNITArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_IS_OPSTART_RECOMDArray_1::__stubcode_version;
_IDL_SEQ_IS_OPSTART_RECOMDArray_1::_IDL_SEQ_IS_OPSTART_RECOMDArray_1()
{
  _defaultInit();
}
_IDL_SEQ_IS_OPSTART_RECOMDArray_1::_IDL_SEQ_IS_OPSTART_RECOMDArray_1 (const ::_IDL_SEQ_IS_OPSTART_RECOMDArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_IS_OPSTART_RECOMDArray_1::_IDL_SEQ_IS_OPSTART_RECOMDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_IS_OPSTART_RECOMDArray_1::~_IDL_SEQ_IS_OPSTART_RECOMDArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_IS_OPSTART_RECOMDArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_IS_OPSTART_RECOMDArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_IS_OPSTART_RECOMDArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_IS_OPSTART_RECOMDArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_IS_OPSTART_RECOMDArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_IS_OPSTART_RECOMDArray_1& _IDL_SEQ_IS_OPSTART_RECOMDArray_1::operator= (const ::_IDL_SEQ_IS_OPSTART_RECOMDArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_IS_OPSTART_RECOMDArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_IS_OPSTART_RECOMDArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_IS_OPSTART_RECOMDArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_IS_OPSTART_RECOMDArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_IS_OPSTART_RECOMDArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_IS_OPSTART_RECOMDArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_IS_OPSTART_RECOMDArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_IS_OPSTART_RECOMDArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_IS_OPSTART_RECOMDArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_IS_OPSTART_RECOMDArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_IS_OPSTART_RECOMDArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_IS_OPSTART_RECOMDArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_IS_OPSTART_RECOMDArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_IS_OPSTART_RECOMDArray_1_var::_IDL_SEQ_IS_OPSTART_RECOMDArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_IS_OPSTART_RECOMDArray_1_var::_IDL_SEQ_IS_OPSTART_RECOMDArray_1_var (::_IDL_SEQ_IS_OPSTART_RECOMDArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_IS_OPSTART_RECOMDArray_1_var::_IDL_SEQ_IS_OPSTART_RECOMDArray_1_var (const ::_IDL_SEQ_IS_OPSTART_RECOMDArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_IS_OPSTART_RECOMDArray_1 (*(_s._ptr));
    }

_IDL_SEQ_IS_OPSTART_RECOMDArray_1_var& _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var::operator= (::_IDL_SEQ_IS_OPSTART_RECOMDArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_IS_OPSTART_RECOMDArray_1_var& _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var::operator= (const ::_IDL_SEQ_IS_OPSTART_RECOMDArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_IS_OPSTART_RECOMDArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_IS_OPSTART_RECOMDArray_1_var::~_IDL_SEQ_IS_OPSTART_RECOMDArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_IS_OPSTART_RECOMDArray_1 * _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_IS_OPSTART_RECOMDArray_1_var::operator ::_IDL_SEQ_IS_OPSTART_RECOMDArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_IS_OPSTART_RECOMDArray_1_var::operator ::_IDL_SEQ_IS_OPSTART_RECOMDArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_IS_OPSTART_RECOMDArray_1_var::operator _IDL_SEQ_IS_OPSTART_RECOMDArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_IS_OPSTART_RECOMDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_IS_OPSTART_RECOMDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_IS_OPSTART_RECOMDArray_1& _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_IS_OPSTART_RECOMDArray_1& _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_IS_OPSTART_RECOMDArray_1*& _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_IS_OPSTART_RECOMDArray_1* _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_IS_OPSTART_RECOMDArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_IS_OPSTART_RECOMDArray_1 > _IDL_SEQ_IS_OPSTART_RECOMDArray_1::IS_OPSTART_RECOMDArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_BR_PARAMSArray_1::__stubcode_version;
_IDL_SEQ_BR_PARAMSArray_1::_IDL_SEQ_BR_PARAMSArray_1()
{
  _defaultInit();
}
_IDL_SEQ_BR_PARAMSArray_1::_IDL_SEQ_BR_PARAMSArray_1 (const ::_IDL_SEQ_BR_PARAMSArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_BR_PARAMSArray_1::_IDL_SEQ_BR_PARAMSArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_BR_PARAMSArray_1::~_IDL_SEQ_BR_PARAMSArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_BR_PARAMSArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_BR_PARAMSArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_BR_PARAMSArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_BR_PARAMSArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_BR_PARAMSArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_BR_PARAMSArray_1& _IDL_SEQ_BR_PARAMSArray_1::operator= (const ::_IDL_SEQ_BR_PARAMSArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_BR_PARAMSArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_BR_PARAMSArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_BR_PARAMSArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_BR_PARAMSArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_BR_PARAMSArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_BR_PARAMSArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_BR_PARAMSArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_BR_PARAMSArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_BR_PARAMSArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_BR_PARAMSArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_BR_PARAMSArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_BR_PARAMSArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_BR_PARAMSArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_BR_PARAMSArray_1_var::_IDL_SEQ_BR_PARAMSArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_BR_PARAMSArray_1_var::_IDL_SEQ_BR_PARAMSArray_1_var (::_IDL_SEQ_BR_PARAMSArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_BR_PARAMSArray_1_var::_IDL_SEQ_BR_PARAMSArray_1_var (const ::_IDL_SEQ_BR_PARAMSArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_BR_PARAMSArray_1 (*(_s._ptr));
    }

_IDL_SEQ_BR_PARAMSArray_1_var& _IDL_SEQ_BR_PARAMSArray_1_var::operator= (::_IDL_SEQ_BR_PARAMSArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_BR_PARAMSArray_1_var& _IDL_SEQ_BR_PARAMSArray_1_var::operator= (const ::_IDL_SEQ_BR_PARAMSArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_BR_PARAMSArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_BR_PARAMSArray_1_var::~_IDL_SEQ_BR_PARAMSArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_BR_PARAMSArray_1 * _IDL_SEQ_BR_PARAMSArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_BR_PARAMSArray_1_var::operator ::_IDL_SEQ_BR_PARAMSArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_BR_PARAMSArray_1_var::operator ::_IDL_SEQ_BR_PARAMSArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_BR_PARAMSArray_1_var::operator _IDL_SEQ_BR_PARAMSArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_BR_PARAMSArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_BR_PARAMSArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_BR_PARAMSArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_BR_PARAMSArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_BR_PARAMSArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_BR_PARAMSArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_BR_PARAMSArray_1& _IDL_SEQ_BR_PARAMSArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_BR_PARAMSArray_1& _IDL_SEQ_BR_PARAMSArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_BR_PARAMSArray_1*& _IDL_SEQ_BR_PARAMSArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_BR_PARAMSArray_1* _IDL_SEQ_BR_PARAMSArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_BR_PARAMSArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_BR_PARAMSArray_1 > _IDL_SEQ_BR_PARAMSArray_1::BR_PARAMSArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_FEEDFORWARD1Array_1::__stubcode_version;
_IDL_SEQ_FEEDFORWARD1Array_1::_IDL_SEQ_FEEDFORWARD1Array_1()
{
  _defaultInit();
}
_IDL_SEQ_FEEDFORWARD1Array_1::_IDL_SEQ_FEEDFORWARD1Array_1 (const ::_IDL_SEQ_FEEDFORWARD1Array_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_FEEDFORWARD1Array_1::_IDL_SEQ_FEEDFORWARD1Array_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_FEEDFORWARD1Array_1::~_IDL_SEQ_FEEDFORWARD1Array_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_FEEDFORWARD1Array_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_FEEDFORWARD1Array_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_FEEDFORWARD1Array_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_FEEDFORWARD1Array_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_FEEDFORWARD1Array_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_FEEDFORWARD1Array_1& _IDL_SEQ_FEEDFORWARD1Array_1::operator= (const ::_IDL_SEQ_FEEDFORWARD1Array_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_FEEDFORWARD1Array_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_FEEDFORWARD1Array_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_FEEDFORWARD1Array_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_FEEDFORWARD1Array_1::length () const
{
  return _length;
}
void _IDL_SEQ_FEEDFORWARD1Array_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD1Array_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD1Array_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_FEEDFORWARD1Array_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_FEEDFORWARD1Array_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_FEEDFORWARD1Array_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_FEEDFORWARD1Array_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_FEEDFORWARD1Array_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_FEEDFORWARD1Array_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_FEEDFORWARD1Array_1_var::_IDL_SEQ_FEEDFORWARD1Array_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_FEEDFORWARD1Array_1_var::_IDL_SEQ_FEEDFORWARD1Array_1_var (::_IDL_SEQ_FEEDFORWARD1Array_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_FEEDFORWARD1Array_1_var::_IDL_SEQ_FEEDFORWARD1Array_1_var (const ::_IDL_SEQ_FEEDFORWARD1Array_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_FEEDFORWARD1Array_1 (*(_s._ptr));
    }

_IDL_SEQ_FEEDFORWARD1Array_1_var& _IDL_SEQ_FEEDFORWARD1Array_1_var::operator= (::_IDL_SEQ_FEEDFORWARD1Array_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_FEEDFORWARD1Array_1_var& _IDL_SEQ_FEEDFORWARD1Array_1_var::operator= (const ::_IDL_SEQ_FEEDFORWARD1Array_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_FEEDFORWARD1Array_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_FEEDFORWARD1Array_1_var::~_IDL_SEQ_FEEDFORWARD1Array_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_FEEDFORWARD1Array_1 * _IDL_SEQ_FEEDFORWARD1Array_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_FEEDFORWARD1Array_1_var::operator ::_IDL_SEQ_FEEDFORWARD1Array_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_FEEDFORWARD1Array_1_var::operator ::_IDL_SEQ_FEEDFORWARD1Array_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_FEEDFORWARD1Array_1_var::operator _IDL_SEQ_FEEDFORWARD1Array_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD1Array_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_FEEDFORWARD1Array_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD1Array_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD1Array_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_FEEDFORWARD1Array_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD1Array_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_FEEDFORWARD1Array_1& _IDL_SEQ_FEEDFORWARD1Array_1_var::in () const { return *_ptr; }
::_IDL_SEQ_FEEDFORWARD1Array_1& _IDL_SEQ_FEEDFORWARD1Array_1_var::inout () { return *_ptr; }
::_IDL_SEQ_FEEDFORWARD1Array_1*& _IDL_SEQ_FEEDFORWARD1Array_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_FEEDFORWARD1Array_1* _IDL_SEQ_FEEDFORWARD1Array_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_FEEDFORWARD1Array_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_FEEDFORWARD1Array_1 > _IDL_SEQ_FEEDFORWARD1Array_1::FEEDFORWARD1Array_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_FEEDFORWARD2Array_1::__stubcode_version;
_IDL_SEQ_FEEDFORWARD2Array_1::_IDL_SEQ_FEEDFORWARD2Array_1()
{
  _defaultInit();
}
_IDL_SEQ_FEEDFORWARD2Array_1::_IDL_SEQ_FEEDFORWARD2Array_1 (const ::_IDL_SEQ_FEEDFORWARD2Array_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_FEEDFORWARD2Array_1::_IDL_SEQ_FEEDFORWARD2Array_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_FEEDFORWARD2Array_1::~_IDL_SEQ_FEEDFORWARD2Array_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_FEEDFORWARD2Array_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_FEEDFORWARD2Array_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_FEEDFORWARD2Array_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_FEEDFORWARD2Array_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_FEEDFORWARD2Array_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_FEEDFORWARD2Array_1& _IDL_SEQ_FEEDFORWARD2Array_1::operator= (const ::_IDL_SEQ_FEEDFORWARD2Array_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_FEEDFORWARD2Array_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_FEEDFORWARD2Array_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_FEEDFORWARD2Array_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_FEEDFORWARD2Array_1::length () const
{
  return _length;
}
void _IDL_SEQ_FEEDFORWARD2Array_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD2Array_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD2Array_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_FEEDFORWARD2Array_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_FEEDFORWARD2Array_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_FEEDFORWARD2Array_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_FEEDFORWARD2Array_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_FEEDFORWARD2Array_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_FEEDFORWARD2Array_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_FEEDFORWARD2Array_1_var::_IDL_SEQ_FEEDFORWARD2Array_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_FEEDFORWARD2Array_1_var::_IDL_SEQ_FEEDFORWARD2Array_1_var (::_IDL_SEQ_FEEDFORWARD2Array_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_FEEDFORWARD2Array_1_var::_IDL_SEQ_FEEDFORWARD2Array_1_var (const ::_IDL_SEQ_FEEDFORWARD2Array_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_FEEDFORWARD2Array_1 (*(_s._ptr));
    }

_IDL_SEQ_FEEDFORWARD2Array_1_var& _IDL_SEQ_FEEDFORWARD2Array_1_var::operator= (::_IDL_SEQ_FEEDFORWARD2Array_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_FEEDFORWARD2Array_1_var& _IDL_SEQ_FEEDFORWARD2Array_1_var::operator= (const ::_IDL_SEQ_FEEDFORWARD2Array_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_FEEDFORWARD2Array_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_FEEDFORWARD2Array_1_var::~_IDL_SEQ_FEEDFORWARD2Array_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_FEEDFORWARD2Array_1 * _IDL_SEQ_FEEDFORWARD2Array_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_FEEDFORWARD2Array_1_var::operator ::_IDL_SEQ_FEEDFORWARD2Array_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_FEEDFORWARD2Array_1_var::operator ::_IDL_SEQ_FEEDFORWARD2Array_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_FEEDFORWARD2Array_1_var::operator _IDL_SEQ_FEEDFORWARD2Array_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD2Array_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_FEEDFORWARD2Array_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD2Array_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD2Array_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_FEEDFORWARD2Array_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD2Array_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_FEEDFORWARD2Array_1& _IDL_SEQ_FEEDFORWARD2Array_1_var::in () const { return *_ptr; }
::_IDL_SEQ_FEEDFORWARD2Array_1& _IDL_SEQ_FEEDFORWARD2Array_1_var::inout () { return *_ptr; }
::_IDL_SEQ_FEEDFORWARD2Array_1*& _IDL_SEQ_FEEDFORWARD2Array_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_FEEDFORWARD2Array_1* _IDL_SEQ_FEEDFORWARD2Array_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_FEEDFORWARD2Array_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_FEEDFORWARD2Array_1 > _IDL_SEQ_FEEDFORWARD2Array_1::FEEDFORWARD2Array_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_FEEDFORWARD3Array_1::__stubcode_version;
_IDL_SEQ_FEEDFORWARD3Array_1::_IDL_SEQ_FEEDFORWARD3Array_1()
{
  _defaultInit();
}
_IDL_SEQ_FEEDFORWARD3Array_1::_IDL_SEQ_FEEDFORWARD3Array_1 (const ::_IDL_SEQ_FEEDFORWARD3Array_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_FEEDFORWARD3Array_1::_IDL_SEQ_FEEDFORWARD3Array_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_FEEDFORWARD3Array_1::~_IDL_SEQ_FEEDFORWARD3Array_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_FEEDFORWARD3Array_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_FEEDFORWARD3Array_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_FEEDFORWARD3Array_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_FEEDFORWARD3Array_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_FEEDFORWARD3Array_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_FEEDFORWARD3Array_1& _IDL_SEQ_FEEDFORWARD3Array_1::operator= (const ::_IDL_SEQ_FEEDFORWARD3Array_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_FEEDFORWARD3Array_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_FEEDFORWARD3Array_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_FEEDFORWARD3Array_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_FEEDFORWARD3Array_1::length () const
{
  return _length;
}
void _IDL_SEQ_FEEDFORWARD3Array_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD3Array_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD3Array_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_FEEDFORWARD3Array_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_FEEDFORWARD3Array_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_FEEDFORWARD3Array_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_FEEDFORWARD3Array_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_FEEDFORWARD3Array_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_FEEDFORWARD3Array_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_FEEDFORWARD3Array_1_var::_IDL_SEQ_FEEDFORWARD3Array_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_FEEDFORWARD3Array_1_var::_IDL_SEQ_FEEDFORWARD3Array_1_var (::_IDL_SEQ_FEEDFORWARD3Array_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_FEEDFORWARD3Array_1_var::_IDL_SEQ_FEEDFORWARD3Array_1_var (const ::_IDL_SEQ_FEEDFORWARD3Array_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_FEEDFORWARD3Array_1 (*(_s._ptr));
    }

_IDL_SEQ_FEEDFORWARD3Array_1_var& _IDL_SEQ_FEEDFORWARD3Array_1_var::operator= (::_IDL_SEQ_FEEDFORWARD3Array_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_FEEDFORWARD3Array_1_var& _IDL_SEQ_FEEDFORWARD3Array_1_var::operator= (const ::_IDL_SEQ_FEEDFORWARD3Array_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_FEEDFORWARD3Array_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_FEEDFORWARD3Array_1_var::~_IDL_SEQ_FEEDFORWARD3Array_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_FEEDFORWARD3Array_1 * _IDL_SEQ_FEEDFORWARD3Array_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_FEEDFORWARD3Array_1_var::operator ::_IDL_SEQ_FEEDFORWARD3Array_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_FEEDFORWARD3Array_1_var::operator ::_IDL_SEQ_FEEDFORWARD3Array_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_FEEDFORWARD3Array_1_var::operator _IDL_SEQ_FEEDFORWARD3Array_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD3Array_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_FEEDFORWARD3Array_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD3Array_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD3Array_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_FEEDFORWARD3Array_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD3Array_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_FEEDFORWARD3Array_1& _IDL_SEQ_FEEDFORWARD3Array_1_var::in () const { return *_ptr; }
::_IDL_SEQ_FEEDFORWARD3Array_1& _IDL_SEQ_FEEDFORWARD3Array_1_var::inout () { return *_ptr; }
::_IDL_SEQ_FEEDFORWARD3Array_1*& _IDL_SEQ_FEEDFORWARD3Array_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_FEEDFORWARD3Array_1* _IDL_SEQ_FEEDFORWARD3Array_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_FEEDFORWARD3Array_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_FEEDFORWARD3Array_1 > _IDL_SEQ_FEEDFORWARD3Array_1::FEEDFORWARD3Array_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_FEEDFORWARD4Array_1::__stubcode_version;
_IDL_SEQ_FEEDFORWARD4Array_1::_IDL_SEQ_FEEDFORWARD4Array_1()
{
  _defaultInit();
}
_IDL_SEQ_FEEDFORWARD4Array_1::_IDL_SEQ_FEEDFORWARD4Array_1 (const ::_IDL_SEQ_FEEDFORWARD4Array_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_FEEDFORWARD4Array_1::_IDL_SEQ_FEEDFORWARD4Array_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_FEEDFORWARD4Array_1::~_IDL_SEQ_FEEDFORWARD4Array_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_FEEDFORWARD4Array_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_FEEDFORWARD4Array_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_FEEDFORWARD4Array_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_FEEDFORWARD4Array_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_FEEDFORWARD4Array_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_FEEDFORWARD4Array_1& _IDL_SEQ_FEEDFORWARD4Array_1::operator= (const ::_IDL_SEQ_FEEDFORWARD4Array_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_FEEDFORWARD4Array_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_FEEDFORWARD4Array_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_FEEDFORWARD4Array_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_FEEDFORWARD4Array_1::length () const
{
  return _length;
}
void _IDL_SEQ_FEEDFORWARD4Array_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD4Array_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD4Array_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_FEEDFORWARD4Array_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_FEEDFORWARD4Array_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_FEEDFORWARD4Array_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_FEEDFORWARD4Array_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_FEEDFORWARD4Array_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_FEEDFORWARD4Array_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_FEEDFORWARD4Array_1_var::_IDL_SEQ_FEEDFORWARD4Array_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_FEEDFORWARD4Array_1_var::_IDL_SEQ_FEEDFORWARD4Array_1_var (::_IDL_SEQ_FEEDFORWARD4Array_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_FEEDFORWARD4Array_1_var::_IDL_SEQ_FEEDFORWARD4Array_1_var (const ::_IDL_SEQ_FEEDFORWARD4Array_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_FEEDFORWARD4Array_1 (*(_s._ptr));
    }

_IDL_SEQ_FEEDFORWARD4Array_1_var& _IDL_SEQ_FEEDFORWARD4Array_1_var::operator= (::_IDL_SEQ_FEEDFORWARD4Array_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_FEEDFORWARD4Array_1_var& _IDL_SEQ_FEEDFORWARD4Array_1_var::operator= (const ::_IDL_SEQ_FEEDFORWARD4Array_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_FEEDFORWARD4Array_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_FEEDFORWARD4Array_1_var::~_IDL_SEQ_FEEDFORWARD4Array_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_FEEDFORWARD4Array_1 * _IDL_SEQ_FEEDFORWARD4Array_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_FEEDFORWARD4Array_1_var::operator ::_IDL_SEQ_FEEDFORWARD4Array_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_FEEDFORWARD4Array_1_var::operator ::_IDL_SEQ_FEEDFORWARD4Array_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_FEEDFORWARD4Array_1_var::operator _IDL_SEQ_FEEDFORWARD4Array_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD4Array_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_FEEDFORWARD4Array_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD4Array_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD4Array_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_FEEDFORWARD4Array_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_FEEDFORWARD4Array_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_FEEDFORWARD4Array_1& _IDL_SEQ_FEEDFORWARD4Array_1_var::in () const { return *_ptr; }
::_IDL_SEQ_FEEDFORWARD4Array_1& _IDL_SEQ_FEEDFORWARD4Array_1_var::inout () { return *_ptr; }
::_IDL_SEQ_FEEDFORWARD4Array_1*& _IDL_SEQ_FEEDFORWARD4Array_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_FEEDFORWARD4Array_1* _IDL_SEQ_FEEDFORWARD4Array_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_FEEDFORWARD4Array_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_FEEDFORWARD4Array_1 > _IDL_SEQ_FEEDFORWARD4Array_1::FEEDFORWARD4Array_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_NAMEArray_1::__stubcode_version;
_IDL_SEQ_NAMEArray_1::_IDL_SEQ_NAMEArray_1()
{
  _defaultInit();
}
_IDL_SEQ_NAMEArray_1::_IDL_SEQ_NAMEArray_1 (const ::_IDL_SEQ_NAMEArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_NAMEArray_1::_IDL_SEQ_NAMEArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_NAMEArray_1::~_IDL_SEQ_NAMEArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_NAMEArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_NAMEArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_NAMEArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_NAMEArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_NAMEArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_NAMEArray_1& _IDL_SEQ_NAMEArray_1::operator= (const ::_IDL_SEQ_NAMEArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_NAMEArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_NAMEArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_NAMEArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_NAMEArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_NAMEArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_NAMEArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_NAMEArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_NAMEArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_NAMEArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_NAMEArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_NAMEArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_NAMEArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_NAMEArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_NAMEArray_1_var::_IDL_SEQ_NAMEArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_NAMEArray_1_var::_IDL_SEQ_NAMEArray_1_var (::_IDL_SEQ_NAMEArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_NAMEArray_1_var::_IDL_SEQ_NAMEArray_1_var (const ::_IDL_SEQ_NAMEArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_NAMEArray_1 (*(_s._ptr));
    }

_IDL_SEQ_NAMEArray_1_var& _IDL_SEQ_NAMEArray_1_var::operator= (::_IDL_SEQ_NAMEArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_NAMEArray_1_var& _IDL_SEQ_NAMEArray_1_var::operator= (const ::_IDL_SEQ_NAMEArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_NAMEArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_NAMEArray_1_var::~_IDL_SEQ_NAMEArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_NAMEArray_1 * _IDL_SEQ_NAMEArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_NAMEArray_1_var::operator ::_IDL_SEQ_NAMEArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_NAMEArray_1_var::operator ::_IDL_SEQ_NAMEArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_NAMEArray_1_var::operator _IDL_SEQ_NAMEArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_NAMEArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_NAMEArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_NAMEArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_NAMEArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_NAMEArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_NAMEArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_NAMEArray_1& _IDL_SEQ_NAMEArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_NAMEArray_1& _IDL_SEQ_NAMEArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_NAMEArray_1*& _IDL_SEQ_NAMEArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_NAMEArray_1* _IDL_SEQ_NAMEArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_NAMEArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_NAMEArray_1 > _IDL_SEQ_NAMEArray_1::NAMEArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_VALUEArray_1::__stubcode_version;
_IDL_SEQ_VALUEArray_1::_IDL_SEQ_VALUEArray_1()
{
  _defaultInit();
}
_IDL_SEQ_VALUEArray_1::_IDL_SEQ_VALUEArray_1 (const ::_IDL_SEQ_VALUEArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_VALUEArray_1::_IDL_SEQ_VALUEArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_VALUEArray_1::~_IDL_SEQ_VALUEArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_VALUEArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_VALUEArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_VALUEArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_VALUEArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_VALUEArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_VALUEArray_1& _IDL_SEQ_VALUEArray_1::operator= (const ::_IDL_SEQ_VALUEArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_VALUEArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_VALUEArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_VALUEArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_VALUEArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_VALUEArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_VALUEArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_VALUEArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_VALUEArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_VALUEArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_VALUEArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_VALUEArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_VALUEArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_VALUEArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_VALUEArray_1_var::_IDL_SEQ_VALUEArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_VALUEArray_1_var::_IDL_SEQ_VALUEArray_1_var (::_IDL_SEQ_VALUEArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_VALUEArray_1_var::_IDL_SEQ_VALUEArray_1_var (const ::_IDL_SEQ_VALUEArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_VALUEArray_1 (*(_s._ptr));
    }

_IDL_SEQ_VALUEArray_1_var& _IDL_SEQ_VALUEArray_1_var::operator= (::_IDL_SEQ_VALUEArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_VALUEArray_1_var& _IDL_SEQ_VALUEArray_1_var::operator= (const ::_IDL_SEQ_VALUEArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_VALUEArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_VALUEArray_1_var::~_IDL_SEQ_VALUEArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_VALUEArray_1 * _IDL_SEQ_VALUEArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_VALUEArray_1_var::operator ::_IDL_SEQ_VALUEArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_VALUEArray_1_var::operator ::_IDL_SEQ_VALUEArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_VALUEArray_1_var::operator _IDL_SEQ_VALUEArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_VALUEArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_VALUEArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_VALUEArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_VALUEArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_VALUEArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_VALUEArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_VALUEArray_1& _IDL_SEQ_VALUEArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_VALUEArray_1& _IDL_SEQ_VALUEArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_VALUEArray_1*& _IDL_SEQ_VALUEArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_VALUEArray_1* _IDL_SEQ_VALUEArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_VALUEArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_VALUEArray_1 > _IDL_SEQ_VALUEArray_1::VALUEArray_1_Info;

void ITEM_VALUE::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("NAME");
    NAME.encodeOp(_req);
    _req.setVarName("VALUE");
    VALUE.encodeOp(_req);
    _req.encodeEndStructure();
}

void ITEM_VALUE::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("NAME");
    NAME.decodeOp(_req);
    _req.setVarName("VALUE");
    VALUE.decodeOp(_req);
    _req.decodeEndStructure();
}

void ITEM_VALUE::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("NAME");
    NAME.decodeInOutOp(_req);
    _req.setVarName("VALUE");
    VALUE.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 ITEM_VALUE::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 ITEM_VALUE::__stubcode_dependents[] = {::VALUEArray::__stubcode_version,::NAMEArray::__stubcode_version};
ITEM_VALUE::ITEM_VALUE()
{
}
ITEM_VALUE::ITEM_VALUE( const ::ITEM_VALUE &EB_s )
{
    operator=( EB_s );
}
ITEM_VALUE& ITEM_VALUE::operator=( const ::ITEM_VALUE &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   NAME = EB_s.NAME;
   VALUE = EB_s.VALUE;
   return *this;
}
ITEM_VALUE_var::ITEM_VALUE_var () {
   _ptr = 0;
}
ITEM_VALUE_var::ITEM_VALUE_var (::ITEM_VALUE*_p) {
   _ptr = _p;
}
ITEM_VALUE_var::ITEM_VALUE_var (const ::ITEM_VALUE_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::ITEM_VALUE ();
   *(_ptr) = *(_s._ptr);
}
ITEM_VALUE_var& ITEM_VALUE_var::operator= (::ITEM_VALUE *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

ITEM_VALUE_var& ITEM_VALUE_var::operator= (const ::ITEM_VALUE_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::ITEM_VALUE ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

ITEM_VALUE_var::~ITEM_VALUE_var () {
   delete _ptr;
}

::ITEM_VALUE * ITEM_VALUE_var::operator-> ()
{ return _ptr; }

ITEM_VALUE_var::operator ::ITEM_VALUE_cvPtr () const 
{ return _ptr;}

ITEM_VALUE_var::operator ::ITEM_VALUE_vPtr& () 
{ return _ptr;}

ITEM_VALUE_var::operator const ::ITEM_VALUE& () const 
{ return *_ptr;}

ITEM_VALUE_var::operator ::ITEM_VALUE& () 
{ return *_ptr;}

const ::ITEM_VALUE& ITEM_VALUE_var::in () const { return *_ptr; }
::ITEM_VALUE& ITEM_VALUE_var::inout () { return *_ptr; }
::ITEM_VALUE*& ITEM_VALUE_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::ITEM_VALUE* ITEM_VALUE_var::_retn () {
  // yield ownership 
  ITEM_VALUE* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::ITEM_VALUE > ITEM_VALUE::ITEM_VALUE_Info;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_ArrayOfITEM_VALUE_0::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_ArrayOfITEM_VALUE_0::__stubcode_dependents[] = {::ITEM_VALUE::__stubcode_version };
_IDL_SEQ_ArrayOfITEM_VALUE_0::_IDL_SEQ_ArrayOfITEM_VALUE_0()
{
  _defaultInit();
}
_IDL_SEQ_ArrayOfITEM_VALUE_0::_IDL_SEQ_ArrayOfITEM_VALUE_0 (const ::_IDL_SEQ_ArrayOfITEM_VALUE_0& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_ArrayOfITEM_VALUE_0::_IDL_SEQ_ArrayOfITEM_VALUE_0 (::CORBA::ULong max, ::CORBA::ULong length, ::ITEM_VALUE* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
  _maximum = max;
}
_IDL_SEQ_ArrayOfITEM_VALUE_0::_IDL_SEQ_ArrayOfITEM_VALUE_0 (::CORBA::ULong max)
{
  _defaultInit();
  _maximum = max;
  if (_maximum > 0)
    _buffer = allocbuf_throw (max);
}
_IDL_SEQ_ArrayOfITEM_VALUE_0::~_IDL_SEQ_ArrayOfITEM_VALUE_0 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_ArrayOfITEM_VALUE_0::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer  = NULL;
  _maximum = 0;
}
::ITEM_VALUE* _IDL_SEQ_ArrayOfITEM_VALUE_0::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  // Allocate an array of the element type (which may be a
  // self managed StructElem)
#ifdef SIVIEW_EBROKER
  ::ITEM_VALUE* _ret;
  ::CORBA::ULong alloc_len = sizeof(::ITEM_VALUE) * nelems + sizeof(::CORBA::ULong);
  ::CORBA::ULong * tmp = (::CORBA::ULong *)malloc( alloc_len );
  if( tmp )
  {
    memset( tmp, 0, alloc_len );
    *tmp = nelems;
    tmp++;
    _ret = (::ITEM_VALUE*)tmp;
    for( CORBA::ULong _index = 0; _index < nelems; _index++ )
    {
      (void)new ((void*)( _ret + _index)) ::ITEM_VALUE;
    }
  }
  return _ret;
#else
  return (::ITEM_VALUE*) new ::ITEM_VALUE[nelems];
#endif
}
::ITEM_VALUE* _IDL_SEQ_ArrayOfITEM_VALUE_0::allocbuf_throw (::CORBA::ULong nelems)
{
  ::ITEM_VALUE* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_ArrayOfITEM_VALUE_0::freebuf (::ITEM_VALUE* _data)
{
#ifdef SIVIEW_EBROKER
  if (_data)
  {
    ::CORBA::ULong * tmp = (CORBA::ULong *)_data;
    tmp--;
    for( CORBA::ULong _index = *tmp; _index; _index-- )
    {
    #ifdef _WIN32
      _data[ _index - 1 ].~ITEM_VALUE ();
    #else
      _data[ _index - 1 ].::ITEM_VALUE::~ITEM_VALUE ();
    #endif
    }
    free(tmp);
  }
#else
  if (_data)
    delete [] (::ITEM_VALUE*) _data;
#endif
}
void _IDL_SEQ_ArrayOfITEM_VALUE_0::replace (::CORBA::ULong max,  ::CORBA::ULong length, ::ITEM_VALUE* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
  _maximum = max;
}
::_IDL_SEQ_ArrayOfITEM_VALUE_0& _IDL_SEQ_ArrayOfITEM_VALUE_0::operator= (const ::_IDL_SEQ_ArrayOfITEM_VALUE_0& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  _maximum = max;
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_ArrayOfITEM_VALUE_0::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::ITEM_VALUE* data)
{
  return; // simple elements don't require resetting.
}
void _IDL_SEQ_ArrayOfITEM_VALUE_0::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::ITEM_VALUE* src, ::ITEM_VALUE* tgt)
{
  // Copy elements 
  ::ITEM_VALUE* _src = (::ITEM_VALUE*) src;
  ::ITEM_VALUE* _tgt = (::ITEM_VALUE*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_ArrayOfITEM_VALUE_0::maximum () const
{
  return   _maximum;
;
}
::CORBA::ULong _IDL_SEQ_ArrayOfITEM_VALUE_0::length () const
{
  return _length;
}
void _IDL_SEQ_ArrayOfITEM_VALUE_0::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  ::ITEM_VALUE* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace(max, len, newBuffer, 1);
  return;
}
::ITEM_VALUE& _IDL_SEQ_ArrayOfITEM_VALUE_0::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return _buffer[i];
}
const ::ITEM_VALUE& _IDL_SEQ_ArrayOfITEM_VALUE_0::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return ((const ::ITEM_VALUE*)_buffer) [i];
}
::CORBA::Boolean _IDL_SEQ_ArrayOfITEM_VALUE_0::release() const 
{ return _release; }
::ITEM_VALUE* _IDL_SEQ_ArrayOfITEM_VALUE_0::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::ITEM_VALUE* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::ITEM_VALUE* _IDL_SEQ_ArrayOfITEM_VALUE_0::get_buffer () const
{
    return (const ::ITEM_VALUE*) _buffer;
}
void _IDL_SEQ_ArrayOfITEM_VALUE_0::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       ::ITEM_VALUE const* _elem =     (::ITEM_VALUE*) _buffer;
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
           _elem->encodeOp(_req);
       }
    }
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_ArrayOfITEM_VALUE_0::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
      ::ITEM_VALUE* _elem = (::ITEM_VALUE*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_ArrayOfITEM_VALUE_0::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(max,__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
      ::ITEM_VALUE* _elem = (::ITEM_VALUE*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeInOutOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_ArrayOfITEM_VALUE_0_var::_IDL_SEQ_ArrayOfITEM_VALUE_0_var () {
   _ptr = 0;
    }

_IDL_SEQ_ArrayOfITEM_VALUE_0_var::_IDL_SEQ_ArrayOfITEM_VALUE_0_var (::_IDL_SEQ_ArrayOfITEM_VALUE_0 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_ArrayOfITEM_VALUE_0_var::_IDL_SEQ_ArrayOfITEM_VALUE_0_var (const ::_IDL_SEQ_ArrayOfITEM_VALUE_0_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_ArrayOfITEM_VALUE_0 (*(_s._ptr));
    }

_IDL_SEQ_ArrayOfITEM_VALUE_0_var& _IDL_SEQ_ArrayOfITEM_VALUE_0_var::operator= (::_IDL_SEQ_ArrayOfITEM_VALUE_0 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_ArrayOfITEM_VALUE_0_var& _IDL_SEQ_ArrayOfITEM_VALUE_0_var::operator= (const ::_IDL_SEQ_ArrayOfITEM_VALUE_0_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_ArrayOfITEM_VALUE_0 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_ArrayOfITEM_VALUE_0_var::~_IDL_SEQ_ArrayOfITEM_VALUE_0_var()
{
   delete _ptr;
}
::_IDL_SEQ_ArrayOfITEM_VALUE_0 * _IDL_SEQ_ArrayOfITEM_VALUE_0_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_ArrayOfITEM_VALUE_0_var::operator ::_IDL_SEQ_ArrayOfITEM_VALUE_0_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_ArrayOfITEM_VALUE_0_var::operator ::_IDL_SEQ_ArrayOfITEM_VALUE_0_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_ArrayOfITEM_VALUE_0_var::operator _IDL_SEQ_ArrayOfITEM_VALUE_0() const
{
   return *_ptr;
}
const ::ITEM_VALUE& _IDL_SEQ_ArrayOfITEM_VALUE_0_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_ArrayOfITEM_VALUE_0 *)_ptr)[index];
}
::ITEM_VALUE& _IDL_SEQ_ArrayOfITEM_VALUE_0_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::ITEM_VALUE& _IDL_SEQ_ArrayOfITEM_VALUE_0_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_ArrayOfITEM_VALUE_0 *)_ptr)[index];
}
::ITEM_VALUE& _IDL_SEQ_ArrayOfITEM_VALUE_0_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_ArrayOfITEM_VALUE_0& _IDL_SEQ_ArrayOfITEM_VALUE_0_var::in () const { return *_ptr; }
::_IDL_SEQ_ArrayOfITEM_VALUE_0& _IDL_SEQ_ArrayOfITEM_VALUE_0_var::inout () { return *_ptr; }
::_IDL_SEQ_ArrayOfITEM_VALUE_0*& _IDL_SEQ_ArrayOfITEM_VALUE_0_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_ArrayOfITEM_VALUE_0* _IDL_SEQ_ArrayOfITEM_VALUE_0_var::_retn () {
  // yield ownership 
  _IDL_SEQ_ArrayOfITEM_VALUE_0* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_ArrayOfITEM_VALUE_0 > _IDL_SEQ_ArrayOfITEM_VALUE_0::ArrayOfITEM_VALUE_0_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_LD_EXTENDArray_1::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_LD_EXTENDArray_1::__stubcode_dependents[] = {::ArrayOfITEM_VALUE::__stubcode_version };
_IDL_SEQ_LD_EXTENDArray_1::_IDL_SEQ_LD_EXTENDArray_1()
{
  _defaultInit();
}
_IDL_SEQ_LD_EXTENDArray_1::_IDL_SEQ_LD_EXTENDArray_1 (const ::_IDL_SEQ_LD_EXTENDArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_LD_EXTENDArray_1::_IDL_SEQ_LD_EXTENDArray_1 (::CORBA::ULong length, ::ArrayOfITEM_VALUE* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_LD_EXTENDArray_1::~_IDL_SEQ_LD_EXTENDArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_LD_EXTENDArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::ArrayOfITEM_VALUE* _IDL_SEQ_LD_EXTENDArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::ArrayOfITEM_VALUE*) new ::ArrayOfITEM_VALUE[nelems];
}
::ArrayOfITEM_VALUE* _IDL_SEQ_LD_EXTENDArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::ArrayOfITEM_VALUE* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_LD_EXTENDArray_1::freebuf (::ArrayOfITEM_VALUE* _data)
{
  if (_data)
    delete [] (::ArrayOfITEM_VALUE*) _data;
}
void _IDL_SEQ_LD_EXTENDArray_1::replace ( ::CORBA::ULong length, ::ArrayOfITEM_VALUE* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_LD_EXTENDArray_1& _IDL_SEQ_LD_EXTENDArray_1::operator= (const ::_IDL_SEQ_LD_EXTENDArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_LD_EXTENDArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::ArrayOfITEM_VALUE* data)
{
  return; // simple elements don't require resetting.
}
void _IDL_SEQ_LD_EXTENDArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::ArrayOfITEM_VALUE* src, ::ArrayOfITEM_VALUE* tgt)
{
  // Copy elements 
  ::ArrayOfITEM_VALUE* _src = (::ArrayOfITEM_VALUE*) src;
  ::ArrayOfITEM_VALUE* _tgt = (::ArrayOfITEM_VALUE*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_LD_EXTENDArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_LD_EXTENDArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_LD_EXTENDArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::ArrayOfITEM_VALUE* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::ArrayOfITEM_VALUE& _IDL_SEQ_LD_EXTENDArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return _buffer[i];
}
const ::ArrayOfITEM_VALUE& _IDL_SEQ_LD_EXTENDArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return ((const ::ArrayOfITEM_VALUE*)_buffer) [i];
}
::CORBA::Boolean _IDL_SEQ_LD_EXTENDArray_1::release() const 
{ return _release; }
::ArrayOfITEM_VALUE* _IDL_SEQ_LD_EXTENDArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::ArrayOfITEM_VALUE* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::ArrayOfITEM_VALUE* _IDL_SEQ_LD_EXTENDArray_1::get_buffer () const
{
    return (const ::ArrayOfITEM_VALUE*) _buffer;
}
void _IDL_SEQ_LD_EXTENDArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       ::_IDL_SEQ_ArrayOfITEM_VALUE_0 const* _elem =     (::_IDL_SEQ_ArrayOfITEM_VALUE_0*) _buffer;
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
           _elem->encodeOp(_req);
       }
    }
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_LD_EXTENDArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
      ::_IDL_SEQ_ArrayOfITEM_VALUE_0* _elem = (::_IDL_SEQ_ArrayOfITEM_VALUE_0*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_LD_EXTENDArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
      ::_IDL_SEQ_ArrayOfITEM_VALUE_0* _elem = (::_IDL_SEQ_ArrayOfITEM_VALUE_0*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeInOutOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_LD_EXTENDArray_1_var::_IDL_SEQ_LD_EXTENDArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_LD_EXTENDArray_1_var::_IDL_SEQ_LD_EXTENDArray_1_var (::_IDL_SEQ_LD_EXTENDArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_LD_EXTENDArray_1_var::_IDL_SEQ_LD_EXTENDArray_1_var (const ::_IDL_SEQ_LD_EXTENDArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_LD_EXTENDArray_1 (*(_s._ptr));
    }

_IDL_SEQ_LD_EXTENDArray_1_var& _IDL_SEQ_LD_EXTENDArray_1_var::operator= (::_IDL_SEQ_LD_EXTENDArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_LD_EXTENDArray_1_var& _IDL_SEQ_LD_EXTENDArray_1_var::operator= (const ::_IDL_SEQ_LD_EXTENDArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_LD_EXTENDArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_LD_EXTENDArray_1_var::~_IDL_SEQ_LD_EXTENDArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_LD_EXTENDArray_1 * _IDL_SEQ_LD_EXTENDArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_LD_EXTENDArray_1_var::operator ::_IDL_SEQ_LD_EXTENDArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_LD_EXTENDArray_1_var::operator ::_IDL_SEQ_LD_EXTENDArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_LD_EXTENDArray_1_var::operator _IDL_SEQ_LD_EXTENDArray_1() const
{
   return *_ptr;
}
const ::ArrayOfITEM_VALUE& _IDL_SEQ_LD_EXTENDArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_LD_EXTENDArray_1 *)_ptr)[index];
}
::ArrayOfITEM_VALUE& _IDL_SEQ_LD_EXTENDArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::ArrayOfITEM_VALUE& _IDL_SEQ_LD_EXTENDArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_LD_EXTENDArray_1 *)_ptr)[index];
}
::ArrayOfITEM_VALUE& _IDL_SEQ_LD_EXTENDArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_LD_EXTENDArray_1& _IDL_SEQ_LD_EXTENDArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_LD_EXTENDArray_1& _IDL_SEQ_LD_EXTENDArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_LD_EXTENDArray_1*& _IDL_SEQ_LD_EXTENDArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_LD_EXTENDArray_1* _IDL_SEQ_LD_EXTENDArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_LD_EXTENDArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_LD_EXTENDArray_1 > _IDL_SEQ_LD_EXTENDArray_1::LD_EXTENDArray_1_Info;

void Innotron_Rec_APC_CONTEXT::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("CONTROLJOBTYPE");
    CONTROLJOBTYPE.encodeOp(_req);
    _req.setVarName("TRANSACTIONID");
    TRANSACTIONID.encodeOp(_req);
    _req.setVarName("LOTID");
    LOTID.encodeOp(_req);
    _req.setVarName("LOTTYPE");
    LOTTYPE.encodeOp(_req);
    _req.setVarName("PARTID");
    PARTID.encodeOp(_req);
    _req.setVarName("LAYER");
    LAYER.encodeOp(_req);
    _req.setVarName("ROUTE");
    ROUTE.encodeOp(_req);
    _req.setVarName("ROUTEGROUP");
    ROUTEGROUP.encodeOp(_req);
    _req.setVarName("OPERATION");
    OPERATION.encodeOp(_req);
    _req.setVarName("RETICLEID");
    RETICLEID.encodeOp(_req);
    _req.setVarName("PROCESSEQUIPTYPE");
    PROCESSEQUIPTYPE.encodeOp(_req);
    _req.setVarName("PROCESSEQUIPID");
    PROCESSEQUIPID.encodeOp(_req);
    _req.setVarName("RECOMMENDMODE");
    RECOMMENDMODE.encodeOp(_req);
    _req.setVarName("REWORK");
    REWORK.encodeOp(_req);
    _req.setVarName("PARENTLOTID");
    PARENTLOTID.encodeOp(_req);
    _req.setVarName("PRETOOL");
    PRETOOL.encodeOp(_req);
    _req.setVarName("SENDAHEAD");
    SENDAHEAD.encodeOp(_req);
    _req.setVarName("SENDAHEADVALUES");
    SENDAHEADVALUES.encodeOp(_req);
    _req.setVarName("AVAILABLE_SUBUNIT");
    AVAILABLE_SUBUNIT.encodeOp(_req);
    _req.setVarName("IS_OPSTART_RECOMD");
    IS_OPSTART_RECOMD.encodeOp(_req);
    _req.setVarName("BR_PARAMS");
    BR_PARAMS.encodeOp(_req);
    _req.setVarName("FEEDFORWARD1");
    FEEDFORWARD1.encodeOp(_req);
    _req.setVarName("FEEDFORWARD2");
    FEEDFORWARD2.encodeOp(_req);
    _req.setVarName("FEEDFORWARD3");
    FEEDFORWARD3.encodeOp(_req);
    _req.setVarName("FEEDFORWARD4");
    FEEDFORWARD4.encodeOp(_req);
    _req.setVarName("LD_EXTEND");
    LD_EXTEND.encodeOp(_req);
    _req.encodeEndStructure();
}

void Innotron_Rec_APC_CONTEXT::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("CONTROLJOBTYPE");
    CONTROLJOBTYPE.decodeOp(_req);
    _req.setVarName("TRANSACTIONID");
    TRANSACTIONID.decodeOp(_req);
    _req.setVarName("LOTID");
    LOTID.decodeOp(_req);
    _req.setVarName("LOTTYPE");
    LOTTYPE.decodeOp(_req);
    _req.setVarName("PARTID");
    PARTID.decodeOp(_req);
    _req.setVarName("LAYER");
    LAYER.decodeOp(_req);
    _req.setVarName("ROUTE");
    ROUTE.decodeOp(_req);
    _req.setVarName("ROUTEGROUP");
    ROUTEGROUP.decodeOp(_req);
    _req.setVarName("OPERATION");
    OPERATION.decodeOp(_req);
    _req.setVarName("RETICLEID");
    RETICLEID.decodeOp(_req);
    _req.setVarName("PROCESSEQUIPTYPE");
    PROCESSEQUIPTYPE.decodeOp(_req);
    _req.setVarName("PROCESSEQUIPID");
    PROCESSEQUIPID.decodeOp(_req);
    _req.setVarName("RECOMMENDMODE");
    RECOMMENDMODE.decodeOp(_req);
    _req.setVarName("REWORK");
    REWORK.decodeOp(_req);
    _req.setVarName("PARENTLOTID");
    PARENTLOTID.decodeOp(_req);
    _req.setVarName("PRETOOL");
    PRETOOL.decodeOp(_req);
    _req.setVarName("SENDAHEAD");
    SENDAHEAD.decodeOp(_req);
    _req.setVarName("SENDAHEADVALUES");
    SENDAHEADVALUES.decodeOp(_req);
    _req.setVarName("AVAILABLE_SUBUNIT");
    AVAILABLE_SUBUNIT.decodeOp(_req);
    _req.setVarName("IS_OPSTART_RECOMD");
    IS_OPSTART_RECOMD.decodeOp(_req);
    _req.setVarName("BR_PARAMS");
    BR_PARAMS.decodeOp(_req);
    _req.setVarName("FEEDFORWARD1");
    FEEDFORWARD1.decodeOp(_req);
    _req.setVarName("FEEDFORWARD2");
    FEEDFORWARD2.decodeOp(_req);
    _req.setVarName("FEEDFORWARD3");
    FEEDFORWARD3.decodeOp(_req);
    _req.setVarName("FEEDFORWARD4");
    FEEDFORWARD4.decodeOp(_req);
    _req.setVarName("LD_EXTEND");
    LD_EXTEND.decodeOp(_req);
    _req.decodeEndStructure();
}

void Innotron_Rec_APC_CONTEXT::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("CONTROLJOBTYPE");
    CONTROLJOBTYPE.decodeInOutOp(_req);
    _req.setVarName("TRANSACTIONID");
    TRANSACTIONID.decodeInOutOp(_req);
    _req.setVarName("LOTID");
    LOTID.decodeInOutOp(_req);
    _req.setVarName("LOTTYPE");
    LOTTYPE.decodeInOutOp(_req);
    _req.setVarName("PARTID");
    PARTID.decodeInOutOp(_req);
    _req.setVarName("LAYER");
    LAYER.decodeInOutOp(_req);
    _req.setVarName("ROUTE");
    ROUTE.decodeInOutOp(_req);
    _req.setVarName("ROUTEGROUP");
    ROUTEGROUP.decodeInOutOp(_req);
    _req.setVarName("OPERATION");
    OPERATION.decodeInOutOp(_req);
    _req.setVarName("RETICLEID");
    RETICLEID.decodeInOutOp(_req);
    _req.setVarName("PROCESSEQUIPTYPE");
    PROCESSEQUIPTYPE.decodeInOutOp(_req);
    _req.setVarName("PROCESSEQUIPID");
    PROCESSEQUIPID.decodeInOutOp(_req);
    _req.setVarName("RECOMMENDMODE");
    RECOMMENDMODE.decodeInOutOp(_req);
    _req.setVarName("REWORK");
    REWORK.decodeInOutOp(_req);
    _req.setVarName("PARENTLOTID");
    PARENTLOTID.decodeInOutOp(_req);
    _req.setVarName("PRETOOL");
    PRETOOL.decodeInOutOp(_req);
    _req.setVarName("SENDAHEAD");
    SENDAHEAD.decodeInOutOp(_req);
    _req.setVarName("SENDAHEADVALUES");
    SENDAHEADVALUES.decodeInOutOp(_req);
    _req.setVarName("AVAILABLE_SUBUNIT");
    AVAILABLE_SUBUNIT.decodeInOutOp(_req);
    _req.setVarName("IS_OPSTART_RECOMD");
    IS_OPSTART_RECOMD.decodeInOutOp(_req);
    _req.setVarName("BR_PARAMS");
    BR_PARAMS.decodeInOutOp(_req);
    _req.setVarName("FEEDFORWARD1");
    FEEDFORWARD1.decodeInOutOp(_req);
    _req.setVarName("FEEDFORWARD2");
    FEEDFORWARD2.decodeInOutOp(_req);
    _req.setVarName("FEEDFORWARD3");
    FEEDFORWARD3.decodeInOutOp(_req);
    _req.setVarName("FEEDFORWARD4");
    FEEDFORWARD4.decodeInOutOp(_req);
    _req.setVarName("LD_EXTEND");
    LD_EXTEND.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 Innotron_Rec_APC_CONTEXT::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 Innotron_Rec_APC_CONTEXT::__stubcode_dependents[] = {::SENDAHEADArray::__stubcode_version,::LD_EXTENDArray::__stubcode_version,::PARTIDArray::__stubcode_version,::LAYERArray::__stubcode_version,::BR_PARAMSArray::__stubcode_version,::IS_OPSTART_RECOMDArray::__stubcode_version,::PROCESSEQUIPIDArray::__stubcode_version,::REWORKArray::__stubcode_version,::LOTIDArray::__stubcode_version,::FEEDFORWARD1Array::__stubcode_version,::RECOMMENDMODEArray::__stubcode_version,::SENDAHEADVALUESArray::__stubcode_version,::PARENTLOTIDArray::__stubcode_version,::PROCESSEQUIPTYPEArray::__stubcode_version,::FEEDFORWARD2Array::__stubcode_version,::CONTROLJOBTYPEArray::__stubcode_version,::OPERATIONArray::__stubcode_version,::RETICLEIDArray::__stubcode_version,::AVAILABLE_SUBUNITArray::__stubcode_version,::FEEDFORWARD3Array::__stubcode_version,::ROUTEGROUPArray::__stubcode_version,::ROUTEArray::__stubcode_version,::FEEDFORWARD4Array::__stubcode_version,::TRANSACTIONIDArray::__stubcode_version,::LOTTYPEArray::__stubcode_version,::PRETOOLArray::__stubcode_version};
Innotron_Rec_APC_CONTEXT::Innotron_Rec_APC_CONTEXT()
{
}
Innotron_Rec_APC_CONTEXT::Innotron_Rec_APC_CONTEXT( const ::Innotron_Rec_APC_CONTEXT &EB_s )
{
    operator=( EB_s );
}
Innotron_Rec_APC_CONTEXT& Innotron_Rec_APC_CONTEXT::operator=( const ::Innotron_Rec_APC_CONTEXT &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   CONTROLJOBTYPE = EB_s.CONTROLJOBTYPE;
   TRANSACTIONID = EB_s.TRANSACTIONID;
   LOTID = EB_s.LOTID;
   LOTTYPE = EB_s.LOTTYPE;
   PARTID = EB_s.PARTID;
   LAYER = EB_s.LAYER;
   ROUTE = EB_s.ROUTE;
   ROUTEGROUP = EB_s.ROUTEGROUP;
   OPERATION = EB_s.OPERATION;
   RETICLEID = EB_s.RETICLEID;
   PROCESSEQUIPTYPE = EB_s.PROCESSEQUIPTYPE;
   PROCESSEQUIPID = EB_s.PROCESSEQUIPID;
   RECOMMENDMODE = EB_s.RECOMMENDMODE;
   REWORK = EB_s.REWORK;
   PARENTLOTID = EB_s.PARENTLOTID;
   PRETOOL = EB_s.PRETOOL;
   SENDAHEAD = EB_s.SENDAHEAD;
   SENDAHEADVALUES = EB_s.SENDAHEADVALUES;
   AVAILABLE_SUBUNIT = EB_s.AVAILABLE_SUBUNIT;
   IS_OPSTART_RECOMD = EB_s.IS_OPSTART_RECOMD;
   BR_PARAMS = EB_s.BR_PARAMS;
   FEEDFORWARD1 = EB_s.FEEDFORWARD1;
   FEEDFORWARD2 = EB_s.FEEDFORWARD2;
   FEEDFORWARD3 = EB_s.FEEDFORWARD3;
   FEEDFORWARD4 = EB_s.FEEDFORWARD4;
   LD_EXTEND = EB_s.LD_EXTEND;
   return *this;
}
Innotron_Rec_APC_CONTEXT_var::Innotron_Rec_APC_CONTEXT_var () {
   _ptr = 0;
}
Innotron_Rec_APC_CONTEXT_var::Innotron_Rec_APC_CONTEXT_var (::Innotron_Rec_APC_CONTEXT*_p) {
   _ptr = _p;
}
Innotron_Rec_APC_CONTEXT_var::Innotron_Rec_APC_CONTEXT_var (const ::Innotron_Rec_APC_CONTEXT_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::Innotron_Rec_APC_CONTEXT ();
   *(_ptr) = *(_s._ptr);
}
Innotron_Rec_APC_CONTEXT_var& Innotron_Rec_APC_CONTEXT_var::operator= (::Innotron_Rec_APC_CONTEXT *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

Innotron_Rec_APC_CONTEXT_var& Innotron_Rec_APC_CONTEXT_var::operator= (const ::Innotron_Rec_APC_CONTEXT_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::Innotron_Rec_APC_CONTEXT ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

Innotron_Rec_APC_CONTEXT_var::~Innotron_Rec_APC_CONTEXT_var () {
   delete _ptr;
}

::Innotron_Rec_APC_CONTEXT * Innotron_Rec_APC_CONTEXT_var::operator-> ()
{ return _ptr; }

Innotron_Rec_APC_CONTEXT_var::operator ::Innotron_Rec_APC_CONTEXT_cvPtr () const 
{ return _ptr;}

Innotron_Rec_APC_CONTEXT_var::operator ::Innotron_Rec_APC_CONTEXT_vPtr& () 
{ return _ptr;}

Innotron_Rec_APC_CONTEXT_var::operator const ::Innotron_Rec_APC_CONTEXT& () const 
{ return *_ptr;}

Innotron_Rec_APC_CONTEXT_var::operator ::Innotron_Rec_APC_CONTEXT& () 
{ return *_ptr;}

const ::Innotron_Rec_APC_CONTEXT& Innotron_Rec_APC_CONTEXT_var::in () const { return *_ptr; }
::Innotron_Rec_APC_CONTEXT& Innotron_Rec_APC_CONTEXT_var::inout () { return *_ptr; }
::Innotron_Rec_APC_CONTEXT*& Innotron_Rec_APC_CONTEXT_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::Innotron_Rec_APC_CONTEXT* Innotron_Rec_APC_CONTEXT_var::_retn () {
  // yield ownership 
  Innotron_Rec_APC_CONTEXT* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::Innotron_Rec_APC_CONTEXT > Innotron_Rec_APC_CONTEXT::Innotron_Rec_APC_CONTEXT_Info;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_PARAMSArray_1::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_PARAMSArray_1::__stubcode_dependents[] = {::ArrayOfITEM_VALUE::__stubcode_version };
_IDL_SEQ_PARAMSArray_1::_IDL_SEQ_PARAMSArray_1()
{
  _defaultInit();
}
_IDL_SEQ_PARAMSArray_1::_IDL_SEQ_PARAMSArray_1 (const ::_IDL_SEQ_PARAMSArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_PARAMSArray_1::_IDL_SEQ_PARAMSArray_1 (::CORBA::ULong length, ::ArrayOfITEM_VALUE* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_PARAMSArray_1::~_IDL_SEQ_PARAMSArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_PARAMSArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::ArrayOfITEM_VALUE* _IDL_SEQ_PARAMSArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::ArrayOfITEM_VALUE*) new ::ArrayOfITEM_VALUE[nelems];
}
::ArrayOfITEM_VALUE* _IDL_SEQ_PARAMSArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::ArrayOfITEM_VALUE* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_PARAMSArray_1::freebuf (::ArrayOfITEM_VALUE* _data)
{
  if (_data)
    delete [] (::ArrayOfITEM_VALUE*) _data;
}
void _IDL_SEQ_PARAMSArray_1::replace ( ::CORBA::ULong length, ::ArrayOfITEM_VALUE* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_PARAMSArray_1& _IDL_SEQ_PARAMSArray_1::operator= (const ::_IDL_SEQ_PARAMSArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_PARAMSArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::ArrayOfITEM_VALUE* data)
{
  return; // simple elements don't require resetting.
}
void _IDL_SEQ_PARAMSArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::ArrayOfITEM_VALUE* src, ::ArrayOfITEM_VALUE* tgt)
{
  // Copy elements 
  ::ArrayOfITEM_VALUE* _src = (::ArrayOfITEM_VALUE*) src;
  ::ArrayOfITEM_VALUE* _tgt = (::ArrayOfITEM_VALUE*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_PARAMSArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_PARAMSArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_PARAMSArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::ArrayOfITEM_VALUE* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::ArrayOfITEM_VALUE& _IDL_SEQ_PARAMSArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return _buffer[i];
}
const ::ArrayOfITEM_VALUE& _IDL_SEQ_PARAMSArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return ((const ::ArrayOfITEM_VALUE*)_buffer) [i];
}
::CORBA::Boolean _IDL_SEQ_PARAMSArray_1::release() const 
{ return _release; }
::ArrayOfITEM_VALUE* _IDL_SEQ_PARAMSArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::ArrayOfITEM_VALUE* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::ArrayOfITEM_VALUE* _IDL_SEQ_PARAMSArray_1::get_buffer () const
{
    return (const ::ArrayOfITEM_VALUE*) _buffer;
}
void _IDL_SEQ_PARAMSArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       ::_IDL_SEQ_ArrayOfITEM_VALUE_0 const* _elem =     (::_IDL_SEQ_ArrayOfITEM_VALUE_0*) _buffer;
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
           _elem->encodeOp(_req);
       }
    }
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_PARAMSArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
      ::_IDL_SEQ_ArrayOfITEM_VALUE_0* _elem = (::_IDL_SEQ_ArrayOfITEM_VALUE_0*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_PARAMSArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
      ::_IDL_SEQ_ArrayOfITEM_VALUE_0* _elem = (::_IDL_SEQ_ArrayOfITEM_VALUE_0*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeInOutOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_PARAMSArray_1_var::_IDL_SEQ_PARAMSArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_PARAMSArray_1_var::_IDL_SEQ_PARAMSArray_1_var (::_IDL_SEQ_PARAMSArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_PARAMSArray_1_var::_IDL_SEQ_PARAMSArray_1_var (const ::_IDL_SEQ_PARAMSArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_PARAMSArray_1 (*(_s._ptr));
    }

_IDL_SEQ_PARAMSArray_1_var& _IDL_SEQ_PARAMSArray_1_var::operator= (::_IDL_SEQ_PARAMSArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_PARAMSArray_1_var& _IDL_SEQ_PARAMSArray_1_var::operator= (const ::_IDL_SEQ_PARAMSArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_PARAMSArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_PARAMSArray_1_var::~_IDL_SEQ_PARAMSArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_PARAMSArray_1 * _IDL_SEQ_PARAMSArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_PARAMSArray_1_var::operator ::_IDL_SEQ_PARAMSArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_PARAMSArray_1_var::operator ::_IDL_SEQ_PARAMSArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_PARAMSArray_1_var::operator _IDL_SEQ_PARAMSArray_1() const
{
   return *_ptr;
}
const ::ArrayOfITEM_VALUE& _IDL_SEQ_PARAMSArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_PARAMSArray_1 *)_ptr)[index];
}
::ArrayOfITEM_VALUE& _IDL_SEQ_PARAMSArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::ArrayOfITEM_VALUE& _IDL_SEQ_PARAMSArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_PARAMSArray_1 *)_ptr)[index];
}
::ArrayOfITEM_VALUE& _IDL_SEQ_PARAMSArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_PARAMSArray_1& _IDL_SEQ_PARAMSArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_PARAMSArray_1& _IDL_SEQ_PARAMSArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_PARAMSArray_1*& _IDL_SEQ_PARAMSArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_PARAMSArray_1* _IDL_SEQ_PARAMSArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_PARAMSArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_PARAMSArray_1 > _IDL_SEQ_PARAMSArray_1::PARAMSArray_1_Info;

void REC_Reticle::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("RETICLEID");
    RETICLEID.encodeOp(_req);
    _req.setVarName("PARAMS");
    PARAMS.encodeOp(_req);
    _req.encodeEndStructure();
}

void REC_Reticle::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("RETICLEID");
    RETICLEID.decodeOp(_req);
    _req.setVarName("PARAMS");
    PARAMS.decodeOp(_req);
    _req.decodeEndStructure();
}

void REC_Reticle::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("RETICLEID");
    RETICLEID.decodeInOutOp(_req);
    _req.setVarName("PARAMS");
    PARAMS.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 REC_Reticle::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 REC_Reticle::__stubcode_dependents[] = {::RETICLEIDArray::__stubcode_version,::PARAMSArray::__stubcode_version};
REC_Reticle::REC_Reticle()
{
}
REC_Reticle::REC_Reticle( const ::REC_Reticle &EB_s )
{
    operator=( EB_s );
}
REC_Reticle& REC_Reticle::operator=( const ::REC_Reticle &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   RETICLEID = EB_s.RETICLEID;
   PARAMS = EB_s.PARAMS;
   return *this;
}
REC_Reticle_var::REC_Reticle_var () {
   _ptr = 0;
}
REC_Reticle_var::REC_Reticle_var (::REC_Reticle*_p) {
   _ptr = _p;
}
REC_Reticle_var::REC_Reticle_var (const ::REC_Reticle_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::REC_Reticle ();
   *(_ptr) = *(_s._ptr);
}
REC_Reticle_var& REC_Reticle_var::operator= (::REC_Reticle *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

REC_Reticle_var& REC_Reticle_var::operator= (const ::REC_Reticle_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::REC_Reticle ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

REC_Reticle_var::~REC_Reticle_var () {
   delete _ptr;
}

::REC_Reticle * REC_Reticle_var::operator-> ()
{ return _ptr; }

REC_Reticle_var::operator ::REC_Reticle_cvPtr () const 
{ return _ptr;}

REC_Reticle_var::operator ::REC_Reticle_vPtr& () 
{ return _ptr;}

REC_Reticle_var::operator const ::REC_Reticle& () const 
{ return *_ptr;}

REC_Reticle_var::operator ::REC_Reticle& () 
{ return *_ptr;}

const ::REC_Reticle& REC_Reticle_var::in () const { return *_ptr; }
::REC_Reticle& REC_Reticle_var::inout () { return *_ptr; }
::REC_Reticle*& REC_Reticle_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::REC_Reticle* REC_Reticle_var::_retn () {
  // yield ownership 
  REC_Reticle* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::REC_Reticle > REC_Reticle::REC_Reticle_Info;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_ArrayOfREC_Reticle_0::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_ArrayOfREC_Reticle_0::__stubcode_dependents[] = {::REC_Reticle::__stubcode_version };
_IDL_SEQ_ArrayOfREC_Reticle_0::_IDL_SEQ_ArrayOfREC_Reticle_0()
{
  _defaultInit();
}
_IDL_SEQ_ArrayOfREC_Reticle_0::_IDL_SEQ_ArrayOfREC_Reticle_0 (const ::_IDL_SEQ_ArrayOfREC_Reticle_0& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_ArrayOfREC_Reticle_0::_IDL_SEQ_ArrayOfREC_Reticle_0 (::CORBA::ULong max, ::CORBA::ULong length, ::REC_Reticle* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
  _maximum = max;
}
_IDL_SEQ_ArrayOfREC_Reticle_0::_IDL_SEQ_ArrayOfREC_Reticle_0 (::CORBA::ULong max)
{
  _defaultInit();
  _maximum = max;
  if (_maximum > 0)
    _buffer = allocbuf_throw (max);
}
_IDL_SEQ_ArrayOfREC_Reticle_0::~_IDL_SEQ_ArrayOfREC_Reticle_0 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_ArrayOfREC_Reticle_0::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer  = NULL;
  _maximum = 0;
}
::REC_Reticle* _IDL_SEQ_ArrayOfREC_Reticle_0::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  // Allocate an array of the element type (which may be a
  // self managed StructElem)
#ifdef SIVIEW_EBROKER
  ::REC_Reticle* _ret;
  ::CORBA::ULong alloc_len = sizeof(::REC_Reticle) * nelems + sizeof(::CORBA::ULong);
  ::CORBA::ULong * tmp = (::CORBA::ULong *)malloc( alloc_len );
  if( tmp )
  {
    memset( tmp, 0, alloc_len );
    *tmp = nelems;
    tmp++;
    _ret = (::REC_Reticle*)tmp;
    for( CORBA::ULong _index = 0; _index < nelems; _index++ )
    {
      (void)new ((void*)( _ret + _index)) ::REC_Reticle;
    }
  }
  return _ret;
#else
  return (::REC_Reticle*) new ::REC_Reticle[nelems];
#endif
}
::REC_Reticle* _IDL_SEQ_ArrayOfREC_Reticle_0::allocbuf_throw (::CORBA::ULong nelems)
{
  ::REC_Reticle* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_ArrayOfREC_Reticle_0::freebuf (::REC_Reticle* _data)
{
#ifdef SIVIEW_EBROKER
  if (_data)
  {
    ::CORBA::ULong * tmp = (CORBA::ULong *)_data;
    tmp--;
    for( CORBA::ULong _index = *tmp; _index; _index-- )
    {
    #ifdef _WIN32
      _data[ _index - 1 ].~REC_Reticle ();
    #else
      _data[ _index - 1 ].::REC_Reticle::~REC_Reticle ();
    #endif
    }
    free(tmp);
  }
#else
  if (_data)
    delete [] (::REC_Reticle*) _data;
#endif
}
void _IDL_SEQ_ArrayOfREC_Reticle_0::replace (::CORBA::ULong max,  ::CORBA::ULong length, ::REC_Reticle* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
  _maximum = max;
}
::_IDL_SEQ_ArrayOfREC_Reticle_0& _IDL_SEQ_ArrayOfREC_Reticle_0::operator= (const ::_IDL_SEQ_ArrayOfREC_Reticle_0& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  _maximum = max;
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_ArrayOfREC_Reticle_0::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::REC_Reticle* data)
{
  return; // simple elements don't require resetting.
}
void _IDL_SEQ_ArrayOfREC_Reticle_0::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::REC_Reticle* src, ::REC_Reticle* tgt)
{
  // Copy elements 
  ::REC_Reticle* _src = (::REC_Reticle*) src;
  ::REC_Reticle* _tgt = (::REC_Reticle*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_ArrayOfREC_Reticle_0::maximum () const
{
  return   _maximum;
;
}
::CORBA::ULong _IDL_SEQ_ArrayOfREC_Reticle_0::length () const
{
  return _length;
}
void _IDL_SEQ_ArrayOfREC_Reticle_0::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  ::REC_Reticle* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace(max, len, newBuffer, 1);
  return;
}
::REC_Reticle& _IDL_SEQ_ArrayOfREC_Reticle_0::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return _buffer[i];
}
const ::REC_Reticle& _IDL_SEQ_ArrayOfREC_Reticle_0::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return ((const ::REC_Reticle*)_buffer) [i];
}
::CORBA::Boolean _IDL_SEQ_ArrayOfREC_Reticle_0::release() const 
{ return _release; }
::REC_Reticle* _IDL_SEQ_ArrayOfREC_Reticle_0::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::REC_Reticle* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::REC_Reticle* _IDL_SEQ_ArrayOfREC_Reticle_0::get_buffer () const
{
    return (const ::REC_Reticle*) _buffer;
}
void _IDL_SEQ_ArrayOfREC_Reticle_0::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       ::REC_Reticle const* _elem =     (::REC_Reticle*) _buffer;
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
           _elem->encodeOp(_req);
       }
    }
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_ArrayOfREC_Reticle_0::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
      ::REC_Reticle* _elem = (::REC_Reticle*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_ArrayOfREC_Reticle_0::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(max,__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
      ::REC_Reticle* _elem = (::REC_Reticle*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeInOutOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_ArrayOfREC_Reticle_0_var::_IDL_SEQ_ArrayOfREC_Reticle_0_var () {
   _ptr = 0;
    }

_IDL_SEQ_ArrayOfREC_Reticle_0_var::_IDL_SEQ_ArrayOfREC_Reticle_0_var (::_IDL_SEQ_ArrayOfREC_Reticle_0 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_ArrayOfREC_Reticle_0_var::_IDL_SEQ_ArrayOfREC_Reticle_0_var (const ::_IDL_SEQ_ArrayOfREC_Reticle_0_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_ArrayOfREC_Reticle_0 (*(_s._ptr));
    }

_IDL_SEQ_ArrayOfREC_Reticle_0_var& _IDL_SEQ_ArrayOfREC_Reticle_0_var::operator= (::_IDL_SEQ_ArrayOfREC_Reticle_0 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_ArrayOfREC_Reticle_0_var& _IDL_SEQ_ArrayOfREC_Reticle_0_var::operator= (const ::_IDL_SEQ_ArrayOfREC_Reticle_0_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_ArrayOfREC_Reticle_0 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_ArrayOfREC_Reticle_0_var::~_IDL_SEQ_ArrayOfREC_Reticle_0_var()
{
   delete _ptr;
}
::_IDL_SEQ_ArrayOfREC_Reticle_0 * _IDL_SEQ_ArrayOfREC_Reticle_0_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_ArrayOfREC_Reticle_0_var::operator ::_IDL_SEQ_ArrayOfREC_Reticle_0_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_ArrayOfREC_Reticle_0_var::operator ::_IDL_SEQ_ArrayOfREC_Reticle_0_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_ArrayOfREC_Reticle_0_var::operator _IDL_SEQ_ArrayOfREC_Reticle_0() const
{
   return *_ptr;
}
const ::REC_Reticle& _IDL_SEQ_ArrayOfREC_Reticle_0_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_ArrayOfREC_Reticle_0 *)_ptr)[index];
}
::REC_Reticle& _IDL_SEQ_ArrayOfREC_Reticle_0_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::REC_Reticle& _IDL_SEQ_ArrayOfREC_Reticle_0_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_ArrayOfREC_Reticle_0 *)_ptr)[index];
}
::REC_Reticle& _IDL_SEQ_ArrayOfREC_Reticle_0_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_ArrayOfREC_Reticle_0& _IDL_SEQ_ArrayOfREC_Reticle_0_var::in () const { return *_ptr; }
::_IDL_SEQ_ArrayOfREC_Reticle_0& _IDL_SEQ_ArrayOfREC_Reticle_0_var::inout () { return *_ptr; }
::_IDL_SEQ_ArrayOfREC_Reticle_0*& _IDL_SEQ_ArrayOfREC_Reticle_0_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_ArrayOfREC_Reticle_0* _IDL_SEQ_ArrayOfREC_Reticle_0_var::_retn () {
  // yield ownership 
  _IDL_SEQ_ArrayOfREC_Reticle_0* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_ArrayOfREC_Reticle_0 > _IDL_SEQ_ArrayOfREC_Reticle_0::ArrayOfREC_Reticle_0_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_WAFERIDArray_1::__stubcode_version;
_IDL_SEQ_WAFERIDArray_1::_IDL_SEQ_WAFERIDArray_1()
{
  _defaultInit();
}
_IDL_SEQ_WAFERIDArray_1::_IDL_SEQ_WAFERIDArray_1 (const ::_IDL_SEQ_WAFERIDArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_WAFERIDArray_1::_IDL_SEQ_WAFERIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_WAFERIDArray_1::~_IDL_SEQ_WAFERIDArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_WAFERIDArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_WAFERIDArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_WAFERIDArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_WAFERIDArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_WAFERIDArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_WAFERIDArray_1& _IDL_SEQ_WAFERIDArray_1::operator= (const ::_IDL_SEQ_WAFERIDArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_WAFERIDArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_WAFERIDArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_WAFERIDArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_WAFERIDArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_WAFERIDArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_WAFERIDArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_WAFERIDArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_WAFERIDArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_WAFERIDArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_WAFERIDArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_WAFERIDArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_WAFERIDArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_WAFERIDArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_WAFERIDArray_1_var::_IDL_SEQ_WAFERIDArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_WAFERIDArray_1_var::_IDL_SEQ_WAFERIDArray_1_var (::_IDL_SEQ_WAFERIDArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_WAFERIDArray_1_var::_IDL_SEQ_WAFERIDArray_1_var (const ::_IDL_SEQ_WAFERIDArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_WAFERIDArray_1 (*(_s._ptr));
    }

_IDL_SEQ_WAFERIDArray_1_var& _IDL_SEQ_WAFERIDArray_1_var::operator= (::_IDL_SEQ_WAFERIDArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_WAFERIDArray_1_var& _IDL_SEQ_WAFERIDArray_1_var::operator= (const ::_IDL_SEQ_WAFERIDArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_WAFERIDArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_WAFERIDArray_1_var::~_IDL_SEQ_WAFERIDArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_WAFERIDArray_1 * _IDL_SEQ_WAFERIDArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_WAFERIDArray_1_var::operator ::_IDL_SEQ_WAFERIDArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_WAFERIDArray_1_var::operator ::_IDL_SEQ_WAFERIDArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_WAFERIDArray_1_var::operator _IDL_SEQ_WAFERIDArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_WAFERIDArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_WAFERIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_WAFERIDArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_WAFERIDArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_WAFERIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_WAFERIDArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_WAFERIDArray_1& _IDL_SEQ_WAFERIDArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_WAFERIDArray_1& _IDL_SEQ_WAFERIDArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_WAFERIDArray_1*& _IDL_SEQ_WAFERIDArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_WAFERIDArray_1* _IDL_SEQ_WAFERIDArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_WAFERIDArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_WAFERIDArray_1 > _IDL_SEQ_WAFERIDArray_1::WAFERIDArray_1_Info;

void WAFER::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("SLOTNO");
    _req << SLOTNO;
    _req.setVarName("WAFERID");
    WAFERID.encodeOp(_req);
    _req.setVarName("CHUCKID");
    _req << CHUCKID;
    _req.setVarName("REWORK_CNT");
    _req << REWORK_CNT;
    _req.encodeEndStructure();
}

void WAFER::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("SLOTNO");
    _req >> SLOTNO;
    _req.setVarName("WAFERID");
    WAFERID.decodeOp(_req);
    _req.setVarName("CHUCKID");
    _req >> CHUCKID;
    _req.setVarName("REWORK_CNT");
    _req >> REWORK_CNT;
    _req.decodeEndStructure();
}

void WAFER::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("SLOTNO");
    _req >> SLOTNO;
    _req.setVarName("WAFERID");
    WAFERID.decodeInOutOp(_req);
    _req.setVarName("CHUCKID");
    _req >> CHUCKID;
    _req.setVarName("REWORK_CNT");
    _req >> REWORK_CNT;
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 WAFER::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 WAFER::__stubcode_dependents[] = {::WAFERIDArray::__stubcode_version};
WAFER::WAFER()
{
}
WAFER::WAFER( const ::WAFER &EB_s )
{
    operator=( EB_s );
}
WAFER& WAFER::operator=( const ::WAFER &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   SLOTNO = EB_s.SLOTNO;
   WAFERID = EB_s.WAFERID;
   CHUCKID = EB_s.CHUCKID;
   REWORK_CNT = EB_s.REWORK_CNT;
   return *this;
}
WAFER_var::WAFER_var () {
   _ptr = 0;
}
WAFER_var::WAFER_var (::WAFER*_p) {
   _ptr = _p;
}
WAFER_var::WAFER_var (const ::WAFER_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::WAFER ();
   *(_ptr) = *(_s._ptr);
}
WAFER_var& WAFER_var::operator= (::WAFER *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

WAFER_var& WAFER_var::operator= (const ::WAFER_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::WAFER ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

WAFER_var::~WAFER_var () {
   delete _ptr;
}

::WAFER * WAFER_var::operator-> ()
{ return _ptr; }

WAFER_var::operator ::WAFER_cvPtr () const 
{ return _ptr;}

WAFER_var::operator ::WAFER_vPtr& () 
{ return _ptr;}

WAFER_var::operator const ::WAFER& () const 
{ return *_ptr;}

WAFER_var::operator ::WAFER& () 
{ return *_ptr;}

const ::WAFER& WAFER_var::in () const { return *_ptr; }
::WAFER& WAFER_var::inout () { return *_ptr; }
::WAFER*& WAFER_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::WAFER* WAFER_var::_retn () {
  // yield ownership 
  WAFER* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::WAFER > WAFER::WAFER_Info;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_ArrayOfWAFER_0::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_ArrayOfWAFER_0::__stubcode_dependents[] = {::WAFER::__stubcode_version };
_IDL_SEQ_ArrayOfWAFER_0::_IDL_SEQ_ArrayOfWAFER_0()
{
  _defaultInit();
}
_IDL_SEQ_ArrayOfWAFER_0::_IDL_SEQ_ArrayOfWAFER_0 (const ::_IDL_SEQ_ArrayOfWAFER_0& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_ArrayOfWAFER_0::_IDL_SEQ_ArrayOfWAFER_0 (::CORBA::ULong max, ::CORBA::ULong length, ::WAFER* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
  _maximum = max;
}
_IDL_SEQ_ArrayOfWAFER_0::_IDL_SEQ_ArrayOfWAFER_0 (::CORBA::ULong max)
{
  _defaultInit();
  _maximum = max;
  if (_maximum > 0)
    _buffer = allocbuf_throw (max);
}
_IDL_SEQ_ArrayOfWAFER_0::~_IDL_SEQ_ArrayOfWAFER_0 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_ArrayOfWAFER_0::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer  = NULL;
  _maximum = 0;
}
::WAFER* _IDL_SEQ_ArrayOfWAFER_0::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  // Allocate an array of the element type (which may be a
  // self managed StructElem)
#ifdef SIVIEW_EBROKER
  ::WAFER* _ret;
  ::CORBA::ULong alloc_len = sizeof(::WAFER) * nelems + sizeof(::CORBA::ULong);
  ::CORBA::ULong * tmp = (::CORBA::ULong *)malloc( alloc_len );
  if( tmp )
  {
    memset( tmp, 0, alloc_len );
    *tmp = nelems;
    tmp++;
    _ret = (::WAFER*)tmp;
    for( CORBA::ULong _index = 0; _index < nelems; _index++ )
    {
      (void)new ((void*)( _ret + _index)) ::WAFER;
    }
  }
  return _ret;
#else
  return (::WAFER*) new ::WAFER[nelems];
#endif
}
::WAFER* _IDL_SEQ_ArrayOfWAFER_0::allocbuf_throw (::CORBA::ULong nelems)
{
  ::WAFER* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_ArrayOfWAFER_0::freebuf (::WAFER* _data)
{
#ifdef SIVIEW_EBROKER
  if (_data)
  {
    ::CORBA::ULong * tmp = (CORBA::ULong *)_data;
    tmp--;
    for( CORBA::ULong _index = *tmp; _index; _index-- )
    {
    #ifdef _WIN32
      _data[ _index - 1 ].~WAFER ();
    #else
      _data[ _index - 1 ].::WAFER::~WAFER ();
    #endif
    }
    free(tmp);
  }
#else
  if (_data)
    delete [] (::WAFER*) _data;
#endif
}
void _IDL_SEQ_ArrayOfWAFER_0::replace (::CORBA::ULong max,  ::CORBA::ULong length, ::WAFER* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
  _maximum = max;
}
::_IDL_SEQ_ArrayOfWAFER_0& _IDL_SEQ_ArrayOfWAFER_0::operator= (const ::_IDL_SEQ_ArrayOfWAFER_0& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  _maximum = max;
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_ArrayOfWAFER_0::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::WAFER* data)
{
  return; // simple elements don't require resetting.
}
void _IDL_SEQ_ArrayOfWAFER_0::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::WAFER* src, ::WAFER* tgt)
{
  // Copy elements 
  ::WAFER* _src = (::WAFER*) src;
  ::WAFER* _tgt = (::WAFER*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_ArrayOfWAFER_0::maximum () const
{
  return   _maximum;
;
}
::CORBA::ULong _IDL_SEQ_ArrayOfWAFER_0::length () const
{
  return _length;
}
void _IDL_SEQ_ArrayOfWAFER_0::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  ::WAFER* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace(max, len, newBuffer, 1);
  return;
}
::WAFER& _IDL_SEQ_ArrayOfWAFER_0::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return _buffer[i];
}
const ::WAFER& _IDL_SEQ_ArrayOfWAFER_0::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return ((const ::WAFER*)_buffer) [i];
}
::CORBA::Boolean _IDL_SEQ_ArrayOfWAFER_0::release() const 
{ return _release; }
::WAFER* _IDL_SEQ_ArrayOfWAFER_0::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::WAFER* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::WAFER* _IDL_SEQ_ArrayOfWAFER_0::get_buffer () const
{
    return (const ::WAFER*) _buffer;
}
void _IDL_SEQ_ArrayOfWAFER_0::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       ::WAFER const* _elem =     (::WAFER*) _buffer;
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
           _elem->encodeOp(_req);
       }
    }
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_ArrayOfWAFER_0::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
      ::WAFER* _elem = (::WAFER*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_ArrayOfWAFER_0::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(max,__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
      ::WAFER* _elem = (::WAFER*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeInOutOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_ArrayOfWAFER_0_var::_IDL_SEQ_ArrayOfWAFER_0_var () {
   _ptr = 0;
    }

_IDL_SEQ_ArrayOfWAFER_0_var::_IDL_SEQ_ArrayOfWAFER_0_var (::_IDL_SEQ_ArrayOfWAFER_0 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_ArrayOfWAFER_0_var::_IDL_SEQ_ArrayOfWAFER_0_var (const ::_IDL_SEQ_ArrayOfWAFER_0_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_ArrayOfWAFER_0 (*(_s._ptr));
    }

_IDL_SEQ_ArrayOfWAFER_0_var& _IDL_SEQ_ArrayOfWAFER_0_var::operator= (::_IDL_SEQ_ArrayOfWAFER_0 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_ArrayOfWAFER_0_var& _IDL_SEQ_ArrayOfWAFER_0_var::operator= (const ::_IDL_SEQ_ArrayOfWAFER_0_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_ArrayOfWAFER_0 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_ArrayOfWAFER_0_var::~_IDL_SEQ_ArrayOfWAFER_0_var()
{
   delete _ptr;
}
::_IDL_SEQ_ArrayOfWAFER_0 * _IDL_SEQ_ArrayOfWAFER_0_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_ArrayOfWAFER_0_var::operator ::_IDL_SEQ_ArrayOfWAFER_0_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_ArrayOfWAFER_0_var::operator ::_IDL_SEQ_ArrayOfWAFER_0_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_ArrayOfWAFER_0_var::operator _IDL_SEQ_ArrayOfWAFER_0() const
{
   return *_ptr;
}
const ::WAFER& _IDL_SEQ_ArrayOfWAFER_0_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_ArrayOfWAFER_0 *)_ptr)[index];
}
::WAFER& _IDL_SEQ_ArrayOfWAFER_0_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::WAFER& _IDL_SEQ_ArrayOfWAFER_0_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_ArrayOfWAFER_0 *)_ptr)[index];
}
::WAFER& _IDL_SEQ_ArrayOfWAFER_0_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_ArrayOfWAFER_0& _IDL_SEQ_ArrayOfWAFER_0_var::in () const { return *_ptr; }
::_IDL_SEQ_ArrayOfWAFER_0& _IDL_SEQ_ArrayOfWAFER_0_var::inout () { return *_ptr; }
::_IDL_SEQ_ArrayOfWAFER_0*& _IDL_SEQ_ArrayOfWAFER_0_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_ArrayOfWAFER_0* _IDL_SEQ_ArrayOfWAFER_0_var::_retn () {
  // yield ownership 
  _IDL_SEQ_ArrayOfWAFER_0* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_ArrayOfWAFER_0 > _IDL_SEQ_ArrayOfWAFER_0::ArrayOfWAFER_0_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_WAFERSArray_1::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_WAFERSArray_1::__stubcode_dependents[] = {::ArrayOfWAFER::__stubcode_version };
_IDL_SEQ_WAFERSArray_1::_IDL_SEQ_WAFERSArray_1()
{
  _defaultInit();
}
_IDL_SEQ_WAFERSArray_1::_IDL_SEQ_WAFERSArray_1 (const ::_IDL_SEQ_WAFERSArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_WAFERSArray_1::_IDL_SEQ_WAFERSArray_1 (::CORBA::ULong length, ::ArrayOfWAFER* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_WAFERSArray_1::~_IDL_SEQ_WAFERSArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_WAFERSArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::ArrayOfWAFER* _IDL_SEQ_WAFERSArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::ArrayOfWAFER*) new ::ArrayOfWAFER[nelems];
}
::ArrayOfWAFER* _IDL_SEQ_WAFERSArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::ArrayOfWAFER* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_WAFERSArray_1::freebuf (::ArrayOfWAFER* _data)
{
  if (_data)
    delete [] (::ArrayOfWAFER*) _data;
}
void _IDL_SEQ_WAFERSArray_1::replace ( ::CORBA::ULong length, ::ArrayOfWAFER* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_WAFERSArray_1& _IDL_SEQ_WAFERSArray_1::operator= (const ::_IDL_SEQ_WAFERSArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_WAFERSArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::ArrayOfWAFER* data)
{
  return; // simple elements don't require resetting.
}
void _IDL_SEQ_WAFERSArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::ArrayOfWAFER* src, ::ArrayOfWAFER* tgt)
{
  // Copy elements 
  ::ArrayOfWAFER* _src = (::ArrayOfWAFER*) src;
  ::ArrayOfWAFER* _tgt = (::ArrayOfWAFER*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_WAFERSArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_WAFERSArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_WAFERSArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::ArrayOfWAFER* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::ArrayOfWAFER& _IDL_SEQ_WAFERSArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return _buffer[i];
}
const ::ArrayOfWAFER& _IDL_SEQ_WAFERSArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return ((const ::ArrayOfWAFER*)_buffer) [i];
}
::CORBA::Boolean _IDL_SEQ_WAFERSArray_1::release() const 
{ return _release; }
::ArrayOfWAFER* _IDL_SEQ_WAFERSArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::ArrayOfWAFER* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::ArrayOfWAFER* _IDL_SEQ_WAFERSArray_1::get_buffer () const
{
    return (const ::ArrayOfWAFER*) _buffer;
}
void _IDL_SEQ_WAFERSArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       ::_IDL_SEQ_ArrayOfWAFER_0 const* _elem =     (::_IDL_SEQ_ArrayOfWAFER_0*) _buffer;
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
           _elem->encodeOp(_req);
       }
    }
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_WAFERSArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
      ::_IDL_SEQ_ArrayOfWAFER_0* _elem = (::_IDL_SEQ_ArrayOfWAFER_0*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_WAFERSArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
      ::_IDL_SEQ_ArrayOfWAFER_0* _elem = (::_IDL_SEQ_ArrayOfWAFER_0*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeInOutOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_WAFERSArray_1_var::_IDL_SEQ_WAFERSArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_WAFERSArray_1_var::_IDL_SEQ_WAFERSArray_1_var (::_IDL_SEQ_WAFERSArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_WAFERSArray_1_var::_IDL_SEQ_WAFERSArray_1_var (const ::_IDL_SEQ_WAFERSArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_WAFERSArray_1 (*(_s._ptr));
    }

_IDL_SEQ_WAFERSArray_1_var& _IDL_SEQ_WAFERSArray_1_var::operator= (::_IDL_SEQ_WAFERSArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_WAFERSArray_1_var& _IDL_SEQ_WAFERSArray_1_var::operator= (const ::_IDL_SEQ_WAFERSArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_WAFERSArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_WAFERSArray_1_var::~_IDL_SEQ_WAFERSArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_WAFERSArray_1 * _IDL_SEQ_WAFERSArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_WAFERSArray_1_var::operator ::_IDL_SEQ_WAFERSArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_WAFERSArray_1_var::operator ::_IDL_SEQ_WAFERSArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_WAFERSArray_1_var::operator _IDL_SEQ_WAFERSArray_1() const
{
   return *_ptr;
}
const ::ArrayOfWAFER& _IDL_SEQ_WAFERSArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_WAFERSArray_1 *)_ptr)[index];
}
::ArrayOfWAFER& _IDL_SEQ_WAFERSArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::ArrayOfWAFER& _IDL_SEQ_WAFERSArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_WAFERSArray_1 *)_ptr)[index];
}
::ArrayOfWAFER& _IDL_SEQ_WAFERSArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_WAFERSArray_1& _IDL_SEQ_WAFERSArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_WAFERSArray_1& _IDL_SEQ_WAFERSArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_WAFERSArray_1*& _IDL_SEQ_WAFERSArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_WAFERSArray_1* _IDL_SEQ_WAFERSArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_WAFERSArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_WAFERSArray_1 > _IDL_SEQ_WAFERSArray_1::WAFERSArray_1_Info;

void LOT::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("LOTID");
    _req << LOTID;
    _req.setVarName("WAFERS");
    WAFERS.encodeOp(_req);
    _req.encodeEndStructure();
}

void LOT::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("LOTID");
    _req >> LOTID;
    _req.setVarName("WAFERS");
    WAFERS.decodeOp(_req);
    _req.decodeEndStructure();
}

void LOT::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("LOTID");
    _req >> LOTID;
    _req.setVarName("WAFERS");
    WAFERS.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 LOT::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 LOT::__stubcode_dependents[] = {::WAFERSArray::__stubcode_version};
LOT::LOT()
{
}
LOT::LOT( const ::LOT &EB_s )
{
    operator=( EB_s );
}
LOT& LOT::operator=( const ::LOT &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   LOTID = EB_s.LOTID;
   WAFERS = EB_s.WAFERS;
   return *this;
}
LOT_var::LOT_var () {
   _ptr = 0;
}
LOT_var::LOT_var (::LOT*_p) {
   _ptr = _p;
}
LOT_var::LOT_var (const ::LOT_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::LOT ();
   *(_ptr) = *(_s._ptr);
}
LOT_var& LOT_var::operator= (::LOT *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

LOT_var& LOT_var::operator= (const ::LOT_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::LOT ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

LOT_var::~LOT_var () {
   delete _ptr;
}

::LOT * LOT_var::operator-> ()
{ return _ptr; }

LOT_var::operator ::LOT_cvPtr () const 
{ return _ptr;}

LOT_var::operator ::LOT_vPtr& () 
{ return _ptr;}

LOT_var::operator const ::LOT& () const 
{ return *_ptr;}

LOT_var::operator ::LOT& () 
{ return *_ptr;}

const ::LOT& LOT_var::in () const { return *_ptr; }
::LOT& LOT_var::inout () { return *_ptr; }
::LOT*& LOT_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::LOT* LOT_var::_retn () {
  // yield ownership 
  LOT* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::LOT > LOT::LOT_Info;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_USED_TRANSACTIONIDArray_1::__stubcode_version;
_IDL_SEQ_USED_TRANSACTIONIDArray_1::_IDL_SEQ_USED_TRANSACTIONIDArray_1()
{
  _defaultInit();
}
_IDL_SEQ_USED_TRANSACTIONIDArray_1::_IDL_SEQ_USED_TRANSACTIONIDArray_1 (const ::_IDL_SEQ_USED_TRANSACTIONIDArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_USED_TRANSACTIONIDArray_1::_IDL_SEQ_USED_TRANSACTIONIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_USED_TRANSACTIONIDArray_1::~_IDL_SEQ_USED_TRANSACTIONIDArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_USED_TRANSACTIONIDArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_USED_TRANSACTIONIDArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_USED_TRANSACTIONIDArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_USED_TRANSACTIONIDArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_USED_TRANSACTIONIDArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_USED_TRANSACTIONIDArray_1& _IDL_SEQ_USED_TRANSACTIONIDArray_1::operator= (const ::_IDL_SEQ_USED_TRANSACTIONIDArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_USED_TRANSACTIONIDArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_USED_TRANSACTIONIDArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_USED_TRANSACTIONIDArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_USED_TRANSACTIONIDArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_USED_TRANSACTIONIDArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_USED_TRANSACTIONIDArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_USED_TRANSACTIONIDArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_USED_TRANSACTIONIDArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_USED_TRANSACTIONIDArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_USED_TRANSACTIONIDArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_USED_TRANSACTIONIDArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_USED_TRANSACTIONIDArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_USED_TRANSACTIONIDArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_USED_TRANSACTIONIDArray_1_var::_IDL_SEQ_USED_TRANSACTIONIDArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_USED_TRANSACTIONIDArray_1_var::_IDL_SEQ_USED_TRANSACTIONIDArray_1_var (::_IDL_SEQ_USED_TRANSACTIONIDArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_USED_TRANSACTIONIDArray_1_var::_IDL_SEQ_USED_TRANSACTIONIDArray_1_var (const ::_IDL_SEQ_USED_TRANSACTIONIDArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_USED_TRANSACTIONIDArray_1 (*(_s._ptr));
    }

_IDL_SEQ_USED_TRANSACTIONIDArray_1_var& _IDL_SEQ_USED_TRANSACTIONIDArray_1_var::operator= (::_IDL_SEQ_USED_TRANSACTIONIDArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_USED_TRANSACTIONIDArray_1_var& _IDL_SEQ_USED_TRANSACTIONIDArray_1_var::operator= (const ::_IDL_SEQ_USED_TRANSACTIONIDArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_USED_TRANSACTIONIDArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_USED_TRANSACTIONIDArray_1_var::~_IDL_SEQ_USED_TRANSACTIONIDArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_USED_TRANSACTIONIDArray_1 * _IDL_SEQ_USED_TRANSACTIONIDArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_USED_TRANSACTIONIDArray_1_var::operator ::_IDL_SEQ_USED_TRANSACTIONIDArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_USED_TRANSACTIONIDArray_1_var::operator ::_IDL_SEQ_USED_TRANSACTIONIDArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_USED_TRANSACTIONIDArray_1_var::operator _IDL_SEQ_USED_TRANSACTIONIDArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_USED_TRANSACTIONIDArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_USED_TRANSACTIONIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_USED_TRANSACTIONIDArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_USED_TRANSACTIONIDArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_USED_TRANSACTIONIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_USED_TRANSACTIONIDArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_USED_TRANSACTIONIDArray_1& _IDL_SEQ_USED_TRANSACTIONIDArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_USED_TRANSACTIONIDArray_1& _IDL_SEQ_USED_TRANSACTIONIDArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_USED_TRANSACTIONIDArray_1*& _IDL_SEQ_USED_TRANSACTIONIDArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_USED_TRANSACTIONIDArray_1* _IDL_SEQ_USED_TRANSACTIONIDArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_USED_TRANSACTIONIDArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_USED_TRANSACTIONIDArray_1 > _IDL_SEQ_USED_TRANSACTIONIDArray_1::USED_TRANSACTIONIDArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::__stubcode_version;
_IDL_SEQ_METROLOGYEQUIPTYPEArray_1::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1()
{
  _defaultInit();
}
_IDL_SEQ_METROLOGYEQUIPTYPEArray_1::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1 (const ::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_METROLOGYEQUIPTYPEArray_1::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_METROLOGYEQUIPTYPEArray_1::~_IDL_SEQ_METROLOGYEQUIPTYPEArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1& _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::operator= (const ::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var (::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var (const ::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1 (*(_s._ptr));
    }

_IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var& _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var::operator= (::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var& _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var::operator= (const ::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var::~_IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1 * _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var::operator ::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var::operator ::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var::operator _IDL_SEQ_METROLOGYEQUIPTYPEArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1& _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1& _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1*& _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1* _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_METROLOGYEQUIPTYPEArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_METROLOGYEQUIPTYPEArray_1 > _IDL_SEQ_METROLOGYEQUIPTYPEArray_1::METROLOGYEQUIPTYPEArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_METROLOGYEQUIPIDArray_1::__stubcode_version;
_IDL_SEQ_METROLOGYEQUIPIDArray_1::_IDL_SEQ_METROLOGYEQUIPIDArray_1()
{
  _defaultInit();
}
_IDL_SEQ_METROLOGYEQUIPIDArray_1::_IDL_SEQ_METROLOGYEQUIPIDArray_1 (const ::_IDL_SEQ_METROLOGYEQUIPIDArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_METROLOGYEQUIPIDArray_1::_IDL_SEQ_METROLOGYEQUIPIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_METROLOGYEQUIPIDArray_1::~_IDL_SEQ_METROLOGYEQUIPIDArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_METROLOGYEQUIPIDArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_METROLOGYEQUIPIDArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_METROLOGYEQUIPIDArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_METROLOGYEQUIPIDArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_METROLOGYEQUIPIDArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_METROLOGYEQUIPIDArray_1& _IDL_SEQ_METROLOGYEQUIPIDArray_1::operator= (const ::_IDL_SEQ_METROLOGYEQUIPIDArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_METROLOGYEQUIPIDArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_METROLOGYEQUIPIDArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_METROLOGYEQUIPIDArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_METROLOGYEQUIPIDArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_METROLOGYEQUIPIDArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_METROLOGYEQUIPIDArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_METROLOGYEQUIPIDArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_METROLOGYEQUIPIDArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_METROLOGYEQUIPIDArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_METROLOGYEQUIPIDArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_METROLOGYEQUIPIDArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_METROLOGYEQUIPIDArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_METROLOGYEQUIPIDArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_METROLOGYEQUIPIDArray_1_var::_IDL_SEQ_METROLOGYEQUIPIDArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_METROLOGYEQUIPIDArray_1_var::_IDL_SEQ_METROLOGYEQUIPIDArray_1_var (::_IDL_SEQ_METROLOGYEQUIPIDArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_METROLOGYEQUIPIDArray_1_var::_IDL_SEQ_METROLOGYEQUIPIDArray_1_var (const ::_IDL_SEQ_METROLOGYEQUIPIDArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_METROLOGYEQUIPIDArray_1 (*(_s._ptr));
    }

_IDL_SEQ_METROLOGYEQUIPIDArray_1_var& _IDL_SEQ_METROLOGYEQUIPIDArray_1_var::operator= (::_IDL_SEQ_METROLOGYEQUIPIDArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_METROLOGYEQUIPIDArray_1_var& _IDL_SEQ_METROLOGYEQUIPIDArray_1_var::operator= (const ::_IDL_SEQ_METROLOGYEQUIPIDArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_METROLOGYEQUIPIDArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_METROLOGYEQUIPIDArray_1_var::~_IDL_SEQ_METROLOGYEQUIPIDArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_METROLOGYEQUIPIDArray_1 * _IDL_SEQ_METROLOGYEQUIPIDArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_METROLOGYEQUIPIDArray_1_var::operator ::_IDL_SEQ_METROLOGYEQUIPIDArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_METROLOGYEQUIPIDArray_1_var::operator ::_IDL_SEQ_METROLOGYEQUIPIDArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_METROLOGYEQUIPIDArray_1_var::operator _IDL_SEQ_METROLOGYEQUIPIDArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_METROLOGYEQUIPIDArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_METROLOGYEQUIPIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_METROLOGYEQUIPIDArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_METROLOGYEQUIPIDArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_METROLOGYEQUIPIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_METROLOGYEQUIPIDArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_METROLOGYEQUIPIDArray_1& _IDL_SEQ_METROLOGYEQUIPIDArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_METROLOGYEQUIPIDArray_1& _IDL_SEQ_METROLOGYEQUIPIDArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_METROLOGYEQUIPIDArray_1*& _IDL_SEQ_METROLOGYEQUIPIDArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_METROLOGYEQUIPIDArray_1* _IDL_SEQ_METROLOGYEQUIPIDArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_METROLOGYEQUIPIDArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_METROLOGYEQUIPIDArray_1 > _IDL_SEQ_METROLOGYEQUIPIDArray_1::METROLOGYEQUIPIDArray_1_Info;

void Innotron_Met_APC_CONTEXT::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("CONTROLJOBTYPE");
    CONTROLJOBTYPE.encodeOp(_req);
    _req.setVarName("TRANSACTIONID");
    TRANSACTIONID.encodeOp(_req);
    _req.setVarName("USED_TRANSACTIONID");
    USED_TRANSACTIONID.encodeOp(_req);
    _req.setVarName("LOTID");
    LOTID.encodeOp(_req);
    _req.setVarName("PARTID");
    PARTID.encodeOp(_req);
    _req.setVarName("LAYER");
    LAYER.encodeOp(_req);
    _req.setVarName("ROUTE");
    ROUTE.encodeOp(_req);
    _req.setVarName("ROUTEGROUP");
    ROUTEGROUP.encodeOp(_req);
    _req.setVarName("OPERATION");
    OPERATION.encodeOp(_req);
    _req.setVarName("RETICLEID");
    RETICLEID.encodeOp(_req);
    _req.setVarName("METROLOGYEQUIPTYPE");
    METROLOGYEQUIPTYPE.encodeOp(_req);
    _req.setVarName("METROLOGYEQUIPID");
    METROLOGYEQUIPID.encodeOp(_req);
    _req.setVarName("PROCESSEQUIPTYPE");
    PROCESSEQUIPTYPE.encodeOp(_req);
    _req.setVarName("PROCESSEQUIPID");
    PROCESSEQUIPID.encodeOp(_req);
    _req.encodeEndStructure();
}

void Innotron_Met_APC_CONTEXT::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("CONTROLJOBTYPE");
    CONTROLJOBTYPE.decodeOp(_req);
    _req.setVarName("TRANSACTIONID");
    TRANSACTIONID.decodeOp(_req);
    _req.setVarName("USED_TRANSACTIONID");
    USED_TRANSACTIONID.decodeOp(_req);
    _req.setVarName("LOTID");
    LOTID.decodeOp(_req);
    _req.setVarName("PARTID");
    PARTID.decodeOp(_req);
    _req.setVarName("LAYER");
    LAYER.decodeOp(_req);
    _req.setVarName("ROUTE");
    ROUTE.decodeOp(_req);
    _req.setVarName("ROUTEGROUP");
    ROUTEGROUP.decodeOp(_req);
    _req.setVarName("OPERATION");
    OPERATION.decodeOp(_req);
    _req.setVarName("RETICLEID");
    RETICLEID.decodeOp(_req);
    _req.setVarName("METROLOGYEQUIPTYPE");
    METROLOGYEQUIPTYPE.decodeOp(_req);
    _req.setVarName("METROLOGYEQUIPID");
    METROLOGYEQUIPID.decodeOp(_req);
    _req.setVarName("PROCESSEQUIPTYPE");
    PROCESSEQUIPTYPE.decodeOp(_req);
    _req.setVarName("PROCESSEQUIPID");
    PROCESSEQUIPID.decodeOp(_req);
    _req.decodeEndStructure();
}

void Innotron_Met_APC_CONTEXT::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("CONTROLJOBTYPE");
    CONTROLJOBTYPE.decodeInOutOp(_req);
    _req.setVarName("TRANSACTIONID");
    TRANSACTIONID.decodeInOutOp(_req);
    _req.setVarName("USED_TRANSACTIONID");
    USED_TRANSACTIONID.decodeInOutOp(_req);
    _req.setVarName("LOTID");
    LOTID.decodeInOutOp(_req);
    _req.setVarName("PARTID");
    PARTID.decodeInOutOp(_req);
    _req.setVarName("LAYER");
    LAYER.decodeInOutOp(_req);
    _req.setVarName("ROUTE");
    ROUTE.decodeInOutOp(_req);
    _req.setVarName("ROUTEGROUP");
    ROUTEGROUP.decodeInOutOp(_req);
    _req.setVarName("OPERATION");
    OPERATION.decodeInOutOp(_req);
    _req.setVarName("RETICLEID");
    RETICLEID.decodeInOutOp(_req);
    _req.setVarName("METROLOGYEQUIPTYPE");
    METROLOGYEQUIPTYPE.decodeInOutOp(_req);
    _req.setVarName("METROLOGYEQUIPID");
    METROLOGYEQUIPID.decodeInOutOp(_req);
    _req.setVarName("PROCESSEQUIPTYPE");
    PROCESSEQUIPTYPE.decodeInOutOp(_req);
    _req.setVarName("PROCESSEQUIPID");
    PROCESSEQUIPID.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 Innotron_Met_APC_CONTEXT::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 Innotron_Met_APC_CONTEXT::__stubcode_dependents[] = {::METROLOGYEQUIPTYPEArray::__stubcode_version,::LOTIDArray::__stubcode_version,::PROCESSEQUIPIDArray::__stubcode_version,::TRANSACTIONIDArray::__stubcode_version,::RETICLEIDArray::__stubcode_version,::LAYERArray::__stubcode_version,::PROCESSEQUIPTYPEArray::__stubcode_version,::USED_TRANSACTIONIDArray::__stubcode_version,::ROUTEGROUPArray::__stubcode_version,::CONTROLJOBTYPEArray::__stubcode_version,::METROLOGYEQUIPIDArray::__stubcode_version,::OPERATIONArray::__stubcode_version,::ROUTEArray::__stubcode_version,::PARTIDArray::__stubcode_version};
Innotron_Met_APC_CONTEXT::Innotron_Met_APC_CONTEXT()
{
}
Innotron_Met_APC_CONTEXT::Innotron_Met_APC_CONTEXT( const ::Innotron_Met_APC_CONTEXT &EB_s )
{
    operator=( EB_s );
}
Innotron_Met_APC_CONTEXT& Innotron_Met_APC_CONTEXT::operator=( const ::Innotron_Met_APC_CONTEXT &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   CONTROLJOBTYPE = EB_s.CONTROLJOBTYPE;
   TRANSACTIONID = EB_s.TRANSACTIONID;
   USED_TRANSACTIONID = EB_s.USED_TRANSACTIONID;
   LOTID = EB_s.LOTID;
   PARTID = EB_s.PARTID;
   LAYER = EB_s.LAYER;
   ROUTE = EB_s.ROUTE;
   ROUTEGROUP = EB_s.ROUTEGROUP;
   OPERATION = EB_s.OPERATION;
   RETICLEID = EB_s.RETICLEID;
   METROLOGYEQUIPTYPE = EB_s.METROLOGYEQUIPTYPE;
   METROLOGYEQUIPID = EB_s.METROLOGYEQUIPID;
   PROCESSEQUIPTYPE = EB_s.PROCESSEQUIPTYPE;
   PROCESSEQUIPID = EB_s.PROCESSEQUIPID;
   return *this;
}
Innotron_Met_APC_CONTEXT_var::Innotron_Met_APC_CONTEXT_var () {
   _ptr = 0;
}
Innotron_Met_APC_CONTEXT_var::Innotron_Met_APC_CONTEXT_var (::Innotron_Met_APC_CONTEXT*_p) {
   _ptr = _p;
}
Innotron_Met_APC_CONTEXT_var::Innotron_Met_APC_CONTEXT_var (const ::Innotron_Met_APC_CONTEXT_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::Innotron_Met_APC_CONTEXT ();
   *(_ptr) = *(_s._ptr);
}
Innotron_Met_APC_CONTEXT_var& Innotron_Met_APC_CONTEXT_var::operator= (::Innotron_Met_APC_CONTEXT *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

Innotron_Met_APC_CONTEXT_var& Innotron_Met_APC_CONTEXT_var::operator= (const ::Innotron_Met_APC_CONTEXT_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::Innotron_Met_APC_CONTEXT ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

Innotron_Met_APC_CONTEXT_var::~Innotron_Met_APC_CONTEXT_var () {
   delete _ptr;
}

::Innotron_Met_APC_CONTEXT * Innotron_Met_APC_CONTEXT_var::operator-> ()
{ return _ptr; }

Innotron_Met_APC_CONTEXT_var::operator ::Innotron_Met_APC_CONTEXT_cvPtr () const 
{ return _ptr;}

Innotron_Met_APC_CONTEXT_var::operator ::Innotron_Met_APC_CONTEXT_vPtr& () 
{ return _ptr;}

Innotron_Met_APC_CONTEXT_var::operator const ::Innotron_Met_APC_CONTEXT& () const 
{ return *_ptr;}

Innotron_Met_APC_CONTEXT_var::operator ::Innotron_Met_APC_CONTEXT& () 
{ return *_ptr;}

const ::Innotron_Met_APC_CONTEXT& Innotron_Met_APC_CONTEXT_var::in () const { return *_ptr; }
::Innotron_Met_APC_CONTEXT& Innotron_Met_APC_CONTEXT_var::inout () { return *_ptr; }
::Innotron_Met_APC_CONTEXT*& Innotron_Met_APC_CONTEXT_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::Innotron_Met_APC_CONTEXT* Innotron_Met_APC_CONTEXT_var::_retn () {
  // yield ownership 
  Innotron_Met_APC_CONTEXT* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::Innotron_Met_APC_CONTEXT > Innotron_Met_APC_CONTEXT::Innotron_Met_APC_CONTEXT_Info;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_WAFERLISTArray_1::__stubcode_version;
_IDL_SEQ_WAFERLISTArray_1::_IDL_SEQ_WAFERLISTArray_1()
{
  _defaultInit();
}
_IDL_SEQ_WAFERLISTArray_1::_IDL_SEQ_WAFERLISTArray_1 (const ::_IDL_SEQ_WAFERLISTArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_WAFERLISTArray_1::_IDL_SEQ_WAFERLISTArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_WAFERLISTArray_1::~_IDL_SEQ_WAFERLISTArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_WAFERLISTArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_WAFERLISTArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_WAFERLISTArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_WAFERLISTArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_WAFERLISTArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_WAFERLISTArray_1& _IDL_SEQ_WAFERLISTArray_1::operator= (const ::_IDL_SEQ_WAFERLISTArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_WAFERLISTArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_WAFERLISTArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_WAFERLISTArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_WAFERLISTArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_WAFERLISTArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_WAFERLISTArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_WAFERLISTArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_WAFERLISTArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_WAFERLISTArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_WAFERLISTArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_WAFERLISTArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_WAFERLISTArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_WAFERLISTArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_WAFERLISTArray_1_var::_IDL_SEQ_WAFERLISTArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_WAFERLISTArray_1_var::_IDL_SEQ_WAFERLISTArray_1_var (::_IDL_SEQ_WAFERLISTArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_WAFERLISTArray_1_var::_IDL_SEQ_WAFERLISTArray_1_var (const ::_IDL_SEQ_WAFERLISTArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_WAFERLISTArray_1 (*(_s._ptr));
    }

_IDL_SEQ_WAFERLISTArray_1_var& _IDL_SEQ_WAFERLISTArray_1_var::operator= (::_IDL_SEQ_WAFERLISTArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_WAFERLISTArray_1_var& _IDL_SEQ_WAFERLISTArray_1_var::operator= (const ::_IDL_SEQ_WAFERLISTArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_WAFERLISTArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_WAFERLISTArray_1_var::~_IDL_SEQ_WAFERLISTArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_WAFERLISTArray_1 * _IDL_SEQ_WAFERLISTArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_WAFERLISTArray_1_var::operator ::_IDL_SEQ_WAFERLISTArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_WAFERLISTArray_1_var::operator ::_IDL_SEQ_WAFERLISTArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_WAFERLISTArray_1_var::operator _IDL_SEQ_WAFERLISTArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_WAFERLISTArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_WAFERLISTArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_WAFERLISTArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_WAFERLISTArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_WAFERLISTArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_WAFERLISTArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_WAFERLISTArray_1& _IDL_SEQ_WAFERLISTArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_WAFERLISTArray_1& _IDL_SEQ_WAFERLISTArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_WAFERLISTArray_1*& _IDL_SEQ_WAFERLISTArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_WAFERLISTArray_1* _IDL_SEQ_WAFERLISTArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_WAFERLISTArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_WAFERLISTArray_1 > _IDL_SEQ_WAFERLISTArray_1::WAFERLISTArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_DCITEMSArray_1::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_DCITEMSArray_1::__stubcode_dependents[] = {::ArrayOfITEM_VALUE::__stubcode_version };
_IDL_SEQ_DCITEMSArray_1::_IDL_SEQ_DCITEMSArray_1()
{
  _defaultInit();
}
_IDL_SEQ_DCITEMSArray_1::_IDL_SEQ_DCITEMSArray_1 (const ::_IDL_SEQ_DCITEMSArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_DCITEMSArray_1::_IDL_SEQ_DCITEMSArray_1 (::CORBA::ULong length, ::ArrayOfITEM_VALUE* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_DCITEMSArray_1::~_IDL_SEQ_DCITEMSArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_DCITEMSArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::ArrayOfITEM_VALUE* _IDL_SEQ_DCITEMSArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::ArrayOfITEM_VALUE*) new ::ArrayOfITEM_VALUE[nelems];
}
::ArrayOfITEM_VALUE* _IDL_SEQ_DCITEMSArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::ArrayOfITEM_VALUE* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_DCITEMSArray_1::freebuf (::ArrayOfITEM_VALUE* _data)
{
  if (_data)
    delete [] (::ArrayOfITEM_VALUE*) _data;
}
void _IDL_SEQ_DCITEMSArray_1::replace ( ::CORBA::ULong length, ::ArrayOfITEM_VALUE* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_DCITEMSArray_1& _IDL_SEQ_DCITEMSArray_1::operator= (const ::_IDL_SEQ_DCITEMSArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_DCITEMSArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::ArrayOfITEM_VALUE* data)
{
  return; // simple elements don't require resetting.
}
void _IDL_SEQ_DCITEMSArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::ArrayOfITEM_VALUE* src, ::ArrayOfITEM_VALUE* tgt)
{
  // Copy elements 
  ::ArrayOfITEM_VALUE* _src = (::ArrayOfITEM_VALUE*) src;
  ::ArrayOfITEM_VALUE* _tgt = (::ArrayOfITEM_VALUE*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_DCITEMSArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_DCITEMSArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_DCITEMSArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::ArrayOfITEM_VALUE* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::ArrayOfITEM_VALUE& _IDL_SEQ_DCITEMSArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return _buffer[i];
}
const ::ArrayOfITEM_VALUE& _IDL_SEQ_DCITEMSArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return ((const ::ArrayOfITEM_VALUE*)_buffer) [i];
}
::CORBA::Boolean _IDL_SEQ_DCITEMSArray_1::release() const 
{ return _release; }
::ArrayOfITEM_VALUE* _IDL_SEQ_DCITEMSArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::ArrayOfITEM_VALUE* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::ArrayOfITEM_VALUE* _IDL_SEQ_DCITEMSArray_1::get_buffer () const
{
    return (const ::ArrayOfITEM_VALUE*) _buffer;
}
void _IDL_SEQ_DCITEMSArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       ::_IDL_SEQ_ArrayOfITEM_VALUE_0 const* _elem =     (::_IDL_SEQ_ArrayOfITEM_VALUE_0*) _buffer;
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
           _elem->encodeOp(_req);
       }
    }
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_DCITEMSArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
      ::_IDL_SEQ_ArrayOfITEM_VALUE_0* _elem = (::_IDL_SEQ_ArrayOfITEM_VALUE_0*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_DCITEMSArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
      ::_IDL_SEQ_ArrayOfITEM_VALUE_0* _elem = (::_IDL_SEQ_ArrayOfITEM_VALUE_0*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeInOutOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_DCITEMSArray_1_var::_IDL_SEQ_DCITEMSArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_DCITEMSArray_1_var::_IDL_SEQ_DCITEMSArray_1_var (::_IDL_SEQ_DCITEMSArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_DCITEMSArray_1_var::_IDL_SEQ_DCITEMSArray_1_var (const ::_IDL_SEQ_DCITEMSArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_DCITEMSArray_1 (*(_s._ptr));
    }

_IDL_SEQ_DCITEMSArray_1_var& _IDL_SEQ_DCITEMSArray_1_var::operator= (::_IDL_SEQ_DCITEMSArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_DCITEMSArray_1_var& _IDL_SEQ_DCITEMSArray_1_var::operator= (const ::_IDL_SEQ_DCITEMSArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_DCITEMSArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_DCITEMSArray_1_var::~_IDL_SEQ_DCITEMSArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_DCITEMSArray_1 * _IDL_SEQ_DCITEMSArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_DCITEMSArray_1_var::operator ::_IDL_SEQ_DCITEMSArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_DCITEMSArray_1_var::operator ::_IDL_SEQ_DCITEMSArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_DCITEMSArray_1_var::operator _IDL_SEQ_DCITEMSArray_1() const
{
   return *_ptr;
}
const ::ArrayOfITEM_VALUE& _IDL_SEQ_DCITEMSArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_DCITEMSArray_1 *)_ptr)[index];
}
::ArrayOfITEM_VALUE& _IDL_SEQ_DCITEMSArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::ArrayOfITEM_VALUE& _IDL_SEQ_DCITEMSArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_DCITEMSArray_1 *)_ptr)[index];
}
::ArrayOfITEM_VALUE& _IDL_SEQ_DCITEMSArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_DCITEMSArray_1& _IDL_SEQ_DCITEMSArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_DCITEMSArray_1& _IDL_SEQ_DCITEMSArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_DCITEMSArray_1*& _IDL_SEQ_DCITEMSArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_DCITEMSArray_1* _IDL_SEQ_DCITEMSArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_DCITEMSArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_DCITEMSArray_1 > _IDL_SEQ_DCITEMSArray_1::DCITEMSArray_1_Info;

void Met_Reticle::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("RETICLEID");
    RETICLEID.encodeOp(_req);
    _req.setVarName("WAFERLIST");
    WAFERLIST.encodeOp(_req);
    _req.setVarName("DCITEMS");
    DCITEMS.encodeOp(_req);
    _req.encodeEndStructure();
}

void Met_Reticle::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("RETICLEID");
    RETICLEID.decodeOp(_req);
    _req.setVarName("WAFERLIST");
    WAFERLIST.decodeOp(_req);
    _req.setVarName("DCITEMS");
    DCITEMS.decodeOp(_req);
    _req.decodeEndStructure();
}

void Met_Reticle::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("RETICLEID");
    RETICLEID.decodeInOutOp(_req);
    _req.setVarName("WAFERLIST");
    WAFERLIST.decodeInOutOp(_req);
    _req.setVarName("DCITEMS");
    DCITEMS.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 Met_Reticle::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 Met_Reticle::__stubcode_dependents[] = {::DCITEMSArray::__stubcode_version,::WAFERLISTArray::__stubcode_version,::RETICLEIDArray::__stubcode_version};
Met_Reticle::Met_Reticle()
{
}
Met_Reticle::Met_Reticle( const ::Met_Reticle &EB_s )
{
    operator=( EB_s );
}
Met_Reticle& Met_Reticle::operator=( const ::Met_Reticle &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   RETICLEID = EB_s.RETICLEID;
   WAFERLIST = EB_s.WAFERLIST;
   DCITEMS = EB_s.DCITEMS;
   return *this;
}
Met_Reticle_var::Met_Reticle_var () {
   _ptr = 0;
}
Met_Reticle_var::Met_Reticle_var (::Met_Reticle*_p) {
   _ptr = _p;
}
Met_Reticle_var::Met_Reticle_var (const ::Met_Reticle_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::Met_Reticle ();
   *(_ptr) = *(_s._ptr);
}
Met_Reticle_var& Met_Reticle_var::operator= (::Met_Reticle *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

Met_Reticle_var& Met_Reticle_var::operator= (const ::Met_Reticle_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::Met_Reticle ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

Met_Reticle_var::~Met_Reticle_var () {
   delete _ptr;
}

::Met_Reticle * Met_Reticle_var::operator-> ()
{ return _ptr; }

Met_Reticle_var::operator ::Met_Reticle_cvPtr () const 
{ return _ptr;}

Met_Reticle_var::operator ::Met_Reticle_vPtr& () 
{ return _ptr;}

Met_Reticle_var::operator const ::Met_Reticle& () const 
{ return *_ptr;}

Met_Reticle_var::operator ::Met_Reticle& () 
{ return *_ptr;}

const ::Met_Reticle& Met_Reticle_var::in () const { return *_ptr; }
::Met_Reticle& Met_Reticle_var::inout () { return *_ptr; }
::Met_Reticle*& Met_Reticle_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::Met_Reticle* Met_Reticle_var::_retn () {
  // yield ownership 
  Met_Reticle* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::Met_Reticle > Met_Reticle::Met_Reticle_Info;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_ArrayOfMet_Reticle_0::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_ArrayOfMet_Reticle_0::__stubcode_dependents[] = {::Met_Reticle::__stubcode_version };
_IDL_SEQ_ArrayOfMet_Reticle_0::_IDL_SEQ_ArrayOfMet_Reticle_0()
{
  _defaultInit();
}
_IDL_SEQ_ArrayOfMet_Reticle_0::_IDL_SEQ_ArrayOfMet_Reticle_0 (const ::_IDL_SEQ_ArrayOfMet_Reticle_0& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_ArrayOfMet_Reticle_0::_IDL_SEQ_ArrayOfMet_Reticle_0 (::CORBA::ULong max, ::CORBA::ULong length, ::Met_Reticle* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
  _maximum = max;
}
_IDL_SEQ_ArrayOfMet_Reticle_0::_IDL_SEQ_ArrayOfMet_Reticle_0 (::CORBA::ULong max)
{
  _defaultInit();
  _maximum = max;
  if (_maximum > 0)
    _buffer = allocbuf_throw (max);
}
_IDL_SEQ_ArrayOfMet_Reticle_0::~_IDL_SEQ_ArrayOfMet_Reticle_0 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_ArrayOfMet_Reticle_0::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer  = NULL;
  _maximum = 0;
}
::Met_Reticle* _IDL_SEQ_ArrayOfMet_Reticle_0::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  // Allocate an array of the element type (which may be a
  // self managed StructElem)
#ifdef SIVIEW_EBROKER
  ::Met_Reticle* _ret;
  ::CORBA::ULong alloc_len = sizeof(::Met_Reticle) * nelems + sizeof(::CORBA::ULong);
  ::CORBA::ULong * tmp = (::CORBA::ULong *)malloc( alloc_len );
  if( tmp )
  {
    memset( tmp, 0, alloc_len );
    *tmp = nelems;
    tmp++;
    _ret = (::Met_Reticle*)tmp;
    for( CORBA::ULong _index = 0; _index < nelems; _index++ )
    {
      (void)new ((void*)( _ret + _index)) ::Met_Reticle;
    }
  }
  return _ret;
#else
  return (::Met_Reticle*) new ::Met_Reticle[nelems];
#endif
}
::Met_Reticle* _IDL_SEQ_ArrayOfMet_Reticle_0::allocbuf_throw (::CORBA::ULong nelems)
{
  ::Met_Reticle* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_ArrayOfMet_Reticle_0::freebuf (::Met_Reticle* _data)
{
#ifdef SIVIEW_EBROKER
  if (_data)
  {
    ::CORBA::ULong * tmp = (CORBA::ULong *)_data;
    tmp--;
    for( CORBA::ULong _index = *tmp; _index; _index-- )
    {
    #ifdef _WIN32
      _data[ _index - 1 ].~Met_Reticle ();
    #else
      _data[ _index - 1 ].::Met_Reticle::~Met_Reticle ();
    #endif
    }
    free(tmp);
  }
#else
  if (_data)
    delete [] (::Met_Reticle*) _data;
#endif
}
void _IDL_SEQ_ArrayOfMet_Reticle_0::replace (::CORBA::ULong max,  ::CORBA::ULong length, ::Met_Reticle* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
  _maximum = max;
}
::_IDL_SEQ_ArrayOfMet_Reticle_0& _IDL_SEQ_ArrayOfMet_Reticle_0::operator= (const ::_IDL_SEQ_ArrayOfMet_Reticle_0& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  _maximum = max;
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_ArrayOfMet_Reticle_0::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::Met_Reticle* data)
{
  return; // simple elements don't require resetting.
}
void _IDL_SEQ_ArrayOfMet_Reticle_0::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::Met_Reticle* src, ::Met_Reticle* tgt)
{
  // Copy elements 
  ::Met_Reticle* _src = (::Met_Reticle*) src;
  ::Met_Reticle* _tgt = (::Met_Reticle*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_ArrayOfMet_Reticle_0::maximum () const
{
  return   _maximum;
;
}
::CORBA::ULong _IDL_SEQ_ArrayOfMet_Reticle_0::length () const
{
  return _length;
}
void _IDL_SEQ_ArrayOfMet_Reticle_0::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  ::Met_Reticle* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace(max, len, newBuffer, 1);
  return;
}
::Met_Reticle& _IDL_SEQ_ArrayOfMet_Reticle_0::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return _buffer[i];
}
const ::Met_Reticle& _IDL_SEQ_ArrayOfMet_Reticle_0::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return ((const ::Met_Reticle*)_buffer) [i];
}
::CORBA::Boolean _IDL_SEQ_ArrayOfMet_Reticle_0::release() const 
{ return _release; }
::Met_Reticle* _IDL_SEQ_ArrayOfMet_Reticle_0::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::Met_Reticle* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::Met_Reticle* _IDL_SEQ_ArrayOfMet_Reticle_0::get_buffer () const
{
    return (const ::Met_Reticle*) _buffer;
}
void _IDL_SEQ_ArrayOfMet_Reticle_0::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       ::Met_Reticle const* _elem =     (::Met_Reticle*) _buffer;
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
           _elem->encodeOp(_req);
       }
    }
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_ArrayOfMet_Reticle_0::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
      ::Met_Reticle* _elem = (::Met_Reticle*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_ArrayOfMet_Reticle_0::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(max,__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
      ::Met_Reticle* _elem = (::Met_Reticle*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeInOutOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_ArrayOfMet_Reticle_0_var::_IDL_SEQ_ArrayOfMet_Reticle_0_var () {
   _ptr = 0;
    }

_IDL_SEQ_ArrayOfMet_Reticle_0_var::_IDL_SEQ_ArrayOfMet_Reticle_0_var (::_IDL_SEQ_ArrayOfMet_Reticle_0 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_ArrayOfMet_Reticle_0_var::_IDL_SEQ_ArrayOfMet_Reticle_0_var (const ::_IDL_SEQ_ArrayOfMet_Reticle_0_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_ArrayOfMet_Reticle_0 (*(_s._ptr));
    }

_IDL_SEQ_ArrayOfMet_Reticle_0_var& _IDL_SEQ_ArrayOfMet_Reticle_0_var::operator= (::_IDL_SEQ_ArrayOfMet_Reticle_0 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_ArrayOfMet_Reticle_0_var& _IDL_SEQ_ArrayOfMet_Reticle_0_var::operator= (const ::_IDL_SEQ_ArrayOfMet_Reticle_0_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_ArrayOfMet_Reticle_0 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_ArrayOfMet_Reticle_0_var::~_IDL_SEQ_ArrayOfMet_Reticle_0_var()
{
   delete _ptr;
}
::_IDL_SEQ_ArrayOfMet_Reticle_0 * _IDL_SEQ_ArrayOfMet_Reticle_0_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_ArrayOfMet_Reticle_0_var::operator ::_IDL_SEQ_ArrayOfMet_Reticle_0_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_ArrayOfMet_Reticle_0_var::operator ::_IDL_SEQ_ArrayOfMet_Reticle_0_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_ArrayOfMet_Reticle_0_var::operator _IDL_SEQ_ArrayOfMet_Reticle_0() const
{
   return *_ptr;
}
const ::Met_Reticle& _IDL_SEQ_ArrayOfMet_Reticle_0_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_ArrayOfMet_Reticle_0 *)_ptr)[index];
}
::Met_Reticle& _IDL_SEQ_ArrayOfMet_Reticle_0_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::Met_Reticle& _IDL_SEQ_ArrayOfMet_Reticle_0_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_ArrayOfMet_Reticle_0 *)_ptr)[index];
}
::Met_Reticle& _IDL_SEQ_ArrayOfMet_Reticle_0_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_ArrayOfMet_Reticle_0& _IDL_SEQ_ArrayOfMet_Reticle_0_var::in () const { return *_ptr; }
::_IDL_SEQ_ArrayOfMet_Reticle_0& _IDL_SEQ_ArrayOfMet_Reticle_0_var::inout () { return *_ptr; }
::_IDL_SEQ_ArrayOfMet_Reticle_0*& _IDL_SEQ_ArrayOfMet_Reticle_0_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_ArrayOfMet_Reticle_0* _IDL_SEQ_ArrayOfMet_Reticle_0_var::_retn () {
  // yield ownership 
  _IDL_SEQ_ArrayOfMet_Reticle_0* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_ArrayOfMet_Reticle_0 > _IDL_SEQ_ArrayOfMet_Reticle_0::ArrayOfMet_Reticle_0_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_RETICLESArray_1::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_RETICLESArray_1::__stubcode_dependents[] = {::ArrayOfMet_Reticle::__stubcode_version };
_IDL_SEQ_RETICLESArray_1::_IDL_SEQ_RETICLESArray_1()
{
  _defaultInit();
}
_IDL_SEQ_RETICLESArray_1::_IDL_SEQ_RETICLESArray_1 (const ::_IDL_SEQ_RETICLESArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_RETICLESArray_1::_IDL_SEQ_RETICLESArray_1 (::CORBA::ULong length, ::ArrayOfMet_Reticle* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_RETICLESArray_1::~_IDL_SEQ_RETICLESArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_RETICLESArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::ArrayOfMet_Reticle* _IDL_SEQ_RETICLESArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::ArrayOfMet_Reticle*) new ::ArrayOfMet_Reticle[nelems];
}
::ArrayOfMet_Reticle* _IDL_SEQ_RETICLESArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::ArrayOfMet_Reticle* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_RETICLESArray_1::freebuf (::ArrayOfMet_Reticle* _data)
{
  if (_data)
    delete [] (::ArrayOfMet_Reticle*) _data;
}
void _IDL_SEQ_RETICLESArray_1::replace ( ::CORBA::ULong length, ::ArrayOfMet_Reticle* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_RETICLESArray_1& _IDL_SEQ_RETICLESArray_1::operator= (const ::_IDL_SEQ_RETICLESArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_RETICLESArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::ArrayOfMet_Reticle* data)
{
  return; // simple elements don't require resetting.
}
void _IDL_SEQ_RETICLESArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::ArrayOfMet_Reticle* src, ::ArrayOfMet_Reticle* tgt)
{
  // Copy elements 
  ::ArrayOfMet_Reticle* _src = (::ArrayOfMet_Reticle*) src;
  ::ArrayOfMet_Reticle* _tgt = (::ArrayOfMet_Reticle*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_RETICLESArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_RETICLESArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_RETICLESArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::ArrayOfMet_Reticle* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::ArrayOfMet_Reticle& _IDL_SEQ_RETICLESArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return _buffer[i];
}
const ::ArrayOfMet_Reticle& _IDL_SEQ_RETICLESArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return ((const ::ArrayOfMet_Reticle*)_buffer) [i];
}
::CORBA::Boolean _IDL_SEQ_RETICLESArray_1::release() const 
{ return _release; }
::ArrayOfMet_Reticle* _IDL_SEQ_RETICLESArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::ArrayOfMet_Reticle* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::ArrayOfMet_Reticle* _IDL_SEQ_RETICLESArray_1::get_buffer () const
{
    return (const ::ArrayOfMet_Reticle*) _buffer;
}
void _IDL_SEQ_RETICLESArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       ::_IDL_SEQ_ArrayOfMet_Reticle_0 const* _elem =     (::_IDL_SEQ_ArrayOfMet_Reticle_0*) _buffer;
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
           _elem->encodeOp(_req);
       }
    }
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_RETICLESArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
      ::_IDL_SEQ_ArrayOfMet_Reticle_0* _elem = (::_IDL_SEQ_ArrayOfMet_Reticle_0*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_RETICLESArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
      ::_IDL_SEQ_ArrayOfMet_Reticle_0* _elem = (::_IDL_SEQ_ArrayOfMet_Reticle_0*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeInOutOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_RETICLESArray_1_var::_IDL_SEQ_RETICLESArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_RETICLESArray_1_var::_IDL_SEQ_RETICLESArray_1_var (::_IDL_SEQ_RETICLESArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_RETICLESArray_1_var::_IDL_SEQ_RETICLESArray_1_var (const ::_IDL_SEQ_RETICLESArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_RETICLESArray_1 (*(_s._ptr));
    }

_IDL_SEQ_RETICLESArray_1_var& _IDL_SEQ_RETICLESArray_1_var::operator= (::_IDL_SEQ_RETICLESArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_RETICLESArray_1_var& _IDL_SEQ_RETICLESArray_1_var::operator= (const ::_IDL_SEQ_RETICLESArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_RETICLESArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_RETICLESArray_1_var::~_IDL_SEQ_RETICLESArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_RETICLESArray_1 * _IDL_SEQ_RETICLESArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_RETICLESArray_1_var::operator ::_IDL_SEQ_RETICLESArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_RETICLESArray_1_var::operator ::_IDL_SEQ_RETICLESArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_RETICLESArray_1_var::operator _IDL_SEQ_RETICLESArray_1() const
{
   return *_ptr;
}
const ::ArrayOfMet_Reticle& _IDL_SEQ_RETICLESArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_RETICLESArray_1 *)_ptr)[index];
}
::ArrayOfMet_Reticle& _IDL_SEQ_RETICLESArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::ArrayOfMet_Reticle& _IDL_SEQ_RETICLESArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_RETICLESArray_1 *)_ptr)[index];
}
::ArrayOfMet_Reticle& _IDL_SEQ_RETICLESArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_RETICLESArray_1& _IDL_SEQ_RETICLESArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_RETICLESArray_1& _IDL_SEQ_RETICLESArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_RETICLESArray_1*& _IDL_SEQ_RETICLESArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_RETICLESArray_1* _IDL_SEQ_RETICLESArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_RETICLESArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_RETICLESArray_1 > _IDL_SEQ_RETICLESArray_1::RETICLESArray_1_Info;

void Innotron_Met_Request::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("APC_CONTEXT");
    APC_CONTEXT.encodeOp(_req);
    _req.setVarName("RETICLES");
    RETICLES.encodeOp(_req);
    _req.encodeEndStructure();
}

void Innotron_Met_Request::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("APC_CONTEXT");
    APC_CONTEXT.decodeOp(_req);
    _req.setVarName("RETICLES");
    RETICLES.decodeOp(_req);
    _req.decodeEndStructure();
}

void Innotron_Met_Request::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("APC_CONTEXT");
    APC_CONTEXT.decodeInOutOp(_req);
    _req.setVarName("RETICLES");
    RETICLES.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 Innotron_Met_Request::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 Innotron_Met_Request::__stubcode_dependents[] = {::Innotron_Met_APC_CONTEXT::__stubcode_version,::RETICLESArray::__stubcode_version};
Innotron_Met_Request::Innotron_Met_Request()
{
}
Innotron_Met_Request::Innotron_Met_Request( const ::Innotron_Met_Request &EB_s )
{
    operator=( EB_s );
}
Innotron_Met_Request& Innotron_Met_Request::operator=( const ::Innotron_Met_Request &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   APC_CONTEXT = EB_s.APC_CONTEXT;
   RETICLES = EB_s.RETICLES;
   return *this;
}
Innotron_Met_Request_var::Innotron_Met_Request_var () {
   _ptr = 0;
}
Innotron_Met_Request_var::Innotron_Met_Request_var (::Innotron_Met_Request*_p) {
   _ptr = _p;
}
Innotron_Met_Request_var::Innotron_Met_Request_var (const ::Innotron_Met_Request_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::Innotron_Met_Request ();
   *(_ptr) = *(_s._ptr);
}
Innotron_Met_Request_var& Innotron_Met_Request_var::operator= (::Innotron_Met_Request *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

Innotron_Met_Request_var& Innotron_Met_Request_var::operator= (const ::Innotron_Met_Request_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::Innotron_Met_Request ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

Innotron_Met_Request_var::~Innotron_Met_Request_var () {
   delete _ptr;
}

::Innotron_Met_Request * Innotron_Met_Request_var::operator-> ()
{ return _ptr; }

Innotron_Met_Request_var::operator ::Innotron_Met_Request_cvPtr () const 
{ return _ptr;}

Innotron_Met_Request_var::operator ::Innotron_Met_Request_vPtr& () 
{ return _ptr;}

Innotron_Met_Request_var::operator const ::Innotron_Met_Request& () const 
{ return *_ptr;}

Innotron_Met_Request_var::operator ::Innotron_Met_Request& () 
{ return *_ptr;}

const ::Innotron_Met_Request& Innotron_Met_Request_var::in () const { return *_ptr; }
::Innotron_Met_Request& Innotron_Met_Request_var::inout () { return *_ptr; }
::Innotron_Met_Request*& Innotron_Met_Request_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::Innotron_Met_Request* Innotron_Met_Request_var::_retn () {
  // yield ownership 
  Innotron_Met_Request* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::Innotron_Met_Request > Innotron_Met_Request::Innotron_Met_Request_Info;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_ArrayOfLOT_0::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_ArrayOfLOT_0::__stubcode_dependents[] = {::LOT::__stubcode_version };
_IDL_SEQ_ArrayOfLOT_0::_IDL_SEQ_ArrayOfLOT_0()
{
  _defaultInit();
}
_IDL_SEQ_ArrayOfLOT_0::_IDL_SEQ_ArrayOfLOT_0 (const ::_IDL_SEQ_ArrayOfLOT_0& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_ArrayOfLOT_0::_IDL_SEQ_ArrayOfLOT_0 (::CORBA::ULong max, ::CORBA::ULong length, ::LOT* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
  _maximum = max;
}
_IDL_SEQ_ArrayOfLOT_0::_IDL_SEQ_ArrayOfLOT_0 (::CORBA::ULong max)
{
  _defaultInit();
  _maximum = max;
  if (_maximum > 0)
    _buffer = allocbuf_throw (max);
}
_IDL_SEQ_ArrayOfLOT_0::~_IDL_SEQ_ArrayOfLOT_0 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_ArrayOfLOT_0::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer  = NULL;
  _maximum = 0;
}
::LOT* _IDL_SEQ_ArrayOfLOT_0::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  // Allocate an array of the element type (which may be a
  // self managed StructElem)
#ifdef SIVIEW_EBROKER
  ::LOT* _ret;
  ::CORBA::ULong alloc_len = sizeof(::LOT) * nelems + sizeof(::CORBA::ULong);
  ::CORBA::ULong * tmp = (::CORBA::ULong *)malloc( alloc_len );
  if( tmp )
  {
    memset( tmp, 0, alloc_len );
    *tmp = nelems;
    tmp++;
    _ret = (::LOT*)tmp;
    for( CORBA::ULong _index = 0; _index < nelems; _index++ )
    {
      (void)new ((void*)( _ret + _index)) ::LOT;
    }
  }
  return _ret;
#else
  return (::LOT*) new ::LOT[nelems];
#endif
}
::LOT* _IDL_SEQ_ArrayOfLOT_0::allocbuf_throw (::CORBA::ULong nelems)
{
  ::LOT* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_ArrayOfLOT_0::freebuf (::LOT* _data)
{
#ifdef SIVIEW_EBROKER
  if (_data)
  {
    ::CORBA::ULong * tmp = (CORBA::ULong *)_data;
    tmp--;
    for( CORBA::ULong _index = *tmp; _index; _index-- )
    {
    #ifdef _WIN32
      _data[ _index - 1 ].~LOT ();
    #else
      _data[ _index - 1 ].::LOT::~LOT ();
    #endif
    }
    free(tmp);
  }
#else
  if (_data)
    delete [] (::LOT*) _data;
#endif
}
void _IDL_SEQ_ArrayOfLOT_0::replace (::CORBA::ULong max,  ::CORBA::ULong length, ::LOT* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
  _maximum = max;
}
::_IDL_SEQ_ArrayOfLOT_0& _IDL_SEQ_ArrayOfLOT_0::operator= (const ::_IDL_SEQ_ArrayOfLOT_0& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  _maximum = max;
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_ArrayOfLOT_0::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::LOT* data)
{
  return; // simple elements don't require resetting.
}
void _IDL_SEQ_ArrayOfLOT_0::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::LOT* src, ::LOT* tgt)
{
  // Copy elements 
  ::LOT* _src = (::LOT*) src;
  ::LOT* _tgt = (::LOT*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_ArrayOfLOT_0::maximum () const
{
  return   _maximum;
;
}
::CORBA::ULong _IDL_SEQ_ArrayOfLOT_0::length () const
{
  return _length;
}
void _IDL_SEQ_ArrayOfLOT_0::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  ::LOT* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace(max, len, newBuffer, 1);
  return;
}
::LOT& _IDL_SEQ_ArrayOfLOT_0::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return _buffer[i];
}
const ::LOT& _IDL_SEQ_ArrayOfLOT_0::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return ((const ::LOT*)_buffer) [i];
}
::CORBA::Boolean _IDL_SEQ_ArrayOfLOT_0::release() const 
{ return _release; }
::LOT* _IDL_SEQ_ArrayOfLOT_0::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::LOT* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::LOT* _IDL_SEQ_ArrayOfLOT_0::get_buffer () const
{
    return (const ::LOT*) _buffer;
}
void _IDL_SEQ_ArrayOfLOT_0::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       ::LOT const* _elem =     (::LOT*) _buffer;
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
           _elem->encodeOp(_req);
       }
    }
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_ArrayOfLOT_0::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
      ::LOT* _elem = (::LOT*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_ArrayOfLOT_0::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(max,__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
      ::LOT* _elem = (::LOT*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeInOutOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_ArrayOfLOT_0_var::_IDL_SEQ_ArrayOfLOT_0_var () {
   _ptr = 0;
    }

_IDL_SEQ_ArrayOfLOT_0_var::_IDL_SEQ_ArrayOfLOT_0_var (::_IDL_SEQ_ArrayOfLOT_0 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_ArrayOfLOT_0_var::_IDL_SEQ_ArrayOfLOT_0_var (const ::_IDL_SEQ_ArrayOfLOT_0_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_ArrayOfLOT_0 (*(_s._ptr));
    }

_IDL_SEQ_ArrayOfLOT_0_var& _IDL_SEQ_ArrayOfLOT_0_var::operator= (::_IDL_SEQ_ArrayOfLOT_0 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_ArrayOfLOT_0_var& _IDL_SEQ_ArrayOfLOT_0_var::operator= (const ::_IDL_SEQ_ArrayOfLOT_0_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_ArrayOfLOT_0 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_ArrayOfLOT_0_var::~_IDL_SEQ_ArrayOfLOT_0_var()
{
   delete _ptr;
}
::_IDL_SEQ_ArrayOfLOT_0 * _IDL_SEQ_ArrayOfLOT_0_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_ArrayOfLOT_0_var::operator ::_IDL_SEQ_ArrayOfLOT_0_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_ArrayOfLOT_0_var::operator ::_IDL_SEQ_ArrayOfLOT_0_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_ArrayOfLOT_0_var::operator _IDL_SEQ_ArrayOfLOT_0() const
{
   return *_ptr;
}
const ::LOT& _IDL_SEQ_ArrayOfLOT_0_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_ArrayOfLOT_0 *)_ptr)[index];
}
::LOT& _IDL_SEQ_ArrayOfLOT_0_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::LOT& _IDL_SEQ_ArrayOfLOT_0_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_ArrayOfLOT_0 *)_ptr)[index];
}
::LOT& _IDL_SEQ_ArrayOfLOT_0_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_ArrayOfLOT_0& _IDL_SEQ_ArrayOfLOT_0_var::in () const { return *_ptr; }
::_IDL_SEQ_ArrayOfLOT_0& _IDL_SEQ_ArrayOfLOT_0_var::inout () { return *_ptr; }
::_IDL_SEQ_ArrayOfLOT_0*& _IDL_SEQ_ArrayOfLOT_0_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_ArrayOfLOT_0* _IDL_SEQ_ArrayOfLOT_0_var::_retn () {
  // yield ownership 
  _IDL_SEQ_ArrayOfLOT_0* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_ArrayOfLOT_0 > _IDL_SEQ_ArrayOfLOT_0::ArrayOfLOT_0_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_LOT_DATAArray_1::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_LOT_DATAArray_1::__stubcode_dependents[] = {::ArrayOfLOT::__stubcode_version };
_IDL_SEQ_LOT_DATAArray_1::_IDL_SEQ_LOT_DATAArray_1()
{
  _defaultInit();
}
_IDL_SEQ_LOT_DATAArray_1::_IDL_SEQ_LOT_DATAArray_1 (const ::_IDL_SEQ_LOT_DATAArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_LOT_DATAArray_1::_IDL_SEQ_LOT_DATAArray_1 (::CORBA::ULong length, ::ArrayOfLOT* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_LOT_DATAArray_1::~_IDL_SEQ_LOT_DATAArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_LOT_DATAArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::ArrayOfLOT* _IDL_SEQ_LOT_DATAArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::ArrayOfLOT*) new ::ArrayOfLOT[nelems];
}
::ArrayOfLOT* _IDL_SEQ_LOT_DATAArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::ArrayOfLOT* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_LOT_DATAArray_1::freebuf (::ArrayOfLOT* _data)
{
  if (_data)
    delete [] (::ArrayOfLOT*) _data;
}
void _IDL_SEQ_LOT_DATAArray_1::replace ( ::CORBA::ULong length, ::ArrayOfLOT* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_LOT_DATAArray_1& _IDL_SEQ_LOT_DATAArray_1::operator= (const ::_IDL_SEQ_LOT_DATAArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_LOT_DATAArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::ArrayOfLOT* data)
{
  return; // simple elements don't require resetting.
}
void _IDL_SEQ_LOT_DATAArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::ArrayOfLOT* src, ::ArrayOfLOT* tgt)
{
  // Copy elements 
  ::ArrayOfLOT* _src = (::ArrayOfLOT*) src;
  ::ArrayOfLOT* _tgt = (::ArrayOfLOT*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_LOT_DATAArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_LOT_DATAArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_LOT_DATAArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::ArrayOfLOT* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::ArrayOfLOT& _IDL_SEQ_LOT_DATAArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return _buffer[i];
}
const ::ArrayOfLOT& _IDL_SEQ_LOT_DATAArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  return ((const ::ArrayOfLOT*)_buffer) [i];
}
::CORBA::Boolean _IDL_SEQ_LOT_DATAArray_1::release() const 
{ return _release; }
::ArrayOfLOT* _IDL_SEQ_LOT_DATAArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::ArrayOfLOT* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::ArrayOfLOT* _IDL_SEQ_LOT_DATAArray_1::get_buffer () const
{
    return (const ::ArrayOfLOT*) _buffer;
}
void _IDL_SEQ_LOT_DATAArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       ::_IDL_SEQ_ArrayOfLOT_0 const* _elem =     (::_IDL_SEQ_ArrayOfLOT_0*) _buffer;
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
           _elem->encodeOp(_req);
       }
    }
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_LOT_DATAArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
      ::_IDL_SEQ_ArrayOfLOT_0* _elem = (::_IDL_SEQ_ArrayOfLOT_0*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_LOT_DATAArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
      ::_IDL_SEQ_ArrayOfLOT_0* _elem = (::_IDL_SEQ_ArrayOfLOT_0*)_buffer;
        for (::CORBA::ULong _i=0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
              _elem->decodeInOutOp(_req);
        }
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_LOT_DATAArray_1_var::_IDL_SEQ_LOT_DATAArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_LOT_DATAArray_1_var::_IDL_SEQ_LOT_DATAArray_1_var (::_IDL_SEQ_LOT_DATAArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_LOT_DATAArray_1_var::_IDL_SEQ_LOT_DATAArray_1_var (const ::_IDL_SEQ_LOT_DATAArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_LOT_DATAArray_1 (*(_s._ptr));
    }

_IDL_SEQ_LOT_DATAArray_1_var& _IDL_SEQ_LOT_DATAArray_1_var::operator= (::_IDL_SEQ_LOT_DATAArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_LOT_DATAArray_1_var& _IDL_SEQ_LOT_DATAArray_1_var::operator= (const ::_IDL_SEQ_LOT_DATAArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_LOT_DATAArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_LOT_DATAArray_1_var::~_IDL_SEQ_LOT_DATAArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_LOT_DATAArray_1 * _IDL_SEQ_LOT_DATAArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_LOT_DATAArray_1_var::operator ::_IDL_SEQ_LOT_DATAArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_LOT_DATAArray_1_var::operator ::_IDL_SEQ_LOT_DATAArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_LOT_DATAArray_1_var::operator _IDL_SEQ_LOT_DATAArray_1() const
{
   return *_ptr;
}
const ::ArrayOfLOT& _IDL_SEQ_LOT_DATAArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_LOT_DATAArray_1 *)_ptr)[index];
}
::ArrayOfLOT& _IDL_SEQ_LOT_DATAArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::ArrayOfLOT& _IDL_SEQ_LOT_DATAArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_LOT_DATAArray_1 *)_ptr)[index];
}
::ArrayOfLOT& _IDL_SEQ_LOT_DATAArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_LOT_DATAArray_1& _IDL_SEQ_LOT_DATAArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_LOT_DATAArray_1& _IDL_SEQ_LOT_DATAArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_LOT_DATAArray_1*& _IDL_SEQ_LOT_DATAArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_LOT_DATAArray_1* _IDL_SEQ_LOT_DATAArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_LOT_DATAArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_LOT_DATAArray_1 > _IDL_SEQ_LOT_DATAArray_1::LOT_DATAArray_1_Info;

void Innotron_Recomd_Request::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("APC_CONTEXT");
    APC_CONTEXT.encodeOp(_req);
    _req.setVarName("LOT_DATA");
    LOT_DATA.encodeOp(_req);
    _req.encodeEndStructure();
}

void Innotron_Recomd_Request::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("APC_CONTEXT");
    APC_CONTEXT.decodeOp(_req);
    _req.setVarName("LOT_DATA");
    LOT_DATA.decodeOp(_req);
    _req.decodeEndStructure();
}

void Innotron_Recomd_Request::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("APC_CONTEXT");
    APC_CONTEXT.decodeInOutOp(_req);
    _req.setVarName("LOT_DATA");
    LOT_DATA.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 Innotron_Recomd_Request::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 Innotron_Recomd_Request::__stubcode_dependents[] = {::Innotron_Rec_APC_CONTEXT::__stubcode_version,::LOT_DATAArray::__stubcode_version};
Innotron_Recomd_Request::Innotron_Recomd_Request()
{
}
Innotron_Recomd_Request::Innotron_Recomd_Request( const ::Innotron_Recomd_Request &EB_s )
{
    operator=( EB_s );
}
Innotron_Recomd_Request& Innotron_Recomd_Request::operator=( const ::Innotron_Recomd_Request &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   APC_CONTEXT = EB_s.APC_CONTEXT;
   LOT_DATA = EB_s.LOT_DATA;
   return *this;
}
Innotron_Recomd_Request_var::Innotron_Recomd_Request_var () {
   _ptr = 0;
}
Innotron_Recomd_Request_var::Innotron_Recomd_Request_var (::Innotron_Recomd_Request*_p) {
   _ptr = _p;
}
Innotron_Recomd_Request_var::Innotron_Recomd_Request_var (const ::Innotron_Recomd_Request_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::Innotron_Recomd_Request ();
   *(_ptr) = *(_s._ptr);
}
Innotron_Recomd_Request_var& Innotron_Recomd_Request_var::operator= (::Innotron_Recomd_Request *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

Innotron_Recomd_Request_var& Innotron_Recomd_Request_var::operator= (const ::Innotron_Recomd_Request_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::Innotron_Recomd_Request ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

Innotron_Recomd_Request_var::~Innotron_Recomd_Request_var () {
   delete _ptr;
}

::Innotron_Recomd_Request * Innotron_Recomd_Request_var::operator-> ()
{ return _ptr; }

Innotron_Recomd_Request_var::operator ::Innotron_Recomd_Request_cvPtr () const 
{ return _ptr;}

Innotron_Recomd_Request_var::operator ::Innotron_Recomd_Request_vPtr& () 
{ return _ptr;}

Innotron_Recomd_Request_var::operator const ::Innotron_Recomd_Request& () const 
{ return *_ptr;}

Innotron_Recomd_Request_var::operator ::Innotron_Recomd_Request& () 
{ return *_ptr;}

const ::Innotron_Recomd_Request& Innotron_Recomd_Request_var::in () const { return *_ptr; }
::Innotron_Recomd_Request& Innotron_Recomd_Request_var::inout () { return *_ptr; }
::Innotron_Recomd_Request*& Innotron_Recomd_Request_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::Innotron_Recomd_Request* Innotron_Recomd_Request_var::_retn () {
  // yield ownership 
  Innotron_Recomd_Request* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::Innotron_Recomd_Request > Innotron_Recomd_Request::Innotron_Recomd_Request_Info;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_REC_TRANSACTIONIDArray_1::__stubcode_version;
_IDL_SEQ_REC_TRANSACTIONIDArray_1::_IDL_SEQ_REC_TRANSACTIONIDArray_1()
{
  _defaultInit();
}
_IDL_SEQ_REC_TRANSACTIONIDArray_1::_IDL_SEQ_REC_TRANSACTIONIDArray_1 (const ::_IDL_SEQ_REC_TRANSACTIONIDArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_REC_TRANSACTIONIDArray_1::_IDL_SEQ_REC_TRANSACTIONIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_REC_TRANSACTIONIDArray_1::~_IDL_SEQ_REC_TRANSACTIONIDArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_REC_TRANSACTIONIDArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_REC_TRANSACTIONIDArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_REC_TRANSACTIONIDArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_REC_TRANSACTIONIDArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_REC_TRANSACTIONIDArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_REC_TRANSACTIONIDArray_1& _IDL_SEQ_REC_TRANSACTIONIDArray_1::operator= (const ::_IDL_SEQ_REC_TRANSACTIONIDArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_REC_TRANSACTIONIDArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_REC_TRANSACTIONIDArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_REC_TRANSACTIONIDArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_REC_TRANSACTIONIDArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_REC_TRANSACTIONIDArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_REC_TRANSACTIONIDArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_REC_TRANSACTIONIDArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_REC_TRANSACTIONIDArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_REC_TRANSACTIONIDArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_REC_TRANSACTIONIDArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_REC_TRANSACTIONIDArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_REC_TRANSACTIONIDArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_REC_TRANSACTIONIDArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_REC_TRANSACTIONIDArray_1_var::_IDL_SEQ_REC_TRANSACTIONIDArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_REC_TRANSACTIONIDArray_1_var::_IDL_SEQ_REC_TRANSACTIONIDArray_1_var (::_IDL_SEQ_REC_TRANSACTIONIDArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_REC_TRANSACTIONIDArray_1_var::_IDL_SEQ_REC_TRANSACTIONIDArray_1_var (const ::_IDL_SEQ_REC_TRANSACTIONIDArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_REC_TRANSACTIONIDArray_1 (*(_s._ptr));
    }

_IDL_SEQ_REC_TRANSACTIONIDArray_1_var& _IDL_SEQ_REC_TRANSACTIONIDArray_1_var::operator= (::_IDL_SEQ_REC_TRANSACTIONIDArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_REC_TRANSACTIONIDArray_1_var& _IDL_SEQ_REC_TRANSACTIONIDArray_1_var::operator= (const ::_IDL_SEQ_REC_TRANSACTIONIDArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_REC_TRANSACTIONIDArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_REC_TRANSACTIONIDArray_1_var::~_IDL_SEQ_REC_TRANSACTIONIDArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_REC_TRANSACTIONIDArray_1 * _IDL_SEQ_REC_TRANSACTIONIDArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_REC_TRANSACTIONIDArray_1_var::operator ::_IDL_SEQ_REC_TRANSACTIONIDArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_REC_TRANSACTIONIDArray_1_var::operator ::_IDL_SEQ_REC_TRANSACTIONIDArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_REC_TRANSACTIONIDArray_1_var::operator _IDL_SEQ_REC_TRANSACTIONIDArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_REC_TRANSACTIONIDArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_REC_TRANSACTIONIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_REC_TRANSACTIONIDArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_REC_TRANSACTIONIDArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_REC_TRANSACTIONIDArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_REC_TRANSACTIONIDArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_REC_TRANSACTIONIDArray_1& _IDL_SEQ_REC_TRANSACTIONIDArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_REC_TRANSACTIONIDArray_1& _IDL_SEQ_REC_TRANSACTIONIDArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_REC_TRANSACTIONIDArray_1*& _IDL_SEQ_REC_TRANSACTIONIDArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_REC_TRANSACTIONIDArray_1* _IDL_SEQ_REC_TRANSACTIONIDArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_REC_TRANSACTIONIDArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_REC_TRANSACTIONIDArray_1 > _IDL_SEQ_REC_TRANSACTIONIDArray_1::REC_TRANSACTIONIDArray_1_Info;

void Innotron_Used_APC_CONTEXT::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("CONTROLJOBTYPE");
    CONTROLJOBTYPE.encodeOp(_req);
    _req.setVarName("TRANSACTIONID");
    TRANSACTIONID.encodeOp(_req);
    _req.setVarName("REC_TRANSACTIONID");
    REC_TRANSACTIONID.encodeOp(_req);
    _req.setVarName("LOTID");
    LOTID.encodeOp(_req);
    _req.setVarName("LOTTYPE");
    LOTTYPE.encodeOp(_req);
    _req.setVarName("PARTID");
    PARTID.encodeOp(_req);
    _req.setVarName("LAYER");
    LAYER.encodeOp(_req);
    _req.setVarName("ROUTE");
    ROUTE.encodeOp(_req);
    _req.setVarName("ROUTEGROUP");
    ROUTEGROUP.encodeOp(_req);
    _req.setVarName("OPERATION");
    OPERATION.encodeOp(_req);
    _req.setVarName("RETICLEID");
    RETICLEID.encodeOp(_req);
    _req.setVarName("PROCESSEQUIPTYPE");
    PROCESSEQUIPTYPE.encodeOp(_req);
    _req.setVarName("PROCESSEQUIPID");
    PROCESSEQUIPID.encodeOp(_req);
    _req.setVarName("RECOMMENDMODE");
    RECOMMENDMODE.encodeOp(_req);
    _req.setVarName("REWORK");
    REWORK.encodeOp(_req);
    _req.setVarName("PARENTLOTID");
    PARENTLOTID.encodeOp(_req);
    _req.setVarName("PRETOOL");
    PRETOOL.encodeOp(_req);
    _req.setVarName("SENDAHEAD");
    SENDAHEAD.encodeOp(_req);
    _req.setVarName("SENDAHEADVALUES");
    SENDAHEADVALUES.encodeOp(_req);
    _req.setVarName("AVAILABLE_SUBUNIT");
    AVAILABLE_SUBUNIT.encodeOp(_req);
    _req.setVarName("IS_OPSTART_RECOMD");
    IS_OPSTART_RECOMD.encodeOp(_req);
    _req.setVarName("LD_EXTEND");
    LD_EXTEND.encodeOp(_req);
    _req.encodeEndStructure();
}

void Innotron_Used_APC_CONTEXT::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("CONTROLJOBTYPE");
    CONTROLJOBTYPE.decodeOp(_req);
    _req.setVarName("TRANSACTIONID");
    TRANSACTIONID.decodeOp(_req);
    _req.setVarName("REC_TRANSACTIONID");
    REC_TRANSACTIONID.decodeOp(_req);
    _req.setVarName("LOTID");
    LOTID.decodeOp(_req);
    _req.setVarName("LOTTYPE");
    LOTTYPE.decodeOp(_req);
    _req.setVarName("PARTID");
    PARTID.decodeOp(_req);
    _req.setVarName("LAYER");
    LAYER.decodeOp(_req);
    _req.setVarName("ROUTE");
    ROUTE.decodeOp(_req);
    _req.setVarName("ROUTEGROUP");
    ROUTEGROUP.decodeOp(_req);
    _req.setVarName("OPERATION");
    OPERATION.decodeOp(_req);
    _req.setVarName("RETICLEID");
    RETICLEID.decodeOp(_req);
    _req.setVarName("PROCESSEQUIPTYPE");
    PROCESSEQUIPTYPE.decodeOp(_req);
    _req.setVarName("PROCESSEQUIPID");
    PROCESSEQUIPID.decodeOp(_req);
    _req.setVarName("RECOMMENDMODE");
    RECOMMENDMODE.decodeOp(_req);
    _req.setVarName("REWORK");
    REWORK.decodeOp(_req);
    _req.setVarName("PARENTLOTID");
    PARENTLOTID.decodeOp(_req);
    _req.setVarName("PRETOOL");
    PRETOOL.decodeOp(_req);
    _req.setVarName("SENDAHEAD");
    SENDAHEAD.decodeOp(_req);
    _req.setVarName("SENDAHEADVALUES");
    SENDAHEADVALUES.decodeOp(_req);
    _req.setVarName("AVAILABLE_SUBUNIT");
    AVAILABLE_SUBUNIT.decodeOp(_req);
    _req.setVarName("IS_OPSTART_RECOMD");
    IS_OPSTART_RECOMD.decodeOp(_req);
    _req.setVarName("LD_EXTEND");
    LD_EXTEND.decodeOp(_req);
    _req.decodeEndStructure();
}

void Innotron_Used_APC_CONTEXT::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("CONTROLJOBTYPE");
    CONTROLJOBTYPE.decodeInOutOp(_req);
    _req.setVarName("TRANSACTIONID");
    TRANSACTIONID.decodeInOutOp(_req);
    _req.setVarName("REC_TRANSACTIONID");
    REC_TRANSACTIONID.decodeInOutOp(_req);
    _req.setVarName("LOTID");
    LOTID.decodeInOutOp(_req);
    _req.setVarName("LOTTYPE");
    LOTTYPE.decodeInOutOp(_req);
    _req.setVarName("PARTID");
    PARTID.decodeInOutOp(_req);
    _req.setVarName("LAYER");
    LAYER.decodeInOutOp(_req);
    _req.setVarName("ROUTE");
    ROUTE.decodeInOutOp(_req);
    _req.setVarName("ROUTEGROUP");
    ROUTEGROUP.decodeInOutOp(_req);
    _req.setVarName("OPERATION");
    OPERATION.decodeInOutOp(_req);
    _req.setVarName("RETICLEID");
    RETICLEID.decodeInOutOp(_req);
    _req.setVarName("PROCESSEQUIPTYPE");
    PROCESSEQUIPTYPE.decodeInOutOp(_req);
    _req.setVarName("PROCESSEQUIPID");
    PROCESSEQUIPID.decodeInOutOp(_req);
    _req.setVarName("RECOMMENDMODE");
    RECOMMENDMODE.decodeInOutOp(_req);
    _req.setVarName("REWORK");
    REWORK.decodeInOutOp(_req);
    _req.setVarName("PARENTLOTID");
    PARENTLOTID.decodeInOutOp(_req);
    _req.setVarName("PRETOOL");
    PRETOOL.decodeInOutOp(_req);
    _req.setVarName("SENDAHEAD");
    SENDAHEAD.decodeInOutOp(_req);
    _req.setVarName("SENDAHEADVALUES");
    SENDAHEADVALUES.decodeInOutOp(_req);
    _req.setVarName("AVAILABLE_SUBUNIT");
    AVAILABLE_SUBUNIT.decodeInOutOp(_req);
    _req.setVarName("IS_OPSTART_RECOMD");
    IS_OPSTART_RECOMD.decodeInOutOp(_req);
    _req.setVarName("LD_EXTEND");
    LD_EXTEND.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 Innotron_Used_APC_CONTEXT::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 Innotron_Used_APC_CONTEXT::__stubcode_dependents[] = {::SENDAHEADArray::__stubcode_version,::LD_EXTENDArray::__stubcode_version,::PARTIDArray::__stubcode_version,::LAYERArray::__stubcode_version,::IS_OPSTART_RECOMDArray::__stubcode_version,::PROCESSEQUIPIDArray::__stubcode_version,::REWORKArray::__stubcode_version,::LOTIDArray::__stubcode_version,::RECOMMENDMODEArray::__stubcode_version,::SENDAHEADVALUESArray::__stubcode_version,::PARENTLOTIDArray::__stubcode_version,::PROCESSEQUIPTYPEArray::__stubcode_version,::CONTROLJOBTYPEArray::__stubcode_version,::REC_TRANSACTIONIDArray::__stubcode_version,::OPERATIONArray::__stubcode_version,::RETICLEIDArray::__stubcode_version,::AVAILABLE_SUBUNITArray::__stubcode_version,::ROUTEGROUPArray::__stubcode_version,::ROUTEArray::__stubcode_version,::TRANSACTIONIDArray::__stubcode_version,::LOTTYPEArray::__stubcode_version,::PRETOOLArray::__stubcode_version};
Innotron_Used_APC_CONTEXT::Innotron_Used_APC_CONTEXT()
{
}
Innotron_Used_APC_CONTEXT::Innotron_Used_APC_CONTEXT( const ::Innotron_Used_APC_CONTEXT &EB_s )
{
    operator=( EB_s );
}
Innotron_Used_APC_CONTEXT& Innotron_Used_APC_CONTEXT::operator=( const ::Innotron_Used_APC_CONTEXT &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   CONTROLJOBTYPE = EB_s.CONTROLJOBTYPE;
   TRANSACTIONID = EB_s.TRANSACTIONID;
   REC_TRANSACTIONID = EB_s.REC_TRANSACTIONID;
   LOTID = EB_s.LOTID;
   LOTTYPE = EB_s.LOTTYPE;
   PARTID = EB_s.PARTID;
   LAYER = EB_s.LAYER;
   ROUTE = EB_s.ROUTE;
   ROUTEGROUP = EB_s.ROUTEGROUP;
   OPERATION = EB_s.OPERATION;
   RETICLEID = EB_s.RETICLEID;
   PROCESSEQUIPTYPE = EB_s.PROCESSEQUIPTYPE;
   PROCESSEQUIPID = EB_s.PROCESSEQUIPID;
   RECOMMENDMODE = EB_s.RECOMMENDMODE;
   REWORK = EB_s.REWORK;
   PARENTLOTID = EB_s.PARENTLOTID;
   PRETOOL = EB_s.PRETOOL;
   SENDAHEAD = EB_s.SENDAHEAD;
   SENDAHEADVALUES = EB_s.SENDAHEADVALUES;
   AVAILABLE_SUBUNIT = EB_s.AVAILABLE_SUBUNIT;
   IS_OPSTART_RECOMD = EB_s.IS_OPSTART_RECOMD;
   LD_EXTEND = EB_s.LD_EXTEND;
   return *this;
}
Innotron_Used_APC_CONTEXT_var::Innotron_Used_APC_CONTEXT_var () {
   _ptr = 0;
}
Innotron_Used_APC_CONTEXT_var::Innotron_Used_APC_CONTEXT_var (::Innotron_Used_APC_CONTEXT*_p) {
   _ptr = _p;
}
Innotron_Used_APC_CONTEXT_var::Innotron_Used_APC_CONTEXT_var (const ::Innotron_Used_APC_CONTEXT_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::Innotron_Used_APC_CONTEXT ();
   *(_ptr) = *(_s._ptr);
}
Innotron_Used_APC_CONTEXT_var& Innotron_Used_APC_CONTEXT_var::operator= (::Innotron_Used_APC_CONTEXT *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

Innotron_Used_APC_CONTEXT_var& Innotron_Used_APC_CONTEXT_var::operator= (const ::Innotron_Used_APC_CONTEXT_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::Innotron_Used_APC_CONTEXT ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

Innotron_Used_APC_CONTEXT_var::~Innotron_Used_APC_CONTEXT_var () {
   delete _ptr;
}

::Innotron_Used_APC_CONTEXT * Innotron_Used_APC_CONTEXT_var::operator-> ()
{ return _ptr; }

Innotron_Used_APC_CONTEXT_var::operator ::Innotron_Used_APC_CONTEXT_cvPtr () const 
{ return _ptr;}

Innotron_Used_APC_CONTEXT_var::operator ::Innotron_Used_APC_CONTEXT_vPtr& () 
{ return _ptr;}

Innotron_Used_APC_CONTEXT_var::operator const ::Innotron_Used_APC_CONTEXT& () const 
{ return *_ptr;}

Innotron_Used_APC_CONTEXT_var::operator ::Innotron_Used_APC_CONTEXT& () 
{ return *_ptr;}

const ::Innotron_Used_APC_CONTEXT& Innotron_Used_APC_CONTEXT_var::in () const { return *_ptr; }
::Innotron_Used_APC_CONTEXT& Innotron_Used_APC_CONTEXT_var::inout () { return *_ptr; }
::Innotron_Used_APC_CONTEXT*& Innotron_Used_APC_CONTEXT_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::Innotron_Used_APC_CONTEXT* Innotron_Used_APC_CONTEXT_var::_retn () {
  // yield ownership 
  Innotron_Used_APC_CONTEXT* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::Innotron_Used_APC_CONTEXT > Innotron_Used_APC_CONTEXT::Innotron_Used_APC_CONTEXT_Info;
const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_STATUSSTRINGArray_1::__stubcode_version;
_IDL_SEQ_STATUSSTRINGArray_1::_IDL_SEQ_STATUSSTRINGArray_1()
{
  _defaultInit();
}
_IDL_SEQ_STATUSSTRINGArray_1::_IDL_SEQ_STATUSSTRINGArray_1 (const ::_IDL_SEQ_STATUSSTRINGArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_STATUSSTRINGArray_1::_IDL_SEQ_STATUSSTRINGArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_STATUSSTRINGArray_1::~_IDL_SEQ_STATUSSTRINGArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_STATUSSTRINGArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_STATUSSTRINGArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_STATUSSTRINGArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_STATUSSTRINGArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_STATUSSTRINGArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_STATUSSTRINGArray_1& _IDL_SEQ_STATUSSTRINGArray_1::operator= (const ::_IDL_SEQ_STATUSSTRINGArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_STATUSSTRINGArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_STATUSSTRINGArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_STATUSSTRINGArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_STATUSSTRINGArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_STATUSSTRINGArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_STATUSSTRINGArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_STATUSSTRINGArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_STATUSSTRINGArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_STATUSSTRINGArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_STATUSSTRINGArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_STATUSSTRINGArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_STATUSSTRINGArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_STATUSSTRINGArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_STATUSSTRINGArray_1_var::_IDL_SEQ_STATUSSTRINGArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_STATUSSTRINGArray_1_var::_IDL_SEQ_STATUSSTRINGArray_1_var (::_IDL_SEQ_STATUSSTRINGArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_STATUSSTRINGArray_1_var::_IDL_SEQ_STATUSSTRINGArray_1_var (const ::_IDL_SEQ_STATUSSTRINGArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_STATUSSTRINGArray_1 (*(_s._ptr));
    }

_IDL_SEQ_STATUSSTRINGArray_1_var& _IDL_SEQ_STATUSSTRINGArray_1_var::operator= (::_IDL_SEQ_STATUSSTRINGArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_STATUSSTRINGArray_1_var& _IDL_SEQ_STATUSSTRINGArray_1_var::operator= (const ::_IDL_SEQ_STATUSSTRINGArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_STATUSSTRINGArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_STATUSSTRINGArray_1_var::~_IDL_SEQ_STATUSSTRINGArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_STATUSSTRINGArray_1 * _IDL_SEQ_STATUSSTRINGArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_STATUSSTRINGArray_1_var::operator ::_IDL_SEQ_STATUSSTRINGArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_STATUSSTRINGArray_1_var::operator ::_IDL_SEQ_STATUSSTRINGArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_STATUSSTRINGArray_1_var::operator _IDL_SEQ_STATUSSTRINGArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_STATUSSTRINGArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_STATUSSTRINGArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_STATUSSTRINGArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_STATUSSTRINGArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_STATUSSTRINGArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_STATUSSTRINGArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_STATUSSTRINGArray_1& _IDL_SEQ_STATUSSTRINGArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_STATUSSTRINGArray_1& _IDL_SEQ_STATUSSTRINGArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_STATUSSTRINGArray_1*& _IDL_SEQ_STATUSSTRINGArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_STATUSSTRINGArray_1* _IDL_SEQ_STATUSSTRINGArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_STATUSSTRINGArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_STATUSSTRINGArray_1 > _IDL_SEQ_STATUSSTRINGArray_1::STATUSSTRINGArray_1_Info;

const ::CORBA::ClassVersionInfo_1_0 _IDL_SEQ_SAHD_REASONArray_1::__stubcode_version;
_IDL_SEQ_SAHD_REASONArray_1::_IDL_SEQ_SAHD_REASONArray_1()
{
  _defaultInit();
}
_IDL_SEQ_SAHD_REASONArray_1::_IDL_SEQ_SAHD_REASONArray_1 (const ::_IDL_SEQ_SAHD_REASONArray_1& s)
{
  _defaultInit();
  operator=(s);
}
_IDL_SEQ_SAHD_REASONArray_1::_IDL_SEQ_SAHD_REASONArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  _release = release;
  _length  = length;
  _buffer  = data;
}
_IDL_SEQ_SAHD_REASONArray_1::~_IDL_SEQ_SAHD_REASONArray_1 ()
{
  if (_buffer && _release)
    // freebuf frees the elements and the buffer
    freebuf (_buffer);
  _buffer = NULL;
}
void _IDL_SEQ_SAHD_REASONArray_1::_defaultInit ()
{
  _release = 1;
  _length  = 0;
  _buffer = allocbuf_throw(maximum());}
::CORBA::String* _IDL_SEQ_SAHD_REASONArray_1::allocbuf (::CORBA::ULong nelems)
{
  if (nelems <= 0)
    return NULL;
  return (::CORBA::String*) new ::CORBA::String_StructElem[nelems];
}
::CORBA::String* _IDL_SEQ_SAHD_REASONArray_1::allocbuf_throw (::CORBA::ULong nelems)
{
  ::CORBA::String* result = allocbuf (nelems);
  if (result != NULL)
    return result;
  ::CORBA::NO_MEMORY exc (SOMDERROR_NoMemory, ::CORBA::COMPLETED_NO);
  throw exc;
  return result;
}
void _IDL_SEQ_SAHD_REASONArray_1::freebuf (::CORBA::String* _data)
{
  if (_data)
    delete [] (::CORBA::String_StructElem*) _data;
}
void _IDL_SEQ_SAHD_REASONArray_1::replace ( ::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release)
{
  if (_release && _buffer != data)
    freebuf(_buffer);
  _buffer  = data;
  _release = release;
  _length  = length;
}
::_IDL_SEQ_SAHD_REASONArray_1& _IDL_SEQ_SAHD_REASONArray_1::operator= (const ::_IDL_SEQ_SAHD_REASONArray_1& s)
{
  // Return if self
  if (this == &s)
    return *this;
  // Get a new buffer if necessary 
  if (!_release || s.maximum() > maximum()) 
  {
    if (_release)
      freebuf(_buffer);
    _buffer = allocbuf_throw(s.maximum());
    _release = 1;
  ::CORBA::ULong max = s.maximum();
  }
  else 
    _resetElements(0, _length, _buffer); 
  _length = s._length;
  // Copy the elements from s.
  _copyElements(0, _length, s._buffer, _buffer);
  return *this;
}
void _IDL_SEQ_SAHD_REASONArray_1::_resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data)
{
  // Reset elements 
  ::CORBA::String_StructElem _blank;
  ::CORBA::String_StructElem* _list = (::CORBA::String_StructElem*) data;
  for (::CORBA::ULong i=start; i<stop; i++)
    _list[i] = _blank;
}
void _IDL_SEQ_SAHD_REASONArray_1::_copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt)
{
  // Copy elements 
  ::CORBA::String_StructElem* _src = (::CORBA::String_StructElem*) src;
  ::CORBA::String_StructElem* _tgt = (::CORBA::String_StructElem*) tgt;
  for (::CORBA::ULong i=start; i<stop; i++)
    _tgt[i] = _src[i];
}
::CORBA::ULong _IDL_SEQ_SAHD_REASONArray_1::maximum () const
{
  return 1;
}
::CORBA::ULong _IDL_SEQ_SAHD_REASONArray_1::length () const
{
  return _length;
}
void _IDL_SEQ_SAHD_REASONArray_1::length (::CORBA::ULong len)
{
  if (len == _length)
    return; 
  else if (len < _length)
  {
    if (_release)
      _resetElements(len, _length, _buffer);
    _length = len;
    return;
  }
  else if (len >= _length && len <= maximum())
  {
    _length = len;
    return;
  }
  if (len > maximum())
    len = maximum();
  ::CORBA::String* newBuffer = allocbuf_throw(len);
  _copyElements(0, _length, _buffer, newBuffer);
  ::CORBA::ULong max = len;
  replace( len, newBuffer, 1);
  return;
}
::CORBA::String_SeqElem _IDL_SEQ_SAHD_REASONArray_1::operator[] (::CORBA::ULong i)
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
const ::CORBA::String_SeqElem _IDL_SEQ_SAHD_REASONArray_1::operator[] (::CORBA::ULong i) const 
{
  __cs_apcstr_initialize();
  if( boundaryCheck_Maximum ){ if( !(i < maximum()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Maximum,i,maximum());} }
  if( boundaryCheck_Length ){ if( !(i < length()) ) { SOMD_BOUNDARY_CHECK_ERROR(boundaryCheck_Length,i,length()); } }
  ::CORBA::String_SeqElem se(_buffer + i, _release);
  return se;
}
::CORBA::Boolean _IDL_SEQ_SAHD_REASONArray_1::release() const 
{ return _release; }
::CORBA::String* _IDL_SEQ_SAHD_REASONArray_1::get_buffer (::CORBA::Boolean orphan)
{
  if (!orphan) 
    // Return the buffer so client can manipulate it. 
    return _buffer;
  else 
  {
    // If sequence does not own the buffer, it cannot yield ownership 
    if (!release())
      return NULL;
    else
    {
      // Yield ownership of buffer and restore status to that of default constructor
      ::CORBA::String* rc = _buffer; 
      _defaultInit();
      return rc;
    }
  }
}
const ::CORBA::String* _IDL_SEQ_SAHD_REASONArray_1::get_buffer () const
{
    return (const ::CORBA::String*) _buffer;
}
void _IDL_SEQ_SAHD_REASONArray_1::encodeOp (::CORBA::Request &_req) const
{
  _req.encodeBeginSequence(_length);
  if (_length) 
  {
    {
       CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
       char * _s;
       _req.encodeBeginArray( _length );
       for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _s = *_elem;
           _req.setSequenceMember(_i);
           _req.encode_string_op(_s);
       }
       _req.encodeEndArray();
    }
    
  }
  _req.encodeEndSequence();
}

void _IDL_SEQ_SAHD_REASONArray_1::decodeOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (__length)
  {
    length(__length); // Allocate sufficient buffer 
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

void _IDL_SEQ_SAHD_REASONArray_1::decodeInOutOp (::CORBA::Request &_req)
{
  ::CORBA::ULong __length;
  _req.decodeBeginSequence( __length );
  if (!_release)
  {
    ::CORBA::ULong max = __length;
    replace(__length, allocbuf_throw(__length), 1);
  }
  length(__length);
  if (__length)
  {
    {
        CORBA::String_StructElem *_elem = (CORBA::String_StructElem *)_buffer;
        char * _s;
        ::CORBA::ULong _array_len = _length;
        _req.decodeBeginArray(_array_len);
        for (::CORBA::ULong _i = 0; _i < _length; _i++, _elem++) {
           _req.setSequenceMember(_i);
            _req.decode_string_op(_s);
            *_elem = _s;
        }
        _req.decodeEndArray();
    }
  }
  _req.decodeEndSequence();
}

_IDL_SEQ_SAHD_REASONArray_1_var::_IDL_SEQ_SAHD_REASONArray_1_var () {
   _ptr = 0;
    }

_IDL_SEQ_SAHD_REASONArray_1_var::_IDL_SEQ_SAHD_REASONArray_1_var (::_IDL_SEQ_SAHD_REASONArray_1 *_p) {
   _ptr = _p;
    }

_IDL_SEQ_SAHD_REASONArray_1_var::_IDL_SEQ_SAHD_REASONArray_1_var (const ::_IDL_SEQ_SAHD_REASONArray_1_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::_IDL_SEQ_SAHD_REASONArray_1 (*(_s._ptr));
    }

_IDL_SEQ_SAHD_REASONArray_1_var& _IDL_SEQ_SAHD_REASONArray_1_var::operator= (::_IDL_SEQ_SAHD_REASONArray_1 *_p) {
   if (_ptr && (_ptr != _p)) {
      delete _ptr;
   }
   _ptr = _p;
   return *this;
}

_IDL_SEQ_SAHD_REASONArray_1_var& _IDL_SEQ_SAHD_REASONArray_1_var::operator= (const ::_IDL_SEQ_SAHD_REASONArray_1_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
      delete _ptr;
   }
   if (_s._ptr)
      _ptr = new ::_IDL_SEQ_SAHD_REASONArray_1 (*(_s._ptr));
   else
      _ptr = 0;
   return *this;
}
_IDL_SEQ_SAHD_REASONArray_1_var::~_IDL_SEQ_SAHD_REASONArray_1_var()
{
   delete _ptr;
}
::_IDL_SEQ_SAHD_REASONArray_1 * _IDL_SEQ_SAHD_REASONArray_1_var::operator->()
{
   return _ptr;
}
_IDL_SEQ_SAHD_REASONArray_1_var::operator ::_IDL_SEQ_SAHD_REASONArray_1_cvPtr() const
{
   return _ptr;
}
_IDL_SEQ_SAHD_REASONArray_1_var::operator ::_IDL_SEQ_SAHD_REASONArray_1_vPtr&()
{
   return _ptr;
}
_IDL_SEQ_SAHD_REASONArray_1_var::operator _IDL_SEQ_SAHD_REASONArray_1() const
{
   return *_ptr;
}
const ::CORBA::String_SeqElem _IDL_SEQ_SAHD_REASONArray_1_var::operator[](::CORBA::ULong index) const
{
   return (* (const ::_IDL_SEQ_SAHD_REASONArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_SAHD_REASONArray_1_var::operator[](::CORBA::ULong index)
{
   return (*_ptr)[index];
}
const ::CORBA::String_SeqElem _IDL_SEQ_SAHD_REASONArray_1_var::operator[](int index) const
{
   return (* (const ::_IDL_SEQ_SAHD_REASONArray_1 *)_ptr)[index];
}
::CORBA::String_SeqElem _IDL_SEQ_SAHD_REASONArray_1_var::operator[](int index)
{
   return (*_ptr)[index];
}
const ::_IDL_SEQ_SAHD_REASONArray_1& _IDL_SEQ_SAHD_REASONArray_1_var::in () const { return *_ptr; }
::_IDL_SEQ_SAHD_REASONArray_1& _IDL_SEQ_SAHD_REASONArray_1_var::inout () { return *_ptr; }
::_IDL_SEQ_SAHD_REASONArray_1*& _IDL_SEQ_SAHD_REASONArray_1_var::out () {
  // release managed object and clear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::_IDL_SEQ_SAHD_REASONArray_1* _IDL_SEQ_SAHD_REASONArray_1_var::_retn () {
  // yield ownership 
  _IDL_SEQ_SAHD_REASONArray_1* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::_IDL_SEQ_SAHD_REASONArray_1 > _IDL_SEQ_SAHD_REASONArray_1::SAHD_REASONArray_1_Info;

void Status::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("STATUSCODE");
    _req << STATUSCODE;
    _req.setVarName("STATUSSTRING");
    STATUSSTRING.encodeOp(_req);
    _req.setVarName("SAHD_REQUEST");
    _req << SAHD_REQUEST;
    _req.setVarName("SAHD_REASON");
    SAHD_REASON.encodeOp(_req);
    _req.encodeEndStructure();
}

void Status::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("STATUSCODE");
    _req >> STATUSCODE;
    _req.setVarName("STATUSSTRING");
    STATUSSTRING.decodeOp(_req);
    _req.setVarName("SAHD_REQUEST");
    _req >> SAHD_REQUEST;
    _req.setVarName("SAHD_REASON");
    SAHD_REASON.decodeOp(_req);
    _req.decodeEndStructure();
}

void Status::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("STATUSCODE");
    _req >> STATUSCODE;
    _req.setVarName("STATUSSTRING");
    STATUSSTRING.decodeInOutOp(_req);
    _req.setVarName("SAHD_REQUEST");
    _req >> SAHD_REQUEST;
    _req.setVarName("SAHD_REASON");
    SAHD_REASON.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 Status::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 Status::__stubcode_dependents[] = {::SAHD_REASONArray::__stubcode_version,::STATUSSTRINGArray::__stubcode_version};
Status::Status()
{
}
Status::Status( const ::Status &EB_s )
{
    operator=( EB_s );
}
Status& Status::operator=( const ::Status &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   STATUSCODE = EB_s.STATUSCODE;
   STATUSSTRING = EB_s.STATUSSTRING;
   SAHD_REQUEST = EB_s.SAHD_REQUEST;
   SAHD_REASON = EB_s.SAHD_REASON;
   return *this;
}
Status_var::Status_var () {
   _ptr = 0;
}
Status_var::Status_var (::Status*_p) {
   _ptr = _p;
}
Status_var::Status_var (const ::Status_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::Status ();
   *(_ptr) = *(_s._ptr);
}
Status_var& Status_var::operator= (::Status *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

Status_var& Status_var::operator= (const ::Status_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::Status ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

Status_var::~Status_var () {
   delete _ptr;
}

::Status * Status_var::operator-> ()
{ return _ptr; }

Status_var::operator ::Status_cvPtr () const 
{ return _ptr;}

Status_var::operator ::Status_vPtr& () 
{ return _ptr;}

Status_var::operator const ::Status& () const 
{ return *_ptr;}

Status_var::operator ::Status& () 
{ return *_ptr;}

const ::Status& Status_var::in () const { return *_ptr; }
::Status& Status_var::inout () { return *_ptr; }
::Status*& Status_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::Status* Status_var::_retn () {
  // yield ownership 
  Status* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::Status > Status::Status_Info;
void Innotron_Recomd_Result::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("APC_CONTEXT");
    APC_CONTEXT.encodeOp(_req);
    _req.setVarName("APC_STATUS");
    APC_STATUS.encodeOp(_req);
    _req.setVarName("RETICLES");
    RETICLES.encodeOp(_req);
    _req.encodeEndStructure();
}

void Innotron_Recomd_Result::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("APC_CONTEXT");
    APC_CONTEXT.decodeOp(_req);
    _req.setVarName("APC_STATUS");
    APC_STATUS.decodeOp(_req);
    _req.setVarName("RETICLES");
    RETICLES.decodeOp(_req);
    _req.decodeEndStructure();
}

void Innotron_Recomd_Result::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("APC_CONTEXT");
    APC_CONTEXT.decodeInOutOp(_req);
    _req.setVarName("APC_STATUS");
    APC_STATUS.decodeInOutOp(_req);
    _req.setVarName("RETICLES");
    RETICLES.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 Innotron_Recomd_Result::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 Innotron_Recomd_Result::__stubcode_dependents[] = {::Innotron_Rec_APC_CONTEXT::__stubcode_version,::RETICLESArray::__stubcode_version,::Status::__stubcode_version};
Innotron_Recomd_Result::Innotron_Recomd_Result()
{
}
Innotron_Recomd_Result::Innotron_Recomd_Result( const ::Innotron_Recomd_Result &EB_s )
{
    operator=( EB_s );
}
Innotron_Recomd_Result& Innotron_Recomd_Result::operator=( const ::Innotron_Recomd_Result &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   APC_CONTEXT = EB_s.APC_CONTEXT;
   APC_STATUS = EB_s.APC_STATUS;
   RETICLES = EB_s.RETICLES;
   return *this;
}
Innotron_Recomd_Result_var::Innotron_Recomd_Result_var () {
   _ptr = 0;
}
Innotron_Recomd_Result_var::Innotron_Recomd_Result_var (::Innotron_Recomd_Result*_p) {
   _ptr = _p;
}
Innotron_Recomd_Result_var::Innotron_Recomd_Result_var (const ::Innotron_Recomd_Result_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::Innotron_Recomd_Result ();
   *(_ptr) = *(_s._ptr);
}
Innotron_Recomd_Result_var& Innotron_Recomd_Result_var::operator= (::Innotron_Recomd_Result *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

Innotron_Recomd_Result_var& Innotron_Recomd_Result_var::operator= (const ::Innotron_Recomd_Result_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::Innotron_Recomd_Result ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

Innotron_Recomd_Result_var::~Innotron_Recomd_Result_var () {
   delete _ptr;
}

::Innotron_Recomd_Result * Innotron_Recomd_Result_var::operator-> ()
{ return _ptr; }

Innotron_Recomd_Result_var::operator ::Innotron_Recomd_Result_cvPtr () const 
{ return _ptr;}

Innotron_Recomd_Result_var::operator ::Innotron_Recomd_Result_vPtr& () 
{ return _ptr;}

Innotron_Recomd_Result_var::operator const ::Innotron_Recomd_Result& () const 
{ return *_ptr;}

Innotron_Recomd_Result_var::operator ::Innotron_Recomd_Result& () 
{ return *_ptr;}

const ::Innotron_Recomd_Result& Innotron_Recomd_Result_var::in () const { return *_ptr; }
::Innotron_Recomd_Result& Innotron_Recomd_Result_var::inout () { return *_ptr; }
::Innotron_Recomd_Result*& Innotron_Recomd_Result_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::Innotron_Recomd_Result* Innotron_Recomd_Result_var::_retn () {
  // yield ownership 
  Innotron_Recomd_Result* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::Innotron_Recomd_Result > Innotron_Recomd_Result::Innotron_Recomd_Result_Info;
void Innotron_Used_Result::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("APC_CONTEXT");
    APC_CONTEXT.encodeOp(_req);
    _req.setVarName("APC_STATUS");
    APC_STATUS.encodeOp(_req);
    _req.encodeEndStructure();
}

void Innotron_Used_Result::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("APC_CONTEXT");
    APC_CONTEXT.decodeOp(_req);
    _req.setVarName("APC_STATUS");
    APC_STATUS.decodeOp(_req);
    _req.decodeEndStructure();
}

void Innotron_Used_Result::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("APC_CONTEXT");
    APC_CONTEXT.decodeInOutOp(_req);
    _req.setVarName("APC_STATUS");
    APC_STATUS.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 Innotron_Used_Result::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 Innotron_Used_Result::__stubcode_dependents[] = {::Innotron_Used_APC_CONTEXT::__stubcode_version,::Status::__stubcode_version};
Innotron_Used_Result::Innotron_Used_Result()
{
}
Innotron_Used_Result::Innotron_Used_Result( const ::Innotron_Used_Result &EB_s )
{
    operator=( EB_s );
}
Innotron_Used_Result& Innotron_Used_Result::operator=( const ::Innotron_Used_Result &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   APC_CONTEXT = EB_s.APC_CONTEXT;
   APC_STATUS = EB_s.APC_STATUS;
   return *this;
}
Innotron_Used_Result_var::Innotron_Used_Result_var () {
   _ptr = 0;
}
Innotron_Used_Result_var::Innotron_Used_Result_var (::Innotron_Used_Result*_p) {
   _ptr = _p;
}
Innotron_Used_Result_var::Innotron_Used_Result_var (const ::Innotron_Used_Result_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::Innotron_Used_Result ();
   *(_ptr) = *(_s._ptr);
}
Innotron_Used_Result_var& Innotron_Used_Result_var::operator= (::Innotron_Used_Result *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

Innotron_Used_Result_var& Innotron_Used_Result_var::operator= (const ::Innotron_Used_Result_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::Innotron_Used_Result ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

Innotron_Used_Result_var::~Innotron_Used_Result_var () {
   delete _ptr;
}

::Innotron_Used_Result * Innotron_Used_Result_var::operator-> ()
{ return _ptr; }

Innotron_Used_Result_var::operator ::Innotron_Used_Result_cvPtr () const 
{ return _ptr;}

Innotron_Used_Result_var::operator ::Innotron_Used_Result_vPtr& () 
{ return _ptr;}

Innotron_Used_Result_var::operator const ::Innotron_Used_Result& () const 
{ return *_ptr;}

Innotron_Used_Result_var::operator ::Innotron_Used_Result& () 
{ return *_ptr;}

const ::Innotron_Used_Result& Innotron_Used_Result_var::in () const { return *_ptr; }
::Innotron_Used_Result& Innotron_Used_Result_var::inout () { return *_ptr; }
::Innotron_Used_Result*& Innotron_Used_Result_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::Innotron_Used_Result* Innotron_Used_Result_var::_retn () {
  // yield ownership 
  Innotron_Used_Result* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::Innotron_Used_Result > Innotron_Used_Result::Innotron_Used_Result_Info;
void Innotron_Met_Result::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("APC_CONTEXT");
    APC_CONTEXT.encodeOp(_req);
    _req.setVarName("APC_STATUS");
    APC_STATUS.encodeOp(_req);
    _req.encodeEndStructure();
}

void Innotron_Met_Result::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("APC_CONTEXT");
    APC_CONTEXT.decodeOp(_req);
    _req.setVarName("APC_STATUS");
    APC_STATUS.decodeOp(_req);
    _req.decodeEndStructure();
}

void Innotron_Met_Result::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("APC_CONTEXT");
    APC_CONTEXT.decodeInOutOp(_req);
    _req.setVarName("APC_STATUS");
    APC_STATUS.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 Innotron_Met_Result::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 Innotron_Met_Result::__stubcode_dependents[] = {::Innotron_Met_APC_CONTEXT::__stubcode_version,::Status::__stubcode_version};
Innotron_Met_Result::Innotron_Met_Result()
{
}
Innotron_Met_Result::Innotron_Met_Result( const ::Innotron_Met_Result &EB_s )
{
    operator=( EB_s );
}
Innotron_Met_Result& Innotron_Met_Result::operator=( const ::Innotron_Met_Result &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   APC_CONTEXT = EB_s.APC_CONTEXT;
   APC_STATUS = EB_s.APC_STATUS;
   return *this;
}
Innotron_Met_Result_var::Innotron_Met_Result_var () {
   _ptr = 0;
}
Innotron_Met_Result_var::Innotron_Met_Result_var (::Innotron_Met_Result*_p) {
   _ptr = _p;
}
Innotron_Met_Result_var::Innotron_Met_Result_var (const ::Innotron_Met_Result_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::Innotron_Met_Result ();
   *(_ptr) = *(_s._ptr);
}
Innotron_Met_Result_var& Innotron_Met_Result_var::operator= (::Innotron_Met_Result *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

Innotron_Met_Result_var& Innotron_Met_Result_var::operator= (const ::Innotron_Met_Result_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::Innotron_Met_Result ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

Innotron_Met_Result_var::~Innotron_Met_Result_var () {
   delete _ptr;
}

::Innotron_Met_Result * Innotron_Met_Result_var::operator-> ()
{ return _ptr; }

Innotron_Met_Result_var::operator ::Innotron_Met_Result_cvPtr () const 
{ return _ptr;}

Innotron_Met_Result_var::operator ::Innotron_Met_Result_vPtr& () 
{ return _ptr;}

Innotron_Met_Result_var::operator const ::Innotron_Met_Result& () const 
{ return *_ptr;}

Innotron_Met_Result_var::operator ::Innotron_Met_Result& () 
{ return *_ptr;}

const ::Innotron_Met_Result& Innotron_Met_Result_var::in () const { return *_ptr; }
::Innotron_Met_Result& Innotron_Met_Result_var::inout () { return *_ptr; }
::Innotron_Met_Result*& Innotron_Met_Result_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::Innotron_Met_Result* Innotron_Met_Result_var::_retn () {
  // yield ownership 
  Innotron_Met_Result* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::Innotron_Met_Result > Innotron_Met_Result::Innotron_Met_Result_Info;
void Innotron_Used_Request::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("APC_CONTEXT");
    APC_CONTEXT.encodeOp(_req);
    _req.setVarName("LOT_DATA");
    LOT_DATA.encodeOp(_req);
    _req.setVarName("RETICLES");
    RETICLES.encodeOp(_req);
    _req.encodeEndStructure();
}

void Innotron_Used_Request::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("APC_CONTEXT");
    APC_CONTEXT.decodeOp(_req);
    _req.setVarName("LOT_DATA");
    LOT_DATA.decodeOp(_req);
    _req.setVarName("RETICLES");
    RETICLES.decodeOp(_req);
    _req.decodeEndStructure();
}

void Innotron_Used_Request::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("APC_CONTEXT");
    APC_CONTEXT.decodeInOutOp(_req);
    _req.setVarName("LOT_DATA");
    LOT_DATA.decodeInOutOp(_req);
    _req.setVarName("RETICLES");
    RETICLES.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 Innotron_Used_Request::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 Innotron_Used_Request::__stubcode_dependents[] = {::RETICLESArray::__stubcode_version,::Innotron_Used_APC_CONTEXT::__stubcode_version,::LOT_DATAArray::__stubcode_version};
Innotron_Used_Request::Innotron_Used_Request()
{
}
Innotron_Used_Request::Innotron_Used_Request( const ::Innotron_Used_Request &EB_s )
{
    operator=( EB_s );
}
Innotron_Used_Request& Innotron_Used_Request::operator=( const ::Innotron_Used_Request &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   APC_CONTEXT = EB_s.APC_CONTEXT;
   LOT_DATA = EB_s.LOT_DATA;
   RETICLES = EB_s.RETICLES;
   return *this;
}
Innotron_Used_Request_var::Innotron_Used_Request_var () {
   _ptr = 0;
}
Innotron_Used_Request_var::Innotron_Used_Request_var (::Innotron_Used_Request*_p) {
   _ptr = _p;
}
Innotron_Used_Request_var::Innotron_Used_Request_var (const ::Innotron_Used_Request_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::Innotron_Used_Request ();
   *(_ptr) = *(_s._ptr);
}
Innotron_Used_Request_var& Innotron_Used_Request_var::operator= (::Innotron_Used_Request *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

Innotron_Used_Request_var& Innotron_Used_Request_var::operator= (const ::Innotron_Used_Request_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::Innotron_Used_Request ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

Innotron_Used_Request_var::~Innotron_Used_Request_var () {
   delete _ptr;
}

::Innotron_Used_Request * Innotron_Used_Request_var::operator-> ()
{ return _ptr; }

Innotron_Used_Request_var::operator ::Innotron_Used_Request_cvPtr () const 
{ return _ptr;}

Innotron_Used_Request_var::operator ::Innotron_Used_Request_vPtr& () 
{ return _ptr;}

Innotron_Used_Request_var::operator const ::Innotron_Used_Request& () const 
{ return *_ptr;}

Innotron_Used_Request_var::operator ::Innotron_Used_Request& () 
{ return *_ptr;}

const ::Innotron_Used_Request& Innotron_Used_Request_var::in () const { return *_ptr; }
::Innotron_Used_Request& Innotron_Used_Request_var::inout () { return *_ptr; }
::Innotron_Used_Request*& Innotron_Used_Request_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::Innotron_Used_Request* Innotron_Used_Request_var::_retn () {
  // yield ownership 
  Innotron_Used_Request* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::Innotron_Used_Request > Innotron_Used_Request::Innotron_Used_Request_Info;
void Metrology_RequestResponse::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("Metrology_RequestResult");
    Metrology_RequestResult.encodeOp(_req);
    _req.encodeEndStructure();
}

void Metrology_RequestResponse::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("Metrology_RequestResult");
    Metrology_RequestResult.decodeOp(_req);
    _req.decodeEndStructure();
}

void Metrology_RequestResponse::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("Metrology_RequestResult");
    Metrology_RequestResult.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 Metrology_RequestResponse::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 Metrology_RequestResponse::__stubcode_dependents[] = {::Innotron_Met_Result::__stubcode_version};
Metrology_RequestResponse::Metrology_RequestResponse()
{
}
Metrology_RequestResponse::Metrology_RequestResponse( const ::Metrology_RequestResponse &EB_s )
{
    operator=( EB_s );
}
Metrology_RequestResponse& Metrology_RequestResponse::operator=( const ::Metrology_RequestResponse &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   Metrology_RequestResult = EB_s.Metrology_RequestResult;
   return *this;
}
Metrology_RequestResponse_var::Metrology_RequestResponse_var () {
   _ptr = 0;
}
Metrology_RequestResponse_var::Metrology_RequestResponse_var (::Metrology_RequestResponse*_p) {
   _ptr = _p;
}
Metrology_RequestResponse_var::Metrology_RequestResponse_var (const ::Metrology_RequestResponse_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::Metrology_RequestResponse ();
   *(_ptr) = *(_s._ptr);
}
Metrology_RequestResponse_var& Metrology_RequestResponse_var::operator= (::Metrology_RequestResponse *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

Metrology_RequestResponse_var& Metrology_RequestResponse_var::operator= (const ::Metrology_RequestResponse_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::Metrology_RequestResponse ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

Metrology_RequestResponse_var::~Metrology_RequestResponse_var () {
   delete _ptr;
}

::Metrology_RequestResponse * Metrology_RequestResponse_var::operator-> ()
{ return _ptr; }

Metrology_RequestResponse_var::operator ::Metrology_RequestResponse_cvPtr () const 
{ return _ptr;}

Metrology_RequestResponse_var::operator ::Metrology_RequestResponse_vPtr& () 
{ return _ptr;}

Metrology_RequestResponse_var::operator const ::Metrology_RequestResponse& () const 
{ return *_ptr;}

Metrology_RequestResponse_var::operator ::Metrology_RequestResponse& () 
{ return *_ptr;}

const ::Metrology_RequestResponse& Metrology_RequestResponse_var::in () const { return *_ptr; }
::Metrology_RequestResponse& Metrology_RequestResponse_var::inout () { return *_ptr; }
::Metrology_RequestResponse*& Metrology_RequestResponse_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::Metrology_RequestResponse* Metrology_RequestResponse_var::_retn () {
  // yield ownership 
  Metrology_RequestResponse* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::Metrology_RequestResponse > Metrology_RequestResponse::Metrology_RequestResponse_Info;
void Used_RequestResponse::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("Used_RequestResult");
    Used_RequestResult.encodeOp(_req);
    _req.encodeEndStructure();
}

void Used_RequestResponse::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("Used_RequestResult");
    Used_RequestResult.decodeOp(_req);
    _req.decodeEndStructure();
}

void Used_RequestResponse::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("Used_RequestResult");
    Used_RequestResult.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 Used_RequestResponse::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 Used_RequestResponse::__stubcode_dependents[] = {::Innotron_Used_Result::__stubcode_version};
Used_RequestResponse::Used_RequestResponse()
{
}
Used_RequestResponse::Used_RequestResponse( const ::Used_RequestResponse &EB_s )
{
    operator=( EB_s );
}
Used_RequestResponse& Used_RequestResponse::operator=( const ::Used_RequestResponse &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   Used_RequestResult = EB_s.Used_RequestResult;
   return *this;
}
Used_RequestResponse_var::Used_RequestResponse_var () {
   _ptr = 0;
}
Used_RequestResponse_var::Used_RequestResponse_var (::Used_RequestResponse*_p) {
   _ptr = _p;
}
Used_RequestResponse_var::Used_RequestResponse_var (const ::Used_RequestResponse_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::Used_RequestResponse ();
   *(_ptr) = *(_s._ptr);
}
Used_RequestResponse_var& Used_RequestResponse_var::operator= (::Used_RequestResponse *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

Used_RequestResponse_var& Used_RequestResponse_var::operator= (const ::Used_RequestResponse_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::Used_RequestResponse ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

Used_RequestResponse_var::~Used_RequestResponse_var () {
   delete _ptr;
}

::Used_RequestResponse * Used_RequestResponse_var::operator-> ()
{ return _ptr; }

Used_RequestResponse_var::operator ::Used_RequestResponse_cvPtr () const 
{ return _ptr;}

Used_RequestResponse_var::operator ::Used_RequestResponse_vPtr& () 
{ return _ptr;}

Used_RequestResponse_var::operator const ::Used_RequestResponse& () const 
{ return *_ptr;}

Used_RequestResponse_var::operator ::Used_RequestResponse& () 
{ return *_ptr;}

const ::Used_RequestResponse& Used_RequestResponse_var::in () const { return *_ptr; }
::Used_RequestResponse& Used_RequestResponse_var::inout () { return *_ptr; }
::Used_RequestResponse*& Used_RequestResponse_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::Used_RequestResponse* Used_RequestResponse_var::_retn () {
  // yield ownership 
  Used_RequestResponse* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::Used_RequestResponse > Used_RequestResponse::Used_RequestResponse_Info;
void Metrology_Request::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("objRequest");
    objRequest.encodeOp(_req);
    _req.encodeEndStructure();
}

void Metrology_Request::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("objRequest");
    objRequest.decodeOp(_req);
    _req.decodeEndStructure();
}

void Metrology_Request::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("objRequest");
    objRequest.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 Metrology_Request::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 Metrology_Request::__stubcode_dependents[] = {::Innotron_Met_Request::__stubcode_version};
Metrology_Request::Metrology_Request()
{
}
Metrology_Request::Metrology_Request( const ::Metrology_Request &EB_s )
{
    operator=( EB_s );
}
Metrology_Request& Metrology_Request::operator=( const ::Metrology_Request &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   objRequest = EB_s.objRequest;
   return *this;
}
Metrology_Request_var::Metrology_Request_var () {
   _ptr = 0;
}
Metrology_Request_var::Metrology_Request_var (::Metrology_Request*_p) {
   _ptr = _p;
}
Metrology_Request_var::Metrology_Request_var (const ::Metrology_Request_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::Metrology_Request ();
   *(_ptr) = *(_s._ptr);
}
Metrology_Request_var& Metrology_Request_var::operator= (::Metrology_Request *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

Metrology_Request_var& Metrology_Request_var::operator= (const ::Metrology_Request_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::Metrology_Request ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

Metrology_Request_var::~Metrology_Request_var () {
   delete _ptr;
}

::Metrology_Request * Metrology_Request_var::operator-> ()
{ return _ptr; }

Metrology_Request_var::operator ::Metrology_Request_cvPtr () const 
{ return _ptr;}

Metrology_Request_var::operator ::Metrology_Request_vPtr& () 
{ return _ptr;}

Metrology_Request_var::operator const ::Metrology_Request& () const 
{ return *_ptr;}

Metrology_Request_var::operator ::Metrology_Request& () 
{ return *_ptr;}

const ::Metrology_Request& Metrology_Request_var::in () const { return *_ptr; }
::Metrology_Request& Metrology_Request_var::inout () { return *_ptr; }
::Metrology_Request*& Metrology_Request_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::Metrology_Request* Metrology_Request_var::_retn () {
  // yield ownership 
  Metrology_Request* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::Metrology_Request > Metrology_Request::Metrology_Request_Info;
void Recommend_RequestResponse::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("Recommend_RequestResult");
    Recommend_RequestResult.encodeOp(_req);
    _req.encodeEndStructure();
}

void Recommend_RequestResponse::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("Recommend_RequestResult");
    Recommend_RequestResult.decodeOp(_req);
    _req.decodeEndStructure();
}

void Recommend_RequestResponse::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("Recommend_RequestResult");
    Recommend_RequestResult.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 Recommend_RequestResponse::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 Recommend_RequestResponse::__stubcode_dependents[] = {::Innotron_Recomd_Result::__stubcode_version};
Recommend_RequestResponse::Recommend_RequestResponse()
{
}
Recommend_RequestResponse::Recommend_RequestResponse( const ::Recommend_RequestResponse &EB_s )
{
    operator=( EB_s );
}
Recommend_RequestResponse& Recommend_RequestResponse::operator=( const ::Recommend_RequestResponse &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   Recommend_RequestResult = EB_s.Recommend_RequestResult;
   return *this;
}
Recommend_RequestResponse_var::Recommend_RequestResponse_var () {
   _ptr = 0;
}
Recommend_RequestResponse_var::Recommend_RequestResponse_var (::Recommend_RequestResponse*_p) {
   _ptr = _p;
}
Recommend_RequestResponse_var::Recommend_RequestResponse_var (const ::Recommend_RequestResponse_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::Recommend_RequestResponse ();
   *(_ptr) = *(_s._ptr);
}
Recommend_RequestResponse_var& Recommend_RequestResponse_var::operator= (::Recommend_RequestResponse *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

Recommend_RequestResponse_var& Recommend_RequestResponse_var::operator= (const ::Recommend_RequestResponse_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::Recommend_RequestResponse ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

Recommend_RequestResponse_var::~Recommend_RequestResponse_var () {
   delete _ptr;
}

::Recommend_RequestResponse * Recommend_RequestResponse_var::operator-> ()
{ return _ptr; }

Recommend_RequestResponse_var::operator ::Recommend_RequestResponse_cvPtr () const 
{ return _ptr;}

Recommend_RequestResponse_var::operator ::Recommend_RequestResponse_vPtr& () 
{ return _ptr;}

Recommend_RequestResponse_var::operator const ::Recommend_RequestResponse& () const 
{ return *_ptr;}

Recommend_RequestResponse_var::operator ::Recommend_RequestResponse& () 
{ return *_ptr;}

const ::Recommend_RequestResponse& Recommend_RequestResponse_var::in () const { return *_ptr; }
::Recommend_RequestResponse& Recommend_RequestResponse_var::inout () { return *_ptr; }
::Recommend_RequestResponse*& Recommend_RequestResponse_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::Recommend_RequestResponse* Recommend_RequestResponse_var::_retn () {
  // yield ownership 
  Recommend_RequestResponse* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::Recommend_RequestResponse > Recommend_RequestResponse::Recommend_RequestResponse_Info;
void Used_Request::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("objRequest");
    objRequest.encodeOp(_req);
    _req.encodeEndStructure();
}

void Used_Request::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("objRequest");
    objRequest.decodeOp(_req);
    _req.decodeEndStructure();
}

void Used_Request::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("objRequest");
    objRequest.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 Used_Request::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 Used_Request::__stubcode_dependents[] = {::Innotron_Used_Request::__stubcode_version};
Used_Request::Used_Request()
{
}
Used_Request::Used_Request( const ::Used_Request &EB_s )
{
    operator=( EB_s );
}
Used_Request& Used_Request::operator=( const ::Used_Request &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   objRequest = EB_s.objRequest;
   return *this;
}
Used_Request_var::Used_Request_var () {
   _ptr = 0;
}
Used_Request_var::Used_Request_var (::Used_Request*_p) {
   _ptr = _p;
}
Used_Request_var::Used_Request_var (const ::Used_Request_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::Used_Request ();
   *(_ptr) = *(_s._ptr);
}
Used_Request_var& Used_Request_var::operator= (::Used_Request *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

Used_Request_var& Used_Request_var::operator= (const ::Used_Request_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::Used_Request ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

Used_Request_var::~Used_Request_var () {
   delete _ptr;
}

::Used_Request * Used_Request_var::operator-> ()
{ return _ptr; }

Used_Request_var::operator ::Used_Request_cvPtr () const 
{ return _ptr;}

Used_Request_var::operator ::Used_Request_vPtr& () 
{ return _ptr;}

Used_Request_var::operator const ::Used_Request& () const 
{ return *_ptr;}

Used_Request_var::operator ::Used_Request& () 
{ return *_ptr;}

const ::Used_Request& Used_Request_var::in () const { return *_ptr; }
::Used_Request& Used_Request_var::inout () { return *_ptr; }
::Used_Request*& Used_Request_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::Used_Request* Used_Request_var::_retn () {
  // yield ownership 
  Used_Request* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::Used_Request > Used_Request::Used_Request_Info;
void Recommend_Request::encodeOp (::CORBA::Request &_req) const
{
    _req.encodeBeginStructure();
    _req.setVarName("objRequest");
    objRequest.encodeOp(_req);
    _req.encodeEndStructure();
}

void Recommend_Request::decodeOp (::CORBA::Request &_req)
{
    _req.decodeBeginStructure();
    _req.setVarName("objRequest");
    objRequest.decodeOp(_req);
    _req.decodeEndStructure();
}

void Recommend_Request::decodeInOutOp (::CORBA::Request &_req)
{

    _req.decodeBeginStructure();
    _req.setVarName("objRequest");
    objRequest.decodeInOutOp(_req);
    _req.decodeEndStructure();
}

const ::CORBA::ClassVersionInfo_1_0 Recommend_Request::__stubcode_version;
const ::CORBA::ClassVersionInfo_1_0 Recommend_Request::__stubcode_dependents[] = {::Innotron_Recomd_Request::__stubcode_version};
Recommend_Request::Recommend_Request()
{
}
Recommend_Request::Recommend_Request( const ::Recommend_Request &EB_s )
{
    operator=( EB_s );
}
Recommend_Request& Recommend_Request::operator=( const ::Recommend_Request &EB_s )
{
   if( this == &EB_s )
   {
      return *this;
   }
   objRequest = EB_s.objRequest;
   return *this;
}
Recommend_Request_var::Recommend_Request_var () {
   _ptr = 0;
}
Recommend_Request_var::Recommend_Request_var (::Recommend_Request*_p) {
   _ptr = _p;
}
Recommend_Request_var::Recommend_Request_var (const ::Recommend_Request_var &_s) {
   if (!_s._ptr) {
      _ptr = _s._ptr;
      return;
   }
   _ptr = new ::Recommend_Request ();
   *(_ptr) = *(_s._ptr);
}
Recommend_Request_var& Recommend_Request_var::operator= (::Recommend_Request *_p) {
   if (_p == _ptr) return *this;
   if (_ptr) {
       delete _ptr;
   }
   _ptr = _p;
   return *this;
}

Recommend_Request_var& Recommend_Request_var::operator= (const ::Recommend_Request_var &_s) {
   if (this == &_s) return *this;
   if (_ptr && (_ptr != _s._ptr)) {
       delete _ptr;
   }
   if (_s._ptr) {
      _ptr = new ::Recommend_Request ();
      *(_ptr) = *(_s._ptr);
   }
   else
      _ptr = 0;
   return *this;
}

Recommend_Request_var::~Recommend_Request_var () {
   delete _ptr;
}

::Recommend_Request * Recommend_Request_var::operator-> ()
{ return _ptr; }

Recommend_Request_var::operator ::Recommend_Request_cvPtr () const 
{ return _ptr;}

Recommend_Request_var::operator ::Recommend_Request_vPtr& () 
{ return _ptr;}

Recommend_Request_var::operator const ::Recommend_Request& () const 
{ return *_ptr;}

Recommend_Request_var::operator ::Recommend_Request& () 
{ return *_ptr;}

const ::Recommend_Request& Recommend_Request_var::in () const { return *_ptr; }
::Recommend_Request& Recommend_Request_var::inout () { return *_ptr; }
::Recommend_Request*& Recommend_Request_var::out () {
  // release struct and lear pointer
  if (_ptr)
     delete _ptr;
  _ptr = NULL;
  return _ptr;}
::Recommend_Request* Recommend_Request_var::_retn () {
  // yield ownership 
  Recommend_Request* ret = _ptr;
  _ptr = NULL;
  return ret;}

CORBA::Info < ::Recommend_Request > Recommend_Request::Recommend_Request_Info;
/*
 * TypeCode constants
 */
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_CONTROLJOBTYPEArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_CONTROLJOBTYPEArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_TRANSACTIONIDArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_TRANSACTIONIDArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_LOTIDArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_LOTIDArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_LOTTYPEArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_LOTTYPEArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_PARTIDArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_PARTIDArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_LAYERArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_LAYERArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_ROUTEArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_ROUTEArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_ROUTEGROUPArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_ROUTEGROUPArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_OPERATIONArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_OPERATIONArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_RETICLEIDArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_RETICLEIDArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_PROCESSEQUIPTYPEArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_PROCESSEQUIPTYPEArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_PROCESSEQUIPIDArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_PROCESSEQUIPIDArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_RECOMMENDMODEArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_RECOMMENDMODEArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_REWORKArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_REWORKArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_PARENTLOTIDArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_PARENTLOTIDArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_PRETOOLArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_PRETOOLArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_SENDAHEADArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_SENDAHEADArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_SENDAHEADVALUESArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_SENDAHEADVALUESArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_AVAILABLE_SUBUNITArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_AVAILABLE_SUBUNITArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_IS_OPSTART_RECOMDArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_IS_OPSTART_RECOMDArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_BR_PARAMSArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_BR_PARAMSArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_FEEDFORWARD1Array = NULL;
#else
::CORBA::TypeCode_ptr _tc_FEEDFORWARD1Array =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_FEEDFORWARD2Array = NULL;
#else
::CORBA::TypeCode_ptr _tc_FEEDFORWARD2Array =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_FEEDFORWARD3Array = NULL;
#else
::CORBA::TypeCode_ptr _tc_FEEDFORWARD3Array =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_FEEDFORWARD4Array = NULL;
#else
::CORBA::TypeCode_ptr _tc_FEEDFORWARD4Array =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_NAMEArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_NAMEArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_VALUEArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_VALUEArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_ITEM_VALUE = NULL;
#else
::CORBA::TypeCode_ptr _tc_ITEM_VALUE =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_ArrayOfITEM_VALUE = NULL;
#else
::CORBA::TypeCode_ptr _tc_ArrayOfITEM_VALUE =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_LD_EXTENDArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_LD_EXTENDArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_Innotron_Rec_APC_CONTEXT = NULL;
#else
::CORBA::TypeCode_ptr _tc_Innotron_Rec_APC_CONTEXT =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_PARAMSArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_PARAMSArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_REC_Reticle = NULL;
#else
::CORBA::TypeCode_ptr _tc_REC_Reticle =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_ArrayOfREC_Reticle = NULL;
#else
::CORBA::TypeCode_ptr _tc_ArrayOfREC_Reticle =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_WAFERIDArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_WAFERIDArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_WAFER = NULL;
#else
::CORBA::TypeCode_ptr _tc_WAFER =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_ArrayOfWAFER = NULL;
#else
::CORBA::TypeCode_ptr _tc_ArrayOfWAFER =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_WAFERSArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_WAFERSArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_LOT = NULL;
#else
::CORBA::TypeCode_ptr _tc_LOT =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_USED_TRANSACTIONIDArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_USED_TRANSACTIONIDArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_METROLOGYEQUIPTYPEArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_METROLOGYEQUIPTYPEArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_METROLOGYEQUIPIDArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_METROLOGYEQUIPIDArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_Innotron_Met_APC_CONTEXT = NULL;
#else
::CORBA::TypeCode_ptr _tc_Innotron_Met_APC_CONTEXT =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_WAFERLISTArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_WAFERLISTArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_DCITEMSArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_DCITEMSArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_Met_Reticle = NULL;
#else
::CORBA::TypeCode_ptr _tc_Met_Reticle =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_ArrayOfMet_Reticle = NULL;
#else
::CORBA::TypeCode_ptr _tc_ArrayOfMet_Reticle =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_RETICLESArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_RETICLESArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_Innotron_Met_Request = NULL;
#else
::CORBA::TypeCode_ptr _tc_Innotron_Met_Request =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_ArrayOfLOT = NULL;
#else
::CORBA::TypeCode_ptr _tc_ArrayOfLOT =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_LOT_DATAArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_LOT_DATAArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_Innotron_Recomd_Request = NULL;
#else
::CORBA::TypeCode_ptr _tc_Innotron_Recomd_Request =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_REC_TRANSACTIONIDArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_REC_TRANSACTIONIDArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_Innotron_Used_APC_CONTEXT = NULL;
#else
::CORBA::TypeCode_ptr _tc_Innotron_Used_APC_CONTEXT =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_STATUSSTRINGArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_STATUSSTRINGArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_SAHD_REASONArray = NULL;
#else
::CORBA::TypeCode_ptr _tc_SAHD_REASONArray =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_Status = NULL;
#else
::CORBA::TypeCode_ptr _tc_Status =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_Innotron_Recomd_Result = NULL;
#else
::CORBA::TypeCode_ptr _tc_Innotron_Recomd_Result =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_Innotron_Used_Result = NULL;
#else
::CORBA::TypeCode_ptr _tc_Innotron_Used_Result =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_Innotron_Met_Result = NULL;
#else
::CORBA::TypeCode_ptr _tc_Innotron_Met_Result =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_Innotron_Used_Request = NULL;
#else
::CORBA::TypeCode_ptr _tc_Innotron_Used_Request =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_Metrology_RequestResponse = NULL;
#else
::CORBA::TypeCode_ptr _tc_Metrology_RequestResponse =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_Used_RequestResponse = NULL;
#else
::CORBA::TypeCode_ptr _tc_Used_RequestResponse =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_Metrology_Request = NULL;
#else
::CORBA::TypeCode_ptr _tc_Metrology_Request =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_Recommend_RequestResponse = NULL;
#else
::CORBA::TypeCode_ptr _tc_Recommend_RequestResponse =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_Used_Request = NULL;
#else
::CORBA::TypeCode_ptr _tc_Used_Request =NULL;
#endif // _USE_NAMESPACE
#ifndef _USE_NAMESPACE
::CORBA::TypeCode_ptr _tc_Recommend_Request = NULL;
#else
::CORBA::TypeCode_ptr _tc_Recommend_Request =NULL;
#endif // _USE_NAMESPACE
static void __cs_apcstr_emit_tc(::CORBA::ORB_ptr _orb)
{ 

::CORBA::TypeCode_ptr _tmp_tc__CONTROLJOBTYPEArray= _orb->create_alias_tc("IDL:CONTROLJOBTYPEArray:1.0", "CONTROLJOBTYPEArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_CONTROLJOBTYPEArray = _tmp_tc__CONTROLJOBTYPEArray;
_orb->setClassInfo(::_tc_CONTROLJOBTYPEArray, &::CONTROLJOBTYPEArray::CONTROLJOBTYPEArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__TRANSACTIONIDArray= _orb->create_alias_tc("IDL:TRANSACTIONIDArray:1.0", "TRANSACTIONIDArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_TRANSACTIONIDArray = _tmp_tc__TRANSACTIONIDArray;
_orb->setClassInfo(::_tc_TRANSACTIONIDArray, &::TRANSACTIONIDArray::TRANSACTIONIDArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__LOTIDArray= _orb->create_alias_tc("IDL:LOTIDArray:1.0", "LOTIDArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_LOTIDArray = _tmp_tc__LOTIDArray;
_orb->setClassInfo(::_tc_LOTIDArray, &::LOTIDArray::LOTIDArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__LOTTYPEArray= _orb->create_alias_tc("IDL:LOTTYPEArray:1.0", "LOTTYPEArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_LOTTYPEArray = _tmp_tc__LOTTYPEArray;
_orb->setClassInfo(::_tc_LOTTYPEArray, &::LOTTYPEArray::LOTTYPEArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__PARTIDArray= _orb->create_alias_tc("IDL:PARTIDArray:1.0", "PARTIDArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_PARTIDArray = _tmp_tc__PARTIDArray;
_orb->setClassInfo(::_tc_PARTIDArray, &::PARTIDArray::PARTIDArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__LAYERArray= _orb->create_alias_tc("IDL:LAYERArray:1.0", "LAYERArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_LAYERArray = _tmp_tc__LAYERArray;
_orb->setClassInfo(::_tc_LAYERArray, &::LAYERArray::LAYERArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__ROUTEArray= _orb->create_alias_tc("IDL:ROUTEArray:1.0", "ROUTEArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_ROUTEArray = _tmp_tc__ROUTEArray;
_orb->setClassInfo(::_tc_ROUTEArray, &::ROUTEArray::ROUTEArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__ROUTEGROUPArray= _orb->create_alias_tc("IDL:ROUTEGROUPArray:1.0", "ROUTEGROUPArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_ROUTEGROUPArray = _tmp_tc__ROUTEGROUPArray;
_orb->setClassInfo(::_tc_ROUTEGROUPArray, &::ROUTEGROUPArray::ROUTEGROUPArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__OPERATIONArray= _orb->create_alias_tc("IDL:OPERATIONArray:1.0", "OPERATIONArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_OPERATIONArray = _tmp_tc__OPERATIONArray;
_orb->setClassInfo(::_tc_OPERATIONArray, &::OPERATIONArray::OPERATIONArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__RETICLEIDArray= _orb->create_alias_tc("IDL:RETICLEIDArray:1.0", "RETICLEIDArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_RETICLEIDArray = _tmp_tc__RETICLEIDArray;
_orb->setClassInfo(::_tc_RETICLEIDArray, &::RETICLEIDArray::RETICLEIDArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__PROCESSEQUIPTYPEArray= _orb->create_alias_tc("IDL:PROCESSEQUIPTYPEArray:1.0", "PROCESSEQUIPTYPEArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_PROCESSEQUIPTYPEArray = _tmp_tc__PROCESSEQUIPTYPEArray;
_orb->setClassInfo(::_tc_PROCESSEQUIPTYPEArray, &::PROCESSEQUIPTYPEArray::PROCESSEQUIPTYPEArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__PROCESSEQUIPIDArray= _orb->create_alias_tc("IDL:PROCESSEQUIPIDArray:1.0", "PROCESSEQUIPIDArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_PROCESSEQUIPIDArray = _tmp_tc__PROCESSEQUIPIDArray;
_orb->setClassInfo(::_tc_PROCESSEQUIPIDArray, &::PROCESSEQUIPIDArray::PROCESSEQUIPIDArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__RECOMMENDMODEArray= _orb->create_alias_tc("IDL:RECOMMENDMODEArray:1.0", "RECOMMENDMODEArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_RECOMMENDMODEArray = _tmp_tc__RECOMMENDMODEArray;
_orb->setClassInfo(::_tc_RECOMMENDMODEArray, &::RECOMMENDMODEArray::RECOMMENDMODEArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__REWORKArray= _orb->create_alias_tc("IDL:REWORKArray:1.0", "REWORKArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_REWORKArray = _tmp_tc__REWORKArray;
_orb->setClassInfo(::_tc_REWORKArray, &::REWORKArray::REWORKArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__PARENTLOTIDArray= _orb->create_alias_tc("IDL:PARENTLOTIDArray:1.0", "PARENTLOTIDArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_PARENTLOTIDArray = _tmp_tc__PARENTLOTIDArray;
_orb->setClassInfo(::_tc_PARENTLOTIDArray, &::PARENTLOTIDArray::PARENTLOTIDArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__PRETOOLArray= _orb->create_alias_tc("IDL:PRETOOLArray:1.0", "PRETOOLArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_PRETOOLArray = _tmp_tc__PRETOOLArray;
_orb->setClassInfo(::_tc_PRETOOLArray, &::PRETOOLArray::PRETOOLArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__SENDAHEADArray= _orb->create_alias_tc("IDL:SENDAHEADArray:1.0", "SENDAHEADArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_SENDAHEADArray = _tmp_tc__SENDAHEADArray;
_orb->setClassInfo(::_tc_SENDAHEADArray, &::SENDAHEADArray::SENDAHEADArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__SENDAHEADVALUESArray= _orb->create_alias_tc("IDL:SENDAHEADVALUESArray:1.0", "SENDAHEADVALUESArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_SENDAHEADVALUESArray = _tmp_tc__SENDAHEADVALUESArray;
_orb->setClassInfo(::_tc_SENDAHEADVALUESArray, &::SENDAHEADVALUESArray::SENDAHEADVALUESArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__AVAILABLE_SUBUNITArray= _orb->create_alias_tc("IDL:AVAILABLE_SUBUNITArray:1.0", "AVAILABLE_SUBUNITArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_AVAILABLE_SUBUNITArray = _tmp_tc__AVAILABLE_SUBUNITArray;
_orb->setClassInfo(::_tc_AVAILABLE_SUBUNITArray, &::AVAILABLE_SUBUNITArray::AVAILABLE_SUBUNITArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__IS_OPSTART_RECOMDArray= _orb->create_alias_tc("IDL:IS_OPSTART_RECOMDArray:1.0", "IS_OPSTART_RECOMDArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_IS_OPSTART_RECOMDArray = _tmp_tc__IS_OPSTART_RECOMDArray;
_orb->setClassInfo(::_tc_IS_OPSTART_RECOMDArray, &::IS_OPSTART_RECOMDArray::IS_OPSTART_RECOMDArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__BR_PARAMSArray= _orb->create_alias_tc("IDL:BR_PARAMSArray:1.0", "BR_PARAMSArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_BR_PARAMSArray = _tmp_tc__BR_PARAMSArray;
_orb->setClassInfo(::_tc_BR_PARAMSArray, &::BR_PARAMSArray::BR_PARAMSArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__FEEDFORWARD1Array= _orb->create_alias_tc("IDL:FEEDFORWARD1Array:1.0", "FEEDFORWARD1Array",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_FEEDFORWARD1Array = _tmp_tc__FEEDFORWARD1Array;
_orb->setClassInfo(::_tc_FEEDFORWARD1Array, &::FEEDFORWARD1Array::FEEDFORWARD1Array_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__FEEDFORWARD2Array= _orb->create_alias_tc("IDL:FEEDFORWARD2Array:1.0", "FEEDFORWARD2Array",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_FEEDFORWARD2Array = _tmp_tc__FEEDFORWARD2Array;
_orb->setClassInfo(::_tc_FEEDFORWARD2Array, &::FEEDFORWARD2Array::FEEDFORWARD2Array_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__FEEDFORWARD3Array= _orb->create_alias_tc("IDL:FEEDFORWARD3Array:1.0", "FEEDFORWARD3Array",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_FEEDFORWARD3Array = _tmp_tc__FEEDFORWARD3Array;
_orb->setClassInfo(::_tc_FEEDFORWARD3Array, &::FEEDFORWARD3Array::FEEDFORWARD3Array_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__FEEDFORWARD4Array= _orb->create_alias_tc("IDL:FEEDFORWARD4Array:1.0", "FEEDFORWARD4Array",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_FEEDFORWARD4Array = _tmp_tc__FEEDFORWARD4Array;
_orb->setClassInfo(::_tc_FEEDFORWARD4Array, &::FEEDFORWARD4Array::FEEDFORWARD4Array_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__NAMEArray= _orb->create_alias_tc("IDL:NAMEArray:1.0", "NAMEArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_NAMEArray = _tmp_tc__NAMEArray;
_orb->setClassInfo(::_tc_NAMEArray, &::NAMEArray::NAMEArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__VALUEArray= _orb->create_alias_tc("IDL:VALUEArray:1.0", "VALUEArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_VALUEArray = _tmp_tc__VALUEArray;
_orb->setClassInfo(::_tc_VALUEArray, &::VALUEArray::VALUEArray_1_Info );
::CORBA::StructMemberSeq _members__tmp_tc__ITEM_VALUE(2);
_members__tmp_tc__ITEM_VALUE.length(2);
::CORBA::StructMember _StructMember__members__tmp_tc__ITEM_VALUE;
_StructMember__members__tmp_tc__ITEM_VALUE.type_def = NULL;
_StructMember__members__tmp_tc__ITEM_VALUE.name = (const char *)"NAME";
_StructMember__members__tmp_tc__ITEM_VALUE.type = _tmp_tc__NAMEArray;
_members__tmp_tc__ITEM_VALUE[0] = _StructMember__members__tmp_tc__ITEM_VALUE;
_StructMember__members__tmp_tc__ITEM_VALUE.name = (const char *)"VALUE";
_StructMember__members__tmp_tc__ITEM_VALUE.type = _tmp_tc__VALUEArray;
_members__tmp_tc__ITEM_VALUE[1] = _StructMember__members__tmp_tc__ITEM_VALUE;
::CORBA::TypeCode_ptr _tmp_tc__ITEM_VALUE= _orb->create_struct_tc("IDL:ITEM_VALUE:1.0", "ITEM_VALUE", _members__tmp_tc__ITEM_VALUE, 0);
_tc_ITEM_VALUE = _tmp_tc__ITEM_VALUE;
_orb->setClassInfo(::_tc_ITEM_VALUE, &::ITEM_VALUE::ITEM_VALUE_Info );
::CORBA::TypeCode_ptr _tmp_tc__ArrayOfITEM_VALUE= _orb->create_alias_tc("IDL:ArrayOfITEM_VALUE:1.0", "ArrayOfITEM_VALUE",  _orb->create_sequence_tc(0, _tmp_tc__ITEM_VALUE, 0), 0);
_tc_ArrayOfITEM_VALUE = _tmp_tc__ArrayOfITEM_VALUE;
_orb->setClassInfo(::_tc_ArrayOfITEM_VALUE, &::ArrayOfITEM_VALUE::ArrayOfITEM_VALUE_0_Info );
::CORBA::TypeCode_ptr _tmp_tc__LD_EXTENDArray= _orb->create_alias_tc("IDL:LD_EXTENDArray:1.0", "LD_EXTENDArray",  _orb->create_sequence_tc(1, _tmp_tc__ArrayOfITEM_VALUE, 0), 0);
_tc_LD_EXTENDArray = _tmp_tc__LD_EXTENDArray;
_orb->setClassInfo(::_tc_LD_EXTENDArray, &::LD_EXTENDArray::LD_EXTENDArray_1_Info );
::CORBA::StructMemberSeq _members__tmp_tc__Innotron_Rec_APC_CONTEXT(26);
_members__tmp_tc__Innotron_Rec_APC_CONTEXT.length(26);
::CORBA::StructMember _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type_def = NULL;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"CONTROLJOBTYPE";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__CONTROLJOBTYPEArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[0] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"TRANSACTIONID";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__TRANSACTIONIDArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[1] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"LOTID";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__LOTIDArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[2] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"LOTTYPE";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__LOTTYPEArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[3] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"PARTID";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__PARTIDArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[4] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"LAYER";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__LAYERArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[5] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"ROUTE";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__ROUTEArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[6] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"ROUTEGROUP";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__ROUTEGROUPArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[7] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"OPERATION";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__OPERATIONArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[8] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"RETICLEID";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__RETICLEIDArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[9] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"PROCESSEQUIPTYPE";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__PROCESSEQUIPTYPEArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[10] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"PROCESSEQUIPID";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__PROCESSEQUIPIDArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[11] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"RECOMMENDMODE";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__RECOMMENDMODEArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[12] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"REWORK";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__REWORKArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[13] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"PARENTLOTID";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__PARENTLOTIDArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[14] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"PRETOOL";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__PRETOOLArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[15] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"SENDAHEAD";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__SENDAHEADArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[16] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"SENDAHEADVALUES";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__SENDAHEADVALUESArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[17] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"AVAILABLE_SUBUNIT";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__AVAILABLE_SUBUNITArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[18] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"IS_OPSTART_RECOMD";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__IS_OPSTART_RECOMDArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[19] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"BR_PARAMS";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__BR_PARAMSArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[20] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"FEEDFORWARD1";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__FEEDFORWARD1Array;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[21] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"FEEDFORWARD2";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__FEEDFORWARD2Array;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[22] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"FEEDFORWARD3";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__FEEDFORWARD3Array;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[23] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"FEEDFORWARD4";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__FEEDFORWARD4Array;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[24] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.name = (const char *)"LD_EXTEND";
_StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT.type = _tmp_tc__LD_EXTENDArray;
_members__tmp_tc__Innotron_Rec_APC_CONTEXT[25] = _StructMember__members__tmp_tc__Innotron_Rec_APC_CONTEXT;
::CORBA::TypeCode_ptr _tmp_tc__Innotron_Rec_APC_CONTEXT= _orb->create_struct_tc("IDL:Innotron_Rec_APC_CONTEXT:1.0", "Innotron_Rec_APC_CONTEXT", _members__tmp_tc__Innotron_Rec_APC_CONTEXT, 0);
_tc_Innotron_Rec_APC_CONTEXT = _tmp_tc__Innotron_Rec_APC_CONTEXT;
_orb->setClassInfo(::_tc_Innotron_Rec_APC_CONTEXT, &::Innotron_Rec_APC_CONTEXT::Innotron_Rec_APC_CONTEXT_Info );
::CORBA::TypeCode_ptr _tmp_tc__PARAMSArray= _orb->create_alias_tc("IDL:PARAMSArray:1.0", "PARAMSArray",  _orb->create_sequence_tc(1, _tmp_tc__ArrayOfITEM_VALUE, 0), 0);
_tc_PARAMSArray = _tmp_tc__PARAMSArray;
_orb->setClassInfo(::_tc_PARAMSArray, &::PARAMSArray::PARAMSArray_1_Info );
::CORBA::StructMemberSeq _members__tmp_tc__REC_Reticle(2);
_members__tmp_tc__REC_Reticle.length(2);
::CORBA::StructMember _StructMember__members__tmp_tc__REC_Reticle;
_StructMember__members__tmp_tc__REC_Reticle.type_def = NULL;
_StructMember__members__tmp_tc__REC_Reticle.name = (const char *)"RETICLEID";
_StructMember__members__tmp_tc__REC_Reticle.type = _tmp_tc__RETICLEIDArray;
_members__tmp_tc__REC_Reticle[0] = _StructMember__members__tmp_tc__REC_Reticle;
_StructMember__members__tmp_tc__REC_Reticle.name = (const char *)"PARAMS";
_StructMember__members__tmp_tc__REC_Reticle.type = _tmp_tc__PARAMSArray;
_members__tmp_tc__REC_Reticle[1] = _StructMember__members__tmp_tc__REC_Reticle;
::CORBA::TypeCode_ptr _tmp_tc__REC_Reticle= _orb->create_struct_tc("IDL:REC_Reticle:1.0", "REC_Reticle", _members__tmp_tc__REC_Reticle, 0);
_tc_REC_Reticle = _tmp_tc__REC_Reticle;
_orb->setClassInfo(::_tc_REC_Reticle, &::REC_Reticle::REC_Reticle_Info );
::CORBA::TypeCode_ptr _tmp_tc__ArrayOfREC_Reticle= _orb->create_alias_tc("IDL:ArrayOfREC_Reticle:1.0", "ArrayOfREC_Reticle",  _orb->create_sequence_tc(0, _tmp_tc__REC_Reticle, 0), 0);
_tc_ArrayOfREC_Reticle = _tmp_tc__ArrayOfREC_Reticle;
_orb->setClassInfo(::_tc_ArrayOfREC_Reticle, &::ArrayOfREC_Reticle::ArrayOfREC_Reticle_0_Info );
::CORBA::TypeCode_ptr _tmp_tc__WAFERIDArray= _orb->create_alias_tc("IDL:WAFERIDArray:1.0", "WAFERIDArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_WAFERIDArray = _tmp_tc__WAFERIDArray;
_orb->setClassInfo(::_tc_WAFERIDArray, &::WAFERIDArray::WAFERIDArray_1_Info );
::CORBA::StructMemberSeq _members__tmp_tc__WAFER(4);
_members__tmp_tc__WAFER.length(4);
::CORBA::StructMember _StructMember__members__tmp_tc__WAFER;
_StructMember__members__tmp_tc__WAFER.type_def = NULL;
_StructMember__members__tmp_tc__WAFER.name = (const char *)"SLOTNO";
_StructMember__members__tmp_tc__WAFER.type = ::CORBA::_tc_long;
_members__tmp_tc__WAFER[0] = _StructMember__members__tmp_tc__WAFER;
_StructMember__members__tmp_tc__WAFER.name = (const char *)"WAFERID";
_StructMember__members__tmp_tc__WAFER.type = _tmp_tc__WAFERIDArray;
_members__tmp_tc__WAFER[1] = _StructMember__members__tmp_tc__WAFER;
_StructMember__members__tmp_tc__WAFER.name = (const char *)"CHUCKID";
_StructMember__members__tmp_tc__WAFER.type = ::CORBA::_tc_long;
_members__tmp_tc__WAFER[2] = _StructMember__members__tmp_tc__WAFER;
_StructMember__members__tmp_tc__WAFER.name = (const char *)"REWORK_CNT";
_StructMember__members__tmp_tc__WAFER.type = ::CORBA::_tc_long;
_members__tmp_tc__WAFER[3] = _StructMember__members__tmp_tc__WAFER;
::CORBA::TypeCode_ptr _tmp_tc__WAFER= _orb->create_struct_tc("IDL:WAFER:1.0", "WAFER", _members__tmp_tc__WAFER, 0);
_tc_WAFER = _tmp_tc__WAFER;
_orb->setClassInfo(::_tc_WAFER, &::WAFER::WAFER_Info );
::CORBA::TypeCode_ptr _tmp_tc__ArrayOfWAFER= _orb->create_alias_tc("IDL:ArrayOfWAFER:1.0", "ArrayOfWAFER",  _orb->create_sequence_tc(0, _tmp_tc__WAFER, 0), 0);
_tc_ArrayOfWAFER = _tmp_tc__ArrayOfWAFER;
_orb->setClassInfo(::_tc_ArrayOfWAFER, &::ArrayOfWAFER::ArrayOfWAFER_0_Info );
::CORBA::TypeCode_ptr _tmp_tc__WAFERSArray= _orb->create_alias_tc("IDL:WAFERSArray:1.0", "WAFERSArray",  _orb->create_sequence_tc(1, _tmp_tc__ArrayOfWAFER, 0), 0);
_tc_WAFERSArray = _tmp_tc__WAFERSArray;
_orb->setClassInfo(::_tc_WAFERSArray, &::WAFERSArray::WAFERSArray_1_Info );
::CORBA::StructMemberSeq _members__tmp_tc__LOT(2);
_members__tmp_tc__LOT.length(2);
::CORBA::StructMember _StructMember__members__tmp_tc__LOT;
_StructMember__members__tmp_tc__LOT.type_def = NULL;
_StructMember__members__tmp_tc__LOT.name = (const char *)"LOTID";
_StructMember__members__tmp_tc__LOT.type = ::CORBA::_tc_long;
_members__tmp_tc__LOT[0] = _StructMember__members__tmp_tc__LOT;
_StructMember__members__tmp_tc__LOT.name = (const char *)"WAFERS";
_StructMember__members__tmp_tc__LOT.type = _tmp_tc__WAFERSArray;
_members__tmp_tc__LOT[1] = _StructMember__members__tmp_tc__LOT;
::CORBA::TypeCode_ptr _tmp_tc__LOT= _orb->create_struct_tc("IDL:LOT:1.0", "LOT", _members__tmp_tc__LOT, 0);
_tc_LOT = _tmp_tc__LOT;
_orb->setClassInfo(::_tc_LOT, &::LOT::LOT_Info );
::CORBA::TypeCode_ptr _tmp_tc__USED_TRANSACTIONIDArray= _orb->create_alias_tc("IDL:USED_TRANSACTIONIDArray:1.0", "USED_TRANSACTIONIDArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_USED_TRANSACTIONIDArray = _tmp_tc__USED_TRANSACTIONIDArray;
_orb->setClassInfo(::_tc_USED_TRANSACTIONIDArray, &::USED_TRANSACTIONIDArray::USED_TRANSACTIONIDArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__METROLOGYEQUIPTYPEArray= _orb->create_alias_tc("IDL:METROLOGYEQUIPTYPEArray:1.0", "METROLOGYEQUIPTYPEArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_METROLOGYEQUIPTYPEArray = _tmp_tc__METROLOGYEQUIPTYPEArray;
_orb->setClassInfo(::_tc_METROLOGYEQUIPTYPEArray, &::METROLOGYEQUIPTYPEArray::METROLOGYEQUIPTYPEArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__METROLOGYEQUIPIDArray= _orb->create_alias_tc("IDL:METROLOGYEQUIPIDArray:1.0", "METROLOGYEQUIPIDArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_METROLOGYEQUIPIDArray = _tmp_tc__METROLOGYEQUIPIDArray;
_orb->setClassInfo(::_tc_METROLOGYEQUIPIDArray, &::METROLOGYEQUIPIDArray::METROLOGYEQUIPIDArray_1_Info );
::CORBA::StructMemberSeq _members__tmp_tc__Innotron_Met_APC_CONTEXT(14);
_members__tmp_tc__Innotron_Met_APC_CONTEXT.length(14);
::CORBA::StructMember _StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.type_def = NULL;
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.name = (const char *)"CONTROLJOBTYPE";
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.type = _tmp_tc__CONTROLJOBTYPEArray;
_members__tmp_tc__Innotron_Met_APC_CONTEXT[0] = _StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.name = (const char *)"TRANSACTIONID";
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.type = _tmp_tc__TRANSACTIONIDArray;
_members__tmp_tc__Innotron_Met_APC_CONTEXT[1] = _StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.name = (const char *)"USED_TRANSACTIONID";
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.type = _tmp_tc__USED_TRANSACTIONIDArray;
_members__tmp_tc__Innotron_Met_APC_CONTEXT[2] = _StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.name = (const char *)"LOTID";
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.type = _tmp_tc__LOTIDArray;
_members__tmp_tc__Innotron_Met_APC_CONTEXT[3] = _StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.name = (const char *)"PARTID";
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.type = _tmp_tc__PARTIDArray;
_members__tmp_tc__Innotron_Met_APC_CONTEXT[4] = _StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.name = (const char *)"LAYER";
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.type = _tmp_tc__LAYERArray;
_members__tmp_tc__Innotron_Met_APC_CONTEXT[5] = _StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.name = (const char *)"ROUTE";
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.type = _tmp_tc__ROUTEArray;
_members__tmp_tc__Innotron_Met_APC_CONTEXT[6] = _StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.name = (const char *)"ROUTEGROUP";
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.type = _tmp_tc__ROUTEGROUPArray;
_members__tmp_tc__Innotron_Met_APC_CONTEXT[7] = _StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.name = (const char *)"OPERATION";
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.type = _tmp_tc__OPERATIONArray;
_members__tmp_tc__Innotron_Met_APC_CONTEXT[8] = _StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.name = (const char *)"RETICLEID";
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.type = _tmp_tc__RETICLEIDArray;
_members__tmp_tc__Innotron_Met_APC_CONTEXT[9] = _StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.name = (const char *)"METROLOGYEQUIPTYPE";
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.type = _tmp_tc__METROLOGYEQUIPTYPEArray;
_members__tmp_tc__Innotron_Met_APC_CONTEXT[10] = _StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.name = (const char *)"METROLOGYEQUIPID";
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.type = _tmp_tc__METROLOGYEQUIPIDArray;
_members__tmp_tc__Innotron_Met_APC_CONTEXT[11] = _StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.name = (const char *)"PROCESSEQUIPTYPE";
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.type = _tmp_tc__PROCESSEQUIPTYPEArray;
_members__tmp_tc__Innotron_Met_APC_CONTEXT[12] = _StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.name = (const char *)"PROCESSEQUIPID";
_StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT.type = _tmp_tc__PROCESSEQUIPIDArray;
_members__tmp_tc__Innotron_Met_APC_CONTEXT[13] = _StructMember__members__tmp_tc__Innotron_Met_APC_CONTEXT;
::CORBA::TypeCode_ptr _tmp_tc__Innotron_Met_APC_CONTEXT= _orb->create_struct_tc("IDL:Innotron_Met_APC_CONTEXT:1.0", "Innotron_Met_APC_CONTEXT", _members__tmp_tc__Innotron_Met_APC_CONTEXT, 0);
_tc_Innotron_Met_APC_CONTEXT = _tmp_tc__Innotron_Met_APC_CONTEXT;
_orb->setClassInfo(::_tc_Innotron_Met_APC_CONTEXT, &::Innotron_Met_APC_CONTEXT::Innotron_Met_APC_CONTEXT_Info );
::CORBA::TypeCode_ptr _tmp_tc__WAFERLISTArray= _orb->create_alias_tc("IDL:WAFERLISTArray:1.0", "WAFERLISTArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_WAFERLISTArray = _tmp_tc__WAFERLISTArray;
_orb->setClassInfo(::_tc_WAFERLISTArray, &::WAFERLISTArray::WAFERLISTArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__DCITEMSArray= _orb->create_alias_tc("IDL:DCITEMSArray:1.0", "DCITEMSArray",  _orb->create_sequence_tc(1, _tmp_tc__ArrayOfITEM_VALUE, 0), 0);
_tc_DCITEMSArray = _tmp_tc__DCITEMSArray;
_orb->setClassInfo(::_tc_DCITEMSArray, &::DCITEMSArray::DCITEMSArray_1_Info );
::CORBA::StructMemberSeq _members__tmp_tc__Met_Reticle(3);
_members__tmp_tc__Met_Reticle.length(3);
::CORBA::StructMember _StructMember__members__tmp_tc__Met_Reticle;
_StructMember__members__tmp_tc__Met_Reticle.type_def = NULL;
_StructMember__members__tmp_tc__Met_Reticle.name = (const char *)"RETICLEID";
_StructMember__members__tmp_tc__Met_Reticle.type = _tmp_tc__RETICLEIDArray;
_members__tmp_tc__Met_Reticle[0] = _StructMember__members__tmp_tc__Met_Reticle;
_StructMember__members__tmp_tc__Met_Reticle.name = (const char *)"WAFERLIST";
_StructMember__members__tmp_tc__Met_Reticle.type = _tmp_tc__WAFERLISTArray;
_members__tmp_tc__Met_Reticle[1] = _StructMember__members__tmp_tc__Met_Reticle;
_StructMember__members__tmp_tc__Met_Reticle.name = (const char *)"DCITEMS";
_StructMember__members__tmp_tc__Met_Reticle.type = _tmp_tc__DCITEMSArray;
_members__tmp_tc__Met_Reticle[2] = _StructMember__members__tmp_tc__Met_Reticle;
::CORBA::TypeCode_ptr _tmp_tc__Met_Reticle= _orb->create_struct_tc("IDL:Met_Reticle:1.0", "Met_Reticle", _members__tmp_tc__Met_Reticle, 0);
_tc_Met_Reticle = _tmp_tc__Met_Reticle;
_orb->setClassInfo(::_tc_Met_Reticle, &::Met_Reticle::Met_Reticle_Info );
::CORBA::TypeCode_ptr _tmp_tc__ArrayOfMet_Reticle= _orb->create_alias_tc("IDL:ArrayOfMet_Reticle:1.0", "ArrayOfMet_Reticle",  _orb->create_sequence_tc(0, _tmp_tc__Met_Reticle, 0), 0);
_tc_ArrayOfMet_Reticle = _tmp_tc__ArrayOfMet_Reticle;
_orb->setClassInfo(::_tc_ArrayOfMet_Reticle, &::ArrayOfMet_Reticle::ArrayOfMet_Reticle_0_Info );
::CORBA::TypeCode_ptr _tmp_tc__RETICLESArray= _orb->create_alias_tc("IDL:RETICLESArray:1.0", "RETICLESArray",  _orb->create_sequence_tc(1, _tmp_tc__ArrayOfMet_Reticle, 0), 0);
_tc_RETICLESArray = _tmp_tc__RETICLESArray;
_orb->setClassInfo(::_tc_RETICLESArray, &::RETICLESArray::RETICLESArray_1_Info );
::CORBA::StructMemberSeq _members__tmp_tc__Innotron_Met_Request(2);
_members__tmp_tc__Innotron_Met_Request.length(2);
::CORBA::StructMember _StructMember__members__tmp_tc__Innotron_Met_Request;
_StructMember__members__tmp_tc__Innotron_Met_Request.type_def = NULL;
_StructMember__members__tmp_tc__Innotron_Met_Request.name = (const char *)"APC_CONTEXT";
_StructMember__members__tmp_tc__Innotron_Met_Request.type = _tmp_tc__Innotron_Met_APC_CONTEXT;
_members__tmp_tc__Innotron_Met_Request[0] = _StructMember__members__tmp_tc__Innotron_Met_Request;
_StructMember__members__tmp_tc__Innotron_Met_Request.name = (const char *)"RETICLES";
_StructMember__members__tmp_tc__Innotron_Met_Request.type = _tmp_tc__RETICLESArray;
_members__tmp_tc__Innotron_Met_Request[1] = _StructMember__members__tmp_tc__Innotron_Met_Request;
::CORBA::TypeCode_ptr _tmp_tc__Innotron_Met_Request= _orb->create_struct_tc("IDL:Innotron_Met_Request:1.0", "Innotron_Met_Request", _members__tmp_tc__Innotron_Met_Request, 0);
_tc_Innotron_Met_Request = _tmp_tc__Innotron_Met_Request;
_orb->setClassInfo(::_tc_Innotron_Met_Request, &::Innotron_Met_Request::Innotron_Met_Request_Info );
::CORBA::TypeCode_ptr _tmp_tc__ArrayOfLOT= _orb->create_alias_tc("IDL:ArrayOfLOT:1.0", "ArrayOfLOT",  _orb->create_sequence_tc(0, _tmp_tc__LOT, 0), 0);
_tc_ArrayOfLOT = _tmp_tc__ArrayOfLOT;
_orb->setClassInfo(::_tc_ArrayOfLOT, &::ArrayOfLOT::ArrayOfLOT_0_Info );
::CORBA::TypeCode_ptr _tmp_tc__LOT_DATAArray= _orb->create_alias_tc("IDL:LOT_DATAArray:1.0", "LOT_DATAArray",  _orb->create_sequence_tc(1, _tmp_tc__ArrayOfLOT, 0), 0);
_tc_LOT_DATAArray = _tmp_tc__LOT_DATAArray;
_orb->setClassInfo(::_tc_LOT_DATAArray, &::LOT_DATAArray::LOT_DATAArray_1_Info );
::CORBA::StructMemberSeq _members__tmp_tc__Innotron_Recomd_Request(2);
_members__tmp_tc__Innotron_Recomd_Request.length(2);
::CORBA::StructMember _StructMember__members__tmp_tc__Innotron_Recomd_Request;
_StructMember__members__tmp_tc__Innotron_Recomd_Request.type_def = NULL;
_StructMember__members__tmp_tc__Innotron_Recomd_Request.name = (const char *)"APC_CONTEXT";
_StructMember__members__tmp_tc__Innotron_Recomd_Request.type = _tmp_tc__Innotron_Rec_APC_CONTEXT;
_members__tmp_tc__Innotron_Recomd_Request[0] = _StructMember__members__tmp_tc__Innotron_Recomd_Request;
_StructMember__members__tmp_tc__Innotron_Recomd_Request.name = (const char *)"LOT_DATA";
_StructMember__members__tmp_tc__Innotron_Recomd_Request.type = _tmp_tc__LOT_DATAArray;
_members__tmp_tc__Innotron_Recomd_Request[1] = _StructMember__members__tmp_tc__Innotron_Recomd_Request;
::CORBA::TypeCode_ptr _tmp_tc__Innotron_Recomd_Request= _orb->create_struct_tc("IDL:Innotron_Recomd_Request:1.0", "Innotron_Recomd_Request", _members__tmp_tc__Innotron_Recomd_Request, 0);
_tc_Innotron_Recomd_Request = _tmp_tc__Innotron_Recomd_Request;
_orb->setClassInfo(::_tc_Innotron_Recomd_Request, &::Innotron_Recomd_Request::Innotron_Recomd_Request_Info );
::CORBA::TypeCode_ptr _tmp_tc__REC_TRANSACTIONIDArray= _orb->create_alias_tc("IDL:REC_TRANSACTIONIDArray:1.0", "REC_TRANSACTIONIDArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_REC_TRANSACTIONIDArray = _tmp_tc__REC_TRANSACTIONIDArray;
_orb->setClassInfo(::_tc_REC_TRANSACTIONIDArray, &::REC_TRANSACTIONIDArray::REC_TRANSACTIONIDArray_1_Info );
::CORBA::StructMemberSeq _members__tmp_tc__Innotron_Used_APC_CONTEXT(22);
_members__tmp_tc__Innotron_Used_APC_CONTEXT.length(22);
::CORBA::StructMember _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type_def = NULL;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"CONTROLJOBTYPE";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__CONTROLJOBTYPEArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[0] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"TRANSACTIONID";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__TRANSACTIONIDArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[1] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"REC_TRANSACTIONID";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__REC_TRANSACTIONIDArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[2] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"LOTID";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__LOTIDArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[3] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"LOTTYPE";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__LOTTYPEArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[4] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"PARTID";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__PARTIDArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[5] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"LAYER";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__LAYERArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[6] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"ROUTE";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__ROUTEArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[7] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"ROUTEGROUP";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__ROUTEGROUPArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[8] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"OPERATION";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__OPERATIONArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[9] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"RETICLEID";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__RETICLEIDArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[10] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"PROCESSEQUIPTYPE";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__PROCESSEQUIPTYPEArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[11] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"PROCESSEQUIPID";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__PROCESSEQUIPIDArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[12] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"RECOMMENDMODE";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__RECOMMENDMODEArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[13] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"REWORK";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__REWORKArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[14] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"PARENTLOTID";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__PARENTLOTIDArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[15] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"PRETOOL";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__PRETOOLArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[16] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"SENDAHEAD";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__SENDAHEADArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[17] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"SENDAHEADVALUES";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__SENDAHEADVALUESArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[18] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"AVAILABLE_SUBUNIT";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__AVAILABLE_SUBUNITArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[19] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"IS_OPSTART_RECOMD";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__IS_OPSTART_RECOMDArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[20] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.name = (const char *)"LD_EXTEND";
_StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT.type = _tmp_tc__LD_EXTENDArray;
_members__tmp_tc__Innotron_Used_APC_CONTEXT[21] = _StructMember__members__tmp_tc__Innotron_Used_APC_CONTEXT;
::CORBA::TypeCode_ptr _tmp_tc__Innotron_Used_APC_CONTEXT= _orb->create_struct_tc("IDL:Innotron_Used_APC_CONTEXT:1.0", "Innotron_Used_APC_CONTEXT", _members__tmp_tc__Innotron_Used_APC_CONTEXT, 0);
_tc_Innotron_Used_APC_CONTEXT = _tmp_tc__Innotron_Used_APC_CONTEXT;
_orb->setClassInfo(::_tc_Innotron_Used_APC_CONTEXT, &::Innotron_Used_APC_CONTEXT::Innotron_Used_APC_CONTEXT_Info );
::CORBA::TypeCode_ptr _tmp_tc__STATUSSTRINGArray= _orb->create_alias_tc("IDL:STATUSSTRINGArray:1.0", "STATUSSTRINGArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_STATUSSTRINGArray = _tmp_tc__STATUSSTRINGArray;
_orb->setClassInfo(::_tc_STATUSSTRINGArray, &::STATUSSTRINGArray::STATUSSTRINGArray_1_Info );
::CORBA::TypeCode_ptr _tmp_tc__SAHD_REASONArray= _orb->create_alias_tc("IDL:SAHD_REASONArray:1.0", "SAHD_REASONArray",  _orb->create_sequence_tc(1, _orb->create_string_tc(0, 0), 0), 0);
_tc_SAHD_REASONArray = _tmp_tc__SAHD_REASONArray;
_orb->setClassInfo(::_tc_SAHD_REASONArray, &::SAHD_REASONArray::SAHD_REASONArray_1_Info );
::CORBA::StructMemberSeq _members__tmp_tc__Status(4);
_members__tmp_tc__Status.length(4);
::CORBA::StructMember _StructMember__members__tmp_tc__Status;
_StructMember__members__tmp_tc__Status.type_def = NULL;
_StructMember__members__tmp_tc__Status.name = (const char *)"STATUSCODE";
_StructMember__members__tmp_tc__Status.type = ::CORBA::_tc_long;
_members__tmp_tc__Status[0] = _StructMember__members__tmp_tc__Status;
_StructMember__members__tmp_tc__Status.name = (const char *)"STATUSSTRING";
_StructMember__members__tmp_tc__Status.type = _tmp_tc__STATUSSTRINGArray;
_members__tmp_tc__Status[1] = _StructMember__members__tmp_tc__Status;
_StructMember__members__tmp_tc__Status.name = (const char *)"SAHD_REQUEST";
_StructMember__members__tmp_tc__Status.type = ::CORBA::_tc_long;
_members__tmp_tc__Status[2] = _StructMember__members__tmp_tc__Status;
_StructMember__members__tmp_tc__Status.name = (const char *)"SAHD_REASON";
_StructMember__members__tmp_tc__Status.type = _tmp_tc__SAHD_REASONArray;
_members__tmp_tc__Status[3] = _StructMember__members__tmp_tc__Status;
::CORBA::TypeCode_ptr _tmp_tc__Status= _orb->create_struct_tc("IDL:Status:1.0", "Status", _members__tmp_tc__Status, 0);
_tc_Status = _tmp_tc__Status;
_orb->setClassInfo(::_tc_Status, &::Status::Status_Info );
::CORBA::StructMemberSeq _members__tmp_tc__Innotron_Recomd_Result(3);
_members__tmp_tc__Innotron_Recomd_Result.length(3);
::CORBA::StructMember _StructMember__members__tmp_tc__Innotron_Recomd_Result;
_StructMember__members__tmp_tc__Innotron_Recomd_Result.type_def = NULL;
_StructMember__members__tmp_tc__Innotron_Recomd_Result.name = (const char *)"APC_CONTEXT";
_StructMember__members__tmp_tc__Innotron_Recomd_Result.type = _tmp_tc__Innotron_Rec_APC_CONTEXT;
_members__tmp_tc__Innotron_Recomd_Result[0] = _StructMember__members__tmp_tc__Innotron_Recomd_Result;
_StructMember__members__tmp_tc__Innotron_Recomd_Result.name = (const char *)"APC_STATUS";
_StructMember__members__tmp_tc__Innotron_Recomd_Result.type = _tmp_tc__Status;
_members__tmp_tc__Innotron_Recomd_Result[1] = _StructMember__members__tmp_tc__Innotron_Recomd_Result;
_StructMember__members__tmp_tc__Innotron_Recomd_Result.name = (const char *)"RETICLES";
_StructMember__members__tmp_tc__Innotron_Recomd_Result.type = _tmp_tc__RETICLESArray;
_members__tmp_tc__Innotron_Recomd_Result[2] = _StructMember__members__tmp_tc__Innotron_Recomd_Result;
::CORBA::TypeCode_ptr _tmp_tc__Innotron_Recomd_Result= _orb->create_struct_tc("IDL:Innotron_Recomd_Result:1.0", "Innotron_Recomd_Result", _members__tmp_tc__Innotron_Recomd_Result, 0);
_tc_Innotron_Recomd_Result = _tmp_tc__Innotron_Recomd_Result;
_orb->setClassInfo(::_tc_Innotron_Recomd_Result, &::Innotron_Recomd_Result::Innotron_Recomd_Result_Info );
::CORBA::StructMemberSeq _members__tmp_tc__Innotron_Used_Result(2);
_members__tmp_tc__Innotron_Used_Result.length(2);
::CORBA::StructMember _StructMember__members__tmp_tc__Innotron_Used_Result;
_StructMember__members__tmp_tc__Innotron_Used_Result.type_def = NULL;
_StructMember__members__tmp_tc__Innotron_Used_Result.name = (const char *)"APC_CONTEXT";
_StructMember__members__tmp_tc__Innotron_Used_Result.type = _tmp_tc__Innotron_Used_APC_CONTEXT;
_members__tmp_tc__Innotron_Used_Result[0] = _StructMember__members__tmp_tc__Innotron_Used_Result;
_StructMember__members__tmp_tc__Innotron_Used_Result.name = (const char *)"APC_STATUS";
_StructMember__members__tmp_tc__Innotron_Used_Result.type = _tmp_tc__Status;
_members__tmp_tc__Innotron_Used_Result[1] = _StructMember__members__tmp_tc__Innotron_Used_Result;
::CORBA::TypeCode_ptr _tmp_tc__Innotron_Used_Result= _orb->create_struct_tc("IDL:Innotron_Used_Result:1.0", "Innotron_Used_Result", _members__tmp_tc__Innotron_Used_Result, 0);
_tc_Innotron_Used_Result = _tmp_tc__Innotron_Used_Result;
_orb->setClassInfo(::_tc_Innotron_Used_Result, &::Innotron_Used_Result::Innotron_Used_Result_Info );
::CORBA::StructMemberSeq _members__tmp_tc__Innotron_Met_Result(2);
_members__tmp_tc__Innotron_Met_Result.length(2);
::CORBA::StructMember _StructMember__members__tmp_tc__Innotron_Met_Result;
_StructMember__members__tmp_tc__Innotron_Met_Result.type_def = NULL;
_StructMember__members__tmp_tc__Innotron_Met_Result.name = (const char *)"APC_CONTEXT";
_StructMember__members__tmp_tc__Innotron_Met_Result.type = _tmp_tc__Innotron_Met_APC_CONTEXT;
_members__tmp_tc__Innotron_Met_Result[0] = _StructMember__members__tmp_tc__Innotron_Met_Result;
_StructMember__members__tmp_tc__Innotron_Met_Result.name = (const char *)"APC_STATUS";
_StructMember__members__tmp_tc__Innotron_Met_Result.type = _tmp_tc__Status;
_members__tmp_tc__Innotron_Met_Result[1] = _StructMember__members__tmp_tc__Innotron_Met_Result;
::CORBA::TypeCode_ptr _tmp_tc__Innotron_Met_Result= _orb->create_struct_tc("IDL:Innotron_Met_Result:1.0", "Innotron_Met_Result", _members__tmp_tc__Innotron_Met_Result, 0);
_tc_Innotron_Met_Result = _tmp_tc__Innotron_Met_Result;
_orb->setClassInfo(::_tc_Innotron_Met_Result, &::Innotron_Met_Result::Innotron_Met_Result_Info );
::CORBA::StructMemberSeq _members__tmp_tc__Innotron_Used_Request(3);
_members__tmp_tc__Innotron_Used_Request.length(3);
::CORBA::StructMember _StructMember__members__tmp_tc__Innotron_Used_Request;
_StructMember__members__tmp_tc__Innotron_Used_Request.type_def = NULL;
_StructMember__members__tmp_tc__Innotron_Used_Request.name = (const char *)"APC_CONTEXT";
_StructMember__members__tmp_tc__Innotron_Used_Request.type = _tmp_tc__Innotron_Used_APC_CONTEXT;
_members__tmp_tc__Innotron_Used_Request[0] = _StructMember__members__tmp_tc__Innotron_Used_Request;
_StructMember__members__tmp_tc__Innotron_Used_Request.name = (const char *)"LOT_DATA";
_StructMember__members__tmp_tc__Innotron_Used_Request.type = _tmp_tc__LOT_DATAArray;
_members__tmp_tc__Innotron_Used_Request[1] = _StructMember__members__tmp_tc__Innotron_Used_Request;
_StructMember__members__tmp_tc__Innotron_Used_Request.name = (const char *)"RETICLES";
_StructMember__members__tmp_tc__Innotron_Used_Request.type = _tmp_tc__RETICLESArray;
_members__tmp_tc__Innotron_Used_Request[2] = _StructMember__members__tmp_tc__Innotron_Used_Request;
::CORBA::TypeCode_ptr _tmp_tc__Innotron_Used_Request= _orb->create_struct_tc("IDL:Innotron_Used_Request:1.0", "Innotron_Used_Request", _members__tmp_tc__Innotron_Used_Request, 0);
_tc_Innotron_Used_Request = _tmp_tc__Innotron_Used_Request;
_orb->setClassInfo(::_tc_Innotron_Used_Request, &::Innotron_Used_Request::Innotron_Used_Request_Info );
::CORBA::StructMemberSeq _members__tmp_tc__Metrology_RequestResponse(1);
_members__tmp_tc__Metrology_RequestResponse.length(1);
::CORBA::StructMember _StructMember__members__tmp_tc__Metrology_RequestResponse;
_StructMember__members__tmp_tc__Metrology_RequestResponse.type_def = NULL;
_StructMember__members__tmp_tc__Metrology_RequestResponse.name = (const char *)"Metrology_RequestResult";
_StructMember__members__tmp_tc__Metrology_RequestResponse.type = _tmp_tc__Innotron_Met_Result;
_members__tmp_tc__Metrology_RequestResponse[0] = _StructMember__members__tmp_tc__Metrology_RequestResponse;
::CORBA::TypeCode_ptr _tmp_tc__Metrology_RequestResponse= _orb->create_struct_tc("IDL:Metrology_RequestResponse:1.0", "Metrology_RequestResponse", _members__tmp_tc__Metrology_RequestResponse, 0);
_tc_Metrology_RequestResponse = _tmp_tc__Metrology_RequestResponse;
_orb->setClassInfo(::_tc_Metrology_RequestResponse, &::Metrology_RequestResponse::Metrology_RequestResponse_Info );
::CORBA::StructMemberSeq _members__tmp_tc__Used_RequestResponse(1);
_members__tmp_tc__Used_RequestResponse.length(1);
::CORBA::StructMember _StructMember__members__tmp_tc__Used_RequestResponse;
_StructMember__members__tmp_tc__Used_RequestResponse.type_def = NULL;
_StructMember__members__tmp_tc__Used_RequestResponse.name = (const char *)"Used_RequestResult";
_StructMember__members__tmp_tc__Used_RequestResponse.type = _tmp_tc__Innotron_Used_Result;
_members__tmp_tc__Used_RequestResponse[0] = _StructMember__members__tmp_tc__Used_RequestResponse;
::CORBA::TypeCode_ptr _tmp_tc__Used_RequestResponse= _orb->create_struct_tc("IDL:Used_RequestResponse:1.0", "Used_RequestResponse", _members__tmp_tc__Used_RequestResponse, 0);
_tc_Used_RequestResponse = _tmp_tc__Used_RequestResponse;
_orb->setClassInfo(::_tc_Used_RequestResponse, &::Used_RequestResponse::Used_RequestResponse_Info );
::CORBA::StructMemberSeq _members__tmp_tc__Metrology_Request(1);
_members__tmp_tc__Metrology_Request.length(1);
::CORBA::StructMember _StructMember__members__tmp_tc__Metrology_Request;
_StructMember__members__tmp_tc__Metrology_Request.type_def = NULL;
_StructMember__members__tmp_tc__Metrology_Request.name = (const char *)"objRequest";
_StructMember__members__tmp_tc__Metrology_Request.type = _tmp_tc__Innotron_Met_Request;
_members__tmp_tc__Metrology_Request[0] = _StructMember__members__tmp_tc__Metrology_Request;
::CORBA::TypeCode_ptr _tmp_tc__Metrology_Request= _orb->create_struct_tc("IDL:Metrology_Request:1.0", "Metrology_Request", _members__tmp_tc__Metrology_Request, 0);
_tc_Metrology_Request = _tmp_tc__Metrology_Request;
_orb->setClassInfo(::_tc_Metrology_Request, &::Metrology_Request::Metrology_Request_Info );
::CORBA::StructMemberSeq _members__tmp_tc__Recommend_RequestResponse(1);
_members__tmp_tc__Recommend_RequestResponse.length(1);
::CORBA::StructMember _StructMember__members__tmp_tc__Recommend_RequestResponse;
_StructMember__members__tmp_tc__Recommend_RequestResponse.type_def = NULL;
_StructMember__members__tmp_tc__Recommend_RequestResponse.name = (const char *)"Recommend_RequestResult";
_StructMember__members__tmp_tc__Recommend_RequestResponse.type = _tmp_tc__Innotron_Recomd_Result;
_members__tmp_tc__Recommend_RequestResponse[0] = _StructMember__members__tmp_tc__Recommend_RequestResponse;
::CORBA::TypeCode_ptr _tmp_tc__Recommend_RequestResponse= _orb->create_struct_tc("IDL:Recommend_RequestResponse:1.0", "Recommend_RequestResponse", _members__tmp_tc__Recommend_RequestResponse, 0);
_tc_Recommend_RequestResponse = _tmp_tc__Recommend_RequestResponse;
_orb->setClassInfo(::_tc_Recommend_RequestResponse, &::Recommend_RequestResponse::Recommend_RequestResponse_Info );
::CORBA::StructMemberSeq _members__tmp_tc__Used_Request(1);
_members__tmp_tc__Used_Request.length(1);
::CORBA::StructMember _StructMember__members__tmp_tc__Used_Request;
_StructMember__members__tmp_tc__Used_Request.type_def = NULL;
_StructMember__members__tmp_tc__Used_Request.name = (const char *)"objRequest";
_StructMember__members__tmp_tc__Used_Request.type = _tmp_tc__Innotron_Used_Request;
_members__tmp_tc__Used_Request[0] = _StructMember__members__tmp_tc__Used_Request;
::CORBA::TypeCode_ptr _tmp_tc__Used_Request= _orb->create_struct_tc("IDL:Used_Request:1.0", "Used_Request", _members__tmp_tc__Used_Request, 0);
_tc_Used_Request = _tmp_tc__Used_Request;
_orb->setClassInfo(::_tc_Used_Request, &::Used_Request::Used_Request_Info );
::CORBA::StructMemberSeq _members__tmp_tc__Recommend_Request(1);
_members__tmp_tc__Recommend_Request.length(1);
::CORBA::StructMember _StructMember__members__tmp_tc__Recommend_Request;
_StructMember__members__tmp_tc__Recommend_Request.type_def = NULL;
_StructMember__members__tmp_tc__Recommend_Request.name = (const char *)"objRequest";
_StructMember__members__tmp_tc__Recommend_Request.type = _tmp_tc__Innotron_Recomd_Request;
_members__tmp_tc__Recommend_Request[0] = _StructMember__members__tmp_tc__Recommend_Request;
::CORBA::TypeCode_ptr _tmp_tc__Recommend_Request= _orb->create_struct_tc("IDL:Recommend_Request:1.0", "Recommend_Request", _members__tmp_tc__Recommend_Request, 0);
_tc_Recommend_Request = _tmp_tc__Recommend_Request;
_orb->setClassInfo(::_tc_Recommend_Request, &::Recommend_Request::Recommend_Request_Info );
}
static ::CORBA::TypeCodeInitStruct __cs_apcstr_TypeCodeInitStruct = { __cs_apcstr_emit_tc, 0 , "cs_apcstr"};
static ::CORBA::TypeCodeInitializer __cs_apcstr_TypeCodeInitializer(&__cs_apcstr_TypeCodeInitStruct);
/*
 * Overloaded CORBA::Any operators.
 */
#ifndef _Anyops_for_ITEM_VALUE
#define _Anyops_for_ITEM_VALUE
void operator <<= (::CORBA::Any& _any, const ::ITEM_VALUE &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::ITEM_VALUE(_data);
   _any.replace(::_tc_ITEM_VALUE, (void*)EB_dc, 1, &ITEM_VALUE::ITEM_VALUE_Info);
}
void operator <<= (::CORBA::Any& _any, ::ITEM_VALUE *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_ITEM_VALUE, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::ITEM_VALUE*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_ITEM_VALUE)) {
     _data = (::ITEM_VALUE*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::ITEM_VALUE*& _data)
{
   return operator>>=(_any, (::ITEM_VALUE*&)_data );
}
#endif // _Anyops_for_ITEM_VALUE
#ifndef _Anyops_for__IDL_SEQ_ArrayOfITEM_VALUE_0
#define _Anyops_for__IDL_SEQ_ArrayOfITEM_VALUE_0
void operator <<= (::CORBA::Any& _any, const ::ArrayOfITEM_VALUE &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::ArrayOfITEM_VALUE(_data);
   _any.replace(::_tc_ArrayOfITEM_VALUE, (void*)EB_dc, 1, &::ArrayOfITEM_VALUE::ArrayOfITEM_VALUE_0_Info );
}
void operator <<= (::CORBA::Any& _any, ::ArrayOfITEM_VALUE *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_ArrayOfITEM_VALUE, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::ArrayOfITEM_VALUE*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_ArrayOfITEM_VALUE)) {
     _data = (::ArrayOfITEM_VALUE*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::ArrayOfITEM_VALUE*& _data)
{
   return operator>>=(_any, (::ArrayOfITEM_VALUE*&)_data );
}
#endif // _Anyops_for__IDL_SEQ_ArrayOfITEM_VALUE_0
#ifndef _Anyops_for__IDL_SEQ_LD_EXTENDArray_1
#define _Anyops_for__IDL_SEQ_LD_EXTENDArray_1
void operator <<= (::CORBA::Any& _any, const ::LD_EXTENDArray &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::LD_EXTENDArray(_data);
   _any.replace(::_tc_LD_EXTENDArray, (void*)EB_dc, 1, &::LD_EXTENDArray::LD_EXTENDArray_1_Info );
}
void operator <<= (::CORBA::Any& _any, ::LD_EXTENDArray *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_LD_EXTENDArray, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::LD_EXTENDArray*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_LD_EXTENDArray)) {
     _data = (::LD_EXTENDArray*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::LD_EXTENDArray*& _data)
{
   return operator>>=(_any, (::LD_EXTENDArray*&)_data );
}
#endif // _Anyops_for__IDL_SEQ_LD_EXTENDArray_1
#ifndef _Anyops_for_Innotron_Rec_APC_CONTEXT
#define _Anyops_for_Innotron_Rec_APC_CONTEXT
void operator <<= (::CORBA::Any& _any, const ::Innotron_Rec_APC_CONTEXT &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::Innotron_Rec_APC_CONTEXT(_data);
   _any.replace(::_tc_Innotron_Rec_APC_CONTEXT, (void*)EB_dc, 1, &Innotron_Rec_APC_CONTEXT::Innotron_Rec_APC_CONTEXT_Info);
}
void operator <<= (::CORBA::Any& _any, ::Innotron_Rec_APC_CONTEXT *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_Innotron_Rec_APC_CONTEXT, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Innotron_Rec_APC_CONTEXT*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_Innotron_Rec_APC_CONTEXT)) {
     _data = (::Innotron_Rec_APC_CONTEXT*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Innotron_Rec_APC_CONTEXT*& _data)
{
   return operator>>=(_any, (::Innotron_Rec_APC_CONTEXT*&)_data );
}
#endif // _Anyops_for_Innotron_Rec_APC_CONTEXT
#ifndef _Anyops_for__IDL_SEQ_PARAMSArray_1
#define _Anyops_for__IDL_SEQ_PARAMSArray_1
void operator <<= (::CORBA::Any& _any, const ::PARAMSArray &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::PARAMSArray(_data);
   _any.replace(::_tc_PARAMSArray, (void*)EB_dc, 1, &::PARAMSArray::PARAMSArray_1_Info );
}
void operator <<= (::CORBA::Any& _any, ::PARAMSArray *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_PARAMSArray, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::PARAMSArray*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_PARAMSArray)) {
     _data = (::PARAMSArray*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::PARAMSArray*& _data)
{
   return operator>>=(_any, (::PARAMSArray*&)_data );
}
#endif // _Anyops_for__IDL_SEQ_PARAMSArray_1
#ifndef _Anyops_for_REC_Reticle
#define _Anyops_for_REC_Reticle
void operator <<= (::CORBA::Any& _any, const ::REC_Reticle &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::REC_Reticle(_data);
   _any.replace(::_tc_REC_Reticle, (void*)EB_dc, 1, &REC_Reticle::REC_Reticle_Info);
}
void operator <<= (::CORBA::Any& _any, ::REC_Reticle *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_REC_Reticle, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::REC_Reticle*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_REC_Reticle)) {
     _data = (::REC_Reticle*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::REC_Reticle*& _data)
{
   return operator>>=(_any, (::REC_Reticle*&)_data );
}
#endif // _Anyops_for_REC_Reticle
#ifndef _Anyops_for__IDL_SEQ_ArrayOfREC_Reticle_0
#define _Anyops_for__IDL_SEQ_ArrayOfREC_Reticle_0
void operator <<= (::CORBA::Any& _any, const ::ArrayOfREC_Reticle &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::ArrayOfREC_Reticle(_data);
   _any.replace(::_tc_ArrayOfREC_Reticle, (void*)EB_dc, 1, &::ArrayOfREC_Reticle::ArrayOfREC_Reticle_0_Info );
}
void operator <<= (::CORBA::Any& _any, ::ArrayOfREC_Reticle *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_ArrayOfREC_Reticle, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::ArrayOfREC_Reticle*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_ArrayOfREC_Reticle)) {
     _data = (::ArrayOfREC_Reticle*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::ArrayOfREC_Reticle*& _data)
{
   return operator>>=(_any, (::ArrayOfREC_Reticle*&)_data );
}
#endif // _Anyops_for__IDL_SEQ_ArrayOfREC_Reticle_0
#ifndef _Anyops_for_WAFER
#define _Anyops_for_WAFER
void operator <<= (::CORBA::Any& _any, const ::WAFER &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::WAFER(_data);
   _any.replace(::_tc_WAFER, (void*)EB_dc, 1, &WAFER::WAFER_Info);
}
void operator <<= (::CORBA::Any& _any, ::WAFER *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_WAFER, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::WAFER*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_WAFER)) {
     _data = (::WAFER*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::WAFER*& _data)
{
   return operator>>=(_any, (::WAFER*&)_data );
}
#endif // _Anyops_for_WAFER
#ifndef _Anyops_for__IDL_SEQ_ArrayOfWAFER_0
#define _Anyops_for__IDL_SEQ_ArrayOfWAFER_0
void operator <<= (::CORBA::Any& _any, const ::ArrayOfWAFER &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::ArrayOfWAFER(_data);
   _any.replace(::_tc_ArrayOfWAFER, (void*)EB_dc, 1, &::ArrayOfWAFER::ArrayOfWAFER_0_Info );
}
void operator <<= (::CORBA::Any& _any, ::ArrayOfWAFER *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_ArrayOfWAFER, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::ArrayOfWAFER*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_ArrayOfWAFER)) {
     _data = (::ArrayOfWAFER*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::ArrayOfWAFER*& _data)
{
   return operator>>=(_any, (::ArrayOfWAFER*&)_data );
}
#endif // _Anyops_for__IDL_SEQ_ArrayOfWAFER_0
#ifndef _Anyops_for__IDL_SEQ_WAFERSArray_1
#define _Anyops_for__IDL_SEQ_WAFERSArray_1
void operator <<= (::CORBA::Any& _any, const ::WAFERSArray &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::WAFERSArray(_data);
   _any.replace(::_tc_WAFERSArray, (void*)EB_dc, 1, &::WAFERSArray::WAFERSArray_1_Info );
}
void operator <<= (::CORBA::Any& _any, ::WAFERSArray *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_WAFERSArray, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::WAFERSArray*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_WAFERSArray)) {
     _data = (::WAFERSArray*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::WAFERSArray*& _data)
{
   return operator>>=(_any, (::WAFERSArray*&)_data );
}
#endif // _Anyops_for__IDL_SEQ_WAFERSArray_1
#ifndef _Anyops_for_LOT
#define _Anyops_for_LOT
void operator <<= (::CORBA::Any& _any, const ::LOT &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::LOT(_data);
   _any.replace(::_tc_LOT, (void*)EB_dc, 1, &LOT::LOT_Info);
}
void operator <<= (::CORBA::Any& _any, ::LOT *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_LOT, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::LOT*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_LOT)) {
     _data = (::LOT*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::LOT*& _data)
{
   return operator>>=(_any, (::LOT*&)_data );
}
#endif // _Anyops_for_LOT
#ifndef _Anyops_for_Innotron_Met_APC_CONTEXT
#define _Anyops_for_Innotron_Met_APC_CONTEXT
void operator <<= (::CORBA::Any& _any, const ::Innotron_Met_APC_CONTEXT &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::Innotron_Met_APC_CONTEXT(_data);
   _any.replace(::_tc_Innotron_Met_APC_CONTEXT, (void*)EB_dc, 1, &Innotron_Met_APC_CONTEXT::Innotron_Met_APC_CONTEXT_Info);
}
void operator <<= (::CORBA::Any& _any, ::Innotron_Met_APC_CONTEXT *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_Innotron_Met_APC_CONTEXT, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Innotron_Met_APC_CONTEXT*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_Innotron_Met_APC_CONTEXT)) {
     _data = (::Innotron_Met_APC_CONTEXT*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Innotron_Met_APC_CONTEXT*& _data)
{
   return operator>>=(_any, (::Innotron_Met_APC_CONTEXT*&)_data );
}
#endif // _Anyops_for_Innotron_Met_APC_CONTEXT
#ifndef _Anyops_for__IDL_SEQ_DCITEMSArray_1
#define _Anyops_for__IDL_SEQ_DCITEMSArray_1
void operator <<= (::CORBA::Any& _any, const ::DCITEMSArray &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::DCITEMSArray(_data);
   _any.replace(::_tc_DCITEMSArray, (void*)EB_dc, 1, &::DCITEMSArray::DCITEMSArray_1_Info );
}
void operator <<= (::CORBA::Any& _any, ::DCITEMSArray *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_DCITEMSArray, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::DCITEMSArray*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_DCITEMSArray)) {
     _data = (::DCITEMSArray*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::DCITEMSArray*& _data)
{
   return operator>>=(_any, (::DCITEMSArray*&)_data );
}
#endif // _Anyops_for__IDL_SEQ_DCITEMSArray_1
#ifndef _Anyops_for_Met_Reticle
#define _Anyops_for_Met_Reticle
void operator <<= (::CORBA::Any& _any, const ::Met_Reticle &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::Met_Reticle(_data);
   _any.replace(::_tc_Met_Reticle, (void*)EB_dc, 1, &Met_Reticle::Met_Reticle_Info);
}
void operator <<= (::CORBA::Any& _any, ::Met_Reticle *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_Met_Reticle, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Met_Reticle*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_Met_Reticle)) {
     _data = (::Met_Reticle*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Met_Reticle*& _data)
{
   return operator>>=(_any, (::Met_Reticle*&)_data );
}
#endif // _Anyops_for_Met_Reticle
#ifndef _Anyops_for__IDL_SEQ_ArrayOfMet_Reticle_0
#define _Anyops_for__IDL_SEQ_ArrayOfMet_Reticle_0
void operator <<= (::CORBA::Any& _any, const ::ArrayOfMet_Reticle &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::ArrayOfMet_Reticle(_data);
   _any.replace(::_tc_ArrayOfMet_Reticle, (void*)EB_dc, 1, &::ArrayOfMet_Reticle::ArrayOfMet_Reticle_0_Info );
}
void operator <<= (::CORBA::Any& _any, ::ArrayOfMet_Reticle *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_ArrayOfMet_Reticle, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::ArrayOfMet_Reticle*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_ArrayOfMet_Reticle)) {
     _data = (::ArrayOfMet_Reticle*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::ArrayOfMet_Reticle*& _data)
{
   return operator>>=(_any, (::ArrayOfMet_Reticle*&)_data );
}
#endif // _Anyops_for__IDL_SEQ_ArrayOfMet_Reticle_0
#ifndef _Anyops_for__IDL_SEQ_RETICLESArray_1
#define _Anyops_for__IDL_SEQ_RETICLESArray_1
void operator <<= (::CORBA::Any& _any, const ::RETICLESArray &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::RETICLESArray(_data);
   _any.replace(::_tc_RETICLESArray, (void*)EB_dc, 1, &::RETICLESArray::RETICLESArray_1_Info );
}
void operator <<= (::CORBA::Any& _any, ::RETICLESArray *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_RETICLESArray, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::RETICLESArray*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_RETICLESArray)) {
     _data = (::RETICLESArray*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::RETICLESArray*& _data)
{
   return operator>>=(_any, (::RETICLESArray*&)_data );
}
#endif // _Anyops_for__IDL_SEQ_RETICLESArray_1
#ifndef _Anyops_for_Innotron_Met_Request
#define _Anyops_for_Innotron_Met_Request
void operator <<= (::CORBA::Any& _any, const ::Innotron_Met_Request &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::Innotron_Met_Request(_data);
   _any.replace(::_tc_Innotron_Met_Request, (void*)EB_dc, 1, &Innotron_Met_Request::Innotron_Met_Request_Info);
}
void operator <<= (::CORBA::Any& _any, ::Innotron_Met_Request *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_Innotron_Met_Request, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Innotron_Met_Request*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_Innotron_Met_Request)) {
     _data = (::Innotron_Met_Request*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Innotron_Met_Request*& _data)
{
   return operator>>=(_any, (::Innotron_Met_Request*&)_data );
}
#endif // _Anyops_for_Innotron_Met_Request
#ifndef _Anyops_for__IDL_SEQ_ArrayOfLOT_0
#define _Anyops_for__IDL_SEQ_ArrayOfLOT_0
void operator <<= (::CORBA::Any& _any, const ::ArrayOfLOT &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::ArrayOfLOT(_data);
   _any.replace(::_tc_ArrayOfLOT, (void*)EB_dc, 1, &::ArrayOfLOT::ArrayOfLOT_0_Info );
}
void operator <<= (::CORBA::Any& _any, ::ArrayOfLOT *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_ArrayOfLOT, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::ArrayOfLOT*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_ArrayOfLOT)) {
     _data = (::ArrayOfLOT*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::ArrayOfLOT*& _data)
{
   return operator>>=(_any, (::ArrayOfLOT*&)_data );
}
#endif // _Anyops_for__IDL_SEQ_ArrayOfLOT_0
#ifndef _Anyops_for__IDL_SEQ_LOT_DATAArray_1
#define _Anyops_for__IDL_SEQ_LOT_DATAArray_1
void operator <<= (::CORBA::Any& _any, const ::LOT_DATAArray &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::LOT_DATAArray(_data);
   _any.replace(::_tc_LOT_DATAArray, (void*)EB_dc, 1, &::LOT_DATAArray::LOT_DATAArray_1_Info );
}
void operator <<= (::CORBA::Any& _any, ::LOT_DATAArray *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_LOT_DATAArray, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::LOT_DATAArray*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_LOT_DATAArray)) {
     _data = (::LOT_DATAArray*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::LOT_DATAArray*& _data)
{
   return operator>>=(_any, (::LOT_DATAArray*&)_data );
}
#endif // _Anyops_for__IDL_SEQ_LOT_DATAArray_1
#ifndef _Anyops_for_Innotron_Recomd_Request
#define _Anyops_for_Innotron_Recomd_Request
void operator <<= (::CORBA::Any& _any, const ::Innotron_Recomd_Request &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::Innotron_Recomd_Request(_data);
   _any.replace(::_tc_Innotron_Recomd_Request, (void*)EB_dc, 1, &Innotron_Recomd_Request::Innotron_Recomd_Request_Info);
}
void operator <<= (::CORBA::Any& _any, ::Innotron_Recomd_Request *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_Innotron_Recomd_Request, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Innotron_Recomd_Request*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_Innotron_Recomd_Request)) {
     _data = (::Innotron_Recomd_Request*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Innotron_Recomd_Request*& _data)
{
   return operator>>=(_any, (::Innotron_Recomd_Request*&)_data );
}
#endif // _Anyops_for_Innotron_Recomd_Request
#ifndef _Anyops_for_Innotron_Used_APC_CONTEXT
#define _Anyops_for_Innotron_Used_APC_CONTEXT
void operator <<= (::CORBA::Any& _any, const ::Innotron_Used_APC_CONTEXT &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::Innotron_Used_APC_CONTEXT(_data);
   _any.replace(::_tc_Innotron_Used_APC_CONTEXT, (void*)EB_dc, 1, &Innotron_Used_APC_CONTEXT::Innotron_Used_APC_CONTEXT_Info);
}
void operator <<= (::CORBA::Any& _any, ::Innotron_Used_APC_CONTEXT *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_Innotron_Used_APC_CONTEXT, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Innotron_Used_APC_CONTEXT*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_Innotron_Used_APC_CONTEXT)) {
     _data = (::Innotron_Used_APC_CONTEXT*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Innotron_Used_APC_CONTEXT*& _data)
{
   return operator>>=(_any, (::Innotron_Used_APC_CONTEXT*&)_data );
}
#endif // _Anyops_for_Innotron_Used_APC_CONTEXT
#ifndef _Anyops_for_Status
#define _Anyops_for_Status
void operator <<= (::CORBA::Any& _any, const ::Status &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::Status(_data);
   _any.replace(::_tc_Status, (void*)EB_dc, 1, &Status::Status_Info);
}
void operator <<= (::CORBA::Any& _any, ::Status *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_Status, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Status*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_Status)) {
     _data = (::Status*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Status*& _data)
{
   return operator>>=(_any, (::Status*&)_data );
}
#endif // _Anyops_for_Status
#ifndef _Anyops_for_Innotron_Recomd_Result
#define _Anyops_for_Innotron_Recomd_Result
void operator <<= (::CORBA::Any& _any, const ::Innotron_Recomd_Result &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::Innotron_Recomd_Result(_data);
   _any.replace(::_tc_Innotron_Recomd_Result, (void*)EB_dc, 1, &Innotron_Recomd_Result::Innotron_Recomd_Result_Info);
}
void operator <<= (::CORBA::Any& _any, ::Innotron_Recomd_Result *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_Innotron_Recomd_Result, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Innotron_Recomd_Result*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_Innotron_Recomd_Result)) {
     _data = (::Innotron_Recomd_Result*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Innotron_Recomd_Result*& _data)
{
   return operator>>=(_any, (::Innotron_Recomd_Result*&)_data );
}
#endif // _Anyops_for_Innotron_Recomd_Result
#ifndef _Anyops_for_Innotron_Used_Result
#define _Anyops_for_Innotron_Used_Result
void operator <<= (::CORBA::Any& _any, const ::Innotron_Used_Result &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::Innotron_Used_Result(_data);
   _any.replace(::_tc_Innotron_Used_Result, (void*)EB_dc, 1, &Innotron_Used_Result::Innotron_Used_Result_Info);
}
void operator <<= (::CORBA::Any& _any, ::Innotron_Used_Result *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_Innotron_Used_Result, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Innotron_Used_Result*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_Innotron_Used_Result)) {
     _data = (::Innotron_Used_Result*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Innotron_Used_Result*& _data)
{
   return operator>>=(_any, (::Innotron_Used_Result*&)_data );
}
#endif // _Anyops_for_Innotron_Used_Result
#ifndef _Anyops_for_Innotron_Met_Result
#define _Anyops_for_Innotron_Met_Result
void operator <<= (::CORBA::Any& _any, const ::Innotron_Met_Result &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::Innotron_Met_Result(_data);
   _any.replace(::_tc_Innotron_Met_Result, (void*)EB_dc, 1, &Innotron_Met_Result::Innotron_Met_Result_Info);
}
void operator <<= (::CORBA::Any& _any, ::Innotron_Met_Result *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_Innotron_Met_Result, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Innotron_Met_Result*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_Innotron_Met_Result)) {
     _data = (::Innotron_Met_Result*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Innotron_Met_Result*& _data)
{
   return operator>>=(_any, (::Innotron_Met_Result*&)_data );
}
#endif // _Anyops_for_Innotron_Met_Result
#ifndef _Anyops_for_Innotron_Used_Request
#define _Anyops_for_Innotron_Used_Request
void operator <<= (::CORBA::Any& _any, const ::Innotron_Used_Request &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::Innotron_Used_Request(_data);
   _any.replace(::_tc_Innotron_Used_Request, (void*)EB_dc, 1, &Innotron_Used_Request::Innotron_Used_Request_Info);
}
void operator <<= (::CORBA::Any& _any, ::Innotron_Used_Request *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_Innotron_Used_Request, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Innotron_Used_Request*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_Innotron_Used_Request)) {
     _data = (::Innotron_Used_Request*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Innotron_Used_Request*& _data)
{
   return operator>>=(_any, (::Innotron_Used_Request*&)_data );
}
#endif // _Anyops_for_Innotron_Used_Request
#ifndef _Anyops_for_Metrology_RequestResponse
#define _Anyops_for_Metrology_RequestResponse
void operator <<= (::CORBA::Any& _any, const ::Metrology_RequestResponse &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::Metrology_RequestResponse(_data);
   _any.replace(::_tc_Metrology_RequestResponse, (void*)EB_dc, 1, &Metrology_RequestResponse::Metrology_RequestResponse_Info);
}
void operator <<= (::CORBA::Any& _any, ::Metrology_RequestResponse *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_Metrology_RequestResponse, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Metrology_RequestResponse*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_Metrology_RequestResponse)) {
     _data = (::Metrology_RequestResponse*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Metrology_RequestResponse*& _data)
{
   return operator>>=(_any, (::Metrology_RequestResponse*&)_data );
}
#endif // _Anyops_for_Metrology_RequestResponse
#ifndef _Anyops_for_Used_RequestResponse
#define _Anyops_for_Used_RequestResponse
void operator <<= (::CORBA::Any& _any, const ::Used_RequestResponse &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::Used_RequestResponse(_data);
   _any.replace(::_tc_Used_RequestResponse, (void*)EB_dc, 1, &Used_RequestResponse::Used_RequestResponse_Info);
}
void operator <<= (::CORBA::Any& _any, ::Used_RequestResponse *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_Used_RequestResponse, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Used_RequestResponse*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_Used_RequestResponse)) {
     _data = (::Used_RequestResponse*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Used_RequestResponse*& _data)
{
   return operator>>=(_any, (::Used_RequestResponse*&)_data );
}
#endif // _Anyops_for_Used_RequestResponse
#ifndef _Anyops_for_Metrology_Request
#define _Anyops_for_Metrology_Request
void operator <<= (::CORBA::Any& _any, const ::Metrology_Request &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::Metrology_Request(_data);
   _any.replace(::_tc_Metrology_Request, (void*)EB_dc, 1, &Metrology_Request::Metrology_Request_Info);
}
void operator <<= (::CORBA::Any& _any, ::Metrology_Request *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_Metrology_Request, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Metrology_Request*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_Metrology_Request)) {
     _data = (::Metrology_Request*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Metrology_Request*& _data)
{
   return operator>>=(_any, (::Metrology_Request*&)_data );
}
#endif // _Anyops_for_Metrology_Request
#ifndef _Anyops_for_Recommend_RequestResponse
#define _Anyops_for_Recommend_RequestResponse
void operator <<= (::CORBA::Any& _any, const ::Recommend_RequestResponse &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::Recommend_RequestResponse(_data);
   _any.replace(::_tc_Recommend_RequestResponse, (void*)EB_dc, 1, &Recommend_RequestResponse::Recommend_RequestResponse_Info);
}
void operator <<= (::CORBA::Any& _any, ::Recommend_RequestResponse *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_Recommend_RequestResponse, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Recommend_RequestResponse*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_Recommend_RequestResponse)) {
     _data = (::Recommend_RequestResponse*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Recommend_RequestResponse*& _data)
{
   return operator>>=(_any, (::Recommend_RequestResponse*&)_data );
}
#endif // _Anyops_for_Recommend_RequestResponse
#ifndef _Anyops_for_Used_Request
#define _Anyops_for_Used_Request
void operator <<= (::CORBA::Any& _any, const ::Used_Request &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::Used_Request(_data);
   _any.replace(::_tc_Used_Request, (void*)EB_dc, 1, &Used_Request::Used_Request_Info);
}
void operator <<= (::CORBA::Any& _any, ::Used_Request *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_Used_Request, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Used_Request*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_Used_Request)) {
     _data = (::Used_Request*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Used_Request*& _data)
{
   return operator>>=(_any, (::Used_Request*&)_data );
}
#endif // _Anyops_for_Used_Request
#ifndef _Anyops_for_Recommend_Request
#define _Anyops_for_Recommend_Request
void operator <<= (::CORBA::Any& _any, const ::Recommend_Request &_data) /* Any.release = 0 */
{
   void *EB_dc;
   EB_dc = new ::Recommend_Request(_data);
   _any.replace(::_tc_Recommend_Request, (void*)EB_dc, 1, &Recommend_Request::Recommend_Request_Info);
}
void operator <<= (::CORBA::Any& _any, ::Recommend_Request *_data) /* Any.release = 1 */ 
{
   _any.replace(::_tc_Recommend_Request, (void*)_data, 1);
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Recommend_Request*& _data) // deprecated
{
   ::CORBA::TypeCode_var _tmpType = _any.type();
   if (_tmpType->equivalent(::_tc_Recommend_Request)) {
     _data = (::Recommend_Request*)(_any.value());
      return 1;
   }
   else return 0;
}
::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Recommend_Request*& _data)
{
   return operator>>=(_any, (::Recommend_Request*&)_data );
}
#endif // _Anyops_for_Recommend_Request
