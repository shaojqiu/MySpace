//----------------------------------------------------------------------------
//
//  Generated from cs_apcsm.idl
//  On Thursday, October 19, 2017 5:49:49 PM GMT+07:00
//  by IBM CORBA 2.3 (sc) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#define _cs_apcsm_bindings_defined
#ifdef SOMCBNOLOCALINCLUDES
#include <cs_apcsm.hh>
#else
#include "cs_apcsm.hh"
#endif
#ifdef _DCL_LithoR2RWebServiceSoap

#define LithoR2RWebServiceSoap_dispatcher

CORBA::Boolean LithoR2RWebServiceSoap_Dispatcher::dispatch (CORBA::Request &_req) 
{
   const char *mname = _req.operation();
   CORBA::Long _code = CORBA::_somd_hash_string(mname);
if ( _code == 0xcac4884 && !strcmp(mname, "Recommend_Request")){
    goto _dispatch_Recommend_Request;
}
else if ( _code == 0xd0106e4 && !strcmp(mname, "Used_Request")){
    goto _dispatch_Used_Request;
}
else if ( _code == 0xe4e9a74 && !strcmp(mname, "Metrology_Request")){
    goto _dispatch_Metrology_Request;
}
   return (
           #ifndef _MSC_VER
              ::CORBA::
           #endif
                    Object_Dispatcher::dispatch(_req)
           );

   _dispatch_Recommend_Request:

    {
      ::Innotron_Recomd_Result* _retval;
      try {
      _req.dispatch_method_start(CORBA::RDC_Twoway);
    _req.setVarName("objRequest");
    ::Innotron_Recomd_Request objRequest;
    objRequest.decodeOp(_req);
         if ( !_req.local())
             CORBA::RequestInterceptor::run_target_filters(&_req);
         ::LithoR2RWebServiceSoap_var retVal_var=::LithoR2RWebServiceSoap::_narrow(m_target_obj);
         _retval = retVal_var->Recommend_Request(objRequest);
         _req.convert_to_reply();
         _retval->encodeOp(_req);
            delete _retval;
      }
      catch(CORBA::SystemException &sys_exc) {
         _req.set_exception(sys_exc);
         _req.convert_to_reply();
      }
      catch(...){
          CORBA::UNKNOWN _unknownExcept(SOMDERROR_Unknown, CORBA::COMPLETED_MAYBE);
          _req.set_exception(_unknownExcept);
          _req.convert_to_reply();
      }
      return 1;
   }
   _dispatch_Used_Request:

    {
      ::Innotron_Used_Result* _retval;
      try {
      _req.dispatch_method_start(CORBA::RDC_Twoway);
    _req.setVarName("objRequest");
    ::Innotron_Used_Request objRequest;
    objRequest.decodeOp(_req);
         if ( !_req.local())
             CORBA::RequestInterceptor::run_target_filters(&_req);
         ::LithoR2RWebServiceSoap_var retVal_var=::LithoR2RWebServiceSoap::_narrow(m_target_obj);
         _retval = retVal_var->Used_Request(objRequest);
         _req.convert_to_reply();
         _retval->encodeOp(_req);
            delete _retval;
      }
      catch(CORBA::SystemException &sys_exc) {
         _req.set_exception(sys_exc);
         _req.convert_to_reply();
      }
      catch(...){
          CORBA::UNKNOWN _unknownExcept(SOMDERROR_Unknown, CORBA::COMPLETED_MAYBE);
          _req.set_exception(_unknownExcept);
          _req.convert_to_reply();
      }
      return 1;
   }
   _dispatch_Metrology_Request:

    {
      ::Innotron_Met_Result* _retval;
      try {
      _req.dispatch_method_start(CORBA::RDC_Twoway);
    _req.setVarName("objRequest");
    ::Innotron_Met_Request objRequest;
    objRequest.decodeOp(_req);
         if ( !_req.local())
             CORBA::RequestInterceptor::run_target_filters(&_req);
         ::LithoR2RWebServiceSoap_var retVal_var=::LithoR2RWebServiceSoap::_narrow(m_target_obj);
         _retval = retVal_var->Metrology_Request(objRequest);
         _req.convert_to_reply();
         _retval->encodeOp(_req);
            delete _retval;
      }
      catch(CORBA::SystemException &sys_exc) {
         _req.set_exception(sys_exc);
         _req.convert_to_reply();
      }
      catch(...){
          CORBA::UNKNOWN _unknownExcept(SOMDERROR_Unknown, CORBA::COMPLETED_MAYBE);
          _req.set_exception(_unknownExcept);
          _req.convert_to_reply();
      }
      return 1;
   }
}

#ifdef _MSC_VER
CORBA::Boolean LithoR2RWebServiceSoap_Dispatcher::__LithoR2RWebServiceSoap__dispatch (CORBA::Request &_req)
{
   typedef ::LithoR2RWebServiceSoap_Dispatcher _scope_;
   return (_scope_::dispatch(_req));
}
#endif // _MSC_VER

#endif // _DCL_LithoR2RWebServiceSoap

#define _cs_apcsm_server_defined
#ifdef SOMCBNOLOCALINCLUDES
#include <cs_apcsmC.C>
#else
#include "cs_apcsmC.C"
#endif

