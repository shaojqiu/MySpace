//----------------------------------------------------------------------------
//
//  Generated from cs_apcsm.idl
//  On Thursday, October 19, 2017 5:49:49 PM GMT+07:00
//  by IBM CORBA 2.3 (hh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _cs_apcsm_server_defined
#ifndef _cs_apcsm_hh_included
#define _cs_apcsm_hh_included

#ifdef _MSC_VER
#define _export export
#endif
#ifndef _USE_NAMESPACE
#define _USE_NAMESPACE
#endif
#ifndef _DCL_LithoR2RWebServiceSoap_SOM_IMPORTEXPORT
#define _DCL_LithoR2RWebServiceSoap_SOM_IMPORTEXPORT 
#endif

#ifndef CORBA_included
#include <corba.h>
#endif
#ifdef SIVIEW_EBROKER
extern "C" {
   #include<stdlib.h>
}
 #if defined(minor)
  #undef minor
 #endif
#endif // SIVIEW_EBROKER

#ifndef IMTRIM
#define IMTRIM
#endif

#ifndef IM_EBROKER
#define IM_EBROKER
#endif

#ifndef CIMFWEVENTS_DISABLED
#define CIMFWEVENTS_DISABLED
#endif

#ifndef DB2PW
#define DB2PW
#endif

#ifndef _AIX
#define _AIX
#endif


#ifndef CS_APCServiceManager_idl 
#define CS_APCServiceManager_idl 
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _cs_apcstr_hh_included
#include <cs_apcstr.hh>
#endif
#else
#ifndef _cs_apcstr_hh_included
#include "cs_apcstr.hh"
#endif
#endif

// Begin mapping for interface ::LithoR2RWebServiceSoap

#ifndef _DCL_LithoR2RWebServiceSoap
#define _DCL_LithoR2RWebServiceSoap
#ifndef _DCL_LithoR2RWebServiceSoap_SOM_IMPORTEXPORT
#define _DCL_LithoR2RWebServiceSoap_SOM_IMPORTEXPORT 
#endif
class _DCL_LithoR2RWebServiceSoap_SOM_IMPORTEXPORT
   LithoR2RWebServiceSoap
    ;
class _DCL_LithoR2RWebServiceSoap_SOM_IMPORTEXPORT LithoR2RWebServiceSoap_var;
typedef LithoR2RWebServiceSoap* LithoR2RWebServiceSoap_ptr;
typedef LithoR2RWebServiceSoap* LithoR2RWebServiceSoapRef;

_DCL_LithoR2RWebServiceSoap_SOM_IMPORTEXPORT CORBA::Object_ptr SOMLINK LithoR2RWebServiceSoap_getBase(void *);

_DCL_LithoR2RWebServiceSoap_SOM_IMPORTEXPORT LithoR2RWebServiceSoap_ptr SOMLINK LithoR2RWebServiceSoap_aux_duplicate(LithoR2RWebServiceSoap_ptr);
_DCL_LithoR2RWebServiceSoap_SOM_IMPORTEXPORT LithoR2RWebServiceSoap_ptr SOMLINK LithoR2RWebServiceSoap_aux_narrow(::CORBA::Object_ptr);
_DCL_LithoR2RWebServiceSoap_SOM_IMPORTEXPORT LithoR2RWebServiceSoap_ptr SOMLINK LithoR2RWebServiceSoap_aux_nil();
_DCL_LithoR2RWebServiceSoap_SOM_IMPORTEXPORT const char* SOMLINK LithoR2RWebServiceSoap_aux_CN();

    class _DCL_LithoR2RWebServiceSoap_SOM_IMPORTEXPORT LithoR2RWebServiceSoap_StructElem
    {
        public:

        LithoR2RWebServiceSoap_StructElem ();

        LithoR2RWebServiceSoap_StructElem (const LithoR2RWebServiceSoap_StructElem &s);

        LithoR2RWebServiceSoap_StructElem &operator= (LithoR2RWebServiceSoap_ptr p);

        LithoR2RWebServiceSoap_StructElem &operator= (LithoR2RWebServiceSoap_var v);

        LithoR2RWebServiceSoap_StructElem &operator= (const LithoR2RWebServiceSoap_StructElem &s);

        ~LithoR2RWebServiceSoap_StructElem ();

        operator ::CORBA::Object_ptr() const;

        operator LithoR2RWebServiceSoap_ptr () const;

        LithoR2RWebServiceSoap_ptr _ptr;

    }; // LithoR2RWebServiceSoap_StructElem

    class _DCL_LithoR2RWebServiceSoap_SOM_IMPORTEXPORT LithoR2RWebServiceSoap_SeqElem
    {
       public:

       LithoR2RWebServiceSoap_SeqElem (LithoR2RWebServiceSoap_ptr* p, unsigned char rel);

       LithoR2RWebServiceSoap_SeqElem &operator= (LithoR2RWebServiceSoap_ptr p);

        LithoR2RWebServiceSoap_SeqElem &operator= (LithoR2RWebServiceSoap_var v);

       LithoR2RWebServiceSoap_SeqElem &operator= (const LithoR2RWebServiceSoap_SeqElem &s);

       operator LithoR2RWebServiceSoap_ptr () const;

       LithoR2RWebServiceSoap_ptr operator->() const;

       protected:
       LithoR2RWebServiceSoap_ptr *_ptr;
       unsigned char _release;
   }; // LithoR2RWebServiceSoap_SeqElem


class  LithoR2RWebServiceSoap_var : public ::CORBA::__vb__
{
    public:

    LithoR2RWebServiceSoap_var ();
    LithoR2RWebServiceSoap_var (LithoR2RWebServiceSoap *p);
    LithoR2RWebServiceSoap_var (const LithoR2RWebServiceSoap_var &s);
    LithoR2RWebServiceSoap_var (const LithoR2RWebServiceSoap_StructElem &s);
    LithoR2RWebServiceSoap_var (const LithoR2RWebServiceSoap_SeqElem &s);
    LithoR2RWebServiceSoap_var &operator= (LithoR2RWebServiceSoap *p);
    LithoR2RWebServiceSoap_var &operator= (const LithoR2RWebServiceSoap_var &s);
    LithoR2RWebServiceSoap_var &operator= (const LithoR2RWebServiceSoap_StructElem &s);
    LithoR2RWebServiceSoap_var &operator= (const LithoR2RWebServiceSoap_SeqElem &s);
    ~LithoR2RWebServiceSoap_var ();
    LithoR2RWebServiceSoap_ptr in() const;
    LithoR2RWebServiceSoap_ptr& inout();
    LithoR2RWebServiceSoap_ptr& out();
    LithoR2RWebServiceSoap_ptr _retn();
    LithoR2RWebServiceSoap_ptr operator-> ();
    operator LithoR2RWebServiceSoap_ptr& ();
    operator const LithoR2RWebServiceSoap_ptr& () const;
#ifdef __sun
    operator LithoR2RWebServiceSoap_ptr () { return _ptr; };
#endif

    protected:
       LithoR2RWebServiceSoap *_ptr;

    private:
       ::CORBA::__vb__& operator= (::CORBA::__vb__&);

};  // LithoR2RWebServiceSoap_var

#endif /* _DCL_LithoR2RWebServiceSoap */ 


class 

   LithoR2RWebServiceSoap
: virtual public ::CORBA::Object {

public: 
    static const char* LithoR2RWebServiceSoap_CN;
    static const char* LithoR2RWebServiceSoap_RID;
    typedef LithoR2RWebServiceSoap_ptr _ptr_type;
    typedef LithoR2RWebServiceSoap_var _var_type;

    /* for Orbix compatibility */
    virtual void *_deref();

protected: 
    /* constructor */

   LithoR2RWebServiceSoap
();
protected: 
    virtual ~

   LithoR2RWebServiceSoap
();
private: 

   LithoR2RWebServiceSoap
    (const 
   LithoR2RWebServiceSoap
     &); // unimplemented

    void operator=(const 
   LithoR2RWebServiceSoap
     &); // unimplemented
public: 

    static LithoR2RWebServiceSoap_ptr SOMLINK _duplicate(LithoR2RWebServiceSoap_ptr obj);

    static LithoR2RWebServiceSoap_ptr SOMLINK _narrow (::CORBA::Object_ptr);

    virtual void* _has_ancestor(const char* classname);
    static LithoR2RWebServiceSoap_ptr SOMLINK _nil ();

    LithoR2RWebServiceSoap_ptr _self();
    LithoR2RWebServiceSoap_ptr _this();
    virtual void *_SOMThis(const char *& ifname);


    virtual  ::Innotron_Recomd_Result*  Recommend_Request (const ::Innotron_Recomd_Request& objRequest, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::Innotron_Recomd_Result*  _req_Recommend_Request (const ::Innotron_Recomd_Request& objRequest, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::Innotron_Used_Result*  Used_Request (const ::Innotron_Used_Request& objRequest, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::Innotron_Used_Result*  _req_Used_Request (const ::Innotron_Used_Request& objRequest, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:
    virtual  ::Innotron_Met_Result*  Metrology_Request (const ::Innotron_Met_Request& objRequest, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment())=0;

protected:
    ::Innotron_Met_Result*  _req_Metrology_Request (const ::Innotron_Met_Request& objRequest, ::CORBA::Request &_req, ::CORBA::Environment &env);

public:

}; // end nesting scope for interface class ::LithoR2RWebServiceSoap

#ifdef _MSC_VER
#pragma warning(disable:4250)
#endif

class  LithoR2RWebServiceSoap_ORBProxy : virtual public 

   LithoR2RWebServiceSoap
, virtual public ::CORBA::Object_ORBProxy  {

public: 
    LithoR2RWebServiceSoap_ORBProxy ();

    virtual  ::Innotron_Recomd_Result*  Recommend_Request (const ::Innotron_Recomd_Request& objRequest, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::Innotron_Used_Result*  Used_Request (const ::Innotron_Used_Request& objRequest, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

    virtual  ::Innotron_Met_Result*  Metrology_Request (const ::Innotron_Met_Request& objRequest, ::CORBA::Environment &env = ::CORBA::EB_defaultEnvironment());

}; /* end of ::LithoR2RWebServiceSoap_ORBProxy*/
#ifdef _MSC_VER
#pragma warning(default:4250)
#endif
class  LithoR2RWebServiceSoapProxyFactory : virtual public ::CORBA::ObjectProxyFactory  {

public:
   LithoR2RWebServiceSoapProxyFactory (::CORBA::Boolean is_default = 0);

   virtual ::CORBA::Object_ptr create_proxy (const char* classname);
   virtual ::CORBA::Object_ptr asObject(void *obj);
}; // LithoR2RWebServiceSoapProxyFactory


class  LithoR2RWebServiceSoap_Dispatcher : virtual public ::CORBA::Object_Dispatcher_2  {

  public:

   LithoR2RWebServiceSoap_Dispatcher (::CORBA::Object_ptr target);

   LithoR2RWebServiceSoap_Dispatcher (); 

   virtual ::CORBA::Boolean dispatch (::CORBA::Request &request);
#ifdef _MSC_VER
   ::CORBA::Boolean __LithoR2RWebServiceSoap__dispatch(::CORBA::Request &_req);
#endif // _MSC_VER
}; // LithoR2RWebServiceSoap_Dispatcher
#ifdef _MSC_VER
#pragma warning(disable:4250)
#endif
class  LithoR2RWebServiceSoapBOAImpl : virtual public 

   LithoR2RWebServiceSoap
, virtual public ::CORBA::Object_ORBProxy { 
   public:
     LithoR2RWebServiceSoapBOAImpl() ;

     virtual ~LithoR2RWebServiceSoapBOAImpl();
     LithoR2RWebServiceSoapBOAImpl &operator= (const LithoR2RWebServiceSoapBOAImpl &s);
     LithoR2RWebServiceSoapBOAImpl (const LithoR2RWebServiceSoapBOAImpl &s);
};  // LithoR2RWebServiceSoapBOAImpl

    extern  ::CORBA::TypeCode_ptr _tc_LithoR2RWebServiceSoap;
#endif   
/*
 * Guard codes of CORBA::Any operators.
 */
#ifdef __NOTUSE_ANYOPERATOR__
#define __NOTUSE_cs_apcsm_ANYOPERATOR__
#endif //__NOTUSE_ANYOPERATOR__

#ifdef __USE_cs_apcsm_ANYOPERATOR__
#undef __NOTUSE_cs_apcsm_ANYOPERATOR__
#endif //__USE_cs_apcsm_ANYOPERATOR__
#ifndef __NOTUSE_cs_apcsm_ANYOPERATOR__
#define _DCL_ANYOPS_LithoR2RWebServiceSoap
#endif //__NOTUSE_cs_apcsm_ANYOPERATOR__

/*
 * Overloaded CORBA::Any operators.
 */
#ifdef _DCL_ANYOPS_LithoR2RWebServiceSoap
#ifndef __NOTUSE_ANYOPERATOR_INTERFACE__
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::LithoR2RWebServiceSoap_ptr _data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::LithoR2RWebServiceSoap_ptr *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::LithoR2RWebServiceSoap_ptr& _data);
#endif
#endif //__NOTUSE_ANYOPERATOR_INTERFACE__
#endif // _DCL_ANYOPS_LithoR2RWebServiceSoap

#endif /* _cs_apcsm_hh_included */

#endif /* _cs_apcsm_server_defined */
