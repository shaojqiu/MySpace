//----------------------------------------------------------------------------
//
//  Generated from cs_apcstr.idl
//  On Thursday, October 19, 2017 5:49:46 PM GMT+07:00
//  by IBM CORBA 2.3 (sc) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#define _cs_apcstr_bindings_defined
#ifdef SOMCBNOLOCALINCLUDES
#include <cs_apcstr.hh>
#else
#include "cs_apcstr.hh"
#endif
#define _cs_apcstr_server_defined
#ifdef SOMCBNOLOCALINCLUDES
#include <cs_apcstrC.C>
#else
#include "cs_apcstrC.C"
#endif

