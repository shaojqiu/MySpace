//----------------------------------------------------------------------------
//
//  Generated from cs_apcstr.idl
//  On Thursday, October 19, 2017 5:49:46 PM GMT+07:00
//  by IBM CORBA 2.3 (hh) C++ emitter 2.30
//
//----------------------------------------------------------------------------

#ifndef _cs_apcstr_server_defined
#ifndef _cs_apcstr_hh_included
#define _cs_apcstr_hh_included

#ifdef _MSC_VER
#define _export export
#endif
#ifndef _USE_NAMESPACE
#define _USE_NAMESPACE
#endif

#ifndef CORBA_included
#include <corba.h>
#endif
#ifdef SIVIEW_EBROKER
extern "C" {
   #include<stdlib.h>
}
 #if defined(minor)
  #undef minor
 #endif
#endif // SIVIEW_EBROKER

#ifndef IMTRIM
#define IMTRIM
#endif

#ifndef IM_EBROKER
#define IM_EBROKER
#endif

#ifndef CIMFWEVENTS_DISABLED
#define CIMFWEVENTS_DISABLED
#endif

#ifndef DB2PW
#define DB2PW
#endif

#ifndef _AIX
#define _AIX
#endif


#ifndef CS_APCSTR_IDL 
#define CS_APCSTR_IDL 
#ifdef SOMCBNOLOCALINCLUDES
#ifndef _cs_pptstr_hh_included
#include <cs_pptstr.hh>
#endif
#else
#ifndef _cs_pptstr_hh_included
#include "cs_pptstr.hh"
#endif
#endif
class  _IDL_SEQ_CONTROLJOBTYPEArray_1_var;
class  _IDL_SEQ_CONTROLJOBTYPEArray_1 {
    public:
        typedef _IDL_SEQ_CONTROLJOBTYPEArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_CONTROLJOBTYPEArray_1 ();
    _IDL_SEQ_CONTROLJOBTYPEArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_CONTROLJOBTYPEArray_1 (const _IDL_SEQ_CONTROLJOBTYPEArray_1&);


    ~_IDL_SEQ_CONTROLJOBTYPEArray_1 ();

    _IDL_SEQ_CONTROLJOBTYPEArray_1& operator= (const _IDL_SEQ_CONTROLJOBTYPEArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_CONTROLJOBTYPEArray_1> CONTROLJOBTYPEArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_CONTROLJOBTYPEArray_1* _IDL_SEQ_CONTROLJOBTYPEArray_1_vPtr;
typedef const _IDL_SEQ_CONTROLJOBTYPEArray_1* _IDL_SEQ_CONTROLJOBTYPEArray_1_cvPtr;

class  _IDL_SEQ_CONTROLJOBTYPEArray_1_var
{
    public:

    _IDL_SEQ_CONTROLJOBTYPEArray_1_var ();

    _IDL_SEQ_CONTROLJOBTYPEArray_1_var (_IDL_SEQ_CONTROLJOBTYPEArray_1 *_p);

    _IDL_SEQ_CONTROLJOBTYPEArray_1_var (const _IDL_SEQ_CONTROLJOBTYPEArray_1_var &_s);

    _IDL_SEQ_CONTROLJOBTYPEArray_1_var &operator= (_IDL_SEQ_CONTROLJOBTYPEArray_1 *_p);

    _IDL_SEQ_CONTROLJOBTYPEArray_1_var &operator= (const _IDL_SEQ_CONTROLJOBTYPEArray_1_var &_s);

    ~_IDL_SEQ_CONTROLJOBTYPEArray_1_var ();

    _IDL_SEQ_CONTROLJOBTYPEArray_1* operator-> ();

    operator _IDL_SEQ_CONTROLJOBTYPEArray_1_cvPtr () const;

    operator _IDL_SEQ_CONTROLJOBTYPEArray_1_vPtr& ();

    operator _IDL_SEQ_CONTROLJOBTYPEArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_CONTROLJOBTYPEArray_1& in() const;
    _IDL_SEQ_CONTROLJOBTYPEArray_1& inout();
    _IDL_SEQ_CONTROLJOBTYPEArray_1*& out();
    _IDL_SEQ_CONTROLJOBTYPEArray_1* _retn();

    protected:
    _IDL_SEQ_CONTROLJOBTYPEArray_1 *_ptr;
};

    typedef _IDL_SEQ_CONTROLJOBTYPEArray_1 _CONTROLJOBTYPEArray_seq;
    typedef _IDL_SEQ_CONTROLJOBTYPEArray_1 _CONTROLJOBTYPEArray_seq_1;
    typedef _IDL_SEQ_CONTROLJOBTYPEArray_1 CONTROLJOBTYPEArray;
    typedef _IDL_SEQ_CONTROLJOBTYPEArray_1_var CONTROLJOBTYPEArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_CONTROLJOBTYPEArray;
class  _IDL_SEQ_TRANSACTIONIDArray_1_var;
class  _IDL_SEQ_TRANSACTIONIDArray_1 {
    public:
        typedef _IDL_SEQ_TRANSACTIONIDArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_TRANSACTIONIDArray_1 ();
    _IDL_SEQ_TRANSACTIONIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_TRANSACTIONIDArray_1 (const _IDL_SEQ_TRANSACTIONIDArray_1&);


    ~_IDL_SEQ_TRANSACTIONIDArray_1 ();

    _IDL_SEQ_TRANSACTIONIDArray_1& operator= (const _IDL_SEQ_TRANSACTIONIDArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_TRANSACTIONIDArray_1> TRANSACTIONIDArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_TRANSACTIONIDArray_1* _IDL_SEQ_TRANSACTIONIDArray_1_vPtr;
typedef const _IDL_SEQ_TRANSACTIONIDArray_1* _IDL_SEQ_TRANSACTIONIDArray_1_cvPtr;

class  _IDL_SEQ_TRANSACTIONIDArray_1_var
{
    public:

    _IDL_SEQ_TRANSACTIONIDArray_1_var ();

    _IDL_SEQ_TRANSACTIONIDArray_1_var (_IDL_SEQ_TRANSACTIONIDArray_1 *_p);

    _IDL_SEQ_TRANSACTIONIDArray_1_var (const _IDL_SEQ_TRANSACTIONIDArray_1_var &_s);

    _IDL_SEQ_TRANSACTIONIDArray_1_var &operator= (_IDL_SEQ_TRANSACTIONIDArray_1 *_p);

    _IDL_SEQ_TRANSACTIONIDArray_1_var &operator= (const _IDL_SEQ_TRANSACTIONIDArray_1_var &_s);

    ~_IDL_SEQ_TRANSACTIONIDArray_1_var ();

    _IDL_SEQ_TRANSACTIONIDArray_1* operator-> ();

    operator _IDL_SEQ_TRANSACTIONIDArray_1_cvPtr () const;

    operator _IDL_SEQ_TRANSACTIONIDArray_1_vPtr& ();

    operator _IDL_SEQ_TRANSACTIONIDArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_TRANSACTIONIDArray_1& in() const;
    _IDL_SEQ_TRANSACTIONIDArray_1& inout();
    _IDL_SEQ_TRANSACTIONIDArray_1*& out();
    _IDL_SEQ_TRANSACTIONIDArray_1* _retn();

    protected:
    _IDL_SEQ_TRANSACTIONIDArray_1 *_ptr;
};

    typedef _IDL_SEQ_TRANSACTIONIDArray_1 _TRANSACTIONIDArray_seq;
    typedef _IDL_SEQ_TRANSACTIONIDArray_1 _TRANSACTIONIDArray_seq_1;
    typedef _IDL_SEQ_TRANSACTIONIDArray_1 TRANSACTIONIDArray;
    typedef _IDL_SEQ_TRANSACTIONIDArray_1_var TRANSACTIONIDArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_TRANSACTIONIDArray;
class  _IDL_SEQ_LOTIDArray_1_var;
class  _IDL_SEQ_LOTIDArray_1 {
    public:
        typedef _IDL_SEQ_LOTIDArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_LOTIDArray_1 ();
    _IDL_SEQ_LOTIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_LOTIDArray_1 (const _IDL_SEQ_LOTIDArray_1&);


    ~_IDL_SEQ_LOTIDArray_1 ();

    _IDL_SEQ_LOTIDArray_1& operator= (const _IDL_SEQ_LOTIDArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_LOTIDArray_1> LOTIDArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_LOTIDArray_1* _IDL_SEQ_LOTIDArray_1_vPtr;
typedef const _IDL_SEQ_LOTIDArray_1* _IDL_SEQ_LOTIDArray_1_cvPtr;

class  _IDL_SEQ_LOTIDArray_1_var
{
    public:

    _IDL_SEQ_LOTIDArray_1_var ();

    _IDL_SEQ_LOTIDArray_1_var (_IDL_SEQ_LOTIDArray_1 *_p);

    _IDL_SEQ_LOTIDArray_1_var (const _IDL_SEQ_LOTIDArray_1_var &_s);

    _IDL_SEQ_LOTIDArray_1_var &operator= (_IDL_SEQ_LOTIDArray_1 *_p);

    _IDL_SEQ_LOTIDArray_1_var &operator= (const _IDL_SEQ_LOTIDArray_1_var &_s);

    ~_IDL_SEQ_LOTIDArray_1_var ();

    _IDL_SEQ_LOTIDArray_1* operator-> ();

    operator _IDL_SEQ_LOTIDArray_1_cvPtr () const;

    operator _IDL_SEQ_LOTIDArray_1_vPtr& ();

    operator _IDL_SEQ_LOTIDArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_LOTIDArray_1& in() const;
    _IDL_SEQ_LOTIDArray_1& inout();
    _IDL_SEQ_LOTIDArray_1*& out();
    _IDL_SEQ_LOTIDArray_1* _retn();

    protected:
    _IDL_SEQ_LOTIDArray_1 *_ptr;
};

    typedef _IDL_SEQ_LOTIDArray_1 _LOTIDArray_seq;
    typedef _IDL_SEQ_LOTIDArray_1 _LOTIDArray_seq_1;
    typedef _IDL_SEQ_LOTIDArray_1 LOTIDArray;
    typedef _IDL_SEQ_LOTIDArray_1_var LOTIDArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_LOTIDArray;
class  _IDL_SEQ_LOTTYPEArray_1_var;
class  _IDL_SEQ_LOTTYPEArray_1 {
    public:
        typedef _IDL_SEQ_LOTTYPEArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_LOTTYPEArray_1 ();
    _IDL_SEQ_LOTTYPEArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_LOTTYPEArray_1 (const _IDL_SEQ_LOTTYPEArray_1&);


    ~_IDL_SEQ_LOTTYPEArray_1 ();

    _IDL_SEQ_LOTTYPEArray_1& operator= (const _IDL_SEQ_LOTTYPEArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_LOTTYPEArray_1> LOTTYPEArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_LOTTYPEArray_1* _IDL_SEQ_LOTTYPEArray_1_vPtr;
typedef const _IDL_SEQ_LOTTYPEArray_1* _IDL_SEQ_LOTTYPEArray_1_cvPtr;

class  _IDL_SEQ_LOTTYPEArray_1_var
{
    public:

    _IDL_SEQ_LOTTYPEArray_1_var ();

    _IDL_SEQ_LOTTYPEArray_1_var (_IDL_SEQ_LOTTYPEArray_1 *_p);

    _IDL_SEQ_LOTTYPEArray_1_var (const _IDL_SEQ_LOTTYPEArray_1_var &_s);

    _IDL_SEQ_LOTTYPEArray_1_var &operator= (_IDL_SEQ_LOTTYPEArray_1 *_p);

    _IDL_SEQ_LOTTYPEArray_1_var &operator= (const _IDL_SEQ_LOTTYPEArray_1_var &_s);

    ~_IDL_SEQ_LOTTYPEArray_1_var ();

    _IDL_SEQ_LOTTYPEArray_1* operator-> ();

    operator _IDL_SEQ_LOTTYPEArray_1_cvPtr () const;

    operator _IDL_SEQ_LOTTYPEArray_1_vPtr& ();

    operator _IDL_SEQ_LOTTYPEArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_LOTTYPEArray_1& in() const;
    _IDL_SEQ_LOTTYPEArray_1& inout();
    _IDL_SEQ_LOTTYPEArray_1*& out();
    _IDL_SEQ_LOTTYPEArray_1* _retn();

    protected:
    _IDL_SEQ_LOTTYPEArray_1 *_ptr;
};

    typedef _IDL_SEQ_LOTTYPEArray_1 _LOTTYPEArray_seq;
    typedef _IDL_SEQ_LOTTYPEArray_1 _LOTTYPEArray_seq_1;
    typedef _IDL_SEQ_LOTTYPEArray_1 LOTTYPEArray;
    typedef _IDL_SEQ_LOTTYPEArray_1_var LOTTYPEArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_LOTTYPEArray;
class  _IDL_SEQ_PARTIDArray_1_var;
class  _IDL_SEQ_PARTIDArray_1 {
    public:
        typedef _IDL_SEQ_PARTIDArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_PARTIDArray_1 ();
    _IDL_SEQ_PARTIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_PARTIDArray_1 (const _IDL_SEQ_PARTIDArray_1&);


    ~_IDL_SEQ_PARTIDArray_1 ();

    _IDL_SEQ_PARTIDArray_1& operator= (const _IDL_SEQ_PARTIDArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_PARTIDArray_1> PARTIDArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_PARTIDArray_1* _IDL_SEQ_PARTIDArray_1_vPtr;
typedef const _IDL_SEQ_PARTIDArray_1* _IDL_SEQ_PARTIDArray_1_cvPtr;

class  _IDL_SEQ_PARTIDArray_1_var
{
    public:

    _IDL_SEQ_PARTIDArray_1_var ();

    _IDL_SEQ_PARTIDArray_1_var (_IDL_SEQ_PARTIDArray_1 *_p);

    _IDL_SEQ_PARTIDArray_1_var (const _IDL_SEQ_PARTIDArray_1_var &_s);

    _IDL_SEQ_PARTIDArray_1_var &operator= (_IDL_SEQ_PARTIDArray_1 *_p);

    _IDL_SEQ_PARTIDArray_1_var &operator= (const _IDL_SEQ_PARTIDArray_1_var &_s);

    ~_IDL_SEQ_PARTIDArray_1_var ();

    _IDL_SEQ_PARTIDArray_1* operator-> ();

    operator _IDL_SEQ_PARTIDArray_1_cvPtr () const;

    operator _IDL_SEQ_PARTIDArray_1_vPtr& ();

    operator _IDL_SEQ_PARTIDArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_PARTIDArray_1& in() const;
    _IDL_SEQ_PARTIDArray_1& inout();
    _IDL_SEQ_PARTIDArray_1*& out();
    _IDL_SEQ_PARTIDArray_1* _retn();

    protected:
    _IDL_SEQ_PARTIDArray_1 *_ptr;
};

    typedef _IDL_SEQ_PARTIDArray_1 _PARTIDArray_seq;
    typedef _IDL_SEQ_PARTIDArray_1 _PARTIDArray_seq_1;
    typedef _IDL_SEQ_PARTIDArray_1 PARTIDArray;
    typedef _IDL_SEQ_PARTIDArray_1_var PARTIDArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_PARTIDArray;
class  _IDL_SEQ_LAYERArray_1_var;
class  _IDL_SEQ_LAYERArray_1 {
    public:
        typedef _IDL_SEQ_LAYERArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_LAYERArray_1 ();
    _IDL_SEQ_LAYERArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_LAYERArray_1 (const _IDL_SEQ_LAYERArray_1&);


    ~_IDL_SEQ_LAYERArray_1 ();

    _IDL_SEQ_LAYERArray_1& operator= (const _IDL_SEQ_LAYERArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_LAYERArray_1> LAYERArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_LAYERArray_1* _IDL_SEQ_LAYERArray_1_vPtr;
typedef const _IDL_SEQ_LAYERArray_1* _IDL_SEQ_LAYERArray_1_cvPtr;

class  _IDL_SEQ_LAYERArray_1_var
{
    public:

    _IDL_SEQ_LAYERArray_1_var ();

    _IDL_SEQ_LAYERArray_1_var (_IDL_SEQ_LAYERArray_1 *_p);

    _IDL_SEQ_LAYERArray_1_var (const _IDL_SEQ_LAYERArray_1_var &_s);

    _IDL_SEQ_LAYERArray_1_var &operator= (_IDL_SEQ_LAYERArray_1 *_p);

    _IDL_SEQ_LAYERArray_1_var &operator= (const _IDL_SEQ_LAYERArray_1_var &_s);

    ~_IDL_SEQ_LAYERArray_1_var ();

    _IDL_SEQ_LAYERArray_1* operator-> ();

    operator _IDL_SEQ_LAYERArray_1_cvPtr () const;

    operator _IDL_SEQ_LAYERArray_1_vPtr& ();

    operator _IDL_SEQ_LAYERArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_LAYERArray_1& in() const;
    _IDL_SEQ_LAYERArray_1& inout();
    _IDL_SEQ_LAYERArray_1*& out();
    _IDL_SEQ_LAYERArray_1* _retn();

    protected:
    _IDL_SEQ_LAYERArray_1 *_ptr;
};

    typedef _IDL_SEQ_LAYERArray_1 _LAYERArray_seq;
    typedef _IDL_SEQ_LAYERArray_1 _LAYERArray_seq_1;
    typedef _IDL_SEQ_LAYERArray_1 LAYERArray;
    typedef _IDL_SEQ_LAYERArray_1_var LAYERArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_LAYERArray;
class  _IDL_SEQ_ROUTEArray_1_var;
class  _IDL_SEQ_ROUTEArray_1 {
    public:
        typedef _IDL_SEQ_ROUTEArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_ROUTEArray_1 ();
    _IDL_SEQ_ROUTEArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_ROUTEArray_1 (const _IDL_SEQ_ROUTEArray_1&);


    ~_IDL_SEQ_ROUTEArray_1 ();

    _IDL_SEQ_ROUTEArray_1& operator= (const _IDL_SEQ_ROUTEArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_ROUTEArray_1> ROUTEArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_ROUTEArray_1* _IDL_SEQ_ROUTEArray_1_vPtr;
typedef const _IDL_SEQ_ROUTEArray_1* _IDL_SEQ_ROUTEArray_1_cvPtr;

class  _IDL_SEQ_ROUTEArray_1_var
{
    public:

    _IDL_SEQ_ROUTEArray_1_var ();

    _IDL_SEQ_ROUTEArray_1_var (_IDL_SEQ_ROUTEArray_1 *_p);

    _IDL_SEQ_ROUTEArray_1_var (const _IDL_SEQ_ROUTEArray_1_var &_s);

    _IDL_SEQ_ROUTEArray_1_var &operator= (_IDL_SEQ_ROUTEArray_1 *_p);

    _IDL_SEQ_ROUTEArray_1_var &operator= (const _IDL_SEQ_ROUTEArray_1_var &_s);

    ~_IDL_SEQ_ROUTEArray_1_var ();

    _IDL_SEQ_ROUTEArray_1* operator-> ();

    operator _IDL_SEQ_ROUTEArray_1_cvPtr () const;

    operator _IDL_SEQ_ROUTEArray_1_vPtr& ();

    operator _IDL_SEQ_ROUTEArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_ROUTEArray_1& in() const;
    _IDL_SEQ_ROUTEArray_1& inout();
    _IDL_SEQ_ROUTEArray_1*& out();
    _IDL_SEQ_ROUTEArray_1* _retn();

    protected:
    _IDL_SEQ_ROUTEArray_1 *_ptr;
};

    typedef _IDL_SEQ_ROUTEArray_1 _ROUTEArray_seq;
    typedef _IDL_SEQ_ROUTEArray_1 _ROUTEArray_seq_1;
    typedef _IDL_SEQ_ROUTEArray_1 ROUTEArray;
    typedef _IDL_SEQ_ROUTEArray_1_var ROUTEArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_ROUTEArray;
class  _IDL_SEQ_ROUTEGROUPArray_1_var;
class  _IDL_SEQ_ROUTEGROUPArray_1 {
    public:
        typedef _IDL_SEQ_ROUTEGROUPArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_ROUTEGROUPArray_1 ();
    _IDL_SEQ_ROUTEGROUPArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_ROUTEGROUPArray_1 (const _IDL_SEQ_ROUTEGROUPArray_1&);


    ~_IDL_SEQ_ROUTEGROUPArray_1 ();

    _IDL_SEQ_ROUTEGROUPArray_1& operator= (const _IDL_SEQ_ROUTEGROUPArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_ROUTEGROUPArray_1> ROUTEGROUPArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_ROUTEGROUPArray_1* _IDL_SEQ_ROUTEGROUPArray_1_vPtr;
typedef const _IDL_SEQ_ROUTEGROUPArray_1* _IDL_SEQ_ROUTEGROUPArray_1_cvPtr;

class  _IDL_SEQ_ROUTEGROUPArray_1_var
{
    public:

    _IDL_SEQ_ROUTEGROUPArray_1_var ();

    _IDL_SEQ_ROUTEGROUPArray_1_var (_IDL_SEQ_ROUTEGROUPArray_1 *_p);

    _IDL_SEQ_ROUTEGROUPArray_1_var (const _IDL_SEQ_ROUTEGROUPArray_1_var &_s);

    _IDL_SEQ_ROUTEGROUPArray_1_var &operator= (_IDL_SEQ_ROUTEGROUPArray_1 *_p);

    _IDL_SEQ_ROUTEGROUPArray_1_var &operator= (const _IDL_SEQ_ROUTEGROUPArray_1_var &_s);

    ~_IDL_SEQ_ROUTEGROUPArray_1_var ();

    _IDL_SEQ_ROUTEGROUPArray_1* operator-> ();

    operator _IDL_SEQ_ROUTEGROUPArray_1_cvPtr () const;

    operator _IDL_SEQ_ROUTEGROUPArray_1_vPtr& ();

    operator _IDL_SEQ_ROUTEGROUPArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_ROUTEGROUPArray_1& in() const;
    _IDL_SEQ_ROUTEGROUPArray_1& inout();
    _IDL_SEQ_ROUTEGROUPArray_1*& out();
    _IDL_SEQ_ROUTEGROUPArray_1* _retn();

    protected:
    _IDL_SEQ_ROUTEGROUPArray_1 *_ptr;
};

    typedef _IDL_SEQ_ROUTEGROUPArray_1 _ROUTEGROUPArray_seq;
    typedef _IDL_SEQ_ROUTEGROUPArray_1 _ROUTEGROUPArray_seq_1;
    typedef _IDL_SEQ_ROUTEGROUPArray_1 ROUTEGROUPArray;
    typedef _IDL_SEQ_ROUTEGROUPArray_1_var ROUTEGROUPArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_ROUTEGROUPArray;
class  _IDL_SEQ_OPERATIONArray_1_var;
class  _IDL_SEQ_OPERATIONArray_1 {
    public:
        typedef _IDL_SEQ_OPERATIONArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_OPERATIONArray_1 ();
    _IDL_SEQ_OPERATIONArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_OPERATIONArray_1 (const _IDL_SEQ_OPERATIONArray_1&);


    ~_IDL_SEQ_OPERATIONArray_1 ();

    _IDL_SEQ_OPERATIONArray_1& operator= (const _IDL_SEQ_OPERATIONArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_OPERATIONArray_1> OPERATIONArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_OPERATIONArray_1* _IDL_SEQ_OPERATIONArray_1_vPtr;
typedef const _IDL_SEQ_OPERATIONArray_1* _IDL_SEQ_OPERATIONArray_1_cvPtr;

class  _IDL_SEQ_OPERATIONArray_1_var
{
    public:

    _IDL_SEQ_OPERATIONArray_1_var ();

    _IDL_SEQ_OPERATIONArray_1_var (_IDL_SEQ_OPERATIONArray_1 *_p);

    _IDL_SEQ_OPERATIONArray_1_var (const _IDL_SEQ_OPERATIONArray_1_var &_s);

    _IDL_SEQ_OPERATIONArray_1_var &operator= (_IDL_SEQ_OPERATIONArray_1 *_p);

    _IDL_SEQ_OPERATIONArray_1_var &operator= (const _IDL_SEQ_OPERATIONArray_1_var &_s);

    ~_IDL_SEQ_OPERATIONArray_1_var ();

    _IDL_SEQ_OPERATIONArray_1* operator-> ();

    operator _IDL_SEQ_OPERATIONArray_1_cvPtr () const;

    operator _IDL_SEQ_OPERATIONArray_1_vPtr& ();

    operator _IDL_SEQ_OPERATIONArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_OPERATIONArray_1& in() const;
    _IDL_SEQ_OPERATIONArray_1& inout();
    _IDL_SEQ_OPERATIONArray_1*& out();
    _IDL_SEQ_OPERATIONArray_1* _retn();

    protected:
    _IDL_SEQ_OPERATIONArray_1 *_ptr;
};

    typedef _IDL_SEQ_OPERATIONArray_1 _OPERATIONArray_seq;
    typedef _IDL_SEQ_OPERATIONArray_1 _OPERATIONArray_seq_1;
    typedef _IDL_SEQ_OPERATIONArray_1 OPERATIONArray;
    typedef _IDL_SEQ_OPERATIONArray_1_var OPERATIONArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_OPERATIONArray;
class  _IDL_SEQ_RETICLEIDArray_1_var;
class  _IDL_SEQ_RETICLEIDArray_1 {
    public:
        typedef _IDL_SEQ_RETICLEIDArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_RETICLEIDArray_1 ();
    _IDL_SEQ_RETICLEIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_RETICLEIDArray_1 (const _IDL_SEQ_RETICLEIDArray_1&);


    ~_IDL_SEQ_RETICLEIDArray_1 ();

    _IDL_SEQ_RETICLEIDArray_1& operator= (const _IDL_SEQ_RETICLEIDArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_RETICLEIDArray_1> RETICLEIDArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_RETICLEIDArray_1* _IDL_SEQ_RETICLEIDArray_1_vPtr;
typedef const _IDL_SEQ_RETICLEIDArray_1* _IDL_SEQ_RETICLEIDArray_1_cvPtr;

class  _IDL_SEQ_RETICLEIDArray_1_var
{
    public:

    _IDL_SEQ_RETICLEIDArray_1_var ();

    _IDL_SEQ_RETICLEIDArray_1_var (_IDL_SEQ_RETICLEIDArray_1 *_p);

    _IDL_SEQ_RETICLEIDArray_1_var (const _IDL_SEQ_RETICLEIDArray_1_var &_s);

    _IDL_SEQ_RETICLEIDArray_1_var &operator= (_IDL_SEQ_RETICLEIDArray_1 *_p);

    _IDL_SEQ_RETICLEIDArray_1_var &operator= (const _IDL_SEQ_RETICLEIDArray_1_var &_s);

    ~_IDL_SEQ_RETICLEIDArray_1_var ();

    _IDL_SEQ_RETICLEIDArray_1* operator-> ();

    operator _IDL_SEQ_RETICLEIDArray_1_cvPtr () const;

    operator _IDL_SEQ_RETICLEIDArray_1_vPtr& ();

    operator _IDL_SEQ_RETICLEIDArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_RETICLEIDArray_1& in() const;
    _IDL_SEQ_RETICLEIDArray_1& inout();
    _IDL_SEQ_RETICLEIDArray_1*& out();
    _IDL_SEQ_RETICLEIDArray_1* _retn();

    protected:
    _IDL_SEQ_RETICLEIDArray_1 *_ptr;
};

    typedef _IDL_SEQ_RETICLEIDArray_1 _RETICLEIDArray_seq;
    typedef _IDL_SEQ_RETICLEIDArray_1 _RETICLEIDArray_seq_1;
    typedef _IDL_SEQ_RETICLEIDArray_1 RETICLEIDArray;
    typedef _IDL_SEQ_RETICLEIDArray_1_var RETICLEIDArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_RETICLEIDArray;
class  _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var;
class  _IDL_SEQ_PROCESSEQUIPTYPEArray_1 {
    public:
        typedef _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_PROCESSEQUIPTYPEArray_1 ();
    _IDL_SEQ_PROCESSEQUIPTYPEArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_PROCESSEQUIPTYPEArray_1 (const _IDL_SEQ_PROCESSEQUIPTYPEArray_1&);


    ~_IDL_SEQ_PROCESSEQUIPTYPEArray_1 ();

    _IDL_SEQ_PROCESSEQUIPTYPEArray_1& operator= (const _IDL_SEQ_PROCESSEQUIPTYPEArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_PROCESSEQUIPTYPEArray_1> PROCESSEQUIPTYPEArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_PROCESSEQUIPTYPEArray_1* _IDL_SEQ_PROCESSEQUIPTYPEArray_1_vPtr;
typedef const _IDL_SEQ_PROCESSEQUIPTYPEArray_1* _IDL_SEQ_PROCESSEQUIPTYPEArray_1_cvPtr;

class  _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var
{
    public:

    _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var ();

    _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var (_IDL_SEQ_PROCESSEQUIPTYPEArray_1 *_p);

    _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var (const _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var &_s);

    _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var &operator= (_IDL_SEQ_PROCESSEQUIPTYPEArray_1 *_p);

    _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var &operator= (const _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var &_s);

    ~_IDL_SEQ_PROCESSEQUIPTYPEArray_1_var ();

    _IDL_SEQ_PROCESSEQUIPTYPEArray_1* operator-> ();

    operator _IDL_SEQ_PROCESSEQUIPTYPEArray_1_cvPtr () const;

    operator _IDL_SEQ_PROCESSEQUIPTYPEArray_1_vPtr& ();

    operator _IDL_SEQ_PROCESSEQUIPTYPEArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_PROCESSEQUIPTYPEArray_1& in() const;
    _IDL_SEQ_PROCESSEQUIPTYPEArray_1& inout();
    _IDL_SEQ_PROCESSEQUIPTYPEArray_1*& out();
    _IDL_SEQ_PROCESSEQUIPTYPEArray_1* _retn();

    protected:
    _IDL_SEQ_PROCESSEQUIPTYPEArray_1 *_ptr;
};

    typedef _IDL_SEQ_PROCESSEQUIPTYPEArray_1 _PROCESSEQUIPTYPEArray_seq;
    typedef _IDL_SEQ_PROCESSEQUIPTYPEArray_1 _PROCESSEQUIPTYPEArray_seq_1;
    typedef _IDL_SEQ_PROCESSEQUIPTYPEArray_1 PROCESSEQUIPTYPEArray;
    typedef _IDL_SEQ_PROCESSEQUIPTYPEArray_1_var PROCESSEQUIPTYPEArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_PROCESSEQUIPTYPEArray;
class  _IDL_SEQ_PROCESSEQUIPIDArray_1_var;
class  _IDL_SEQ_PROCESSEQUIPIDArray_1 {
    public:
        typedef _IDL_SEQ_PROCESSEQUIPIDArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_PROCESSEQUIPIDArray_1 ();
    _IDL_SEQ_PROCESSEQUIPIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_PROCESSEQUIPIDArray_1 (const _IDL_SEQ_PROCESSEQUIPIDArray_1&);


    ~_IDL_SEQ_PROCESSEQUIPIDArray_1 ();

    _IDL_SEQ_PROCESSEQUIPIDArray_1& operator= (const _IDL_SEQ_PROCESSEQUIPIDArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_PROCESSEQUIPIDArray_1> PROCESSEQUIPIDArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_PROCESSEQUIPIDArray_1* _IDL_SEQ_PROCESSEQUIPIDArray_1_vPtr;
typedef const _IDL_SEQ_PROCESSEQUIPIDArray_1* _IDL_SEQ_PROCESSEQUIPIDArray_1_cvPtr;

class  _IDL_SEQ_PROCESSEQUIPIDArray_1_var
{
    public:

    _IDL_SEQ_PROCESSEQUIPIDArray_1_var ();

    _IDL_SEQ_PROCESSEQUIPIDArray_1_var (_IDL_SEQ_PROCESSEQUIPIDArray_1 *_p);

    _IDL_SEQ_PROCESSEQUIPIDArray_1_var (const _IDL_SEQ_PROCESSEQUIPIDArray_1_var &_s);

    _IDL_SEQ_PROCESSEQUIPIDArray_1_var &operator= (_IDL_SEQ_PROCESSEQUIPIDArray_1 *_p);

    _IDL_SEQ_PROCESSEQUIPIDArray_1_var &operator= (const _IDL_SEQ_PROCESSEQUIPIDArray_1_var &_s);

    ~_IDL_SEQ_PROCESSEQUIPIDArray_1_var ();

    _IDL_SEQ_PROCESSEQUIPIDArray_1* operator-> ();

    operator _IDL_SEQ_PROCESSEQUIPIDArray_1_cvPtr () const;

    operator _IDL_SEQ_PROCESSEQUIPIDArray_1_vPtr& ();

    operator _IDL_SEQ_PROCESSEQUIPIDArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_PROCESSEQUIPIDArray_1& in() const;
    _IDL_SEQ_PROCESSEQUIPIDArray_1& inout();
    _IDL_SEQ_PROCESSEQUIPIDArray_1*& out();
    _IDL_SEQ_PROCESSEQUIPIDArray_1* _retn();

    protected:
    _IDL_SEQ_PROCESSEQUIPIDArray_1 *_ptr;
};

    typedef _IDL_SEQ_PROCESSEQUIPIDArray_1 _PROCESSEQUIPIDArray_seq;
    typedef _IDL_SEQ_PROCESSEQUIPIDArray_1 _PROCESSEQUIPIDArray_seq_1;
    typedef _IDL_SEQ_PROCESSEQUIPIDArray_1 PROCESSEQUIPIDArray;
    typedef _IDL_SEQ_PROCESSEQUIPIDArray_1_var PROCESSEQUIPIDArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_PROCESSEQUIPIDArray;
class  _IDL_SEQ_RECOMMENDMODEArray_1_var;
class  _IDL_SEQ_RECOMMENDMODEArray_1 {
    public:
        typedef _IDL_SEQ_RECOMMENDMODEArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_RECOMMENDMODEArray_1 ();
    _IDL_SEQ_RECOMMENDMODEArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_RECOMMENDMODEArray_1 (const _IDL_SEQ_RECOMMENDMODEArray_1&);


    ~_IDL_SEQ_RECOMMENDMODEArray_1 ();

    _IDL_SEQ_RECOMMENDMODEArray_1& operator= (const _IDL_SEQ_RECOMMENDMODEArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_RECOMMENDMODEArray_1> RECOMMENDMODEArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_RECOMMENDMODEArray_1* _IDL_SEQ_RECOMMENDMODEArray_1_vPtr;
typedef const _IDL_SEQ_RECOMMENDMODEArray_1* _IDL_SEQ_RECOMMENDMODEArray_1_cvPtr;

class  _IDL_SEQ_RECOMMENDMODEArray_1_var
{
    public:

    _IDL_SEQ_RECOMMENDMODEArray_1_var ();

    _IDL_SEQ_RECOMMENDMODEArray_1_var (_IDL_SEQ_RECOMMENDMODEArray_1 *_p);

    _IDL_SEQ_RECOMMENDMODEArray_1_var (const _IDL_SEQ_RECOMMENDMODEArray_1_var &_s);

    _IDL_SEQ_RECOMMENDMODEArray_1_var &operator= (_IDL_SEQ_RECOMMENDMODEArray_1 *_p);

    _IDL_SEQ_RECOMMENDMODEArray_1_var &operator= (const _IDL_SEQ_RECOMMENDMODEArray_1_var &_s);

    ~_IDL_SEQ_RECOMMENDMODEArray_1_var ();

    _IDL_SEQ_RECOMMENDMODEArray_1* operator-> ();

    operator _IDL_SEQ_RECOMMENDMODEArray_1_cvPtr () const;

    operator _IDL_SEQ_RECOMMENDMODEArray_1_vPtr& ();

    operator _IDL_SEQ_RECOMMENDMODEArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_RECOMMENDMODEArray_1& in() const;
    _IDL_SEQ_RECOMMENDMODEArray_1& inout();
    _IDL_SEQ_RECOMMENDMODEArray_1*& out();
    _IDL_SEQ_RECOMMENDMODEArray_1* _retn();

    protected:
    _IDL_SEQ_RECOMMENDMODEArray_1 *_ptr;
};

    typedef _IDL_SEQ_RECOMMENDMODEArray_1 _RECOMMENDMODEArray_seq;
    typedef _IDL_SEQ_RECOMMENDMODEArray_1 _RECOMMENDMODEArray_seq_1;
    typedef _IDL_SEQ_RECOMMENDMODEArray_1 RECOMMENDMODEArray;
    typedef _IDL_SEQ_RECOMMENDMODEArray_1_var RECOMMENDMODEArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_RECOMMENDMODEArray;
class  _IDL_SEQ_REWORKArray_1_var;
class  _IDL_SEQ_REWORKArray_1 {
    public:
        typedef _IDL_SEQ_REWORKArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_REWORKArray_1 ();
    _IDL_SEQ_REWORKArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_REWORKArray_1 (const _IDL_SEQ_REWORKArray_1&);


    ~_IDL_SEQ_REWORKArray_1 ();

    _IDL_SEQ_REWORKArray_1& operator= (const _IDL_SEQ_REWORKArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_REWORKArray_1> REWORKArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_REWORKArray_1* _IDL_SEQ_REWORKArray_1_vPtr;
typedef const _IDL_SEQ_REWORKArray_1* _IDL_SEQ_REWORKArray_1_cvPtr;

class  _IDL_SEQ_REWORKArray_1_var
{
    public:

    _IDL_SEQ_REWORKArray_1_var ();

    _IDL_SEQ_REWORKArray_1_var (_IDL_SEQ_REWORKArray_1 *_p);

    _IDL_SEQ_REWORKArray_1_var (const _IDL_SEQ_REWORKArray_1_var &_s);

    _IDL_SEQ_REWORKArray_1_var &operator= (_IDL_SEQ_REWORKArray_1 *_p);

    _IDL_SEQ_REWORKArray_1_var &operator= (const _IDL_SEQ_REWORKArray_1_var &_s);

    ~_IDL_SEQ_REWORKArray_1_var ();

    _IDL_SEQ_REWORKArray_1* operator-> ();

    operator _IDL_SEQ_REWORKArray_1_cvPtr () const;

    operator _IDL_SEQ_REWORKArray_1_vPtr& ();

    operator _IDL_SEQ_REWORKArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_REWORKArray_1& in() const;
    _IDL_SEQ_REWORKArray_1& inout();
    _IDL_SEQ_REWORKArray_1*& out();
    _IDL_SEQ_REWORKArray_1* _retn();

    protected:
    _IDL_SEQ_REWORKArray_1 *_ptr;
};

    typedef _IDL_SEQ_REWORKArray_1 _REWORKArray_seq;
    typedef _IDL_SEQ_REWORKArray_1 _REWORKArray_seq_1;
    typedef _IDL_SEQ_REWORKArray_1 REWORKArray;
    typedef _IDL_SEQ_REWORKArray_1_var REWORKArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_REWORKArray;
class  _IDL_SEQ_PARENTLOTIDArray_1_var;
class  _IDL_SEQ_PARENTLOTIDArray_1 {
    public:
        typedef _IDL_SEQ_PARENTLOTIDArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_PARENTLOTIDArray_1 ();
    _IDL_SEQ_PARENTLOTIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_PARENTLOTIDArray_1 (const _IDL_SEQ_PARENTLOTIDArray_1&);


    ~_IDL_SEQ_PARENTLOTIDArray_1 ();

    _IDL_SEQ_PARENTLOTIDArray_1& operator= (const _IDL_SEQ_PARENTLOTIDArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_PARENTLOTIDArray_1> PARENTLOTIDArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_PARENTLOTIDArray_1* _IDL_SEQ_PARENTLOTIDArray_1_vPtr;
typedef const _IDL_SEQ_PARENTLOTIDArray_1* _IDL_SEQ_PARENTLOTIDArray_1_cvPtr;

class  _IDL_SEQ_PARENTLOTIDArray_1_var
{
    public:

    _IDL_SEQ_PARENTLOTIDArray_1_var ();

    _IDL_SEQ_PARENTLOTIDArray_1_var (_IDL_SEQ_PARENTLOTIDArray_1 *_p);

    _IDL_SEQ_PARENTLOTIDArray_1_var (const _IDL_SEQ_PARENTLOTIDArray_1_var &_s);

    _IDL_SEQ_PARENTLOTIDArray_1_var &operator= (_IDL_SEQ_PARENTLOTIDArray_1 *_p);

    _IDL_SEQ_PARENTLOTIDArray_1_var &operator= (const _IDL_SEQ_PARENTLOTIDArray_1_var &_s);

    ~_IDL_SEQ_PARENTLOTIDArray_1_var ();

    _IDL_SEQ_PARENTLOTIDArray_1* operator-> ();

    operator _IDL_SEQ_PARENTLOTIDArray_1_cvPtr () const;

    operator _IDL_SEQ_PARENTLOTIDArray_1_vPtr& ();

    operator _IDL_SEQ_PARENTLOTIDArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_PARENTLOTIDArray_1& in() const;
    _IDL_SEQ_PARENTLOTIDArray_1& inout();
    _IDL_SEQ_PARENTLOTIDArray_1*& out();
    _IDL_SEQ_PARENTLOTIDArray_1* _retn();

    protected:
    _IDL_SEQ_PARENTLOTIDArray_1 *_ptr;
};

    typedef _IDL_SEQ_PARENTLOTIDArray_1 _PARENTLOTIDArray_seq;
    typedef _IDL_SEQ_PARENTLOTIDArray_1 _PARENTLOTIDArray_seq_1;
    typedef _IDL_SEQ_PARENTLOTIDArray_1 PARENTLOTIDArray;
    typedef _IDL_SEQ_PARENTLOTIDArray_1_var PARENTLOTIDArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_PARENTLOTIDArray;
class  _IDL_SEQ_PRETOOLArray_1_var;
class  _IDL_SEQ_PRETOOLArray_1 {
    public:
        typedef _IDL_SEQ_PRETOOLArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_PRETOOLArray_1 ();
    _IDL_SEQ_PRETOOLArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_PRETOOLArray_1 (const _IDL_SEQ_PRETOOLArray_1&);


    ~_IDL_SEQ_PRETOOLArray_1 ();

    _IDL_SEQ_PRETOOLArray_1& operator= (const _IDL_SEQ_PRETOOLArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_PRETOOLArray_1> PRETOOLArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_PRETOOLArray_1* _IDL_SEQ_PRETOOLArray_1_vPtr;
typedef const _IDL_SEQ_PRETOOLArray_1* _IDL_SEQ_PRETOOLArray_1_cvPtr;

class  _IDL_SEQ_PRETOOLArray_1_var
{
    public:

    _IDL_SEQ_PRETOOLArray_1_var ();

    _IDL_SEQ_PRETOOLArray_1_var (_IDL_SEQ_PRETOOLArray_1 *_p);

    _IDL_SEQ_PRETOOLArray_1_var (const _IDL_SEQ_PRETOOLArray_1_var &_s);

    _IDL_SEQ_PRETOOLArray_1_var &operator= (_IDL_SEQ_PRETOOLArray_1 *_p);

    _IDL_SEQ_PRETOOLArray_1_var &operator= (const _IDL_SEQ_PRETOOLArray_1_var &_s);

    ~_IDL_SEQ_PRETOOLArray_1_var ();

    _IDL_SEQ_PRETOOLArray_1* operator-> ();

    operator _IDL_SEQ_PRETOOLArray_1_cvPtr () const;

    operator _IDL_SEQ_PRETOOLArray_1_vPtr& ();

    operator _IDL_SEQ_PRETOOLArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_PRETOOLArray_1& in() const;
    _IDL_SEQ_PRETOOLArray_1& inout();
    _IDL_SEQ_PRETOOLArray_1*& out();
    _IDL_SEQ_PRETOOLArray_1* _retn();

    protected:
    _IDL_SEQ_PRETOOLArray_1 *_ptr;
};

    typedef _IDL_SEQ_PRETOOLArray_1 _PRETOOLArray_seq;
    typedef _IDL_SEQ_PRETOOLArray_1 _PRETOOLArray_seq_1;
    typedef _IDL_SEQ_PRETOOLArray_1 PRETOOLArray;
    typedef _IDL_SEQ_PRETOOLArray_1_var PRETOOLArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_PRETOOLArray;
class  _IDL_SEQ_SENDAHEADArray_1_var;
class  _IDL_SEQ_SENDAHEADArray_1 {
    public:
        typedef _IDL_SEQ_SENDAHEADArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_SENDAHEADArray_1 ();
    _IDL_SEQ_SENDAHEADArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_SENDAHEADArray_1 (const _IDL_SEQ_SENDAHEADArray_1&);


    ~_IDL_SEQ_SENDAHEADArray_1 ();

    _IDL_SEQ_SENDAHEADArray_1& operator= (const _IDL_SEQ_SENDAHEADArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_SENDAHEADArray_1> SENDAHEADArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_SENDAHEADArray_1* _IDL_SEQ_SENDAHEADArray_1_vPtr;
typedef const _IDL_SEQ_SENDAHEADArray_1* _IDL_SEQ_SENDAHEADArray_1_cvPtr;

class  _IDL_SEQ_SENDAHEADArray_1_var
{
    public:

    _IDL_SEQ_SENDAHEADArray_1_var ();

    _IDL_SEQ_SENDAHEADArray_1_var (_IDL_SEQ_SENDAHEADArray_1 *_p);

    _IDL_SEQ_SENDAHEADArray_1_var (const _IDL_SEQ_SENDAHEADArray_1_var &_s);

    _IDL_SEQ_SENDAHEADArray_1_var &operator= (_IDL_SEQ_SENDAHEADArray_1 *_p);

    _IDL_SEQ_SENDAHEADArray_1_var &operator= (const _IDL_SEQ_SENDAHEADArray_1_var &_s);

    ~_IDL_SEQ_SENDAHEADArray_1_var ();

    _IDL_SEQ_SENDAHEADArray_1* operator-> ();

    operator _IDL_SEQ_SENDAHEADArray_1_cvPtr () const;

    operator _IDL_SEQ_SENDAHEADArray_1_vPtr& ();

    operator _IDL_SEQ_SENDAHEADArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_SENDAHEADArray_1& in() const;
    _IDL_SEQ_SENDAHEADArray_1& inout();
    _IDL_SEQ_SENDAHEADArray_1*& out();
    _IDL_SEQ_SENDAHEADArray_1* _retn();

    protected:
    _IDL_SEQ_SENDAHEADArray_1 *_ptr;
};

    typedef _IDL_SEQ_SENDAHEADArray_1 _SENDAHEADArray_seq;
    typedef _IDL_SEQ_SENDAHEADArray_1 _SENDAHEADArray_seq_1;
    typedef _IDL_SEQ_SENDAHEADArray_1 SENDAHEADArray;
    typedef _IDL_SEQ_SENDAHEADArray_1_var SENDAHEADArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_SENDAHEADArray;
class  _IDL_SEQ_SENDAHEADVALUESArray_1_var;
class  _IDL_SEQ_SENDAHEADVALUESArray_1 {
    public:
        typedef _IDL_SEQ_SENDAHEADVALUESArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_SENDAHEADVALUESArray_1 ();
    _IDL_SEQ_SENDAHEADVALUESArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_SENDAHEADVALUESArray_1 (const _IDL_SEQ_SENDAHEADVALUESArray_1&);


    ~_IDL_SEQ_SENDAHEADVALUESArray_1 ();

    _IDL_SEQ_SENDAHEADVALUESArray_1& operator= (const _IDL_SEQ_SENDAHEADVALUESArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_SENDAHEADVALUESArray_1> SENDAHEADVALUESArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_SENDAHEADVALUESArray_1* _IDL_SEQ_SENDAHEADVALUESArray_1_vPtr;
typedef const _IDL_SEQ_SENDAHEADVALUESArray_1* _IDL_SEQ_SENDAHEADVALUESArray_1_cvPtr;

class  _IDL_SEQ_SENDAHEADVALUESArray_1_var
{
    public:

    _IDL_SEQ_SENDAHEADVALUESArray_1_var ();

    _IDL_SEQ_SENDAHEADVALUESArray_1_var (_IDL_SEQ_SENDAHEADVALUESArray_1 *_p);

    _IDL_SEQ_SENDAHEADVALUESArray_1_var (const _IDL_SEQ_SENDAHEADVALUESArray_1_var &_s);

    _IDL_SEQ_SENDAHEADVALUESArray_1_var &operator= (_IDL_SEQ_SENDAHEADVALUESArray_1 *_p);

    _IDL_SEQ_SENDAHEADVALUESArray_1_var &operator= (const _IDL_SEQ_SENDAHEADVALUESArray_1_var &_s);

    ~_IDL_SEQ_SENDAHEADVALUESArray_1_var ();

    _IDL_SEQ_SENDAHEADVALUESArray_1* operator-> ();

    operator _IDL_SEQ_SENDAHEADVALUESArray_1_cvPtr () const;

    operator _IDL_SEQ_SENDAHEADVALUESArray_1_vPtr& ();

    operator _IDL_SEQ_SENDAHEADVALUESArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_SENDAHEADVALUESArray_1& in() const;
    _IDL_SEQ_SENDAHEADVALUESArray_1& inout();
    _IDL_SEQ_SENDAHEADVALUESArray_1*& out();
    _IDL_SEQ_SENDAHEADVALUESArray_1* _retn();

    protected:
    _IDL_SEQ_SENDAHEADVALUESArray_1 *_ptr;
};

    typedef _IDL_SEQ_SENDAHEADVALUESArray_1 _SENDAHEADVALUESArray_seq;
    typedef _IDL_SEQ_SENDAHEADVALUESArray_1 _SENDAHEADVALUESArray_seq_1;
    typedef _IDL_SEQ_SENDAHEADVALUESArray_1 SENDAHEADVALUESArray;
    typedef _IDL_SEQ_SENDAHEADVALUESArray_1_var SENDAHEADVALUESArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_SENDAHEADVALUESArray;
class  _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var;
class  _IDL_SEQ_AVAILABLE_SUBUNITArray_1 {
    public:
        typedef _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_AVAILABLE_SUBUNITArray_1 ();
    _IDL_SEQ_AVAILABLE_SUBUNITArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_AVAILABLE_SUBUNITArray_1 (const _IDL_SEQ_AVAILABLE_SUBUNITArray_1&);


    ~_IDL_SEQ_AVAILABLE_SUBUNITArray_1 ();

    _IDL_SEQ_AVAILABLE_SUBUNITArray_1& operator= (const _IDL_SEQ_AVAILABLE_SUBUNITArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_AVAILABLE_SUBUNITArray_1> AVAILABLE_SUBUNITArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_AVAILABLE_SUBUNITArray_1* _IDL_SEQ_AVAILABLE_SUBUNITArray_1_vPtr;
typedef const _IDL_SEQ_AVAILABLE_SUBUNITArray_1* _IDL_SEQ_AVAILABLE_SUBUNITArray_1_cvPtr;

class  _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var
{
    public:

    _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var ();

    _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var (_IDL_SEQ_AVAILABLE_SUBUNITArray_1 *_p);

    _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var (const _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var &_s);

    _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var &operator= (_IDL_SEQ_AVAILABLE_SUBUNITArray_1 *_p);

    _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var &operator= (const _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var &_s);

    ~_IDL_SEQ_AVAILABLE_SUBUNITArray_1_var ();

    _IDL_SEQ_AVAILABLE_SUBUNITArray_1* operator-> ();

    operator _IDL_SEQ_AVAILABLE_SUBUNITArray_1_cvPtr () const;

    operator _IDL_SEQ_AVAILABLE_SUBUNITArray_1_vPtr& ();

    operator _IDL_SEQ_AVAILABLE_SUBUNITArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_AVAILABLE_SUBUNITArray_1& in() const;
    _IDL_SEQ_AVAILABLE_SUBUNITArray_1& inout();
    _IDL_SEQ_AVAILABLE_SUBUNITArray_1*& out();
    _IDL_SEQ_AVAILABLE_SUBUNITArray_1* _retn();

    protected:
    _IDL_SEQ_AVAILABLE_SUBUNITArray_1 *_ptr;
};

    typedef _IDL_SEQ_AVAILABLE_SUBUNITArray_1 _AVAILABLE_SUBUNITArray_seq;
    typedef _IDL_SEQ_AVAILABLE_SUBUNITArray_1 _AVAILABLE_SUBUNITArray_seq_1;
    typedef _IDL_SEQ_AVAILABLE_SUBUNITArray_1 AVAILABLE_SUBUNITArray;
    typedef _IDL_SEQ_AVAILABLE_SUBUNITArray_1_var AVAILABLE_SUBUNITArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_AVAILABLE_SUBUNITArray;
class  _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var;
class  _IDL_SEQ_IS_OPSTART_RECOMDArray_1 {
    public:
        typedef _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_IS_OPSTART_RECOMDArray_1 ();
    _IDL_SEQ_IS_OPSTART_RECOMDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_IS_OPSTART_RECOMDArray_1 (const _IDL_SEQ_IS_OPSTART_RECOMDArray_1&);


    ~_IDL_SEQ_IS_OPSTART_RECOMDArray_1 ();

    _IDL_SEQ_IS_OPSTART_RECOMDArray_1& operator= (const _IDL_SEQ_IS_OPSTART_RECOMDArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_IS_OPSTART_RECOMDArray_1> IS_OPSTART_RECOMDArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_IS_OPSTART_RECOMDArray_1* _IDL_SEQ_IS_OPSTART_RECOMDArray_1_vPtr;
typedef const _IDL_SEQ_IS_OPSTART_RECOMDArray_1* _IDL_SEQ_IS_OPSTART_RECOMDArray_1_cvPtr;

class  _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var
{
    public:

    _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var ();

    _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var (_IDL_SEQ_IS_OPSTART_RECOMDArray_1 *_p);

    _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var (const _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var &_s);

    _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var &operator= (_IDL_SEQ_IS_OPSTART_RECOMDArray_1 *_p);

    _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var &operator= (const _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var &_s);

    ~_IDL_SEQ_IS_OPSTART_RECOMDArray_1_var ();

    _IDL_SEQ_IS_OPSTART_RECOMDArray_1* operator-> ();

    operator _IDL_SEQ_IS_OPSTART_RECOMDArray_1_cvPtr () const;

    operator _IDL_SEQ_IS_OPSTART_RECOMDArray_1_vPtr& ();

    operator _IDL_SEQ_IS_OPSTART_RECOMDArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_IS_OPSTART_RECOMDArray_1& in() const;
    _IDL_SEQ_IS_OPSTART_RECOMDArray_1& inout();
    _IDL_SEQ_IS_OPSTART_RECOMDArray_1*& out();
    _IDL_SEQ_IS_OPSTART_RECOMDArray_1* _retn();

    protected:
    _IDL_SEQ_IS_OPSTART_RECOMDArray_1 *_ptr;
};

    typedef _IDL_SEQ_IS_OPSTART_RECOMDArray_1 _IS_OPSTART_RECOMDArray_seq;
    typedef _IDL_SEQ_IS_OPSTART_RECOMDArray_1 _IS_OPSTART_RECOMDArray_seq_1;
    typedef _IDL_SEQ_IS_OPSTART_RECOMDArray_1 IS_OPSTART_RECOMDArray;
    typedef _IDL_SEQ_IS_OPSTART_RECOMDArray_1_var IS_OPSTART_RECOMDArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_IS_OPSTART_RECOMDArray;
class  _IDL_SEQ_BR_PARAMSArray_1_var;
class  _IDL_SEQ_BR_PARAMSArray_1 {
    public:
        typedef _IDL_SEQ_BR_PARAMSArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_BR_PARAMSArray_1 ();
    _IDL_SEQ_BR_PARAMSArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_BR_PARAMSArray_1 (const _IDL_SEQ_BR_PARAMSArray_1&);


    ~_IDL_SEQ_BR_PARAMSArray_1 ();

    _IDL_SEQ_BR_PARAMSArray_1& operator= (const _IDL_SEQ_BR_PARAMSArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_BR_PARAMSArray_1> BR_PARAMSArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_BR_PARAMSArray_1* _IDL_SEQ_BR_PARAMSArray_1_vPtr;
typedef const _IDL_SEQ_BR_PARAMSArray_1* _IDL_SEQ_BR_PARAMSArray_1_cvPtr;

class  _IDL_SEQ_BR_PARAMSArray_1_var
{
    public:

    _IDL_SEQ_BR_PARAMSArray_1_var ();

    _IDL_SEQ_BR_PARAMSArray_1_var (_IDL_SEQ_BR_PARAMSArray_1 *_p);

    _IDL_SEQ_BR_PARAMSArray_1_var (const _IDL_SEQ_BR_PARAMSArray_1_var &_s);

    _IDL_SEQ_BR_PARAMSArray_1_var &operator= (_IDL_SEQ_BR_PARAMSArray_1 *_p);

    _IDL_SEQ_BR_PARAMSArray_1_var &operator= (const _IDL_SEQ_BR_PARAMSArray_1_var &_s);

    ~_IDL_SEQ_BR_PARAMSArray_1_var ();

    _IDL_SEQ_BR_PARAMSArray_1* operator-> ();

    operator _IDL_SEQ_BR_PARAMSArray_1_cvPtr () const;

    operator _IDL_SEQ_BR_PARAMSArray_1_vPtr& ();

    operator _IDL_SEQ_BR_PARAMSArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_BR_PARAMSArray_1& in() const;
    _IDL_SEQ_BR_PARAMSArray_1& inout();
    _IDL_SEQ_BR_PARAMSArray_1*& out();
    _IDL_SEQ_BR_PARAMSArray_1* _retn();

    protected:
    _IDL_SEQ_BR_PARAMSArray_1 *_ptr;
};

    typedef _IDL_SEQ_BR_PARAMSArray_1 _BR_PARAMSArray_seq;
    typedef _IDL_SEQ_BR_PARAMSArray_1 _BR_PARAMSArray_seq_1;
    typedef _IDL_SEQ_BR_PARAMSArray_1 BR_PARAMSArray;
    typedef _IDL_SEQ_BR_PARAMSArray_1_var BR_PARAMSArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_BR_PARAMSArray;
class  _IDL_SEQ_FEEDFORWARD1Array_1_var;
class  _IDL_SEQ_FEEDFORWARD1Array_1 {
    public:
        typedef _IDL_SEQ_FEEDFORWARD1Array_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_FEEDFORWARD1Array_1 ();
    _IDL_SEQ_FEEDFORWARD1Array_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_FEEDFORWARD1Array_1 (const _IDL_SEQ_FEEDFORWARD1Array_1&);


    ~_IDL_SEQ_FEEDFORWARD1Array_1 ();

    _IDL_SEQ_FEEDFORWARD1Array_1& operator= (const _IDL_SEQ_FEEDFORWARD1Array_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_FEEDFORWARD1Array_1> FEEDFORWARD1Array_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_FEEDFORWARD1Array_1* _IDL_SEQ_FEEDFORWARD1Array_1_vPtr;
typedef const _IDL_SEQ_FEEDFORWARD1Array_1* _IDL_SEQ_FEEDFORWARD1Array_1_cvPtr;

class  _IDL_SEQ_FEEDFORWARD1Array_1_var
{
    public:

    _IDL_SEQ_FEEDFORWARD1Array_1_var ();

    _IDL_SEQ_FEEDFORWARD1Array_1_var (_IDL_SEQ_FEEDFORWARD1Array_1 *_p);

    _IDL_SEQ_FEEDFORWARD1Array_1_var (const _IDL_SEQ_FEEDFORWARD1Array_1_var &_s);

    _IDL_SEQ_FEEDFORWARD1Array_1_var &operator= (_IDL_SEQ_FEEDFORWARD1Array_1 *_p);

    _IDL_SEQ_FEEDFORWARD1Array_1_var &operator= (const _IDL_SEQ_FEEDFORWARD1Array_1_var &_s);

    ~_IDL_SEQ_FEEDFORWARD1Array_1_var ();

    _IDL_SEQ_FEEDFORWARD1Array_1* operator-> ();

    operator _IDL_SEQ_FEEDFORWARD1Array_1_cvPtr () const;

    operator _IDL_SEQ_FEEDFORWARD1Array_1_vPtr& ();

    operator _IDL_SEQ_FEEDFORWARD1Array_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_FEEDFORWARD1Array_1& in() const;
    _IDL_SEQ_FEEDFORWARD1Array_1& inout();
    _IDL_SEQ_FEEDFORWARD1Array_1*& out();
    _IDL_SEQ_FEEDFORWARD1Array_1* _retn();

    protected:
    _IDL_SEQ_FEEDFORWARD1Array_1 *_ptr;
};

    typedef _IDL_SEQ_FEEDFORWARD1Array_1 _FEEDFORWARD1Array_seq;
    typedef _IDL_SEQ_FEEDFORWARD1Array_1 _FEEDFORWARD1Array_seq_1;
    typedef _IDL_SEQ_FEEDFORWARD1Array_1 FEEDFORWARD1Array;
    typedef _IDL_SEQ_FEEDFORWARD1Array_1_var FEEDFORWARD1Array_var;
    extern  ::CORBA::TypeCode_ptr _tc_FEEDFORWARD1Array;
class  _IDL_SEQ_FEEDFORWARD2Array_1_var;
class  _IDL_SEQ_FEEDFORWARD2Array_1 {
    public:
        typedef _IDL_SEQ_FEEDFORWARD2Array_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_FEEDFORWARD2Array_1 ();
    _IDL_SEQ_FEEDFORWARD2Array_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_FEEDFORWARD2Array_1 (const _IDL_SEQ_FEEDFORWARD2Array_1&);


    ~_IDL_SEQ_FEEDFORWARD2Array_1 ();

    _IDL_SEQ_FEEDFORWARD2Array_1& operator= (const _IDL_SEQ_FEEDFORWARD2Array_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_FEEDFORWARD2Array_1> FEEDFORWARD2Array_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_FEEDFORWARD2Array_1* _IDL_SEQ_FEEDFORWARD2Array_1_vPtr;
typedef const _IDL_SEQ_FEEDFORWARD2Array_1* _IDL_SEQ_FEEDFORWARD2Array_1_cvPtr;

class  _IDL_SEQ_FEEDFORWARD2Array_1_var
{
    public:

    _IDL_SEQ_FEEDFORWARD2Array_1_var ();

    _IDL_SEQ_FEEDFORWARD2Array_1_var (_IDL_SEQ_FEEDFORWARD2Array_1 *_p);

    _IDL_SEQ_FEEDFORWARD2Array_1_var (const _IDL_SEQ_FEEDFORWARD2Array_1_var &_s);

    _IDL_SEQ_FEEDFORWARD2Array_1_var &operator= (_IDL_SEQ_FEEDFORWARD2Array_1 *_p);

    _IDL_SEQ_FEEDFORWARD2Array_1_var &operator= (const _IDL_SEQ_FEEDFORWARD2Array_1_var &_s);

    ~_IDL_SEQ_FEEDFORWARD2Array_1_var ();

    _IDL_SEQ_FEEDFORWARD2Array_1* operator-> ();

    operator _IDL_SEQ_FEEDFORWARD2Array_1_cvPtr () const;

    operator _IDL_SEQ_FEEDFORWARD2Array_1_vPtr& ();

    operator _IDL_SEQ_FEEDFORWARD2Array_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_FEEDFORWARD2Array_1& in() const;
    _IDL_SEQ_FEEDFORWARD2Array_1& inout();
    _IDL_SEQ_FEEDFORWARD2Array_1*& out();
    _IDL_SEQ_FEEDFORWARD2Array_1* _retn();

    protected:
    _IDL_SEQ_FEEDFORWARD2Array_1 *_ptr;
};

    typedef _IDL_SEQ_FEEDFORWARD2Array_1 _FEEDFORWARD2Array_seq;
    typedef _IDL_SEQ_FEEDFORWARD2Array_1 _FEEDFORWARD2Array_seq_1;
    typedef _IDL_SEQ_FEEDFORWARD2Array_1 FEEDFORWARD2Array;
    typedef _IDL_SEQ_FEEDFORWARD2Array_1_var FEEDFORWARD2Array_var;
    extern  ::CORBA::TypeCode_ptr _tc_FEEDFORWARD2Array;
class  _IDL_SEQ_FEEDFORWARD3Array_1_var;
class  _IDL_SEQ_FEEDFORWARD3Array_1 {
    public:
        typedef _IDL_SEQ_FEEDFORWARD3Array_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_FEEDFORWARD3Array_1 ();
    _IDL_SEQ_FEEDFORWARD3Array_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_FEEDFORWARD3Array_1 (const _IDL_SEQ_FEEDFORWARD3Array_1&);


    ~_IDL_SEQ_FEEDFORWARD3Array_1 ();

    _IDL_SEQ_FEEDFORWARD3Array_1& operator= (const _IDL_SEQ_FEEDFORWARD3Array_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_FEEDFORWARD3Array_1> FEEDFORWARD3Array_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_FEEDFORWARD3Array_1* _IDL_SEQ_FEEDFORWARD3Array_1_vPtr;
typedef const _IDL_SEQ_FEEDFORWARD3Array_1* _IDL_SEQ_FEEDFORWARD3Array_1_cvPtr;

class  _IDL_SEQ_FEEDFORWARD3Array_1_var
{
    public:

    _IDL_SEQ_FEEDFORWARD3Array_1_var ();

    _IDL_SEQ_FEEDFORWARD3Array_1_var (_IDL_SEQ_FEEDFORWARD3Array_1 *_p);

    _IDL_SEQ_FEEDFORWARD3Array_1_var (const _IDL_SEQ_FEEDFORWARD3Array_1_var &_s);

    _IDL_SEQ_FEEDFORWARD3Array_1_var &operator= (_IDL_SEQ_FEEDFORWARD3Array_1 *_p);

    _IDL_SEQ_FEEDFORWARD3Array_1_var &operator= (const _IDL_SEQ_FEEDFORWARD3Array_1_var &_s);

    ~_IDL_SEQ_FEEDFORWARD3Array_1_var ();

    _IDL_SEQ_FEEDFORWARD3Array_1* operator-> ();

    operator _IDL_SEQ_FEEDFORWARD3Array_1_cvPtr () const;

    operator _IDL_SEQ_FEEDFORWARD3Array_1_vPtr& ();

    operator _IDL_SEQ_FEEDFORWARD3Array_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_FEEDFORWARD3Array_1& in() const;
    _IDL_SEQ_FEEDFORWARD3Array_1& inout();
    _IDL_SEQ_FEEDFORWARD3Array_1*& out();
    _IDL_SEQ_FEEDFORWARD3Array_1* _retn();

    protected:
    _IDL_SEQ_FEEDFORWARD3Array_1 *_ptr;
};

    typedef _IDL_SEQ_FEEDFORWARD3Array_1 _FEEDFORWARD3Array_seq;
    typedef _IDL_SEQ_FEEDFORWARD3Array_1 _FEEDFORWARD3Array_seq_1;
    typedef _IDL_SEQ_FEEDFORWARD3Array_1 FEEDFORWARD3Array;
    typedef _IDL_SEQ_FEEDFORWARD3Array_1_var FEEDFORWARD3Array_var;
    extern  ::CORBA::TypeCode_ptr _tc_FEEDFORWARD3Array;
class  _IDL_SEQ_FEEDFORWARD4Array_1_var;
class  _IDL_SEQ_FEEDFORWARD4Array_1 {
    public:
        typedef _IDL_SEQ_FEEDFORWARD4Array_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_FEEDFORWARD4Array_1 ();
    _IDL_SEQ_FEEDFORWARD4Array_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_FEEDFORWARD4Array_1 (const _IDL_SEQ_FEEDFORWARD4Array_1&);


    ~_IDL_SEQ_FEEDFORWARD4Array_1 ();

    _IDL_SEQ_FEEDFORWARD4Array_1& operator= (const _IDL_SEQ_FEEDFORWARD4Array_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_FEEDFORWARD4Array_1> FEEDFORWARD4Array_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_FEEDFORWARD4Array_1* _IDL_SEQ_FEEDFORWARD4Array_1_vPtr;
typedef const _IDL_SEQ_FEEDFORWARD4Array_1* _IDL_SEQ_FEEDFORWARD4Array_1_cvPtr;

class  _IDL_SEQ_FEEDFORWARD4Array_1_var
{
    public:

    _IDL_SEQ_FEEDFORWARD4Array_1_var ();

    _IDL_SEQ_FEEDFORWARD4Array_1_var (_IDL_SEQ_FEEDFORWARD4Array_1 *_p);

    _IDL_SEQ_FEEDFORWARD4Array_1_var (const _IDL_SEQ_FEEDFORWARD4Array_1_var &_s);

    _IDL_SEQ_FEEDFORWARD4Array_1_var &operator= (_IDL_SEQ_FEEDFORWARD4Array_1 *_p);

    _IDL_SEQ_FEEDFORWARD4Array_1_var &operator= (const _IDL_SEQ_FEEDFORWARD4Array_1_var &_s);

    ~_IDL_SEQ_FEEDFORWARD4Array_1_var ();

    _IDL_SEQ_FEEDFORWARD4Array_1* operator-> ();

    operator _IDL_SEQ_FEEDFORWARD4Array_1_cvPtr () const;

    operator _IDL_SEQ_FEEDFORWARD4Array_1_vPtr& ();

    operator _IDL_SEQ_FEEDFORWARD4Array_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_FEEDFORWARD4Array_1& in() const;
    _IDL_SEQ_FEEDFORWARD4Array_1& inout();
    _IDL_SEQ_FEEDFORWARD4Array_1*& out();
    _IDL_SEQ_FEEDFORWARD4Array_1* _retn();

    protected:
    _IDL_SEQ_FEEDFORWARD4Array_1 *_ptr;
};

    typedef _IDL_SEQ_FEEDFORWARD4Array_1 _FEEDFORWARD4Array_seq;
    typedef _IDL_SEQ_FEEDFORWARD4Array_1 _FEEDFORWARD4Array_seq_1;
    typedef _IDL_SEQ_FEEDFORWARD4Array_1 FEEDFORWARD4Array;
    typedef _IDL_SEQ_FEEDFORWARD4Array_1_var FEEDFORWARD4Array_var;
    extern  ::CORBA::TypeCode_ptr _tc_FEEDFORWARD4Array;
class  _IDL_SEQ_NAMEArray_1_var;
class  _IDL_SEQ_NAMEArray_1 {
    public:
        typedef _IDL_SEQ_NAMEArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_NAMEArray_1 ();
    _IDL_SEQ_NAMEArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_NAMEArray_1 (const _IDL_SEQ_NAMEArray_1&);


    ~_IDL_SEQ_NAMEArray_1 ();

    _IDL_SEQ_NAMEArray_1& operator= (const _IDL_SEQ_NAMEArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_NAMEArray_1> NAMEArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_NAMEArray_1* _IDL_SEQ_NAMEArray_1_vPtr;
typedef const _IDL_SEQ_NAMEArray_1* _IDL_SEQ_NAMEArray_1_cvPtr;

class  _IDL_SEQ_NAMEArray_1_var
{
    public:

    _IDL_SEQ_NAMEArray_1_var ();

    _IDL_SEQ_NAMEArray_1_var (_IDL_SEQ_NAMEArray_1 *_p);

    _IDL_SEQ_NAMEArray_1_var (const _IDL_SEQ_NAMEArray_1_var &_s);

    _IDL_SEQ_NAMEArray_1_var &operator= (_IDL_SEQ_NAMEArray_1 *_p);

    _IDL_SEQ_NAMEArray_1_var &operator= (const _IDL_SEQ_NAMEArray_1_var &_s);

    ~_IDL_SEQ_NAMEArray_1_var ();

    _IDL_SEQ_NAMEArray_1* operator-> ();

    operator _IDL_SEQ_NAMEArray_1_cvPtr () const;

    operator _IDL_SEQ_NAMEArray_1_vPtr& ();

    operator _IDL_SEQ_NAMEArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_NAMEArray_1& in() const;
    _IDL_SEQ_NAMEArray_1& inout();
    _IDL_SEQ_NAMEArray_1*& out();
    _IDL_SEQ_NAMEArray_1* _retn();

    protected:
    _IDL_SEQ_NAMEArray_1 *_ptr;
};

    typedef _IDL_SEQ_NAMEArray_1 _NAMEArray_seq;
    typedef _IDL_SEQ_NAMEArray_1 _NAMEArray_seq_1;
    typedef _IDL_SEQ_NAMEArray_1 NAMEArray;
    typedef _IDL_SEQ_NAMEArray_1_var NAMEArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_NAMEArray;
class  _IDL_SEQ_VALUEArray_1_var;
class  _IDL_SEQ_VALUEArray_1 {
    public:
        typedef _IDL_SEQ_VALUEArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_VALUEArray_1 ();
    _IDL_SEQ_VALUEArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_VALUEArray_1 (const _IDL_SEQ_VALUEArray_1&);


    ~_IDL_SEQ_VALUEArray_1 ();

    _IDL_SEQ_VALUEArray_1& operator= (const _IDL_SEQ_VALUEArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_VALUEArray_1> VALUEArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_VALUEArray_1* _IDL_SEQ_VALUEArray_1_vPtr;
typedef const _IDL_SEQ_VALUEArray_1* _IDL_SEQ_VALUEArray_1_cvPtr;

class  _IDL_SEQ_VALUEArray_1_var
{
    public:

    _IDL_SEQ_VALUEArray_1_var ();

    _IDL_SEQ_VALUEArray_1_var (_IDL_SEQ_VALUEArray_1 *_p);

    _IDL_SEQ_VALUEArray_1_var (const _IDL_SEQ_VALUEArray_1_var &_s);

    _IDL_SEQ_VALUEArray_1_var &operator= (_IDL_SEQ_VALUEArray_1 *_p);

    _IDL_SEQ_VALUEArray_1_var &operator= (const _IDL_SEQ_VALUEArray_1_var &_s);

    ~_IDL_SEQ_VALUEArray_1_var ();

    _IDL_SEQ_VALUEArray_1* operator-> ();

    operator _IDL_SEQ_VALUEArray_1_cvPtr () const;

    operator _IDL_SEQ_VALUEArray_1_vPtr& ();

    operator _IDL_SEQ_VALUEArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_VALUEArray_1& in() const;
    _IDL_SEQ_VALUEArray_1& inout();
    _IDL_SEQ_VALUEArray_1*& out();
    _IDL_SEQ_VALUEArray_1* _retn();

    protected:
    _IDL_SEQ_VALUEArray_1 *_ptr;
};

    typedef _IDL_SEQ_VALUEArray_1 _VALUEArray_seq;
    typedef _IDL_SEQ_VALUEArray_1 _VALUEArray_seq_1;
    typedef _IDL_SEQ_VALUEArray_1 VALUEArray;
    typedef _IDL_SEQ_VALUEArray_1_var VALUEArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_VALUEArray;
    class  ITEM_VALUE_var;
    struct  ITEM_VALUE {
        typedef ITEM_VALUE_var _var_type;
       ::NAMEArray NAME;
       ::VALUEArray VALUE;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       ITEM_VALUE();
       ITEM_VALUE(const ITEM_VALUE&);
       ITEM_VALUE& operator=(const ITEM_VALUE&);
       static CORBA::Info<ITEM_VALUE> ITEM_VALUE_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct ITEM_VALUE


typedef ITEM_VALUE* ITEM_VALUE_vPtr;
typedef const ITEM_VALUE* ITEM_VALUE_cvPtr;

class  ITEM_VALUE_var
{
    public:

    ITEM_VALUE_var ();

    ITEM_VALUE_var (ITEM_VALUE *_p);

    ITEM_VALUE_var (const ITEM_VALUE_var &_s);

    ITEM_VALUE_var &operator= (ITEM_VALUE *_p);

    ITEM_VALUE_var &operator= (const ITEM_VALUE_var &_s);

    ~ITEM_VALUE_var ();

    ITEM_VALUE* operator-> ();

    const ITEM_VALUE& in() const;
    ITEM_VALUE& inout();
    ITEM_VALUE*& out();
    ITEM_VALUE* _retn();

    operator ITEM_VALUE_cvPtr () const;

    operator ITEM_VALUE_vPtr& ();

    operator const ITEM_VALUE& () const;

    operator ITEM_VALUE& ();

    protected:
    ITEM_VALUE *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_ITEM_VALUE;
class  _IDL_SEQ_ArrayOfITEM_VALUE_0_var;
class  _IDL_SEQ_ArrayOfITEM_VALUE_0 {
    public:
        typedef _IDL_SEQ_ArrayOfITEM_VALUE_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    ITEM_VALUE *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_ArrayOfITEM_VALUE_0 ();
    _IDL_SEQ_ArrayOfITEM_VALUE_0 (::CORBA::ULong max);
    _IDL_SEQ_ArrayOfITEM_VALUE_0 (::CORBA::ULong max, ::CORBA::ULong length, ITEM_VALUE* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_ArrayOfITEM_VALUE_0 (const _IDL_SEQ_ArrayOfITEM_VALUE_0&);

    ~_IDL_SEQ_ArrayOfITEM_VALUE_0 ();

    _IDL_SEQ_ArrayOfITEM_VALUE_0& operator= (const _IDL_SEQ_ArrayOfITEM_VALUE_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ITEM_VALUE& operator [] (::CORBA::ULong indx);
    const ITEM_VALUE& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ITEM_VALUE* get_buffer (::CORBA::Boolean orphan=0);
    const ITEM_VALUE* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, ITEM_VALUE* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ITEM_VALUE* src, ITEM_VALUE* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ITEM_VALUE* data); 
  public:

    static ITEM_VALUE* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ITEM_VALUE* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(ITEM_VALUE* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_ArrayOfITEM_VALUE_0> ArrayOfITEM_VALUE_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_ArrayOfITEM_VALUE_0* _IDL_SEQ_ArrayOfITEM_VALUE_0_vPtr;
typedef const _IDL_SEQ_ArrayOfITEM_VALUE_0* _IDL_SEQ_ArrayOfITEM_VALUE_0_cvPtr;

class  _IDL_SEQ_ArrayOfITEM_VALUE_0_var
{
    public:

    _IDL_SEQ_ArrayOfITEM_VALUE_0_var ();

    _IDL_SEQ_ArrayOfITEM_VALUE_0_var (_IDL_SEQ_ArrayOfITEM_VALUE_0 *_p);

    _IDL_SEQ_ArrayOfITEM_VALUE_0_var (const _IDL_SEQ_ArrayOfITEM_VALUE_0_var &_s);

    _IDL_SEQ_ArrayOfITEM_VALUE_0_var &operator= (_IDL_SEQ_ArrayOfITEM_VALUE_0 *_p);

    _IDL_SEQ_ArrayOfITEM_VALUE_0_var &operator= (const _IDL_SEQ_ArrayOfITEM_VALUE_0_var &_s);

    ~_IDL_SEQ_ArrayOfITEM_VALUE_0_var ();

    _IDL_SEQ_ArrayOfITEM_VALUE_0* operator-> ();

    operator _IDL_SEQ_ArrayOfITEM_VALUE_0_cvPtr () const;

    operator _IDL_SEQ_ArrayOfITEM_VALUE_0_vPtr& ();

    operator _IDL_SEQ_ArrayOfITEM_VALUE_0() const;

    const ITEM_VALUE& operator[] (::CORBA::ULong index) const;
    ITEM_VALUE& operator[] (::CORBA::ULong index);
    const ITEM_VALUE& operator[] (int index) const;
    ITEM_VALUE& operator[] (int index);
    const _IDL_SEQ_ArrayOfITEM_VALUE_0& in() const;
    _IDL_SEQ_ArrayOfITEM_VALUE_0& inout();
    _IDL_SEQ_ArrayOfITEM_VALUE_0*& out();
    _IDL_SEQ_ArrayOfITEM_VALUE_0* _retn();

    protected:
    _IDL_SEQ_ArrayOfITEM_VALUE_0 *_ptr;
};

    typedef _IDL_SEQ_ArrayOfITEM_VALUE_0 _ArrayOfITEM_VALUE_seq;
    typedef _IDL_SEQ_ArrayOfITEM_VALUE_0 _ArrayOfITEM_VALUE_seq_1;
    typedef _IDL_SEQ_ArrayOfITEM_VALUE_0 ArrayOfITEM_VALUE;
    typedef _IDL_SEQ_ArrayOfITEM_VALUE_0_var ArrayOfITEM_VALUE_var;
    extern  ::CORBA::TypeCode_ptr _tc_ArrayOfITEM_VALUE;
class  _IDL_SEQ_LD_EXTENDArray_1_var;
class  _IDL_SEQ_LD_EXTENDArray_1 {
    public:
        typedef _IDL_SEQ_LD_EXTENDArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ArrayOfITEM_VALUE *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_LD_EXTENDArray_1 ();
    _IDL_SEQ_LD_EXTENDArray_1 (::CORBA::ULong length, ArrayOfITEM_VALUE* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_LD_EXTENDArray_1 (const _IDL_SEQ_LD_EXTENDArray_1&);


    ~_IDL_SEQ_LD_EXTENDArray_1 ();

    _IDL_SEQ_LD_EXTENDArray_1& operator= (const _IDL_SEQ_LD_EXTENDArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ArrayOfITEM_VALUE& operator [] (::CORBA::ULong indx);
    const ArrayOfITEM_VALUE& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ArrayOfITEM_VALUE* get_buffer (::CORBA::Boolean orphan=0);
    const ArrayOfITEM_VALUE* get_buffer () const;
    void replace (::CORBA::ULong length, ArrayOfITEM_VALUE* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ArrayOfITEM_VALUE* src, ArrayOfITEM_VALUE* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ArrayOfITEM_VALUE* data); 
  public:

    static ArrayOfITEM_VALUE* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ArrayOfITEM_VALUE* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(ArrayOfITEM_VALUE* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_LD_EXTENDArray_1> LD_EXTENDArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_LD_EXTENDArray_1* _IDL_SEQ_LD_EXTENDArray_1_vPtr;
typedef const _IDL_SEQ_LD_EXTENDArray_1* _IDL_SEQ_LD_EXTENDArray_1_cvPtr;

class  _IDL_SEQ_LD_EXTENDArray_1_var
{
    public:

    _IDL_SEQ_LD_EXTENDArray_1_var ();

    _IDL_SEQ_LD_EXTENDArray_1_var (_IDL_SEQ_LD_EXTENDArray_1 *_p);

    _IDL_SEQ_LD_EXTENDArray_1_var (const _IDL_SEQ_LD_EXTENDArray_1_var &_s);

    _IDL_SEQ_LD_EXTENDArray_1_var &operator= (_IDL_SEQ_LD_EXTENDArray_1 *_p);

    _IDL_SEQ_LD_EXTENDArray_1_var &operator= (const _IDL_SEQ_LD_EXTENDArray_1_var &_s);

    ~_IDL_SEQ_LD_EXTENDArray_1_var ();

    _IDL_SEQ_LD_EXTENDArray_1* operator-> ();

    operator _IDL_SEQ_LD_EXTENDArray_1_cvPtr () const;

    operator _IDL_SEQ_LD_EXTENDArray_1_vPtr& ();

    operator _IDL_SEQ_LD_EXTENDArray_1() const;

    const ArrayOfITEM_VALUE& operator[] (::CORBA::ULong index) const;
    ArrayOfITEM_VALUE& operator[] (::CORBA::ULong index);
    const ArrayOfITEM_VALUE& operator[] (int index) const;
    ArrayOfITEM_VALUE& operator[] (int index);
    const _IDL_SEQ_LD_EXTENDArray_1& in() const;
    _IDL_SEQ_LD_EXTENDArray_1& inout();
    _IDL_SEQ_LD_EXTENDArray_1*& out();
    _IDL_SEQ_LD_EXTENDArray_1* _retn();

    protected:
    _IDL_SEQ_LD_EXTENDArray_1 *_ptr;
};

    typedef _IDL_SEQ_LD_EXTENDArray_1 _LD_EXTENDArray_seq;
    typedef _IDL_SEQ_LD_EXTENDArray_1 _LD_EXTENDArray_seq_1;
    typedef _IDL_SEQ_LD_EXTENDArray_1 LD_EXTENDArray;
    typedef _IDL_SEQ_LD_EXTENDArray_1_var LD_EXTENDArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_LD_EXTENDArray;
    class  Innotron_Rec_APC_CONTEXT_var;
    struct  Innotron_Rec_APC_CONTEXT {
        typedef Innotron_Rec_APC_CONTEXT_var _var_type;
       ::CONTROLJOBTYPEArray CONTROLJOBTYPE;
       ::TRANSACTIONIDArray TRANSACTIONID;
       ::LOTIDArray LOTID;
       ::LOTTYPEArray LOTTYPE;
       ::PARTIDArray PARTID;
       ::LAYERArray LAYER;
       ::ROUTEArray ROUTE;
       ::ROUTEGROUPArray ROUTEGROUP;
       ::OPERATIONArray OPERATION;
       ::RETICLEIDArray RETICLEID;
       ::PROCESSEQUIPTYPEArray PROCESSEQUIPTYPE;
       ::PROCESSEQUIPIDArray PROCESSEQUIPID;
       ::RECOMMENDMODEArray RECOMMENDMODE;
       ::REWORKArray REWORK;
       ::PARENTLOTIDArray PARENTLOTID;
       ::PRETOOLArray PRETOOL;
       ::SENDAHEADArray SENDAHEAD;
       ::SENDAHEADVALUESArray SENDAHEADVALUES;
       ::AVAILABLE_SUBUNITArray AVAILABLE_SUBUNIT;
       ::IS_OPSTART_RECOMDArray IS_OPSTART_RECOMD;
       ::BR_PARAMSArray BR_PARAMS;
       ::FEEDFORWARD1Array FEEDFORWARD1;
       ::FEEDFORWARD2Array FEEDFORWARD2;
       ::FEEDFORWARD3Array FEEDFORWARD3;
       ::FEEDFORWARD4Array FEEDFORWARD4;
       ::LD_EXTENDArray LD_EXTEND;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       Innotron_Rec_APC_CONTEXT();
       Innotron_Rec_APC_CONTEXT(const Innotron_Rec_APC_CONTEXT&);
       Innotron_Rec_APC_CONTEXT& operator=(const Innotron_Rec_APC_CONTEXT&);
       static CORBA::Info<Innotron_Rec_APC_CONTEXT> Innotron_Rec_APC_CONTEXT_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct Innotron_Rec_APC_CONTEXT


typedef Innotron_Rec_APC_CONTEXT* Innotron_Rec_APC_CONTEXT_vPtr;
typedef const Innotron_Rec_APC_CONTEXT* Innotron_Rec_APC_CONTEXT_cvPtr;

class  Innotron_Rec_APC_CONTEXT_var
{
    public:

    Innotron_Rec_APC_CONTEXT_var ();

    Innotron_Rec_APC_CONTEXT_var (Innotron_Rec_APC_CONTEXT *_p);

    Innotron_Rec_APC_CONTEXT_var (const Innotron_Rec_APC_CONTEXT_var &_s);

    Innotron_Rec_APC_CONTEXT_var &operator= (Innotron_Rec_APC_CONTEXT *_p);

    Innotron_Rec_APC_CONTEXT_var &operator= (const Innotron_Rec_APC_CONTEXT_var &_s);

    ~Innotron_Rec_APC_CONTEXT_var ();

    Innotron_Rec_APC_CONTEXT* operator-> ();

    const Innotron_Rec_APC_CONTEXT& in() const;
    Innotron_Rec_APC_CONTEXT& inout();
    Innotron_Rec_APC_CONTEXT*& out();
    Innotron_Rec_APC_CONTEXT* _retn();

    operator Innotron_Rec_APC_CONTEXT_cvPtr () const;

    operator Innotron_Rec_APC_CONTEXT_vPtr& ();

    operator const Innotron_Rec_APC_CONTEXT& () const;

    operator Innotron_Rec_APC_CONTEXT& ();

    protected:
    Innotron_Rec_APC_CONTEXT *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_Innotron_Rec_APC_CONTEXT;
class  _IDL_SEQ_PARAMSArray_1_var;
class  _IDL_SEQ_PARAMSArray_1 {
    public:
        typedef _IDL_SEQ_PARAMSArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ArrayOfITEM_VALUE *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_PARAMSArray_1 ();
    _IDL_SEQ_PARAMSArray_1 (::CORBA::ULong length, ArrayOfITEM_VALUE* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_PARAMSArray_1 (const _IDL_SEQ_PARAMSArray_1&);


    ~_IDL_SEQ_PARAMSArray_1 ();

    _IDL_SEQ_PARAMSArray_1& operator= (const _IDL_SEQ_PARAMSArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ArrayOfITEM_VALUE& operator [] (::CORBA::ULong indx);
    const ArrayOfITEM_VALUE& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ArrayOfITEM_VALUE* get_buffer (::CORBA::Boolean orphan=0);
    const ArrayOfITEM_VALUE* get_buffer () const;
    void replace (::CORBA::ULong length, ArrayOfITEM_VALUE* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ArrayOfITEM_VALUE* src, ArrayOfITEM_VALUE* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ArrayOfITEM_VALUE* data); 
  public:

    static ArrayOfITEM_VALUE* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ArrayOfITEM_VALUE* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(ArrayOfITEM_VALUE* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_PARAMSArray_1> PARAMSArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_PARAMSArray_1* _IDL_SEQ_PARAMSArray_1_vPtr;
typedef const _IDL_SEQ_PARAMSArray_1* _IDL_SEQ_PARAMSArray_1_cvPtr;

class  _IDL_SEQ_PARAMSArray_1_var
{
    public:

    _IDL_SEQ_PARAMSArray_1_var ();

    _IDL_SEQ_PARAMSArray_1_var (_IDL_SEQ_PARAMSArray_1 *_p);

    _IDL_SEQ_PARAMSArray_1_var (const _IDL_SEQ_PARAMSArray_1_var &_s);

    _IDL_SEQ_PARAMSArray_1_var &operator= (_IDL_SEQ_PARAMSArray_1 *_p);

    _IDL_SEQ_PARAMSArray_1_var &operator= (const _IDL_SEQ_PARAMSArray_1_var &_s);

    ~_IDL_SEQ_PARAMSArray_1_var ();

    _IDL_SEQ_PARAMSArray_1* operator-> ();

    operator _IDL_SEQ_PARAMSArray_1_cvPtr () const;

    operator _IDL_SEQ_PARAMSArray_1_vPtr& ();

    operator _IDL_SEQ_PARAMSArray_1() const;

    const ArrayOfITEM_VALUE& operator[] (::CORBA::ULong index) const;
    ArrayOfITEM_VALUE& operator[] (::CORBA::ULong index);
    const ArrayOfITEM_VALUE& operator[] (int index) const;
    ArrayOfITEM_VALUE& operator[] (int index);
    const _IDL_SEQ_PARAMSArray_1& in() const;
    _IDL_SEQ_PARAMSArray_1& inout();
    _IDL_SEQ_PARAMSArray_1*& out();
    _IDL_SEQ_PARAMSArray_1* _retn();

    protected:
    _IDL_SEQ_PARAMSArray_1 *_ptr;
};

    typedef _IDL_SEQ_PARAMSArray_1 _PARAMSArray_seq;
    typedef _IDL_SEQ_PARAMSArray_1 _PARAMSArray_seq_1;
    typedef _IDL_SEQ_PARAMSArray_1 PARAMSArray;
    typedef _IDL_SEQ_PARAMSArray_1_var PARAMSArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_PARAMSArray;
    class  REC_Reticle_var;
    struct  REC_Reticle {
        typedef REC_Reticle_var _var_type;
       ::RETICLEIDArray RETICLEID;
       ::PARAMSArray PARAMS;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       REC_Reticle();
       REC_Reticle(const REC_Reticle&);
       REC_Reticle& operator=(const REC_Reticle&);
       static CORBA::Info<REC_Reticle> REC_Reticle_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct REC_Reticle


typedef REC_Reticle* REC_Reticle_vPtr;
typedef const REC_Reticle* REC_Reticle_cvPtr;

class  REC_Reticle_var
{
    public:

    REC_Reticle_var ();

    REC_Reticle_var (REC_Reticle *_p);

    REC_Reticle_var (const REC_Reticle_var &_s);

    REC_Reticle_var &operator= (REC_Reticle *_p);

    REC_Reticle_var &operator= (const REC_Reticle_var &_s);

    ~REC_Reticle_var ();

    REC_Reticle* operator-> ();

    const REC_Reticle& in() const;
    REC_Reticle& inout();
    REC_Reticle*& out();
    REC_Reticle* _retn();

    operator REC_Reticle_cvPtr () const;

    operator REC_Reticle_vPtr& ();

    operator const REC_Reticle& () const;

    operator REC_Reticle& ();

    protected:
    REC_Reticle *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_REC_Reticle;
class  _IDL_SEQ_ArrayOfREC_Reticle_0_var;
class  _IDL_SEQ_ArrayOfREC_Reticle_0 {
    public:
        typedef _IDL_SEQ_ArrayOfREC_Reticle_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    REC_Reticle *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_ArrayOfREC_Reticle_0 ();
    _IDL_SEQ_ArrayOfREC_Reticle_0 (::CORBA::ULong max);
    _IDL_SEQ_ArrayOfREC_Reticle_0 (::CORBA::ULong max, ::CORBA::ULong length, REC_Reticle* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_ArrayOfREC_Reticle_0 (const _IDL_SEQ_ArrayOfREC_Reticle_0&);

    ~_IDL_SEQ_ArrayOfREC_Reticle_0 ();

    _IDL_SEQ_ArrayOfREC_Reticle_0& operator= (const _IDL_SEQ_ArrayOfREC_Reticle_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    REC_Reticle& operator [] (::CORBA::ULong indx);
    const REC_Reticle& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    REC_Reticle* get_buffer (::CORBA::Boolean orphan=0);
    const REC_Reticle* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, REC_Reticle* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, REC_Reticle* src, REC_Reticle* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, REC_Reticle* data); 
  public:

    static REC_Reticle* SOMLINK allocbuf(::CORBA::ULong nelems);
    static REC_Reticle* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(REC_Reticle* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_ArrayOfREC_Reticle_0> ArrayOfREC_Reticle_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_ArrayOfREC_Reticle_0* _IDL_SEQ_ArrayOfREC_Reticle_0_vPtr;
typedef const _IDL_SEQ_ArrayOfREC_Reticle_0* _IDL_SEQ_ArrayOfREC_Reticle_0_cvPtr;

class  _IDL_SEQ_ArrayOfREC_Reticle_0_var
{
    public:

    _IDL_SEQ_ArrayOfREC_Reticle_0_var ();

    _IDL_SEQ_ArrayOfREC_Reticle_0_var (_IDL_SEQ_ArrayOfREC_Reticle_0 *_p);

    _IDL_SEQ_ArrayOfREC_Reticle_0_var (const _IDL_SEQ_ArrayOfREC_Reticle_0_var &_s);

    _IDL_SEQ_ArrayOfREC_Reticle_0_var &operator= (_IDL_SEQ_ArrayOfREC_Reticle_0 *_p);

    _IDL_SEQ_ArrayOfREC_Reticle_0_var &operator= (const _IDL_SEQ_ArrayOfREC_Reticle_0_var &_s);

    ~_IDL_SEQ_ArrayOfREC_Reticle_0_var ();

    _IDL_SEQ_ArrayOfREC_Reticle_0* operator-> ();

    operator _IDL_SEQ_ArrayOfREC_Reticle_0_cvPtr () const;

    operator _IDL_SEQ_ArrayOfREC_Reticle_0_vPtr& ();

    operator _IDL_SEQ_ArrayOfREC_Reticle_0() const;

    const REC_Reticle& operator[] (::CORBA::ULong index) const;
    REC_Reticle& operator[] (::CORBA::ULong index);
    const REC_Reticle& operator[] (int index) const;
    REC_Reticle& operator[] (int index);
    const _IDL_SEQ_ArrayOfREC_Reticle_0& in() const;
    _IDL_SEQ_ArrayOfREC_Reticle_0& inout();
    _IDL_SEQ_ArrayOfREC_Reticle_0*& out();
    _IDL_SEQ_ArrayOfREC_Reticle_0* _retn();

    protected:
    _IDL_SEQ_ArrayOfREC_Reticle_0 *_ptr;
};

    typedef _IDL_SEQ_ArrayOfREC_Reticle_0 _ArrayOfREC_Reticle_seq;
    typedef _IDL_SEQ_ArrayOfREC_Reticle_0 _ArrayOfREC_Reticle_seq_1;
    typedef _IDL_SEQ_ArrayOfREC_Reticle_0 ArrayOfREC_Reticle;
    typedef _IDL_SEQ_ArrayOfREC_Reticle_0_var ArrayOfREC_Reticle_var;
    extern  ::CORBA::TypeCode_ptr _tc_ArrayOfREC_Reticle;
class  _IDL_SEQ_WAFERIDArray_1_var;
class  _IDL_SEQ_WAFERIDArray_1 {
    public:
        typedef _IDL_SEQ_WAFERIDArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_WAFERIDArray_1 ();
    _IDL_SEQ_WAFERIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_WAFERIDArray_1 (const _IDL_SEQ_WAFERIDArray_1&);


    ~_IDL_SEQ_WAFERIDArray_1 ();

    _IDL_SEQ_WAFERIDArray_1& operator= (const _IDL_SEQ_WAFERIDArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_WAFERIDArray_1> WAFERIDArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_WAFERIDArray_1* _IDL_SEQ_WAFERIDArray_1_vPtr;
typedef const _IDL_SEQ_WAFERIDArray_1* _IDL_SEQ_WAFERIDArray_1_cvPtr;

class  _IDL_SEQ_WAFERIDArray_1_var
{
    public:

    _IDL_SEQ_WAFERIDArray_1_var ();

    _IDL_SEQ_WAFERIDArray_1_var (_IDL_SEQ_WAFERIDArray_1 *_p);

    _IDL_SEQ_WAFERIDArray_1_var (const _IDL_SEQ_WAFERIDArray_1_var &_s);

    _IDL_SEQ_WAFERIDArray_1_var &operator= (_IDL_SEQ_WAFERIDArray_1 *_p);

    _IDL_SEQ_WAFERIDArray_1_var &operator= (const _IDL_SEQ_WAFERIDArray_1_var &_s);

    ~_IDL_SEQ_WAFERIDArray_1_var ();

    _IDL_SEQ_WAFERIDArray_1* operator-> ();

    operator _IDL_SEQ_WAFERIDArray_1_cvPtr () const;

    operator _IDL_SEQ_WAFERIDArray_1_vPtr& ();

    operator _IDL_SEQ_WAFERIDArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_WAFERIDArray_1& in() const;
    _IDL_SEQ_WAFERIDArray_1& inout();
    _IDL_SEQ_WAFERIDArray_1*& out();
    _IDL_SEQ_WAFERIDArray_1* _retn();

    protected:
    _IDL_SEQ_WAFERIDArray_1 *_ptr;
};

    typedef _IDL_SEQ_WAFERIDArray_1 _WAFERIDArray_seq;
    typedef _IDL_SEQ_WAFERIDArray_1 _WAFERIDArray_seq_1;
    typedef _IDL_SEQ_WAFERIDArray_1 WAFERIDArray;
    typedef _IDL_SEQ_WAFERIDArray_1_var WAFERIDArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_WAFERIDArray;
    class  WAFER_var;
    struct  WAFER {
        typedef WAFER_var _var_type;
       ::CORBA::Long SLOTNO;
       ::WAFERIDArray WAFERID;
       ::CORBA::Long CHUCKID;
       ::CORBA::Long REWORK_CNT;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       WAFER();
       WAFER(const WAFER&);
       WAFER& operator=(const WAFER&);
       static CORBA::Info<WAFER> WAFER_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct WAFER


typedef WAFER* WAFER_vPtr;
typedef const WAFER* WAFER_cvPtr;

class  WAFER_var
{
    public:

    WAFER_var ();

    WAFER_var (WAFER *_p);

    WAFER_var (const WAFER_var &_s);

    WAFER_var &operator= (WAFER *_p);

    WAFER_var &operator= (const WAFER_var &_s);

    ~WAFER_var ();

    WAFER* operator-> ();

    const WAFER& in() const;
    WAFER& inout();
    WAFER*& out();
    WAFER* _retn();

    operator WAFER_cvPtr () const;

    operator WAFER_vPtr& ();

    operator const WAFER& () const;

    operator WAFER& ();

    protected:
    WAFER *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_WAFER;
class  _IDL_SEQ_ArrayOfWAFER_0_var;
class  _IDL_SEQ_ArrayOfWAFER_0 {
    public:
        typedef _IDL_SEQ_ArrayOfWAFER_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    WAFER *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_ArrayOfWAFER_0 ();
    _IDL_SEQ_ArrayOfWAFER_0 (::CORBA::ULong max);
    _IDL_SEQ_ArrayOfWAFER_0 (::CORBA::ULong max, ::CORBA::ULong length, WAFER* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_ArrayOfWAFER_0 (const _IDL_SEQ_ArrayOfWAFER_0&);

    ~_IDL_SEQ_ArrayOfWAFER_0 ();

    _IDL_SEQ_ArrayOfWAFER_0& operator= (const _IDL_SEQ_ArrayOfWAFER_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    WAFER& operator [] (::CORBA::ULong indx);
    const WAFER& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    WAFER* get_buffer (::CORBA::Boolean orphan=0);
    const WAFER* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, WAFER* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, WAFER* src, WAFER* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, WAFER* data); 
  public:

    static WAFER* SOMLINK allocbuf(::CORBA::ULong nelems);
    static WAFER* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(WAFER* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_ArrayOfWAFER_0> ArrayOfWAFER_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_ArrayOfWAFER_0* _IDL_SEQ_ArrayOfWAFER_0_vPtr;
typedef const _IDL_SEQ_ArrayOfWAFER_0* _IDL_SEQ_ArrayOfWAFER_0_cvPtr;

class  _IDL_SEQ_ArrayOfWAFER_0_var
{
    public:

    _IDL_SEQ_ArrayOfWAFER_0_var ();

    _IDL_SEQ_ArrayOfWAFER_0_var (_IDL_SEQ_ArrayOfWAFER_0 *_p);

    _IDL_SEQ_ArrayOfWAFER_0_var (const _IDL_SEQ_ArrayOfWAFER_0_var &_s);

    _IDL_SEQ_ArrayOfWAFER_0_var &operator= (_IDL_SEQ_ArrayOfWAFER_0 *_p);

    _IDL_SEQ_ArrayOfWAFER_0_var &operator= (const _IDL_SEQ_ArrayOfWAFER_0_var &_s);

    ~_IDL_SEQ_ArrayOfWAFER_0_var ();

    _IDL_SEQ_ArrayOfWAFER_0* operator-> ();

    operator _IDL_SEQ_ArrayOfWAFER_0_cvPtr () const;

    operator _IDL_SEQ_ArrayOfWAFER_0_vPtr& ();

    operator _IDL_SEQ_ArrayOfWAFER_0() const;

    const WAFER& operator[] (::CORBA::ULong index) const;
    WAFER& operator[] (::CORBA::ULong index);
    const WAFER& operator[] (int index) const;
    WAFER& operator[] (int index);
    const _IDL_SEQ_ArrayOfWAFER_0& in() const;
    _IDL_SEQ_ArrayOfWAFER_0& inout();
    _IDL_SEQ_ArrayOfWAFER_0*& out();
    _IDL_SEQ_ArrayOfWAFER_0* _retn();

    protected:
    _IDL_SEQ_ArrayOfWAFER_0 *_ptr;
};

    typedef _IDL_SEQ_ArrayOfWAFER_0 _ArrayOfWAFER_seq;
    typedef _IDL_SEQ_ArrayOfWAFER_0 _ArrayOfWAFER_seq_1;
    typedef _IDL_SEQ_ArrayOfWAFER_0 ArrayOfWAFER;
    typedef _IDL_SEQ_ArrayOfWAFER_0_var ArrayOfWAFER_var;
    extern  ::CORBA::TypeCode_ptr _tc_ArrayOfWAFER;
class  _IDL_SEQ_WAFERSArray_1_var;
class  _IDL_SEQ_WAFERSArray_1 {
    public:
        typedef _IDL_SEQ_WAFERSArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ArrayOfWAFER *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_WAFERSArray_1 ();
    _IDL_SEQ_WAFERSArray_1 (::CORBA::ULong length, ArrayOfWAFER* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_WAFERSArray_1 (const _IDL_SEQ_WAFERSArray_1&);


    ~_IDL_SEQ_WAFERSArray_1 ();

    _IDL_SEQ_WAFERSArray_1& operator= (const _IDL_SEQ_WAFERSArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ArrayOfWAFER& operator [] (::CORBA::ULong indx);
    const ArrayOfWAFER& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ArrayOfWAFER* get_buffer (::CORBA::Boolean orphan=0);
    const ArrayOfWAFER* get_buffer () const;
    void replace (::CORBA::ULong length, ArrayOfWAFER* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ArrayOfWAFER* src, ArrayOfWAFER* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ArrayOfWAFER* data); 
  public:

    static ArrayOfWAFER* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ArrayOfWAFER* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(ArrayOfWAFER* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_WAFERSArray_1> WAFERSArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_WAFERSArray_1* _IDL_SEQ_WAFERSArray_1_vPtr;
typedef const _IDL_SEQ_WAFERSArray_1* _IDL_SEQ_WAFERSArray_1_cvPtr;

class  _IDL_SEQ_WAFERSArray_1_var
{
    public:

    _IDL_SEQ_WAFERSArray_1_var ();

    _IDL_SEQ_WAFERSArray_1_var (_IDL_SEQ_WAFERSArray_1 *_p);

    _IDL_SEQ_WAFERSArray_1_var (const _IDL_SEQ_WAFERSArray_1_var &_s);

    _IDL_SEQ_WAFERSArray_1_var &operator= (_IDL_SEQ_WAFERSArray_1 *_p);

    _IDL_SEQ_WAFERSArray_1_var &operator= (const _IDL_SEQ_WAFERSArray_1_var &_s);

    ~_IDL_SEQ_WAFERSArray_1_var ();

    _IDL_SEQ_WAFERSArray_1* operator-> ();

    operator _IDL_SEQ_WAFERSArray_1_cvPtr () const;

    operator _IDL_SEQ_WAFERSArray_1_vPtr& ();

    operator _IDL_SEQ_WAFERSArray_1() const;

    const ArrayOfWAFER& operator[] (::CORBA::ULong index) const;
    ArrayOfWAFER& operator[] (::CORBA::ULong index);
    const ArrayOfWAFER& operator[] (int index) const;
    ArrayOfWAFER& operator[] (int index);
    const _IDL_SEQ_WAFERSArray_1& in() const;
    _IDL_SEQ_WAFERSArray_1& inout();
    _IDL_SEQ_WAFERSArray_1*& out();
    _IDL_SEQ_WAFERSArray_1* _retn();

    protected:
    _IDL_SEQ_WAFERSArray_1 *_ptr;
};

    typedef _IDL_SEQ_WAFERSArray_1 _WAFERSArray_seq;
    typedef _IDL_SEQ_WAFERSArray_1 _WAFERSArray_seq_1;
    typedef _IDL_SEQ_WAFERSArray_1 WAFERSArray;
    typedef _IDL_SEQ_WAFERSArray_1_var WAFERSArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_WAFERSArray;
    class  LOT_var;
    struct  LOT {
        typedef LOT_var _var_type;
       ::CORBA::Long LOTID;
       ::WAFERSArray WAFERS;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       LOT();
       LOT(const LOT&);
       LOT& operator=(const LOT&);
       static CORBA::Info<LOT> LOT_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct LOT


typedef LOT* LOT_vPtr;
typedef const LOT* LOT_cvPtr;

class  LOT_var
{
    public:

    LOT_var ();

    LOT_var (LOT *_p);

    LOT_var (const LOT_var &_s);

    LOT_var &operator= (LOT *_p);

    LOT_var &operator= (const LOT_var &_s);

    ~LOT_var ();

    LOT* operator-> ();

    const LOT& in() const;
    LOT& inout();
    LOT*& out();
    LOT* _retn();

    operator LOT_cvPtr () const;

    operator LOT_vPtr& ();

    operator const LOT& () const;

    operator LOT& ();

    protected:
    LOT *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_LOT;
class  _IDL_SEQ_USED_TRANSACTIONIDArray_1_var;
class  _IDL_SEQ_USED_TRANSACTIONIDArray_1 {
    public:
        typedef _IDL_SEQ_USED_TRANSACTIONIDArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_USED_TRANSACTIONIDArray_1 ();
    _IDL_SEQ_USED_TRANSACTIONIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_USED_TRANSACTIONIDArray_1 (const _IDL_SEQ_USED_TRANSACTIONIDArray_1&);


    ~_IDL_SEQ_USED_TRANSACTIONIDArray_1 ();

    _IDL_SEQ_USED_TRANSACTIONIDArray_1& operator= (const _IDL_SEQ_USED_TRANSACTIONIDArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_USED_TRANSACTIONIDArray_1> USED_TRANSACTIONIDArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_USED_TRANSACTIONIDArray_1* _IDL_SEQ_USED_TRANSACTIONIDArray_1_vPtr;
typedef const _IDL_SEQ_USED_TRANSACTIONIDArray_1* _IDL_SEQ_USED_TRANSACTIONIDArray_1_cvPtr;

class  _IDL_SEQ_USED_TRANSACTIONIDArray_1_var
{
    public:

    _IDL_SEQ_USED_TRANSACTIONIDArray_1_var ();

    _IDL_SEQ_USED_TRANSACTIONIDArray_1_var (_IDL_SEQ_USED_TRANSACTIONIDArray_1 *_p);

    _IDL_SEQ_USED_TRANSACTIONIDArray_1_var (const _IDL_SEQ_USED_TRANSACTIONIDArray_1_var &_s);

    _IDL_SEQ_USED_TRANSACTIONIDArray_1_var &operator= (_IDL_SEQ_USED_TRANSACTIONIDArray_1 *_p);

    _IDL_SEQ_USED_TRANSACTIONIDArray_1_var &operator= (const _IDL_SEQ_USED_TRANSACTIONIDArray_1_var &_s);

    ~_IDL_SEQ_USED_TRANSACTIONIDArray_1_var ();

    _IDL_SEQ_USED_TRANSACTIONIDArray_1* operator-> ();

    operator _IDL_SEQ_USED_TRANSACTIONIDArray_1_cvPtr () const;

    operator _IDL_SEQ_USED_TRANSACTIONIDArray_1_vPtr& ();

    operator _IDL_SEQ_USED_TRANSACTIONIDArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_USED_TRANSACTIONIDArray_1& in() const;
    _IDL_SEQ_USED_TRANSACTIONIDArray_1& inout();
    _IDL_SEQ_USED_TRANSACTIONIDArray_1*& out();
    _IDL_SEQ_USED_TRANSACTIONIDArray_1* _retn();

    protected:
    _IDL_SEQ_USED_TRANSACTIONIDArray_1 *_ptr;
};

    typedef _IDL_SEQ_USED_TRANSACTIONIDArray_1 _USED_TRANSACTIONIDArray_seq;
    typedef _IDL_SEQ_USED_TRANSACTIONIDArray_1 _USED_TRANSACTIONIDArray_seq_1;
    typedef _IDL_SEQ_USED_TRANSACTIONIDArray_1 USED_TRANSACTIONIDArray;
    typedef _IDL_SEQ_USED_TRANSACTIONIDArray_1_var USED_TRANSACTIONIDArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_USED_TRANSACTIONIDArray;
class  _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var;
class  _IDL_SEQ_METROLOGYEQUIPTYPEArray_1 {
    public:
        typedef _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_METROLOGYEQUIPTYPEArray_1 ();
    _IDL_SEQ_METROLOGYEQUIPTYPEArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_METROLOGYEQUIPTYPEArray_1 (const _IDL_SEQ_METROLOGYEQUIPTYPEArray_1&);


    ~_IDL_SEQ_METROLOGYEQUIPTYPEArray_1 ();

    _IDL_SEQ_METROLOGYEQUIPTYPEArray_1& operator= (const _IDL_SEQ_METROLOGYEQUIPTYPEArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_METROLOGYEQUIPTYPEArray_1> METROLOGYEQUIPTYPEArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_METROLOGYEQUIPTYPEArray_1* _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_vPtr;
typedef const _IDL_SEQ_METROLOGYEQUIPTYPEArray_1* _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_cvPtr;

class  _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var
{
    public:

    _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var ();

    _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var (_IDL_SEQ_METROLOGYEQUIPTYPEArray_1 *_p);

    _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var (const _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var &_s);

    _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var &operator= (_IDL_SEQ_METROLOGYEQUIPTYPEArray_1 *_p);

    _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var &operator= (const _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var &_s);

    ~_IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var ();

    _IDL_SEQ_METROLOGYEQUIPTYPEArray_1* operator-> ();

    operator _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_cvPtr () const;

    operator _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_vPtr& ();

    operator _IDL_SEQ_METROLOGYEQUIPTYPEArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_METROLOGYEQUIPTYPEArray_1& in() const;
    _IDL_SEQ_METROLOGYEQUIPTYPEArray_1& inout();
    _IDL_SEQ_METROLOGYEQUIPTYPEArray_1*& out();
    _IDL_SEQ_METROLOGYEQUIPTYPEArray_1* _retn();

    protected:
    _IDL_SEQ_METROLOGYEQUIPTYPEArray_1 *_ptr;
};

    typedef _IDL_SEQ_METROLOGYEQUIPTYPEArray_1 _METROLOGYEQUIPTYPEArray_seq;
    typedef _IDL_SEQ_METROLOGYEQUIPTYPEArray_1 _METROLOGYEQUIPTYPEArray_seq_1;
    typedef _IDL_SEQ_METROLOGYEQUIPTYPEArray_1 METROLOGYEQUIPTYPEArray;
    typedef _IDL_SEQ_METROLOGYEQUIPTYPEArray_1_var METROLOGYEQUIPTYPEArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_METROLOGYEQUIPTYPEArray;
class  _IDL_SEQ_METROLOGYEQUIPIDArray_1_var;
class  _IDL_SEQ_METROLOGYEQUIPIDArray_1 {
    public:
        typedef _IDL_SEQ_METROLOGYEQUIPIDArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_METROLOGYEQUIPIDArray_1 ();
    _IDL_SEQ_METROLOGYEQUIPIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_METROLOGYEQUIPIDArray_1 (const _IDL_SEQ_METROLOGYEQUIPIDArray_1&);


    ~_IDL_SEQ_METROLOGYEQUIPIDArray_1 ();

    _IDL_SEQ_METROLOGYEQUIPIDArray_1& operator= (const _IDL_SEQ_METROLOGYEQUIPIDArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_METROLOGYEQUIPIDArray_1> METROLOGYEQUIPIDArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_METROLOGYEQUIPIDArray_1* _IDL_SEQ_METROLOGYEQUIPIDArray_1_vPtr;
typedef const _IDL_SEQ_METROLOGYEQUIPIDArray_1* _IDL_SEQ_METROLOGYEQUIPIDArray_1_cvPtr;

class  _IDL_SEQ_METROLOGYEQUIPIDArray_1_var
{
    public:

    _IDL_SEQ_METROLOGYEQUIPIDArray_1_var ();

    _IDL_SEQ_METROLOGYEQUIPIDArray_1_var (_IDL_SEQ_METROLOGYEQUIPIDArray_1 *_p);

    _IDL_SEQ_METROLOGYEQUIPIDArray_1_var (const _IDL_SEQ_METROLOGYEQUIPIDArray_1_var &_s);

    _IDL_SEQ_METROLOGYEQUIPIDArray_1_var &operator= (_IDL_SEQ_METROLOGYEQUIPIDArray_1 *_p);

    _IDL_SEQ_METROLOGYEQUIPIDArray_1_var &operator= (const _IDL_SEQ_METROLOGYEQUIPIDArray_1_var &_s);

    ~_IDL_SEQ_METROLOGYEQUIPIDArray_1_var ();

    _IDL_SEQ_METROLOGYEQUIPIDArray_1* operator-> ();

    operator _IDL_SEQ_METROLOGYEQUIPIDArray_1_cvPtr () const;

    operator _IDL_SEQ_METROLOGYEQUIPIDArray_1_vPtr& ();

    operator _IDL_SEQ_METROLOGYEQUIPIDArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_METROLOGYEQUIPIDArray_1& in() const;
    _IDL_SEQ_METROLOGYEQUIPIDArray_1& inout();
    _IDL_SEQ_METROLOGYEQUIPIDArray_1*& out();
    _IDL_SEQ_METROLOGYEQUIPIDArray_1* _retn();

    protected:
    _IDL_SEQ_METROLOGYEQUIPIDArray_1 *_ptr;
};

    typedef _IDL_SEQ_METROLOGYEQUIPIDArray_1 _METROLOGYEQUIPIDArray_seq;
    typedef _IDL_SEQ_METROLOGYEQUIPIDArray_1 _METROLOGYEQUIPIDArray_seq_1;
    typedef _IDL_SEQ_METROLOGYEQUIPIDArray_1 METROLOGYEQUIPIDArray;
    typedef _IDL_SEQ_METROLOGYEQUIPIDArray_1_var METROLOGYEQUIPIDArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_METROLOGYEQUIPIDArray;
    class  Innotron_Met_APC_CONTEXT_var;
    struct  Innotron_Met_APC_CONTEXT {
        typedef Innotron_Met_APC_CONTEXT_var _var_type;
       ::CONTROLJOBTYPEArray CONTROLJOBTYPE;
       ::TRANSACTIONIDArray TRANSACTIONID;
       ::USED_TRANSACTIONIDArray USED_TRANSACTIONID;
       ::LOTIDArray LOTID;
       ::PARTIDArray PARTID;
       ::LAYERArray LAYER;
       ::ROUTEArray ROUTE;
       ::ROUTEGROUPArray ROUTEGROUP;
       ::OPERATIONArray OPERATION;
       ::RETICLEIDArray RETICLEID;
       ::METROLOGYEQUIPTYPEArray METROLOGYEQUIPTYPE;
       ::METROLOGYEQUIPIDArray METROLOGYEQUIPID;
       ::PROCESSEQUIPTYPEArray PROCESSEQUIPTYPE;
       ::PROCESSEQUIPIDArray PROCESSEQUIPID;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       Innotron_Met_APC_CONTEXT();
       Innotron_Met_APC_CONTEXT(const Innotron_Met_APC_CONTEXT&);
       Innotron_Met_APC_CONTEXT& operator=(const Innotron_Met_APC_CONTEXT&);
       static CORBA::Info<Innotron_Met_APC_CONTEXT> Innotron_Met_APC_CONTEXT_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct Innotron_Met_APC_CONTEXT


typedef Innotron_Met_APC_CONTEXT* Innotron_Met_APC_CONTEXT_vPtr;
typedef const Innotron_Met_APC_CONTEXT* Innotron_Met_APC_CONTEXT_cvPtr;

class  Innotron_Met_APC_CONTEXT_var
{
    public:

    Innotron_Met_APC_CONTEXT_var ();

    Innotron_Met_APC_CONTEXT_var (Innotron_Met_APC_CONTEXT *_p);

    Innotron_Met_APC_CONTEXT_var (const Innotron_Met_APC_CONTEXT_var &_s);

    Innotron_Met_APC_CONTEXT_var &operator= (Innotron_Met_APC_CONTEXT *_p);

    Innotron_Met_APC_CONTEXT_var &operator= (const Innotron_Met_APC_CONTEXT_var &_s);

    ~Innotron_Met_APC_CONTEXT_var ();

    Innotron_Met_APC_CONTEXT* operator-> ();

    const Innotron_Met_APC_CONTEXT& in() const;
    Innotron_Met_APC_CONTEXT& inout();
    Innotron_Met_APC_CONTEXT*& out();
    Innotron_Met_APC_CONTEXT* _retn();

    operator Innotron_Met_APC_CONTEXT_cvPtr () const;

    operator Innotron_Met_APC_CONTEXT_vPtr& ();

    operator const Innotron_Met_APC_CONTEXT& () const;

    operator Innotron_Met_APC_CONTEXT& ();

    protected:
    Innotron_Met_APC_CONTEXT *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_Innotron_Met_APC_CONTEXT;
class  _IDL_SEQ_WAFERLISTArray_1_var;
class  _IDL_SEQ_WAFERLISTArray_1 {
    public:
        typedef _IDL_SEQ_WAFERLISTArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_WAFERLISTArray_1 ();
    _IDL_SEQ_WAFERLISTArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_WAFERLISTArray_1 (const _IDL_SEQ_WAFERLISTArray_1&);


    ~_IDL_SEQ_WAFERLISTArray_1 ();

    _IDL_SEQ_WAFERLISTArray_1& operator= (const _IDL_SEQ_WAFERLISTArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_WAFERLISTArray_1> WAFERLISTArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_WAFERLISTArray_1* _IDL_SEQ_WAFERLISTArray_1_vPtr;
typedef const _IDL_SEQ_WAFERLISTArray_1* _IDL_SEQ_WAFERLISTArray_1_cvPtr;

class  _IDL_SEQ_WAFERLISTArray_1_var
{
    public:

    _IDL_SEQ_WAFERLISTArray_1_var ();

    _IDL_SEQ_WAFERLISTArray_1_var (_IDL_SEQ_WAFERLISTArray_1 *_p);

    _IDL_SEQ_WAFERLISTArray_1_var (const _IDL_SEQ_WAFERLISTArray_1_var &_s);

    _IDL_SEQ_WAFERLISTArray_1_var &operator= (_IDL_SEQ_WAFERLISTArray_1 *_p);

    _IDL_SEQ_WAFERLISTArray_1_var &operator= (const _IDL_SEQ_WAFERLISTArray_1_var &_s);

    ~_IDL_SEQ_WAFERLISTArray_1_var ();

    _IDL_SEQ_WAFERLISTArray_1* operator-> ();

    operator _IDL_SEQ_WAFERLISTArray_1_cvPtr () const;

    operator _IDL_SEQ_WAFERLISTArray_1_vPtr& ();

    operator _IDL_SEQ_WAFERLISTArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_WAFERLISTArray_1& in() const;
    _IDL_SEQ_WAFERLISTArray_1& inout();
    _IDL_SEQ_WAFERLISTArray_1*& out();
    _IDL_SEQ_WAFERLISTArray_1* _retn();

    protected:
    _IDL_SEQ_WAFERLISTArray_1 *_ptr;
};

    typedef _IDL_SEQ_WAFERLISTArray_1 _WAFERLISTArray_seq;
    typedef _IDL_SEQ_WAFERLISTArray_1 _WAFERLISTArray_seq_1;
    typedef _IDL_SEQ_WAFERLISTArray_1 WAFERLISTArray;
    typedef _IDL_SEQ_WAFERLISTArray_1_var WAFERLISTArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_WAFERLISTArray;
class  _IDL_SEQ_DCITEMSArray_1_var;
class  _IDL_SEQ_DCITEMSArray_1 {
    public:
        typedef _IDL_SEQ_DCITEMSArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ArrayOfITEM_VALUE *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_DCITEMSArray_1 ();
    _IDL_SEQ_DCITEMSArray_1 (::CORBA::ULong length, ArrayOfITEM_VALUE* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_DCITEMSArray_1 (const _IDL_SEQ_DCITEMSArray_1&);


    ~_IDL_SEQ_DCITEMSArray_1 ();

    _IDL_SEQ_DCITEMSArray_1& operator= (const _IDL_SEQ_DCITEMSArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ArrayOfITEM_VALUE& operator [] (::CORBA::ULong indx);
    const ArrayOfITEM_VALUE& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ArrayOfITEM_VALUE* get_buffer (::CORBA::Boolean orphan=0);
    const ArrayOfITEM_VALUE* get_buffer () const;
    void replace (::CORBA::ULong length, ArrayOfITEM_VALUE* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ArrayOfITEM_VALUE* src, ArrayOfITEM_VALUE* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ArrayOfITEM_VALUE* data); 
  public:

    static ArrayOfITEM_VALUE* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ArrayOfITEM_VALUE* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(ArrayOfITEM_VALUE* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_DCITEMSArray_1> DCITEMSArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_DCITEMSArray_1* _IDL_SEQ_DCITEMSArray_1_vPtr;
typedef const _IDL_SEQ_DCITEMSArray_1* _IDL_SEQ_DCITEMSArray_1_cvPtr;

class  _IDL_SEQ_DCITEMSArray_1_var
{
    public:

    _IDL_SEQ_DCITEMSArray_1_var ();

    _IDL_SEQ_DCITEMSArray_1_var (_IDL_SEQ_DCITEMSArray_1 *_p);

    _IDL_SEQ_DCITEMSArray_1_var (const _IDL_SEQ_DCITEMSArray_1_var &_s);

    _IDL_SEQ_DCITEMSArray_1_var &operator= (_IDL_SEQ_DCITEMSArray_1 *_p);

    _IDL_SEQ_DCITEMSArray_1_var &operator= (const _IDL_SEQ_DCITEMSArray_1_var &_s);

    ~_IDL_SEQ_DCITEMSArray_1_var ();

    _IDL_SEQ_DCITEMSArray_1* operator-> ();

    operator _IDL_SEQ_DCITEMSArray_1_cvPtr () const;

    operator _IDL_SEQ_DCITEMSArray_1_vPtr& ();

    operator _IDL_SEQ_DCITEMSArray_1() const;

    const ArrayOfITEM_VALUE& operator[] (::CORBA::ULong index) const;
    ArrayOfITEM_VALUE& operator[] (::CORBA::ULong index);
    const ArrayOfITEM_VALUE& operator[] (int index) const;
    ArrayOfITEM_VALUE& operator[] (int index);
    const _IDL_SEQ_DCITEMSArray_1& in() const;
    _IDL_SEQ_DCITEMSArray_1& inout();
    _IDL_SEQ_DCITEMSArray_1*& out();
    _IDL_SEQ_DCITEMSArray_1* _retn();

    protected:
    _IDL_SEQ_DCITEMSArray_1 *_ptr;
};

    typedef _IDL_SEQ_DCITEMSArray_1 _DCITEMSArray_seq;
    typedef _IDL_SEQ_DCITEMSArray_1 _DCITEMSArray_seq_1;
    typedef _IDL_SEQ_DCITEMSArray_1 DCITEMSArray;
    typedef _IDL_SEQ_DCITEMSArray_1_var DCITEMSArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_DCITEMSArray;
    class  Met_Reticle_var;
    struct  Met_Reticle {
        typedef Met_Reticle_var _var_type;
       ::RETICLEIDArray RETICLEID;
       ::WAFERLISTArray WAFERLIST;
       ::DCITEMSArray DCITEMS;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       Met_Reticle();
       Met_Reticle(const Met_Reticle&);
       Met_Reticle& operator=(const Met_Reticle&);
       static CORBA::Info<Met_Reticle> Met_Reticle_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct Met_Reticle


typedef Met_Reticle* Met_Reticle_vPtr;
typedef const Met_Reticle* Met_Reticle_cvPtr;

class  Met_Reticle_var
{
    public:

    Met_Reticle_var ();

    Met_Reticle_var (Met_Reticle *_p);

    Met_Reticle_var (const Met_Reticle_var &_s);

    Met_Reticle_var &operator= (Met_Reticle *_p);

    Met_Reticle_var &operator= (const Met_Reticle_var &_s);

    ~Met_Reticle_var ();

    Met_Reticle* operator-> ();

    const Met_Reticle& in() const;
    Met_Reticle& inout();
    Met_Reticle*& out();
    Met_Reticle* _retn();

    operator Met_Reticle_cvPtr () const;

    operator Met_Reticle_vPtr& ();

    operator const Met_Reticle& () const;

    operator Met_Reticle& ();

    protected:
    Met_Reticle *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_Met_Reticle;
class  _IDL_SEQ_ArrayOfMet_Reticle_0_var;
class  _IDL_SEQ_ArrayOfMet_Reticle_0 {
    public:
        typedef _IDL_SEQ_ArrayOfMet_Reticle_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    Met_Reticle *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_ArrayOfMet_Reticle_0 ();
    _IDL_SEQ_ArrayOfMet_Reticle_0 (::CORBA::ULong max);
    _IDL_SEQ_ArrayOfMet_Reticle_0 (::CORBA::ULong max, ::CORBA::ULong length, Met_Reticle* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_ArrayOfMet_Reticle_0 (const _IDL_SEQ_ArrayOfMet_Reticle_0&);

    ~_IDL_SEQ_ArrayOfMet_Reticle_0 ();

    _IDL_SEQ_ArrayOfMet_Reticle_0& operator= (const _IDL_SEQ_ArrayOfMet_Reticle_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    Met_Reticle& operator [] (::CORBA::ULong indx);
    const Met_Reticle& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    Met_Reticle* get_buffer (::CORBA::Boolean orphan=0);
    const Met_Reticle* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, Met_Reticle* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, Met_Reticle* src, Met_Reticle* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, Met_Reticle* data); 
  public:

    static Met_Reticle* SOMLINK allocbuf(::CORBA::ULong nelems);
    static Met_Reticle* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(Met_Reticle* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_ArrayOfMet_Reticle_0> ArrayOfMet_Reticle_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_ArrayOfMet_Reticle_0* _IDL_SEQ_ArrayOfMet_Reticle_0_vPtr;
typedef const _IDL_SEQ_ArrayOfMet_Reticle_0* _IDL_SEQ_ArrayOfMet_Reticle_0_cvPtr;

class  _IDL_SEQ_ArrayOfMet_Reticle_0_var
{
    public:

    _IDL_SEQ_ArrayOfMet_Reticle_0_var ();

    _IDL_SEQ_ArrayOfMet_Reticle_0_var (_IDL_SEQ_ArrayOfMet_Reticle_0 *_p);

    _IDL_SEQ_ArrayOfMet_Reticle_0_var (const _IDL_SEQ_ArrayOfMet_Reticle_0_var &_s);

    _IDL_SEQ_ArrayOfMet_Reticle_0_var &operator= (_IDL_SEQ_ArrayOfMet_Reticle_0 *_p);

    _IDL_SEQ_ArrayOfMet_Reticle_0_var &operator= (const _IDL_SEQ_ArrayOfMet_Reticle_0_var &_s);

    ~_IDL_SEQ_ArrayOfMet_Reticle_0_var ();

    _IDL_SEQ_ArrayOfMet_Reticle_0* operator-> ();

    operator _IDL_SEQ_ArrayOfMet_Reticle_0_cvPtr () const;

    operator _IDL_SEQ_ArrayOfMet_Reticle_0_vPtr& ();

    operator _IDL_SEQ_ArrayOfMet_Reticle_0() const;

    const Met_Reticle& operator[] (::CORBA::ULong index) const;
    Met_Reticle& operator[] (::CORBA::ULong index);
    const Met_Reticle& operator[] (int index) const;
    Met_Reticle& operator[] (int index);
    const _IDL_SEQ_ArrayOfMet_Reticle_0& in() const;
    _IDL_SEQ_ArrayOfMet_Reticle_0& inout();
    _IDL_SEQ_ArrayOfMet_Reticle_0*& out();
    _IDL_SEQ_ArrayOfMet_Reticle_0* _retn();

    protected:
    _IDL_SEQ_ArrayOfMet_Reticle_0 *_ptr;
};

    typedef _IDL_SEQ_ArrayOfMet_Reticle_0 _ArrayOfMet_Reticle_seq;
    typedef _IDL_SEQ_ArrayOfMet_Reticle_0 _ArrayOfMet_Reticle_seq_1;
    typedef _IDL_SEQ_ArrayOfMet_Reticle_0 ArrayOfMet_Reticle;
    typedef _IDL_SEQ_ArrayOfMet_Reticle_0_var ArrayOfMet_Reticle_var;
    extern  ::CORBA::TypeCode_ptr _tc_ArrayOfMet_Reticle;
class  _IDL_SEQ_RETICLESArray_1_var;
class  _IDL_SEQ_RETICLESArray_1 {
    public:
        typedef _IDL_SEQ_RETICLESArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ArrayOfMet_Reticle *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_RETICLESArray_1 ();
    _IDL_SEQ_RETICLESArray_1 (::CORBA::ULong length, ArrayOfMet_Reticle* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_RETICLESArray_1 (const _IDL_SEQ_RETICLESArray_1&);


    ~_IDL_SEQ_RETICLESArray_1 ();

    _IDL_SEQ_RETICLESArray_1& operator= (const _IDL_SEQ_RETICLESArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ArrayOfMet_Reticle& operator [] (::CORBA::ULong indx);
    const ArrayOfMet_Reticle& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ArrayOfMet_Reticle* get_buffer (::CORBA::Boolean orphan=0);
    const ArrayOfMet_Reticle* get_buffer () const;
    void replace (::CORBA::ULong length, ArrayOfMet_Reticle* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ArrayOfMet_Reticle* src, ArrayOfMet_Reticle* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ArrayOfMet_Reticle* data); 
  public:

    static ArrayOfMet_Reticle* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ArrayOfMet_Reticle* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(ArrayOfMet_Reticle* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_RETICLESArray_1> RETICLESArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_RETICLESArray_1* _IDL_SEQ_RETICLESArray_1_vPtr;
typedef const _IDL_SEQ_RETICLESArray_1* _IDL_SEQ_RETICLESArray_1_cvPtr;

class  _IDL_SEQ_RETICLESArray_1_var
{
    public:

    _IDL_SEQ_RETICLESArray_1_var ();

    _IDL_SEQ_RETICLESArray_1_var (_IDL_SEQ_RETICLESArray_1 *_p);

    _IDL_SEQ_RETICLESArray_1_var (const _IDL_SEQ_RETICLESArray_1_var &_s);

    _IDL_SEQ_RETICLESArray_1_var &operator= (_IDL_SEQ_RETICLESArray_1 *_p);

    _IDL_SEQ_RETICLESArray_1_var &operator= (const _IDL_SEQ_RETICLESArray_1_var &_s);

    ~_IDL_SEQ_RETICLESArray_1_var ();

    _IDL_SEQ_RETICLESArray_1* operator-> ();

    operator _IDL_SEQ_RETICLESArray_1_cvPtr () const;

    operator _IDL_SEQ_RETICLESArray_1_vPtr& ();

    operator _IDL_SEQ_RETICLESArray_1() const;

    const ArrayOfMet_Reticle& operator[] (::CORBA::ULong index) const;
    ArrayOfMet_Reticle& operator[] (::CORBA::ULong index);
    const ArrayOfMet_Reticle& operator[] (int index) const;
    ArrayOfMet_Reticle& operator[] (int index);
    const _IDL_SEQ_RETICLESArray_1& in() const;
    _IDL_SEQ_RETICLESArray_1& inout();
    _IDL_SEQ_RETICLESArray_1*& out();
    _IDL_SEQ_RETICLESArray_1* _retn();

    protected:
    _IDL_SEQ_RETICLESArray_1 *_ptr;
};

    typedef _IDL_SEQ_RETICLESArray_1 _RETICLESArray_seq;
    typedef _IDL_SEQ_RETICLESArray_1 _RETICLESArray_seq_1;
    typedef _IDL_SEQ_RETICLESArray_1 RETICLESArray;
    typedef _IDL_SEQ_RETICLESArray_1_var RETICLESArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_RETICLESArray;
    class  Innotron_Met_Request_var;
    struct  Innotron_Met_Request {
        typedef Innotron_Met_Request_var _var_type;
       ::Innotron_Met_APC_CONTEXT APC_CONTEXT;
       ::RETICLESArray RETICLES;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       Innotron_Met_Request();
       Innotron_Met_Request(const Innotron_Met_Request&);
       Innotron_Met_Request& operator=(const Innotron_Met_Request&);
       static CORBA::Info<Innotron_Met_Request> Innotron_Met_Request_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct Innotron_Met_Request


typedef Innotron_Met_Request* Innotron_Met_Request_vPtr;
typedef const Innotron_Met_Request* Innotron_Met_Request_cvPtr;

class  Innotron_Met_Request_var
{
    public:

    Innotron_Met_Request_var ();

    Innotron_Met_Request_var (Innotron_Met_Request *_p);

    Innotron_Met_Request_var (const Innotron_Met_Request_var &_s);

    Innotron_Met_Request_var &operator= (Innotron_Met_Request *_p);

    Innotron_Met_Request_var &operator= (const Innotron_Met_Request_var &_s);

    ~Innotron_Met_Request_var ();

    Innotron_Met_Request* operator-> ();

    const Innotron_Met_Request& in() const;
    Innotron_Met_Request& inout();
    Innotron_Met_Request*& out();
    Innotron_Met_Request* _retn();

    operator Innotron_Met_Request_cvPtr () const;

    operator Innotron_Met_Request_vPtr& ();

    operator const Innotron_Met_Request& () const;

    operator Innotron_Met_Request& ();

    protected:
    Innotron_Met_Request *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_Innotron_Met_Request;
class  _IDL_SEQ_ArrayOfLOT_0_var;
class  _IDL_SEQ_ArrayOfLOT_0 {
    public:
        typedef _IDL_SEQ_ArrayOfLOT_0_var _var_type;
    protected:
    ::CORBA::ULong _maximum;
    ::CORBA::ULong _length;
    LOT *_buffer;
    unsigned char _release;

    public:
    _IDL_SEQ_ArrayOfLOT_0 ();
    _IDL_SEQ_ArrayOfLOT_0 (::CORBA::ULong max);
    _IDL_SEQ_ArrayOfLOT_0 (::CORBA::ULong max, ::CORBA::ULong length, LOT* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_ArrayOfLOT_0 (const _IDL_SEQ_ArrayOfLOT_0&);

    ~_IDL_SEQ_ArrayOfLOT_0 ();

    _IDL_SEQ_ArrayOfLOT_0& operator= (const _IDL_SEQ_ArrayOfLOT_0&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    LOT& operator [] (::CORBA::ULong indx);
    const LOT& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    LOT* get_buffer (::CORBA::Boolean orphan=0);
    const LOT* get_buffer () const;
    void replace (::CORBA::ULong max, ::CORBA::ULong length, LOT* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, LOT* src, LOT* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, LOT* data); 
  public:

    static LOT* SOMLINK allocbuf(::CORBA::ULong nelems);
    static LOT* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(LOT* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_ArrayOfLOT_0> ArrayOfLOT_0_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_ArrayOfLOT_0* _IDL_SEQ_ArrayOfLOT_0_vPtr;
typedef const _IDL_SEQ_ArrayOfLOT_0* _IDL_SEQ_ArrayOfLOT_0_cvPtr;

class  _IDL_SEQ_ArrayOfLOT_0_var
{
    public:

    _IDL_SEQ_ArrayOfLOT_0_var ();

    _IDL_SEQ_ArrayOfLOT_0_var (_IDL_SEQ_ArrayOfLOT_0 *_p);

    _IDL_SEQ_ArrayOfLOT_0_var (const _IDL_SEQ_ArrayOfLOT_0_var &_s);

    _IDL_SEQ_ArrayOfLOT_0_var &operator= (_IDL_SEQ_ArrayOfLOT_0 *_p);

    _IDL_SEQ_ArrayOfLOT_0_var &operator= (const _IDL_SEQ_ArrayOfLOT_0_var &_s);

    ~_IDL_SEQ_ArrayOfLOT_0_var ();

    _IDL_SEQ_ArrayOfLOT_0* operator-> ();

    operator _IDL_SEQ_ArrayOfLOT_0_cvPtr () const;

    operator _IDL_SEQ_ArrayOfLOT_0_vPtr& ();

    operator _IDL_SEQ_ArrayOfLOT_0() const;

    const LOT& operator[] (::CORBA::ULong index) const;
    LOT& operator[] (::CORBA::ULong index);
    const LOT& operator[] (int index) const;
    LOT& operator[] (int index);
    const _IDL_SEQ_ArrayOfLOT_0& in() const;
    _IDL_SEQ_ArrayOfLOT_0& inout();
    _IDL_SEQ_ArrayOfLOT_0*& out();
    _IDL_SEQ_ArrayOfLOT_0* _retn();

    protected:
    _IDL_SEQ_ArrayOfLOT_0 *_ptr;
};

    typedef _IDL_SEQ_ArrayOfLOT_0 _ArrayOfLOT_seq;
    typedef _IDL_SEQ_ArrayOfLOT_0 _ArrayOfLOT_seq_1;
    typedef _IDL_SEQ_ArrayOfLOT_0 ArrayOfLOT;
    typedef _IDL_SEQ_ArrayOfLOT_0_var ArrayOfLOT_var;
    extern  ::CORBA::TypeCode_ptr _tc_ArrayOfLOT;
class  _IDL_SEQ_LOT_DATAArray_1_var;
class  _IDL_SEQ_LOT_DATAArray_1 {
    public:
        typedef _IDL_SEQ_LOT_DATAArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ArrayOfLOT *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_LOT_DATAArray_1 ();
    _IDL_SEQ_LOT_DATAArray_1 (::CORBA::ULong length, ArrayOfLOT* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_LOT_DATAArray_1 (const _IDL_SEQ_LOT_DATAArray_1&);


    ~_IDL_SEQ_LOT_DATAArray_1 ();

    _IDL_SEQ_LOT_DATAArray_1& operator= (const _IDL_SEQ_LOT_DATAArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ArrayOfLOT& operator [] (::CORBA::ULong indx);
    const ArrayOfLOT& operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ArrayOfLOT* get_buffer (::CORBA::Boolean orphan=0);
    const ArrayOfLOT* get_buffer () const;
    void replace (::CORBA::ULong length, ArrayOfLOT* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ArrayOfLOT* src, ArrayOfLOT* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ArrayOfLOT* data); 
  public:

    static ArrayOfLOT* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ArrayOfLOT* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(ArrayOfLOT* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_LOT_DATAArray_1> LOT_DATAArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_LOT_DATAArray_1* _IDL_SEQ_LOT_DATAArray_1_vPtr;
typedef const _IDL_SEQ_LOT_DATAArray_1* _IDL_SEQ_LOT_DATAArray_1_cvPtr;

class  _IDL_SEQ_LOT_DATAArray_1_var
{
    public:

    _IDL_SEQ_LOT_DATAArray_1_var ();

    _IDL_SEQ_LOT_DATAArray_1_var (_IDL_SEQ_LOT_DATAArray_1 *_p);

    _IDL_SEQ_LOT_DATAArray_1_var (const _IDL_SEQ_LOT_DATAArray_1_var &_s);

    _IDL_SEQ_LOT_DATAArray_1_var &operator= (_IDL_SEQ_LOT_DATAArray_1 *_p);

    _IDL_SEQ_LOT_DATAArray_1_var &operator= (const _IDL_SEQ_LOT_DATAArray_1_var &_s);

    ~_IDL_SEQ_LOT_DATAArray_1_var ();

    _IDL_SEQ_LOT_DATAArray_1* operator-> ();

    operator _IDL_SEQ_LOT_DATAArray_1_cvPtr () const;

    operator _IDL_SEQ_LOT_DATAArray_1_vPtr& ();

    operator _IDL_SEQ_LOT_DATAArray_1() const;

    const ArrayOfLOT& operator[] (::CORBA::ULong index) const;
    ArrayOfLOT& operator[] (::CORBA::ULong index);
    const ArrayOfLOT& operator[] (int index) const;
    ArrayOfLOT& operator[] (int index);
    const _IDL_SEQ_LOT_DATAArray_1& in() const;
    _IDL_SEQ_LOT_DATAArray_1& inout();
    _IDL_SEQ_LOT_DATAArray_1*& out();
    _IDL_SEQ_LOT_DATAArray_1* _retn();

    protected:
    _IDL_SEQ_LOT_DATAArray_1 *_ptr;
};

    typedef _IDL_SEQ_LOT_DATAArray_1 _LOT_DATAArray_seq;
    typedef _IDL_SEQ_LOT_DATAArray_1 _LOT_DATAArray_seq_1;
    typedef _IDL_SEQ_LOT_DATAArray_1 LOT_DATAArray;
    typedef _IDL_SEQ_LOT_DATAArray_1_var LOT_DATAArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_LOT_DATAArray;
    class  Innotron_Recomd_Request_var;
    struct  Innotron_Recomd_Request {
        typedef Innotron_Recomd_Request_var _var_type;
       ::Innotron_Rec_APC_CONTEXT APC_CONTEXT;
       ::LOT_DATAArray LOT_DATA;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       Innotron_Recomd_Request();
       Innotron_Recomd_Request(const Innotron_Recomd_Request&);
       Innotron_Recomd_Request& operator=(const Innotron_Recomd_Request&);
       static CORBA::Info<Innotron_Recomd_Request> Innotron_Recomd_Request_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct Innotron_Recomd_Request


typedef Innotron_Recomd_Request* Innotron_Recomd_Request_vPtr;
typedef const Innotron_Recomd_Request* Innotron_Recomd_Request_cvPtr;

class  Innotron_Recomd_Request_var
{
    public:

    Innotron_Recomd_Request_var ();

    Innotron_Recomd_Request_var (Innotron_Recomd_Request *_p);

    Innotron_Recomd_Request_var (const Innotron_Recomd_Request_var &_s);

    Innotron_Recomd_Request_var &operator= (Innotron_Recomd_Request *_p);

    Innotron_Recomd_Request_var &operator= (const Innotron_Recomd_Request_var &_s);

    ~Innotron_Recomd_Request_var ();

    Innotron_Recomd_Request* operator-> ();

    const Innotron_Recomd_Request& in() const;
    Innotron_Recomd_Request& inout();
    Innotron_Recomd_Request*& out();
    Innotron_Recomd_Request* _retn();

    operator Innotron_Recomd_Request_cvPtr () const;

    operator Innotron_Recomd_Request_vPtr& ();

    operator const Innotron_Recomd_Request& () const;

    operator Innotron_Recomd_Request& ();

    protected:
    Innotron_Recomd_Request *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_Innotron_Recomd_Request;
class  _IDL_SEQ_REC_TRANSACTIONIDArray_1_var;
class  _IDL_SEQ_REC_TRANSACTIONIDArray_1 {
    public:
        typedef _IDL_SEQ_REC_TRANSACTIONIDArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_REC_TRANSACTIONIDArray_1 ();
    _IDL_SEQ_REC_TRANSACTIONIDArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_REC_TRANSACTIONIDArray_1 (const _IDL_SEQ_REC_TRANSACTIONIDArray_1&);


    ~_IDL_SEQ_REC_TRANSACTIONIDArray_1 ();

    _IDL_SEQ_REC_TRANSACTIONIDArray_1& operator= (const _IDL_SEQ_REC_TRANSACTIONIDArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_REC_TRANSACTIONIDArray_1> REC_TRANSACTIONIDArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_REC_TRANSACTIONIDArray_1* _IDL_SEQ_REC_TRANSACTIONIDArray_1_vPtr;
typedef const _IDL_SEQ_REC_TRANSACTIONIDArray_1* _IDL_SEQ_REC_TRANSACTIONIDArray_1_cvPtr;

class  _IDL_SEQ_REC_TRANSACTIONIDArray_1_var
{
    public:

    _IDL_SEQ_REC_TRANSACTIONIDArray_1_var ();

    _IDL_SEQ_REC_TRANSACTIONIDArray_1_var (_IDL_SEQ_REC_TRANSACTIONIDArray_1 *_p);

    _IDL_SEQ_REC_TRANSACTIONIDArray_1_var (const _IDL_SEQ_REC_TRANSACTIONIDArray_1_var &_s);

    _IDL_SEQ_REC_TRANSACTIONIDArray_1_var &operator= (_IDL_SEQ_REC_TRANSACTIONIDArray_1 *_p);

    _IDL_SEQ_REC_TRANSACTIONIDArray_1_var &operator= (const _IDL_SEQ_REC_TRANSACTIONIDArray_1_var &_s);

    ~_IDL_SEQ_REC_TRANSACTIONIDArray_1_var ();

    _IDL_SEQ_REC_TRANSACTIONIDArray_1* operator-> ();

    operator _IDL_SEQ_REC_TRANSACTIONIDArray_1_cvPtr () const;

    operator _IDL_SEQ_REC_TRANSACTIONIDArray_1_vPtr& ();

    operator _IDL_SEQ_REC_TRANSACTIONIDArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_REC_TRANSACTIONIDArray_1& in() const;
    _IDL_SEQ_REC_TRANSACTIONIDArray_1& inout();
    _IDL_SEQ_REC_TRANSACTIONIDArray_1*& out();
    _IDL_SEQ_REC_TRANSACTIONIDArray_1* _retn();

    protected:
    _IDL_SEQ_REC_TRANSACTIONIDArray_1 *_ptr;
};

    typedef _IDL_SEQ_REC_TRANSACTIONIDArray_1 _REC_TRANSACTIONIDArray_seq;
    typedef _IDL_SEQ_REC_TRANSACTIONIDArray_1 _REC_TRANSACTIONIDArray_seq_1;
    typedef _IDL_SEQ_REC_TRANSACTIONIDArray_1 REC_TRANSACTIONIDArray;
    typedef _IDL_SEQ_REC_TRANSACTIONIDArray_1_var REC_TRANSACTIONIDArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_REC_TRANSACTIONIDArray;
    class  Innotron_Used_APC_CONTEXT_var;
    struct  Innotron_Used_APC_CONTEXT {
        typedef Innotron_Used_APC_CONTEXT_var _var_type;
       ::CONTROLJOBTYPEArray CONTROLJOBTYPE;
       ::TRANSACTIONIDArray TRANSACTIONID;
       ::REC_TRANSACTIONIDArray REC_TRANSACTIONID;
       ::LOTIDArray LOTID;
       ::LOTTYPEArray LOTTYPE;
       ::PARTIDArray PARTID;
       ::LAYERArray LAYER;
       ::ROUTEArray ROUTE;
       ::ROUTEGROUPArray ROUTEGROUP;
       ::OPERATIONArray OPERATION;
       ::RETICLEIDArray RETICLEID;
       ::PROCESSEQUIPTYPEArray PROCESSEQUIPTYPE;
       ::PROCESSEQUIPIDArray PROCESSEQUIPID;
       ::RECOMMENDMODEArray RECOMMENDMODE;
       ::REWORKArray REWORK;
       ::PARENTLOTIDArray PARENTLOTID;
       ::PRETOOLArray PRETOOL;
       ::SENDAHEADArray SENDAHEAD;
       ::SENDAHEADVALUESArray SENDAHEADVALUES;
       ::AVAILABLE_SUBUNITArray AVAILABLE_SUBUNIT;
       ::IS_OPSTART_RECOMDArray IS_OPSTART_RECOMD;
       ::LD_EXTENDArray LD_EXTEND;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       Innotron_Used_APC_CONTEXT();
       Innotron_Used_APC_CONTEXT(const Innotron_Used_APC_CONTEXT&);
       Innotron_Used_APC_CONTEXT& operator=(const Innotron_Used_APC_CONTEXT&);
       static CORBA::Info<Innotron_Used_APC_CONTEXT> Innotron_Used_APC_CONTEXT_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct Innotron_Used_APC_CONTEXT


typedef Innotron_Used_APC_CONTEXT* Innotron_Used_APC_CONTEXT_vPtr;
typedef const Innotron_Used_APC_CONTEXT* Innotron_Used_APC_CONTEXT_cvPtr;

class  Innotron_Used_APC_CONTEXT_var
{
    public:

    Innotron_Used_APC_CONTEXT_var ();

    Innotron_Used_APC_CONTEXT_var (Innotron_Used_APC_CONTEXT *_p);

    Innotron_Used_APC_CONTEXT_var (const Innotron_Used_APC_CONTEXT_var &_s);

    Innotron_Used_APC_CONTEXT_var &operator= (Innotron_Used_APC_CONTEXT *_p);

    Innotron_Used_APC_CONTEXT_var &operator= (const Innotron_Used_APC_CONTEXT_var &_s);

    ~Innotron_Used_APC_CONTEXT_var ();

    Innotron_Used_APC_CONTEXT* operator-> ();

    const Innotron_Used_APC_CONTEXT& in() const;
    Innotron_Used_APC_CONTEXT& inout();
    Innotron_Used_APC_CONTEXT*& out();
    Innotron_Used_APC_CONTEXT* _retn();

    operator Innotron_Used_APC_CONTEXT_cvPtr () const;

    operator Innotron_Used_APC_CONTEXT_vPtr& ();

    operator const Innotron_Used_APC_CONTEXT& () const;

    operator Innotron_Used_APC_CONTEXT& ();

    protected:
    Innotron_Used_APC_CONTEXT *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_Innotron_Used_APC_CONTEXT;
class  _IDL_SEQ_STATUSSTRINGArray_1_var;
class  _IDL_SEQ_STATUSSTRINGArray_1 {
    public:
        typedef _IDL_SEQ_STATUSSTRINGArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_STATUSSTRINGArray_1 ();
    _IDL_SEQ_STATUSSTRINGArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_STATUSSTRINGArray_1 (const _IDL_SEQ_STATUSSTRINGArray_1&);


    ~_IDL_SEQ_STATUSSTRINGArray_1 ();

    _IDL_SEQ_STATUSSTRINGArray_1& operator= (const _IDL_SEQ_STATUSSTRINGArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_STATUSSTRINGArray_1> STATUSSTRINGArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_STATUSSTRINGArray_1* _IDL_SEQ_STATUSSTRINGArray_1_vPtr;
typedef const _IDL_SEQ_STATUSSTRINGArray_1* _IDL_SEQ_STATUSSTRINGArray_1_cvPtr;

class  _IDL_SEQ_STATUSSTRINGArray_1_var
{
    public:

    _IDL_SEQ_STATUSSTRINGArray_1_var ();

    _IDL_SEQ_STATUSSTRINGArray_1_var (_IDL_SEQ_STATUSSTRINGArray_1 *_p);

    _IDL_SEQ_STATUSSTRINGArray_1_var (const _IDL_SEQ_STATUSSTRINGArray_1_var &_s);

    _IDL_SEQ_STATUSSTRINGArray_1_var &operator= (_IDL_SEQ_STATUSSTRINGArray_1 *_p);

    _IDL_SEQ_STATUSSTRINGArray_1_var &operator= (const _IDL_SEQ_STATUSSTRINGArray_1_var &_s);

    ~_IDL_SEQ_STATUSSTRINGArray_1_var ();

    _IDL_SEQ_STATUSSTRINGArray_1* operator-> ();

    operator _IDL_SEQ_STATUSSTRINGArray_1_cvPtr () const;

    operator _IDL_SEQ_STATUSSTRINGArray_1_vPtr& ();

    operator _IDL_SEQ_STATUSSTRINGArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_STATUSSTRINGArray_1& in() const;
    _IDL_SEQ_STATUSSTRINGArray_1& inout();
    _IDL_SEQ_STATUSSTRINGArray_1*& out();
    _IDL_SEQ_STATUSSTRINGArray_1* _retn();

    protected:
    _IDL_SEQ_STATUSSTRINGArray_1 *_ptr;
};

    typedef _IDL_SEQ_STATUSSTRINGArray_1 _STATUSSTRINGArray_seq;
    typedef _IDL_SEQ_STATUSSTRINGArray_1 _STATUSSTRINGArray_seq_1;
    typedef _IDL_SEQ_STATUSSTRINGArray_1 STATUSSTRINGArray;
    typedef _IDL_SEQ_STATUSSTRINGArray_1_var STATUSSTRINGArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_STATUSSTRINGArray;
class  _IDL_SEQ_SAHD_REASONArray_1_var;
class  _IDL_SEQ_SAHD_REASONArray_1 {
    public:
        typedef _IDL_SEQ_SAHD_REASONArray_1_var _var_type;
    protected:
    ::CORBA::ULong _length;
    ::CORBA::String *_buffer; 
    unsigned char _release;

    public:
    _IDL_SEQ_SAHD_REASONArray_1 ();
    _IDL_SEQ_SAHD_REASONArray_1 (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
    _IDL_SEQ_SAHD_REASONArray_1 (const _IDL_SEQ_SAHD_REASONArray_1&);


    ~_IDL_SEQ_SAHD_REASONArray_1 ();

    _IDL_SEQ_SAHD_REASONArray_1& operator= (const _IDL_SEQ_SAHD_REASONArray_1&);

    ::CORBA::ULong maximum() const;
    ::CORBA::ULong length() const;
    void length (::CORBA::ULong len);

    ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx);
    const ::CORBA::String_SeqElem operator [] (::CORBA::ULong indx) const;

    ::CORBA::Boolean release() const;
    ::CORBA::String* get_buffer (::CORBA::Boolean orphan=0);
    const ::CORBA::String* get_buffer () const;
    void replace (::CORBA::ULong length, ::CORBA::String* data, ::CORBA::Boolean release = 0);
  private:
    void _defaultInit (); 
    static void _copyElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* src, ::CORBA::String* tgt); 
    static void _resetElements (::CORBA::ULong start, ::CORBA::ULong stop, ::CORBA::String* data); 
  public:

    static ::CORBA::String* SOMLINK allocbuf(::CORBA::ULong nelems);
    static ::CORBA::String* SOMLINK allocbuf_throw(::CORBA::ULong nelems);
    static void SOMLINK freebuf(::CORBA::String* data);

    void encodeOp (::CORBA::Request &req) const;
    void decodeOp (::CORBA::Request &req);
    void decodeInOutOp (::CORBA::Request &req);
    static CORBA::Info<_IDL_SEQ_SAHD_REASONArray_1> SAHD_REASONArray_1_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
};


typedef _IDL_SEQ_SAHD_REASONArray_1* _IDL_SEQ_SAHD_REASONArray_1_vPtr;
typedef const _IDL_SEQ_SAHD_REASONArray_1* _IDL_SEQ_SAHD_REASONArray_1_cvPtr;

class  _IDL_SEQ_SAHD_REASONArray_1_var
{
    public:

    _IDL_SEQ_SAHD_REASONArray_1_var ();

    _IDL_SEQ_SAHD_REASONArray_1_var (_IDL_SEQ_SAHD_REASONArray_1 *_p);

    _IDL_SEQ_SAHD_REASONArray_1_var (const _IDL_SEQ_SAHD_REASONArray_1_var &_s);

    _IDL_SEQ_SAHD_REASONArray_1_var &operator= (_IDL_SEQ_SAHD_REASONArray_1 *_p);

    _IDL_SEQ_SAHD_REASONArray_1_var &operator= (const _IDL_SEQ_SAHD_REASONArray_1_var &_s);

    ~_IDL_SEQ_SAHD_REASONArray_1_var ();

    _IDL_SEQ_SAHD_REASONArray_1* operator-> ();

    operator _IDL_SEQ_SAHD_REASONArray_1_cvPtr () const;

    operator _IDL_SEQ_SAHD_REASONArray_1_vPtr& ();

    operator _IDL_SEQ_SAHD_REASONArray_1() const;

    const ::CORBA::String_SeqElem operator[] (::CORBA::ULong index) const;
    ::CORBA::String_SeqElem operator[] (::CORBA::ULong index);
    const ::CORBA::String_SeqElem operator[] (int index) const;
    ::CORBA::String_SeqElem operator[] (int index);
    const _IDL_SEQ_SAHD_REASONArray_1& in() const;
    _IDL_SEQ_SAHD_REASONArray_1& inout();
    _IDL_SEQ_SAHD_REASONArray_1*& out();
    _IDL_SEQ_SAHD_REASONArray_1* _retn();

    protected:
    _IDL_SEQ_SAHD_REASONArray_1 *_ptr;
};

    typedef _IDL_SEQ_SAHD_REASONArray_1 _SAHD_REASONArray_seq;
    typedef _IDL_SEQ_SAHD_REASONArray_1 _SAHD_REASONArray_seq_1;
    typedef _IDL_SEQ_SAHD_REASONArray_1 SAHD_REASONArray;
    typedef _IDL_SEQ_SAHD_REASONArray_1_var SAHD_REASONArray_var;
    extern  ::CORBA::TypeCode_ptr _tc_SAHD_REASONArray;
    class  Status_var;
    struct  Status {
        typedef Status_var _var_type;
       ::CORBA::Long STATUSCODE;
       ::STATUSSTRINGArray STATUSSTRING;
       ::CORBA::Long SAHD_REQUEST;
       ::SAHD_REASONArray SAHD_REASON;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       Status();
       Status(const Status&);
       Status& operator=(const Status&);
       static CORBA::Info<Status> Status_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct Status


typedef Status* Status_vPtr;
typedef const Status* Status_cvPtr;

class  Status_var
{
    public:

    Status_var ();

    Status_var (Status *_p);

    Status_var (const Status_var &_s);

    Status_var &operator= (Status *_p);

    Status_var &operator= (const Status_var &_s);

    ~Status_var ();

    Status* operator-> ();

    const Status& in() const;
    Status& inout();
    Status*& out();
    Status* _retn();

    operator Status_cvPtr () const;

    operator Status_vPtr& ();

    operator const Status& () const;

    operator Status& ();

    protected:
    Status *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_Status;
    class  Innotron_Recomd_Result_var;
    struct  Innotron_Recomd_Result {
        typedef Innotron_Recomd_Result_var _var_type;
       ::Innotron_Rec_APC_CONTEXT APC_CONTEXT;
       ::Status APC_STATUS;
       ::RETICLESArray RETICLES;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       Innotron_Recomd_Result();
       Innotron_Recomd_Result(const Innotron_Recomd_Result&);
       Innotron_Recomd_Result& operator=(const Innotron_Recomd_Result&);
       static CORBA::Info<Innotron_Recomd_Result> Innotron_Recomd_Result_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct Innotron_Recomd_Result


typedef Innotron_Recomd_Result* Innotron_Recomd_Result_vPtr;
typedef const Innotron_Recomd_Result* Innotron_Recomd_Result_cvPtr;

class  Innotron_Recomd_Result_var
{
    public:

    Innotron_Recomd_Result_var ();

    Innotron_Recomd_Result_var (Innotron_Recomd_Result *_p);

    Innotron_Recomd_Result_var (const Innotron_Recomd_Result_var &_s);

    Innotron_Recomd_Result_var &operator= (Innotron_Recomd_Result *_p);

    Innotron_Recomd_Result_var &operator= (const Innotron_Recomd_Result_var &_s);

    ~Innotron_Recomd_Result_var ();

    Innotron_Recomd_Result* operator-> ();

    const Innotron_Recomd_Result& in() const;
    Innotron_Recomd_Result& inout();
    Innotron_Recomd_Result*& out();
    Innotron_Recomd_Result* _retn();

    operator Innotron_Recomd_Result_cvPtr () const;

    operator Innotron_Recomd_Result_vPtr& ();

    operator const Innotron_Recomd_Result& () const;

    operator Innotron_Recomd_Result& ();

    protected:
    Innotron_Recomd_Result *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_Innotron_Recomd_Result;
    class  Innotron_Used_Result_var;
    struct  Innotron_Used_Result {
        typedef Innotron_Used_Result_var _var_type;
       ::Innotron_Used_APC_CONTEXT APC_CONTEXT;
       ::Status APC_STATUS;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       Innotron_Used_Result();
       Innotron_Used_Result(const Innotron_Used_Result&);
       Innotron_Used_Result& operator=(const Innotron_Used_Result&);
       static CORBA::Info<Innotron_Used_Result> Innotron_Used_Result_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct Innotron_Used_Result


typedef Innotron_Used_Result* Innotron_Used_Result_vPtr;
typedef const Innotron_Used_Result* Innotron_Used_Result_cvPtr;

class  Innotron_Used_Result_var
{
    public:

    Innotron_Used_Result_var ();

    Innotron_Used_Result_var (Innotron_Used_Result *_p);

    Innotron_Used_Result_var (const Innotron_Used_Result_var &_s);

    Innotron_Used_Result_var &operator= (Innotron_Used_Result *_p);

    Innotron_Used_Result_var &operator= (const Innotron_Used_Result_var &_s);

    ~Innotron_Used_Result_var ();

    Innotron_Used_Result* operator-> ();

    const Innotron_Used_Result& in() const;
    Innotron_Used_Result& inout();
    Innotron_Used_Result*& out();
    Innotron_Used_Result* _retn();

    operator Innotron_Used_Result_cvPtr () const;

    operator Innotron_Used_Result_vPtr& ();

    operator const Innotron_Used_Result& () const;

    operator Innotron_Used_Result& ();

    protected:
    Innotron_Used_Result *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_Innotron_Used_Result;
    class  Innotron_Met_Result_var;
    struct  Innotron_Met_Result {
        typedef Innotron_Met_Result_var _var_type;
       ::Innotron_Met_APC_CONTEXT APC_CONTEXT;
       ::Status APC_STATUS;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       Innotron_Met_Result();
       Innotron_Met_Result(const Innotron_Met_Result&);
       Innotron_Met_Result& operator=(const Innotron_Met_Result&);
       static CORBA::Info<Innotron_Met_Result> Innotron_Met_Result_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct Innotron_Met_Result


typedef Innotron_Met_Result* Innotron_Met_Result_vPtr;
typedef const Innotron_Met_Result* Innotron_Met_Result_cvPtr;

class  Innotron_Met_Result_var
{
    public:

    Innotron_Met_Result_var ();

    Innotron_Met_Result_var (Innotron_Met_Result *_p);

    Innotron_Met_Result_var (const Innotron_Met_Result_var &_s);

    Innotron_Met_Result_var &operator= (Innotron_Met_Result *_p);

    Innotron_Met_Result_var &operator= (const Innotron_Met_Result_var &_s);

    ~Innotron_Met_Result_var ();

    Innotron_Met_Result* operator-> ();

    const Innotron_Met_Result& in() const;
    Innotron_Met_Result& inout();
    Innotron_Met_Result*& out();
    Innotron_Met_Result* _retn();

    operator Innotron_Met_Result_cvPtr () const;

    operator Innotron_Met_Result_vPtr& ();

    operator const Innotron_Met_Result& () const;

    operator Innotron_Met_Result& ();

    protected:
    Innotron_Met_Result *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_Innotron_Met_Result;
    class  Innotron_Used_Request_var;
    struct  Innotron_Used_Request {
        typedef Innotron_Used_Request_var _var_type;
       ::Innotron_Used_APC_CONTEXT APC_CONTEXT;
       ::LOT_DATAArray LOT_DATA;
       ::RETICLESArray RETICLES;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       Innotron_Used_Request();
       Innotron_Used_Request(const Innotron_Used_Request&);
       Innotron_Used_Request& operator=(const Innotron_Used_Request&);
       static CORBA::Info<Innotron_Used_Request> Innotron_Used_Request_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct Innotron_Used_Request


typedef Innotron_Used_Request* Innotron_Used_Request_vPtr;
typedef const Innotron_Used_Request* Innotron_Used_Request_cvPtr;

class  Innotron_Used_Request_var
{
    public:

    Innotron_Used_Request_var ();

    Innotron_Used_Request_var (Innotron_Used_Request *_p);

    Innotron_Used_Request_var (const Innotron_Used_Request_var &_s);

    Innotron_Used_Request_var &operator= (Innotron_Used_Request *_p);

    Innotron_Used_Request_var &operator= (const Innotron_Used_Request_var &_s);

    ~Innotron_Used_Request_var ();

    Innotron_Used_Request* operator-> ();

    const Innotron_Used_Request& in() const;
    Innotron_Used_Request& inout();
    Innotron_Used_Request*& out();
    Innotron_Used_Request* _retn();

    operator Innotron_Used_Request_cvPtr () const;

    operator Innotron_Used_Request_vPtr& ();

    operator const Innotron_Used_Request& () const;

    operator Innotron_Used_Request& ();

    protected:
    Innotron_Used_Request *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_Innotron_Used_Request;
    class  Metrology_RequestResponse_var;
    struct  Metrology_RequestResponse {
        typedef Metrology_RequestResponse_var _var_type;
       ::Innotron_Met_Result Metrology_RequestResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       Metrology_RequestResponse();
       Metrology_RequestResponse(const Metrology_RequestResponse&);
       Metrology_RequestResponse& operator=(const Metrology_RequestResponse&);
       static CORBA::Info<Metrology_RequestResponse> Metrology_RequestResponse_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct Metrology_RequestResponse


typedef Metrology_RequestResponse* Metrology_RequestResponse_vPtr;
typedef const Metrology_RequestResponse* Metrology_RequestResponse_cvPtr;

class  Metrology_RequestResponse_var
{
    public:

    Metrology_RequestResponse_var ();

    Metrology_RequestResponse_var (Metrology_RequestResponse *_p);

    Metrology_RequestResponse_var (const Metrology_RequestResponse_var &_s);

    Metrology_RequestResponse_var &operator= (Metrology_RequestResponse *_p);

    Metrology_RequestResponse_var &operator= (const Metrology_RequestResponse_var &_s);

    ~Metrology_RequestResponse_var ();

    Metrology_RequestResponse* operator-> ();

    const Metrology_RequestResponse& in() const;
    Metrology_RequestResponse& inout();
    Metrology_RequestResponse*& out();
    Metrology_RequestResponse* _retn();

    operator Metrology_RequestResponse_cvPtr () const;

    operator Metrology_RequestResponse_vPtr& ();

    operator const Metrology_RequestResponse& () const;

    operator Metrology_RequestResponse& ();

    protected:
    Metrology_RequestResponse *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_Metrology_RequestResponse;
    class  Used_RequestResponse_var;
    struct  Used_RequestResponse {
        typedef Used_RequestResponse_var _var_type;
       ::Innotron_Used_Result Used_RequestResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       Used_RequestResponse();
       Used_RequestResponse(const Used_RequestResponse&);
       Used_RequestResponse& operator=(const Used_RequestResponse&);
       static CORBA::Info<Used_RequestResponse> Used_RequestResponse_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct Used_RequestResponse


typedef Used_RequestResponse* Used_RequestResponse_vPtr;
typedef const Used_RequestResponse* Used_RequestResponse_cvPtr;

class  Used_RequestResponse_var
{
    public:

    Used_RequestResponse_var ();

    Used_RequestResponse_var (Used_RequestResponse *_p);

    Used_RequestResponse_var (const Used_RequestResponse_var &_s);

    Used_RequestResponse_var &operator= (Used_RequestResponse *_p);

    Used_RequestResponse_var &operator= (const Used_RequestResponse_var &_s);

    ~Used_RequestResponse_var ();

    Used_RequestResponse* operator-> ();

    const Used_RequestResponse& in() const;
    Used_RequestResponse& inout();
    Used_RequestResponse*& out();
    Used_RequestResponse* _retn();

    operator Used_RequestResponse_cvPtr () const;

    operator Used_RequestResponse_vPtr& ();

    operator const Used_RequestResponse& () const;

    operator Used_RequestResponse& ();

    protected:
    Used_RequestResponse *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_Used_RequestResponse;
    class  Metrology_Request_var;
    struct  Metrology_Request {
        typedef Metrology_Request_var _var_type;
       ::Innotron_Met_Request objRequest;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       Metrology_Request();
       Metrology_Request(const Metrology_Request&);
       Metrology_Request& operator=(const Metrology_Request&);
       static CORBA::Info<Metrology_Request> Metrology_Request_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct Metrology_Request


typedef Metrology_Request* Metrology_Request_vPtr;
typedef const Metrology_Request* Metrology_Request_cvPtr;

class  Metrology_Request_var
{
    public:

    Metrology_Request_var ();

    Metrology_Request_var (Metrology_Request *_p);

    Metrology_Request_var (const Metrology_Request_var &_s);

    Metrology_Request_var &operator= (Metrology_Request *_p);

    Metrology_Request_var &operator= (const Metrology_Request_var &_s);

    ~Metrology_Request_var ();

    Metrology_Request* operator-> ();

    const Metrology_Request& in() const;
    Metrology_Request& inout();
    Metrology_Request*& out();
    Metrology_Request* _retn();

    operator Metrology_Request_cvPtr () const;

    operator Metrology_Request_vPtr& ();

    operator const Metrology_Request& () const;

    operator Metrology_Request& ();

    protected:
    Metrology_Request *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_Metrology_Request;
    class  Recommend_RequestResponse_var;
    struct  Recommend_RequestResponse {
        typedef Recommend_RequestResponse_var _var_type;
       ::Innotron_Recomd_Result Recommend_RequestResult;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       Recommend_RequestResponse();
       Recommend_RequestResponse(const Recommend_RequestResponse&);
       Recommend_RequestResponse& operator=(const Recommend_RequestResponse&);
       static CORBA::Info<Recommend_RequestResponse> Recommend_RequestResponse_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct Recommend_RequestResponse


typedef Recommend_RequestResponse* Recommend_RequestResponse_vPtr;
typedef const Recommend_RequestResponse* Recommend_RequestResponse_cvPtr;

class  Recommend_RequestResponse_var
{
    public:

    Recommend_RequestResponse_var ();

    Recommend_RequestResponse_var (Recommend_RequestResponse *_p);

    Recommend_RequestResponse_var (const Recommend_RequestResponse_var &_s);

    Recommend_RequestResponse_var &operator= (Recommend_RequestResponse *_p);

    Recommend_RequestResponse_var &operator= (const Recommend_RequestResponse_var &_s);

    ~Recommend_RequestResponse_var ();

    Recommend_RequestResponse* operator-> ();

    const Recommend_RequestResponse& in() const;
    Recommend_RequestResponse& inout();
    Recommend_RequestResponse*& out();
    Recommend_RequestResponse* _retn();

    operator Recommend_RequestResponse_cvPtr () const;

    operator Recommend_RequestResponse_vPtr& ();

    operator const Recommend_RequestResponse& () const;

    operator Recommend_RequestResponse& ();

    protected:
    Recommend_RequestResponse *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_Recommend_RequestResponse;
    class  Used_Request_var;
    struct  Used_Request {
        typedef Used_Request_var _var_type;
       ::Innotron_Used_Request objRequest;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       Used_Request();
       Used_Request(const Used_Request&);
       Used_Request& operator=(const Used_Request&);
       static CORBA::Info<Used_Request> Used_Request_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct Used_Request


typedef Used_Request* Used_Request_vPtr;
typedef const Used_Request* Used_Request_cvPtr;

class  Used_Request_var
{
    public:

    Used_Request_var ();

    Used_Request_var (Used_Request *_p);

    Used_Request_var (const Used_Request_var &_s);

    Used_Request_var &operator= (Used_Request *_p);

    Used_Request_var &operator= (const Used_Request_var &_s);

    ~Used_Request_var ();

    Used_Request* operator-> ();

    const Used_Request& in() const;
    Used_Request& inout();
    Used_Request*& out();
    Used_Request* _retn();

    operator Used_Request_cvPtr () const;

    operator Used_Request_vPtr& ();

    operator const Used_Request& () const;

    operator Used_Request& ();

    protected:
    Used_Request *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_Used_Request;
    class  Recommend_Request_var;
    struct  Recommend_Request {
        typedef Recommend_Request_var _var_type;
       ::Innotron_Recomd_Request objRequest;
       void  encodeOp (::CORBA::Request &r) const;
       void  decodeOp (::CORBA::Request &r);
       void  decodeInOutOp (::CORBA::Request &r);
       Recommend_Request();
       Recommend_Request(const Recommend_Request&);
       Recommend_Request& operator=(const Recommend_Request&);
       static CORBA::Info<Recommend_Request> Recommend_Request_Info;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_version;
       static const CORBA::ClassVersionInfo_1_0 __stubcode_dependents[];
   }; // struct Recommend_Request


typedef Recommend_Request* Recommend_Request_vPtr;
typedef const Recommend_Request* Recommend_Request_cvPtr;

class  Recommend_Request_var
{
    public:

    Recommend_Request_var ();

    Recommend_Request_var (Recommend_Request *_p);

    Recommend_Request_var (const Recommend_Request_var &_s);

    Recommend_Request_var &operator= (Recommend_Request *_p);

    Recommend_Request_var &operator= (const Recommend_Request_var &_s);

    ~Recommend_Request_var ();

    Recommend_Request* operator-> ();

    const Recommend_Request& in() const;
    Recommend_Request& inout();
    Recommend_Request*& out();
    Recommend_Request* _retn();

    operator Recommend_Request_cvPtr () const;

    operator Recommend_Request_vPtr& ();

    operator const Recommend_Request& () const;

    operator Recommend_Request& ();

    protected:
    Recommend_Request *_ptr;
};

    extern  ::CORBA::TypeCode_ptr _tc_Recommend_Request;
#endif   
/*
 * Guard codes of CORBA::Any operators.
 */
#ifdef __NOTUSE_ANYOPERATOR__
#define __NOTUSE_cs_apcstr_ANYOPERATOR__
#endif //__NOTUSE_ANYOPERATOR__

#ifdef __USE_cs_apcstr_ANYOPERATOR__
#undef __NOTUSE_cs_apcstr_ANYOPERATOR__
#endif //__USE_cs_apcstr_ANYOPERATOR__
#ifndef __NOTUSE_cs_apcstr_ANYOPERATOR__
#define _DCL_ANYOPS_ITEM_VALUE
#define _DCL_ANYOPS_ArrayOfITEM_VALUE
#define _DCL_ANYOPS_LD_EXTENDArray
#define _DCL_ANYOPS_Innotron_Rec_APC_CONTEXT
#define _DCL_ANYOPS_PARAMSArray
#define _DCL_ANYOPS_REC_Reticle
#define _DCL_ANYOPS_ArrayOfREC_Reticle
#define _DCL_ANYOPS_WAFER
#define _DCL_ANYOPS_ArrayOfWAFER
#define _DCL_ANYOPS_WAFERSArray
#define _DCL_ANYOPS_LOT
#define _DCL_ANYOPS_Innotron_Met_APC_CONTEXT
#define _DCL_ANYOPS_DCITEMSArray
#define _DCL_ANYOPS_Met_Reticle
#define _DCL_ANYOPS_ArrayOfMet_Reticle
#define _DCL_ANYOPS_RETICLESArray
#define _DCL_ANYOPS_Innotron_Met_Request
#define _DCL_ANYOPS_ArrayOfLOT
#define _DCL_ANYOPS_LOT_DATAArray
#define _DCL_ANYOPS_Innotron_Recomd_Request
#define _DCL_ANYOPS_Innotron_Used_APC_CONTEXT
#define _DCL_ANYOPS_Status
#define _DCL_ANYOPS_Innotron_Recomd_Result
#define _DCL_ANYOPS_Innotron_Used_Result
#define _DCL_ANYOPS_Innotron_Met_Result
#define _DCL_ANYOPS_Innotron_Used_Request
#define _DCL_ANYOPS_Metrology_RequestResponse
#define _DCL_ANYOPS_Used_RequestResponse
#define _DCL_ANYOPS_Metrology_Request
#define _DCL_ANYOPS_Recommend_RequestResponse
#define _DCL_ANYOPS_Used_Request
#define _DCL_ANYOPS_Recommend_Request
#endif //__NOTUSE_cs_apcstr_ANYOPERATOR__

/*
 * Overloaded CORBA::Any operators.
 */
#ifdef _DCL_ANYOPS_ITEM_VALUE
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::ITEM_VALUE &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::ITEM_VALUE *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::ITEM_VALUE*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::ITEM_VALUE*& _data);
#endif
#endif // _DCL_ANYOPS_ITEM_VALUE
#ifdef _DCL_ANYOPS_ArrayOfITEM_VALUE
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::ArrayOfITEM_VALUE &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::ArrayOfITEM_VALUE *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::ArrayOfITEM_VALUE*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::ArrayOfITEM_VALUE*& _data);
#endif
#endif // _DCL_ANYOPS_ArrayOfITEM_VALUE
#ifdef _DCL_ANYOPS_LD_EXTENDArray
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::LD_EXTENDArray &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::LD_EXTENDArray *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::LD_EXTENDArray*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::LD_EXTENDArray*& _data);
#endif
#endif // _DCL_ANYOPS_LD_EXTENDArray
#ifdef _DCL_ANYOPS_Innotron_Rec_APC_CONTEXT
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::Innotron_Rec_APC_CONTEXT &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::Innotron_Rec_APC_CONTEXT *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Innotron_Rec_APC_CONTEXT*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Innotron_Rec_APC_CONTEXT*& _data);
#endif
#endif // _DCL_ANYOPS_Innotron_Rec_APC_CONTEXT
#ifdef _DCL_ANYOPS_PARAMSArray
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::PARAMSArray &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::PARAMSArray *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::PARAMSArray*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::PARAMSArray*& _data);
#endif
#endif // _DCL_ANYOPS_PARAMSArray
#ifdef _DCL_ANYOPS_REC_Reticle
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::REC_Reticle &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::REC_Reticle *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::REC_Reticle*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::REC_Reticle*& _data);
#endif
#endif // _DCL_ANYOPS_REC_Reticle
#ifdef _DCL_ANYOPS_ArrayOfREC_Reticle
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::ArrayOfREC_Reticle &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::ArrayOfREC_Reticle *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::ArrayOfREC_Reticle*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::ArrayOfREC_Reticle*& _data);
#endif
#endif // _DCL_ANYOPS_ArrayOfREC_Reticle
#ifdef _DCL_ANYOPS_WAFER
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::WAFER &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::WAFER *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::WAFER*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::WAFER*& _data);
#endif
#endif // _DCL_ANYOPS_WAFER
#ifdef _DCL_ANYOPS_ArrayOfWAFER
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::ArrayOfWAFER &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::ArrayOfWAFER *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::ArrayOfWAFER*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::ArrayOfWAFER*& _data);
#endif
#endif // _DCL_ANYOPS_ArrayOfWAFER
#ifdef _DCL_ANYOPS_WAFERSArray
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::WAFERSArray &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::WAFERSArray *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::WAFERSArray*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::WAFERSArray*& _data);
#endif
#endif // _DCL_ANYOPS_WAFERSArray
#ifdef _DCL_ANYOPS_LOT
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::LOT &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::LOT *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::LOT*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::LOT*& _data);
#endif
#endif // _DCL_ANYOPS_LOT
#ifdef _DCL_ANYOPS_Innotron_Met_APC_CONTEXT
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::Innotron_Met_APC_CONTEXT &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::Innotron_Met_APC_CONTEXT *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Innotron_Met_APC_CONTEXT*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Innotron_Met_APC_CONTEXT*& _data);
#endif
#endif // _DCL_ANYOPS_Innotron_Met_APC_CONTEXT
#ifdef _DCL_ANYOPS_DCITEMSArray
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::DCITEMSArray &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::DCITEMSArray *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::DCITEMSArray*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::DCITEMSArray*& _data);
#endif
#endif // _DCL_ANYOPS_DCITEMSArray
#ifdef _DCL_ANYOPS_Met_Reticle
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::Met_Reticle &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::Met_Reticle *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Met_Reticle*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Met_Reticle*& _data);
#endif
#endif // _DCL_ANYOPS_Met_Reticle
#ifdef _DCL_ANYOPS_ArrayOfMet_Reticle
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::ArrayOfMet_Reticle &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::ArrayOfMet_Reticle *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::ArrayOfMet_Reticle*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::ArrayOfMet_Reticle*& _data);
#endif
#endif // _DCL_ANYOPS_ArrayOfMet_Reticle
#ifdef _DCL_ANYOPS_RETICLESArray
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::RETICLESArray &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::RETICLESArray *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::RETICLESArray*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::RETICLESArray*& _data);
#endif
#endif // _DCL_ANYOPS_RETICLESArray
#ifdef _DCL_ANYOPS_Innotron_Met_Request
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::Innotron_Met_Request &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::Innotron_Met_Request *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Innotron_Met_Request*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Innotron_Met_Request*& _data);
#endif
#endif // _DCL_ANYOPS_Innotron_Met_Request
#ifdef _DCL_ANYOPS_ArrayOfLOT
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::ArrayOfLOT &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::ArrayOfLOT *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::ArrayOfLOT*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::ArrayOfLOT*& _data);
#endif
#endif // _DCL_ANYOPS_ArrayOfLOT
#ifdef _DCL_ANYOPS_LOT_DATAArray
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::LOT_DATAArray &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::LOT_DATAArray *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::LOT_DATAArray*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::LOT_DATAArray*& _data);
#endif
#endif // _DCL_ANYOPS_LOT_DATAArray
#ifdef _DCL_ANYOPS_Innotron_Recomd_Request
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::Innotron_Recomd_Request &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::Innotron_Recomd_Request *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Innotron_Recomd_Request*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Innotron_Recomd_Request*& _data);
#endif
#endif // _DCL_ANYOPS_Innotron_Recomd_Request
#ifdef _DCL_ANYOPS_Innotron_Used_APC_CONTEXT
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::Innotron_Used_APC_CONTEXT &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::Innotron_Used_APC_CONTEXT *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Innotron_Used_APC_CONTEXT*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Innotron_Used_APC_CONTEXT*& _data);
#endif
#endif // _DCL_ANYOPS_Innotron_Used_APC_CONTEXT
#ifdef _DCL_ANYOPS_Status
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::Status &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::Status *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Status*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Status*& _data);
#endif
#endif // _DCL_ANYOPS_Status
#ifdef _DCL_ANYOPS_Innotron_Recomd_Result
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::Innotron_Recomd_Result &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::Innotron_Recomd_Result *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Innotron_Recomd_Result*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Innotron_Recomd_Result*& _data);
#endif
#endif // _DCL_ANYOPS_Innotron_Recomd_Result
#ifdef _DCL_ANYOPS_Innotron_Used_Result
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::Innotron_Used_Result &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::Innotron_Used_Result *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Innotron_Used_Result*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Innotron_Used_Result*& _data);
#endif
#endif // _DCL_ANYOPS_Innotron_Used_Result
#ifdef _DCL_ANYOPS_Innotron_Met_Result
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::Innotron_Met_Result &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::Innotron_Met_Result *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Innotron_Met_Result*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Innotron_Met_Result*& _data);
#endif
#endif // _DCL_ANYOPS_Innotron_Met_Result
#ifdef _DCL_ANYOPS_Innotron_Used_Request
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::Innotron_Used_Request &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::Innotron_Used_Request *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Innotron_Used_Request*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Innotron_Used_Request*& _data);
#endif
#endif // _DCL_ANYOPS_Innotron_Used_Request
#ifdef _DCL_ANYOPS_Metrology_RequestResponse
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::Metrology_RequestResponse &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::Metrology_RequestResponse *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Metrology_RequestResponse*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Metrology_RequestResponse*& _data);
#endif
#endif // _DCL_ANYOPS_Metrology_RequestResponse
#ifdef _DCL_ANYOPS_Used_RequestResponse
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::Used_RequestResponse &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::Used_RequestResponse *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Used_RequestResponse*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Used_RequestResponse*& _data);
#endif
#endif // _DCL_ANYOPS_Used_RequestResponse
#ifdef _DCL_ANYOPS_Metrology_Request
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::Metrology_Request &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::Metrology_Request *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Metrology_Request*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Metrology_Request*& _data);
#endif
#endif // _DCL_ANYOPS_Metrology_Request
#ifdef _DCL_ANYOPS_Recommend_RequestResponse
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::Recommend_RequestResponse &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::Recommend_RequestResponse *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Recommend_RequestResponse*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Recommend_RequestResponse*& _data);
#endif
#endif // _DCL_ANYOPS_Recommend_RequestResponse
#ifdef _DCL_ANYOPS_Used_Request
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::Used_Request &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::Used_Request *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Used_Request*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Used_Request*& _data);
#endif
#endif // _DCL_ANYOPS_Used_Request
#ifdef _DCL_ANYOPS_Recommend_Request
#ifndef __NOTUSE_ANYOPERATOR_INSERTION__
 void operator <<= (::CORBA::Any& _any, const ::Recommend_Request &_data);
#endif
#ifdef __USE_ANYOPERATOR_PTR_INSERTION__
 void operator <<= (::CORBA::Any& _any, ::Recommend_Request *_data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, ::Recommend_Request*& _data);
#endif
#ifndef __NOTUSE_ANYOPERATOR_CONST_EXTRACTION__
 ::CORBA::Boolean operator >>= (const ::CORBA::Any& _any, const ::Recommend_Request*& _data);
#endif
#endif // _DCL_ANYOPS_Recommend_Request

#endif /* _cs_apcstr_hh_included */

#endif /* _cs_apcstr_server_defined */
