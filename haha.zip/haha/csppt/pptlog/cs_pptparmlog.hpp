// @(#) 1.3 superpos/src/csppt/source/posppt/pptlog/cs_pptparmlog.hpp, mm_srv_5_0_cspp, mm_srv_5_0_cspp 6/9/03 13:56:31 [ 6/9/03 13:56:32 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// File : cs_pptparmlog.hpp
// Description : Definition of Customized Parameter Log
//
// ** Notice **
//   This is a sample code for customizing a PPT ServiceManager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT ServiceManager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//
//
// Modeficaiton History:
// Date       Defect   Name             Description
// ---------- -------- ---------------- ----------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya       Initial Release for R5.0
// 2004/11/05 D6000025 K.Murakami       Add include <corba.h> for eBrokerMigration.
// 2005/06/13 D6000354 K.Murakami       follow up for eBroker.


#ifndef _cspptparmlog_hpp_
#define _cspptparmlog_hpp_

#include <fstream.h>
#include <strstream.h>
#ifdef EBROKER    //D6000025
#include <corba.h> //D6000025
#else              //D6000025
#include <CORBA.h>
#endif             //D6000025
#include "cs_pptstr.hh"
#include "pptparmlog.hpp"

#define CS_LogFile CS_PPTParameterLog

extern char* getSimpleFunctionName( const char* fullFunctionName );

class CS_PPTParameterLog : virtual public ParameterLog
{
public:

	CS_PPTParameterLog( const char* opname, const char* node, const char* user, const char* desc = NULL );
	~CS_PPTParameterLog();

    virtual void outVariable( CORBA::SystemException& object, char* name );

    virtual void outVariable( const int object, char* name );
//  virtual void outVariable( const unsigned long object, char* name );
//  virtual void outVariable( const double object, char* name );
    virtual void outVariable( const char* object, char* name );
//D6000354    virtual void outVariable( const CORBA::any& object, char* name );
    virtual void outVariable( const CORBA::Any& object, char* name );          //D6000354

	#include "outvariable.h"
	#include "cs_outvariable.h"

};

#define CS_PPTPARAMETERLOG(a,b,c,d)  CS_PPTParameterLog __parmLog(a, b, c, d); 

#define CS_PPT_METHODPARMTRACELOG_FILTER(a,b) \
PPT_METHODTRACELOG_FILTER(a,b); \
CORBA::String_var __opname = getSimpleFunctionName( __FUNCTION__ ); \
CS_PPTParameterLog __parmLog((const char*)__opname, a, b);

#define CS_PPT_PARMTRACE_VERBOSE(a) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
}

#define CS_PPT_PARMTRACE_VERBOSE1(a) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
}

#define CS_PPT_PARMTRACE_VERBOSE2(a,b)  \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
__parmLog.outVariable(b,#b); \
}

#define CS_PPT_PARMTRACE_VERBOSE3(a,b,c) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
__parmLog.outVariable(b,#b); \
__parmLog.outVariable(c,#c); \
}

#define CS_PPT_PARMTRACE_VERBOSE4(a,b,c,d) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
__parmLog.outVariable(b,#b); \
__parmLog.outVariable(c,#c); \
__parmLog.outVariable(d,#d); \
}

#define CS_PPT_PARMTRACE_VERBOSE5(a,b,c,d,e) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
__parmLog.outVariable(b,#b); \
__parmLog.outVariable(c,#c); \
__parmLog.outVariable(d,#d); \
__parmLog.outVariable(e,#e); \
}

#define CS_PPT_PARMTRACE_VERBOSE6(a,b,c,d,e,f) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
__parmLog.outVariable(b,#b); \
__parmLog.outVariable(c,#c); \
__parmLog.outVariable(d,#d); \
__parmLog.outVariable(e,#e); \
__parmLog.outVariable(f,#f); \
}

#define CS_PPT_PARMTRACE_VERBOSE7(a,b,c,d,e,f,g) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
__parmLog.outVariable(b,#b); \
__parmLog.outVariable(c,#c); \
__parmLog.outVariable(d,#d); \
__parmLog.outVariable(e,#e); \
__parmLog.outVariable(f,#f); \
__parmLog.outVariable(g,#g); \
}

#define CS_PPT_PARMTRACE_VERBOSE8(a,b,c,d,e,f,g,h) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
__parmLog.outVariable(b,#b); \
__parmLog.outVariable(c,#c); \
__parmLog.outVariable(d,#d); \
__parmLog.outVariable(e,#e); \
__parmLog.outVariable(f,#f); \
__parmLog.outVariable(g,#g); \
__parmLog.outVariable(h,#h); \
}

#define CS_PPT_PARMTRACE_VERBOSE9(a,b,c,d,e,f,g,h,i) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
__parmLog.outVariable(b,#b); \
__parmLog.outVariable(c,#c); \
__parmLog.outVariable(d,#d); \
__parmLog.outVariable(e,#e); \
__parmLog.outVariable(f,#f); \
__parmLog.outVariable(g,#g); \
__parmLog.outVariable(h,#h); \
__parmLog.outVariable(i,#i); \
}

#define CS_PPT_PARMTRACE_VERBOSE10(a,b,c,d,e,f,g,h,i,j) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
__parmLog.outVariable(b,#b); \
__parmLog.outVariable(c,#c); \
__parmLog.outVariable(d,#d); \
__parmLog.outVariable(e,#e); \
__parmLog.outVariable(f,#f); \
__parmLog.outVariable(g,#g); \
__parmLog.outVariable(h,#h); \
__parmLog.outVariable(i,#i); \
__parmLog.outVariable(j,#j); \
}

#define CS_PPT_PARMTRACE_VERBOSE11(a,b,c,d,e,f,g,h,i,j,k) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
__parmLog.outVariable(b,#b); \
__parmLog.outVariable(c,#c); \
__parmLog.outVariable(d,#d); \
__parmLog.outVariable(e,#e); \
__parmLog.outVariable(f,#f); \
__parmLog.outVariable(g,#g); \
__parmLog.outVariable(h,#h); \
__parmLog.outVariable(i,#i); \
__parmLog.outVariable(j,#j); \
__parmLog.outVariable(k,#k); \
}

#define CS_PPT_PARMTRACE_VERBOSE12(a,b,c,d,e,f,g,h,i,j,k,l) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
__parmLog.outVariable(b,#b); \
__parmLog.outVariable(c,#c); \
__parmLog.outVariable(d,#d); \
__parmLog.outVariable(e,#e); \
__parmLog.outVariable(f,#f); \
__parmLog.outVariable(g,#g); \
__parmLog.outVariable(h,#h); \
__parmLog.outVariable(i,#i); \
__parmLog.outVariable(j,#j); \
__parmLog.outVariable(k,#k); \
__parmLog.outVariable(l,#l); \
}

#define CS_PPT_PARMTRACE_VERBOSE13(a,b,c,d,e,f,g,h,i,j,k,l,m) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
__parmLog.outVariable(b,#b); \
__parmLog.outVariable(c,#c); \
__parmLog.outVariable(d,#d); \
__parmLog.outVariable(e,#e); \
__parmLog.outVariable(f,#f); \
__parmLog.outVariable(g,#g); \
__parmLog.outVariable(h,#h); \
__parmLog.outVariable(i,#i); \
__parmLog.outVariable(j,#j); \
__parmLog.outVariable(k,#k); \
__parmLog.outVariable(l,#l); \
__parmLog.outVariable(m,#m); \
}

#define CS_PPT_PARMTRACE_VERBOSE14(a,b,c,d,e,f,g,h,i,j,k,l,m,n) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
__parmLog.outVariable(b,#b); \
__parmLog.outVariable(c,#c); \
__parmLog.outVariable(d,#d); \
__parmLog.outVariable(e,#e); \
__parmLog.outVariable(f,#f); \
__parmLog.outVariable(g,#g); \
__parmLog.outVariable(h,#h); \
__parmLog.outVariable(i,#i); \
__parmLog.outVariable(j,#j); \
__parmLog.outVariable(k,#k); \
__parmLog.outVariable(l,#l); \
__parmLog.outVariable(m,#m); \
__parmLog.outVariable(n,#n); \
}

#define CS_PPT_PARMTRACE_VERBOSE15(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
__parmLog.outVariable(b,#b); \
__parmLog.outVariable(c,#c); \
__parmLog.outVariable(d,#d); \
__parmLog.outVariable(e,#e); \
__parmLog.outVariable(f,#f); \
__parmLog.outVariable(g,#g); \
__parmLog.outVariable(h,#h); \
__parmLog.outVariable(i,#i); \
__parmLog.outVariable(j,#j); \
__parmLog.outVariable(k,#k); \
__parmLog.outVariable(l,#l); \
__parmLog.outVariable(m,#m); \
__parmLog.outVariable(n,#n); \
__parmLog.outVariable(o,#o); \
}

#define CS_PPT_PARMTRACE_VERBOSE16(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
__parmLog.outVariable(b,#b); \
__parmLog.outVariable(c,#c); \
__parmLog.outVariable(d,#d); \
__parmLog.outVariable(e,#e); \
__parmLog.outVariable(f,#f); \
__parmLog.outVariable(g,#g); \
__parmLog.outVariable(h,#h); \
__parmLog.outVariable(i,#i); \
__parmLog.outVariable(j,#j); \
__parmLog.outVariable(k,#k); \
__parmLog.outVariable(l,#l); \
__parmLog.outVariable(m,#m); \
__parmLog.outVariable(n,#n); \
__parmLog.outVariable(o,#o); \
__parmLog.outVariable(p,#p); \
}

#define CS_PPT_PARMTRACE_VERBOSE17(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
__parmLog.outVariable(b,#b); \
__parmLog.outVariable(c,#c); \
__parmLog.outVariable(d,#d); \
__parmLog.outVariable(e,#e); \
__parmLog.outVariable(f,#f); \
__parmLog.outVariable(g,#g); \
__parmLog.outVariable(h,#h); \
__parmLog.outVariable(i,#i); \
__parmLog.outVariable(j,#j); \
__parmLog.outVariable(k,#k); \
__parmLog.outVariable(l,#l); \
__parmLog.outVariable(m,#m); \
__parmLog.outVariable(n,#n); \
__parmLog.outVariable(o,#o); \
__parmLog.outVariable(p,#p); \
__parmLog.outVariable(q,#q); \
}

#define CS_PPT_PARMTRACE_VERBOSE18(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
__parmLog.outVariable(b,#b); \
__parmLog.outVariable(c,#c); \
__parmLog.outVariable(d,#d); \
__parmLog.outVariable(e,#e); \
__parmLog.outVariable(f,#f); \
__parmLog.outVariable(g,#g); \
__parmLog.outVariable(h,#h); \
__parmLog.outVariable(i,#i); \
__parmLog.outVariable(j,#j); \
__parmLog.outVariable(k,#k); \
__parmLog.outVariable(l,#l); \
__parmLog.outVariable(m,#m); \
__parmLog.outVariable(n,#n); \
__parmLog.outVariable(o,#o); \
__parmLog.outVariable(p,#p); \
__parmLog.outVariable(q,#q); \
__parmLog.outVariable(r,#r); \
}

#define CS_PPT_PARMTRACE_VERBOSE19(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
__parmLog.outVariable(b,#b); \
__parmLog.outVariable(c,#c); \
__parmLog.outVariable(d,#d); \
__parmLog.outVariable(e,#e); \
__parmLog.outVariable(f,#f); \
__parmLog.outVariable(g,#g); \
__parmLog.outVariable(h,#h); \
__parmLog.outVariable(i,#i); \
__parmLog.outVariable(j,#j); \
__parmLog.outVariable(k,#k); \
__parmLog.outVariable(l,#l); \
__parmLog.outVariable(m,#m); \
__parmLog.outVariable(n,#n); \
__parmLog.outVariable(o,#o); \
__parmLog.outVariable(p,#p); \
__parmLog.outVariable(q,#q); \
__parmLog.outVariable(r,#r); \
__parmLog.outVariable(s,#s); \
}

#define CS_PPT_PARMTRACE_VERBOSE20(a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t) \
if ( __parmLog.isLogEnabled() ) \
{ \
__parmLog.outVariable(a,#a); \
__parmLog.outVariable(b,#b); \
__parmLog.outVariable(c,#c); \
__parmLog.outVariable(d,#d); \
__parmLog.outVariable(e,#e); \
__parmLog.outVariable(f,#f); \
__parmLog.outVariable(g,#g); \
__parmLog.outVariable(h,#h); \
__parmLog.outVariable(i,#i); \
__parmLog.outVariable(j,#j); \
__parmLog.outVariable(k,#k); \
__parmLog.outVariable(l,#l); \
__parmLog.outVariable(m,#m); \
__parmLog.outVariable(n,#n); \
__parmLog.outVariable(o,#o); \
__parmLog.outVariable(p,#p); \
__parmLog.outVariable(q,#q); \
__parmLog.outVariable(r,#r); \
__parmLog.outVariable(s,#s); \
__parmLog.outVariable(t,#t); \
}

#endif
