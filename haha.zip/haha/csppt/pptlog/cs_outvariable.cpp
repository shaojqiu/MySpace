// @(#) 1.4 superpos/src/csppt/source/posppt/pptlog/cs_outvariable.cpp, mm_srv_5_0_cspp, mm_srv_5_0_cspp 6/9/03 13:59:07 [ 6/9/03 13:59:09 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// File : cs_outvariable.cpp
// Description : Customized Parameter Log
//
// ** Notice **
//   This is a sample code for customizing a PPT ServiceManager.
//   IBM desn't ensure  the behaviour in all cases and all situations.
//   If you customize PPT ServiceManager using this examples from this code,
//   you have to ensure the behavior of your code through your test process.
//
//
// Modeficaiton History:
// Date       Defect   Name             Description
// ---------- -------- ---------------- ----------------------------------------------
// 2003/06/09 D5000014 C.Tsuchiya      Initial Release for R5.0
//

#include "cs_pptstr._oc" 
