#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/svcmgr/txmethods/CS_TxEqpRelatedRecipeIDAuditFlagListInq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:57:34 [ 7/13/07 21:57:35 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: CS_TxEqpRelatedRecipeIDAuditFlagListInq.cpp
//

//D02.0145 #include "pptsm.hpp"
#include "cs_pptsm.hpp" //D02.0145 
#include "spfunc.hpp"
#include "pptenv.hpp"          //D4100134
#include "ppteventlog.hpp"

// Class: CS_PPTServiceManager
//
// Service: CS_TxEqpRelatedRecipeIDAuditFlagListInq()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2002/01/07 D4100057 Cinthia Jao     Initial Release(R4.1)
// 2002-02-14 D4100014 H.Adachi       Add Parameter Log and Trace Log Filter
// 2002-02-25 D4100134 C.Tsuchiya     Delete thePPT_TRACE_INCOMING
// 2002/08/05 P4200079 T.Nishimura    Method name miss match.
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2005-08-09 D6000220 A.Tomari       Add the following document infomation
//                                    -<Method Summary>
//                                    -<MRM>
//                                    -<Sample Code>
//                                    -<IN-parm's description>
//
// Date       version     Person         Comments
// ---------- --------    -------------- -------------------------------------------
// 2017/08/02 INN-A170001 Mike Chang     INN-A170001:RMS enabling
// 2017/09/15 INN-A170001 Helios Zhen    Change TRANSACTION_ID to CSEQQ001
//
// Description:
//<Method Summary>
//This function returns candidate lists to change Recipe that will be used for Equipment. with a customized option to get audit flag.
//
//There is a fixed Recipe used for Equipment, but the Recipe can be changed at the time of StartLotReserve or OpeStart.
//This function is used for returning the Lists of Recipe that can be changed by Equipment.
//</Method Summary>
//
//<MRM>
//EWR1-2. : Flexible Process Condition Change
//</MRM>
//
//     Machine/Physical Recipe List Inquiry
//
// Return:
//     csEqpRelatedRecipeIDAuditFlagListInqResult
//
// Parameter:
//
//     const pptUser&           requestUserID,
//     const objectIdentifier&  equipmentID,
//     CORBA::Environment       &IT_env
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//Sample code:
//<Sample Code>
//    //m_pSvcMgr is CS_PPTServiceManager class
//    //m_User is pptUser struct
//
//    objectIdentifier equipmentID;
//    equipmentID.identifier                   = CORBA::string_dup("LM001");
//
//    csEqpRelatedRecipeIDAuditFlagListInqResult* pRet = NULL;
//
//    pRet = m_pSvcMgr-> CS_TxEqpRelatedRecipeIDAuditFlagListInq (
//        m_User,
//        equipmentID
//        );
//</Sample Code>
//
//<Method Start>
#define TRANSACTION_ID "CSEQQ001"
csEqpRelatedRecipeIDAuditFlagListInqResult* CS_PPTServiceManager_i::CS_TxEqpRelatedRecipeIDAuditFlagListInq( 
    const pptUser&           requestUserID,  //<i>R/Request User ID
//D6000025     const objectIdentifier&  equipmentID,
//D6000025     CORBA::Environment       &IT_env )
    const objectIdentifier&  equipmentID,    //<i>R/Equipment ID    //D6000025
    CORBA::Boolean getAuditFlag
    CORBAENV_LAST_CPP )                      //<i>O/IT Environment  //D6000025
{
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);    //D4100014
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i::CS_TxEqpRelatedRecipeIDAuditFlagListInq")
    CS_PPT_PARMTRACE_VERBOSE2(requestUserID,equipmentID);    //D4100014

    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
    csEqpRelatedRecipeIDAuditFlagListInqResult* retVal = new csEqpRelatedRecipeIDAuditFlagListInqResult;

    pptEventParameterSequence strEventParameter;

    objCalendar_GetCurrentTimeDR_out strCalendar_GetCurrentTimeDR_out ;

    pptObjCommonIn strObjCommonIn ;

    CORBA::Long rc = 0 ;

    // Initializing strObjCommonIn's first two parameters
    strObjCommonIn.transactionID = CIMFWStrDup(TRANSACTION_ID);
    strObjCommonIn.strUser = requestUserID ;

    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID);

    // Incoming Log Put
    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp =
                       strObjCommonIn.strTimeStamp.reportTimeStamp;
//D4100134    if(thePPT_TRACE_INCOMING)
    if(PPTEnv::logIncoming)    //D4100134
    {
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID);
        retVal->strResult.returnCode = CIMFWStrDup("Incoming") ;
        CORBA::Long nLen = strEventParameter.length();
        strEventParameter.length( nLen + 1 );
        strEventParameter[nLen].parameterName  = CIMFWStrDup("EQP_ID");
        strEventParameter[nLen].parameterValue = CIMFWStrDup( equipmentID.identifier );
        eventLog_Put(strEventParameter,strObjCommonIn,retVal->strResult);
        strEventParameter.length( 0 ) ;
        nLen = 0 ;
    }

    CREATE_TX_OBJ

    TX_BEGIN(calendar_GetCurrentTimeDR)
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn);
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp;
        if ( CIMFWStrLen(strObjCommonIn.strUser.functionID)==0 )
        {
            strObjCommonIn.strUser.functionID = CIMFWStrDup(TRANSACTION_ID);
        }
    }

    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTServiceManager_i::CS_TxEqpRelatedRecipeIDAuditFlagListInq", "rc != RC_OK")
        TX_ROLLBACK(calendar_GetCurrentTimeDR)
        retVal->strResult = strCalendar_GetCurrentTimeDR_out.strResult;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID);
        CORBA::Long nLen = strEventParameter.length();
        strEventParameter.length( nLen + 1 );
        strEventParameter[nLen].parameterName  = CIMFWStrDup("EQP_ID");
        strEventParameter[nLen].parameterValue = CIMFWStrDup( equipmentID.identifier );
        eventLog_Put(strEventParameter,strObjCommonIn,retVal->strResult);
        return retVal;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR)

    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummy;
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

    TX_BEGIN(txPrivilegeCheckReq)
    try
    {
        rc = theCS_PPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult,strObjCommonIn,equipmentID,dummy,dummyIDs,dummyIDs,dummyIDs,dummyIDs);
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTServiceManager_i::CS_TxEqpRelatedRecipeIDAuditFlagListInq", "rc != RC_OK")
        TX_ROLLBACK(txPrivilegeCheckReq)
        retVal->strResult = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID);
        CORBA::Long nLen = strEventParameter.length();
        strEventParameter.length( nLen + 1 );
        strEventParameter[nLen].parameterName  = CIMFWStrDup("EQP_ID");
        strEventParameter[nLen].parameterValue = CIMFWStrDup( equipmentID.identifier );
        eventLog_Put(strEventParameter,strObjCommonIn,retVal->strResult);
        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq)

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
//P4200079    TX_BEGIN(CS_TxEqpRelatedRecipeIDAuditFlagListInq)
    TX_BEGIN(cs_txEqpRelatedRecipeIDAuditFlagListInq) //P4200079
    try
    {
        rc = theCS_PPTManager->cs_txEqpRelatedRecipeIDAuditFlagListInq( *retVal,
                                                                      strObjCommonIn,
                                                                      equipmentID,
                                                                      getAuditFlag );
    }
//P4200079    CATCH_TX_TIMEOUT_EXCEPTIONS(CS_TxEqpRelatedRecipeIDAuditFlagListInq)
    CATCH_TX_TIMEOUT_EXCEPTIONS(cs_txEqpRelatedRecipeIDAuditFlagListInq) //P4200079
    if (rc == RC_OK)
    {
        PPT_METHODTRACE_V1("CS_PPTServiceManager_i::CS_TxEqpRelatedRecipeIDAuditFlagListInq", "rc == RC_OK")
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
//P4200079        TX_COMMIT(CS_TxEqpRelatedRecipeIDAuditFlagListInq)
        TX_COMMIT(cs_txEqpRelatedRecipeIDAuditFlagListInq) //P4200079
    }
    else
    {
        PPT_METHODTRACE_V1("CS_PPTServiceManager_i::CS_TxEqpRelatedRecipeIDAuditFlagListInq", "rc != RC_OK")
//P4200079        TX_ROLLBACK(CS_TxEqpRelatedRecipeIDAuditFlagListInq)
        TX_ROLLBACK(cs_txEqpRelatedRecipeIDAuditFlagListInq) //P4200079
    }

    /*-----------------------------------------------------------------------*/
    /*   Post Process                                                        */
    /*-----------------------------------------------------------------------*/
    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID);
    CORBA::Long nLen = strEventParameter.length();
    strEventParameter.length( nLen + 1 );
    strEventParameter[nLen].parameterName  = CIMFWStrDup("EQP_ID");
    strEventParameter[nLen].parameterValue = CIMFWStrDup( equipmentID.identifier );
    eventLog_Put(strEventParameter,strObjCommonIn,retVal->strResult);

    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i::CS_TxEqpRelatedRecipeIDAuditFlagListInq")
//    CS_PPT_PARMTRACE_VERBOSE1(*retVal);
    return retVal;
}
