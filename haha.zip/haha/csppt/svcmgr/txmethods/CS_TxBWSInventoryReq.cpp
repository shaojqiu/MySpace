//
// (c) Copyright: IBM Services Company Ltd, 2017, 2037. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 2017, 2037. All rights reserved.
//
// SiView
// Name: CS_TxBWSInventoryReq.cpp
//
#include "cs_pptsm.hpp"
#include "pptenv.hpp"          
#include "spfunc.hpp"  
#include "ppteventlog.hpp"     

// Class: CS_PPTServiceManager
//
// Service: CS_TxBWSInventoryReq()
//
// Change history:
// Date       Defect#     Person         Comments
// ---------- ----------- -------------- -------------------------------------------
// 2017/10/17 INN-R170017 Wang Fang      Initial Release
//
// Description:
//
// Return:
//     csBWSInventoryReqResult
//
// Parameter:
//        const pptUser&                   requestUserID,
//        const csBWSInventoryReqInParm&   strBWSInventoryReqInParm,
//        const char *                     claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//Sample code:
//<Sample Code>

//</Sample Code>
//
//<Method Start>
#define	 TRANSACTION_ID "CSEQC003"
csBWSInventoryReqResult* PPTServiceManager_i::CS_TxBWSInventoryReq (
    const pptUser&                   requestUserID,
    const csBWSInventoryReqInParm&   strBWSInventoryReqInParm,
    const char *                     claimMemo,
    CORBAENV_LAST_CPP )
{
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i:: CS_TxBWSInventoryReq ");
    CS_PPT_PARMTRACE_VERBOSE3(requestUserID,strBWSInventoryReqInParm, claimMemo); 
	
    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
    csBWSInventoryReqResult* retVal = new csBWSInventoryReqResult;
    pptEventParameterSequence strEventParameter ;
    objCalendar_GetCurrentTimeDR_out strCalendar_GetCurrentTimeDR_out;
    pptObjCommonIn strObjCommonIn ;
    
    CORBA::Long rc = 0 ;
    
    // Initialising strObjCommonIn's first two parameters
    strObjCommonIn.transactionID = CIMFWStrDup(TRANSACTION_ID);
    strObjCommonIn.strUser = requestUserID ;

    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID);
    
    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
		
    // setting event parameters
    CORBA::ULong nLen = 0;
    strEventParameter.length (2);
	
    strEventParameter[nLen].parameterName  = CIMFWStrDup("BWS_ID");
    strEventParameter[nLen].parameterValue = CIMFWStrDup(strBWSInventoryReqInParm.BWSID.identifier);
    nLen++;
	
    strEventParameter[nLen].parameterName  = CIMFWStrDup("ZONE_ID");
    strEventParameter[nLen].parameterValue = CIMFWStrDup(strBWSInventoryReqInParm.zoneID);
    nLen++;
	
    PPTEVENTLOG( retVal, &strObjCommonIn, &strEventParameter );
	
    CREATE_TX_OBJ

    TX_BEGIN(calendar_GetCurrentTimeDR)
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn) ;
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp ;
        strObjCommonIn.strUser.functionID = CIMFWStrDup(TRANSACTION_ID) ;  
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "calendar_GetCurrentTimeDR() rc != RC_OK", rc);
        TX_ROLLBACK(calendar_GetCurrentTimeDR)
        retVal->strResult = strCalendar_GetCurrentTimeDR_out.strResult ;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

        return retVal ;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR)

    // privilege check
    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummy;
    objectIdentifier eqpId = strBWSWaferListInqInParm.BWSID;
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);
	
    TX_BEGIN(txPrivilegeCheckReq)
    try
    {
        rc = theCS_PPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult,strObjCommonIn,eqpID,dummy,dummyIDs,dummyIDs,dummyIDs,dummyIDs); 
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "txPrivilegeCheckReq() rc != RC_OK", rc)
        TX_ROLLBACK(txPrivilegeCheckReq)
        retVal->strResult = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq)
	
    // main process
    TX_BEGIN(cs_txBWSInventroyReq);
    try
    {
        rc = theCS_PPTManager->cs_txBWSInventroyReq( *retVal, strObjCommonIn, strBWSInventoryReqInParm, claimMemo );
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(cs_txBWSInventroyReq);
	
    if( rc == RC_OK )
    {
        PPT_METHODTRACE_V1( "", "rc == RC_OK" );
        TX_COMMIT( cs_txBWSInventroyReq)
    }
    else
    {
        PPT_METHODTRACE_V1( "", "rc != RC_OK" );
        TX_COMMIT( cs_txBWSInventroyReq)
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID);
        return retVal;
    }
	
    /*-----------------------------------------------------------------------*/
    /*   Post Process                                                        */
    /*-----------------------------------------------------------------------*/
    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i:: CS_TxBWSInventoryReq");
    CS_PPT_PARMTRACE_VERBOSE1(*retVal);
    return retVal ;	
}
