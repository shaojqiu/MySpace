#ifndef lint
static char *sccsid =  "@(#) 1.3 superpos/src/spppt/source/posppt/svcmgr/txmethods/TxLotCassetteXferStatusChangeRpt__160.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/5/07 14:46:10 [ 11/5/07 14:46:11 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: TxLotCassetteXferStatusChangeRpt__160.cpp
//

#include "pptsm.hpp"
//D4000012     #include "pptenv.hpp"
#include "pptenv.hpp"          //D4100134 restore
#include "spfunc.hpp"
#include "ppteventlog.hpp"     //D4200212
#include "cs_pptsm.hpp" //INN-R170003

// Class: PPTServiceManager
//
// Service: TxLotCassetteXferStatusChangeRpt__160()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/08/23          O.Sugiyama     Initial Release
// 2000/11/02 P3000310 Y.Iwasaki      Change rc handling
// 2001/06/18 D4000013 K.Matsuei      Unified Security Control.
// 2001/06/27 D4000012 S.Miyatani     add environment variable control(PPTEnv::logIncoming change)
// 2002-02-04 D4100110 S.Tokumasu     Add timeStamp into xferStatusChangeRpt
// 2002-02-15 D4100014 H.Adachi       Add Parameter Log and Trace Log Filter
// 2002-02-25 D4100134 C.Tsuchiya     Delete thePPT_TRACE_INCOMING
// 2002-07-04 P4200039 K.Kimura       Modify the way of handling machineID in TxLotCassetteXferStatusChangeRpt
// 2002-10-10 P4200176 H.Adachi       Fix Wrong Message of Method Trace
// 2002-12-20 D4200212 H.Adachi       EventLog enhancement
// 2002-12-20 D4200250 H.Adachi       Add status information at event log.
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 2005-08-12 D6000270 A.Tomari       Add the following document information
//                                    -<Method Summary>
//                                    -<MRM>
//                                    -<Sample Code>
//                                    -<IN-parm's description>
// 2007/05/25 D9000007 D.Tamura       EventLog improvement
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/11/02 DSIV00000214 K.Kido         Multi Fab support.
// 2013/08/13 DSN000080226 W.Zhang        Add for Priviledge Check for lotID
// 2015/10/07 PSN000081321 T.Ishida       Claim Memo Improvement
//
// Innotron Modification history :
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2017/09/25 INN-R170003  SF.Peng        Add new transfer state PI/PO to control FOUP location
//
// Description:
//<Method Summary>
// This function changes Carrier Transfer Status.
//
// You can change Carrier Transfer Status to the followings.
//-SI: Station-In       --- Carrier is taken into Stocker by AGV.
//-SO: Station-Out      --- Carrier is taken out of Stocker by AGV.
//-BI: Bay-In           --- Carrier is taken into Stocker by InterBay.
//-BO: Bay-Out          --- Carrier is taken out of Stocker by InterBay.
//-MI: Manual-In        --- Carrier is taken into Stocker manually.
//-MO: Manual-Out       --- Carrier is taken out of Stocker manually.
//-EI: Equipment-In     --- Carrier is in Equipment.
//-EO: Equipment-Out    --- Carrier is out of Equipment.
//-HI: Shelf-In         --- Carrier is in Shelf that belongs to Internal Buffer Equipment.
//-HO: Shelf-Out        --- Carrier is out of Shelf that belongs to Internal Buffer Equipment.
//-II: Intermediate-In  --- Carrier is in intermediate Stocker.
//-IO: Intermediate-Out --- Carrier is out of intermediate Stocker.
//-AI: Abnormal-In      --- Carrier is in Stoker or Equipment without intervention of SiviewSystem.
//-AO: Abnormal-Out     --- Carrier is out of Stocker or Equipment without intervention of SiviewSystem.
//
//If the Carrier has transfer reservation when an operator takes Stocker into Carrier manually, the reservation will be cancelled.
//And it depends on Carrier XferStatus whether you can change specified Transfer Status or not.
//</Method Summary>
//
//<MRM>
// LGS1-4. Transfer Request
//</MRM>
//
// Return: pptLotCassetteXferStatusChangeRptResult
//
//
// Parameter:
//
//    const pptUser&              requestUserID
//    const objectIdentifier&     carrierID
//    const char *                xferStatus
//    CORBA::Boolean              ManualInFlag
//    const objectIdentifier&     machineID
//    const objectIdentifier&     portID
//    const char *                zoneID
//    const char *                shelfType
//    const char *                transferStatusChangeTimeStamp
//    const char *                claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//Sample code:
//<Sample Code>
//    //m_pSvcMgr is PPTServiceManager class
//    //m_User is pptUser struct
//
//    objectIdentifier  carrierID;
//    objectIdentifier  machineID;
//    objectIdentifier  portID;
//
//    carrierID.identifier         = CORBA::string_dup("CST001");
//    CORBA::String_var xferStatus = CORBA::string_dup("EO");
//    CORBA::Boolean ManualInFlag  = TRUE; 
//    machineID.identifier         = CORBA::string_dup("LM001");
//    portID.identifier            = CORBA::string_dup("P1");
//    CORBA::String_var zoneID     = CORBA::string_dup("");
//    CORBA::String_var shelfType  = CORBA::string_dup("");
//    CORBA::String_var transferStatusChangeTimeStamp  = CORBA::string_dup("");
//    CORBA::String_var ClaimMemo  = CORBA::string_dup("ClaimMemo");
//
//    pptLotCassetteXferStatusChangeRptResult* pRet = NULL;
//    pRet = m_pSvcMgr->TxLotCassetteXferStatusChangeRpt__160(
//        m_User,
//        carrierID,
//        xferStatus,
//        ManualInFlag,
//        machineID,
//        portID,
//        zoneID,
//        shelfType,
//        transferStatusChangeTimeStamp,
//        claimMemo
//        );
//</Sample Code>
//
//<Method Start>
//
//D4100110 pptLotCassetteXferStatusChangeRptResult* PPTServiceManager_i:: TxLotCassetteXferStatusChangeRpt (
//D4100110     const pptUser&              requestUserID, 
//D4100110     const objectIdentifier&     carrierID, 
//D4100110     const char *                xferStatus, 
//D4100110     CORBA::Boolean              ManualInFlag, 
//D4100110     const objectIdentifier&     machineID, 
//D4100110     const objectIdentifier&     portID, 
//D4100110     const char *                zoneID, 
//D4100110     const char *                shelfType, 
//D4100110     CORBA::Environment &        IT_env)
//INN-R170003 pptLotCassetteXferStatusChangeRptResult* PPTServiceManager_i:: TxLotCassetteXferStatusChangeRpt__160 (
pptLotCassetteXferStatusChangeRptResult* CS_PPTServiceManager_i:: TxLotCassetteXferStatusChangeRpt__160 ( //INN-R170003
    const pptUser&              requestUserID,                    //<i>R/Request User ID
    const objectIdentifier&     carrierID,                        //<i>R/Carrier ID
    const char *                xferStatus,                       //<i>R/Transfer Status
                                                                  //<c>SP_TransState_StationIn          "SI"
                                                                  //<c>SP_TransState_StationOut         "SO"
                                                                  //<c>SP_TransState_BayIn              "BI"
                                                                  //<c>SP_TransState_BayOut             "BO"
                                                                  //<c>SP_TransState_ManualIn           "MI"
                                                                  //<c>SP_TransState_ManualOut          "MO"
                                                                  //<c>SP_TransState_EquipmentIn        "EI"
                                                                  //<c>SP_TransState_EquipmentOut       "EO"
                                                                  //<c>SP_TransState_ShelfIn            "HI"
                                                                  //<c>SP_TransState_ShelfOut           "HO"
                                                                  //<c>SP_TransState_IntermediateIn     "II"
                                                                  //<c>SP_TransState_IntermediateOut    "IO"
                                                                  //<c>SP_TransState_AbnormalIn         "AI"
                                                                  //<c>SP_TransState_AbnormalOut        "AO"
    CORBA::Boolean              ManualInFlag,                     //<i>R/Manual In Flag
    const objectIdentifier&     machineID,                        //<i>R/Machine ID
    const objectIdentifier&     portID,                           //<i>R/Port ID
    const char *                zoneID,                           //<i>R/Zone ID
    const char *                shelfType,                        //<i>R/Shelf Type
//D6000025     const char *                transferStatusChangeTimeStamp,
//D6000025     CORBA::Environment &        IT_env)
//PSN000081321    const char *                transferStatusChangeTimeStamp     //<i>R/Transfer Status Change Time Stamp //D6000025
    const char *                transferStatusChangeTimeStamp,    //<i>R/Transfer Status Change Time Stamp    //PSN000081321
    const char *                claimMemo                         //<i>R/Claim Memo                           //PSN000081321
    CORBAENV_LAST_CPP)                                            //<i>O/IT Environment                    //D6000025
{
//INN-R170003    PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);    //D4100014
//INN-R170003    PPT_METHODTRACE_ENTRY("PPTServiceManager_i:: TxLotCassetteXferStatusChangeRpt__160");
//INN-R170003    PPT_PARMTRACE_VERBOSE9(requestUserID,carrierID,xferStatus,ManualInFlag,machineID,portID,zoneID,shelfType,transferStatusChangeTimeStamp);    //D4100014
//INN-R170003 Add Start
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i:: TxLotCassetteXferStatusChangeRpt__160");
    CS_PPT_PARMTRACE_VERBOSE9(requestUserID,carrierID,xferStatus,ManualInFlag,machineID,portID,zoneID,shelfType,transferStatusChangeTimeStamp);
//INN-R170003 Add End
    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/

    pptLotCassetteXferStatusChangeRptResult*    retVal = new pptLotCassetteXferStatusChangeRptResult;
    pptEventParameterSequence                   strEventParameter ;
    objCalendar_GetCurrentTimeDR_out            strCalendar_GetCurrentTimeDR_out ;
    pptObjCommonIn                              strObjCommonIn ;
    CORBA::Long                                 rc = 0 ;

    // Initialising strObjCommonIn's first two parameters

    strObjCommonIn.transactionID = CIMFWStrDup("TXLGR001") ;
    strObjCommonIn.strUser = requestUserID ;

    retVal->strResult.transactionID = CIMFWStrDup("TXLGR001") ;

    // Incoming Log Put
    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp =
                                               strObjCommonIn.strTimeStamp.reportTimeStamp;
//D4000012    if(PPTEnv::logIncoming)
//D4100134    if(thePPT_TRACE_INCOMING)    //D4000012
//D4200212    if(PPTEnv::logIncoming)    //D4100134
//D4200212    {
//D4200212        retVal->strResult.transactionID = CIMFWStrDup("TXLGR001") ;
//D4200212        retVal->strResult.returnCode = CIMFWStrDup("Incoming") ;
//D4200212
//D4200212        CORBA::Long nLen = strEventParameter.length() ;
//D4200212        strEventParameter.length( nLen + 4 ) ;
//D4200212        strEventParameter[nLen  ].parameterName  = CIMFWStrDup("CARR_ID") ;
//D4200212        strEventParameter[nLen++].parameterValue = CIMFWStrDup( carrierID.identifier ) ;
//D4200212        strEventParameter[nLen  ].parameterName  = CIMFWStrDup("MCN_ID") ;
//D4200212        strEventParameter[nLen++].parameterValue = CIMFWStrDup( machineID.identifier ) ;
//D4200212        strEventParameter[nLen  ].parameterName  = CIMFWStrDup("PORT_ID") ;
//D4200212        strEventParameter[nLen++].parameterValue = CIMFWStrDup( portID.identifier ) ;
//D4200212        strEventParameter[nLen  ].parameterName  = CIMFWStrDup("ZONE_ID") ;
//D4200212        strEventParameter[nLen++].parameterValue = CIMFWStrDup( zoneID ) ;
//D4200212        eventLog_Put(strEventParameter, strObjCommonIn, retVal->strResult);
//D4200212        strEventParameter.length( 0 ) ;
//D4200212        nLen = 0 ;
//D4200212    }

    //D4200212, D4200250 Add Start
    retVal->strResult.transactionID = CIMFWStrDup("TXLGR001") ;
//D9000007    retVal->strResult.returnCode    = CIMFWStrDup("Incoming") ;

    CORBA::Long nLen = strEventParameter.length() ;
    strEventParameter.length( nLen + 5 ) ;
//D9000007    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("CARR_ID") ;
//D9000007    strEventParameter[nLen++].parameterValue = CIMFWStrDup( carrierID.identifier ) ;
//D9000007    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("MCN_ID") ;
//D9000007    strEventParameter[nLen++].parameterValue = CIMFWStrDup( machineID.identifier ) ;
//D9000007    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("PORT_ID") ;
//D9000007    strEventParameter[nLen++].parameterValue = CIMFWStrDup( portID.identifier ) ;
//D9000007    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("ZONE_ID") ;
//D9000007    strEventParameter[nLen++].parameterValue = CIMFWStrDup( zoneID ) ;
//D9000007    strEventParameter[nLen  ].parameterName =  CIMFWStrDup("STATUS") ;
//D9000007    strEventParameter[nLen  ].parameterValue = CIMFWStrDup( xferStatus );
//D9000007 add start
    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("ZONE_ID") ;
    strEventParameter[nLen++].parameterValue = CIMFWStrDup( zoneID ) ;
    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("EQP_ID") ;
    strEventParameter[nLen++].parameterValue = CIMFWStrDup( machineID.identifier ) ;
    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("PORT_ID") ;
    strEventParameter[nLen++].parameterValue = CIMFWStrDup( portID.identifier ) ;
    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("CAST_ID") ;
    strEventParameter[nLen++].parameterValue = CIMFWStrDup( carrierID.identifier ) ;
    strEventParameter[nLen  ].parameterName =  CIMFWStrDup("XFER_STAT") ;
    strEventParameter[nLen  ].parameterValue = CIMFWStrDup( xferStatus );
//D9000007 add end
    PPTEVENTLOG( retVal, &strObjCommonIn, &strEventParameter ); 
    //D4200212, D4200250 Add End

    CREATE_TX_OBJ;

    TX_BEGIN(calendar_GetCurrentTimeDR);
    try
    {
        rc = thePPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn) ;
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp ;
        strObjCommonIn.strUser.functionID = CIMFWStrDup( "TXLGR001" ) ;
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR);

    if (rc != RC_OK)
    {
//INN-R170003        PPT_METHODTRACE_V1("PPTServiceManager_i:: TxReticleInventoryRpt", "rc != RC_OK");
        PPT_METHODTRACE_V1("CS_PPTServiceManager_i:: TxReticleInventoryRpt", "rc != RC_OK"); //INN-R170003
        TX_ROLLBACK(calendar_GetCurrentTimeDR);
        retVal->strResult = strCalendar_GetCurrentTimeDR_out.strResult ;
        retVal->strResult.transactionID = CIMFWStrDup("TXLGR001") ;

//D4200212        CORBA::Long nLen = strEventParameter.length() ;
//D4200212        strEventParameter.length( nLen + 4 ) ;
//D4200212        strEventParameter[nLen  ].parameterName  = CIMFWStrDup("CARR_ID") ;
//D4200212        strEventParameter[nLen++].parameterValue = CIMFWStrDup( carrierID.identifier ) ;
//D4200212        strEventParameter[nLen  ].parameterName  = CIMFWStrDup("MCN_ID") ;
//D4200212        strEventParameter[nLen++].parameterValue = CIMFWStrDup( machineID.identifier ) ;
//D4200212        strEventParameter[nLen  ].parameterName  = CIMFWStrDup("PORT_ID") ;
//D4200212        strEventParameter[nLen++].parameterValue = CIMFWStrDup( portID.identifier ) ;
//D4200212        strEventParameter[nLen  ].parameterName  = CIMFWStrDup("ZONE_ID") ;
//D4200212        strEventParameter[nLen++].parameterValue = CIMFWStrDup( zoneID ) ;
//D4200212        eventLog_Put(strEventParameter, strObjCommonIn, retVal->strResult);

        return retVal ;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR);

    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummy;
//D4000013 add start
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);
//D4000013 add end

//DSN000080226 Add Start
    objectIdentifierSequence lotIDs;
    lotIDs.length(0);
    CORBA::String_var tmpPrivilegeCheckCASTValue  = CIMFWStrDup(getenv(SP_PRIVILEGECHECK_FOR_CAST)); 
    
    PPT_METHODTRACE_V2("","env value of SP_PRIVILEGECHECK_FOR_CAST  = ",tmpPrivilegeCheckCASTValue);
    if( (0 != CIMFWStrLen(tmpPrivilegeCheckCASTValue)) && (0 == CIMFWStrCmp(tmpPrivilegeCheckCASTValue, "1")) )
    {
        objCassette_lotIDList_GetDR_out strCassette_lotIDList_GetDR_out;
        TX_BEGIN(cassette_lotIDList_GetDR);
        try
        {
            PPT_METHODTRACE_V1("", "Call cassette_lotIDList_GetDR");
            rc = thePPTManager->cassette_lotIDList_GetDR(strCassette_lotIDList_GetDR_out, strObjCommonIn, carrierID);
        }
        CATCH_TX_TIMEOUT_EXCEPTIONS(cassette_lotIDList_GetDR);
    
        if (rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "cassette_lotIDList_GetDR() != RC_OK");
            TX_ROLLBACK(cassette_lotIDList_GetDR);
            retVal->strResult               = strCassette_lotIDList_GetDR_out.strResult;
            retVal->strResult.transactionID = CIMFWStrDup("TXLGR001");
    
            return retVal;
        }
        TX_COMMIT(cassette_lotIDList_GetDR);
        
        lotIDs = strCassette_lotIDList_GetDR_out.lotIDs;
    }
    else
    {
        PPT_METHODTRACE_V1("", "SP_PRIVILEGECHECK_FOR_CAST OFF Do Nothing." );
    }
//DSN000080226 Add End

    TX_BEGIN(txPrivilegeCheckReq);
    try
    {
        //P4200039 Add Start
//INN-R170003        if(   (CIMFWStrCmp(xferStatus,SP_TransState_EquipmentIn)  == 0 )
//INN-R170003           || (CIMFWStrCmp(xferStatus,SP_TransState_EquipmentOut) == 0 ) )
//INN-R170003 Add Start
        if( CIMFWStrCmp(xferStatus, SP_TransState_EquipmentIn) == 0 ||
            CIMFWStrCmp(xferStatus, SP_TransState_EquipmentOut) == 0 ||
            CIMFWStrCmp(xferStatus, CS_TRANS_STATE_PORT_IN) == 0 ||
            CIMFWStrCmp(xferStatus, CS_TRANS_STATE_PORT_OUT) == 0 )
//INN-R170003 Add End
        {
            PPT_METHODTRACE_V1("","### machineID is handled as EqpID");
//DSN000080226            rc = thePPTManager->txPrivilegeCheckReq( strPrivilegeCheckReqResult,strObjCommonIn,machineID,dummy,dummyIDs,dummyIDs,dummyIDs,dummyIDs);
            rc = thePPTManager->txPrivilegeCheckReq( strPrivilegeCheckReqResult,strObjCommonIn,machineID,dummy,dummyIDs,dummyIDs,lotIDs,dummyIDs); //DSN000080226
        }
        else
        {
            PPT_METHODTRACE_V1("","### machineID is handled as CassetteID");
//DSN000080226            rc = thePPTManager->txPrivilegeCheckReq( strPrivilegeCheckReqResult,strObjCommonIn, dummy, machineID, dummyIDs,dummyIDs,dummyIDs,dummyIDs);
            rc = thePPTManager->txPrivilegeCheckReq( strPrivilegeCheckReqResult,strObjCommonIn, dummy, machineID, dummyIDs,dummyIDs,lotIDs,dummyIDs); //DSN000080226
        } 
        //P4200039 Add End
//D4000013        rc = thePPTManager->txPrivilegeCheckReq( strPrivilegeCheckReqResult,strObjCommonIn, dummy, machineID);
//P4200039        rc = thePPTManager->txPrivilegeCheckReq( strPrivilegeCheckReqResult,strObjCommonIn, dummy, machineID, dummyIDs,dummyIDs,dummyIDs,dummyIDs); //D4000013
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq);

    if (rc != RC_OK)
    {
//INN-R170003       PPT_METHODTRACE_V1("PPTServiceManager_i:: TxReticleInventoryRpt", "rc != RC_OK");
        PPT_METHODTRACE_V1("CS_PPTServiceManager_i:: TxReticleInventoryRpt", "rc != RC_OK"); //INN-R170003
        TX_ROLLBACK(txPrivilegeCheckReq);
        retVal->strResult = strPrivilegeCheckReqResult.strResult ;
        retVal->strResult.transactionID = CIMFWStrDup("TXLGR001") ;

//D4200212        CORBA::Long nLen = strEventParameter.length() ;
//D4200212        strEventParameter.length( nLen + 4 ) ;
//D4200212        strEventParameter[nLen  ].parameterName  = CIMFWStrDup("CARR_ID") ;
//D4200212        strEventParameter[nLen++].parameterValue = CIMFWStrDup( carrierID.identifier ) ;
//D4200212        strEventParameter[nLen  ].parameterName  = CIMFWStrDup("MCN_ID") ;
//D4200212        strEventParameter[nLen++].parameterValue = CIMFWStrDup( machineID.identifier ) ;
//D4200212        strEventParameter[nLen  ].parameterName  = CIMFWStrDup("PORT_ID") ;
//D4200212        strEventParameter[nLen++].parameterValue = CIMFWStrDup( portID.identifier ) ;
//D4200212        strEventParameter[nLen  ].parameterName  = CIMFWStrDup("ZONE_ID") ;
//D4200212        strEventParameter[nLen++].parameterValue = CIMFWStrDup( zoneID ) ;
//D4200212        eventLog_Put(strEventParameter, strObjCommonIn, retVal->strResult);

        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq);

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/
    TX_BEGIN(txLotCassetteXferStatusChangeRpt__160);
    try
    {
//D4100110        rc = thePPTManager->txLotCassetteXferStatusChangeRpt( *retVal, strObjCommonIn ,
//D4100110                                                              carrierID, xferStatus, ManualInFlag,
//D4100110                                                              machineID, portID, zoneID, shelfType);

//PSN000081321        rc = thePPTManager->txLotCassetteXferStatusChangeRpt( *retVal, strObjCommonIn ,
        rc = thePPTManager->txLotCassetteXferStatusChangeRpt__160( *retVal, strObjCommonIn ,                 //PSN000081321
                                                              carrierID, xferStatus, ManualInFlag,
                                                              machineID, portID, zoneID, shelfType,
//PSN000081321                                                              transferStatusChangeTimeStamp);
                                                              transferStatusChangeTimeStamp, claimMemo );    //PSN000081321
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txLotCassetteXferStatusChangeRpt__160);
//  if (rc != RC_INVALID_MACHINEID)
    if (rc == RC_OK)                  //P3300310
    {
//INN-R170003        PPT_METHODTRACE_V1("PPTServiceManager_i:: TxLotCassetteXferStatusChangeRpt__160", "rc == RC_OK");
        PPT_METHODTRACE_V1("CS_PPTServiceManager_i:: TxLotCassetteXferStatusChangeRpt__160", "rc == RC_OK"); //INN-R170003
        TX_COMMIT(txLotCassetteXferStatusChangeRpt__160);

        objMessageQueue_Put_out strMessageQueue_Put_out;
        objectIdentifier          dummy;
        pptPortOperationModeSequence dmyPortOperationMode;
        CORBA::Long rc2 = RC_OK;

        TX_BEGIN(messageQueue_Put);
        try 
        {
            rc2 = thePPTManager->messageQueue_Put( strMessageQueue_Put_out,
                                                  strObjCommonIn,
                                                  dummy,
                                                  dmyPortOperationMode,
                                                  dummy,
                                                  dummy,
                                                  "",
                                                  "",
                                                  carrierID,
                                                  retVal->strXferLot[0].transferStatus,
                                                  FALSE,
                                                  FALSE,
                                                  dummy,
                                                  "" );
        }
        CATCH_TX_TIMEOUT_EXCEPTIONS(messageQueue_Put);
        if ( rc2 == RC_OK ) 
        {
//P4200176           PPT_METHODTRACE_V1("PPTServiceManager_i::TxLotCassetteXferStatusChangeRpt__160", "messageQueue_Put() rc2 != RC_OK");
           PPT_METHODTRACE_V1("", "messageQueue_Put() rc2 == RC_OK") ;    //P4200176
           TX_COMMIT(messageQueue_Put);
//DSIV00000214 add start
           CORBA::Long rc3 = RC_OK;
           pptInterFabXferArrivalListInqResult strInterFabXferArrivalListInqResult;
           pptInterFabXferArrivalListInqInParm strInterFabXferArrivalListInqInParm;
           strInterFabXferArrivalListInqInParm.category = CIMFWStrDup(SP_InterFab_XferCategory_FOUP);
           strInterFabXferArrivalListInqInParm.objectID = carrierID;

           TX_BEGIN(txInterFabXferArrivalListInq);
           try
           {
               rc3 = thePPTManager->txInterFabXferArrivalListInq( strInterFabXferArrivalListInqResult,
                                                                  strObjCommonIn,
                                                                  strInterFabXferArrivalListInqInParm );
           }
           CATCH_TX_TIMEOUT_EXCEPTIONS(txInterFabXferArrivalListInq);

           if( rc3 == RC_OK )
           {
               PPT_METHODTRACE_V1("", "txInterFabXferArrivalListInq() rc3 == RC_OK") ;
               PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
               TX_COMMIT(txInterFabXferArrivalListInq);

               CORBA::ULong listLen = strInterFabXferArrivalListInqResult.strInterFabXferArrivalInfoSeq.length();
               if( 0 != listLen )
               {
                   const char* claimMemo2 = NULL ;
                   pptInterFabXferLotReceiveReqInParm strInterFabXferLotReceiveReqInParm;
                   strInterFabXferLotReceiveReqInParm.category = CIMFWStrDup(SP_InterFab_XferCategory_FOUP);
                   strInterFabXferLotReceiveReqInParm.objectID = carrierID;

                   pptInterFabXferLotReceiveReqResult_var result  = TxInterFabXferLotReceiveReq( requestUserID, strInterFabXferLotReceiveReqInParm, claimMemo2 );

                   rc = atoi( result->strResult.returnCode );
                   if( rc != RC_OK )
                   {
                       PPT_METHODTRACE_V1("", "TxInterFabXferLotReceiveReq :rc != RC_OK");
                       retVal->strResult = result->strResult;
                   }
                   else
                   {
                       PPT_METHODTRACE_V1("", "TxInterFabXferLotReceiveReq :rc == RC_OK");
                   }
               }
           }
           else
           {
               PPT_METHODTRACE_V1("", "txInterFabXferArrivalListInq() rc3 != RC_OK");
               TX_ROLLBACK(txInterFabXferArrivalListInq);
           }
//DSIV00000214 add end
        } 
        else 
        {
//INN-R170003        PPT_METHODTRACE_V1("PPTServiceManager_i::TxLotCassetteXferStatusChangeRpt__160", "messageQueue_Put() rc2 != RC_OK");
        PPT_METHODTRACE_V1("CS_PPTServiceManager_i::TxLotCassetteXferStatusChangeRpt__160", "messageQueue_Put() rc2 != RC_OK"); //INN-R170003
           TX_ROLLBACK(messageQueue_Put);
        }
    }
    else
    {
//INN-R170003        PPT_METHODTRACE_V1("PPTServiceManager_i:: TxLotCassetteXferStatusChangeRpt__160", "rc != RC_OK");
        PPT_METHODTRACE_V1("CS_PPTServiceManager_i:: TxLotCassetteXferStatusChangeRpt__160", "rc != RC_OK"); //INN-R170003
        TX_ROLLBACK(txLotCassetteXferStatusChangeRpt__160);
        retVal->strResult.transactionID = CIMFWStrDup("TXLGR001");

//D4200212        CORBA::Long nLen = strEventParameter.length() ;
//D4200212        strEventParameter.length( nLen + 4 ) ;
//D4200212        strEventParameter[nLen  ].parameterName  = CIMFWStrDup("CARR_ID") ;
//D4200212        strEventParameter[nLen++].parameterValue = CIMFWStrDup( carrierID.identifier ) ;
//D4200212        strEventParameter[nLen  ].parameterName  = CIMFWStrDup("MCN_ID") ;
//D4200212        strEventParameter[nLen++].parameterValue = CIMFWStrDup( machineID.identifier ) ;
//D4200212        strEventParameter[nLen  ].parameterName  = CIMFWStrDup("PORT_ID") ;
//D4200212        strEventParameter[nLen++].parameterValue = CIMFWStrDup( portID.identifier ) ;
//D4200212        strEventParameter[nLen  ].parameterName  = CIMFWStrDup("ZONE_ID") ;
//D4200212        strEventParameter[nLen++].parameterValue = CIMFWStrDup( zoneID ) ;
//D4200212        eventLog_Put(strEventParameter, strObjCommonIn, retVal->strResult);

        return retVal;
    }

    PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);

    /*-----------------------------------------------------------------------*/
    /*   Post Process                                                        */
    /*-----------------------------------------------------------------------*/

    retVal->strResult.transactionID = CIMFWStrDup("TXLGR001") ;

//D4200212    CORBA::Long nLen = strEventParameter.length() ;
//D4200212    strEventParameter.length( nLen + 4 ) ;
//D4200212    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("CARR_ID") ;
//D4200212    strEventParameter[nLen++].parameterValue = CIMFWStrDup( carrierID.identifier ) ;
//D4200212    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("MCN_ID") ;
//D4200212    strEventParameter[nLen++].parameterValue = CIMFWStrDup( machineID.identifier ) ;
//D4200212    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("PORT_ID") ;
//D4200212    strEventParameter[nLen++].parameterValue = CIMFWStrDup( portID.identifier ) ;
//D4200212    strEventParameter[nLen  ].parameterName  = CIMFWStrDup("ZONE_ID") ;
//D4200212    strEventParameter[nLen++].parameterValue = CIMFWStrDup( zoneID ) ;
//D4200212    eventLog_Put(strEventParameter, strObjCommonIn, retVal->strResult);
//D9000007 add start
    if (retVal->strXferLot.length() > 0 )
    {
        CORBA::ULong strPortIDLen= 0;
        CORBA::ULong strCastIDLen= 0;
        //Calculate the length of the string
        CORBA::ULong count = 0;
        for ( count = 0; count < retVal->strXferLot.length(); count++ )
        {
            strPortIDLen += 1 + CIMFWStrLen( retVal->strXferLot[count].portID.identifier );
            strCastIDLen += 1 + CIMFWStrLen( retVal->strXferLot[count].cassetteID.identifier );
        }
        char* strPortID = CORBA::string_alloc( strPortIDLen  + 1 ) ;
        char* strCastID = CORBA::string_alloc( strCastIDLen  + 1 ) ;
        strPortID[0]  = '\0';
        strCastID[0]  = '\0';
        for ( count = 0; count < retVal->strXferLot.length(); count++ )
        {
            CIMFWStrCat( strPortID, (const char *)retVal->strXferLot[count].portID.identifier );
            CIMFWStrCat( strCastID, (const char *)retVal->strXferLot[count].cassetteID.identifier );
            CIMFWStrCat( strPortID, "," ) ;
            CIMFWStrCat( strCastID, "," ) ;
        }
        CORBA::ULong nLen = strEventParameter.length();
        strEventParameter.length( nLen + 2 );
        strEventParameter[nLen].parameterName    = CIMFWStrDup( "PORT_ID");
        strEventParameter[nLen++].parameterValue = strPortID;
        strEventParameter[nLen].parameterName    = CIMFWStrDup( "CAST_ID") ;
        strEventParameter[nLen].parameterValue   = strCastID;
    }
//D9000007 add end
//INN-R170003        PPT_METHODTRACE_EXIT("PPTServiceManager_i:: TxLotCassetteXferStatusChangeRpt__160");
        PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i:: TxLotCassetteXferStatusChangeRpt__160"); //INN-R170003
    PPT_PARMTRACE_VERBOSE1(*retVal);    //D4100014
    return retVal ;
}
