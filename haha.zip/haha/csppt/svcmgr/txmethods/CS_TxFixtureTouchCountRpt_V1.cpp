#ifndef lint
static char *sccsid =  "@(#) 1.1 /superpos/src/csppt/source/posppt/svcmgr/txmethods/CS_TxFixtureTouchCountRpt.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:51:36 [ 7/13/07 21:51:36 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: CS_TxFixtureTouchCountRpt.cpp
//

#include "cs_pptsm.hpp"
#include "pptenv.hpp"          
#include "spfunc.hpp"  
#include "ppteventlog.hpp"     
// Class: PPTServiceManager
//
// Service: CS_TxFixtureTouchCountRpt()
//
// Change history:
// Date       Defect#       Person          Comments
// ---------- --------      --------------  -------------------------------------------
// 2017/09/04 INN-R170006   YangXigang      for fixture

// Description:
//<Method Summary>

//</Method Summary>

//<MRM>

//</MRM>
//
// Return:
//     csFixtureTouchCountRptResult
//
// Parameter:
//
//     const pptUser&                   requestUserID
//     csFixtureTouchCountRptInParm&    strFixtureTouchCountRptInParm
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//Sample code:
//<Sample Code>

//</Sample Code>
//
//<Method Start>

#define  TRANSACTION_ID "CSPDC005"
csFixtureTouchCountRptResult* CS_PPTServiceManager_i:: CS_TxFixtureTouchCountRpt (
    const pptUser&                          requestUserID,
    const csFixtureTouchCountRptInParm&     strFixtureTouchCountRptInParm
    CORBAENV_LAST_CPP)
{
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i:: CS_TxFixtureTouchCountRpt ");
    CS_PPT_PARMTRACE_VERBOSE2(requestUserID,strFixtureTouchCountRptInParm);
    
    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
    csFixtureTouchCountRptResult *retVal = new csFixtureTouchCountRptResult;
    
    pptEventParameterSequence strEventParameter ;
    objCalendar_GetCurrentTimeDR_out strCalendar_GetCurrentTimeDR_out ;
    pptObjCommonIn strObjCommonIn ;
    
    CORBA::Long rc = 0 ;
    
    // Initialising strObjCommonIn's first two parameters
    strObjCommonIn.transactionID = CIMFWStrDup(TRANSACTION_ID) ;
    strObjCommonIn.strUser = requestUserID ;

    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;
    
    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp =
                       strObjCommonIn.strTimeStamp.reportTimeStamp;

    CORBA::Long     nLen = strEventParameter.length() ;
    strEventParameter.length( nLen + 3 ) ;
    
    strEventParameter[nLen].parameterName  =  CIMFWStrDup("FIXTR_ID") ;
    strEventParameter[nLen].parameterValue =  CIMFWStrDup(strFixtureTouchCountRptInParm.fixtureID.identifier) ;
    
    strEventParameter[nLen+1].parameterName = CIMFWStrDup("IN_TCH") ;
    strEventParameter[nLen+1].parameterValue =  CIMFWStrDup(ConvertLongtoString(strFixtureTouchCountRptInParm.strFixtureTouchCountInfo.touchCount)) ;
    
    strEventParameter[nLen+2].parameterName = CIMFWStrDup("IN_ACCUM_TCH") ;
    strEventParameter[nLen+2].parameterValue =  CIMFWStrDup(ConvertLongtoString(strFixtureTouchCountRptInParm.strFixtureTouchCountInfo.accumTouchCount)) ;
    
    PPTEVENTLOG( retVal, &strObjCommonIn, &strEventParameter );

    CREATE_TX_OBJ

    TX_BEGIN(calendar_GetCurrentTimeDR)
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn) ;
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp ;
        strObjCommonIn.strUser.functionID = CIMFWStrDup(TRANSACTION_ID) ;  
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "calendar_GetCurrentTimeDR() rc != RC_OK", rc);
        TX_ROLLBACK(calendar_GetCurrentTimeDR)
        retVal->strResult = strCalendar_GetCurrentTimeDR_out.strResult ;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

        return retVal ;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR)

    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummy;
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

    TX_BEGIN(txPrivilegeCheckReq)
    try
    {
        rc = theCS_PPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult,strObjCommonIn,dummy,dummy,dummyIDs,dummyIDs,dummyIDs,dummyIDs); 
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "txPrivilegeCheckReq() rc != RC_OK", rc)
        TX_ROLLBACK(txPrivilegeCheckReq)
        retVal->strResult = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq)   

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/

    TX_BEGIN(cs_txFixtureTouchCountRpt)

    try
    {
        rc = theCS_PPTManager->cs_txFixtureTouchCountRpt(*retVal, strObjCommonIn, strFixtureTouchCountRptInParm, IT_env) ;
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(cs_txFixtureTouchCountRpt)
    if (rc == RC_OK)
    {
        PPT_METHODTRACE_V2("", "cs_txFixtureTouchCountRpt() rc == RC_OK", rc);
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(cs_txFixtureTouchCountRpt)
    }
    else
    {
        PPT_METHODTRACE_V2("", "cs_txFixtureTouchCountRpt() rc != RC_OK", rc)
        TX_ROLLBACK(cs_txFixtureTouchCountRpt)
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

        return retVal;
    }

    
    /*-----------------------------------------------------------------------*/
    /*   Post Process                                                        */
    /*-----------------------------------------------------------------------*/
    
    strEventParameter.length( nLen + 2 ) ;
       
    strEventParameter[nLen+1].parameterName = CIMFWStrDup("IN_TCH") ;
    strEventParameter[nLen+1].parameterValue =  CIMFWStrDup(ConvertLongtoString(strFixtureTouchCountRptInParm.strFixtureTouchCountInfo.touchCount)) ;
    
    strEventParameter[nLen+2].parameterName = CIMFWStrDup("IN_ACCUM_TCH") ;
    strEventParameter[nLen+2].parameterValue =  CIMFWStrDup(ConvertLongtoString(strFixtureTouchCountRptInParm.strFixtureTouchCountInfo.accumTouchCount)) ;
    
    PPTEVENTLOG_SET( retVal, &strObjCommonIn, &strEventParameter );
    
    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;
    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i:: cs_txFixtureTouchCountRpt ");
    CS_PPT_PARMTRACE_VERBOSE1(*retVal);    
    return retVal ;
}