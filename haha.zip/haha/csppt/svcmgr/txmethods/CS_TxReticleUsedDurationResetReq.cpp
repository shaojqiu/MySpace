#ifndef lint
static char *sccsid =  "@(#) 1.1 /superpos/src/csppt/source/posppt/svcmgr/txmethods/CS_TxReticleUsedDurationResetReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:51:36 [ 7/13/07 21:51:36 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: CS_TxReticleUsedDurationResetReq.cpp
//

#include "cs_pptsm.hpp"
#include "pptenv.hpp"          
#include "spfunc.hpp"  
#include "ppteventlog.hpp"     
// Class: PPTServiceManager
//
// Service: CS_TxReticleUsedDurationResetReq()
//
// Change history:
// Date       Defect#       Person          Comments
// ---------- --------      --------------  -------------------------------------------
// 2017/09/04 INN-R170003   Helios Zhen     Durable Management Enhancement

// Description:
//<Method Summary>

//</Method Summary>

//<MRM>

//</MRM>
//
// Return:
//     csReticleUsedDurationResetReqResult
//
// Parameter:
//
//     const pptUser& requestUserID
//     const objectIdentifier& reticleID
//	   const char *            claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//Sample code:
//<Sample Code>

//</Sample Code>
//
//<Method Start>

#define  TRANSACTION_ID "CSPDC004"
csReticleUsedDurationResetReqResult* CS_PPTServiceManager_i:: CS_TxReticleUsedDurationResetReq (
    const pptUser&              requestUserID, //<i>R/Request User ID 
    const objectIdentifier&     reticleID,  //<i>R/reticleID
    const char *                claimMemo //<i>O/Claim Memo
    CORBAENV_LAST_CPP)                    //<i>O/IT Environment        
{
    CS_PPT_METHODPARMTRACELOG_FILTER(requestUserID.clientNode, requestUserID.userID.identifier);    
    PPT_METHODTRACE_ENTRY("CS_PPTServiceManager_i:: CS_TxReticleUsedDurationResetReq ");
    CS_PPT_PARMTRACE_VERBOSE2(requestUserID,reticleID);    
    /*-----------------------------------------------------------------------*/
    /*   Pre Process                                                         */
    /*-----------------------------------------------------------------------*/
    csReticleUsedDurationResetReqResult* retVal = new csReticleUsedDurationResetReqResult;
	pptEventParameterSequence strEventParameter ;
    objCalendar_GetCurrentTimeDR_out strCalendar_GetCurrentTimeDR_out ;
    pptObjCommonIn strObjCommonIn ;
    
    CORBA::Long rc = 0 ;
    
    // Initialising strObjCommonIn's first two parameters
    strObjCommonIn.transactionID = CIMFWStrDup(TRANSACTION_ID) ;
    strObjCommonIn.strUser = requestUserID ;

    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;
    
    strObjCommonIn.strTimeStamp.reportTimeStamp = getTimeStamp();
    strCalendar_GetCurrentTimeDR_out.strTimeStamp.reportTimeStamp =
                       strObjCommonIn.strTimeStamp.reportTimeStamp;

    CORBA::Long     nLen = strEventParameter.length() ;
    strEventParameter.length( nLen + 1 ) ;
    strEventParameter[nLen].parameterName = CIMFWStrDup("RTCL_ID") ;
    strEventParameter[nLen].parameterValue =  CIMFWStrDup( reticleID.identifier ) ;
    PPTEVENTLOG( retVal, &strObjCommonIn, &strEventParameter );

    CREATE_TX_OBJ

    TX_BEGIN(calendar_GetCurrentTimeDR)
    try
    {
        rc = theCS_PPTManager->calendar_GetCurrentTimeDR(strCalendar_GetCurrentTimeDR_out,strObjCommonIn) ;
        strObjCommonIn.strTimeStamp = strCalendar_GetCurrentTimeDR_out.strTimeStamp ;
        strObjCommonIn.strUser.functionID = CIMFWStrDup(TRANSACTION_ID) ;  
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(calendar_GetCurrentTimeDR)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "calendar_GetCurrentTimeDR() rc != RC_OK", rc);
        TX_ROLLBACK(calendar_GetCurrentTimeDR);
        retVal->strResult = strCalendar_GetCurrentTimeDR_out.strResult ;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

        return retVal ;
    }
    TX_COMMIT(calendar_GetCurrentTimeDR);

    pptPrivilegeCheckReqResult strPrivilegeCheckReqResult;
    objectIdentifier dummy;
    objectIdentifierSequence dummyIDs;
    dummyIDs.length(0);

    TX_BEGIN(txPrivilegeCheckReq)
    try
    {
        rc = theCS_PPTManager->txPrivilegeCheckReq(strPrivilegeCheckReqResult,strObjCommonIn,dummy,dummy,dummyIDs,dummyIDs,dummyIDs,dummyIDs); 
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(txPrivilegeCheckReq)

    if (rc != RC_OK)
    {
        PPT_METHODTRACE_V2("", "txPrivilegeCheckReq() rc != RC_OK", rc);
        TX_ROLLBACK(txPrivilegeCheckReq);
        retVal->strResult = strPrivilegeCheckReqResult.strResult;
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

        return retVal;
    }
    TX_COMMIT(txPrivilegeCheckReq)

    /*-----------------------------------------------------------------------*/
    /*   Main Process                                                        */
    /*-----------------------------------------------------------------------*/

    TX_BEGIN(cs_txReticleUsedDurationResetReq)

    try
    {
        rc = theCS_PPTManager->cs_txReticleUsedDurationResetReq(*retVal, strObjCommonIn, reticleID, claimMemo) ;
    }
    CATCH_TX_TIMEOUT_EXCEPTIONS(cs_txReticleUsedDurationResetReq)
    if (rc == RC_OK)
    {
        PPT_METHODTRACE_V2("", "cs_txReticleUsedDurationResetReq() rc == RC_OK", rc);
        PPT_SET_TX_MSG((*retVal), MSG_OK, RC_OK);
        TX_COMMIT(cs_txReticleUsedDurationResetReq);
    }
    else
    {
        PPT_METHODTRACE_V2("", "cs_txReticleUsedDurationResetReq() rc != RC_OK", rc);
        TX_ROLLBACK(cs_txReticleUsedDurationResetReq);
        retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;

        return retVal;
    }

    
    /*-----------------------------------------------------------------------*/
    /*   Post Process                                                        */
    /*-----------------------------------------------------------------------*/

    retVal->strResult.transactionID = CIMFWStrDup(TRANSACTION_ID) ;


    PPT_METHODTRACE_EXIT("CS_PPTServiceManager_i:: CS_TxReticleUsedDurationResetReq ");
    CS_PPT_PARMTRACE_VERBOSE1(*retVal);    
    return retVal ;
}
