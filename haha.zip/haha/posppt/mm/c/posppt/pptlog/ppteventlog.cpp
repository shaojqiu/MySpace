#ifndef lint
static char *sccsid =  "@(#) 1.3 superpos/src/spppt/source/posppt/pptlog/ppteventlog.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/4/08 14:47:34 [ 7/4/08 14:47:35 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SuperPOSEIDON
// Name: pptevlog.cpp
//
// Change history:
//
// Date     Defect#  Person         Comments
// -------- -------- -------------- -------------------------------------------
// 01/12/01          Yamaguchi      Newly created
// 02/10/21 D4200138 C.Tsuchiya     Remove debug code 
// 02/12/26 P4200476 K.Kido         Fix : Memory fault (BFCP) in sendMessage().
// 03/08/11 D5000201 H.Adachi       Add Host Name and Server Name for R5.0(HAS)
// 09/15/04 D6000025 K.Murakami     TIE was deleted in order to make it TIE to BOA.
// 11/30/04 D6000025 S.Yamamoto     eBroker migration
// 12/05/07 P9000107 K.Kido         Mutex lock required.
// 07/02/08 P9000360 K.Kido         check log buffer length.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009/08/05 DSIV00001249 K.Yamaoku      Improvement of Timestamp for Logging.
// 2009/11/04 DSIV00001481 K.Yamaoku      Add getTimeStamp method
// 2012/01/24 DSN000030296 K.Yamaoku      Support thread ID which is longer than 8 digit
// 2012/09/11 DSN000052888 M.Nakano       Trace log improvement.
// 2013/07/29 DSN000079252 S.Yamamoto    Support override PPTEventLog.
// 2016/11/18 PSN000103788 K.Yamaoku      When PPTEVENTLOG is performed in smallTx, MMS is hung up
//

#ifndef EXCEPTIONS
#define EXCEPTIONS
#endif

#include <stdio.h>
//DSIV00001481 #include <timeb.h>
//DSIV00001481 #include <time.h>
#include <pthread.h>
#include "eventlogmgr.hpp"
#include "ppteventlog.hpp"
#include "splock.hpp"     //P9000107
#include "spmutex.hpp"    //P9000107
#include "pptmacros.hpp"  //DSIV00001481
#include "posconst.hpp"   //DSIV00001481

#include "bufferedlogger_kicker_mm.hpp"  //DSN000052888

#ifdef EBROKER      //D6000025
#include "IMProt.h" //D6000025
#endif              //D6000025

DEFINE_SPFW_CURRENT_TIMESTAMP_LOCAL_FUNCTION( getCurrentTimeLocal ) //DSIV00001481

EventLogManager_var theEventLogManager;
SPMutex theEventLogGlobalMutexObject;    //P9000107

//DSN000079252 PPTEventLog::PPTEventLog()
PPTEventLog::PPTEventLog() : PPTEventLogBase() //DSN000079252
{
    // initialize data members
    theRetVal       = NULL;
    theObjCommonIn  = NULL;
    theParms        = NULL;
}

//DSN000079252 PPTEventLog::PPTEventLog(void *retVal, pptObjCommonIn *objCommonIn, pptEventParameterSequence *parms)
PPTEventLog::PPTEventLog(void *retVal, pptObjCommonIn *objCommonIn, pptEventParameterSequence *parms) : PPTEventLogBase(retVal,objCommonIn,parms) //DSN000079252
{
    // keep pointers of parameters for outgoing message
    theRetVal      = retVal;
    theObjCommonIn = objCommonIn;
    theParms       = parms;

    // get current timestamp with millisecond
//DSIV00001481    //DSIV00001249 struct timeb tp ;
//DSIV00001481    struct timeval tv;    //DSIV00001249
//DSIV00001481    struct tm tm;
//DSIV00001481    //DSIV00001249 ftime( &tp) ;
//DSIV00001481    //DSIV00001249 localtime_r( &tp.time, &tm );
//DSIV00001481    gettimeofday( &tv, NULL );      //DSIV00001249
//DSIV00001481    localtime_r( &tv.tv_sec, &tm ); //DSIV00001249
//DSIV00001481
//DSIV00001481    char _strtimestamp[27];
//DSIV00001481    //DSIV00001249 sprintf( _strtimestamp, "%04d-%02d-%02d-%02d.%02d.%02d.%03d000",
//DSIV00001481    //DSIV00001249          tm.tm_year+1900,tm.tm_mon+1,tm.tm_mday,tm.tm_hour,tm.tm_min,tm.tm_sec,tp.millitm);
//DSIV00001481    sprintf( _strtimestamp, "%04d-%02d-%02d-%02d.%02d.%02d.%06d",                               //DSIV00001249
//DSIV00001481             tm.tm_year+1900,tm.tm_mon+1,tm.tm_mday,tm.tm_hour,tm.tm_min,tm.tm_sec,tv.tv_usec); //DSIV00001249
//DSIV00001481
//DSIV00001481    theStartTime = strdup(_strtimestamp);
    theStartTime = getTimeStamp(); //DSIV00001481

    if ( CORBA::is_nil(theEventLogManager) )
    {
        // mutex lock required here
        SPLock lockobj (&theEventLogGlobalMutexObject);    //P9000107

        if ( CORBA::is_nil(theEventLogManager) )
        {
#ifdef MO_BOA   //D6000025 
            theEventLogManager =
               new EventLogManager_i() ;   //D6000025
#else   //D6000025
            theEventLogManager =
               new TIE_EventLogManager(EventLogManager_i)(new EventLogManager_i) ;
#endif  //D6000025
        }
    }

//DSN000079252    // incoming message 
//DSN000079252    sendMessage( INCOMING );
}

PPTEventLog::~PPTEventLog()
{
//DSN000079252    // outgoing message
//DSN000079252    sendMessage( OUTGOING );

}

void PPTEventLog::resetParameters(void *retVal, pptObjCommonIn *objCommonIn, pptEventParameterSequence *parms)
{
    // keep pointers of parameters for outgoing message
    theRetVal      = retVal;
    theObjCommonIn = objCommonIn;
    theParms       = parms;
}

void PPTEventLog::sendMessage( EVENTLOGTYPE type )
{
    //D4200138 cout << "entering PPTEventLog::sendMessage" << endl;

    char aBuffer[32768];
    char aCommonInBuffer[256];
    char aResultBuffer[32768];

    pptRetCode *theResult = (pptRetCode*)theRetVal;

    try
    {
        CORBA::String_var currentTime;

        aCommonInBuffer[0] = NULL;
        if ( theObjCommonIn != NULL )
        {
//P9000360  strcat(aCommonInBuffer,theObjCommonIn->transactionID);
//P9000360  strcat(aCommonInBuffer,"|");
//P9000360  strcat(aCommonInBuffer,theObjCommonIn->strUser.functionID);
//P9000360  strcat(aCommonInBuffer,"|");
//P9000360  strcat(aCommonInBuffer,theObjCommonIn->strUser.userID.identifier);
//P9000360  strcat(aCommonInBuffer,"|");
//P9000360  strcat(aCommonInBuffer,theObjCommonIn->strUser.clientNode);
//P9000360 add start
            snprintf( aCommonInBuffer, sizeof(aCommonInBuffer),
                      "%s|%s|%s|%s",
                      (theObjCommonIn->transactionID             == NULL) ? "" : (const char*)theObjCommonIn->transactionID,
                      (theObjCommonIn->strUser.functionID        == NULL) ? "" : (const char*)theObjCommonIn->strUser.functionID,
                      (theObjCommonIn->strUser.userID.identifier == NULL) ? "" : (const char*)theObjCommonIn->strUser.userID.identifier,
                      (theObjCommonIn->strUser.clientNode        == NULL) ? "" : (const char*)theObjCommonIn->strUser.clientNode
                    );
//P9000360 add end
        }
        else
        {
            strcat(aCommonInBuffer,"|");
            strcat(aCommonInBuffer,"|");
            strcat(aCommonInBuffer,"|");
        }

        aResultBuffer[0] = NULL;
        if ( type == INCOMING )
        {
            strcpy(aResultBuffer, "Incoming");
            currentTime = strdup(theStartTime);
        }
        else if ( type == OUTGOING )
        {
            if ( theResult->returnCode != NULL )
            {
                strcpy(aResultBuffer, theResult->returnCode);
                // DSN000052888 add start
                if(kickermm != NULL)
                {
                    kickermm->checkAtEnd("",theResult->returnCode);
                }
                // DSN000052888 add end
            }

            // getting current timestamp
//DSIV00001481            //DSIV00001249 struct timeb tp ;
//DSIV00001481            struct timeval tv;    //DSIV00001249
//DSIV00001481            struct tm tm;
//DSIV00001481            //DSIV00001249 ftime( &tp) ;
//DSIV00001481            //DSIV00001249 localtime_r( &tp.time, &tm );
//DSIV00001481            gettimeofday( &tv, NULL );      //DSIV00001249
//DSIV00001481            localtime_r( &tv.tv_sec, &tm ); //DSIV00001249
//DSIV00001481
//DSIV00001481            char _strtimestamp[27];
//DSIV00001481            //DSIV00001249 sprintf( _strtimestamp, "%04d-%02d-%02d-%02d.%02d.%02d.%03d000",
//DSIV00001481            //DSIV00001249     tm.tm_year+1900,tm.tm_mon+1,tm.tm_mday,tm.tm_hour,tm.tm_min,tm.tm_sec,tp.millitm);
//DSIV00001481            sprintf( _strtimestamp, "%04d-%02d-%02d-%02d.%02d.%02d.%06d",                          //DSIV00001249
//DSIV00001481                tm.tm_year+1900,tm.tm_mon+1,tm.tm_mday,tm.tm_hour,tm.tm_min,tm.tm_sec,tv.tv_usec); //DSIV00001249
//DSIV00001481
//DSIV00001481            currentTime = strdup(_strtimestamp);
            currentTime = getTimeStamp(); //DSIV00001481
        }
        strcat(aResultBuffer,"|");
//      if ( theResult->returnCode != NULL )    //P4200476
        if ( theResult->messageText != NULL )   //P4200476
        {
//P9000360  strcat(aResultBuffer,theResult->messageText);
//P9000360 add start
            char aTmpResultBuffer[1024*32];   // 1024*32 = 32768
            aTmpResultBuffer[0] = NULL;
            snprintf( aTmpResultBuffer, sizeof(aTmpResultBuffer),
                      "%s%s",
                      aResultBuffer,
                      (const char*)theResult->messageText
                    );
            strcpy(aResultBuffer,aTmpResultBuffer);    // aResultBuffer size == aTmpResultBuffer size
//P9000360 add end
        }

        // make text for event log common part
//D5000201        sprintf( aBuffer,
//D5000201                 "%s|%s|%06d(%06d)|%s|%s|",

//P9000360        sprintf( aBuffer,                                                  //D5000201
//P9000360 add start
        snprintf( aBuffer, sizeof(aBuffer),
//P9000360 add end
//DSN000030296                 "%s|%s|%s:%s:%06d(%06d)|%s|%s|",                          //D5000201
                 "%s|%s|%s:%s:%06ld(%06u)|%s|%s|",                          //DSN000030296
                 (const char*)theStartTime,
                 (const char*)currentTime,
#ifdef EBROKER //D6000025
                 ::IMRegistry::HostName,   //D6000025
                 ::IMRegistry::ServerName, //D6000025
#else          //D6000025
                 (const char*)CORBA::Orbix.myHost(),                       //D5000201 Host Name
                 (const char*)CORBA::Orbix.myServer(),                     //D5000201 Server Name
#endif         //D6000025
//DSN000030296                 (int)thread_self(),
//DSN000030296                 (int)pthread_self(),
                 thread_self(),   //DSN000030296
                 pthread_self(),  //DSN000030296
                 aCommonInBuffer,
                 aResultBuffer );

        // make text for parameters
        if ( theParms != NULL )
        {
            for( unsigned int i=0, n=theParms->length(); i<n; i++ )
            {
                if ( strlen(aBuffer) < (sizeof(aBuffer)/2) )
                {
//P9000360          strcat(aBuffer,(*theParms)[i].parameterName);
//P9000360          strcat(aBuffer,"=");
//P9000360          strcat(aBuffer,(*theParms)[i].parameterValue);
//P9000360 add start
                    char aTmpBuf[1024*32];
                    aTmpBuf[0] = NULL;
                    snprintf( aTmpBuf, (sizeof(aTmpBuf) - strlen(aTmpBuf) -1 ),
                              "%s=%s",
                              ((*theParms)[i].parameterName == NULL) ? "" : (const char*)(*theParms)[i].parameterName,
                              ((*theParms)[i].parameterValue == NULL) ? "" : (const char*)(*theParms)[i].parameterValue
                            );
//P9000360 add end
                    if ( i+1 < n )
                    {
//P9000360              strcat(aBuffer,",");
                        strncat(aTmpBuf,",", (sizeof(aTmpBuf) - strlen(aTmpBuf) -1) );    //P9000360
                    }
                    strncat(aBuffer, aTmpBuf, (sizeof(aBuffer) - strlen(aBuffer) -1) );    //P9000360
                }
            }
        }

        // make text for return message
//P9000360        strcat( aBuffer, "|" ) ;
        strncat(aBuffer,"|",(sizeof(aBuffer) - strlen(aBuffer) -1));    //P9000360

        if ( theResult->reasonText != NULL )
        {
//P9000360  if ( strlen(theResult->reasonText)+strlen(aBuffer) < sizeof(aBuffer) )
            if ( strlen(theResult->reasonText)+strlen(aBuffer)+1 < sizeof(aBuffer) )    //P9000360
            {
                strcat( aBuffer, theResult->reasonText ) ;
            }
        }

        // send event log to event log server object
        if ( !CORBA::is_nil(theEventLogManager) )
        {
            theEventLogManager->putLog( aBuffer );
        }

    } 
    catch(CORBA::SystemException &se) 
    {
        cout << "PPTEventLog::sendMessage" << "caught CORBA::SystemException exception, minor=" << se.minor() << endl;
    }
    catch(...) 
    {
        cout << "PPTEventLog::sendMessage" << "caught unknown exception" << endl;
    }

    return ;
}

//DSIV00001481 add start
char * PPTEventLog::getTimeStamp ()
{
    char* retVal = NULL;

    CORBA::Long tmpUseDBTimeStamp = atoi( getenv(SP_USE_DB_TIMESTAMP) );

    if( tmpUseDBTimeStamp != 0 )
    {
        SPFW_TRACE_VERBOSE1( "Time stump is get from DB." );

//PSN000103788 add start
        tran_tid_t tranTID = TRAN_TID_NULL;
        try
        {
            tranTID = threadTid_Lookup();
        }
        catch(...)
        {
            APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ();
            SPFW_TRACE_VERBOSE3( "", "threadTid_Lookup", "caught exception" );
            return getCurrentTimeLocal();
        }
        if (TRAN_TID_NULL == tranTID)
        {
            SPFW_TRACE_VERBOSE1( "TX_BEGIN: getTimeStamp" );
//PSN000103788 add end
            try
            {
                costransactions_current_begin("getTimeStamp");
            }
            catch ( CosTransactions::SubtransactionsUnavailable& ex)
            {
                APPERRLOG_USEREXCEPTION_FOR_PUREOBJ(ex);
                SPFW_TRACE_VERBOSE3( "BEGIN", "The geting error of DB time stump", "SubtransactionsUnavailable" );
                return getCurrentTimeLocal();
            }
            catch ( CosTransactions::TransactionRolledBack& ex)
            {
                APPERRLOG_USEREXCEPTION_FOR_PUREOBJ(ex);
                SPFW_TRACE_VERBOSE3( "BEGIN", "The geting error of DB time stump", "TransactionRolledBack" );
                return getCurrentTimeLocal();
            }
            catch (const CORBA::TRANSACTION_ROLLEDBACK& SysEx)
            {
                APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
                SPFW_TRACE_VERBOSE3( "BEGIN", "The geting error of DB time stump", "TRANSACTION_ROLLEDBACK" );
                return getCurrentTimeLocal();
            }
            catch (const CORBA::SystemException& SysEx)
            {
                APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
                try
                {
                    costransactions_current_rollback("getTimeStamp");
                }
                catch(...)
                {
                }
                SPFW_TRACE_VERBOSE3( "BEGIN", "The geting error of DB time stump", "SystemException" );
                return getCurrentTimeLocal();
            }
            catch (FrameworkErrorSignal& fex)
            {
                APPERRLOG_FRAMEWORKERRORSIGNAL_FOR_PUREOBJ(fex);
                try
                {
                    costransactions_current_rollback("getTimeStamp");
                }
                catch(...)
                {
                }
                SPFW_TRACE_VERBOSE3( "BEGIN", "The geting error of DB time stump", "FrameworkErrorSignal" );
                return getCurrentTimeLocal();
            }
            catch (...)
            {
                APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ();
                try
                {
                    costransactions_current_rollback("getTimeStamp");
                }
                catch(...)
                {
                }
                SPFW_TRACE_VERBOSE3( "BEGIN", "The geting error of DB time stump", "UNKNOWN_EXCEPTION" );
                return getCurrentTimeLocal();
            }
        } //PSN000103788

        retVal = ::getTimeStamp();

//PSN000103788 add start
        if (TRAN_TID_NULL == tranTID)
        {
            SPFW_TRACE_VERBOSE1( "TX_COMMIT: getTimeStamp" );
//PSN000103788 add end
            try
            {
                costransactions_current_commit("getTimeStamp");
            }
            catch ( CosTransactions::TransactionRolledBack& ex)
            {
                APPERRLOG_USEREXCEPTION_FOR_PUREOBJ(ex);
                SPFW_TRACE_VERBOSE3( "COMMIT", "The geting error of DB time stump", "TransactionRolledBack" );
            }
            catch ( CosTransactions::NoTransaction& ex)
            {
                APPERRLOG_USEREXCEPTION_FOR_PUREOBJ(ex);
                SPFW_TRACE_VERBOSE3( "COMMIT", "The geting error of DB time stump", "NoTransaction" );
            }
            catch ( CosTransactions::HeuristicMixed& ex)
            {
                APPERRLOG_USEREXCEPTION_FOR_PUREOBJ(ex);
                SPFW_TRACE_VERBOSE3( "COMMIT", "The geting error of DB time stump", "HeuristicMixed" );
            }
            catch ( CosTransactions::HeuristicHazard& ex)
            {
                APPERRLOG_USEREXCEPTION_FOR_PUREOBJ(ex);
                SPFW_TRACE_VERBOSE3( "COMMIT", "The geting error of DB time stump", "HeuristicHazard" );
            }
            catch (const CORBA::TRANSACTION_ROLLEDBACK& SysEx)
            {
                APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
                SPFW_TRACE_VERBOSE3( "COMMIT", "The geting error of DB time stump", "TRANSACTION_ROLLEDBACK" );
            }
            catch (const CORBA::SystemException& SysEx)
            {
                APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
                try
                {
                    costransactions_current_rollback("getTimeStamp");
                }
                catch(...)
                {
                }
                SPFW_TRACE_VERBOSE3( "COMMIT", "The geting error of DB time stump", "SystemException" );
            }
            catch (FrameworkErrorSignal& fex)
            {
                APPERRLOG_FRAMEWORKERRORSIGNAL_FOR_PUREOBJ(fex);
                try
                {
                    costransactions_current_rollback("getTimeStamp");
                }
                catch(...)
                {
                }
                SPFW_TRACE_VERBOSE3( "COMMIT", "The geting error of DB time stump", "FrameworkErrorSignal" );
            }
            catch (...)
            {
                APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ();
                try
                {
                    costransactions_current_rollback("getTimeStamp");
                }
                catch(...)
                {
                }
                SPFW_TRACE_VERBOSE3( "COMMIT", "The geting error of DB time stump", "UNKNOWN_EXCEPTION" );
            }
        } //PSN000103788
    }
    else
    {
        SPFW_TRACE_VERBOSE1( "Time stump is get from AIX." );
        retVal = ::getTimeStamp();
    }

    return retVal;
}
//DSIV00001481 add end

//DSN000079252 add start

//default

//ctor
PPTEventLogDefault::PPTEventLogDefault() : PPTEventLog()
{
}

PPTEventLogDefault::PPTEventLogDefault( void *retVal, pptObjCommonIn *objCommonIn, pptEventParameterSequence *parms ) : PPTEventLog( retVal, objCommonIn, parms )
{
    // incoming message 
    sendMessage( INCOMING );
}

//dtor
PPTEventLogDefault::~PPTEventLogDefault()
{
    // outgoing message
    sendMessage( OUTGOING );
}

//ctor
PPTEventLogBase_var::PPTEventLogBase_var()
{
	_ptr = NULL;
}

PPTEventLogBase_var::PPTEventLogBase_var(PPTEventLogBase *param)
{
	_ptr = param;
}

//dtor
PPTEventLogBase_var::~PPTEventLogBase_var()
{
	if(_ptr)
	{
		delete _ptr;
		_ptr = NULL;
	}
}

//operator=
PPTEventLogBase_var& PPTEventLogBase_var::operator=( PPTEventLogBase *param )
{
	if(_ptr)
	{
		delete _ptr;
	}
	_ptr = param;
	
	return *this;
}

//operator->
PPTEventLogBase* PPTEventLogBase_var::operator->()
{
	return _ptr;
}

//operator PPTEventLogBase&
PPTEventLogBase_var::operator PPTEventLogBase&()
{
	return *_ptr;
}


//Current CreateEventLogObjectFunction pointer.
PPTEventLogFactory::PCreateEventLogFunction PPTEventLogFactory::pCreateEventLogFunction = PPTEventLogFactory::defaultCreateEventLogFunction;

//ctor
PPTEventLogFactory::PPTEventLogFactory()
{
}

//dtor
PPTEventLogFactory::~PPTEventLogFactory()
{
}

//API for applications
PPTEventLogBase* PPTEventLogFactory::createEventLogObject( void *retVal, pptObjCommonIn *objCommonIn, pptEventParameterSequence *parms )
{
	return (*pCreateEventLogFunction) ( retVal, objCommonIn, parms );
}

//registration of CreateEventLogObject function
bool PPTEventLogFactory::registCreateEventLogFunction( PPTEventLogFactory::PCreateEventLogFunction function )
{
	if( function )
	{
		pCreateEventLogFunction = function;
		return true;
	}
	else
	{
		return false;
	}
}

//default CreateEventLogObject function
PPTEventLogBase* PPTEventLogFactory::defaultCreateEventLogFunction( void *retVal, pptObjCommonIn *objCommonIn, pptEventParameterSequence *parms )
{
	return new PPTEventLogDefault( retVal, objCommonIn, parms );
}

//DSN000079252 add end
