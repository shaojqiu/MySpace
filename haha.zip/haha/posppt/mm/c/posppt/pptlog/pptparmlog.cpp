#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptlog/pptparmlog.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 22:54:54 [ 7/13/07 22:54:55 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// Siview - ParameterLogGen
// Name: pptparmlog.cpp
//
// Change history:
//
// Date     Defect#  Person         Comments
// -------- -------- -------------- -------------------------------------------
// 12/21/01 D4100017 Y.Yamaguchi    Newly created.
// 06/20/02 P4100583 Y.Yamaguchi    Delete cout statement
// 11/04/04 D6000025 K.Murakami     Change any to Any for eBrokerMigration.
// 11/30/04 D6000025 S.Yamamoto     eBroker migration
// -------- ------------ ------------- ----------------------------------------------
// 29/07/13 DSN000079778 S.Yamamoto    Performance Improvement of Any
//

#include <time.h>
#include <iomanip.h>

#include "pptparmlog.hpp"

char* getSimpleFunctionName(const char* fullFunctionName)
{
//  cout << __FUNCTION__ << endl; //P4100583
    char* retVal = NULL;

    if ( fullFunctionName != NULL )
    {
        // full qualified function name:
        // c++: PPTServiceManager_i::TxEqpInfoInq(pptUser&,......)
        // c  : main(int, char**)
        retVal = strdup(fullFunctionName);

        // remove parameters
        char* es = strchr(retVal,'(');
        if ( es != NULL )
        {
            *es = NULL;
        }

    }

    return retVal;
}

PPTParameterLog::PPTParameterLog( const char* opname, const char* node, const char* user, const char* desc ) :
ParameterLog(opname, node, user, desc )
{
    #ifdef PARMLOG_DEBUG
    cout << "entering PPTParameterLog::PPTParameterLog" << endl;
    #endif
}

PPTParameterLog::~PPTParameterLog()
{
    #ifdef PARMLOG_DEBUG
    cout << "entering PPTParameterLog::~PPTParameterLog" << endl;
    #endif
}

void PPTParameterLog::outVariable( CORBA::SystemException& object, char* name )
{
    *record << setw( _indent ) << "";
    *record << name << ":(CORBA::SystemException)" << endl;
    _indent++;
    outVariable( object.minor()    , "minor"     );
    outVariable( object.id()       , "id"        );
#ifndef EBROKER //D6000025
    outVariable( object.param()    , "param"     );
#endif          //D6000025
    outVariable( object.completed(), "completed" );
    _indent--;
}

void PPTParameterLog::outVariable( const int object, char* name )
{
    *record << setw( _indent ) << "";
    *record << name << ":" << object << endl;
}

/*
void PPTParameterLog::outVariable( const unsigned long object, char* name )
{
    *record << setw( _indent ) << "";
    *record << name << ":" << object << endl;
}

void PPTParameterLog::outVariable( const double object, char* name )
{
    *record << setw( _indent ) << "";
    *record << name << ":" << object << endl;
}
*/

void PPTParameterLog::outVariable( const char* object, char* name )
{
    *record << setw( _indent ) << "";
    if( object == NULL )
        *record << name << ":" << endl;
    else
        *record << name << ":\"" << object << "\"" << endl;
}

#include "outvariable.cpp"

//DSN000079778 add start
typedef  bool (*PExtractFunc)( PPTParameterLog *paramlog, const CORBA::Any& object, char *name );
/*
#include <map>
#include <string>
static std::map<std::string,PExtractFunc> callbackFuncs;
*/
#include <strstream>
#include "pptparmlogutil.hpp"
CallBackFuncTable<PExtractFunc> callbackFuncs;

void PPTParameterLog_genJumpTable();

//static std::string getKeyFromTypeCode( const CORBA::TypeCode_ptr tc );
static char * getKeyFromTypeCode( const CORBA::TypeCode_ptr tc );
//DSN000079778 add end

//D6000025void PPTParameterLog::outVariable( const CORBA::any& object, char* name )
void PPTParameterLog::outVariable( const CORBA::Any& object, char* name )    //D6000025
{
    if( object.value() == NULL )    //0.01
    {
        *record << setw( _indent ) << "";
        *record << name << ":(any[])" << endl;
        return;
    }
    PPTParameterLog_genJumpTable(); //DSN000079778

    LOG_ANY_TYPE(CORBA::Short,short);
    LOG_ANY_TYPE(CORBA::Long,long);
    LOG_ANY_TYPE(CORBA::UShort,unsigned short);
    LOG_ANY_TYPE(CORBA::ULong,unsigned long);
    LOG_ANY_TYPE(CORBA::Float,float);
    LOG_ANY_TYPE(CORBA::Double,double);
    LOG_ANY_TYPE(char*,string);

    LOG_ANY_CHAR(CORBA::Boolean,boolean,CORBA::Any::to_boolean);
    LOG_ANY_CHAR(CORBA::Octet,octet,CORBA::Any::to_octet);
    LOG_ANY_CHAR(CORBA::Char,char,CORBA::Any::to_char);

    LOG_ANY_CLASS(stringSequence);

//DSN000079778    #include "outany.cpp"
//DSN000079778 add start
    CORBA::TypeCode_var tc = object.type();
    
//    std::string key = getKeyFromTypeCode( tc ) ;
    CORBA::String_var key = getKeyFromTypeCode( tc ) ;

//    PExtractFunc pFunc = callbackFuncs[key];
    PExtractFunc pFunc = callbackFuncs.findFunc( (const char*)key );
    if( pFunc != NULL )
    {
        if( false != (*pFunc)( this, object, name ) )
        {
            return;
        }
    }
//DSN000079778 add end

    *record << setw( _indent ) << "";
    *record << name << ":(any[unknown])" << endl;
}

//DSN000079778 add start
class _PPTParameterLog : public PPTParameterLog
{
public:
    _PPTParameterLog();//not implement
    ~_PPTParameterLog();//not implement

    ostrstream &Record() { return *record; }
    int &Indent() { return _indent; }
};

#undef LOG_ANY_CLASS
#define LOG_ANY_CLASS(x)\
static bool PPTParameterLog_extract##x( PPTParameterLog *parmlog, const CORBA::Any& object, char *name )\
    {\
        _PPTParameterLog *_paramlog = (_PPTParameterLog *)parmlog;\
        x *tobj;\
        if( object >>= tobj )\
        {\
            _paramlog->Record() << setw( _paramlog->Indent() ) << ""; \
            _paramlog->Record() << name << ":(any[" #x "])" << endl;\
            _paramlog->Indent()++;\
            parmlog->outVariable(*tobj, name);\
            _paramlog->Indent()--;\
            return true;\
        }\
        return false;\
    }

//define extract methods
#include "outany.cpp"

/*
std::string getKeyFromTypeCode( const CORBA::TypeCode_ptr ptc )
{
    std::string key = "";
    CORBA::TypeCode_ptr tc = (CORBA::TypeCode_ptr)ptc;
    CORBA::TypeCode_var _tc;//don't set tc here. ( original tc is managed by caller. )
    while(1)
    {
        while( tc->kind() == CORBA::tk_alias )
        {
            tc = tc->content_type();
            _tc = tc;
        }
        CORBA::TCKind kind = tc->kind();
        if( kind == CORBA::tk_struct )
        {
            key += tc->id();
            break;
        }
        else if( kind == CORBA::tk_sequence )
        {
            tc = tc->content_type();
            _tc = tc;
            
            key += "sequence:";
            continue;
        }
        else
        {
            char buf[64];
            buf[0] = 0;
            std::ostrstream tmps(buf,sizeof(buf)-1);
            tmps << (int)kind << std::ends;
            key += tmps.str();
            break;
        }
    }
    return key;
}
*/
char *getKeyFromTypeCode( const CORBA::TypeCode_ptr ptc )
{
    char buf[512];
    buf[0] = 0;
    std::ostrstream key(buf,sizeof(buf)-1);

    CORBA::TypeCode_ptr tc = (CORBA::TypeCode_ptr)ptc;
    CORBA::TypeCode_var _tc;//don't set tc here. ( original tc is managed by caller. )
    while(1)
    {
        while( tc->kind() == CORBA::tk_alias )
        {
            tc = tc->content_type();
            _tc = tc;
        }
        CORBA::TCKind kind = tc->kind();
        if( kind == CORBA::tk_struct )
        {
            key << tc->id();
            break;
        }
        else if( kind == CORBA::tk_sequence )
        {
            tc = tc->content_type();
            _tc = tc;
            
            key << "sequence:";
            continue;
        }
        else
        {
            key << (int)kind;
            break;
        }
    }
    key << std::ends;
    return CORBA::string_dup(key.str());
}

//register method
void PPTParameterLog_registExtractor( const char *typeName, const CORBA::TypeCode_ptr ptc, PExtractFunc func )
{
    if( ptc->kind() == CORBA::tk_struct )
    {
        callbackFuncs.set( (char*)ptc->id() , func );//for reduction of memory usage
    }
    else
    {
//    std::string key = getKeyFromTypeCode( ptc );
//    callbackFuncs[key] = func;
        char * key = getKeyFromTypeCode( ptc );
        callbackFuncs.set( key , func );
    }
}

#undef LOG_ANY_CLASS
#define LOG_ANY_CLASS(x)\
    PPTParameterLog_registExtractor(#x,_tc_##x,&PPTParameterLog_extract##x);

//generate type id vs function table for extraction
static void PPTParameterLog_generateFunctionTable()
{
    #include "outany.cpp"
}

//for initialize at 1st time only
#include <pthread.h>

static pthread_once_t PPTParameterLog_once_key = PTHREAD_ONCE_INIT;

//for external
void PPTParameterLog_genJumpTable()
{
    pthread_once( &PPTParameterLog_once_key, PPTParameterLog_generateFunctionTable );
}
//DSN000079778 add end
