#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptlog/spparmclt_command.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 22:55:04 [ 7/13/07 22:55:05 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// Siview 
// Name: spparmclt_command.cpp
//
// Change history:
//
// Date        Defect#     Person         Comments
// ----------- ----------- -------------- -------------------------------------------
// 2005/01/07  #DCR6000160 T.Ohsaki       Newly created 
// 2005/04/18  #DCR6000250 K.Murakami     Change genIOR for eBroker Migration.
// 2007/06/01  DCR9000041  S.Yamamoto     Improvement of usage message.
//
//(1) Declare global variables and a structure
//(2) Main routine
//int main(int argc , char **argv)
//{
//  1.Declare local variables.
//
//  2.Check whether "-help" option is specified.
//  if("-help" option is specified)
//  {
//      show usage;
//      show option list;
//      return 0;
//  }
//
//  3.Check the number of command line arguments.
//  if(argc <= 5)
//  {
//      show exception message;
//      show usage;
//      return 1;
//  }
//
//  4.Check the specified options and arguments.
//  for(int i=first option seq num ; i < argc ; i++)
//  {
//      if(argv[opseqnum][0] == "-")
//      {
//          4.1.Check whether the specified option corresponds with the option list.
//          if(specified option does not correspond)
//          {
//              show exception message;
//              return 1;
//          }
//          4.2.Check whether the argument is valid  for the specified option.
//          if(argument is not valid)
//          {
//              show exception message;
//              return 1;
//          }
//      }
//  }
//
//  5.Check whether the specified options are duplicated.
//  if(duplicated)
//  {
//      show exceptin message;
//      return 1;
//  }
//
//  6.Connect to server using genIOR method of IIOPHelper Class
//
//  7.Set values according to specified options
//  for(int i=0; i < the number of elements of option list array ; i++ )
//  {
//      if(optins are specified)
//      {
//          set values to settings of ParameterLevel and FilterKeywords;
//          (e.g. theParameterLogManager_var->setxxxxxxFilterKeywords(atoi(argument));)
//          if("-v" option is specified)
//          {
//              get current settings of ParameterLevel and FilterKeywords;
//              show current settings;
//          }
//      }
//  }
//  return 0;
#include <stdio.h>
#include <stdlib.h>
#include <iostream.h>
#include <string.h>
#include <unistd.h>
#include <time.h>
#include "parmlogmgr.hh"
#include "IIOPHelper.hpp"

// (1) Declare global variables and a structure
#define NUM_OPTION             5
#define NUM_THRESHOLD_PARAM    5
#define STR_INTERFACE          "ParameterLogManager"
typedef struct  option
{
   char    *strOption;
   char    *strArgument;
   char    *strWordDescr;
   int     minvalue;
   int     maxvalue;
   int     sflag;
   int     value;
   char    *strValue;
};
option optionList[NUM_OPTION] =
{
    { "-e", "0,1          ", "Parameter Log Enabled ", 0 , 1 , 0 , 0 , NULL},
    { "-t", "keywords     ", "Transaction Keywords  ", 0 , 0 , 0 , 0 , NULL},
    { "-c", "keywords     ", "Client Keywords       ", 0 , 0 , 0 , 0 , NULL},
    { "-u", "keywords     ", "User Keywords         ", 0 , 0 , 0 , 0 , NULL},
    { "-v", "             ", "View Settings         ", 0 , 0 , 0 , 0 , NULL},
};
///////////////////////////////////////////////////////////////////////////////
// showUsage function
// arguments    : char **argv
// return value : void
// explanation  : Get the arguments from command line and show usage
///////////////////////////////////////////////////////////////////////////////
void showUsage(char **argv)
{
#ifdef EBROKER //D9000041
    cout << "Usage : " << argv[0] << " hostname marker uuid portnumber -option [argument] [-option [argument]]"  << endl;//D9000041
#else          //D9000041
    cout << "Usage : " << argv[0] << " hostname marker servername portnumber -option [argument] [-option [argument]]"  << endl;
#endif         //D9000041
    cout << "OR"                                                                                                       << endl;
    cout << "        " << argv[0] << " -help     for detailed help" << endl                                            << endl;
}
///////////////////////////////////////////////////////////////////////////////
// showHelp function
// arguments    : char **argv 
// return value : void
// explanation  : Get the arguments from command line and show usage
///////////////////////////////////////////////////////////////////////////////
void showHelp(char **argv)
{
   cout << "Usage : " << argv[0] << " hostname marker servername portnumber -option [argument] [-option [argument]]" << endl << endl;
   cout << "+--------+---------------+------------------------+" << endl;
   cout << "| option | argument      | description            |" << endl;
   cout << "+--------+---------------+------------------------+" << endl;
   for (int i=0 ; i< NUM_OPTION ; i++ )
   {
      cout << "| " << optionList[i].strOption << "     | " << optionList[i].strArgument << " | " << optionList[i].strWordDescr << " | " << endl;
   }
   cout << "+--------+---------------+------------------------+" << endl;
}
///////////////////////////////////////////////////////////////////////////////
// isCorrectOption function
// arguments    : char *str     (the pointer contained a specified option) 
//                int *opseqnum (the pointer to keep the array number of optionList)
// return value : 1 or 0 (if a specified option is correct, return value is 1,
//                if not, return value is 0)
// explanation  : Get an argument from command line as str and check if it's correct.
//                If it's correct, keep the array number of optionList as opseqnum.
///////////////////////////////////////////////////////////////////////////////
int isCorrectOption(char *str , int *seqnum)
{
    if(str == NULL)      return 0;
    for(int i=0 ; i < NUM_OPTION ; i++ )
    {
        if(!strncmp(optionList[i].strOption,str,strlen(str)))
        {//when str corresponds with optionList[i]
            *seqnum = i;
            optionList[i].sflag++;
            return 1;
        }
        else
        {
            /*nop*/
        }
    }
    return 0;
}
///////////////////////////////////////////////////////////////////////////////
// isCorrectArg function
// arguments    : int seq   (the array number of optionList)
//                char *str (the pointer contained a specified option argument)
// return value : 1 or 0 (if a specified argument is correct, return value is 1,
//                if not, return value is 0)
// explanation  : Get an argument from command line as str
//                and check if it's correct for a specified option.
///////////////////////////////////////////////////////////////////////////////
int isCorrectArg(int seq , char *str)
{
    if(str == NULL)       return 0;
    if(!strcmp(str,"0"))        return 1;
    if(!atoi(str))              return 0;
    if(atoi(str) >= optionList[seq].minvalue && atoi(str) <= optionList[seq].maxvalue)  return 1;
    else                                                                                return 0;
}
///////////////////////////////////////////////////////////////////////////////
// main function
// arguments    : int argc      (the number of command line arguments)
//                char **argv   (the pointer of command line arguments)
// return value : 1 or 0 (if exception occurs, return value is 1
//                if not, return value is 0)
// explanation  : the enrty point of spparmclt_command program.
//                Get values of the parmlog levels from command line and set them.
///////////////////////////////////////////////////////////////////////////////
int main (int argc , char **argv)
{
    //  1.Declare local variables.
    int                      i;
    int                      optCheck    = NUM_THRESHOLD_PARAM;
    char                     *hostname   = NULL;
    char                     *markername = NULL;
    char                     *servername = NULL;
    char                     *portnumber = NULL;
    ParameterLogManager_var  theParameterLogManager_var ;
    
    //  2.Check whether "-help" option is specified.
    for(i=0 ; i < argc ; i++)
    {
        if(!strncmp(argv[i],"-help",strlen("-help")))
        {
            showHelp(argv);
            return 1;
        }
        else
        {
            /*nop*/
        }
    }
    
    //  3.Check the number of command line arguments.
    if(argc <= NUM_THRESHOLD_PARAM )
    {
        showUsage(argv);
        return 1;
    }
    hostname   = argv[1];
    markername = argv[2];
    servername = argv[3];
    portnumber = argv[4];
    
    //  4.Check the specified options and arguments.
    while(optCheck < argc)
    {
        int opseqnum = 100;
        if(strchr(argv[optCheck],'-'))
        {
            //  4.1.Check whether the specified option corresponds with the option list.
            if( isCorrectOption(argv[optCheck],&opseqnum) )
            {
                //  4.2.Check whether the argument is valid  for the specified option.
                if(opseqnum <= 0)         //  When the option is -e, check the validity of the option argument.
                {
                    if(optCheck+1 >= argc)
                    {
                        cout << "Invalid option / parameter is specified." << endl;
                        return 1;
                    }
                    else if( !isCorrectArg(opseqnum,argv[optCheck+1]) )
                    {
                        cout << "Invalid option / parameter is specified." << endl;
                        return 1;
                    }
                    else
                    {
                        optionList[opseqnum].value = atoi(argv[optCheck+1]);
                        optCheck += 2;
                    }
                }
                else if(opseqnum == 4)    //  When the option is -v, check next option.
                {
                    optCheck++;
                }
                else                      //  When the option is -t,-c,or -u, check the validity of the option argument.
                {
                    if(optCheck+1 >= argc)
                    {
                        optionList[opseqnum].strValue = "";
                        optCheck++;
                    }
                    else if(strchr(argv[optCheck+1],'-') == argv[optCheck+1])
                    {
                        optionList[opseqnum].strValue = "";
                        optCheck++;
                    }
                    else
                    {
                        optionList[opseqnum].strValue = argv[optCheck+1];
                        optCheck += 2;
                    }
                }
            }
            else
            {
                cout << "Invalid option / parameter is specified." << endl;
                return 1;
            }
        }
        else
        {
            cout << "Invalid option / parameter is specified with wrong position." << endl;
            return 1;
        }
    }
    //  5.Check whether the specified options are duplicated.
    for(i=0 ; i < NUM_OPTION ; i++ )
    {
        if(optionList[i].sflag >= 2)
        {
            cout << "Please specify an option for ONLY ONE time." << endl;
            return 1;
        }
        else
        {
            /*nop*/
        }
    }
    //  6.Connect to server
    try
    {
#ifdef EBROKER                                                                                                          //D6000250
        CORBA::String_var buf = genIOR( hostname , portnumber , servername , markername , STR_INTERFACE , "EBROKER");   //D6000250
#else                                                                                                                   //D6000250
        CORBA::String_var buf = genIOR( hostname , portnumber , servername , markername , STR_INTERFACE );
#endif                                                                                                                  //D6000250
        CORBA::Object_var anObj = SP_STRING_TO_OBJECT(buf);
        if( CORBA::is_nil( anObj ))
        {
            cout << "failed to SP_STRING_TO_OBJECT" << endl;
            return 1;
        }
        theParameterLogManager_var = ParameterLogManager::_narrow(anObj);
        if( CORBA::is_nil( theParameterLogManager_var ))
        {
            cout << "failed to narrow" << endl;
            return 1;
        }
    }
    catch (CORBA::SystemException &sysex)
    {
        cout << "CORBA::SystemException is raised during connecting to " << servername << " on " << hostname << endl;
        cout << &sysex << endl;
        return 1;
    }
    catch (CORBA::Exception &ex)
    {
        cout << "CORBA::Exception is raised during connecting to " << servername << " on " << hostname << endl;
        cout << &ex << endl;
        return 1;
    }
    catch (...)
    {
        cout << "Unknown exception is raised connecting to " << servername << " on " << hostname << endl;
        return 1;
    }
    //  7.Set values according to specified options.
    try
    {
        if(optionList[0].sflag == 1)
        {
            if(optionList[0].value == 1)  theParameterLogManager_var->logEnabled();
            else                          theParameterLogManager_var->logDisabled();
        }
        if(optionList[1].sflag == 1)  theParameterLogManager_var->setTransactionFilterKeywords(optionList[1].strValue);
        if(optionList[2].sflag == 1)  theParameterLogManager_var->setClientFilterKeywords(optionList[2].strValue);
        if(optionList[3].sflag == 1)  theParameterLogManager_var->setUserFilterKeywords(optionList[3].strValue);
        if(optionList[4].sflag == 1)
        {
            CORBA::Boolean theParameterLogEnabled   = FALSE;
            CORBA::String_var theTransactionFilterKeywords;
            CORBA::String_var theClientFilterKeywords;
            CORBA::String_var theUserFilterKeywords;
            time_t tp;
            
            theParameterLogEnabled       = theParameterLogManager_var->isLogEnabled();
            theTransactionFilterKeywords = theParameterLogManager_var->getTransactionFilterKeywords();
            theClientFilterKeywords      = theParameterLogManager_var->getClientFilterKeywords();
            theUserFilterKeywords        = theParameterLogManager_var->getUserFilterKeywords();
            
            time(&tp);
            struct tm *ltm = localtime(&tp);
            cout << " Siview Parameter Log Manager as of " << asctime(ltm);
            cout << " connected " << servername << " on " << hostname                << endl << endl;;
            cout << " Log level settings"                                                    << endl;
            cout << " --------------------------------"                                      << endl;
            cout << " 1. Parameter log enabled    : " << (int)theParameterLogEnabled << endl << endl;
            cout << " Log filter settings"                                                   << endl;
            cout << " --------------------------------"                                      << endl;
            cout << " 2. Transaction keywords     : " << theTransactionFilterKeywords        << endl;
            cout << " 3. Client keywords          : " << theClientFilterKeywords             << endl;
            cout << " 4. User keywords            : " << theUserFilterKeywords       << endl << endl;
        }
    }
    catch (CORBA::SystemException &sysex)
    {
        cout << "CORBA::SystemException is raised during calling method" << endl;
        cout << &sysex << endl;
        return 1;
    }
    catch (CORBA::Exception &ex)
    {
        cout << "CORBA::Exception is raised during calling method" << endl;
        cout << &ex << endl;
        return 1;
    }
    catch (...)
    {
        cout << "Unknown exception is raised during calling method" << endl;
        return 1;
    }
   return 0;
}
