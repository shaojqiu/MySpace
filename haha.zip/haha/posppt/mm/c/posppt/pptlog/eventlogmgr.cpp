#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptlog/eventlogmgr.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 22:54:20 [ 7/13/07 22:54:21 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// Siview - EventLogManager_i
// Name: eventlogmgr.cpp
//
// Change history:
//
// Date     Defect#  Person         Comments
// -------- -------- -------------- -------------------------------------------
// 02/10/16 D4200138 C.Tsuchiya     Remove debug code
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
//

#include <stdlib.h>
#include <time.h>
#include <timeb.h>
#include <stdio.h>
#include <iostream.h>
#include <strstream.h>
#include <sys/msg.h>
#include <errno.h>

#include "eventlogmgr.hpp"

struct eventlog_msgbuf {
    mtyp_t mtype;
    char mtext[EVENTLOGMGR_BUFFER_SIZE]; 
};

EventLogManager_i::EventLogManager_i()
{
    cout << "entering EventLogManager_i::EventLogManager_i" << endl;

    // export SP_EVENTLOG_ENABLED=1 {0/1}
    // 1: enable logging parameters (default)
    // 0: disable logging parameters
    //
    // if no string is specified, no filter works.
    // if string is specified, filter works.
    // "," and " " is sparator for keywords for filter.

    char* enabled                   = getenv("SP_EVENTLOG_ENABLED");

    // enabled or disabled
    //if ( strcmp(enabled,"0") == 0 )
    if ( ( enabled != NULL ) && ( strcmp(enabled,"0") == 0 ) )
    {
        logDisabled();
    }
    else
    {
        logEnabled();
    }
     
    // creating IPC Message queue
    int _ipckey = 0;
    char *ipckey = getenv("EVENT_IPCKEY_MMEVENT");
    if ( ipckey == NULL )
    {
        ipckey = getenv("EVENT_IPCKEY_MM");
    }

    if ( ipckey != NULL )
    {
        istrstream is((const char*)ipckey);
        is >> hex >> _ipckey;
    }

    // sending IPC message
    if ( _ipckey != 0 )
    {
        theIPC = msgget( _ipckey, IPC_CREAT | 0666 );

        if ( theIPC == -1 )
        {
            int _no = errno;
            cout << "msgget() error reported. rc=" << theIPC << " errno=" << _no << endl;

            theIPC = NULL;
        }
    }
}

EventLogManager_i::~EventLogManager_i()
{
    cout << "entering EventLogManager_i::~EventLogManager_i" << endl;
}

//D6000025 void EventLogManager_i::logEnabled (CORBA::Environment &IT_env)
void EventLogManager_i::logEnabled (CORBAENV_ONLY_CPP) //D6000025
{
    //D4200138 cout << "entering EventLogManager_i::logEnabled" << endl;
    theLogEnabled = TRUE;       
}

//D6000025 void EventLogManager_i::logDisabled (CORBA::Environment &IT_env)
void EventLogManager_i::logDisabled (CORBAENV_ONLY_CPP) //D6000025
{
    //D4200138 cout << "entering EventLogManager_i::logDisabled" << endl;
    theLogEnabled = FALSE;       
}

//D6000025 CORBA::Boolean EventLogManager_i::isLogEnabled (CORBA::Environment &IT_env)
CORBA::Boolean EventLogManager_i::isLogEnabled (CORBAENV_ONLY_CPP) //D6000025
{
    //D4200138 cout << "entering EventLogManager_i::isLogEnabled" << endl;
    return (theLogEnabled == TRUE);
}

//D6000025 CORBA::Boolean EventLogManager_i::isLogDisabled (CORBA::Environment &IT_env)
CORBA::Boolean EventLogManager_i::isLogDisabled (CORBAENV_ONLY_CPP) //D6000025
{
    //D4200138 cout << "entering EventLogManager_i::isLogDisabled" << endl;
    return (theLogEnabled != TRUE);
}

//D6000025 void EventLogManager_i::putLog (const char * record, CORBA::Environment &IT_env)
void EventLogManager_i::putLog (const char * record CORBAENV_LAST_CPP) //D6000025
{
    //D4200138 cout << "entering EventLogManager_i::putLog" << endl;

    if ( theIPC != NULL )
    {
        int _ipcsize = 0;
        char* _stripcsize = getenv("EVENT_IPCKEY_MMEVENT_SIZE");
        if ( _stripcsize == NULL )
        {
            _ipcsize = EVENTLOGMGR_BUFFER_SIZE;
        }
        else
        {
            _ipcsize = atol(_stripcsize);
        }
        
        eventlog_msgbuf _msgbuf;
        _msgbuf.mtype = 4;
        memset (_msgbuf.mtext,'\0',sizeof(_msgbuf.mtext));
        strncpy(_msgbuf.mtext,record,_ipcsize-1);

//D4200138 cout << "about to send the following message" << endl;
//D4200138 cout << _msgbuf.mtext << endl;
//D4200138 cout << "about to call msgsnd() " << endl;

        int _rc = msgsnd (theIPC, &_msgbuf, _ipcsize, IPC_NOWAIT);

        if ( _rc != 0 )
        {
            int _no = errno;
            //D4200138 cout << "msgsnd() error reported. rc=" << _rc << " errno=" << _no << endl;
        }
    }
}

