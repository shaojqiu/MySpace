//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2012. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2012. All rights reserved.
//
// Siview
// Name: bufferedlogger_kicker_mm.cpp
//
// Change history:
//
// Date        Defect#       Person         Comments
// ----------- ------------- -------------- -------------------------------------------
// 2012/09/11  DSN000052888  M.Nakano       Initial release
//
//

#define __KICKERMM_INSTANCE__
#include <stdlib.h>
#define BUFFEREDLOGGERKKUTIL_FOR_KICKER
#include "bufferedlogger_kicker_mm.hpp"
#include "bufferedloggerkkconst.hpp"
#include "logger_msg.hpp"

#include "bufferedloggerkkctrl.hpp"
#include "bufferedloggerctrl.hpp"
#include <vector>
#include <sstream>

using namespace bufferedloggerutil;


//typedef struct pptRetCode_struct {
//    string transactionID;  //<i>Transaction ID
//    string returnCode;     //<i>Return Code
//    string messageID;      //<i>Message ID
//    string messageText;    //<i>Message Text
//    string reasonText;     //<i>Reason Text
//    any siInfo;            //<i>Reserved for SI customization
//} pptRetCode;

namespace
{
  ControllerOfBufferedLogger *cp = NULL;
};

KickerMM::KickerMM()
{
    kcp = KickerControllerOfBufferedLogger::getInstance();
    cp = ControllerOfBufferedLogger::getInstance();
    
    //prepare config file keywords
    std::string * strs = new std::string[KICKER_MAXKEYWORD_MM];
    strs[0] = KICKER_RC_STR;
    kcp->setKeywords( strs, KICKER_MAXKEYWORD_MM );
    
    //load configuration file
//    if( cp->isBufferedLogging() )
//    {
        int ret = kcp->loadConfigurationFile( kcp->getConfigurationFile() );
//    }
}

//for MM
void KickerMM::checkAtBegin(const char* operation, const char* misc)
{
    BUFFEREDLOGGER_PRINT_MSG_ENTRY("", "", "")
    BUFFEREDLOGGER_PRINT_MSG_V1("", "operation=", operation)

    if( !cp->isBufferedLogging() )
    {
        BUFFEREDLOGGER_PRINT_CTRL_MSG_V1("", "logger is not active.", "" );
        BUFFEREDLOGGER_PRINT_MSG_EXIT("", "", "")
        return;
    }

    std::vector<StanzaEntry*> * conditions = NULL;
    StanzaEntry* condition = NULL;

    //check nested L-TX
    conditions = getConditions();
    if( conditions )
    {
        BUFFEREDLOGGER_PRINT_CTRL_MSG_V1("", "condition was already set.", (void*)conditions );
        BUFFEREDLOGGER_PRINT_MSG_EXIT("", "", "")
        return;
    }

    IFTrace *logger = bufferedloggerutil::getLogger();
    if( logger == NULL )
    {
        BUFFEREDLOGGER_PRINT_CTRL_MSG_V1("", "logger is not active.", "" );
        BUFFEREDLOGGER_PRINT_MSG_EXIT("", "", "")
        return;
    }
    
    BUFFEREDLOGGER_PRINT_CTRL_MSG_V1("", "operation=", operation)

    CORBA::String_var txname = operationName(operation);

    if (txname == NULL || strlen(txname) == 0)
    {
        logger->cancel(); 
        
        //invalid tx name
        BUFFEREDLOGGER_PRINT_MSG_EXIT("", "", "")
        return;
    }

    BUFFEREDLOGGER_PRINT_CTRL_MSG_V1("", "txname=", txname )

    size_t condition_num = 0;

    //find condition with txname
    conditions = kcp->findConfiguration(txname);

    if (conditions == NULL)
    {
        BUFFEREDLOGGER_PRINT_MSG_V1("", "=", "")
        //find condition with OTHERS
        conditions = kcp->findConfiguration(KICKER_OTHERS_STR);
    }

    if (conditions == NULL)
    {
        //not found setting for this operation --> not need logging
        logger->cancel(); 

        //keep condition as not need;
        BUFFEREDLOGGER_PRINT_MSG_EXIT("", "", "")
        return;
    }

    //store conditions for this thread.
    keepConditions(conditions);

    condition_num = conditions->size();

    for (size_t i = 0; i < condition_num; i++)
    {
        condition = (*conditions)[i];

        //check condition is  "=[blank]" or "!=*" (not begin)
        if (isAllDenied(condition->value, condition->eq))
        {
            logger->cancel(); 

            //all flush condition says "not need logging"
            BUFFEREDLOGGER_PRINT_MSG_EXIT("", "", "")
            return;
        }
    }

    logger->init(); 
    bufferedloggerutil::setResultFlag(0);

    BUFFEREDLOGGER_PRINT_MSG_EXIT("", "", "")
    return;
}

//for MM
//not use operation name as condition is kept as thread_specific
void KickerMM::checkAtEnd(const char * operation, const char* rc, const char* misc)
{

    BUFFEREDLOGGER_PRINT_MSG_ENTRY("", "", "")
    BUFFEREDLOGGER_PRINT_MSG_V1("", "rc=", rc)

    BUFFEREDLOGGER_PRINT_CTRL_MSG_V1("", "rc=", rc)

    if( !cp->isBufferedLogging() )
    {
        BUFFEREDLOGGER_PRINT_CTRL_MSG_V1("", "logger is not active.", "" );
        BUFFEREDLOGGER_PRINT_MSG_EXIT("", "", "")
        setResultFlag(0);
        return;
    }

    std::vector<StanzaEntry*> * conditions = NULL;
    StanzaEntry* condition = NULL;

    if(rc == NULL || strlen(rc)== 0){
        //no rc --> clear
        setResultFlag(0);
        BUFFEREDLOGGER_PRINT_MSG_EXIT("", "", "")
        return;
    }

    size_t condition_num = 0;
    conditions = getConditions();

    if (conditions != NULL)
    {
        int matched = 0;
        condition_num = conditions->size();
        std::string rc_str(rc);

        //check each condition
        for (size_t i = 0; i < condition_num; i++)
        {
            condition = (*conditions)[i];

            //assume RC as key
            if ((condition->key).compare(KICKER_RC_STR))
            {
                //unknown key
                setResultFlag(0);
                BUFFEREDLOGGER_PRINT_MSG_EXIT("", "", "")
                return;
            }

            matched = ismatch(condition->value, KICKER_CHAR_FIRST_DELIMITER, rc_str, condition->eq);
    
            BUFFEREDLOGGER_PRINT_CTRL_MSG_V1("", "condition->value" , condition->value );
            BUFFEREDLOGGER_PRINT_CTRL_MSG_V1("", "condition->eq" , (int)condition->eq );

            if (matched)
            {
                setResultFlag(1);
                BUFFEREDLOGGER_PRINT_MSG_EXIT("", "", "")
                return;
            }
            else
            {
                setResultFlag(0);
                BUFFEREDLOGGER_PRINT_MSG_EXIT("", "", "")
                return;
            }
        }
    }

    //no condition --> clear
    setResultFlag(0);
    BUFFEREDLOGGER_PRINT_MSG_EXIT("", "", "")
    return;
}

