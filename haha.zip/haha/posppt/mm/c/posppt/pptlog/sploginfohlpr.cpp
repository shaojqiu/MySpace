//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView - Log information helper
// Name: sploginfohlpr.cpp
//
// Change history:
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2015/10/23 DSN000098739 S.Yamamoto     Initial Release
//


#include "sploginfohlpr.hpp"
#ifdef EBROKER
#include <corba.h>
#else
#include <CORBA.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include "cimfwstr.hpp"
#include "cimfwerr.hpp"

#ifdef linux
#include <strstream>
#else
#include <strstream.h>
#endif

static LogInfomationHelperBase defaultHelper;
LogInfomationHelperBase *LogInformationHelperHolder::helper = &defaultHelper;

LogInfomationHelperBase::LogInfomationHelperBase()
{
}

LogInfomationHelperBase::~LogInfomationHelperBase()
{
}

#define MAX_LEN_FOR_ADDITIONALINFO_BUF 128

char* LogInfomationHelperBase::getAdditonalInfo( const char *filename, int lineno )
{
	char buf[MAX_LEN_FOR_ADDITIONALINFO_BUF];
	
    if( *filename == '/' )
    {
      const char *tmp = strrchr( filename, '/' );
      if( tmp )
      {
         filename = tmp + 1;
      }
    }
    snprintf( buf, sizeof(buf), " (%s:%d)", filename, lineno );
    
    return CORBA::string_dup(buf);
}

#define MAX_LEN_FOR_SYS_EXCPET_BUF  3000


char * LogInfomationHelperBase::getSystemExceptionInfo( const CORBA::SystemException &sysex )
{
	char buf[MAX_LEN_FOR_SYS_EXCPET_BUF];
	memset( buf, 0, sizeof(buf) );
	
    if( strcmp( sysex.id(), "CORBA::UNKNOWN" ) == 0 )
    {
        snprintf( buf, sizeof(buf), "CORBA::SystemException occurred. (%s)",  (const char*)sysex.id() ) ;
    }
    else
    {
        ostrstream anExceptStream( buf, sizeof(buf)) ;
        anExceptStream << sysex;
    }

    return CORBA::string_dup(buf);
}

char *LogInfomationHelperBase::getDefaultReasonText()
{
	return CORBA::string_dup("");//blank ( additional information (file:lineno) only. )
}

int LogInfomationHelperBase::isUseDefaultReasonText()
{
	return TRUE;
}

char * LogInfomationHelperBase::getConcatString( const char *str1, const char *str2 )
{
	CORBA::ULong tmpLen = CIMFWStrLen( str1 );
	CORBA::ULong tmpLen2 = CIMFWStrLen( str2 );
	char *ptr = CORBA::string_alloc( tmpLen + tmpLen2 );
	if( ptr == NULL ) throw OUTOFMEM ;
    *ptr = 0;
    CIMFWStrCpy( ptr, str1 );
    CIMFWStrCat( ptr, str2 );
    return ptr;
}

LogInformationHelperHolder::LogInformationHelperHolder()
{
}

LogInformationHelperHolder::~LogInformationHelperHolder()
{
}

LogInfomationHelperBase *LogInformationHelperHolder::getHelper()
{
    return helper;
}

void LogInformationHelperHolder::setHelper( LogInfomationHelperBase* _helper )
{
    helper = _helper;
}
