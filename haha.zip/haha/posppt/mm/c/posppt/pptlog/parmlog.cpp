#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptlog/parmlog.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 22:54:37 [ 7/13/07 22:54:39 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// Siview - ParameterLog
// Name: parmlog.cpp
//
// Change history:
//
// Date     Defect#  Person         Comments
// -------- -------- -------------- -------------------------------------------
// 12/21/01 D4100017 Y.Yamaguchi    Newly created.
// 04/09/02 P4100345 Y.Yamaguchi    Fixed DFREE
// 04/11/02 P4100350 K.Matsuei      Memory Leak in ParameterLog.
// 06/12/02 P4100548 C.Tsuchiya     Fixed UMR in case of name is NULL
// 09/15/04 D6000025 K.Murakami     TIE was deleted in order to make it TIE to BOA.
// 11/04/04 D6000025 K.Murakami     Change any to Any for eBrokerMigration.
// 11/30/04 D6000025 S.Yamamoto     eBroker migration
// 05/23/05 D6000308 K.Murakami     follow up for eBroker.
//

#include "stdlib.h"
#include "time.h"
#include "iomanip.h"

#include "parmlog.hpp"
#include "parmlogmgr.hpp"

ParameterLogManager* theParameterLogManager=NULL;

#ifdef EBROKER                                                     //D6000308
#include "spebmarker.hpp"                                          //D6000308
ParameterLogManagerFactory* theParameterLogManagerFactory = NULL;  //D6000308
#else                                                              //D6000308
ParameterLogManagerFactory* theParameterLogManagerFactory = new ParameterLogManagerFactory();
#endif                                                             //D6000308

ParameterLogManagerFactory::ParameterLogManagerFactory()
{
    if ( CORBA::is_nil(theParameterLogManager) )
    {
#ifdef MO_BOA   //D6000025
        theParameterLogManager =
            new ParameterLogManager_i() ;   //D6000025
#else  //D6000025
        theParameterLogManager =
            new TIE_ParameterLogManager(ParameterLogManager_i)(new ParameterLogManager_i) ;
#endif  //D6000025

        char* _markername = getenv("SP_PARMLOG_MARKER");
        if ( _markername == NULL )
        {
             _markername = "MMS";
        }
        
        try
        {
             theParameterLogManager->_marker(_markername);
//D6000308 add start
#ifdef EBROKER
             EB_SiView_registObjectWithMarker( _markername, theParameterLogManager );
#endif
//D6000308 add end
        }
        catch(...)
        {
            // nothing to do
        }
    }
}

ParameterLogManagerFactory::~ParameterLogManagerFactory()
{
}

ParameterLog::ParameterLog( const char* opname, const char* node, const char* user, const char* name )
{
    #ifdef PARMLOG_DEBUG
    cout << "entering ParameterLog::ParameterLog" << endl;
    #endif
    _indent = 0;
    recordbuf = new char[PARMLOG_BUFFER_SIZE];
    memset(recordbuf,'\0',PARMLOG_BUFFER_SIZE);
    record = new ostrstream(recordbuf, PARMLOG_BUFFER_SIZE);

    if ( CORBA::is_nil(theParameterLogManager) )
    {
        // mutex lock required here

        if ( CORBA::is_nil(theParameterLogManager) )
        {
#ifdef MO_BOA   //D6000025
            theParameterLogManager = 
               new ParameterLogManager_i() ;   //D6000025
#else   //D6000025
            theParameterLogManager = 
               new TIE_ParameterLogManager(ParameterLogManager_i)(new ParameterLogManager_i) ;
#endif  //D6000025
        }
    }
    
    theLogEnabled = FALSE;
    if ( !CORBA::is_nil(theParameterLogManager) )
    {
         if ( theParameterLogManager->isFiltered(opname, node, user) )
         {
                theLogEnabled = TRUE;
                if( name != NULL )                                                                                         //P4100548
                {                                                                                                          //P4100548
                    *record << "name: " << opname << " node: " << node << " user: " << user << " desc: " << name << endl;
                }                                                                                                          //P4100548
                else                                                                                                       //P4100548
                {                                                                                                          //P4100548
                    *record << "name: " << opname << " node: " << node << " user: " << user << " desc: " << "" << endl;    //P4100548
                }                                                                                                          //P4100548
         }
    }

}

ParameterLog::~ParameterLog()
{
    #ifdef PARMLOG_DEBUG
    cout << "entering ParameterLog::~ParameterLog" << endl;
    #endif

    if ( isLogEnabled() )
    {
//P4100350        CORBA::String_var _strrecord = record->str();
        char * _strrecord = record->str();  //P4100350

        if ( !CORBA::is_nil(theParameterLogManager) )
        {
            theParameterLogManager->putLog(_strrecord);
        }
    }

    // deleting output message
    if ( record != NULL )
    {
        delete record;
    }

    // do not delete it because of DFREE //P4100345
//  if ( recordbuf != NULL )
//  {
//      delete recordbuf;
//  }
    if ( recordbuf != NULL )  //P4100350
    {                         //P4100350
        delete recordbuf;     //P4100350
    }                         //P4100350

}

CORBA::Boolean ParameterLog::isLogEnabled()
{
    #ifdef PARMLOG_DEBUG
    cout << "entering ParameterLog::isLogEnabled" << endl;
    #endif
    return theLogEnabled;
}

void ParameterLog::outVariable( CORBA::SystemException& object, char* name )
{
    *record << setw( _indent ) << "";
    *record << name << ":(CORBA::SystemException)" << endl;
    _indent++;
    outVariable( object.minor()    , "minor"     );
    outVariable( object.id()       , "id"        );
#ifndef EBROKER //D6000025
    outVariable( object.param()    , "param"     );
#endif          //D6000025
    outVariable( object.completed(), "completed" );
    _indent--;
}

void ParameterLog::outVariable( const int object, char* name )
{
    *record << setw( _indent ) << "";
    *record << name << ":" << object << endl;
}

/*
void ParameterLog::outVariable( const unsigned long object, char* name )
{
    *record << setw( _indent ) << "";
    *record << name << ":" << object << endl;
}

void ParameterLog::outVariable( const double object, char* name )
{
    *record << setw( _indent ) << "";
    *record << name << ":" << object << endl;
}
*/

void ParameterLog::outVariable( const char* object, char* name )
{
    *record << setw( _indent ) << "";
    if( object == NULL )
        *record << name << ":" << endl;
    else
        *record << name << ":\"" << object << "\"" << endl;
}

//D6000025void ParameterLog::outVariable( const CORBA::any& object, char* name )
void ParameterLog::outVariable( const CORBA::Any& object, char* name )    //D6000025
{
    if( object.value() == NULL )    //0.01
    {
        *record << setw( _indent ) << "";
        *record << name << ":(any[])" << endl;
        return;
    }

    LOG_ANY_TYPE(CORBA::Short,short);
    LOG_ANY_TYPE(CORBA::Long,long);
    LOG_ANY_TYPE(CORBA::UShort,unsigned short);
    LOG_ANY_TYPE(CORBA::ULong,unsigned long);
    LOG_ANY_TYPE(CORBA::Float,float);
    LOG_ANY_TYPE(CORBA::Double,double);
    LOG_ANY_TYPE(char*,string);

    LOG_ANY_CHAR(CORBA::Boolean,boolean,CORBA::Any::to_boolean);
    LOG_ANY_CHAR(CORBA::Octet,octet,CORBA::Any::to_octet);
    LOG_ANY_CHAR(CORBA::Char,char,CORBA::Any::to_char);

    *record << setw( _indent ) << "";
    *record << name << ":(any[unknown])" << endl;
}

