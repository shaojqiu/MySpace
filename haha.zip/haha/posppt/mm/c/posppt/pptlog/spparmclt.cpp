#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptlog/spparmclt.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 22:54:59 [ 7/13/07 22:55:00 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// Siview - ParameterLog client
// Name: pptparmlogclt.cpp
//
// Change history:
//
// Date     Defect#  Person         Comments
// -------- -------- -------------- -------------------------------------------
// 01/16/02          Y.Yamaguchi    Newly created.
// 11/30/04 D6000025 S.Yamamoto     eBroker migration
// 06/01/07 D9000041 S.Yamamoto     Improvement of usage message

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream.h>
#include <unistd.h>
#include <time.h>

#include "parmlogmgr.hh"

#ifdef EBROKER          //D6000025
#include "corbaenv.hpp" //D6000025
#endif                  //D6000025

// usage: spparmclt hostname marker:servername
//        spparmclt marker:servername
//        spparmclt :servername
//        spparmclt servername
//
int main (int argc, char **argv)
{
    //
    // checking arguments
    //
    char hostname[1024];
    char servername[1024];
    char portnumber[1024];
    const char* markername=NULL;

    memset(hostname,NULL,sizeof(hostname));
    memset(servername,NULL,sizeof(servername));
    memset(portnumber,NULL,sizeof(portnumber));

    if ( argc == 2 )
    {
        gethostname(hostname, sizeof(hostname));
        strcpy(servername, argv[1]);
    }
    else if ( argc == 3 )
    {
        strcpy(hostname,   argv[1]);
        strcpy(servername, argv[2]);
    }
    else
    {
        cerr << "invalid parameter specified" << endl;
#ifdef EBROKER  //D9000041
        cerr << "usage: " << argv[0] << " hostname marker:uuid:portnumber:orbtype" << endl; //D9000041
        cerr << "       " << argv[0] << " marker:uuid:portnumber:orbtype" << endl; //D9000041
        cerr << "                orbtype ... EBROKER" << endl; //D9000041
#else           //D9000041
        cerr << "usage: " << argv[0] << " hostname marker:servername" << endl;
        cerr << "       " << argv[0] << " marker:servername" << endl;
        cerr << "       " << argv[0] << " :servername" << endl;
        cerr << "       " << argv[0] << " servername" << endl;
#endif          //D9000041
        return 1;
    }

    if ( strlen(hostname) == 0 )
    {
        cerr << "no hostname specified" << endl;
        return 1;
    }

    if ( strlen(servername) == 0 )
    {
        cerr << "no servername specified" << endl;
        return 1;
    }

    if ( strchr(servername,':') == NULL )
    {
        char _buf[sizeof(servername)];

        strcpy(_buf,":");
        strcat(_buf,servername);
        strcpy(servername,_buf);
    }

    //
    // bind Parameter Log Manager
    //
    ParameterLogManager_var theParameterLogManager_var ;

    try
    {
#ifdef EBROKER //D6000025
        SP_GET_OBJECT( theParameterLogManager_var, servername, hostname, ParameterLogManager ); //D6000025
#else          //D6000025
        theParameterLogManager_var = ParameterLogManager::_bind(servername, hostname);
#endif         //D6000025
        markername = theParameterLogManager_var->_marker();
    }
    catch (CORBA::SystemException &sysex)
    {
        cerr << "CORBA::SystemException is raised during binding " << servername << " on " << hostname << endl;
        cerr << &sysex << endl;
        return 1;
    }
    catch (...)
    {
        cerr << "Unknow exception is raised during " << servername << " on " << hostname << endl;
        return 1;
    }


    //
    // Parameter Log Control Operations
    //
    while (1)
    {
        CORBA::Boolean theParameterLogEnabled  = FALSE;
        char* theTransactionFilterKeywords     = NULL;
        char* theClientFilterKeywords          = NULL;
        char* theUserFilterKeywords            = NULL;

        //
        // getting current settings
        //
        try
        {
            theParameterLogEnabled       = theParameterLogManager_var->isLogEnabled();
            theTransactionFilterKeywords = theParameterLogManager_var->getTransactionFilterKeywords();
            theClientFilterKeywords      = theParameterLogManager_var->getClientFilterKeywords();
            theUserFilterKeywords        = theParameterLogManager_var->getUserFilterKeywords();
        }
        catch (CORBA::SystemException &sysex)
        {
            cerr << "CORBA::SystemException is raised during calling method" << endl;
            cerr << &sysex << endl;
            break;
        }
        catch (...)
        {
            cerr << "Unknown exception is raised during calling method" << endl;
            break;
        }

        //
        // showing current settings
        //
        time_t tp;
        time(&tp);
        struct tm *ltm = localtime(&tp);

        char menu = ' ';

        while ( menu == ' ' )
        {
            system("clear");
            cout << " Siview Parameter Log Manager as of " << asctime(ltm);
            if ( strstr(servername,":") == servername )
               cout << " connected " << markername << servername << " on " << hostname << endl;
            else
               cout << " connected " << servername << " on " << hostname << endl;
            cout << endl;
            cout << " Log level settings" << endl;
            cout << " ------------------" << endl;
            cout << " 1. Parameter log enabled: "     << (int)theParameterLogEnabled << endl;
            cout << endl;
            cout << " Log filter settings" << endl;
            cout << " -------------------" << endl;
            cout << " 2. Transaction keywords : " << theTransactionFilterKeywords << endl;
            cout << " 3. Client keywords : "      << theClientFilterKeywords << endl;
            cout << " 4. User keywords : "        << theUserFilterKeywords << endl;
            cout << " X. Exit" << endl;
            cout << endl;
            cout << " Enter : ";

            char _buf[1024];

            cin >> _buf;
//          cin.get(_buf,sizeof(_buf),'\n');

            if ( strstr("1234Xx", _buf) == NULL )
            {
               cerr << endl;
               cerr << "invalid menu is selected" << endl;
               continue;
            }
            else
            {
               menu = _buf[0];
            }
        }
        if ( menu == 'X' || menu == 'x' )
        {
            break;
        }

        //
        // showing input field
        //
        cout << endl;
        switch ( menu )
        {
        case '1' : cout << " Parameter log enabled (0,1) : ";
            break;
        case '2' : cout << " Transaction keywords : ";
            break;
        case '3' : cout << " Client keywords : ";
            break;
        case '4' : cout << " User keywords : ";
            break;
        }
        cout << flush;

        //
        // entering value
        //
        char _buf[1024];

        gets(_buf);
//      cin >> _buf;
//      cin.get(_buf,sizeof(_buf),'\n');


//      if ( strlen(_buf) > 0 )
//      {
            char value[1024];
            memset(value, NULL, sizeof(value));

            switch (menu)
            {
            case '1' : if ( strstr("0 1",_buf) != NULL ) strcpy(value, _buf);
                break;
            case '2' : strcpy(value, _buf);
                break;
            case '3' : strcpy(value, _buf);
                break;
            case '4' : strcpy(value, _buf);
                break;
            }

            if ( menu > '1' || strlen(value) > 0 )
            {
                try
                {
                    switch (menu)
                    {
                    case '1' :
                        if ( value[0] == '1' )
                            theParameterLogManager_var->logEnabled();
                        else
                            theParameterLogManager_var->logDisabled();
                        break;
                    case '2' : theParameterLogManager_var->setTransactionFilterKeywords(value);
                        break;
                    case '3' : theParameterLogManager_var->setClientFilterKeywords(value);
                        break;
                    case '4' : theParameterLogManager_var->setUserFilterKeywords(value);
                        break;
                    }
                }
                catch (CORBA::SystemException &sysex)
                {
                    cerr << "CORBA::SystemException is raised during calling method" << endl;
                    cerr << &sysex << endl;
                    break;
                }
                catch (...)
                {
                    cerr << "Unknown exception is raised during calling method" << endl;
                    break;
                }
            }
//      }

        if ( theTransactionFilterKeywords == NULL )
        {
            delete theTransactionFilterKeywords;
            theTransactionFilterKeywords = NULL;
        }
        if ( theClientFilterKeywords == NULL )
        {
            delete theClientFilterKeywords;
            theClientFilterKeywords = NULL;
        }
        if ( theUserFilterKeywords == NULL )
        {
            delete theUserFilterKeywords;
            theUserFilterKeywords = NULL;
        }
    }

    return 0;
}
