#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptlog/parmlogmgr.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 22:54:44 [ 7/13/07 22:54:45 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2009. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2009. All rights reserved.
//
// Siview - ParameterLogManager_i
// Name: parmlogmgr.cpp
//
// Change history:
//
// Date     Defect#  Person         Comments
// -------- -------- -------------- -------------------------------------------
// 12/21/01 D4100017 Y.Yamaguchi    Newly created.
// 10/22/04 D6000025 K.Murakami     eBroker Migration.
// 06/14/05 D6000358 T.Ohsaki       Filter logic change.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2009/08/05 DSIV00001249 K.Yamaoku      Improvement of Timestamp for Logging.

#include <stdlib.h>
#include <timeb.h>
#include <stdio.h>
#include <iostream.h>
#include <strstream.h>
#include <sys/msg.h>
#include <errno.h>
#include <time.h>
#include <pthread.h>

#include "parmlogmgr.hpp"

struct parmlog_msgbuf {
    mtyp_t mtype;
    char mtext[PARMLOGMGR_BUFFER_SIZE]; 
};


ParameterLogManager_i::ParameterLogManager_i()
{
    #ifdef PARMLOG_DEBUG
    cout << "entering ParameterLogManager_i::ParameterLogManager_i" << endl;
    #endif
    // export SP_PARMLOG_ENABLED=1 {0/1}
    // 1: enable logging parameters
    // 0: disable logging parameters
    //
    // export SP_PARMLOG_TRANSACTIONKEYWORDS=TXTRC002
    // export SP_PARMLOG_CLIENTKEYWORDS=spd06,spd07
    // export SP_PARMLOG_USERKEYWORDS=
    // if no string is specified, no filter works.
    // if string is specified, filter works.
    // "," and " " is sparator for keywords for filter.

    char* enabled                   = getenv("SP_PARMLOG_ENABLED");
    char* transactionFilterKeywords = getenv("SP_PARMLOG_TRANSACTIONKEYWORDS");
    char* clientFilterKeywords      = getenv("SP_PARMLOG_CLIENTKEYWORDS");
    char* userFilterKeywords        = getenv("SP_PARMLOG_USERKEYWORDS");

    // enabled or disabled
    if ( strcmp(enabled,"1") == 0 )
    {
        logEnabled();
    }
    else
    {
        logDisabled();
    }
     
    // setting keywords for transaction filter
    setTransactionFilterKeywords(transactionFilterKeywords);

    // setting keywords for client filter
    setClientFilterKeywords(clientFilterKeywords);

    // setting keywords for user filter
    setUserFilterKeywords(userFilterKeywords);

    // creating IPC Message queue
    int _ipckey = 0;
    char *ipckey = getenv("EVENT_IPCKEY_MMPARAMETER");
    if ( ipckey != NULL )
    {
        istrstream is((const char*)ipckey);
        is >> hex >> _ipckey;
    }

    // sending IPC message
    if ( _ipckey != 0 )
    {
        theIPC = msgget( _ipckey, IPC_CREAT | 0666 );

        if ( theIPC == -1 )
        {
            int _no = errno;
            cout << "msgget() error reported. rc=" << theIPC << " errno=" << _no << endl;

            theIPC = NULL;
        }
    }
}

ParameterLogManager_i::~ParameterLogManager_i()
{
    #ifdef PARMLOG_DEBUG
    cout << "entering ParameterLogManager_i::~ParameterLogManager_i" << endl;
    #endif
}

//D6000025 void ParameterLogManager_i::logEnabled (CORBA::Environment &IT_env)
void ParameterLogManager_i::logEnabled (CORBAENV_ONLY_CPP) //D6000025
{
    #ifdef PARMLOG_DEBUG
    cout << "entering ParameterLogManager_i::logEnabled" << endl;
    #endif
    theLogEnabled = TRUE;       
}

//D6000025 void ParameterLogManager_i::logDisabled (CORBA::Environment &IT_env)
void ParameterLogManager_i::logDisabled (CORBAENV_ONLY_CPP) //D6000025
{
    #ifdef PARMLOG_DEBUG
    cout << "entering ParameterLogManager_i::logDisabled" << endl;
    #endif
    theLogEnabled = FALSE;       
}

//D6000025 void ParameterLogManager_i::setTransactionFilterKeywords(const char* filterKeywords, CORBA::Environment &IT_env)
void ParameterLogManager_i::setTransactionFilterKeywords(const char* filterKeywords CORBAENV_LAST_CPP) //D6000025
{
    #ifdef PARMLOG_DEBUG
    cout << "entering ParameterLogManager_i::setTransactionFilterKeywords" << endl;
    #endif
    theTransactionFilterKeywords.length(0);

    if ( filterKeywords != NULL )
    {
        unsigned int n=0;

        #ifdef PARMLOG_DEBUG
        cout << "SP_PARMLOG_TRANSACTIONKEYWORDS=" <<  filterKeywords << endl;
        #endif
        char *token = NULL;
        char *searchstring = (char*)filterKeywords;
        char *startpointer = NULL;
        char **savepointer = &startpointer;
        while ( (token = strtok_r(searchstring," ,",savepointer)) != NULL )
        {
            theTransactionFilterKeywords.length(n+1);
            theTransactionFilterKeywords[n++] = strdup(token);
            #ifdef PARMLOG_DEBUG
            cout <<  "token " << n << "=" << token << endl;
            #endif
            searchstring = NULL;
        }
    }
}

//D6000025 void ParameterLogManager_i::setClientFilterKeywords(const char* filterKeywords, CORBA::Environment &IT_env)
void ParameterLogManager_i::setClientFilterKeywords(const char* filterKeywords CORBAENV_LAST_CPP) //D6000025
{
    #ifdef PARMLOG_DEBUG
    cout << "entering ParameterLogManager_i::setClientFilterKeywords" << endl;
    #endif
    theClientFilterKeywords.length(0);

    if ( filterKeywords != NULL )
    {
        unsigned int n=0;

        #ifdef PARMLOG_DEBUG
        cout << "SP_PARMLOG_CLIENTKEYWORDS=" << filterKeywords << endl;
        #endif
        char *token = NULL;
        char *searchstring = (char*)filterKeywords;
        char *startpointer = NULL;
        char **savepointer = &startpointer;
        while ( (token = strtok_r(searchstring," ,",savepointer)) != NULL )
        {
            theClientFilterKeywords.length(n+1);
            theClientFilterKeywords[n++] = strdup(token);
            #ifdef PARMLOG_DEBUG
            cout <<  "token " << n << "=" << token << endl;
            #endif
            searchstring = NULL;
        }
    }
}

//D6000025 void ParameterLogManager_i::setUserFilterKeywords(const char* filterKeywords, CORBA::Environment &IT_env)
void ParameterLogManager_i::setUserFilterKeywords(const char* filterKeywords CORBAENV_LAST_CPP) //D6000025
{
    #ifdef PARMLOG_DEBUG
    cout << "entering ParameterLogManager_i::setUserFilterKeywords" << endl;
    #endif
    theUserFilterKeywords.length(0);

    if ( filterKeywords != NULL )
    {
        unsigned int n=0;

        #ifdef PARMLOG_DEBUG
        cout << "SP_PARMLOG_USERKEYWORDS=" << filterKeywords  <<endl;
        #endif
        char *token = NULL;
        char *searchstring = (char*)filterKeywords;
        char *startpointer = NULL;
        char **savepointer = &startpointer;
        while ( (token = strtok_r(searchstring," ,",savepointer)) != NULL )
        {
            theUserFilterKeywords.length(n+1);
            theUserFilterKeywords[n++] = strdup(token);
            #ifdef PARMLOG_DEBUG
            cout <<  "token " << n << "=" << token << endl;
            #endif
            searchstring = NULL;
        }
    }
}

//D6000025 char* ParameterLogManager_i::getTransactionFilterKeywords(CORBA::Environment &IT_env)
char* ParameterLogManager_i::getTransactionFilterKeywords(CORBAENV_ONLY_CPP) //D6000025
{
    #ifdef PARMLOG_DEBUG
    cout << "entering ParameterLogManager_i::getTransactionFilterKeywords" << endl;
    #endif

    char *retVal = NULL;

    if ( theTransactionFilterKeywords.length() > 0 )
    {
        unsigned int len = 0;
        unsigned int i;
        for ( i=0; i<theTransactionFilterKeywords.length(); i++ )
        {
            len = len + strlen(theTransactionFilterKeywords[i])+1;
        }
        retVal = new char[len];
        memset(retVal,'\0',len);
        for ( i=0; i<theTransactionFilterKeywords.length(); i++ )
        {
            strcat(retVal, theTransactionFilterKeywords[i]);
            if ( i < theTransactionFilterKeywords.length() - 1 )
            {
                strcat(retVal,",");
            }
        }
    }
    else
    {
        retVal = strdup("");
    }

    return retVal;
}

//D6000025 char* ParameterLogManager_i::getClientFilterKeywords(CORBA::Environment &IT_env)
char* ParameterLogManager_i::getClientFilterKeywords(CORBAENV_ONLY_CPP) //D6000025
{
    #ifdef PARMLOG_DEBUG
    cout << "entering ParameterLogManager_i::getClientFilterKeywords" << endl;
    #endif

    char *retVal = NULL;

    if ( theClientFilterKeywords.length() > 0 )
    {
        unsigned int len = 0;
        unsigned int i;
        for ( i=0; i<theClientFilterKeywords.length(); i++ )
        {
            len = len + strlen(theClientFilterKeywords[i])+1;
        }
        retVal = new char[len];
        memset(retVal,'\0',len);
        for ( i=0; i<theClientFilterKeywords.length(); i++ )
        {
            strcat(retVal, theClientFilterKeywords[i]);
            if ( i < theClientFilterKeywords.length() - 1 )
            {
                strcat(retVal,",");
            }
        }
    }
    else
    {
        retVal = strdup("");
    }

    return retVal;
}

//D6000025 char* ParameterLogManager_i::getUserFilterKeywords(CORBA::Environment &IT_env)
char* ParameterLogManager_i::getUserFilterKeywords(CORBAENV_ONLY_CPP) //D6000025
{
    #ifdef PARMLOG_DEBUG
    cout << "entering ParameterLogManager_i::getUserFilterKeywords" << endl;
    #endif
 
    char *retVal = NULL;

    if ( theUserFilterKeywords.length() > 0 )
    {
        unsigned int len = 0;
        unsigned int i;
        for ( i=0; i<theUserFilterKeywords.length(); i++ )
        {
            len = len + strlen(theUserFilterKeywords[i])+1;
        }
        retVal = new char[len];
        memset(retVal,'\0',len);
        for ( i=0; i<theUserFilterKeywords.length(); i++ )
        {
            strcat(retVal, theUserFilterKeywords[i]);
            if ( i < theUserFilterKeywords.length() - 1 )
            {
                strcat(retVal,",");
            }
        }
    }
    else
    {
        retVal = strdup("");
    }

    return retVal;
}

//D6000025 CORBA::Boolean ParameterLogManager_i::isLogEnabled (CORBA::Environment &IT_env)
CORBA::Boolean ParameterLogManager_i::isLogEnabled (CORBAENV_ONLY_CPP) //D6000025
{
    return (theLogEnabled == TRUE);
}

//D6000025 CORBA::Boolean ParameterLogManager_i::isLogDisabled (CORBA::Environment &IT_env)
CORBA::Boolean ParameterLogManager_i::isLogDisabled (CORBAENV_ONLY_CPP) //D6000025
{
    return (theLogEnabled != TRUE);
}

//D6000025 CORBA::Boolean ParameterLogManager_i::isFiltered (const char * tran, const char * client, const char * user, CORBA::Environment &IT_env)
CORBA::Boolean ParameterLogManager_i::isFiltered (const char * tran, const char * client, const char * user CORBAENV_LAST_CPP) //D6000025
{
    #ifdef PARMLOG_DEBUG
    cout << "entering ParameterLogManager_i::isFiltered" << endl;
    #endif

    if ( isLogEnabled() )
    {
        // log is enabled and no filter is specfied, no filter is used.
        if ( theTransactionFilterKeywords.length() == 0 &&
             theClientFilterKeywords.length() == 0 &&
             theUserFilterKeywords.length() == 0 )
        {
            return TRUE;
        }

        // serach transaction in keyword list
        #ifdef PARMLOG_DEBUG
        cout << "finding TransactionFilterKeywords" << endl;
        #endif
        unsigned int n= theTransactionFilterKeywords.length();
        
        //D6000358 start
        if ( n > 0 && ( tran == NULL || strlen(tran) == 0 ) )
        {
            return FALSE;
        }
        //D6000358 end

        if ( n > 0 && tran != NULL && strlen(tran) > 0 )
        {
            unsigned int i=0;
            for (i=0; i<n; i++)
            {
//              if ( strcmp(theTransactionFilterKeywords[i],tran) == 0 )     // exact check
                if ( strstr(tran, theTransactionFilterKeywords[i]) != NULL ) // ambiguous check
                {
                    break;
                }
            }             
            if ( i>=n )
            {
                return FALSE;
            }
        }
//      else
//      {
//          return FALSE;
//      }

        // serach client in keyword list
        #ifdef PARMLOG_DEBUG
        cout << "finding ClientFilterKeywords" << endl;
        #endif
        n= theClientFilterKeywords.length();

        //D6000358 start
        if ( n > 0 && ( client == NULL || strlen(client) == 0 ) )
        {
            return FALSE;
        }
        //D6000358 end

        if ( n > 0 && client != NULL && strlen(client) > 0 )
        {
            unsigned int i=0;
            for (i=0; i<n; i++)
            {
                if ( strcmp(theClientFilterKeywords[i],client) == 0 )
                {
                    break;
                }
            }             
            if ( i>=n )
            {
                return FALSE;
            }
        }
//      else
//      {
//          return FALSE;
//      }

        // serach user in keyword list
        #ifdef PARMLOG_DEBUG
        cout << "finding UserFilterKeywords" << endl;
        #endif
        n= theUserFilterKeywords.length();
        #ifdef PARMLOG_DEBUG
        cout << "n=" << n << endl;
        #endif
        
        //D6000358 start
        if ( n > 0 && ( user == NULL || strlen(user) == 0 ) )
        {
            return FALSE;
        }
        //D6000358 end

        if ( n > 0 && user != NULL && strlen(user) > 0 )
        {
            unsigned int i=0;
            for (i=0; i<n; i++)
            {
                #ifdef PARMLOG_DEBUG
                cout << "list=" << theUserFilterKeywords[i] << " keyword=" << user << endl;
                #endif
                if ( strcmp(theUserFilterKeywords[i],user) == 0 )
                {
                    break;
                }
            }             
            if ( i>=n )
            {
                return FALSE;
            }
        }
//      else
//      {
//          return FALSE;
//      }

        return TRUE;
    }
    else
    {
        return FALSE;
    }

}

//D6000025 void ParameterLogManager_i::putLog (const char * record, CORBA::Environment &IT_env)
void ParameterLogManager_i::putLog (const char * record CORBAENV_LAST_CPP) //D6000025
{
    #ifdef PARMLOG_DEBUG
    cout << "entering ParameterLogManager_i::putLog" << endl;
    #endif

    // getting current timestamp
    //DSIV00001249 struct timeb tp ;
    struct timeval tv;    //DSIV00001249
    struct tm tm;
    //DSIV00001249 ftime( &tp) ;
    //DSIV00001249 localtime_r( &tp.time, &tm );
    gettimeofday( &tv, NULL );      //DSIV00001249
    localtime_r( &tv.tv_sec, &tm ); //DSIV00001249

    char strTimestamp[27];
    //DSIV00001249 sprintf( strTimestamp, "%04d-%02d-%02d-%02d.%02d.%02d.%03d000",
    //DSIV00001249          tm.tm_year+1900,tm.tm_mon+1,tm.tm_mday,tm.tm_hour,tm.tm_min,tm.tm_sec,tp.millitm);
    sprintf( strTimestamp, "%04d-%02d-%02d-%02d.%02d.%02d.%06d",                                //DSIV00001249
             tm.tm_year+1900,tm.tm_mon+1,tm.tm_mday,tm.tm_hour,tm.tm_min,tm.tm_sec,tv.tv_usec); //DSIV00001249
 
    // making output string
    //
    // format:
    // thread: kkkkkk(uuuuuu) timestamp: yyyy-mm-yy-hh.mm.ss.nnnnnn <header>
    // <parameters>
    //
    char buf[PARMLOGMGR_BUFFER_SIZE];
    memset(buf,'\0',PARMLOGMGR_BUFFER_SIZE);
    ostrstream separator(buf,PARMLOGMGR_BUFFER_SIZE);
    separator << "thread: " << thread_self() << "(" << pthread_self() << ") ";
    separator << "timestamp: " << strTimestamp << " ";
    separator << record;

    char* str = separator.str();

    // sending paramater to ParameterLogControl object
    if ( theIPC != NULL )
    {
        // msgctl for reference
/*      struct msqid_ds ds;
        int __rc = msgctl( _ipc, IPC_STAT, &ds );

        if ( __rc == -1 )
        {
            #ifdef PARMLOG_DEBUG
            cout << "msgctl() error reported, rc=" << __rc << " error=" << errno << endl;
            #endif
        }
        else
        {
            #ifdef PARMLOG_DEBUG
            cout << "msgctl() reported, ";
            cout << "msg_qnum=" << ds.msg_qnum << " ";
            cout << "msg_qbytes=" << ds.msg_qbytes << " ";
            cout << "msg_stime=" << ds.msg_stime<< " ";
            cout << "msg_rtime=" << ds.msg_rtime<< " ";
            cout << "msg_ctime=" << ds.msg_ctime<< " ";
            cout << "msg_lspid=" << ds.msg_lspid<< " ";
            cout << "msg_lrpid=" << ds.msg_lrpid<< " ";
            cout << endl;
            #endif
        }
*/

        // msgsnd
        int _ipcsize = 0;
        char* _stripcsize = getenv("EVENT_IPCKEY_MMPARAMETER_SIZE");
        if ( _stripcsize == NULL )
        {
            _ipcsize = PARMLOGMGR_BUFFER_SIZE;
        }
        else
        {
            _ipcsize = atol(_stripcsize);
        }

        parmlog_msgbuf _msgbuf;
        _msgbuf.mtype = 11;
        memset (_msgbuf.mtext, '\0', sizeof(_msgbuf.mtext));
        strncpy(_msgbuf.mtext, str , _ipcsize-1);

        #ifdef PARMLOG_DEBUG
        cout << "about to send the following message" << endl;
        cout << _msgbuf.mtext << endl;
        cout << "about to call msgsnd() " << endl;
        #endif

        int _rc = msgsnd (theIPC, &_msgbuf, _ipcsize, IPC_NOWAIT);

        if ( _rc != 0 )
        {
            int _no = errno;
            cout << "msgsnd() error reported. rc=" << _rc << " errno=" << _no << endl;
        }
    }

}
