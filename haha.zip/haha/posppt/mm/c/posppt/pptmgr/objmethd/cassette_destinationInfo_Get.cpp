#ifndef lint
static char *sccsid =  "@(#) 1.3 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_destinationInfo_Get.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/23/07 15:29:56 [ 7/23/07 15:29:57 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2012. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2012. All rights reserved.
//
// SiView
// Name: cassette_destinationInfo_Get.cpp
//

#include "pptmgr.hpp"
#include "plot.hh"

//
//[Object Function Name]: long   cassette_destinationInfo_Get
//
// Date        Level    Author         Note
// ----------  -------- -------------  -------------------------------------------------
// 2006-09-21  D8000028 K.Kido         Initial Release(R80) for where next improvement
// 2007-07-23  P9000033 K.Kido         Fix memory fault

// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2012-10-10 PSN000054161 GC.Wang        Fix can not return stocker when a FOUP is empty
//
//[Function Description]
//  This objmethod returns destination order of input cassette(or Lot).
//  Lots in cassette are sorted by "lot_priorityOrderInCassette_Get"
//  The lot's equipment are sorted by "lot_equipmentOrder_GetByLotStatus"
//  The equipment stockers are sorted by "equipment_stockerOrder_GetByLotStatus"
//
// Destination information is NOT returned following conditions.
//  1. The input cassette is empty.
//  2. The input Lot is not in cassette.
//  3. represent Lot is inprocessing.
//  4. Some system error occurs (Invalid objref/SQL error)
//
//[Input Parameters]:
//  in  pptObjCommonIn    strObjCommonIn;
//  in  objectIdentifier  cassetteID;
//  in  objectIdentifier  lotID;  (Optional)
//
//[Output Parameters]:
//
//  out objCassette_destinationInfo_Get_out  strCassette_destinationInfo_Get_out;
//
//  typedef struct objCassette_destinationInfo_Get_out_struct {
//     pptRetCode                     strResult;
//     pptWhereNextInterBayInqResult  destinationOrder;
//  } objCassette_destinationInfo_Get_out;
//
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//  RC_INVALID_INPUT_PARM     MSG_INVALID_INPUT_PARM
//  RC_NOT_FOUND_CST          MSG_NOT_FOUND_CST
//  RC_INVALID_LOT_PROCSTAT   MSG_INVALID_LOT_PROCSTAT
//
CORBA::Long PPTManager_i::cassette_destinationInfo_Get(
                            objCassette_destinationInfo_Get_out& strCassette_destinationInfo_Get_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& cassetteID,
                            const objectIdentifier& lotID)
{
    char * methodName = NULL;
    CORBA::Long rc = RC_OK;
    try
    {
        PosLot_var aLot;

        PPT_METHODTRACE_V2("", "### Input parameter cassetteID = ", cassetteID.identifier ) ;
        PPT_METHODTRACE_V2("", "### Input parameter lotID      = ", lotID.identifier ) ;
        objCassette_lotList_GetWithPriorityOrder_out strCassette_lotList_GetWithPriorityOrder_out;
        objectIdentifier lotCastID;

        if( 0 == CIMFWStrLen(lotID.identifier) )
        {
            if(0 == CIMFWStrLen(cassetteID.identifier))
            {
                SET_MSG_RC(strCassette_destinationInfo_Get_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM);
                return RC_INVALID_INPUT_PARM;
            }

            /******************************************/
            /*  Get Lot priority order in cassette    */
            /******************************************/
            rc = cassette_lotList_GetWithPriorityOrder( strCassette_lotList_GetWithPriorityOrder_out, strObjCommonIn, cassetteID );

            if (rc == RC_CAST_IS_EMPTY)
            {
                PPT_METHODTRACE_V1("", "### Cassette is empty.") ;
//PSN000054161               SET_MSG_RC( strCassette_destinationInfo_Get_out, MSG_OK, RC_OK ) ;
//PSN000054161               return RC_OK;
//PSN000054161 add start
                CORBA::Boolean bStayOnPort = TRUE;
                CORBA::String_var envStayOnPort = CIMFWStrDup(getenv(SP_STAYONPORT_WITH_NO_DESTINATION));
                PPT_METHODTRACE_V2("", "SP_STAYONPORT_WITH_NO_DESTINATION", envStayOnPort);
                if ( 0 == CIMFWStrCmp(envStayOnPort, "0") )
                {
                    bStayOnPort = FALSE;
                    PPT_METHODTRACE_V1("", "bStayOnPort = FALSE");
                }
                if ( bStayOnPort != TRUE )
                {
                    PPT_METHODTRACE_V1("", "bStayOnPort != TRUE");
                    /*------------------------------------*/
                    /*   Get Cassette Equipment Info      */
                    /*------------------------------------*/
                    objCassette_equipmentID_Get_out strCassette_equipmentID_Get_out;
                    rc = cassette_equipmentID_Get( strCassette_equipmentID_Get_out,
                                                   strObjCommonIn,
                                                   cassetteID);
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "cassette_equipmentID_Get != RC_OK");
                        strCassette_destinationInfo_Get_out.strResult = strCassette_equipmentID_Get_out.strResult;
                        return rc;
                    }

                    if( CIMFWStrLen(strCassette_equipmentID_Get_out.equipmentID.identifier) != 0)
                    {
                        /*---------------------------------------------------------*/
                        /*   Get Cassette Equipment related stocker information    */
                        /*---------------------------------------------------------*/
                        PPT_METHODTRACE_V2("", "Call equipment related stocker information for :" , strCassette_equipmentID_Get_out.equipmentID.identifier);
                        objEquipment_stockerInfo_Get_out strEquipment_stockerInfo_Get_out;
                        rc = equipment_stockerInfo_Get( strEquipment_stockerInfo_Get_out,
                                                        strObjCommonIn, 
                                                        strCassette_equipmentID_Get_out.equipmentID);
                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V1("", "equipment_stockerInfo_Get() rc != RC_OK");
                            strCassette_destinationInfo_Get_out.strResult = strEquipment_stockerInfo_Get_out.strResult;
                            return( rc );
                        }

                        pptEqpStockerStatusSequence tmpEqpStockerStatusSeq;
                        CORBA::ULong stkLen = 0;
                        CORBA::ULong mLen =  strEquipment_stockerInfo_Get_out.equipmentStockerInfo.strEqpStockerStatus.length();
                        tmpEqpStockerStatusSeq.length(mLen);
                        PPT_METHODTRACE_V2("", "strEquipment_stockerInfo_Get_out.equipmentStockerInfo.strEqpStockerStatus.length--->", mLen);
                        for ( CORBA::ULong i=0; i < mLen; i++ )
                        {
                            if ( 0 < CIMFWStrLen(strEquipment_stockerInfo_Get_out.equipmentStockerInfo.strEqpStockerStatus[i].stockerID.identifier) )
                            {
                                PPT_METHODTRACE_V2("", "StockerID", strEquipment_stockerInfo_Get_out.equipmentStockerInfo.strEqpStockerStatus[i].stockerID.identifier);
                                PPT_METHODTRACE_V2("", "StockerType", strEquipment_stockerInfo_Get_out.equipmentStockerInfo.strEqpStockerStatus[i].stockerType);

                                if ( 0 != CIMFWStrCmp(SP_Stocker_Type_Auto, strEquipment_stockerInfo_Get_out.equipmentStockerInfo.strEqpStockerStatus[i].stockerType) )
                                {
                                    PPT_METHODTRACE_V1("", "Not AutoStocker ...<continue>");
                                    continue;
                                }
                                stkLen++;
                                PPT_METHODTRACE_V2("", "stkLen--->", stkLen);
                                tmpEqpStockerStatusSeq[stkLen-1] = strEquipment_stockerInfo_Get_out.equipmentStockerInfo.strEqpStockerStatus[i];
                            }
                        } 
                        tmpEqpStockerStatusSeq.length(stkLen);
                        if( 0 < stkLen )
                        {
                            PPT_METHODTRACE_V2("", "Auto Stocker Count", stkLen);
                            strCassette_destinationInfo_Get_out.destinationOrder.strWhereNextEqpStatus.length(1);
                            strCassette_destinationInfo_Get_out.destinationOrder.strWhereNextEqpStatus[0].strEqpStockerStatus = tmpEqpStockerStatusSeq;
                        }
                    }
                }
                SET_MSG_RC( strCassette_destinationInfo_Get_out, MSG_OK, RC_OK ) ;
                return RC_OK;
//PSN000054161 add end
            }
            else if(rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "lot_priorityOrderInCassette_Get() != RC_OK") ;
                strCassette_destinationInfo_Get_out.strResult = strCassette_lotList_GetWithPriorityOrder_out.strResult;
                return rc;
            }

            /*****************************/
            /* Set input Cassette ID     */
            /*****************************/
            lotCastID = cassetteID;
        }
        else
        {
//P9000033 add start
            /********************/
            /*  Set lot count   */
            /********************/
            strCassette_lotList_GetWithPriorityOrder_out.waitingLotCount = 1;
            strCassette_lotList_GetWithPriorityOrder_out.holdLotCount    = 0;
            strCassette_lotList_GetWithPriorityOrder_out.bankInLotCount  = 0;
//P9000033 add end
            /********************************/
            /*  Set specified Lot status    */
            /********************************/
            strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq.length(1);
            strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].lotID = lotID;

            objLot_allState_Get_out strLot_allState_Get_out ;
            rc = lot_allState_Get(strLot_allState_Get_out,strObjCommonIn,lotID) ;
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_allState_Get() != RC_OK") ;
                strCassette_destinationInfo_Get_out.strResult = strLot_allState_Get_out.strResult ;
                return rc ;
            }

            strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].currentStatus.lotState        = strLot_allState_Get_out.lotState;
            strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].currentStatus.productionState = strLot_allState_Get_out.productionState;
            strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].currentStatus.holdState       = strLot_allState_Get_out.holdState;
            strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].currentStatus.finishedState   = strLot_allState_Get_out.finishedState;
            strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].currentStatus.processState    = strLot_allState_Get_out.processState;
            strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].currentStatus.inventoryState  = strLot_allState_Get_out.inventoryState;

            /*******************************************/
            /* Set Lot inventory sate and hold state   */
            /*******************************************/
            PPT_CONVERT_LOTID_TO_LOT_OR( aLot, lotID, strCassette_destinationInfo_Get_out, cassette_destinationInfo_Get );

            /********************************/
            /*   Get lot Base information   */
            /********************************/
            posLotBaseInfo_var aLotBaseInfo;
            try
            {
                aLotBaseInfo = aLot->getLotBaseInfo();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getState)

            strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].representativeState = aLotBaseInfo->representativeState;
            strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].productID = aLotBaseInfo->productSpecificationID;

            try
            {
                strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].onFloorFlag = aLot->isOnFloor();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::isOnFloor);

            try
            {
                strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].onHoldFlag = aLot->isOnHold();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::isOnHold);

            /*****************************/
            /* Set Cassette ID of Lot    */
            /*****************************/
            objLot_cassetteList_GetDR_out strLot_cassetteList_GetDR_out;
            rc = lot_cassetteList_GetDR( strLot_cassetteList_GetDR_out, strObjCommonIn,
                                         strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].lotID );

            if ( rc != RC_OK  )
            {
                PPT_METHODTRACE_V1("", "lot_cassetteList_GetDR() != RC_OK") ;
                strCassette_destinationInfo_Get_out.strResult = strLot_cassetteList_GetDR_out.strResult ;
                return ( rc );
            }

            lotCastID = strLot_cassetteList_GetDR_out.cassetteID ;
            if( 0 == CIMFWStrLen(lotCastID.identifier))
            {
                PPT_METHODTRACE_V1("", "### The lot is not in cassette.") ;
                SET_MSG_RC( strCassette_destinationInfo_Get_out, MSG_NOT_FOUND_CST, RC_NOT_FOUND_CST ) ;
                return RC_NOT_FOUND_CST;
            }

            //##### Debug trace
            PPT_METHODTRACE_V1("", "##### Lot status. ") ;
            PPT_METHODTRACE_V2("", "### LotID           = ", strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].lotID.identifier );
            PPT_METHODTRACE_V2("", "### cassetteID      = ", lotCastID.identifier );
            PPT_METHODTRACE_V2("", "### onFloorFlag     = ", strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].onFloorFlag );
            PPT_METHODTRACE_V2("", "### onHoldFlag      = ", strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].onHoldFlag );
            PPT_METHODTRACE_V2("", "### LotState        = ", strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].currentStatus.lotState        );
            PPT_METHODTRACE_V2("", "### ProductionState = ", strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].currentStatus.productionState );
            PPT_METHODTRACE_V2("", "### HoldState       = ", strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].currentStatus.holdState       );
            PPT_METHODTRACE_V2("", "### FinishedState   = ", strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].currentStatus.finishedState   );
            PPT_METHODTRACE_V2("", "### ProcessState    = ", strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].currentStatus.processState    );
            PPT_METHODTRACE_V2("", "### InventoryState  = ", strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0].currentStatus.inventoryState  );
        }

        CORBA::ULong lotLen = strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq.length();

        pptWhereNextEqpStatusSequence priorEqpSeq;
        pptLotStatusInfo priorLot;

        CORBA::ULong lotCnt = 0 ;
        CORBA::Boolean usePriorInfoFlag = FALSE;
        CORBA::Boolean getStockerFlag = FALSE;

        if( 0 == lotLen )
        {
            PPT_METHODTRACE_V1("", "### lotLen == 0. Return error.");
            SET_MSG_RC( strCassette_lotList_GetWithPriorityOrder_out, MSG_INVALID_DATA_CONTENTS, RC_INVALID_DATA_CONTENTS );
            return RC_INVALID_DATA_CONTENTS;
        }

        /****************************************/
        /*  Get cassette detail information     */
        /****************************************/
        objCassette_LocationInfo_GetDR_out strCassette_LocationInfo_GetDR_out;
        rc = cassette_LocationInfo_GetDR( strCassette_LocationInfo_GetDR_out,
                                          strObjCommonIn,
                                          lotCastID );

        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "cassette_LocationInfo_GetDR() != RC_OK") ;
            strCassette_destinationInfo_Get_out.strResult = strCassette_LocationInfo_GetDR_out.strResult ;
            return ( rc );
        }

        /***************************************************************/
        /*  Check and get cassette(or lot) destination information.    */
        /***************************************************************/
        if( 0 < strCassette_lotList_GetWithPriorityOrder_out.waitingLotCount )
        {
            /***********************/
            /*  Search prior Lot   */
            /***********************/
            for( CORBA::ULong lotCnt = 0 ; lotCnt < strCassette_lotList_GetWithPriorityOrder_out.waitingLotCount ; lotCnt++ )
            {
                /******************************/
                /*  Get Lot equipment order   */
                /******************************/
                objLot_equipmentOrder_GetByLotStatus_out strLot_equipmentOrder_GetByLotStatus_out;
                rc = lot_equipmentOrder_GetByLotStatus( strLot_equipmentOrder_GetByLotStatus_out,
                                                        strObjCommonIn,
                                                        strCassette_LocationInfo_GetDR_out.cassetteLocationInfo,
                                                        strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[lotCnt] );

                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "lot_equipmentOrder_GetByLotStatus() != RC_OK") ;
                    strCassette_destinationInfo_Get_out.strResult = strLot_equipmentOrder_GetByLotStatus_out.strResult;
                    return rc;
                }

                /**************************************************************************/
                /*  In any case, first lot in the cassete should be set as prior Lot.     */
                /**************************************************************************/
                if( 0 == lotCnt )
                {
                    PPT_METHODTRACE_V1("", "### 0 == lot loop.") ;
                    priorLot = strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[lotCnt] ;
                    priorEqpSeq = strLot_equipmentOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq ;
                }

                /**********************************************************************************/
                /*  RC_OK and "availableEqpExist" means...                                        */
                /*  1. The Lot is wip on the available Equipment.                                 */
                /*  2. Or the Lot does not have machine list. (It does not mean equipment down)   */
                /**********************************************************************************/
                if( TRUE == strLot_equipmentOrder_GetByLotStatus_out.availableEqpExistFlag )
                {
                    PPT_METHODTRACE_V1("", "### Available Equipment is detected.") ;
                    /*****************************************************************/
                    /*  If lotCnt == 0, the equipment information has already set.   */
                    /*****************************************************************/
                    if( 0 != lotCnt )
                    {
                        PPT_METHODTRACE_V1("", "### Set Equipment and Lot information.") ;
                        priorLot = strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[lotCnt] ;
                        priorEqpSeq = strLot_equipmentOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq ;
                    }
                    break;
                }
            }
        }
        /**************************************************/
        /*  Only Hold or BankIn Lot exists in Cassette.   */
        /*  Always set first Lot                          */
        /**************************************************/
        else
        {
            /******************************/
            /*  Get Lot equipment order   */
            /******************************/
            objLot_equipmentOrder_GetByLotStatus_out strLot_equipmentOrder_GetByLotStatus_out;
            rc = lot_equipmentOrder_GetByLotStatus( strLot_equipmentOrder_GetByLotStatus_out,
                                                    strObjCommonIn,
                                                    strCassette_LocationInfo_GetDR_out.cassetteLocationInfo,
                                                    strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0] );

            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "lot_equipmentOrder_GetByLotStatus() != RC_OK") ;
                strCassette_destinationInfo_Get_out.strResult = strLot_equipmentOrder_GetByLotStatus_out.strResult;
                return rc;
            }

            priorLot = strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq[0] ;
            priorEqpSeq = strLot_equipmentOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq ;
        }

        /*****************************************************/
        /*  At here, cassette represent Lot is decided.      */
        /*  Then, if the Lot is in Process, return error!    */
        /*****************************************************/
        if( CIMFWStrCmp( priorLot.currentStatus.processState, SP_Lot_ProcState_Processing) == 0 )
        {
            PPT_SET_MSG_RC_KEY2( strCassette_destinationInfo_Get_out,
                                 MSG_INVALID_LOT_PROCSTAT,
                                 RC_INVALID_LOT_PROCSTAT,
                                 priorLot.lotID.identifier,
                                 priorLot.currentStatus.processState);
            return RC_INVALID_LOT_PROCSTAT ;
        }

        /******************************/
        /*  Get equipment stockers.   */
        /******************************/
        PPT_METHODTRACE_V1("", "### Get Stocker information.") ;
        objEquipment_stockerOrder_GetByLotStatus_out strEquipment_stockerOrder_GetByLotStatus_out;
        rc = equipment_stockerOrder_GetByLotStatus( strEquipment_stockerOrder_GetByLotStatus_out,
                                                    strObjCommonIn,
                                                    strCassette_LocationInfo_GetDR_out.cassetteLocationInfo,
                                                    priorLot,
                                                    priorEqpSeq ) ;

        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "equipment_stockerOrder_GetByLotStatus() != RC_OK") ;
            strCassette_destinationInfo_Get_out.strResult = strEquipment_stockerOrder_GetByLotStatus_out.strResult;
            return rc;
        }

        /**********************************/
        /*  Set destination information   */
        /**********************************/
        strCassette_destinationInfo_Get_out.destinationOrder.strWhereNextEqpStatus = strEquipment_stockerOrder_GetByLotStatus_out.strWhereNextEqpStatusSeq ;

        /***************************/
        /*  Set return structure   */
        /***************************/
        {
            /***************************/
            /*  Set Lot information    */
            /***************************/
            strCassette_destinationInfo_Get_out.destinationOrder.lotID           = priorLot.lotID;
            strCassette_destinationInfo_Get_out.destinationOrder.lotState        = priorLot.currentStatus.lotState;
            strCassette_destinationInfo_Get_out.destinationOrder.productionState = priorLot.currentStatus.productionState;
            strCassette_destinationInfo_Get_out.destinationOrder.holdState       = priorLot.currentStatus.holdState;
            strCassette_destinationInfo_Get_out.destinationOrder.finishedState   = priorLot.currentStatus.finishedState;
            strCassette_destinationInfo_Get_out.destinationOrder.processState    = priorLot.currentStatus.processState ;
            strCassette_destinationInfo_Get_out.destinationOrder.inventoryState  = priorLot.currentStatus.inventoryState;

            /********************************/
            /*  Set cassette information    */
            /********************************/
            strCassette_destinationInfo_Get_out.destinationOrder.cassetteID = strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.cassetteID;
            strCassette_destinationInfo_Get_out.destinationOrder.transferStatus = strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferStatus;

            if( 0 == CIMFWStrCmp(strCassette_destinationInfo_Get_out.destinationOrder.transferStatus, SP_TransState_EquipmentIn) ||
                0 == CIMFWStrCmp(strCassette_destinationInfo_Get_out.destinationOrder.transferStatus, SP_TransState_EquipmentOut) )
            {
                strCassette_destinationInfo_Get_out.destinationOrder.current_equipmentID = strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.equipmentID;
            }
            else
            {
                strCassette_destinationInfo_Get_out.destinationOrder.current_stockerID = strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.stockerID;
            }

            strCassette_destinationInfo_Get_out.destinationOrder.transferReserveUserID.identifier = strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.transferReserveUserID;

            //Debug trace
            PPT_METHODTRACE_V1("", "###### pptWhereNextInterBayInqResult");
            PPT_METHODTRACE_V2("", "### LotID           = ", strCassette_destinationInfo_Get_out.destinationOrder.lotID.identifier );
            PPT_METHODTRACE_V2("", "### cassetteID      = ", strCassette_destinationInfo_Get_out.destinationOrder.cassetteID.identifier );
            PPT_METHODTRACE_V2("", "### LotState        = ", strCassette_destinationInfo_Get_out.destinationOrder.lotState        );
            PPT_METHODTRACE_V2("", "### ProductionState = ", strCassette_destinationInfo_Get_out.destinationOrder.productionState );
            PPT_METHODTRACE_V2("", "### HoldState       = ", strCassette_destinationInfo_Get_out.destinationOrder.holdState       );
            PPT_METHODTRACE_V2("", "### FinishedState   = ", strCassette_destinationInfo_Get_out.destinationOrder.finishedState   );
            PPT_METHODTRACE_V2("", "### ProcessState    = ", strCassette_destinationInfo_Get_out.destinationOrder.processState    );
            PPT_METHODTRACE_V2("", "### InventoryState  = ", strCassette_destinationInfo_Get_out.destinationOrder.inventoryState  );
            PPT_METHODTRACE_V2("", "### transferStatus  = ", strCassette_destinationInfo_Get_out.destinationOrder.transferStatus  );
            PPT_METHODTRACE_V2("", "### current_stockerID      = ", strCassette_destinationInfo_Get_out.destinationOrder.current_stockerID.identifier );
            PPT_METHODTRACE_V2("", "### current_equipmentID    = ", strCassette_destinationInfo_Get_out.destinationOrder.current_equipmentID.identifier );
            PPT_METHODTRACE_V2("", "### transferReserveUserID  = ", strCassette_destinationInfo_Get_out.destinationOrder.transferReserveUserID.identifier );
        }

        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_destinationInfo_Get");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_destinationInfo_Get_out, cassette_destinationInfo_Get, methodName)
}
