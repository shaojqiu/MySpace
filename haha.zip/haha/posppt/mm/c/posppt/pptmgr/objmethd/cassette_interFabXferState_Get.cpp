//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_interFabXferState_Get.cpp
//

#include "pptmgr.hpp"
#include "pcas.hh"

//[Object Function Name]: long cassette_interFabXferState_Get()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/21 DSIV00000214 H.Mutoh        Multi Fab Transfer Support
//
//[Function Description]:
//  Get interFabXferState of the cassette. 
//
//[Input Parameters]:
//  const pptObjCommonIn& strObjCommonIn
//  const objCassette_interFabXferState_Get_in& strCassette_interFabXferState_Get_in
//
//  typedef struct objCassette_interFabXferState_Get_in_struct {
//      objectIdentifier& lotID;
//      any siInfo;
//  } objCassette_interFabXferState_Get_in;
//
//[Output Parameters]:
//  objCassette_interFabXferState_Get_out& strCassette_interFabXferState_Get_out
//
//  typedef struct objCassette_interFabXferState_Get_out_struct {
//      string interFabXferState;
//      any siInfo;
//  } objCassette_interFabXferState_Get_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK

CORBA::Long PPTManager_i::cassette_interFabXferState_Get(
       objCassette_interFabXferState_Get_out&      strCassette_interFabXferState_Get_out,
       const pptObjCommonIn&                       strObjCommonIn,
       const objCassette_interFabXferState_Get_in& strCassette_interFabXferState_Get_in)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_interFabXferState_Get");

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        PPT_METHODTRACE_V2("", "in-para cassetteID:",
                           strCassette_interFabXferState_Get_in.cassetteID.identifier);

        /*------------------------------------*/
        /*   Get Cassette interFabXferState   */
        /*------------------------------------*/
        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette, strCassette_interFabXferState_Get_in.cassetteID,
                                     strCassette_interFabXferState_Get_out, cassette_interFabXferState_Get );

        try
        {
            strCassette_interFabXferState_Get_out.interFabXferState = aCassette->getInterFabTransferState();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getInterFabXferState);

        PPT_METHODTRACE_V2("", "interFabXferState :", strCassette_interFabXferState_Get_out.interFabXferState);

        /*----------------------*/
        /*   Return to Caller   */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_interFabXferState_Get");
        return rc;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_interFabXferState_Get_out, cassette_interFabXferState_Get, methodName);
}
