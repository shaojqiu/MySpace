#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/chamberStatusChangeEvent_Make.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:37:34 [ 7/13/07 19:37:35 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: chamberStatusChangeEvent_Make.cpp
//

#include "pptmgr.hpp"

#include "mtrllctn.hh"
#include "parea.hh"
#include "pbank.hh"
#include "pbufrs.hh"
#include "pcas.hh"
#include "pdcdf.hh"
//D6000044 #include "pdorv.hh"
#include "pdp.hh"
#include "pdpgl.hh"
#include "pe10st.hh"             //DCR 9900001
#include "pevalrm.hh"
#include "pevbase.hh"
#include "pevcmbs.hh"
#include "peveqps.hh"
#include "pevmg.hh"
#include "pevmggl.hh"
#include "pflwbch.hh"
#include "pflwdp.hh"
#include "plcrc.hh"
#include "plot.hh"
//PTR2300043 #include "pltopnt.hh"            //(DCR9900205) (R20b)
#include "pmc.hh"
#include "pmcmggl.hh"
#include "pmcnote.hh"
#include "pmcrc.hh"
#include "pmstat.hh"             //DCR 9900001
#include "ppcdf.hh"
#include "ppcdr.hh"
#include "ppcdrcp.hh"
#include "ppcflw.hh"
#include "ppcflwx.hh"
//D5000016 #include "ppcgrp.hh"
//D5000016 #include "ppcj.hh"
//D5000016 #include "ppcjmg.hh"
#include "ppcope.hh"
#include "ppcopsp.hh"
#include "ppcrs.hh"
#include "pperson.hh"
#include "pportrs.hh"
#include "pprmggl.hh"
#include "pprsp.hh"
#include "prcssctv.hh"
#include "prmsts.hh"             //DCR 9900001
#include "pstmc.hh"
#include "ptesttp.hh"
//D5000016 #include "ptrrs.hh"

#define SP_EqpStateConvertType_ByStartLot           "STLT"      //DCR 9900001
#define SP_EqpStateConvertType_ByStartSubLot        "STSL"      //DCR 9900001
#define SP_EqpStateConvertType_ByStartRoute         "STRT"      //DCR 9900001
#define SP_EqpStateConvertType_ByInProcessLot       "IPLT"      //DCR 9900001
#define SP_EqpStateConvertType_ByInProcessSubLot    "IPSL"      //DCR 9900001
#define SP_EqpStateConvertType_ByInProcessRoute     "IPRT"      //DCR 9900001

// Class: PPTManager
//
// Service: chamberStatusChangeEvent_Make()
//
// Change history:
// Date       Defect#     Person         Comments
// --------   --------    -------------- -------------------------------------------
// 98/12/11   DCR 9900001 M.Hirouchi     Add data member for E10 (IMD)
// 2000/09/12 P3000139    T.Yamano       SET_MSG_RC(MSG_OK,RC_OK) Comment Out
// 2003/05/19 D5000016 K.Kido         Useless class deletion.
// 2004/11/09 D6000044    F.Masada       Remove Document Component. 
//
// Description:
//
// Return:
//     Long
//
// Parameter:
//     objChamberStatusChangeEvent_Make_out&  strChamberStatusChangeEvent_Make_out
//     const pptObjCommonIn&                  strObjCommonIn
//     const objectIdentifier&                equipmentID
//     const pptEqpChamberStateSequence&      strEqpChamberState
//     const char*                            claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long   PPTManager_i::chamberStatusChangeEvent_Make(
     objChamberStatusChangeEvent_Make_out&  strChamberStatusChangeEvent_Make_out ,
     const pptObjCommonIn&                  strObjCommonIn                       ,
     const char*                            transactionID                        ,
     const objectIdentifier&                equipmentID                          ,
     const pptEqpChamberStateSequence&      strEqpChamberState                   ,
     const char*                            claimMemo                            )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::chamberStatusChangeEvent_Make");

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        posChamberStatusChangeEventRecord  chmbStatChgEvtData ;

        CORBA::Long length  = strEqpChamberState.length() ;
        CORBA::Long i       = 0 ;

//P3000139        SET_MSG_RC( strChamberStatusChangeEvent_Make_out ,
//P3000139                              MSG_OK,
//P3000139                              RC_OK   )

        for ( i = 0 ; i < length ; i++ ){
            /*------------------------------------------*/
            /*   Set Chamber Status Change Event Data   */
            /*------------------------------------------*/
            chmbStatChgEvtData.equipmentID                      = equipmentID.identifier;
            chmbStatChgEvtData.processResourceID                = strEqpChamberState[i].chamberID.identifier;
            chmbStatChgEvtData.processResourceState             = strEqpChamberState[i].previousStatus.identifier;
            chmbStatChgEvtData.processResourceE10State          = strEqpChamberState[i].previousE10Status.identifier;        //DCR 9900001
            chmbStatChgEvtData.actualProcessResourceState       = strEqpChamberState[i].previousActualStatus.identifier;     //DCR 9900001
            chmbStatChgEvtData.actualProcessResourceE10State    = strEqpChamberState[i].previousActualE10Status.identifier;  //DCR 9900001
            chmbStatChgEvtData.startTimeStamp                   = strEqpChamberState[i].prevStateStartTime;
            chmbStatChgEvtData.newProcessResourceState          = strEqpChamberState[i].chamberStatusCode.identifier;
            chmbStatChgEvtData.newProcessResourceE10State       = strEqpChamberState[i].chamberE10Status.identifier;         //DCR 9900001
            chmbStatChgEvtData.newActualProcessResourceState    = strEqpChamberState[i].actualStatus.identifier;             //DCR 9900001
            chmbStatChgEvtData.newActualProcessResourceE10State = strEqpChamberState[i].actualE10Status.identifier;          //DCR 9900001
            chmbStatChgEvtData.eventCommon.transactionID        = transactionID;
            chmbStatChgEvtData.eventCommon.userID               = strObjCommonIn.strUser.userID.identifier;
            chmbStatChgEvtData.eventCommon.eventTimeStamp       = strObjCommonIn.strTimeStamp.reportTimeStamp;
            chmbStatChgEvtData.eventCommon.eventShopDate        = strObjCommonIn.strTimeStamp.reportShopdate;
            chmbStatChgEvtData.eventCommon.eventMemo            = claimMemo;

            /*--------------------*/
            /*   Put Event Data   */
            /*--------------------*/

            PosEventBase_var anEvent ;

            CORBA::Any eventRecord ;
            eventRecord <<= chmbStatChgEvtData ;

            try
            {
                anEvent = theEventManager->createEvent( eventRecord );
            }

            catch( PosEventManager::InvalidEventRecordTypeSignal )
            {
                SET_FW_MSG_RC_NO_KEY( strChamberStatusChangeEvent_Make_out ,
                                      chamberStatusChangeEvent_Make        ,
                                      MSG_INVALID_EVENTRECORD_TYPE         ,
                                      RC_INVALID_EVENTRECORD_TYPE          ,
                                      PosEventManager::createEvent         ,
                                      InvalidEventRecordTypeSignal         )
                return  RC_INVALID_EVENTRECORD_TYPE ;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosEventManager::createEvent)
        }
        PPT_METHODTRACE_EXIT("PPTManager_i::chamberStatusChangeEvent_Make");
        return  RC_OK ;
    }
    CATCH_GLOBAL_EXCEPTIONS(strChamberStatusChangeEvent_Make_out, chamberStatusChangeEvent_Make, methodName)
}
