#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_zoneType_Get.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:37:21 [ 7/13/07 19:37:22 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_zoneType_Get.cpp
//

#include "pptmgr.hpp"

#include "pcas.hh"
#include "plot.hh"
#include "pprmggl.hh"


//[Object Function Name]: long   cassette_zoneType_Get
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2000-09-20  0.00      S.Tokumasu     Initial Release (R30)
// 2000-10-24  P3000284  K.Matsuei      ZoneType Error *
// 2000-10-26  P3000298  S.Kawabe       using CIMFWStrDup(getenv("SP_XX")); 
// 2000/11/09  P2200204  R.Furuta       Initialize local pointers
// 2000/11/27  P3000339  S.Tokumasu     Add Priority (Class)
// 2001/01/17  P3000426  K.Matsuei      Bug fix for Memory Leak
// 2001/05/29  D4000011  M.SHimizu      Add getenv Values on Manager Class Member
// 2002/02/13  D4100134  C.Tsuchiya     Drop D4000011
// 2002/04/03  P4100313  K.Kimura       "cout" is changed into Method Trace
// 2002/08/21  P4200111  K.Matsuei      ZoneType of Lot is not displayed correctly.
// 2002/10/21  D4200062  K.Kido         Add : getLotInfo flag for backupOperation(Rel4.2).
// 2004/01/26  P5100103  T.Hikari       Change strEquipment_getTypeDR_out.strResult from
//                                      strCassette_zoneType_Get_out.strResult
// 2005/11/09  D7000026  K.Kido         Delete unnecessary method.
// 2006/10/31  D7000371  K.Kido         Omit Q-Atctions.
// 2007/04/20  D9000001  M.Murata       64bit support.
//
//[Function Description]:
//  1.Get cassette information, then get all lot information with lotIDs in cassette information.
//    Determine the Carrier Attribute value from all of lots  information according to the following conditions.
//  2.if Environment value(ZONE_TYPE_FLAG=ON), read a record of "zone_type.ini",
//  3.Check Carrier Attribute Type & Carrier Attribute value with in-parameter .
//    Determine  zone_type of carrier.
//
//  < carrier Empty>
//       frcast.cast_used_capacity = 0 then, values ="Empty"
//       frcast.cast_used_capacity > 0 then, values ="Ocupied"
//       related Carrier Attribute Type is SP_ZONE_ATTR_EMPTY(="Empty")
//
//  < carrier Category>
//       frcast.cast_category
//       related Carrier Attribute Type is SP_ZONE_ATTR_CATEGORY(="CarrierCategory")
//       values = depend on SM definition
//
//  < carrier Status>
//       frcast.drbl_state
//       related Carrier Attribute Type is SP_ZONE_ATTR_CARRIER_STATE(="CarrierStatus")
//       value = "AVAILABLE" / "NOTAVAILABLE"
//
//  < lot Priority Class>
//       frlot.priority_class
//       related Carrier Attribute Type is SP_ZONE_ATTR_PRIORITY_CLASS(="LotPriorityClass")
//       value = 0/1/2/3/4/5
//
//  < next Equipment>
//       related Carrier Attribute Type is SP_ZONE_ATTR_NEXT_EQUIPMENT(="NextEquipment")
//       values = depend on SM definition
//
//  < next EquipmentType>
//       related Carrier Attribute Type is SP_ZONE_ATTR_NEXT_EQUIPMENT_TYPE(="NextEquipmentType")
//       values = depend on SM definition
//
//  < lot Status All>
//       related Carrier Attribute Type is SP_ZONE_ATTR_LOT_STATUS_ALL(="LotStatusAll")
//       all lot status is same
//       values = "Waiting"/"OnHold"/"InBank"/"Scrap"
//
//  < lot Type All>
//       frlot.lot_type
//       related Carrier Attribute Type is SP_ZONE_ATTR_LOT_TYPE_ALL(="LotTypeAll")
//       all lot type is same
//       values = "Dummy"/"Engineering"/"Equipment Monitor"/"Process Monitor"/"Production"/"Other"
//
//  < lot Status One>
//       related Carrier Attribute Type is SP_ZONE_ATTR_LOT_STATUS_ONE(="LotStatusOne")
//       at least one lot status is the following value
//       values = "Waiting"/"OnHold"/"InBank"/"Scrap"
//
//  < lot Type One>
//       related Carrier Attribute Type is SP_ZONE_ATTR_LOT_TYPE_ONE(="LotTypeOne")
//       at least one lot status is the following value
//       values = "Dummy"/"Engineering"/"Equipment Monitor"/"Process Monitor"/"Production"/"Other"
//
//[Input Parameters]:
//  in  pptObjCommonIn    strObjCommonIn;
//  in  objectIdentifier  cassetteID;
//
//[Output Parameters]:
//
//  out objCassette_zoneType_Get_out  strCassette_zoneType_Get_out;
//
//  typedef struct objCassette_zoneType_Get_out_struct {
//     pptRetCode        strResult;
//     string            zoneType;
//  } objCassette_zoneType_Get_out;
//
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//  RC_NOT_FOUND_LOT          MSG_NOT_FOUND_LOT
//  RC_NOT_FOUND_CASSETTE     MSG_NOT_FOUND_CASSETTE
//  RC_LOCKED_BY_ANOTHER      MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR           MSG_SYSTEM_ERROR
//
//[Pseudo Code]:
//

CORBA::Long PPTManager_i::cassette_zoneType_Get(
                    objCassette_zoneType_Get_out& strCassette_zoneType_Get_out,
                    const pptObjCommonIn& strObjCommonIn,
                    const objectIdentifier& cassetteID )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_zoneType_Get");

        PPT_METHODTRACE_V2( "","inparam [cassetteID]", cassetteID.identifier);

        CORBA::Long rc;
        LotSequence* aLotSequence = NULL; //P2200204
        LotSequence_var aLotSequenceVar;
        PosLot_var aLot;
        posLotInfo zoneLotInfo;
        CORBA::Long i, j;

        strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(SP_ZONE_DEFAULT);

        if ( 0 < CIMFWStrLen(cassetteID.identifier) )
        {
            PPT_METHODTRACE_V1( "","cassetteID is not null");
//          /* get cassette information */
//          select CAST_USED_CAPACITY,CAST_CATEGORY,DRBL_STATE
//          into   hFRCASTCAST_CAPACITY,hFRCASTCAST_CATEGORY,hFRCASTDRBL_STATE
//          form frcast 
//          where CAST_ID=cassetteID.identifier
//
            objCassette_getStatusDR_out strCassette_getStatusDR_out;

            rc = cassette_getStatusDR( strCassette_getStatusDR_out,
                                       strObjCommonIn,
                                       cassetteID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "","cassette_getStatusDR() != RC_OK", rc);
                strCassette_zoneType_Get_out.strResult = strCassette_getStatusDR_out.strResult;
                return rc;
            }

            PPT_METHODTRACE_V2( "","strCassette_getStatusDR_out.cast_used_capacity--->", strCassette_getStatusDR_out.cast_used_capacity);

            // determine TYPE_EMPTY_VALUE
            CORBA::String_var empty_value;
            if ( strCassette_getStatusDR_out.cast_used_capacity == 0 )
            {
                PPT_METHODTRACE_V1( "","strCassette_getStatusDR_out.cast_used_capacity == 0");
                empty_value = CIMFWStrDup(SP_ZONE_EMPTY);
            }
            else
            {
                empty_value = CIMFWStrDup(SP_ZONE_OCUPIED);
            }

            // determine TYPE_CATEGORY
            CORBA::String_var ccate_value = CIMFWStrDup(strCassette_getStatusDR_out.cast_category);
            // determine TYPE_CARRIER_STATE_VALUE
            CORBA::String_var cstat_value = CIMFWStrDup(strCassette_getStatusDR_out.drbl_state);

            PosCassette_var aCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                                   cassetteID,
                                                   strCassette_zoneType_Get_out,
                                                   cassette_zoneType_Get );
            // findMethod      : theDurableManager->findCassetteNamed(cassetteID.identifier );
            // user exception  : DurableManager::CassetteRetrievalFailedSignal
            //                   RC_NOT_FOUND_CASSETTE, MSG_NOT_FOUND_CASSETTE

            try
            {
                aLotSequence = aCassette->allLots();
                aLotSequenceVar = aLotSequence;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::allLots)

            posLotInfo*    aNowLotInfo = NULL; //P2200204
            posLotInfo_var aLotInfoVar;

            CORBA::Long  statWaitingCnt =0;
            CORBA::Long  statOnHoldCnt  =0;
            CORBA::Long  statInBankCnt  =0;
            CORBA::Long  statScrappedCnt=0;
            CORBA::Long  typeProdCnt    =0;
            CORBA::Long  typeEngCnt     =0;
            CORBA::Long  typePMonCnt    =0;
            CORBA::Long  typeEMonCnt    =0;
            CORBA::Long  typeDumyCnt    =0;
            CORBA::Long  typeOthCnt     =0;
            CORBA::Long LSLength;
            LSLength = (*aLotSequence).length();
            CORBA::Boolean bFirstSetting = FALSE;
            CORBA::Long highRemainTime = 0;
            CORBA::Long nowRemainTime = 0;
            CORBA::Long zone_qTime = 0;
            CORBA::Long nowPriortyClass = 0;
            CORBA::Long zonePriortyClass = 0;
            CORBA::Long nowExPriorty = 0;
            CORBA::Long zoneExPriorty = 0;
            CORBA::Long nowInPriorty = 0;
            CORBA::Long zoneInPriorty = 0;

            PPT_METHODTRACE_V2("", "aLotSequence.length()",LSLength);

            for ( i=0; i < LSLength; i++ )
            {
                //aLot = object reference for aLotSequence[i]
                // findMethod      : theProductManager->findLotNamed(lotID.identifier );
                // user exception  : ProductManager::LotRetrievalFailedSignal
                //                   RC_NOT_FOUND_LOT, MSG_NOT_FOUND_LOT
                PPT_METHODTRACE_V2("", "loop to LotCount",i);
                aLot = PosLot::_narrow((*aLotSequence)[i]);
                //PTR3000330 Start
                if(CORBA::is_nil(aLot))
                {
                    PPT_METHODTRACE_V1("", "Returned Lot Sequence contained NIL object reference.");
                    PPT_SET_MSG_RC_KEY( strCassette_zoneType_Get_out,
                                        MSG_NOT_FOUND_LOT,
                                        RC_NOT_FOUND_LOT,
                                        "" );

                    return RC_NOT_FOUND_LOT;
                }
                //PTR3000330 End
//D7000026      try
//D7000026      {
//D7000026          posLotInfoInqFlag lotInfoInqFlag;
//D7000026          lotInfoInqFlag.lotBasicInfoFlag        = TRUE;
//D7000026          lotInfoInqFlag.lotControlUseInfoFlag   = FALSE;
//D7000026          lotInfoInqFlag.lotFlowBatchInfoFlag    = FALSE;
//D7000026          lotInfoInqFlag.lotNoteFlagInfoFlag     = FALSE;
//D7000026          lotInfoInqFlag.lotOperationInfoFlag    = FALSE;
//D7000026          lotInfoInqFlag.lotOrderInfoFlag        = FALSE;
//D7000026          lotInfoInqFlag.lotControlJobInfoFlag   = FALSE;
//D7000026          lotInfoInqFlag.lotProductInfoFlag      = FALSE;
//D7000026          lotInfoInqFlag.lotRecipeInfoFlag       = FALSE;
//D7000026          lotInfoInqFlag.lotLocationInfoFlag     = FALSE;
//D7000026          lotInfoInqFlag.lotWipOperationInfoFlag = FALSE;
//D7000026          lotInfoInqFlag.lotWaferAttributesFlag  = FALSE;
//D7000026          lotInfoInqFlag.lotBackupInfoFlag       = FALSE;    //D4200062
//D7000026
//D7000026          try
//D7000026          {
//D7000026              aNowLotInfo = aLot->getLotInfo(lotInfoInqFlag);
//D7000026              aLotInfoVar = aNowLotInfo;
//D7000026          }
//D7000026          CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotInfo)
//D7000026
//D7000026          PPT_METHODTRACE_V2("", "LotID", aNowLotInfo->strLotBasicInfo.lotID.identifier);  //P4200111
//D7000026          PPT_METHODTRACE_V2("", "aNowLotInfo->strLotBasicInfo.lotStatus--->", aNowLotInfo->strLotBasicInfo.lotStatus);
//D7000026 add start

                aNowLotInfo = new posLotInfo();
                aLotInfoVar = aNowLotInfo;
                posLotBaseInfo_var aLotBaseInfo;
                try
                {
                    aLotBaseInfo = aLot->getLotBaseInfo();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotBaseInfo);

                SP_INIT_LOTINFO_STRUCT((*aNowLotInfo));
                aNowLotInfo->strLotBasicInfo.lotID            = aLotBaseInfo->lotID ;
                aNowLotInfo->strLotBasicInfo.internalPriority = convertDoubleToStringForInternalPriority( aLotBaseInfo->internalPriority );
                aNowLotInfo->strLotBasicInfo.externalPriority = ConvertLongtoString( aLotBaseInfo->externalPriority );
                aNowLotInfo->strLotBasicInfo.priorityClass    = ConvertLongtoString( aLotBaseInfo->priorityClass );
                aNowLotInfo->strLotBasicInfo.lotStatus        = aLotBaseInfo->representativeState ;
                aNowLotInfo->strLotBasicInfo.lotType          = aLotBaseInfo->lotType ;

                PosQTimeInfoSequence_var aQTimeInfoSeq;
                try
                {
                    aQTimeInfoSeq = aLot->getQTimeInfo();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getQTimeInfo);

                if( aQTimeInfoSeq->length() )
                {
//D7000371          aNowLotInfo->strLotBasicInfo.qtimeFlag = TRUE;
//D7000371 add start
                    CORBA::ULong qtimeLen = aQTimeInfoSeq->length();
                    aNowLotInfo->strLotBasicInfo.qtimeFlag = FALSE;
                    for( CORBA::ULong i = 0 ; i < qtimeLen ; i++ )
                    {
                        if( 0 != CIMFWStrCmp((*aQTimeInfoSeq)[i].qrestrictionTargetTimeStamp, SP_TIMESTAMP_NIL_OBJECT_STRING) )
                        {
                            aNowLotInfo->strLotBasicInfo.qtimeFlag = TRUE;
                            break;
                        }
                    }
//D7000371 add end
                }
                else
                {
                    aNowLotInfo->strLotBasicInfo.qtimeFlag = FALSE;
                }
//D7000026 add end
                    // Lot Stat
                    if ( 0 == CIMFWStrCmp(aNowLotInfo->strLotBasicInfo.lotStatus, SP_Lot_ProcState_Waiting) )
                    {
                        statWaitingCnt++;
                        PPT_METHODTRACE_V2("", "statWaitingCnt++", statWaitingCnt);
                    }
                    else if ( 0 == CIMFWStrCmp(aNowLotInfo->strLotBasicInfo.lotStatus, CIMFW_Lot_HoldState_OnHold) )
                    {
                        statOnHoldCnt++;
                        PPT_METHODTRACE_V2("", "statOnHoldCnt++", statOnHoldCnt);
                    }
                    else if ( 0 == CIMFWStrCmp(aNowLotInfo->strLotBasicInfo.lotStatus, SP_Lot_InventoryState_InBank) )
                    {
                        statInBankCnt++;
                        PPT_METHODTRACE_V2("", "statInBankCnt++", statInBankCnt);
                    }
                    else if ( 0 == CIMFWStrCmp(aNowLotInfo->strLotBasicInfo.lotStatus, CIMFW_Lot_FinishedState_Scrapped) )
                    {
                        statScrappedCnt++;
                        PPT_METHODTRACE_V2("", "statScrappedCnt++", statScrappedCnt);
                    }

                    PPT_METHODTRACE_V2("", "aNowLotInfo->strLotBasicInfo.lotType--->", aNowLotInfo->strLotBasicInfo.lotType);

                    // Lot Type
                    if ( 0 == CIMFWStrCmp(aNowLotInfo->strLotBasicInfo.lotType, SP_Lot_Type_ProductionLot) )
                    {
                        typeProdCnt++;
                        PPT_METHODTRACE_V2("", "typeProdCnt++", typeProdCnt);
                    }
                    else if ( 0 == CIMFWStrCmp(aNowLotInfo->strLotBasicInfo.lotType, SP_Lot_Type_EngineeringLot) )
                    {
                        typeEngCnt++;
                        PPT_METHODTRACE_V2("", "typeEngCnt++", typeEngCnt);
                    }
                    else if ( 0 == CIMFWStrCmp(aNowLotInfo->strLotBasicInfo.lotType, SP_Lot_Type_ProductionMonitorLot) )
                    {
                        typePMonCnt++;
                        PPT_METHODTRACE_V2("", "typePMonCnt++", typePMonCnt);
                    }
                    else if ( 0 == CIMFWStrCmp(aNowLotInfo->strLotBasicInfo.lotType, SP_Lot_Type_EquipmentMonitorLot) )
                    {
                        typeEMonCnt++;
                        PPT_METHODTRACE_V2("", "typeEMonCnt++", typeEMonCnt);
                    }
                    else if ( 0 == CIMFWStrCmp(aNowLotInfo->strLotBasicInfo.lotType, SP_Lot_Type_DummyLot) )
                    {
                        typeDumyCnt++;
                        PPT_METHODTRACE_V2("", "typeDumyCnt++", typeDumyCnt);
                    }
                    else
                    {
                        typeOthCnt++;
                        PPT_METHODTRACE_V2("", "typeOthCnt++", typeOthCnt);
                    }
//D7000026      }
//D7000026      CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotInfo);

                /*-----------------------------------------------------*/
                /*  Sorting fields;                                    */
                /*  1st field :  qrestrictionRemainTime                */
                /*  2st field :  priortyClass                          */
                /*  3rd field :  externalPriority                      */
                /*  4th field :  internalPriority                      */
                /*-----------------------------------------------------*/

                objLot_qTime_GetDR_out strLot_qTime_GetDR_out;

                if ( aNowLotInfo->strLotBasicInfo.qtimeFlag == TRUE )
                {
                    PPT_METHODTRACE_V1("", "aLot->qtimeFlag == TRUE");
                    objectIdentifier lotID;

                    PPT_SET_OBJECT_IDENTIFIER( lotID,
                                               aLot,
                                               strCassette_zoneType_Get_out,
                                               cassette_zoneType_Get,
                                               PosLot );

                    rc = lot_qTime_GetDR( strLot_qTime_GetDR_out,
                                          strObjCommonIn,
                                          lotID );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1( "","lot_qTime_GetDR() != RC_OK");
                        strCassette_zoneType_Get_out.strResult = strLot_qTime_GetDR_out.strResult;
                        return rc;
                    }

                    CORBA::Long LQTILength;
                    LQTILength = strLot_qTime_GetDR_out.strLotQtimeInfo.length();
                    PPT_METHODTRACE_V2("", "strLot_qTime_GetDR_out.strLotQtimeInfo.length()", LQTILength);

//D7000371          if ( 0 == LQTILength )
//D7000371          {
//D7000371              PPT_METHODTRACE_V1("", "0 == LQTILength");
//D7000371              continue;
//D7000371          }
//D7000371
//D7000371          highRemainTime = atoi(strLot_qTime_GetDR_out.strLotQtimeInfo[0].qrestrictionRemainTime);
//D7000371          PPT_METHODTRACE_V2("", "Start RemainQ-Time", highRemainTime);
//D7000371
//D7000371          for ( j=0; j < LQTILength; j++ )
//D7000371          {
//D7000371              nowRemainTime = atoi(strLot_qTime_GetDR_out.strLotQtimeInfo[j].qrestrictionRemainTime);
//D7000371              if ( highRemainTime > nowRemainTime )
//D7000371              {
//D7000371                  highRemainTime = nowRemainTime;
//D7000371                  PPT_METHODTRACE_V2("", "Change RemainQ-Time", highRemainTime);
//D7000371              }
//D7000371          }
//D7000371 add start
                    CORBA::ULong qactionCount = 0 ;
                    CORBA::Boolean firstOneFlag = TRUE ;
    
                    for ( j = 0 ; j < LQTILength ; j++ )
                    {
                        if( 0 == CIMFWStrCmp(strLot_qTime_GetDR_out.strLotQtimeInfo[j].qrestrictionTargetTimeStamp, SP_TIMESTAMP_NIL_OBJECT_STRING) )
                        {
                            qactionCount++;
                            continue;
                        }

                        if( TRUE == firstOneFlag )
                        {
                            highRemainTime = atoi(strLot_qTime_GetDR_out.strLotQtimeInfo[j].qrestrictionRemainTime);
                            PPT_METHODTRACE_V2("", "Start RemainQ-Time", highRemainTime);
                            firstOneFlag = FALSE;
                        }
                        else
                        {
                            nowRemainTime = atoi(strLot_qTime_GetDR_out.strLotQtimeInfo[j].qrestrictionRemainTime);
                            if ( highRemainTime > nowRemainTime )
                            {
                                highRemainTime = nowRemainTime;
                                PPT_METHODTRACE_V2("", "Change RemainQ-Time", highRemainTime);
                            }
                        }
                    }

                    if( LQTILength == qactionCount )
                    {
                        PPT_METHODTRACE_V2("", "### LQTILength == 0 or all Lot Q-times are Q-Action. LQTILength = ", LQTILength);
                        continue;
                    }
//D7000371 add end

                    // Determin Q-Time Lot
                    if ( FALSE == bFirstSetting )
                    {
                        PPT_METHODTRACE_V1("", "FALSE == bFirstSetting");
                        zone_qTime = highRemainTime;
                        zoneLotInfo = (*aNowLotInfo);
                        bFirstSetting = TRUE;
                    }
                    else
                    {
                        if ( zone_qTime > highRemainTime )
                        {
                            PPT_METHODTRACE_V3("", "zone_qTime > highRemainTime", zone_qTime, highRemainTime);
                            zone_qTime = highRemainTime;
                            zoneLotInfo = (*aNowLotInfo);
                        }
                        else if (zone_qTime == highRemainTime )
                        {
                            /*********************************/
                            /* If Q-Time is same and highest */
                            /* Check Priority Class          */
                            /*********************************/
                            PPT_METHODTRACE_V3("", "zone_qTime == highRemainTime", zone_qTime, highRemainTime);
//D9000001                            nowPriortyClass  = atol(aNowLotInfo->strLotBasicInfo.priorityClass); 
//D9000001                            zonePriortyClass = atol(zoneLotInfo.strLotBasicInfo.priorityClass); 
                            nowPriortyClass  = atoi(aNowLotInfo->strLotBasicInfo.priorityClass);//D9000001
                            zonePriortyClass = atoi(zoneLotInfo.strLotBasicInfo.priorityClass); //D9000001
                            if ( zonePriortyClass > nowPriortyClass )
                            {
                                PPT_METHODTRACE_V3("", "zonePriortyClass > nowPriortyClass", zonePriortyClass, nowPriortyClass);
                                zoneLotInfo = (*aNowLotInfo);
                            }
                            else if ( nowPriortyClass == zonePriortyClass )
                            {
                                /*******************************************/
                                /* If Priority Class is same and highest   */
                                /* Check externalPriority                  */
                                /*******************************************/
                                PPT_METHODTRACE_V3("", "nowPriortyClass == zonePriortyClass", nowPriortyClass, zonePriortyClass);
//D9000001                                nowExPriorty  = atol(aNowLotInfo->strLotBasicInfo.externalPriority); 
//D9000001                                zoneExPriorty = atol(zoneLotInfo.strLotBasicInfo.externalPriority); 
                                nowExPriorty  = atoi(aNowLotInfo->strLotBasicInfo.externalPriority);//D9000001
                                zoneExPriorty = atoi(zoneLotInfo.strLotBasicInfo.externalPriority); //D9000001

                                if ( zoneExPriorty > nowExPriorty )
                                {
                                    PPT_METHODTRACE_V3("", "zoneExPriorty > nowExPriorty", zoneExPriorty, nowExPriorty);
                                    zoneLotInfo = (*aNowLotInfo);
                                }
                                else if ( zoneExPriorty == nowExPriorty )
                                {
                                    PPT_METHODTRACE_V3("", "zoneExPriorty == nowExPriorty", zoneExPriorty, nowExPriorty);
                                    /*******************************************/
                                    /* If externalPriority is same and highest */
                                    /* Check internalPriority                  */
                                    /*******************************************/
                                    PPT_METHODTRACE_V1("", "zoneExPriorty == nowExPriorty");
//D9000001                                    nowInPriorty  = atol(aNowLotInfo->strLotBasicInfo.internalPriority); 
//D9000001                                    zoneInPriorty = atol(zoneLotInfo.strLotBasicInfo.internalPriority);
                                    nowInPriorty  = atoi(aNowLotInfo->strLotBasicInfo.internalPriority);//D9000001
                                    zoneInPriorty = atoi(zoneLotInfo.strLotBasicInfo.internalPriority); //D9000001
                                    if ( zoneInPriorty > nowInPriorty )
                                    {
                                        PPT_METHODTRACE_V3("", "zoneInPriorty > nowInPriorty", zoneInPriorty, nowInPriorty);
                                        zoneLotInfo = (*aNowLotInfo);
                                    }
                                }
                            }
                        }
                    }
                }
                else if ( i == 0 )
                {
                    PPT_METHODTRACE_V1("", "i == 0");
                    zoneLotInfo = (*aNowLotInfo);
                }
                else
                {
                    PPT_METHODTRACE_V1("", "qtimeFlag == FALSE");
//D9000001                    nowPriortyClass  = atol(aNowLotInfo->strLotBasicInfo.priorityClass); 
//D9000001                    zonePriortyClass = atol(zoneLotInfo.strLotBasicInfo.priorityClass); 
                    nowPriortyClass  = atoi(aNowLotInfo->strLotBasicInfo.priorityClass);//D9000001
                    zonePriortyClass = atoi(zoneLotInfo.strLotBasicInfo.priorityClass); //D9000001
                    if ( zonePriortyClass > nowPriortyClass )
                    {
                        PPT_METHODTRACE_V3("", "zonePriortyClass > nowPriortyClass", zonePriortyClass, nowPriortyClass);
                        zoneLotInfo = (*aNowLotInfo);
                    }
                    else if ( nowPriortyClass == zonePriortyClass )
                    {
                        PPT_METHODTRACE_V3("", "nowPriortyClass == zonePriortyClass", nowPriortyClass, zonePriortyClass);
                        /*******************************************/
                        /* If Priority Class is same and highest   */
                        /* Check externalPriority                  */
                        /*******************************************/
                        PPT_METHODTRACE_V1("", "nowPriortyClass == zonePriortyClass");
//D9000001                        nowExPriorty  = atol(aNowLotInfo->strLotBasicInfo.externalPriority); 
//D9000001                        zoneExPriorty = atol(zoneLotInfo.strLotBasicInfo.externalPriority); 
                        nowExPriorty  = atoi(aNowLotInfo->strLotBasicInfo.externalPriority);//D9000001
                        zoneExPriorty = atoi(zoneLotInfo.strLotBasicInfo.externalPriority); //D9000001
                        if ( zoneExPriorty > nowExPriorty )
                        {
                            PPT_METHODTRACE_V3("", "zoneExPriorty > nowExPriorty", zoneExPriorty, nowExPriorty);
                            zoneLotInfo = (*aNowLotInfo);
                        }
                        else if ( zoneExPriorty == nowExPriorty )
                        {
                            PPT_METHODTRACE_V3("", "zoneExPriorty == nowExPriorty", zoneExPriorty, nowExPriorty);
                            /*******************************************/
                            /* If externalPriority is same and highest */
                            /* Check internalPriority                  */
                            /*******************************************/
                            PPT_METHODTRACE_V1("", "zoneExPriorty == nowExPriorty");
//D9000001                            nowInPriorty  = atol(aNowLotInfo->strLotBasicInfo.internalPriority);
//D9000001                            zoneInPriorty = atol(zoneLotInfo.strLotBasicInfo.internalPriority);
                            nowInPriorty  = atoi(aNowLotInfo->strLotBasicInfo.internalPriority);//D9000001
                            zoneInPriorty = atoi(zoneLotInfo.strLotBasicInfo.internalPriority); //D9000001
                            if ( zoneInPriorty > nowInPriorty )
                            {
                                PPT_METHODTRACE_V3("", "zoneInPriorty > nowInPriorty", zoneInPriorty, nowInPriorty);
                                zoneLotInfo = (*aNowLotInfo);
                            }
                        }
                    }
                } // end of qtimeFlag
            } // end of i

            /* Start P3000339 */
            /*******************************************/
            // Add Priority for representative Lot
            /*******************************************/
            if(0 < LSLength)
            {
                strCassette_zoneType_Get_out.priority = CIMFWStrDup(zoneLotInfo.strLotBasicInfo.priorityClass);
            }
            /*******************************************/
            // Get Next EquipmentID
            /*******************************************/
            PPT_METHODTRACE_V1("", "Get Next EquipmentID");

            PosLot_var aLot;
            CORBA::Boolean lotFound = FALSE;    //P3000284
            PPT_CONVERT_LOTID_TO_LOT_WITH_NO_RETURN( aLot, zoneLotInfo.strLotBasicInfo.lotID );    //P3000284

            PPT_METHODTRACE_V2("", "Target LotID", zoneLotInfo.strLotBasicInfo.lotID.identifier);  //P4200111

//P3000284            PPT_CONVERT_LOTID_TO_LOT_OR( aLot,
//P3000284                                         zoneLotInfo.strLotBasicInfo.lotID,
//P3000284                                         strCassette_zoneType_Get_out,
//P3000284                                         cassette_zoneType_Get );

            CORBA::String_var etype_value;          //P3000284
            objectIdentifierSequence equipmentIDs;  //P3000284
            CORBA::Boolean bEquipmentTypeGet = FALSE;  //P4200111

            if ( TRUE == lotFound )     //P3000284
            {                           //P3000284
                PPT_METHODTRACE_V1("", "TRUE == lotFound");

                PosMachineSequence*    aMachineSeq = NULL;
                PosMachineSequence_var aMachineSeqVar;
                try
                {
                    aMachineSeq = aLot->getQueuedMachines();
                    aMachineSeqVar = aMachineSeq;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getQueuedMachines);

                CORBA::Long lenMachine = aMachineSeq->length();
                PPT_METHODTRACE_V2("", "aMachineSeq->length--->", lenMachine);

//P4200111                if ( 0 == lenMachine )
//P4200111                {
//P4200111                    PPT_METHODTRACE_V1("", "0 == lenMachine");
//P4200111                    PPT_SET_MSG_RC_KEY( strCassette_zoneType_Get_out,
//P4200111                                        MSG_NOT_FOUND_EQP,
//P4200111                                        RC_NOT_FOUND_EQP,
//P4200111                                        "" );
//P4200111
//P4200111//                  return RC_NOT_FOUND_EQP;
//P4200111                    return RC_OK;
//P4200111                }

//P3000284                objectIdentifierSequence equipmentIDs;
                equipmentIDs.length(lenMachine);

                for ( j=0; j < lenMachine; j++ )
                {
                    if ( !CORBA::is_nil( (*aMachineSeq)[j] ) )
                    {
                        PPT_SET_OBJECT_IDENTIFIER( equipmentIDs[j],
                                                   (*aMachineSeq)[j],
                                                   strCassette_zoneType_Get_out,
                                                   cassette_zoneType_Get,
                                                   PosMachine );
                    }
                }

                if ( 0 < lenMachine )   //P4200111
                {                       //P4200111
                    /*******************************************/
                    // get equipmentType
                    /*******************************************/
                    PPT_METHODTRACE_V1("", "get equipmentType");
                    PPT_METHODTRACE_V2("", "equipmentIDs[0]--->", equipmentIDs[0].identifier);     //P5100103
                    objEquipment_getTypeDR_out strEquipment_getTypeDR_out;

                    rc = equipment_getTypeDR( strEquipment_getTypeDR_out,
                                              strObjCommonIn,
                                              equipmentIDs[0] );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1( "","equipment_getTypeDR_out() != RC_OK");
//P5100103                        strCassette_zoneType_Get_out.strResult = strCassette_zoneType_Get_out.strResult;
                        strCassette_zoneType_Get_out.strResult = strEquipment_getTypeDR_out.strResult;     //P5100103
                        return rc;
                    }

//P3000284                CORBA::String_var etype_value = CIMFWStrDup(strEquipment_getTypeDR_out.equipmentType);
                    etype_value = CIMFWStrDup(strEquipment_getTypeDR_out.equipmentType);    //P3000284
                    PPT_METHODTRACE_V2("", "etype_value--->", etype_value);
                    bEquipmentTypeGet = TRUE;  //P4200111
                }                              //P4200111
            }       //P3000284

//P3000298            CORBA::String_var zoneFlag = getenv("SP_ZONE_TYPE_FLAG");
//P3000426            char * zoneFlag = CIMFWStrDup(getenv("SP_ZONE_TYPE_FLAG"));    //P3000298
//D4000011            CORBA::String_var zoneFlag = CIMFWStrDup(getenv("SP_ZONE_TYPE_FLAG"));    //P3000426
//D4100134            PPT_METHODTRACE_V2("PPTManager_i::cassette_zoneType_Get","theSP_ZONE_TYPE_FLAG = ", theSP_ZONE_TYPE_FLAG );    //D4000011

//D4100134            CORBA::String_var zoneFlag = theSP_ZONE_TYPE_FLAG;    //D4000011
            CORBA::String_var zoneFlag = CIMFWStrDup(getenv("SP_ZONE_TYPE_FLAG"));    //D4100134
          
            PPT_METHODTRACE_V2("", "getenv(SP_ZONE_TYPE_FLAG)--->", zoneFlag);

            if ( 0 != CIMFWStrCmp(zoneFlag, "ON") )
            {
                PPT_METHODTRACE_V1( "","zoneFlag == ON");

                if ( 0 == CIMFWStrCmp(empty_value, SP_ZONE_EMPTY) )
                {
                    PPT_METHODTRACE_V1( "","empty_value == SP_ZONE_EMPTY");
                    strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(SP_ZONE_EMPTY);
                }
                else if ( 0 == CIMFWStrCmp(zoneLotInfo.strLotBasicInfo.lotStatus, CIMFW_Lot_HoldState_OnHold ) )
                {
                    PPT_METHODTRACE_V1( "","zoneLotInfo.strLotBasicInfo.lotStatus == CIMFW_Lot_HoldState_OnHold");
                    strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(CIMFW_Lot_HoldState_OnHold);
                }
                else if ( 0 == CIMFWStrCmp(zoneLotInfo.strLotBasicInfo.lotStatus, SP_Lot_InventoryState_InBank) )
                {
                    PPT_METHODTRACE_V1( "","zoneLotInfo.strLotBasicInfo.lotStatus == SP_Lot_InventoryState_InBank");
                    strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(SP_Lot_InventoryState_InBank);
                }
                else if ( 0 == CIMFWStrCmp(zoneLotInfo.strLotBasicInfo.lotStatus, CIMFW_Lot_FinishedState_Scrapped) )
                {
                    PPT_METHODTRACE_V1( "","zoneLotInfo.strLotBasicInfo.lotStatus == CIMFW_Lot_FinishedState_Scrapped");
                    strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(CIMFW_Lot_FinishedState_Scrapped);
                }
                else if ( 0 == CIMFWStrCmp(zoneLotInfo.strLotBasicInfo.lotType, SP_Lot_Type_EngineeringLot) )
                {
                    PPT_METHODTRACE_V1( "","zoneLotInfo.strLotBasicInfo.lotType == SP_Lot_Type_EngineeringLot");
                    strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(SP_Lot_Type_EngineeringLot);
                }
                else if ( 0 == CIMFWStrCmp(zoneLotInfo.strLotBasicInfo.lotType, SP_Lot_Type_ProductionMonitorLot) )
                {
                    PPT_METHODTRACE_V1( "","zoneLotInfo.strLotBasicInfo.lotType == SP_Lot_Type_ProductionMonitorLot");
                    strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(SP_Lot_Type_ProductionMonitorLot);
                }
                else if ( 0 == CIMFWStrCmp(zoneLotInfo.strLotBasicInfo.lotType, SP_Lot_Type_EquipmentMonitorLot) )
                {
                    PPT_METHODTRACE_V1( "","zoneLotInfo.strLotBasicInfo.lotType == SP_Lot_Type_EquipmentMonitorLot");
                    strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(SP_Lot_Type_EquipmentMonitorLot);
                }
                else if ( 0 == CIMFWStrCmp(zoneLotInfo.strLotBasicInfo.lotType, SP_Lot_Type_DummyLot) )
                {
                    PPT_METHODTRACE_V1( "","zoneLotInfo.strLotBasicInfo.lotType == SP_Lot_Type_DummyLot");
                    strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(SP_Lot_Type_DummyLot);
                }
                else
                {
                    PPT_METHODTRACE_V1( "","else...");
                }
            }
            else
            {
                /*******************************************************************/
                /* Read  zone_type.ini                                             */
                /* file format :                                                   */
                /* 1st parm  , 2nd parm            ,3rd parm             ,4th parm */
                /* ---------- --------------------- --------------------- -------- */
                /* SqquenceNo,carrierAttributteType,carrierAttributeValue,ZoneType */
                /*                                                                 */
                /*******************************************************************/
                PPT_METHODTRACE_V1( "","Read  zone_type.ini");

                char LnRead[200];

//P3000298                CORBA::String_var pZoneTypeFile;
                CORBA::Long seqLen = 0;

                PPT_METHODTRACE_V1("","Reading ZONE-TYPE-DETERMIN-Table");

//              CIMFWStrCpy( pZoneTypeFile, getenv("SP_ZONE_TYPE_INI") );
//P3000298                pZoneTypeFile = getenv("SP_ZONE_TYPE_INI") ;
//P3000426                char * pZoneTypeFile = CIMFWStrDup(getenv("SP_ZONE_TYPE_INI")) ; //P3000298
//D4000011      CORBA::String_var pZoneTypeFile = CIMFWStrDup(getenv("SP_ZONE_TYPE_INI")) ; //P3000426

//D4100134      PPT_METHODTRACE_V2("PPTManager_i::cassette_zoneType_Get","theSP_ZONE_TYPE_INI = ", theSP_ZONE_TYPE_INI );      //D4000011
//D4100134      CORBA::String_var pZoneTypeFile = theSP_ZONE_TYPE_INI;                                                         //D4000011
                CORBA::String_var pZoneTypeFile = CIMFWStrDup(getenv("SP_ZONE_TYPE_INI")) ; //D4100134

                PPT_METHODTRACE_V2("","Read zone_type file name--->", pZoneTypeFile);

                ifstream tblStream(pZoneTypeFile, ios::in | ios::nocreate);
                if ( tblStream.rdbuf()->is_open() == 0 )
                {
//P4100313          cout << "Error while opening - ZONE-TYPE-DETERMIN-Table - " << pZoneTypeFile << "." << endl;
                    PPT_METHODTRACE_V2("","Error while opening - ZONE-TYPE-DETERMIN-Table - ",pZoneTypeFile); //P4100313
                    SET_MSG_RC(strCassette_zoneType_Get_out, MSG_INIFILE_OPEN_ERR, RC_INIFILE_OPEN_ERR);
                    return RC_INIFILE_OPEN_ERR;
                }

                stringSequence zoneTypeSeq;
                zoneTypeSeq.length(0);
                CORBA::Boolean zoneTypeEndFlag = FALSE;

                while ( tblStream.eof() == 0 )
                {
                    tblStream.getline(LnRead, 200);
                    seqLen++;
                    zoneTypeSeq.length(seqLen);
                    zoneTypeSeq[seqLen-1] = CIMFWStrDup(LnRead);

                    PPT_METHODTRACE_V3("","[read line]", seqLen, zoneTypeSeq[seqLen-1]);

                    if ( 0 == CIMFWStrLen(zoneTypeSeq[seqLen-1]))
                    {
                        PPT_METHODTRACE_V1("","0 == CIMFWStrLen(zoneTypeSeq[seqLen-1]) break");
                        break;
                    }
                }

                tblStream.close();
                PPT_METHODTRACE_V1("","Successfully read ZONE-TYPE-DETERMIN-Table");

                // End of reading table

                i =0;
                while ( i < seqLen && zoneTypeEndFlag == FALSE)
                {
                    PPT_METHODTRACE_V1("","********** Get Read File Param START **********");
                    stringSequence getItems;
                    char tmpBuf[1024];
                    CIMFWStrCpy(&tmpBuf[0], zoneTypeSeq[i]);

                    char *startPos = &tmpBuf[0];
                    char *endPos   = &tmpBuf[0];

                    CORBA::Long nDataNum;
                    for ( nDataNum=0; endPos != NULL; nDataNum++ )
                    {
                        endPos = strstr(startPos, ",");
                        if ( endPos != NULL )
                        {
                            PPT_METHODTRACE_V1("","endPos != NULL");
                            *endPos = '\0';
                            getItems.length(nDataNum + 1);
                            getItems[nDataNum] = CIMFWStrDup(startPos);
                            startPos = endPos + 1;
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("","endPos == NULL");
                            getItems.length(nDataNum + 1);
                            getItems[nDataNum] = CIMFWStrDup(startPos);
                        }
                    } // end of for (nDataNum)
                    PPT_METHODTRACE_V1("","********** Get Read File Param END **********");

                    if ( 4 != nDataNum )
                    {
                        PPT_METHODTRACE_V1("","XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
                        PPT_METHODTRACE_V2("","4 != nDataNum", nDataNum);
                        PPT_METHODTRACE_V1("","XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");

                        break;
                    }

                    CORBA::String_var carrierAttributteType;
                    CORBA::String_var carrierAttributeValue;
                    CORBA::String_var zoneTypeValue;

                    for ( j=0; j < nDataNum; j++ )
                    {
                        PPT_METHODTRACE_V3("","getItems[j]", j, getItems[j]);
                        if ( 1 == j)
                        {
                            carrierAttributteType = CIMFWStrDup(getItems[j]);
                        }
                        else if ( 2 == j )
                        {
                            carrierAttributeValue = CIMFWStrDup(getItems[j]);
                        }
                        else if ( 3 == j )
                        {
                            zoneTypeValue = CIMFWStrDup(getItems[j]);
                        }
                        else
                        {
                            PPT_METHODTRACE_V3("","else", j, getItems[j]);
                        }
                    }

                    PPT_METHODTRACE_V2("","carrierAttributteType--->", carrierAttributteType);
                    PPT_METHODTRACE_V2("","carrierAttributeValue--->", carrierAttributeValue);
                    PPT_METHODTRACE_V2("","zoneTypeValue----------->", zoneTypeValue);

                    if ( 0 == CIMFWStrCmp(carrierAttributteType, SP_ZONE_ATTR_EMPTY) )
                    {
                        PPT_METHODTRACE_V1( "","carrierAttributteType == SP_ZONE_ATTR_EMPTY");
                        if ( 0 == CIMFWStrCmp(carrierAttributeValue, empty_value) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == empty_value");
                            strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                            zoneTypeEndFlag = TRUE;
                        }
                    }
                    else if ( 0 == CIMFWStrCmp(carrierAttributteType, SP_ZONE_ATTR_CATEGORY) )
                    {
                        PPT_METHODTRACE_V1( "","carrierAttributteType == SP_ZONE_ATTR_CATEGORY");
                        if ( 0 == CIMFWStrCmp(carrierAttributeValue, ccate_value) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == ccate_value");
                            strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                            zoneTypeEndFlag = TRUE;
                        }
                    }
                    else if ( 0 == CIMFWStrCmp(carrierAttributteType, SP_ZONE_ATTR_CARRIER_STATE) )
                    {
                        PPT_METHODTRACE_V1( "","carrierAttributteType == SP_ZONE_ATTR_CARRIER_STATE");
                        if ( 0 == CIMFWStrCmp(carrierAttributeValue, cstat_value) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == cstat_value");
                            strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                            zoneTypeEndFlag = TRUE;
                        }
                    }
                    else if ( 0 == CIMFWStrCmp(carrierAttributteType, SP_ZONE_ATTR_PRIORITY_CLASS) )
                    {
                        PPT_METHODTRACE_V1( "","carrierAttributteType == SP_ZONE_ATTR_PRIORITY_CLASS");
                        if ( 0 == CIMFWStrCmp(carrierAttributeValue, zoneLotInfo.strLotBasicInfo.priorityClass) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == zoneLotInfo.strLotBasicInfo.priorityClass");
                            strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                            zoneTypeEndFlag = TRUE;
                        }
                    }
                    else if ( 0 == CIMFWStrCmp(carrierAttributteType, SP_ZONE_ATTR_NEXT_EQUIPMENT) )
                    {
                        CORBA::Long lenNextEqp = equipmentIDs.length();
                        PPT_METHODTRACE_V2( "","equipmentIDs.length()", lenNextEqp);

                        for ( j=0; j < lenNextEqp ; j++)
                        {
                            if ( 0 == CIMFWStrCmp(carrierAttributeValue, equipmentIDs[j].identifier) )
                            {
                                PPT_METHODTRACE_V2( "","carrierAttributeValue == equipmentIDs[j]", equipmentIDs[j].identifier);
                                strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                                zoneTypeEndFlag = TRUE;
                            }
                        }
                    }
                    else if ( 0 == CIMFWStrCmp(carrierAttributteType, SP_ZONE_ATTR_NEXT_EQUIPMENT_TYPE) )
                    {
                        PPT_METHODTRACE_V1( "","carrierAttributteType == SP_ZONE_ATTR_NEXT_EQUIPMENT_TYPE");
                        if ( 0 == CIMFWStrCmp(carrierAttributeValue, etype_value) && TRUE == bEquipmentTypeGet )    //P4200111
//P4200111                        if ( 0 == CIMFWStrCmp(carrierAttributeValue, etype_value) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == etype_value");
                            strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                            zoneTypeEndFlag = TRUE;
                        }
                    }
                    else if ( 0 == CIMFWStrCmp(carrierAttributteType, SP_ZONE_ATTR_LOT_STATUS_ALL) )
                    {
                        PPT_METHODTRACE_V1( "","carrierAttributteType == SP_ZONE_ATTR_LOT_STATUS_ALL");
                        if ( 0 == CIMFWStrCmp(carrierAttributeValue, SP_Lot_ProcState_Waiting) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == SP_Lot_ProcState_Waiting");
                            if ( statWaitingCnt == LSLength )
                            {
                                PPT_METHODTRACE_V1( "","statWaitingCnt == LSLength");
                                strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                                zoneTypeEndFlag = TRUE;
                            }
                        }
                        else if ( 0 == CIMFWStrCmp(carrierAttributeValue, CIMFW_Lot_HoldState_OnHold) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == CIMFW_Lot_HoldState_OnHold");
                            if ( statOnHoldCnt == LSLength )
                            {
                                PPT_METHODTRACE_V1( "","statOnHoldCnt == LSLength");
                                strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                                zoneTypeEndFlag = TRUE;
                            }
                        }
                        else if ( 0 == CIMFWStrCmp(carrierAttributeValue, SP_Lot_InventoryState_InBank) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == SP_Lot_InventoryState_InBank");
                            if ( statInBankCnt == LSLength )
                            {
                                PPT_METHODTRACE_V1( "","statInBankCnt == LSLength");
                                strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                                zoneTypeEndFlag = TRUE;
                            }
                        }
                        else if ( 0 == CIMFWStrCmp(carrierAttributeValue, CIMFW_Lot_FinishedState_Scrapped) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == CIMFW_Lot_FinishedState_Scrapped");
                            if ( statScrappedCnt == LSLength )
                            {
                                PPT_METHODTRACE_V1( "","statScrappedCnt == LSLength");
                                strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                                zoneTypeEndFlag = TRUE;
                            }
                        }
                    }
                    else if ( 0 == CIMFWStrCmp(carrierAttributteType, SP_ZONE_ATTR_LOT_TYPE_ALL) )
                    {
                        PPT_METHODTRACE_V1( "","carrierAttributteType == SP_ZONE_ATTR_LOT_TYPE_ALL");
                        if ( 0 == CIMFWStrCmp(carrierAttributeValue, SP_Lot_Type_ProductionLot) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == SP_Lot_Type_ProductionLot");
                            if ( typeProdCnt == LSLength )
                            {
                                PPT_METHODTRACE_V1( "","statScrappedCnt == LSLength");
                                strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                                zoneTypeEndFlag = TRUE;
                            }
                        }
                        else if ( 0 == CIMFWStrCmp(carrierAttributeValue, SP_Lot_Type_EngineeringLot) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == SP_Lot_Type_EngineeringLot");
                            if ( typeEngCnt == LSLength )
                            {
                                PPT_METHODTRACE_V1( "","typeEngCnt == LSLength");
                                strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                                zoneTypeEndFlag = TRUE;
                            }
                        }
                        else if ( 0 == CIMFWStrCmp(carrierAttributeValue, SP_Lot_Type_ProductionMonitorLot) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == SP_Lot_Type_ProductionMonitorLot");
                            if ( typePMonCnt == LSLength )
                            {
                                PPT_METHODTRACE_V1( "","typePMonCnt == LSLength");
                                strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                                zoneTypeEndFlag = TRUE;
                            }
                        }
                        else if ( 0 == CIMFWStrCmp(carrierAttributeValue, SP_Lot_Type_EquipmentMonitorLot) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == SP_Lot_Type_EquipmentMonitorLot");
                            if ( typeEMonCnt == LSLength )
                            {
                                PPT_METHODTRACE_V1( "","typeEMonCnt == LSLength");
                                strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                                zoneTypeEndFlag = TRUE;
                            }
                        }
                        else if ( 0 == CIMFWStrCmp(carrierAttributeValue, SP_Lot_Type_DummyLot) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == SP_Lot_Type_DummyLot");
                            if ( typeDumyCnt == LSLength )
                            {
                                PPT_METHODTRACE_V1( "","typeDumyCnt == LSLength");
                                strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                                zoneTypeEndFlag = TRUE;
                            }
                        }
                    }
                    else if ( 0 == CIMFWStrCmp(carrierAttributteType, SP_ZONE_ATTR_LOT_STATUS_ONE) )
                    {
                        PPT_METHODTRACE_V1( "","carrierAttributteType == SP_ZONE_ATTR_LOT_STATUS_ONE");
                        if ( 0 == CIMFWStrCmp(carrierAttributeValue, SP_Lot_ProcState_Waiting) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == SP_Lot_ProcState_Waiting");
                            if ( statWaitingCnt > 0 )
                            {
                                PPT_METHODTRACE_V1( "","statWaitingCnt > 0");
                                strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                                zoneTypeEndFlag = TRUE;
                            }
                        }
                        else if ( 0 == CIMFWStrCmp(carrierAttributeValue, CIMFW_Lot_HoldState_OnHold) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == CIMFW_Lot_HoldState_OnHold");
                            if ( statOnHoldCnt > 0 )
                            {
                                PPT_METHODTRACE_V1( "","statOnHoldCnt > 0");
                                strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                                zoneTypeEndFlag = TRUE;
                            }
                        }
                        else if ( 0 == CIMFWStrCmp(carrierAttributeValue, SP_Lot_InventoryState_InBank) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == SP_Lot_InventoryState_InBank");
                            if ( statInBankCnt > 0 )
                            {
                                PPT_METHODTRACE_V1( "","statInBankCnt > 0");
                                strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                                zoneTypeEndFlag = TRUE;
                            }
                        }
                        else if ( 0 == CIMFWStrCmp(carrierAttributeValue, CIMFW_Lot_FinishedState_Scrapped) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == CIMFW_Lot_FinishedState_Scrapped");
                            if ( statScrappedCnt > 0 )
                            {
                                PPT_METHODTRACE_V1( "","statScrappedCnt > 0");
                                strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                                zoneTypeEndFlag = TRUE;
                            }
                        }
                    }
                    else if ( 0 == CIMFWStrCmp(carrierAttributteType, SP_ZONE_ATTR_LOT_TYPE_ONE) )
                    {
                        PPT_METHODTRACE_V1( "","carrierAttributteType == SP_ZONE_ATTR_LOT_TYPE_ONE");
                        if ( 0 == CIMFWStrCmp(carrierAttributeValue, SP_Lot_Type_ProductionLot) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == SP_Lot_Type_ProductionLot");
                            if ( typeProdCnt > 0 )
                            {
                                PPT_METHODTRACE_V1( "","typeProdCnt > 0");
                                strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                                zoneTypeEndFlag = TRUE;
                            }
                        }
                        else if ( 0 == CIMFWStrCmp(carrierAttributeValue, SP_Lot_Type_EngineeringLot) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == SP_Lot_Type_EngineeringLot");
                            if ( typeEngCnt > 0 )
                            {
                                PPT_METHODTRACE_V1( "","typeEngCnt > 0");
                                strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                                zoneTypeEndFlag = TRUE;
                            }
                        }
                        else if ( 0 == CIMFWStrCmp(carrierAttributeValue, SP_Lot_Type_ProductionMonitorLot) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == SP_Lot_Type_ProductionMonitorLot");
                            if ( typePMonCnt > 0 )
                            {
                                PPT_METHODTRACE_V1( "","typePMonCnt > 0");
                                strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                                zoneTypeEndFlag = TRUE;
                            }
                        }
                        else if ( 0 == CIMFWStrCmp(carrierAttributeValue, SP_Lot_Type_EquipmentMonitorLot) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == SP_Lot_Type_EquipmentMonitorLot");
                            if ( typeEMonCnt > 0 )
                            {
                                PPT_METHODTRACE_V1( "","typeEMonCnt > 0");
                                strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                                zoneTypeEndFlag = TRUE;
                            }
                        }
                        else if ( 0 == CIMFWStrCmp(carrierAttributeValue, SP_Lot_Type_DummyLot) )
                        {
                            PPT_METHODTRACE_V1( "","carrierAttributeValue == SP_Lot_Type_DummyLot");
                            if ( typeDumyCnt > 0 )
                            {
                                PPT_METHODTRACE_V1( "","typeDumyCnt > 0");
                                strCassette_zoneType_Get_out.zoneType = CIMFWStrDup(zoneTypeValue);
                                zoneTypeEndFlag = TRUE;
                            }
                        }
                    }

                    i++;
                }
            }
        }
        else   // cassetteID.identifier is Null
        {
            PPT_METHODTRACE_V1( "","cassetteID is null");

            PPT_SET_MSG_RC_KEY( strCassette_zoneType_Get_out,
                                MSG_NOT_FOUND_CASSETTE,
                                RC_NOT_FOUND_CASSETTE,
                                cassetteID.identifier );

            return RC_NOT_FOUND_CASSETTE;
        }

        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_zoneType_Get");

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_zoneType_Get_out, cassette_zoneType_Get, methodName)
}
