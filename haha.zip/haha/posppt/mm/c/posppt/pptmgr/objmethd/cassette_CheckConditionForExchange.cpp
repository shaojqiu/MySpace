#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_CheckConditionForExchange.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:31:23 [ 7/13/07 19:31:25 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_CheckConditionForExchange.cpp
//

#include "pptmgr.hpp"

#include "pcas.hh"
#include "pctrlj.hh"


//[Object Function Name]: long   cassette_CheckConditionForExchange()
//
// Date        Level       Author         Note
// ----------  ----------  -------------  -------------------------------------------
// 2000/09/14              H.Katoh        Initial Release
// 2000/10/23  P3000280    K.Matsuei      CORBA::Boolean does not initialized. sometime It causes error.
// 2001/03/16  P3100134    Y.Iwasaki      Spell Miss for MethodTrace
// 2001/09/01  D4000056    Y.Yoshihara    Add routine to check machine category
//
//[Function Description]
//  * If 1 carrier is loaded on 1 equipment, all input carriers must be loaded on the same equipment.
//      (This method does not check carrier-equipment relation.)
//  * If 1 carrier is not loaded on any equipment, all input carriers must not be loaded on any equipment.
//      (This method does not check carrier-equipment relation.)
//  * If carrier is loaded on some equipment, this method maintains equipment's carrier-lot data
//    and inprocessing log data. and also maintain controlJob's carrier-lot information.
//
//
//[Input Parameters]:
//  in  pptObjCommonIn              strObjCommonIn;
//  in  objectIdentifier            equipmentID;
//  in  pptWaferTransferSequence    strWaferXferSeq;
//
//
//[Output Parameters]:
//
//  out objCassette_CheckConditionForExchange_out  strCassette_CheckConditionForExchange_out;
//
//  typedef struct objCassette_CheckConditionForExchange_out_struct {
//     pptRetCode         strResult;
//  } objCassette_CheckConditionForExchange_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  -------------------------   --------------------------------------------------
//
//[Pseudo Code]:
//

CORBA::Long PPTManager_i::cassette_CheckConditionForExchange(
                            objCassette_CheckConditionForExchange_out& strCassette_CheckConditionForExchange_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& equipmentID,
                            const pptWaferTransferSequence& strWaferXferSeq )
{
    char * methodName = NULL;
    try
    {
//      PPT_METHODTRACE_ENTRY("PPTManager_i::lot_CheckConditionForLoading");
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_CheckConditionForExchange");  //P3100134

        //--------------------------------------------------
        // Collect cassette ID of input parameter
        //--------------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckConditionForExchange", "Collect cassette ID of input parameter");

        objectIdentifierSequence cassetteIDSeq;
        CORBA::Long i, j;
//P3000280        CORBA::Boolean bCassetteAdded;
        CORBA::Boolean bCassetteAdded = FALSE;  //P3000280
        CORBA::Long lenWaferXferSeq = strWaferXferSeq.length();
        CORBA::Long lenCasIDSeq;

        PPT_METHODTRACE_V2("PPTManager_i::cassette_CheckConditionForExchange", "lenWaferXferSeq-->", lenWaferXferSeq);

        for ( i=0; i < lenWaferXferSeq; i++ )
        {
            PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckConditionForExchange", i );
            PPT_METHODTRACE_V2("PPTManager_i::cassette_CheckConditionForExchange", "Dest. Cassette ID", strWaferXferSeq[i].destinationCassetteID.identifier);
            PPT_METHODTRACE_V2("PPTManager_i::cassette_CheckConditionForExchange", "Org. Cassette ID ", strWaferXferSeq[i].originalCassetteID.identifier);

            bCassetteAdded = FALSE;

            lenCasIDSeq = cassetteIDSeq.length();
            PPT_METHODTRACE_V2("PPTManager_i::cassette_CheckConditionForExchange", "lenCasIDSeq-->", lenCasIDSeq);
            for ( j=0; j < lenCasIDSeq; j++ )
            {
                if ( 0 == CIMFWStrCmp(strWaferXferSeq[i].destinationCassetteID.identifier, cassetteIDSeq[j].identifier) )
                {
                    PPT_METHODTRACE_V2("PPTManager_i::cassette_CheckConditionForExchange", "set bCassetteAdded = TRUE", j);
                    bCassetteAdded = TRUE;
                    break;
                }
            }
            if ( bCassetteAdded == FALSE )
            {
                PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckConditionForExchange", "bCassetteAdded == FALSE");

                lenCasIDSeq++;
                cassetteIDSeq.length(lenCasIDSeq);
                cassetteIDSeq[lenCasIDSeq-1] = strWaferXferSeq[i].destinationCassetteID;
            }

            bCassetteAdded = FALSE;

            lenCasIDSeq = cassetteIDSeq.length();
            PPT_METHODTRACE_V2("PPTManager_i::cassette_CheckConditionForExchange", "lenCasIDSeq-->", lenCasIDSeq);
            for ( j=0; j < lenCasIDSeq; j++ )
            {
                if ( 0 == CIMFWStrCmp(strWaferXferSeq[i].originalCassetteID.identifier, cassetteIDSeq[j].identifier) )
                {
                    PPT_METHODTRACE_V2("PPTManager_i::cassette_CheckConditionForExchange", "set bCassetteAdded = TRUE", j);
                    bCassetteAdded = TRUE;
                    break;
                }
            }
            if ( bCassetteAdded == FALSE )
            {
                PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckConditionForExchange", "bCassetteAdded == FALSE");

                lenCasIDSeq++;
                cassetteIDSeq.length(lenCasIDSeq);
                cassetteIDSeq[lenCasIDSeq-1] = strWaferXferSeq[i].originalCassetteID;
            }
        }

        for(i=0; i<lenCasIDSeq; i++)
        {
            PPT_METHODTRACE_V2("PPTManager_i::cassette_CheckConditionForExchange", "Cassette IDs of in-parameter", cassetteIDSeq[i].identifier);
        }

        //--------------------------------------------------
        // Collect cassette's equipment ID / Cassette ObjRef
        //--------------------------------------------------
        lenCasIDSeq = cassetteIDSeq.length();
        PPT_METHODTRACE_V2("PPTManager_i::cassette_CheckConditionForExchange", "Collect cassette's equipment ID / Cassette ObjRef", lenCasIDSeq);

        PosCassetteSequence aPosCassetteSeq;
        aPosCassetteSeq.length(lenCasIDSeq);

        stringSequence strLoadedEquipments;
        strLoadedEquipments.length(lenCasIDSeq);

        CORBA::Long LoadedEqpCnt = 0;

        for ( i=0; i < lenCasIDSeq; i++ )
        {
            PosCassette_var aPosCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aPosCassette,
                                                   cassetteIDSeq[i],
                                                   strCassette_CheckConditionForExchange_out,
                                                   cassette_CheckConditionForExchange );

            CORBA::String_var tmpCassetteTransportState;
            try
            {
                tmpCassetteTransportState = aPosCassette->getTransportState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::currentAssignedMachine);

            Machine_var tmpMachine;
            try
            {
                tmpMachine = aPosCassette->currentAssignedMachine();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::currentAssignedMachine);

            LoadedEqpCnt++;
            strLoadedEquipments.length(LoadedEqpCnt);
            aPosCassetteSeq[LoadedEqpCnt-1] = aPosCassette;

            if ( ! CORBA::is_nil(tmpMachine) &&
                 0 == CIMFWStrCmp(tmpCassetteTransportState, SP_TransState_EquipmentIn) )
            {
                PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckConditionForExchange", "tmpMachine is not nil");

                CORBA::String_var strLoadedEquipment;
                try
                {
                    strLoadedEquipment = tmpMachine->getIdentifier();
                }
                CATCH_AND_RAISE_EXCEPTIONS(Machine::getIdentifier);

                strLoadedEquipments[LoadedEqpCnt-1] = strLoadedEquipment;
            }
        }

        strLoadedEquipments.length(LoadedEqpCnt);
        aPosCassetteSeq.length(LoadedEqpCnt);

        //--------------------------------------------------
        // Check all cassette is on the same equipment
        //--------------------------------------------------
        CORBA::String_var tmpLoadedEquipment;
        CORBA::Long lenLoadedEqp = strLoadedEquipments.length();
        PPT_METHODTRACE_V2("PPTManager_i::cassette_CheckConditionForExchange", "Check all cassette is on the same equipment", lenLoadedEqp);

        for (i=0; i < lenLoadedEqp; i++)
        {
            if ( 0 == i )
            {
                PPT_METHODTRACE_V2("PPTManager_i::cassette_CheckConditionForExchange", "i == 0", strLoadedEquipments[0]);
                tmpLoadedEquipment = strLoadedEquipments[0];
            }
            else
            {
                PPT_METHODTRACE_V3("PPTManager_i::cassette_CheckConditionForExchange", "i > 0", i, strLoadedEquipments[i]);

                if ( 0 != CIMFWStrCmp(tmpLoadedEquipment, strLoadedEquipments[i]) )
                {
                    SET_MSG_RC( strCassette_CheckConditionForExchange_out,
                                MSG_EQP_OF_CASSETTE_NOT_SAME,
                                RC_EQP_OF_CASSETTE_NOT_SAME );

                    return RC_EQP_OF_CASSETTE_NOT_SAME;
                }
            }
        }

        //--------------------------------------------------
        // Check Carriers are loaded to equipment or not
        //--------------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckConditionForExchange", "Check Carriers are loaded to equipment or not");

        if ( 0 == CIMFWStrLen(equipmentID.identifier) && 0 == CIMFWStrLen(tmpLoadedEquipment) )
        {
            SET_MSG_RC( strCassette_CheckConditionForExchange_out,
                        MSG_CASSETTE_NOT_ON_EQP,
                        RC_CASSETTE_NOT_ON_EQP );

            return RC_CASSETTE_NOT_ON_EQP;
        }

        //--------------------------------------------------
        // Check equipment of cassette and input equipment is same or not
        //--------------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckConditionForExchange", "Check equipment of cassette and input equipment is same or not");

        if ( 0 != CIMFWStrCmp(equipmentID.identifier, tmpLoadedEquipment) )
        {
            SET_MSG_RC( strCassette_CheckConditionForExchange_out,
                        MSG_CASSETTE_EQP_DIFFERENT,
                        RC_CASSETTE_EQP_DIFFERENT );

            return RC_CASSETTE_EQP_DIFFERENT;
        }

        //--------------------------------------------------
        // Get object reference of PosMachine
        //--------------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckConditionForExchange", "Get object reference of PosMachine");

        PosMachine_var aPosMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aPosMachine,
                                         equipmentID,
                                         strCassette_CheckConditionForExchange_out,
                                         cassette_CheckConditionForExchange );
        // if aPosMachine is NIL, return error

        //--------------------------------------------------
        // Get Equipment attributes
        //--------------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckConditionForExchange", "Get Equipment attributes");

        CORBA::Boolean bCassetteExchangeType;
        try
        {
            bCassetteExchangeType = aPosMachine->isCassetteChangeRequired();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::isCassetteChangeRequired);

// Comment Out by Katoh         // D4000056 2001/09/01 Start
// Comment Out by Katoh         //--------------------------------------------------
// Comment Out by Katoh         // Get Equipment attributes
// Comment Out by Katoh         //--------------------------------------------------
// Comment Out by Katoh         PPT_METHODTRACE_V1("", "Get Equipment attributes");
// Comment Out by Katoh 
// Comment Out by Katoh         CORBA::String_var strMachineCategory;
// Comment Out by Katoh         try
// Comment Out by Katoh         {
// Comment Out by Katoh             strMachineCategory = aPosMachine->getCategory();
// Comment Out by Katoh         }
// Comment Out by Katoh         CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getCategory);
// Comment Out by Katoh         // D4000056 2001/09/01 Start

        //--------------------------------------------------
        // Check equipment type
        //--------------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckConditionForExchange", "Check equipment type");

// Comment Out by Katoh         // D4000056 2001/09/01 Start
// Comment Out by Katoh         if( bCassetteExchangeType != TRUE && 
// Comment Out by Katoh             CIMFWStrCmp(strMachineCategory, SP_Mc_Category_WaferSorter) !=0 )
// Comment Out by Katoh         {
// Comment Out by Katoh         // D4000056 if( bCassetteExchangeType != TRUE )
// Comment Out by Katoh         // D4000056 {
        if( bCassetteExchangeType != TRUE )
        {
            SET_MSG_RC( strCassette_CheckConditionForExchange_out,
                    MSG_MACHINE_TYPE_NOT_EXCHANGE,
                    RC_MACHINE_TYPE_NOT_EXCHANGE );
        
            return RC_MACHINE_TYPE_NOT_EXCHANGE;
        }

        //--------------------------------------------------
        // Check cassette control jobs
        //--------------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckConditionForExchange", "Check cassette control jobs");
        PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckConditionForExchange", "bCassetteExchangeType == TRUE");

        // CORBA::Long lenCasSeq=0;
        // lenCasSeq = aPosCassetteSeq.length();

        objectIdentifierSequence cassetteControlJobIDs;
        cassetteControlJobIDs.length(lenCasIDSeq);

        for(i=0; i<lenCasIDSeq; i++)
        {
            PosControlJob_var aPosCtrlJob;
            try
            {
                aPosCtrlJob = aPosCassetteSeq[i]->getControlJob();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob);

            PPT_SET_OBJECT_IDENTIFIER(cassetteControlJobIDs[i],
                                      aPosCtrlJob,
                                      strCassette_CheckConditionForExchange_out,
                                      cassette_CheckConditionForExchange,
                                      PosControlJob);
        }

        for(i=1; i<lenCasIDSeq; i++)
        {
            if(CIMFWStrCmp(cassetteControlJobIDs[0].identifier, cassetteControlJobIDs[i].identifier))
            {
                PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckConditionForExchange", "Cassette Control Job is not same for all input cassette");

                CORBA::String_var cassetteID;
                try
                {
                    cassetteID = aPosCassetteSeq[i]->getIdentifier();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getIdentifier)

                PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForExchange_out,
                                    MSG_NOT_SAME_CTLJOBID,
                                    RC_NOT_SAME_CTLJOBID,
                                    cassetteID );
                return RC_NOT_SAME_CTLJOBID;
            }
        }

// Comment Out by Katoh         CORBA::String_var strCassetteControlJob;
// Comment Out by Katoh         CORBA::String_var tmpCassetteControlJob;
// Comment Out by Katoh         CORBA::Long lenCasSeq = aPosCassetteSeq.length();
// Comment Out by Katoh         PPT_METHODTRACE_V2("", "lenCasSeq-->", lenCasSeq);
// Comment Out by Katoh 
// Comment Out by Katoh         for ( i=0; i < lenCasSeq; i++ )
// Comment Out by Katoh         {
// Comment Out by Katoh             PosControlJob_var aPosCtrlJob;
// Comment Out by Katoh 
// Comment Out by Katoh             if ( i == 0 )
// Comment Out by Katoh             {
// Comment Out by Katoh                 PPT_METHODTRACE_V1("", "i == 0");
// Comment Out by Katoh                 try
// Comment Out by Katoh                 {
// Comment Out by Katoh                     aPosCtrlJob = aPosCassetteSeq[i]->getControlJob();
// Comment Out by Katoh                 }
// Comment Out by Katoh                 CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)
// Comment Out by Katoh 
// Comment Out by Katoh                 if ( CORBA::is_nil(aPosCtrlJob) )
// Comment Out by Katoh                 {
// Comment Out by Katoh                     PPT_METHODTRACE_V1("", "aPosCtrlJob is nil");
// Comment Out by Katoh 
// Comment Out by Katoh                     CORBA::String_var cassetteID;
// Comment Out by Katoh                     try
// Comment Out by Katoh                     {
// Comment Out by Katoh                         cassetteID = aPosCassetteSeq[i]->getIdentifier();
// Comment Out by Katoh                     }
// Comment Out by Katoh                     CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getIdentifier)
// Comment Out by Katoh 
// Comment Out by Katoh                     PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForExchange_out,
// Comment Out by Katoh                                         MSG_NOT_SAME_CTLJOBID,
// Comment Out by Katoh                                         RC_NOT_SAME_CTLJOBID,
// Comment Out by Katoh                                         cassetteID );
// Comment Out by Katoh                 }
// Comment Out by Katoh                 else
// Comment Out by Katoh                 {
// Comment Out by Katoh                     PPT_METHODTRACE_V1("", "aPosCtrlJob is not nil");
// Comment Out by Katoh                     try
// Comment Out by Katoh                     {
// Comment Out by Katoh                         strCassetteControlJob = aPosCtrlJob->getIdentifier();
// Comment Out by Katoh                     }
// Comment Out by Katoh                     CATCH_AND_RAISE_EXCEPTIONS(PosControlJob::getIdentifier)
// Comment Out by Katoh                 }
// Comment Out by Katoh             }
// Comment Out by Katoh             else
// Comment Out by Katoh             {
// Comment Out by Katoh                 PPT_METHODTRACE_V2("", "i > 0", i);
// Comment Out by Katoh                 try
// Comment Out by Katoh                 {
// Comment Out by Katoh                     aPosCtrlJob = aPosCassetteSeq[i]->getControlJob();
// Comment Out by Katoh                 }
// Comment Out by Katoh                 CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)
// Comment Out by Katoh 
// Comment Out by Katoh                 if ( CORBA::is_nil(aPosCtrlJob) )
// Comment Out by Katoh                 {
// Comment Out by Katoh                     PPT_METHODTRACE_V1("", "aPosCtrlJob is nil");
// Comment Out by Katoh 
// Comment Out by Katoh                     CORBA::String_var cassetteID;
// Comment Out by Katoh                     try
// Comment Out by Katoh                     {
// Comment Out by Katoh                         cassetteID = aPosCassetteSeq[i]->getIdentifier();
// Comment Out by Katoh                     }
// Comment Out by Katoh                     CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getIdentifier)
// Comment Out by Katoh 
// Comment Out by Katoh                     PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForExchange_out,
// Comment Out by Katoh                                         MSG_NOT_SAME_CTLJOBID,
// Comment Out by Katoh                                         RC_NOT_SAME_CTLJOBID,
// Comment Out by Katoh                                         cassetteID );
// Comment Out by Katoh                 }
// Comment Out by Katoh                 else
// Comment Out by Katoh                 {
// Comment Out by Katoh                     PPT_METHODTRACE_V1("", "aPosCtrlJob is not nil");
// Comment Out by Katoh                     try
// Comment Out by Katoh                     {
// Comment Out by Katoh                         tmpCassetteControlJob = aPosCtrlJob->getIdentifier();
// Comment Out by Katoh                     }
// Comment Out by Katoh                     CATCH_AND_RAISE_EXCEPTIONS(PosControlJob::getIdentifier)
// Comment Out by Katoh 
// Comment Out by Katoh                     if ( 0 != CIMFWStrCmp(strCassetteControlJob, tmpCassetteControlJob) )
// Comment Out by Katoh                     {
// Comment Out by Katoh                         PPT_METHODTRACE_V1("", "strCassetteControlJob != tmpCassetteControlJob");
// Comment Out by Katoh 
// Comment Out by Katoh                         CORBA::String_var cassetteID;
// Comment Out by Katoh                         try
// Comment Out by Katoh                         {
// Comment Out by Katoh                             cassetteID = aPosCassetteSeq[i]->getIdentifier();
// Comment Out by Katoh                         }
// Comment Out by Katoh                         CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getIdentifier)
// Comment Out by Katoh 
// Comment Out by Katoh                         PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForExchange_out,
// Comment Out by Katoh                                             MSG_NOT_SAME_CTLJOBID,
// Comment Out by Katoh                                             RC_NOT_SAME_CTLJOBID,
// Comment Out by Katoh                                             cassetteID );
// Comment Out by Katoh                     }
// Comment Out by Katoh                 }
// Comment Out by Katoh             }
// Comment Out by Katoh         }

//      PPT_METHODTRACE_EXIT("PPTManager_i::lot_CheckConditionForLoading");
        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_CheckConditionForExchange");  //P3100134

        return( RC_OK );
    }
//  CATCH_GLOBAL_EXCEPTIONS(strCassette_CheckConditionForExchange_out, lot_CheckConditionForLoading, methodName)
    CATCH_GLOBAL_EXCEPTIONS(strCassette_CheckConditionForExchange_out, cassette_CheckConditionForExchange, methodName)  //P3100134
}

