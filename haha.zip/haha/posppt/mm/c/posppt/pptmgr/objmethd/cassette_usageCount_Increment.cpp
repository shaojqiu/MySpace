#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_usageCount_Increment.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:36:56 [ 7/13/07 19:36:57 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_usageCount_Increment.cpp
//

#include "pptmgr.hpp"
#include "timstamp.hpp"
#include "duration.hpp"

#include "pcas.hh"
#include "plot.hh"
#include "pperson.hh"
#include "pstmc.hh"
#include "pmc.hh"
#include "pbufrs.hh"
#include "pmaloc.hh"
//D5000016 #include "ppcgrp.hh"

// Class: PPTManager
//
// [Object Function Name]: long   cassette_usageCount_Increment
//
// Date       Level    Author         Note
// ---------- -----    -------------  -------------------------------------------
// 1999-07-22 0.00     Y.Iwasaki      Initial Release (DCR9900155) (R20b)
// 2000/09/12 P3000139 T.Yamano       SET_MSG_RC(MSG_OK,RC_OK) Comment Out
// 2003/05/20 D5000016 K.Kido         Useless class deletion(R5.0).
//
// [Function Description]:
//   Increase the usage count of specified cassette.
//
//    - theTimeUsed : +1
//
// [Input Parameters]:
//   in  pptObjCommonIn        strObjCommonIn;
//   in  objectIdentifier      cassetteID;
//
// [Output Parameters]:
//   out objCassette_usageCount_Increment_out   strCassette_usageCount_Increment_out;
//
//   typedef struct objCassette_usageCount_Increment_out_struct {
//       pptRetCode            strResult;
//   } objCassette_usageCount_Increment_out;
//
//
// [Return Value]:
//
//   Return Code                 Messsage ID
//   --------------------------- ------------------------------------------------
//   RC_OK                       MSG_OK
//   RC_NOT_FOUND_CAST           MSG_NOT_FOUND_CAST
//   RC_LOCKED_BY_ANOTHER        MSG_LOCKED_BY_ANOTHER
//   RC_SYSTEM_ERROR             MSG_SYSTEM_ERROR
//
CORBA::Long PPTManager_i::cassette_usageCount_Increment(
                          objCassette_usageCount_Increment_out&   strCassette_usageCount_Increment_out,
                          const pptObjCommonIn&                   strObjCommonIn,
                          const objectIdentifier&                 cassetteID )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_usageCount_Increment");

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
//P3000139        SET_MSG_RC( strCassette_usageCount_Increment_out, MSG_OK, RC_OK )

        /*-------------------------*/
        /*   Get Cassette Object   */
        /*-------------------------*/
        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR(aCassette, cassetteID, strCassette_usageCount_Increment_out, cassette_usageCount_Increment);

        /*-----------------------*/
        /*   Increse timesUsed   */
        /*-----------------------*/
        try
        {
            aCassette->incrementTimesUsed();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::incrementTimesUsed)

        /*---------------------------*/
        /*   Increse totalTimeUsed   */
        /*---------------------------*/
        CORBA::Long totalTimesUsed = 0;
        try
        {
            totalTimesUsed = aCassette->getTotalTimesUsed();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTotalTimesUsed)

        totalTimesUsed++;

        try
        {
            aCassette->setTotalTimesUsed(totalTimesUsed);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setTotalTimesUsed)

        /*----------------------*/
        /*   Return to Caller   */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_usageCount_Increment");
        return( RC_OK );

    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_usageCount_Increment_out, cassette_usageCount_Increment, methodName)
}

