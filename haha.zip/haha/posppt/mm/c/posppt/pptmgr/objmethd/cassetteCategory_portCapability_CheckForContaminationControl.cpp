#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassetteCategory_portCapability_CheckForContaminationControl.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:30:24 [ 7/13/07 19:30:25 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassetteCategory_portCapability_CheckForContaminationControl.cpp
//

#include "pptmgr.hpp"

#include "pcas.hh"
#include "pportrs.hh"

//[Object Function Name]: long   cassetteCategory_portCapability_CheckForContaminationControl
//
// Date        Level   Author         Note
// ----------  ------- -------------  -------------------------------------------
// 2001-07-20  D4000028 K.Takikita    Initila Release  (R40)
// 2001-09-21  P4000234 S.Tokumasu    Fix Bug
//
//[Function Description]:
//  Check Cassette's CassetteCapability and Port's CassetteCategoryCapability for Copper/Non Copper
//
//[Input Parameters]:
//  in  pptObjCommonIn    strObjCommonIn;
//  in  objectIdentifier  cassetteID;
//  in  objectIdentifier  equipmentID;
//  in  objectIdentifier  portID;
//
//[Output Parameters]:
//  out objCassetteCategory_portCapability_CheckForContaminationControl_out   strCassetteCategory_portCapability_CheckForContaminationControl_out;
//
//  typedef struct objCassetteCategory_portCapability_CheckForContaminationControl_out_struct {
//      pptRetCode                     strResult;
//      any siInfo;
//  } objCassetteCategory_portCapability_CheckForContaminationControl_out;
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//  RC_INVALID_CATEGORY       MSG_INVALID_CATEGORY
//
//[Pseudo Code]:
//

CORBA::Long PPTManager_i::cassetteCategory_portCapability_CheckForContaminationControl(
                                                        objCassetteCategory_portCapability_CheckForContaminationControl_out& strCassetteCategory_portCapability_CheckForContaminationControl_out,
                                                        const pptObjCommonIn&                                                strObjCommonIn,
                                                        const objectIdentifier&                                              cassetteID,
                                                        const objectIdentifier&                                              equipmentID,
                                                        const objectIdentifier&                                              portID
                                                        )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassetteCategory_portCapability_CheckForContaminationControl");

        CORBA::Long rc;

        SET_MSG_RC( strCassetteCategory_portCapability_CheckForContaminationControl_out ,
                    MSG_OK,
                    RC_OK
                    );
     
        /*---------------------------------------------*/
        /* Get PosCassette Object And cassetteCategory */
        /*---------------------------------------------*/
        PPT_METHODTRACE_V1("PPTManager_i::cassetteCategory_portCapability_CheckForContaminationControl","Get PosCassette Object And cassetteCategory");
        PosCassette_var aPosCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR (aPosCassette, 
                                               cassetteID,
                                               strCassetteCategory_portCapability_CheckForContaminationControl_out,
                                               cassetteCategory_portCapability_CheckForContaminationControl);

        CORBA::String_var cassetteCategory;
        try
        {
            cassetteCategory = aPosCassette->getCassetteCategory();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getCassetteCategory)

        /*-----------------------------------------------------------*/
        /* Get PosPortResource Object And cassetteCategoryCapability */
        /*-----------------------------------------------------------*/
        PPT_METHODTRACE_V1("PPTManager_i::cassetteCategory_portCapability_CheckForContaminationControl","Get PosPortResource Object And cassetteCategoryCapability");
        PosMachine_var aPosMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aPosMachine,
                                         equipmentID,
                                         strCassetteCategory_portCapability_CheckForContaminationControl_out,
                                         cassetteCategory_portCapability_CheckForContaminationControl );

        PortResource_var aPort;
        PPT_CONVERT_PORTID_TO_PORTRESOURCE_OR( aPosMachine,
                                               aPort,
                                               portID,
                                               strCassetteCategory_portCapability_CheckForContaminationControl_out,
                                               cassetteCategory_portCapability_CheckForContaminationControl );

        PosPortResource_var aPosPortResource;
        aPosPortResource = PosPortResource::_narrow(aPort);

        stringSequence  * cassetteCategoryCapability= NULL ;
        stringSequence_var  cassetteCategoryCapabilityVar;
        try
        {
            cassetteCategoryCapability = aPosPortResource->getCassetteCategoryCapability();
            cassetteCategoryCapabilityVar = cassetteCategoryCapability;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::getCassetteCategoryCapability)

        /*-----------------------------------------------------------*/
        /* It is checked whether a category is the same.             */
        /*-----------------------------------------------------------*/
        PPT_METHODTRACE_V1("PPTManager_i::cassetteCategory_portCapability_CheckForContaminationControl","It is checked whether a category is the same.");
        CORBA::Long categoryLen = (* cassetteCategoryCapability).length();
        CORBA::Long i;
        CORBA::Boolean bCategory = FALSE;

        for(i = 0; i < categoryLen; i++)
        {
            PPT_METHODTRACE_V2("PPTManager_i::cassetteCategory_portCapability_CheckForContaminationControl","categoryLen",i);
            if( CIMFWStrCmp( cassetteCategory , (* cassetteCategoryCapability)[i] ) == 0 )
            {
                PPT_METHODTRACE_V1("PPTManager_i::cassetteCategory_portCapability_CheckForContaminationControl","cassetteCategory = cassetteCategoryCapability");
                bCategory = TRUE;
                break;
            }
        }

        //--start P4000234
        if(categoryLen ==0)
        {
            PPT_METHODTRACE_V2("PPTManager_i::cassetteCategory_portCapability_CheckForContaminationControl","categoryLen ==0",categoryLen);
            bCategory = TRUE;
        }
        //--end   P4000234

        if(bCategory == FALSE)
        {
            PPT_METHODTRACE_V1("PPTManager_i::cassetteCategory_portCapability_CheckForContaminationControl","cassetteCategory != cassetteCategoryCapability");
            SET_MSG_RC( strCassetteCategory_portCapability_CheckForContaminationControl_out ,
                        MSG_CATEGORY_INCONSISTENCY,
                        RC_CATEGORY_INCONSISTENCY
                        );
            return( RC_CATEGORY_INCONSISTENCY );
        }
        else
        {
            rc = RC_OK;
        }
       
        PPT_METHODTRACE_EXIT("PPTManager_i::cassetteCategory_portCapability_CheckForContaminationControl");

        return( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassetteCategory_portCapability_CheckForContaminationControl_out, cassetteCategory_portCapability_CheckForContaminationControl, methodName)
}
