#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_multiLotType_Get.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:35:29 [ 7/13/07 19:35:29 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_multiLotType_Get.cpp
//

#include "pptmgr.hpp"
#include "pcas.hh"

//[Object Function Name]: long   cassette_multiLotType_Get
//
// Date        Level  Author         Note
// ----------  -----  -------------  -------------------------------------------
//
//
//[Function Description]:
//  Get multiLotType in PosCassette object and set it to returned structure.
//
//[Input Parameters]:
//  in  pptObjCommonIn        strObjCommonIn;
//  in  objectIdentifier      cassetteID;
//
//[Output Parameters]:
//  out objCassette_multiLotType_Get_out   strCassette_multiLotType_Get_out;
//
//  typedef struct objCassette_multiLotType_Get_out_struct {
//      pptRetCode            strResult;
//      string                multiLotType;
//  } objCassette_multiLotType_Get_out;
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//  RC_NOT_FOUND_CASSETTE     MSG_NOT_FOUND_CASSETTE
//  RC_LOCKED_BY_ANOTHER      MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR           MSG_SYSTEM_ERROR

CORBA::Long PPTManager_i::cassette_multiLotType_Get(
                            objCassette_multiLotType_Get_out& strCassette_multiLotType_Get_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& cassetteID)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_multiLotType_Get");
        PPT_METHODTRACE_V2( "PPTManager_i::cassette_multiLotType_Get","in-parm's cassetteID", cassetteID.identifier);

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        /*-------------------------*/
        /*   Get Cassette Object   */
        /*-------------------------*/
        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR(aCassette,cassetteID,strCassette_multiLotType_Get_out,cassette_multiLotType_Get);

        /*----------------------*/
        /*   Get multiLotType   */
        /*----------------------*/
        try
        {
            strCassette_multiLotType_Get_out.multiLotType = aCassette->getMultiLotType();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getMultiLotType);

        /*----------------------*/
        /*   Return to Caller   */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_multiLotType_Get");
        return( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_multiLotType_Get_out, cassette_multiLotType_Get, methodName);
}
