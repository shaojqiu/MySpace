#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_CheckConditionForOpeStartCancel.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:31:54 [ 7/13/07 19:31:56 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_CheckConditionForOpeStartCancel.cpp
//

#include "pptmgr.hpp"
#include "pcas.hh"

//[Object Function Name]: long   cassette_CheckConditionForOpeStartCancel
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/15 DSIV00000099 F.Chen         SLM(Small Lot Manufacturing) Support.
//
//
//
//[Function Description]:
//  Check cassette's condition for OpeStartCancel.
//
//  The following conditions are checked.
//
//  <<< transferState >>>
//  Cassette's transfer state must be EI.
//
//
//[Input Parameters]:
//  in  pptObjCommonIn             strObjCommonIn;
//  in  pptStartCassetteSequence   strStartCassette;
//
//[Output Parameters]:
//  out objCassette_CheckConditionForOpeStartCancel_out   strCassette_CheckConditionForOpeStartCancel_out;
//
//  typedef struct objCassette_CheckConditionForOpeStartCancel_out_struct {
//      pptRetCode                      strResult;
//  } objCassette_CheckConditionForOpeStartCancel_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------

CORBA::Long PPTManager_i::cassette_CheckConditionForOpeStartCancel(
                            objCassette_CheckConditionForOpeStartCancel_out& strCassette_CheckConditionForOpeStartCancel_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const pptStartCassetteSequence& strStartCassette)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_CheckConditionForOpeStartCancel");
        PPT_METHODTRACE_V2( "PPTManager_i::cassette_CheckConditionForOpeStartCancel","in-parm's strStartCassette", "pptStartCassetteSequence");

        /*----------------*/
        /*                */
        /*   Initialize   */
        /*                */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        /*--------------------------------------*/
        /*                                      */
        /*   Check Cassette's Transfer Status   */
        /*                                      */
        /*--------------------------------------*/
        CORBA::Long SCLength;
        SCLength = strStartCassette.length();
        for (CORBA::Long i=0 ; i<SCLength ; i++)
        {
            PPT_METHODTRACE_V3( "PPTManager_i::cassette_CheckConditionForOpeStartCancel","loop to strStartCassette.length()",SCLength,i);

            if (CIMFWStrLen(strStartCassette[i].cassetteID.identifier) == 0)
            {
                // blank start cassetteID is allowed because of SLM
                PPT_METHODTRACE_V1( "","CIMFWStrLen(strStartCassette[i].cassetteID.identifier) == 0");
                continue;
            }

            /*-------------------------*/
            /*   Get Cassette Object   */
            /*-------------------------*/
            PosCassette_var aCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR(aCassette,strStartCassette[i].cassetteID,strCassette_CheckConditionForOpeStartCancel_out,cassette_CheckConditionForOpeStartCancel);

            /*-----------------------*/
            /*   Get TransferState   */
            /*-----------------------*/
            CORBA::String_var transferState;
            try
            {
                transferState = aCassette->getTransportState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTransportState);

            if (CIMFWStrCmp(transferState,SP_TransState_EquipmentIn) == 0)
            {
                PPT_METHODTRACE_V1( "PPTManager_i::cassette_CheckConditionForOpeStartCancel","transferState == SP_TransState_EquipmentIn");
                rc = RC_OK;
            }
            else
            {
                PPT_METHODTRACE_V1( "PPTManager_i::cassette_CheckConditionForOpeStartCancel","transferState != SP_TransState_EquipmentIn");
                objectIdentifier cassetteID;
                PPT_SET_OBJECT_IDENTIFIER(cassetteID,aCassette,strCassette_CheckConditionForOpeStartCancel_out,cassette_CheckConditionForOpeStartCancel,PosCassette);
                PPT_SET_MSG_RC_KEY2(strCassette_CheckConditionForOpeStartCancel_out, MSG_INVALID_CAST_XFERSTAT, RC_INVALID_CAST_XFERSTAT,transferState, cassetteID.identifier )
                return(RC_INVALID_CAST_XFERSTAT);
            }

        }

        /*----------------------*/
        /*                      */
        /*   Return to Caller   */
        /*                      */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_CheckConditionForOpeStartCancel");
        return(RC_OK);
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_CheckConditionForOpeStartCancel_out, cassette_CheckConditionForOpeStartCancel, methodName);
}
