//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: AuthSvr_SendAuthenticate.cpp
//

#include "pptmgr.hpp"
#include "authserver.hh"
#include "authstr.hh"
#include "unistd.h"

// Class: PPTManager
//
// Service: AuthSvr_SendAuthenticate()
//
// Change history:
//
// Date        Level          Author         Note
// ----------  -------------  -------------  -------------------------------------------
// 2009-06-12  DSIV00001049   R.Okano        Initial Release for Security Control Enhancement
// 2009-10-20  PSIV00001308   R.Okano        Add "return RC_AUTHENTICATION_ERROR;".
//
// Description:
//    Bind to Authserver, and then call authentication method for requested user.
//    Specifying forceLDAPFlag, you can change the behavior of Authserver.
//        1    : Authserver always accesses to LDAP server for authentication.
//        else : Authserver accesses cash in memory at first, 
//               then accesses to LDAP server if requested user is not found in cash.
//
// Return:
//    Long
//
// Parameter:
//    objAuthSvr_SendAuthenticate_out&  strAuthSvr_SendAuthenticate_out
//    const pptObjCommonIn&             strObjCommonIn
//    const pptUser&                    requestUserID
//    const CORBA::Long                 forceLDAPFlag
//
//    typedef struct objAuthSvr_SendAuthenticate_out_struct {
//       pptRetCode              strResult;
//       any                     siInfo;
//    } objAuthSvr_SendAuthenticate_out;
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long PPTManager_i::AuthSvr_SendAuthenticate(
    objAuthSvr_SendAuthenticate_out&  strAuthSvr_SendAuthenticate_out,
    const pptObjCommonIn&             strObjCommonIn,
    const pptUser&                    requestUserID,
    const CORBA::Long                 forceLDAPFlag )
{
    char *methodName = NULL;
    
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::AuthSvr_SendAuthenticate");
        
        /*--------------------*/
        /*   Initialization   */
        /*--------------------*/
        CORBA::Long rc = RC_OK;

        /*------------------------------*/
        /*   Get Environment Variable   */
        /*------------------------------*/
        CORBA::String_var AuthSvrHostName   = CIMFWStrDup(getenv(SP_AUTH_HOST_NAME));
        CORBA::String_var AuthSvrServerName = CIMFWStrDup(getenv(SP_AUTH_SERVER_NAME));
        CORBA::String_var tmpRetryMax       = CIMFWStrDup(getenv(SP_AUTH_AUTHENTICATE_RETRY));
        CORBA::String_var tmpRetryInterval  = CIMFWStrDup(getenv(SP_AUTH_AUTHENTICATE_INTERVAL));
        CORBA::String_var timeOutValue      = CIMFWStrDup(getenv(SP_AUTH_TX_TIMEOUT));
        PPT_METHODTRACE_V1("","### Get Environment Variable for Authserver...");
        PPT_METHODTRACE_V2("","### AuthSvrHostName   = ",AuthSvrHostName);
        PPT_METHODTRACE_V2("","### AuthSvrServerName = ",AuthSvrServerName);
        
        /*-----------------------*/
        /*   Set Retry Setting   */
        /*-----------------------*/
        CORBA::Long    retryMax = 0;
        CORBA::Long    retryInterval = 0;

        if( 0 == CIMFWStrLen(tmpRetryMax) )
        {
            retryMax = SP_AUTH_AUTHENTICATE_RETRY_DEFAULT;
        }
        else
        {
            retryMax = atoi(tmpRetryMax);
            if( retryMax < 0)
            {
                retryMax = SP_AUTH_AUTHENTICATE_RETRY_DEFAULT;
            }
        }
        if( 0 == CIMFWStrLen(tmpRetryInterval) )
        {
            retryInterval = SP_AUTH_AUTHENTICATE_INTERVAL_DEFAULT;
        }
        else
        {
            retryInterval = atoi(tmpRetryInterval);
            if( retryInterval < 0)
            {
                retryInterval = SP_AUTH_AUTHENTICATE_INTERVAL_DEFAULT;
            }
        }
        PPT_METHODTRACE_V2("","### retryMax  = ",retryMax);
        PPT_METHODTRACE_V2("","### retryInterval = ",retryInterval);
        
        /*-------------------------------*/
        /*   Authentication Main Logic   */
        /*-------------------------------*/
        for( CORBA::Long retryCnt = 0; retryCnt <= retryMax; retryCnt++ )
        {
            if( retryCnt != 0 && retryInterval != 0)
            {
                PPT_METHODTRACE_V2("","now sleeping... ",retryInterval);
                sleep(retryInterval);
            }

            /*------------------------*/
            /*   Bind to Authserver   */
            /*------------------------*/
            PPT_METHODTRACE_V1("", "Bind to Authserver");

            objAuthSvr_GetAuthServer_out strAuthSvr_GetAuthServer_out;
            rc = AuthSvr_GetAuthServer( strAuthSvr_GetAuthServer_out,
                                        strObjCommonIn,
                                        AuthSvrServerName,
                                        AuthSvrHostName );
            if( rc == RC_OK )
            {
                PPT_METHODTRACE_V1("","AuthSvr_GetAuthServer() == RC_OK");
            }
            else if ( rc == RC_AUTHSERVER_BIND_FAIL )
            {
                PPT_METHODTRACE_V2("","AuthSvr_GetAuthServer() rc != RC_OK  Retry!! now retryCnt...",retryCnt);
                strAuthSvr_SendAuthenticate_out.strResult = strAuthSvr_GetAuthServer_out.strResult;
                continue;
            }
            else
            {
                PPT_METHODTRACE_V1("","AuthSvr_GetAuthServer() != RC_OK");
                strAuthSvr_SendAuthenticate_out.strResult = strAuthSvr_GetAuthServer_out.strResult;
                return rc;
            }
            PPT_METHODTRACE_V2("", "AuthSvr ---> ", strAuthSvr_GetAuthServer_out.AuthSvr);

            /*--------------------------*/
            /*   Get Authserver object  */
            /*--------------------------*/
            CORBA::Object_var tmpAuthSvr = CORBA::Object::_nil();
            Authserver_var AuthSvrObj = Authserver::_nil();
            try
            {
                tmpAuthSvr = SP_STRING_TO_OBJECT(strAuthSvr_GetAuthServer_out.AuthSvr);
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "SP_STRING_TO_OBJECT() raises exception");
                try
                {
                    externalServerList.remove((char *)AuthSvrServerName);
                }
                catch(...)
                {
                    PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                }
                SET_MSG_RC( strAuthSvr_SendAuthenticate_out,
                            MSG_SYSTEM_ERROR,
                            RC_SYSTEM_ERROR );
                return RC_SYSTEM_ERROR;
            }
            if( CORBA::is_nil(tmpAuthSvr) == TRUE)
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil(tmpAuthSvr) == TRUE");
                try
                {
                    externalServerList.remove((char *)AuthSvrServerName);
                }
                catch(...)
                {
                    PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                }
                SET_MSG_RC( strAuthSvr_SendAuthenticate_out,
                            MSG_EXT_SERVER_NIL_OBJ,
                            RC_EXT_SERVER_NIL_OBJ );
                return RC_EXT_SERVER_NIL_OBJ;
            }

            AuthSvrObj = Authserver::_narrow(tmpAuthSvr);
            if( CORBA::is_nil(AuthSvrObj) == TRUE)
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil(AuthSvrObj) == TRUE");
                try
                {
                    externalServerList.remove((char *)AuthSvrServerName);
                }
                catch(...)
                {
                    PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                }
                SET_MSG_RC( strAuthSvr_SendAuthenticate_out,
                            MSG_EXT_SERVER_NIL_OBJ,
                            RC_EXT_SERVER_NIL_OBJ );
                return RC_EXT_SERVER_NIL_OBJ;
            }
        
            /*--------------------------------*/
            /*   Send Request to Authserver   */
            /*--------------------------------*/
            CORBA::Environment envTimeOut = SP_CORBAENV_DEFENV;
            PPT_METHODTRACE_V2("","timeOutValue ---> ",timeOutValue);
            if ( 0 < CIMFWStrLen(timeOutValue) )
            {
                PPT_METHODTRACE_V1("", "setting timeout!!");
                envTimeOut.timeout(atol(timeOutValue) * 1000);
            }
            
            AuthResult_var   authResult_var;
            CORBA::Any       siInfo;
            try
            {
                authResult_var = AuthSvrObj->authenticate( requestUserID.userID.identifier,
                                                           requestUserID.password,
                                                           SP_AUTH_ClientName_MMS,
                                                           forceLDAPFlag,
                                                           siInfo,
                                                           envTimeOut);

                if( authResult_var->retcode == Authserver::CODEAUTHENTICATION_SUCCESS )
                {
                    PPT_METHODTRACE_V1("", "authResult_var->retcode == CODEAUTHENTICATION_SUCCESS");
                    SET_MSG_RC( strAuthSvr_SendAuthenticate_out,
                                MSG_OK,
                                RC_OK );
                }
                else
                {
                    PPT_METHODTRACE_V1("", "auth_varAuthResult.retcode != CODEAUTHENTICATION_SUCCESS");
                    CORBA::String_var authCode = ConvertLongtoString( authResult_var->retcode );
                    PPT_SET_MSG_RC_KEY2( strAuthSvr_SendAuthenticate_out,
                                         MSG_AUTHENTICATION_ERROR,
                                         RC_AUTHENTICATION_ERROR,
                                         authCode,
                                         authResult_var->message);
                    return RC_AUTHENTICATION_ERROR;                   //PSIV00001308
                }
            }
            catch(const CORBA::SystemException &SysEx)
            {
                PPT_METHODTRACE_V1("", "AuthSvrObj->authenticate() raises system exception");
                APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
                try
                {
                    externalServerList.remove((char *)AuthSvrServerName);
                }
                catch(...)
                {
                    PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                }
                SET_MSG_RC( strAuthSvr_SendAuthenticate_out,
                            MSG_AUTHSERVER_BIND_FAIL,
                            RC_AUTHSERVER_BIND_FAIL );

                PPT_METHODTRACE_V2("","AuthSvrObj->authenticate() raises exception  Retry!! now retryCnt...",retryCnt);
                continue;
            }
            catch(const Authserver::AuthException &AuthEx)
            {
                PPT_METHODTRACE_V1("", "AuthSvrObj->authenticate() raises AuthException");
                CORBA::String_var authCode = ConvertLongtoString(AuthEx.code);
                PPT_SET_MSG_RC_KEY2( strAuthSvr_SendAuthenticate_out,
                                     MSG_AUTHSERVER_ERROR,
                                     RC_AUTHSERVER_ERROR,
                                     authCode,
                                     AuthEx.message);
                return RC_AUTHSERVER_ERROR;
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "AuthSvrObj->authenticate() raises exception");
                APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ();
                try
                {
                    externalServerList.remove((char *)AuthSvrServerName);
                }
                catch(...)
                {
                    PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                }
                SET_MSG_RC( strAuthSvr_SendAuthenticate_out,
                            MSG_SYSTEM_ERROR,
                            RC_SYSTEM_ERROR );
                return RC_SYSTEM_ERROR;
            }
            
            //if authentication is performed, escape from retry loop
            break;
        } //end of retry loop
        
        /*--------------------------*/
        /*   Set output parameter   */
        /*--------------------------*/
        rc = atoi(strAuthSvr_SendAuthenticate_out.strResult.returnCode);
        
        PPT_METHODTRACE_EXIT("PPTManager_i::AuthSvr_SendAuthenticate");
        return rc;
    }
    CATCH_GLOBAL_EXCEPTIONS(strAuthSvr_SendAuthenticate_out, AuthSvr_SendAuthenticate, methodName);
}
