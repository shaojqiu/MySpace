#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_dispatchState_Change.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:34:16 [ 7/13/07 19:34:17 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_dispatchState_Change.cpp
//

#include "pptmgr.hpp"
#include "timstamp.hpp"
#include "duration.hpp"

#include "pcas.hh"
#include "plot.hh"
#include "pperson.hh"
#include "pstmc.hh"
#include "pmc.hh"
#include "pbufrs.hh"
#include "pmaloc.hh"
//D5000016 #include "ppcgrp.hh"

//[Object Function Name]: long   cassette_dispatchState_Change
//
// Date       Level    Author         Note
// ---------- -----    -------------  -------------------------------------------
// 2000-09-07 P3000071 Y.Iwasaki      Change check logic for FALSE case
// 2000/09/12 P3000139 T.Yamano       SET_MSG_RC(MSG_OK,RC_OK) Comment Out
// 2003/05/20 D5000016 K.Kido         Useless class deletion(R5.0).
//
//
//
//[Function Description]:
//  Change dispatch reserved status of cassette by input parameter.
//
//[Input Parameters]:
//  in  pptObjCommonIn        strObjCommonIn;
//  in  objectIdentifier      cassetteID;
//  in  boolean               dispatchReservedFlag;
//
//[Output Parameters]:
//  out objCassette_dispatchState_Change_out   strCassette_dispatchState_Change_out;
//
//  typedef struct objCassette_reservedState_Get_out_struct {
//      pptRetCode            strResult;
//  } objCassette_dispatchState_Change_out;
//
//
//[Return Value]:
//
//  Return Code                      Messsage ID
//  -------------------------------- -------------------------------------------
//  RC_OK                            MSG_OK
//  RC_ALREADY_DISPATCH_RESVED_CST   MSG_ALREADY_DISPATCH_RESVED_CST
//  RC_NOT_DISPATCH_RESVED_CST       MSG_NOT_DISPATCH_RESVED_CST
//  RC_NOT_FOUND_CASSETTE            MSG_NOT_FOUND_CASSETTE
//  RC_LOCKED_BY_ANOTHER             MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR                  MSG_SYSTEM_ERROR
//

CORBA::Long PPTManager_i::cassette_dispatchState_Change(
                                   objCassette_dispatchState_Change_out& strCassette_dispatchState_Change_out,
                                   const pptObjCommonIn&                 strObjCommonIn,
                                   const objectIdentifier&               cassetteID,
                                   const CORBA::Boolean&                 dispatchReserveFlag)
{
    char * methodName = NULL;
    try
    {

        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_dispatchState_Change");
        PPT_METHODTRACE_V2( "PPTManager_i::cassette_dispatchState_Change","in-parm's cassetteID", cassetteID.identifier);
        PPT_METHODTRACE_V2( "PPTManager_i::cassette_dispatchState_Change","in-parm's dispatchReserveFlag", dispatchReserveFlag);


        /*----------------*/
        /*   Initialize   */
        /*----------------*/
//P3000139        SET_MSG_RC( strCassette_dispatchState_Change_out, MSG_OK, RC_OK )

        CORBA::Long    rc = RC_OK;
        CORBA::Boolean curDispatchReservedFlag = FALSE;

        /*-------------------------*/
        /*   Get Cassette Object   */
        /*-------------------------*/
        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                               cassetteID,
                                               strCassette_dispatchState_Change_out,
                                               cassette_dispatchState_Change );

        if( CORBA::is_nil(aCassette) == TRUE)
        {
            PPT_METHODTRACE_V1("PPTManager_i::cassette_dispatchState_Change", "aCassette is null")
            rc = RC_NOT_FOUND_CASSETTE;
            PPT_SET_MSG_RC_KEY(strCassette_dispatchState_Change_out, MSG_NOT_FOUND_CASSETTE , RC_NOT_FOUND_CASSETTE , cassetteID.identifier);
            return(rc);
        }

        /*--------------------------------*/
        /*   Get Current Dispatch State   */
        /*--------------------------------*/
        try
        {
           curDispatchReservedFlag = aCassette->isDispatchReserved();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isDispatchReserved)

        if ( dispatchReserveFlag == TRUE )
        {
            PPT_METHODTRACE_V1("PPTManager_i::cassette_dispatchState_Change", "in param dispatchReserveFlag == TRUE")

           /*----------------------*/
           /*   Make Reservation   */
           /*----------------------*/
           if ( curDispatchReservedFlag == TRUE )
           {
              PPT_METHODTRACE_V1("PPTManager_i::cassette_dispatchState_Change", "aCassette->isDispatchReserved() == TRUE")
              rc = RC_ALREADY_DISPATCH_RESVED_CST;
              SET_MSG_RC(strCassette_dispatchState_Change_out, MSG_ALREADY_DISPATCH_RESVED_CST, RC_ALREADY_DISPATCH_RESVED_CST)
              return( rc );
           }

           try
           {
              aCassette->makeDispatchReserved();
           }
           CATCH_AND_RAISE_EXCEPTIONS(PosCassette::makeDispatchReserved)

        }
        else
        {
            PPT_METHODTRACE_V1("PPTManager_i::cassette_dispatchState_Change", "in param dispatchReserveFlag != TRUE")

           /*-------------------------*/
           /*   Make Un-Reservation   */
           /*-------------------------*/
//P3000071 if ( curDispatchReservedFlag == FALSE )
//P3000071 {
//P3000071    PPT_METHODTRACE_V1("PPTManager_i::cassette_dispatchState_Change", "curDispatchReservedFlag == FALSE")
//P3000071    rc = RC_NOT_DISPATCH_RESVED_CST;
//P3000071    SET_MSG_RC(strCassette_dispatchState_Change_out, MSG_NOT_DISPATCH_RESVED_CST, RC_NOT_DISPATCH_RESVED_CST)
//P3000071    return( rc );
//P3000071 }

           try
           {
              aCassette->makeNotDispatchReserved();
           }
           CATCH_AND_RAISE_EXCEPTIONS(PosCassette::makeNotDispatchReserved)

        }

        /*----------------------*/
        /*   Return to Caller   */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_dispatchState_Change");

        return( RC_OK );

    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_dispatchState_Change_out, cassette_dispatchState_Change, methodName)
}

