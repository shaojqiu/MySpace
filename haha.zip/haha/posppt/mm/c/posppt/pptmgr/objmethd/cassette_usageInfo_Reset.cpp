#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_usageInfo_Reset.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:37:04 [ 7/13/07 19:37:05 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_usageInfo_Reset.cpp
//

#include "pptmgr.hpp"
#include "timstamp.hpp"
#include "duration.hpp"

#include "pcas.hh"
#include "plot.hh"
#include "pperson.hh"
#include "pstmc.hh"
#include "pmc.hh"
#include "pbufrs.hh"
#include "pmaloc.hh"
//D5000016 #include "ppcgrp.hh"

// Class: PPTManager
//
// Service: cassette_usageInfo_Reset()
//
// Change history:
// Date     Defect#  Person         Comments
// -------- -------- -------------- -------------------------------------------
// 2003/05/19 D5000016 K.Kido         Useless class deletion.
//
// Description:
//
// Return:
//     Long
//
// Parameter:
//    objCassette_usageInfo_Reset_out&  strCassette_usageInfo_Reset_out
//    const pptObjCommonIn& strObjCommonIn
//    const objectIdentifier& cassetteID
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long PPTManager_i::cassette_usageInfo_Reset(objCassette_usageInfo_Reset_out&  strCassette_usageInfo_Reset_out, const pptObjCommonIn& strObjCommonIn,  const objectIdentifier& cassetteID)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_usageInfo_Reset");

        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR(aCassette, cassetteID, strCassette_usageInfo_Reset_out,
                                            cassette_usageInfo_Reset);

        try
        {
            aCassette->setTimesUsed( 0 );         //A0711
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setTimesUsed);

        try
        {
            aCassette->setDurationUsed( 0 );    //A0711
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setDurationUsed);

        try
        {
            aCassette->setLastMaintenanceTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setLastMaintenanceTimeStamp);

        PosPerson_var aPerson;
        PPT_GET_PERSON_FROM_USERID(aPerson, strObjCommonIn.strUser.userID, strCassette_usageInfo_Reset_out,cassette_usageInfo_Reset)

        try
        {
            aCassette->setLastMaintenancePerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setLastMaintenancePerson);

        try
        {
            aCassette->setLastClaimedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setLastClaimedTimeStamp);

        try
        {
            aCassette->setLastClaimedPerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setLastClaimedPerson);

        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_usageInfo_Reset");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_usageInfo_Reset_out, cassette_usageInfo_Reset, methodName)
}

