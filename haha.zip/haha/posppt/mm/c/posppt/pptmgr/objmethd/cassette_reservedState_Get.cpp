#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_reservedState_Get.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:35:51 [ 7/13/07 19:35:52 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_reservedState_Get.cpp
//

#include "pptmgr.hpp"
#include "timstamp.hpp"
#include "duration.hpp"

#include "pcas.hh"
#include "plot.hh"
#include "pperson.hh"
#include "pstmc.hh"
#include "pmc.hh"
#include "pbufrs.hh"
#include "pmaloc.hh"
//D5000016 #include "ppcgrp.hh"

// Class: PPTManager
//
// Service: cassette_reservedState_Get
//
// Change history:
// Date       Defect#    Person         Comments
// ---------- ---------- -------------- -------------------------------------------
// 2000-05-08 D2300014   F.Masada       Get personID.
// 2000/09/12 P3000139   T.Yamano       SET_MSG_RC(MSG_OK,RC_OK) Comment Out
// 2003/05/19 D5000016 K.Kido         Useless class deletion.
// 2007/04/20 D9000001  M.Murata       64bit support.
//
// Description:
//
// Return:
//     Long
//
// Parameter:
//  objCassette_reservedState_Get_out&   strCassette_reservedState_Get_out
//  const pptObjCommonIn&                strObjCommonIn
//  const objectIdentifier&              cassetteID
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long PPTManager_i::cassette_reservedState_Get(objCassette_reservedState_Get_out&
                                                                                                         strCassette_reservedState_Get_out       ,
                                                                                                 const pptObjCommonIn&    strObjCommonIn ,
                                                                                                 const objectIdentifier&  cassetteID     )
{
    char* methodName=NULL;
//D9000001    long rc;
    CORBA::Long rc;//D9000001
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_reservedState_Get")
        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR(aCassette, cassetteID, strCassette_reservedState_Get_out, cassette_reservedState_Get );

        try
        {
            strCassette_reservedState_Get_out.transferReserved = aCassette->isReserved();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isReserved)

// D2300014        PosPerson_var aPerson;
// D2300014        try
// D2300014        {
// D2300014            aPerson = aCassette->reservedBy();
// D2300014        }
// D2300014        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::reservedBy)
// D2300014        PPT_SET_OBJECT_IDENTIFIER(strCassette_reservedState_Get_out.reservedPerson,
// D2300014                                  aPerson,strCassette_reservedState_Get_out,
// D2300014                                  cassette_reservedState_Get,
// D2300014                                  PosPerson)
        try
        {
            strCassette_reservedState_Get_out.reservedPerson.identifier = aCassette->getReservePersonID();   // D2300014
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getReservePersonID)

        rc = RC_OK;
//P3000139        SET_MSG_RC(strCassette_reservedState_Get_out,MSG_OK, RC_OK)
        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_reservedState_Get")
        return rc;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_reservedState_Get_out, cassette_reservedState_Get, methodName)
}

