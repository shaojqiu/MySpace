//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cassette_emptyCassetteForRetrieving_Get.cpp
//

#include "pptmgr.hpp"
#include "parea.hh"
#include "pstmc.hh"
#include "pmc.hh"


// Class: PPTManager
//
// Service: cassette_emptyCassetteForRetrieving_Get()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/17 DSIV00000099 F.Chen        SLM(Small Lot Manufacturing) Support.
// 2015/11/10 DSN000096126 C.Mo          cassette_ListGetDR__100 ==> cassette_ListGetDR__160
// 2016/07/27 DSN000101569 C.Mo          cassette_ListGetDR__160 ==> cassette_ListGetDR__170
//
//[Function Description]:
// This function get available cassette list for lot retrieving
// Available cassette is selected by following priorities
//     1. select source cassette as destination cassette if SP_SLM_SRC_CAST_PRIORITY=ON
//     2. select loaded empty cassettes on the same equipment as the processing lot
//     3. select empty cassettes in equipment associated available auto stockers (SLMUTS is prior to normal auto stockers)
//     4. select empty cassettes in available auto stockers in the same workArea
//     5. select empty cassettes in available auto stockers in the same location
//
// cassette that is selected should not be reserved for lot processing, NPW or as destination cassette for other lots
//
//[Input Parameters]:
//
// typedef struct objCassette_emptyCassetteForRetrieving_Get_in_struct{
//     objectIdentifier  equipmentID;
//     objectIdentifier  lotID;
//     any               siInfo;
// }objCassette_emptyCassetteForRetrieving_Get_in;
//
//[Output Parameters]:
//
// typedef struct objCassette_emptyCassetteForRetrieving_Get_out_struct{
//     pptRetCode        strResult;
//     objectIdentifier  cassetteID;
//     any               siInfo;
// }objCassette_emptyCassetteForRetrieving_Get_out;
//
//[Return Value]:
//
//  Return Code                        Messsage ID
//  ---------------------------------- -----------------------------------------
//  RC_OK                              MSG_OK
//  RC_NOT_FOUND_EQPCTNPST             MSG_NOT_FOUND_EQPCTNPST

CORBA::Long PPTManager_i::cassette_emptyCassetteForRetrieving_Get(
    objCassette_emptyCassetteForRetrieving_Get_out&       strCassette_emptyCassetteForRetrieving_Get_out,
    const pptObjCommonIn&                                 strObjCommonIn,
    const objCassette_emptyCassetteForRetrieving_Get_in&  strCassette_emptyCassetteForRetrieving_Get_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_emptyCassetteForRetrieving_Get");

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        const objectIdentifier& equipmentID = strCassette_emptyCassetteForRetrieving_Get_in.equipmentID;
        const objectIdentifier& lotID       = strCassette_emptyCassetteForRetrieving_Get_in.lotID;
        PPT_METHODTRACE_V2("", "in Parameter equipmentID    ", equipmentID.identifier);
        PPT_METHODTRACE_V2("", "in Parameter lotID          ", lotID.identifier);


        CORBA::ULong pstLen = 0;
        CORBA::ULong stkLen = 0;
        CORBA::ULong foundCassetteLen = 0;

        CORBA::ULong nCnt1  = 0;
        CORBA::ULong nCnt2  = 0;
        CORBA::ULong nCnt3  = 0;

        objectIdentifier dummyID;
        dummyID.identifier = CIMFWStrDup("");
        stringSequence dummySeq;
        dummySeq.length(0);

        objCassette_CheckConditionForSLMDestCassette_out strCassette_CheckConditionForSLMDestCassette_out;
        objCassette_CheckConditionForSLMDestCassette_in strCassette_CheckConditionForSLMDestCassette_in;
        strCassette_CheckConditionForSLMDestCassette_in.equipmentID = equipmentID;
        strCassette_CheckConditionForSLMDestCassette_in.lotID       = lotID;

        // -----------------------------------------------------------------------------------
        // 1. select source cassette as destination cassette if SP_SLM_SRC_CAST_PRIORITY=ON
        // -----------------------------------------------------------------------------------
        PPT_METHODTRACE_V1("", "1. select source cassette as destination cassette if SP_SLM_SRC_CAST_PRIORITY=ON");

        // Get SP_SLM_SRC_CAST_PRIORITY
        CORBA::String_var srcCassettePriority = CIMFWStrDup(getenv(SP_SLM_SRC_CAST_PRIORITY));
        if(CIMFWStrCmp(srcCassettePriority, SP_SLM_Switch_ON) == 0)
        {
            //  Get equipmentContainer position objects by lotID
            objEquipmentContainerPosition_info_Get_in strEquipmentContainerPosition_info_Get_in;
            strEquipmentContainerPosition_info_Get_in.equipmentID = equipmentID;
            strEquipmentContainerPosition_info_Get_in.key         = lotID;
            strEquipmentContainerPosition_info_Get_in.keyCategory = CIMFWStrDup( SP_SLM_KeyCategory_Lot );

            objEquipmentContainerPosition_info_Get_out strEquipmentContainerPosition_info_Get_out;
            rc = equipmentContainerPosition_info_Get( strEquipmentContainerPosition_info_Get_out,
                                                      strObjCommonIn,
                                                      strEquipmentContainerPosition_info_Get_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "equipmentContainerPosition_info_Get() rc != RC_OK, rc = ", rc);
                strCassette_emptyCassetteForRetrieving_Get_out.strResult = strEquipmentContainerPosition_info_Get_out.strResult;
                return( rc );
            }
            pptEqpContainerPositionSequence strEqpContainerPositionSeq;
            strEqpContainerPositionSeq = strEquipmentContainerPosition_info_Get_out.strEqpContainerPositionInfo.strEqpContainerPositionSeq;

            // check source cassette
            if (strEqpContainerPositionSeq.length() ==0 || CIMFWStrLen(strEqpContainerPositionSeq[0].srcCassetteID.identifier) == 0)
            {
                PPT_METHODTRACE_V1("", "CIMFWStrLen(strEqpContainerPositionSeq[0].srcCassetteID.identifier) == 0)");
                PPT_SET_MSG_RC_KEY3 ( strCassette_emptyCassetteForRetrieving_Get_out,
                                     MSG_SLM_SRCAST_NOT_EXIST, RC_SLM_SRCAST_NOT_EXIST,
                                     strEqpContainerPositionSeq[0].controlJobID.identifier,
                                     lotID.identifier,
                                     dummyID.identifier);
                return( RC_SLM_SRCAST_NOT_EXIST );
            }

            PPT_METHODTRACE_V1(" ", "call cassette_CheckConditionForSLMDestCassette()");
            strCassette_CheckConditionForSLMDestCassette_in.cassetteID  = strEqpContainerPositionSeq[0].srcCassetteID;

            rc = cassette_CheckConditionForSLMDestCassette( strCassette_CheckConditionForSLMDestCassette_out,
                                                            strObjCommonIn,
                                                            strCassette_CheckConditionForSLMDestCassette_in );
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "cassette_CheckConditionForSLMDestCassette() rc != RC_OK, rc = ", rc);
            }
            else
            {
                PPT_METHODTRACE_V1("", "cassette_CheckConditionForSLMDestCassette() rc == RC_OK");
                strCassette_emptyCassetteForRetrieving_Get_out.cassetteID = strEqpContainerPositionSeq[0].srcCassetteID;

                // return to caller
                PPT_METHODTRACE_EXIT("PPTManager_i::cassette_emptyCassetteForRetrieving_Get");
                return RC_OK;
            }
        } // if SP_SLM_SRC_CAST_PRIORITY = ON


        // -----------------------------------------------------------------------------------
        // 2. select loaded empty cassettes on the same equipment as the processing lot
        // -----------------------------------------------------------------------------------
        PPT_METHODTRACE_V1("", "2. select loaded empty cassettes on the same equipment as the processing lot");

        //  Get equipment port information
        objEquipment_portInfo_GetDR_out strEquipment_portInfo_GetDR_out;
        rc = equipment_portInfo_GetDR(strEquipment_portInfo_GetDR_out, strObjCommonIn, equipmentID);

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "equipment_portInfo_GetDR() rc != RC_OK");
            strCassette_emptyCassetteForRetrieving_Get_out.strResult = strEquipment_portInfo_GetDR_out.strResult;
            return( rc );
        }

        CORBA::ULong nPortLen = strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
        PPT_METHODTRACE_V2("", "nPortLen", nPortLen);

        for( nCnt1 = 0; nCnt1 < nPortLen; nCnt1++ )
        {
            PPT_METHODTRACE_V3("", "# Loop[nCnt1], portID = ", nCnt1, strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[nCnt1].portID.identifier);
            if (CIMFWStrLen(strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[nCnt1].loadedCassetteID.identifier) >0)
            {
                PPT_METHODTRACE_V3("", "# Found a cassette at port, cassetteID | portID ",
                                        strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[nCnt1].loadedCassetteID.identifier,
                                        strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[nCnt1].portID.identifier);

                // check if the cassette is empty
                objCassette_CheckEmpty_out strCassette_CheckEmpty_out;
                rc = cassette_CheckEmpty( strCassette_CheckEmpty_out,
                                          strObjCommonIn,
                                          strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[nCnt1].loadedCassetteID);
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "# cassette_CheckEmpty() rc != RC_OK");
                    continue;
                }
                else
                {
                    PPT_METHODTRACE_V1(" ", "# call cassette_CheckConditionForSLMDestCassette()");
                    strCassette_CheckConditionForSLMDestCassette_in.cassetteID  = strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[nCnt1].loadedCassetteID;

                    rc = cassette_CheckConditionForSLMDestCassette( strCassette_CheckConditionForSLMDestCassette_out,
                                                                    strObjCommonIn,
                                                                    strCassette_CheckConditionForSLMDestCassette_in );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "# cassette_CheckConditionForSLMDestCassette() rc != RC_OK, rc = ", rc);
                        continue;
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "# cassette_CheckConditionForSLMDestCassette() rc == RC_OK");
                        strCassette_emptyCassetteForRetrieving_Get_out.cassetteID = strEquipment_portInfo_GetDR_out.strEqpPortInfo.strEqpPortStatus[nCnt1].loadedCassetteID;

                        // return to caller
                        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_emptyCassetteForRetrieving_Get");
                        return RC_OK;
                    }
                }
            } // if loadedCassetteID
        }

        // -----------------------------------------------------------------------------------
        // 3. select empty cassettes in equipment associated available auto stockers
        //    (SLMUTS is prior to normal auto stockers)
        // -----------------------------------------------------------------------------------
        PPT_METHODTRACE_V1("", "3. select empty cassettes in equipment associated available auto stockers");

        CORBA::ULong slmUTSLen = 0;
        CORBA::ULong autoStkLen = 0;

        pptEqpStockerStatusSequence strEqpStockerStatus;

        // get associated SLMUTS stockers
        PPT_METHODTRACE_V1("", "get associated SLMUTS stockers");
        objEquipment_SLMUTSInfo_GetDR_in strEquipment_SLMUTSInfo_GetDR_in;
        strEquipment_SLMUTSInfo_GetDR_in.equipmentID = equipmentID;

        objEquipment_SLMUTSInfo_GetDR_out strEquipment_SLMUTSInfo_GetDR_out;
        rc = equipment_SLMUTSInfo_GetDR( strEquipment_SLMUTSInfo_GetDR_out,
                                         strObjCommonIn,
                                         strEquipment_SLMUTSInfo_GetDR_in );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "equipment_SLMUTSInfo_GetDR() rc != RC_OK, rc = ", rc);
            strCassette_emptyCassetteForRetrieving_Get_out.strResult = strEquipment_SLMUTSInfo_GetDR_out.strResult;
            return( rc );
        }
        slmUTSLen = strEquipment_SLMUTSInfo_GetDR_out.equipmentSLMUTSInfo.strEqpStockerStatus.length();
        PPT_METHODTRACE_V2("", "slmUTSLen", slmUTSLen);

        // get associated auto stockers
        PPT_METHODTRACE_V1("", "get associated auto stockers");
        objEquipment_stockerInfo_GetDR_out strEquipment_stockerInfo_GetDR_out;
        rc = equipment_stockerInfo_GetDR(strEquipment_stockerInfo_GetDR_out,
                                         strObjCommonIn,
                                         equipmentID);
        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V2("", "equipment_stockerInfo_GetDR() != RC_OK", rc);
            strCassette_emptyCassetteForRetrieving_Get_out.strResult = strEquipment_stockerInfo_GetDR_out.strResult;
            return rc;
        }
        autoStkLen = strEquipment_stockerInfo_GetDR_out.equipmentStockerInfo.strEqpStockerStatus.length();
        PPT_METHODTRACE_V2("", "autoStkLen", autoStkLen);

        stkLen = slmUTSLen + autoStkLen;
        strEqpStockerStatus.length(stkLen);
        PPT_METHODTRACE_V2("", "stkLen", stkLen);

        for( nCnt1 = 0; nCnt1 < slmUTSLen; nCnt1++ )
        {
            PPT_METHODTRACE_V2("", "# Loop[nCnt1], nCnt1 = ", nCnt1);
            strEqpStockerStatus[nCnt1] = strEquipment_SLMUTSInfo_GetDR_out.equipmentSLMUTSInfo.strEqpStockerStatus[nCnt1];
        }
        nCnt2 = slmUTSLen;
        for( nCnt1 = 0; nCnt1 < autoStkLen; nCnt1++ )
        {
            PPT_METHODTRACE_V2("", "# Loop[nCnt1], nCnt1 = ", nCnt1);
            if (CIMFWStrCmp (strEquipment_stockerInfo_GetDR_out.equipmentStockerInfo.strEqpStockerStatus[nCnt1].stockerType, SP_Stocker_Type_Auto) == 0)
            {
                PPT_METHODTRACE_V1("", "# Auto Stoker");
                strEqpStockerStatus[nCnt2] = strEquipment_stockerInfo_GetDR_out.equipmentStockerInfo.strEqpStockerStatus[nCnt1];
                nCnt2++;
            }
        }
        strEqpStockerStatus.length(nCnt2);
        stkLen = strEqpStockerStatus.length();
        PPT_METHODTRACE_V2("", "stkLen", stkLen);

        if (stkLen > 0)
        {
            PPT_METHODTRACE_V2("", "stkLen > 0", stkLen);
            pptEqpStockerStatus aEquipmentStockerInfo;
            for( nCnt1 = 0; nCnt1 < stkLen; nCnt1++ )
            {
                aEquipmentStockerInfo = strEqpStockerStatus[nCnt1];
                PPT_METHODTRACE_V3("", "# Loop[nCnt1], stockerID = ", nCnt1, aEquipmentStockerInfo.stockerID.identifier);

                // check availability
                objEquipment_CheckAvail_out  strEquipment_CheckAvail_out;
                rc = equipment_CheckAvail(strEquipment_CheckAvail_out,
                                          strObjCommonIn,
                                          aEquipmentStockerInfo.stockerID);
                if( rc == RC_EQP_NOT_AVAILSTAT )
                {
                    PPT_METHODTRACE_V2("","# This stocker is not Available.", aEquipmentStockerInfo.stockerID.identifier);
                    continue;
                }
                else if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("","# equipment_CheckAvail() != RC_OK. rc", rc);
                    strCassette_emptyCassetteForRetrieving_Get_out.strResult = strEquipment_CheckAvail_out.strResult;
                    return rc;
                }

                //get cassette list in the stocker
//DSN000096126                PPT_METHODTRACE_V1(" ", "call cassette_ListGetDR__100()");
//DSN000096126                objCassette_ListGetDR_in__100 strCassette_ListGetDR_in;
                PPT_METHODTRACE_V1(" ", "call cassette_ListGetDR__170()"); //DSN000096126
//DSN000101569                objCassette_ListGetDR_in__160 strCassette_ListGetDR_in;    //DSN000096126
                objCassette_ListGetDR_in__170 strCassette_ListGetDR_in;                                                         //DSN000101569
                strCassette_ListGetDR_in.emptyFlag                  = TRUE;
                strCassette_ListGetDR_in.stockerID                  = aEquipmentStockerInfo.stockerID;
                strCassette_ListGetDR_in.cassetteID                 = dummyID;
                strCassette_ListGetDR_in.cassetteStatus             = CIMFWStrDup(CIMFW_Durable_Available);;
                strCassette_ListGetDR_in.maxRetrieveCount           = -1;
                strCassette_ListGetDR_in.sorterJobCreationCheckFlag = FALSE;
                strCassette_ListGetDR_in.bankID                     = dummyID; //DSN000096126
                strCassette_ListGetDR_in.durableSubStatus           = dummyID;                                                  //DSN000101569
                strCassette_ListGetDR_in.flowStatus                 = CIMFWStrDup("");                                          //DSN000101569

//DSN000096126                objCassette_ListGetDR_out__100 strCassette_ListGetDR_out;
//DSN000096126                rc = cassette_ListGetDR__100( strCassette_ListGetDR_out,
//DSN000096126                                              strObjCommonIn,
//DSN000096126                                              strCassette_ListGetDR_in );
//DSN000101569                objCassette_ListGetDR_out__160 strCassette_ListGetDR_out; //DSN000096126
                objCassette_ListGetDR_out__170 strCassette_ListGetDR_out;                                                       //DSN000101569
//DSN000101569                rc = cassette_ListGetDR__160(strCassette_ListGetDR_out, strObjCommonIn, strCassette_ListGetDR_in);
                rc = cassette_ListGetDR__170(strCassette_ListGetDR_out, strObjCommonIn, strCassette_ListGetDR_in);              //DSN000101569
                if( rc == RC_OK )
                {
//DSN000096126                    PPT_METHODTRACE_V1("", "cassette_ListGetDR__100() rc == RC_OK");
                    PPT_METHODTRACE_V1("", "cassette_ListGetDR__170() rc == RC_OK"); //DSN000096126
                    foundCassetteLen = strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette.length();

                    if (foundCassetteLen > 0)
                    {
                        PPT_METHODTRACE_V1(" ", "foundCassetteLen > 0");
                        for( nCnt2 = 0; nCnt2 < foundCassetteLen; nCnt2++ )
                        {
                            PPT_METHODTRACE_V3("", "## Loop[nCnt2], cassetteID = ", nCnt2, strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette[nCnt2].cassetteID.identifier);
                            PPT_METHODTRACE_V1(" ", "## call cassette_CheckConditionForSLMDestCassette()");
                            strCassette_CheckConditionForSLMDestCassette_in.cassetteID  = strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette[nCnt2].cassetteID;

                            rc = cassette_CheckConditionForSLMDestCassette( strCassette_CheckConditionForSLMDestCassette_out,
                                                                            strObjCommonIn,
                                                                            strCassette_CheckConditionForSLMDestCassette_in );
                            if( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "## cassette_CheckConditionForSLMDestCassette() rc != RC_OK, rc = ", rc);
                                continue;
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("", "## cassette_CheckConditionForSLMDestCassette() rc == RC_OK");
                                strCassette_emptyCassetteForRetrieving_Get_out.cassetteID = strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette[nCnt2].cassetteID;

                                // return to caller
                                PPT_METHODTRACE_EXIT("PPTManager_i::cassette_emptyCassetteForRetrieving_Get");
                                return RC_OK;
                            }
                        } // loop nCnt2
                    } // foundCassetteLen > 0
                } //cassette_ListGetDR__160 RC_OK
            } // loop nCnt1
        }

        // -----------------------------------------------------------------------------------
        // 4. select empty cassettes in available auto stockers in the same workArea
        // -----------------------------------------------------------------------------------
        PPT_METHODTRACE_V1("", "4. select empty cassettes in available auto stockers in the same workArea");

        objMachine_type_Get_out strMachine_type_Get_out;
        rc = machine_type_Get(strMachine_type_Get_out, strObjCommonIn, equipmentID);
        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V2("", "machine_type_Get() != RC_OK", rc);
            strCassette_emptyCassetteForRetrieving_Get_out.strResult = strMachine_type_Get_out.strResult;
            return rc;
        }

        objEquipment_FillInTxEQQ003DR_out strEquipment_FillInTxEQQ003DR_out;
        rc = equipment_FillInTxEQQ003DR(strEquipment_FillInTxEQQ003DR_out,
                                        strObjCommonIn,
                                        strMachine_type_Get_out.areaID,
                                        dummyID,
                                        "",
                                        dummySeq,
                                        "");
        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V2("", "equipment_FillInTxEQQ003DR() != RC_OK", rc);
            strCassette_emptyCassetteForRetrieving_Get_out.strResult = strEquipment_FillInTxEQQ003DR_out.strResult;
            return rc;
        }

        stkLen = strEquipment_FillInTxEQQ003DR_out.strAreaStocker.length();
        PPT_METHODTRACE_V2("", "stkLen", stkLen);
        for( nCnt1 = 0; nCnt1 < stkLen; nCnt1++ )
        {
            PPT_METHODTRACE_V3("", "# Loop[nCnt1], stockerID = ", nCnt1, strEquipment_FillInTxEQQ003DR_out.strAreaStocker[nCnt1].stockerID.identifier);
            if (CIMFWStrCmp (strEquipment_FillInTxEQQ003DR_out.strAreaStocker[nCnt1].stockerType, SP_Stocker_Type_Auto) == 0)
            {
                PPT_METHODTRACE_V1("", "Auto Stocker");
                // check availability
                objEquipment_CheckAvail_out  strEquipment_CheckAvail_out;
                rc = equipment_CheckAvail(strEquipment_CheckAvail_out,
                                          strObjCommonIn,
                                          strEquipment_FillInTxEQQ003DR_out.strAreaStocker[nCnt1].stockerID);
                if( rc == RC_EQP_NOT_AVAILSTAT )
                {
                    PPT_METHODTRACE_V2("","# This stocker is not Available.", strEquipment_FillInTxEQQ003DR_out.strAreaStocker[nCnt1].stockerID.identifier);
                    continue;
                }
                else if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("","# equipment_CheckAvail() != RC_OK. rc", rc);
                    strCassette_emptyCassetteForRetrieving_Get_out.strResult = strEquipment_CheckAvail_out.strResult;
                    return rc;
                }

                //get cassette list in the stocker
//DSN000096126                PPT_METHODTRACE_V1(" ", "call cassette_ListGetDR__100()");
//DSN000096126                objCassette_ListGetDR_in__100 strCassette_ListGetDR_in;
                PPT_METHODTRACE_V1(" ", "call cassette_ListGetDR__170()"); //DSN000096126
//DSN000101569                objCassette_ListGetDR_in__160 strCassette_ListGetDR_in;    //DSN000096126
                objCassette_ListGetDR_in__170 strCassette_ListGetDR_in;                                                         //DSN000101569
                strCassette_ListGetDR_in.emptyFlag                  = TRUE;
                strCassette_ListGetDR_in.stockerID                  = strEquipment_FillInTxEQQ003DR_out.strAreaStocker[nCnt1].stockerID;
                strCassette_ListGetDR_in.cassetteID                 = dummyID;
                strCassette_ListGetDR_in.cassetteStatus             = CIMFWStrDup(CIMFW_Durable_Available);;
                strCassette_ListGetDR_in.maxRetrieveCount           = -1;
                strCassette_ListGetDR_in.sorterJobCreationCheckFlag = FALSE;
                strCassette_ListGetDR_in.bankID                     = dummyID; //DSN000096126
                strCassette_ListGetDR_in.durableSubStatus           = dummyID;                                                  //DSN000101569
                strCassette_ListGetDR_in.flowStatus                 = CIMFWStrDup("");                                          //DSN000101569
//DSN000096126                objCassette_ListGetDR_out__100 strCassette_ListGetDR_out;
//DSN000096126                rc = cassette_ListGetDR__100( strCassette_ListGetDR_out,
//DSN000096126                                              strObjCommonIn,
//DSN000096126                                              strCassette_ListGetDR_in );
//DSN000101569                objCassette_ListGetDR_out__160 strCassette_ListGetDR_out; //DSN000096126
                objCassette_ListGetDR_out__170 strCassette_ListGetDR_out;                                                       //DSN000101569
//DSN000101569                rc = cassette_ListGetDR__160(strCassette_ListGetDR_out, strObjCommonIn, strCassette_ListGetDR_in);
                rc = cassette_ListGetDR__170(strCassette_ListGetDR_out, strObjCommonIn, strCassette_ListGetDR_in);              //DSN000101569
                if( rc == RC_OK )
                {
//DSN000096126                    PPT_METHODTRACE_V1("", "cassette_ListGetDR__100() rc == RC_OK");
                    PPT_METHODTRACE_V1("", "cassette_ListGetDR__170() rc == RC_OK"); //DSN000096126
                    foundCassetteLen = strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette.length();
                    PPT_METHODTRACE_V2("", "foundCassetteLen", foundCassetteLen);

                    if (foundCassetteLen > 0)
                    {
                        PPT_METHODTRACE_V1(" ", "foundCassetteLen > 0");
                        for( nCnt2 = 0; nCnt2 < foundCassetteLen; nCnt2++ )
                        {
                            PPT_METHODTRACE_V3("", "## Loop[nCnt2], cassetteID = ", nCnt2, strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette[nCnt2].cassetteID.identifier);
                            PPT_METHODTRACE_V1(" ", "## call cassette_CheckConditionForSLMDestCassette()");
                            strCassette_CheckConditionForSLMDestCassette_in.cassetteID  = strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette[nCnt2].cassetteID;

                            rc = cassette_CheckConditionForSLMDestCassette( strCassette_CheckConditionForSLMDestCassette_out,
                                                                            strObjCommonIn,
                                                                            strCassette_CheckConditionForSLMDestCassette_in );
                            if( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V2("", "## cassette_CheckConditionForSLMDestCassette() rc != RC_OK, rc = ", rc);
                                continue;
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("", "## cassette_CheckConditionForSLMDestCassette() rc == RC_OK");
                                strCassette_emptyCassetteForRetrieving_Get_out.cassetteID = strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette[nCnt2].cassetteID;

                                // return to caller
                                PPT_METHODTRACE_EXIT("PPTManager_i::cassette_emptyCassetteForRetrieving_Get");
                                return RC_OK;
                            }
                        } // loop nCnt2
                    } // foundCassetteLen > 0
                } //cassette_ListGetDR__160 RC_OK
            } // if Auto stocker
        } // loop nCnt1

        // -----------------------------------------------------------------------------------
        // 5. select empty cassettes in available auto stockers in the same location
        // -----------------------------------------------------------------------------------
        PPT_METHODTRACE_V1("", "5. select empty cassettes in available auto stockers in the same location");

        PosMachine_var aMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine,
                                         equipmentID,
                                         strCassette_emptyCassetteForRetrieving_Get_out,
                                         cassette_emptyCassetteForRetrieving_Get );
        PosMachine_var aPosMachine;
        aPosMachine = PosMachine::_narrow(aMachine);
        if(CORBA::is_nil(aPosMachine))
        {
            PPT_METHODTRACE_V1("", "TRUE == CORBA::is_nil(aPosMachine)");
            SET_MSG_RC(strCassette_emptyCassetteForRetrieving_Get_out, MSG_UNEXPECTED_NIL_OBJECT, RC_UNEXPECTED_NIL_OBJECT);
            return RC_UNEXPECTED_NIL_OBJECT;
        }
        PosArea_var aPosArea;
        try
        {
            aPosArea = aPosMachine -> getWorkArea();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getWorkArea);

        if(CORBA::is_nil(aPosArea))
        {
            PPT_METHODTRACE_V1("", "aPosArea is nil.");
            PPT_SET_MSG_RC_KEY(strCassette_emptyCassetteForRetrieving_Get_out,
                               MSG_NOT_FOUND_WORKAREA, RC_NOT_FOUND_WORKAREA,
                               "*****");
            return RC_NOT_FOUND_WORKAREA;
        }

        Area_var anArea;
        try
        {
            anArea = aPosArea -> getSuperArea();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosArea::getSuperArea);

        if(CORBA::is_nil(anArea))
        {
            PPT_METHODTRACE_V1("", "aPosArea is nil.");
            PPT_SET_MSG_RC_KEY(strCassette_emptyCassetteForRetrieving_Get_out,
                               MSG_NOT_FOUND_AREA, RC_NOT_FOUND_AREA,
                               "*****");
            return RC_NOT_FOUND_AREA;
        }

        PosArea_var aLocation;
        aLocation = PosArea::_narrow(anArea);

        objectIdentifier locationID;
        try
        {
            locationID.identifier = aLocation->getIdentifier();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosArea::getIdentifier);

        PPT_METHODTRACE_V2("", "location is", locationID.identifier);

        objArea_GetByLocationIDDR_out strArea_GetByLocationIDDR_out;
        rc = area_GetByLocationIDDR(strArea_GetByLocationIDDR_out, strObjCommonIn, locationID);
        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V2("", "area_GetByLocationIDDR() != RC_OK", rc);
            strCassette_emptyCassetteForRetrieving_Get_out.strResult = strArea_GetByLocationIDDR_out.strResult;
            return rc;
        }

        CORBA::Long wLen = strArea_GetByLocationIDDR_out.workAreaIDList.length();
        PPT_METHODTRACE_V2("", "wLen", wLen);
        for( nCnt1 = 0; nCnt1 < wLen; nCnt1++ )
        {
            objectIdentifier workAreaID = strArea_GetByLocationIDDR_out.workAreaIDList[nCnt1];
            PPT_METHODTRACE_V2("", "workAreaID", workAreaID.identifier);

            objEquipment_FillInTxEQQ003DR_out strEquipment_FillInTxEQQ003DR_out_Other;
            rc = equipment_FillInTxEQQ003DR(strEquipment_FillInTxEQQ003DR_out_Other,
                                            strObjCommonIn,
                                            workAreaID,
                                            dummyID,
                                            "",
                                            dummySeq,
                                            "");
            if(rc != RC_OK)
            {
                PPT_METHODTRACE_V1("", "equipment_FillInTxEQQ003DR() != RC_OK");
                strCassette_emptyCassetteForRetrieving_Get_out.strResult = strEquipment_FillInTxEQQ003DR_out_Other.strResult;
                return rc;
            }

            stkLen = strEquipment_FillInTxEQQ003DR_out.strAreaStocker.length();
            PPT_METHODTRACE_V2("", "stkLen", stkLen);
            if(stkLen == 0)
            {
                PPT_METHODTRACE_V2("", "Not found stocker in this workArea", workAreaID.identifier);
                continue;
            }

            if(CIMFWStrCmp(strMachine_type_Get_out.areaID.identifier, workAreaID.identifier) == 0)
            {
                PPT_METHODTRACE_V3("", "This is the current workArea. Skipped.",
                                   strMachine_type_Get_out.areaID.identifier,
                                   workAreaID.identifier);
                continue;
            }

            for( nCnt2 = 0; nCnt2 < stkLen; nCnt2++ )
            {
                PPT_METHODTRACE_V3("", "# Loop[nCnt2], stockerID = ", nCnt2, strEquipment_FillInTxEQQ003DR_out.strAreaStocker[nCnt2].stockerID.identifier);
                if (CIMFWStrCmp (strEquipment_FillInTxEQQ003DR_out.strAreaStocker[nCnt2].stockerType, SP_Stocker_Type_Auto) == 0)
                {
                    PPT_METHODTRACE_V1("", "Auto Stocker");
                    // check availability
                    objEquipment_CheckAvail_out  strEquipment_CheckAvail_out;
                    rc = equipment_CheckAvail(strEquipment_CheckAvail_out,
                                              strObjCommonIn,
                                              strEquipment_FillInTxEQQ003DR_out.strAreaStocker[nCnt2].stockerID);
                    if( rc == RC_EQP_NOT_AVAILSTAT )
                    {
                        PPT_METHODTRACE_V2("","# This stocker is not Available.", strEquipment_FillInTxEQQ003DR_out.strAreaStocker[nCnt2].stockerID.identifier);
                        continue;
                    }
                    else if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("","# equipment_CheckAvail() != RC_OK. rc", rc);
                        strCassette_emptyCassetteForRetrieving_Get_out.strResult = strEquipment_CheckAvail_out.strResult;
                        return rc;
                    }

                    //get cassette list in the stocker
//DSN000096126                    PPT_METHODTRACE_V1(" ", "call cassette_ListGetDR__100()");
//DSN000096126                    objCassette_ListGetDR_in__100 strCassette_ListGetDR_in;
                    PPT_METHODTRACE_V1(" ", "call cassette_ListGetDR__170()"); //DSN000096126
//DSN000101569                    objCassette_ListGetDR_in__160 strCassette_ListGetDR_in;    //DSN000096126
                    objCassette_ListGetDR_in__170 strCassette_ListGetDR_in;                                                     //DSN000101569
                    strCassette_ListGetDR_in.emptyFlag                  = TRUE;
                    strCassette_ListGetDR_in.stockerID                  = strEquipment_FillInTxEQQ003DR_out.strAreaStocker[nCnt2].stockerID;
                    strCassette_ListGetDR_in.cassetteID                 = dummyID;
                    strCassette_ListGetDR_in.cassetteStatus             = CIMFWStrDup(CIMFW_Durable_Available);;
                    strCassette_ListGetDR_in.maxRetrieveCount           = -1;
                    strCassette_ListGetDR_in.sorterJobCreationCheckFlag = FALSE;
                    strCassette_ListGetDR_in.bankID                     = dummyID; //DSN000096126
                    strCassette_ListGetDR_in.durableSubStatus           = dummyID;                                              //DSN000101569
                    strCassette_ListGetDR_in.flowStatus                 = CIMFWStrDup("");                                      //DSN000101569
//DSN000096126                    objCassette_ListGetDR_out__100 strCassette_ListGetDR_out;
//DSN000096126                    rc = cassette_ListGetDR__100( strCassette_ListGetDR_out,
//DSN000096126                                                  strObjCommonIn,
//DSN000096126                                                  strCassette_ListGetDR_in );
//DSN000101569                    objCassette_ListGetDR_out__160 strCassette_ListGetDR_out; //DSN000096126
                    objCassette_ListGetDR_out__170 strCassette_ListGetDR_out;                                                   //DSN000101569
//DSN000101569                    rc = cassette_ListGetDR__160(strCassette_ListGetDR_out, strObjCommonIn, strCassette_ListGetDR_in); //DSN000096126
                    rc = cassette_ListGetDR__170(strCassette_ListGetDR_out, strObjCommonIn, strCassette_ListGetDR_in);          //DSN000101569
                    if( rc == RC_OK )
                    {
//DSN000096126                        PPT_METHODTRACE_V1("", "cassette_ListGetDR__100() rc == RC_OK");
                        PPT_METHODTRACE_V1("", "cassette_ListGetDR__170() rc == RC_OK"); //DSN000096126
                        foundCassetteLen = strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette.length();

                        if (foundCassetteLen > 0)
                        {
                            PPT_METHODTRACE_V1(" ", "foundCassetteLen > 0");
                            for( nCnt3 = 0; nCnt3 < foundCassetteLen; nCnt3++ )
                            {
                                PPT_METHODTRACE_V3("", "### Loop[nCnt3], cassetteID = ", nCnt3, strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette[nCnt3].cassetteID.identifier);
                                PPT_METHODTRACE_V1(" ", "### call cassette_CheckConditionForSLMDestCassette()");
                                strCassette_CheckConditionForSLMDestCassette_in.cassetteID  = strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette[nCnt3].cassetteID;

                                rc = cassette_CheckConditionForSLMDestCassette( strCassette_CheckConditionForSLMDestCassette_out,
                                                                                strObjCommonIn,
                                                                                strCassette_CheckConditionForSLMDestCassette_in );
                                if( rc != RC_OK )
                                {
                                    PPT_METHODTRACE_V2("", "### cassette_CheckConditionForSLMDestCassette() rc != RC_OK, rc = ", rc);
                                    continue;
                                }
                                else
                                {
                                    PPT_METHODTRACE_V1("", "### cassette_CheckConditionForSLMDestCassette() rc == RC_OK");
                                    strCassette_emptyCassetteForRetrieving_Get_out.cassetteID = strCassette_ListGetDR_out.strCassetteListInqResult.strFoundCassette[nCnt3].cassetteID;

                                    // return to caller
                                    PPT_METHODTRACE_EXIT("PPTManager_i::cassette_emptyCassetteForRetrieving_Get");
                                    return RC_OK;
                                }
                            } // loop nCnt3
                        } // foundCassetteLen > 0
                    } //cassette_ListGetDR__160 RC_OK
                } // if Auto stocker
            } // loop nCnt2

        } // loop nCnt1

        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_emptyCassetteForRetrieving_Get");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_emptyCassetteForRetrieving_Get_out, cassette_emptyCassetteForRetrieving_Get, methodName)
}


