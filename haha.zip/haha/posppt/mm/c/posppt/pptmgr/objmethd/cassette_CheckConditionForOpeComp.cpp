#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_CheckConditionForOpeComp.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:31:48 [ 7/13/07 19:31:48 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_CheckConditionForOpeComp.cpp
//

#include "pptmgr.hpp"

#include "pcas.hh"


//[Object Function Name]: long   cassette_CheckConditionForOpeComp
//
// Date        Level  Author         Note
// ----------  -----  -------------  -------------------------------------------
// 2000/08/21  0.00   H.Ueda         Initial Release                 (R30)
//
//[Function Description]:
//  Check cassette's condition for OpeComp.
//
//  The following conditions are checked.
//
//  <<< transferState >>>
//  Cassette's transfer state must be EI.
//
//
//[Input Parameters]:
//  in  pptObjCommonIn             strObjCommonIn;
//  in  pptStartCassetteSequence   strStartCassette;
//
//[Output Parameters]:
//  out objCassette_CheckConditionForOpeComp_out   strCassette_CheckConditionForOpeComp_out;
//
//  typedef struct objCassette_CheckConditionForOpeComp_out_struct {
//      pptRetCode                      strResult;
//  } objCassette_CheckConditionForOpeComp_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//
//
//[Pseudo Code]:
//

CORBA::Long PPTManager_i::cassette_CheckConditionForOpeComp(
                    objCassette_CheckConditionForOpeComp_out& strCassette_CheckConditionForOpeComp_out,
                    const pptObjCommonIn& strObjCommonIn,
                    const pptStartCassetteSequence& strStartCassette )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_CheckConditionForOpeComp");

        /*----------------*/
        /*                */
        /*   Initialize   */
        /*                */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        /*--------------------------------------*/
        /*                                      */
        /*   Check Cassette's Transfer Status   */
        /*                                      */
        /*--------------------------------------*/
        CORBA::Long lenStarCassette = strStartCassette.length();
        CORBA::Long i;

        PPT_METHODTRACE_V2("", "Check Cassette's Transfer Status", lenStarCassette);

        for ( i=0 ; i < lenStarCassette; i++ )
        {
            /*-------------------------*/
            /*   Get Cassette Object   */
            /*-------------------------*/
            PPT_METHODTRACE_V1("", "Get Cassette Object");

            PosCassette_var aCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                                   strStartCassette[i].cassetteID,
                                                   strCassette_CheckConditionForOpeComp_out,
                                                   cassette_CheckConditionForOpeComp );

            /*-----------------------*/
            /*   Get TransferState   */
            /*-----------------------*/
            PPT_METHODTRACE_V1("", "Get TransferState");

            CORBA::String_var transferState;
            try
            {
                transferState = aCassette->getTransportState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTransportState)

            if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn) )
            {
                PPT_METHODTRACE_V1("", "transferState == SP_TransState_EquipmentIn");
                rc = RC_OK;
            }
            else
            {
                PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForOpeComp_out,
                                     MSG_INVALID_CAST_XFERSTAT,
                                     RC_INVALID_CAST_XFERSTAT,
                                     transferState,
                                     strStartCassette[i].cassetteID.identifier );

                return RC_INVALID_CAST_XFERSTAT;
            }
        }

        /*----------------------*/
        /*                      */
        /*   Return to Caller   */
        /*                      */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_CheckConditionForOpeComp");

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_CheckConditionForOpeComp_out, cassette_CheckConditionForOpeComp, methodName)
}
