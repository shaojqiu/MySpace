#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_UTSInfo_Get.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:33:30 [ 7/13/07 19:33:31 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_UTSInfo_Get.cpp
//
#include "pptmgr.hpp"

#include "pstmc.hh"

// Class: PPTManager
//
// Service: cassette_UTSInfo_Get()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2006/09/26 D8000028 F.Chen         Initial Release (R80)
//
//[Function Description]:
//  The object method will get the UTS ID what the carrier is in.
//
//[Input Parameters]:
//     in const pptObjCommonIn& strObjCommonIn
//     in const objectIdentifier& cassetteID
//
//[Output Parameters]:
//         out objCassette_UTSInfo_Get_out& strCassette_UTSInfo_Get_out
//         typedef struct objCassette_UTSInfo_Get_out_struct {
//         pptRetCode                         strResult;
//         objectIdentifier                   stockerID;
//         any siInfo;
//         } objCassette_UTSInfo_Get_out;
//
//
//[Return Value]:
//
//  Return Code               Message ID                    Note
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK                        // the carrier is in a UTS and the UTSID is set to return structure
//  RC_INVALID_DATA_CONTENTS  MSG_INVALID_DATA_CONTENTS     // cassetteID is not filled in parameter
//  RC_CARRIER_NOT_IN_UTS     MSG_CARRIER_NOT_IN_UTS        // the inpara cassetteID is not in any UTS
//
//
CORBA::Long PPTManager_i::cassette_UTSInfo_Get ( objCassette_UTSInfo_Get_out& strCassette_UTSInfo_Get_out,
                                                 const pptObjCommonIn&        strObjCommonIn,
                                                 const objectIdentifier&      cassetteID )
{
    char * methodName = NULL;
    CORBA::Long rc = RC_OK;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i:: cassette_UTSInfo_Get ") ;
        PPT_METHODTRACE_V2("", "in para cassetteID ", cassetteID.identifier );
        
        if (CIMFWStrLen(cassetteID.identifier) == 0)
        {
            PPT_METHODTRACE_V1("", "cassetteID is not filled in parm") ;
            SET_MSG_RC(strCassette_UTSInfo_Get_out, MSG_INVALID_DATA_CONTENTS, RC_INVALID_DATA_CONTENTS) ;
            return RC_INVALID_DATA_CONTENTS;
        }
        else
        {
            PPT_METHODTRACE_V2("","in param cassetteID ", cassetteID.identifier) ;
        }
        
        /*---------------------------------------------*/
        /*  Get carrier location information           */
        /*---------------------------------------------*/
        objCassette_LocationInfo_GetDR_out strCassette_LocationInfo_GetDR_out;
        rc = cassette_LocationInfo_GetDR( strCassette_LocationInfo_GetDR_out,
                                          strObjCommonIn,
                                          cassetteID );
        if(rc != RC_OK)
        {
            PPT_METHODTRACE_V1("", "cassette_LocationInfo_GetDR() != RC_OK") ;
            strCassette_UTSInfo_Get_out.strResult = strCassette_LocationInfo_GetDR_out.strResult ;
            return ( rc );
        }

        /*---------------------------------------------*/
        /*  Verify if the carrier is in a UTS          */
        /*---------------------------------------------*/
        objectIdentifier stockerID;
        stockerID = strCassette_LocationInfo_GetDR_out.cassetteLocationInfo.stockerID ;
        
        if( CIMFWStrLen( stockerID.identifier ) != 0 )
        {
            PPT_METHODTRACE_V1("", "CIMFWStrLen(stockerID.identifier) != 0");
            
            PosStorageMachine_var aStorageMachine ;
            PPT_CONVERT_STOCKERID_TO_STORAGEMACHINE_OR(aStorageMachine, stockerID, strCassette_UTSInfo_Get_out, cassette_UTSInfo_Get);
            
            CORBA::Boolean aBool = FALSE;
            try
            {
                PPT_DISPLAY_RESPONSE_TIME();
                aBool = aStorageMachine->isUTSStocker() ;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosStorageMachine::isUTSStocker)

            if( aBool == FALSE )
            {
                PPT_METHODTRACE_V2("", "aBool == FALSE ", stockerID.identifier) ;
                SET_MSG_RC(strCassette_UTSInfo_Get_out, MSG_CARRIER_NOT_IN_UTS, RC_CARRIER_NOT_IN_UTS);
                return RC_CARRIER_NOT_IN_UTS;
            }
        }
        // stockerID is empty, the cassette is not in any stockers
        else
        {
            PPT_METHODTRACE_V1("", "CIMFWStrLen(stockerID.identifier) == 0");
            SET_MSG_RC(strCassette_UTSInfo_Get_out, MSG_CARRIER_NOT_IN_UTS, RC_CARRIER_NOT_IN_UTS);
            return RC_CARRIER_NOT_IN_UTS;
        }
        
        /*---------------------------------------------*/
        /*  Set return structure                       */
        /*---------------------------------------------*/
        strCassette_UTSInfo_Get_out.stockerID = stockerID;

        /*------------------------------------------------------------------------*/
        /*   Return                                                               */
        /*------------------------------------------------------------------------*/
        SET_MSG_RC(strCassette_UTSInfo_Get_out, MSG_OK, RC_OK) ;
        PPT_METHODTRACE_EXIT("PPTManager_i:: cassette_UTSInfo_Get ") ;
        return rc;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_UTSInfo_Get_out, cassette_UTSInfo_Get, methodName);
        
}
