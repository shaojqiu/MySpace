//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: advanced_object_LockForEquipmentResource.cpp
//

#include "pptmgr.hpp"
#include "pmc.hh"
#include "pstmc.hh"
#include "pcas.hh"
#include "plot.hh"
#include "pportrs.hh"
#include "ppcrs.hh"
#include "pmaloc.hh"
#include "pbufrs.hh"
#include "pmcctn.hh"
#include "pctnpst.hh"

// Class: PPTManager
//
// Service: advanced_object_LockForEquipmentResource()
//
// Change history:
// Date        Level        Author         Note
// ----------  ------------ -------------  -------------------------------------------
// 2012/11/29  DSN000049350 F.Chen         Initial release.
// 2016/11/07  PSN000103621 Q.Li           Add SP_ClassName_PosMaterialLocation_EmptyML
//
// Description:
//    Make Write or Read Locking for equipment related object.
//
//    This function can lock for the following objects.
//
//    - PosMaterialLocation
//
// Return:
//    Long
//
//    Return Code               Messsage ID
//    ------------------------- --------------------------------------------------
//    RC_OK                     MSG_OK
//    RC_INVALID_INPUT_PARM     MSG_INVALID_INPUT_PARM
//    RC_NOT_FOUND_EQP          MSG_NOT_FOUND_EQP
//    RC_CANNOT_LOCK_OBJECT     MSG_CANNOT_LOCK_OBJECT
//    RC_LOCKED_BY_ANOTHER      MSG_OBJECT_LOCKED_BY_ANOTHER
//    other return code may be from other function called from this function.
//
// Parameter:
//
//    objAdvanced_object_LockForEquipmentResource_out&       strAdvanced_object_LockForEquipmentResource_out
//    const pptObjCommonIn&                                  strObjCommonIn
//    const objAdvanced_object_LockForEquipmentResource_in&  strAdvanced_object_LockForEquipmentResource_in
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long PPTManager_i::advanced_object_LockForEquipmentResource (
    objAdvanced_object_LockForEquipmentResource_out&       strAdvanced_object_LockForEquipmentResource_out,
    const pptObjCommonIn&                                  strObjCommonIn,
    const objAdvanced_object_LockForEquipmentResource_in&  strAdvanced_object_LockForEquipmentResource_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::advanced_object_LockForEquipmentResource");

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;
        MOFW_TransactionalObject::lock_mode lockMode = MOFW_TransactionalObject::im_write;

        //---------------------------------
        // Input Parameter
        //---------------------------------
        const objectIdentifier& equipmentID      = strAdvanced_object_LockForEquipmentResource_in.equipmentID;
        const char *className                    = strAdvanced_object_LockForEquipmentResource_in.className;
        const objectIdentifier& objectID         = strAdvanced_object_LockForEquipmentResource_in.objectID;
        const CORBA::Long objectLockType         = strAdvanced_object_LockForEquipmentResource_in.objectLockType;
        const char *bufferResourceName           = strAdvanced_object_LockForEquipmentResource_in.bufferResourceName;
        const CORBA::Long bufferResourceLockType = strAdvanced_object_LockForEquipmentResource_in.bufferResourceLockType;

        PPT_METHODTRACE_V2("", "in-para equipmentID             ", equipmentID.identifier);
        PPT_METHODTRACE_V2("", "in-para className               ", className);
        PPT_METHODTRACE_V2("", "in-para objectID                ", objectID.identifier);
        PPT_METHODTRACE_V2("", "in-para objectLockType          ", objectLockType);
        PPT_METHODTRACE_V2("", "in-para bufferResourceName      ", bufferResourceName);
        PPT_METHODTRACE_V2("", "in-para bufferResourceLockType  ", bufferResourceLockType);

        /*---------------------------*/
        /*   Check input parameter   */
        /*---------------------------*/
        if ( CIMFWStrLen(equipmentID.identifier) == 0 && CIMFWStrLen(equipmentID.stringifiedObjectReference) == 0 )
        {
            PPT_METHODTRACE_V1("","objectID.Identifier and stringifiedObjectReference is NULL.");
            SET_MSG_RC( strAdvanced_object_LockForEquipmentResource_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM )
            return( RC_OK );
        }

        if ( 0 != CIMFWStrCmp( className, SP_ClassName_PosMaterialLocation )
          && 0 == CIMFWStrLen( objectID.identifier )
          && 0 == CIMFWStrLen( objectID.stringifiedObjectReference ) )
        {
            PPT_METHODTRACE_V2("","objectID is NULL for class", className);
            SET_MSG_RC( strAdvanced_object_LockForEquipmentResource_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM )
            return( RC_OK );
        }

        if ( ( objectLockType != SP_ObjectLock_LockType_WRITE && objectLockType != SP_ObjectLock_LockType_READ )
          || ( bufferResourceLockType != SP_ObjectLock_LockType_WRITE && bufferResourceLockType != SP_ObjectLock_LockType_READ ) )
        {
            PPT_METHODTRACE_V1("", "Invalid input parameter.");
            SET_MSG_RC( strAdvanced_object_LockForEquipmentResource_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        /*-------------------------*/
        /*   Get and Lock Object   */
        /*-------------------------*/

        // Convert lockType into lockMode of the lock method argument
        MOFW_TransactionalObject::lock_mode objectLockMode = (objectLockType == SP_ObjectLock_LockType_READ) ? MOFW_TransactionalObject::im_read : MOFW_TransactionalObject::im_write;
        MOFW_TransactionalObject::lock_mode bufferResourceLockMode = (bufferResourceLockType == SP_ObjectLock_LockType_READ) ? MOFW_TransactionalObject::im_read : MOFW_TransactionalObject::im_write;

        PPT_METHODTRACE_V2("","objectLockMode           ", objectLockMode);
        PPT_METHODTRACE_V2("","bufferResourceLockMode   ", bufferResourceLockMode);

        /*--------------------------*/
        /*   Get Equipment Object   */
        /*--------------------------*/
        PosMachine_var anEquipment;
        PPT_METHODTRACE_V2("","className", className);
        PPT_CONVERT_EQPID_TO_MACHINE_OR( anEquipment, equipmentID, strAdvanced_object_LockForEquipmentResource_out, object_LockForMachineResource )


        /*----------------------------*/
        /*   For PosMaterialLocation  */
        /*----------------------------*/
        if ( 0 == CIMFWStrCmp( className, SP_ClassName_PosMaterialLocation )
           || 0 == CIMFWStrCmp( className, SP_ClassName_PosMaterialLocation_ByCJ )
           || 0 == CIMFWStrCmp( className, SP_ClassName_PosMaterialLocation_EmptyML )  //PSN000103621
           || 0 == CIMFWStrCmp( className, SP_ClassName_PosMaterialLocation_ByCastID ) )
        {
            PPT_METHODTRACE_V2("","LoadPurposeType    ", bufferResourceName);
            PPT_METHODTRACE_V2("","objectID           ", objectID.identifier);

            /*------------------------------*/
            /*   Get BufferResourceObject   */
            /*------------------------------*/
            BufferResourceSequence_var aBufferResourceSeqVar;

            // Not specify Buffer Resource Name
            if ( 0 == CIMFWStrLen(bufferResourceName) )
            {
                PPT_METHODTRACE_V1("","bufferResourceName is empty");
                // Get all Buffer Resources
                try
                {
                    aBufferResourceSeqVar = anEquipment->allBufferResources();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosMachine::allBufferResources)
                
            }
            // Specify Buffer Resource Name
            else
            {
                PPT_METHODTRACE_V2("","bufferResourceName", bufferResourceName);
                aBufferResourceSeqVar = new BufferResourceSequence(0);
                aBufferResourceSeqVar->length(0);

                // Find specified Buffer Resource
                BufferResource_var aBufferResource;
                try
                {
                    aBufferResource = anEquipment->findBufferResourceNamed(bufferResourceName);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosMachine::findBufferResourceNamed)

                if( !CORBA::is_nil(aBufferResource) )
                {
                    PPT_METHODTRACE_V1("","!CORBA::is_nil(aBufferResource)");
                    aBufferResourceSeqVar->length(1);
                    aBufferResourceSeqVar[0] = aBufferResource;
                }
            }

            // Lock completion flag
            CORBA::Boolean bLockCompletion = FALSE;

            CORBA::ULong lenBufferResource = aBufferResourceSeqVar->length();
            PPT_METHODTRACE_V2("","lenBufferResource", lenBufferResource);
            for ( CORBA::ULong i = 0 ; i < lenBufferResource ; i++ )
            {
                PPT_METHODTRACE_V2("","counter[i]", i);
                // lock was completed
                if ( TRUE == bLockCompletion )
                {
                    PPT_METHODTRACE_V1("","TRUE == bLockCompletion");
                    break;
                }

                PosBufferResource_var posBufferResource = PosBufferResource::_narrow(aBufferResourceSeqVar[i]);

                if ( CORBA::is_nil(posBufferResource) )
                {
                    PPT_METHODTRACE_V1("","posBufferResource is nil. return RC_NOT_FOUND_BUFFER_RESOURCE");
                    SET_MSG_RC( strAdvanced_object_LockForEquipmentResource_out,
                                MSG_NOT_FOUND_BUFFER_RESOURCE,
                                RC_NOT_FOUND_BUFFER_RESOURCE );
                    return( RC_NOT_FOUND_BUFFER_RESOURCE );
                }

                // Lock completion flag of BufferResource
                CORBA::Boolean bLockBuffRes = FALSE;

                if ( 0 < CIMFWStrLen( bufferResourceName )
                  || 0 == CIMFWStrCmp( className, SP_ClassName_PosMaterialLocation ) )
                {
                    PPT_METHODTRACE_V2("","bufferResourceName", bufferResourceName);
                    PPT_METHODTRACE_V2("","className", className);
                    
                    /*----------------------------------*/
                    /*   Lock Buffer Resoucre Object    */
                    /*----------------------------------*/
                    try
                    {
                        PPT_METHODTRACE_V1("","Advanced_Lock_PosBufferResource: Lock Start...");
                        CORBA::Long retLock = posBufferResource->TxnLock(bufferResourceLockMode, theLockTimeout);
                        if ( retLock != MOFW_TransactionalObject::OK && retLock != MOFW_TransactionalObject::LockAlreadyHeld )
                        {
                            PPT_METHODTRACE_V2("","Advanced_Lock_PosBufferResource: TxnLock Failed", retLock);
                            SET_MSG_RC( strAdvanced_object_LockForEquipmentResource_out, MSG_CANNOT_LOCK_OBJECT, RC_CANNOT_LOCK_OBJECT );
                            return( RC_CANNOT_LOCK_OBJECT );
                        }
                    }
                    catch( MFGBOS_UnableToObtainTxnLock )
                    {
                        PPT_METHODTRACE_V1("","Advanced_Lock_PosBufferResource: Catch MFGBOS_UnableToObtainTxnLock Exception");
                        char buf[1024];
                        memset( buf, '\0', sizeof(buf)) ;
                        snprintf(buf, sizeof(buf), "%s's Buffer Resource", (const char*)equipmentID.identifier);
                        PPT_SET_MSG_RC_KEY( strAdvanced_object_LockForEquipmentResource_out,
                                            MSG_OBJECT_LOCKED_BY_ANOTHER,
                                            RC_LOCKED_BY_ANOTHER, buf);
                        return( RC_LOCKED_BY_ANOTHER );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosBufferResource::TxnLock)
                    PPT_METHODTRACE_V1("","Advanced_Lock_PosBufferResource: Lock Completed...");

                    // Lock completion of BufferResource
                    bLockBuffRes = TRUE;
                }

                /*---------------------------------*/
                /*   Get MaterialLocation Objects  */
                /*---------------------------------*/
                MaterialLocationSequence_var aMaterialLocationSeq;
                try
                {
                    aMaterialLocationSeq = posBufferResource->allMaterialLocations();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosBufferResource::allMaterialLocations)

                CORBA::ULong lenMaterialLocation = aMaterialLocationSeq->length();
                PPT_METHODTRACE_V2("","lenMaterialLocation", lenMaterialLocation);

                for ( CORBA::ULong j = 0 ; j < lenMaterialLocation ; j++ )
                {
                    PPT_METHODTRACE_V2("","counter[j]", j);
                    PosMaterialLocation_var aMaterialLocation = PosMaterialLocation::_narrow((*aMaterialLocationSeq)[j]);
                    if ( CORBA::is_nil(aMaterialLocation) )
                    {
                        PPT_METHODTRACE_V1("","CORBA::is_nil(aMaterialLocation)");
                        SET_MSG_RC( strAdvanced_object_LockForEquipmentResource_out,
                                    MSG_NOT_FOUND_MATERIAL_LOCATION,
                                    RC_NOT_FOUND_MATERIAL_LOCATION );
                        return( RC_NOT_FOUND_MATERIAL_LOCATION );
                    }

                    CORBA::String_var objectKey = CIMFWStrDup("");

                    // By CJ
                    if ( 0 == CIMFWStrCmp( className, SP_ClassName_PosMaterialLocation_ByCJ ) )
                    {
                        PPT_METHODTRACE_V2("","className", className);
                        CORBA::String_var materialControlJobIdent;
                        PosControlJob_var aMaterialLocationControlJob;
                        try
                        {
                            aMaterialLocationControlJob = aMaterialLocation->getControlJob();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(MaterialLocation::getControlJob)

                        if ( CORBA::is_nil(aMaterialLocationControlJob) )
                        {
                            PPT_METHODTRACE_V1("","aMaterialLocationControlJob is nil");
                            // Check next
                            continue;
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("","aMaterialLocationControlJob is not nil");
                        }

                        try
                        {
                            objectKey = aMaterialLocationControlJob->getIdentifier();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosControlJob::getIdentifier);
                    }
                    // By CassetteID
                    else if ( 0 == CIMFWStrCmp( className, SP_ClassName_PosMaterialLocation_ByCastID ) )
                    {
                        PPT_METHODTRACE_V2("","className", className);
                        Material_var aMaterial;

                        // Get Allocated Cassette
                        try
                        {
                            aMaterial = aMaterialLocation->getAllocatedMaterial();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosMaterialLocation::getAllocatedMaterial)

                        // There is no Allocated Cassette
                        if ( CORBA::is_nil(aMaterial) )
                        {
                            PPT_METHODTRACE_V1("","aMaterial is nil");
                            // Get Contained Cassette
                            try
                            {
                                aMaterial = aMaterialLocation->getMaterial();
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosMaterialLocation::getMaterial)

                            // There is no Contained Cassette
                            if ( CORBA::is_nil(aMaterial) )
                            {
                                PPT_METHODTRACE_V1("","aMaterial is nil");
                                // Check next
                                continue;
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("","aMaterial is not nil");
                            }
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("","aMaterial is not nil");
                        }

                        PosCassette_var aCassette = PosCassette::_narrow(aMaterial);
                        if ( CORBA::is_nil(aCassette) )
                        {
                            PPT_METHODTRACE_V1("","aCassette is nil");
                            // Check next
                            continue;
                        }

                        try
                        {
                            objectKey = aCassette->getIdentifier();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getIdentifier);
                    }
//PSN000103621 Add Start
                    // Empty MaterialLocation
                    else if ( 0 == CIMFWStrCmp( className, SP_ClassName_PosMaterialLocation_EmptyML ) )
                    {
                        PPT_METHODTRACE_V2("","className", className);
                        Material_var aMaterial;

                        // Get Allocated Cassette
                        try
                        {
                            aMaterial = aMaterialLocation->getAllocatedMaterial();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosMaterialLocation::getAllocatedMaterial)

                        // There is no Allocated Cassette
                        if ( CORBA::is_nil(aMaterial) )
                        {
                            PPT_METHODTRACE_V1("","aMaterial is nil");
                            // Get Contained Cassette
                            try
                            {
                                aMaterial = aMaterialLocation->getMaterial();
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosMaterialLocation::getMaterial)

                            // There is no Contained Cassette
                            if ( CORBA::is_nil(aMaterial) )
                            {
                                PPT_METHODTRACE_V1("","aMaterial is nil");
                                objectKey = objectID.identifier;
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("","aMaterial is not nil");
                                // Check next
                                continue;
                            }
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("","aMaterial is not nil");
                            // Check next
                            continue;
                        }
                    }
//PSN000103621 Add End
                    else
                    {
                        PPT_METHODTRACE_V2("","className", className);
                    }

                    if ( 0 == CIMFWStrCmp( className, SP_ClassName_PosMaterialLocation )
                      || 0 == CIMFWStrCmp( objectID.identifier, objectKey ) )
                    {
                        PPT_METHODTRACE_V2("","objectID.identifier", objectID.identifier);
                        PPT_METHODTRACE_V2("","objectKey", objectKey);
                        
                        // If is not lock completion of BufferResource
                        if ( FALSE == bLockBuffRes )
                        {
                            PPT_METHODTRACE_V1("","FALSE == bLockBuffRes");
                            /*----------------------------------*/
                            /*   Lock Buffer Resoucre Object    */
                            /*----------------------------------*/
                            try
                            {
                                PPT_METHODTRACE_V1("","Advanced_Lock_PosBufferResource: Lock Start...");
                                CORBA::Long retLock = posBufferResource->TxnLock(bufferResourceLockMode, theLockTimeout);
                                if ( retLock != MOFW_TransactionalObject::OK && retLock != MOFW_TransactionalObject::LockAlreadyHeld )
                                {
                                    PPT_METHODTRACE_V2("","Advanced_Lock_PosBufferResource: TxnLock Failed", retLock);
                                    SET_MSG_RC( strAdvanced_object_LockForEquipmentResource_out, MSG_CANNOT_LOCK_OBJECT, RC_CANNOT_LOCK_OBJECT );
                                    return( RC_CANNOT_LOCK_OBJECT );
                                }
                            }
                            catch( MFGBOS_UnableToObtainTxnLock )
                            {
                                PPT_METHODTRACE_V1("","Advanced_Lock_PosBufferResource: Catch MFGBOS_UnableToObtainTxnLock Exception");
                                char buf[1024];
                                memset( buf, '\0', sizeof(buf)) ;
                                snprintf(buf, sizeof(buf), "%s's Buffer Resource", (const char*)equipmentID.identifier);
                                PPT_SET_MSG_RC_KEY( strAdvanced_object_LockForEquipmentResource_out,
                                                    MSG_OBJECT_LOCKED_BY_ANOTHER,
                                                    RC_LOCKED_BY_ANOTHER, buf);
                                return( RC_LOCKED_BY_ANOTHER );
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(PosBufferResource::TxnLock)
                            PPT_METHODTRACE_V1("","Advanced_Lock_PosBufferResource: Lock Completed...");

                            // Lock completion of BufferResource
                            bLockBuffRes = TRUE;
                        }

                        /*----------------------------------*/
                        /*   Lock Material Location Object  */
                        /*----------------------------------*/
                        try
                        {
                            PPT_METHODTRACE_V1("","Advanced_Lock_PosMaterialLocation: Lock Start...");
                            CORBA::Long retLock = aMaterialLocation->TxnLock(objectLockMode, theLockTimeout);
                            if ( retLock != MOFW_TransactionalObject::OK && retLock != MOFW_TransactionalObject::LockAlreadyHeld )
                            {
                                PPT_METHODTRACE_V2("","Advanced_Lock_PosMaterialLocation: TxnLock Failed", retLock);
                                SET_MSG_RC( strAdvanced_object_LockForEquipmentResource_out, MSG_CANNOT_LOCK_OBJECT, RC_CANNOT_LOCK_OBJECT );
                                return( RC_CANNOT_LOCK_OBJECT );
                            }
                        }
                        catch( MFGBOS_UnableToObtainTxnLock )
                        {
                            PPT_METHODTRACE_V1("","Advanced_Lock_PosMaterialLocation: Catch MFGBOS_UnableToObtainTxnLock Exception");
                            char buf[1024];
                            memset( buf, '\0', sizeof(buf)) ;
                            snprintf(buf, sizeof(buf), "%s's Material Location", (const char*)equipmentID.identifier);
                            PPT_SET_MSG_RC_KEY( strAdvanced_object_LockForEquipmentResource_out,
                                                MSG_OBJECT_LOCKED_BY_ANOTHER,
                                                RC_LOCKED_BY_ANOTHER, buf);
                            return( RC_LOCKED_BY_ANOTHER );
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosMaterialLocation::TxnLock)
                        PPT_METHODTRACE_V1("","Advanced_Lock_PosMaterialLocation: Lock Completed...");

                        // By CassetteID
                        if ( 0 == CIMFWStrCmp( className, SP_ClassName_PosMaterialLocation_ByCastID ) )
                        {
                            PPT_METHODTRACE_V1("","className = SP_ClassName_PosMaterialLocation_ByCastID");
                            // lock was completed
                            bLockCompletion = TRUE;
                            break;
                        }
                    }
                } // j loop end of lenMaterialLocation
            } // i loop end of lenBufferResource
        }

        /*----------------------*/
        /*   Return to Caller   */
        /*----------------------*/
        SET_MSG_RC( strAdvanced_object_LockForEquipmentResource_out, MSG_OK, RC_OK );
        PPT_METHODTRACE_EXIT("PPTManager::advanced_object_LockForEquipmentResource");

        return( RC_OK );

    }
    CATCH_GLOBAL_EXCEPTIONS(strAdvanced_object_LockForEquipmentResource_out, advanced_object_LockForEquipmentResource, methodName)
}
