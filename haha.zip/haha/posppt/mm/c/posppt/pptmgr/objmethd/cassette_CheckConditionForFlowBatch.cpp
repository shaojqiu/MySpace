#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_CheckConditionForFlowBatch.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:31:32 [ 7/13/07 19:31:33 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
// SiView
// Name: cassette_CheckConditionForFlowBatch.cpp
//

#include "pptmgr.hpp"

#include "pcas.hh"

//[Object Function Name]: long   cassette_CheckConditionForFlowBatch
//
// Date        Level       Author         Note
// ----------  ----------- -------------  -------------------------------------------
// 2000/07/03  0.00        O.Ohishi       Initial Release
// 2000/10/02  0.01        M.Mori         Bug Fix
// 2001/12/20  0.02        Cinthia Jao    Add check logic for Re-FlowBatching  (SP_Operation_FlowBatch_ReBatch)
// 2002/01/25  D4100036    K.Matsuei      FlowBatch Control.
// 2002/02/24  D4100036(2) K.Matsuei      FlowBatch Control.
// 2002/02/26  D4100036(3) K.Matsuei      FlowBatch Control.
// 2002/02/27  D4100036(4) K.Matsuei      FlowBatch Control. Add operation [SP_Operation_FlowBatchingAuto]
// 2002/02/28  D4100036(5) K.Matsuei      FlowBatch Control. change logic.
// 2003/09/08  P5000145    H.Adachi       Fix Message and Message Macro mismatch.
// 2006/05/12  P7000142    K.Matsuei      Incorrect FlowBatching is performed.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/04 DSIV00000099 M.Ogawa        Change name cassette_FillInTxPDQ008DR() -->>> cassette_DBInfo_GetDR__100
// 2015/11/11 DSN000096126 C.Mo           cassette_DBInfo_GetDR__100 ==> cassette_DBInfo_GetDR__160
// 2016/07/27 DSN000101569 C.Mo           cassette_DBInfo_GetDR__160 ==> cassette_DBInfo_GetDR__170
//
//[Function Description]:
//  Check cassette's condition for Flow Batch except for cassette size
//  This Function is used by TXDSC002,TXDSC004,TXDSC005,TXDSC007
//
//  For TXDSC002:
//       - 'in operation' has to be SP_Operation_FlowBatching
//       - 'in flowBatchID' is not used
//       - including lot's lot_holdState has to be CIMFW_Lot_HoldState_NotOnHold
//       - including lot's lot_processStae has to be SP_Lot_ProcState_Waiting
//       - including lot's lot_inventoryState has to be SP_Lot_InventoryState_OnFloor
//       - including lot's flowBatchID has to be Blank
//
//  For TXDSC004:
//       - 'in operation' has to be SP_Operation_FlowBatch_EqpReserve_Cancel
//       - 'in flowBatchID' is not used
//       - cassette's dispatchingState has to be FALSE
//
//  For TXDSC005:
//       - 'in operation' has to be SP_Operation_FlowBatch_LotRemove
//       - including lot's lot_processStae has to be SP_Lot_ProcState_Waiting
//       - including lot's lot_inventoryState has to be SP_Lot_InventoryState_OnFloor
//       - including lot's flowBatchID has to be filled and it has to same as 'in flowBatchID'
//       - cassette's dispatchingState has to be FALSE
//
//  For TXDSC007: (ReFlowBatching)
//       - 'in operation' has to be SP_Operation_FlowBatch_ReBatch
//       - Same logic with SP_Operation_FlowBatching but change part as follow
//       - bypass the EntryPoint check for lots next operation
//
//[Input Parameters]:
//  in  pptObjCommonIn                          strObjCommonIn;
//D4100036//  in  pptUser                                 requestUserID;
//  in  objectIdentifier                        equipmentID;
//  in  objectIdentifier                        flowBatchID;
//  in  sequence <pptFlowBatchingReqCassette>   strFlowBatchingReqCassette;
//  in  String                                  operation
//
//  typedef struct pptFlowBatchingReqCassette_struct {
//      objectIdentifier                        cassetteID;
//      sequence <objectIdentifier>             lotID;
//  } pptFlowBatchingReqCassette;
//
//
// [operation]
//     SP_Operation_FlowBatching
//     SP_Operation_FlowBatch_EqpReserve
//     SP_Operation_FlowBatch_EqpReserveCancel
//     SP_Operation_FlowBatch_LotRemove
//     SP_Operation_FlowBatch_ReBatch//
//
//[Output Parameters]:
//  out objCassette_CheckConditionForFlowBatch_out   strCassette_CheckConditionForFlowBatch_out;
//
//  typedef struct objCassette_CheckConditionForFlowBatch_out_struct {
//      pptRetCode                  strResult;
//  } objCassette_CheckConditionForFlowBatch_out;
//
//[Return Value]:
//
//  Return Code                               Messsage ID
//  ----------------------------------------- ------------------------------------------------
//  RC_OK                                     MSG_OK
//  RC_ALREADY_DISPATCH_RESVED_CST            MSG_ALREADY_DISPATCH_RESVED_CST
//  RC_CASTLOT_ID_BLANK                       MSG_CASTLOT_ID_BLANK
//  RC_INVALID_CAST_DISPATCH_STAT             MSG_INVALID_CAST_DISPATCH_STAT
//  RC_LOCKED_BY_ANOTHER                      MSG_LOCKED_BY_ANOTHER
//  RC_LOT_CAST_UNMATCH                       MSG_LOT_CAST_UNMATCH
//  RC_LOT_FLOW_BATCH_ID_FILLED               MSG_LOT_FLOW_BATCH_ID_FILLED
//  RC_NOT_DISPATCH_RESVED_CST                MSG_NOT_DISPATCH_RESVED_CST
//  RC_NOT_ENTRY_POINT_OF_BATCH               MSG_NOT_ENTRY_POINT_OF_BATCH
//  RC_NOT_FOUND_CASSETTE                     MSG_NOT_FOUND_CASSETTE
//  RC_NOT_FOUND_EQP                          MSG_NOT_FOUND_EQP
//  RC_NOT_FOUND_LOT                          MSG_NOT_FOUND_LOT
//  RC_SYSTEM_ERROR                           MSG_SYSTEM_ERROR

CORBA::Long  PPTManager_i::cassette_CheckConditionForFlowBatch(
                              objCassette_CheckConditionForFlowBatch_out&   strCassette_CheckConditionForFlowBatch_out,
                              const pptObjCommonIn&                         strObjCommonIn,
//D4100036                              const pptUser&                                requestUserID,
                              const objectIdentifier&                       equipmentID,
                              const objectIdentifier&                       flowBatchID,
                              const pptFlowBatchingReqCassetteSequence&     strFlowBatchingReqCassette,
                              const char*                                   operation )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_CheckConditionForFlowBatch");

{
    PPT_METHODTRACE_V1("", "*******************************************************************");
    PPT_METHODTRACE_V1("", " Debug Input Param");
    PPT_METHODTRACE_V1("", "*******************************************************************");
    PPT_METHODTRACE_V2("", "equipmentID_______________", equipmentID.identifier);
    PPT_METHODTRACE_V2("", "flowBatchID_______________", flowBatchID.identifier);
    CORBA::Long len = strFlowBatchingReqCassette.length();
    PPT_METHODTRACE_V2("", "strFlowBatchingReqCassette.length()", len);
    for ( CORBA::Long ii=0; ii < len; ii++ )
    {
        PPT_METHODTRACE_V2("", "  cassetteID______________", strFlowBatchingReqCassette[ii].cassetteID.identifier);
        CORBA::Long len2 = strFlowBatchingReqCassette[ii].lotID.length();
        PPT_METHODTRACE_V2("", "strFlowBatchingReqCassette[ii].lotID.length()", len2);
        for ( CORBA::Long jj=0; jj < len2; jj++ )
        {
            PPT_METHODTRACE_V2("", "    lotID_________________", strFlowBatchingReqCassette[ii].lotID[jj].identifier);
            PPT_METHODTRACE_V1("", ".............................................");
        }
    }
}

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        CORBA::Long i, j, k;
        CORBA::Long lotLen, cassetteLen, waferAttrLen;
        char* portGroupID = NULL;
        cassetteLen = strFlowBatchingReqCassette.length();
        PPT_METHODTRACE_V2("", "strFlowBatchingReqCassette.length()", cassetteLen);

        pptStartCassetteSequence strStartCassette;
        strStartCassette.length( cassetteLen );

//D4100036(5)        if ( 0 != CIMFWStrCmp(operation, SP_Operation_FlowBatch_EqpReserveCancel) )
//D4100036(5)        {
//D4100036(5)            PPT_METHODTRACE_V1("", "operation is not [EqpReserveCancel]");

            /*-----------------------------------------*/
            /*   Check lot infromation for Operation   */
            /*-----------------------------------------*/
            for ( i=0; i < cassetteLen; i++ )
            {
                PPT_METHODTRACE_V2("", "-----------------------------round[i] strFlowBatchingReqCassette", i);
                PPT_METHODTRACE_V2("", "cassetteID", strFlowBatchingReqCassette[i].cassetteID.identifier);

                lotLen = strFlowBatchingReqCassette[i].lotID.length();
                PPT_METHODTRACE_V2("", "strFlowBatchingReqCassette[i].lotID.length()", lotLen);

                strStartCassette[i].cassetteID = strFlowBatchingReqCassette[i].cassetteID;
                strStartCassette[i].strLotInCassette.length( lotLen );

                for ( j=0; j < lotLen; j++ )
                {
                    PPT_METHODTRACE_V2("", "---------------------------------round[j] strFlowBatchingReqCassette[i].lotID", j);
                    PPT_METHODTRACE_V2("", "lotID", strFlowBatchingReqCassette[i].lotID[j].identifier);

                    strStartCassette[i].strLotInCassette[j].lotID = strFlowBatchingReqCassette[i].lotID[j];

                    strStartCassette[i].strLotInCassette[j].operationStartFlag = TRUE;  //D4100036(2)

                    PPT_METHODTRACE_V1("", "call lot_materials_GetWafers()");
                    objLot_materials_GetWafers_out  strLot_materials_GetWafers_out;
                    rc = lot_materials_GetWafers( strLot_materials_GetWafers_out,
                                                  strObjCommonIn,
                                                  strFlowBatchingReqCassette[i].lotID[j] );

                    waferAttrLen = strLot_materials_GetWafers_out.strLotWaferAttributes.length();
                    PPT_METHODTRACE_V2("", "strLot_materials_GetWafers_out.strLotWaferAttributes.length()", waferAttrLen);

                    strStartCassette[i].strLotInCassette[j].strLotWafer.length( waferAttrLen );

                    for ( k=0; k < waferAttrLen; k++ )
                    {
                        PPT_METHODTRACE_V2("", "-------------------------------------round[k] .strLotWaferAttributes", k);

                        strStartCassette[i].strLotInCassette[j].strLotWafer[k].waferID          = strLot_materials_GetWafers_out.strLotWaferAttributes[k].waferID;
                        strStartCassette[i].strLotInCassette[j].strLotWafer[k].slotNumber       = strLot_materials_GetWafers_out.strLotWaferAttributes[k].slotNumber;
                        strStartCassette[i].strLotInCassette[j].strLotWafer[k].controlWaferFlag = strLot_materials_GetWafers_out.strLotWaferAttributes[k].controlWaferFlag;

//D4100036(2)                        PPT_METHODTRACE_V1("", "call lot_CheckConditionForOperation()");
//D4100036(2)                        objLot_CheckConditionForOperation_out strLot_CheckConditionForOperation_out;
//D4100036(2)                        rc = lot_CheckConditionForOperation( strLot_CheckConditionForOperation_out,
//D4100036(2)                                                             strObjCommonIn,
//D4100036(2)                                                             equipmentID,
//D4100036(2)                                                             portGroupID,
//D4100036(2)                                                             strStartCassette,
//D4100036(2)                                                             operation );
//D4100036(2)
//D4100036(2)                        if (rc != RC_OK)
//D4100036(2)                        {
//D4100036(2)                            PPT_METHODTRACE_V2("", "##### RC_OK != lot_CheckConditionForOperation()", rc);
//D4100036(2)                            strCassette_CheckConditionForFlowBatch_out.strResult = strLot_CheckConditionForOperation_out.strResult;
//D4100036(2)                            return rc;
//D4100036(2)                        }
                    }  //end of for[k] strStartCassette[i].strLotInCassette[j].strLotWafer
                }  //end of for[j] strFlowBatchingReqCassette[i].lotID
            }  //end of for[i] strFlowBatchingReqCassette

//D4100036(2) start
            PPT_METHODTRACE_V1("", "call lot_CheckConditionForFlowBatch()");
            objLot_CheckConditionForFlowBatch_out strLot_CheckConditionForFlowBatch_out;
            rc = lot_CheckConditionForFlowBatch( strLot_CheckConditionForFlowBatch_out,
                                                 strObjCommonIn,
                                                 equipmentID,
                                                 portGroupID,
                                                 strStartCassette,
                                                 operation );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "##### RC_OK != lot_CheckConditionForFlowBatch()", rc);
                strCassette_CheckConditionForFlowBatch_out.strResult = strLot_CheckConditionForFlowBatch_out.strResult;
                return rc;
            }
//D4100036(2) end
//D4100036(5)        }

        for ( i=0; i < cassetteLen; i++ )
        {
            PPT_METHODTRACE_V2("", "-----------------------------round[i] strFlowBatchingReqCassette", i);
            PPT_METHODTRACE_V2("", "cassetteID", strFlowBatchingReqCassette[i].cassetteID.identifier);

            /*--------------------------------------------*/
            /*   Check Cassette's TransferReserveUserID   */
            /*--------------------------------------------*/
            if ( 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatching)
              || 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatchingAuto)   //D4100036(4)
              || 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatch_ReBatch) )
            {
                PPT_METHODTRACE_V1("", "operation is [AutoBatching] or [FlowBatching] or [ReBatch]");

//DSIV00000099                objCassette_FillInTxPDQ008DR_out  strCassette_FillInTxPDQ008DR_out;
//DSIV00000099                rc = cassette_FillInTxPDQ008DR( strCassette_FillInTxPDQ008DR_out,
//DSIV00000099                                                strObjCommonIn,
//DSIV00000099                                                strFlowBatchingReqCassette[i].cassetteID );
//DSIV00000099                if ( rc != RC_OK )
//DSIV00000099                {
//DSIV00000099                    PPT_METHODTRACE_V2("", "##### RC_OK != cassette_FillInTxPDQ008DR()", rc);
//DSIV00000099                    strCassette_CheckConditionForFlowBatch_out.strResult = strCassette_FillInTxPDQ008DR_out.strResult;
//DSIV00000099                    return rc;
//DSIV00000099                }
//DSIV00000099
//DSIV00000099                if ( 0 < CIMFWStrLen(strCassette_FillInTxPDQ008DR_out.strCassetteStatusInqResult.cassetteStatusInfo.transferReserveUserID.identifier) )
//DSIV00000099                {
//DSIV00000099                    PPT_METHODTRACE_V1("", "##### return RC_ALREADY_XFER_RESERVED_CST");
//DSIV00000099                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForFlowBatch_out,
//DSIV00000099                                         MSG_ALREADY_XFER_RESERVED_CST, RC_ALREADY_XFER_RESERVED_CST,
//DSIV00000099                                         strFlowBatchingReqCassette[i].cassetteID.identifier,
//DSIV00000099                                         strCassette_FillInTxPDQ008DR_out.strCassetteStatusInqResult.cassetteStatusInfo.transferReserveUserID.identifier );
//DSIV00000099                    return RC_ALREADY_XFER_RESERVED_CST;
//DSIV00000099                }
//DSIV00000099 add start
//DSN000096126                objCassette_DBInfo_GetDR_out__100  strCassette_DBInfo_GetDR_out;
//DSN000096126                objCassette_DBInfo_GetDR_in__100   strCassette_DBInfo_GetDR_in;
//DSN000096126                strCassette_DBInfo_GetDR_in.cassetteID = strFlowBatchingReqCassette[i].cassetteID;
//DSN000096126                rc = cassette_DBInfo_GetDR__100( strCassette_DBInfo_GetDR_out,
//DSN000096126                                                 strObjCommonIn,
//DSN000096126                                                 strCassette_DBInfo_GetDR_in );
//DSN000096126                if ( rc != RC_OK )
//DSN000096126                {
//DSN000096126                    PPT_METHODTRACE_V2("", "##### RC_OK != cassette_DBInfo_GetDR__100()", rc);
//DSN000096126                    strCassette_CheckConditionForFlowBatch_out.strResult = strCassette_DBInfo_GetDR_out.strResult;
//DSN000096126                    return rc;
//DSN000096126                }
//DSN000096126 Add Start
//DSN000101569                objCassette_DBInfo_GetDR_out__160  strCassette_DBInfo_GetDR_out;
                objCassette_DBInfo_GetDR_out__170  strCassette_DBInfo_GetDR_out;                                                //DSN000101569
                objCassette_DBInfo_GetDR_in__160   strCassette_DBInfo_GetDR_in;
                strCassette_DBInfo_GetDR_in.cassetteID                  = strFlowBatchingReqCassette[i].cassetteID;
                strCassette_DBInfo_GetDR_in.durableOperationInfoFlag    = FALSE;
                strCassette_DBInfo_GetDR_in.durableWipOperationInfoFlag = FALSE;
//DSN000101569                rc = cassette_DBInfo_GetDR__160(strCassette_DBInfo_GetDR_out, strObjCommonIn, strCassette_DBInfo_GetDR_in);
                rc = cassette_DBInfo_GetDR__170(strCassette_DBInfo_GetDR_out, strObjCommonIn, strCassette_DBInfo_GetDR_in);     //DSN000101569
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "##### RC_OK != cassette_DBInfo_GetDR__170()", rc);
                    strCassette_CheckConditionForFlowBatch_out.strResult = strCassette_DBInfo_GetDR_out.strResult;
                    return rc;
                }
//DSN000096126 Add End

                if ( 0 < CIMFWStrLen(strCassette_DBInfo_GetDR_out.strCassetteStatusInqResult.cassetteStatusInfo.transferReserveUserID.identifier) )
                {
                    PPT_METHODTRACE_V1("", "##### return RC_ALREADY_XFER_RESERVED_CST");
                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForFlowBatch_out,
                                         MSG_ALREADY_XFER_RESERVED_CST, RC_ALREADY_XFER_RESERVED_CST,
                                         strFlowBatchingReqCassette[i].cassetteID.identifier,
                                         strCassette_DBInfo_GetDR_out.strCassetteStatusInqResult.cassetteStatusInfo.transferReserveUserID.identifier );
                    return RC_ALREADY_XFER_RESERVED_CST;
                }
//DSIV00000099 add end
            }

//D4100036(3) start
            /*---------------------------------*/
            /*   Check Cassette's ControlJob   */
            /*---------------------------------*/
            PPT_METHODTRACE_V1("", "Check Cassette's ControlJob");
            PosCassette_var aCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                                   strFlowBatchingReqCassette[i].cassetteID,
                                                   strCassette_CheckConditionForFlowBatch_out,
                                                   cassette_CheckConditionForFlowBatch );

            PosControlJob_var aControlJob;
            try
            {
                aControlJob = aCassette->getControlJob();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)

            if ( TRUE != CORBA::is_nil(aControlJob) )
            {
                PPT_METHODTRACE_V1("", "##### return RC_CAST_CTRLJOBID_FILLED");
                SET_MSG_RC( strCassette_CheckConditionForFlowBatch_out, MSG_CAST_CTRLJOBID_FILLED, RC_CAST_CTRLJOBID_FILLED );
                return RC_CAST_CTRLJOBID_FILLED;
            }
//D4100036(3) end

            lotLen = strFlowBatchingReqCassette[i].lotID.length();

            for ( j=0; j < lotLen; j++ )
            {
                PPT_METHODTRACE_V2("", "---------------------------------round[j] strFlowBatchingReqCassette[i].lotID", j);
                PPT_METHODTRACE_V2("", "lotID", strFlowBatchingReqCassette[i].lotID[j].identifier);

                /*--------------------------*/
                /*   Check TransferStatus   */
                /*--------------------------*/
                if ( 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatching)
                  || 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatchingAuto)   //D4100036(4)
                  || 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatch_ReBatch) )
                {
                    PPT_METHODTRACE_V1("", "operation is [AutoBatching] or [FlowBatching] or [ReBatch]");

                    objLot_transferState_Get_out  strLot_transferState_Get_out;
                    rc = lot_transferState_Get( strLot_transferState_Get_out, strObjCommonIn, strFlowBatchingReqCassette[i].lotID[j] );

                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "##### RC_OK != lot_transferState_Get()", rc);
                        strCassette_CheckConditionForFlowBatch_out.strResult = strLot_transferState_Get_out.strResult;
                        return rc;
                    }
                    PPT_METHODTRACE_V2("", "transferState", strLot_transferState_Get_out.transferState);

                    if ( 0 != CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_StationIn)
                      && 0 != CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_BayIn)
                      && 0 != CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_ManualIn)
                      && 0 != CIMFWStrCmp(strLot_transferState_Get_out.transferState, SP_TransState_IntermediateIn) )
                    {
                        PPT_METHODTRACE_V1("", "##### return RC_INVALID_LOT_XFER_STAT   transState != [SI]/[BI]/[MI]/[II]");
                        PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForFlowBatch_out,
                                             MSG_INVALID_LOT_XFER_STAT, RC_INVALID_LOT_XFER_STAT,
                                             strFlowBatchingReqCassette[i].lotID[j].identifier,
                                             strLot_transferState_Get_out.transferState );
                        return RC_INVALID_LOT_XFER_STAT;
                    }
                }

                /*-----------------------------------*/
                /*   Check cassette-lot connection   */
                /*-----------------------------------*/
                PPT_METHODTRACE_V1("", "call lot_cassette_CheckSame()");
                objLot_cassette_CheckSame_out  strLot_cassette_CheckSame_out;
                rc = lot_cassette_CheckSame( strLot_cassette_CheckSame_out,
                                             strObjCommonIn,
                                             strFlowBatchingReqCassette[i].lotID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "##### RC_OK != lot_cassette_CheckSame()", rc);
                    strCassette_CheckConditionForFlowBatch_out.strResult = strLot_cassette_CheckSame_out.strResult;
                    return rc;
                }

                if ( 0 != CIMFWStrCmp(operation, SP_Operation_FlowBatch_EqpReserveCancel) )
                {
                    PPT_METHODTRACE_V1("", "operation is [EqpReserveCancel]");

//0.02                    if ( ( CIMFWStrCmp(operation, SP_Operation_FlowBatching) == 0 ) ||
//0.02                         ( CIMFWStrCmp(operation, SP_Operation_FlowBatch_LotRemove ) == 0 ) )
                    if ( 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatching)
                      || 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatchingAuto)   //D4100036(4)
                      || 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatch_ReBatch)
                      || 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatch_LotRemove) )  //0.02
                    {
//0.02                        PPT_METHODTRACE_V3("", "CIMFWStrCmp(operation, SP_Operation_FlowBatching or SP_Operation_FlowBatch_LotRemove ) == 0", i, j);
                        PPT_METHODTRACE_V1("", "operation is [AutoBatching] or [FlowBatching] or [ReBatch] or [LotRemove]");  //0.02

                        /*-------------------------------*/
                        /*   Check lot's flow batch ID   */
                        /*-------------------------------*/
                        PPT_METHODTRACE_V1("", "call lot_flowBatchID_Get()");
                        objLot_flowBatchID_Get_out  strLot_flowBatchID_Get_out;
                        rc = lot_flowBatchID_Get( strLot_flowBatchID_Get_out,
                                                  strObjCommonIn,
                                                  strFlowBatchingReqCassette[i].lotID[j]);

                        switch( rc )
                        {
                        case RC_LOT_FLOW_BATCH_ID_BLANK:
                            PPT_METHODTRACE_V1("", "RC_LOT_FLOW_BATCH_ID_BLANK <--- lot_flowBatchID_Get()" );

                            if ( 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatch_LotRemove) )
                            {
                                PPT_METHODTRACE_V1("", "operation is [LotRemove]");
                                PPT_METHODTRACE_V1("", "##### return RC_NOT_BATCHED_LOT");
                                PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForFlowBatch_out,
                                                    MSG_NOT_BATCHED_LOT, RC_NOT_BATCHED_LOT,
                                                    strFlowBatchingReqCassette[i].lotID[j].identifier  );
                                return RC_NOT_BATCHED_LOT;
                            }
                            break;

                        case RC_LOT_FLOW_BATCH_ID_FILLED:
                            PPT_METHODTRACE_V1("", "RC_LOT_FLOW_BATCH_ID_FILLED <--- lot_flowBatchID_Get()" );

                            if ( 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatch_LotRemove) )
                            {
                                PPT_METHODTRACE_V1("", "operation is [LotRemove]");

                                if ( 0 != CIMFWStrCmp(strLot_flowBatchID_Get_out.flowBatchID.identifier, flowBatchID.identifier) )
                                {
                                    PPT_METHODTRACE_V1("", "strLot_flowBatchID_Get_out.flowBatchID != flowBatchID");
                                    PPT_METHODTRACE_V1("", "##### return RC_LOT_FLOWBATCH_MISMATCH");
                                    PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForFlowBatch_out,
                                                        MSG_LOT_FLOWBATCH_MISMATCH, RC_LOT_FLOWBATCH_MISMATCH,
                                                        strLot_flowBatchID_Get_out.flowBatchID.identifier );
                                    return RC_LOT_FLOWBATCH_MISMATCH;
                                }
                            }

                            PPT_METHODTRACE_V1("", "##### return RC_LOT_FLOW_BATCH_ID_FILLED");
//P5000145                            PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForFlowBatch_out,
//P5000145                                                MSG_LOT_FLOW_BATCH_ID_FILLED, RC_LOT_FLOW_BATCH_ID_FILLED,
//P5000145                                                strLot_flowBatchID_Get_out.flowBatchID.identifier );
                            SET_MSG_RC( strCassette_CheckConditionForFlowBatch_out,                     //P5000145
                                        MSG_LOT_FLOW_BATCH_ID_FILLED, RC_LOT_FLOW_BATCH_ID_FILLED );    //P5000145
                            return RC_LOT_FLOW_BATCH_ID_FILLED;
                            break;

                        default:
                            PPT_METHODTRACE_V1("", "##### default" );
                            strCassette_CheckConditionForFlowBatch_out.strResult = strLot_flowBatchID_Get_out.strResult;
                            return rc;
                            break;
                        }
                    }

                    if ( 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatching)
                      || 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatchingAuto) )   //D4100036(4)
                    {
                        PPT_METHODTRACE_V1("", "operation is [AutoBatching] or [FlowBatching]" );

                        /*---------------------------------*/
                        /*   Check lot's next oeperation   */
                        /*---------------------------------*/
                        PPT_METHODTRACE_V1("", "call lot_nextOperation_CheckEntryPointOfFlowBatch()");
                        pptBatchingReqLot strBatchingReqLot;
                        strBatchingReqLot.lotID = strFlowBatchingReqCassette[i].lotID[j];
                        strBatchingReqLot.cassetteID = strFlowBatchingReqCassette[i].cassetteID;

                        objLot_nextOperation_CheckEntryPointOfFlowBatch_out  strLot_nextOperation_CheckEntryPointOfFlowBatch_out;
                        rc = lot_nextOperation_CheckEntryPointOfFlowBatch( strLot_nextOperation_CheckEntryPointOfFlowBatch_out,
                                                                           strObjCommonIn,
                                                                           strBatchingReqLot );

                        if ( rc != RC_OK )
                        {
                            PPT_METHODTRACE_V2("", "##### RC_OK != lot_nextOperation_CheckEntryPointOfFlowBatch()", rc);
                            strCassette_CheckConditionForFlowBatch_out.strResult = strLot_nextOperation_CheckEntryPointOfFlowBatch_out.strResult;
                            return rc;
                        }
                    }
                }

                if ( 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatch_EqpReserveCancel)
                  || 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatch_LotRemove) )
                {
                    PPT_METHODTRACE_V1("", "operation is [EqpReserveCancel] or [LotRemove]" );

                    /*--------------------------*/
                    /*   Check dispath status   */
                    /*--------------------------*/
                    PPT_METHODTRACE_V1("", "call cassette_dispatchState_Get()");
                    objCassette_dispatchState_Get_out strCassette_dispatchState_Get_out;
                    rc = cassette_dispatchState_Get( strCassette_dispatchState_Get_out,
                                                     strObjCommonIn,
                                                     strFlowBatchingReqCassette[i].cassetteID );

                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V2("", "##### RC_OK != cassette_dispatchState_Get()", rc);
                        strCassette_CheckConditionForFlowBatch_out.strResult = strCassette_dispatchState_Get_out.strResult;
                        return rc;
                    }
                    if ( strCassette_dispatchState_Get_out.dispatchReservedFlag == TRUE )
                    {
                        PPT_METHODTRACE_V1("", "##### return RC_INVALID_CAST_DISPATCH_STAT");
                        SET_MSG_RC( strCassette_CheckConditionForFlowBatch_out, MSG_INVALID_CAST_DISPATCH_STAT, RC_INVALID_CAST_DISPATCH_STAT );
                        return RC_INVALID_CAST_DISPATCH_STAT;
                    }
                }
            }
        }

//P7000142 start
        /*---------------------------------*/
        /*   Check all Lots in Cassette.   */
        /*---------------------------------*/
        if ( 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatching) )
        {
            PPT_METHODTRACE_V1("", "Check all Lots in Cassette");

            CORBA::Long lenFBReqCast = strFlowBatchingReqCassette.length();

            for ( i=0; i < lenFBReqCast; i++ )
            {
                PPT_METHODTRACE_V2("", "-----------------------------round[i] strFlowBatchingReqCassette", i);
                PPT_METHODTRACE_V2("", "cassetteID", strFlowBatchingReqCassette[i].cassetteID.identifier);

                objCassette_GetLotList_out  strCassette_GetLotList_out;
                rc = cassette_GetLotList( strCassette_GetLotList_out, strObjCommonIn, strFlowBatchingReqCassette[i].cassetteID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "##### RC_OK != cassette_GetLotList()", rc);
                    strCassette_CheckConditionForFlowBatch_out.strResult = strCassette_GetLotList_out.strResult;
                    return rc;
                }

                CORBA::Long lenLotInCassette = strCassette_GetLotList_out.strLotListInCassetteInfo.lotID.length();
                PPT_METHODTRACE_V2("", "lenLotInCassette", lenLotInCassette);

                CORBA::Long lenFBReqLot = strFlowBatchingReqCassette[i].lotID.length();

                if ( lenFBReqLot != lenLotInCassette )
                {
                    PPT_METHODTRACE_V1("", "##### All Lots weren't found in Cassette.");
                    SET_MSG_RC( strCassette_CheckConditionForFlowBatch_out, MSG_NOT_ENOUGH_LOT_FOR_FLOW_BATCH, RC_NOT_ENOUGH_LOT_FOR_FLOW_BATCH );
                    return RC_NOT_ENOUGH_LOT_FOR_FLOW_BATCH;
                }

                CORBA::Boolean bFound = FALSE;
                for ( j=0; j < lenLotInCassette; j++ )
                {
                    PPT_METHODTRACE_V2("", "  LotInCassette--->Lot", strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[j].identifier);
                    bFound = FALSE;

                    for ( k=0; k < lenFBReqLot; k++ )
                    {
                        if ( 0 == CIMFWStrCmp(strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[j].identifier,
                                              strFlowBatchingReqCassette[i].lotID[k].identifier) )
                        {
                            bFound = TRUE;
                            break; //[k]
                        }
                    } //end of [k]

                    if ( FALSE == bFound )
                    {
                        PPT_METHODTRACE_V1("", "##### All Lots weren't found in Cassette.");
                        SET_MSG_RC( strCassette_CheckConditionForFlowBatch_out, MSG_NOT_ENOUGH_LOT_FOR_FLOW_BATCH, RC_NOT_ENOUGH_LOT_FOR_FLOW_BATCH );
                        return RC_NOT_ENOUGH_LOT_FOR_FLOW_BATCH;
                    }
                } //end of [j]
            } //end of [i]
        }
//P7000142 end

        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_CheckConditionForFlowBatch");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_CheckConditionForFlowBatch_out, cassette_CheckConditionForFlowBatch, methodName)
}
