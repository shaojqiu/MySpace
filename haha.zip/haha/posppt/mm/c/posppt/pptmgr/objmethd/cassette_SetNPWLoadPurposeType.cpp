#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_SetNPWLoadPurposeType.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:33:20 [ 7/13/07 19:33:21 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_SetNPWLoadPurposeType.cpp
//

#include "pptmgr.hpp"

#include "pcas.hh"


//[Object Function Name]: long   cassette_SetNPWLoadPurposeType
//
// Date        Level   Author         Note
// ----------  ------- -------------  -------------------------------------------
// 2001-07-16  D400028 M.Sunakawa     Initial Release (R40)
//
//[Function Description]:
//  Set in-param's loadPurposeType to NPWLoadPurposeTypeReset PosCassette.
//
//[Input Parameters]:
//  in  pptObjCommonIn        strObjCommonIn;
//  in  objectIdentifier      cassetteID;
//  in  string                loadPurposeType;
//
//[Output Parameters]:
//  out objCassette_SetNPWLoadPurposeType_out   strCassette_SetNPWLoadPurposeType_out;
//
//  typedef struct objCassette_SetNPWLoadPurposeType_out_struct {
//      pptRetCode            strResult;
//  } objCassette_SetNPWLoadPurposeType_out;
//
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//  RC_NOT_FOUND_CASSETTE     MSG_NOT_FOUND_CASSETTE
//  RC_LOCKED_BY_ANOTHER      MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR           MSG_SYSTEM_ERROR
//
//
//[Pseudo Code]:
//

CORBA::Long PPTManager_i::cassette_SetNPWLoadPurposeType(objCassette_SetNPWLoadPurposeType_out& strCassette_SetNPWLoadPurposeType_out,
                                                        const pptObjCommonIn& strObjCommonIn,
                                                        const objectIdentifier& cassetteID,
                                                        const char* loadPurposeType)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_SetNPWLoadPurposeType");
        PPT_METHODTRACE_V2("PPTManager_i::cassette_SetNPWLoadPurposeType","in-parm's cassetteID", cassetteID.identifier);
        PPT_METHODTRACE_V2("PPTManager_i::cassette_SetNPWLoadPurposeType","in-parm's loadPurposeType loadPurposeType", loadPurposeType);

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;
        SET_MSG_RC( strCassette_SetNPWLoadPurposeType_out , MSG_OK , RC_OK )
        
        /*---------------------------*/
        /*   Get cassetteID Object   */
        /*---------------------------*/
        PPT_METHODTRACE_V1("PPTManager_i::cassette_SetNPWLoadPurposeType","Get cassetteID Object");
        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                               cassetteID,
                                               strCassette_SetNPWLoadPurposeType_out,
                                               cassette_SetNPWLoadPurposeType );
        try
        {
            aCassette->setNPWLoadPurposeType(loadPurposeType);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setNPWLoadPurposeType)
        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_SetNPWLoadPurposeType");

        return( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_SetNPWLoadPurposeType_out, cassette_SetNPWLoadPurposeType, methodName)
}
