#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/backup_lotCategory_Get.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:29:07 [ 7/13/07 19:29:08 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: backup_lotCategory_Get.cpp
//

#include "pptmgr.hpp"
#include "plot.hh"

// Class: PPTManager
//
// Service: backup_lotCategory_Get()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2002/09/04 D4200062 K.Kimura       Initial : Backup Operation (R4.2)
//
// Description:
//
// Return:
//    long
//
// Parameter:
//    objBackup_lotCategory_Get_out& strBackup_lotCategory_Get_out
//    const pptObjCommonIn&          strObjCommonIn
//    const objectIdentifier&        lotID
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long PPTManager_i::backup_lotCategory_Get(
    objBackup_lotCategory_Get_out& strBackup_lotCategory_Get_out,
    const pptObjCommonIn&          strObjCommonIn,
    const objectIdentifier&        lotID)
{
    char * methodName = NULL ;
    CORBA::Long rc = 0;

    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::backup_lotCategory_Get") ;

        //---------------------------------------//
        //    Get object reference from lotID    //
        //---------------------------------------//
        PosLot_var aLot ;
        PPT_CONVERT_LOTID_TO_LOT_OR( aLot,
                                     lotID,
                                     strBackup_lotCategory_Get_out,
                                     backup_lotCategory_Get ) ;

        //------------------------------//
        //    Get ProductID from lot    //
        //------------------------------//
        PosProductSpecification_var aPosProductSpecification ;
        ProductSpecification_var aProductSpecification ;
        try
        {
            aProductSpecification  = aLot->getProductSpecification() ;
            aPosProductSpecification = PosProductSpecification::_narrow(aProductSpecification);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification)

        if (CORBA::is_nil(aPosProductSpecification) == TRUE)
        {
            PPT_METHODTRACE_V1("", "aPosProductSpecification is Nil");
            SET_MSG_RC( strBackup_lotCategory_Get_out,
                        MSG_NOT_FOUND_PRODUCTSPEC,
                        RC_NOT_FOUND_PRODUCTSPEC ) ;
            return( RC_NOT_FOUND_PRODUCTSPEC ) ;
        }

        //---------------------------------------------------//
        //    Set identifier from aPosProductGroup object    //
        //---------------------------------------------------//
        objectIdentifier productID ;
        PPT_SET_OBJECT_IDENTIFIER( productID,
                                   aPosProductSpecification,
                                   strBackup_lotCategory_Get_out,
                                   backup_lotCategory_Get,
                                   PosProductSpecification ) ;

        //---------------------------------------//
        //   Get ProductGroupID from product     //
        //---------------------------------------//
        PosProductGroup_var aPosProductGroup ;
        try
        {
            aPosProductGroup = aPosProductSpecification->getProductGroup() ;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProductGroup::getProductGroup)

        if (CORBA::is_nil(aPosProductGroup) == TRUE)
        {
            PPT_METHODTRACE_V1("", "aPosProductGroup is Nil");

            PPT_SET_MSG_RC_KEY( strBackup_lotCategory_Get_out,
                                MSG_NOT_FOUND_PRODUCTID,
                                RC_NOT_FOUND_PRODUCTID,
                                productID.identifier ) ;
            return( RC_NOT_FOUND_PRODUCTID ) ;
        }

        //---------------------------------------------------//
        //    Set identifier from aPosProductGroup object    //
        //---------------------------------------------------// 
        objectIdentifier productGroupID ;
        PPT_SET_OBJECT_IDENTIFIER( productGroupID,
                                   aPosProductGroup,
                                   strBackup_lotCategory_Get_out,
                                   backup_lotCategory_Get,
                                   PosProductGroup ) ;

        //--- Get TechnologyID from productGroup ---//
        PosTechnology_var aPosTechnology ;
        try
        {
            aPosTechnology = aPosProductGroup->getTechnology() ;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProductGroup::getTechnology)

        if (CORBA::is_nil(aPosTechnology) == TRUE)
        {
            PPT_METHODTRACE_V1("", "aPosTechnology is Nil");

            PPT_SET_MSG_RC_KEY( strBackup_lotCategory_Get_out,
                                MSG_NOT_FOUND_PRODUCTGROUP,
                                RC_NOT_FOUND_PRODUCTGROUP,
                                productGroupID.identifier ) ;
            return( RC_NOT_FOUND_PRODUCTGROUP ) ;
        }

        //--- Set identifier from aPosTechonology object ---//
        objectIdentifier technologyID ;
        PPT_SET_OBJECT_IDENTIFIER( technologyID,
                                   aPosTechnology,
                                   strBackup_lotCategory_Get_out,
                                   backup_lotCategory_Get,
                                   PosTechnology ) ;

        /*----------------------*/
        /*   Return to Caller   */
        /*----------------------*/
        //--- Set to return structure productID, productGroupID, technologyID ---//
        strBackup_lotCategory_Get_out.productID      = productID;
        strBackup_lotCategory_Get_out.productGroupID = productGroupID;
        strBackup_lotCategory_Get_out.technologyID   = technologyID;

        return( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS(strBackup_lotCategory_Get_out,backup_lotCategory_Get,methodName)
}
