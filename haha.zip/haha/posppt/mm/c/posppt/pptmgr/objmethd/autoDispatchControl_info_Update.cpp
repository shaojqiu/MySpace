//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2011. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2011. All rights reserved.
//
// SiView
// Name: autoDispatchControl_info_Update.cpp
//

#include "pptmgr.hpp"
#include "pevbase.hh"
#include "plot.hh"

// Class: PPTManager
//
// Service: autoDispatchControl_info_Update()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2011/09/21 DSN000020767 T.Ishida       Auto Dispatch Control Support
//
//[Function Description]:
//
//
//[Input Parameters]:
//  const pptObjCommonIn&                        strObjCommonIn
//  const objAutoDispatchControl_info_Update_in& strAutoDispatchControl_info_Update_in
//
//    typedef struct objAutoDispatchControl_info_Update_in_struct {
//        objectIdentifier                 lotID;
//        pptAutoDispatchControlUpdateInfo strAutoDispatchControlUpdateInfo;
//        any                              siInfo;
//    } objAutoDispatchControl_info_Update_in;
//
//[Output Parameters]:
//  objAutoDispatchControl_info_Update_out& strAutoDispatchControl_info_Update_out
//
//    typedef objBase_out objAutoDispatchControl_info_Update_out;
//
//[Return Value]:
//
//  Return Code                        Message ID
//  ---------------------------------- -----------------------------------------
//  RC_OK                              MSG_OK
//
CORBA::Long PPTManager_i::autoDispatchControl_info_Update(
    objAutoDispatchControl_info_Update_out&      strAutoDispatchControl_info_Update_out,
    const pptObjCommonIn&                        strObjCommonIn,
    const objAutoDispatchControl_info_Update_in& objAutoDispatchControl_info_Update_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY( "PPTManager_i::autoDispatchControl_info_Update" );

        //--------------//
        //  Initialize  //
        //--------------//
        CORBA::Long rc = RC_OK;

        objectIdentifier lotID;
        pptAutoDispatchControlUpdateInfo strAutoDispatchControlUpdateInfo;

        lotID                            = objAutoDispatchControl_info_Update_in.lotID;
        strAutoDispatchControlUpdateInfo = objAutoDispatchControl_info_Update_in.strAutoDispatchControlUpdateInfo;

        PosLot_var aLot ;
        PPT_CONVERT_LOTID_TO_LOT_OR( aLot, lotID , strAutoDispatchControl_info_Update_out, autoDispatchControl_info_Update )

        /*-----   Check Input Parameter   -----*/
        if( CIMFWStrLen( strAutoDispatchControlUpdateInfo.updateMode ) == 0 )
        {
            PPT_METHODTRACE_V1( "", "updateMode is Null" );

            SET_MSG_RC( strAutoDispatchControl_info_Update_out,
                        MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        if( CIMFWStrLen( strAutoDispatchControlUpdateInfo.routeID.identifier ) == 0 )
        {
            PPT_METHODTRACE_V1( "", "routeID is Null" );

            SET_MSG_RC( strAutoDispatchControl_info_Update_out,
                        MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        if( CIMFWStrLen( strAutoDispatchControlUpdateInfo.operationNumber ) == 0 )
        {
            PPT_METHODTRACE_V1( "", "operationNumber is Null" );

            SET_MSG_RC( strAutoDispatchControl_info_Update_out,
                        MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        posAutoDispatchControlRecord aAutoDispatchControlRecord;

        aAutoDispatchControlRecord.routeID           = strAutoDispatchControlUpdateInfo.routeID;
        aAutoDispatchControlRecord.operationNumber   = strAutoDispatchControlUpdateInfo.operationNumber;
        aAutoDispatchControlRecord.singleTriggerFlag = strAutoDispatchControlUpdateInfo.singleTriggerFlag;
        aAutoDispatchControlRecord.description       = strAutoDispatchControlUpdateInfo.description;
        aAutoDispatchControlRecord.updateUserID      = strObjCommonIn.strUser.userID;
        aAutoDispatchControlRecord.updateTimeStamp   = strObjCommonIn.strTimeStamp.reportTimeStamp;

        if( CIMFWStrCmp( strAutoDispatchControlUpdateInfo.updateMode, SP_AutoDispatchControl_Create ) == 0 )
        {
            try
            {
                PPT_DISPLAY_RESPONSE_TIME();
                aLot->addAutoDispatchControlRecord( aAutoDispatchControlRecord );
            }
            catch( PosLot::AutoDispatchControlRecordDuplicateSignal )
            {
                SET_MSG_RC( strAutoDispatchControl_info_Update_out, MSG_DUPLICATE_DISPCTRL_ENTRY, RC_DUPLICATE_DISPCTRL_ENTRY )
                PPT_METHODTRACE_EXIT( "PPTManager_i::autoDispatchControl_info_Update" )
                return RC_DUPLICATE_DISPCTRL_ENTRY ;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::addAutoDispatchControlRecord)
        }
        else if( CIMFWStrCmp( strAutoDispatchControlUpdateInfo.updateMode, SP_AutoDispatchControl_Update ) == 0 )
        {
            try
            {
                PPT_DISPLAY_RESPONSE_TIME();
                aLot->removeAutoDispatchControlRecord( aAutoDispatchControlRecord );
            }
            catch( PosLot::AutoDispatchControlRecordNotFoundSignal )
            {
                SET_MSG_RC( strAutoDispatchControl_info_Update_out, MSG_NOT_FOUND_DISPCTRL, RC_NOT_FOUND_DISPCTRL )
                PPT_METHODTRACE_EXIT( "PPTManager_i::removeAutoDispatchControlRecord" )
                return RC_NOT_FOUND_DISPCTRL;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::removeAutoDispatchControlRecord)

            try
            {
                PPT_DISPLAY_RESPONSE_TIME();
                aLot->addAutoDispatchControlRecord( aAutoDispatchControlRecord );
            }
            catch( PosLot::AutoDispatchControlRecordDuplicateSignal )
            {
                SET_MSG_RC( strAutoDispatchControl_info_Update_out, MSG_DUPLICATE_DISPCTRL_ENTRY, RC_DUPLICATE_DISPCTRL_ENTRY )
                PPT_METHODTRACE_EXIT( "PPTManager_i::autoDispatchControl_info_Update" )
                return RC_DUPLICATE_DISPCTRL_ENTRY;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::addAutoDispatchControlRecord)
        }
        else if( CIMFWStrCmp( strAutoDispatchControlUpdateInfo.updateMode, SP_AutoDispatchControl_Delete ) == 0 )
        {
            try
            {
                PPT_DISPLAY_RESPONSE_TIME();
                aLot->removeAutoDispatchControlRecord( aAutoDispatchControlRecord );
            }
            catch( PosLot::AutoDispatchControlRecordNotFoundSignal )
            {
                SET_MSG_RC( strAutoDispatchControl_info_Update_out, MSG_NOT_FOUND_DISPCTRL, RC_NOT_FOUND_DISPCTRL )
                PPT_METHODTRACE_EXIT( "PPTManager_i::removeAutoDispatchControlRecord" )
                return RC_NOT_FOUND_DISPCTRL;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::removeAutoDispatchControlRecord)
        }
        else if( CIMFWStrCmp( strAutoDispatchControlUpdateInfo.updateMode, SP_AutoDispatchControl_AutoDelete ) == 0 )
        {
            if( strAutoDispatchControlUpdateInfo.singleTriggerFlag == TRUE )
            {
                try
                {
                    PPT_DISPLAY_RESPONSE_TIME();
                    aLot->removeAutoDispatchControlRecord( aAutoDispatchControlRecord );
                }
                catch( PosLot::AutoDispatchControlRecordNotFoundSignal )
                {
                    SET_MSG_RC( strAutoDispatchControl_info_Update_out, MSG_NOT_FOUND_DISPCTRL, RC_NOT_FOUND_DISPCTRL )
                    PPT_METHODTRACE_EXIT( "PPTManager_i::removeAutoDispatchControlRecord" )
                    return RC_NOT_FOUND_DISPCTRL;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::removeAutoDispatchControlRecord)
            }
            else
            {
               SET_MSG_RC( strAutoDispatchControl_info_Update_out,
                           MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
               return RC_INVALID_INPUT_PARM;
            }
        }
        else
        {
            PPT_METHODTRACE_V1( "", "updateMode is Invalid" );

            SET_MSG_RC( strAutoDispatchControl_info_Update_out,
                        MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        //--------------------//
        //  Return to Caller  //
        //--------------------//
        PPT_METHODTRACE_EXIT( "PPTManager_i::autoDispatchControl_info_Update" );
        return RC_OK ;
    }
    CATCH_GLOBAL_EXCEPTIONS( strAutoDispatchControl_info_Update_out, autoDispatchControl_info_Update, methodName );
}
