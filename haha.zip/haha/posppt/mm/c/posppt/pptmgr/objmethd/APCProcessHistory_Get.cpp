#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/APCProcessHistory_Get.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:18:35 [ 7/13/07 19:18:36 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: APCProcessHistory_Get.cpp
//

#include "pptmgr.hpp"

#include "plot.hh"
#include "ppcflwx.hh"
#include "ppcope.hh"
#include "pmongrp.hh"
#include "pmcrc.hh"

//[Object Function Name]: long  APCProcessHistory_Get
//
// Date        Level    Author         Note
// ----------  -------  -------------  -------------------------------------------
// 2004/07/13  D51M0000 M.Mori         Initial Release (R51M)
//
//[Function Description]:
//
// [Input Parameters]:
//  in  pptObjCommonIn          strObjCommonIn
//  in  objectIdentifier        lotID
//
// [Output Parameters]:
//
//  out objAPCProcessHistory_Get_out  strAPCProcessHistory_Get_out
//
//  typedef struct objAPCProcessHistory_Get_out_struct {
//      pptRetCode                  strResult;
//      pptAPCLotHistorySequence    strAPCLotHistoryList;
//      any                         siInfo;
//  } objAPCProcessHistory_Get_out;
//
// [Return Value]:
//
//  Return Code                 Messsage ID
//  -------------------------   --------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_NOT_FOUND_PFX            MSG_NOT_FOUND_PFX
//  RC_NOT_FOUND_OPERATION      MSG_NOT_FOUND_OPERATION
//  RC_NOT_FOUND_PROHS          MSG_NOT_FOUND_PROHS
//  RC_NOT_FOUND_EQP            MSG_NOT_FOUND_EQP
//  RC_NOT_FOUND_MCRECIPE       MSG_NOT_FOUND_MCRECIPE
//  RC_NOT_FOUND_PD             MSG_NOT_FOUND_PD

CORBA::Long PPTManager_i::APCProcessHistory_Get(
    objAPCProcessHistory_Get_out&       strAPCProcessHistory_Get_out,
    const pptObjCommonIn&               strObjCommonIn,
    const objectIdentifier&             lotID)
{
    CORBA::Long rc = RC_OK;
    char * methodName = NULL;

    try
    {
        CORBA::Long SetCnt = 0;
        pptAPCLotHistorySequence  strAPCLotHistoryList;

        //---------------------------------------------
        //   get PosLot
        //---------------------------------------------
        PosLot_var aLot;
        PPT_CONVERT_LOTID_TO_LOT_OR( aLot, lotID, strAPCProcessHistory_Get_out, APCProcessHistory_Get )

        //----------------------------------------------------------------------------------------
        //   set processEquipmentID & processRecipeID & processRouteID & processOperaitonNumber
        //----------------------------------------------------------------------------------------
        //---------------------------------------------
        //   get ProcessFlowContext
        //---------------------------------------------
        PosProcessFlowContext_var aPFX;
        try
        {
            aPFX = aLot->getProcessFlowContext();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessFlowContext);

        if ( CORBA::is_nil(aPFX) == TRUE )
        {
            PPT_METHODTRACE_V1("", "CORBA::is_nil(aPFX)")

            PPT_SET_MSG_RC_KEY(strAPCProcessHistory_Get_out,
                               MSG_NOT_FOUND_PFX,
                               RC_NOT_FOUND_PFX,
                               "");

            return( RC_NOT_FOUND_PFX );
        }

        //---------------------------------------------
        //   get current Process Operation
        //---------------------------------------------
        ProcessOperation_var aPO;
        PosProcessOperation_var aCurrentPO;
        try
        {
            aPO = aLot->getProcessOperation();
            aCurrentPO = PosProcessOperation::_narrow(aPO);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation);

        if(CORBA::is_nil(aCurrentPO) == TRUE)
        {
            PPT_METHODTRACE_V1("", "##### return RC_NOT_FOUND_OPERATION");
            PPT_SET_MSG_RC_KEY(strAPCProcessHistory_Get_out,
                               MSG_NOT_FOUND_OPERATION,
                               RC_NOT_FOUND_OPERATION,
                               "");

            return( RC_NOT_FOUND_OPERATION );
        }

        stringSequence_var responsibleOperationNumbersList;

        try
        {
            responsibleOperationNumbersList = aCurrentPO->getResponsibleProcessOperationNumbers();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getResponsibleProcessOperationNumbers);

        if(responsibleOperationNumbersList->length() == 0)
        {
            PPT_METHODTRACE_V1("", "responsibleOperationNumber is not found.");
            SET_MSG_RC(strAPCProcessHistory_Get_out,
                       MSG_NOT_FOUND_PROHS,
                       RC_NOT_FOUND_PROHS);

            return( RC_NOT_FOUND_PROHS );
        }

        PPT_METHODTRACE_V2("", "Responsible Operation Number", (*responsibleOperationNumbersList)[0]);

        CORBA::Long nLenResPO = responsibleOperationNumbersList->length();
        PosProcessOperation_var aResponsiblePO;
        PosProcessOperation_var aCorrespondingPO;

        if(nLenResPO > 0)
        {
            try
            {
                aResponsiblePO = aPFX->findProcessOperationForOperationNumberBefore((*responsibleOperationNumbersList)[0]);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessFlowContext::findProcessOperationForOperationNumberBefore);
        }

        if(CORBA::is_nil(aResponsiblePO) == FALSE)
        {
            aCorrespondingPO = aResponsiblePO;

            PPT_METHODTRACE_V1("", "is_nil(aCorrespondingPO) != TRUE");
            strAPCLotHistoryList.length(1);

            //---------------------------------------------
            //   set lotID in ControlMonitorGroup
            //---------------------------------------------
            PPT_METHODTRACE_V2("", "Lot is ...", lotID.identifier);
            strAPCLotHistoryList[SetCnt].lotID = lotID;

            //---------------------------------------------
            //   set EquipmentID in CorrespondingPO
            //---------------------------------------------
            PosMachine_var  aMachine;
            try
            {
                aMachine = aCorrespondingPO->getAssignedMachine();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getAssignedMachine);

            if ( CORBA::is_nil(aMachine) == TRUE )
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil(aMachine)")
                PPT_SET_MSG_RC_KEY(strAPCProcessHistory_Get_out,
                                   MSG_NOT_FOUND_EQP,
                                   RC_NOT_FOUND_EQP,
                                   "");

                return( RC_NOT_FOUND_EQP );
            }

            try
            {
                strAPCLotHistoryList[SetCnt].equipmentID.identifier = aMachine->getIdentifier();
                PPT_METHODTRACE_V2("", "Equipment is ...", strAPCLotHistoryList[SetCnt].equipmentID.identifier);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getIdentifier);

            //---------------------------------------------
            //   set RecipeID in CorrespondingPO
            //---------------------------------------------
            PosMachineRecipe_var  aRecipe;
            try
            {
                aRecipe = aCorrespondingPO->getAssignedMachineRecipe();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getAssignedMachineRecipe);

            if ( CORBA::is_nil(aRecipe) == TRUE )
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil(aRecipe)")

                SET_MSG_RC(strAPCProcessHistory_Get_out,
                           MSG_NOT_FOUND_MCRECIPE,
                           RC_NOT_FOUND_MCRECIPE );

                return( RC_NOT_FOUND_MCRECIPE );
            }

            try
            {
                strAPCLotHistoryList[SetCnt].recipeID.identifier = aRecipe->getIdentifier();
                PPT_METHODTRACE_V2("", "Recipe is ...", strAPCLotHistoryList[SetCnt].recipeID.identifier);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosMachineRecipe::getIdentifier);

            //---------------------------------------------
            //   set operationID in CorrespondingPO
            //---------------------------------------------
            PosProcessDefinition_var aProcessDefinition;
            try
            {
                aProcessDefinition = aCorrespondingPO->getProcessDefinition() ;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getProcessDefinition)

            if ( CORBA::is_nil(aProcessDefinition) == TRUE )
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil(aProcessDefinition)")
                PPT_SET_MSG_RC_KEY(strAPCProcessHistory_Get_out,
                                   MSG_NOT_FOUND_PD,
                                   RC_NOT_FOUND_PD,
                                   "");

                return( RC_NOT_FOUND_PD );
            }

            try
            {
                strAPCLotHistoryList[SetCnt].operationID.identifier = aProcessDefinition->getIdentifier() ;
                PPT_METHODTRACE_V2("", "ProcessDefinition is ...", strAPCLotHistoryList[SetCnt].operationID.identifier);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessDefinition::getIdentifier)
            //---------------------------------------------
            //   increase Count
            //---------------------------------------------
            SetCnt ++;
        }

        PPT_METHODTRACE_V2("", "Set Count ...", SetCnt);
        if( SetCnt == 0 )
        {
            PPT_METHODTRACE_V2("", "No Process History ...", SetCnt);
            SET_MSG_RC(strAPCProcessHistory_Get_out,
                       MSG_NOT_FOUND_PROHS,
                       RC_NOT_FOUND_PROHS ) ;

            return( RC_NOT_FOUND_PROHS );
        }

        strAPCLotHistoryList.length( SetCnt );

        strAPCProcessHistory_Get_out.strAPCLotHistoryList = strAPCLotHistoryList;

        SET_MSG_RC(strAPCProcessHistory_Get_out,
                   MSG_OK, RC_OK);

        PPT_METHODTRACE_EXIT("PPTManager_i::APCProcessHistory_Get");

        return ( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS(strAPCProcessHistory_Get_out, APCProcessHistory_Get, methodName);
}
