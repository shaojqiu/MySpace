#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/APCMgr_GetServiceManager.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:16:58 [ 7/13/07 19:16:59 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: APCMgr_GetServiceManager.cpp
//

#include "pptmgr.hpp"
#include "mqsm.hh"

//[Object Function Name]: long  APCMgr_GetServiceManager
//
// Date        Level    Author         Note
// ----------  -------  -------------  -------------------------------------------
// 2004/07/08  D51M0000 M.Mori         Initial Release (R51M)
// 2004/11/17  D6000025 K.Murakami     Change CORBA::string to CORBA::String
//                                     Add SP_STRING_TO_OBJECT for eBroker
// 2004/11/18  D6000025 K.Murakami     Change CORBA::IT_chooseDefaultEnv() to SP_CORBAENV_DEFENV
// 2004/11/25  D6000025 K.Murakami     Add SP_GET_OBJECT_WITH_ENV for eBroker
//                                     Add IMRegistry::orbPtr->object_to_string() for eBroker
// 2005/05/09  D6000275 M.Murata       Change Bind to GenIOR to get proxy object of MQTxHandler for HAS.(APC FDC Backbone)
// 2005/05/10  P6000466 M.Murata       Change bind() to object_to_string()
// 2005/05/11  D6000314 M.Murata       Add temporary variable for extarnalServerList.
// 2005/05/11  P6000467 K.Murakami     Change SP_GET_OBJECT_WITH_ENV to IMRegistry::orbPtr->object_to_string()
//
// Date        Level         Author         Note
// ----------  ------------  -------------  -------------------------------------------
// 2011/10/13  DSN000022130  S.Kawabe       IOR Support
//
// [Function Description]:
//
// [Input Parameters]:
//    in string     APCServerName
//    in string     APCHostName
//
// [Output Parameters]:
//
//    out objAPCMgr_GetServiceManager_out   strAPCMgr_GetServiceManager_out
//
//    typedef struct objAPCMgr_GetServiceManager_out_struct {
//        pptRetCode                strResult;
//        string                    APCSvcMgr;
//        any                       siInfo;
//    } objAPCMgr_GetServiceManager_out;
//
// [Return Value]:
//
//  Return Code                 Messsage ID
//  -------------------------   --------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_SYSTEM_ERROR             MSG_SYSTEM_ERROR
//  RC_APC_SERVER_BIND_FAIL     MSG_APC_SERVER_BIND_FAIL
//  RC_APC_SERVER_NIL_OBJ       MSG_APC_SERVER_NIL_OBJ

CORBA::Long PPTManager_i:: APCMgr_GetServiceManager(
    objAPCMgr_GetServiceManager_out&        strAPCMgr_GetServiceManager_out,
    const pptObjCommonIn&                   strObjCommonIn,
    const char *                            APCServerName,
    const char *                            APCHostName)
{

    CORBA::Long rc = RC_OK;
    char * methodName = NULL;

    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i:: APCMgr_GetServiceManager");
        MQSvcMgr_var APCSvcMgr = MQSvcMgr::_nil();

//D6000275 Add Start
        //---------------------------------------------
        // Get Environment for GenIOR                  
        //---------------------------------------------
        CORBA::String_var APCHostNameForGenIOR   = CIMFWStrDup(getenv(SP_APCHostName_ForGenIOR)  );
        CORBA::String_var APCServerNameForGenIOR = CIMFWStrDup(getenv(SP_APCServerName_ForGenIOR));
        CORBA::String_var APCMarkerNameForGenIOR = CIMFWStrDup(getenv(SP_APCMarkerName_ForGenIOR));
        CORBA::String_var APCPortNoForGenIOR     = CIMFWStrDup(getenv(SP_APCPortNo_ForGenIOR)    );

        CORBA::String_var tmpAPCServerName;
#ifdef EBROKER                                                    //D6000314
        tmpAPCServerName = CIMFWStrDup(APCServerName);            //D6000314
#else                                                             //D6000314
        tmpAPCServerName = CIMFWStrDup(getenv(SP_APCServerName_ForGenIOR));
        PPT_METHODTRACE_V1("","//-- Get Environment For GenIOR --//");
        PPT_METHODTRACE_V2("","  APCHostNameForGenIOR   ---> ", APCHostNameForGenIOR  );
        PPT_METHODTRACE_V2("","  APCServerNameForGenIOR ---> ", APCServerNameForGenIOR);
        PPT_METHODTRACE_V2("","  APCMarkerNameForGenIOR ---> ", APCMarkerNameForGenIOR);
        PPT_METHODTRACE_V2("","  APCPortNoForGenIOR     ---> ", APCPortNoForGenIOR    );
//D6000275 Add End
#endif                                                            //D6000314

        CORBA::String_var BindEverytimeFlg = CIMFWStrDup(getenv(SP_BindEverytime_APC));
        PPT_METHODTRACE_V2("","BindEverytimeFlg ---> ",BindEverytimeFlg);

        CORBA::Boolean bExecBind = FALSE;

        if ( CIMFWStrCmp(getenv(SP_BindEverytime_APC), "1") == 0 )
        {
            /*--------------------*/
            /*   Everytime Bind   */
            /*--------------------*/
            PPT_METHODTRACE_V1("","/*--------------------*/");
            PPT_METHODTRACE_V1("","/*   Everytime Bind   */");
            PPT_METHODTRACE_V1("","/*--------------------*/");

            bExecBind = TRUE;
        }

        if ( FALSE == bExecBind )
        {
            /*----------------------------*/
            /*   Search Service Manager   */
            /*----------------------------*/
            PPT_METHODTRACE_V1("","/*----------------------------*/");
            PPT_METHODTRACE_V1("","/*   Search Service Manager   */");
            PPT_METHODTRACE_V1("","/*----------------------------*/");

            CORBA::Boolean existFlag = FALSE;
            //D6000025char* objRef = CORBA::string(NULL);
            char* objRef = CORBA::String(NULL);  //D6000025
            try
            {
//D6000275                existFlag = externalServerList.find((char*)APCServerName, objRef);
                existFlag = externalServerList.find((char*)tmpAPCServerName, objRef);    //D6000275
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "externalServerList.find() raises exception");
                SET_MSG_RC(strAPCMgr_GetServiceManager_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
                return(RC_SYSTEM_ERROR);
            }
            if ( existFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "existFlag == TRUE...");
                CORBA::Object_var tmpAPC = CORBA::Object::_nil();
                try
                {
#ifdef EBROKER         //D6000025
                    tmpAPC = SP_STRING_TO_OBJECT(objRef);   //D6000025
#else                  //D6000025
                    tmpAPC = CORBA::Orbix.string_to_object(objRef);
#endif                 //D6000025
                }
                catch(...)
                {
                    PPT_METHODTRACE_V1("", "CORBA::Orbix.string_to_object() raises exception");
                    SET_MSG_RC(strAPCMgr_GetServiceManager_out, MSG_APC_SERVER_BIND_FAIL, RC_APC_SERVER_BIND_FAIL);
                    try
                    {
//D6000275                        externalServerList.remove((char *)APCServerName);
                        existFlag = externalServerList.remove((char*)tmpAPCServerName);    //D6000275
                    }
                    catch( ... )
                    {
                        PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                    }
                    return(RC_APC_SERVER_BIND_FAIL);
                }
                if (CORBA::is_nil(tmpAPC) == TRUE)
                {
                    PPT_METHODTRACE_V1("", "CORBA::is_nil(tmpAPC) == TRUE");
                    SET_MSG_RC(strAPCMgr_GetServiceManager_out, MSG_APC_SERVER_BIND_FAIL, RC_APC_SERVER_BIND_FAIL);

                    try
                    {
//D6000275                        externalServerList.remove((char *)APCServerName);
                        existFlag = externalServerList.remove((char*)tmpAPCServerName);    //D6000275
                    }
                    catch( ... )
                    {
                        PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                    }
                    return(RC_APC_SERVER_BIND_FAIL);
                }
                APCSvcMgr = MQSvcMgr::_narrow(tmpAPC);
            }
            else
            {
                bExecBind = TRUE;
            }
        }

        //D6000025CORBA::Environment envTimeOut = CORBA::IT_chooseDefaultEnv();
        CORBA::Environment envTimeOut = SP_CORBAENV_DEFENV;        //D6000025
        CORBA::String_var timeOutValue = CIMFWStrDup(getenv(SP_TX_Timeout_APC));
        PPT_METHODTRACE_V2("","timeOutValue ---> ", timeOutValue);

        if( 0 < CIMFWStrLen(timeOutValue) )
        {
            PPT_METHODTRACE_V1("", "setting timeout!!");
            envTimeOut.timeout(atol(timeOutValue) * 1000);
        }

        if ( TRUE == bExecBind )
        {
            /*--------------------------*/
            /*   Bind Service Manager   */
            /*--------------------------*/
//D6000275            PPT_METHODTRACE_V1("","/*--------------------------*/");
//D6000275            PPT_METHODTRACE_V1("","/*   Bind Service Manager   */");
//D6000275            PPT_METHODTRACE_V1("","/*--------------------------*/");
            PPT_METHODTRACE_V1("","//-----------------------------");    //D6000275
            PPT_METHODTRACE_V1("","// Generate Object Reference   ");    //D6000275
            PPT_METHODTRACE_V1("","//-----------------------------");    //D6000275

            CORBA::String_var newObjRef;
            try
            {
#ifdef EBROKER                                                                                          //D6000025 
                CORBA::String_var APCIOR = CIMFWStrDup(getenv("APC_IOR"));                              //DSN000022130
                if( CIMFWStrLen(APCIOR) == 0 )                                                          //DSN000022130
                {                                                                                       //DSN000022130
                    PPT_METHODTRACE_V1("", "APC_IOR is not setting.");                                  //DSN000022130
                    SP_GET_OBJECT_WITH_ENV(APCSvcMgr, APCServerName, APCHostName, MQSvcMgr, envTimeOut);    //D6000025
                }                                                                                       //DSN000022130
                else                                                                                    //DSN000022130
                {                                                                                       //DSN000022130
                    PPT_METHODTRACE_V1("", "APC_IOR is setting.");                                      //DSN000022130
                    SP_GET_OBJECT_FOR_IOR_WITH_ENV(APCSvcMgr, APCIOR, MQSvcMgr, envTimeOut);            //DSN000022130
                }                                                                                       //DSN000022130
#else  
//D6000275                APCSvcMgr = MQSvcMgr::_bind( APCServerName, APCHostName, envTimeOut );                  //D6000025
//D6000275 Add Start
                CORBA::String_var APC_ior = genIOR( (char*)APCHostNameForGenIOR,
                                                    APCPortNoForGenIOR,
                                                    APCServerNameForGenIOR,
                                                    APCMarkerNameForGenIOR,
                                                    "MQSvcMgr");

                CORBA::Object_var anobj = sp_string_to_object( APC_ior );
                APCSvcMgr = MQSvcMgr::_narrow( anobj );
                if (CORBA::is_nil(APCSvcMgr) != TRUE)
                {
                    CORBA::String_var strCheckExistenceFlag = CIMFWStrDup(getenv( SP_CheckExistenceFlag ));
                    PPT_METHODTRACE_V2("", "SP_CheckExistenceFlag ---> ", strCheckExistenceFlag );
                    if( CIMFWStrCmp(strCheckExistenceFlag, "1" ) == 0 || CIMFWStrLen(strCheckExistenceFlag) == 0 )
                    {
                        //------------------------------------------
                        // Check existent 0:existent 1:non-existent 
                        //------------------------------------------
                        PPT_METHODTRACE_V1("", "Check existent  0:existent 1:non-existent ");
                        CORBA::Boolean nonExistenceFlag = APCSvcMgr->_non_existent( envTimeOut );
                        PPT_METHODTRACE_V2("","_non_existent ---> ", nonExistenceFlag);
                        if( nonExistenceFlag != 0 )
                        {
                            PPT_METHODTRACE_V1("", "non-existent....");
                            SET_MSG_RC(strAPCMgr_GetServiceManager_out, MSG_APC_SERVER_BIND_FAIL, RC_APC_SERVER_BIND_FAIL);
                            return(RC_APC_SERVER_BIND_FAIL);
                        }
                    }
                }
//D6000275 Add End
#endif
            }
            catch(const CORBA::SystemException &SysEx)
            {
                PPT_METHODTRACE_V1("", "APCSERVER::_bind() raises system exception");
                PPT_METHODTRACE_V1("", SysEx);
                APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
                SET_MSG_RC(strAPCMgr_GetServiceManager_out, MSG_APC_SERVER_BIND_FAIL, RC_APC_SERVER_BIND_FAIL);
                return(RC_APC_SERVER_BIND_FAIL);
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "APCSERVER::_bind() raises unknown exception");
                APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ();
                SET_MSG_RC(strAPCMgr_GetServiceManager_out, MSG_APC_SERVER_BIND_FAIL, RC_APC_SERVER_BIND_FAIL);
                return(RC_APC_SERVER_BIND_FAIL);
            }
            if (CORBA::is_nil(APCSvcMgr) == TRUE)
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil(APCSvcMgr) == TRUE");
                SET_MSG_RC(strAPCMgr_GetServiceManager_out, MSG_APC_SERVER_NIL_OBJ, RC_APC_SERVER_NIL_OBJ);
                return(RC_APC_SERVER_NIL_OBJ);
            }
            try
            {
#ifdef EBROKER                                                                                          //D6000025
//P6000467                SP_GET_OBJECT_WITH_ENV(APCSvcMgr, APCServerName, APCHostName, MQSvcMgr, envTimeOut);    //D6000025
                newObjRef = IMRegistry::orbPtr->object_to_string(APCSvcMgr);                            //P6000467
#else                                                                                                   //D6000025
//P6000466                APCSvcMgr = MQSvcMgr::_bind( APCServerName, APCHostName, envTimeOut );
                newObjRef = APCSvcMgr->_object_to_string();                                             //P6000466
#endif                                                                                                  //D6000025
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "APCSvcMgr->_object_to_string() raises exception");
                SET_MSG_RC(strAPCMgr_GetServiceManager_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
                return(RC_SYSTEM_ERROR);
            }
            try
            {
                PPT_METHODTRACE_V1("", "externalServerList.remove()");
                try
                {
//D6000275                    externalServerList.remove((char *)APCServerName);
                    externalServerList.remove((char*)tmpAPCServerName);    //D6000275
                }
                catch( ... )
                {
                    PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                }

        //The following comments are mistakes.
        //It does not MemoryLeak, if it remove same member after adding.
                //About 2nd parameter, CIMFWStrDup(newObjRef) makes memory-leak, but it will be
                //happened when stopping mmserver, so CIMFWStrDup(newObjRef) can be used.
                //When 1st and 2nd parameters are same valiable case, CIMFWStrDup should not be
                //used for 2nd parameter.
//D6000275                externalServerList.add(CIMFWStrDup(APCServerName), CIMFWStrDup(newObjRef));
                PPT_METHODTRACE_V2("", "externalServerList.add()", tmpAPCServerName);             //D6000275
                externalServerList.add(CIMFWStrDup(tmpAPCServerName), CIMFWStrDup(newObjRef));    //D6000275
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "externalServerList.add() raises exception");
                SET_MSG_RC(strAPCMgr_GetServiceManager_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
                return(RC_SYSTEM_ERROR);
            }
        }

        /*--------------------------*/
        /*   set output parameter   */
        /*--------------------------*/
        try
        {
#ifdef EBROKER                                                                                            //D6000025
            strAPCMgr_GetServiceManager_out.APCSvcMgr = IMRegistry::orbPtr->object_to_string(APCSvcMgr);  //D6000025
#else                                                                                                     //D6000025
            strAPCMgr_GetServiceManager_out.APCSvcMgr = APCSvcMgr->_object_to_string();
#endif                                                                                                    //D6000025
        }
        catch(...)
        {
            PPT_METHODTRACE_V1("", "APCSvcMgr->_object_to_string() raises exception");
            SET_MSG_RC(strAPCMgr_GetServiceManager_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
            return(RC_SYSTEM_ERROR);
        }

        SET_MSG_RC( strAPCMgr_GetServiceManager_out, MSG_OK, RC_OK);
        PPT_METHODTRACE_EXIT("PPTManager_i:: APCMgr_GetServiceManager");
        return(RC_OK);
    }
    CATCH_GLOBAL_EXCEPTIONS(strAPCMgr_GetServiceManager_out, strObjCommonIn, methodName);
}

