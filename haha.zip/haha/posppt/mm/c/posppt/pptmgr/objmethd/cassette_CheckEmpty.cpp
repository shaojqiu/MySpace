#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_CheckEmpty.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:32:53 [ 7/13/07 19:32:54 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_CheckEmpty.cpp
//

#include "pptmgr.hpp"
#include "timstamp.hpp"
#include "duration.hpp"

#include "pcas.hh"
#include "plot.hh"
#include "pperson.hh"
#include "pstmc.hh"
#include "pmc.hh"
#include "pbufrs.hh"
#include "pmaloc.hh"
//D5000016 #include "ppcgrp.hh"

// Class: PPTManager
//
// Service: cassette_CheckEmpty()
//
// Change history:
// Date     Defect#  Person         Comments
// -------- -------- -------------- -------------------------------------------
// 2003/05/19 D5000016 K.Kido         Useless class deletion.
//
// Description:
//
// Return:
//     Long
//
// Parameter:
//    const pptObjCommonIn& strObjCommonIn
//    const objectIdentifier& cassetteID
//    objCassette_CheckEmpty_out& strCassette_CheckEmpty_out
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long PPTManager_i::cassette_CheckEmpty(objCassette_CheckEmpty_out& strCassette_CheckEmpty_out, const pptObjCommonIn& strObjCommonIn, const objectIdentifier& cassetteID)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_CheckEmpty");
        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR(aCassette, cassetteID, strCassette_CheckEmpty_out,
                                              cassette_CheckEmpty);

        CORBA::Boolean anIsEmpty;
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            anIsEmpty = aCassette->isEmpty();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isEmpty)

        if (anIsEmpty == TRUE)
        {
            PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckEmpty","anIsEmpty == TRUE");
            PPT_METHODTRACE_EXIT("PPTManager_i::cassette_CheckEmpty");
            return RC_OK;
        }
        else
        {
            PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckEmpty","anIsEmpty != TRUE");
            PPT_SET_MSG_RC_KEY(strCassette_CheckEmpty_out, MSG_CAST_NOT_EMPTY, RC_CAST_NOT_EMPTY,
                               cassetteID.identifier);
            PPT_METHODTRACE_EXIT("PPTManager_i::cassette_CheckEmpty");
            return RC_CAST_NOT_EMPTY;
        }
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_CheckEmpty_out, cassette_CheckEmpty, methodName)
}

