//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2012. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2012. All rights reserved.
//
// SiView
// Name: advanced_object_Lock.cpp
//

#include "pptmgr.hpp"
#include "pmc.hh"
#include "plot.hh"      //DSN000050720
#include "pcas.hh"      //DSN000050720
#include "pflwbch.hh"   //DSN000050720
#include "pmongrp.hh"   //DSN000050720

// For time when supported other class, the lock logic of the main object becomes the macro
#define PPT_MAINOBJ_LOCK(theMainObject)\
{\
    PPT_METHODTRACE_V1("", "MainObject");\
    try\
    {\
        /* Call TxLockMainObject() of the main object. */ \
        PPT_METHODTRACE_V1("","Advanced_Lock_MainObject: Lock Start..."); \
        retState = theMainObject->TxLockMainObject(lockType); \ 
    }\
    /* If catch MFGBOS_UnableToObtainTxnLoc exception, return RC_LOCKED_BY_ANOTHER. */ \
    catch( MFGBOS_UnableToObtainTxnLock )\
    {\
        PPT_METHODTRACE_V1("","Advanced_Lock_MainObject: Catch MFGBOS_UnableToObtainTxnLock Exception"); \
        PPT_SET_MSG_RC_KEY( strAdvanced_object_Lock_out, MSG_OBJECT_LOCKED_BY_ANOTHER, RC_LOCKED_BY_ANOTHER, objectID.identifier );\
        return( RC_LOCKED_BY_ANOTHER );\
    }\
    CATCH_AND_RAISE_EXCEPTIONS(PosMachine::TxLockMainObject)\
    /* If return state is not OK and is not LockAlreadyHeld, return RC_CANNOT_LOCK_OBJECT */ \
    if ( retState != MOFW_TransactionalObject::OK && retState != MOFW_TransactionalObject::LockAlreadyHeld )\
    {\
        PPT_METHODTRACE_V2("","Advanced_Lock_MainObject: TxnLock Failed", retState); \
        SET_MSG_RC( strAdvanced_object_Lock_out, MSG_CANNOT_LOCK_OBJECT, RC_CANNOT_LOCK_OBJECT );\
        return( RC_CANNOT_LOCK_OBJECT );\
    }\
    PPT_METHODTRACE_V1("","Advanced_Lock_MainObject: Lock Completed..."); \
}

// For time when supported other class, the lock logic of the element becomes the macro
#define PPT_ELEMENT_LOCK(theMainObject)\
{\
    PPT_METHODTRACE_V2("", "Element", objectType);\
    resultInfo_var resultInfo;\
    /* Count lock */ \
    if ( lockType == SP_ObjectLock_LockType_COUNT )\
    {\
        try\
        {\
            /* Call TxLockElements() of the main object.                        */ \
            /* When execute count lock, in keySeq argument, specify empty data. */ \
            PPT_METHODTRACE_V2("","Advanced_Lock_Element_Count: Lock Start...", objectType); \
            resultInfo = theMainObject->TxLockElements(lockType, objectType, dummySeq);\
        }\
        /* If catch MFGBOS_UnableToObtainTxnLoc exception, return RC_LOCKED_BY_ANOTHER. */ \
        catch( MFGBOS_UnableToObtainTxnLock )\
        {\
            PPT_METHODTRACE_V1("","Advanced_Lock_Element_Count: Catch MFGBOS_UnableToObtainTxnLock Exception"); \
            PPT_SET_MSG_RC_KEY( strAdvanced_object_Lock_out, MSG_OBJECT_LOCKED_BY_ANOTHER, RC_LOCKED_BY_ANOTHER, objectID.identifier );\ 
            return( RC_LOCKED_BY_ANOTHER );\
        }\
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::TxLockElements)\
    }\
    /* Other than Count lock, do nothing when keySeq is 0.                     */ \
    /* (It becomes Count rock if specify 0 keySeq and execute TxLockElements.) */ \
    else if ( 0 < keySeq.length() )\
    {\
        try\
        {\
            /* Call TxLockElements() of the main object. */ \
            PPT_METHODTRACE_V2("","Advanced_Lock_Element: Lock Start...", objectType); \
            resultInfo = theMainObject->TxLockElements(lockType, objectType, keySeq);\
        }\
        /* If catch MFGBOS_UnableToObtainTxnLoc exception, return RC_LOCKED_BY_ANOTHER. */ \
        catch( MFGBOS_UnableToObtainTxnLock )\ 
        {\
            PPT_METHODTRACE_V1("","Advanced_Lock_Element: Catch MFGBOS_UnableToObtainTxnLock Exception"); \
            PPT_SET_MSG_RC_KEY( strAdvanced_object_Lock_out, MSG_OBJECT_LOCKED_BY_ANOTHER, RC_LOCKED_BY_ANOTHER, objectID.identifier );\ 
            return( RC_LOCKED_BY_ANOTHER );\
        }\
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::TxLockElements)\
    }\
    else if ( 0 == keySeq.length() )\
    {\
        SET_MSG_RC( strAdvanced_object_Lock_out, MSG_OK, RC_OK ); \
        PPT_METHODTRACE_EXIT("PPTManager_i::advanced_object_Lock"); \
        return RC_OK; \
    }\
    if ( NULL == resultInfo)\
    {\
        PPT_METHODTRACE_V2("","Advanced_Lock_Element: TxLockElements Failed", "resultInfo is nil"); \
        SET_MSG_RC(strAdvanced_object_Lock_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);\
        return RC_SYSTEM_ERROR;\
    }\
    /* If return code is ElementNotFound, return RC_NOT_FOUND_SOME_OBJECT */ \
    else if ( CIMFW_ElementLock::ElementNotFound == resultInfo->returnCode )\
    {\
        PPT_METHODTRACE_V2("","Advanced_Lock_Element: TxLockElements Failed", "ElementNotFound"); \
        strAdvanced_object_Lock_out.notFoundkeys = resultInfo->infoKeys; \
        PPT_SET_MSG_RC_KEY2( strAdvanced_object_Lock_out, MSG_NOT_FOUND_SOME_OBJECT, RC_NOT_FOUND_SOME_OBJECT, objectType, objectID.identifier );\
        return( RC_NOT_FOUND_SOME_OBJECT );\
    }\
    /* If return code is not OK and is not LockAlreadyHeld, return RC_CANNOT_LOCK_OBJECT */ \
    else if ( CIMFW_ElementLock::OK != resultInfo->returnCode && CIMFW_ElementLock::LockAlreadyHeld != resultInfo->returnCode )\
    {\
        PPT_METHODTRACE_V2("","Advanced_Lock_Element: TxLockElements Failed", resultInfo->returnCode); \
        SET_MSG_RC( strAdvanced_object_Lock_out, MSG_CANNOT_LOCK_OBJECT, RC_CANNOT_LOCK_OBJECT );\
        return( RC_CANNOT_LOCK_OBJECT );\
    }\
    PPT_METHODTRACE_V1("","Advanced_Lock_Element: Lock Completed..."); \
}

//DSN000050720 Add Start
// For time when supported other class, the lock logic of the object becomes the macro
#define PPT_OBJ_LOCK(theObject)\
{\
    PPT_METHODTRACE_V1("", "Object");\
    try\
    {\
        /* Call TxLockMainObject() of the main object. */ \
        retState = theObject->TxnLock(MOFW_TransactionalObject::im_read, theLockTimeout); \ 
    }\
    /* If catch MFGBOS_UnableToObtainTxnLoc exception, return RC_LOCKED_BY_ANOTHER. */ \
    catch( MFGBOS_UnableToObtainTxnLock )\
    {\
        PPT_METHODTRACE_V1("","Advanced_Lock_Object: Catch MFGBOS_UnableToObtainTxnLock Exception"); \
        PPT_SET_MSG_RC_KEY( strAdvanced_object_Lock_out, MSG_OBJECT_LOCKED_BY_ANOTHER, RC_LOCKED_BY_ANOTHER, objectID.identifier );\
        return( RC_LOCKED_BY_ANOTHER );\
    }\
    CATCH_AND_RAISE_EXCEPTIONS(PosMachine::TxnLock)\
    /* If return state is not OK and is not LockAlreadyHeld, return RC_CANNOT_LOCK_OBJECT */ \
    if ( retState != MOFW_TransactionalObject::OK && retState != MOFW_TransactionalObject::LockAlreadyHeld )\
    {\
        PPT_METHODTRACE_V2("","Advanced_Lock_Object: TxnLock Failed", retState); \
        SET_MSG_RC( strAdvanced_object_Lock_out, MSG_CANNOT_LOCK_OBJECT, RC_CANNOT_LOCK_OBJECT );\
        return( RC_CANNOT_LOCK_OBJECT );\
    }\
    PPT_METHODTRACE_V1("","Advanced_Lock_MainObject: Lock Completed..."); \
}
//DSN000050720 Add End

// Class: PPTManager
//
// Service: advanced_object_Lock()
//
// Change history:
// Date        Level        Author         Note
// ----------  ------------ -------------  -------------------------------------------
// 2012/12/03  DSN000049350 F.Chen         Initial release.
// 2013/01/28  DSN000050720 M.Ogawa        Support PosLot/PosCassette/PosMonitorGroup/PosFlowBatch
//
// Description:
//    This function locks object by specified lock type.
//
// Return:
//    Long
//
//    Return Code                  Messsage ID
//    ---------------------------- --------------------------------------------------
//    RC_OK                        MSG_OK
//    RC_INVALID_INPUT_PARM        MSG_INVALID_INPUT_PARM
//    RC_CANNOT_LOCK_OBJECT        MSG_CANNOT_LOCK_OBJECT
//    RC_LOCKED_BY_ANOTHER         MSG_OBJECT_LOCKED_BY_ANOTHER
//    RC_NOT_FOUND_SOME_OBJECT     MSG_NOT_FOUND_SOME_OBJECT
//    RC_SYSTEM_ERROR              MSG_SYSTEM_ERROR
//
// Parameter:
//
//    objAdvanced_object_Lock_out&       strAdvanced_object_Lock_out
//    const pptObjCommonIn&              strObjCommonIn
//    const objAdvanced_object_Lock_in&  strAdvanced_object_Lock_in
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long PPTManager_i:: advanced_object_Lock (
    objAdvanced_object_Lock_out&       strAdvanced_object_Lock_out,
    const pptObjCommonIn&              strObjCommonIn,
    const objAdvanced_object_Lock_in&  strAdvanced_object_Lock_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::advanced_object_Lock");

        //----------------
        //  Initialize
        //----------------
        CORBA::Long rc = RC_OK;
        CORBA::Long retState = 0;
        stringSequence dummySeq;
        dummySeq.length(0);

        strAdvanced_object_Lock_out.notFoundkeys.length(0);

        //---------------------------------
        // Input Parameter
        //---------------------------------
        const objectIdentifier& objectID = strAdvanced_object_Lock_in.objectID;
        const char *className            = strAdvanced_object_Lock_in.className;
        const char *objectType           = strAdvanced_object_Lock_in.objectType;
        const CORBA::Long lockType       = strAdvanced_object_Lock_in.lockType;
        const stringSequence& keySeq     = strAdvanced_object_Lock_in.keySeq;

        PPT_METHODTRACE_V2("", "in-para objectID    ", objectID.identifier);
        PPT_METHODTRACE_V2("", "in-para className   ", className);
        PPT_METHODTRACE_V2("", "in-para objectType  ", objectType);
        PPT_METHODTRACE_V2("", "in-para lockType    ", lockType);

        //---------------------------
        //  Check input parameter
        //---------------------------
        // Check that there is specification of objectID, className and objectType
        // Check whether specification contents of lockType are valid.(WRITE, READ or COUNT)
        // Must not specify "COUNT" in lockType when specification of objectType is "MainObject"
        // If there is invalid parameter, return RC_INVALID_INPUT_PARM.
        if ( 0 == CIMFWStrLen( objectID.identifier )
          || 0 == CIMFWStrLen( className )
          || 0 == CIMFWStrLen( objectType )
          || ( lockType != SP_ObjectLock_LockType_WRITE
            && lockType != SP_ObjectLock_LockType_READ 
            && lockType != SP_ObjectLock_LockType_COUNT ) 
          || ( 0 == CIMFWStrCmp(objectType, SP_ObjectLock_ObjectType_MainObject) 
            && lockType == SP_ObjectLock_LockType_COUNT ) )
        {
            PPT_METHODTRACE_V1("", "Invalid input parameter.");
            SET_MSG_RC( strAdvanced_object_Lock_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        /*--------------------*/
        /*   For PosMachine   */
        /*--------------------*/
        if ( 0 == CIMFWStrCmp(className, SP_ClassName_PosMachine) )
        {
            PPT_METHODTRACE_V1("","className = SP_ClassName_PosMachine");
            /*--------------------------*/
            /*   Get Equipment Object   */
            /*--------------------------*/
            PosMachine_var anEquipment;
            PPT_CONVERT_EQPID_TO_MACHINE_OR( anEquipment, objectID, strAdvanced_object_Lock_out, advanced_object_Lock )

            // Main Object
            if ( 0 == CIMFWStrCmp(objectType, SP_ObjectLock_ObjectType_MainObject) )
            {
                //---------------------------
                //  Lock Main Object
                //---------------------------
                PPT_MAINOBJ_LOCK(anEquipment);
            }
            // LoadCassette or ProcessingLot or UserDefinedData
            else if ( 0 == CIMFWStrCmp(objectType, SP_ObjectLock_ObjectType_LoadCassette)
                   || 0 == CIMFWStrCmp(objectType, SP_ObjectLock_ObjectType_InProcessingLot)
                   || 0 == CIMFWStrCmp(objectType, SP_ObjectLock_ObjectType_UserDefinedData) )
            {
                //---------------------------
                //  Lock Element
                //---------------------------
                PPT_ELEMENT_LOCK(anEquipment);
            }
            // Other Object Type
            else
            {
                PPT_METHODTRACE_V2("", "The specified object type is invalid.", objectType);
            }

        } // if PosMachine
//DSN000050720 Add Start
        //---------------------------
        //   For PosLot
        //---------------------------
        else if( 0 == CIMFWStrCmp(className, SP_ClassName_PosLot) )
        {
            PPT_METHODTRACE_V1("","className = SP_ClassName_PosLot");
            //---------------------------
            //   Get Lot Object
            //---------------------------
            PosLot_var aLot;
            PPT_CONVERT_LOTID_TO_LOT_OR( aLot, objectID, strAdvanced_object_Lock_out, advanced_object_Lock )

            // Object
            if ( 0 == CIMFWStrCmp(objectType, SP_ObjectLock_ObjectType_Object) )
            {
                //---------------------------
                //  Lock Object
                //---------------------------
                PPT_OBJ_LOCK(aLot);
            }
            // Other Object Type
            else
            {
                PPT_METHODTRACE_V2("", "The specified object type is invalid.", objectType);
            }
        } // if PosLot  */
        //---------------------------
        //   For PosCassette
        //---------------------------
        else if ( 0 == CIMFWStrCmp(className, SP_ClassName_PosCassette) )
        {
            PPT_METHODTRACE_V1("","className = SP_ClassName_PosCassette");
            //---------------------------
            //   Get Cassette Object
            //---------------------------
            PosCassette_var aCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette, objectID, strAdvanced_object_Lock_out, advanced_object_Lock )

            // Object
            if ( 0 == CIMFWStrCmp(objectType, SP_ObjectLock_ObjectType_Object) )
            {
                //---------------------------
                //  Lock Main Object
                //---------------------------
                PPT_OBJ_LOCK(aCassette);
            }
            // Other Object Type
            else
            {
                PPT_METHODTRACE_V2("", "The specified object type is invalid.", objectType);
            }

        } // if PosCassette
        //---------------------------
        //   For PosMonitorGroup
        //---------------------------
        else if ( 0 == CIMFWStrCmp(className, SP_ClassName_PosMonitorGroup) )
        {
            PPT_METHODTRACE_V1("","className = SP_ClassName_PosMonitorGroup");
            //---------------------------
            //   Get MonitorGroup Object
            //---------------------------
            PosMonitorGroup_var aMonitorGroup;
            PPT_CONVERT_MONITORGRPID_TO_MONITORGRP_OR( aMonitorGroup, objectID, strAdvanced_object_Lock_out, advanced_object_Lock )

            // Object
            if ( 0 == CIMFWStrCmp(objectType, SP_ObjectLock_ObjectType_Object) )
            {
                //---------------------------
                //  Lock Main Object
                //---------------------------
                PPT_OBJ_LOCK(aMonitorGroup);
            }
            // Other Object Type
            else
            {
                PPT_METHODTRACE_V2("", "The specified object type is invalid.", objectType);
            }

        } // if PosMonitorGroup
        //---------------------------
        //   For PosFlowBatch
        //---------------------------
        else if ( 0 == CIMFWStrCmp(className, SP_ClassName_PosFlowBatch) )
        {
            PPT_METHODTRACE_V1("","className = SP_ClassName_PosFlowBatch");
            //---------------------------
            //   Get FlowBatch Object
            //---------------------------
            PosFlowBatch_var aFlowBatch;
            PPT_CONVERT_BATCHID_TO_FLWBATCH_OR( aFlowBatch, objectID, strAdvanced_object_Lock_out, advanced_object_Lock )

            // Object
            if ( 0 == CIMFWStrCmp(objectType, SP_ObjectLock_ObjectType_Object) )
            {
                //---------------------------
                //  Lock Object
                //---------------------------
                PPT_OBJ_LOCK(aFlowBatch);
            }
            // Other Object Type
            else
            {
                PPT_METHODTRACE_V2("", "The specified object type is invalid.", objectType);
            }

        } // if PosFlowBatch
//DSN000050720 Add End
        // Other Class Name
        else
        {
            PPT_METHODTRACE_V2("", "The specified class name is invalid.", className);
        }

        //----------------------
        //  Return to Caller
        //----------------------
        SET_MSG_RC( strAdvanced_object_Lock_out, MSG_OK, RC_OK );
        PPT_METHODTRACE_EXIT("PPTManager_i::advanced_object_Lock");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strAdvanced_object_Lock_out, advanced_object_Lock, methodName);
}

