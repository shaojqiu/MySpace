#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_usageLimitation_Check.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:37:14 [ 7/13/07 19:37:16 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_usageLimitation_Check.cpp
//

#include "pptmgr.hpp"
#include "timstamp.hpp"
#include "duration.hpp"

#include "pcas.hh"
#include "plot.hh"
#include "pperson.hh"
#include "pstmc.hh"
#include "pmc.hh"
#include "pbufrs.hh"
#include "pmaloc.hh"
//D5000016 #include "ppcgrp.hh"

// Class: PPTManager
//
// [Object Function Name]: long   cassette_usageLimitation_Check
//
//  Date       Level      Author         Note
//  ---------- ---------- -------------  -------------------------------------------
//  1999-06-25 0.00       Y.Iwasaki      Initial Release (DCR9900098) (R20)
//  1999-09-28 PTR9900241 Y.Iwasaki      Change unit of dulation from second to millisec. (R20b)
//  2000-03/21 PTR2200119 Y.Yamaguchi    Added unit of usage limit over into message
//  2000/09/12 P3000139   T.Yamano       SET_MSG_RC(MSG_OK,RC_OK) Comment Out
//  2000-10-25 PTR2300109 R.Furuta       Change used function.
//  2001-02-22 DCR3100032 Y.Yoshihara    Add interval between PM check logic
//                                       Remove runTime calcuration / check logic
//                                       * When all of limitation is 0, return RC_OK
//  2003/05/20 D5000016   K.Kido         Useless class deletion(R5.0).
//  2007/04/20 D9000001  M.Murata       64bit support.
//
//
// [Function Description]:
//   Check whether the following cassette's usage limitation is exceeded or not.
//
//   - Max run time
//   - Max start count
//   - Passage time from last PM   // D3100032
//
//
// [Input Parameters]:
//   in  pptObjCommonIn        strObjCommonIn;
//   in  objectIdentifier      cassetteID;
//
// [Output Parameters]:
//   out objCassette_usageLimitation_Check_out   strCassette_usageLimitation_Check_out;
//
//   typedef struct objCassette_usageLimitation_Check_out_struct {
//       pptRetCode            strResult;
//       objectIdentifier      cassetteID;
//       boolean               usageLimitOverFlag;
//       boolean               runTimeOverFlag;
//       boolean               startCountOverFlag;
//       long                  pmTimeOverFlag;        // D3100032
//       long                  runTime;
//       long                  maxRunTime;
//       long                  startCount;
//       long                  maxStartCount;
//       long                  passageTimeFromLastPM; // D3100032
//       long                  intervalBetweenPM;     // D3100032
//       string                messageText;
//   } objCassette_usageLimitation_Check_out;
//
//
// [Return Value]:
//
//   Return Code                 Messsage ID
//   --------------------------- ------------------------------------------------
//   RC_OK                       MSG_OK
//   RC_NOT_FOUND_CAST           MSG_NOT_FOUND_CAST
//   RC_LOCKED_BY_ANOTHER        MSG_LOCKED_BY_ANOTHER
//   RC_SYSTEM_ERROR             MSG_SYSTEM_ERROR
//
CORBA::Long PPTManager_i::cassette_usageLimitation_Check(
                          objCassette_usageLimitation_Check_out&  strCassette_usageLimitation_Check_out,
                          const pptObjCommonIn&                   strObjCommonIn,
                          const objectIdentifier&                 cassetteID )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_usageLimitation_Check");

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        strCassette_usageLimitation_Check_out.usageLimitOverFlag = FALSE;
        strCassette_usageLimitation_Check_out.runTimeOverFlag    = FALSE;
        strCassette_usageLimitation_Check_out.startCountOverFlag = FALSE;
        strCassette_usageLimitation_Check_out.pmTimeOverFlag     = FALSE;   // D3100032

//P3000139        SET_MSG_RC( strCassette_usageLimitation_Check_out, MSG_OK, RC_OK )

        /*-------------------------*/
        /*   Get Cassette Object   */
        /*-------------------------*/
        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR(aCassette, cassetteID, strCassette_usageLimitation_Check_out, cassette_usageLimitation_Check);
        PPT_SET_OBJECT_IDENTIFIER(strCassette_usageLimitation_Check_out.cassetteID, aCassette, strCassette_usageLimitation_Check_out, cassette_usageLimitation_Check, PosCassette);

        /*--------------------------*/
        /*   Get Usage Check Flag   */
        /*--------------------------*/
        try
        {
            CORBA::Long usageCheckRequiredFlag = aCassette->isUsageCheckRequired();
            if ( usageCheckRequiredFlag == FALSE )
            {
               return( RC_OK );
            }
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isUsageCheckRequired)

        /*--------------------------*/
        /*   Get Usage Limitation   */
        /*--------------------------*/
        try
        {
//D9000001            strCassette_usageLimitation_Check_out.maxRunTime = (long)( aCassette->getDurationLimit() / (60*1000) );
            strCassette_usageLimitation_Check_out.maxRunTime = (CORBA::Long)( aCassette->getDurationLimit() / (60*1000) );//D9000001
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getDulationLimit)

        try
        {
//P2300109  strCassette_usageLimitation_Check_out.startCount = aCassette->getTotalTimesUsed();
            strCassette_usageLimitation_Check_out.startCount = aCassette->timesUsed(); //P2300109
        }
//P2300109        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTotalTimesUsed)
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::timesUsed) //P2300109

        try
        {
            strCassette_usageLimitation_Check_out.maxStartCount = aCassette->getTimesUsedLimit();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTimesUsedLimit)


// D3100032 add start
        try                                                                                             
        {                                                                                               
            strCassette_usageLimitation_Check_out.intervalBetweenPM= aCassette->getIntervalBetweenPM(); 
        }                                                                                               
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getIntervalBetweenPM)                                   
    
        // if all limitation value is 0 , then no check return
        if( strCassette_usageLimitation_Check_out.maxRunTime        == 0 &&                            
            strCassette_usageLimitation_Check_out.maxStartCount     == 0 &&                            
            strCassette_usageLimitation_Check_out.intervalBetweenPM == 0 )                             
        {                                                                                             
          return(RC_OK);                                                                             
        }                                                                                           
// D3100032 add end

        /*-------------------------------------*/
        /*   Calcurate Run Time from Last PM   */
        /*-------------------------------------*/
        CORBA::String_var lastMaintTime;
        try
        {
            lastMaintTime = aCassette->getLastMaintenanceTimeStamp();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getLastMaintenanceTimeStamp)

        TimeStampImpl aTimeStamp( strObjCommonIn.strTimeStamp.reportTimeStamp );

        DurationImpl aDuration;
        aDuration = aTimeStamp.substractTimeStamp( lastMaintTime );
//      CORBA::Double tempElapsedTime = aDuration;                                  // Unit:seconds
        CORBA::Double tempElapsedTime = aDuration / 1000;                           // Unit:seconds  //PTR9900241 (R20b)
        // strCassette_usageLimitation_Check_out.runTime = (long)(tempElapsedTime/60); // Unit:minutes
        strCassette_usageLimitation_Check_out.runTime               = 0;                          // D3100032
//D9000001        strCassette_usageLimitation_Check_out.passageTimeFromLastPM = (long)(tempElapsedTime/60); // Unit:minutes // D3100032
        strCassette_usageLimitation_Check_out.passageTimeFromLastPM = (CORBA::Long)(tempElapsedTime/60); // Unit:minutes //D9000001

        /*--------------------------*/
        /*   Set Flag Information   */
        /*--------------------------*/
// D3100032 Delete Start
//      if ( strCassette_usageLimitation_Check_out.runTime >= strCassette_usageLimitation_Check_out.maxRunTime )
//      {
//          strCassette_usageLimitation_Check_out.usageLimitOverFlag = TRUE;
//          strCassette_usageLimitation_Check_out.runTimeOverFlag    = TRUE;
//      }
// D3100032 Delete Start

        if ( strCassette_usageLimitation_Check_out.startCount >= strCassette_usageLimitation_Check_out.maxStartCount )
        {
            strCassette_usageLimitation_Check_out.usageLimitOverFlag = TRUE;
            strCassette_usageLimitation_Check_out.startCountOverFlag = TRUE;
        }

// D3100032 add Start
        if ( strCassette_usageLimitation_Check_out.passageTimeFromLastPM       
                  >= strCassette_usageLimitation_Check_out.intervalBetweenPM )
        {                                                                    
            strCassette_usageLimitation_Check_out.usageLimitOverFlag = TRUE;
            strCassette_usageLimitation_Check_out.pmTimeOverFlag    = TRUE;
        }                                                                 
// D3100032 add Start

        PPT_METHODTRACE_V2("PPTManager_i::cassette_usageLimitation_Check", "cassetteID           ", strCassette_usageLimitation_Check_out.cassetteID.identifier)
        PPT_METHODTRACE_V2("PPTManager_i::cassette_usageLimitation_Check", "usageLimitOverFlag   ", (strCassette_usageLimitation_Check_out.usageLimitOverFlag ? "True" : "False") )
        PPT_METHODTRACE_V2("PPTManager_i::cassette_usageLimitation_Check", "runTimeOverFlag      ", (strCassette_usageLimitation_Check_out.runTimeOverFlag    ? "True" : "False") )
        PPT_METHODTRACE_V2("PPTManager_i::cassette_usageLimitation_Check", "startCountOverFlag   ", (strCassette_usageLimitation_Check_out.startCountOverFlag ? "True" : "False") )
        PPT_METHODTRACE_V2("PPTManager_i::cassette_usageLimitation_Check", "pmTimeOverFlag       ", (strCassette_usageLimitation_Check_out.pmTimeOverFlag? "True" : "False") ) // D3100032
        PPT_METHODTRACE_V2("PPTManager_i::cassette_usageLimitation_Check", "runTime              ", strCassette_usageLimitation_Check_out.runTime              )
        PPT_METHODTRACE_V2("PPTManager_i::cassette_usageLimitation_Check", "maxRunTime           ", strCassette_usageLimitation_Check_out.maxRunTime           )
        PPT_METHODTRACE_V2("PPTManager_i::cassette_usageLimitation_Check", "startCount           ", strCassette_usageLimitation_Check_out.startCount           )
        PPT_METHODTRACE_V2("PPTManager_i::cassette_usageLimitation_Check", "maxStartCount        ", strCassette_usageLimitation_Check_out.maxStartCount        )
        PPT_METHODTRACE_V2("PPTManager_i::cassette_usageLimitation_Check", "passageTimeFromLastPM",strCassette_usageLimitation_Check_out.passageTimeFromLastPM)              // D3100032
        PPT_METHODTRACE_V2("PPTManager_i::cassette_usageLimitation_Check", "intervalBetweenPM    ", strCassette_usageLimitation_Check_out.intervalBetweenPM    )             // D3100032

        /*-------------------------*/
        /*   Create Message Text   */
        /*-------------------------*/
        if ( strCassette_usageLimitation_Check_out.usageLimitOverFlag == TRUE )
        {

            PPT_METHODTRACE_V1("PPTManager_i::cassette_usageLimitation_Check", "usage limit over...")

            char     tmpMsg[1024];
            char     m1[] = "<<< Cassette Usage Limitation Over >>>";
            char     m2[] = "\n    Cassette ID        : ";
// D3100032 char     m3[] = "\n    Run Time (min)     : ";
// D3100032 char     m4[] = "\n    Max Run Time (min) : ";
            char     m5[] = "\n    Start Count        : ";
            char     m6[] = "\n    Max Start Count    : ";
            char     m7[] = "\n    Passage from PM    : ";              // D3100032
            char     m8[] = "\n    Interval for PM    : ";              // D3100032

            sprintf( tmpMsg, "%s%s%s%s%d%s%d%s%d%s%d",
                     m1,
                     m2, (const char*)(cassetteID.identifier),
// D3100032          m3, strCassette_usageLimitation_Check_out.runTime,
// D3100032          m4, strCassette_usageLimitation_Check_out.maxRunTime,
                     m5, strCassette_usageLimitation_Check_out.startCount,
                     m6, strCassette_usageLimitation_Check_out.maxStartCount ,
                     m7, strCassette_usageLimitation_Check_out.passageTimeFromLastPM, // D3100032
                     m8, strCassette_usageLimitation_Check_out.intervalBetweenPM );   // D3100032

            strCassette_usageLimitation_Check_out.messageText = CIMFWStrDup( tmpMsg );

        }

        /*----------------------*/
        /*   Return to Caller   */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_usageLimitation_Check");
        return( RC_OK );

    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_usageLimitation_Check_out, cassette_usageLimitation_Check, methodName)
}

