#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/backupChannelEvent_Make.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:28:40 [ 7/13/07 19:28:41 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: backupChannelEvent_Make.cpp
//

#include "pptmgr.hpp"
#include "pevbase.hh"

// Class: PPTManager
//
// Service: backupChannelEvent_Make()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2002/09/04 D4200062 K.Kimura       Initial : Backup Operation (R4.2)
//
// Description:
//
// Return:
//    long
//
// Parameter:
//    objBackupChannelEvent_Make_out& strBackupChannelEvent_Make_out
//    const pptObjCommonIn&           strObjCommonIn
//    const char *                    request
//    const pptBackupChannelSequence& strBackupChannelSeq
//    const char*                     claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long PPTManager_i::backupChannelEvent_Make(
    objBackupChannelEvent_Make_out& strBackupChannelEvent_Make_out,
    const pptObjCommonIn&           strObjCommonIn,
    const char *                    request,
    const pptBackupChannelSequence& strBackupChannelSeq,
    const char*                     claimMemo )
{
    char * methodName = NULL ;

    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::backupChannelEvent_Make") ;

        CORBA::Long eventLen = 0 ;
        eventLen = strBackupChannelSeq.length() ;

        //----------------//
        //   Initialize   //
        //----------------//
        posBackupChannelEventRecord anEventRecord ;

        for( CORBA::Long i = 0 ; i < eventLen ; i++ )
        {
            //---------------------//
            //    Put Event Data   //
            //---------------------//
            anEventRecord.request              = request ;
            anEventRecord.categoryLevel        = strBackupChannelSeq[i].strBackupUniqueChannel.categoryLevel ;
            anEventRecord.categoryID           = strBackupChannelSeq[i].strBackupUniqueChannel.categoryID ;
            anEventRecord.routeID              = strBackupChannelSeq[i].strBackupUniqueChannel.routeID ;
            anEventRecord.operationNumber      = strBackupChannelSeq[i].strBackupUniqueChannel.operationNumber ;
            anEventRecord.hostName             = strBackupChannelSeq[i].strBackupUniqueChannel.strBackupAddress.hostName ;
            anEventRecord.serverName           = strBackupChannelSeq[i].strBackupUniqueChannel.strBackupAddress.serverName ;
            anEventRecord.itDaemonPort         = strBackupChannelSeq[i].strBackupUniqueChannel.strBackupAddress.itDaemonPort ;
            anEventRecord.entryRouteID         = strBackupChannelSeq[i].strBackupUniqueChannel.strBackupProcess.entryRouteID ;
            anEventRecord.entryOperationNumber = strBackupChannelSeq[i].strBackupUniqueChannel.strBackupProcess.entryOperationNumber ;
            anEventRecord.exitRouteID          = strBackupChannelSeq[i].strBackupUniqueChannel.strBackupProcess.exitRouteID ;
            anEventRecord.exitOperationNumber  = strBackupChannelSeq[i].strBackupUniqueChannel.strBackupProcess.exitOperationNumber ;
            anEventRecord.state                = strBackupChannelSeq[i].state ;
            anEventRecord.startTime            = strBackupChannelSeq[i].startTime ;
            anEventRecord.endTime              = strBackupChannelSeq[i].endTime ;

            anEventRecord.eventCommon.transactionID  = strObjCommonIn.transactionID ;
            anEventRecord.eventCommon.userID         = strObjCommonIn.strUser.userID.identifier ;
            anEventRecord.eventCommon.eventTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp ;
            anEventRecord.eventCommon.eventShopDate  = strObjCommonIn.strTimeStamp.reportShopdate ;
            anEventRecord.eventCommon.eventMemo      = claimMemo;

            PPT_METHODTRACE_V1("","###Put Event Data###") ;
            PPT_METHODTRACE_V2("","strBackupChannelSeq[i]:",i) ;
            PPT_METHODTRACE_V2("","anEventRecord.request              :",anEventRecord.request) ;
            PPT_METHODTRACE_V2("","anEventRecord.categoryLevel        :",anEventRecord.categoryLevel) ;
            PPT_METHODTRACE_V2("","anEventRecord.categoryID           :",anEventRecord.categoryID) ;
            PPT_METHODTRACE_V2("","anEventRecord.routeID              :",anEventRecord.routeID) ;
            PPT_METHODTRACE_V2("","anEventRecord.operationNumber      :",anEventRecord.operationNumber) ;
            PPT_METHODTRACE_V2("","anEventRecord.hostName             :",anEventRecord.hostName) ;
            PPT_METHODTRACE_V2("","anEventRecord.serverName           :",anEventRecord.serverName) ;
            PPT_METHODTRACE_V2("","anEventRecord.itDaemonPort         :",anEventRecord.itDaemonPort) ;
            PPT_METHODTRACE_V2("","anEventRecord.entryRouteID         :",anEventRecord.entryRouteID) ;
            PPT_METHODTRACE_V2("","anEventRecord.entryOperationNumber :",anEventRecord.entryOperationNumber) ;
            PPT_METHODTRACE_V2("","anEventRecord.exitRouteID          :",anEventRecord.exitRouteID) ;
            PPT_METHODTRACE_V2("","anEventRecord.exitOperationNumber  :",anEventRecord.exitOperationNumber) ;
            PPT_METHODTRACE_V2("","anEventRecord.state                :",anEventRecord.state) ;
            PPT_METHODTRACE_V2("","anEventRecord.startTime            :",anEventRecord.startTime) ;
            PPT_METHODTRACE_V2("","anEventRecord.endTime              :",anEventRecord.endTime) ;

            PPT_METHODTRACE_V2("","anEventRecord.eventCommon.transactionID  :",anEventRecord.eventCommon.transactionID) ;
            PPT_METHODTRACE_V2("","anEventRecord.eventCommon.userID         :",anEventRecord.eventCommon.userID) ;
            PPT_METHODTRACE_V2("","anEventRecord.eventCommon.eventTimeStamp :",anEventRecord.eventCommon.eventTimeStamp) ;
            PPT_METHODTRACE_V2("","anEventRecord.eventCommon.eventShopDate  :",anEventRecord.eventCommon.eventShopDate) ;
            PPT_METHODTRACE_V2("","anEventRecord.eventCommon.eventMemo      :",anEventRecord.eventCommon.eventMemo) ;

            PosEventBase_var anEvent ;
            CORBA::Any eventRecord ;
            eventRecord <<= anEventRecord ;
            try
            {
                anEvent = theEventManager->createEvent( eventRecord );
            }
            catch( PosEventManager::InvalidEventRecordTypeSignal )
            {
                SET_FW_MSG_RC_NO_KEY( strBackupChannelEvent_Make_out,
                                      backupChannelEvent_Make,
                                      MSG_INVALID_EVENTRECORD_TYPE,
                                      RC_INVALID_EVENTRECORD_TYPE,
                                      PosEventManager::createEvent,
                                      PosEventManager::InvalidEventRecordTypeSignal )
                return RC_INVALID_EVENTRECORD_TYPE ;
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosEventManager::createEvent)
        } //end of for loop

        /*----------------------*/
        /*   Return to Caller   */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("PPTManager_i::backupChannelEvent_Make") ;
        return( RC_OK ) ;
    }
    CATCH_GLOBAL_EXCEPTIONS(strBackupChannelEvent_Make_out,backupChannelEvent_Make,methodName)
}
