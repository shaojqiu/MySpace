//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2016. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2016. All rights reserved.
//
//
// SiView
// Name: cassette_status_FinalizeForPostProcess.cpp
//

#include "pptmgr.hpp"
#include "plot.hh"    //DSN000075328
#include "pcas.hh"    //DSN000075328

// Class: PPTManager
//
// Service: cassette_status_FinalizeForPostProcess()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -----------------------------------------------------
// 2013/01/25 DSN000050720 M.Ogawa        Post Process parallel execution
// 2013/10/27 DSN000075328 JJ.Zhang       Support post process on chained mode
// 2016/02/17 PSN000100936 S.Kawabe       Post Process may leave post process flag as On for a carrier
//
//[Function Description]:
//
//[Input Parameters]:
//  const pptObjCommonIn&                               strObjCommonIn
//  const objCassette_status_FinalizeForPostProcess_in& strCassette_status_FinalizeForPostProcess_in
//
//[Output Parameters]:
//   objCassette_status_FinalizeForPostProcess_out&     strCassette_status_FinalizeForPostProcess_out
//
//  typedef pptBaseResult objCassette_status_FinalizeForPostProcess_out;
//
//[Return Value]:
//
//  Return Code                        Messsage ID
//  ---------------------------------- -----------------------------------------
//  RC_OK                              MSG_OK
//

CORBA::Long PPTManager_i::cassette_status_FinalizeForPostProcess(
    objCassette_status_FinalizeForPostProcess_out&          strCassette_status_FinalizeForPostProcess_out,
    const pptObjCommonIn&                                   strObjCommonIn,
    const objCassette_status_FinalizeForPostProcess_in&     strCassette_status_FinalizeForPostProcess_in )
{
    char* methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_status_FinalizeForPostProcess");
        //----------------
        //   Initialize
        //----------------
        CORBA::Long rc = RC_OK;

        //---------------------------------
        // Put Input Parameter
        //---------------------------------
        const objectIdentifier& cassetteID  = strCassette_status_FinalizeForPostProcess_in.cassetteID;

        if ( 0 < CIMFWStrLen(cassetteID.identifier) )
        {
            PPT_METHODTRACE_V2("", "cassetteID", cassetteID.identifier)

            //----------------------
            //   Update cassette MultiLotType
            //----------------------
            PPT_METHODTRACE_V1("", "call objCassette_multiLotType_Update_out()");
            objCassette_multiLotType_Update_out strCassette_multiLotType_Update_out;
            rc = cassette_multiLotType_Update( strCassette_multiLotType_Update_out,
                                               strObjCommonIn,
                                               cassetteID );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "cassette_multiLotType_Update() rc != RC_OK", rc);
                strCassette_status_FinalizeForPostProcess_out.strResult = strCassette_multiLotType_Update_out.strResult;
                return( rc );
            }

            //----------------------
            //   Set cassette's PostProcessFlag to FALSE
            //----------------------
            PPT_METHODTRACE_V1("", "call cassette_inPostProcessFlag_Set()");
            objCassette_inPostProcessFlag_Set_out strCassette_inPostProcessFlag_Set_out;
            objCassette_inPostProcessFlag_Set_in  strCassette_inPostProcessFlag_Set_in;
            strCassette_inPostProcessFlag_Set_in.cassetteID = cassetteID;
            strCassette_inPostProcessFlag_Set_in.inPostProcessFlag = FALSE ;
//DSN000075328 add start
            CORBA::ULong ppChainMode = 0;
            ppChainMode = atoi(getenv(SP_POSTPROC_CHAINED_MODE));
            PPT_METHODTRACE_V2("", "SP_POSTPROC_CHAINED_MODE", ppChainMode);

            if( 1 == ppChainMode )
            {
                PPT_METHODTRACE_V1("", "1 == ppChainMod");
                //-------------------------------------------------------------
                //  Check the lots' InPostProcessFlag in the cassette
                //  new PostProcess may be created for PSM/FPC child lot
                //-------------------------------------------------------------
//PSN000100936                PosCassette_var aCassette;
//PSN000100936                PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette, cassetteID,
//PSN000100936                                                       strCassette_status_FinalizeForPostProcess_out,
//PSN000100936                                                       cassette_status_FinalizeForPostProcess);
//PSN000100936
//PSN000100936                LotSequence*    aLotSequence = NULL;
//PSN000100936                LotSequence_var aLotSequenceVar;
//PSN000100936                try
//PSN000100936                {
//PSN000100936                    aLotSequence    = aCassette->allLots();
//PSN000100936                    aLotSequenceVar = aLotSequence;
//PSN000100936                }
//PSN000100936                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::allLots);
//PSN000100936
//PSN000100936                CORBA::Long nLotLen = aLotSequence->length();
//PSN000100936                PPT_METHODTRACE_V2("", "aLotSequence->length()", nLotLen);
//PSN000100936
//PSN000100936                for( CORBA::Long i = 0; i < nLotLen; i++ )
//PSN000100936                {
//PSN000100936                    PosLot_var tmpLot = PosLot::_narrow( (*aLotSequence)[i] );
//PSN000100936
//PSN000100936                    if( CORBA::is_nil( tmpLot ) )
//PSN000100936                    {
//PSN000100936                        PPT_METHODTRACE_V1("", "Lot is nil.");
//PSN000100936                        PPT_SET_MSG_RC_KEY( strCassette_status_FinalizeForPostProcess_out,
//PSN000100936                                            MSG_NOT_FOUND_LOT, RC_NOT_FOUND_LOT,
//PSN000100936                                            "****" );
//PSN000100936                        return( RC_NOT_FOUND_LOT );
//PSN000100936                    }
//PSN000100936
//PSN000100936                    CORBA::Boolean bPostProcessFlag = FALSE;
//PSN000100936                    try
//PSN000100936                    {
//PSN000100936                        bPostProcessFlag = tmpLot->isPostProcessFlagOn();
//PSN000100936                    }
//PSN000100936                    CATCH_AND_RAISE_EXCEPTIONS(PosLot::isPostProcessFlagOn);
//PSN000100936
//PSN000100936                    if( TRUE == bPostProcessFlag )
//PSN000100936                    {
//PSN000100936                        PPT_METHODTRACE_V2("", "Found Lot whose InPostProcessFlag is ON. ", i);
//PSN000100936                        strCassette_inPostProcessFlag_Set_in.inPostProcessFlag = TRUE ;
//PSN000100936                        break;
//PSN000100936                    }
//PSN000100936                }
//PSN000100936 add start
                objPostProcess_LastFlagForCarrier_GetDR_out strPostProcess_LastFlagForCarrier_GetDR_out;
                objPostProcess_LastFlagForCarrier_GetDR_in  strPostProcess_LastFlagForCarrier_GetDR_in;
                strPostProcess_LastFlagForCarrier_GetDR_in.carrierID = cassetteID;

                rc = postProcess_LastFlagForCarrier_GetDR( strPostProcess_LastFlagForCarrier_GetDR_out,
                                                           strObjCommonIn,
                                                           strPostProcess_LastFlagForCarrier_GetDR_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "postProcess_LastFlagForCarrier_GetDR() != RC_OK");
                    strCassette_status_FinalizeForPostProcess_out.strResult = strPostProcess_LastFlagForCarrier_GetDR_out.strResult;
                    return rc;
                }
                strCassette_inPostProcessFlag_Set_in.inPostProcessFlag = strPostProcess_LastFlagForCarrier_GetDR_out.lotPostProcessingFlag;
//PSN000100936 add end
            }
//DSN000075328 add end
            rc = cassette_inPostProcessFlag_Set( strCassette_inPostProcessFlag_Set_out, strObjCommonIn, strCassette_inPostProcessFlag_Set_in);
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "##### cassette_inPostProcessFlag_Set() != RC_OK", rc);
                strCassette_status_FinalizeForPostProcess_out.strResult = strCassette_inPostProcessFlag_Set_out.strResult ;
                return rc;
            }
        }

        //----------------------
        //   Return to Caller
        //----------------------
        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_status_FinalizeForPostProcess");

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_status_FinalizeForPostProcess_out, cassette_status_FinalizeForPostProcess, methodName)
}
