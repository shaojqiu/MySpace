#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/availableEquipment_GetForDeliveryReqDR.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:28:31 [ 7/13/07 19:28:32 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: availableEquipment_GetForDeliveryReqDR.cpp
//

#include "pptmgr.hpp"

#include "pcas.hh"
#include "plot.hh"
#include "pmc.hh"
#include "ppcdr.hh"
#include "pportrs.hh"

//[Object Function Name]: long   availableEquipment_GetForDeliveryReqDR
//
//[Called by           ]: TXEQQ017
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2000/07/11  0.00      O.Ohishi       Initial Release
// 2000/09/10  0.01      O.Ohishi       Bug Fix
// 2000/09/23  0.03      M.Mori         repeat of nil check
// 2001/10/30  D4000251  K.Matsuei      Narrow the start factor of CassetteDelivery Watchdog.
// 2001/11/08  D40A0011  K.Matsuei      Narrow the start factor of CassetteDelivery Watchdog. The modification of 4000251 was left.
// 2001/11/08  D40A0010  K.Matsuei      The same EQP-ID is returned from TxAvailableEqpInq.
// 2001/11/26  P4100013  Y.Iwasaki      Bug Fix of D4000254 (Auto-2's UnloadReq handling)
// 2002/10/10  P4200030  K.Matsuei      Initialize "CORBA::String" by NULL.
// 2003/01/23  D4200273  K.Matsuei      TakeOut Xfer is supported under EqpState:NotAvailable, PortState:UnloadReq conditions.
// 2003/09/08  P5000145  H.Adachi       Fix Message and Message Macro mismatch.
// 2005/04/19  P6000232  H.Hasegawa     Add missing error handling.
// 2007/04/20  D9000001  M.Murata       64bit support.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2012/01/13 PSN000030052 M.Ogawa        Fix port group sort logic
//
//[Function Description]:
//
//  Inquire available equipments, which DispatchMode is Auto or
//  Access Mode is Auto and eqp available flag is True.
//
//  Client can specify one of four parameters, eqpid,lotid,cstid,durableid.
//  If equipmentID is specified,
//     check eqp mode and avai state flag
//  If lotID is specified,
//     get next equipments from lotID first.
//     check eqp mode and avai state flag
//  If cassetteID is specified,
//     get lotID from cassetteID first.
//     get next equipments from lotID.
//     check eqp mode and avai state flag
//  If durableID is specified,
//     get equipmentID from durableID first.
//     check eqp mode and avai state flag
//  Then return eqpIDs.
//
//  Before return eqpSequence, it must be sorted by lastDisopatchRequiredTimeStamp kept
//  in each port.
//
//
//[Input Parameters]:
//  in  pptObjCommonIn   strObjCommonIn;                  // Tx, DateTime, User
//  in  objectIdentifier equipmentID;                     //
//  in  objectIdentifier lotID;                           //
//  in  objectIdentifier cassetteID;                      //
//  in  objectIdentifier durableID;                       //
//
//[Output Parameters]:
//  out objAvailableEquipment_GetForDeliveryReqDR_out    strAvailableEquipment_GetForDeliveryReqDR_out;
//
//  typedef struct objAvailableEquipment_GetForDeliveryReqDR_out_struct {
//      pptRetCode           strResult;
//      objectIdentifierSequence  equipmentIDs;
//  } objAvailableEquipment_GetForDeliveryReqDR_out;
//
//  *** NOTE ***
//   See TXEQQ017.hpp for the detail of each structures.
//
//
//[Return Value]:
//
//  Return Code               Message ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//  RC_SYSTEM_ERROR           MSG_SYSTEM_ERROR
//  RC_NOT_FOUND_EQP          MSG_NOT_FOUND_EQP
//  RC_NOT_FOUND_LOT          MSG_NOT_FOUND_LOT
//  RC_NOT_FOUND_CASSETTE     MSG_NOT_FOUND_CASSETTE
//  RC_NOT_FOUND_DURABLE      MSG_NOT_FOUND_DURABLE
//


CORBA::Long PPTManager_i::availableEquipment_GetForDeliveryReqDR(
                                  objAvailableEquipment_GetForDeliveryReqDR_out& strAvailableEquipment_GetForDeliveryReqDR_out,
                                  const pptObjCommonIn&                          strObjCommonIn,
                                  const objectIdentifier&                        equipmentID   ,
                                  const objectIdentifier&                        lotID         ,
                                  const objectIdentifier&                        cassetteID    ,
                                  const objectIdentifier&                        durableID      )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::availableEquipment_GetForDeliveryReqDR");

        CORBA::Long rc = RC_OK;
        CORBA::Long deliverableEqpCount = 0;
        CORBA::Long i, j, k, l;     //D40A0010   Declare [i, j, k, l] only here.

        /****************************************************************************************/
        /*                                                                                      */
        /*                                                                                      */
        /*   When it is examined about EquipmentID.                                             */
        /*                                                                                      */
        /*                                                                                      */
        /****************************************************************************************/
        if ( CIMFWStrLen( equipmentID.identifier ) != 0 )
        {
            PPT_METHODTRACE_V1("", "//******************************************************************");
            PPT_METHODTRACE_V2("", "// When it is examined about LotID or EquipmentID.", equipmentID.identifier);
            PPT_METHODTRACE_V1("", "//******************************************************************");

            /*------------------------------*/
            /*   Check Operation Mode       */
            /*------------------------------*/
            objEquipment_operationMode_GetDR_out strEquipment_operationMode_GetDR_out;
            rc = equipment_operationMode_GetDR( strEquipment_operationMode_GetDR_out, strObjCommonIn, equipmentID );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "rc != RC_OK", rc);

                if ( rc == RC_NOT_FOUND_EQP )
                {
                    PPT_METHODTRACE_V1("", "rc == RC_NOT_FOUND_EQP");
                    strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs.length(deliverableEqpCount);
                    PPT_SET_MSG_RC_KEY( strAvailableEquipment_GetForDeliveryReqDR_out, MSG_NOT_FOUND_EQP, RC_NOT_FOUND_EQP, equipmentID.identifier );
                    return RC_NOT_FOUND_EQP;
                }
                else
                {
                    PPT_METHODTRACE_V1("", "rc != RC_NOT_FOUND_EQP");
                    strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs.length(deliverableEqpCount);
//P5000145                    PPT_SET_MSG_RC_KEY( strAvailableEquipment_GetForDeliveryReqDR_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR, equipmentID.identifier );
                    SET_MSG_RC( strAvailableEquipment_GetForDeliveryReqDR_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR );    //P5000145
                    return RC_SYSTEM_ERROR;
                }
            }

            /*----------------------------*/
            /*   Get Eqp Port Information */
            /*----------------------------*/
            objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
            rc = equipment_portInfo_Get(strEquipment_portInfo_Get_out, strObjCommonIn, equipmentID);
            //P6000232 Add Start
            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "equipment_portInfo_Get() != RC_OK", rc);

                strAvailableEquipment_GetForDeliveryReqDR_out.strResult = strEquipment_portInfo_Get_out.strResult;
                strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs.length( deliverableEqpCount );
                PPT_METHODTRACE_EXIT("PPTManager_i::availableEquipment_GetForDeliveryReqDR");
                return rc;
            }
            //P6000232 Add End

            CORBA::Long strEqpPortInfo_len = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
            PPT_METHODTRACE_V2("", "strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length()", strEqpPortInfo_len);

//P4100013 delete start
//P4100013            for ( long pCnt=0; pCnt < strEqpPortInfo_len; pCnt++ )
//P4100013            {
//P4100013                PPT_METHODTRACE_V2("", "loop to strEqpPortInfo.strEqpPortStatus.length()", pCnt);
//P4100013
//P4100013                if ( ( CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].dispatchMode, SP_Eqp_DispatchMode_Auto) != 0 ) &&
//P4100013                     ( CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].accessMode, SP_Eqp_AccessMode_Auto) != 0 ) &&
//P4100013                     ( ( ( CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portState, "LoadAvail") != 0 ) &&
//P4100013                         ( CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portState, "LoadReq") != 0 ) &&
//P4100013                         ( CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portState, "UnloadReq") != 0 ) ) ||
//P4100013                       ( CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].dispatchState, "Required") != 0 ) ) )
//P4100013                {
//P4100013                    strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs.length( deliverableEqpCount );
//P4100013                    PPT_METHODTRACE_EXIT("PPTManager_i::availableEquipment_GetForDeliveryReqDR");
//P4100013                    return RC_OK;
//P4100013                }
//P4100013
//P4100013//D40A0011 start
//P4100013                PPT_METHODTRACE_V1("", "Omit LoadAvail of Semi2 and LoadReq  [D4000251]");
//P4100013                // Omit LoadAvail of Semi2 and LoadReq
//P4100013                if ( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].dispatchMode, SP_Eqp_DispatchMode_Manual) )
//P4100013                {
//P4100013                    PPT_METHODTRACE_V1("", "DispatchMode == Manual");
//P4100013                    if ( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portState, SP_PortRsc_PortState_LoadAvail)
//P4100013                      || 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portState, SP_PortRsc_PortState_LoadReq) )
//P4100013                    {
//P4100013                        PPT_METHODTRACE_V1("", "Omit LoadAvail of Semi2 and LoadReq  [D4000251]");
//P4100013                        strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs.length( deliverableEqpCount );
//P4100013                        PPT_METHODTRACE_EXIT("PPTManager_i::availableEquipment_GetForDeliveryReqDR");
//P4100013                        return RC_OK;
//P4100013                    }
//P4100013                }
//P4100013//D40A0011 end
//P4100013            }
//P4100013 delete start

            //P4100013 add start
            //--------------------------------------------------------------------------------//
            //   Check whether at least one port, which is deliverable, is existing or not.   //
            //   If all of port is not ready for delivery, return RC_OK.                      //
            //--------------------------------------------------------------------------------//
            CORBA::Boolean deliverableFlag = FALSE;

//D9000001            for ( long pCnt=0; pCnt < strEqpPortInfo_len; pCnt++ )
            for ( CORBA::Long pCnt=0; pCnt < strEqpPortInfo_len; pCnt++ )//D9000001
            {
                PPT_METHODTRACE_V2("", "loop to strEqpPortInfo.strEqpPortStatus.length()", pCnt);

                if ( CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].dispatchMode , SP_Eqp_DispatchMode_Auto          ) == 0 &&
                     CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].accessMode   , SP_Eqp_AccessMode_Auto            ) == 0 &&
                     CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].dispatchState, SP_PortRsc_DispatchState_Required ) == 0 &&
                    (CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portState    , SP_PortRsc_PortState_LoadAvail    ) == 0 ||
                     CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portState    , SP_PortRsc_PortState_LoadReq      ) == 0 ||
                     CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portState    , SP_PortRsc_PortState_UnloadReq    ) == 0) )
                {
                    PPT_METHODTRACE_V2("", "Dispatch available port found!!!", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portID.identifier);
                    deliverableFlag = TRUE;
                    break;
                }
                else
                if ( CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].dispatchMode , SP_Eqp_DispatchMode_Manual        ) == 0 &&
                     CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].accessMode   , SP_Eqp_AccessMode_Auto            ) == 0 &&
                     CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].dispatchState, SP_PortRsc_DispatchState_Required ) == 0 &&
                     CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portState    , SP_PortRsc_PortState_UnloadReq    ) == 0 )
                {
                    PPT_METHODTRACE_V2("", "Dispatch available port found!!!", strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portID.identifier);
                    deliverableFlag = TRUE;
                    break;
                }
            }

            if ( deliverableFlag == FALSE )
            {
                PPT_METHODTRACE_V1("", "All of port is not ready for Delivery. return RC_OK...");
                strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs.length( deliverableEqpCount );
                PPT_METHODTRACE_EXIT("PPTManager_i::availableEquipment_GetForDeliveryReqDR");
                return( RC_OK );
            }
            //P4100013 add end

//D4200273 start
            CORBA::String_var takeOutXferInNotAvailableState = CIMFWStrDup(getenv(SP_TAKEOUT_XFER_IN_NOTAVAILABLE_STATE));
            PPT_METHODTRACE_V2("","SP_TAKEOUT_XFER_IN_NOTAVAILABLE_STATE ---> ",takeOutXferInNotAvailableState);

            if ( 0 != CIMFWStrCmp(takeOutXferInNotAvailableState, "1") )
            {
                PPT_METHODTRACE_V1("", "call equipment_CheckAvailDR()");
//D4200273 end
                /*------------------------------*/
                /*   Check Eqp Availability     */
                /*------------------------------*/
                objEquipment_CheckAvailDR_out strEquipment_CheckAvailDR_out;
                rc = equipment_CheckAvailDR(strEquipment_CheckAvailDR_out, strObjCommonIn, equipmentID);

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "rc != RC_OK");

                    if ( rc == RC_EQP_NOT_AVAILSTAT )
                    {
                        PPT_METHODTRACE_V2("", "rc == RC_EQP_NOT_AVAILSTAT", rc);
                        strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs.length(deliverableEqpCount);
                        PPT_METHODTRACE_EXIT("PPTManager_i::availableEquipment_GetForDeliveryReqDR");
                        return RC_OK;
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("", "rc != RC_EQP_NOT_AVAILSTAT");
                        strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs.length(deliverableEqpCount);
//P5000145                        PPT_SET_MSG_RC_KEY( strAvailableEquipment_GetForDeliveryReqDR_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR, equipmentID.identifier );
                        SET_MSG_RC( strAvailableEquipment_GetForDeliveryReqDR_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR );    //P5000145
                        return RC_SYSTEM_ERROR;
                    }
                }
            }  //D4200273

            /*------------------------------*/
            /*   Eqp Available              */
            /*------------------------------*/
            strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs.length(deliverableEqpCount+1);
            strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs[deliverableEqpCount] = equipmentID;
            deliverableEqpCount++;

            PPT_METHODTRACE_V2("", "deliverableEqpCount", deliverableEqpCount);

            PPT_METHODTRACE_EXIT("PPTManager_i::availableEquipment_GetForDeliveryReqDR");
            return RC_OK;
        }
//D40A0010 start
        /****************************************************************************************/
        /*                                                                                      */
        /*                                                                                      */
        /*   When it is examined about LotID or CassetteID.                                     */
        /*                                                                                      */
        /*                                                                                      */
        /****************************************************************************************/
        else if ( 0 != CIMFWStrLen(lotID.identifier) || 0 != CIMFWStrLen(cassetteID.identifier) )
        {
            PPT_METHODTRACE_V1("", "//******************************************************************");
            PPT_METHODTRACE_V3("", "// When it is examined about LotID or CassetteID.", lotID.identifier, cassetteID.identifier);
            PPT_METHODTRACE_V1("", "//******************************************************************");

            objectIdentifierSequence targetEqps;

            if ( 0 != CIMFWStrLen(lotID.identifier) )
            {
                /*-------------------------------------------------------*/
                /*   Get all the devices which should be necessary Lot   */
                /*-------------------------------------------------------*/
                PPT_METHODTRACE_V1("", "/*-------------------------------------------------------*/");
                PPT_METHODTRACE_V1("", "/*   Get all the devices which should be necessary Lot   */");
                PPT_METHODTRACE_V1("", "/*-------------------------------------------------------*/");
                PosLot_var aLot;
                PPT_CONVERT_LOTID_TO_LOT_OR( aLot, lotID, strAvailableEquipment_GetForDeliveryReqDR_out,
                                                availableEquipment_GetForDeliveryReqDR );

                if ( TRUE == CORBA::is_nil( aLot ) )
                {
                    PPT_METHODTRACE_V1("", "##### aLot is nil");
                    PPT_SET_MSG_RC_KEY( strAvailableEquipment_GetForDeliveryReqDR_out,
                                        MSG_NOT_FOUND_LOT, RC_NOT_FOUND_LOT, cassetteID.identifier );
                    return RC_NOT_FOUND_LOT;
                }

                PosMachineSequence* equipmentSeq = NULL;
                PosMachineSequence_var TmpequipmentSeq = NULL;
                try
                {
                    equipmentSeq = aLot->getQueuedMachines();
                    TmpequipmentSeq = equipmentSeq;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getQueuedMachines);

                objectIdentifier tempEquipmentID;
                CORBA::Long lenEqp = equipmentSeq->length();
                PPT_METHODTRACE_V2("", "aLot->getQueuedMachines.length()", lenEqp);
                targetEqps.length( lenEqp );
                for ( i=0; i< lenEqp; i++ )
                {
                    PPT_SET_OBJECT_IDENTIFIER( tempEquipmentID, (*equipmentSeq)[i],
                                               strAvailableEquipment_GetForDeliveryReqDR_out,
                                               availableEquipment_GetForDeliveryReqDR, PosMachine );

                    PPT_METHODTRACE_V2("", "  QueuedMachine--->", tempEquipmentID.identifier);
                    targetEqps[i] = tempEquipmentID;
                }
            }
            else if ( 0 != CIMFWStrLen(cassetteID.identifier) )
            {
                PPT_METHODTRACE_V2("", "0 < len( cassetteID.identifier )", cassetteID.identifier);
                /*------------------------------------------------------------*/
                /*   Get all the devices which should be necessary Cassette   */
                /*------------------------------------------------------------*/
                PPT_METHODTRACE_V1("", "/*------------------------------------------------------------*/");
                PPT_METHODTRACE_V1("", "/*   Get all the devices which should be necessary Cassette   */");
                PPT_METHODTRACE_V1("", "/*------------------------------------------------------------*/");
                PosCassette_var aCassette;
                PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette, cassetteID,
                                                       strAvailableEquipment_GetForDeliveryReqDR_out,
                                                       availableEquipment_GetForDeliveryReqDR );

                LotSequence* lotIDs = NULL;
                LotSequence_var lotIDsVar;
                try
                {
                    lotIDs = aCassette->allLots();
                    lotIDsVar = lotIDs;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::allLots);

                CORBA::Long nLen = lotIDs->length();
                PPT_METHODTRACE_V2("", "aCassette->allLots.length()", nLen);

                if ( nLen == 0 )
                {
                    PPT_METHODTRACE_V1("", "##### 0 == aCassette->allLots.length()");
                    PPT_SET_MSG_RC_KEY( strAvailableEquipment_GetForDeliveryReqDR_out,
                                        MSG_NOT_FOUND_LOT, RC_NOT_FOUND_LOT, cassetteID.identifier );
                    return RC_NOT_FOUND_LOT;
                }

                for ( j=0; j < nLen; j++ )
                {
                    PosLot_var aLot = PosLot::_narrow( (*lotIDs)[j] );

                    if ( CORBA::is_nil(aLot) )
                    {
                        PPT_METHODTRACE_V2("", "##### aLot is nil", j);
                        PPT_SET_MSG_RC_KEY( strAvailableEquipment_GetForDeliveryReqDR_out, MSG_NOT_FOUND_LOT, RC_NOT_FOUND_LOT, "" );
                        return RC_NOT_FOUND_LOT;
                    }

                    PosMachineSequence* equipmentSeq = NULL;
                    PosMachineSequence_var TmpequipmentSeq;
                    try
                    {
                        equipmentSeq = aLot->getQueuedMachines();
                        TmpequipmentSeq = equipmentSeq;
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosLot::getQueuedMachines);

                    objectIdentifier tempEquipmentID;
                    CORBA::Long lenEqp = equipmentSeq->length();
                    PPT_METHODTRACE_V2("", "aLot->getQueuedMachines.length()", lenEqp);
                    for ( k=0; k < lenEqp; k++ )
                    {
                        PPT_SET_OBJECT_IDENTIFIER( tempEquipmentID, (*equipmentSeq)[k],
                                                   strAvailableEquipment_GetForDeliveryReqDR_out,
                                                   availableEquipment_GetForDeliveryReqDR, PosMachine );

                        // Omit the same EQPID
                        CORBA::Boolean bExist = FALSE;
                        CORBA::Long lenTgtEqp = targetEqps.length();
                        for ( l=0; l < lenTgtEqp; l++ )
                        {
                            if ( 0 == CIMFWStrCmp(tempEquipmentID.identifier, targetEqps[l].identifier) )
                            {
                                bExist = TRUE;
                                break;
                            }
                        }
                        if ( FALSE == bExist )
                        {
                            PPT_METHODTRACE_V2("", "add EqpID--->", tempEquipmentID.identifier);
                            targetEqps.length( lenTgtEqp + 1 );
                            targetEqps[ lenTgtEqp ] = tempEquipmentID;
                        }
                    }
                }
            }

            PPT_METHODTRACE_V1("", "");
            PPT_METHODTRACE_V1("", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Debug Start");
            CORBA::Long len = targetEqps.length();
            PPT_METHODTRACE_V2("", "targetEqps.length--->", len);
            for ( i=0; i < len; i++ )
            {
                PPT_METHODTRACE_V2("", "TargetEqpID", targetEqps[i].identifier);
            }
            PPT_METHODTRACE_V1("", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Debug End");
            PPT_METHODTRACE_V1("", "");

            /*---------------------------------------------------------------------------------*/
            /*   Get Eqps Port Info and Divide it into every PortGroup                         */
            /*                                                                                 */
            /*  strEquipment_portInfo_SortByGroup_out                                          */
            /*  +----------------------+   +----------------------+                            */
            /*  | EQP-1                |   | EQP-2                |                            */
            /*  |----------------------+   |----------------------+                            */
            /*  | PortGrp-A | PortID-1 |   | PortGrp-A | PortID-1 |                            */
            /*  |           | PortID-2 |   |           | PortID-2 |                            */
            /*  |-----------+----------+   +----------------------+                            */
            /*  | PortGrp-B | PortID-3 |                                                       */
            /*  |           | PortID-4 |                                                       */
            /*  +----------------------+                                                       */
            /*                                                                                 */
            /*                    |   |   |   |   |                                            */
            /*                    V   V   V   V   V                                            */
            /*                                                                                 */
            /*  pptEqpOnePortGroupInfoSequence                                                 */
            /*  +----------------------+  +----------------------+  +----------------------+   */
            /*  | EQP-1                |  | EQP-1                |  | EQP-2                |   */
            /*  |----------------------+  |----------------------+  |----------------------+   */
            /*  | PortGrp-A | PortID-1 |  | PortGrp-B | PortID-3 |  | PortGrp-A | PortID-1 |   */
            /*  |           | PortID-2 |  |           | PortID-4 |  |           | PortID-2 |   */
            /*  +----------------------+  +----------------------+  +----------------------+   */
            /*---------------------------------------------------------------------------------*/
            PPT_METHODTRACE_V1("", "/*-----------------------------------------------------------*/");
            PPT_METHODTRACE_V1("", "/*   Get Eqps Port Info and Divide it into every PortGroup   */");
            PPT_METHODTRACE_V1("", "/*-----------------------------------------------------------*/");

            pptEqpOnePortGroupInfoSequence pptEqpOnePortGroupInfoSeq;
            CORBA::Long lenPortGrpInfoSeq = 0;
            CORBA::Long lenTgtEqp = targetEqps.length();
            PPT_METHODTRACE_V2("", "targetEqps.length--->", lenTgtEqp);
            for ( i=0; i < lenTgtEqp; i++ )
            {
                PPT_METHODTRACE_V2("", "call equipment_portInfo_Get()", targetEqps[i].identifier);
                objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
                rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out, strObjCommonIn, targetEqps[i] );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "##### RC_OK != equipment_portInfo_SortByGroup()", rc);
                    strAvailableEquipment_GetForDeliveryReqDR_out.strResult = strEquipment_portInfo_Get_out.strResult;
                    PPT_METHODTRACE_EXIT("PPTManager_i::availableEquipment_GetForDeliveryReqDR");
                    return rc;
                }

                PPT_METHODTRACE_V1("", "call equipment_portInfo_SortByGroup()");
                objEquipment_portInfo_SortByGroup_out strEquipment_portInfo_SortByGroup_out;
                rc = equipment_portInfo_SortByGroup( strEquipment_portInfo_SortByGroup_out,
                                                     strObjCommonIn,
                                                     targetEqps[i],
                                                     strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "##### RC_OK != equipment_portInfo_SortByGroup()", rc);
                    strAvailableEquipment_GetForDeliveryReqDR_out.strResult = strEquipment_portInfo_SortByGroup_out.strResult;
                    PPT_METHODTRACE_EXIT("PPTManager_i::availableEquipment_GetForDeliveryReqDR");
                    return rc;
                }

                CORBA::Long lenPortGroup = strEquipment_portInfo_SortByGroup_out.strEqpPortInfoOrderByGroup.strPortGroup.length();
                PPT_METHODTRACE_V2("", "lenPortGroup--->", lenPortGroup);
                pptEqpOnePortGroupInfoSeq.length( lenPortGrpInfoSeq + lenPortGroup );

                for ( j=0; j < lenPortGroup; j++ )
                {
                    pptEqpOnePortGroupInfoSeq[ lenPortGrpInfoSeq + j ].equipmentID = strEquipment_portInfo_SortByGroup_out.strEqpPortInfoOrderByGroup.equipmentID;
                    pptEqpOnePortGroupInfoSeq[ lenPortGrpInfoSeq + j ].strPortGroup.portGroup = strEquipment_portInfo_SortByGroup_out.strEqpPortInfoOrderByGroup.strPortGroup[j].portGroup;

                    PPT_METHODTRACE_V2("", "equipmentID ---> ", pptEqpOnePortGroupInfoSeq[ lenPortGrpInfoSeq + j ].equipmentID.identifier);
                    PPT_METHODTRACE_V2("", "portGroup -----> ", pptEqpOnePortGroupInfoSeq[ lenPortGrpInfoSeq + j ].strPortGroup.portGroup);

                    CORBA::Long lenPortID = strEquipment_portInfo_SortByGroup_out.strEqpPortInfoOrderByGroup.strPortGroup[j].strPortID.length();
                    PPT_METHODTRACE_V2("", "lenPortID", lenPortID);
                    pptEqpOnePortGroupInfoSeq[ lenPortGrpInfoSeq + j ].strPortGroup.strPortID.length( lenPortID );

                    for ( k=0; k < lenPortID; k++ )
                    {
                        pptEqpOnePortGroupInfoSeq[ lenPortGrpInfoSeq + j ].strPortGroup.strPortID[k] = strEquipment_portInfo_SortByGroup_out.strEqpPortInfoOrderByGroup.strPortGroup[j].strPortID[k];
                        PPT_METHODTRACE_V2("", "  strPortID ----> ", pptEqpOnePortGroupInfoSeq[ lenPortGrpInfoSeq + j ].strPortGroup.strPortID[k].portID.identifier);
                    }
                }

                lenPortGrpInfoSeq += lenPortGroup;
                PPT_METHODTRACE_V2("", "lenPortGrpInfoSeq", lenPortGrpInfoSeq);
            }

            PPT_METHODTRACE_V1("", "");
            PPT_METHODTRACE_V1("", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Debug Start");
            len = pptEqpOnePortGroupInfoSeq.length();
            PPT_METHODTRACE_V2("", "pptEqpOnePortGroupInfoSeq.length()", len);
            for ( i=0; i < len; i++ )
            {
                PPT_METHODTRACE_V2("", "---------------------------------------round[i]", i);
                PPT_METHODTRACE_V2("", "  equipmentID--->", pptEqpOnePortGroupInfoSeq[i].equipmentID.identifier);
                PPT_METHODTRACE_V2("", "  portGroup----->", pptEqpOnePortGroupInfoSeq[i].strPortGroup.portGroup);
                CORBA::Long lenPortID = pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID.length();
                PPT_METHODTRACE_V2("", "  lenPortID----->", lenPortID);
                for ( j=0; j < lenPortID; j++ )
                {
                    PPT_METHODTRACE_V2("", "    portID-------------------->", pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID[j].portID.identifier);
                    PPT_METHODTRACE_V2("", "    dispatchState_TimeStamp--->", pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID[j].dispatchState_TimeStamp);
                }
            }
            PPT_METHODTRACE_V1("", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Debug End");
            PPT_METHODTRACE_V1("", "");

            /*------------------------------------------------------------------------------*/
            /*   sort old order of portGroup timeStamp                                      */
            /*                                                                              */
            /* EQP-3 --- PG-A                                                               */
            /*       P1 : dispatchState_TimeStamp: 2000/05/03 18:23:08  <--- This!          */
            /*       P2 : dispatchState_TimeStamp: 2000/05/01 12:14:28                      */
            /*                                                                              */
            /* EQP-3 --- PG-B                                                               */
            /*       P1 : dispatchState_TimeStamp: 2000/05/02 11:47:13  <--- This!          */
            /*       P2 : dispatchState_TimeStamp: 2000/05/01 02:54:31                      */
            /*                                                                              */
            /* EQP-4 --- PG-A                                                               */
            /*       P1 : dispatchState_TimeStamp: 2000/05/02 20:21:49                      */
            /*       P2 : dispatchState_TimeStamp: 2000/05/03 14:58:26  <--- This!          */
            /*                                                                              */
            /* pptEqpOnePortGroupInfoSeq ---> [EQP3 - PG-A], [EQP3 - PG-B], [EQP4 - PG-A]   */
            /*          |                                                                   */
            /*          V                                                                   */
            /* pptEqpOnePortGroupInfoSeq ---> [EQP3 - PG-B], [EQP4 - PG-A], [EQP3 - PG-A]   */
            /*------------------------------------------------------------------------------*/
            PPT_METHODTRACE_V1("", "/*-------------------------------------------*/");
            PPT_METHODTRACE_V1("", "/*   sort old order of portGroup timeStamp   */");
            PPT_METHODTRACE_V1("", "/*-------------------------------------------*/");

            pptEqpOnePortGroupInfo tmpEqpPortGroupInfoSeq;
//P4200030            CORBA::String tmpTime;
            CORBA::String tmpTime = NULL ;        //P4200030
            longSequence portNumSeq;
            CORBA::Long lenEqpPortGroupInfoSeq = pptEqpOnePortGroupInfoSeq.length();

            portNumSeq.length(lenEqpPortGroupInfoSeq);

            // Get High Priority Port
            PPT_METHODTRACE_V1("", "Get High Priority Port ----------------");
            for ( i=0; i < lenEqpPortGroupInfoSeq; i++ )
            {
                portNumSeq[i] = 0;
                CORBA::Long lenPortID = pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID.length();
                tmpTime = pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID[0].dispatchState_TimeStamp;
                for ( j=0; j < lenPortID; j++ )
                {
                    if ( CIMFWStrCmp(pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID[j].dispatchState_TimeStamp, tmpTime) > 0 )
                    {
//PSN000030052                        CIMFWStrCpy(tmpTime, pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID[j].dispatchState_TimeStamp);
                        tmpTime = pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID[j].dispatchState_TimeStamp;   //PSN000030052
                        portNumSeq[i] = j;
                    }
                }

                PPT_METHODTRACE_V5("", "PickUp Port--->", pptEqpOnePortGroupInfoSeq[i].equipmentID.identifier,
                                                          pptEqpOnePortGroupInfoSeq[i].strPortGroup.portGroup,
                                                          pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID[portNumSeq[i]].portID.identifier,
                                                          pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID[portNumSeq[i]].dispatchState_TimeStamp);
            }
            PPT_METHODTRACE_V1("", "Sort ----------------------------------");
            //sort
            for ( i=0; i < lenEqpPortGroupInfoSeq; i++ )
            {
//PSN000030052 Add Start
                PPT_METHODTRACE_V5("", "PickUp Port for i --->",
                                        pptEqpOnePortGroupInfoSeq[i].equipmentID.identifier,
                                        pptEqpOnePortGroupInfoSeq[i].strPortGroup.portGroup,
                                        pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID[portNumSeq[i]].portID.identifier,
                                        pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID[portNumSeq[i]].dispatchState_TimeStamp);
//PSN000030052 Add End
                for ( j=i+1; j < lenEqpPortGroupInfoSeq; j++ )
                {
//PSN000030052 Add Start
                    PPT_METHODTRACE_V5("", "PickUp Port for j --->",
                                            pptEqpOnePortGroupInfoSeq[j].equipmentID.identifier,
                                            pptEqpOnePortGroupInfoSeq[j].strPortGroup.portGroup,
                                            pptEqpOnePortGroupInfoSeq[j].strPortGroup.strPortID[portNumSeq[j]].portID.identifier,
                                            pptEqpOnePortGroupInfoSeq[j].strPortGroup.strPortID[portNumSeq[j]].dispatchState_TimeStamp);
//PSN000030052 Add End
                    if ( CIMFWStrCmp(pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID[portNumSeq[i]].dispatchState_TimeStamp,
                                     pptEqpOnePortGroupInfoSeq[j].strPortGroup.strPortID[portNumSeq[j]].dispatchState_TimeStamp) > 0 )
                    {
                        tmpEqpPortGroupInfoSeq = pptEqpOnePortGroupInfoSeq[j];
                        pptEqpOnePortGroupInfoSeq[j] = pptEqpOnePortGroupInfoSeq[i];
                        pptEqpOnePortGroupInfoSeq[i] = tmpEqpPortGroupInfoSeq;
                        CORBA::ULong tmpPortNum = 0;    //PSN000030052
                        tmpPortNum    = portNumSeq[j];  //PSN000030052
                        portNumSeq[j] = portNumSeq[i];  //PSN000030052
                        portNumSeq[i] = tmpPortNum;     //PSN000030052
                    }
                }
            }
            PPT_METHODTRACE_V1("", "");
            PPT_METHODTRACE_V1("", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Debug Start");
            CORBA::Long lenPortGroup = pptEqpOnePortGroupInfoSeq.length();
            for ( i=0; i < lenPortGroup; i++ )
            {
                PPT_METHODTRACE_V2("", "---------------------------------------round[i]", i);
                PPT_METHODTRACE_V2("", "  equipmentID--->", pptEqpOnePortGroupInfoSeq[i].equipmentID.identifier);
                PPT_METHODTRACE_V2("", "  portGroup----->", pptEqpOnePortGroupInfoSeq[i].strPortGroup.portGroup);
                CORBA::Long lenPortID = pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID.length();
                PPT_METHODTRACE_V2("", "  lenPortID----->", lenPortID);
                for ( j=0; j < lenPortID; j++ )
                {
                    PPT_METHODTRACE_V2("", "    portID-------------------->", pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID[j].portID.identifier);
                    PPT_METHODTRACE_V2("", "    dispatchState_TimeStamp--->", pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID[j].dispatchState_TimeStamp);
                }
            }
            PPT_METHODTRACE_V1("", "@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ Debug End");
            PPT_METHODTRACE_V1("", "");

            /*----------------------------------------------------------*/
            /*                                                          */
            /*   Check condition of EQP. Then, decide EQPID to return   */
            /*                                                          */
            /*----------------------------------------------------------*/
            PPT_METHODTRACE_V1("", "/*----------------------------------------------------------*/");
            PPT_METHODTRACE_V1("", "/*   Check condition of EQP. Then, decide EQPID to return   */");
            PPT_METHODTRACE_V1("", "/*----------------------------------------------------------*/");

            objectIdentifierSequence returnEqpSeq;
            returnEqpSeq.length( lenEqpPortGroupInfoSeq );
            CORBA::Long nSetCnt = 0;

            for ( i=0; i < lenEqpPortGroupInfoSeq; i++ )
            {
                objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
                rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out, strObjCommonIn, pptEqpOnePortGroupInfoSeq[i].equipmentID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "##### RC_OK != equipment_portInfo_Get()", rc);
                    strAvailableEquipment_GetForDeliveryReqDR_out.strResult = strEquipment_portInfo_Get_out.strResult;
                    PPT_METHODTRACE_EXIT("PPTManager_i::availableEquipment_GetForDeliveryReqDR");
                    return rc;
                }

                // Find the same PortGroup. and check EQP status
                CORBA::Long nFoundPortGrpIdx = -1;
                CORBA::Long lenPortGrp = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
                for ( j=0; j < lenPortGrp; j++ )
                {
                    if ( 0 == CIMFWStrCmp(pptEqpOnePortGroupInfoSeq[i].strPortGroup.portGroup,
                                          strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].portGroup) )
                    {
                        nFoundPortGrpIdx = j;
                        break;
                    }
                }
                if ( 0 > nFoundPortGrpIdx )
                {
                    PPT_METHODTRACE_V2("", "##### Not Found PortGroup !!!!!", pptEqpOnePortGroupInfoSeq[i].strPortGroup.portGroup);
                    continue; //[i]
                }

                if ( 0 != CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[nFoundPortGrpIdx].dispatchMode, SP_Eqp_DispatchMode_Auto)
                  && 0 != CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[nFoundPortGrpIdx].accessMode,   SP_Eqp_AccessMode_Auto) )
                {
                    PPT_METHODTRACE_V1("", "dispatchMode != [Auto] and accessMode != [Auto]  ...<<continue>>");
                    continue; //[i]
                }

                CORBA::Long lenPortID = pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID.length();
                for ( j=0; j < lenPortID; j++ )
                {
                    if ( ( 0 == CIMFWStrCmp(pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID[j].portState, SP_PortRsc_PortState_LoadAvail)
                        || 0 == CIMFWStrCmp(pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID[j].portState, SP_PortRsc_PortState_LoadReq)
                        || 0 == CIMFWStrCmp(pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID[j].portState, SP_PortRsc_PortState_UnloadReq) )
                      && 0 == CIMFWStrCmp(pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID[j].dispatchState, SP_PortRsc_DispatchState_Required) )
                    {
                        PPT_METHODTRACE_V3("", "(portState == [LoadAvail] or [LoadReq] or [UnloadReq]) and dispatchState == [Required]", i, j);

                        // Omit LoadAvail of Semi2 and LoadReq [D4000251]
                        if ( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[nFoundPortGrpIdx].dispatchMode, SP_Eqp_DispatchMode_Manual)
                          && ( 0 == CIMFWStrCmp(pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID[j].portState, SP_PortRsc_PortState_LoadAvail)
                            || 0 == CIMFWStrCmp(pptEqpOnePortGroupInfoSeq[i].strPortGroup.strPortID[j].portState, SP_PortRsc_PortState_LoadReq) ) )
                        {
                            PPT_METHODTRACE_V1("", "DispatchMode == [Manual] and (portState == [LoadAvail] or [LoadReq])   <-----[D4000251]");
                            // Omit Semi-2
                        }
                        else
                        {
                            PPT_METHODTRACE_V2("", "@@@@@ Add Return EquipmentIDs ----->", pptEqpOnePortGroupInfoSeq[i].equipmentID.identifier);
                            returnEqpSeq[ nSetCnt ] = pptEqpOnePortGroupInfoSeq[i].equipmentID;
                            nSetCnt++;
                            break;
                        }
                    }
                }
            }

            PPT_METHODTRACE_V2("", "Add Return EquipmentIDs Count ----->", nSetCnt);
            returnEqpSeq.length( nSetCnt );

            strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs = returnEqpSeq;

            PPT_METHODTRACE_EXIT("PPTManager_i::availableEquipment_GetForDeliveryReqDR");
            return RC_OK;
        }
//D40A0010 end

//D40A0010 delete start
//D40A0010        else if ( CIMFWStrLen( lotID.identifier ) != 0 )
//D40A0010        {
//D40A0010            PPT_METHODTRACE_V2("", "CIMFWStrLen( lotID.identifier ) != 0", lotID.identifier);
//D40A0010
//D40A0010            PosLot_var aLot;
//D40A0010            PPT_CONVERT_LOTID_TO_LOT_OR( aLot, lotID,
//D40A0010                                         strAvailableEquipment_GetForDeliveryReqDR_out,
//D40A0010                                         availableEquipment_GetForDeliveryReqDR );
//D40A0010
//D40A0010            if ( CORBA::is_nil( aLot ) == TRUE )
//D40A0010            {
//D40A0010                PPT_METHODTRACE_V1("", "CORBA::is_nil( aLot ) == TRUE");
//D40A0010
//D40A0010                PPT_SET_MSG_RC_KEY( strAvailableEquipment_GetForDeliveryReqDR_out,
//D40A0010                                    MSG_NOT_FOUND_LOT, RC_NOT_FOUND_LOT,
//D40A0010                                    cassetteID.identifier );
//D40A0010                return RC_NOT_FOUND_LOT;
//D40A0010            }
//D40A0010
//D40A0010            PosMachineSequence* equipmentSeq = NULL;
//D40A0010            PosMachineSequence_var TmpequipmentSeq = NULL;
//D40A0010
//D40A0010            try
//D40A0010            {
//D40A0010                equipmentSeq = aLot->getQueuedMachines();
//D40A0010                TmpequipmentSeq = equipmentSeq;
//D40A0010            }
//D40A0010            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getQueuedMachines);
//D40A0010
//D40A0010            CORBA::Long nMachineQLen   = equipmentSeq->length();
//D40A0010            PPT_METHODTRACE_V2("", "equipmentSeq->length()", nMachineQLen);
//D40A0010
//D40A0010            objectIdentifier         tempEquipmentID; //0.01
//D40A0010            objectIdentifierSequence dispatchEqpSeq;
//D40A0010            TimeStampSequence        dispatchTimeSeq;
//D40A0010            dispatchEqpSeq.length(0);
//D40A0010            dispatchTimeSeq.length(0);
//D40A0010
//D40A0010            for( i=0 ; i< nMachineQLen ; i++ )
//D40A0010            {
//D40A0010                PPT_METHODTRACE_V2("", "loop to equipmentSeq->length()", i);
//D40A0010                PPT_SET_OBJECT_IDENTIFIER( tempEquipmentID, (*equipmentSeq)[i],                     //0.01
//D40A0010                                           strAvailableEquipment_GetForDeliveryReqDR_out,           //0.01
//D40A0010                                           availableEquipment_GetForDeliveryReqDR, PosMachine);     //0.01
//D40A0010
//D40A0010                /*----------------------------*/
//D40A0010                /*   Get Eqp Operation Mode   */
//D40A0010                /*----------------------------*/
//D40A0010                objEquipment_portInfo_Get_out    strEquipment_portInfo_Get_out;
//D40A0010                rc = equipment_portInfo_Get(strEquipment_portInfo_Get_out,
//D40A0010                                            strObjCommonIn,
//D40A0010                                            tempEquipmentID); //0.01
//D40A0010//0.01                                      equipmentID);
//D40A0010
//D40A0010                if ( rc != RC_OK )
//D40A0010                {
//D40A0010                    PPT_METHODTRACE_V1("", "rc != RC_OK");
//D40A0010
//D40A0010                    strAvailableEquipment_GetForDeliveryReqDR_out.strResult = strEquipment_portInfo_Get_out.strResult;
//D40A0010                    PPT_METHODTRACE_EXIT("PPTManager_i::availableEquipment_GetForDeliveryReqDR");
//D40A0010                    return rc; //0.01
//D40A0010//0.01              return RC_OK;
//D40A0010                }
//D40A0010
//D40A0010                CORBA::Long strEqpPortInfo_len = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
//D40A0010                PPT_METHODTRACE_V3("", "strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length()", strEqpPortInfo_len, i);
//D40A0010
//D40A0010                for ( CORBA::Long pCnt=0; pCnt< strEqpPortInfo_len; pCnt++ )
//D40A0010                {
//D40A0010                    PPT_METHODTRACE_V3("", "loop to strEqpPortInfo.strEqpPortStatus.length()", pCnt, i);
//D40A0010
//D40A0010                    if ( ( CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].dispatchMode, SP_Eqp_DispatchMode_Auto) == 0 ) ||
//D40A0010                         ( CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].accessMode, SP_Eqp_AccessMode_Auto) == 0 ) )
//D40A0010                    {
//D40A0010                        PPT_METHODTRACE_V3("", "( dispatchMode == SP_Eqp_DispatchMode_Auto ) or ( accessMode == SP_Eqp_AccessMode_Auto )", i, pCnt);
//D40A0010
//D40A0010                        if ( ( ( CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portState, "LoadAvail") == 0 ) ||
//D40A0010                               ( CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portState, "LoadReq") == 0 ) ||
//D40A0010                               ( CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portState, "UnloadReq") == 0 ) ) &&
//D40A0010                             ( CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].dispatchState, "Required" ) == 0 ) )
//D40A0010                        {
//D40A0010                            PPT_METHODTRACE_V3("", "( portState == LoadAvail or LoadReq or UnloadReq ) and ( dispatchState == Required )", i, pCnt);
//D40A0010
//D40A0010//D4000251 start
//D40A0010                            PPT_METHODTRACE_V1("", "Omit LoadAvail of Semi2 and LoadReq  [D4000251]");
//D40A0010                            // Omit LoadAvail of Semi2 and LoadReq
//D40A0010                            if ( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].dispatchMode, SP_Eqp_DispatchMode_Manual) )
//D40A0010                            {
//D40A0010                                PPT_METHODTRACE_V1("", "DispatchMode == Manual");
//D40A0010                                if ( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portState, SP_PortRsc_PortState_LoadAvail)
//D40A0010                                  || 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portState, SP_PortRsc_PortState_LoadReq) )
//D40A0010                                {
//D40A0010                                    PPT_METHODTRACE_V1("", "PortState == LoadAvail or LoadReq   ...<<continue>>");
//D40A0010                                    continue; //[pCnt]
//D40A0010                                }
//D40A0010                            }
//D40A0010//D4000251 end
//D40A0010
//D40A0010                            /*-----------------------*/
//D40A0010                            /*   Get Port Sequence   */
//D40A0010                            /*-----------------------*/
//D40A0010                            PortResourceSequence*       portRscSeq=NULL;
//D40A0010                            PortResourceSequence_var    portRscSeqVar;
//D40A0010                            try
//D40A0010                            {
//D40A0010                                portRscSeq    = (*equipmentSeq)[i]->allPortResources();
//D40A0010                                portRscSeqVar = portRscSeq;
//D40A0010                            }
//D40A0010                            CATCH_AND_RAISE_EXCEPTIONS(PosMachine::allPortResources);
//D40A0010
//D40A0010                            /*--------------------------------------------------------*/
//D40A0010                            /*   Get Earliest lastDispatchTimeStamp  from all ports   */
//D40A0010                            /*--------------------------------------------------------*/
//D40A0010                            CORBA::Long portSeqLen        = portRscSeq->length();
//D40A0010                            PPT_METHODTRACE_V4("", "portRscSeq->length()", portSeqLen, i, pCnt);
//D40A0010
//D40A0010                            CORBA::Boolean initialSetFlag = TRUE;
//D40A0010                            TimeStamp      workTimeStamp  = CIMFWStrDup("");
//D40A0010                            TimeStamp      saveTimeStamp  = CIMFWStrDup("");
//D40A0010
//D40A0010                            for ( CORBA::Long v=0; v< portSeqLen; v++ )
//D40A0010                            {
//D40A0010                                PPT_METHODTRACE_V4("", "loop to portRscSeq->length()", i, pCnt, v);
//D40A0010
//D40A0010                                PosPortResource_var aPortResource=PosPortResource::_narrow((*portRscSeq)[v]);
//D40A0010
//D40A0010                                if(CORBA::is_nil(aPortResource))
//D40A0010                                {
//D40A0010                                    PPT_SET_MSG_RC_KEY( strAvailableEquipment_GetForDeliveryReqDR_out,
//D40A0010                                                        MSG_NOT_FOUND_PORTRESOURCE,
//D40A0010                                                        RC_NOT_FOUND_PORTRESOURCE, "" );
//D40A0010                                    return RC_NOT_FOUND_PORTRESOURCE;
//D40A0010                                }
//D40A0010
//D40A0010                                CORBA::String_var dispatchState;
//D40A0010
//D40A0010                                try
//D40A0010                                {
//D40A0010                                    dispatchState = aPortResource->getDispatchState();
//D40A0010                                }
//D40A0010                                CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::getDispatchState);
//D40A0010
//D40A0010                                if ( CIMFWStrCmp(dispatchState, SP_PortRsc_DispatchState_Required) == 0 )
//D40A0010                                {
//D40A0010                                    PPT_METHODTRACE_V2("", "CIMFWStrCmp(dispatchState, SP_PortRsc_DispatchState_Required) == 0", v);
//D40A0010
//D40A0010                                    try
//D40A0010                                    {
//D40A0010                                        workTimeStamp = aPortResource->getLastDispatchRequiredTimeStamp();
//D40A0010                                    }
//D40A0010                                    CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::getLastDispatchedTimeStamp);
//D40A0010
//D40A0010                                    if ( initialSetFlag == TRUE )
//D40A0010                                    {
//D40A0010                                        PPT_METHODTRACE_V2("", "initialSetFlag == TRUE", v);
//D40A0010                                        saveTimeStamp = workTimeStamp;
//D40A0010                                        initialSetFlag = FALSE;
//D40A0010                                    }
//D40A0010                                    else
//D40A0010                                    {
//D40A0010                                        PPT_METHODTRACE_V2("", "initialSetFlag == FALSE", v);
//D40A0010                                        if ( CIMFWStrCmp(saveTimeStamp, workTimeStamp) > 0 )
//D40A0010                                        {
//D40A0010                                            PPT_METHODTRACE_V2("", "iCIMFWStrCmp(saveTimeStamp, workTimeStamp) > 0", v);
//D40A0010
//D40A0010                                            saveTimeStamp = workTimeStamp;
//D40A0010                                        }
//D40A0010                                    }
//D40A0010                                }
//D40A0010                            }  // end of for( v )
//D40A0010
//D40A0010                            if ( initialSetFlag == FALSE )
//D40A0010                            {
//D40A0010                                PPT_METHODTRACE_V3("", "initialSetFlag == FALSE", i, pCnt);
//D40A0010
//D40A0010                                dispatchEqpSeq.length(deliverableEqpCount+1);
//D40A0010                                PPT_SET_OBJECT_IDENTIFIER(dispatchEqpSeq[deliverableEqpCount],
//D40A0010                                                          (*equipmentSeq)[i],
//D40A0010                                                          strAvailableEquipment_GetForDeliveryReqDR_out,
//D40A0010                                                          availableEquipment_GetForDeliveryReqDR,
//D40A0010                                                          PosMachine);
//D40A0010
//D40A0010                                dispatchTimeSeq.length(deliverableEqpCount+1);
//D40A0010                                dispatchTimeSeq[deliverableEqpCount] = saveTimeStamp;
//D40A0010                                deliverableEqpCount++;
//D40A0010
//D40A0010                                PPT_METHODTRACE_V4("", "deliverableEqpCount", deliverableEqpCount, i, pCnt );
//D40A0010                            }
//D40A0010                        }
//D40A0010                    }
//D40A0010                } // end of for( pCnt )
//D40A0010            }  // end of for( i )
//D40A0010
//D40A0010            /*----------------------------------------*/
//D40A0010            /*   Set returned equipmentIDs sequence   */
//D40A0010            /*----------------------------------------*/
//D40A0010            if ( deliverableEqpCount == 0 )
//D40A0010            {
//D40A0010                PPT_METHODTRACE_V1("", "deliverableEqpCount == 0");
//D40A0010                strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs.length(0);
//D40A0010            }
//D40A0010            else if ( deliverableEqpCount == 1 )
//D40A0010            {
//D40A0010                PPT_METHODTRACE_V1("", "deliverableEqpCount == 1");
//D40A0010                strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs.length(1);
//D40A0010                strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs[0] = dispatchEqpSeq[0];
//D40A0010            }
//D40A0010            else
//D40A0010            {
//D40A0010                /*---------------------------------------------------------*/
//D40A0010                /*   Sort  dispatchEqpSeq[]   <--objectIdentiferSequence   */
//D40A0010                /*   using dispatchTimeSeq[]  <--timestampSequence         */
//D40A0010                /*---------------------------------------------------------*/
//D40A0010                PPT_METHODTRACE_V1("", "else");
//D40A0010
//D40A0010                strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs.length(deliverableEqpCount);
//D40A0010
//D40A0010                CORBA::Long iSortCounter = 0;
//D40A0010                CORBA::Long iTmpDeliberableEqpCount = deliverableEqpCount;
//D40A0010
//D40A0010                PPT_METHODTRACE_V2("", "deliverableEqpCount", deliverableEqpCount);
//D40A0010
//D40A0010                for ( iSortCounter=0; iSortCounter< deliverableEqpCount; iSortCounter++ )
//D40A0010                {
//D40A0010                    PPT_METHODTRACE_V2("","[Round]             ",iSortCounter);
//D40A0010                    PPT_METHODTRACE_V2("","[Equipment ID]      ",dispatchEqpSeq[iSortCounter].identifier);
//D40A0010                    PPT_METHODTRACE_V2("","[Dispatch TimeStamp]",dispatchTimeSeq[iSortCounter]);
//D40A0010                }
//D40A0010
//D40A0010                for ( iSortCounter=0; iSortCounter< deliverableEqpCount; iSortCounter++ )
//D40A0010                {
//D40A0010                    CORBA::Long iEqpSeqNumber = 0;
//D40A0010                    CORBA::Long iSortCounter2 = 0;
//D40A0010                    TimeStamp tmpTimeStampForSort = dispatchTimeSeq[0];
//D40A0010
//D40A0010                    for( iSortCounter2=0; iSortCounter2<iTmpDeliberableEqpCount; iSortCounter2++ )
//D40A0010                    {
//D40A0010                        if( CIMFWStrCmp(tmpTimeStampForSort, dispatchTimeSeq[iSortCounter2]) > 0 )
//D40A0010                        {
//D40A0010                            PPT_METHODTRACE_V3("","CIMFWStrCmp(tmpTimeStampForSort, dispatchTimeSeq[iSortCounter2]) > 0", iSortCounter, iSortCounter2);
//D40A0010
//D40A0010                            iEqpSeqNumber = iSortCounter2;
//D40A0010                            tmpTimeStampForSort = dispatchTimeSeq[iSortCounter2];
//D40A0010                        }
//D40A0010                    }
//D40A0010
//D40A0010                    strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs[iSortCounter] = dispatchEqpSeq[iEqpSeqNumber];
//D40A0010
//D40A0010                    PPT_METHODTRACE_V2("","[Round]             ",iSortCounter);
//D40A0010                    PPT_METHODTRACE_V2("","[Equipment ID]      ",strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs[iSortCounter].identifier);
//D40A0010                    PPT_METHODTRACE_V2("","[Dispatch TimeStamp]",tmpTimeStampForSort);
//D40A0010
//D40A0010                    CORBA::Long iSortCounter3 = 0;
//D40A0010                    for ( iSortCounter3=iEqpSeqNumber; iSortCounter3<iTmpDeliberableEqpCount-1; iSortCounter3++ )
//D40A0010                    {
//D40A0010                        dispatchEqpSeq[iSortCounter3] = dispatchEqpSeq[iSortCounter3+1];
//D40A0010                        dispatchTimeSeq[iSortCounter3] = dispatchTimeSeq[iSortCounter3+1];
//D40A0010                    }
//D40A0010
//D40A0010                    dispatchEqpSeq.length(iTmpDeliberableEqpCount-1);
//D40A0010                    dispatchTimeSeq.length(iTmpDeliberableEqpCount-1);
//D40A0010                    iTmpDeliberableEqpCount--;
//D40A0010                }
//D40A0010
//D40A0010                PPT_METHODTRACE_V1("","=== Check Output Equipment Sequence ===");
//D40A0010                for ( iSortCounter=0; iSortCounter<deliverableEqpCount; iSortCounter++ )
//D40A0010                {
//D40A0010                    PPT_METHODTRACE_V2("","[Round]             ",iSortCounter);
//D40A0010                    PPT_METHODTRACE_V2("","[Equipment ID]      ",strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs[iSortCounter].identifier);
//D40A0010                }
//D40A0010            }
//D40A0010
//D40A0010            PPT_METHODTRACE_EXIT("PPTManager_i::availableEquipment_GetForDeliveryReqDR");
//D40A0010            return RC_OK;
//D40A0010        }
//D40A0010        else if ( CIMFWStrLen( cassetteID.identifier ) != 0 )
//D40A0010        {
//D40A0010            PPT_METHODTRACE_V2("", "CIMFWStrLen( cassetteID.identifier ) != 0", cassetteID.identifier);
//D40A0010
//D40A0010            PosCassette_var aCassette;
//D40A0010            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette, cassetteID,
//D40A0010                                                   strAvailableEquipment_GetForDeliveryReqDR_out,
//D40A0010                                                   availableEquipment_GetForDeliveryReqDR );
//D40A0010
//D40A0010//0.03            if ( CORBA::is_nil( aCassette ) == TRUE )
//D40A0010//0.03            {
//D40A0010//0.03                PPT_METHODTRACE_V1("", "CORBA::is_nil( aCassette ) == TRUE");
//D40A0010//0.03
//D40A0010//0.03                PPT_SET_MSG_RC_KEY( strAvailableEquipment_GetForDeliveryReqDR_out,
//D40A0010//0.03                                    MSG_NOT_FOUND_CASSETTE , RC_NOT_FOUND_CASSETTE,
//D40A0010//0.03                                    cassetteID.identifier );
//D40A0010//0.03                return RC_NOT_FOUND_CASSETTE;
//D40A0010//0.03            }
//D40A0010
//D40A0010            LotSequence* lotIDs = NULL;
//D40A0010            LotSequence_var lotIDsVar;
//D40A0010
//D40A0010            try
//D40A0010            {
//D40A0010                PPT_DISPLAY_RESPONSE_TIME();
//D40A0010                lotIDs = aCassette->allLots();
//D40A0010                lotIDsVar = lotIDs;
//D40A0010            }
//D40A0010            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::allLots);
//D40A0010
//D40A0010            CORBA::Long nLen = lotIDs->length();
//D40A0010            PPT_METHODTRACE_V2("", "lotIDs->length()", nLen);
//D40A0010
//D40A0010            if ( nLen == 0 )
//D40A0010            {
//D40A0010                PPT_SET_MSG_RC_KEY( strAvailableEquipment_GetForDeliveryReqDR_out,
//D40A0010                                    MSG_NOT_FOUND_LOT, RC_NOT_FOUND_LOT,
//D40A0010                                    cassetteID.identifier );
//D40A0010                return RC_NOT_FOUND_LOT;
//D40A0010            }
//D40A0010
//D40A0010            PosMachineSequence* equipmentSeq = NULL;
//D40A0010            PosMachineSequence_var TmpequipmentSeq;
//D40A0010
//D40A0010            objectIdentifierSequence dispatchEqpSeq;
//D40A0010            TimeStampSequence        dispatchTimeSeq;
//D40A0010            dispatchEqpSeq.length(0);
//D40A0010            dispatchTimeSeq.length(0);
//D40A0010
//D40A0010            for ( k=0; k< nLen ; k++ )
//D40A0010            {
//D40A0010                PPT_METHODTRACE_V2("", "loop to lotIDs->length()", k);
//D40A0010
//D40A0010                PosLot_var aLot = PosLot::_narrow( (*lotIDs)[k] );
//D40A0010
//D40A0010                if ( CORBA::is_nil(aLot) )
//D40A0010                {
//D40A0010                    PPT_METHODTRACE_V2("", "CORBA::is_nil(aLot)", k);
//D40A0010                    PPT_SET_MSG_RC_KEY( strAvailableEquipment_GetForDeliveryReqDR_out,
//D40A0010                                        MSG_NOT_FOUND_LOT,
//D40A0010                                        RC_NOT_FOUND_LOT, "" );
//D40A0010                    return RC_NOT_FOUND_LOT;
//D40A0010                }
//D40A0010
//D40A0010                try
//D40A0010                {
//D40A0010                    equipmentSeq = aLot->getQueuedMachines();
//D40A0010                    TmpequipmentSeq = equipmentSeq;
//D40A0010                }
//D40A0010                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getQueuedMachines);
//D40A0010
//D40A0010                CORBA::Long  l, nMachineQLen = equipmentSeq->length();
//D40A0010                PPT_METHODTRACE_V3("", "equipmentSeq->length()", nMachineQLen, k);
//D40A0010
//D40A0010                objectIdentifier tempEquipmentID; //0.01
//D40A0010
//D40A0010                for ( i=0 ; i< nMachineQLen ; i++ )
//D40A0010                {
//D40A0010                    PPT_METHODTRACE_V3("", "loop to equipmentSeq->length()", k, i);
//D40A0010                    PPT_SET_OBJECT_IDENTIFIER( tempEquipmentID, (*equipmentSeq)[i],                 //0.01
//D40A0010                                               strAvailableEquipment_GetForDeliveryReqDR_out,       //0.01
//D40A0010                                               availableEquipment_GetForDeliveryReqDR, PosMachine); //0.01
//D40A0010
//D40A0010                    /*----------------------------*/
//D40A0010                    /*   Get Eqp Operation Mode   */
//D40A0010                    /*----------------------------*/
//D40A0010                    objEquipment_portInfo_Get_out    strEquipment_portInfo_Get_out;
//D40A0010                    rc = equipment_portInfo_Get(strEquipment_portInfo_Get_out,
//D40A0010                                                strObjCommonIn,
//D40A0010                                                tempEquipmentID); //0.01
//D40A0010//0.01                                          equipmentID);
//D40A0010
//D40A0010                    if ( rc != RC_OK )
//D40A0010                    {
//D40A0010                        strAvailableEquipment_GetForDeliveryReqDR_out.strResult = strEquipment_portInfo_Get_out.strResult;
//D40A0010                        PPT_METHODTRACE_EXIT("PPTManager_i::availableEquipment_GetForDeliveryReqDR");
//D40A0010                        return rc;
//D40A0010//0.01                  return RC_OK;
//D40A0010                    }
//D40A0010
//D40A0010                    CORBA::Long strEqpPortInfo_len = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
//D40A0010                    PPT_METHODTRACE_V4("", "strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length()", strEqpPortInfo_len, k, i);
//D40A0010
//D40A0010                    for ( CORBA::Long pCnt=0; pCnt < strEqpPortInfo_len; pCnt++ )
//D40A0010                    {
//D40A0010                        PPT_METHODTRACE_V4("", "loop to strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length()", k, i, pCnt);
//D40A0010
//D40A0010                        if ( ( CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].dispatchMode, SP_Eqp_DispatchMode_Auto) == 0 ) ||
//D40A0010                             ( CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].accessMode, SP_Eqp_AccessMode_Auto) == 0 ) )
//D40A0010                        {
//D40A0010                            PPT_METHODTRACE_V2("", "( dispatchMode == SP_Eqp_DispatchMode_Auto ) or ( accessMode == SP_Eqp_AccessMode_Auto )", pCnt);
//D40A0010
//D40A0010                            if ( ( ( CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portState, "LoadAvail") == 0 ) ||
//D40A0010                                   ( CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portState, "LoadReq") == 0 ) ||
//D40A0010                                   ( CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portState, "UnloadReq") == 0 ) ) &&
//D40A0010                                 ( CIMFWStrCmp( strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].dispatchState, "Required" ) == 0 ) )
//D40A0010                            {
//D40A0010                                PPT_METHODTRACE_V2("", "( portState == LoadAvail or LoadReq or UnloadReq ) and ( dispatchState == Required )", pCnt);
//D40A0010
//D40A0010//D40A0011 start
//D40A0010                                PPT_METHODTRACE_V1("", "Omit LoadAvail of Semi2 and LoadReq  [D4000251]");
//D40A0010                                // Omit LoadAvail of Semi2 and LoadReq
//D40A0010                                if ( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].dispatchMode, SP_Eqp_DispatchMode_Manual) )
//D40A0010                                {
//D40A0010                                    PPT_METHODTRACE_V1("", "DispatchMode == Manual");
//D40A0010                                    if ( 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portState, SP_PortRsc_PortState_LoadAvail)
//D40A0010                                      || 0 == CIMFWStrCmp(strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[pCnt].portState, SP_PortRsc_PortState_LoadReq) )
//D40A0010                                    {
//D40A0010                                        PPT_METHODTRACE_V1("", "PortState == LoadAvail or LoadReq   ...<<continue>>");
//D40A0010                                        continue; //[pCnt]
//D40A0010                                    }
//D40A0010                                }
//D40A0010//D40A0011 end
//D40A0010
//D40A0010                                /*-----------------------*/
//D40A0010                                /*   Get Port Sequence   */
//D40A0010                                /*-----------------------*/
//D40A0010                                PortResourceSequence*       portRscSeq=NULL;
//D40A0010                                PortResourceSequence_var    portRscSeqVar;
//D40A0010
//D40A0010                                try
//D40A0010                                {
//D40A0010                                    portRscSeq    = (*equipmentSeq)[i]->allPortResources();
//D40A0010                                    portRscSeqVar = portRscSeq;
//D40A0010                                }
//D40A0010                                CATCH_AND_RAISE_EXCEPTIONS(PosMachine::allPortResources);
//D40A0010
//D40A0010                                /*--------------------------------------------------------*/
//D40A0010                                /*   Get Earliest lastDispatchTimeStamp  from all ports   */
//D40A0010                                /*--------------------------------------------------------*/
//D40A0010                                CORBA::Long portSeqLen        = portRscSeq->length();
//D40A0010                                PPT_METHODTRACE_V2("", "portRscSeq->length()", portSeqLen);
//D40A0010
//D40A0010                                CORBA::Boolean initialSetFlag = TRUE;
//D40A0010                                TimeStamp      workTimeStamp  = CIMFWStrDup("");
//D40A0010                                TimeStamp      saveTimeStamp  = CIMFWStrDup("");
//D40A0010
//D40A0010                                for ( CORBA::Long v=0 ; v<portSeqLen ; v++ )
//D40A0010                                {
//D40A0010                                    PPT_METHODTRACE_V2("", "loop to portRscSeq->length()", v);
//D40A0010
//D40A0010                                    PosPortResource_var aPortResource=PosPortResource::_narrow((*portRscSeq)[v]);
//D40A0010
//D40A0010                                    if ( CORBA::is_nil(aPortResource) )
//D40A0010                                    {
//D40A0010                                        PPT_METHODTRACE_V2("", "CORBA::is_nil(aPortResource)", v);
//D40A0010                                        PPT_SET_MSG_RC_KEY( strAvailableEquipment_GetForDeliveryReqDR_out,
//D40A0010                                                            MSG_NOT_FOUND_PORTRESOURCE,
//D40A0010                                                            RC_NOT_FOUND_PORTRESOURCE, "" );
//D40A0010                                        return RC_NOT_FOUND_PORTRESOURCE;
//D40A0010                                    }
//D40A0010
//D40A0010                                    CORBA::String_var dispatchState;
//D40A0010                                    try
//D40A0010                                    {
//D40A0010                                        dispatchState = aPortResource->getDispatchState();
//D40A0010                                    }
//D40A0010                                    CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::getDispatchState);
//D40A0010
//D40A0010                                    if ( CIMFWStrCmp(dispatchState, SP_PortRsc_DispatchState_Required) == 0 )
//D40A0010                                    {
//D40A0010                                        PPT_METHODTRACE_V2("", "CIMFWStrCmp(dispatchState, SP_PortRsc_DispatchState_Required) == 0", v);
//D40A0010
//D40A0010                                        try
//D40A0010                                        {
//D40A0010                                            workTimeStamp = aPortResource->getLastDispatchRequiredTimeStamp();
//D40A0010                                        }
//D40A0010                                        CATCH_AND_RAISE_EXCEPTIONS(PosPortResource::getLastDispatchedTimeStamp);
//D40A0010
//D40A0010                                        if ( initialSetFlag == TRUE )
//D40A0010                                        {
//D40A0010                                            PPT_METHODTRACE_V2("", "initialSetFlag == TRUE", v);
//D40A0010
//D40A0010                                            saveTimeStamp = workTimeStamp;
//D40A0010                                            initialSetFlag = FALSE;
//D40A0010                                        }
//D40A0010                                        else
//D40A0010                                        {
//D40A0010                                            PPT_METHODTRACE_V2("", "initialSetFlag == FALSE", v);
//D40A0010                                            if ( CIMFWStrCmp(saveTimeStamp, workTimeStamp) > 0 )
//D40A0010                                            {
//D40A0010                                                PPT_METHODTRACE_V2("", "CIMFWStrCmp(saveTimeStamp, workTimeStamp) > 0", v);
//D40A0010                                                saveTimeStamp = workTimeStamp;
//D40A0010                                            }
//D40A0010                                        }
//D40A0010                                    }
//D40A0010                                }  // end of for ( v )
//D40A0010
//D40A0010                                if ( initialSetFlag == FALSE )
//D40A0010                                {
//D40A0010                                   PPT_METHODTRACE_V1("", "initialSetFlag == FALSE ");
//D40A0010
//D40A0010                                    dispatchEqpSeq.length(deliverableEqpCount+1);
//D40A0010                                    PPT_SET_OBJECT_IDENTIFIER(dispatchEqpSeq[deliverableEqpCount],
//D40A0010                                                              (*equipmentSeq)[i],
//D40A0010                                                               strAvailableEquipment_GetForDeliveryReqDR_out,
//D40A0010                                                               availableEquipment_GetForDeliveryReqDR,
//D40A0010                                                               PosMachine);
//D40A0010
//D40A0010                                    dispatchTimeSeq.length(deliverableEqpCount+1);
//D40A0010                                    dispatchTimeSeq[deliverableEqpCount] = saveTimeStamp;
//D40A0010                                    deliverableEqpCount++;
//D40A0010
//D40A0010                                    PPT_METHODTRACE_V2("", "deliverableEqpCount", deliverableEqpCount);
//D40A0010                               }
//D40A0010                            }
//D40A0010                        }
//D40A0010                    }  // end of for( pCnt )
//D40A0010                }  // end of for( i )
//D40A0010            }  // end of ( k )
//D40A0010
//D40A0010            /*----------------------------------------*/
//D40A0010            /*   Set returned equipmentIDs sequence   */
//D40A0010            /*----------------------------------------*/
//D40A0010            PPT_METHODTRACE_V2("", "deliverableEqpCount", deliverableEqpCount);
//D40A0010
//D40A0010            if ( deliverableEqpCount == 0 )
//D40A0010            {
//D40A0010                strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs.length(0);
//D40A0010            }
//D40A0010            else if ( deliverableEqpCount == 1 )
//D40A0010            {
//D40A0010                strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs.length(1);
//D40A0010                strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs[0] = dispatchEqpSeq[0];
//D40A0010            }
//D40A0010            else
//D40A0010            {
//D40A0010                /*---------------------------------------------------------*/
//D40A0010                /*   Sort  dispatchEqpSeq[]   <--objectIdentiferSequence   */
//D40A0010                /*   using dispatchTimeSeq[]  <--timestampSequence         */
//D40A0010                /*---------------------------------------------------------*/
//D40A0010                strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs.length(deliverableEqpCount);
//D40A0010
//D40A0010                CORBA::Long iSortCounter = 0;
//D40A0010                CORBA::Long iTmpDeliberableEqpCount = deliverableEqpCount;
//D40A0010
//D40A0010                for ( iSortCounter=0; iSortCounter< deliverableEqpCount; iSortCounter++ )
//D40A0010                {
//D40A0010                    PPT_METHODTRACE_V2("", "loop for deliverableEqpCount", iSortCounter);
//D40A0010
//D40A0010                    CORBA::Long iEqpSeqNumber = 0;
//D40A0010                    CORBA::Long iSortCounter2 = 0;
//D40A0010                    TimeStamp tmpTimeStampForSort = dispatchTimeSeq[0];
//D40A0010
//D40A0010                    for ( iSortCounter2=0; iSortCounter2<iTmpDeliberableEqpCount; iSortCounter2++ )
//D40A0010                    {
//D40A0010                        PPT_METHODTRACE_V2("", "loop for iTmpDeliberableEqpCount", iSortCounter2);
//D40A0010
//D40A0010                        if ( CIMFWStrCmp(tmpTimeStampForSort, dispatchTimeSeq[iSortCounter2]) > 0 )
//D40A0010                        {
//D40A0010                            PPT_METHODTRACE_V3("", "CIMFWStrCmp(tmpTimeStampForSort, dispatchTimeSeq[iSortCounter2]) > 0", iSortCounter, iSortCounter2);
//D40A0010
//D40A0010                            iEqpSeqNumber = iSortCounter2;
//D40A0010                            tmpTimeStampForSort = dispatchTimeSeq[iSortCounter2];
//D40A0010                        }
//D40A0010                    }
//D40A0010
//D40A0010                    strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs[iSortCounter] = dispatchEqpSeq[iEqpSeqNumber];
//D40A0010
//D40A0010                    CORBA::Long iSortCounter3 = 0;
//D40A0010                    for ( iSortCounter3=iEqpSeqNumber; iSortCounter3< iTmpDeliberableEqpCount-1; iSortCounter3++ )
//D40A0010                    {
//D40A0010                        PPT_METHODTRACE_V2("", "loop to iTmpDeliberableEqpCount-1", iSortCounter3);
//D40A0010
//D40A0010                        dispatchEqpSeq[iSortCounter3] = dispatchEqpSeq[iSortCounter3+1];
//D40A0010                        dispatchTimeSeq[iSortCounter3] = dispatchTimeSeq[iSortCounter3+1];
//D40A0010                    }
//D40A0010
//D40A0010                    dispatchEqpSeq.length(iTmpDeliberableEqpCount-1);
//D40A0010                    dispatchTimeSeq.length(iTmpDeliberableEqpCount-1);
//D40A0010                    iTmpDeliberableEqpCount--;
//D40A0010                }
//D40A0010            }
//D40A0010
//D40A0010            PPT_METHODTRACE_EXIT("PPTManager_i::availableEquipment_GetForDeliveryReqDR");
//D40A0010            return RC_OK;
//D40A0010        }
//D40A0010 delete end

        /****************************************************************************************/
        /*                                                                                      */
        /*                                                                                      */
        /*   When it is examined about LotID or DurableID.                                      */
        /*                                                                                      */
        /*                                                                                      */
        /****************************************************************************************/
        else if ( CIMFWStrLen( durableID.identifier ) != 0 )
        {
            PPT_METHODTRACE_V2("", "CIMFWStrLen( durableID.identifier ) != 0", durableID.identifier);

            PosProcessDurable_var aDurable;

            PPT_CONVERT_RETICLEID_TO_RETICLE_OR( aDurable, durableID,
                                                 strAvailableEquipment_GetForDeliveryReqDR_out,
                                                 availableEquipment_GetForDeliveryReqDR );

            if ( CORBA::is_nil( aDurable ) == TRUE )
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil( aDurable ) == TRUE");

//P5000145                 PPT_SET_MSG_RC_KEY( strAvailableEquipment_GetForDeliveryReqDR_out,
//P5000145                                     MSG_NOT_FOUND_DURABLE, RC_NOT_FOUND_DURABLE,
//P5000145                                     durableID.identifier );
                SET_MSG_RC( strAvailableEquipment_GetForDeliveryReqDR_out,    //P5000145
                            MSG_NOT_FOUND_DURABLE, RC_NOT_FOUND_DURABLE );    //P5000145
                return RC_NOT_FOUND_DURABLE;
            }

            if ( aDurable->isEquipmentIn() == TRUE )
            {
                PPT_METHODTRACE_V1("", "aDurable->isEquipmentIn() == TRUE");

                Machine_var aMachine;

                try
                {
                    aMachine = aDurable->currentAssignedMachine();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::currentAssignedMachine);

                // PTR3000037 Start
                if ( CORBA::is_nil(aMachine) == TRUE )
                {
                    PPT_METHODTRACE_V1("", "CORBA::is_nil(aMachine) == TRUE");
                    strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs.length(0);
                    PPT_METHODTRACE_EXIT("PPTManager_i::availableEquipment_GetForDeliveryReqDR");
                    return RC_OK;
                }
                // PTR3000037 End

                strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs.length(deliverableEqpCount+1);
                PPT_SET_OBJECT_IDENTIFIER( strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs[deliverableEqpCount],
                                           aMachine,
                                           strAvailableEquipment_GetForDeliveryReqDR_out,
                                           availableEquipment_GetForDeliveryReqDR, PosMachine );

                deliverableEqpCount++;
                PPT_METHODTRACE_EXIT("PPTManager_i::availableEquipment_GetForDeliveryReqDR");
                return RC_OK;
            }
        }

        strAvailableEquipment_GetForDeliveryReqDR_out.equipmentIDs.length(deliverableEqpCount);
        SET_MSG_RC(strAvailableEquipment_GetForDeliveryReqDR_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
        return RC_SYSTEM_ERROR;
    }
    CATCH_GLOBAL_EXCEPTIONS(strAvailableEquipment_GetForDeliveryReqDR_out, availableEquipment_GetForDeliveryReqDR, methodName)
}
