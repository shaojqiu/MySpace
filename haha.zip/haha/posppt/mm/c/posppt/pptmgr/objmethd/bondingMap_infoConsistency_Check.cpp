//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
//
// SiView
// Name: bondingMap_infoConsistency_Check.cpp
//

#include "pptmgr.hpp"
#include "plot.hh"
#include "pprsp.hh"
#include "pmc.hh"
#include "ppcope.hh"
#include "ppcdf.hh"
#include "pctrlj.hh"
#include "plcrc.hh"
#include "pmcrc.hh"
#include "pwafer.hh"

//[Object Function Name]: long   bondingMap_infoConsistency_Check
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2010-03-31 DSIV00001830 R.Iriguchi     Wafer Stacking Support
//
//[Function Description]:
//This function checks the FPC Information relations.
//
//[Input Parameters]:
//  const pptObjCommonIn&                               strObjCommonIn
//  const objbondingMap_infoConsistency_Check_in&       strBondingMap_infoConsistency_Check_in
//
//[Output Parameters]:
//  objbondingMap_infoConsistency_Check_out&            strBondingMap_infoConsistency_Check_out
//
//[Return Value]:
//
//  Return Code                          Message ID
//  -----------------------------------  --------------------------------------------------
//  RC_OK                                MSG_OK
//
//[Pseudo Code]
//

CORBA::Long  PPTManager_i::bondingMap_infoConsistency_Check(
    objBondingMap_infoConsistency_Check_out&            strBondingMap_infoConsistency_Check_out,
    const pptObjCommonIn &                              strObjCommonIn,
    const objBondingMap_infoConsistency_Check_in&       strBondingMap_infoConsistency_Check_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY( "PPTManager_i::bondingMap_infoConsistency_Check" );
        CORBA::Long rc;
        const CORBA::Long actualTopFlag = strBondingMap_infoConsistency_Check_in.actualTopFlag;
        const pptBondingMapInfoSequence& strBondingMapInfoSeq = strBondingMap_infoConsistency_Check_in.strBondingMapInfoSeq;
        const CORBA::Long mapLen = strBondingMapInfoSeq.length();

        PosWafer_var aBaseWafer, aTopWafer;
        PosLot_var aBaseLot, aTopLot;
        Lot_var tmpBaseLot, tmpTopLot;
        PosProductSpecification_var aBaseProdSpec, aTopProdSpec;
        ProductSpecification_var tmpBaseProdSpec, tmpTopProdSpec;
       //----------------------------------------------------------------------
        // Check Inputed Bonding Map
        //----------------------------------------------------------------------
        for ( CORBA::Long mapCnt = 0; mapCnt < mapLen; mapCnt++ )
        {
            //----------------------------------------------------------------------
            // Check Fields Filled in
            //----------------------------------------------------------------------
            if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].baseWaferID.identifier ) == 0 )
            {
                PPT_METHODTRACE_V2( "", "Base Wafer ID is not filled.", mapCnt );
                PPT_SET_MSG_RC_KEY( strBondingMap_infoConsistency_Check_out,
                                    MSG_INVALID_PARM_FOR_BONDING_MAP_REPORT, RC_INVALID_PARM_FOR_BONDING_MAP_REPORT,
                                    "Base Wafer ID" );
                return RC_INVALID_PARM_FOR_BONDING_MAP_REPORT;
            }
            if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].baseLotID.identifier ) == 0 )
            {
                PPT_METHODTRACE_V2( "", "Base Lot ID is not filled.", mapCnt );
                PPT_SET_MSG_RC_KEY( strBondingMap_infoConsistency_Check_out,
                                    MSG_INVALID_PARM_FOR_BONDING_MAP_REPORT, RC_INVALID_PARM_FOR_BONDING_MAP_REPORT,
                                    "Base Lot ID" );
                return RC_INVALID_PARM_FOR_BONDING_MAP_REPORT;
            }
            if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].baseProductID.identifier ) == 0 )
            {
                PPT_METHODTRACE_V2( "", "Base Product ID is not filled.", mapCnt );
                PPT_SET_MSG_RC_KEY( strBondingMap_infoConsistency_Check_out,
                                    MSG_INVALID_PARM_FOR_BONDING_MAP_REPORT, RC_INVALID_PARM_FOR_BONDING_MAP_REPORT,
                                    "Base Product ID" );
                return RC_INVALID_PARM_FOR_BONDING_MAP_REPORT;
            }
            if ( actualTopFlag )
            {
                if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier ) == 0 )
                {
                    PPT_METHODTRACE_V2( "", "Actual Top Wafer ID is not filled.", mapCnt );
                    PPT_SET_MSG_RC_KEY( strBondingMap_infoConsistency_Check_out,
                                        MSG_INVALID_PARM_FOR_BONDING_MAP_REPORT, RC_INVALID_PARM_FOR_BONDING_MAP_REPORT,
                                        "Top Wafer ID");
                    return RC_INVALID_PARM_FOR_BONDING_MAP_REPORT;
                }
                if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].actualTopLotID.identifier ) == 0 )
                {
                    PPT_METHODTRACE_V2( "", "Actual Top Lot ID is not filled.", mapCnt );
                    PPT_SET_MSG_RC_KEY( strBondingMap_infoConsistency_Check_out,
                                        MSG_INVALID_PARM_FOR_BONDING_MAP_REPORT, RC_INVALID_PARM_FOR_BONDING_MAP_REPORT,
                                        "Top Lot ID");
                    return RC_INVALID_PARM_FOR_BONDING_MAP_REPORT;
                }
                if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].actualTopProductID.identifier ) == 0 )
                {
                    PPT_METHODTRACE_V2( "", "Actual Top Product ID is not filled.", mapCnt );
                    PPT_SET_MSG_RC_KEY( strBondingMap_infoConsistency_Check_out,
                                        MSG_INVALID_PARM_FOR_BONDING_MAP_REPORT, RC_INVALID_PARM_FOR_BONDING_MAP_REPORT,
                                        "Top Product ID");
                    return RC_INVALID_PARM_FOR_BONDING_MAP_REPORT;
                }
                if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].bondingProcessState ) == 0 )
                {
                    PPT_METHODTRACE_V2( "", "Bonding Process State is not filled.", mapCnt );
                    PPT_SET_MSG_RC_KEY( strBondingMap_infoConsistency_Check_out,
                                        MSG_INVALID_PARM_FOR_BONDING_MAP_REPORT, RC_INVALID_PARM_FOR_BONDING_MAP_REPORT,
                                        "Bonding Process State" );
                    return RC_INVALID_PARM_FOR_BONDING_MAP_REPORT;
                }
            }
            else
            {
                if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].planTopWaferID.identifier ) == 0 )
                {
                    PPT_METHODTRACE_V2( "", "Plan Top Wafer ID is not filled.", mapCnt );
                    PPT_SET_MSG_RC_KEY( strBondingMap_infoConsistency_Check_out,
                                        MSG_INVALID_PARM_FOR_BONDING_MAP_REPORT, RC_INVALID_PARM_FOR_BONDING_MAP_REPORT,
                                        "Top Wafer ID" );
                    return RC_INVALID_PARM_FOR_BONDING_MAP_REPORT;
                }
                if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].planTopLotID.identifier ) == 0 )
                {
                    PPT_METHODTRACE_V2( "", "Plan Top Lot ID is not filled.", mapCnt );
                    PPT_SET_MSG_RC_KEY( strBondingMap_infoConsistency_Check_out,
                                        MSG_INVALID_PARM_FOR_BONDING_MAP_REPORT, RC_INVALID_PARM_FOR_BONDING_MAP_REPORT,
                                        "Top Lot ID");
                    return RC_INVALID_PARM_FOR_BONDING_MAP_REPORT;
                }
                if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].planTopProductID.identifier ) == 0 )
                {
                    PPT_METHODTRACE_V2( "", "Plan Top Product ID is not filled.", mapCnt );
                    PPT_SET_MSG_RC_KEY( strBondingMap_infoConsistency_Check_out,
                                        MSG_INVALID_PARM_FOR_BONDING_MAP_REPORT, RC_INVALID_PARM_FOR_BONDING_MAP_REPORT,
                                        "Top Product ID");
                    return RC_INVALID_PARM_FOR_BONDING_MAP_REPORT;
                }
            }

            //----------------------------------------------------------------------
            // Check Wafer-Lot-Product Consistency
            //----------------------------------------------------------------------
            PPT_CONVERT_WAFERID_TO_WAFER_OR( aBaseWafer, strBondingMapInfoSeq[mapCnt].baseWaferID,
                                             strBondingMap_infoConsistency_Check_out,
                                             bondingMap_infoConsistency_Check );

            PPT_CONVERT_WAFERID_TO_WAFER_OR( aTopWafer, ( actualTopFlag ? strBondingMapInfoSeq[mapCnt].actualTopWaferID
                                                                        : strBondingMapInfoSeq[mapCnt].planTopWaferID ),
                                             strBondingMap_infoConsistency_Check_out,
                                             bondingMap_infoConsistency_Check );

            CORBA::String_var baseLotID, topLotID;
            try
            {
                tmpBaseLot = aBaseWafer->getLot();
                tmpTopLot  = aTopWafer->getLot();
                aBaseLot = PosLot::_narrow( tmpBaseLot );
                aTopLot  = PosLot::_narrow( tmpTopLot );
                if ( !CORBA::is_nil( aBaseLot ) )
                {
                    baseLotID = aBaseLot->getIdentifier();
                }
                if ( !CORBA::is_nil( aTopLot ) )
                {
                    topLotID = aTopLot->getIdentifier();
                }
            }
            CATCH_AND_RAISE_EXCEPTIONS( Product::getLot );

            if ( CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].baseLotID.identifier, baseLotID ) != 0 )
            {
                PPT_METHODTRACE_V2( "", "Base Lot ID is not correct.", mapCnt );
                PPT_SET_MSG_RC_KEY2( strBondingMap_infoConsistency_Check_out,
                                     MSG_LOT_WAFER_UNMATCH, RC_LOT_WAFER_UNMATCH,
                                     strBondingMapInfoSeq[mapCnt].baseLotID.identifier,
                                     strBondingMapInfoSeq[mapCnt].baseWaferID.identifier );
                return RC_LOT_WAFER_UNMATCH;
            }

            if ( actualTopFlag && CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].actualTopLotID.identifier, topLotID ) != 0 )
            {
                PPT_METHODTRACE_V2( "", "Actual Top Lot ID is not correct.", mapCnt );
                PPT_SET_MSG_RC_KEY2( strBondingMap_infoConsistency_Check_out,
                                     MSG_LOT_WAFER_UNMATCH, RC_LOT_WAFER_UNMATCH,
                                     strBondingMapInfoSeq[mapCnt].actualTopLotID.identifier,
                                     strBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier );
                return RC_LOT_WAFER_UNMATCH;
            }
            if ( !actualTopFlag && CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].planTopLotID.identifier, topLotID ) != 0 )
            {
                PPT_METHODTRACE_V2( "", "Planned Top Lot ID is not correct.", mapCnt );
                PPT_SET_MSG_RC_KEY2( strBondingMap_infoConsistency_Check_out,
                                     MSG_LOT_WAFER_UNMATCH, RC_LOT_WAFER_UNMATCH,
                                     strBondingMapInfoSeq[mapCnt].planTopLotID.identifier,
                                     strBondingMapInfoSeq[mapCnt].planTopWaferID.identifier );
                return RC_LOT_WAFER_UNMATCH;
            }

            CORBA::String_var baseProdSpecID, topProdSpecID;
            try
            {
                tmpBaseProdSpec = aBaseWafer->getProductSpecification();
                tmpTopProdSpec  = aTopWafer->getProductSpecification();
                aBaseProdSpec = PosProductSpecification::_narrow( tmpBaseProdSpec );
                aTopProdSpec  = PosProductSpecification::_narrow( tmpTopProdSpec );
                if ( !CORBA::is_nil( aBaseProdSpec ) )
                {
                    baseProdSpecID = aBaseProdSpec->getIdentifier();
                }
                if ( !CORBA::is_nil( aTopProdSpec ) )
                {
                    topProdSpecID = aTopProdSpec->getIdentifier();
                }
            }
            CATCH_AND_RAISE_EXCEPTIONS( Product::getProductSpecification );

            if ( CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].baseProductID.identifier, baseProdSpecID ) != 0 )
            {
                PPT_METHODTRACE_V2( "", "Base Product ID is not correct.", mapCnt );
                PPT_SET_MSG_RC_KEY3( strBondingMap_infoConsistency_Check_out,
                                     MSG_WAFER_PRODUCTSPEC_UNMATCH, RC_PRODUCTSPEC_UNMATCH,
                                     strBondingMapInfoSeq[mapCnt].baseProductID.identifier,
                                     strBondingMapInfoSeq[mapCnt].baseWaferID.identifier,
                                     baseProdSpecID  );
                return RC_PRODUCTSPEC_UNMATCH;
            }

            if ( actualTopFlag &&
                 CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].actualTopProductID.identifier, topProdSpecID ) != 0 )
            {
                PPT_METHODTRACE_V2( "", "Actual Top Product ID is not correct.", mapCnt );
                PPT_SET_MSG_RC_KEY3( strBondingMap_infoConsistency_Check_out,
                                     MSG_WAFER_PRODUCTSPEC_UNMATCH, RC_PRODUCTSPEC_UNMATCH,
                                     strBondingMapInfoSeq[mapCnt].actualTopProductID.identifier,
                                     strBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier,
                                     topProdSpecID  );
                return RC_PRODUCTSPEC_UNMATCH;
            }
            if ( !actualTopFlag &&
                 CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].planTopProductID.identifier, topProdSpecID ) != 0 )
            {
                PPT_METHODTRACE_V2( "", "Plan Top Product ID is not correct.", mapCnt );
                PPT_SET_MSG_RC_KEY3( strBondingMap_infoConsistency_Check_out,
                                     MSG_WAFER_PRODUCTSPEC_UNMATCH, RC_PRODUCTSPEC_UNMATCH,
                                     strBondingMapInfoSeq[mapCnt].planTopProductID.identifier,
                                     strBondingMapInfoSeq[mapCnt].planTopWaferID.identifier,
                                     topProdSpecID  );
                return RC_PRODUCTSPEC_UNMATCH;
            }

            //----------------------------------------------------------------------
            // Check Bonding Side Consistency
            //----------------------------------------------------------------------
            if ( CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].baseBondingSide,    SP_BondingSide_Bottom ) != 0 &&
                 CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].planTopBondingSide, SP_BondingSide_Bottom ) != 0 )
            {
                PPT_METHODTRACE_V2( "", "Whichever Base Wafer or Top Wafer must be SP_BondingSide_Bottom.",
                                    strBondingMapInfoSeq[mapCnt].baseWaferID.identifier );
                SET_MSG_RC( strBondingMap_infoConsistency_Check_out,
                            MSG_INVALID_PARAMETER, RC_INVALID_PARAMETER );
                return RC_INVALID_PARAMETER;
            }
            if ( CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].baseBondingSide,    SP_BondingSide_Top ) != 0 &&
                 CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].planTopBondingSide, SP_BondingSide_Top ) != 0 )
            {
                PPT_METHODTRACE_V2( "", "Whichever Base Wafer or Top Wafer must be SP_BondingSide_Top.",
                                    strBondingMapInfoSeq[mapCnt].baseWaferID.identifier );
                SET_MSG_RC( strBondingMap_infoConsistency_Check_out,
                            MSG_INVALID_PARAMETER, RC_INVALID_PARAMETER );
                return RC_INVALID_PARAMETER;
            }

            //----------------------------------------------------------------------
            // Check Bonding Process State
            //----------------------------------------------------------------------
            if ( actualTopFlag &&
                 CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].bondingProcessState, SP_BondingProcessState_Completed ) != 0 &&
                 CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].bondingProcessState, SP_BondingProcessState_Error ) != 0 &&
                 CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].bondingProcessState, SP_BondingProcessState_Unknown ) != 0 )
            {
                PPT_METHODTRACE_V2( "", "BondingProcessState is Invalid.",
                                    strBondingMapInfoSeq[mapCnt].bondingProcessState );
                PPT_SET_MSG_RC_KEY2( strBondingMap_infoConsistency_Check_out,
                                     MSG_BONDMAP_STATE_INVALID, RC_BONDMAP_STATE_INVALID,
                                     strBondingMapInfoSeq[mapCnt].bondingProcessState,
                                     strBondingMapInfoSeq[mapCnt].baseWaferID.identifier );
                return RC_BONDMAP_STATE_INVALID;
            }
            if ( !actualTopFlag&& CIMFWStrLen( strBondingMapInfoSeq[mapCnt].bondingProcessState ) != 0 )
            {
                PPT_METHODTRACE_V2( "", "BondingProcessState is Invalid.",
                                    strBondingMapInfoSeq[mapCnt].bondingProcessState );
                PPT_SET_MSG_RC_KEY2( strBondingMap_infoConsistency_Check_out,
                                     MSG_BONDMAP_STATE_INVALID, RC_BONDMAP_STATE_INVALID,
                                     strBondingMapInfoSeq[mapCnt].bondingProcessState,
                                     strBondingMapInfoSeq[mapCnt].baseWaferID.identifier );
                return RC_BONDMAP_STATE_INVALID;
            }

            //----------------------------------------------------------------------
            // Check Duplication of wafer
            //----------------------------------------------------------------------
            for ( CORBA::Long j = 0; j < mapCnt; j++ )
            {
                if ( CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].baseWaferID.identifier,
                                  strBondingMapInfoSeq[j].baseWaferID.identifier ) == 0 )
                {
                    PPT_METHODTRACE_V2( "", "Base Wafer ID is not unique.",
                                        strBondingMapInfoSeq[mapCnt].baseWaferID.identifier );
                    PPT_SET_MSG_RC_KEY( strBondingMap_infoConsistency_Check_out,
                                        MSG_BONDGRP_WAFER_DUPLICATE, RC_BONDGRP_WAFER_DUPLICATE,
                                        strBondingMapInfoSeq[mapCnt].baseWaferID.identifier );
                    return RC_BONDGRP_WAFER_DUPLICATE;
                }
                if ( actualTopFlag &&
                     CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier,
                                  strBondingMapInfoSeq[j].actualTopWaferID.identifier ) == 0 )
                {
                    PPT_METHODTRACE_V2( "", "Actual Top Wafer ID is not unique.",
                                        strBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier );
                    PPT_SET_MSG_RC_KEY( strBondingMap_infoConsistency_Check_out,
                                        MSG_BONDGRP_WAFER_DUPLICATE, RC_BONDGRP_WAFER_DUPLICATE,
                                        strBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier );
                    return RC_BONDGRP_WAFER_DUPLICATE;
                }
                if ( !actualTopFlag &&
                     CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].planTopWaferID.identifier,
                                  strBondingMapInfoSeq[j].planTopWaferID.identifier ) == 0 )
                {
                    PPT_METHODTRACE_V2( "", "Plan Top Wafer ID is not unique.",
                                        strBondingMapInfoSeq[mapCnt].planTopWaferID.identifier );
                    PPT_SET_MSG_RC_KEY( strBondingMap_infoConsistency_Check_out,
                                        MSG_BONDGRP_WAFER_DUPLICATE, RC_BONDGRP_WAFER_DUPLICATE,
                                        strBondingMapInfoSeq[mapCnt].planTopWaferID.identifier );
                    return RC_BONDGRP_WAFER_DUPLICATE;
                }
            }
        }

        //----------------------------------------------------------------------
        // Collect uniquely pairs of BaseLot and TopLot
        //----------------------------------------------------------------------
        objectIdentifierSequence baseLotIDs, baseProdIDs, topLotIDs, topProdIDs;
        stringSequence baseWaferIDs, topWaferIDs;
        longSequence  baseWaferNums, topWaferNums;
        CORBA::Long lotLen = 0;
        CORBA::Long lotCnt = 0;
        for ( mapCnt = 0; mapCnt < mapLen; mapCnt++ )
        {
            const objectIdentifier& baseLotID  = strBondingMapInfoSeq[mapCnt].baseLotID;
            const objectIdentifier& baseProdID = strBondingMapInfoSeq[mapCnt].baseProductID;
            const objectIdentifier& topLotID   = actualTopFlag ? strBondingMapInfoSeq[mapCnt].actualTopLotID
                                                               : strBondingMapInfoSeq[mapCnt].planTopLotID;
            const objectIdentifier& topProdID  = actualTopFlag ? strBondingMapInfoSeq[mapCnt].actualTopProductID
                                                               : strBondingMapInfoSeq[mapCnt].planTopProductID;

            CORBA::Boolean infoFound = FALSE;
            for ( CORBA::Long j = lotCnt; j > 0; j-- )
            {
                if ( CIMFWStrCmp( baseLotID.identifier,  baseLotIDs[j-1].identifier ) == 0 &&
                     CIMFWStrCmp( baseProdID.identifier, baseProdIDs[j-1].identifier ) == 0 &&
                     CIMFWStrCmp( topLotID.identifier,   topLotIDs[j-1].identifier  ) == 0 &&
                     CIMFWStrCmp( topProdID.identifier,  topProdIDs[j-1].identifier ) == 0 )
                {
                    infoFound = TRUE;
                    baseWaferNums[j-1]++;
                    topWaferNums[j-1]++;
                    break;
                }
            }
            if ( infoFound )
            {
                continue;
            }

            if ( lotCnt >= lotLen )
            {
                lotLen += 10;
                baseLotIDs.length( lotLen );
                baseProdIDs.length( lotLen );
                topLotIDs.length( lotLen );
                topProdIDs.length( lotLen );
                baseWaferIDs.length( lotLen );
                topWaferIDs.length( lotLen );
                baseWaferNums.length( lotLen );
                topWaferNums.length( lotLen );
            }
            baseLotIDs[lotCnt]  = baseLotID;
            baseProdIDs[lotCnt] = baseProdID;
            topLotIDs[lotCnt]   = topLotID;
            topProdIDs[lotCnt]  = topProdID;
            baseWaferIDs[lotCnt] = strBondingMapInfoSeq[mapCnt].baseWaferID.identifier;
            topWaferIDs[lotCnt]  = actualTopFlag ? strBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier
                                                 : strBondingMapInfoSeq[mapCnt].planTopWaferID.identifier;
            baseWaferNums[lotCnt] = 1;
            topWaferNums[lotCnt] = 1;
            lotCnt++;
        }
        lotLen = lotCnt;
        baseLotIDs.length( lotLen );
        baseProdIDs.length( lotLen );
        topLotIDs.length( lotLen );
        topProdIDs.length( lotLen );
        baseWaferIDs.length( lotLen );
        topWaferIDs.length( lotLen );
        baseWaferNums.length( lotLen );
        topWaferNums.length( lotLen );

        PosMachine_var aEqp;
        if ( CIMFWStrLen( strBondingMap_infoConsistency_Check_in.targetEquipmentID.identifier ) > 0 )
        {
            PPT_CONVERT_EQPID_TO_MACHINE_OR( aEqp, strBondingMap_infoConsistency_Check_in.targetEquipmentID,
                                             strBondingMap_infoConsistency_Check_out,
                                             bondingMap_infoConsistency_Check );
        }

        for ( lotCnt = 0; lotCnt < lotLen; lotCnt++ )
        {
            PPT_METHODTRACE_V3( "", "round", lotCnt, lotLen );

            PPT_CONVERT_LOTID_TO_LOT_OR( aBaseLot, baseLotIDs[lotCnt],
                                         strBondingMap_infoConsistency_Check_out,
                                         bondingMap_infoConsistency_Check );
            PPT_CONVERT_LOTID_TO_LOT_OR( aTopLot, topLotIDs[lotCnt],
                                         strBondingMap_infoConsistency_Check_out,
                                         bondingMap_infoConsistency_Check );

            pptBondingLotAttributes baseBondingLotAttributes, topBondingLotAttributes;
            PPT_SET_OBJECT_IDENTIFIER( baseBondingLotAttributes.lotID, aBaseLot,
                                       strBondingMap_infoConsistency_Check_out,
                                       bondingMap_infoConsistency_Check,
                                       PosLot );
            PPT_SET_OBJECT_IDENTIFIER( topBondingLotAttributes.lotID, aTopLot,
                                       strBondingMap_infoConsistency_Check_out,
                                       bondingMap_infoConsistency_Check,
                                       PosLot );

            //--------------------------------------------------------------
            // Check Relation of Lot and Product
            //--------------------------------------------------------------
            try
            {
                tmpBaseProdSpec = aBaseLot->getProductSpecification();
                tmpTopProdSpec  = aTopLot->getProductSpecification();
                aBaseProdSpec = PosProductSpecification::_narrow( tmpBaseProdSpec );
                aTopProdSpec  = PosProductSpecification::_narrow( tmpTopProdSpec );
            }
            CATCH_AND_RAISE_EXCEPTIONS( Lot::getProductSpecification );

            PPT_SET_OBJECT_IDENTIFIER( baseBondingLotAttributes.productID, aBaseProdSpec,
                                       strBondingMap_infoConsistency_Check_out,
                                       bondingMap_infoConsistency_Check,
                                       PosProductSpecification );
            PPT_SET_OBJECT_IDENTIFIER( topBondingLotAttributes.productID, aTopProdSpec,
                                       strBondingMap_infoConsistency_Check_out,
                                       bondingMap_infoConsistency_Check,
                                       PosProductSpecification );

            PPT_METHODTRACE_V3( "", "Product ID from Lot",
                                baseBondingLotAttributes.productID.identifier, topBondingLotAttributes.productID.identifier );
            PPT_METHODTRACE_V3( "", "Product ID from BondingMap",
                                baseProdIDs[lotCnt].identifier, topProdIDs[lotCnt].identifier );

            if ( CIMFWStrLen( baseBondingLotAttributes.productID.identifier ) == 0 ||
                 CIMFWStrCmp( baseBondingLotAttributes.productID.identifier, baseProdIDs[lotCnt].identifier ) != 0 )
            {
                PPT_METHODTRACE_V3( "", "Base Lot and Base Product Mismatch.",
                                    baseBondingLotAttributes.lotID.identifier, baseProdIDs[lotCnt].identifier );
                PPT_SET_MSG_RC_KEY3( strBondingMap_infoConsistency_Check_out,
                                     MSG_WAFER_PRODUCTSPEC_UNMATCH, RC_PRODUCTSPEC_UNMATCH,
                                     baseProdIDs[lotCnt].identifier, baseWaferIDs[lotCnt],
                                     baseBondingLotAttributes.productID.identifier );
                return RC_PRODUCTSPEC_UNMATCH;
            }

            if ( CIMFWStrLen( topBondingLotAttributes.productID.identifier ) == 0 ||
                 CIMFWStrCmp( topBondingLotAttributes.productID.identifier, topProdIDs[lotCnt].identifier ) != 0 )
            {
                PPT_METHODTRACE_V3( "", "Top Lot and Top Product Mismatch.",
                                    topBondingLotAttributes.lotID.identifier, topProdIDs[lotCnt].identifier );
                PPT_SET_MSG_RC_KEY3( strBondingMap_infoConsistency_Check_out,
                                     MSG_WAFER_PRODUCTSPEC_UNMATCH, RC_PRODUCTSPEC_UNMATCH,
                                     topProdIDs[lotCnt].identifier, topWaferIDs[lotCnt],
                                     topBondingLotAttributes.productID.identifier );
                return RC_PRODUCTSPEC_UNMATCH;
            }

            if ( actualTopFlag )
            {
                PPT_METHODTRACE_V1( "", "actualTopFlag == TRUE" );

                //-------------------------------------------------------------------
                // There is a case such that not all wafers in Bonding Map.
                // There is a case such that Bonding Operation is previous Operation.
                //-------------------------------------------------------------------
                continue;
            }

            //--------------------------------------------------------------
            // Check Number of Wafers in Lot
            //--------------------------------------------------------------
            PPT_METHODTRACE_V1( "", "actualTopFlag == FALSE" );

            try
            {
                baseBondingLotAttributes.totalWaferCount = aBaseLot->getQuantity();
                topBondingLotAttributes.totalWaferCount  = aTopLot->getQuantity();
            }
            CATCH_AND_RAISE_EXCEPTIONS( PosLot::getQuantity );

            PPT_METHODTRACE_V3( "", "The number of Wafers from Lot",
                                baseBondingLotAttributes.totalWaferCount,
                                topBondingLotAttributes.totalWaferCount );

            CORBA::Long baseWaferNum = 0, topWaferNum = 0;
            for ( CORBA::Long j = 0; j < lotLen; j++ )
            {
                if ( CIMFWStrCmp( baseBondingLotAttributes.lotID.identifier, baseLotIDs[j].identifier ) == 0 )
                {
                    baseWaferNum += baseWaferNums[j];
                }
                if ( CIMFWStrCmp( topBondingLotAttributes.lotID.identifier,  topLotIDs[j].identifier ) == 0 )
                {
                    topWaferNum += topWaferNums[j];
                }
            }
            PPT_METHODTRACE_V3( "", "The number of Wafers from BondingMap", baseWaferNum, topWaferNum );

            if ( baseBondingLotAttributes.totalWaferCount != baseWaferNum )
            {
                PPT_METHODTRACE_V3( "", "Base Lot Quantity and The number of Wafers in Bonding Map Mismatch.",
                                    baseBondingLotAttributes.lotID.identifier, baseWaferNum );
                PPT_SET_MSG_RC_KEY( strBondingMap_infoConsistency_Check_out,
                                    MSG_BONDGRP_LOT_QUANTITY_UNMATCH, RC_BONDGRP_LOT_QUANTITY_UNMATCH,
                                    baseBondingLotAttributes.lotID.identifier );
                return RC_BONDGRP_LOT_QUANTITY_UNMATCH;
            }
            if ( topBondingLotAttributes.totalWaferCount != topWaferNum )
            {
                PPT_METHODTRACE_V3( "", "Top Lot Quantity and The number of Wafers in Bonding Map Mismatch.",
                                    topBondingLotAttributes.lotID.identifier, topWaferNum );
                PPT_SET_MSG_RC_KEY( strBondingMap_infoConsistency_Check_out,
                                    MSG_BONDGRP_LOT_QUANTITY_UNMATCH, RC_BONDGRP_LOT_QUANTITY_UNMATCH,
                                    topBondingLotAttributes.lotID.identifier );
                return RC_BONDGRP_LOT_QUANTITY_UNMATCH;
            }

            //--------------------------------------------------------------
            // Get Base Operation ID.
            //--------------------------------------------------------------
            objLot_bondingOperationInfo_GetDR_out strLot_bondingOperationInfo_GetDR_out;
            objLot_bondingOperationInfo_GetDR_in strLot_bondingOperationInfo_GetDR_in;
            strLot_bondingOperationInfo_GetDR_in.lotID = baseBondingLotAttributes.lotID;

            PPT_METHODTRACE_V1( "", "Calling lot_bondingOperationInfo_GetDR()" );
            rc = lot_bondingOperationInfo_GetDR( strLot_bondingOperationInfo_GetDR_out, strObjCommonIn,
                                                 strLot_bondingOperationInfo_GetDR_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "", "lot_bondingOperationInfo_GetDR() != RC_OK", rc );
                strBondingMap_infoConsistency_Check_out.strResult = strLot_bondingOperationInfo_GetDR_out.strResult;
                return rc;
            }

            baseBondingLotAttributes.targetRouteID          = strLot_bondingOperationInfo_GetDR_out.targetRouteID;
            baseBondingLotAttributes.targetOpeNo            = strLot_bondingOperationInfo_GetDR_out.targetOperationNumber;
            baseBondingLotAttributes.targetOpeID            = strLot_bondingOperationInfo_GetDR_out.targetOperationID;
            baseBondingLotAttributes.bondingFlowSectionName = strLot_bondingOperationInfo_GetDR_out.bondingFlowSectionName;

            //--------------------------------------------------------------
            // Check if the Top Product is Parts of Base Product
            //--------------------------------------------------------------
            objProcess_BOMPartsInfo_GetDR_out strProcess_BOMPartsInfo_GetDR_out;
            objProcess_BOMPartsInfo_GetDR_in strProcess_BOMPartsInfo_GetDR_in;
            strProcess_BOMPartsInfo_GetDR_in.productID   = baseBondingLotAttributes.productID;
            strProcess_BOMPartsInfo_GetDR_in.operationID = baseBondingLotAttributes.targetOpeID;

            PPT_METHODTRACE_V1( "", "Calling process_BOMPartsInfo_GetDR()" );
            rc = process_BOMPartsInfo_GetDR( strProcess_BOMPartsInfo_GetDR_out, strObjCommonIn,
                                             strProcess_BOMPartsInfo_GetDR_in );

            if ( rc != RC_OK && rc != RC_BOM_NOT_DEFINED && rc != RC_PARTS_NOT_DEFINED_FOR_PROCESS )
            {
                PPT_METHODTRACE_V2( "", "process_BOMPartsInfo_GetDR() != RC_OK", rc );
                strBondingMap_infoConsistency_Check_out.strResult = strProcess_BOMPartsInfo_GetDR_out.strResult;
                return rc;
            }
            else if ( strProcess_BOMPartsInfo_GetDR_out.strBOMPartsInfoSeq.length() != 1 )
            {
                PPT_METHODTRACE_V2( "", "BOMParts is not defined for Base Product.",
                                    baseBondingLotAttributes.productID.identifier );
                PPT_SET_MSG_RC_KEY( strBondingMap_infoConsistency_Check_out,
                                    MSG_NOT_BASE_PROD_FOR_BONDING, RC_NOT_BASE_PROD_FOR_BONDING,
                                    baseBondingLotAttributes.productID.identifier );
                return RC_NOT_BASE_PROD_FOR_BONDING;
            }

            if ( CIMFWStrCmp( strProcess_BOMPartsInfo_GetDR_out.strBOMPartsInfoSeq[0].partID.identifier,
                              topBondingLotAttributes.productID.identifier ) != 0 )
            {
                PPT_METHODTRACE_V3( "", "Top Product is not Parts of Base Product.",
                                    topBondingLotAttributes.productID.identifier,
                                    baseBondingLotAttributes.productID.identifier );
                PPT_SET_MSG_RC_KEY2( strBondingMap_infoConsistency_Check_out,
                                     MSG_BONDING_TOP_PRODSPEC_MISMATCH, RC_BONDING_TOP_PRODSPEC_MISMATCH,
                                     topBondingLotAttributes.productID.identifier,
                                     baseBondingLotAttributes.productID.identifier );
                return RC_BONDING_TOP_PRODSPEC_MISMATCH;
            }

            baseBondingLotAttributes.topProductID = strProcess_BOMPartsInfo_GetDR_out.strBOMPartsInfoSeq[0].partID;

            //--------------------------------------------------------------
            // Check Top Operation ID
            //--------------------------------------------------------------
            strLot_bondingOperationInfo_GetDR_in.lotID  = topBondingLotAttributes.lotID;

            PPT_METHODTRACE_V1( "", "Calling process_BOMPartsInfo_GetDR()" );
            rc = lot_bondingOperationInfo_GetDR( strLot_bondingOperationInfo_GetDR_out, strObjCommonIn,
                                                 strLot_bondingOperationInfo_GetDR_in );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2( "", "lot_bondingOperationInfo_GetDR() != RC_OK", rc );
                strBondingMap_infoConsistency_Check_out.strResult = strLot_bondingOperationInfo_GetDR_out.strResult;
                return rc;
            }

            topBondingLotAttributes.targetRouteID          = strLot_bondingOperationInfo_GetDR_out.targetRouteID;
            topBondingLotAttributes.targetOpeNo            = strLot_bondingOperationInfo_GetDR_out.targetOperationNumber;
            topBondingLotAttributes.targetOpeID            = strLot_bondingOperationInfo_GetDR_out.targetOperationID;
            topBondingLotAttributes.bondingFlowSectionName = strLot_bondingOperationInfo_GetDR_out.bondingFlowSectionName;

            //---------------------------------------------------------------------
            // Check if the Top Product is not Base Product of any other Product
            //---------------------------------------------------------------------
            strProcess_BOMPartsInfo_GetDR_in.productID   = topBondingLotAttributes.productID;
            strProcess_BOMPartsInfo_GetDR_in.operationID = topBondingLotAttributes.targetOpeID;

            PPT_METHODTRACE_V1( "", "Calling process_BOMPartsInfo_GetDR()" );
            rc = process_BOMPartsInfo_GetDR( strProcess_BOMPartsInfo_GetDR_out, strObjCommonIn,
                                             strProcess_BOMPartsInfo_GetDR_in );

            if ( rc != RC_OK && rc != RC_BOM_NOT_DEFINED && rc != RC_PARTS_NOT_DEFINED_FOR_PROCESS )
            {
                PPT_METHODTRACE_V2( "", "process_BOMPartsInfo_GetDR() != RC_OK", rc );
                strBondingMap_infoConsistency_Check_out.strResult = strProcess_BOMPartsInfo_GetDR_out.strResult;
                return rc;
            }

            if ( strProcess_BOMPartsInfo_GetDR_out.strBOMPartsInfoSeq.length() > 0 )
            {
                PPT_METHODTRACE_V3( "", "Top Product is Base Product of some other Product.",
                                    topBondingLotAttributes.productID.identifier,
                                    strProcess_BOMPartsInfo_GetDR_out.strBOMPartsInfoSeq[0].partID.identifier );
                PPT_SET_MSG_RC_KEY2( strBondingMap_infoConsistency_Check_out,
                                     MSG_BASE_PRODSPEC_FOR_BONDING, RC_BASE_PRODSPEC_FOR_BONDING,
                                     topBondingLotAttributes.productID.identifier,
                                     strProcess_BOMPartsInfo_GetDR_out.strBOMPartsInfoSeq[0].partID.identifier );
                return RC_BASE_PRODSPEC_FOR_BONDING;
            }

            //--------------------------------------------------------------
            // Check if Bonding Flow Section is same
            //--------------------------------------------------------------
            if ( CIMFWStrCmp( baseBondingLotAttributes.bondingFlowSectionName,
                              topBondingLotAttributes.bondingFlowSectionName ) != 0 )
            {
                PPT_METHODTRACE_V3( "", "Bonding Flow Section Name is not same.",
                                    baseBondingLotAttributes.bondingFlowSectionName,
                                    topBondingLotAttributes.bondingFlowSectionName );
                PPT_SET_MSG_RC_KEY2( strBondingMap_infoConsistency_Check_out,
                                     MSG_NOT_SAME_FLOWSECTION, RC_NOT_SAME_FLOWSECTION,
                                     baseBondingLotAttributes.lotID.identifier,
                                     topBondingLotAttributes.lotID.identifier );
                return RC_NOT_SAME_FLOWSECTION;
            }

            PosProcessDefinition_var aBasePD, aTopPD;
            PPT_CONVERT_OPERATIONID_TO_PROCESSDEFINITION_OR( aBasePD, baseBondingLotAttributes.targetOpeID,
                                                             strBondingMap_infoConsistency_Check_out,
                                                             bondingMap_infoConsistency_Check );
            PPT_CONVERT_OPERATIONID_TO_PROCESSDEFINITION_OR( aTopPD,  topBondingLotAttributes.targetOpeID,
                                                             strBondingMap_infoConsistency_Check_out,
                                                             bondingMap_infoConsistency_Check );

            //--------------------------------------------------------------
            // Check if Current Operation is Target Operation
            //--------------------------------------------------------------
            CORBA::String_var baseRouteID, topRouteID;
            try
            {
                PosProcessDefinition_var aBaseMainPD, aTopMainPD;
                aBaseMainPD = aBaseLot->getMainProcessDefinition();
                aTopMainPD  = aTopLot->getMainProcessDefinition();
                if ( !CORBA::is_nil( aBaseMainPD ) )
                {
                    baseRouteID = aBaseMainPD->getIdentifier();
                }
                if ( !CORBA::is_nil( aTopMainPD ) )
                {
                    topRouteID  = aTopMainPD->getIdentifier();
                }
            }
            CATCH_AND_RAISE_EXCEPTIONS( PosLot::getMainProcessDefinition );

            CORBA::String_var baseOpeNo, topOpeNo;
            try
            {
                baseOpeNo = aBaseLot->getOperationNumber();
                topOpeNo  = aTopLot->getOperationNumber();
            }
            CATCH_AND_RAISE_EXCEPTIONS( PosLot::getOperationNumber );

            PPT_METHODTRACE_V3( "", "Route Operation of Base Lot", baseRouteID, baseOpeNo );
            PPT_METHODTRACE_V3( "", "Route Operation of Top Lot",  topRouteID,  topOpeNo );

            //--------------------------------------------------------------
            // Check Lot Reserved
            //--------------------------------------------------------------
            PosProcessOperation_var aBasePO, aTopPO;

            if ( CIMFWStrCmp( baseBondingLotAttributes.targetRouteID.identifier, baseRouteID ) == 0 &&
                 CIMFWStrCmp( baseBondingLotAttributes.targetOpeNo, baseOpeNo ) == 0 )
            {
                PPT_METHODTRACE_V1( "", "Current Operation for Base Lot is Bonding Target Operation." );

                PosControlJob_var aBaseCtrlJob;
                try
                {
                    aBaseCtrlJob = aBaseLot->getControlJob();
                }
                CATCH_AND_RAISE_EXCEPTIONS( PosLot::getControlJob );

                if ( !CORBA::is_nil( aBaseCtrlJob ) )
                {
                    PPT_METHODTRACE_V1( "", "Base Lot is reserved." );

                    try
                    {
                        ProcessOperation_var tmpBasePO = aBaseLot->getProcessOperation();
                        aBasePO = PosProcessOperation::_narrow( tmpBasePO );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS( Lot::getProcessOperation );
                }

            }

            if ( CIMFWStrCmp( topBondingLotAttributes.targetRouteID.identifier, topRouteID ) == 0 &&
                 CIMFWStrCmp( topBondingLotAttributes.targetOpeNo, topOpeNo ) == 0 )
            {
                PPT_METHODTRACE_V1( "", "Current Operation for Top Lot is Bonding Target Operation." );

                PosControlJob_var aTopCtrlJob;
                try
                {
                    aTopCtrlJob  = aTopLot->getControlJob();
                }
                CATCH_AND_RAISE_EXCEPTIONS( PosLot::getControlJob );

                if ( !CORBA::is_nil( aTopCtrlJob ) )
                {
                    PPT_METHODTRACE_V1( "", "Top Lot is reserved." );

                    try
                    {
                        ProcessOperation_var tmpTopPO = aTopLot->getProcessOperation();
                        aTopPO = PosProcessOperation::_narrow( tmpTopPO );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS( Lot::getProcessOperation );
                }
            }

            //--------------------------------------------------------------
            // Check if the LogicalRecipe are the same.
            //--------------------------------------------------------------
            PosLogicalRecipe_var aBaseLR, aTopLR;

            if ( !CORBA::is_nil( aBasePO ) )
            {
                try
                {
                    aBaseLR = aBasePO->getAssignedLogicalRecipe();
                }
                CATCH_AND_RAISE_EXCEPTIONS( PosProcessOperation::getAssignedLogicalRecipe );
            }
            else
            {
                try
                {
                    aBaseLR = aBasePD->findLogicalRecipeFor( aBaseProdSpec );
                }
                CATCH_AND_RAISE_EXCEPTIONS( PosProcessDefinition::findLogicalRecipeFor );
            }

            if ( !CORBA::is_nil( aTopPO ) )
            {
                try
                {
                    aTopLR = aTopPO->getAssignedLogicalRecipe();
                }
                CATCH_AND_RAISE_EXCEPTIONS( PosProcessOperation::getAssignedLogicalRecipe );
            }
            else
            {
                try
                {
                    aTopLR = aTopPD->findLogicalRecipeFor( aTopProdSpec );
                }
                CATCH_AND_RAISE_EXCEPTIONS( PosProcessDefinition::findLogicalRecipeFor );
            }

            PPT_SET_OBJECT_IDENTIFIER( baseBondingLotAttributes.targetLogicalRecipeID, aBaseLR,
                                       strBondingMap_infoConsistency_Check_out,
                                       bondingMap_infoConsistency_Check,
                                       PosLogicalRecipe );
            PPT_SET_OBJECT_IDENTIFIER( topBondingLotAttributes.targetLogicalRecipeID, aTopLR,
                                       strBondingMap_infoConsistency_Check_out,
                                       bondingMap_infoConsistency_Check,
                                       PosLogicalRecipe );

            PPT_METHODTRACE_V3( "", "LogicalRecipeID",
                                baseBondingLotAttributes.targetLogicalRecipeID.identifier,
                                topBondingLotAttributes.targetLogicalRecipeID.identifier );

            if ( CIMFWStrLen( baseBondingLotAttributes.targetLogicalRecipeID.identifier ) == 0 ||
                 CIMFWStrLen( topBondingLotAttributes.targetLogicalRecipeID.identifier ) == 0 ||
                 CIMFWStrCmp( baseBondingLotAttributes.targetLogicalRecipeID.identifier,
                              topBondingLotAttributes.targetLogicalRecipeID.identifier ) != 0 )
            {
                PPT_SET_MSG_RC_KEY( strBondingMap_infoConsistency_Check_out,
                                    MSG_NOT_SAME_LOGICAL_RECIPE, RC_NOT_SAME_LOGICAL_RECIPE,
                                    topBondingLotAttributes.lotID.identifier );
                return RC_NOT_SAME_LOGICAL_RECIPE;
            }

            //--------------------------------------------------------------
            // Check if the MachineRecipe are the same.
            //--------------------------------------------------------------
            PosMachine_var aBaseEqp, aTopEqp;
            if ( !CORBA::is_nil( aBasePO ) )
            {
                PPT_METHODTRACE_V1( "", "Base Lot is reserved for Bonding Operation." );

                try
                {
                    aBaseEqp = aBasePO->getAssignedMachine();
                }
                CATCH_AND_RAISE_EXCEPTIONS( PosProcessOperation::getAssignedMachine );

                PosMachineRecipe_var aBaseMR;
                try
                {
                    aBaseMR = aBasePO->getAssignedMachineRecipe();
                }
                CATCH_AND_RAISE_EXCEPTIONS( PosProcessOperation::getAssignedMachineRecipe );

                PPT_SET_OBJECT_IDENTIFIER( baseBondingLotAttributes.targetMachineRecipeID, aBaseMR,
                                           strBondingMap_infoConsistency_Check_out,
                                           bondingMap_infoConsistency_Check,
                                           PosMachineRecipe );
            }
            if ( !CORBA::is_nil( aTopPO ) )
            {
                PPT_METHODTRACE_V1( "", "Top Lot is reserved for Bonding Operation." );

                try
                {
                    aTopEqp = aTopPO->getAssignedMachine();
                }
                CATCH_AND_RAISE_EXCEPTIONS( PosProcessOperation::getAssignedMachine );

                PosMachineRecipe_var  aTopMR;
                try
                {
                    aTopMR = aTopPO->getAssignedMachineRecipe();
                }
                CATCH_AND_RAISE_EXCEPTIONS( PosProcessOperation::getAssignedMachineRecipe );

                PPT_SET_OBJECT_IDENTIFIER( topBondingLotAttributes.targetMachineRecipeID, aTopMR,
                                           strBondingMap_infoConsistency_Check_out,
                                           bondingMap_infoConsistency_Check,
                                           PosMachineRecipe );
            }

            if ( !CORBA::is_nil( aBaseEqp ) )
            {
                CORBA::String_var baseEqpID;
                try
                {
                    baseEqpID = aBaseEqp->getIdentifier();
                }
                CATCH_AND_RAISE_EXCEPTIONS( PosMachine::getIdentifier );

                PPT_METHODTRACE_V2( "", "Assigned Machine for Base Lot", baseEqpID );

                if ( CIMFWStrCmp( strBondingMap_infoConsistency_Check_in.targetEquipmentID.identifier, baseEqpID ) != 0 )
                {
                    PPT_METHODTRACE_V3( "", "Assigned Machine and Target Equipment differ for Base Lot.",
                                        baseBondingLotAttributes.lotID.identifier,
                                        strBondingMap_infoConsistency_Check_in.targetEquipmentID.identifier );
                    PPT_SET_MSG_RC_KEY3( strBondingMap_infoConsistency_Check_out,
                                         MSG_BONDGRP_INVALID_EQP, RC_BONDGRP_INVALID_EQP,
                                         baseBondingLotAttributes.lotID.identifier,
                                         strBondingMap_infoConsistency_Check_in.targetEquipmentID.identifier,
                                         baseBondingLotAttributes.targetOpeID.identifier );
                    return RC_BONDGRP_INVALID_EQP;
                }
            }
            else if ( !CORBA::is_nil( aEqp ) )
            {
                //-------------------------------------------------------------
                // Get FPC Information of the Base Lot at Target Operation
                //-------------------------------------------------------------
                objLot_effectiveFPCInfoForOperation_Get_out strLot_effectiveFPCInfoForOperation_Get_out;
                objLot_effectiveFPCInfoForOperation_Get_in strLot_effectiveFPCInfoForOperation_Get_in;
                strLot_effectiveFPCInfoForOperation_Get_in.exchangeType    = CIMFWStrDup( SP_FPC_ExchangeType_BondingGroup );
                strLot_effectiveFPCInfoForOperation_Get_in.equipmentID     = strBondingMap_infoConsistency_Check_in.targetEquipmentID;
                strLot_effectiveFPCInfoForOperation_Get_in.lotID           = baseBondingLotAttributes.lotID;
                strLot_effectiveFPCInfoForOperation_Get_in.routeID         = baseBondingLotAttributes.targetRouteID;
                strLot_effectiveFPCInfoForOperation_Get_in.operationNumber = baseBondingLotAttributes.targetOpeNo;

                PPT_METHODTRACE_V1( "", "Calling lot_effectiveFPCInfoForOperation_Get()" );
                rc = lot_effectiveFPCInfoForOperation_Get( strLot_effectiveFPCInfoForOperation_Get_out, strObjCommonIn,
                                                           strLot_effectiveFPCInfoForOperation_Get_in );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2( "","lot_effectiveFPCInfoForOperation_Get() != RC_OK", rc );
                    strBondingMap_infoConsistency_Check_out.strResult = strLot_effectiveFPCInfoForOperation_Get_out.strResult;
                    return rc;
                }

                //-------------------------------------------------------------
                // Check if the Base Lot can be processed by Target Equipment
                //-------------------------------------------------------------
                CORBA::Boolean baseEqpFound = FALSE;
                if ( strLot_effectiveFPCInfoForOperation_Get_out.equipmentActionRequired )
                {
                    PPT_METHODTRACE_V1("","Base Lot can be processed by Target Equipment.");
                    baseEqpFound = TRUE;
                }

                objLot_FPCdispatchEqpInfo_Get_out strLot_FPCdispatchEqpInfo_Get_out;
                if ( !baseEqpFound )
                {
                    //----------------------------------------------------
                    // Get FPC Information of the Lot at Target Operation
                    //----------------------------------------------------
                    objLot_FPCdispatchEqpInfo_Get_in strLot_FPCdispatchEqpInfo_Get_in;
                    strLot_FPCdispatchEqpInfo_Get_in.lotID           = baseBondingLotAttributes.lotID;
                    strLot_FPCdispatchEqpInfo_Get_in.routeID         = baseBondingLotAttributes.targetRouteID;
                    strLot_FPCdispatchEqpInfo_Get_in.operationNumber = baseBondingLotAttributes.targetOpeNo;

                    PPT_METHODTRACE_V1( "", "Calling lot_FPCdispatchEqpInfo_Get()" );
                    rc = lot_FPCdispatchEqpInfo_Get( strLot_FPCdispatchEqpInfo_Get_out, strObjCommonIn,
                                                     strLot_FPCdispatchEqpInfo_Get_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V4( "","lot_FPCdispatchEqpInfo_Get() != RC_OK", rc,
                                            strLot_FPCdispatchEqpInfo_Get_out.strResult.messageText,
                                            strLot_FPCdispatchEqpInfo_Get_out.strResult.reasonText );
                        strBondingMap_infoConsistency_Check_out.strResult = strLot_FPCdispatchEqpInfo_Get_out.strResult;
                        return rc;
                    }

                    const CORBA::Long eqpLen = strLot_FPCdispatchEqpInfo_Get_out.strFPCDispatchEqpInfo.dispatchEqpIDs.length();
                    for ( CORBA::Long i = 0; i < eqpLen; i++ )
                    {
                        if ( CIMFWStrCmp( strLot_FPCdispatchEqpInfo_Get_out.strFPCDispatchEqpInfo.dispatchEqpIDs[i].identifier,
                                          strBondingMap_infoConsistency_Check_in.targetEquipmentID.identifier ) == 0 )
                        {
                            baseEqpFound = TRUE;
                            break;
                        }
                    }
                }

                if ( !baseEqpFound && !strLot_FPCdispatchEqpInfo_Get_out.strFPCDispatchEqpInfo.restrictEqpFlag )
                {
                    PPT_METHODTRACE_V1( "", "FPC Setting of Equipment is not Found." );

                    /************************************************/
                    /* Call PosProcessDefinition::findMachinesFor() */
                    /************************************************/
                    PosMachineSequence_var aBaseEqpSeq;
                    try
                    {
                        aBaseEqpSeq = aBasePD->findMachinesFor( aBaseProdSpec );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS( PosProcessDefinition::findMachinesFor );

                    const CORBA::Long eqpLen = aBaseEqpSeq ? aBaseEqpSeq->length() : 0;
                    for ( CORBA::Long i = 0; i < eqpLen; i++ )
                    {
                        if ( aEqp == (*aBaseEqpSeq)[i] )
                        {
                            baseEqpFound = TRUE;
                            break;
                        }
                    }
                }
                if ( !baseEqpFound )
                {
                    PPT_METHODTRACE_V3( "", "Base Lot cannot be Processed.",
                                        baseBondingLotAttributes.lotID.identifier,
                                        strBondingMap_infoConsistency_Check_in.targetEquipmentID.identifier );
                    PPT_SET_MSG_RC_KEY3( strBondingMap_infoConsistency_Check_out,
                                         MSG_BONDGRP_INVALID_EQP, RC_BONDGRP_INVALID_EQP,
                                         baseBondingLotAttributes.lotID.identifier,
                                         strBondingMap_infoConsistency_Check_in.targetEquipmentID.identifier,
                                         baseBondingLotAttributes.targetOpeID.identifier );
                    return RC_BONDGRP_INVALID_EQP;
                }

                //-------------------------------------------------------------
                // Getting Machine Recipe for Base Lot
                //-------------------------------------------------------------
                if ( strLot_effectiveFPCInfoForOperation_Get_out.machineRecipeActionRequired )
                {
                    PPT_METHODTRACE_V1("","FPC Setting of Machine Recipe Found. Use it.");

                    baseBondingLotAttributes.targetMachineRecipeID = strLot_effectiveFPCInfoForOperation_Get_out.strFPCInfo.machineRecipeID;
                }
                else
                {
                    PPT_METHODTRACE_V1("","FPC Setting of Machine Recipe is not Found. calling PosLogicalRecipe::findMachineRecipeFor().");

                    PosMachineRecipe_var aBaseMR;
                    try
                    {
                        aBaseMR = aBaseLR->findMachineRecipeFor( aBaseLot, aEqp );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS( PosLogicalRecipe::findMachineRecipeFor );

                    PPT_SET_OBJECT_IDENTIFIER( baseBondingLotAttributes.targetMachineRecipeID, aBaseMR,
                                               strBondingMap_infoConsistency_Check_out,
                                               bondingMap_infoConsistency_Check,
                                               PosMachineRecipe );
                }
            }

            if ( !CORBA::is_nil( aTopEqp ) )
            {
                CORBA::String_var topEqpID;
                try
                {
                    topEqpID = aTopEqp->getIdentifier();
                }
                CATCH_AND_RAISE_EXCEPTIONS( PosMachine::getIdentifier );

                PPT_METHODTRACE_V2( "", "Assigned Machine for Top Lot", topEqpID );

                if ( CIMFWStrCmp( strBondingMap_infoConsistency_Check_in.targetEquipmentID.identifier, topEqpID ) != 0 )
                {
                    PPT_METHODTRACE_V3( "", "Assigned Machine and Target Equipment differ for Top Lot.",
                                        topBondingLotAttributes.lotID.identifier,
                                        strBondingMap_infoConsistency_Check_in.targetEquipmentID.identifier );
                    PPT_SET_MSG_RC_KEY3( strBondingMap_infoConsistency_Check_out,
                                         MSG_BONDGRP_INVALID_EQP, RC_BONDGRP_INVALID_EQP,
                                         topBondingLotAttributes.lotID.identifier,
                                         strBondingMap_infoConsistency_Check_in.targetEquipmentID.identifier,
                                         topBondingLotAttributes.targetOpeID.identifier );
                    return RC_BONDGRP_INVALID_EQP;
                }
            }
            else if ( !CORBA::is_nil( aEqp ) )
            {
                //-------------------------------------------------------------
                // Get FPC Information of the Top Lot at Current Operation
                //-------------------------------------------------------------
                objLot_effectiveFPCInfoForOperation_Get_out strLot_effectiveFPCInfoForOperation_Get_out;
                objLot_effectiveFPCInfoForOperation_Get_in strLot_effectiveFPCInfoForOperation_Get_in;
                strLot_effectiveFPCInfoForOperation_Get_in.exchangeType    = CIMFWStrDup( SP_FPC_ExchangeType_BondingGroup );
                strLot_effectiveFPCInfoForOperation_Get_in.equipmentID     = strBondingMap_infoConsistency_Check_in.targetEquipmentID;
                strLot_effectiveFPCInfoForOperation_Get_in.lotID           = topBondingLotAttributes.lotID;
                strLot_effectiveFPCInfoForOperation_Get_in.routeID         = topBondingLotAttributes.targetRouteID;
                strLot_effectiveFPCInfoForOperation_Get_in.operationNumber = topBondingLotAttributes.targetOpeNo;

                PPT_METHODTRACE_V1( "", "Calling lot_effectiveFPCInfoForOperation_Get()" );
                rc = lot_effectiveFPCInfoForOperation_Get( strLot_effectiveFPCInfoForOperation_Get_out, strObjCommonIn,
                                                           strLot_effectiveFPCInfoForOperation_Get_in );

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2( "","lot_effectiveFPCInfoForOperation_Get() != RC_OK", rc );
                    strBondingMap_infoConsistency_Check_out.strResult = strLot_effectiveFPCInfoForOperation_Get_out.strResult;
                    return rc;
                }

                //-------------------------------------------------------------
                // Check if the Base Lot can be processed by Target Equipment
                //-------------------------------------------------------------
                CORBA::Boolean topEqpFound = FALSE;
                if ( strLot_effectiveFPCInfoForOperation_Get_out.equipmentActionRequired )
                {
                    PPT_METHODTRACE_V1("","Top Lot can be processed by Target Equipment.");
                    topEqpFound = TRUE;
                }

                objLot_FPCdispatchEqpInfo_Get_out strLot_FPCdispatchEqpInfo_Get_out;
                if ( !topEqpFound )
                {
                    //----------------------------------------------------
                    // Get FPC Information of the Lot at Target Operation
                    //----------------------------------------------------
                    objLot_FPCdispatchEqpInfo_Get_in strLot_FPCdispatchEqpInfo_Get_in;
                    strLot_FPCdispatchEqpInfo_Get_in.lotID           = topBondingLotAttributes.lotID;
                    strLot_FPCdispatchEqpInfo_Get_in.routeID         = topBondingLotAttributes.targetRouteID;
                    strLot_FPCdispatchEqpInfo_Get_in.operationNumber = topBondingLotAttributes.targetOpeNo;

                    PPT_METHODTRACE_V1( "", "Calling lot_FPCdispatchEqpInfo_Get()" );
                    rc = lot_FPCdispatchEqpInfo_Get( strLot_FPCdispatchEqpInfo_Get_out, strObjCommonIn,
                                                     strLot_FPCdispatchEqpInfo_Get_in );
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V4( "","lot_FPCdispatchEqpInfo_Get() != RC_OK", rc,
                                            strLot_FPCdispatchEqpInfo_Get_out.strResult.messageText,
                                            strLot_FPCdispatchEqpInfo_Get_out.strResult.reasonText );
                        strBondingMap_infoConsistency_Check_out.strResult = strLot_FPCdispatchEqpInfo_Get_out.strResult;
                        return rc;
                    }

                    const CORBA::Long eqpLen = strLot_FPCdispatchEqpInfo_Get_out.strFPCDispatchEqpInfo.dispatchEqpIDs.length();
                    for ( CORBA::Long i = 0; i < eqpLen; i++ )
                    {
                        if ( CIMFWStrCmp( strLot_FPCdispatchEqpInfo_Get_out.strFPCDispatchEqpInfo.dispatchEqpIDs[i].identifier,
                                          strBondingMap_infoConsistency_Check_in.targetEquipmentID.identifier ) == 0 )
                        {
                            topEqpFound = TRUE;
                            break;
                        }
                    }
                }

                if ( !topEqpFound && !strLot_FPCdispatchEqpInfo_Get_out.strFPCDispatchEqpInfo.restrictEqpFlag )
                {
                    PPT_METHODTRACE_V1( "", "FPC Setting of Equipment is not Found." );

                    /************************************************/
                    /* Call PosProcessDefinition::findMachinesFor() */
                    /************************************************/
                    PosMachineSequence_var aTopEqpSeq;
                    try
                    {
                        aTopEqpSeq = aTopPD->findMachinesFor( aTopProdSpec );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS( PosProcessDefinition::findMachinesFor );

                    const CORBA::Long eqpLen = aTopEqpSeq ? aTopEqpSeq->length() : 0;
                    for ( CORBA::Long i = 0; i < eqpLen; i++ )
                    {
                        if ( aEqp == (*aTopEqpSeq)[i] )
                        {
                            topEqpFound = TRUE;
                            break;
                        }
                    }
                }
                if ( !topEqpFound )
                {
                    PPT_METHODTRACE_V3( "", "Top Lot cannot be Processed.",
                                        topBondingLotAttributes.lotID.identifier,
                                        strBondingMap_infoConsistency_Check_in.targetEquipmentID.identifier );
                    PPT_SET_MSG_RC_KEY3( strBondingMap_infoConsistency_Check_out,
                                         MSG_BONDGRP_INVALID_EQP, RC_BONDGRP_INVALID_EQP,
                                         topBondingLotAttributes.lotID.identifier,
                                         strBondingMap_infoConsistency_Check_in.targetEquipmentID.identifier,
                                         topBondingLotAttributes.targetOpeID.identifier );
                    return RC_BONDGRP_INVALID_EQP;
                }

                //-------------------------------------------------------------
                // Getting Machine Recipe for Base Lot
                //-------------------------------------------------------------
                if ( strLot_effectiveFPCInfoForOperation_Get_out.machineRecipeActionRequired )
                {
                    PPT_METHODTRACE_V1("","FPC Setting of Machine Recipe Found. Use it.");

                    topBondingLotAttributes.targetMachineRecipeID = strLot_effectiveFPCInfoForOperation_Get_out.strFPCInfo.machineRecipeID;
                }
                else
                {
                    PPT_METHODTRACE_V1("","FPC Setting of Machine Recipe is not Found. calling PosLogicalRecipe::findMachineRecipeFor().");

                    PosMachineRecipe_var aTopMR;
                    try
                    {
                        aTopMR  = aTopLR->findMachineRecipeFor( aTopLot, aEqp );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS( PosLogicalRecipe::findMachineRecipeFor );

                    PPT_SET_OBJECT_IDENTIFIER( topBondingLotAttributes.targetMachineRecipeID, aTopMR,
                                               strBondingMap_infoConsistency_Check_out,
                                               bondingMap_infoConsistency_Check,
                                               PosMachineRecipe );
                }
            }

            PPT_METHODTRACE_V3( "", "MachineRecipeID",
                                baseBondingLotAttributes.targetMachineRecipeID.identifier,
                                topBondingLotAttributes.targetMachineRecipeID.identifier );

            if ( !CORBA::is_nil( aEqp ) )
            {
                //--------------------------------------------------------------
                // Check if the MachineRecipe are the same.
                //--------------------------------------------------------------

                if ( CIMFWStrLen( baseBondingLotAttributes.targetMachineRecipeID.identifier ) == 0 ||
                     CIMFWStrLen( topBondingLotAttributes.targetMachineRecipeID.identifier ) == 0 ||
                     CIMFWStrCmp( baseBondingLotAttributes.targetMachineRecipeID.identifier,
                                  topBondingLotAttributes.targetMachineRecipeID.identifier ) != 0 )
                {
                    PPT_SET_MSG_RC_KEY( strBondingMap_infoConsistency_Check_out,
                                        MSG_NOT_SAME_RECIPE, RC_NOT_SAME_RECIPE,
                                        topBondingLotAttributes.lotID.identifier );
                    return RC_NOT_SAME_RECIPE;
                }
            }
        }

        // Return to Caller
        PPT_METHODTRACE_EXIT( "PPTManager_i::bondingMap_infoConsistency_Check" );
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS( strBondingMap_infoConsistency_Check_out, bondingMap_infoConsistency_Check, methodName )
}

