//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_destinationInfo_GetForSLM.cpp
//

#include "pptmgr.hpp"

#include "pmc.hh"
#include "pcas.hh"

// Class: PPTManager
//
// Service: cassette_destinationInfo_GetForSLM()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/06/25 DSIV00000099 K.Matsuei      SLM(Small Lot Manufacturing) Support.
//
//[Function Description]:
//  The SLMUTS stocker for carrying SLMReserved Cassette is looked for.
//  If SLMUTSStocker is not found, UTSStocker is looked for.
//  If UTSStocker is not found, AutoStocker is looked for.
//  Nothing is returned when a stocker is not found.
//
//[Input Parameters]:
//  in  const pptObjCommonIn&                            strObjCommonIn
//  in  const objCassette_destinationInfo_GetForSLM_in&  strCassette_destinationInfo_GetForSLM_in
//
//  typedef struct objCassette_destinationInfo_GetForSLM_in_struct {
//      objectIdentifier  cassetteID;
//      any               siInfo;
//  } objCassette_destinationInfo_GetForSLM_in;
//
//[Output Parameters]:
//  out objCassette_destinationInfo_GetForSLM_out&       strCassette_destinationInfo_GetForSLM_out
//
//  typedef struct objCassette_destinationInfo_GetForSLM_out_struct {
//      pptRetCode                     strResult;
//      pptWhereNextInterBayInqResult  destinationOrder;
//      any                            siInfo;
//  } objCassette_destinationInfo_GetForSLM_out;
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long PPTManager_i::cassette_destinationInfo_GetForSLM(
    objCassette_destinationInfo_GetForSLM_out&       strCassette_destinationInfo_GetForSLM_out,
    const pptObjCommonIn&                            strObjCommonIn,
    const objCassette_destinationInfo_GetForSLM_in&  strCassette_destinationInfo_GetForSLM_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_destinationInfo_GetForSLM");

        PPT_METHODTRACE_V2("", "InParam [cassetteID]", strCassette_destinationInfo_GetForSLM_in.cassetteID.identifier);
        PPT_METHODTRACE_V2("", "InParam [lotID]     ", strCassette_destinationInfo_GetForSLM_in.lotID.identifier);

        CORBA::Long rc = RC_OK;

        //------------------------------------------------------
        // Decide CassetteID
        //------------------------------------------------------
        objectIdentifier cassetteID;

        if ( 0 == CIMFWStrLen(strCassette_destinationInfo_GetForSLM_in.lotID.identifier) )
        {
            if ( 0 == CIMFWStrLen(strCassette_destinationInfo_GetForSLM_in.cassetteID.identifier) )
            {
                PPT_METHODTRACE_V1("", "##### return RC_INVALID_INPUT_PARM");
                SET_MSG_RC( strCassette_destinationInfo_GetForSLM_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
                return RC_INVALID_INPUT_PARM;
            }

            cassetteID = strCassette_destinationInfo_GetForSLM_in.cassetteID;
        }
        else
        {
            objLot_cassette_Get_out strLot_cassette_Get_out;
            rc = lot_cassette_Get( strLot_cassette_Get_out, strObjCommonIn, strCassette_destinationInfo_GetForSLM_in.lotID );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "##### lot_cassette_Get() != RC_OK", rc);
                strCassette_destinationInfo_GetForSLM_out.strResult = strLot_cassette_Get_out.strResult;
                return rc;
            }

            cassetteID = strLot_cassette_Get_out.cassetteID;
        }

        PPT_METHODTRACE_V2("", "cassetteID", cassetteID.identifier);

        //------------------------------------------------------
        // Get SLM reserved equipment of cassette.
        //------------------------------------------------------
        PPT_METHODTRACE_V1("", "Get SLM reserved equipment of cassette.");

        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                               cassetteID,
                                               strCassette_destinationInfo_GetForSLM_out,
                                               cassette_destinationInfo_GetForSLM );

        PosMachine_var aSLMReservedMachine;
        try
        {
            aSLMReservedMachine = aCassette->getSLMReservedMachine();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getSLMReservedMachine);

        if ( CORBA::is_nil(aSLMReservedMachine) )
        {
            PPT_METHODTRACE_V1("", "##### return RC_CAST_NOT_SLM");
            PPT_SET_MSG_RC_KEY( strCassette_destinationInfo_GetForSLM_out,
                                MSG_NOT_RESERVED_CAST_SLM, RC_NOT_RESERVED_CAST_SLM,
                                strCassette_destinationInfo_GetForSLM_in.cassetteID.identifier );
            return RC_NOT_RESERVED_CAST_SLM;
        }

        //------------------------------------------------------
        // Get UTS/SLMUTS stocker which can be used.
        //------------------------------------------------------
        PPT_METHODTRACE_V1("", "Get UTS/SLMUTS stocker which can be used");

        PosStorageMachineSequence_var aUTSStockerSeq;
        try
        {
            aUTSStockerSeq = aSLMReservedMachine->getSLMUnderTrackStorages();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getSLMUnderTrackStorages);

        CORBA::Long lenUTSStocker = aUTSStockerSeq->length();
        PPT_METHODTRACE_V2("", "lenUTSStocker (SLMStk)", lenUTSStocker);

        pptEqpStockerStatusSequence strUTSStocker;
        strUTSStocker.length( lenUTSStocker );

        pptEqpStockerStatusSequence strSLMUTSStocker;
        strSLMUTSStocker.length( lenUTSStocker );

        CORBA::Long nSLMUTSCnt = 0;
        CORBA::Long nUTSCnt = 0;
        CORBA::Long nAutoCnt = 0;

        for ( CORBA::Long i=0; i < lenUTSStocker; i++ )
        {
            pptEqpStockerStatus tmpStocker;

            PPT_SET_OBJECT_IDENTIFIER( tmpStocker.stockerID,
                                       (*aUTSStockerSeq)[i],
                                       strCassette_destinationInfo_GetForSLM_out,
                                       cassette_destinationInfo_GetForSLM,
                                       PosStorageMachine );
            PPT_METHODTRACE_V2("", "stockerID", tmpStocker.stockerID.identifier);

            // Get Stocker Type
            CORBA::String_var stockerType;
            try
            {
                stockerType = (*aUTSStockerSeq)[i]->getStockerType();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosStorageMachine::getStockerType);
            PPT_METHODTRACE_V2("", "stockerType", stockerType);

            tmpStocker.stockerType = stockerType;
            tmpStocker.maxUTSCapacity = 0;

            // Get Available State
            CORBA::Boolean bAvailable = FALSE;
            try
            {
                bAvailable = (*aUTSStockerSeq)[i]->isAvailableState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosStorageMachine::isAvailableState)
            PPT_METHODTRACE_V2("", "bAvailable", (long)bAvailable);

            if ( !bAvailable )
            {
                continue; //[i]
            }

            CORBA::Boolean bUTSFlag = FALSE;
            try
            {
                bUTSFlag = (*aUTSStockerSeq)[i]->isUTSStocker();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosStorageMachine::isUTSStocker)
            PPT_METHODTRACE_V2("", "bUTSFlag", (long)bUTSFlag);

            CORBA::Boolean bSLMUTSFlag = FALSE;
            try
            {
                bSLMUTSFlag = (*aUTSStockerSeq)[i]->isSLMUTSFlagOn();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosStorageMachine::isSLMUTSFlagOn)
            PPT_METHODTRACE_V2("", "bAvailable", (long)bSLMUTSFlag);

            // Get Vacant Space
            PPT_METHODTRACE_V1("", "call stockerUTS_vacantSpace_CheckDR()");
            objStockerUTS_vacantSpace_CheckDR_out strStockerUTS_vacantSpace_CheckDR_out;
            rc = stockerUTS_vacantSpace_CheckDR( strStockerUTS_vacantSpace_CheckDR_out, strObjCommonIn, tmpStocker.stockerID );

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "##### stockerUTS_vacantSpace_CheckDR() != RC_OK", rc);
                strCassette_destinationInfo_GetForSLM_out.strResult = strStockerUTS_vacantSpace_CheckDR_out.strResult;
                return rc;
            }
            PPT_METHODTRACE_V2("", "vacantSpace", strStockerUTS_vacantSpace_CheckDR_out.vacantSpace);

            if ( 0 == strStockerUTS_vacantSpace_CheckDR_out.vacantSpace )
            {
                PPT_METHODTRACE_V1("", "vacantSpace is 0");
                continue; //[i]
            }

            tmpStocker.UTSFlag = TRUE;

            if ( bUTSFlag )
            {
                strUTSStocker[nUTSCnt] = tmpStocker;
                nUTSCnt++;
            }
            else if ( bSLMUTSFlag )
            {
                strSLMUTSStocker[nSLMUTSCnt] = tmpStocker;
                nSLMUTSCnt++;
            }
        } //[i]

        strUTSStocker.length( nUTSCnt );
        strSLMUTSStocker.length( nSLMUTSCnt );

        if ( 0 < nUTSCnt || 0 < nSLMUTSCnt )
        {
            strCassette_destinationInfo_GetForSLM_out.destinationOrder.strWhereNextEqpStatus.length( 1 );

            if ( 0 < nSLMUTSCnt )
            {
                PPT_METHODTRACE_V1("", "Return SLM-UTS Stocker");
                strCassette_destinationInfo_GetForSLM_out.destinationOrder.strWhereNextEqpStatus[0].strEqpStockerStatus = strSLMUTSStocker;
            }
            else if ( 0 < nUTSCnt )
            {
                PPT_METHODTRACE_V1("", "Return UTS Stocker");
                strCassette_destinationInfo_GetForSLM_out.destinationOrder.strWhereNextEqpStatus[0].strEqpStockerStatus = strUTSStocker;
            }
        }
        else
        {
            //------------------------------------------------------
            // Get Auto stocker which can be used.
            //------------------------------------------------------
            PPT_METHODTRACE_V1("", "Get Auto stocker which can be used");

            PosStorageMachineSequence_var aStockerSeq;
            try
            {
                aStockerSeq = aSLMReservedMachine->getStorageMachines();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getStorageMachines);

            CORBA::Long lenStocker = aStockerSeq->length();
            PPT_METHODTRACE_V2("", "lenStocker", lenStocker);

            pptEqpStockerStatusSequence strAutoStocker;
            strAutoStocker.length( lenStocker );

            for ( CORBA::Long i=0; i < lenStocker; i++ )
            {
                pptEqpStockerStatus tmpStocker;

                PPT_SET_OBJECT_IDENTIFIER( tmpStocker.stockerID,
                                           (*aStockerSeq)[i],
                                           strCassette_destinationInfo_GetForSLM_out,
                                           cassette_destinationInfo_GetForSLM,
                                           PosStorageMachine );
                PPT_METHODTRACE_V2("", "stockerID", tmpStocker.stockerID.identifier);

                // Get Stocker Type
                CORBA::String_var stockerType;
                try
                {
                    stockerType = (*aStockerSeq)[i]->getStockerType();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosStorageMachine::getStockerType);
                PPT_METHODTRACE_V2("", "stockerType", stockerType);

                if ( 0 != CIMFWStrCmp(stockerType, SP_Stocker_Type_Auto) )
                {
                    continue; //[i]
                }

                tmpStocker.stockerType = stockerType;
                tmpStocker.maxUTSCapacity = 0;
                tmpStocker.UTSFlag = FALSE;

                // Get Available State
                CORBA::Boolean bAvailable = FALSE;
                try
                {
                    bAvailable = (*aStockerSeq)[i]->isAvailableState();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosStorageMachine::isAvailableState)
                PPT_METHODTRACE_V2("", "bAvailable", (long)bAvailable);

                if ( !bAvailable )
                {
                    continue; //[i]
                }

                strAutoStocker[nAutoCnt] = tmpStocker;
                nAutoCnt++;
            } //[i]

            strAutoStocker.length( nAutoCnt );

            if ( 0 < nAutoCnt )
            {
                strCassette_destinationInfo_GetForSLM_out.destinationOrder.strWhereNextEqpStatus.length( 1 );

                PPT_METHODTRACE_V1("", "Return Auto Stocker");
                strCassette_destinationInfo_GetForSLM_out.destinationOrder.strWhereNextEqpStatus[0].strEqpStockerStatus = strAutoStocker;
            }
            else
            {
                PPT_METHODTRACE_V1("", "Return No Stocker");
            }
        }

        PPT_METHODTRACE_V1("", "---------------------------");
        PPT_METHODTRACE_V2("", "[nAutoCnt]  ", nAutoCnt);
        PPT_METHODTRACE_V2("", "[nUTSCnt]   ", nUTSCnt);
        PPT_METHODTRACE_V2("", "[nSLMUTSCnt]", nSLMUTSCnt);
        PPT_METHODTRACE_V1("", "---------------------------");

        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_destinationInfo_GetForSLM");

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_destinationInfo_GetForSLM_out, cassette_destinationInfo_GetForSLM, methodName)
}
