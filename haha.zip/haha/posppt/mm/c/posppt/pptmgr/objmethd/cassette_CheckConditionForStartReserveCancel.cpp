#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_CheckConditionForStartReserveCancel.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:32:20 [ 7/13/07 19:32:21 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_CheckConditionForStartReserveCancel.cpp
//

#include "pptmgr.hpp"
#include "pctrlj.hh"
#include "pcas.hh"

//[Object Function Name]: long   cassette_CheckConditionForStartReserveCancel
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2000-08-23  0.00      Y.Iwasaki      Initial release
// 2003-11-27  P5100056  K.Matsuei      TCS cannot perform error recovery in InternalBuffer.
// 2005-11-09  D7000009  K.Matsuei      Take-out Xfer for LoadVerifyNG Carrier by CassetteDelivery.
//
//[Function Description]:
//  Check cassette's condition for StartReserveCancel.
//
//  The following conditions are checked.
//
//  <<< dispatchState >>>
//  Cassette's dispatch state must be TRUE.
//
//  <<< controlJobID >>>
//  Cassette's controlJobID must be same as in-parm's controlJobID
//
//
//[Input Parameters]:
//  in  pptObjCommonIn             strObjCommonIn;
//  in  objectIdentifier           controlJobID;
//  in  pptStartCassetteSequence   strStartCassette;
//
//[Output Parameters]:
//  out objCassette_CheckConditionForStartReserveCancel_out   strCassette_CheckConditionForStartReserveCancel_out;
//
//  typedef struct objCassette_CheckConditionForStartReserveCancel_out_struct {
//      pptRetCode                      strResult;
//  } objCassette_CheckConditionForStartReserveCancel_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------

CORBA::Long PPTManager_i::cassette_CheckConditionForStartReserveCancel(
                            objCassette_CheckConditionForStartReserveCancel_out& strCassette_CheckConditionForStartReserveCancel_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& controlJobID,
                            const pptStartCassetteSequence& strStartCassette)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_CheckConditionForStartReserveCancel");
        PPT_METHODTRACE_V2( "","in-parm's controlJobID", controlJobID.identifier);
        PPT_METHODTRACE_V2( "","in-parm's strStartCassette", "pptStartCassetteSequence");

        /*----------------*/
        /*                */
        /*   Initialize   */
        /*                */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        /*--------------------------------------*/
        /*                                      */
        /*   Check Cassette's Transfer Status   */
        /*                                      */
        /*--------------------------------------*/
        CORBA::Long SCLength = strStartCassette.length();
        for (CORBA::Long i=0 ; i<SCLength ; i++)
        {
            PPT_METHODTRACE_V3("", "loop to strStartCassette.length()",SCLength,i);

            /*-------------------------*/
            /*   Get Cassette Object   */
            /*-------------------------*/
            PosCassette_var aCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR(aCassette,strStartCassette[i].cassetteID,strCassette_CheckConditionForStartReserveCancel_out,cassette_CheckConditionForStartReserveCancel);

            /*-----------------------*/
            /*   Get DispatchState   */
            /*-----------------------*/
            CORBA::Boolean dispatchState;
            try
            {
                dispatchState = aCassette->isDispatchReserved();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getDispatchState);

            if (dispatchState == TRUE)
            {
                PPT_METHODTRACE_V1("", "dispatchState == TRUE");
                rc = RC_OK;
            }
            else
            {
                PPT_METHODTRACE_V1("", "dispatchState != TRUE");
                SET_MSG_RC(strCassette_CheckConditionForStartReserveCancel_out, MSG_NOT_DISPATCH_RESVED_CST, RC_NOT_DISPATCH_RESVED_CST);
                return(RC_NOT_DISPATCH_RESVED_CST);
            }

            /*----------------------------------*/
            /*   Get controlJobID of Cassette   */
            /*----------------------------------*/
            PosControlJob_var aControlJob;
            try
            {
                aControlJob = aCassette->getControlJob();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob);

            if (CORBA::is_nil(aControlJob) == TRUE)
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil(aControlJob) == TRUE");
                SET_MSG_RC(strCassette_CheckConditionForStartReserveCancel_out, MSG_CAST_CTRLJOBID_BLANK, RC_CAST_CTRLJOBID_BLANK);
                return(RC_CAST_CTRLJOBID_BLANK);
            }

            objectIdentifier castControlJobID;
            PPT_SET_OBJECT_IDENTIFIER(
                        castControlJobID,
                        aControlJob,
                        strCassette_CheckConditionForStartReserveCancel_out,
                        cassette_CheckConditionForStartReserveCancel,
                        PosControlJob);

            CORBA::String_var castControlJobIdent;
            CORBA::String_var controlJobIdent;
            castControlJobIdent = castControlJobID.identifier;
            controlJobIdent     = controlJobID.identifier;
            if (CIMFWStrCmp(castControlJobIdent,controlJobIdent) != 0)
            {
                PPT_METHODTRACE_V1("", "castControlJobIdent != controlJobIdent");
                SET_MSG_RC(strCassette_CheckConditionForStartReserveCancel_out, MSG_CAST_CTRLJOB_MIX, RC_CAST_CTRLJOB_MIX);
                return(RC_CAST_CTRLJOB_MIX);
            }
        }

        //D7000009 If this check is carried out, StartReserveCancel can NOT perform immediately after loading Carrier.
        //D7000009 So the following checks are not performed when TCS user does claim.
        if ( 0 != CIMFWStrCmp(SP_TCS_Person, strObjCommonIn.strUser.userID.identifier) ) //D7000009
        {                                                                                //D7000009
//P5100056 start
            /*-----------------------------------*/
            /*                                   */
            /*   Check Cassettes of CJ on Port   */
            /*                                   */
            /*-----------------------------------*/
            PPT_METHODTRACE_V1("", "Check Cassettes of CJ on Port");
            PosControlJob_var aControlJob;
            PPT_CONVERT_CONTROLJOBID_TO_CONTROLJOB_OR( aControlJob, controlJobID,
                            strCassette_CheckConditionForStartReserveCancel_out, cassette_CheckConditionForStartReserveCancel );

            PosMachine_var aMachine;
            try
            {
                aMachine = aControlJob->getMachine();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosControlJob::getMachine);

            if ( TRUE == CORBA::is_nil(aMachine) )
            {
                PPT_METHODTRACE_V1("", "##### aMachine is Nil");
                PPT_SET_MSG_RC_KEY(strCassette_CheckConditionForStartReserveCancel_out, MSG_NOT_FOUND_EQP, RC_NOT_FOUND_EQP, "*****");
                return RC_NOT_FOUND_EQP;
            }

            CORBA::String_var equipmentCategory;
            try
            {
                equipmentCategory = aMachine->getCategory();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getCategory)
            PPT_METHODTRACE_V2("", "equipmentCategory", equipmentCategory);

            if ( 0 == CIMFWStrCmp(equipmentCategory, SP_Mc_Category_InternalBuffer) )
            {
                objectIdentifier equipmentID;
                PPT_SET_OBJECT_IDENTIFIER( equipmentID, aMachine,
                            strCassette_CheckConditionForStartReserveCancel_out, cassette_CheckConditionForStartReserveCancel, PosMachine );

                PPT_METHODTRACE_V1("", "equipment_portInfoForInternalBuffer_GetDR()");
                objEquipment_portInfoForInternalBuffer_GetDR_out  strEquipment_portInfoForInternalBuffer_GetDR_out;
                rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out, strObjCommonIn, equipmentID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "##### equipment_portInfoForInternalBuffer_GetDR() != RC_OK", rc);
                    strCassette_CheckConditionForStartReserveCancel_out.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
                    return( rc );
                }

                PPT_METHODTRACE_V1("", "controlJob_containedLot_Get()");
                objControlJob_containedLot_Get_out  strControlJob_containedLot_Get_out;
                rc = controlJob_containedLot_Get( strControlJob_containedLot_Get_out, strObjCommonIn, controlJobID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "##### controlJob_containedLot_Get() != RC_OK", rc);
                    strCassette_CheckConditionForStartReserveCancel_out.strResult = strControlJob_containedLot_Get_out.strResult;
                    return( rc );
                }

                CORBA::Long lenPort = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus.length();
                PPT_METHODTRACE_V2("", "lenPort", lenPort);

                CORBA::Long lenCJCas = strControlJob_containedLot_Get_out.strControlJobCassette.length();
                PPT_METHODTRACE_V2("", "lenCJCas", lenCJCas);
                for ( i=0; i < lenCJCas; i++ )
                {
                    PPT_METHODTRACE_V2("", "CJ-cassetteID", strControlJob_containedLot_Get_out.strControlJobCassette[i].cassetteID.identifier);

                    for ( CORBA::Long j=0; j < lenPort; j++ )
                    {
                        PPT_METHODTRACE_V2("", "portID", strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID.identifier);
                        PPT_METHODTRACE_V2("", "loadedCassetteID", strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier);

                        if ( 0 == CIMFWStrCmp(strControlJob_containedLot_Get_out.strControlJobCassette[i].cassetteID.identifier,
                                              strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier) )
                        {
                            PPT_METHODTRACE_V1("", "##### return RC_NOT_CASSETTE_ON_PORT");
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForStartReserveCancel_out,
                                                 MSG_NOT_CASSETTE_ON_PORT, RC_NOT_CASSETTE_ON_PORT,
                                                 strControlJob_containedLot_Get_out.strControlJobCassette[i].cassetteID.identifier,
                                                 strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo.strEqpPortStatus[j].portID.identifier );
                            return RC_NOT_CASSETTE_ON_PORT;
                        }
                    } //end of [j]
                } //end of [i]
            }
//P5100056 end
        } //D7000009

        /*----------------------*/
        /*                      */
        /*   Return to Caller   */
        /*                      */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_CheckConditionForStartReserveCancel");
        return(RC_OK);
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_CheckConditionForStartReserveCancel_out, cassette_CheckConditionForStartReserveCancel, methodName);
}

