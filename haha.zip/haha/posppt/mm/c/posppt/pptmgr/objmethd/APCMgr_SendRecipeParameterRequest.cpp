#ifndef lint
static char *sccsid =  "@(#) 1.5 superpos/src/spppt/source/posppt/pptmgr/objmethd/APCMgr_SendRecipeParameterRequest.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 2/13/08 17:34:27 [ 2/13/08 17:34:27 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: APCMgr_SendRecipeParameterRequest.cpp
//

#include "pptmgr.hpp"

//[Object Function Name]: long   APCMgr_SendRecipeParameterRequest
//
// Date        Level    Author         Note
// ----------  -------  -------------  -------------------------------------------
// 2004/07/14  D51M0000 M.Mori         Initial Release (R51M)
// 2004/10/22  D6000035 M.Murata       The return code of TIMEOUT from MQH is handled.
// 2004/11/17  D6000025 K.Murakami     Add SP_STRING_TO_OBJECT for eBroker
// 2004/11/18  D6000025 K.Murakami     Change CORBA::IT_chooseDefaultEnv() to SP_CORBAENV_DEFENV
// 2005/05/17  D6000275 M.Murata       Change variable for externalServerList.
// 2005/05/17  D6000314 M.Murata       Change variable for externalServerList.(EB)
// 2006/01/26  D7000182 H.Mutoh        Change the return code if it didn't communicate with APC system.
// 2007/04/20  D9000001 M.Murata       64bit support.
// 2008/01/17  D9000059 H.Hotta        External System Interface Security Control
// 2008/02/13  P9000198 M.Ishino       Fix the extension logic of SequenceLength is wrong.
//
// Date        Level         Author         Note
// ----------  ------------  -------------  -------------------------------------------
// 2010/10/28  DSIV00002543  S.Yamamoto     Improvement of reasonText message.
//
//[Function Description]:
//
//[Input Parameters]:
//  in  pptObjCommonIn                              strObjCommonIn
//  in  objectIdentifier                            equipmentID
//  in  pptAPCBaseCassetteSequence                  strAPCBaseCassetteList
//  in  pptAPCRunTimeCapabilityResponseSequence     strAPCRunTimeCapabilityResponse
//  in  boolean                                     final
//
//[Output Parameters]:
//
//  out objAPCMgr_SendRecipeParameterRequest_out   strAPCMgr_SendRecipeParameterRequest_out
//
//  typedef struct objAPCMgr_SendRecipeParameterRequest_out_struct
//  {
//      pptRetCode                                  strResult;
//      pptAPCRecipeParameterResponseSequence       strAPCProductDispositionResponse;
//      any                                         siInfo;
//  } objAPCMgr_SendRecipeParameterRequest_out;
//
//[Return Value]:
//
//  Return Code                         Messsage ID
// ------------------------------------ ---------------------------------------------
//  RC_OK                               MSG_OK
//  RC_APC_SERVER_NIL_OBJ               MSG_APC_SERVER_NIL_OBJ
//  RC_APC_RECIPEPARAMETERREQ_ERROR     MSG_APC_RECIPEPARAMETERREQ_ERROR
//  RC_SYSTEM_ERROR                     MSG_SYSTEM_ERROR
//
//[Pseudo Code]
//

#include "mqsm.hh"

CORBA::Long PPTManager_i::APCMgr_SendRecipeParameterRequest(
    objAPCMgr_SendRecipeParameterRequest_out&       strAPCMgr_SendRecipeParameterRequest_out,
    const pptObjCommonIn&                           strObjCommonIn,
    const objectIdentifier&                         equipmentID,
    const pptAPCBaseCassetteSequence&               strAPCBaseCassetteList,
    const pptAPCRunTimeCapabilityResponseSequence&  strAPCRunTimeCapabilityResponse,
    const CORBA::Boolean                            final
)
{
    CORBA::Long rc = RC_OK;
    char * methodName = NULL;

    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::APCMgr_SendRecipeParameterRequest");

        CORBA::Long systemname_cnt = 0;
        CORBA::Long m_len = 1000;
        stringSequence systemNameList;

        systemNameList.length(m_len);

        CORBA::Long response_cnt = strAPCRunTimeCapabilityResponse.length();

        for ( CORBA::Long loop_response_cnt = 0; loop_response_cnt < response_cnt; loop_response_cnt++ )
        {
            PPT_METHODTRACE_V2("", "response_cnt =", response_cnt);
            PPT_METHODTRACE_V2("", "loop_response_cnt =", loop_response_cnt);

            CORBA::Long capability_cnt = strAPCRunTimeCapabilityResponse[loop_response_cnt].strAPCRunTimeCapability.length();

            for ( CORBA::Long loop_capability_cnt = 0; loop_capability_cnt < capability_cnt; loop_capability_cnt++ )
            {
                PPT_METHODTRACE_V2("", "capability_cnt =", capability_cnt);
                PPT_METHODTRACE_V2("", "loop_capability_cnt =", loop_capability_cnt);

                CORBA::Long function_cnt = strAPCRunTimeCapabilityResponse[loop_response_cnt].
                                             strAPCRunTimeCapability[loop_capability_cnt].
                                               strAPCBaseAPCSystemFunction.length();

                for ( CORBA::Long loop_function_cnt = 0; loop_function_cnt < function_cnt; loop_function_cnt++ )
                {
                    PPT_METHODTRACE_V2("", "function_cnt =", function_cnt);
                    PPT_METHODTRACE_V2("", "loop_function_cnt =", loop_function_cnt);

                    if ( CIMFWStrCmp( strAPCRunTimeCapabilityResponse[loop_response_cnt].
                                       strAPCRunTimeCapability[loop_capability_cnt].
                                         strAPCBaseAPCSystemFunction[loop_function_cnt].type, 
                                      SP_APCFunctionType_recipeParameterAdjust ) == 0 )
                    {
                        PPT_METHODTRACE_V1("", "type == SP_APCFunctionType_recipeParameterAdjust");

                        CORBA::Long tmp_cnt = 0;
                        CORBA::Boolean systemNameFlag = FALSE;
                        for ( tmp_cnt = 0; tmp_cnt < systemname_cnt; tmp_cnt++ )
                        {
                             PPT_METHODTRACE_V3("","tmp_cnt / systemname_cnt:",tmp_cnt,systemname_cnt);

                             if ( CIMFWStrCmp( systemNameList[tmp_cnt], strAPCRunTimeCapabilityResponse[loop_response_cnt].
                                                                          strAPCBaseIdentification.systemName ) == 0 )
                             {
                                 PPT_METHODTRACE_V1("","systemNameFlag = TRUE");
                                 systemNameFlag = TRUE;
                                 break;
                             }
                        }

                        if ( systemNameFlag == FALSE )
                        {
                            systemNameList[systemname_cnt] = CIMFWStrDup( strAPCRunTimeCapabilityResponse[loop_response_cnt].strAPCBaseIdentification.systemName );

                            systemname_cnt++;    //P9000198

                            if( systemname_cnt >= m_len )
                            {
                                m_len = m_len + 500;
                                systemNameList.length(m_len);
                            }

//P9000198                            systemname_cnt++;
                        }
                    }
                }
            }
        }

        systemNameList.length(systemname_cnt);
        PPT_METHODTRACE_V2("", "systemNameList.length()", systemname_cnt);

        if ( systemname_cnt > 0 )
        {
            PPT_METHODTRACE_V2("", "systemname_cnt > 0", systemname_cnt);

            CORBA::String_var tmpFinal = CIMFWStrDup("");
            if ( final == TRUE )
            {
                PPT_METHODTRACE_V1("", "recipeParamReq final flag is TRUE");
                tmpFinal = CIMFWStrDup(SP_RecipeParameterRequest_final_true);
            }
            else
            {
                PPT_METHODTRACE_V1("", "recipeParamReq final flag is FALSE");
                tmpFinal = CIMFWStrDup(SP_RecipeParameterRequest_final_false);
            }

            /*---------------------------------*/
            /*   Get Server Name               */
            /*---------------------------------*/
            PPT_METHODTRACE_V1("", "Get Server Name");
            CORBA::String_var tmpAPCServerName = CIMFWStrDup( getenv(SP_APC_SERVER_NAME) );
//D9000001            char* APCServerName = CORBA::string_alloc( CIMFWStrLen(tmpAPCServerName)+1 );
            char* APCServerName = CORBA::string_alloc( (CORBA::ULong) CIMFWStrLen(tmpAPCServerName)+1 );//D9000001
            CORBA::String_var tmpStr = APCServerName;
            if ( NULL != APCServerName )
            {
                APCServerName[0] = NULL;
            }

            if ( strstr(tmpAPCServerName, ":") == NULL )
            {
                CIMFWStrCpy( APCServerName , ":" );
                CIMFWStrCat( APCServerName , tmpAPCServerName );
            }
            else
            {
                CIMFWStrCpy( APCServerName , tmpAPCServerName );
            }

            /*---------------------------------*/
            /*   Get Host Name                 */
            /*---------------------------------*/
            PPT_METHODTRACE_V1("", "Get Host Name");
            CORBA::String_var APCHostName;
            APCHostName = CIMFWStrDup( getenv(SP_APC_HOST_NAME) );

            /*---------------------------------*/
            /*   Get APCManager                */
            /*---------------------------------*/
            PPT_METHODTRACE_V1("", "Get APCManager");
            MQSvcMgr_var APCSvcMgr = MQSvcMgr::_nil();

            PPT_METHODTRACE_V1("", "call APCMgr_GetServiceManager");
            objAPCMgr_GetServiceManager_out strAPCMgr_GetServiceManager_out;
            rc = APCMgr_GetServiceManager( strAPCMgr_GetServiceManager_out,
                                           strObjCommonIn,
                                           APCServerName,
                                           APCHostName);

            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "APCMgr_GetServiceManager() != RC_OK", rc);
                strAPCMgr_SendRecipeParameterRequest_out.strResult = strAPCMgr_GetServiceManager_out.strResult;
                return( rc );
            }

#ifdef EBROKER           //D6000025
            CORBA::Object_var anObject = SP_STRING_TO_OBJECT(strAPCMgr_GetServiceManager_out.APCSvcMgr);   //D6000025
#else                    //D6000025
            CORBA::Object_var anObject = CORBA::Orbix.string_to_object(strAPCMgr_GetServiceManager_out.APCSvcMgr);
#endif                   //D6000025
            APCSvcMgr = MQSvcMgr::_narrow(anObject);
            if ( CORBA::is_nil(APCSvcMgr) )
            {
                SET_MSG_RC(strAPCMgr_SendRecipeParameterRequest_out, MSG_APC_SERVER_NIL_OBJ, RC_APC_SERVER_NIL_OBJ);
                return( RC_APC_SERVER_NIL_OBJ );
            }

            //D6000025CORBA::Environment envTimeOut = CORBA::IT_chooseDefaultEnv();
            CORBA::Environment envTimeOut = SP_CORBAENV_DEFENV;   //D6000025
            CORBA::String_var timeOutValue;
            timeOutValue = CIMFWStrDup( getenv(SP_TX_Timeout_APC) );
            if ( 0 < CIMFWStrLen(timeOutValue) )
            {
                envTimeOut.timeout(atol(timeOutValue) * 1000);
            }

//D6000275 Add Start
            //--------------------------------
            // Get Environment for GenIOR     
            //--------------------------------
#ifdef EBROKER                                                                    //D6000314
            tmpAPCServerName = CIMFWStrDup(APCServerName);                        //D6000314
#else                                                                             //D6000314
            tmpAPCServerName = CIMFWStrDup(getenv(SP_APCServerName_ForGenIOR));
//D6000275 Add End
#endif                                                                            //D6000314

            /*-------------------------*/
            /*   Send Request to APC   */
            /*-------------------------*/
            PPT_METHODTRACE_V1("", "Send Request to APC");

            PPT_METHODTRACE_V1("", "strAPCBaseCassetteList check");
            CORBA::Long cassette_cnt = strAPCBaseCassetteList.length();
            PPT_METHODTRACE_V2("", "cassette_cnt" , cassette_cnt);

            for( CORBA::Long loop_cassette_cnt = 0 ; loop_cassette_cnt < cassette_cnt ; loop_cassette_cnt++)
            {
                PPT_METHODTRACE_V2("", "loop_cassette_cnt" , loop_cassette_cnt);
                CORBA::Long lot_cnt = strAPCBaseCassetteList[loop_cassette_cnt].strAPCBaseLot.length();
                PPT_METHODTRACE_V2("", "lot_cnt" , lot_cnt );
            }

            pptRecipeParameterRequestResult* results = NULL;
            pptRecipeParameterRequestResult_var resultsVar;

//D9000059 add start
            // External System Interface Security Control
            pptUser tmpRequestUser = strObjCommonIn.strUser;

            CORBA::String_var configFlag = CIMFWStrDup( getenv(SP_USER_ID_PASSWORD_CONFIGRATION) );
            PPT_METHODTRACE_V2("","SP_USER_ID_PASSWORD_CONFIGRATION ", configFlag);

            if( 0 == CIMFWStrCmp( configFlag, "1" ) )
            {
                PPT_METHODTRACE_V1("","SP_USER_ID_PASSWORD_CONFIGRATION=1");

                tmpRequestUser.userID.identifier = CIMFWStrDup( getenv(SP_APC_USER_ID) );
                tmpRequestUser.password          = CIMFWStrDup( getenv(SP_APC_USER_PASSWORD) );
            }

            PPT_METHODTRACE_V2("","userID   ", tmpRequestUser.userID.identifier);
            PPT_METHODTRACE_V2("","password ", tmpRequestUser.password);
//D9000059 add end

            try
            {
//D9000059                results = APCSvcMgr->TxRecipeParameterRequest( strObjCommonIn.strUser,
                results = APCSvcMgr->TxRecipeParameterRequest( tmpRequestUser,          //D9000059
                                                               equipmentID.identifier,
                                                               systemNameList,
                                                               strAPCBaseCassetteList,
                                                               tmpFinal, envTimeOut );
                resultsVar = results;
            }
            catch(const CORBA::SystemException &SysEx)
            {
                PPT_METHODTRACE_V1("", "CORBA::SystemException caught");
                APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
                SET_MSG_RC( strAPCMgr_SendRecipeParameterRequest_out, MSG_NO_RESPONSE_APC, RC_NO_RESPONSE_APC );
                try
                {
//D6000275                    externalServerList.remove((char *)APCHostName);
                    PPT_METHODTRACE_V2("", "externalServerList.remove()", tmpAPCServerName);    //D6000275
                    externalServerList.remove((char *)tmpAPCServerName);                        //D6000275
                }
                catch( ... )
                {
                    PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                }
                return( RC_NO_RESPONSE_APC );
            }
            catch( ... )
            {
                PPT_METHODTRACE_V1("", "Unknown exception caught");
                APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ( );
                SET_MSG_RC( strAPCMgr_SendRecipeParameterRequest_out, MSG_NO_RESPONSE_APC, RC_NO_RESPONSE_APC );
                try
                {
//D6000275                    externalServerList.remove((char *)APCHostName);
                    PPT_METHODTRACE_V2("", "externalServerList.remove()", tmpAPCServerName);    //D6000275
                    externalServerList.remove((char *)tmpAPCServerName);                        //D6000275
                }
                catch( ... )
                {
                    PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                }
                return( RC_NO_RESPONSE_APC );
            }

//D6000035            strAPCMgr_SendRecipeParameterRequest_out.strResult = results->strResult;
//D6000035            rc = atol(strAPCMgr_SendRecipeParameterRequest_out.strResult.returnCode);
//D6000035
//D6000035            if ( rc == RC_OK )
//D6000035            {
//D6000035                PPT_METHODTRACE_V1("", "TxRecipeParameterRequest() == RC_OK");
//D6000035
//D6000035                CORBA::Long recipepara_cnt = results->strAPCRecipeParameterResponseList.length();
//D6000035                PPT_METHODTRACE_V2("", "strAPCRecipeParameterResponseList.length()", recipepara_cnt);
//D6000035
//D6000035                CORBA::Long response_cnt = 0;
//D6000035                strAPCMgr_SendRecipeParameterRequest_out.strAPCRecipeParameterResponse.length(recipepara_cnt);
//D6000035
//D6000035                for ( CORBA::Long loop_recipepara_cnt = 0; loop_recipepara_cnt < recipepara_cnt; loop_recipepara_cnt++ )
//D6000035                {
//D6000035                    PPT_METHODTRACE_V2("", "recipepara_cnt =", recipepara_cnt);
//D6000035
//D6000035                    if ( CIMFWStrCmp( results->strAPCRecipeParameterResponseList[loop_recipepara_cnt].strAPCBaseReturnCode.state, SP_APCReturnCode_OK ) == 0 )
//D6000035                    {
//D6000035                        PPT_METHODTRACE_V2("", "strAPCBaseReturnCode.state == SP_APCReturnCode_OK", loop_recipepara_cnt);
//D6000035                        strAPCMgr_SendRecipeParameterRequest_out.strAPCRecipeParameterResponse[response_cnt]
//D6000035                           = results->strAPCRecipeParameterResponseList[loop_recipepara_cnt];
//D6000035
//D6000035                        response_cnt++;
//D6000035                    }
//D6000035                    else
//D6000035                    {
//D6000035                        PPT_METHODTRACE_V2("", "strAPCBaseReturnCode.state != SP_APCReturnCode_OK", loop_recipepara_cnt);
//D6000035
//D6000035                        SET_MSG_RC(strAPCMgr_SendRecipeParameterRequest_out,
//D6000035                                   MSG_APC_RECIPEPARAMETERREQ_ERROR,
//D6000035                                   RC_APC_RECIPEPARAMETERREQ_ERROR);
//D6000035                        return( RC_APC_RECIPEPARAMETERREQ_ERROR );
//D6000035                    }
//D6000035                }
//D6000035                PPT_METHODTRACE_V2("", "strAPCProductDispositionResponse.length()", response_cnt);
//D6000035                strAPCMgr_SendRecipeParameterRequest_out.strAPCRecipeParameterResponse.length(response_cnt);
//D6000035            }
//D6000035            else
//D6000035            {
//D6000035                PPT_METHODTRACE_V2("", "TxRecipeParameterRequest() != RC_OK", rc);
//D6000035
//D6000035                SET_MSG_RC(strAPCMgr_SendRecipeParameterRequest_out,
//D6000035                           MSG_APC_RECIPEPARAMETERREQ_ERROR,
//D6000035                           RC_APC_RECIPEPARAMETERREQ_ERROR);
//D6000035                return( RC_APC_RECIPEPARAMETERREQ_ERROR );
//D6000035            }

//D6000035 Add Start
            //-------------------------------------------------------------------------------------------------
            // APC return only 0 or 2. 0 is nomal end, 2 is error. This returnCode is strResult.returnCode.    
            // But when strAPCBaseReturnCode.state is not "OK", TxRecipeParameterRequest is fail.              
            // By the above reason, we check strAPCBaseReturnCode.state, though returnCode is 0.               
            // If except "OK" is found, this function returns error as RC_APC_RECIPEPARAMETERREQ_ERROR.        
            //-------------------------------------------------------------------------------------------------
            strAPCMgr_SendRecipeParameterRequest_out.strResult = results->strResult;
//D9000001            rc = atol(strAPCMgr_SendRecipeParameterRequest_out.strResult.returnCode);
            rc = atoi(strAPCMgr_SendRecipeParameterRequest_out.strResult.returnCode);//D9000001
            PPT_METHODTRACE_V2("", "results = APCSvcMgr->TxRecipeParameterRequest -->>", rc );

            CORBA::Boolean errorFlag = FALSE;
            if( rc != RC_OK )
            {
                errorFlag = TRUE;
            }

            CORBA::Long recipepara_cnt = results->strAPCRecipeParameterResponseList.length();
            PPT_METHODTRACE_V2("", "strAPCRecipeParameterResponseList.length()", recipepara_cnt);
            //----------------------------------------------
            // Check strAPCBaseReturnCode.state             
            //----------------------------------------------
            for ( CORBA::Long loop_check_cnt = 0; loop_check_cnt < recipepara_cnt; loop_check_cnt++ )
            {
                PPT_METHODTRACE_V2("", "state ", results->strAPCRecipeParameterResponseList[loop_check_cnt].strAPCBaseReturnCode.state);

                if( CIMFWStrCmp( results->strAPCRecipeParameterResponseList[loop_check_cnt].strAPCBaseReturnCode.state , SP_APCReturnCode_OK ) != 0 )
                {
                    PPT_METHODTRACE_V2("", "BaseReturnCode.state is ERROR",
                                           results->strAPCRecipeParameterResponseList[loop_check_cnt].strAPCBaseReturnCode.state);
                    errorFlag = TRUE;
                    break;
                }
            }

            if ( errorFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "TxRecipeParameterRequest ERROR");

                //----------------------------------------------
                // Make Reason Text                             
//DSIV00002543                // ex) APCSystemName : Status : Massage         
                // ex) message Text : reasonCode : reasonText : //DSIV00002543
                //     APCSystemName : Status : Massage : reasonCode : Reasontext //DSIV00002543
                //----------------------------------------------
                CORBA::String_var tmpReasonText;
                tmpReasonText = CIMFWStrDup("");
//DSIV00002543 add start
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, "APC-I/F : " );
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, results->strResult.messageText );
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, " : " );
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, results->strResult.returnCode );
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, " : " );
                PPT_STRDUPCAT_STRING( TRUE , tmpReasonText, tmpReasonText, results->strResult.reasonText );
//DSIV00002543 add end
                for ( CORBA::Long loop_recipepara_cnt = 0; loop_recipepara_cnt < recipepara_cnt; loop_recipepara_cnt++ )
                {
                    PPT_METHODTRACE_V2("", "loop time  ---> ", loop_recipepara_cnt);
                    PPT_METHODTRACE_V2("", "APCSystemName : ", results->strAPCRecipeParameterResponseList[loop_recipepara_cnt].systemName);
                    PPT_METHODTRACE_V2("", "state         : ", results->strAPCRecipeParameterResponseList[loop_recipepara_cnt].strAPCBaseReturnCode.state);
                    PPT_METHODTRACE_V2("", "messageText   : ", results->strAPCRecipeParameterResponseList[loop_recipepara_cnt].strAPCBaseReturnCode.messageText);

                    PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, results->strAPCRecipeParameterResponseList[loop_recipepara_cnt].systemName );
                    PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, " : " );
                    PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, results->strAPCRecipeParameterResponseList[loop_recipepara_cnt].strAPCBaseReturnCode.state );
                    PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, " : " );
//DSIV00002543                    PPT_STRDUPCAT_STRING( TRUE , tmpReasonText, tmpReasonText, results->strAPCRecipeParameterResponseList[loop_recipepara_cnt].strAPCBaseReturnCode.messageText );
//DSIV00002543 add start
                    PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, results->strAPCRecipeParameterResponseList[loop_recipepara_cnt].strAPCBaseReturnCode.messageText );
                    PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, " : Reason [ " );
                    PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, results->strAPCRecipeParameterResponseList[loop_recipepara_cnt].strAPCBaseReturnCode.reasonCode );
                    PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, " : " );
                    PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, results->strAPCRecipeParameterResponseList[loop_recipepara_cnt].strAPCBaseReturnCode.reasonText );
                    PPT_STRDUPCAT_STRING( TRUE , tmpReasonText, tmpReasonText, " ] " );
//DSIV00002543 add end
                }

                strAPCMgr_SendRecipeParameterRequest_out.strResult.reasonText = tmpReasonText;
                strAPCMgr_SendRecipeParameterRequest_out.strAPCRecipeParameterResponse.length(0);

                SET_MSG_RC( strAPCMgr_SendRecipeParameterRequest_out,
                            MSG_APC_RECIPEPARAMETERREQ_ERROR,
                            RC_APC_RECIPEPARAMETERREQ_ERROR);
                return( RC_APC_RECIPEPARAMETERREQ_ERROR );

            }
            else
            {
                PPT_METHODTRACE_V1("", "TxRecipeParameterRequest RC_OK");
                strAPCMgr_SendRecipeParameterRequest_out.strAPCRecipeParameterResponse = results->strAPCRecipeParameterResponseList;
            }
//D6000035 Add End
        }  //endif ( systemNameListLen > 0 )
        else
        {
            PPT_METHODTRACE_V1("", "systemname_cnt = 0");
            strAPCMgr_SendRecipeParameterRequest_out.strAPCRecipeParameterResponse.length(0);
//D7000182 add start
            PPT_METHODTRACE_V1("", "Return as OK, but not interface to APC.");
            SET_MSG_RC(strAPCMgr_SendRecipeParameterRequest_out, MSG_OK_NO_IF, RC_OK_NO_IF);
            return RC_OK_NO_IF;
//D7000182 add end
        }

        PPT_METHODTRACE_EXIT("PPTManager_i::APCMgr_SendRecipeParameterRequest");
        return ( rc ); // rc == RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strAPCMgr_SendRecipeParameterRequest_out, APCMgr_SendRecipeParameterRequest, methodName);
}
