//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_interFabXferState_Set.cpp
//

#include "pptmgr.hpp"
#include "pcas.hh"

//
// Class: PPTManager
//
// Service: cassette_interFabXferState_Set()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/10/24 DSIV00000214 K.Kido         Multi Fab Transfer Support.
//
//[Function Description]:
//
//
//[Input Parameters]:
//  in  const pptObjCommonIn&                        strObjCommonIn
//  in  const objCassette_interFabXferState_Set_in&  strCassette_interFabXferState_Set_in
//
//[Output Parameters]:
//  out objCassette_interFabXferState_Set_out&       strCassette_interFabXferState_Set_out
//
//
CORBA::Long PPTManager_i::cassette_interFabXferState_Set(
    objCassette_interFabXferState_Set_out&       strCassette_interFabXferState_Set_out,
    const pptObjCommonIn&                        strObjCommonIn,
    const objCassette_interFabXferState_Set_in&  strCassette_interFabXferState_Set_in )
{
    PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_interFabXferState_Set")

    char * methodName = NULL;
    try
    {
        CORBA::Long rc = RC_OK;

        const objectIdentifier& castID = strCassette_interFabXferState_Set_in.castID;
        const char* interFabXferState = strCassette_interFabXferState_Set_in.interFabXferState;

        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                               castID,
                                               strCassette_interFabXferState_Set_out,
                                               cassette_interFabXferState_Set );

        PPT_METHODTRACE_V3(""," #### Set InterFabXfer state. [castID:state]", castID.identifier, interFabXferState);

        try
        {
            aCassette->setInterFabTransferState( interFabXferState );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setInterFabTransferState)

        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_interFabXferState_Set");
        return rc;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_interFabXferState_Set_out, cassette_interFabXferState_Set, methodName);
}

