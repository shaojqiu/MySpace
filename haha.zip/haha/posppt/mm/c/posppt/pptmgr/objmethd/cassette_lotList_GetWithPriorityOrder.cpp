#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_lotList_GetWithPriorityOrder.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:34:50 [ 7/13/07 19:34:51 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_lotList_GetWithPriorityOrder.cpp
//

#include "pptmgr.hpp"
#include "plot.hh"
#include "pcas.hh"

//
//[Object Function Name]: long   cassette_lotList_GetWithPriorityOrder
//
// Date        Level    Author         Note
// ----------  -------- -------------  -------------------------------------------------
// 2006-09-21  D8000028 K.Kido         Initial Release(R80) for where next improvement
// 2007-04-20  D9000001 M.Murata       64bit support.
//
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/11/04 DSIV00000214 K.Kido         MultiFab Support.
//
//
//[Function Description]
// This objmethd returns lot priority order in cassette.
//
// Sorting order:
// 1. By Lot Status.
//  Always "waiting lot" is given priority over other lot status.
//
//  High                        priority                           Low
//   <-------------------------------------------------------------->
//   on floor and waiting Lot  >  on floor and hold Lot  >  bankIn Lot
//
// 2. By Qtime and lot priority setting
//  Always the shortest "Qtime remain time" is given priority over others.
//
//  High                        priority                           Low
//  <--------------------------------------------------------------->
//  Qtime remain > PriortyClass > ExternalPriority > InternalPriority
//
//[Input Parameters]:
//  in  pptObjCommonIn    strObjCommonIn;
//  in  objectIdentifier  cassetteID;
//
//[Output Parameters]:
//
//  out objCassette_lotList_GetWithPriorityOrder  strCassette_lotList_GetWithPriorityOrder;
//
//  typedef struct objCassette_lotList_GetWithPriorityOrder_out_struct {
//     pptRetCode                    strResult;
//     long                          waitingLotCount;
//     long                          holdLotCount;
//     long                          bankInLotCount;
//     pptLotStatusInfoSequence      strLotStatusInfoSeq;
//  } objCassette_lotList_GetWithPriorityOrder_out;
//
//  typedef struct pptLotStatusInfo_struct {
//     objectIdentifier lotID;
//     string           representativeState;
//     pptLotStatusAttributes currentStatus;
//     boolean          onFloorFlag;
//     boolean          onHoldFlag;
//     long             priorityClass;
//     long             externalPriority;
//     double           internalPriority;
//     any siInfo;
//  } pptLotStatusInfo ;
//
//  typedef sequence <pptLotStatusInfo> pptLotStatusInfoSequence;
//
//  typedef struct pptLotStatusAttributes_struct {
//     string           lotState;
//     string           productionState;
//     string           holdState;
//     string           finishedState;
//     string           processState;
//     string           inventoryState;
//     any siInfo;
//  } pptLotStatusAttributes ;
//
//  typedef sequence <pptLotStatusAttributes> pptLotStatusAttributesSequence;
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//
//
CORBA::Long PPTManager_i::cassette_lotList_GetWithPriorityOrder(
                            objCassette_lotList_GetWithPriorityOrder_out& strCassette_lotList_GetWithPriorityOrder_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& cassetteID)
{
    char * methodName = NULL;
    CORBA::Long rc = RC_OK;

    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_lotList_GetWithPriorityOrder");
        PPT_METHODTRACE_V2( "","in-parm's cassetteID", cassetteID.identifier);

        /*****************************/
        /*  Check input parameter    */
        /*****************************/
        if( 0 == CIMFWStrLen(cassetteID.identifier))
        {
            PPT_METHODTRACE_V1("", "CIMFWStrLen(cassetteID.identifier) == 0 ... return RC_OK");
            SET_MSG_RC( strCassette_lotList_GetWithPriorityOrder_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM );
            return RC_INVALID_INPUT_PARM;
        }

        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                               cassetteID,
                                               strCassette_lotList_GetWithPriorityOrder_out,
                                               cassette_lotList_GetWithPriorityOrder );

        /********************************/
        /*  Get all Lots in cassette    */
        /********************************/
        LotSequence_var aLotSequence;
        PosLot_var aLot;
        try
        {
            aLotSequence = aCassette->allLots();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::allLots);

        CORBA::ULong lotLen = 0 ;
        lotLen = aLotSequence->length();

        /*****************************/
        /*  Check empty cassette     */
        /*****************************/
        if ( 0 == lotLen )
        {
            PPT_METHODTRACE_V1("", "aLotSequence->length() == 0");
            PPT_SET_MSG_RC_KEY( strCassette_lotList_GetWithPriorityOrder_out, MSG_CAST_IS_EMPTY, RC_CAST_IS_EMPTY, cassetteID.identifier );
            return  RC_CAST_IS_EMPTY ;
        }

        /*****************************/
        /*   Get Lots information    */
        /*****************************/
        pptLotStatusInfoSequence lotInfoSeq;
        lotInfoSeq.length(lotLen);

        CORBA::ULong i = 0 ;
        CORBA::ULong waitingLotLen = 0, heldLotLen = 0, bankLotLen = 0;
        longSequence waitingLotNumber, heldLotNumber, bankLotNumber;
        waitingLotNumber.length(lotLen);
        heldLotNumber.length(lotLen);
        bankLotNumber.length(lotLen);

        posLotBaseInfo_var aLotBaseInfo;

        strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq.length(lotLen);
        for ( i = 0 ; i < lotLen ; i++ )
        {
            aLot = PosLot::_narrow((*aLotSequence)[i]);

            if(CORBA::is_nil(aLot))
            {
                PPT_SET_MSG_RC_KEY( strCassette_lotList_GetWithPriorityOrder_out, MSG_NOT_FOUND_LOT , RC_NOT_FOUND_LOT , "****" );
                return RC_NOT_FOUND_LOT;
            }

            /******************/
            /*   Get lot ID   */
            /******************/
            PPT_SET_OBJECT_IDENTIFIER( lotInfoSeq[i].lotID,
                                       aLot,
                                       strCassette_lotList_GetWithPriorityOrder_out,
                                       cassette_lotList_GetWithPriorityOrder,
                                       PosLot );

            /********************************/
            /*   Get lot Base information   */
            /********************************/
            try
            {
                aLotBaseInfo = aLot->getLotBaseInfo();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getState)

            lotInfoSeq[i].representativeState = aLotBaseInfo->representativeState;
            lotInfoSeq[i].productID           = aLotBaseInfo->productSpecificationID;
            lotInfoSeq[i].priorityClass       = aLotBaseInfo->priorityClass;
            lotInfoSeq[i].externalPriority    = aLotBaseInfo->externalPriority;
            lotInfoSeq[i].internalPriority    = aLotBaseInfo->internalPriority;

            /*****************************/
            /*   Get lot current state   */
            /*****************************/
            try
            {
                 lotInfoSeq[i].currentStatus.lotState = aLot->getLotState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotState)

            /********************************/
            /*   Get lot production state   */
            /********************************/
            try
            {
                lotInfoSeq[i].currentStatus.productionState = aLot->getLotProductionState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotProductionState)

            /**************************/
            /*   Get lot hold state   */
            /**************************/
            try
            {
                lotInfoSeq[i].currentStatus.holdState = aLot->getLotHoldState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotHoldState)

            /******************************/
            /*   Get lot finished state   */
            /******************************/
            try
            {
                lotInfoSeq[i].currentStatus.finishedState = aLot->getLotFinishedState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotFinishedState)

            /*****************************/
            /*   Get lot process state   */
            /*****************************/
            try
            {
                lotInfoSeq[i].currentStatus.processState = aLot->getLotProcessState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotProcessState)

            /*******************************/
            /*   Get lot inventory state   */
            /*******************************/
            try
            {
                lotInfoSeq[i].currentStatus.inventoryState = aLot->getLotInventoryState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotInventoryState)

            /************************/
            /*   Get lot isOnHold   */
            /************************/
            CORBA::Boolean HoldFlag = FALSE ;
            try
            {
                lotInfoSeq[i].onHoldFlag = aLot->isOnHold();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::isOnHold);

            /*************************/
            /*   Get lot isOnFloor   */
            /*************************/
            CORBA::Boolean OnFloorFlag = FALSE ;
            try
            {
                lotInfoSeq[i].onFloorFlag = aLot->isOnFloor();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::isOnFloor);

//DSIV00000214 add start
            /*********************************************************/
            /*   Check lot InterFabXfer Plan  existence              */
            /*********************************************************/
            //------------------------------
            //  Get Lot current operation
            //------------------------------
            objLot_currentOperationInfo_GetDR_out strLot_currentOperationInfo_GetDR_out;
            rc = lot_currentOperationInfo_GetDR( strLot_currentOperationInfo_GetDR_out,
                                                 strObjCommonIn,
                                                 lotInfoSeq[i].lotID );

            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V2(""," #### lot_currentOperationInfo_GetDR != RC_OK : rc = ", rc );
                strCassette_lotList_GetWithPriorityOrder_out.strResult = strLot_currentOperationInfo_GetDR_out.strResult;
                return rc;
            }

            //--------------------------------------
            //  Get original FabID
            //--------------------------------------
            const char* orgFabID = getenv(SP_FAB_ID);

            //--------------------------------------
            //  Check lot InterFab transfer plan
            //--------------------------------------
            objInterFab_xferPlanList_GetDR_out strInterFab_xferPlanList_GetDR_out;

            objInterFab_xferPlanList_GetDR_in  strInterFab_xferPlanList_GetDR_in;
            strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.lotID = lotInfoSeq[i].lotID;
            strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalFabID = CIMFWStrDup(orgFabID);
            strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalRouteID = strLot_currentOperationInfo_GetDR_out.mainPDID;
            strInterFab_xferPlanList_GetDR_in.strInterFabLotXferPlanInfo.originalOpeNumber = strLot_currentOperationInfo_GetDR_out.opeNo;

            rc = interFab_xferPlanList_GetDR( strInterFab_xferPlanList_GetDR_out, strObjCommonIn,
                                              strInterFab_xferPlanList_GetDR_in );

            if( rc != RC_OK && rc != RC_INTERFAB_NOT_FOUND_XFERPLAN )
            {
                PPT_METHODTRACE_V2(""," #### interFab_xferPlanList_GetDR != RC_OK : rc = ", rc );
                strCassette_lotList_GetWithPriorityOrder_out.strResult = strInterFab_xferPlanList_GetDR_out.strResult;
                return rc;
            }

            if(0 != strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq.length() )
            {
                if(  0 == CIMFWStrCmp(strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq[0].state, SP_InterFab_XferPlanState_Created)
                  || 0 == CIMFWStrCmp(strInterFab_xferPlanList_GetDR_out.strInterFabLotXferPlanInfoSeq[0].state, SP_InterFab_XferPlanState_Canceled) )
                {
                    PPT_METHODTRACE_V1("","#### InterFab Plan found at current operation. Operate as HoldLot. (Destination should be current stocker)");
                    lotInfoSeq[i].onFloorFlag = TRUE ;
                    lotInfoSeq[i].onHoldFlag = TRUE ;
                }
            }
//DSIV00000214 add end

            /*********************************************************/
            /*   Check lot state and set element number for sorting  */
            /*********************************************************/
            PPT_METHODTRACE_V2("", "### lot ID = ", lotInfoSeq[i].lotID.identifier);
            if ( lotInfoSeq[i].onFloorFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "OnFloorFlag == TRUE");
                /******************************************/
                /*   When lot is not Held and not InBank  */
                /******************************************/
                if( lotInfoSeq[i].onHoldFlag == FALSE )
                {
                    PPT_METHODTRACE_V1("", "HoldFlag == FALSE");
                    waitingLotNumber[waitingLotLen] = i ;
                    waitingLotLen++;
                }
                /****************************/
                /*   When lot is held      */
                /****************************/
                else
                {
                    PPT_METHODTRACE_V1("", "HoldFlag == TRUE");
                    heldLotNumber[heldLotLen] = i ;
                    heldLotLen++;
                }
            }
            /****************************/
            /*   When lot is InBank     */
            /****************************/
            else
            {
                PPT_METHODTRACE_V1("", "OnFloorFlag == FALSE");
                bankLotNumber[bankLotLen] = i ;
                bankLotLen++;
            }
        }

        /**********************************************/
        /*  Set each lot count to return value        */
        /**********************************************/
        strCassette_lotList_GetWithPriorityOrder_out.waitingLotCount = waitingLotLen;
        strCassette_lotList_GetWithPriorityOrder_out.holdLotCount    = heldLotLen;
        strCassette_lotList_GetWithPriorityOrder_out.bankInLotCount  = bankLotLen;

        /**********************************************/
        /*  Check Lot in cassette count               */
        /*  If lot count is 1, then no need to sort.  */
        /**********************************************/
        if ( 1 == lotLen )
        {
            /************************/
            /*   Return to Caller   */
            /************************/
            PPT_METHODTRACE_V1("", "aLotSequence->length() == 1  ### No need to sort. return.");
            strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq.length(1) ;
            strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq = lotInfoSeq ;
            PPT_METHODTRACE_EXIT("PPTManager_i::cassette_lotList_GetWithPriorityOrder");
            return RC_OK;
        }

        /***********************************/
        /*  Plural Lots exist in cassette  */
        /*  Sort is required.              */
        /***********************************/
        PPT_METHODTRACE_V1("", "aLotSequence->length() > 1  ### Need to sort. ");

        pptLotStatusInfoSequence retLotInfoSeq;
        retLotInfoSeq.length(lotLen);

        waitingLotNumber.length(waitingLotLen);
        heldLotNumber.length(heldLotLen);
        bankLotNumber.length(bankLotLen);

        CORBA::ULong upCount = 0 ;
        enum element{ waiting, hold, bankIn, totalElement } el;

        for( CORBA::ULong categoryCnt = 0 ; categoryCnt < totalElement ; categoryCnt++ )
        {
            CORBA::ULong currentLotLen = 0 ;
            longSequence currentLotNumber ;

            if( waiting == categoryCnt )
            {
                /***********************************/
                /*                                 */
                /*   Firstly, sort waiting Lots    */
                /*                                 */
                /***********************************/
                currentLotLen = waitingLotLen ;
                currentLotNumber = waitingLotNumber ;
            }
            else if ( hold == categoryCnt )
            {
                /***********************************/
                /*                                 */
                /*   Secondly, sort hold Lots      */
                /*                                 */
                /***********************************/
                currentLotLen = heldLotLen ;
                currentLotNumber = heldLotNumber ;
            }
            else if ( bankIn == categoryCnt )
            {
                /***********************************/
                /*                                 */
                /*   Finaly, sort bank Lots        */
                /*                                 */
                /***********************************/
                currentLotLen = bankLotLen ;
                currentLotNumber = bankLotNumber ;
            }

            if( 1 < currentLotLen )
            {
                PPT_METHODTRACE_V1("", "##### Sort by Lot priority order.");

                /*******************************************************/
                /*               Sort by Lot priority                  */
                /*  Sorting fields;                                    */
                /*  1st field :  PriortyClass                          */
                /*  2nd field :  ExternalPriority                      */
                /*  3rd field :  InternalPriority                      */
                /*******************************************************/
                longSequence tmpLotNumber;
                tmpLotNumber.length(currentLotLen);
                CORBA::ULong tmpUpCount = 0 ;

                for ( i = 0 ; i < currentLotLen ; i++ )   //Base loop
                {
//D9000001                    long highLotNumber = 0;
                    CORBA::Long highLotNumber = 0;//D9000001
                    CORBA::Boolean firstFlag = TRUE;
                    for( CORBA::ULong j = 0 ; j < currentLotLen ; j++ )   //Comparison loop
                    {
                        CORBA::Long lotNum = currentLotNumber[j];

                        /*********************************/
                        /*   Omit already checked Lot    */
                        /*********************************/
                        PPT_METHODTRACE_V2("", "### LotID = ", lotInfoSeq[lotNum].lotID.identifier);
                        CORBA::Boolean alreadyCheckedFlag = FALSE ;
                        for( CORBA::ULong assignedCnt = 0 ; assignedCnt < tmpUpCount ; assignedCnt++ )
                        {
                            if( lotNum == tmpLotNumber[assignedCnt])
                            {
                                alreadyCheckedFlag = TRUE;
                                break;
                            }
                        }
                        if(alreadyCheckedFlag)
                        {
                            PPT_METHODTRACE_V1("", "### Omit already checked Lot ");
                            continue;
                        }

                        if ( TRUE == firstFlag )
                        {
                            PPT_METHODTRACE_V1("", "### First. Set highLotNumber.");
                            highLotNumber = lotNum ;
                            firstFlag = FALSE;
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("", "### Compare lot priority.");

                            CORBA::Long nowPriorty = 0 ;
                            CORBA::Long highPriorty = 0 ;

                            nowPriorty  = lotInfoSeq[lotNum].priorityClass;
                            highPriorty = lotInfoSeq[highLotNumber].priorityClass;
                            PPT_METHODTRACE_V2("", "### nowPriority   = ", nowPriorty );
                            PPT_METHODTRACE_V2("", "### highPriority  = ", highPriorty );

                            if (highPriorty > nowPriorty)
                            {
                                highLotNumber = lotNum;
                            }
                            else if (highPriorty == nowPriorty)
                            {
                                nowPriorty  = lotInfoSeq[lotNum].externalPriority;
                                highPriorty = lotInfoSeq[highLotNumber].externalPriority;

                                if (highPriorty > nowPriorty)
                                {
                                    highLotNumber = lotNum;
                                }
                                else if (highPriorty == nowPriorty)
                                {
                                    CORBA::Double nowPriorty  = lotInfoSeq[lotNum].internalPriority;
                                    CORBA::Double highPriorty = lotInfoSeq[highLotNumber].internalPriority;

                                    if (highPriorty > nowPriorty)
                                    {
                                        highLotNumber = lotNum;
                                    }
                                }
                            }
                        }
                    }  //Comparison loop

                    tmpLotNumber[tmpUpCount] = highLotNumber ;
                    tmpUpCount++;
                    PPT_METHODTRACE_V3("", "### Lot priority ID/count ", lotInfoSeq[highLotNumber].lotID.identifier, i);
                }

                if ( bankIn == categoryCnt )
                {
                    PPT_METHODTRACE_V1("", "### If category is bankin, set structure.");
                    for( CORBA::ULong i = 0 ; i < tmpUpCount ; i++ )
                    {
                        CORBA::ULong num = tmpLotNumber[i];
                        retLotInfoSeq[upCount] = lotInfoSeq[num] ;
                        upCount++;
                    }

                    continue;
                }

                currentLotNumber = tmpLotNumber;
                /*******************************/
                /*                             */
                /*  Prepare Qtime structure.   */
                /*                             */
                /*******************************/
                longSequence lotQtimeRemaintimeSeq;
                lotQtimeRemaintimeSeq.length(lotLen);
                for ( CORBA::ULong i = 0 ; i < lotLen ; i++ )
                {
                    if( (waiting == categoryCnt && TRUE == lotInfoSeq[i].onFloorFlag && FALSE == lotInfoSeq[i].onHoldFlag) ||
                        (hold    == categoryCnt && TRUE == lotInfoSeq[i].onFloorFlag && TRUE  == lotInfoSeq[i].onHoldFlag) )
                    {
                        PosQTimeInfoSequence_var aQTimeInfoSeq;
                        PosLot_var aLot = PosLot::_narrow(aLotSequence[i]);
                        try
                        {
                            aQTimeInfoSeq = aLot->getQTimeInfo();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getQTimeInfo);

                        lotQtimeRemaintimeSeq[i] = (long)LONG_MAX; //define "LONG_MAX" is in /usr/include/sys/limits.h

                        CORBA::ULong QtimeLen = aQTimeInfoSeq->length();
                        CORBA::ULong nowRemainTime = 0 ;
                        CORBA::Boolean firstOneFlag = TRUE;
                        for( CORBA::ULong Qcnt = 0 ; Qcnt < QtimeLen ; Qcnt++ )
                        {
                            if( 0 == CIMFWStrCmp( (*aQTimeInfoSeq)[Qcnt].qrestrictionTargetTimeStamp, SP_TIMESTAMP_NIL_OBJECT_STRING) )
                            {
                                PPT_METHODTRACE_V1("","#### qrestrictionTargetTimeStamp == SP_TIMESTAMP_NIL_OBJECT_STRING. continue; ");
                                continue;
                            }

                            nowRemainTime = atoi( (*aQTimeInfoSeq)[Qcnt].qrestrictionRemainTime );
                            PPT_METHODTRACE_V2("", "### nowRemainTime = ", nowRemainTime );
                            if ( TRUE == firstOneFlag )
                            {
                                lotQtimeRemaintimeSeq[i] = nowRemainTime ;
                                firstOneFlag = FALSE;
                            }
                            else
                            {
                                if ( lotQtimeRemaintimeSeq[i] > nowRemainTime )
                                {
                                    lotQtimeRemaintimeSeq[i] = nowRemainTime;
                                }
                            }
                        }
                    }

                    PPT_METHODTRACE_V2("", "###### LotID              = ", lotInfoSeq[i].lotID.identifier );
                    PPT_METHODTRACE_V2("", "### Shortest Qtime remain = ", lotQtimeRemaintimeSeq[i] );
                }

                /*******************************/
                /*                             */
                /*   Check Qtime remain time   */
                /*                             */
                /*******************************/
                for ( i = 0 ; i < currentLotLen ; i++ )   //Base loop
                {
//D9000001                    long highLotNumber = 0;
                    CORBA::Long highLotNumber = 0;//D9000001
                    CORBA::Boolean firstFlag = TRUE;
                    CORBA::ULong highRemainTime = 0 ;
                    for( CORBA::ULong j = 0 ; j < currentLotLen ; j++ )   //Qtime Comparison loop
                    {
                        CORBA::Long lotNum = currentLotNumber[j];
                        PPT_METHODTRACE_V4("", "### LotID, i, j", lotInfoSeq[lotNum].lotID.identifier, i, j);

                        /********************************/
                        /*   Omit already checked Lot   */
                        /********************************/
                        CORBA::Boolean alreadyCheckedFlag = FALSE ;
                        for( CORBA::ULong assignedCnt = 0 ; assignedCnt < upCount ; assignedCnt++ )
                        {
                            if( 0 == CIMFWStrCmp( lotInfoSeq[lotNum].lotID.identifier, retLotInfoSeq[assignedCnt].lotID.identifier ) )
                            {
                                alreadyCheckedFlag = TRUE;
                                break;
                            }
                        }
                        if(alreadyCheckedFlag)
                        {
                            PPT_METHODTRACE_V1("", "### Omit already checked Lot");
                            continue;
                        }

                        /*******************************/
                        /*   Check Qtime remainTime    */
                        /*******************************/
                        if( TRUE == firstFlag )
                        {
                            PPT_METHODTRACE_V1("", "### Set highLotNumber. ");
                            highRemainTime = lotQtimeRemaintimeSeq[lotNum];
                            highLotNumber = lotNum;
                            firstFlag = FALSE;
                        }
                        else
                        {
                            if( highRemainTime > lotQtimeRemaintimeSeq[lotNum] )
                            {
                                highRemainTime = lotQtimeRemaintimeSeq[lotNum];
                                highLotNumber = lotNum;
                            }
                        }
                    }  //QTime Comparison loop

                    retLotInfoSeq[upCount] = lotInfoSeq[highLotNumber] ;
                    upCount++;
                }  //Base loop
            }
            else if ( 1 == currentLotLen )
            {
                CORBA::Long lotNum = currentLotNumber[0];
                retLotInfoSeq[upCount] = lotInfoSeq[lotNum];
                upCount++;
            }
            else
            {
                ; //Do nothing...
            }
        }

        //Debug trace
        {
            PPT_METHODTRACE_V1("", "##### Lot priority order. ") ;
            CORBA::ULong retLen = retLotInfoSeq.length();
            for( CORBA::Long i = 0 ; i < retLen ; i++ )
            {
                PPT_METHODTRACE_V2("", "########## count    = ", i );
                PPT_METHODTRACE_V2("", "### LotID           = ", retLotInfoSeq[i].lotID.identifier );
                PPT_METHODTRACE_V2("", "### onFloorFlag     = ", retLotInfoSeq[i].onFloorFlag );
                PPT_METHODTRACE_V2("", "### onHoldFlag      = ", retLotInfoSeq[i].onHoldFlag );
                PPT_METHODTRACE_V2("", "### LotState        = ", retLotInfoSeq[i].currentStatus.lotState        );
                PPT_METHODTRACE_V2("", "### ProductionState = ", retLotInfoSeq[i].currentStatus.productionState );
                PPT_METHODTRACE_V2("", "### HoldState       = ", retLotInfoSeq[i].currentStatus.holdState       );
                PPT_METHODTRACE_V2("", "### FinishedState   = ", retLotInfoSeq[i].currentStatus.finishedState   );
                PPT_METHODTRACE_V2("", "### ProcessState    = ", retLotInfoSeq[i].currentStatus.processState    );
                PPT_METHODTRACE_V2("", "### InventoryState  = ", retLotInfoSeq[i].currentStatus.inventoryState  );
            }
        }

        /****************************/
        /*   Set return structure   */
        /****************************/
        if(lotLen != upCount)
        {
            PPT_METHODTRACE_V1("", "lotLen != upCount");
            SET_MSG_RC( strCassette_lotList_GetWithPriorityOrder_out, MSG_INVALID_DATA_CONTENTS, RC_INVALID_DATA_CONTENTS );
            return RC_INVALID_DATA_CONTENTS;
        }
        else
        {
            strCassette_lotList_GetWithPriorityOrder_out.strLotStatusInfoSeq = retLotInfoSeq ;
        }

        /************************/
        /*   Return to Caller   */
        /************************/
        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_lotList_GetWithPriorityOrder");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_lotList_GetWithPriorityOrder_out, cassette_lotList_GetWithPriorityOrder, methodName)
}
