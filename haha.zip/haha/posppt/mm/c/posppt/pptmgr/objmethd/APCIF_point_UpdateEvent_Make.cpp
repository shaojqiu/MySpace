#ifndef lint
static char *APCIF_point_UpdateEvent_Make_sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/APCIF_point_UpdateEvent_Make.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:16:44 [ 7/13/07 19:16:46 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: APCIF_point_UpdateEvent_Make.cpp
//

#include "pptmgr.hpp"

#include "pevbase.hh"

//
//
//[Object Function Name]: long   APCIF_point_UpdateEvent_Make
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2004/07/12  D51M0000  M.Murata       APC Initial Release (R51M)
//
//[Function Description]:
//
//[Input Parameters]:
//    const pptObjCommonIn&       strObjCommonIn
//    const char *                transactionID
//    const pptAPCIF&             strAPCIF
//    const char *                opeCategory
//
//[Output Parameters]:
//
//    objAPCIF_point_UpdateEvent_Make_out&      strAPCIF_point_UpdateEvent_Make_out
//
//    typedef struct objAPCIF_point_UpdateEvent_Make_out_struct
//    {
//        pptRetCode   strResult;
//        any          siInfo;
//    } objAPCIF_point_UpdateEvent_Make_out;
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------
//  RC_OK                                 MSG_OK
//

CORBA::Long PPTManager_i::APCIF_point_UpdateEvent_Make(
            objAPCIF_point_UpdateEvent_Make_out&   strAPCIF_point_UpdateEvent_Make_out,
            const pptObjCommonIn&                  strObjCommonIn,
            const char *                           transactionID,
            const pptAPCIF&                        strAPCIF,
            const char *                           opeCategory)
{
    char * methodName = NULL;

    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::APCIF_point_UpdateEvent_Make");

        posAPCInterfaceEventRecord  anAPCIFEventRecord;

        //--------------------------
        // Initialize               
        //--------------------------
        CORBA::Long rc    = RC_OK;
        
        anAPCIFEventRecord.equipmentID                = strAPCIF.equipmentID.identifier;
        anAPCIFEventRecord.APC_systemName             = strAPCIF.APCSystemName;
        anAPCIFEventRecord.operationCategory          = opeCategory;
        anAPCIFEventRecord.equipmentDescription       = strAPCIF.eqpDescription;
        anAPCIFEventRecord.ignoreAbleFlag             = strAPCIF.APCIgnoreable;
        anAPCIFEventRecord.APC_responsibleUserID      = strAPCIF.APCRep1UserID.identifier;
        anAPCIFEventRecord.APC_subResponsibleUserID   = strAPCIF.APCRep2UserID.identifier;
        anAPCIFEventRecord.APC_configState            = strAPCIF.APCConfigStatus;
        anAPCIFEventRecord.APC_registeredUserID       = strAPCIF.registeredUserID.identifier;
        anAPCIFEventRecord.registeredTime             = strAPCIF.registeredTimeStamp;
        anAPCIFEventRecord.registeredMemo             = strAPCIF.registeredMemo;
        anAPCIFEventRecord.approvedUserID             = strAPCIF.approvedUserID.identifier;
        anAPCIFEventRecord.approvedTime               = strAPCIF.approvedTimeStamp;
        anAPCIFEventRecord.approvedMemo               = strAPCIF.approvedMemo;

        anAPCIFEventRecord.eventCommon.transactionID  = transactionID;
        anAPCIFEventRecord.eventCommon.eventTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
        anAPCIFEventRecord.eventCommon.eventShopDate  = strObjCommonIn.strTimeStamp.reportShopdate;
        anAPCIFEventRecord.eventCommon.userID         = strObjCommonIn.strUser.userID.identifier;

        /*--------------------*/
        /*   Put Event Data   */
        /*--------------------*/
        PosEventBase_var anEvent;
        CORBA::Any eventRecord;
        eventRecord <<= anAPCIFEventRecord;

        try
        {
            anEvent =  theEventManager->createEvent( eventRecord );
        }
        catch( PosEventManager::InvalidEventRecordTypeSignal )
        {
            SET_FW_MSG_RC_NO_KEY(strAPCIF_point_UpdateEvent_Make_out,
                                 APCIF_point_UpdateEvent_Make,
                                 MSG_INVALID_EVENTRECORD_TYPE,
                                 RC_INVALID_EVENTRECORD_TYPE,
                                 PosEventManager::createEvent,
                                 InvalidEventRecordTypeSignal)
            return  RC_INVALID_EVENTRECORD_TYPE ;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosEventManager::createEvent)

        //---------------------
        //  Return to Caller   
        //---------------------
        return ( rc );
    }
    CATCH_GLOBAL_EXCEPTIONS(strAPCIF_point_UpdateEvent_Make_out, APCIF_point_UpdateEvent_Make, methodName);

}