//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: bondingMap_infoConsistency_CheckForPartialRelease.dr
//

#include "pptmgr.hpp"

// Class: PPTManager
//
// Service: bondingMap_infoConsistency_CheckForPartialRelease()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2010-04-23 DSIV00001830 R.Iriguchi     Wafer Stacking Operation Support.
// 2017-05-10 PSN000105006 S.Kawabe       In Multi Lot, Release from Bonding Group was failed.
//
// Description:
//    This function inquires information of specified bonding group.
// Return:
//    long
//
// Parameter:
//  [Input Parameters]:
//    const pptObjCommonIn&                       strObjCommonIn
//    const objBondingMap_infoConsistency_CheckForPartialRelease_in&        strBondingMap_infoConsistency_CheckForPartialRelease_in
//
//  [Output Parameters]:
//    objBondingMap_infoConsistency_CheckForPartialRelease_out&             strBondingMap_infoConsistency_CheckForPartialRelease_out
//
//  [Return Value]:
//    Return Code                      Message ID
//    -------------------------------- -------------------------------------------
//    RC_OK                            MSG_OK
//    RC_LOCKED_BY_ANOTHER             MSG_LOCKED_BY_ANOTHER
//    RC_SYSTEM_ERROR                  MSG_SYSTEM_ERROR
//    RC_NOT_FOUND_BONDGRP             MSG_NOT_FOUND_BONDGRP
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long PPTManager_i::bondingMap_infoConsistency_CheckForPartialRelease(
    objBondingMap_infoConsistency_CheckForPartialRelease_out&           strBondingMap_infoConsistency_CheckForPartialRelease_out,
    const pptObjCommonIn&                                               strObjCommonIn,
    const objBondingMap_infoConsistency_CheckForPartialRelease_in&      strBondingMap_infoConsistency_CheckForPartialRelease_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY( "PPTManager_i::bondingMap_infoConsistency_CheckForPartialRelease" );

        const pptBondingMapInfoSequence& strBondingMapInfoSeq = strBondingMap_infoConsistency_CheckForPartialRelease_in.strBondingMapInfoSeq;
        const CORBA::Long mapLen = strBondingMapInfoSeq.length();
        const pptBondingGroupReleaseLotWaferSequence& strBondingGroupReleaseLotWaferSeq =
                strBondingMap_infoConsistency_CheckForPartialRelease_in.strBondingGroupReleaseLotWaferSeq;
        const CORBA::Long lotLen = strBondingGroupReleaseLotWaferSeq.length();

        pptBondingMapInfoSequence& dstBondingMapInfoSeq = strBondingMap_infoConsistency_CheckForPartialRelease_out.strPartialReleaseDestinationMapSeq;
        pptBondingMapInfoSequence& srcBondingMapInfoSeq = strBondingMap_infoConsistency_CheckForPartialRelease_out.strPartialReleaseSourceMapSeq;

        CORBA::Long dstCnt = 0;
        dstBondingMapInfoSeq.length( mapLen );
        CORBA::Long srcCnt = 0;
        srcBondingMapInfoSeq.length( mapLen );

        longSequence numBaseWaferInBondingMapSeq, numTopWaferInBondingMapSeq;
        CORBA::Long numNotReportedWafer = 0;
        numBaseWaferInBondingMapSeq.length( lotLen );
        numTopWaferInBondingMapSeq.length( lotLen );
        CORBA::Long cnt = 0;
        strBondingMap_infoConsistency_CheckForPartialRelease_out.strBondingGroupReleaseLotWaferSeq.length( lotLen );
        for ( CORBA::Long lotCnt = 0; lotCnt < lotLen; lotCnt++ )
        {
            PPT_METHODTRACE_V2( "", "lotCnt", lotCnt );

            numBaseWaferInBondingMapSeq[lotCnt] = 0;
            numTopWaferInBondingMapSeq[lotCnt] = 0;

            for ( CORBA::Long mapCnt = 0; mapCnt < mapLen; mapCnt++ )
            {
                //--------------------------------------------------------------
                //   Count Base Wafer.
                //--------------------------------------------------------------
                if ( CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].baseLotID.identifier,
                                  strBondingGroupReleaseLotWaferSeq[lotCnt].parentLotID.identifier ) == 0 )
                {
                    PPT_METHODTRACE_V2( "", "Lot Found as Base.", lotCnt );

                    numBaseWaferInBondingMapSeq[lotCnt]++;
                }
                //--------------------------------------------------------------
                //   Count Top Wafer.
                //--------------------------------------------------------------
                if ( CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].planTopLotID.identifier,
                                  strBondingGroupReleaseLotWaferSeq[lotCnt].parentLotID.identifier ) == 0 )
                {
                    PPT_METHODTRACE_V2( "", "Lot Found as Top.", lotCnt );

                    numTopWaferInBondingMapSeq[lotCnt]++;
                }
            }

            const CORBA::Long wfrLen = strBondingGroupReleaseLotWaferSeq[lotCnt].childWaferIDSeq.length();
            if ( numBaseWaferInBondingMapSeq[lotCnt] > 0 )
            {
                PPT_METHODTRACE_V2( "", "Lot is Base.", strBondingGroupReleaseLotWaferSeq[lotCnt].parentLotID.identifier );

                if ( numBaseWaferInBondingMapSeq[lotCnt] > wfrLen )
                {
                    strBondingMap_infoConsistency_CheckForPartialRelease_out.strBondingGroupReleaseLotWaferSeq[cnt++] = strBondingGroupReleaseLotWaferSeq[lotCnt];
                }
            }
            else if ( numTopWaferInBondingMapSeq[lotCnt] > 0 )
            {
                PPT_METHODTRACE_V2( "", "Lot is Top.", strBondingGroupReleaseLotWaferSeq[lotCnt].parentLotID.identifier );

                if ( numTopWaferInBondingMapSeq[lotCnt] > wfrLen )
                {
                    strBondingMap_infoConsistency_CheckForPartialRelease_out.strBondingGroupReleaseLotWaferSeq[cnt++] = strBondingGroupReleaseLotWaferSeq[lotCnt];
                }

                for ( CORBA::Long wfrCnt = 0; wfrCnt < wfrLen; wfrCnt++ )
                {
                    PPT_METHODTRACE_V2( "", "wfrCnt", wfrCnt );
                    CORBA::Boolean topWaferFound = FALSE;

                    for ( CORBA::Long mapCnt = 0; mapCnt < mapLen; mapCnt++ )
                    {
                        if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier ) == 0 )
                        {
                            continue;
                        }
                        if ( CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier,
                                          strBondingGroupReleaseLotWaferSeq[lotCnt].childWaferIDSeq[wfrCnt].identifier ) == 0 )
                        {
                            PPT_METHODTRACE_V2( "", "Top Wafer Found", wfrCnt );
                            topWaferFound = TRUE;
                            break;
                        }
                    }
                    if ( !topWaferFound )
                    {
                        PPT_METHODTRACE_V2( "", "Top Wafer Not Found", wfrCnt );

                        numNotReportedWafer++;
                    }
                }
            }
            else
            {
                PPT_METHODTRACE_V2( "", "Specified Lot Wafer is not Found in Bonding Map.",
                                    strBondingGroupReleaseLotWaferSeq[lotCnt].parentLotID.identifier );
                PPT_SET_MSG_RC_KEY2( strBondingMap_infoConsistency_CheckForPartialRelease_out,
                                     MSG_NOT_FOUND_BONDING_MAP, RC_NOT_FOUND_BONDING_MAP,
                                     strBondingGroupReleaseLotWaferSeq[lotCnt].parentLotID.identifier,
                                     strBondingGroupReleaseLotWaferSeq[lotCnt].childWaferIDSeq[0].identifier );
                return RC_NOT_FOUND_BONDING_MAP;
            }
        }
        strBondingMap_infoConsistency_CheckForPartialRelease_out.strBondingGroupReleaseLotWaferSeq.length( cnt );

        for ( CORBA::Long mapCnt = 0; mapCnt < mapLen; mapCnt++ )
        {
            PPT_METHODTRACE_V2( "", "Check Base Wafer", strBondingMapInfoSeq[mapCnt].baseWaferID.identifier );

            //--------------------------------------------------------------
            //   Check if Base Wafer is Released.
            //--------------------------------------------------------------
            CORBA::Boolean baseWaferFound = FALSE;
            for ( CORBA::Long lotCnt = 0; lotCnt < lotLen; lotCnt++ )
            {
                if ( numBaseWaferInBondingMapSeq[lotCnt] == 0 )
                {
                    continue;
                }

                PPT_METHODTRACE_V2( "", "Lot Found as Base.", lotCnt );

                const CORBA::Long wfrLen = strBondingGroupReleaseLotWaferSeq[lotCnt].childWaferIDSeq.length();
                for ( CORBA::Long wfrCnt = 0; wfrCnt < wfrLen; wfrCnt++ )
                {
                    if ( CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].baseWaferID.identifier,
                                      strBondingGroupReleaseLotWaferSeq[lotCnt].childWaferIDSeq[wfrCnt].identifier ) == 0 )
                    {
                        PPT_METHODTRACE_V2( "", "Base WaferFound", wfrCnt );
                        baseWaferFound = TRUE;
                        break;
                    }
                }
//PSN000105006                break;
//PSN000105006 add start
                if( baseWaferFound )
                {
                    break;
                }
//PSN000105006 add end
            }

            //--------------------------------------------------------------
            //   Check if Top Wafer is Released.
            //--------------------------------------------------------------
            CORBA::Boolean topWaferFound = FALSE;
            if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier ) == 0 )
            {
                PPT_METHODTRACE_V1( "", "Top Wafer is blank." );

                topWaferFound = numNotReportedWafer > 0;
                numNotReportedWafer--;
            }
            else
            {
                PPT_METHODTRACE_V2( "", "Check Top Wafer", strBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier );

                for ( lotCnt = 0; lotCnt < lotLen; lotCnt++ )
                {
                    if ( numTopWaferInBondingMapSeq[lotCnt] == 0 )
                    {
                        continue;
                    }

                    PPT_METHODTRACE_V2( "", "Lot Found as Top.", lotCnt );

                    CORBA::Long wfrLen = strBondingGroupReleaseLotWaferSeq[lotCnt].childWaferIDSeq.length();
                    for ( CORBA::Long wfrCnt = 0; wfrCnt < wfrLen; wfrCnt++ )
                    {
                        if ( CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier,
                                          strBondingGroupReleaseLotWaferSeq[lotCnt].childWaferIDSeq[wfrCnt].identifier ) == 0 )
                        {
                            PPT_METHODTRACE_V2( "", "Top WaferFound", wfrCnt );
                            topWaferFound = TRUE;
                            break;
                        }
                    }
//PSN000105006                    break;
//PSN000105006 add start
                    if( topWaferFound )
                    {
                        break;
                    }
//PSN000105006 add end

                }
            }

            if ( !baseWaferFound && !topWaferFound )
            {
                PPT_METHODTRACE_V2( "", "This Map is not released.", mapCnt );

                srcBondingMapInfoSeq[srcCnt++] = strBondingMapInfoSeq[mapCnt];
                continue;
            }

            if ( !baseWaferFound && topWaferFound )
            {
                PPT_METHODTRACE_V2( "", "Base Wafer is NOT released but Top Wafer is released.", mapCnt );

                PPT_SET_MSG_RC_KEY2( strBondingMap_infoConsistency_CheckForPartialRelease_out,
                                     MSG_BONDGRP_WAFER_MISSED_FOR_RELEASE, RC_BONDGRP_WAFER_MISSED_FOR_RELEASE,
                                     strBondingMapInfoSeq[mapCnt].baseWaferID.identifier,
                                     strBondingMapInfoSeq[mapCnt].baseLotID.identifier );
                return RC_BONDGRP_WAFER_MISSED_FOR_RELEASE;
            }

            if ( baseWaferFound && !topWaferFound )
            {
                PPT_METHODTRACE_V2( "", "Base Wafer is released but Top Wafer is NOT released.", mapCnt );

                PPT_SET_MSG_RC_KEY2( strBondingMap_infoConsistency_CheckForPartialRelease_out,
                                     MSG_BONDGRP_WAFER_MISSED_FOR_RELEASE, RC_BONDGRP_WAFER_MISSED_FOR_RELEASE,
                                     strBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier,
                                     strBondingMapInfoSeq[mapCnt].actualTopLotID.identifier );
                return RC_BONDGRP_WAFER_MISSED_FOR_RELEASE;
            }

            //--------------------------------------------------------------
            //   Check Bonding Process State.
            //--------------------------------------------------------------
            if ( CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].bondingProcessState, SP_BondingProcessState_Completed ) == 0 )
            {
                PPT_METHODTRACE_V2( "", "Bonding Process State is SP_BondingProcessState_Completed.",
                                    strBondingMapInfoSeq[mapCnt].baseWaferID.identifier );
                PPT_SET_MSG_RC_KEY2( strBondingMap_infoConsistency_CheckForPartialRelease_out,
                                     MSG_BONDMAP_STATE_INVALID, RC_BONDMAP_STATE_INVALID,
                                     strBondingMapInfoSeq[mapCnt].bondingProcessState,
                                     strBondingMapInfoSeq[mapCnt].baseWaferID.identifier );
                return RC_BONDMAP_STATE_INVALID;
            }

            dstBondingMapInfoSeq[dstCnt++] = strBondingMapInfoSeq[mapCnt];
        }   // for ( mapCnt = 0; mapCnt < mapLen; mapCnt++ )
        dstBondingMapInfoSeq.length( dstCnt );
        srcBondingMapInfoSeq.length( srcCnt );

        //--------------------
        //   Return to Caller
        //--------------------
        PPT_METHODTRACE_EXIT( "PPTManager_i::bondingMap_infoConsistency_CheckForPartialRelease" );
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS( strBondingMap_infoConsistency_CheckForPartialRelease_out, bondingMap_infoConsistency_CheckForPartialRelease, methodName )
}
