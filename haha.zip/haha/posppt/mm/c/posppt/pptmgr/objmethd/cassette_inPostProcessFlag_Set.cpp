#ifndef lint
static char *sccsid =  "@(#) 1.8 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_inPostProcessFlag_Set.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 11/14/07 15:45:39 [ 11/14/07 15:45:40 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_inPostProcessFlag_Set.cpp
//

#include "pptmgr.hpp"

#include "plot.hh"
#include "pcas.hh"
#include "mtrlcntn.hh"

//[Object Function Name]: long   cassette_inPostProcessFlag_Set
//
// Date        Level        Author         Note
// ----------  ------------ -------------  -------------------------------------------
// 2008/1l/08  DSIV00000214 K.Kido         Initial release for MultiFab Support.
//
//[Function Description]:
//  This function sets InPostProcessFlag of Lot/Cassette by the specified lot.
//
//[Input Parameters]:
//  in  pptObjCommonIn                    strObjCommonIn;
//  in  objcassette_inPostProcessFlag_Set_in   strCassette_inPostProcessFlag_Set_in;
//
//  typedef struct objCassette_inPostProcessFlag_Set_in_struct {
//     objectIdentifier  lotID;
//     boolean           inPostProcessFlag;
//     any               siInfo;
//  } objcassette_inPostProcessFlag_Set_in;
//
//[Output Parameters]:
//
//  out objcassette_inPostProcessFlag_Set_out  strCassette_inPostProcessFlag_Set_out;
//
//  typedef objBase_out objCassette_inPostProcessFlag_Set_out_struct;
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//  RC_INVALID_INPUT_PARM     MSG_INVALID_INPUT_PARM
//  RC_NOT_FOUND_CASSETTE     MSG_NOT_FOUND_CASSETTE
//

CORBA::Long PPTManager_i:: cassette_inPostProcessFlag_Set (
    objCassette_inPostProcessFlag_Set_out&       strCassette_inPostProcessFlag_Set_out,
    const pptObjCommonIn&                        strObjCommonIn,
    const objCassette_inPostProcessFlag_Set_in&  strCassette_inPostProcessFlag_Set_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_inPostProcessFlag_Set");
        PPT_METHODTRACE_V2("", "in-para castID            ", strCassette_inPostProcessFlag_Set_in.cassetteID.identifier);
        PPT_METHODTRACE_V2("", "in-para inPostProcessFlag ", strCassette_inPostProcessFlag_Set_in.inPostProcessFlag);
        PPT_METHODTRACE_V2("", "in-para lotID             ", strCassette_inPostProcessFlag_Set_in.lotID.identifier);

        //----------------
        //  Initialize
        //----------------


        //---------------------------
        //  Check input parameter
        //---------------------------
        if( 0 == CIMFWStrLen( strCassette_inPostProcessFlag_Set_in.lotID.identifier )
        &&  0 == CIMFWStrLen( strCassette_inPostProcessFlag_Set_in.cassetteID.identifier )
          )
        {
            SET_MSG_RC( strCassette_inPostProcessFlag_Set_out,
                        MSG_INVALID_INPUT_PARM,
                        RC_INVALID_INPUT_PARM );
            return( RC_INVALID_INPUT_PARM );
        }

        PosCassette_var aCassette;
        if( 0 != CIMFWStrLen(strCassette_inPostProcessFlag_Set_in.cassetteID.identifier) )
        {
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                                   strCassette_inPostProcessFlag_Set_in.cassetteID,
                                                   strCassette_inPostProcessFlag_Set_out,
                                                   cassette_inPostProcessFlag_Set);
        }
        else
        {
            //---------------------------------
            //  Convert lotID to lot object
            //---------------------------------
            PosLot_var aLot;
            PPT_CONVERT_LOTID_TO_LOT_OR( aLot,
                                         strCassette_inPostProcessFlag_Set_in.lotID,
                                         strCassette_inPostProcessFlag_Set_out,
                                         cassette_inPostProcessFlag_Set );

            MaterialContainerSequence_var aMaterialContainerSeq;
            try
            {
                aMaterialContainerSeq = aLot->materialContainers();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::materialContainers);

            if( aMaterialContainerSeq->length() > 0 )
            {
                PPT_METHODTRACE_V1("", "Lot is related to Cassette.");
                aCassette = PosCassette::_narrow( (*aMaterialContainerSeq)[0] );
            }
        }

        if( TRUE == CORBA::is_nil(aCassette) )
        {
            SET_MSG_RC(strCassette_inPostProcessFlag_Set_out,MSG_OK,RC_OK);
            return RC_OK;
        }

        if( TRUE == strCassette_inPostProcessFlag_Set_in.inPostProcessFlag )
        {
            //---------------------------------------------
            //  Set InPostProcessFlag of Cassette to ON
            //---------------------------------------------
            try
            {
                aCassette->makePostProcessFlagOn();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::makePostProcessFlagOn);
        }
        else
        {
            //----------------------------------------------
            //  Set InPostProcessFlag of Cassette to OFF
            //----------------------------------------------
            try
            {
                aCassette->makePostProcessFlagOff();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::makePostProcessFlagOff);
        }

        //----------------------
        //  Return to Caller
        //----------------------
        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_inPostProcessFlag_Set");
        return( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_inPostProcessFlag_Set_out, cassette_inPostProcessFlag_Set, methodName);
}
