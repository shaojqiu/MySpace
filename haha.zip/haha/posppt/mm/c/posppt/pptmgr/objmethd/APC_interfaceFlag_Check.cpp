#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/APC_interfaceFlag_Check.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:18:59 [ 7/13/07 19:19:00 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: APC_interfaceFlag_Check.cpp
//

#include "pptmgr.hpp"

//[Object Function Name]: long   APC_interfaceFlag_Check.cpp
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2001-04-27  0.01      K.Kido         Initial Release
// 2001-08-20  P4000099  K.Kido         Change filename
// 2002-02-14  D4100134  C.Tsuchiya     Use getenv() instead of data member 'theSP_xxx'
//
//[Function Description]:
//
//  This object function check the parameter use APC I/F or not.
//
//
//      sequence <pptStartCassette>   strStartCassette;                  
//
//      typedef struct pptStartCassette_struct {
//          long                          loadSequenceNumber;            
//          objectIdentifier              cassetteID;                    
//          string                        loadPurposeType;               
//          objectIdentifier              loadPortID;                    
//          objectIdentifier              unloadPortID;
//          sequence <pptLotInCassette>   strLotInCassette;              
//      } pptStartLot;
//
//      typedef struct pptLotInCassette_struct
//          boolean                       operationStartFlag;            
//          boolean                       monitorLotFlag;                
//          objectIdentifier              lotID;                         
//          string                        lotType;                       
//          string                        subLotType;                    
//          pptStartRecipe                strStartRecipe;                
//          string                        recipeParameterChangeType;     
//          sequence <pptLotWafer>        strLotWafer;                   
//          objectIdentifier              productID;
//      } pptLotInCassette;
//
//      typedef struct pptLotWafer_struct {
//          objectIdentifier              waferID;                       
//          long                          slotNumber;                    
//          boolean                       controlWaferFlag;              
//          sequence <pptStartRecipeParameter> strStartRecipeParameter;  
//      } pptLotWafer;
//
//      typedef struct pptStartRecipeParameter_struct {
//          string                        parameterName;                 
//          string                        parameterValue;
//          string                        targetValue;                   
//          boolean                       useCurrentSettingValueFlag;    
//      } pptStartRecipeParameter;
//
//      typedef struct pptStartRecipe_struct {
//          objectIdentifier              logicalRecipeID;               
//          objectIdentifier              machineRecipeID;               
//          string                        physicalRecipeID;              
//          sequence <pptStartReticle>    strStartReticle;
//          sequence <pptStartFixture>    strStartFixture;
//          boolean                       dataCollectioinFlag;
//          sequence <pptDCDef>           strDCDef;
//      } pptStartRecipe;
//
//
//  [Input Parameters]:
//    in  pptStartCassetteSequence  strStartCassetteSeq;
//
//  [Output Parameters]:
//    out boolean                   APCInterFaceFlag
//
//    typedef struct objAPC_interfaceFlag_Check_out_struct {
//        pptRetCode                strResult;
//        boolean                   APCInterFaceFlag;
//    } objAPC_interfaceFlag_Check_out;
//
//  [Return Value]:
//
//    Return Code                 Messsage ID
//    --------------------------- ------------------------------------------------
//    RC_OK
//
//  [Pseudo Code]:
//

//P4000099CORBA::Long PPTManager_i::APC_InterfaceFlag_Check(
//P4000099                            objAPC_interfaceFlag_Check_out& strAPC_interfaceFlag_Check_out,
//P4000099                            const pptObjCommonIn& strObjCommonIns,
//P4000099                            const pptStartCassetteSequence& strStartCassetteSeq )
CORBA::Long PPTManager_i::APC_interfaceFlag_Check(                                               //P4000099
                            objAPC_interfaceFlag_Check_out& strAPC_interfaceFlag_Check_out,      //P4000099
                            const pptObjCommonIn& strObjCommonIns,                               //P4000099
                            const pptStartCassetteSequence& strStartCassetteSeq )                //P4000099
{
    char *methodName=NULL;
    try
    {
//P4000099        PPT_METHODTRACE_ENTRY("PPTManager_i::APC_InterfaceFlag_Check");
        PPT_METHODTRACE_ENTRY("PPTManager_i::APC_interfaceFlag_Check");                          //P4000099

        /*----------------*/
        /*                */
        /*   Initialize   */
        /*                */
        /*----------------*/
        CORBA::Long rc = RC_OK;
//P4000099        strAPC_InterfaceFlag_Check_out.APCInterFaceFlag = FALSE;
        strAPC_interfaceFlag_Check_out.APCInterFaceFlag = FALSE;                                 //P4000099

        /*------------------------------------------------------*/
        /*         Check environmentValue for APC I/F           */
        /*------------------------------------------------------*/
//D4100134        CORBA::String_var APCAvailable = theSP_APC_Available;
//D4100134        PPT_METHODTRACE_V2("", "theSP_APC_Available", APCAvailable);
        CORBA::String_var APCAvailable = CIMFWStrDup(getenv(SP_APC_Available));    //D4100134
        PPT_METHODTRACE_V2("", "APCAvailable", APCAvailable);                      //D4100134

        if (CIMFWStrCmp(APCAvailable,SP_APC_NotAvailable) == 0 ||
            CIMFWStrLen(APCAvailable) == 0)
        {
            PPT_METHODTRACE_V1("", "APC interface no use...");
            return ( RC_OK );
        }

        /*----------------------------------*/
        /*                                  */
        /*   Check to use APC I/F or not    */
        /*                                  */
        /*----------------------------------*/
        CORBA::Long i,j,k,l;
        CORBA::Long Cassettelen = strStartCassetteSeq.length();

        PPT_METHODTRACE_V2("", "Cassette Length =",Cassettelen);

        for (i = 0 ; i < Cassettelen ; i++)
        {
            CORBA::Long Lotlen = strStartCassetteSeq[i].strLotInCassette.length();

            PPT_METHODTRACE_V2("", "Lot Length =",Lotlen);

            for (j = 0 ; j < Lotlen ; j++)
            {
                CORBA::Long Waferlen = strStartCassetteSeq[i].strLotInCassette[j].strLotWafer.length();
                
                PPT_METHODTRACE_V2("", "Wafer Length =",Waferlen);

                for (k = 0 ; k < Waferlen ; k++)
                {
                    CORBA::Long recipeParamlen = strStartCassetteSeq[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length();
                    
                    PPT_METHODTRACE_V2("", "RecipeParameter Length =",recipeParamlen);

                    /*------------------------------------*/
                    /*   check Recipe Param definition    */
                    /*------------------------------------*/
                    if (recipeParamlen != 0)
                    {
                        PPT_METHODTRACE_V1("", "RecipeParameter Length != 0");
                        
                        for (l = 0 ; l < recipeParamlen ; l++)
                        {
                            /*-------------------------------------------------*/
                            /*   check Recipe Param CurrentSettingValueFlag    */
                            /*-------------------------------------------------*/
                            if ( ! strStartCassetteSeq[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].useCurrentSettingValueFlag)
                            {
//P4000099                      strAPC_InterfaceFlag_Check_out.APCInterFaceFlag = TRUE;
                                strAPC_interfaceFlag_Check_out.APCInterFaceFlag = TRUE;             //P4000099
                                PPT_METHODTRACE_V1("", "APC_InterfaceFlag is TRUE!!!");
                                return ( RC_OK );
                            }
                        }
                    }
                }
            }
        }
    }
//P4000099    CATCH_GLOBAL_EXCEPTIONS(strAPC_InterfaceFlag_Check_out,APC_interfaceFlag_Check, methodName)
    CATCH_GLOBAL_EXCEPTIONS(strAPC_interfaceFlag_Check_out,APC_interfaceFlag_Check, methodName)      //P4000099
    
//P4000099    PPT_METHODTRACE_EXIT("PPTManager_i::APC_InterfaceFlag_Check");
    PPT_METHODTRACE_EXIT("PPTManager_i::APC_interfaceFlag_Check");                                   //P4000099
    return RC_OK;
}

