#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/bank_lotSTB_Check.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:30:16 [ 7/13/07 19:30:17 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2013. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2013. All rights reserved.
//
// SiView
// Name: bank_lotSTB_Check.cpp
//

#include "pptmgr.hpp"

#include "ppcope.hh"
#include "plot.hh"
#include "pbank.hh"
#include "ppcopsp.hh"
#include "pprsp.hh"
#include "pwafer.hh"
#include "pcas.hh"
#include "pprrq.hh"

//[Object Function Name]: long   bank_lotSTB_Check
//
// Date        Level  DCR/PTR     Author         Note
// ----------  -----  ----------  -------------  -------------------------------------------
// 2000/09/05  0.01               H.Katoh        Initial Release
// 2000/09/12  0.00   PTR3000154  H.Katoh        Add logic to check control job of carrier
// 2000/09/21         Q3000124    K.Matsuei      Nil Check
// 2000/09/22  0.00   PTR3000214  H.Katoh        Add Check logic of carrier location
// 2000/11/09         P2200204    R.Furuta       Initialize local pointers
// 2001/07/16         P4000051    K.Kido         change error MSG's parameter
// 2005/06/22         P6000533    H.Adachi       Fix incorrect dimension reference.
// 2005/12/08         P7000045    Y.Kadowaki     Fix error message parameter.
//
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2013/05/10 DSN000071674 C.Mo           Remove part of the EI state limitation
//
//[Function Description]
//  * Check Bank property
//      - Production Bank or not ?
//      - Control Bank or not ?
//      - STB is allowed or not ?
//  * Check Bank is StartBank of Product Request or not
//  * Check source lot's condition
//      - lot's Finished State (might be COMPLETED)
//      - lot's Lot State (might be FINISHED)
//      - lot's Hold State (might not be NOTONHOLD)
//      - lot's Inventory State (might be InBank)
//  * If STB Lot type is control lot, check lot's control use state
//  * Check source lot's Bank
//    (might be the same as ProductRequest's Start Bank)
//  * Chcek source lot's Product
//  * If Source lots are specified in Product Request,
//    check strNewLotAttributes are the same or not
//  * If Source lots are not specified in Product Request,
//    check source lot's wafer is not allocated for STB.
//  * Check Source wafer count is enough for productRequest or not. //0.01
//  * Check carrier has control job or not                          //PTR3000154
//  * Check carrier is on equipment or not                          //PTR3000214
//
//
//[Input Parameters]:
//  in  pptObjCommonIn          strObjCommonIn;
//  in  objectIdentifier        productRequestID;
//  in  pptNewLotAttributes     strNewLotAttributes,
//
//[Output Parameters]:
//
//  out objBank_lotSTB_Check_out  strBank_lotSTB_Check_out;
//
//  typedef struct objBank_lotSTB_Check_out_struct {
//     pptRetCode         strResult;
//  } objBank_lotSTB_Check_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  -------------------------   --------------------------------------------------
//
//[Pseudo Code]:
//

CORBA::Long PPTManager_i::bank_lotSTB_Check(
                            objBank_lotSTB_Check_out& strBank_lotSTB_Check_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& productRequestID,
                            const pptNewLotAttributes& strNewLotAttributes )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::bank_lotSTB_Check");

        //------------------------------------------
        // Get Object reference of Product Request
        //------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","Get Object reference of Product Request");

        PosProductRequest_var aProdReq;
        PPT_CONVERT_PRODUCTREQUESTID_TO_PRODUCTREQUEST_OR( aProdReq,
                                                           productRequestID,
                                                           strBank_lotSTB_Check_out,
                                                           objBank_lotSTB_Check_out,
                                                           productRequestID.identifier );

        //------------------------------------------
        // Get Object reference of Bank
        //------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","Get Object reference of Bank");

        PosBank_var aStartBank;
        try
        {
            aStartBank = aProdReq->getStartBank();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProductRequest::getStartBank)

        if ( CORBA::is_nil(aStartBank) )
        {
            PPT_SET_MSG_RC_KEY( strBank_lotSTB_Check_out,
                                MSG_NOT_FOUND_BANK,
                                RC_NOT_FOUND_BANK,
                                "" );

            return RC_NOT_FOUND_BANK;
        }

        //------------------------------------------
        // Get Object reference of Bank
        //------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","Get Object reference of Bank");

        CORBA::String_var strStartBankID;
        try
        {
            strStartBankID = aStartBank->getIdentifier();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosBank::getIdentifier)

        //------------------------------------------
        // Check Bank is STB Allowed or not
        //------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","Check Bank is STB Allowed or not");

        CORBA::Boolean bSTBBankFlag;
        try
        {
            bSTBBankFlag = aStartBank->isSTBBank();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosBank::isSTBBank)

        if ( bSTBBankFlag == FALSE )
        {
            PPT_SET_MSG_RC_KEY( strBank_lotSTB_Check_out,
                                MSG_INVALID_BANK_STB,
                                RC_INVALID_BANK_STB,
                                strStartBankID );

            return RC_INVALID_BANK_STB;
        }

        //------------------------------------------
        // Check Reqest type for generating lot and
        // bank attribute combination
        //------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","Check Reqest type for generating lot and bank attribute combination");

        CORBA::String_var strLotType;
        try
        {
            strLotType = aProdReq->getLotType();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProductRequest::getLotType)


        if ( 0 == CIMFWStrCmp(strLotType, SP_Lot_Type_ProductionLot)
          || 0 == CIMFWStrCmp(strLotType, SP_Lot_Type_EngineeringLot)
          || 0 == CIMFWStrCmp(strLotType, SP_Lot_Type_VendorLot) )
        {
            PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","strLotType == SP_Lot_Type_ProductionLot, SP_Lot_Type_EngineeringLot, SP_Lot_Type_VendorLot");

            CORBA::Boolean bPrdBank;
            try
            {
                bPrdBank = aStartBank->isProductionBank();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosBank::isProductionBank)

            if ( bPrdBank == FALSE )
            {
                PPT_SET_MSG_RC_KEY2( strBank_lotSTB_Check_out,
                                     MSG_INVALID_BANK_DATA,
                                     RC_INVALID_BANK_DATA,
                                     productRequestID.identifier,
                                     strStartBankID );

                return RC_INVALID_BANK_DATA;
            }
        }
        else if ( 0 == CIMFWStrCmp(strLotType, SP_Lot_Type_ProductionMonitorLot)
               || 0 == CIMFWStrCmp(strLotType, SP_Lot_Type_EquipmentMonitorLot)
               || 0 == CIMFWStrCmp(strLotType, SP_Lot_Type_RecycleLot)
               || 0 == CIMFWStrCmp(strLotType, SP_Lot_Type_DummyLot) )    //PTR3000191
        {
            PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","strLotType == SP_Lot_Type_ProductionMonitorLot, SP_Lot_Type_EquipmentMonitorLot, SP_Lot_Type_RecycleLot, SP_Lot_Type_DummyLot");

            CORBA::Boolean bCtrlBank;
            try
            {
                bCtrlBank = aStartBank->isControlWaferBank();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosBank::isControlWaferBank)

            if ( bCtrlBank == FALSE )
            {
                PPT_SET_MSG_RC_KEY2( strBank_lotSTB_Check_out,
                                     MSG_INVALID_BANK_DATA,
                                     RC_INVALID_BANK_DATA,
                                     productRequestID.identifier,
                                     strStartBankID );

                return RC_INVALID_BANK_DATA;
            }
        }
        else
        {
            PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","Else!!");
            SET_MSG_RC( strBank_lotSTB_Check_out,
                        MSG_INVALID_INPUT_PARM,
                        RC_INVALID_INPUT_PARM );

            return RC_INVALID_INPUT_PARM;
        }

        //------------------------------------------
        // Retrieve lot product's source product sequence
        //------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","Retrieve lot product's source product sequence");

        ProductSpecification_var aProdSpec;
        PosProductSpecification_var aPosProdSpec;
        try
        {
            aProdSpec = aProdReq->getProductSpecification();
            aPosProdSpec = PosProductSpecification::_narrow(aProdSpec);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProductRequest::getProductSpecification)

//Q3000124 start
        if ( CORBA::is_nil(aPosProdSpec) )
        {
            SET_MSG_RC( strBank_lotSTB_Check_out,
                        MSG_NOT_FOUND_PRODUCTSPEC,
                        RC_NOT_FOUND_PRODUCTSPEC );

            return RC_NOT_FOUND_PRODUCTSPEC;
        }
//Q3000124 end

        PosProductSpecificationSequence* pSourceProdSeq = NULL; //P2200204
        PosProductSpecificationSequence_var aSourceProdSeqVar;
        try
        {
            pSourceProdSeq = aPosProdSpec->allSourceProductSpecifications();
            aSourceProdSeqVar = pSourceProdSeq;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosProductSpecification::allSourceProductSpecifications)

        stringSequence strSourceProductSeq;

        CORBA::Long lenSrcProd = pSourceProdSeq->length();

        strSourceProductSeq.length(lenSrcProd);

        CORBA::Long i, j, k;
        for ( i=0; i < lenSrcProd; i++ )
        {
            try
            {
                strSourceProductSeq[i] = (*pSourceProdSeq)[i]->getIdentifier();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProductSpecificationSequence::getIdentifier)
        }

//DSN000071674 add start
        CORBA::Long lotOperationEIcheck = atoi( getenv(SP_LOT_OPERATION_EI_CHECK) );
        if ( 1 == lotOperationEIcheck )
        {
//DSN000071674 add end
            //PTR3000154 Start
            //------------------------------------------
            // Check carrier has controlJob or not
            //------------------------------------------
            PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","Check carrier has controlJob or not");

            PosCassette_var aPosCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aPosCassette,
                                                   strNewLotAttributes.cassetteID,
                                                   strBank_lotSTB_Check_out,
                                                   bank_lotSTB_Check );

            PosControlJob_var aPosControlJob;
            try
            {
                aPosControlJob = aPosCassette->getControlJob();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)

            if ( ! CORBA::is_nil(aPosControlJob) )
            {
                objectIdentifier ctrlJobID;
                PPT_SET_OBJECT_IDENTIFIER( ctrlJobID,
                                           aPosControlJob,
                                           strBank_lotSTB_Check_out,
                                           bank_lotSTB_Check,
                                           PosControlJob );

                PPT_SET_MSG_RC_KEY2( strBank_lotSTB_Check_out,
                                     MSG_STB_CASSETTE_HAS_CTRLJOB,
                                     RC_STB_CASSETTE_HAS_CTRLJOB,
                                     strNewLotAttributes.cassetteID.identifier,
                                     ctrlJobID.identifier );
                return RC_STB_CASSETTE_HAS_CTRLJOB;
            }
            //PTR3000154 End

            //PTR3000214 Start
            //------------------------------------------
            // Check carrier is on equipment or not
            //------------------------------------------
            PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","Check carrier is on equipment or not");

            CORBA::String_var strCassetteXferState;
            try
            {
                strCassetteXferState = aPosCassette->getTransportState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)

            if( 0 == CIMFWStrCmp(strCassetteXferState, SP_TransState_EquipmentIn) )
            {
                PPT_SET_MSG_RC_KEY2( strBank_lotSTB_Check_out,
                                     MSG_INVALID_CAST_XFERSTAT,
                                     RC_INVALID_CAST_XFERSTAT,
                                     strCassetteXferState,
                                     strNewLotAttributes.cassetteID.identifier );

                return RC_INVALID_CAST_XFERSTAT;
            }
            //PTR3000214 End
        } //DSN000071674

        //------------------------------------------
        // Check source lot condition
        //------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","Check source lot condition");

        CORBA::Long lenNewLotAttr = strNewLotAttributes.strNewWaferAttributes.length();
        for ( i=0; i < lenNewLotAttr; i++ )
        {
            if ( i > 0 )
            {
                PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","i > 0");

                if ( 0 == CIMFWStrCmp(strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier,
                                      strNewLotAttributes.strNewWaferAttributes[i-1].sourceLotID.identifier) )
                {
                    PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","[i]sourceLotID == [i-1]sourceLotID--->continue");
                    continue;
                }
            }

            PosLot_var aSourceLot;
            PPT_CONVERT_LOTID_TO_LOT_OR( aSourceLot,
                                         strNewLotAttributes.strNewWaferAttributes[i].sourceLotID,
                                         strBank_lotSTB_Check_out,
                                         bank_lotSTB_Check);

            //------------------------------------------
            // Check source lot Finished Status
            //------------------------------------------
            PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","Check source lot Finished Status");

            CORBA::String_var strLotFinishedState;
            try
            {
                strLotFinishedState = aSourceLot->getLotFinishedState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotFinishedState)

            if ( 0 != CIMFWStrCmp(strLotFinishedState, CIMFW_Lot_FinishedState_Completed) )
            {
                PPT_SET_MSG_RC_KEY( strBank_lotSTB_Check_out,
                                    MSG_INVALID_LOT_FINISHSTAT,
                                    RC_INVALID_LOT_FINISHSTAT,
                                    strLotFinishedState );

                return RC_INVALID_LOT_FINISHSTAT;
            }

            //------------------------------------------
            // Check source lot Status
            //------------------------------------------
            PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","Check source lot Status");

            CORBA::String_var strLotState;
            try
            {
                strLotState = aSourceLot->getLotState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotState)

            if ( 0 != CIMFWStrCmp(strLotState, CIMFW_Lot_State_Finished) )
            {
                PPT_SET_MSG_RC_KEY( strBank_lotSTB_Check_out,
                                    MSG_INVALID_LOT_STAT,
                                    RC_INVALID_LOT_STAT,
                                    strLotState );

                return RC_INVALID_LOT_STAT;
            }

            //------------------------------------------
            // Check source lot Hold Status
            //------------------------------------------
            PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","Check source lot Hold Status");

            CORBA::String_var strLotHoldState;
            try
            {
                strLotHoldState = aSourceLot->getLotHoldState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotHoldState)

            if ( 0 == CIMFWStrCmp(strLotHoldState, CIMFW_Lot_HoldState_OnHold) )
            {
//P4000051                PPT_SET_MSG_RC_KEY2( strBank_lotSTB_Check_out,
//P4000051                                     MSG_INVALID_LOT_HOLDSTAT,
//P4000051                                     RC_INVALID_LOT_HOLDSTAT,
//P4000051                                     productRequestID.identifier,
//P4000051                                     strLotHoldState );
//P4000051 add start
                PPT_SET_MSG_RC_KEY2( strBank_lotSTB_Check_out,
                                     MSG_INVALID_LOT_HOLDSTAT,
                                     RC_INVALID_LOT_HOLDSTAT,
                                     strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier,
                                     strLotHoldState );
//P4000051 add end
                return RC_INVALID_LOT_HOLDSTAT;
            }

            //------------------------------------------
            // Check source lot Inventory Status
            //------------------------------------------
            PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","Check source lot Inventory Status");

            CORBA::String_var strLotInventoryState;
            try
            {
                strLotInventoryState = aSourceLot->getLotInventoryState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotInventoryState)

            if ( 0 != CIMFWStrCmp(strLotInventoryState, SP_Lot_InventoryState_InBank) )
            {
//P4000051                PPT_SET_MSG_RC_KEY2( strBank_lotSTB_Check_out,
//P4000051                                     MSG_INVALID_LOT_INVENTORYSTAT,
//P4000051                                     RC_INVALID_LOT_INVENTORYSTAT,
//P4000051                                     productRequestID.identifier,
//P4000051                                     strLotInventoryState );
//P4000051 add start
                PPT_SET_MSG_RC_KEY2( strBank_lotSTB_Check_out,
                                     MSG_INVALID_LOT_INVENTORYSTAT,
                                     RC_INVALID_LOT_INVENTORYSTAT,
                                     strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier,
                                     strLotInventoryState );
//P4000051 add end
                return RC_INVALID_LOT_INVENTORYSTAT;
            }

            //------------------------------------------
            // Check source lot control use state
            //------------------------------------------
            PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","Check source lot control use state");

            if ( 0 == CIMFWStrCmp(strLotType, SP_Lot_Type_ProductionMonitorLot)
              || 0 == CIMFWStrCmp(strLotType, SP_Lot_Type_EquipmentMonitorLot)
              || 0 == CIMFWStrCmp(strLotType, SP_Lot_Type_DummyLot)
              || 0 == CIMFWStrCmp(strLotType, SP_Lot_Type_RecycleLot) )
            {
                PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","strLotType == SP_Lot_Type_ProductionMonitorLot, SP_Lot_Type_EquipmentMonitorLot, SP_Lot_Type_DummyLot, SP_Lot_Type_RecycleLot");

                CORBA::String_var strLotControlUseState;
                try
                {
                    strLotControlUseState = aSourceLot->getControlUseState();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getControlUseState)

                if ( 0 != CIMFWStrCmp(strLotControlUseState, SP_Lot_ControlUseState_WaitUse)
                  && 0 != CIMFWStrCmp(strLotControlUseState, SP_Lot_ControlUseState_WaitRecycle) )
                {
                    PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","strLotControlUseState != SP_Lot_ControlUseState_WaitUse and SP_Lot_ControlUseState_WaitRecycle");

                    char tmp[128];
                    sprintf(tmp, "%s or %s", SP_Lot_ControlUseState_WaitUse, SP_Lot_ControlUseState_WaitRecycle);

//P4000051                    PPT_SET_MSG_RC_KEY3( strBank_lotSTB_Check_out,
//P4000051                                         MSG_INVALID_LOT_CNTLUSESTAT,
//P4000051                                         RC_INVALID_LOT_CNTLUSESTAT,
//P4000051                                         productRequestID.identifier,
//P4000051                                         strLotControlUseState ,
//P4000051                                         tmp );
//P4000051 add start 
                    PPT_SET_MSG_RC_KEY3( strBank_lotSTB_Check_out,
                                         MSG_INVALID_LOT_CNTLUSESTAT,
                                         RC_INVALID_LOT_CNTLUSESTAT,
                                         strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier,
                                         strLotControlUseState ,
                                         tmp );
//P4000051 add end
                    return RC_INVALID_LOT_CNTLUSESTAT;
                }
            }

            //------------------------------------------
            // Check source lot bank
            //------------------------------------------
            PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","Check source lot bank");

            PosBank_var aSourceLotBank;
            try
            {
                aSourceLotBank = aSourceLot->getBank();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getBank)

//Q3000124 start
            if(CORBA::is_nil(aSourceLotBank))
            {
                PPT_SET_MSG_RC_KEY( strBank_lotSTB_Check_out,
                                    MSG_NOT_FOUND_BANK,
                                    RC_NOT_FOUND_BANK, "" );
                return RC_NOT_FOUND_BANK ;
            }
//Q3000124 end

            CORBA::String_var strSourceLotBankID;
            try
            {
                strSourceLotBankID = aSourceLotBank->getIdentifier();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosBank::getIdentifier)

            if ( 0 != CIMFWStrCmp(strSourceLotBankID, strStartBankID) )
            {
                PPT_SET_MSG_RC_KEY2( strBank_lotSTB_Check_out,
                                     MSG_NOT_MATCH_STARTBANK,
                                     RC_NOT_MATCH_STARTBANK,
                                     strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier,
                                     productRequestID.identifier );

                return RC_NOT_MATCH_STARTBANK;
            }

            //------------------------------------------
            // Check source lot Product Spec
            //------------------------------------------
            PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","Check source lot Product Spec");

            ProductSpecification_var aProductSpec;
            PosProductSpecification_var aSourceLotProdSpec;
            try
            {
                aProductSpec = aSourceLot->getProductSpecification();
                aSourceLotProdSpec = PosProductSpecification::_narrow(aProductSpec);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification);

//Q3000124 start
            if ( CORBA::is_nil(aSourceLotProdSpec) )
            {
                SET_MSG_RC( strBank_lotSTB_Check_out,
                            MSG_NOT_FOUND_PRODUCTSPEC,
                            RC_NOT_FOUND_PRODUCTSPEC );

                return RC_NOT_FOUND_PRODUCTSPEC;
            }
//Q3000124 end

            CORBA::String_var strSourceLotProduct;
            try
            {
                strSourceLotProduct = aProductSpec->getIdentifier();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProductSpecification::getIdentifier)

            CORBA::Boolean bSourceProductMatchFlag = FALSE;
            CORBA::Long j;
            CORBA::Long lenSrcPrd = strSourceProductSeq.length();

            for ( j=0; j < lenSrcPrd; j++ )
            {
                if ( 0 == CIMFWStrCmp(strSourceProductSeq[j], strSourceLotProduct) )
                {
                    PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","strSourceProductSeq[j] == strSourceLotProduct");

                    bSourceProductMatchFlag = TRUE;
                    break;
                }
            }
            if ( bSourceProductMatchFlag == FALSE )
            {
                PPT_SET_MSG_RC_KEY2( strBank_lotSTB_Check_out,
                                     MSG_INVALID_SOURCELOT_PRODUCT,
                                     RC_INVALID_SOURCELOT_PRODUCT,
                                     strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier,
                                     strSourceLotProduct );

                return RC_INVALID_SOURCELOT_PRODUCT;
            }
        }

        //------------------------------------------
        // Retrieve product request's source lot
        //------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","Retrieve product request's source lot");

        PosSourceLotSequence* aSourceLots = NULL;
        PosSourceLotSequence_var aSourceLotSeq;
        try
        {
            aSourceLots = aProdReq->allSourceLots();
            aSourceLotSeq = aSourceLots;
        }
        CATCH_AND_RAISE_EXCEPTIONS(ProductRequest::allSourceLots)


        //------------------------------------------
        // Check source lot Wafer Contents
        //------------------------------------------
        PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","Check source lot Wafer Contents");

        CORBA::Long lenSrcLot = aSourceLots->length();
        lenNewLotAttr = strNewLotAttributes.strNewWaferAttributes.length();

        if ( lenSrcLot > 0 )
        {
            PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","lenSrcLot > 0");

            for ( i=0; i < lenSrcLot; i++ )
            {
                CORBA::Long lenSrcLotPrd = (*aSourceLots)[i].products.length();

                for ( j=0; j < lenSrcLotPrd; j++ )
                {
                    CORBA::Boolean bFoundFlag = FALSE;

                    for ( k=0; k < lenNewLotAttr; k++ )
                    {
                        if ( 0 == CIMFWStrCmp((*aSourceLots)[i].products[j].identifier,
                                              strNewLotAttributes.strNewWaferAttributes[k].sourceWaferID.identifier) )
                        {
                            PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","aSourceLots[i].products[j] == strNewWaferAttributes[k].sourceWaferID");

                            bFoundFlag = TRUE;
                            break;
                        }
                    }
                    if ( bFoundFlag == FALSE )
                    {
//P4000051                        PPT_SET_MSG_RC_KEY( strBank_lotSTB_Check_out,
//P4000051                                            MSG_NOT_MATCH_SOURCE_PRODUCT,
//P4000051                                            RC_NOT_MATCH_SOURCE_PRODUCT,
//P4000051                                            productRequestID.identifier );
//P4000051 add start
//P7000045                        PPT_SET_MSG_RC_KEY( strBank_lotSTB_Check_out,
//P7000045                                            MSG_NOT_MATCH_SOURCE_PRODUCT,
//P7000045                                            RC_NOT_MATCH_SOURCE_PRODUCT,
//P7000045                                            strNewLotAttributes.strNewWaferAttributes[k].sourceLotID.identifier );    //P6000533
//P6000533                                            strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier );
//P4000051 add end
//P7000045                        return RC_NOT_MATCH_SOURCE_PRODUCT;
//P7000045 add start
                        PPT_SET_MSG_RC_KEY( strBank_lotSTB_Check_out,
                                            MSG_NOT_FOUND_SOURCE_WAFER,
                                            RC_NOT_FOUND_SOURCE_WAFER,
                                            (*aSourceLots)[i].products[j].identifier );

                        return RC_NOT_FOUND_SOURCE_WAFER;
//P7000045 add end
                    }
                }
            }
        }
        else
        {
            PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","not (lenSrcLot > 0)");

            for ( i=0; i < lenNewLotAttr; i++ )
            {
                // check requested wafer existance and
                // STB Allocated Flag of each wafer
                PosWafer_var aPosWafer;
                PPT_CONVERT_WAFERID_TO_WAFER_OR( aPosWafer,
                                                 strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID,
                                                 strBank_lotSTB_Check_out,
                                                 bank_lotSTB_Check );

                CORBA::Boolean bWaferFoundFlag;
                try
                {
                    bWaferFoundFlag = aPosWafer->isSTBAllocated();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosWafer::isSTBAllocated)

                if ( bWaferFoundFlag == TRUE )
                {
                    PPT_METHODTRACE_V1("PPTManager_i::bank_lotSTB_Check","bWaferFoundFlag == TRUE");

                    CORBA::String_var strWaferID;
                    try
                    {
                        strWaferID = aPosWafer->getIdentifier();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getIdentifier)

                    PPT_SET_MSG_RC_KEY( strBank_lotSTB_Check_out,
                                        MSG_WAFER_ALLOCATED,
                                        RC_WAFER_ALLOCATED,
                                        strWaferID );

                    return RC_WAFER_ALLOCATED;
                }

                // Check wafer is in target cassette or not
                MaterialContainer* aMaterialContainer = NULL;  //P2200204
                MaterialContainer_var aMaterialContainerVar;
                try
                {
                    aMaterialContainer = aPosWafer->getMaterialContainer();
                    aMaterialContainerVar = aMaterialContainer;
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getMaterialContainer)

                CORBA::String_var tmpMaterialContainer;
                if ( ! CORBA::is_nil(aMaterialContainerVar) )   // Q3000124
                {                                               // Q3000124
                    try
                    {
                        tmpMaterialContainer = aMaterialContainer->getIdentifier();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(MaterialContainer::getIdentifier)
                }                                               // Q3000124

                if ( 0 != CIMFWStrCmp(tmpMaterialContainer, strNewLotAttributes.cassetteID.identifier) )
                {
                    SET_MSG_RC( strBank_lotSTB_Check_out,
                                MSG_WAFER_NOT_PREPARED,
                                RC_WAFER_NOT_PREPARED );

                    return RC_WAFER_NOT_PREPARED;
                }
            }
        }

        PPT_METHODTRACE_EXIT("PPTManager_i::bank_lotSTB_Check");

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strBank_lotSTB_Check_out, bank_lotSTB_Check, methodName)
}
