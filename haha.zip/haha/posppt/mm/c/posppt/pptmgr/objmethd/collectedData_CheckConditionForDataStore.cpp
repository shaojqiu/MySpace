//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2011. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2011. All rights reserved.
//
// SiView
// Name: collectedData_CheckConditionForDataStore.cpp
//

#include "pptmgr.hpp"
#include "ppcope.hh"
#include "plot.hh"

// Class: PPTManager
//
// Service: collectedData_CheckConditionForDataStore()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2011/08/24 DSN000015229 Yang Xia       Initial Release For Advanced Wafer Level Control
//
//[Function Description]:
//  Check parameters for data collection.
//
//[Input Parameters]:
//  const pptObjCommonIn&                                   strObjCommonIn
//  const objCollectedData_CheckConditionForDataStore_in&   strCollectedData_CheckConditionForDataStore_in
//
//    typedef objCollectedData_CheckConditionForDataStore_in_struct{
//        objectIdentifier              controlJobID;
//        pptCollectedDataItemSequence  strCollectedDataItemSeq;
//        any                           siInfo;
//    }objCollectedData_CheckConditionForDataStore_in;
//
//[Output Parameters]:
//    objcollectedData_CheckConditionForDataStore_out&      strCollectedData_CheckConditionForDataStore
//
//    typedef objcollectedData_CheckConditionForDataStore_out_struct{
//        pptRetCode                strResult;
//        pptStartCassetteSequence  strStartCassetteSeq;
//        any                       siInfo;
//    }objcollectedData_CheckConditionForDataStore_out;
//
//typedef struct pptCollectedDataItem_struct {
//    objectIdentifier                    lotID;                      //<i>Lot ID
//    objectIdentifier                    dataCollectionDefinitionID; //<i>Data Collection Definition ID
//    string                              dataCollectionItemName;     //<i>Data Collection Item Name
//    string                              dataCollectionMode;         //<i>Data Collection Mode (Auto/Derived/Manual)
//    string                              dataType;                   //<i>Data Type
//    string                              itemType;                   //<i>Item Type (Derived/Raw/User Func)
//    string                              measurementType;            //<i>Measurement Type
//    string                              sitePosition;               //<i>Site Position
//    pptCollectedDataSequence            strCollectedDataSeq;        //<i>Sequence of Data Collection Values
//    any                                 siInfo;                     //<i>Reserved for SI customization
//} pptCollectedDataItem;
//
//typedef sequence <pptCollectedDataItem> pptCollectedDataItemSequence;
//
//typedef struct pptCollectedData_struct {
//    objectIdentifier                    waferID;            //<i>Wafer ID
//    string                              waferPosition;      //<i>Wafer Position
//    string                              processJobID;       //<i>Process Job ID
//    string                              processJobPosition; //<i>Process Job Position
//    string                              dataValue;          //<i>Data Value
//    any                                 siInfo;             //<i>Reserved for SI customization
//} pptCollectedData;
//
//typedef sequence <pptCollectedData> pptCollectedDataSequence;
//
//typedef struct pptLotInCassette_struct {
//    boolean                       operationStartFlag;           //<i>Operation Start Flag
//    boolean                       monitorLotFlag;               //<i>Monitor Lot Flag
//    objectIdentifier              lotID;                        //<i>Lot ID
//    string                        lotType;                      //<i>Lot Type
//    string                        subLotType;                   //<i>Sub Lot Type
//    pptStartRecipe                strStartRecipe;               //<i>Start Recipe Information
//    string                        recipeParameterChangeType;    //<i>Recipe Parameter Change Type
//    pptLotWaferSequence           strLotWafer;                  //<i>Sequence of Lot Wafer
//    objectIdentifier              productID;                    //<i>Product ID                   //D3000116
//    pptStartOperationInfo         strStartOperationInfo;        //<i>Start Operation Information  //D4000093
//    any siInfo;                                                 //<i>Reserved for SI customization
//} pptLotInCassette;
//
//typedef sequence <pptLotInCassette> pptLotInCassetteSequence;
//
//typedef struct pptStartRecipe_struct {
//    objectIdentifier              logicalRecipeID;       //<i>Logical Recipe ID
//    objectIdentifier              machineRecipeID;       //<i>Machine Recipe ID
//    string                        physicalRecipeID;      //<i>Physical Recipe ID
//    pptStartReticleSequence       strStartReticle;       //<i>Sequence of Start Reticle
//    pptStartFixtureSequence       strStartFixture;       //<i>Sequence of Start Fixture
//    boolean                       dataCollectionFlag;    //<i>Data Collection Flag
//    pptDCDefSequence              strDCDef;              //<i>Sequence of Data Collection Definition
//    any siInfo;                                          //<i>Reserved for SI customization
//} pptStartRecipe;
//
//typedef struct pptDCDef_struct {
//    objectIdentifier    dataCollectionDefinitionID;            //<i>Data Collection Definition ID
//    string              description;                           //<i>Description
//    string              dataCollectionType;                    //<i>Data Collection Type
//    pptDCItemSequence   strDCItem;                             //<i>Sequence of Data Collection Items
//    boolean             calculationRequiredFlag;               //<i>Calculation Required Flag
//    boolean             specCheckRequiredFlag;                 //<i>Spec Check Required Flag
//    objectIdentifier    dataCollectionSpecificationID;         //<i>Data Collection Definition ID
////D8000025 add start
//    string              dcSpecDescription;                     //<i>Description of Data Collection Specification ID
//    pptDCSpecSequence   strDCSpec;                             //<i>Sequence of Data Collection Specs
////D8000025 add end
//    objectIdentifier    previousDataCollectionDefinitionID;    //<i>Previous Data Collection Definition ID
//    objectIdentifier    previousOperationID;                   //<i>Previous Operation ID
//    string              previousOperationNumber;               //<i>Previous Operation Number
//    any siInfo;                                                //<i>Reserved for SI customization
//} pptDCDef;
//
//typedef sequence <pptDCDef> pptDCDefSequence;
//
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long PPTManager_i:: collectedData_CheckConditionForDataStore(
    objCollectedData_CheckConditionForDataStore_out&        strCollectedData_CheckConditionForDataStore_out,
    const pptObjCommonIn&                                   strObjCommonIn,
    const objCollectedData_CheckConditionForDataStore_in&   strCollectedData_CheckConditionForDataStore_in)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::collectedData_CheckConditionForDataStore");

        //---------------------------------
        // Put Input Parameter
        //---------------------------------
        const objectIdentifier&             controlJobID = strCollectedData_CheckConditionForDataStore_in.controlJobID;
        const pptCollectedDataItemSequence& strCDItemSeq = strCollectedData_CheckConditionForDataStore_in.strCollectedDataItemSeq;

        PPT_METHODTRACE_V2("", " +++++ in para controlJobID        ", controlJobID.identifier);

        /*----------------------------------------------------*/
        /*   Check DataValue length                           */
        /*   (Pick up lot IDs in the same time)               */
        /*----------------------------------------------------*/
        CORBA::Long lenDCItem = strCDItemSeq.length();
        pptLotInCassetteSequence    strTmpLotIDSeq;
        strTmpLotIDSeq.length(lenDCItem);
        char* longStringValue = getenv("SP_LONG_STRING_VALUE");
        CORBA::ULong count = 0;

        CORBA::ULong ii = 0;
        CORBA::ULong jj = 0;
        CORBA::ULong v  = 0;
        CORBA::ULong w  = 0;
        CORBA::ULong x  = 0;

        PPT_METHODTRACE_V2("","Collected Data length",lenDCItem);
        CORBA::ULong lenTempLotSeq = 0;
        CORBA::Boolean bFindFlag = FALSE;
        CORBA::ULong lenData = 0;
        for (ii = 0 ; ii < lenDCItem ; ii++)
        {
            PPT_METHODTRACE_V2("","ii",ii);
            bFindFlag = FALSE;
            lenData = strCDItemSeq[ii].strCollectedDataSeq.length();
            PPT_METHODTRACE_V2("","Data length",lenData);
            if ( 0 < lenData)
            {
                // search the lot in existing strTmpLotIDSeq
                lenTempLotSeq = strTmpLotIDSeq.length();
                PPT_METHODTRACE_V2("","lenTempLotSeq",lenTempLotSeq);
                CORBA::ULong nTmpLotIndex = 0;
                for (CORBA::ULong iCnt1 = 0; iCnt1 < count; iCnt1++)
                {
                    PPT_METHODTRACE_V2("","iCnt1",iCnt1);
                    if( 0 == CIMFWStrCmp( strCDItemSeq[ii].lotID.identifier, strTmpLotIDSeq[iCnt1].lotID.identifier ))
                    {
                        PPT_METHODTRACE_V2("", " ##### Find lot = ", strCDItemSeq[ii].lotID.identifier );
                        bFindFlag = TRUE;
                        nTmpLotIndex = iCnt1;
                        break;
                    }
                }

                if ( FALSE == bFindFlag )
                {
                    //-----------------------
                    // Add lot ID to strTmpLotIDSeq
                    //-----------------------
                    PPT_METHODTRACE_V1("","bFindFlag == FALSE");
                    PPT_METHODTRACE_V2("","add lotID",strCDItemSeq[ii].lotID.identifier);
                    strTmpLotIDSeq.length( count + 1 );
                    strTmpLotIDSeq[count].lotID = strCDItemSeq[ii].lotID;
                    strTmpLotIDSeq[count].strStartRecipe.strDCDef.length(1);
                    strTmpLotIDSeq[count].strStartRecipe.strDCDef[0].dataCollectionDefinitionID = strCDItemSeq[ii].dataCollectionDefinitionID;
                    count++;
                }
                else
                {
                    PPT_METHODTRACE_V1("","bFindFlag == TRUE");
                    CORBA::Boolean bDCDefFindFlag = FALSE;
                    CORBA::ULong nDCDefLen = strTmpLotIDSeq[nTmpLotIndex].strStartRecipe.strDCDef.length();
                    for ( CORBA::ULong nDCDefNum = 0; nDCDefNum < nDCDefLen; nDCDefNum++ )
                    {
                        PPT_METHODTRACE_V3("","nDCDefLen/nDCDefNum", nDCDefLen, nDCDefNum);
                        if ( 0 == CIMFWStrCmp( strCDItemSeq[ii].dataCollectionDefinitionID.identifier, strTmpLotIDSeq[nTmpLotIndex].strStartRecipe.strDCDef[nDCDefNum].dataCollectionDefinitionID.identifier ) )
                        {
                            PPT_METHODTRACE_V3("", " ##### Find DCDef = ", strCDItemSeq[ii].lotID.identifier, strCDItemSeq[ii].dataCollectionDefinitionID.identifier );
                            bDCDefFindFlag = TRUE;
                            break;
                        }
                    }
                    if ( FALSE == bDCDefFindFlag )
                    {
                        strTmpLotIDSeq[nTmpLotIndex].strStartRecipe.strDCDef.length( nDCDefLen + 1 );
                        strTmpLotIDSeq[nTmpLotIndex].strStartRecipe.strDCDef[nDCDefLen].dataCollectionDefinitionID = strCDItemSeq[ii].dataCollectionDefinitionID;
                    }
                }
            }
            for (jj = 0 ; jj < lenData ; jj++)
            {
                CORBA::Long lenDataVal = CIMFWStrLen(strCDItemSeq[ii].strCollectedDataSeq[jj].dataValue);
                PPT_METHODTRACE_V2("","DataValue length",lenDataVal);

                PPT_METHODTRACE_V2("","LONG_STRING_VALUE",longStringValue);
                if ( (longStringValue && 0 == strcmp(longStringValue, "ON") )
                  && (0 == CIMFWStrCmp( strCDItemSeq[ii].dataType, SP_DCDef_Val_String)) )
                {
                    PPT_METHODTRACE_V1("","longStringValue == TRUE");
                    if (128 < lenDataVal)
                    {
                         PPT_METHODTRACE_V1("","DataValue length > 128 !!");
                         SET_MSG_RC( strCollectedData_CheckConditionForDataStore_out,
                                     MSG_INVALID_INPUT_PARM,
                                     RC_INVALID_INPUT_PARM);
                         return( RC_INVALID_INPUT_PARM );
                    }
                }
                else if (12 < lenDataVal)
                {
                    PPT_METHODTRACE_V1("","DataValue length > 12 !!");

                    SET_MSG_RC( strCollectedData_CheckConditionForDataStore_out,
                                MSG_INVALID_INPUT_PARM,
                                RC_INVALID_INPUT_PARM);
                    return( RC_INVALID_INPUT_PARM );
                }
            }

        }
        strTmpLotIDSeq.length(count);

        PPT_METHODTRACE_V1("","All dataValue length < 13 ...");

        //-----------------------
        // Pick up data collection item from strCDItemSeq.
        //-----------------------
        //-----------------------
        // dataCollectionItemName, sitePosition combination should exist in lotID fs PO DC item.
        //-----------------------
        for ( v = 0; v < strTmpLotIDSeq.length(); v++ )
        {
            PPT_METHODTRACE_V2("","v",v);
            //get Lot Object (aPosPO)
            /*--------------------*/
            /*   Get Lot Object   */
            /*--------------------*/
            PosLot_var aLot;
            PPT_CONVERT_LOTID_TO_LOT_OR( aLot, strTmpLotIDSeq[v].lotID, strCollectedData_CheckConditionForDataStore_out, collectedData_CheckConditionForDataStore);

            /*--------------------------------*/
            /*   Get Lot's ProcessOperation   */
            /*--------------------------------*/
            ProcessOperation_var aPO;
            PosProcessOperation_var aPosPO;
            try
            {
                aPO = aLot->getProcessOperation();
                aPosPO = PosProcessOperation::_narrow(aPO);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation);

            if (TRUE == CORBA::is_nil(aPosPO))
            {
                PPT_METHODTRACE_V1("","CORBA::is_nil(aPosPO)");
                PPT_SET_MSG_RC_KEY2(strCollectedData_CheckConditionForDataStore_out, MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO, "", strTmpLotIDSeq[v].lotID.identifier);
                return(RC_NOT_FOUND_PO);
            }

            CORBA::ULong lenDCDefSeq = strTmpLotIDSeq[v].strStartRecipe.strDCDef.length();
            for ( w = 0; w < lenDCDefSeq; w++ )
            {
                PPT_METHODTRACE_V2("","w",w);
                PPT_METHODTRACE_V2("","dataCollectionDefinitionID.identifier", strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].dataCollectionDefinitionID.identifier);
                PosDataCollectionItemInfoSequence_var strDataCollectionItemInfoSeq;
                try
                {
                   strDataCollectionItemInfoSeq = aPosPO->getAssignedDataCollectionItemInfo(strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].dataCollectionDefinitionID.identifier);
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getAssignedDataCollectionItemInfo)

                strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem.length(strDataCollectionItemInfoSeq->length());
                CORBA::ULong lenDCItemInfoSeq = strDataCollectionItemInfoSeq->length();
                for (x = 0; x < lenDCItemInfoSeq; x++)
                {
                    PPT_METHODTRACE_V2("","x",x);
                    strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].dataCollectionItemName = strDataCollectionItemInfoSeq[x].dataCollectionItemName;
                    strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].dataCollectionMode     = strDataCollectionItemInfoSeq[x].dataCollectionMode;
                    strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].dataCollectionUnit     = strDataCollectionItemInfoSeq[x].dataCollectionUnit;
                    strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].dataType               = strDataCollectionItemInfoSeq[x].dataType;
                    strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].itemType               = strDataCollectionItemInfoSeq[x].itemType;
                    strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].measurementType        = strDataCollectionItemInfoSeq[x].measurementType;
                    strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].waferID                = strDataCollectionItemInfoSeq[x].waferID;
                    strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].waferPosition          = strDataCollectionItemInfoSeq[x].waferPosition;
                    strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].sitePosition           = strDataCollectionItemInfoSeq[x].sitePosition;
                    strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].historyRequiredFlag    = strDataCollectionItemInfoSeq[x].historyRequiredFlag;
                    strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].calculationType        = strDataCollectionItemInfoSeq[x].calculationType;
                    strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].calculationExpression  = strDataCollectionItemInfoSeq[x].calculationExpression;
                    strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].dataValue              = strDataCollectionItemInfoSeq[x].dataValue;
                    strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].targetValue            = strDataCollectionItemInfoSeq[x].targetValue;
                    strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].specCheckResult        = strDataCollectionItemInfoSeq[x].specCheckResult;
                    strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].actionCode.length(1);
                    strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].actionCode[0]          = strDataCollectionItemInfoSeq[x].actionCodes;
                }
            }
        }

        //-----------------------
        // Check if reported data items[PJ site and PJ wafer site] exist in PO's collected data
        //-----------------------
        PPT_METHODTRACE_V2("","Collected Data length",lenDCItem);
        for ( ii = 0 ; ii < lenDCItem ; ii++)
        {
            PPT_METHODTRACE_V2("","ii",ii);
            if ( ( 0 == CIMFWStrCmp( SP_DCDef_Meas_PJWafer, strCDItemSeq[ii].measurementType))
              || ( 0 == CIMFWStrCmp( SP_DCDef_Meas_PJWaferSite, strCDItemSeq[ii].measurementType) ))
            {
                PPT_METHODTRACE_V1("","measurementType is SP_DCDef_Meas_PJWaferSite or SP_DCDef_Meas_PJSite");
                CORBA::Boolean bFoundFlag = FALSE;
                CORBA::ULong lenLotIDSeq = strTmpLotIDSeq.length();
                for ( v = 0; v < lenLotIDSeq; v++)
                {
                    PPT_METHODTRACE_V2("","lenTempLotSeq",v);
                    if ( 0 == CIMFWStrCmp(strCDItemSeq[ii].lotID.identifier, strTmpLotIDSeq[v].lotID.identifier))
                    {
                        PPT_METHODTRACE_V1("","Same Lot");
                        CORBA::ULong lenDCDefSeq = strTmpLotIDSeq[v].strStartRecipe.strDCDef.length();
                        for ( w = 0; w < lenDCDefSeq; w++ )
                        {
                            PPT_METHODTRACE_V2("","lenDCDefSeq",w);
                            CORBA::ULong lenDCItemSeq = strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem.length();
                            for ( x = 0; x < lenDCItemSeq; x++ )
                            {
                                PPT_METHODTRACE_V2("","lenDCItemSeq",x);
                                PPT_METHODTRACE_V2("","strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].dataCollectionItemName: ", strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].dataCollectionItemName);
                                PPT_METHODTRACE_V2("","strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].sitePosition: ", strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].sitePosition);
                                if ( 0 == CIMFWStrCmp( strCDItemSeq[ii].dataCollectionItemName, strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].dataCollectionItemName )
                                  && 0 == CIMFWStrCmp( strCDItemSeq[ii].sitePosition, strTmpLotIDSeq[v].strStartRecipe.strDCDef[w].strDCItem[x].sitePosition ) )
                                {
                                    PPT_METHODTRACE_V1("","bFoundFlag == TRUE");
                                    bFoundFlag = TRUE;
                                    break;
                                }
                            }
                            if( TRUE == bFoundFlag )
                            {
                                PPT_METHODTRACE_V1("","bFoundFlag == TRUE and break");
                                break;
                            }
                        }
                        if( TRUE == bFoundFlag )
                        {
                            PPT_METHODTRACE_V1("","bFoundFlag == TRUE and break");
                            break;
                        }
                    }
                }
                if( FALSE == bFoundFlag )
                {
                    PPT_METHODTRACE_V3("", "Invalid measurement type : ", strCDItemSeq[ii].dataCollectionItemName, strCDItemSeq[ii].measurementType );
                    PPT_SET_MSG_RC_KEY3( strCollectedData_CheckConditionForDataStore_out,
                                         MSG_LOT_INVALID_COLLECT_DATA,
                                         RC_LOT_INVALID_COLLECT_DATA,
                                         strCDItemSeq[ii].lotID.identifier,
                                         strCDItemSeq[ii].dataCollectionItemName,
                                         strCDItemSeq[ii].measurementType );
                    return( RC_LOT_INVALID_COLLECT_DATA );
                } 
            }
        }
        //----------------------
        //Set OutPut Parameter
        //----------------------

        PPT_METHODTRACE_EXIT("PPTManager_i::collectedData_CheckConditionForDataStore");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCollectedData_CheckConditionForDataStore_out, collectedData_CheckConditionForDataStore, methodName)
}
