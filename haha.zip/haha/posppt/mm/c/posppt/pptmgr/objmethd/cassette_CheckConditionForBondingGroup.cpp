//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
//
// SiView
// Name: cassette_CheckConditionForBondingGroup.cpp
//

#include "pptmgr.hpp"
#include "pcas.hh"
#include "pperson.hh"
#include "pctrlj.hh"

//[Object Function Name]: long   cassette_CheckConditionForBondingGroup
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2010-03-31 DSIV00001830 R.Iriguchi     Wafer Stacking Support
//
//[Function Description]:
//  Do Check of Lot related to BondingGroup.
//
//[Input Parameters]:
//  in  pptObjCommonIn                                  strObjCommonIn;
//  in  objCassette_CheckConditionForBondingGroup_in         strCassette_CheckConditionForBondingGroup_in;
//
//  //InParameter of cassette_CheckConditionForBondingGroup
//  typedef struct objCassette_CheckConditionForBondingGroup_in_struct {
//      objectIdentifierSequence            cassetteIDSeq;
//      any                                 siInfo;
//  } objCassette_CheckConditionForBondingGroup_in;
//
//[Output Parameters]:
//  out objCassette_CheckConditionForBondingGroup_out        strCassette_CheckConditionForBondingGroup_out;
//
//  //Result of cassette_CheckConditionForBondingGroup
//  typedef objBase_out objCassette_CheckConditionForBondingGroup_out;
//
//[Return Value]:
//
//  Return Code                   Message ID
//  ----------------------------- ------------------------------------------------
//  RC_OK                         MSG_OK
//  RC_LOT_CTLJOBID_FILLED        MSG_LOT_CTLJOBID_FILLED
//  RC_INVALID_LOT_HOLDSTAT       MSG_INVALID_LOT_HOLDSTAT
//  RC_INVALID_LOT_PROCSTAT       MSG_INVALID_LOT_PROCSTAT
//  RC_INVALID_LOT_INVENTORYSTAT  MSG_INVALID_LOT_INVENTORYSTAT
//

CORBA::Long PPTManager_i::cassette_CheckConditionForBondingGroup(
    objCassette_CheckConditionForBondingGroup_out&      strCassette_CheckConditionForBondingGroup_out,
    const pptObjCommonIn&                               strObjCommonIn,
    const objCassette_CheckConditionForBondingGroup_in& strCassette_CheckConditionForBondingGroup_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY( "PPTManager_i::cassette_CheckConditionForBondingGroup" );

        /*----------------*/
        /*                */
        /*   Initialize   */
        /*                */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        CORBA::Long castLen = strCassette_CheckConditionForBondingGroup_in.cassetteIDSeq.length();
        PPT_METHODTRACE_V2( "", "in-parm's cassetteIDSeq.length()", castLen );

        /*-------------------------*/
        /*   Check Lot Condition   */
        /*-------------------------*/
        for ( CORBA::Long castCnt  = 0; castCnt < castLen; castCnt++ )
        {
            PPT_METHODTRACE_V3( "", "-----------------------round[castCnt]",
                                castCnt, strCassette_CheckConditionForBondingGroup_in.cassetteIDSeq[castCnt].identifier );

            PosCassette_var aCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette, strCassette_CheckConditionForBondingGroup_in.cassetteIDSeq[castCnt],
                                                   strCassette_CheckConditionForBondingGroup_out,
                                                   cassette_CheckConditionForBondingGroup );

            CORBA::String_var transportState;
            try
            {
                transportState = aCassette->getTransportState();
            }
            CATCH_AND_RAISE_EXCEPTIONS( PosCassette::getTransportState );

            PPT_METHODTRACE_V2( "", "transportState", transportState );
            if ( CIMFWStrCmp( transportState, SP_TransState_EquipmentIn ) == 0 )
            {
                PPT_METHODTRACE_V1( "", "CIMFWStrCmp( transportState, SP_TransState_EquipmentIn ) == 0" );
                PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForBondingGroup_out,
                                     MSG_INVALID_CAST_XFERSTAT, RC_INVALID_CAST_XFERSTAT,
                                     transportState, strCassette_CheckConditionForBondingGroup_in.cassetteIDSeq[castCnt].identifier );
                return RC_INVALID_CAST_XFERSTAT;
            }

            /*------------------------------*/
            /*   Get TransferReserveState   */
            /*------------------------------*/
            PPT_METHODTRACE_V1( "", "Get TransferReserveState" );

            CORBA::Boolean transferReserved;
            try
            {
                transferReserved = aCassette->isReserved();
            }
            CATCH_AND_RAISE_EXCEPTIONS( PosCassette::isReserved );

            PPT_METHODTRACE_V2( "", "transferReserved", ( transferReserved ? "TRUE" : "FALSE" ) );
            if ( transferReserved )
            {
                CORBA::String_var userID;
                try
                {
                    PosPerson_var aUser = aCassette->reservedBy();
                    userID = aUser->getIdentifier();
                }
                CATCH_AND_RAISE_EXCEPTIONS( PosCassette::reservedBy );

                PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForBondingGroup_out,
                                     MSG_ALREADY_XFER_RESERVED_CST, RC_ALREADY_XFER_RESERVED_CST,
                                     strCassette_CheckConditionForBondingGroup_in.cassetteIDSeq[castCnt].identifier,
                                     userID );
                return RC_ALREADY_XFER_RESERVED_CST;
            }

            /*----------------------------------------------*/
            /*   Get and Check Cassette's Dispatch Status   */
            /*----------------------------------------------*/
            PPT_METHODTRACE_V1("", "Get Cassette's Dispatch Status");

            CORBA::Boolean dispatchReserved;
            try
            {
                dispatchReserved = aCassette->isDispatchReserved();
            }
            CATCH_AND_RAISE_EXCEPTIONS( PosCassette::isDispatchtReserved );

            if ( dispatchReserved )
            {
                PPT_METHODTRACE_V1( "", "Cassette is dispatchReserved." );
                SET_MSG_RC( strCassette_CheckConditionForBondingGroup_out,
                            MSG_ALREADY_DISPATCH_RESVED_CST, RC_ALREADY_DISPATCH_RESVED_CST );

                return RC_ALREADY_DISPATCH_RESVED_CST;
            }

            PosControlJob_var aControlJob;
            try
            {
                aControlJob = aCassette->getControlJob();
            }
            CATCH_AND_RAISE_EXCEPTIONS( PosCassette::getControlJob );

            if ( !CORBA::is_nil( aControlJob ) )
            {
                PPT_METHODTRACE_V1( "", "!CORBA::is_nil( aControlJob )" );
                SET_MSG_RC( strCassette_CheckConditionForBondingGroup_out,
                            MSG_CAST_CTRLJOBID_FILLED, RC_CAST_CTRLJOBID_FILLED );
                return RC_CAST_CTRLJOBID_FILLED;
            }

            /*-------------------------------------*/
            /*   Get and Check Cassette's Status   */
            /*-------------------------------------*/
            CORBA::String_var cassetteState;
            try
            {
                cassetteState = aCassette->getDurableState();
            }
            CATCH_AND_RAISE_EXCEPTIONS( PosCassette::getCurrentState );

            PPT_METHODTRACE_V2( "", "cassetteState", cassetteState );
            if ( 0 == CIMFWStrCmp( cassetteState, CIMFW_Durable_Available ) ||
                 0 == CIMFWStrCmp( cassetteState, CIMFW_Durable_InUse ) )
            {
                PPT_METHODTRACE_V1( "", "cassetteState = CIMFW_Durable_Available or CIMFW_Durable_InUse" );
            }
            else
            {
                PPT_METHODTRACE_V1( "","return RC_INVALID_CAST_STAT" );
                PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForBondingGroup_out,
                                     MSG_INVALID_CAST_STAT, RC_INVALID_CAST_STAT,
                                     cassetteState,
                                     strCassette_CheckConditionForBondingGroup_in.cassetteIDSeq[castCnt].identifier );
                return RC_INVALID_CAST_STAT;
            }
        } //end of [castCnt] cassette

        /*----------------------*/
        /*                      */
        /*   Return to Caller   */
        /*                      */
        /*----------------------*/
        PPT_METHODTRACE_EXIT( "PPTManager_i::cassette_CheckConditionForBondingGroup" );
        return RC_OK;

    }
    CATCH_GLOBAL_EXCEPTIONS( strCassette_CheckConditionForBondingGroup_out, cassette_CheckConditionForBondingGroup, methodName );
}
