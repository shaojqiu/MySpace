//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
//
// SiView
// Name: bondingMap_waferStack_Make.cpp
//

#include "pptmgr.hpp"
#include "pwafer.hh"
#include "pperson.hh"

// Class: PPTManager
//
//[Object Function Name]: long   bondingMap_waferStack_Make
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2010-04-13 DSIV00001830 R.Iriguchi     Wafer Stacking Support
//
//[Function Description]:
//This function makes wafers in the Bonding Map Stacked state.
//
//[Input Parameters]:
//  const pptObjCommonIn&                       strObjCommonIn
//  const objbondingMap_waferStack_Make_in&     strBondingMap_waferStack_Make_in
//
//  //InParameter of bondingMap_waferStack_Make
//  typedef struct objBondingMap_waferStack_Make_in_struct {
//      pptBondingMapInfoSequence           strBondingMapInfoSeq;
//      any                                 siInfo;
//  } objBondingMap_waferStack_Make_in;
//
//[Output Parameters]:
//  objbondingMap_waferStack_Make_out&          strBondingMap_waferStack_Make_out
//
//  //Result of bondingMap_waferStack_Make
//  typedef objBase_out objBondingMap_waferStack_Make_out;
//
//[Return Value]:
//
//  Return Code                          Message ID
//  -----------------------------------  --------------------------------------------------
//  RC_OK                                MSG_OK
//
// Exception:
//
// Pseudo code:
//
CORBA::Long  PPTManager_i::bondingMap_waferStack_Make(
    objBondingMap_waferStack_Make_out&          strBondingMap_waferStack_Make_out,
    const pptObjCommonIn &                      strObjCommonIn,
    const objBondingMap_waferStack_Make_in&     strBondingMap_waferStack_Make_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY( "PPTManager_i::bondingMap_waferStack_Make" );
        const pptBondingMapInfoSequence& strBondingMapInfoSeq = strBondingMap_waferStack_Make_in.strBondingMapInfoSeq;
        const CORBA::Long mapLen = strBondingMapInfoSeq.length();

        PosPerson_var aPerson;
        PPT_GET_PERSON_FROM_USERID( aPerson,
                                    strObjCommonIn.strUser.userID,
                                    strBondingMap_waferStack_Make_out,
                                    bondingMap_waferStack_Make );

        //----------------------------------------------------------------------
        // Check Inputed Bonding Map
        //----------------------------------------------------------------------
        for ( CORBA::Long mapCnt = 0; mapCnt < mapLen; mapCnt++ )
        {
            PPT_METHODTRACE_V2( "", "mapCnt", mapCnt );

            PosWafer_var aBaseWafer, aTopWafer;
            //----------------------------------------------------------------------
            // Get Stacked Wafers
            //----------------------------------------------------------------------
            PPT_CONVERT_WAFERID_TO_WAFER_OR( aBaseWafer, strBondingMapInfoSeq[mapCnt].baseWaferID,
                                             strBondingMap_waferStack_Make_out,
                                             bondingMap_waferStack_Make );

            PPT_CONVERT_WAFERID_TO_WAFER_OR( aTopWafer, strBondingMapInfoSeq[mapCnt].actualTopWaferID,
                                             strBondingMap_waferStack_Make_out,
                                             bondingMap_waferStack_Make );

            PosStackedWaferSequence_var baseStackedWaferSeq, topStackedWaferSeq;
            try
            {
                baseStackedWaferSeq = aBaseWafer->allStackedWafers();
                topStackedWaferSeq  = aTopWafer->allStackedWafers();
            }
            CATCH_AND_RAISE_EXCEPTIONS( PosWafer::allStackedWafers );

            const CORBA::Long baseStackedWaferLen = baseStackedWaferSeq ? baseStackedWaferSeq->length() : 0;
            const CORBA::Long topStackedWaferLen  = topStackedWaferSeq  ? topStackedWaferSeq->length()  : 0;

            PPT_METHODTRACE_V2( "", "baseStackedWaferLen", baseStackedWaferLen );
            PPT_METHODTRACE_V2( "", "topStackedWaferLen", topStackedWaferLen );

            CORBA::Long waferCnt;
            //----------------------------------------------------------------------
            // Get Max Material Offset
            //----------------------------------------------------------------------
            CORBA::Long baseMaxMaterialOffset = 0;
            CORBA::Long topMaxMaterialOffset = 0;
            for ( waferCnt = 0; waferCnt < baseStackedWaferLen; waferCnt++ )
            {
                if ( baseMaxMaterialOffset < (*baseStackedWaferSeq)[waferCnt].materialOffset )
                {
                    baseMaxMaterialOffset = (*baseStackedWaferSeq)[waferCnt].materialOffset;
                }
            }
            for ( waferCnt = 0; waferCnt < topStackedWaferLen; waferCnt++ )
            {
                if ( topMaxMaterialOffset < (*topStackedWaferSeq)[waferCnt].materialOffset )
                {
                    topMaxMaterialOffset = (*topStackedWaferSeq)[waferCnt].materialOffset;
                }
            }

            PPT_METHODTRACE_V2( "", "baseMaxMaterialOffset", baseMaxMaterialOffset );
            PPT_METHODTRACE_V2( "", "topMaxMaterialOffset", topMaxMaterialOffset );

            //----------------------------------------------------------------------
            // Set Stacked Wafer Information
            //----------------------------------------------------------------------
            posStackedWafer aPosStackedWafer;
            PPT_SET_OBJECT_IDENTIFIER( aPosStackedWafer.topWaferID, aTopWafer,
                                       strBondingMap_waferStack_Make_out,
                                       bondingMap_waferStack_Make,
                                       PosWafer );

            try
            {
                aPosStackedWafer.topAliasWaferName  = aTopWafer->getAliasWaferName();
            }
            CATCH_AND_RAISE_EXCEPTIONS( PosWafer::getAliasWaferName );

            PPT_METHODTRACE_V2( "", "topAliasWaferName", aPosStackedWafer.topAliasWaferName );

            aPosStackedWafer.topLotID           = strBondingMapInfoSeq[mapCnt].actualTopLotID;
            aPosStackedWafer.stackedTimeStamp   = strBondingMapInfoSeq[mapCnt].processCompleteTime;
            aPosStackedWafer.fabID              = CIMFWStrDup( getenv( SP_FAB_ID ) );
            aPosStackedWafer.materialOffset     = baseMaxMaterialOffset + topMaxMaterialOffset + 1;

            for ( waferCnt = 0; waferCnt < topStackedWaferLen; waferCnt++ )
            {
                (*topStackedWaferSeq)[waferCnt].materialOffset = aPosStackedWafer.materialOffset - (*topStackedWaferSeq)[waferCnt].materialOffset;
            }

            if ( CIMFWStrCmp( strBondingMapInfoSeq[mapCnt].actualTopBondingSide, SP_BondingSide_Bottom ) == 0 )
            {
                //----------------------------------------------------------------------
                // Handle Alias Wafer Name
                //----------------------------------------------------------------------
                try
                {
                    aPosStackedWafer.previousAliasWaferName = aBaseWafer->getAliasWaferName();
                }
                CATCH_AND_RAISE_EXCEPTIONS( PosWafer::getAliasWaferName );

                PPT_METHODTRACE_V2( "", "previousAliasWaferName", aPosStackedWafer.previousAliasWaferName );

                try
                {
                    aBaseWafer->setAliasWaferName( aPosStackedWafer.topAliasWaferName );
                }
                CATCH_AND_RAISE_EXCEPTIONS( PosWafer::setAliasWaferName );

                //----------------------------------------------------------------------
                // Negate All Material Offset
                //----------------------------------------------------------------------
                aPosStackedWafer.materialOffset = -aPosStackedWafer.materialOffset;

                for ( waferCnt = 0; waferCnt < baseStackedWaferLen; waferCnt++ )
                {
                    try
                    {
                        aBaseWafer->removeStackedWafer( (*baseStackedWaferSeq)[waferCnt] );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS( PosWafer::removeStackedWafer );

                    (*baseStackedWaferSeq)[waferCnt].materialOffset = -(*baseStackedWaferSeq)[waferCnt].materialOffset;

                    PPT_METHODTRACE_V3( "", "addStackedWafer",
                                        (*baseStackedWaferSeq)[waferCnt].topWaferID.identifier,
                                        (*baseStackedWaferSeq)[waferCnt].materialOffset );
                    try
                    {
                        aBaseWafer->addStackedWafer( (*baseStackedWaferSeq)[waferCnt] );
                    }
                    CATCH_AND_RAISE_EXCEPTIONS( PosWafer::addStackedWafer );
                }

                for ( waferCnt = 0; waferCnt < topStackedWaferLen; waferCnt++ )
                {
                    (*topStackedWaferSeq)[waferCnt].materialOffset = -(*topStackedWaferSeq)[waferCnt].materialOffset;
                }
            }

            try
            {
                PPT_METHODTRACE_V3( "", "addStackedWafer",
                                    aPosStackedWafer.topWaferID.identifier,
                                    aPosStackedWafer.materialOffset );
                aBaseWafer->addStackedWafer( aPosStackedWafer );

                for ( waferCnt = 0; waferCnt < topStackedWaferLen; waferCnt++ )
                {
                    PPT_METHODTRACE_V3( "", "addStackedWafer",
                                        (*topStackedWaferSeq)[waferCnt].topWaferID.identifier,
                                        (*topStackedWaferSeq)[waferCnt].materialOffset );
                    aBaseWafer->addStackedWafer( (*topStackedWaferSeq)[waferCnt] );
                }
            }
            CATCH_AND_RAISE_EXCEPTIONS( PosWafer::addStackedWafer );

            //----------------------------------------------------------------------
            // Make Stacked
            //----------------------------------------------------------------------
            try
            {
                aTopWafer->makeStacked();
            }
            CATCH_AND_RAISE_EXCEPTIONS( PosWafer::makeStacked );

            //--------------------------------------------------
            // Set Last Claimed Record
            //--------------------------------------------------
            try
            {
                aBaseWafer->setLastClaimedTimeStamp( strObjCommonIn.strTimeStamp.reportTimeStamp );
                aTopWafer->setLastClaimedTimeStamp( strObjCommonIn.strTimeStamp.reportTimeStamp );
            }
            CATCH_AND_RAISE_EXCEPTIONS( PosLot::setLastClaimedTimeStamp )

            try
            {
                aBaseWafer->setLastClaimedPerson( aPerson );
                aTopWafer->setLastClaimedPerson( aPerson );
            }
            CATCH_AND_RAISE_EXCEPTIONS( PosLot::setLastClaimedPerson )
        }

        // Return to Caller
        PPT_METHODTRACE_EXIT( "PPTManager_i::bondingMap_waferStack_Make" );
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS( strBondingMap_waferStack_Make_out, bondingMap_waferStack_Make, methodName )
}

