#ifndef lint
static char *sccsid =  "@(#) 1.5 superpos/src/spppt/source/posppt/pptmgr/objmethd/APCMgr_SendDerivedDataRequest.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 2/13/08 17:23:20 [ 2/13/08 17:23:21 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: APCMgr_SendDerivedDataRequest.cpp
//

#include "pptmgr.hpp"
#include "mqsm.hh"
#include "plot.hh"     //DSN000015229
#include "ppcope.hh"   //DSN000015229


// Class: PPTManager
//
// Service: APCMgr_SendDerivedDataRequest()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2004/07/14 D51M0000 M.Murata       Initial Release (R51M)
// 2004/10/13 D6000049 M.Mori         APC Interface Spec-B Function Enhancement
// 2004/10/22 D6000035 M.Murata       The return code of TIMEOUT from MQH is handled.
// 2004/11/17 D6000025 K.Murakami     Add SP_STRING_TO_OBJECT for eBroker
// 2004/11/18 D6000025 K.Murakami     Change CORBA::IT_chooseDefaultEnv() to SP_CORBAENV_DEFENV
// 2005/05/17 D6000275 M.Murata       Change variable for externalServerList.
// 2005/05/17 D6000314 M.Murata       Change variable for externalServerList.
// 2007/04/20 D9000001 M.Murata       64bit support.
// 2008/01/17 D9000059 H.Hotta        External System Interface Security Control
// 2008/02/13 P9000198 M.Ishino       Fix the extension logic of SequenceLength is wrong.
//
// Date        Level         Author         Note
// ----------  ------------  -------------  -------------------------------------------
// 2010/10/28  DSIV00002543  S.Yamamoto     Improvement of reasonText message.
// 2011/09/06  DSN000015229  M.Ogawa        Advanced Wafer Level Control
//
// [Function Description]:
// 
// [Input Parameters]:
//    in    pptObjCommonIn                          strObjCommonIn
//    in    objectIdentifier                        equipmentID
//    in    objectIdentifier                        controlJobID
//    in    pptStartCassetteSequence                strStartCassette
//
// [Output Parameters]:
//
//    out   objAPCMgr_SendDerivedDataRequest_out    strAPCMgr_SendDerivedDataRequest_out
//
//    typedef struct objAPCMgr_SendDerivedDataRequest_out_struct {
//        pptRetCode                                strResult;
//        pptAPCDerivedDataResponseSequence         strAPCDerivedDataResponseList;
//        any                                       siInfo;
//    } objAPCMgr_SendDerivedDataRequest_out;
//
//   typedef struct pptStartCassette_struct {
//       long                          loadSequenceNumber;
//       objectIdentifier              cassetteID;
//       string                        loadPurposeType;
//       objectIdentifier              loadPortID;
//       objectIdentifier              unloadPortID;
//       pptLotInCassetteSequence      strLotInCassette;
//       any siInfo;
//   } pptStartCassette;
//
//  typedef sequence <pptStartCassette> pptStartCassetteSequence;

// [Return Value]:
//
//  Return Code                 Messsage ID
//  -------------------------   --------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_APC_DERIVEDDATA_ERROR    MSG_APC_DERIVEDDATA_ERROR
//  RC_APC_SERVER_NIL_OBJ       MSG_APC_SERVER_NIL_OBJ
//

CORBA::Long PPTManager_i:: APCMgr_SendDerivedDataRequest__120 (
            objAPCMgr_SendDerivedDataRequest__120_out& strAPCMgr_SendDerivedDataRequest_out,
            const pptObjCommonIn&                      strObjCommonIn,
            const objectIdentifier&                    equipmentID,
            const objectIdentifier&                    controlJobID,
            const pptStartCassetteSequence&            strStartCassette,
            const char*                                requestType )
{

    CORBA::Long rc    = RC_OK;
    char * methodName = NULL;

    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i:: APCMgr_SendDerivedDataRequest");

        //----------------------------------
        //   Get APCRunTimeCapability
        //----------------------------------
        PPT_METHODTRACE_V1("", "call controlJob_APCRunTimeCapability_GetDR");
        objControlJob_APCRunTimeCapability_GetDR_out strControlJob_APCRunTimeCapability_GetDR_out;
        rc = controlJob_APCRunTimeCapability_GetDR ( strControlJob_APCRunTimeCapability_GetDR_out,
                                                     strObjCommonIn,
                                                     controlJobID);

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "controlJob_APCRunTimeCapability_GetDR() != RC_OK");
            strAPCMgr_SendDerivedDataRequest_out.strResult = strControlJob_APCRunTimeCapability_GetDR_out.strResult;
            return( rc );
        }

        PPT_METHODTRACE_V1("", "controlJob_APCRunTimeCapability_GetDR() == RC_OK");

        CORBA::Long response_cnt = strControlJob_APCRunTimeCapability_GetDR_out.strAPCRunTimeCapabilityResponse.length();
        PPT_METHODTRACE_V2("", "strAPCRunTimeCapabilityResponse.length", response_cnt);

        //------------------------------------------------------
        //   Get SystemName from APCRunTimeCapability
        //------------------------------------------------------
        CORBA::Long apcsystem_cnt = 0;
        CORBA::Long m_len = 1000;
        stringSequence APCSystemNameList;

        APCSystemNameList.length(m_len);

        for ( CORBA::Long loop_response_cnt = 0; loop_response_cnt < response_cnt; loop_response_cnt++ )
        {
            CORBA::Long capability_cnt = strControlJob_APCRunTimeCapability_GetDR_out.strAPCRunTimeCapabilityResponse[loop_response_cnt].
                                            strAPCRunTimeCapability.length();
            PPT_METHODTRACE_V3("", "strAPCRunTimeCapability.length", capability_cnt, loop_response_cnt);

            for ( CORBA::Long loop_capability_cnt = 0; loop_capability_cnt < capability_cnt; loop_capability_cnt++ )
            {
                CORBA::Long function_cnt = strControlJob_APCRunTimeCapability_GetDR_out.strAPCRunTimeCapabilityResponse[loop_response_cnt].
                                            strAPCRunTimeCapability[loop_capability_cnt].strAPCBaseAPCSystemFunction.length();
                PPT_METHODTRACE_V3("", "strAPCBaseAPCSystemFunction.length", function_cnt, loop_capability_cnt);

                for ( CORBA::Long loop_function_cnt = 0; loop_function_cnt < function_cnt; loop_function_cnt++ )
                {
                    PPT_METHODTRACE_V2("", "loop_function_cnt =", loop_function_cnt);

                    if( CIMFWStrCmp( strControlJob_APCRunTimeCapability_GetDR_out.strAPCRunTimeCapabilityResponse[loop_response_cnt].
                                        strAPCRunTimeCapability[loop_capability_cnt].strAPCBaseAPCSystemFunction[loop_function_cnt].type, 
                                     SP_APCFunctionType_derivedData ) == 0 )
                    {
                        PPT_METHODTRACE_V1("", "type == derivedData");

                        CORBA::Long tmp_cnt = 0;
                        CORBA::Boolean systemNameFlag = FALSE;
                        for ( tmp_cnt = 0; tmp_cnt < apcsystem_cnt; tmp_cnt++ )
                        {
                            if ( CIMFWStrCmp( APCSystemNameList[tmp_cnt], strControlJob_APCRunTimeCapability_GetDR_out.strAPCRunTimeCapabilityResponse[loop_response_cnt].
                                                                            strAPCBaseIdentification.systemName ) == 0 )
                            {
                                 PPT_METHODTRACE_V3("", "Duplication of systemName", APCSystemNameList[tmp_cnt], tmp_cnt);
                                 systemNameFlag = TRUE;
                                 break;
                            }
                        }

                        if ( systemNameFlag == FALSE )
                        {
                            PPT_METHODTRACE_V1("", "type == derivedData");
                            APCSystemNameList[apcsystem_cnt] = 
                                CIMFWStrDup( strControlJob_APCRunTimeCapability_GetDR_out.strAPCRunTimeCapabilityResponse[loop_response_cnt].strAPCBaseIdentification.systemName );

                            apcsystem_cnt++;    //P9000198

                            if( apcsystem_cnt >= m_len )
                            {
                                m_len = m_len + 500;
                                APCSystemNameList.length(m_len);
                            }

//P9000198                            apcsystem_cnt++;
                        }
                    } //if type == derivedData
                } //for strAPCBaseAPCSystemFunction
            } //for strAPCRunTimeCapability
        } //for strAPCRunTimeCapabilityResponse

        APCSystemNameList.length(apcsystem_cnt);
        PPT_METHODTRACE_V2("", "APCSystemNameList.length()", apcsystem_cnt);

        //------------------------------------------------------
        //   Get SystemName from strStartCassette
        //------------------------------------------------------
        CORBA::Long systemname_cnt = 0;
        stringSequence systemNameList;
        systemNameList.length(apcsystem_cnt);

//DSN000015229          pptAPCDerivedDataResponseSequence strAPCDerivedDataResponseList;
        pptAPCDerivedDataResponseSequence__120 strAPCDerivedDataResponseList;   //DSN000015229

        strAPCDerivedDataResponseList.length(apcsystem_cnt);
        CORBA::Long derived_idx = 0;

        for ( CORBA::Long apcsysidx = 0; apcsysidx < apcsystem_cnt; apcsysidx++ )
        {
            PPT_METHODTRACE_V3("", "APCSystemNameList", APCSystemNameList[apcsysidx], apcsysidx);
            CORBA::Boolean systemNameAddFlag = FALSE;           //DSN000015229

            CORBA::Long lotderivedLen = 0;
            strAPCDerivedDataResponseList[apcsysidx].strAPCLotDerivedDataList.length(lotderivedLen);

            CORBA::Long sLen = strStartCassette.length();
            PPT_METHODTRACE_V2("", "strStartCassette.length()", sLen);

            for ( CORBA::Long i = 0; i < sLen; i++ )
            {
                PPT_METHODTRACE_V2("", "  startCassette", strStartCassette[i].cassetteID.identifier);

                CORBA::Long liLen = strStartCassette[i].strLotInCassette.length();
                PPT_METHODTRACE_V2("", "  strLotInCassette.length()", liLen);

                for ( CORBA::Long j = 0; j < liLen; j++ )
                {
                    PPT_METHODTRACE_V2("", "    startLot", strStartCassette[i].strLotInCassette[j].lotID.identifier);
                    //
                    // Skip if operationStartFlag = FALSE
                    //
                    if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                    {
                        PPT_METHODTRACE_V1("", "    operationStartFlag == FALSE");
                        continue;
                    }

//DSN000015229 Add Start
                    //------------------------------------------
                    // Current PO or Previous PO ?
                    //------------------------------------------
                    objLot_CheckConditionForPO_out strLot_CheckConditionForPO_out;
                    rc = lot_CheckConditionForPO( strLot_CheckConditionForPO_out, strObjCommonIn, 
                                                  strStartCassette[i].strLotInCassette[j].lotID);
                    if ( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "lot_CheckConditionForPO() != RC_OK ") ;
                        strAPCMgr_SendDerivedDataRequest_out.strResult = strLot_CheckConditionForPO_out.strResult ;
                        return( rc );
                    }

                    //---------------------------------------------
                    // Get PosLot
                    //---------------------------------------------
                    PosLot_var aLot;
                    PPT_CONVERT_LOTID_TO_LOT_OR( aLot, strStartCassette[i].strLotInCassette[j].lotID, strAPCMgr_SendDerivedDataRequest_out, APCMgr_SendDerivedDataRequest )

                    PosProcessOperation_var aProcessOperation;
                    if ( strLot_CheckConditionForPO_out.currentPOFlag  == TRUE )
                    {
                        //--------------------------------------------------------------------------
                        // Get PO from Current Operation.                                           
                        //--------------------------------------------------------------------------
                        PPT_METHODTRACE_V1("", "Get PO from the current Operation.")

                        try
                        {
                            ProcessOperation_var aTmpProcessOperation = aLot->getProcessOperation();
                            aProcessOperation = PosProcessOperation::_narrow(aTmpProcessOperation);
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation);
                    }
                    else
                    {
                        //--------------------------------------------------------------------------
                        // Get PO from Previous Operation.
                        //--------------------------------------------------------------------------
                        PPT_METHODTRACE_V1("", "Get PO from the previous Operation.")

                        try
                        {
                            ProcessOperation_var aTmpProcessOperation = aLot->getPreviousProcessOperation();
                            aProcessOperation = PosProcessOperation::_narrow(aTmpProcessOperation);
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getPreviousProcessOperation);
                    }

                    if ( CORBA::is_nil(aProcessOperation) )
                    {
                        PPT_METHODTRACE_V1("", "CORBA::is_nil(aProcessOperation)");

                        PPT_SET_MSG_RC_KEY2( strAPCMgr_SendDerivedDataRequest_out,
                                             MSG_NOT_FOUND_PO, RC_NOT_FOUND_PO, "*****",
                                             strStartCassette[i].strLotInCassette[j].lotID.identifier);
                        return RC_NOT_FOUND_PO;
                    }

                    PosProcessWaferSequence_var strProcessWaferSeq;
                    try
                    {
                        strProcessWaferSeq = aProcessOperation->getProcessWafers();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getProcessWafers);
                    CORBA::ULong waferLen = strProcessWaferSeq->length();
//DSN000015229 Add End
                    CORBA::Boolean lotAddFlag = FALSE;
                    CORBA::Long derivedLen = 0;
                    CORBA::Long dcDefLen = strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef.length();
                    PPT_METHODTRACE_V2("", "    strStartRecipe.strDCDef.length()", dcDefLen);
//DSN000015229 Add Start
                    CORBA::ULong itemCount = 0;
                    CORBA::ULong itemIncreaseLen = 50;
                    pptAPCDerivedDataSequence__120  strAPCDerivedDataList;
                    strAPCDerivedDataList.length(itemIncreaseLen);
//DSN000015229 Add End

                    for ( CORBA::Long k = 0; k < dcDefLen; k++ )
                    {
                        CORBA::Long dcItemLen = strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem.length();
                        PPT_METHODTRACE_V2("", "strDCItem.length()", dcItemLen);

//DSN000015229                          CORBA::Boolean systemNameAddFlag = FALSE;
                        for ( CORBA::Long l = 0; l < dcItemLen; l++ )
                        {
                            PPT_METHODTRACE_V3("", "strDCItem[l].itemType", strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[l].itemType, l);
                            if ( CIMFWStrCmp ( strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[l].itemType, SP_DCDef_Item_UserFunction ) != 0 )
                            {
                                PPT_METHODTRACE_V1("", "strDCItem[l].itemType != UserFunction");
                                continue;
                            }

                            PPT_METHODTRACE_V3("", "strDCItem[l].calculationType", strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[l].calculationType, l);
                            //------------------------------------------------------
                            //   Check calculationType
                            //------------------------------------------------------
                            if ( CIMFWStrCmp( strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[l].calculationType,
                                              APCSystemNameList[apcsysidx] ) == 0 )
                            {
                                PPT_METHODTRACE_V1("", "strDCItem[l].calculationType == APCSystemNameList[apcsysidx]");
//DSN000015229 Add Start
                                pptDCItem curDCItem = strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[l];
                                CORBA::String_var processJobID = CIMFWStrDup ("");
                                if ( 0 == CIMFWStrCmp( SP_DCDef_Meas_PJ, curDCItem.measurementType ) )
                                {
                                    PPT_METHODTRACE_V1("", "measurementType = SP_DCDef_Meas_PJ")

                                    for (CORBA::ULong m=0; m<waferLen; m++)
                                    {
                                        PPT_METHODTRACE_V2("", "m = ", m)
                                        if ( 0 == CIMFWStrCmp( curDCItem.waferPosition, strProcessWaferSeq[m].prcsJobPosition ) )
                                        {
                                            PPT_METHODTRACE_V2("", "waferPosition = ", curDCItem.waferPosition)
                                            processJobID = CIMFWStrDup(strProcessWaferSeq[m].prcsJob);
                                            break;
                                        }
                                    }
                                }
                                else if ( ( 0 == CIMFWStrCmp( SP_DCDef_Meas_PJWafer,     curDCItem.measurementType ) )
                                       || ( 0 == CIMFWStrCmp( SP_DCDef_Meas_PJWaferSite, curDCItem.measurementType ) ) )
                                {
                                    PPT_METHODTRACE_V2("", "curDCItem.measurementType = ", curDCItem.measurementType)
                                    for (CORBA::ULong m=0; m<waferLen; m++)
                                    {
                                        PPT_METHODTRACE_V2("", "m = ", m)
                                        if ( 0 == CIMFWStrCmp( curDCItem.waferID.identifier, strProcessWaferSeq[m].waferID ) )
                                        {
                                            PPT_METHODTRACE_V2("", "waferID = ", curDCItem.waferID.identifier)
                                            processJobID = CIMFWStrDup(strProcessWaferSeq[m].prcsJob);
                                            break;
                                        }
                                    }
                                }

                                CORBA::Boolean bFoundItemFlag = FALSE;
                                for (CORBA::ULong iCnt1 = 0; iCnt1 < itemCount; iCnt1++)
                                {
                                    PPT_METHODTRACE_V2("", "iCnt1 = ", iCnt1)
                                    if ( ( 0 == CIMFWStrCmp( strAPCDerivedDataList[iCnt1].name,            curDCItem.dataCollectionItemName ) )
                                      && ( 0 == CIMFWStrCmp( strAPCDerivedDataList[iCnt1].measurementType, curDCItem.measurementType ) ) )
                                    {
                                        PPT_METHODTRACE_V2("", "Found Item = ", strAPCDerivedDataList[iCnt1].name)
                                        bFoundItemFlag = TRUE;
                                        // found item, add item to collectedData
                                        CORBA::ULong strAPCCollectedDataSeqLen = strAPCDerivedDataList[iCnt1].strAPCCollectedDataSeq.length();
                                        strAPCDerivedDataList[iCnt1].strAPCCollectedDataSeq.length(strAPCCollectedDataSeqLen+1);
                                        strAPCDerivedDataList[iCnt1].strAPCCollectedDataSeq[strAPCCollectedDataSeqLen].waferID = curDCItem.waferID;
                                        strAPCDerivedDataList[iCnt1].strAPCCollectedDataSeq[strAPCCollectedDataSeqLen].value = curDCItem.dataValue;
                                        if ( ( 0 == CIMFWStrCmp( SP_DCDef_Meas_PJ,          curDCItem.measurementType ) )
                                          || ( 0 == CIMFWStrCmp( SP_DCDef_Meas_PJWafer,     curDCItem.measurementType ) )
                                          || ( 0 == CIMFWStrCmp( SP_DCDef_Meas_PJWaferSite, curDCItem.measurementType ) ) )
                                        {
                                            PPT_METHODTRACE_V2("", "curDCItem.measurementType = ", curDCItem.measurementType)
                                            strAPCDerivedDataList[iCnt1].strAPCCollectedDataSeq[strAPCCollectedDataSeqLen].processJobID = processJobID;
                                        }
                                        else
                                        {
                                            PPT_METHODTRACE_V2("", "curDCItem.measurementType = ", curDCItem.measurementType)
                                            strAPCDerivedDataList[iCnt1].strAPCCollectedDataSeq[strAPCCollectedDataSeqLen].processJobID = CIMFWStrDup ("");
                                        }
                                        break;
                                    }
                                }
                                if (bFoundItemFlag == FALSE)
                                {
                                    if (itemCount >= itemIncreaseLen)
                                    {
                                        itemIncreaseLen = itemIncreaseLen + 50;
                                        strAPCDerivedDataList.length(itemIncreaseLen);
                                        PPT_METHODTRACE_V2("", "itemIncreaseLen = ", itemIncreaseLen)
                                    }
                                    
                                    // create new strAPCDerivedDataList[itemCount]
                                    strAPCDerivedDataList[itemCount].supported = CIMFWStrDup("false");
                                    strAPCDerivedDataList[itemCount].name = curDCItem.dataCollectionItemName;
                                    strAPCDerivedDataList[itemCount].sitePosition = curDCItem.sitePosition;
                                    strAPCDerivedDataList[itemCount].measurementType = curDCItem.measurementType;
                                    strAPCDerivedDataList[itemCount].strAPCCollectedDataSeq.length(1);
                                    strAPCDerivedDataList[itemCount].strAPCCollectedDataSeq[0].waferID = curDCItem.waferID;
                                    strAPCDerivedDataList[itemCount].strAPCCollectedDataSeq[0].value = curDCItem.dataValue;
                                    if ( ( 0 == CIMFWStrCmp( SP_DCDef_Meas_PJ,          curDCItem.measurementType ) )
                                      || ( 0 == CIMFWStrCmp( SP_DCDef_Meas_PJWafer,     curDCItem.measurementType ) )
                                      || ( 0 == CIMFWStrCmp( SP_DCDef_Meas_PJWaferSite, curDCItem.measurementType ) ) )
                                    {
                                        PPT_METHODTRACE_V2("", "curDCItem.measurementType = ", curDCItem.measurementType)
                                        strAPCDerivedDataList[itemCount].strAPCCollectedDataSeq[0].processJobID = processJobID;
                                    }
                                    else
                                    {
                                        PPT_METHODTRACE_V2("", "curDCItem.measurementType = ", curDCItem.measurementType)
                                        strAPCDerivedDataList[itemCount].strAPCCollectedDataSeq[0].processJobID = CIMFWStrDup ("");
                                    }
                                    
                                    itemCount++;
                                }
//DSN000015229 Add End
                                
                                if ( systemNameAddFlag == FALSE )
                                {
                                    derived_idx = systemname_cnt;   //D6000035
                                    //------------------------------------------------------
                                    //   Set SystemName
                                    //------------------------------------------------------
                                    CORBA::Boolean  dupNameFlag = FALSE;

                                    PPT_METHODTRACE_V2("", "systemNameList.length()", systemname_cnt);
                                    for ( CORBA::Long  sysNameIdx = 0; sysNameIdx < systemname_cnt; sysNameIdx++ )
                                    {
                                        PPT_METHODTRACE_V3("", "systemNameList[]==APCSystemNameList[]", systemNameList[sysNameIdx], APCSystemNameList[apcsysidx]);
                                        if ( CIMFWStrCmp(systemNameList[sysNameIdx], APCSystemNameList[apcsysidx]) == 0 )
                                        {
                                            PPT_METHODTRACE_V3("", "Duplication of systemName", systemNameList[sysNameIdx], sysNameIdx);
                                            derived_idx = sysNameIdx;   //D6000035
                                            dupNameFlag = TRUE;
                                            break;
                                        }
                                    }

                                    if ( dupNameFlag == FALSE )
                                    {
                                        PPT_METHODTRACE_V1("", "set systemName");
                                        systemNameList[systemname_cnt] = CIMFWStrDup(APCSystemNameList[apcsysidx]);
                                        systemname_cnt++;
                                        strAPCDerivedDataResponseList.length(systemname_cnt);
                                        systemNameAddFlag = TRUE;
                                    }
                                }

                                //------------------------------------------------------
                                //   Set APCDerivedDataResponseList
                                //------------------------------------------------------
                                if ( lotAddFlag == FALSE )
                                {
                                    lotderivedLen = strAPCDerivedDataResponseList[derived_idx].strAPCLotDerivedDataList.length();
                                    PPT_METHODTRACE_V2("", "strAPCLotDerivedDataList.length()", lotderivedLen);
                                    strAPCDerivedDataResponseList[derived_idx].strAPCLotDerivedDataList.length(lotderivedLen+1);
                                    strAPCDerivedDataResponseList[derived_idx].strAPCLotDerivedDataList[lotderivedLen].lotID =
                                        CIMFWStrDup(strStartCassette[i].strLotInCassette[j].lotID.identifier);
                                    PPT_METHODTRACE_V2("", "set strAPCLotDerivedDataList[].lotID", strAPCDerivedDataResponseList[derived_idx].strAPCLotDerivedDataList[lotderivedLen].lotID);

                                    lotAddFlag = TRUE;
                                }

//DSN000015229                                strAPCDerivedDataResponseList[derived_idx].strAPCLotDerivedDataList[lotderivedLen].strAPCDerivedDataList.length(derivedLen+1);
//DSN000015229                                strAPCDerivedDataResponseList[derived_idx].strAPCLotDerivedDataList[lotderivedLen].strAPCDerivedDataList[derivedLen].name = 
//DSN000015229                                    CIMFWStrDup(strStartCassette[i].strLotInCassette[j].strStartRecipe.strDCDef[k].strDCItem[l].dataCollectionItemName);
//DSN000015229                                strAPCDerivedDataResponseList[derived_idx].strAPCLotDerivedDataList[lotderivedLen].strAPCDerivedDataList[derivedLen].supported = CIMFWStrDup("false");
//DSN000015229                                strAPCDerivedDataResponseList[derived_idx].strAPCLotDerivedDataList[lotderivedLen].strAPCDerivedDataList[derivedLen].value = CIMFWStrDup("");
//DSN000015229                                PPT_METHODTRACE_V3("", "strAPCLotDerivedDataList[].strAPCDerivedDataList[]", lotderivedLen, derivedLen);
//DSN000015229                                derivedLen++;
                            } //if calculationType == APCSystemNameList[]

                        } //for strDCItem
                    } //for strStartRecipe.strDCDef
//DSN000015229 Add Start
                    PPT_METHODTRACE_V2("", "itemCount = ", itemCount)
                    strAPCDerivedDataList.length(itemCount);
                    if (TRUE == lotAddFlag)
                    {
                        PPT_METHODTRACE_V1("", "TRUE == lotAddFlag")
                        CORBA::ULong lastLotIdx = strAPCDerivedDataResponseList[derived_idx].strAPCLotDerivedDataList.length();
                        strAPCDerivedDataResponseList[derived_idx].strAPCLotDerivedDataList[lastLotIdx-1].strAPCDerivedDataList = strAPCDerivedDataList;
                    }
//DSN000015229 Add End
                } // for strLotInCassette
            } //for strStartCassette
        } // for APCSystemNameList

        systemNameList.length(systemname_cnt);
        strAPCDerivedDataResponseList.length(systemname_cnt);       //DSN000015229
        PPT_METHODTRACE_V2("", "systemNameList.length()", systemname_cnt);

        if ( systemname_cnt == 0 )
        {
            PPT_METHODTRACE_V1("", "systemname_cnt = 0");
            strAPCMgr_SendDerivedDataRequest_out.strAPCDerivedDataResponseList.length(0);
            SET_MSG_RC(strAPCMgr_SendDerivedDataRequest_out, MSG_OK, RC_OK);
            PPT_METHODTRACE_EXIT("PPTManager_i:: APCMgr_SendDerivedDataRequest");
            return ( RC_OK );
        }

//D6000035 Add Start
        //----------------------------------------------
        //   Set return strAPCDerivedDataResponseList
        //----------------------------------------------
        strAPCMgr_SendDerivedDataRequest_out.strAPCDerivedDataResponseList = strAPCDerivedDataResponseList;
//D6000035 Add End

        //---------------------
        //   Get Server Name
        //---------------------
        PPT_METHODTRACE_V1("", "Get Server Name");
        CORBA::String_var tmpAPCServerName = CIMFWStrDup(getenv(SP_APC_SERVER_NAME));
//D9000001        char* APCServerName = CORBA::string_alloc( CIMFWStrLen(tmpAPCServerName)+1 );
        char* APCServerName = CORBA::string_alloc( (CORBA::ULong) CIMFWStrLen(tmpAPCServerName)+1 );//D9000001
        CORBA::String_var tmpStr = APCServerName;
        if ( NULL != APCServerName )
        {
            APCServerName[0] = NULL;
        }
        if(strstr(tmpAPCServerName, ":") == NULL) 
        {
            CIMFWStrCpy(APCServerName, ":");
            CIMFWStrCat(APCServerName, tmpAPCServerName);
        }
        else
        {
            CIMFWStrCpy(APCServerName, tmpAPCServerName);
        }

        //-------------------
        //   Get Host Name
        //-------------------
        PPT_METHODTRACE_V1("", "Get Host Name");
        CORBA::String_var APCHostName;
        APCHostName = CIMFWStrDup(getenv(SP_APC_HOST_NAME));

        //--------------------
        //   Get APCManager
        //--------------------
        PPT_METHODTRACE_V1("", "Get APCManager");
        MQSvcMgr_var APCSvcMgr = MQSvcMgr::_nil();

        PPT_METHODTRACE_V1("", "call APCMgr_GetServiceManager");
        objAPCMgr_GetServiceManager_out strAPCMgr_GetServiceManager_out;
        rc = APCMgr_GetServiceManager( strAPCMgr_GetServiceManager_out,
                                       strObjCommonIn,
                                       APCServerName,
                                       APCHostName);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2("", "APCMgr_GetServiceManager() != RC_OK", rc);
            strAPCMgr_SendDerivedDataRequest_out.strResult = strAPCMgr_GetServiceManager_out.strResult;
            return( rc );
        }

#ifdef EBROKER            //D6000025
        CORBA::Object_var anObject = SP_STRING_TO_OBJECT(strAPCMgr_GetServiceManager_out.APCSvcMgr); //D6000025
#else                     //D6000025
        CORBA::Object_var anObject = CORBA::Orbix.string_to_object(strAPCMgr_GetServiceManager_out.APCSvcMgr);
#endif                    //D6000025
        APCSvcMgr = MQSvcMgr::_narrow(anObject);
        if ( CORBA::is_nil(APCSvcMgr) )
        {
            SET_MSG_RC(strAPCMgr_SendDerivedDataRequest_out, MSG_APC_SERVER_NIL_OBJ, RC_APC_SERVER_NIL_OBJ);
            return( RC_APC_SERVER_NIL_OBJ );
        }

//D6000275 Add Start
        //--------------------------------
        // Get Environment for GenIOR     
        //--------------------------------
#ifdef EBROKER                                                                 //D6000314
        tmpAPCServerName = CIMFWStrDup(APCServerName);                         //D6000314
#else                                                                          //D6000314
        tmpAPCServerName = CIMFWStrDup(getenv(SP_APCServerName_ForGenIOR));
//D6000275 Add End
#endif                                                                         //D6000314

//D9000059 add start
        // External System Interface Security Control
        pptUser tmpRequestUser = strObjCommonIn.strUser;

        CORBA::String_var configFlag = CIMFWStrDup( getenv(SP_USER_ID_PASSWORD_CONFIGRATION) );
        PPT_METHODTRACE_V2("","SP_USER_ID_PASSWORD_CONFIGRATION ", configFlag);

        if( 0 == CIMFWStrCmp( configFlag, "1" ) )
        {
            PPT_METHODTRACE_V1("","SP_USER_ID_PASSWORD_CONFIGRATION=1");

            tmpRequestUser.userID.identifier = CIMFWStrDup( getenv(SP_APC_USER_ID) );
            tmpRequestUser.password          = CIMFWStrDup( getenv(SP_APC_USER_PASSWORD) );
        }

        PPT_METHODTRACE_V2("","userID   ", tmpRequestUser.userID.identifier);
        PPT_METHODTRACE_V2("","password ", tmpRequestUser.password);
//D9000059 add end

        strAPCMgr_SendDerivedDataRequest_out.strAPCDerivedDataResponseList.length(systemname_cnt);

        for ( CORBA::Long sysCnt = 0; sysCnt < systemname_cnt; sysCnt++)
        {
            PPT_METHODTRACE_V2("", "loop for systemname", sysCnt);
            stringSequence tmpSystemNameList;
            tmpSystemNameList.length(1);
            tmpSystemNameList[0] = CIMFWStrDup(systemNameList[sysCnt]);

            //D6000025CORBA::Environment envTimeOut = CORBA::IT_chooseDefaultEnv();
            CORBA::Environment envTimeOut = SP_CORBAENV_DEFENV;    //D6000025
            CORBA::String_var timeOutValue;
            timeOutValue = CIMFWStrDup( getenv(SP_TX_Timeout_APC) );
            if ( 0 < CIMFWStrLen(timeOutValue) )
            {
                envTimeOut.timeout(atol(timeOutValue) * 1000);
            }

            //-------------------------
            //   Send Request to APC
            //-------------------------
            PPT_METHODTRACE_V1("", "Send Request to APC");

//DSN000015229            pptDerivedDataRequestResult* results = NULL;
//DSN000015229            pptDerivedDataRequestResult_var resultsVar;
            pptDerivedDataRequestResult__120* results = NULL;       //DSN000015229
            pptDerivedDataRequestResult__120_var resultsVar;        //DSN000015229

            try
            {
//D9000059                results = APCSvcMgr->TxDerivedDataRequest( strObjCommonIn.strUser,
//DSN000015229                results = APCSvcMgr->TxDerivedDataRequest( tmpRequestUser,           //D9000059
//DSN000015229                                                           controlJobID.identifier,
//DSN000015229                                                           tmpSystemNameList,
//DSN000015229                                                           strAPCDerivedDataResponseList[sysCnt].strAPCLotDerivedDataList,
//DSN000015229                                                           equipmentID.identifier,
//DSN000015229                                                           envTimeOut);
//DSN000015229 Add Start
                results = APCSvcMgr->TxDerivedDataRequest__120( tmpRequestUser,
                                                                controlJobID.identifier,
                                                                tmpSystemNameList,
                                                                strAPCDerivedDataResponseList[sysCnt].strAPCLotDerivedDataList,
                                                                requestType,
                                                                equipmentID.identifier,
                                                                envTimeOut);
//DSN000015229 Add End
                resultsVar = results;
            }
            catch(const CORBA::SystemException &SysEx)
            {
                PPT_METHODTRACE_V1("", "CORBA::SystemException caught");
                APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
                SET_MSG_RC( strAPCMgr_SendDerivedDataRequest_out, MSG_NO_RESPONSE_APC, RC_NO_RESPONSE_APC );
                try
                {
//D6000275                    externalServerList.remove((char *)APCHostName);
                    PPT_METHODTRACE_V2("", "externalServerList.remove()", tmpAPCServerName);    //D6000275
                    externalServerList.remove((char *)tmpAPCServerName);                        //D6000275
                }
                catch( ... )
                {
                    PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                }
                return( RC_NO_RESPONSE_APC );
            }
            catch( ... )
            {
                PPT_METHODTRACE_V1("", "Unknown exception caught");
                APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ( );
                SET_MSG_RC( strAPCMgr_SendDerivedDataRequest_out, MSG_NO_RESPONSE_APC, RC_NO_RESPONSE_APC );
                try
                {
//D6000275                    externalServerList.remove((char *)APCHostName);
                    PPT_METHODTRACE_V2("", "externalServerList.remove()", tmpAPCServerName);    //D6000275
                    externalServerList.remove((char *)tmpAPCServerName);                        //D6000275
                }
                catch( ... )
                {
                    PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                }
                return( RC_NO_RESPONSE_APC );
            }

//D6000035 Add Start
            //-------------------------------------------------------------------------------------------------
            // APC return only 0 or 2. 0 is nomal end, 2 is error. This returnCode is strResult.returnCode.    
            // But when strAPCBaseReturnCode.state is not "OK", TxDerivedDataRequest is fail.                  
            // By the above reason, we check strAPCBaseReturnCode.state, though returnCode is 0.               
            // If except "OK" is found, this function returns error as RC_APC_DERIVEDDATA_ERROR.               
            //-------------------------------------------------------------------------------------------------
            strAPCMgr_SendDerivedDataRequest_out.strResult = results->strResult;
//D9000001            rc = atol(strAPCMgr_SendDerivedDataRequest_out.strResult.returnCode);
            rc = atoi(strAPCMgr_SendDerivedDataRequest_out.strResult.returnCode);//D9000001

            CORBA::Boolean errorFlag = FALSE;
            if( rc != RC_OK )
            {
                errorFlag = TRUE;
            }

            CORBA::Long derived_Len = results->strAPCDerivedDataResponseList.length();
            PPT_METHODTRACE_V2("", "results->strAPCDerivedDataResponseList.length()", derived_Len);
            if ( derived_Len == 0 )
            {
//DSIV00002543 add start
                CORBA::String_var tmpReasonText;
                tmpReasonText = CIMFWStrDup("");
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, "APC-I/F : " );
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, results->strResult.messageText );
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, " : " );
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, results->strResult.returnCode );
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, " : " );
                PPT_STRDUPCAT_STRING( TRUE , tmpReasonText, tmpReasonText, results->strResult.reasonText );
                strAPCMgr_SendDerivedDataRequest_out.strResult.reasonText = tmpReasonText;
//DSIV00002543 add end

                PPT_METHODTRACE_V1("", "results->strAPCDerivedDataResponseList.length() == 0");
                SET_MSG_RC( strAPCMgr_SendDerivedDataRequest_out,
                            MSG_APC_DERIVEDDATA_ERROR,
                            RC_APC_DERIVEDDATA_ERROR);
                return( RC_APC_DERIVEDDATA_ERROR );
            }

            if( CIMFWStrCmp( results->strAPCDerivedDataResponseList[0].strAPCBaseReturnCode.state , SP_APCReturnCode_OK ) != 0 )
            {
                PPT_METHODTRACE_V2("", "BaseReturnCode.state is ERROR",
                                       results->strAPCDerivedDataResponseList[0].strAPCBaseReturnCode.state);
                errorFlag = TRUE;
            }

            if ( errorFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "TxDerivedDataRequest ERROR");
                PPT_METHODTRACE_V2("", "APCSystemName : ", systemNameList[sysCnt]);
                PPT_METHODTRACE_V2("", "state         : ", results->strAPCDerivedDataResponseList[0].strAPCBaseReturnCode.state);
                PPT_METHODTRACE_V2("", "messageText   : ", results->strAPCDerivedDataResponseList[0].strAPCBaseReturnCode.messageText);

                //----------------------------------------------
                // Make Reason Text                             
//DSIV00002543                // ex) APCSystemName : Status : Massage         
                // ex) message Text : reasonCode : reasonText : //DSIV00002543
                //     APCSystemName : Status : Massage : reasonCode : Reasontext //DSIV00002543
                //----------------------------------------------
                CORBA::String_var tmpReasonText;
                tmpReasonText = CIMFWStrDup("");
//DSIV00002543 add start
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, "APC-I/F : " );
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, results->strResult.messageText );
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, " : " );
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, results->strResult.returnCode );
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, " : " );
                PPT_STRDUPCAT_STRING( TRUE , tmpReasonText, tmpReasonText, results->strResult.reasonText );
//DSIV00002543 add end
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, systemNameList[sysCnt] );
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, " : " );
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, results->strAPCDerivedDataResponseList[0].strAPCBaseReturnCode.state );
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, " : " );
//DSIV00002543                PPT_STRDUPCAT_STRING( TRUE , tmpReasonText, tmpReasonText, results->strAPCDerivedDataResponseList[0].strAPCBaseReturnCode.messageText );
//DSIV00002543 add start
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, results->strAPCDerivedDataResponseList[0].strAPCBaseReturnCode.messageText );
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, " : Reason [ " );
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, results->strAPCDerivedDataResponseList[0].strAPCBaseReturnCode.reasonCode );
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, " : " );
                PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, results->strAPCDerivedDataResponseList[0].strAPCBaseReturnCode.reasonText );
                PPT_STRDUPCAT_STRING( TRUE , tmpReasonText, tmpReasonText, " ] " );
//DSIV00002543 add end

                strAPCMgr_SendDerivedDataRequest_out.strResult.reasonText = tmpReasonText;

                SET_MSG_RC( strAPCMgr_SendDerivedDataRequest_out,
                            MSG_APC_DERIVEDDATA_ERROR,
                            RC_APC_DERIVEDDATA_ERROR);
                return( RC_APC_DERIVEDDATA_ERROR );
            }
            else
            {
                PPT_METHODTRACE_V1("", "TxDerivedDataRequest RC_OK");
                strAPCMgr_SendDerivedDataRequest_out.strAPCDerivedDataResponseList[sysCnt] = results->strAPCDerivedDataResponseList[0];
            }
//D6000035 Add End
        }

        SET_MSG_RC(strAPCMgr_SendDerivedDataRequest_out, MSG_OK, RC_OK);
        PPT_METHODTRACE_EXIT("PPTManager_i:: APCMgr_SendDerivedDataRequest");
        return ( rc );
    }
    CATCH_GLOBAL_EXCEPTIONS(strAPCMgr_SendDerivedDataRequest_out, strObjCommonIn, methodName);
}
