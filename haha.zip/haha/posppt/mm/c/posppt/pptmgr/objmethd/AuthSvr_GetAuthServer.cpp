//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: AuthSvr_GetAuthServer.cpp
//

#include "pptmgr.hpp"
#include "authserver.hh"
#include "authstr.hh"

// Class: PPTManager
//
// Service: AuthSvr_GetAuthServer()
//
// Change history:
//
// Date        Level          Author         Note
// ----------  -------------  -------------  -------------------------------------------
// 2009-06-12  DSIV00001049   R.Okano        Initial Release for Security Control Enhancement
//
// Description:
//    This function works as follows.
//     - Bind to Authserver (genIOR + _non_existent)
//     - Store object reference of Authserver in list
//     - Return object reference from list or that is newly generated
//
// Return:
//    Long
//
// Parameter:
//    objAuthSvr_GetAuthServer_out&     strAuthSvr_GetAuthServer_out
//    const pptObjCommonIn&             strObjCommonIn
//    const char*                       AuthSvrServerName
//    const char*                       AuthSvrHostName
//
//    typedef struct objAuthSvr_GetAuthServer_out_struct {
//       pptRetCode              strResult;
//       string                  AuthSvr;
//       any                     siInfo;
//    } objAuthSvr_GetAuthServer_out;

// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
//
CORBA::Long PPTManager_i::AuthSvr_GetAuthServer(
    objAuthSvr_GetAuthServer_out&     strAuthSvr_GetAuthServer_out,
    const pptObjCommonIn&             strObjCommonIn,
    const char*                       AuthSvrServerName,
    const char*                       AuthSvrHostName )
{
    char *methodName = NULL;
    
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::AuthSvr_GetAuthServer");
        
        /*--------------------*/
        /*   Initialization   */
        /*--------------------*/
        CORBA::String_var strObjRef;
        strAuthSvr_GetAuthServer_out.AuthSvr = CIMFWStrDup("");
        
        //if flag is set to TRUE, MMS always bind to Authserver
        CORBA::Boolean bExecBind = FALSE;

        /*----------------------------*/
        /*   Check previous binding   */
        /*----------------------------*/
        if( FALSE == bExecBind )
        {
            CORBA::Boolean existFlag = FALSE;
            char* preObjRef = NULL;
            try
            {
                existFlag = externalServerList.find((char*)AuthSvrServerName, preObjRef);
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "externalServerList.find() raises exception");
                SET_MSG_RC( strAuthSvr_GetAuthServer_out,
                            MSG_SYSTEM_ERROR,
                            RC_SYSTEM_ERROR );
                return RC_SYSTEM_ERROR;
            }
            if( existFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "existFlag == TRUE...");
                strObjRef = CIMFWStrDup(preObjRef);
            }
            else
            {
                PPT_METHODTRACE_V1("", "existFlag != TRUE...");
                bExecBind = TRUE;
            }
        }

        /*--------------------*/
        /*   Bind to server   */
        /*--------------------*/
        if ( TRUE == bExecBind )
        {
            PPT_METHODTRACE_V1("","/*--------------------*/");
            PPT_METHODTRACE_V1("","/*   Bind to server   */");
            PPT_METHODTRACE_V1("","/*--------------------*/");
            
            CORBA::Environment envTimeOut = SP_CORBAENV_DEFENV;
            CORBA::String_var timeOutValue = CIMFWStrDup(getenv(SP_AUTH_TX_TIMEOUT));
            PPT_METHODTRACE_V2("","timeOutValue ---> ",timeOutValue);
            if ( 0 < CIMFWStrLen(timeOutValue) )
            {
                PPT_METHODTRACE_V1("", "setting timeout!!");
                envTimeOut.timeout(atol(timeOutValue) * 1000);
            }

            Authserver_var AuthSvrObj = Authserver::_nil();
            try
            {
                SP_GET_OBJECT_ALWAYS_CHECK_EXISTENCE_WITH_ENV( AuthSvrObj,
                                                               AuthSvrServerName,
                                                               AuthSvrHostName,
                                                               Authserver,
                                                               envTimeOut);
            }
            catch(const CORBA::SystemException &SysEx)
            {
                PPT_METHODTRACE_V1("", "SP_GET_OBJECT_ALWAYS_CHECK_EXISTENCE_WITH_ENV() raises system exception");
                APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
                SET_MSG_RC( strAuthSvr_GetAuthServer_out,
                            MSG_AUTHSERVER_BIND_FAIL,
                            RC_AUTHSERVER_BIND_FAIL );
                return RC_AUTHSERVER_BIND_FAIL;
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "SP_GET_OBJECT_ALWAYS_CHECK_EXISTENCE_WITH_ENV() raises unknown exception");
                APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ();
                SET_MSG_RC( strAuthSvr_GetAuthServer_out,
                            MSG_SYSTEM_ERROR,
                            RC_SYSTEM_ERROR );
                return RC_SYSTEM_ERROR;
            }
            if( CORBA::is_nil(AuthSvrObj) == TRUE )
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil(AuthSvr) == TRUE");
                SET_MSG_RC( strAuthSvr_GetAuthServer_out,
                            MSG_EXT_SERVER_NIL_OBJ,
                            RC_EXT_SERVER_NIL_OBJ );
                return RC_EXT_SERVER_NIL_OBJ;
            }

            /*---------------------*/
            /*   Register server   */
            /*---------------------*/
            try
            {
#ifdef EBROKER
                strObjRef = IMRegistry::orbPtr->object_to_string(AuthSvrObj);
#else
                strObjRef = AuthSvrObj->_object_to_string();
#endif
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "SP_OBJECT_TO_STRING() raises exception");
                SET_MSG_RC( strAuthSvr_GetAuthServer_out,
                            MSG_SYSTEM_ERROR,
                            RC_SYSTEM_ERROR );
                return RC_SYSTEM_ERROR;
            }
            try
            {
                PPT_METHODTRACE_V1("", "externalServerList.remove()");
                try
                {
                    externalServerList.remove((char *)AuthSvrServerName);
                }
                catch( ... )
                {
                    PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                }
                PPT_METHODTRACE_V2("", "externalServerList.add()", AuthSvrServerName);
                externalServerList.add(CIMFWStrDup(AuthSvrServerName), CIMFWStrDup(strObjRef));
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "externalServerList.add() raises exception");
                SET_MSG_RC( strAuthSvr_GetAuthServer_out,
                            MSG_SYSTEM_ERROR,
                            RC_SYSTEM_ERROR );
                return RC_SYSTEM_ERROR;
            }
        }

        /*--------------------------*/
        /*   Set output parameter   */
        /*--------------------------*/
        PPT_METHODTRACE_V2("", "strObjRef = ", strObjRef);
        strAuthSvr_GetAuthServer_out.AuthSvr = CIMFWStrDup(strObjRef);
        
        PPT_METHODTRACE_EXIT("PPTManager_i::AuthSvr_GetAuthServer");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strAuthSvr_GetAuthServer_out, AuthSvr_GetAuthServer, methodName);
}
