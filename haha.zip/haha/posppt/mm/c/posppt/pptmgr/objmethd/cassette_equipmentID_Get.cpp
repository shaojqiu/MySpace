#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_equipmentID_Get.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:34:38 [ 7/13/07 19:34:39 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_equipmentID_Get.cpp
//

#include "pptmgr.hpp"

#include "pmc.hh"
#include "pcas.hh"


//[Object Function Name]: long   cassette_equipmentID_Get
//
// Date        Level  Author         Note
// ----------  -----  -------------  -------------------------------------------
// 2001-01-09  D3000093 M.Mori       Initial Release
// 2003-03-13  P5000003 H.Adachi     MM Server Down at narrow to PosMachineObject.
//
//
//[Function Description]:
//
//
//[Input Parameters]:
//  in  pptObjCommonIn     strObjCommonIn;
//  in  objectIdentifier   cassetteID;
//
//[Output Parameters]:
//  out objCassette_equipmentID_Get_out   strCassette_equipmentID_Get_out;
//
//  typedef struct objCassette_equipmentID_Get_out_struct {
//      pptRetCode                  strResult;
//      objectIdentifier            equipmentID;
//  } objCassette_equipmentID_Get_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK

CORBA::Long  PPTManager_i::cassette_equipmentID_Get(
                                  objCassette_equipmentID_Get_out&  strCassette_equipmentID_Get_out,
                                  const pptObjCommonIn&             strObjCommonIn,
                                  const objectIdentifier&           cassetteID)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_equipmentID_Get");

        /*-------------------------*/
        /*   Get Cassette Object   */
        /*-------------------------*/
        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                               cassetteID,
                                               strCassette_equipmentID_Get_out,
                                               cassette_equipmentID_Get );

        Machine_var    aMachine;
        PosMachine_var aOrgMachine;
        try
        {
            aMachine = aCassette->currentAssignedMachine();
//P5000003            aOrgMachine = PosMachine::_narrow( aMachine );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::currentAssignedMachine)

        //P5000003 Add Start
        strCassette_equipmentID_Get_out.equipmentID.identifier = CIMFWStrDup("");
        strCassette_equipmentID_Get_out.equipmentID.stringifiedObjectReference = CIMFWStrDup("");

        if ( TRUE != CORBA::is_nil(aMachine) )
        {
            CORBA::Boolean isStorageBool = FALSE;
            try
            {
                isStorageBool = aMachine->isStorageMachine();
            }
            CATCH_AND_RAISE_EXCEPTIONS(Machine::isStorageMachine)

            if ( isStorageBool == TRUE )
            {
                PPT_METHODTRACE_V1( "", "isStorageBool is TRUE: Storage" );
            }
            else
            {
                PPT_SET_OBJECT_IDENTIFIER( strCassette_equipmentID_Get_out.equipmentID,
                                           aMachine,
                                           strCassette_equipmentID_Get_out,
                                           cassette_equipmentID_Get,
                                           Machine );

                PPT_METHODTRACE_V2( "", "isStorageBool is not TRUE: Equipment",
                                    strCassette_equipmentID_Get_out.equipmentID.identifier );
            }
        }
        else
        {
            PPT_METHODTRACE_V1( "", "aMachine is Nill" );
        }
        //P5000003 Add End

//P5000003        PPT_SET_OBJECT_IDENTIFIER( strCassette_equipmentID_Get_out.equipmentID,
//P5000003                                   aOrgMachine,
//P5000003                                   strCassette_equipmentID_Get_out,
//P5000003                                   cassette_equipmentID_Get,
//P5000003                                   PosMachine );

        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_equipmentID_Get");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_equipmentID_Get_out, cassette_equipmentID_Get, methodName)
}

