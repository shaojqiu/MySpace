#ifndef lint
static char *sccsid =  "@(#) 1.5 superpos/src/spppt/source/posppt/pptmgr/objmethd/APCMgr_SendProductDispositionReport.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 2/5/08 20:34:51 [ 2/5/08 20:34:52 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: APCMgr_SendProductDispositionReport.cpp
//

#include "pptmgr.hpp"
#include "mqsm.hh"

//[Object Function Name]: long  APCMgr_SendProductDispositionReport
//
// Date        Level    Author         Note
// ----------  -------  -------------  -------------------------------------------
// 2004/07/13  D51M0000 M.Mori         Initial Release (R51M)
// 2004/11/17  D6000025 K.Murakami     Add SP_STRING_TO_OBJECT for eBroker
// 2004/11/18  D6000025 K.Murakami     Change CORBA::IT_chooseDefaultEnv() to SP_CORBAENV_DEFENV
// 2005/05/17  D6000275 M.Murata       Change variable for externalServerList.
// 2005/05/17  D6000314 M.Murata       Change variable for externalServerList.(EB)
// 2007/04/20  D9000001 M.Murata       64bit support.
// 2008/01/17  D9000059 H.Hotta        External System Interface Security Control
//
// Date        Level         Author         Note
// ----------  ------------  -------------  -------------------------------------------
// 2010/10/28  DSIV00002543  S.Yamamoto     Improvement of reasonText message.
//
//[Function Description]:
//
//[Input Parameters]:
//  in  pptObjCommonIn                              strObjCommonIn
//  in  pptAPCDispositionLotActionResultSequence    strAPCDispositionLotActionResult
//  in  pptAPCProductDispositionResponse            strAPCProductDispositionResponse
//  in  objectIdentifier                            equipmentID
//
//[Output Parameters]:
//
//  out objAPCMgr_SendProductDispositionReport_out   strAPCMgr_SendProductDispositionReport_out
//
//  typedef struct objAPCMgr_SendProductDispositionReport_out_struct {
//      pptRetCode      strResult;
//      any             siInfo;
//  } objAPCMgr_SendProductDispositionReport_out;
//
// [Return Value]:
//
//  Return Code                         Messsage ID
// ------------------------------------ ---------------------------------------------
//  RC_OK                               MSG_OK
//  RC_APC_SERVER_NIL_OBJ               MSG_APC_SERVER_NIL_OBJ
//  RC_NO_RESPONSE_APC                  MSG_NO_RESPONSE_APC
//  RC_APC_PRODUCTIONDISPOSITION_ERROR  MSG_APC_PRODUCTIONDISPOSITION_ERROR
//
CORBA::Long PPTManager_i::APCMgr_SendProductDispositionReport(
    objAPCMgr_SendProductDispositionReport_out&         strAPCMgr_SendProductDispositionReport_out,
    const pptObjCommonIn&                               strObjCommonIn,
    const pptAPCDispositionLotActionResultSequence&     strAPCDispositionLotActionResult,
    const pptAPCProductDispositionResponse&             strAPCProductDispositionResponse,
    const objectIdentifier&                             equipmentID)
{

    CORBA::Long rc = RC_OK;
    char * methodName = NULL;

    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i:: APCMgr_SendProductDispositionReport");

//D9000059 add start
        // External System Interface Security Control
        pptUser tmpRequestUser = strObjCommonIn.strUser;

        CORBA::String_var configFlag = CIMFWStrDup( getenv(SP_USER_ID_PASSWORD_CONFIGRATION) );
        PPT_METHODTRACE_V2("","SP_USER_ID_PASSWORD_CONFIGRATION ", configFlag);

        if( 0 == CIMFWStrCmp( configFlag, "1" ) )
        {
            PPT_METHODTRACE_V1("","SP_USER_ID_PASSWORD_CONFIGRATION=1");

            tmpRequestUser.userID.identifier = CIMFWStrDup( getenv(SP_APC_USER_ID) );
            tmpRequestUser.password          = CIMFWStrDup( getenv(SP_APC_USER_PASSWORD) );
        }

        PPT_METHODTRACE_V2("","userID   ", tmpRequestUser.userID.identifier);
        PPT_METHODTRACE_V2("","password ", tmpRequestUser.password);
//D9000059 add end

        /*---------------------------------------*/
        /*   Set strAPCBaseidentification   */
        /*---------------------------------------*/
        pptAPCBaseIdentification strAPCBaseIdentification;
        strAPCBaseIdentification.systemName  = CIMFWStrDup(getenv(SP_MM_SYSTEM_NAME));
//D9000059        strAPCBaseIdentification.userId      = CIMFWStrDup(strObjCommonIn.strUser.userID.identifier);
//D9000059        strAPCBaseIdentification.password    = CIMFWStrDup(strObjCommonIn.strUser.password);
        strAPCBaseIdentification.userId      = CIMFWStrDup(tmpRequestUser.userID.identifier);    //D9000059
        strAPCBaseIdentification.password    = CIMFWStrDup(tmpRequestUser.password);             //D9000059
        strAPCBaseIdentification.newPassword = CIMFWStrDup(strObjCommonIn.strUser.newPassword);
        strAPCBaseIdentification.clientNode  = CIMFWStrDup(strObjCommonIn.strUser.clientNode);

        /*---------------------*/
        /*   Get Server Name   */
        /*---------------------*/
        PPT_METHODTRACE_V1("", "get Server Name");

        CORBA::String_var tmpAPCServerName = CIMFWStrDup(getenv(SP_APC_SERVER_NAME)); 
//D9000001        char* APCServerName = CORBA::string_alloc(CIMFWStrLen(tmpAPCServerName)+1);
        char* APCServerName = CORBA::string_alloc( (CORBA::ULong) CIMFWStrLen(tmpAPCServerName)+1);//D9000001
        CORBA::String_var tmpStr = APCServerName;
        if ( NULL != APCServerName )
        {
            APCServerName[0] = NULL;
        }

        if ( strstr(tmpAPCServerName, ":") == NULL )
        {
            PPT_METHODTRACE_V1("", "Not Exist ':' into SP_APC_SERVER_NAME");
            CIMFWStrCpy(APCServerName, ":");
            CIMFWStrCat(APCServerName, tmpAPCServerName);
        }
        else
        {
            PPT_METHODTRACE_V1("", "':' Exist into SP_APC_SERVER_NAME");
            CIMFWStrCpy(APCServerName, tmpAPCServerName);
        }

//D6000275 Add Start
        //--------------------------------
        // Get Environment for GenIOR     
        //--------------------------------
#ifdef EBROKER                                                                 //D6000314
        tmpAPCServerName = CIMFWStrDup(APCServerName);                         //D6000314
#else                                                                          //D6000314
        tmpAPCServerName = CIMFWStrDup(getenv(SP_APCServerName_ForGenIOR));
//D6000275 Add End
#endif                                                                         //D6000314

        /*-------------------*/
        /*   Get Host Name   */
        /*-------------------*/
        PPT_METHODTRACE_V1("", "get Host Name");
        CORBA::String_var APCHostName;
        APCHostName = CIMFWStrDup(getenv(SP_APC_HOST_NAME));

        /*---------------------------------*/
        /*   Prepare e-mail Message Text   */
        /*---------------------------------*/
        CORBA::String_var msg;
        PPT_STRDUPCAT_STRING( FALSE, msg, msg, " Equipment ID      : " );
        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)equipmentID.identifier );
        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, " ControlJob ID     : " );
        PPT_STRDUPCAT_STRING( FALSE, msg, msg, " MM SYSTEM NAME    : " );
        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)strAPCBaseIdentification.systemName );
        PPT_STRDUPCAT_STRING( FALSE, msg, msg, " APC Server Name   : " );
//D6000275        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)APCServerName );
        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)tmpAPCServerName );    //D6000275
        PPT_STRDUPCAT_STRING( FALSE, msg, msg, " APC Host Name     : " );
        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, (const char*)APCHostName );
        PPT_STRDUPCAT_STRING( FALSE, msg, msg, " Function Name     : " );
        PPT_STRDUPCAT_STRING( TRUE,  msg, msg, "txProductDispositionReport" );
        PPT_METHODTRACE_V2("", "messageText--->", msg);
        strAPCMgr_SendProductDispositionReport_out.strResult.reasonText = msg;

        /*--------------------*/
        /*   Get APCManager   */
        /*--------------------*/
        PPT_METHODTRACE_V1("", "get APCManager");
        MQSvcMgr_var APCSvcMgr;
        APCSvcMgr = MQSvcMgr::_nil();
        PPT_METHODTRACE_V1("", "call APCMgr_GetServiceManager");
        objAPCMgr_GetServiceManager_out strAPCMgr_GetServiceManager_out;
        rc = APCMgr_GetServiceManager( strAPCMgr_GetServiceManager_out,
                                       strObjCommonIn,
                                       APCServerName,
                                       APCHostName);
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "APCMgr_GetServiceManager() != RC_OK");
            strAPCMgr_SendProductDispositionReport_out.strResult = strAPCMgr_GetServiceManager_out.strResult;
            strAPCMgr_SendProductDispositionReport_out.strResult.reasonText = msg;
            return( rc );
        }

        CORBA::Object_var anObject;
#ifdef EBROKER           //D6000025
        anObject = SP_STRING_TO_OBJECT(strAPCMgr_GetServiceManager_out.APCSvcMgr);   //D6000025
#else                    //D6000025
        anObject = CORBA::Orbix.string_to_object(strAPCMgr_GetServiceManager_out.APCSvcMgr);
#endif                   //D6000025
        APCSvcMgr = MQSvcMgr::_narrow(anObject);
        if ( CORBA::is_nil(APCSvcMgr) )
        {
            SET_MSG_RC( strAPCMgr_SendProductDispositionReport_out, MSG_APC_SERVER_NIL_OBJ, RC_APC_SERVER_NIL_OBJ );
            return( RC_APC_SERVER_NIL_OBJ );
        }

        //D6000025CORBA::Environment envTimeOut;
        //D6000025envTimeOut = CORBA::IT_chooseDefaultEnv();
        CORBA::Environment envTimeOut = SP_CORBAENV_DEFENV;    //D6000025
        CORBA::String_var timeOutValue;
        timeOutValue = CIMFWStrDup(getenv(SP_TX_Timeout_APC));

        if ( CIMFWStrLen(timeOutValue) > 0 )
        {
            envTimeOut.timeout(atol(timeOutValue) * 1000);
        }

        CORBA::Long resultLen = strAPCDispositionLotActionResult.length();

        /*-------------------------*/
        /*   Send Request to APC   */
        /*-------------------------*/
        pptProductDispositionReportResult* results = NULL;
        pptProductDispositionReportResult_var resultsVar;

        PPT_METHODTRACE_V1("", "Send Request to APC");
        try
        {
            PPT_METHODTRACE_V1("", "call APCSvcMgr -> TxProductDispositionReport");
//D9000059            results = APCSvcMgr->TxProductDispositionReport( strObjCommonIn.strUser,
            results = APCSvcMgr->TxProductDispositionReport( tmpRequestUser,                       //D9000059
                                                             strAPCBaseIdentification,
                                                             strAPCProductDispositionResponse.strAPCBaseIdentification.systemName,
                                                             strAPCDispositionLotActionResult,
                                                             strAPCDispositionLotActionResult[resultLen-1].strAPCBaseReturnCode,
                                                             equipmentID.identifier, envTimeOut);
            resultsVar = results;
        }
        catch(const CORBA::SystemException &SysEx)
        {
            PPT_METHODTRACE_V1("", "CORBA::SystemException caught");
            APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
            SET_MSG_RC( strAPCMgr_SendProductDispositionReport_out, MSG_NO_RESPONSE_APC, RC_NO_RESPONSE_APC );
            try
            {
//D6000275                externalServerList.remove((char *)APCHostName);
                PPT_METHODTRACE_V2("", "externalServerList.remove()", tmpAPCServerName);    //D6000275
                externalServerList.remove((char *)tmpAPCServerName);                        //D6000275
            }
            catch( ... )
            {
                PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
            }
            return( RC_NO_RESPONSE_APC );
        }
        catch( ... )
        {
            PPT_METHODTRACE_V1("", "Unknown exception caught");
            APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ( );
            SET_MSG_RC( strAPCMgr_SendProductDispositionReport_out, MSG_NO_RESPONSE_APC, RC_NO_RESPONSE_APC );
            try
            {
//D6000275                externalServerList.remove((char *)APCHostName);
                PPT_METHODTRACE_V2("", "externalServerList.remove()", tmpAPCServerName);    //D6000275
                externalServerList.remove((char *)tmpAPCServerName);                        //D6000275
            }
            catch( ... )
            {
                PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
            }
            return( RC_NO_RESPONSE_APC );
        }

        strAPCMgr_SendProductDispositionReport_out.strResult = results->strResult;
//D9000001        rc = atol(strAPCMgr_SendProductDispositionReport_out.strResult.returnCode);
        rc = atoi(strAPCMgr_SendProductDispositionReport_out.strResult.returnCode);//D9000001

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", " TxProductDispositionReport()  rc != RC_OK");

//DSIV00002543 add start
            CORBA::String_var tmpReasonText;
            tmpReasonText = CIMFWStrDup("");
            PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, "APC-I/F : " );
            PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, results->strResult.messageText );
            PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, " : " );
            PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, results->strResult.returnCode );
            PPT_STRDUPCAT_STRING( FALSE, tmpReasonText, tmpReasonText, " : " );
            PPT_STRDUPCAT_STRING( TRUE , tmpReasonText, tmpReasonText, results->strResult.reasonText );
            strAPCMgr_SendProductDispositionReport_out.strResult.reasonText = tmpReasonText;
//DSIV00002543 add end

            SET_MSG_RC(strAPCMgr_SendProductDispositionReport_out,
                       MSG_APC_PRODUCTIONDISPOSITION_ERROR,
                       RC_APC_PRODUCTIONDISPOSITION_ERROR);

            return( RC_APC_PRODUCTIONDISPOSITION_ERROR );
         }

        strAPCMgr_SendProductDispositionReport_out.strResult.reasonText = CIMFWStrDup("");

        PPT_METHODTRACE_EXIT("PPTManager_i:: APCMgr_SendProductDispositinReport");
        return( rc );
    }
    CATCH_GLOBAL_EXCEPTIONS(strAPCMgr_SendProductDispositionReport_out, APCMgr_SendProductDispositionReport, methodName);
}
