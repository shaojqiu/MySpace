#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/BRSMgr_GetServiceManager.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:19:18 [ 7/13/07 19:19:19 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: BRSMgr_GetServiceManager.cpp
//

#include"pptmgr.hpp"

#include "brsmanagerfac.hh"

//[Object Function Name]: long   BRSMgr_GetServiceManager()
//
// Date        Level       Author         Note
// ----------  ----------  -------------  -------------------------------------------
// 2000/12/25  D3000107    K.Matsuei      Initial Release
// 2001/01/17  P3000426    K.Matsuei      Bug fix for Memory Leak
// 2001/01/29  P3000438    K.Matsuei      Set timeout
// 2001/05/29  D4000011    M.SHimizu      Add getenv Values on Manager Class Member
// 2002/02/13  D4000134    C.Tsuchiya     Drop D4000011
// 2002/03/26  P4100034    Y.Iwasaki      Change message
// 2002/04/03  D4100133    K.Matsuei      Set _bind timeout logic.
// 2002/07/10  D4200034    K.Matsuei      Improve ErrorCheck in Outside SubSystem call.
// 2002/07/26  P4200074    K.Matsuei      Fix memory leak by externalServerList.
// 2004/11/17  D6000025    K.Murakami     CORBA::string to CORBA::String
//                                        Add SP_STRING_TO_OBJECT for eBroker
// 2004/11/18  D6000025    K.Murakami     Change CORBA::IT_chooseDefaultEnv() to SP_CORBAENV_DEFENV
// 2004/11/24  D6000025    K.Murakami     Add SP_GET_OBJECT_WITH_ENV for eBroker
//                                        Add IMRegistry::orbPtr->object_to_string for eBroker
//
//[Function Description]
//  get BRS Service Manager
//
//[Input Parameters]:
//  in  pptObjCommonIn      strObjCommonIn;
//  in  string              BRSServerName;
//  in  string              BRSHostName;
//
//[Output Parameters]:
//
//  out objBRSMgr_GetServiceManager_out strBRSMgr_GetServiceManager_out;
//
//  typedef struct objBRSMgr_GetServiceManager_out_struct {
//     pptRetCode               strResult;
//     string                   BRSSvcMgr;
//  } objBRSMgr_GetServiceManager_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  -------------------------   --------------------------------------------------

CORBA::Long PPTManager_i::BRSMgr_GetServiceManager(
                objBRSMgr_GetServiceManager_out& strBRSMgr_GetServiceManager_out,
                const pptObjCommonIn&            strObjCommonIn,
                const char*                      BRSServerName,
                const char*                      BRSHostName)
{
    char *methodName=NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::BRSMgr_GetServiceManager");

        BRSManagerObjectFactory_var theBRSManagerObjFactory = BRSManagerObjectFactory::_nil();

//P3000426        char* BindEverytimeFlg = CIMFWStrDup(getenv("SP_BindEverytime_CSS"));
//D4000011        CORBA::String_var BindEverytimeFlg = CIMFWStrDup(getenv("SP_BindEverytime_CSS"));  //P3000426
        CORBA::String_var BindEverytimeFlg = CIMFWStrDup(getenv("SP_BindEverytime_CSS"));  //D4100134

//D4100134        PPT_METHODTRACE_V2("PPTManager_i::BRSMgr_GetServiceManager","theSP_BindEverytime_CSS = ",theSP_BindEverytime_CSS);    //D4000011
//D4100134        CORBA::String_var BindEverytimeFlg = theSP_BindEverytime_CSS;                                                         //P4000011
        PPT_METHODTRACE_V2("","BindEverytimeFlg ---> ",BindEverytimeFlg);

        CORBA::Boolean bExecBind = FALSE;

        if ( 0 == CIMFWStrCmp(BindEverytimeFlg, "1") )
        {
            /*--------------------*/
            /*   Everytime Bind   */
            /*--------------------*/
            PPT_METHODTRACE_V1("","/*--------------------*/");
            PPT_METHODTRACE_V1("","/*   Everytime Bind   */");
            PPT_METHODTRACE_V1("","/*--------------------*/");

            bExecBind = TRUE;
        }

        if ( FALSE == bExecBind )
        {
            /*----------------------------*/
            /*   Search Service Manager   */
            /*----------------------------*/
            PPT_METHODTRACE_V1("","/*----------------------------*/");
            PPT_METHODTRACE_V1("","/*   Search Service Manager   */");
            PPT_METHODTRACE_V1("","/*----------------------------*/");

            CORBA::Boolean existFlag = FALSE;
            //D6000025char* objRef = CORBA::string(NULL);
            char* objRef = CORBA::String(NULL); //D6000025
            try
            {
                existFlag = externalServerList.find((char*)BRSServerName, objRef);
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "externalServerList.find() raises exception");
                SET_MSG_RC(strBRSMgr_GetServiceManager_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
                return(RC_SYSTEM_ERROR);
            }
            if ( existFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "existFlag == TRUE...");
                CORBA::Object_var tmpBRS = CORBA::Object::_nil();
                try
                {
#ifdef EBROKER           //D6000025
                    tmpBRS = SP_STRING_TO_OBJECT(objRef);     //D6000025
#else                    //D6000025
                    tmpBRS = CORBA::Orbix.string_to_object(objRef);
#endif                   //D6000025
                }
                catch(...)
                {
                    PPT_METHODTRACE_V1("", "CORBA::Orbix.string_to_object() raises exception");
                    //D4000180 SET_MSG_RC(strBRSMgr_GetServiceManager_out, MSG_EXT_SERVER_BIND_FAIL, RC_EXT_SERVER_BIND_FAIL);
                    //D4000180 Start
                    SET_MSG_RC( strBRSMgr_GetServiceManager_out,
                                MSG_BRS_SERVER_BIND_FAIL,
                                RC_BRS_SERVER_BIND_FAIL);
                    //D4000180 End
                    try
                    {
                        externalServerList.remove((char *)BRSServerName);
                    }
                    catch( ... )
                    {
                        PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                    }
                    //D4000180 return(RC_EXT_SERVER_BIND_FAIL);
                    return(RC_BRS_SERVER_BIND_FAIL); //D4000180
                }
                if (CORBA::is_nil(tmpBRS) == TRUE)
                {
                    PPT_METHODTRACE_V1("", "CORBA::is_nil(tmpBRS) == TRUE");
                    SET_MSG_RC(strBRSMgr_GetServiceManager_out, MSG_EXT_SERVER_NIL_OBJ, RC_EXT_SERVER_NIL_OBJ);
                    try
                    {
                        externalServerList.remove((char *)BRSServerName);
                    }
                    catch( ... )
                    {
                        PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                    }
                    return(RC_EXT_SERVER_NIL_OBJ);
                }
                theBRSManagerObjFactory = BRSManagerObjectFactory::_narrow(tmpBRS);
            }
            else
            {
                bExecBind = TRUE;
            }
        }

//D4100133 start
        //D6000025CORBA::Environment envTimeOut = CORBA::IT_chooseDefaultEnv();
        CORBA::Environment envTimeOut = SP_CORBAENV_DEFENV;   //D6000025
        CORBA::String_var timeOutValue = CIMFWStrDup(getenv(SP_TX_Timeout_CSS));
        PPT_METHODTRACE_V2("","timeOutValue ---> ",timeOutValue);

        if ( 0 < CIMFWStrLen(timeOutValue) )
        {
            PPT_METHODTRACE_V1("", "setting timeout!!");
            envTimeOut.timeout(atol(timeOutValue) * 1000);
        }
//D4100133 end

        if ( TRUE == bExecBind )
        {
            /*--------------------------*/
            /*   Bind Service Manager   */
            /*--------------------------*/
            PPT_METHODTRACE_V1("","/*--------------------------*/");
            PPT_METHODTRACE_V1("","/*   Bind Service Manager   */");
            PPT_METHODTRACE_V1("","/*--------------------------*/");

            CORBA::String_var newObjRef;
            try
            {
//D4100133                theBRSManagerObjFactory = BRSManagerObjectFactory::_bind( BRSServerName, BRSHostName );
#ifdef EBROKER                                                                                                                     //D6000025
                SP_GET_OBJECT_WITH_ENV(theBRSManagerObjFactory, BRSServerName, BRSHostName, BRSManagerObjectFactory, envTimeOut);  //D6000025
#else                                                                                                                              //D6000025
                theBRSManagerObjFactory = BRSManagerObjectFactory::_bind( BRSServerName, BRSHostName, envTimeOut ); //D4100133
#endif                                                                                                                             //D6000025
            }
            catch(const CORBA::SystemException &SysEx)
            {
                PPT_METHODTRACE_V1("", "BRSManagerObjectFactory::_bind() raises system exception");
                APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
//P4100034      SET_MSG_RC(strBRSMgr_GetServiceManager_out, MSG_EXT_SERVER_BIND_FAIL, RC_EXT_SERVER_BIND_FAIL);
//P4100034      return(RC_EXT_SERVER_BIND_FAIL);
                SET_MSG_RC(strBRSMgr_GetServiceManager_out, MSG_BRS_SERVER_BIND_FAIL, RC_BRS_SERVER_BIND_FAIL);  //P4100034
                return(RC_BRS_SERVER_BIND_FAIL);                                                                 //P4100034
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "BRSManagerObjectFactory::_bind() raises unknown exception");
                APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ();
//P4100034      SET_MSG_RC(strBRSMgr_GetServiceManager_out, MSG_EXT_SERVER_BIND_FAIL, RC_EXT_SERVER_BIND_FAIL);
//P4100034      return(RC_EXT_SERVER_BIND_FAIL);
                SET_MSG_RC(strBRSMgr_GetServiceManager_out, MSG_BRS_SERVER_BIND_FAIL, RC_BRS_SERVER_BIND_FAIL);  //P4100034
                return(RC_BRS_SERVER_BIND_FAIL);                                                                 //P4100034
            }
            if (CORBA::is_nil(theBRSManagerObjFactory) == TRUE)
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil(theBRSManagerObjFactory) == TRUE");
                SET_MSG_RC(strBRSMgr_GetServiceManager_out, MSG_EXT_SERVER_NIL_OBJ, RC_EXT_SERVER_NIL_OBJ);
                return(RC_EXT_SERVER_NIL_OBJ);
            }
            try
            {
#ifdef EBROKER                                                                              //D6000025 
                newObjRef = IMRegistry::orbPtr->object_to_string(theBRSManagerObjFactory);  //D6000025
#else                                                                                       //D6000025
                newObjRef = theBRSManagerObjFactory->_object_to_string();
#endif                                                                                      //D6000025
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "theBRSManagerObjFactory->_object_to_string() raises exception");
                SET_MSG_RC(strBRSMgr_GetServiceManager_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
                return(RC_SYSTEM_ERROR);
            }
            try
            {
                //P4200074 start
                PPT_METHODTRACE_V1("", "externalServerList.remove()");
                try
                {
                    externalServerList.remove((char *)BRSServerName);
                }
                catch( ... )
                {
                    PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                }
                //P4200074 end

//P4200074 The following comments are mistakes.
//P4200074 It does not MemoryLeak, if it remove same member after adding.
//P4200074
//P4200074                //About 2nd parameter, CIMFWStrDup(newObjRef) makes memory-leak, but it will be
//P4200074                //happened when stopping mmserver, so CIMFWStrDup(newObjRef) can be used.
//P4200074                //When 1st and 2nd parameters are same valiable case, CIMFWStrDup should not be
//P4200074                //used for 2nd parameter.
                externalServerList.add(CIMFWStrDup(BRSServerName), CIMFWStrDup(newObjRef));
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "externalServerList.add() raises exception");
                SET_MSG_RC(strBRSMgr_GetServiceManager_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
                return(RC_SYSTEM_ERROR);
            }
        }

        /*--------------------------------*/
        /*   get Service Manager Object   */
        /*--------------------------------*/
        PPT_METHODTRACE_V1("","/*--------------------------------*/");
        PPT_METHODTRACE_V1("","/*   get Service Manager Object   */");
        PPT_METHODTRACE_V1("","/*--------------------------------*/");

//D4100133//P3000438 start
//D4100133        CORBA::Environment envTimeOut = CORBA::IT_chooseDefaultEnv();
//D4100133//D4000011        CORBA::String_var timeOutValue = CIMFWStrDup(getenv(SP_TX_Timeout_CSS));
//D4100133        CORBA::String_var timeOutValue = CIMFWStrDup(getenv(SP_TX_Timeout_CSS));    //D4100134
//D4100133//D4100134        PPT_METHODTRACE_V2("PPTManager_i::BRSMgr_GetServiceManager","theSP_TX_Timeout_CSS = " , theSP_TX_Timeout_CSS);    //D4000011
//D4100133//D4100134        CORBA::String_var timeOutValue = theSP_TX_Timeout_CSS;                                                          //D4000011
//D4100133
//D4100133        PPT_METHODTRACE_V2("","timeOutValue ---> ",timeOutValue);
//D4100133
//D4100133        if ( 0 < CIMFWStrLen(timeOutValue) )
//D4100133        {
//D4100133            PPT_METHODTRACE_V1("", "setting timeout!!");
//D4100133            envTimeOut.timeout(atol(timeOutValue) * 1000);
//D4100133        }
//D4100133//P3000438 end

        BRSManager_var BRSSvcMgr = BRSManager::_nil();
        try
        {
//P3000438            BRSSvcMgr = theBRSManagerObjFactory->createBRSManager();
            BRSSvcMgr = theBRSManagerObjFactory->createBRSManager(envTimeOut);  //P3000438
        }
        catch(...)
        {
            PPT_METHODTRACE_V1("PPTManager_i::script_RunBRScript", "Failed to bind to BRSServer")
            SET_MSG_RC(strBRSMgr_GetServiceManager_out, MSG_SCRIPT_SERVER_NOT_AVAILABLE, RC_SCRIPT_EXEC_FAIL)
            try
            {
                externalServerList.remove((char *)BRSServerName);
            }
            catch( ... )
            {
                PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
            }
            return RC_SCRIPT_EXEC_FAIL;
        }

        if(CORBA::is_nil(BRSSvcMgr))
        {
            PPT_METHODTRACE_V1("BRSManager_i::executeScirptText", "BRS Server is not available now.")
            SET_MSG_RC(strBRSMgr_GetServiceManager_out, MSG_SCRIPT_SERVER_NOT_AVAILABLE, RC_SCRIPT_EXEC_FAIL)
            return RC_SCRIPT_EXEC_FAIL;
        }

        /*--------------------------*/
        /*   set output parameter   */
        /*--------------------------*/
//D4200034        strBRSMgr_GetServiceManager_out.BRSSvcMgr = BRSSvcMgr->_object_to_string();
//D4200034 start
        try
        {
#ifdef EBROKER                                                                                             //D6000025
            strBRSMgr_GetServiceManager_out.BRSSvcMgr = IMRegistry::orbPtr->object_to_string(BRSSvcMgr);   //D6000025
#else                                                                                                      //D6000025
            strBRSMgr_GetServiceManager_out.BRSSvcMgr = BRSSvcMgr->_object_to_string();
#endif                                                                                                     //D6000025
        }
        catch(...)
        {
            PPT_METHODTRACE_V1("", "BRSSvcMgr->_object_to_string() raises exception");
            SET_MSG_RC(strBRSMgr_GetServiceManager_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
            return RC_SYSTEM_ERROR;
        }
//D4200034 end

        PPT_METHODTRACE_EXIT("PPTManager_i::BRSMgr_GetServiceManager");

        return (RC_OK);
    }
    CATCH_GLOBAL_EXCEPTIONS(strBRSMgr_GetServiceManager_out, BRSMgr_GetServiceManager, methodName);
}

