//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: autoDispatchControl_info_Check.cpp
//

#include "pptmgr.hpp"
#include "pevbase.hh"

// Class: PPTManager
//
// Service: autoDispatchControl_info_Check()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2011/09/21 DSN000020767 T.Ishida       Auto Dispatch Control Support
// 2012/06/22 PSN000042280 N.Makino       Add existence check for RouteID and Operation Number
// 2015/11/10 DSN000096135 XF.Ming        process_operationListForRoute ==> process_operationListForRoute__160
//
//[Function Description]:
//
//
//[Input Parameters]:
//  const pptObjCommonIn&                       strObjCommonIn
//  const objAutoDispatchControl_info_Check_in& strAutoDispatchControl_info_Check_in
//
//    typedef struct objAutoDispatchControl_info_Check_in_struct {
//        pptLotAutoDispatchControlUpdateInfo strLotAutoDispatchControlUpdateInfo;
//        any                                 siInfo;
//    } objAutoDispatchControl_info_Check_in;
//
//[Output Parameters]:
//  objAutoDispatchControl_info_Check_out& strAutoDispatchControl_info_Check_out
//
//    typedef objBase_out objAutoDispatchControl_info_Check_out;
//
//[Return Value]:
//
//  Return Code                        Message ID
//  ---------------------------------- -----------------------------------------
//  RC_OK                              MSG_OK
//
CORBA::Long PPTManager_i::autoDispatchControl_info_Check(
    objAutoDispatchControl_info_Check_out&      strAutoDispatchControl_info_Check_out,
    const pptObjCommonIn&                       strObjCommonIn,
    const objAutoDispatchControl_info_Check_in& strAutoDispatchControl_info_Check_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY( "PPTManager_i::autoDispatchControl_info_Check" );

        //--------------//
        //  Initialize  //
        //--------------//
        CORBA::Long rc = RC_OK;

        pptLotAutoDispatchControlUpdateInfo strLotAutoDispatchControlUpdateInfo;
        strLotAutoDispatchControlUpdateInfo = strAutoDispatchControl_info_Check_in.strLotAutoDispatchControlUpdateInfo;

        CORBA::Long updateLen = 0;
        CORBA::Long updateCnt = 0;

        updateLen = strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq.length();
        PPT_METHODTRACE_V2( "", "updateLen ", updateLen );

        objAutoDispatchControl_info_GetDR_in strAutoDispatchControl_info_GetDR_in;
        strAutoDispatchControl_info_GetDR_in.lotID = strLotAutoDispatchControlUpdateInfo.lotID;

        objAutoDispatchControl_info_GetDR_out strAutoDispatchControl_info_GetDR_out;
        rc = autoDispatchControl_info_GetDR( strAutoDispatchControl_info_GetDR_out, strObjCommonIn, strAutoDispatchControl_info_GetDR_in );
        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V2( "", "autoDispatchControl_info_GetDR() != RC_OK", rc );
            strAutoDispatchControl_info_Check_out.strResult = strAutoDispatchControl_info_GetDR_out.strResult;
            return rc;
        }

        //----------------------------//
        //  Check Delete Information  //
        //----------------------------//
        CORBA::Long infoLen = 0;
        CORBA::Long infoCnt = 0;
        CORBA::Long tmpLen = 0;
        CORBA::Long tmpCnt = 0;
        pptLotAutoDispatchControlInfoSequence tmpLotAutoDispatchControlInfoSequence;

        infoLen = strAutoDispatchControl_info_GetDR_out.strLotAutoDispatchControlInfoSeq.length();
        tmpLotAutoDispatchControlInfoSequence.length( infoLen + updateLen );
        for( infoCnt = 0; infoCnt < infoLen; infoCnt++ )
        {
            CORBA::Boolean bDeleteFlag = FALSE;
            for( updateCnt = 0; updateCnt < updateLen; updateCnt++ )
            {
                if( CIMFWStrCmp( strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].updateMode, SP_AutoDispatchControl_Delete ) == 0 )
                {
                    if( ( CIMFWStrCmp( strAutoDispatchControl_info_GetDR_out.strLotAutoDispatchControlInfoSeq[infoCnt].routeID.identifier, strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].routeID.identifier ) == 0 ) &&
                        ( CIMFWStrCmp( strAutoDispatchControl_info_GetDR_out.strLotAutoDispatchControlInfoSeq[infoCnt].operationNumber, strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].operationNumber ) == 0 ) )
                    {
                        PPT_METHODTRACE_V3( "", "This information is Delete", strAutoDispatchControl_info_GetDR_out.strLotAutoDispatchControlInfoSeq[infoCnt].routeID.identifier, strAutoDispatchControl_info_GetDR_out.strLotAutoDispatchControlInfoSeq[infoCnt].operationNumber );
                        bDeleteFlag = TRUE;
                        break;
                    }
                }
            }

            if( bDeleteFlag == FALSE )
            {
                tmpLotAutoDispatchControlInfoSequence[tmpLen] = strAutoDispatchControl_info_GetDR_out.strLotAutoDispatchControlInfoSeq[infoCnt];
                tmpLen++;
            }
        }

        //----------------------------//
        //  Check Create Information  //
        //----------------------------//
        for( updateCnt = 0; updateCnt < updateLen; updateCnt++ )
        {
            if( CIMFWStrCmp( strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].updateMode, SP_AutoDispatchControl_Create ) == 0 )
            {
                PPT_METHODTRACE_V3( "", "Check Update Information", strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].routeID.identifier, strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].operationNumber );
                if( ( CIMFWStrCmp( strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].routeID.identifier, "*" ) == 0 ) &&
                    ( CIMFWStrCmp( strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].operationNumber, "*" ) == 0 ) )
                {
                    PPT_METHODTRACE_V1( "", "Check routeID=Any operationNUmber=Any" );
                    for( tmpCnt = 0; tmpCnt < tmpLen; tmpCnt++ )
                    {
                        if( ( CIMFWStrCmp( tmpLotAutoDispatchControlInfoSequence[tmpCnt].routeID.identifier, "*" ) == 0 ) &&
                            ( CIMFWStrCmp( tmpLotAutoDispatchControlInfoSequence[tmpCnt].operationNumber, "*" ) == 0 ) )
                        {
                            PPT_METHODTRACE_V3( "", "Invalid Information Exist! routeID=* operationNumber=*", tmpLotAutoDispatchControlInfoSequence[tmpCnt].routeID.identifier, tmpLotAutoDispatchControlInfoSequence[tmpCnt].operationNumber );
                            SET_MSG_RC( strAutoDispatchControl_info_Check_out, MSG_INVALID_DISPCTRL_INFORMATION, RC_INVALID_DISPCTRL_INFORMATION );
                            return RC_INVALID_DISPCTRL_INFORMATION; 
                        }
                        else if( ( CIMFWStrCmp( tmpLotAutoDispatchControlInfoSequence[tmpCnt].routeID.identifier, "*" ) != 0 ) &&
                                 ( CIMFWStrCmp( tmpLotAutoDispatchControlInfoSequence[tmpCnt].operationNumber, "*" ) == 0 ) )
                        {
                            PPT_METHODTRACE_V3( "", "Invalid Information Exist! routeID=Set operationNumber=*", tmpLotAutoDispatchControlInfoSequence[tmpCnt].routeID.identifier, tmpLotAutoDispatchControlInfoSequence[tmpCnt].operationNumber );
                            SET_MSG_RC( strAutoDispatchControl_info_Check_out, MSG_INVALID_DISPCTRL_INFORMATION, RC_INVALID_DISPCTRL_INFORMATION );
                            return RC_INVALID_DISPCTRL_INFORMATION; 
                        }
                        else if( ( CIMFWStrCmp( tmpLotAutoDispatchControlInfoSequence[tmpCnt].routeID.identifier, "*" ) != 0 ) &&
                                 ( CIMFWStrCmp( tmpLotAutoDispatchControlInfoSequence[tmpCnt].operationNumber, "*" ) != 0 ) )
                        {
                            PPT_METHODTRACE_V3( "", "Invalid Information Exist! routeID=Set operationNumber=Set", tmpLotAutoDispatchControlInfoSequence[tmpCnt].routeID.identifier, tmpLotAutoDispatchControlInfoSequence[tmpCnt].operationNumber );
                            SET_MSG_RC( strAutoDispatchControl_info_Check_out, MSG_INVALID_DISPCTRL_INFORMATION, RC_INVALID_DISPCTRL_INFORMATION );
                            return RC_INVALID_DISPCTRL_INFORMATION; 
                        }
                    }
                }
                else if( ( CIMFWStrCmp( strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].routeID.identifier, "*" ) != 0 ) &&
                         ( CIMFWStrCmp( strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].operationNumber, "*" ) == 0 ) )
                {
//PSN000042280 add start
                    // Check existence RouteID
                    PPT_METHODTRACE_V1("", "Check existence RouteID");
//DSN000096135                    objProcess_operationListForRoute_out strProcess_operationListForRoute_out;
//DSN000096135                    rc = process_operationListForRoute( strProcess_operationListForRoute_out, 
//DSN000096135                                                        strObjCommonIn,
//DSN000096135                                                        strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].routeID,
//DSN000096135                                                        "",
//DSN000096135                                                        1);
//DSN000096135 add start
                    objProcess_operationListForRoute_out__160 strProcess_operationListForRoute_out ;
                    objProcess_operationListForRoute_in__160 strProcess_operationListForRoute_in;
                    strProcess_operationListForRoute_in.routeID = strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].routeID;
                    strProcess_operationListForRoute_in.operationID.identifier = CIMFWStrDup("");
                    strProcess_operationListForRoute_in.operationNumber = CIMFWStrDup("");
                    strProcess_operationListForRoute_in.pdType = CIMFWStrDup("");
                    strProcess_operationListForRoute_in.searchCount = 1;
                    rc = process_operationListForRoute__160( strProcess_operationListForRoute_out, strObjCommonIn, strProcess_operationListForRoute_in);
//DSN000096135 add end.
                    if (rc != RC_OK)
                    {
//DSN000096135                        PPT_METHODTRACE_V2( "", "process_operationListForRoute() != RC_OK", rc );
                        PPT_METHODTRACE_V2( "", "process_operationListForRoute__160() != RC_OK", rc );   //DSN000096135
                        strAutoDispatchControl_info_Check_out.strResult = strProcess_operationListForRoute_out.strResult;
                        return rc;
                    
                    }
//PSN000042280 add end
                    PPT_METHODTRACE_V1( "", "Check routeID=Set operationNUmber=Any" );
                    for( tmpCnt = 0; tmpCnt < tmpLen; tmpCnt++ )
                    {
                        if( ( CIMFWStrCmp( tmpLotAutoDispatchControlInfoSequence[tmpCnt].routeID.identifier, "*" ) == 0 ) &&
                            ( CIMFWStrCmp( tmpLotAutoDispatchControlInfoSequence[tmpCnt].operationNumber, "*" ) == 0 ) )
                        {
                            PPT_METHODTRACE_V3( "", "Invalid Information Exist! routeID=* operationNumber=*", tmpLotAutoDispatchControlInfoSequence[tmpCnt].routeID.identifier, tmpLotAutoDispatchControlInfoSequence[tmpCnt].operationNumber );
                            SET_MSG_RC( strAutoDispatchControl_info_Check_out, MSG_INVALID_DISPCTRL_INFORMATION, RC_INVALID_DISPCTRL_INFORMATION );
                            return RC_INVALID_DISPCTRL_INFORMATION; 
                        }
                        else if( ( CIMFWStrCmp( tmpLotAutoDispatchControlInfoSequence[tmpCnt].routeID.identifier, strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].routeID.identifier ) == 0 ) &&
                                 ( CIMFWStrCmp( tmpLotAutoDispatchControlInfoSequence[tmpCnt].operationNumber, "*" ) == 0 ) )
                        {
                            PPT_METHODTRACE_V3( "", "Invalid Information Exist! routeID=Same operationNumber=*", tmpLotAutoDispatchControlInfoSequence[tmpCnt].routeID.identifier, tmpLotAutoDispatchControlInfoSequence[tmpCnt].operationNumber );
                            SET_MSG_RC( strAutoDispatchControl_info_Check_out, MSG_INVALID_DISPCTRL_INFORMATION, RC_INVALID_DISPCTRL_INFORMATION );
                            return RC_INVALID_DISPCTRL_INFORMATION; 
                        }
                        else if( ( CIMFWStrCmp( tmpLotAutoDispatchControlInfoSequence[tmpCnt].routeID.identifier, strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].routeID.identifier ) == 0 ) &&
                                 ( CIMFWStrCmp( tmpLotAutoDispatchControlInfoSequence[tmpCnt].operationNumber, "*" ) != 0 ) )
                        {
                            PPT_METHODTRACE_V3( "", "Invalid Information Exist! routeID=Same operationNumber=Set", tmpLotAutoDispatchControlInfoSequence[tmpCnt].routeID.identifier, tmpLotAutoDispatchControlInfoSequence[tmpCnt].operationNumber );
                            SET_MSG_RC( strAutoDispatchControl_info_Check_out, MSG_INVALID_DISPCTRL_INFORMATION, RC_INVALID_DISPCTRL_INFORMATION );
                            return RC_INVALID_DISPCTRL_INFORMATION; 
                        }
                    }
                }
                else if( ( CIMFWStrCmp( strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].routeID.identifier, "*" ) != 0 ) &&
                         ( CIMFWStrCmp( strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].operationNumber, "*" ) != 0 ) )
                {
//PSN000042280 add start
                    // Check existence RouteID and Operation Number
                    PPT_METHODTRACE_V1("", "Check existence RouteID and Operation Number");
//DSN000096135                    objProcess_operationListForRoute_out strProcess_operationListForRoute_out;
//DSN000096135                    rc = process_operationListForRoute( strProcess_operationListForRoute_out, 
//DSN000096135                                                        strObjCommonIn,
//DSN000096135                                                        strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].routeID,
//DSN000096135                                                        strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].operationNumber,
//DSN000096135                                                        1);
//DSN000096135 add start
                    objProcess_operationListForRoute_out__160 strProcess_operationListForRoute_out ;
                    objProcess_operationListForRoute_in__160 strProcess_operationListForRoute_in;
                    strProcess_operationListForRoute_in.routeID = strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].routeID;
                    strProcess_operationListForRoute_in.operationID.identifier = CIMFWStrDup("");
                    strProcess_operationListForRoute_in.operationNumber = CIMFWStrDup(strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].operationNumber);
                    strProcess_operationListForRoute_in.pdType = CIMFWStrDup("");
                    strProcess_operationListForRoute_in.searchCount = 1;
                    rc = process_operationListForRoute__160( strProcess_operationListForRoute_out, strObjCommonIn, strProcess_operationListForRoute_in);
//DSN000096135 add end.
                    if (rc != RC_OK)
                    {
//DSN000096135                        PPT_METHODTRACE_V2( "", "process_operationListForRoute() != RC_OK", rc );
                        PPT_METHODTRACE_V2( "", "process_operationListForRoute__160() != RC_OK", rc );  //DSN000096135
                        strAutoDispatchControl_info_Check_out.strResult = strProcess_operationListForRoute_out.strResult;
                        return rc;
                    
                    }
//PSN000042280 add end
                    PPT_METHODTRACE_V1( "", "Check routeID=Set operationNUmber=Set" );
                    for( tmpCnt = 0; tmpCnt < tmpLen; tmpCnt++ )
                    {
                        if( ( CIMFWStrCmp( tmpLotAutoDispatchControlInfoSequence[tmpCnt].routeID.identifier, "*" ) == 0 ) &&
                            ( CIMFWStrCmp( tmpLotAutoDispatchControlInfoSequence[tmpCnt].operationNumber, "*" ) == 0 ) )
                        {
                            PPT_METHODTRACE_V3( "", "Invalid Information Exist! routeID=* operationNumber=*", tmpLotAutoDispatchControlInfoSequence[tmpCnt].routeID.identifier, tmpLotAutoDispatchControlInfoSequence[tmpCnt].operationNumber );
                            SET_MSG_RC( strAutoDispatchControl_info_Check_out, MSG_INVALID_DISPCTRL_INFORMATION, RC_INVALID_DISPCTRL_INFORMATION );
                            return RC_INVALID_DISPCTRL_INFORMATION; 
                        }
                        else if( ( CIMFWStrCmp( tmpLotAutoDispatchControlInfoSequence[tmpCnt].routeID.identifier, strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].routeID.identifier ) == 0 ) &&
                                 ( CIMFWStrCmp( tmpLotAutoDispatchControlInfoSequence[tmpCnt].operationNumber, "*" ) == 0 ) )
                        {
                            PPT_METHODTRACE_V3( "", "Invalid Information Exist! routeID=Same operationNumber=*", tmpLotAutoDispatchControlInfoSequence[tmpCnt].routeID.identifier, tmpLotAutoDispatchControlInfoSequence[tmpCnt].operationNumber );
                            SET_MSG_RC( strAutoDispatchControl_info_Check_out, MSG_INVALID_DISPCTRL_INFORMATION, RC_INVALID_DISPCTRL_INFORMATION );
                            return RC_INVALID_DISPCTRL_INFORMATION; 
                        }
                        else if( ( CIMFWStrCmp( tmpLotAutoDispatchControlInfoSequence[tmpCnt].routeID.identifier, strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].routeID.identifier ) == 0 ) &&
                                 ( CIMFWStrCmp( tmpLotAutoDispatchControlInfoSequence[tmpCnt].operationNumber, strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].operationNumber ) == 0 ) )
                        {
                            PPT_METHODTRACE_V3( "", "Invalid Information Exist! routeID=Same operationNumber=Same", tmpLotAutoDispatchControlInfoSequence[tmpCnt].routeID.identifier, tmpLotAutoDispatchControlInfoSequence[tmpCnt].operationNumber );
                            SET_MSG_RC( strAutoDispatchControl_info_Check_out, MSG_INVALID_DISPCTRL_INFORMATION, RC_INVALID_DISPCTRL_INFORMATION );
                            return RC_INVALID_DISPCTRL_INFORMATION; 
                        }
                    }
                }
                else
                {
                    SET_MSG_RC( strAutoDispatchControl_info_Check_out, MSG_INVALID_DISPCTRL_INFORMATION, RC_INVALID_DISPCTRL_INFORMATION );
                    return RC_INVALID_DISPCTRL_INFORMATION; 
                }

                tmpLotAutoDispatchControlInfoSequence[tmpLen].lotID             = strLotAutoDispatchControlUpdateInfo.lotID;
                tmpLotAutoDispatchControlInfoSequence[tmpLen].routeID           = strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].routeID;
                tmpLotAutoDispatchControlInfoSequence[tmpLen].operationNumber   = CIMFWStrDup( strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].operationNumber );
                tmpLotAutoDispatchControlInfoSequence[tmpLen].singleTriggerFlag = strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].singleTriggerFlag;
                tmpLotAutoDispatchControlInfoSequence[tmpLen].description       = CIMFWStrDup( strLotAutoDispatchControlUpdateInfo.strAutoDispatchControlUpdateInfoSeq[updateCnt].description );
                tmpLen++;
            }
        }

        //--------------------//
        //  Return to Caller  //
        //--------------------//
        PPT_METHODTRACE_EXIT( "PPTManager_i::autoDispatchControl_info_Check" );
        return RC_OK ;
    }
    CATCH_GLOBAL_EXCEPTIONS( strAutoDispatchControl_info_Check_out, autoDispatchControl_info_Check, methodName );
}
