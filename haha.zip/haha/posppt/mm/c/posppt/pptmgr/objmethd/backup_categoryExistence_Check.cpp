#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/backup_categoryExistence_Check.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:28:58 [ 7/13/07 19:28:59 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: backup_categoryExistence_Check.cpp
//

#include "pptmgr.hpp"

// Class: PPTManager
//
// Service: backup_categoryExistence_Check()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2002/09/03 D4200062 K.Kimura       Initial : Backup Operation (R4.2)
//
// Description:
//
// Return:
//    long
//
// Parameter:
//    objBackup_categoryExistence_Check_out& strBackup_categoryExistence_Check_out
//    const  pptObjCommonIn&           strObjCommonIn
//    const  char *                    categoryLevel
//    const  char *                    categoryID
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long PPTManager_i::backup_categoryExistence_Check(
    objBackup_categoryExistence_Check_out& strBackup_categoryExistence_Check_out,
    const  pptObjCommonIn&           strObjCommonIn,
    const  char *                    categoryLevel,
    const  char *                    categoryID)
{
    char * methodName = NULL ;

    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::backup_categoryExistence_Check") ;

        //-------------------------------------------------//
        // Check categoryLevel whether it is valid or not. //
        //-------------------------------------------------//
        if(  ( 0 != CIMFWStrCmp(categoryLevel,SP_BackupDefinitionCategory_Product      ))
          && ( 0 != CIMFWStrCmp(categoryLevel,SP_BackupDefinitionCategory_ProductGroup ))
          && ( 0 != CIMFWStrCmp(categoryLevel,SP_BackupDefinitionCategory_Technology   )) )
        {
            PPT_METHODTRACE_V2("","categoryLevel is invalid.",categoryLevel) ;
            SET_MSG_RC( strBackup_categoryExistence_Check_out,
                        MSG_INVALID_INPUT_PARM,
                        RC_INVALID_INPUT_PARM ) ;
            return RC_INVALID_INPUT_PARM ;
        }

        //----------------------------------//
        //   If categoryID is wild card     //
        //----------------------------------//
        if( 0 == CIMFWStrCmp(categoryID,SP_Default_char) )
        {
            PPT_METHODTRACE_V1("","0 == CIMFWStrCmp(categoryID,SP_Default_char)") ;
            return (RC_OK) ;
        }

        objectIdentifier tmpID ;
        tmpID.identifier = categoryID ;

        //------------------------------//
        //   Check produtID             //
        //------------------------------//
        if( 0 == CIMFWStrCmp(categoryLevel,SP_BackupDefinitionCategory_Product) )
        {
            PosProductSpecification_var aPosProduct ;
            CORBA::Boolean prodFound = TRUE ;

            PPT_CONVERT_PRODUCTID_TO_PRODUCTSP_WITH_NO_RETURN(aPosProduct, tmpID) ;
            if( prodFound == FALSE )
            {
                PPT_METHODTRACE_V1("","prodFound == FALSE") ;
                PPT_SET_MSG_RC_KEY( strBackup_categoryExistence_Check_out,
                                    MSG_NOT_FOUND_PRODUCTID,
                                    RC_NOT_FOUND_PRODUCTID,
                                    categoryID ) ;
                return RC_NOT_FOUND_PRODUCTID ;
            }
        }
        //-----------------------------//
        //   Check produtGroupID       //
        //-----------------------------//
        else if( 0 == CIMFWStrCmp(categoryLevel,SP_BackupDefinitionCategory_ProductGroup ) )
        {
            PosProductGroup_var aPosProductGroup ;
            CORBA::Boolean productGroupFound = TRUE ;
            PPT_CONVERT_PRODUCTGROUPID_TO_PRODUCTGROUP_WITH_NO_RETURN(aPosProductGroup, tmpID) ;
            if( productGroupFound ==FALSE )
            {
                PPT_SET_MSG_RC_KEY( strBackup_categoryExistence_Check_out,
                                    MSG_NOT_FOUND_PRODUCTGROUP,
                                    RC_NOT_FOUND_PRODUCTGROUP,
                                    categoryID ) ;
                return RC_NOT_FOUND_PRODUCTGROUP ;
            }
        }
        //----------------------------//
        //   Check technologyID       //
        //----------------------------//
        else if( 0 == CIMFWStrCmp(categoryLevel,SP_BackupDefinitionCategory_Technology) )
        {
            PosTechnology_var aPosTechnology ;
            CORBA::Boolean technologyFound = TRUE ;
            PPT_CONVERT_TECHNOLOGYID_TO_TECHNOLOGY_WITH_NO_RETURN(aPosTechnology, tmpID)
            if( technologyFound == FALSE )
            {
                PPT_SET_MSG_RC_KEY( strBackup_categoryExistence_Check_out,
                                    MSG_NOT_FOUND_TECHNOLOGY,
                                    RC_NOT_FOUND_TECHNOLOGY,
                                    categoryID ) ;
                return RC_NOT_FOUND_TECHNOLOGY ;
            }
        }

        //----------------------------//
        //   Return to Caller         //
        //----------------------------//
        PPT_METHODTRACE_EXIT("PPTManager_i::backup_categoryExistence_Check") ;
        return (RC_OK) ;
    }
    CATCH_GLOBAL_EXCEPTIONS(strBackup_categoryExistence_Check_out,backup_categoryExistence_Check,methodName)
}
