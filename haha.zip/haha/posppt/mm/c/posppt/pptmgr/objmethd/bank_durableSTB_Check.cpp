//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2015. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2015. All rights reserved.
//
// SiView
// Name: bank_durableSTB_Check.cpp
//

#include "pptmgr.hpp"

#include "pbank.hh"
#include "ppcdf.hh"
#include "pcas.hh"
#include "prtclp.hh"
#include "ppcdr.hh"

// Class: PPTManager
//
// Service: bank_durableSTB_Check()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2015/07/21 DSN000096126 JQ.Shao        Durable Process Flow Control Support.
//
//
//[Function Description]:
// Check Durable is InBank to StartBank of specified route.
//
//
// [Input Parameters]:
//   const pptObjCommonIn&                        strObjCommonIn
//   const objBank_durableSTB_Check_in&           strBank_durableSTB_Check_in
//
//   typedef struct objBank_durableSTB_Check_in _struct {
//       objectIdentifier           routeID;
//       string                     durableCategory;
//       objectIdentifierSequence   durables;
//       any                        siInfo;
//   }  objBank_durableSTB_Check_in;
//
// [Output Parameters]:
//   objBase_out&      objBank_durableSTB_Check_out
//
// [Return Value]:
//
//   Return Code                Messsage ID
//   -------------------------- --------------------------------------------------
//   RC_OK                      MSG_OK
//   RC_INVALID_PARAMETER       MSG_INVALID_PARAMETER
//   RC_NOT_FOUND_BANK          MSG_NOT_FOUND_BANK
//   RC_NOT_DURABLE_STARTBANK   MSG_NOT_DURABLE_STARTBANK
//   RC_NOT_MATCH_STARTBANK_FOR_DURABLE MSG_NOT_MATCH_STARTBANK_FOR_DURABLE
//

CORBA::Long PPTManager_i::bank_durableSTB_Check(
    objBank_durableSTB_Check_out&               strBank_durableSTB_Check_out,
    const pptObjCommonIn&                       strObjCommonIn,
    const objBank_durableSTB_Check_in&          strBank_durableSTB_Check_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::bank_durableSTB_Check");

        PosBank_var                    aStartBank;
        PosBank_var                    aBank;

        if(CIMFWStrLen(strBank_durableSTB_Check_in.routeID.identifier) == 0)
        {
            PPT_METHODTRACE_V1("", "routeID is blank");
            SET_MSG_RC( strBank_durableSTB_Check_out, MSG_INVALID_PARAMETER, RC_INVALID_PARAMETER );
            return(RC_INVALID_PARAMETER);
        }

        PosProcessDefinition_var mainPD;
        PPT_CONVERT_ROUTEID_TO_PROCESSDEFINITION_OR( mainPD, 
                                                     strBank_durableSTB_Check_in.routeID, 
                                                     strBank_durableSTB_Check_out, 
                                                     bank_durableSTB_Check );

        if(! CORBA::is_nil(mainPD))
        {
            PPT_METHODTRACE_V1("", "mainPD is not nil");

            //-----------------------------------------------------
            // Get and check route's pd type
            //-----------------------------------------------------
            CORBA::String_var processDefinitionType;
            try
            {
                processDefinitionType = mainPD->getProcessDefinitionType();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessDefinition::getProcessDefinitionType)

            if( 0 != CIMFWStrCmp( processDefinitionType, SP_MAINPDTYPE_DURABLE ) )
            {
                PPT_METHODTRACE_V1("", "processDefinitionType is not SP_MAINPDTYPE_DURABLE");
                SET_MSG_RC( strBank_durableSTB_Check_out, MSG_INVALID_ROUTE_TYPE, RC_INVALID_ROUTE_TYPE );
                return(RC_INVALID_ROUTE_TYPE);
            }

            //-----------------------------------------------------
            // get object reference of Start Bank.
            //-----------------------------------------------------
            PPT_METHODTRACE_V2("", "get object reference of Start Bank", __LINE__);

            try
            {
                aStartBank = mainPD->getStartBank();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProcessDefinition::getStartBank)

            if ( CORBA::is_nil(aStartBank) )
            {
                PPT_METHODTRACE_V1("", "aStartBank is nil");
                PPT_SET_MSG_RC_KEY( strBank_durableSTB_Check_out, MSG_NOT_FOUND_BANK, RC_NOT_FOUND_BANK, "" );
                return RC_NOT_FOUND_BANK;
            }

            CORBA::Boolean bSTBBankFlag;
            try
            {
                bSTBBankFlag = aStartBank->isSTBBank();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosBank::isSTBBank)

            CORBA::String_var startBankID = CIMFWStrDup("");
            try
            {
                startBankID = aStartBank->getIdentifier();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosBank::getIdentifier);

            if( bSTBBankFlag == FALSE )
            {
                PPT_METHODTRACE_V1("", "bSTBBankFlag is FALSE");
                PPT_SET_MSG_RC_KEY( strBank_durableSTB_Check_out, MSG_NOT_DURABLE_STARTBANK, RC_NOT_DURABLE_STARTBANK, startBankID );
                return RC_NOT_DURABLE_STARTBANK;
            }

            CORBA::ULong durableLen = strBank_durableSTB_Check_in.durables.length();
            if(0 == durableLen)
            {
                PPT_METHODTRACE_V1("", "The in-parameter is invalid.");
                SET_MSG_RC(strBank_durableSTB_Check_out, MSG_INVALID_PARAMETER, RC_INVALID_PARAMETER);
                return RC_INVALID_PARAMETER;
            }

            PPT_METHODTRACE_V2("", "durableIDSeq.length()", durableLen);
            for(CORBA::ULong durableSeq = 0; durableSeq < durableLen; durableSeq++)
            {
                if ( 0 == CIMFWStrCmp(strBank_durableSTB_Check_in.durableCategory, SP_DurableCat_Cassette) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory is Cassette");
                    PosCassette_var aCassette;
                    PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                                           strBank_durableSTB_Check_in.durables[durableSeq],
                                                           strBank_durableSTB_Check_out,
                                                           bank_durableSTB_Check );

                    try
                    {
                        aBank = aCassette->getBank();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getBank);
                }
                else if( 0 == CIMFWStrCmp(strBank_durableSTB_Check_in.durableCategory, SP_DurableCat_ReticlePod) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory is ReticlePod");
                    PosReticlePod_var aReticlePod;
                    PPT_CONVERT_RETICLEPODID_TO_RETICLEPOD_OR( aReticlePod,
                                                               strBank_durableSTB_Check_in.durables[durableSeq],
                                                               strBank_durableSTB_Check_out,
                                                               bank_durableSTB_Check );

                    try
                    {
                        aBank = aReticlePod->getBank();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getBank);
                }
                else if( 0 == CIMFWStrCmp(strBank_durableSTB_Check_in.durableCategory, SP_DurableCat_Reticle) )
                {
                    PPT_METHODTRACE_V1("", "durableCategory is Reticle");
                    PosProcessDurable_var aReticle;
                    PPT_CONVERT_RETICLEID_TO_RETICLE_OR( aReticle,
                                                         strBank_durableSTB_Check_in.durables[durableSeq],
                                                         strBank_durableSTB_Check_out,
                                                         bank_durableSTB_Check );

                    try
                    {
                        aBank = aReticle->getBank();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessDurable::getBank);
                }

                if(CORBA::is_nil(aBank))
                {
                    PPT_METHODTRACE_V1("", "aBank is Nil");
                    PPT_SET_MSG_RC_KEY( strBank_durableSTB_Check_out, MSG_NOT_FOUND_BANK, RC_NOT_FOUND_BANK, "" );
                    return RC_NOT_FOUND_BANK;
                }

                CORBA::String_var bankID = CIMFWStrDup("");
                try
                {
                    bankID = aBank->getIdentifier();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosBank::getIdentifier);

                if(0 != CIMFWStrCmp(startBankID, bankID))
                {
                    PPT_METHODTRACE_V1("", "startBankID is not same as bankID");
                    PPT_SET_MSG_RC_KEY( strBank_durableSTB_Check_out,
                                        MSG_NOT_MATCH_STARTBANK_FOR_DURABLE,
                                        RC_NOT_MATCH_STARTBANK_FOR_DURABLE, 
                                        strBank_durableSTB_Check_in.durables[durableSeq].identifier );
                    return RC_NOT_MATCH_STARTBANK_FOR_DURABLE;
                }
            }
        }
        PPT_METHODTRACE_EXIT("PPTManager_i::bank_durableSTB_Check");

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strBank_durableSTB_Check_out, bank_durableSTB_Check, methodName)
}