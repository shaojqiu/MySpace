#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_controlJobID_Get.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:33:44 [ 7/13/07 19:33:45 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_controlJobID_Get.cpp
//

#include "pptmgr.hpp"

#include "plot.hh"
#include "pcas.hh"
#include "ppcope.hh"

//[Object Function Name]: long   cassette_controlJobID_Get
//
// Date        Level  Author         Note
// ----------  -----  -------------  -------------------------------------------
//
//
//[Function Description]:
//  Get controlJobID in PosCassette object and set it to returned structure.
//
//[Input Parameters]:
//  in  pptObjCommonIn        strObjCommonIn;
//  in  objectIdentifier      cassetteID;
//
//[Output Parameters]:
//  out objCassette_controlJobID_Get_out   strCassette_controlJobID_Get_out;
//
//  typedef struct objCassette_controlJobID_Get_out_struct {
//      pptRetCode            strResult;
//      objectIdentifier      controlJobID;
//  } objCassette_controlJobID_Get_out;
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//  RC_NOT_FOUND_CASSETTE     MSG_NOT_FOUND_CASSETTE
//  RC_LOCKED_BY_ANOTHER      MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR           MSG_SYSTEM_ERROR

CORBA::Long PPTManager_i::cassette_controlJobID_Get(
                                    objCassette_controlJobID_Get_out& strCassette_controlJobID_Get_out,
                                    const pptObjCommonIn& strObjCommonIn,
                                    const objectIdentifier& cassetteID )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_controlJobID_Get");

        /*----------------*/
        /*   Initialize   */
        /*----------------*/

        /*-------------------------*/
        /*   Get Cassette Object   */
        /*-------------------------*/
        PPT_METHODTRACE_V2("PPTManager_i::cassette_controlJobID_Get","Get Cassette Object", __LINE__);

        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                               cassetteID,
                                               strCassette_controlJobID_Get_out,
                                               cassette_controlJobID_Get );

        /*----------------------*/
        /*   Get controlJobID   */
        /*----------------------*/
        PPT_METHODTRACE_V2("PPTManager_i::cassette_controlJobID_Get","Get controlJobID", __LINE__);

        PosControlJob_var aControlJob;
        try
        {
            aControlJob = aCassette->getControlJob();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)

        if ( CORBA::is_nil(aControlJob) )
        {
            PPT_METHODTRACE_V1("PPTManager_i::cassette_controlJobID_Get", "aControlJob is nil");

            objectIdentifier controlJobID_nil;
            strCassette_controlJobID_Get_out.controlJobID = controlJobID_nil;
        }
        else
        {
            PPT_METHODTRACE_V1("PPTManager_i::cassette_controlJobID_Get", "aControlJob is not nil");

            PPT_SET_OBJECT_IDENTIFIER( strCassette_controlJobID_Get_out.controlJobID,
                                       aControlJob,
                                       strCassette_controlJobID_Get_out,
                                       cassette_controlJobID_Get,
                                       PosControlJob );
        }

        /*----------------------*/
        /*   Return to Caller   */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_controlJobID_Get");

        return( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_controlJobID_Get_out, cassette_controlJobID_Get, methodName)
}
