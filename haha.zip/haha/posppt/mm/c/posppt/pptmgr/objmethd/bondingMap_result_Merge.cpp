//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2017. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2017. All rights reserved.
//
// SiView
// Name: bondingMap_result_Merge.cpp
//

#include "pptmgr.hpp"

// Class: PPTManager
//
// Service: bondingMap_result_Merge()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2010-04-15 DSIV00001830 R.Iriguchi     Initial Release
// 2010-06-30 PSIV00002172 R.Okano        Bonding Map Result cannot be modified.
// 2017-05-09 PSN000104991 S.Kawabe       When bonding group is created, boundary error of sequence length occurs.
//
// Description:
//    This function inquires information of specified bonding group.
// Return:
//    long
//
// Parameter:
//  [Input Parameters]:
//    const pptObjCommonIn&                       strObjCommonIn
//    const objBondingMap_result_Merge_in&        strBondingMap_result_Merge_in
//
//    //InParameter of bondingMap_result_Merge
//    typedef struct objBondingMap_result_Merge_in_struct {
//        objectIdentifier                    equipmentID;                            //<i>Target Equipment ID
//        objectIdentifier                    controlJobID;                           //<i>Control Job ID
//        pptBondingMapInfoSequence           strBondingMapInfoSeq;                   //<i>Sequence of Bonding Map
//        boolean                             consistencyCheckFlag;
//        any                                 siInfo;                                 //<i>Reserved for SI customization
//    } objBondingMap_result_Merge_in;
//
//  [Output Parameters]:
//    objBondingMap_result_Merge_out&             strBondingMap_result_Merge_out
//
//    //Result of bondingMap_result_Merge
//    typedef struct objBondingMap_result_Merge_out_struct {
//        pptRetCode                          strResult;                              //<i>Transaction Execution Result Information
//        pptBondingMapInfoSequence           strBondingMapInfoSeq;                   //<i>Sequence of Bonding Map
//        any                                 siInfo;                                 //<i>Reserved for SI customization
//    } objBondingMap_result_Merge_out;
//
//  [Return Value]:
//    Return Code                      Message ID
//    -------------------------------- -------------------------------------------
//    RC_OK                            MSG_OK
//    RC_LOCKED_BY_ANOTHER             MSG_LOCKED_BY_ANOTHER
//    RC_SYSTEM_ERROR                  MSG_SYSTEM_ERROR
//    RC_NOT_FOUND_BONDGRP             MSG_NOT_FOUND_BONDGRP
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//
CORBA::Long PPTManager_i::bondingMap_result_Merge(
    objBondingMap_result_Merge_out&         strBondingMap_result_Merge_out,
    const pptObjCommonIn&                       strObjCommonIn,
    const objBondingMap_result_Merge_in&    strBondingMap_result_Merge_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY( "PPTManager_i::bondingMap_result_Merge" );
        CORBA::Long rc;

        const pptBondingMapInfoSequence& inBondingMapInfoSeq = strBondingMap_result_Merge_in.strBondingMapInfoSeq;
        const pptBondingGroupInfoSequence& strBondingGroupInfoSeq = strBondingMap_result_Merge_in.strBondingGroupInfoSeq;
        pptBondingMapInfoSequence& outBondingMapInfoSeq = strBondingMap_result_Merge_out.strBondingMapInfoSeq;

        const CORBA::Long mapLen = inBondingMapInfoSeq.length();
        const CORBA::Long grpLen = strBondingGroupInfoSeq.length();
        outBondingMapInfoSeq.length( 0 );
        outBondingMapInfoSeq.length( mapLen );


        for ( CORBA::Long mapCnt = 0; mapCnt < mapLen; mapCnt++ )
        {
            PPT_METHODTRACE_V2( "", "Check Base Wafer:", inBondingMapInfoSeq[mapCnt].baseWaferID.identifier );

            //--------------------------------------------------------------
            //   Check if Base Wafer is in the Bonding Group.
            //--------------------------------------------------------------
            CORBA::Boolean waferFound = FALSE;
            CORBA::Long grpCnt, refCnt, refLen;
            for ( grpCnt = 0; grpCnt < grpLen; grpCnt++ )
            {
                refLen = strBondingGroupInfoSeq[grpCnt].strBondingMapInfoSequence.length();
                for ( refCnt = 0; refCnt < refLen; refCnt++ )
                {
                    if ( CIMFWStrCmp( strBondingGroupInfoSeq[grpCnt].strBondingMapInfoSequence[refCnt].baseWaferID.identifier,
                                      inBondingMapInfoSeq[mapCnt].baseWaferID.identifier ) == 0 )
                    {
                        PPT_METHODTRACE_V2( "", "Found", refCnt );
                        waferFound = TRUE;
                        break;
                    }
                }
                if ( waferFound )
                {
                    break;
                }
            }
            if ( !waferFound )
            {
                PPT_METHODTRACE_V1( "", "Base Wafer is not found in Bonding Group." );
                PPT_SET_MSG_RC_KEY2( strBondingMap_result_Merge_out,
                                     MSG_NOT_FOUND_BONDING_MAP, RC_NOT_FOUND_BONDING_MAP,
                                     inBondingMapInfoSeq[mapCnt].baseLotID.identifier,
                                     inBondingMapInfoSeq[mapCnt].baseWaferID.identifier );
                return RC_NOT_FOUND_BONDING_MAP;
            }
            const pptBondingMapInfoSequence& refBondingMapInfoSeq = strBondingGroupInfoSeq[grpCnt].strBondingMapInfoSequence;

            //--------------------------------------------------------------
            //   Merge Bonding Group ID.
            //--------------------------------------------------------------
            if ( CIMFWStrLen( inBondingMapInfoSeq[mapCnt].bondingGroupID ) == 0 )
            {
                outBondingMapInfoSeq[mapCnt].bondingGroupID = refBondingMapInfoSeq[refCnt].bondingGroupID;
            }
            else if ( CIMFWStrCmp( inBondingMapInfoSeq[mapCnt].bondingGroupID,
                                   refBondingMapInfoSeq[refCnt].bondingGroupID ) == 0 )
            {
                outBondingMapInfoSeq[mapCnt].bondingGroupID = inBondingMapInfoSeq[mapCnt].bondingGroupID;
            }
            else
            {
                PPT_METHODTRACE_V2( "", "Bonding Group ID differs.", refBondingMapInfoSeq[refCnt].bondingGroupID );
                PPT_SET_MSG_RC_KEY2( strBondingMap_result_Merge_out,
                                     MSG_NOT_FOUND_BONDING_MAP, RC_NOT_FOUND_BONDING_MAP,
                                     inBondingMapInfoSeq[mapCnt].baseLotID.identifier,
                                     inBondingMapInfoSeq[mapCnt].baseWaferID.identifier );
                return RC_NOT_FOUND_BONDING_MAP;
            }

            //--------------------------------------------------------------
            //   Merge Base Wafer ID.
            //--------------------------------------------------------------
            outBondingMapInfoSeq[mapCnt].baseWaferID = inBondingMapInfoSeq[mapCnt].baseWaferID;

            //--------------------------------------------------------------
            //   Merge Base Lot ID.
            //--------------------------------------------------------------
            if ( CIMFWStrLen( inBondingMapInfoSeq[mapCnt].baseLotID.identifier ) == 0 )
            {
                outBondingMapInfoSeq[mapCnt].baseLotID = refBondingMapInfoSeq[refCnt].baseLotID;
            }
            else if ( CIMFWStrCmp( inBondingMapInfoSeq[mapCnt].baseLotID.identifier,
                                   refBondingMapInfoSeq[refCnt].baseLotID.identifier ) == 0 )
            {
                outBondingMapInfoSeq[mapCnt].baseLotID = inBondingMapInfoSeq[mapCnt].baseLotID;
            }
            else
            {
                PPT_METHODTRACE_V2( "", "Base Lot ID is not correct.",
                                    refBondingMapInfoSeq[refCnt].baseLotID.identifier );
                PPT_SET_MSG_RC_KEY2( strBondingMap_result_Merge_out,
                                     MSG_LOT_WAFER_UNMATCH, RC_LOT_WAFER_UNMATCH,
                                     refBondingMapInfoSeq[refCnt].baseLotID.identifier,
                                     refBondingMapInfoSeq[refCnt].baseWaferID.identifier );
                return RC_LOT_WAFER_UNMATCH;
            }

            //--------------------------------------------------------------
            //   Merge Base Product ID.
            //--------------------------------------------------------------
            if ( CIMFWStrLen( inBondingMapInfoSeq[mapCnt].baseProductID.identifier ) == 0 )
            {
                outBondingMapInfoSeq[mapCnt].baseProductID = refBondingMapInfoSeq[refCnt].baseProductID;
            }
            else if ( CIMFWStrCmp( inBondingMapInfoSeq[mapCnt].baseProductID.identifier,
                                   refBondingMapInfoSeq[refCnt].baseProductID.identifier ) == 0 )
            {
                outBondingMapInfoSeq[mapCnt].baseProductID = inBondingMapInfoSeq[mapCnt].baseProductID;
            }
            else
            {
                PPT_METHODTRACE_V2( "", "Base Product ID is not correct.",
                                    refBondingMapInfoSeq[refCnt].baseProductID.identifier );
                PPT_SET_MSG_RC_KEY3( strBondingMap_result_Merge_out,
                                     MSG_WAFER_PRODUCTSPEC_UNMATCH, RC_PRODUCTSPEC_UNMATCH,
                                     refBondingMapInfoSeq[refCnt].baseProductID.identifier,
                                     refBondingMapInfoSeq[refCnt].baseWaferID.identifier,
                                     inBondingMapInfoSeq[mapCnt].baseProductID.identifier );
                return RC_PRODUCTSPEC_UNMATCH;
            }

            //--------------------------------------------------------------
            //   Merge Base Bonding Side.
            //--------------------------------------------------------------
            if ( CIMFWStrLen( inBondingMapInfoSeq[mapCnt].baseBondingSide ) == 0 )
            {
                outBondingMapInfoSeq[mapCnt].baseBondingSide = refBondingMapInfoSeq[refCnt].baseBondingSide;
            }
            else if ( CIMFWStrCmp( inBondingMapInfoSeq[mapCnt].baseBondingSide,
                                   refBondingMapInfoSeq[refCnt].baseBondingSide ) == 0 )
            {
                outBondingMapInfoSeq[mapCnt].baseBondingSide = inBondingMapInfoSeq[mapCnt].baseBondingSide;
            }
            else
            {
                PPT_METHODTRACE_V2( "", "Base Bonding Side differs.",
                                    refBondingMapInfoSeq[refCnt].baseBondingSide );
                PPT_SET_MSG_RC_KEY( strBondingMap_result_Merge_out,
                                    MSG_INVALID_PARM_FOR_BONDING_MAP_REPORT, RC_INVALID_PARM_FOR_BONDING_MAP_REPORT,
                                    "Base Bonding Side" );
                return RC_INVALID_PARM_FOR_BONDING_MAP_REPORT;
            }

            //--------------------------------------------------------------
            //   Merge Plan Top Wafer ID.
            //--------------------------------------------------------------
            if ( CIMFWStrLen( inBondingMapInfoSeq[mapCnt].planTopWaferID.identifier ) ==  0 )
            {
                outBondingMapInfoSeq[mapCnt].planTopWaferID = refBondingMapInfoSeq[refCnt].planTopWaferID;
            }
            else if ( CIMFWStrCmp( inBondingMapInfoSeq[mapCnt].planTopWaferID.identifier,
                                   refBondingMapInfoSeq[refCnt].planTopWaferID.identifier ) == 0 )
            {
                outBondingMapInfoSeq[mapCnt].planTopWaferID = inBondingMapInfoSeq[mapCnt].planTopWaferID;
            }
            else
            {
                PPT_METHODTRACE_V3( "", "Plan Top Wafer ID differs.",
                                    inBondingMapInfoSeq[mapCnt].planTopWaferID.identifier,
                                    inBondingMapInfoSeq[mapCnt].planTopLotID.identifier );
                PPT_SET_MSG_RC_KEY2( strBondingMap_result_Merge_out,
                                     MSG_NOT_FOUND_BONDING_MAP, RC_NOT_FOUND_BONDING_MAP,
                                     inBondingMapInfoSeq[mapCnt].planTopLotID.identifier,
                                     inBondingMapInfoSeq[mapCnt].planTopWaferID.identifier );
                return RC_NOT_FOUND_BONDING_MAP;
            }

            //--------------------------------------------------------------
            //   Merge Plan Top Lot ID.
            //--------------------------------------------------------------
            if ( CIMFWStrLen( inBondingMapInfoSeq[mapCnt].planTopLotID.identifier ) == 0 )
            {
                outBondingMapInfoSeq[mapCnt].planTopLotID = refBondingMapInfoSeq[refCnt].planTopLotID;
            }
            else if ( CIMFWStrCmp( inBondingMapInfoSeq[mapCnt].planTopLotID.identifier,
                                   refBondingMapInfoSeq[refCnt].planTopLotID.identifier ) == 0  )
            {
                outBondingMapInfoSeq[mapCnt].planTopLotID = inBondingMapInfoSeq[mapCnt].planTopLotID;
            }
            else
            {
                PPT_METHODTRACE_V3( "", "Plan Top Wafer ID differs.",
                                    inBondingMapInfoSeq[mapCnt].planTopWaferID.identifier,
                                    inBondingMapInfoSeq[mapCnt].planTopLotID.identifier );
                PPT_SET_MSG_RC_KEY2( strBondingMap_result_Merge_out,
                                     MSG_NOT_FOUND_BONDING_MAP, RC_NOT_FOUND_BONDING_MAP,
                                     inBondingMapInfoSeq[mapCnt].planTopLotID.identifier,
                                     inBondingMapInfoSeq[mapCnt].planTopWaferID.identifier );
                return RC_NOT_FOUND_BONDING_MAP;
            }

            //--------------------------------------------------------------
            //   Merge Plan Top Product ID.
            //--------------------------------------------------------------
            if ( CIMFWStrLen( inBondingMapInfoSeq[mapCnt].planTopProductID.identifier ) == 0 )
            {
                outBondingMapInfoSeq[mapCnt].planTopProductID = refBondingMapInfoSeq[refCnt].planTopProductID;
            }
            else if ( CIMFWStrCmp( inBondingMapInfoSeq[mapCnt].planTopProductID.identifier,
                                   refBondingMapInfoSeq[refCnt].planTopProductID.identifier ) == 0 )
            {
                outBondingMapInfoSeq[mapCnt].planTopProductID = inBondingMapInfoSeq[mapCnt].planTopProductID;
            }
            else
            {
                PPT_METHODTRACE_V2( "", "Plan Top Product ID differs.",
                                    inBondingMapInfoSeq[mapCnt].planTopProductID.identifier );
                PPT_SET_MSG_RC_KEY3( strBondingMap_result_Merge_out,
                                     MSG_WAFER_PRODUCTSPEC_UNMATCH, RC_PRODUCTSPEC_UNMATCH,
                                     inBondingMapInfoSeq[mapCnt].planTopProductID.identifier,
                                     inBondingMapInfoSeq[mapCnt].planTopWaferID.identifier,
                                     refBondingMapInfoSeq[refCnt].planTopProductID.identifier );
                return RC_PRODUCTSPEC_UNMATCH;
            }

            //--------------------------------------------------------------
            //   Merge Plan Top Product ID.
            //--------------------------------------------------------------
            if ( CIMFWStrLen( inBondingMapInfoSeq[mapCnt].planTopBondingSide ) == 0 )
            {
                outBondingMapInfoSeq[mapCnt].planTopBondingSide = refBondingMapInfoSeq[refCnt].planTopBondingSide;
            }
            else if ( CIMFWStrCmp( inBondingMapInfoSeq[mapCnt].planTopBondingSide,
                                   refBondingMapInfoSeq[refCnt].planTopBondingSide ) == 0 )
            {
                outBondingMapInfoSeq[mapCnt].planTopBondingSide = inBondingMapInfoSeq[mapCnt].planTopBondingSide;
            }
            else
            {
                PPT_METHODTRACE_V2( "", "Plan Top Bonding Side differs.",
                                    refBondingMapInfoSeq[refCnt].planTopBondingSide );
                PPT_SET_MSG_RC_KEY( strBondingMap_result_Merge_out,
                                    MSG_INVALID_PARM_FOR_BONDING_MAP_REPORT, RC_INVALID_PARM_FOR_BONDING_MAP_REPORT,
                                    "Top Bonding Side" );
                return RC_INVALID_PARM_FOR_BONDING_MAP_REPORT;
            }

            //--------------------------------------------------------------
            //   Set Actual Top Bonding Side.
            //--------------------------------------------------------------
            if ( CIMFWStrLen( inBondingMapInfoSeq[mapCnt].actualTopBondingSide ) == 0 )
            {
                outBondingMapInfoSeq[mapCnt].actualTopBondingSide = refBondingMapInfoSeq[refCnt].planTopBondingSide;
            }
            else
            {
                outBondingMapInfoSeq[mapCnt].actualTopBondingSide = inBondingMapInfoSeq[mapCnt].actualTopBondingSide;
            }

            //--------------------------------------------------------------
            //   Set Bonding Process State.
            //--------------------------------------------------------------
            outBondingMapInfoSeq[mapCnt].bondingProcessState = inBondingMapInfoSeq[mapCnt].bondingProcessState;    //PSIV00002172
//PSIV00002172            if ( CIMFWStrLen( refBondingMapInfoSeq[refCnt].bondingProcessState ) == 0 )
//PSIV00002172            {
//PSIV00002172                outBondingMapInfoSeq[mapCnt].bondingProcessState = inBondingMapInfoSeq[mapCnt].bondingProcessState;
//PSIV00002172            }
//PSIV00002172            else
//PSIV00002172            {
//PSIV00002172                PPT_METHODTRACE_V2( "", "Base Wafer is already reported.",
//PSIV00002172                                    refBondingMapInfoSeq[refCnt].baseWaferID.identifier );
//PSIV00002172                PPT_SET_MSG_RC_KEY2( strBondingMap_result_Merge_out,
//PSIV00002172                                     MSG_ALREADY_BONDING_MAP_RESULT_REPORTED, RC_ALREADY_BONDING_MAP_RESULT_REPORTED,
//PSIV00002172                                     refBondingMapInfoSeq[refCnt].baseLotID.identifier,
//PSIV00002172                                     refBondingMapInfoSeq[refCnt].baseWaferID.identifier );
//PSIV00002172                return RC_ALREADY_BONDING_MAP_RESULT_REPORTED;
//PSIV00002172            }

            if ( CIMFWStrLen( inBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier ) == 0 )
            {
                PPT_METHODTRACE_V1( "", "Actual Top Wafer is not Filled." );
                continue;
            }

            if ( CIMFWStrCmp( inBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier,
                              refBondingMapInfoSeq[refCnt].planTopWaferID.identifier ) != 0 )
            {
                //--------------------------------------------------------------
                //   Check if Top Wafer is in the Bonding Group.
                //--------------------------------------------------------------
                waferFound = FALSE;
                for ( refCnt = 0; refCnt < refLen; refCnt++ )
                {
                    if ( CIMFWStrCmp( refBondingMapInfoSeq[refCnt].planTopWaferID.identifier,
                                      inBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier ) == 0 )
                    {
                        PPT_METHODTRACE_V2( "", "Found", refCnt );
                        waferFound = TRUE;
                        break;
                    }
                }
                if ( !waferFound )
                {
                    PPT_METHODTRACE_V1( "", "Top Wafer is not found in Bonding Group." );
                    PPT_SET_MSG_RC_KEY2( strBondingMap_result_Merge_out,
                                         MSG_NOT_FOUND_BONDING_MAP, RC_NOT_FOUND_BONDING_MAP,
                                         inBondingMapInfoSeq[mapCnt].actualTopLotID.identifier,
                                         inBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier );
                    return RC_NOT_FOUND_BONDING_MAP;
                }

                //--------------------------------------------------------------
                //   Check Bonding Group ID.
                //--------------------------------------------------------------
                if ( CIMFWStrLen( inBondingMapInfoSeq[mapCnt].bondingGroupID ) > 0 &&
                     CIMFWStrCmp( inBondingMapInfoSeq[mapCnt].bondingGroupID,
                                  refBondingMapInfoSeq[refCnt].bondingGroupID ) != 0 )
                {
                    PPT_METHODTRACE_V2( "", "Bonding Group ID differs.",
                                        refBondingMapInfoSeq[refCnt].bondingGroupID );
                    PPT_SET_MSG_RC_KEY2( strBondingMap_result_Merge_out,
                                         MSG_NOT_FOUND_BONDING_MAP, RC_NOT_FOUND_BONDING_MAP,
                                         inBondingMapInfoSeq[mapCnt].actualTopLotID.identifier,
                                         inBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier );
                    return RC_NOT_FOUND_BONDING_MAP;
                }
            }

            //--------------------------------------------------------------
            //   Merge Actual Top Wafer ID.
            //--------------------------------------------------------------
            outBondingMapInfoSeq[mapCnt].actualTopWaferID = inBondingMapInfoSeq[mapCnt].actualTopWaferID;

            //--------------------------------------------------------------
            //   Merge Actual Top Lot ID.
            //--------------------------------------------------------------
            if ( CIMFWStrLen( inBondingMapInfoSeq[mapCnt].actualTopLotID.identifier ) == 0 )
            {
                outBondingMapInfoSeq[mapCnt].actualTopLotID = refBondingMapInfoSeq[refCnt].planTopLotID;
            }
            else if ( CIMFWStrCmp( inBondingMapInfoSeq[mapCnt].actualTopLotID.identifier,
                                   refBondingMapInfoSeq[refCnt].planTopLotID.identifier ) == 0 )
            {
                outBondingMapInfoSeq[mapCnt].actualTopLotID = inBondingMapInfoSeq[mapCnt].actualTopLotID;
            }
            else
            {
                PPT_METHODTRACE_V2( "", "Top Lot ID is not correct.",
                                    refBondingMapInfoSeq[refCnt].planTopLotID.identifier );
                PPT_SET_MSG_RC_KEY2( strBondingMap_result_Merge_out,
                                     MSG_LOT_WAFER_UNMATCH, RC_LOT_WAFER_UNMATCH,
                                     refBondingMapInfoSeq[refCnt].planTopLotID.identifier,
                                     refBondingMapInfoSeq[refCnt].planTopWaferID.identifier );
                return RC_LOT_WAFER_UNMATCH;
            }

            //--------------------------------------------------------------
            //   Merge Actual Top Product ID.
            //--------------------------------------------------------------
            if ( CIMFWStrLen( inBondingMapInfoSeq[mapCnt].actualTopProductID.identifier ) == 0 )
            {
                outBondingMapInfoSeq[mapCnt].actualTopProductID = refBondingMapInfoSeq[refCnt].planTopProductID;
            }
            else if ( CIMFWStrCmp( inBondingMapInfoSeq[mapCnt].actualTopProductID.identifier,
                                   refBondingMapInfoSeq[refCnt].planTopProductID.identifier ) == 0 )
            {
                outBondingMapInfoSeq[mapCnt].actualTopProductID = inBondingMapInfoSeq[mapCnt].actualTopProductID;
            }
            else
            {
                PPT_METHODTRACE_V2( "", "Top Product ID is not correct.",
                                    refBondingMapInfoSeq[refCnt].planTopProductID.identifier );
                PPT_SET_MSG_RC_KEY3( strBondingMap_result_Merge_out,
                                     MSG_WAFER_PRODUCTSPEC_UNMATCH, RC_PRODUCTSPEC_UNMATCH,
                                     refBondingMapInfoSeq[refCnt].planTopProductID.identifier,
                                     refBondingMapInfoSeq[refCnt].planTopWaferID.identifier,
                                     inBondingMapInfoSeq[mapCnt].actualTopProductID.identifier );
                return RC_PRODUCTSPEC_UNMATCH;
            }

            //--------------------------------------------------------------
            //   Check if Top Wafer is already Reported or not.
            //--------------------------------------------------------------
            waferFound = FALSE;
            for ( refCnt = 0; refCnt < refLen; refCnt++ )
            {
                if ( CIMFWStrCmp( refBondingMapInfoSeq[refCnt].actualTopWaferID.identifier,
                                  inBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier ) == 0 )
                {
                    PPT_METHODTRACE_V2( "", "Found", refCnt );
                    waferFound = TRUE;
                    break;
                }
            }
//PSN000104991 add start
            if ( !waferFound )
            {
                PPT_METHODTRACE_V1( "", "Top Wafer is not found in Bonding Group." );
                continue;
            }
//PSN000104991 add end
//PSIV00002172 add start
            // If Base Wafer is the same, it means that bonding map result is overwrited. It is OK.
            if ( CIMFWStrCmp( refBondingMapInfoSeq[refCnt].baseWaferID.identifier,
                              inBondingMapInfoSeq[mapCnt].baseWaferID.identifier ) == 0 )
            {
                PPT_METHODTRACE_V1( "", "Top Wafer is not found in Bonding Group." );
                continue;
            }
            // If existed Actual Top Wafer ID will be changed by this report, it is OK.
            CORBA::Boolean bInputExist = FALSE;
            for ( CORBA::Long tmpMapCnt = 0; tmpMapCnt < mapLen; tmpMapCnt++ )
            {
                if ( CIMFWStrCmp( refBondingMapInfoSeq[refCnt].baseWaferID.identifier,
                                  inBondingMapInfoSeq[tmpMapCnt].baseWaferID.identifier ) == 0 )
                {
                    PPT_METHODTRACE_V1( "", "Same Base Wafer is found in input." );
                    bInputExist = TRUE;
                    break;
                }
            }
            if ( bInputExist )
            {
                PPT_METHODTRACE_V1( "", "bInputExist == TRUE" );
                continue;
            }
//PSIV00002172 add end
//PSN000104991            if ( !waferFound )
//PSN000104991            {
//PSN000104991                PPT_METHODTRACE_V1( "", "Top Wafer is not found in Bonding Group." );
//PSN000104991                continue;
//PSN000104991            }

            //--------------------------------------------------------------
            //   Check Bonding Process State.
            //--------------------------------------------------------------
            if ( CIMFWStrLen( refBondingMapInfoSeq[refCnt].bondingProcessState ) > 0 )
            {
                PPT_METHODTRACE_V2( "", "Top Wafer is already reported.",
                                    refBondingMapInfoSeq[refCnt].actualTopWaferID.identifier );
                PPT_SET_MSG_RC_KEY2( strBondingMap_result_Merge_out,
                                     MSG_ALREADY_BONDING_MAP_RESULT_REPORTED, RC_ALREADY_BONDING_MAP_RESULT_REPORTED,
                                     refBondingMapInfoSeq[refCnt].actualTopLotID.identifier,
                                     refBondingMapInfoSeq[refCnt].actualTopWaferID.identifier );
                return RC_ALREADY_BONDING_MAP_RESULT_REPORTED;
            }
        }   // for ( mapCnt = 0; mapCnt < mapLen; mapCnt++ )

        //--------------------
        //   Return to Caller
        //--------------------
        PPT_METHODTRACE_EXIT( "PPTManager_i::bondingMap_result_Merge" );
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS( strBondingMap_result_Merge_out, bondingMap_result_Merge, methodName )
}
