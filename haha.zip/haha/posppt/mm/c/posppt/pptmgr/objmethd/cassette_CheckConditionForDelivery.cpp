#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_CheckConditionForDelivery.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:31:15 [ 7/13/07 19:31:16 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_CheckConditionForDelivery.cpp
//

#include "pptmgr.hpp"

#include "plot.hh"
#include "pcas.hh"
#include "ppcope.hh"


//[Object Function Name]: long   cassette_CheckConditionForDelivery
//
// Date        Level        Author         Note
// ----------  -----------  -------------  -------------------------------------------
// 2000-11-23  0.00         M.Mori         copy cassette_CheckConditionForOperation.cpp
// 2000-12-06  0.01         k.kido         check comments
// 2002/02/01  P4100105     K.Matsuei      Cassette's XferStatus CheckLogic is Incorrect in StartLotsReservation.
// 2002/06/07  P4100522     H.Adachi       Add Sequence Length Check for wrong dimension access
// 2002/09/25  P4200192     H.Adachi       Add Nil Check
// 2003/03/13  P5000003     H.Adachi       MM Server Down at narrow to PosMachineObject.
// 2003/08/15  D5000194     K.Matsuei      ReRoute of Xfer is supported by CassetteDelivery.
// 2008/12/08  DSIV00000518   K.Matsuei    ReRoute of BO is permitted by Auto3.
//
//[Function Description]:
//  Check cassette's condition for StartReservation, OpeStart, and FlowBatching.
//  The following conditions are checked for each specified operation.
//
//  - controlJobID
//  - multiLotType
//  - transferState
//  - transferReserved
//  - dispatchState
//  - cassetteState
//  - maxBatchSize
//  - minBatchSize
//  - cassette's loadingSequenceNumber
//  - eqp's multiRecipeCapability and recipeParameter
//
//  <<< Condition for controlJobID, multiLotType, transferState, transferReserved >>>
//
//                       || control multiLot transfer transfer dispatch
//   in-parm's operation ||  JobID    Type    State   Reserved  State
//   ====================||======== ======== ======== ======== ========
//    StartReservation   ||  null     (*1)     (*2)     (*2)    FALSE
////  OpeStart           ||  null     (*1)      EI       na      na
//    OpeStart           ||  (*0)     (*1)      EI       na      na
//    FlowBatching       ||  null     (*1)   SI/MI/BI   FALSE   FALSE
//
//  About *0, all of cassettes' controlJobID must be same. If it is not null case,
//  strStartCassette[]'s cassettes and PosProcessJob's contained cassettes must be
//  same perfectlly.
//
//  About *1, the following conditions must be met.
//  If LoadPurposeType is EmptyCassette case, this check is passed.
//
//            Eqp's         ||                Cassette's
//    multiRecipeCapability ||               multiLotType
//    ======================||=============================================
//        Multiple Recipe   ||               everything OK
//    --------------------- || --------------------------------------------
//         SIngle Recipe    ||               everything OK
//    --------------------- || --------------------------------------------
//                          ||  SP_Cas_MultiLotType_SingleLotSingleRecipe
//             Batch        ||                     or
//                          ||  SP_Cas_MultiLotType_MultiLotSingleRecipe
//
//  About *2, the following conditions must be met.
//
//                          ||                 Cassette's
//       Eqp's accessMode   ||    transferState    |    transferReserved
//    ======================||=====================|=======================
//            MANUAL        ||       no-check      |        no-check
//    --------------------- || ------------------- | ----------------------
//                          ||       SI/MI/BI      |         FALSE
//            AUTO (*3)     || ------------------- | ----------------------
//                          ||         (EI)        |         (TRUE)
//
//  About *3, if accessMode is AUTO case, basically transferState must be SI/MI/BI,
//  and transferReserved must be FALSE. However, in the case of Eqp-to-Eqp Xfer,
//  transferState is EI, and transferReserved is TURE. In this Eqp-to-Eqp case,
//  MM must check originator eqp's EqpToEqp transfer Flag is TURE or not, and
//  originator eqp's accessMode (=cassette's equipmentID) must be AUTO.
//
//  <<< Condition for cassetteState >>>
//
//  - About cassetteState, it must be _Available or _InUse.
//
//  <<< Condition for cassette's loadingSequenceNumber >>>
//  - strStartCassette[].loadSequenceNumber must be correct order from 1 to N.
//
//  <<< eqp's multiRecipeCapability and recipeParameter >>>
//  - If equipment's multiRecipeCapability is Batch or Single-Recipe, all of startLots'
//    recipeParameter-set must be same.
//
//  The following input-parameters must be filled to call this object function.
//  - equipmentID
//  - portGroupID
//  - operation
//  - strStartCassette[].cassetteID
//  From here, the followings are not required to fill for SP_Operation_FlowBatching
//  - strStartCassette[].strLotInCassette[].recipeParameterChangeType
//  - strStartCassette[].strLotInCassette[].strLotWafer[].strStartRecipeParameter[].parameterName
//  - strStartCassette[].strLotInCassette[].strLotWafer[].strStartRecipeParameter[].parameterValue
//
//[Input Parameters]:
//  in  pptObjCommonIn              strObjCommonIn;
//  in  objectIdentifier            equipmentID;
//  in  string                      portGroupID;
//  in  sequence <pptStartCassette> strStartCassette;
//  in  string                      operation;
//
//[Output Parameters]:
//  out objCassette_CheckConditionForDelivery_out   strCassette_CheckConditionForDelivery_out;
//
//  typedef struct objCassette_CheckConditionForOperation_out_struct {
//      pptRetCode                  strResult;
//  } objCassette_CheckConditionForDelivery_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_NOT_FOUND_CASSETTE       MSG_NOT_FOUND_CASSETTE
//  RC_NOT_FOUND_EQP            MSG_NOT_FOUND_EQP
//  RC_LOCKED_BY_ANOTHER        MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR             MSG_SYSTEM_ERROR
//
//[Pseudo Code]:
//

CORBA::Long PPTManager_i::cassette_CheckConditionForDelivery(
                            objCassette_CheckConditionForDelivery_out& strCassette_CheckConditionForDelivery_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& equipmentID,
                            const char * portGroupID,
                            const pptStartCassetteSequence& strStartCassette,
                            const char * operation )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_CheckConditionForDelivery");

        PPT_METHODTRACE_V2("","in para equipmentID", equipmentID.identifier);
        PPT_METHODTRACE_V2("","in para portGroupID", portGroupID);
        PPT_METHODTRACE_V2("","in para operation  ", operation);

        /*----------------*/
        /*                */
        /*   Initialize   */
        /*                */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        /*-------------------------------------------------------------------------------------*/
        /*                                                                                     */
        /*   Check Condition of controlJobID, multiLotType, transferState, transferReserved,   */
        /*   dispatchState, and cassetteState for all cassettes                                */
        /*   dispatchState, cassetteState, and loadingSequenceNumber for all cassettes         */
        /*                                                                                     */
        /*-------------------------------------------------------------------------------------*/

        /*--------------------------*/
        /*   Get Equipment Object   */
        /*--------------------------*/
        PPT_METHODTRACE_V1("","Get Equipment Object");

        PosMachine_var aMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine,
                                         equipmentID,
                                         strCassette_CheckConditionForDelivery_out,
                                         cassette_CheckConditionForDelivery );

        /*-------------------------------------------*/
        /*   Get Equipment's MultiRecipeCapability   */
        /*-------------------------------------------*/
        PPT_METHODTRACE_V1("","Get Equipment's MultiRecipeCapability");

        CORBA::String_var multiRecipeCapability;
        try
        {
            multiRecipeCapability = aMachine->getMultipleRecipeCapability();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getMultipleRecipeCapability)

        /*-----------------------------------------*/
        /*   Get Equipment's Operation Mode Info   */
        /*-----------------------------------------*/
        PPT_METHODTRACE_V1("","Get Equipment's Operation Mode Info");

        if ( strStartCassette.length() <= 0 )                                       //P4100522
        {                                                                           //P4100522
            PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForDelivery_out,          //P4100522
                                MSG_NOT_FOUND_CASSETTE,                             //P4100522
                                RC_NOT_FOUND_CASSETTE,                              //P4100522
                                "" );                                               //P4100522
            return( RC_NOT_FOUND_CASSETTE );                                        //P4100522
        }                                                                           //P4100522

        if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart)
          || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation) )
        {
            PPT_METHODTRACE_V1("","operation == SP_Operation_OpeStart, SP_Operation_StartReservation");

            objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
            rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
                                                        strObjCommonIn,
                                                        equipmentID,
                                                        strStartCassette[0].loadPortID );

            if ( rc != RC_OK )
            {
                strCassette_CheckConditionForDelivery_out.strResult = strPortResource_currentOperationMode_Get_out.strResult;
                return rc;
            }
            PPT_METHODTRACE_V1("", "portResource_currentOperationMode_Get=RC_OK")
        }
        else
        {
            PPT_METHODTRACE_V1("", "operation != SP_Operation_OpeStart && operation != SP_Operation_StartReservation")
        }

        /*------------------------------*/
        /*   Check Cassette Condition   */
        /*------------------------------*/
        CORBA::Long i, j;
        CORBA::Long lenCassette = strStartCassette.length();
        objectIdentifier saveControlJobID;
        CORBA::Long cjCastCnt;

        PPT_METHODTRACE_V2("","Check Cassette Condition  lenCassette=", lenCassette);

        for ( i=0; i < lenCassette; i++ )
        {
            PPT_METHODTRACE_V3("","  [].cassetteID", i, strStartCassette[i].cassetteID.identifier);

            /*------------------------------------------*/
            /*   Check Start Cassette's Loading Order   */
            /*------------------------------------------*/
            if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart) || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation) )
            {
                PPT_METHODTRACE_V1("", "(operation == SP_Operation_OpeStart) || (operation == SP_Operation_StartReservation)");

                if ( strStartCassette[i].loadSequenceNumber != (i+1) )
                {
                    PPT_METHODTRACE_V1("", "strStartCassette[i].loadSequenceNumber != i");
                    PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForDelivery_out,
                                        MSG_INVALID_LOADING_SEQ,
                                        RC_INVALID_LOADING_SEQ,
                                        strStartCassette[i].cassetteID.identifier );

                    return RC_INVALID_LOADING_SEQ;
                }
            }

            /*-------------------------*/
            /*   Get Cassette Object   */
            /*-------------------------*/
            PosCassette_var aCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                                   strStartCassette[i].cassetteID,
                                                   strCassette_CheckConditionForDelivery_out,
                                                   cassette_CheckConditionForDelivery );

            /*--------------------------------*/
            /*   Get and Check ControlJobID   */
            /*--------------------------------*/
            PosControlJob_var aControlJob;
            try
            {
                aControlJob = aCassette->getControlJob();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)

            if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart) )
            {
                PPT_METHODTRACE_V2("","operation == SP_Operation_OpeStart", operation);

                if ( i == 0 )
                {
                    PPT_METHODTRACE_V1("","i == 0");

                    PPT_SET_OBJECT_IDENTIFIER( saveControlJobID,
                                               aControlJob,
                                               strCassette_CheckConditionForDelivery_out,
                                               cassette_CheckConditionForDelivery,
                                               PosControlJob );
                }
                else
                {
                    PPT_METHODTRACE_V1("","i != 0");

                    objectIdentifier castControlJobID;
                    PPT_SET_OBJECT_IDENTIFIER( castControlJobID,
                                               aControlJob,
                                               strCassette_CheckConditionForDelivery_out,
                                               cassette_CheckConditionForDelivery,
                                               PosControlJob );

                    if ( 0 != CIMFWStrCmp(castControlJobID.identifier, saveControlJobID.identifier) )
                    {
                        PPT_METHODTRACE_V1("","castControlJobID != saveControlJobID");
                        SET_MSG_RC( strCassette_CheckConditionForDelivery_out,
                                    MSG_CAST_CTRLJOB_MIX,
                                    RC_CAST_CTRLJOB_MIX );

                        return RC_CAST_CTRLJOB_MIX;
                    }
                }
            }
            else
            {
                if ( ! CORBA::is_nil(aControlJob) )
                {

                    PPT_METHODTRACE_V1("","aControlJob is not nil");
                    SET_MSG_RC( strCassette_CheckConditionForDelivery_out,
                                MSG_CAST_CTRLJOBID_FILLED,
                                RC_CAST_CTRLJOBID_FILLED );

                    return RC_CAST_CTRLJOBID_FILLED;
                }
            }

            /*---------------------------------*/
            /*   Get Cassette's MultiLotType   */
            /*---------------------------------*/
            PPT_METHODTRACE_V1("","Get Cassette's MultiLotType");

            CORBA::String_var multiLotType;
            try
            {
                multiLotType = aCassette->getMultiLotType();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getMultiLotType)

            /*-------------------------------------------------*/
            /*   Check MultiRecipeCapability VS MultiLotType   */
            /*-------------------------------------------------*/
            PPT_METHODTRACE_V1("","Check MultiRecipeCapability VS MultiLotType");

            if ( 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) )
            {
                PPT_METHODTRACE_V1("","strStartCassette[i].loadPurposeType == SP_LoadPurposeType_EmptyCassette");
                rc = RC_OK;
            }
            else
            if ( 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_MultipleRecipe) )
            {
                PPT_METHODTRACE_V1("","multiRecipeCapability == SP_Eqp_MultiRecipeCapability_MultipleRecipe");

                rc = RC_OK;
            }
            else if ( 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_SingleRecipe) )
            {
                PPT_METHODTRACE_V1("","multiRecipeCapability == SP_Eqp_MultiRecipeCapability_SingleRecipe");

                rc = RC_OK;
            }
            else if ( 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_Batch) )
            {
                PPT_METHODTRACE_V1("","multiRecipeCapability == SP_Eqp_MultiRecipeCapability_Batch");

                if ( 0 == CIMFWStrCmp(multiLotType, SP_Cas_MultiLotType_SingleLotSingleRecipe)
                  || 0 == CIMFWStrCmp(multiLotType, SP_Cas_MultiLotType_MultiLotSingleRecipe) )
                {
                    PPT_METHODTRACE_V1("","rc = RC_OK");

                    rc = RC_OK;
                }
                else
                {
                    PPT_METHODTRACE_V1("","return RC_CAST_EQP_CONDITION_ERROR!!");
                    SET_MSG_RC( strCassette_CheckConditionForDelivery_out,
                                MSG_CAST_EQP_CONDITION_ERROR,
                                RC_CAST_EQP_CONDITION_ERROR );

                    return RC_CAST_EQP_CONDITION_ERROR;
                }
            }
            else
            {
                PPT_METHODTRACE_V1("","No Process <Check MultiRecipeCapability VS MultiLotType>");
            }

            /*--------------------------------------*/
            /*   Check Cassette's Transfer Status   */
            /*--------------------------------------*/

            /*-----------------------*/
            /*   Get TransferState   */
            /*-----------------------*/
            PPT_METHODTRACE_V1("","Get TransferState");

            CORBA::String_var transferState;
            try
            {
                transferState = aCassette->getTransportState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getTransportState)

            /*------------------------------*/
            /*   Get TransferReserveState   */
            /*------------------------------*/
            PPT_METHODTRACE_V1("","Get TransferReserveState");

            CORBA::Boolean transferReserved;
            try
            {
                transferReserved = aCassette->isReserved();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isReserved)

            /*===== for OpeStart =====*/
            if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart) )
            {
                PPT_METHODTRACE_V1("", "operation = SP_Operation_OpeStart");

                if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn) )
                {
                    PPT_METHODTRACE_V1("","transferState == SP_TransState_EquipmentIn");

                    rc = RC_OK;
                }
                else
                {
                    PPT_METHODTRACE_V1("","return RC_INVALID_CAST_XFERSTAT!!");
                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForDelivery_out,
                                         MSG_INVALID_CAST_XFERSTAT,
                                         RC_INVALID_CAST_XFERSTAT,
                                         transferState,
                                         strStartCassette[i].cassetteID.identifier );

                    return RC_INVALID_CAST_XFERSTAT;
                }
            }
            /*===== for FlowBatching =====*/
            else if ( 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatching) )
            {
                PPT_METHODTRACE_V1("", "operation = SP_Operation_FlowBatching");

                if ((0 == CIMFWStrCmp(transferState, SP_TransState_StationIn)
                  || 0 == CIMFWStrCmp(transferState, SP_TransState_BayIn)
                  || 0 == CIMFWStrCmp(transferState, SP_TransState_ManualIn))
                  && (transferReserved == FALSE) )
                {
                    PPT_METHODTRACE_V1("","rc = RC_OK");

                    rc = RC_OK;
                }
                else
                {
                    PPT_METHODTRACE_V1("","return RC_INVALID_CAST_XFERSTAT");
                    PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForDelivery_out,
                                         MSG_INVALID_CAST_XFERSTAT,
                                         RC_INVALID_CAST_XFERSTAT,
                                         transferState,
                                         strStartCassette[i].cassetteID.identifier );

                    return RC_INVALID_CAST_XFERSTAT;
                }
            }
            /*===== for StartReservation =====*/
            else if ( 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation) )
            {
                PPT_METHODTRACE_V1("", "operation = SP_Operation_StartReservation");

                objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
                rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
                                                            strObjCommonIn,
                                                            equipmentID,
                                                            strStartCassette[i].loadPortID );

                if ( 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode,
                                      SP_Eqp_AccessMode_Manual) )
                {
                    PPT_METHODTRACE_V1("", ".strOperationMode.accessMode = SP_Eqp_AccessMode_Manual");

//P4100105 start
                    /*--------------------------------------------------------------------------------------------------*/
                    /*   Logic which put it here in [cassette_CheckConditionForOperation] by P4100105 is unnecessary.   */
                    /*   Because, This Function is used only at the time of CassetteDelivery.                           */
                    /*   Then, it doesn't come here because Check has already been done.                                */
                    /*--------------------------------------------------------------------------------------------------*/
//P4100105 end

                    rc = RC_OK;
                }
                else
                {
//D5000194 start
                    CORBA::Boolean bReRouteFlg = FALSE;
                    CORBA::String_var reRouteXferFlag = CIMFWStrDup(getenv(SP_REROUTE_XFER_FLAG));
                    PPT_METHODTRACE_V2("","SP_REROUTE_XFER_FLAG ---> ",reRouteXferFlag);

                    PPT_METHODTRACE_V2("","operationMode", strPortResource_currentOperationMode_Get_out.strOperationMode.operationMode.identifier); //DSIV00000518

                    if ( 0 == CIMFWStrCmp(reRouteXferFlag, "1")
//DSIV00000518                      && ( 0 == CIMFWStrCmp("TXDSC008", strObjCommonIn.transactionID) || 0 == CIMFWStrCmp("TXDSC012", strObjCommonIn.transactionID) )
                      && ( 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.operationMode.identifier, SP_Eqp_Port_OperationMode_Auto_3) ) //DSIV00000518
                      && ( 0 == CIMFWStrCmp(transferState, SP_TransState_StationIn) ||
                           0 == CIMFWStrCmp(transferState, SP_TransState_BayIn)     ||
                           0 == CIMFWStrCmp(transferState, SP_TransState_ManualIn)  ||
                           0 == CIMFWStrCmp(transferState, SP_TransState_BayOut) )
                      && ( transferReserved == FALSE ) )
                    {
//DSIV00000518                        PPT_METHODTRACE_V1("", "Transaction is [TXDSC008]TxCassetteDelvieryReq or [TXDSC012]TxCassetteDeliveryForInternalBufferReq")
                        PPT_METHODTRACE_V1("", "operationMode is Auto-3") //DSIV00000518
                        PPT_METHODTRACE_V1("", "transferState = [SI], [BI], [MI], [BO] and transferReserved is FALSE")
                        rc = RC_OK;
                    }
//D5000194 end
//D5000194                    if (( 0 == CIMFWStrCmp(transferState, SP_TransState_StationIn)
                    else if (( 0 == CIMFWStrCmp(transferState, SP_TransState_StationIn)  //D5000194
                            || 0 == CIMFWStrCmp(transferState, SP_TransState_BayIn)
                            || 0 == CIMFWStrCmp(transferState, SP_TransState_ManualIn))
                            && (transferReserved == FALSE) )
                    {
                        PPT_METHODTRACE_V1("", "transferState = [SI], [BI], [MI] and transferReserved is FALSE")
                        rc = RC_OK;
                    }
                    else if ( 0 == CIMFWStrCmp(transferState, SP_TransState_EquipmentIn)
//P4100105                           && transferReserved == TRUE )
                           && transferReserved == FALSE )       //P4100105
                    {
                        PPT_METHODTRACE_V1("", "(transferState = SP_TransState_EquipmentIn) and (transferReserved == TRUE)");

//P4100105 start
                        /*--------------------------------------------------------------------------------------------------*/
                        /*   Logic which put it here in [cassette_CheckConditionForOperation] by P4100105 is unnecessary.   */
                        /*   Because, This Function is used only at the time of CassetteDelivery.                           */
                        /*   Then, it doesn't come here because Check has already been done.                                */
                        /*--------------------------------------------------------------------------------------------------*/
//P4100105 end

                        /*--------------------------------------*/
                        /*   Get Originator Eqp's Access Mode   */
                        /*--------------------------------------*/

                        /*--------------------------------*/
                        /*   Get Originator EquipmentID   */
                        /*--------------------------------*/
                        PPT_METHODTRACE_V1("","Get Originator EquipmentID");

                        Machine_var aMachine;
                        PosMachine_var aOrgMachine;
                        try
                        {
                            aMachine = aCassette->currentAssignedMachine();
//P5000003                            aOrgMachine = PosMachine::_narrow( aMachine );
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::currentAssignedMachine)

                        //P5000003 Add Start
                        if ( TRUE != CORBA::is_nil(aMachine) )
                        {
                            CORBA::Boolean isStorageBool = FALSE;
                            try
                            {
                                isStorageBool = aMachine->isStorageMachine();
                            }
                            CATCH_AND_RAISE_EXCEPTIONS(Machine::isStorageMachine)

                            if ( isStorageBool == TRUE )
                            {
                                PPT_METHODTRACE_V1( "", "isStorageBool is TRUE: Storage" );
                            }
                            else
                            {
                                aOrgMachine = PosMachine::_narrow(aMachine);
                                PPT_METHODTRACE_V1( "", "isStorageBool is not TRUE: Equipment. So narrow to PosMachine" );
                            }
                        }
                        else
                        {
                            PPT_METHODTRACE_V1( "", "aMachine is Nill" );
                        }
                        //P5000003 Add End

                        //P4200192 Add Start
                        if ( CORBA::is_nil(aOrgMachine))
                        {
                            PPT_METHODTRACE_V1("","PosStorageMachine is Nil Object.");
                            PPT_SET_MSG_RC_KEY(strCassette_CheckConditionForDelivery_out,
                                               MSG_NOT_FOUND_EQP, RC_NOT_FOUND_EQP, equipmentID.identifier)
                            return RC_NOT_FOUND_EQP;
                        }
                        //P4200192 Add End

                        objectIdentifier orgEquipmentID;
                        PPT_SET_OBJECT_IDENTIFIER( orgEquipmentID,
                                                   aOrgMachine,
                                                   strCassette_CheckConditionForDelivery_out,
                                                   cassette_CheckConditionForDelivery,
                                                   PosMachine );

                        /*---------------------------------*/
                        /*   Get Cassette Info in OrgEqp   */
                        /*---------------------------------*/
                        PPT_METHODTRACE_V1("","Get Cassette Info in OrgEqp");

//P4100105 start
                        pptEqpPortStatus strOrgEqpPortStatus;
                        pptEqpPortInfo equipmentPortInfo;
                        CORBA::String_var equipmentCategory;
                        try
                        {
                            equipmentCategory = aOrgMachine->getCategory();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getCategory)
                        PPT_METHODTRACE_V2("","aOrgMachine->getCategory()", equipmentCategory);

                        if ( 0 == CIMFWStrCmp(equipmentCategory, SP_Mc_Category_InternalBuffer) )
                        {
                            PPT_METHODTRACE_V1("","equipmentCategory is [InternalBuffer]");
                            objEquipment_portInfoForInternalBuffer_GetDR_out strEquipment_portInfoForInternalBuffer_GetDR_out;
                            rc = equipment_portInfoForInternalBuffer_GetDR( strEquipment_portInfoForInternalBuffer_GetDR_out,
                                                                            strObjCommonIn,
                                                                            orgEquipmentID );
                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("", "equipment_portInfoForInternalBuffer_GetDR != RC_OK")
                                strCassette_CheckConditionForDelivery_out.strResult = strEquipment_portInfoForInternalBuffer_GetDR_out.strResult;
                                return( rc );
                            }
                            equipmentPortInfo = strEquipment_portInfoForInternalBuffer_GetDR_out.strEqpPortInfo;
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("","equipmentCategory is not [InternalBuffer]");
//P4100105 end
                            objEquipment_portInfo_Get_out strEquipment_portInfo_Get_out;
                            rc = equipment_portInfo_Get( strEquipment_portInfo_Get_out,
                                                         strObjCommonIn,
                                                         orgEquipmentID );

                            if ( rc != RC_OK )
                            {
                                PPT_METHODTRACE_V1("", "equipment_portInfo_Get != RC_OK");
                                strCassette_CheckConditionForDelivery_out.strResult = strEquipment_portInfo_Get_out.strResult;
                                return rc;
                            }
                            equipmentPortInfo = strEquipment_portInfo_Get_out.strEqpPortInfo;   //P4100105
                        }                                                                       //P4100105

                        /*--------------------------------------*/
                        /*   Find Assigned Port's portGroupID   */
                        /*--------------------------------------*/
                        PPT_METHODTRACE_V1("","Find Assigned Port's portGroupID");
//P4100105 start
                        CORBA::Boolean bFound = FALSE;
                        CORBA::Long lenEqpPort = equipmentPortInfo.strEqpPortStatus.length();
                        for ( j=0; j < lenEqpPort; j++ )
                        {
                            PPT_METHODTRACE_V2("", "portID..............", equipmentPortInfo.strEqpPortStatus[j].portID.identifier);
                            PPT_METHODTRACE_V2("", "loadedCassetteID....", equipmentPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier);

                            if ( 0 == CIMFWStrCmp(strStartCassette[i].cassetteID.identifier,
                                                  equipmentPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier) )
                            {
                                PPT_METHODTRACE_V1("","break!!");
                                strOrgEqpPortStatus = equipmentPortInfo.strEqpPortStatus[j];
                                bFound = TRUE;
                                break;
                            }
                        }
                        if ( FALSE == bFound )
                        {
                            PPT_METHODTRACE_V1("","return RC_INVALID_CAST_XFERSTAT");
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForDelivery_out,
                                                 MSG_INVALID_CAST_XFERSTAT,
                                                 RC_INVALID_CAST_XFERSTAT,
                                                 transferState,
                                                 strStartCassette[i].cassetteID.identifier );
                            return RC_INVALID_CAST_XFERSTAT;
                        }
//P4100105 end

//P4100105                        CORBA::Long lenEqpPort = strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus.length();
//P4100105                        for ( j=0; j < lenEqpPort; j++ )
//P4100105                        {
//P4100105                            if ( 0 == CIMFWStrCmp(strStartCassette[i].cassetteID.identifier,
//P4100105                                                  strEquipment_portInfo_Get_out.strEqpPortInfo.strEqpPortStatus[j].loadedCassetteID.identifier) )
//P4100105                            {
//P4100105                                PPT_METHODTRACE_V1("","break!!");
//P4100105
//P4100105                                break;
//P4100105                            }
//P4100105                        }
//P4100105
//P4100105                        if ( j == lenEqpPort )
//P4100105                        {
//P4100105                            PPT_METHODTRACE_V1("","return RC_INVALID_CAST_XFERSTAT");
//P4100105                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForDelivery_out,
//P4100105                                                 MSG_INVALID_CAST_XFERSTAT,
//P4100105                                                 RC_INVALID_CAST_XFERSTAT,
//P4100105                                                 transferState,
//P4100105                                                 strStartCassette[i].cassetteID.identifier );
//P4100105
//P4100105                            return RC_INVALID_CAST_XFERSTAT;
//P4100105                        }

//P4100105 start    already been doing by upper logic!!
//P4100105                        /*----------------------------------------------------*/
//P4100105                        /*   Get Originator Equipment's Operation Mode Info   */
//P4100105                        /*----------------------------------------------------*/
//P4100105                        PPT_METHODTRACE_V1("","Get Originator Equipment's Operation Mode Info");
//P4100105
//P4100105                        objPortResource_currentOperationMode_Get_out strPortResource_currentOperationMode_Get_out;
//P4100105                        rc = portResource_currentOperationMode_Get( strPortResource_currentOperationMode_Get_out,
//P4100105                                                                    strObjCommonIn,
//P4100105                                                                    equipmentID,
//P4100105                                                                    strStartCassette[i].loadPortID );
//P4100105
//P4100105                        if ( rc != RC_OK )
//P4100105                        {
//P4100105                            PPT_METHODTRACE_V1("", "portResource_currentOperationMode_Get != RC_OK");
//P4100105                            strCassette_CheckConditionForDelivery_out.strResult = strPortResource_currentOperationMode_Get_out.strResult;
//P4100105                            return rc;
//P4100105                        }
//P4100105 end

//P4100105                        if ( 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode,
//P4100105                                              SP_Eqp_AccessMode_Auto) )
//P4100105 start
                        /*-----------------------------------------------------------------------------------------------*/
                        /*   The following StartLotReserve isn't permitted in Transfer EQP to EQP of CassetteDelivery.   */
                        /*                                                                                               */
                        /*   ToEQP's OperationMode : ***-2                                                               */
                        /*-----------------------------------------------------------------------------------------------*/
                        if ( 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.accessMode, SP_Eqp_AccessMode_Auto)
                          && 0 == CIMFWStrCmp(strPortResource_currentOperationMode_Get_out.strOperationMode.dispatchMode, SP_Eqp_DispatchMode_Auto) )
//P4100105 end
                        {
                            PPT_METHODTRACE_V1("","rc = RC_OK");

                            rc = RC_OK;
                        }
                        else
                        {
                            PPT_METHODTRACE_V1("","return RC_INVALID_CAST_XFERSTAT");
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForDelivery_out,
                                                 MSG_INVALID_CAST_XFERSTAT,
                                                 RC_INVALID_CAST_XFERSTAT,
                                                 transferState,
                                                 strStartCassette[i].cassetteID.identifier );

                            return RC_INVALID_CAST_XFERSTAT;
                        }
                    }
                    else
                    {
                        PPT_METHODTRACE_V1("","return RC_INVALID_CAST_XFERSTAT");
                        PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForDelivery_out,
                                             MSG_INVALID_CAST_XFERSTAT,
                                             RC_INVALID_CAST_XFERSTAT,
                                             transferState,
                                             strStartCassette[i].cassetteID.identifier );

                        return RC_INVALID_CAST_XFERSTAT;
                    }
                }
            }
            else
            {
                PPT_METHODTRACE_V1("","No Process <for Ope Start>");
            }

            /*----------------------------------------------*/
            /*   Get and Check Cassette's Dispatch Status   */
            /*----------------------------------------------*/

            /*------------------------------------*/
            /*   Get Cassette's Dispatch Status   */
            /*------------------------------------*/
            PPT_METHODTRACE_V1("","Get Cassette's Dispatch Status");

            CORBA::Boolean dispatchReserveFlag;
            try
            {
                dispatchReserveFlag = aCassette->isDispatchReserved();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isDispatchtReserved)

            if ( 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation)
              || 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatching) )
            {
                PPT_METHODTRACE_V1("","operation == SP_Operation_StartReservation, SP_Operation_FlowBatching");

                if ( dispatchReserveFlag != FALSE )
                {
                    PPT_METHODTRACE_V1("","dispatchReserveFlag != FALSE");
                    SET_MSG_RC( strCassette_CheckConditionForDelivery_out,
                                MSG_ALREADY_DISPATCH_RESVED_CST,
                                RC_ALREADY_DISPATCH_RESVED_CST );

                    return RC_ALREADY_DISPATCH_RESVED_CST;
                }
            }
            else
            {
                PPT_METHODTRACE_V1("","operation != SP_Operation_StartReservation && operation != SP_Operation_FlowBatching");
            }

            /*-------------------------------------*/
            /*   Get and Check Cassette's Status   */
            /*-------------------------------------*/
            PPT_METHODTRACE_V1("","Get and Check Cassette's Status");

            CORBA::String_var cassetteState;
            try
            {
                cassetteState = aCassette->getDurableState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getCurrentState)

            if ( 0 == CIMFWStrCmp(cassetteState, CIMFW_Durable_Available)
              || 0 == CIMFWStrCmp(cassetteState, CIMFW_Durable_InUse) )
            {
                PPT_METHODTRACE_V1("", "cassetteState = CIMFW_Durable_Available or CIMFW_Durable_InUse");
                rc = RC_OK;
            }
            else
            {
                PPT_METHODTRACE_V1("","return RC_INVALID_CAST_STAT");
                PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForDelivery_out,
                                     MSG_INVALID_CAST_STAT,
                                     RC_INVALID_CAST_STAT,
                                     cassetteState,
                                     strStartCassette[i].cassetteID.identifier );

                return RC_INVALID_CAST_STAT;
            }
        }

        /*---------------------------------------------------------*/
        /*   Check Cassette's ControlJobID vs Eqp's ControlJobID   */
        /*---------------------------------------------------------*/
        PPT_METHODTRACE_V1("","Check Cassette's ControlJobID vs Eqp's ControlJobID");

        if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart) )
        {
            PPT_METHODTRACE_V1("","operation == SP_Operation_OpeStart");

            /*===== get reserved controlJobID for each portGroup =====*/
            objEquipment_reservedControlJobID_Get_out strEquipment_reservedControlJobID_Get_out;
            rc = equipment_reservedControlJobID_Get( strEquipment_reservedControlJobID_Get_out,
                                                     strObjCommonIn,
                                                     equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("","equipment_reservedControlJobID_Get != RC_OK");
                strCassette_CheckConditionForDelivery_out.strResult = strEquipment_reservedControlJobID_Get_out.strResult;
                return rc ;
            }

            CORBA::Long rsvCJLen = strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo.length();

            /*===== find reserved controlJobID for specified portGroup =====*/
            objectIdentifier eqpControlJobID;

            for ( i=0; i < rsvCJLen; i++ )
            {
                if ( 0 == CIMFWStrCmp(strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[i].portGroupID,
                                      portGroupID) )
                {
                    PPT_METHODTRACE_V1("","in-parm's portGroup is found in reservedControlJobInfo...");

                    eqpControlJobID = strEquipment_reservedControlJobID_Get_out.strStartReservedControlJobInfo[i].controlJobID;

                    /*---------------------------*/
                    /*   Get ControlJob Object   */
                    /*---------------------------*/
                    PPT_METHODTRACE_V1("","Get ControlJob Object...");

                    PosControlJob_var aReserveControlJob;
                    PPT_CONVERT_CONTROLJOBID_TO_CONTROLJOB_OR(aReserveControlJob,eqpControlJobID,strEquipment_reservedControlJobID_Get_out,equipment_reservedControlJobID_Get);

                    /*-------------------------------------------*/
                    /*   Get PosStartCassetteInfoSequence Info   */
                    /*-------------------------------------------*/
                    PosStartCassetteInfoSequence*    startCassetteInfo = NULL;
                    PosStartCassetteInfoSequence_var startCassetteInfoVar;

                    try
                    {
                        startCassetteInfo    = aReserveControlJob->getStartCassetteInfo();
                        startCassetteInfoVar = startCassetteInfo;
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosControlJob::getStartCassetteInfo);

                    cjCastCnt = (*startCassetteInfo).length();
                    PPT_METHODTRACE_V2("","controlJob's cassetteCount = ",cjCastCnt);

                    PPT_METHODTRACE_V1("","break!!");
                    break;
                }
            }

            /*===== compare reserved controlJobID vs cassette's controlJobID =====*/
            if ( 0 != CIMFWStrCmp(saveControlJobID.identifier, eqpControlJobID.identifier) )
            {
                PPT_METHODTRACE_V1("","compare reserved controlJobID vs cassette's controlJobID");

                SET_MSG_RC( strCassette_CheckConditionForDelivery_out,
                            MSG_CAST_PORT_CTRLJOB_UNMATCH,
                            RC_CAST_PORT_CTRLJOB_UNMATCH );

                return RC_CAST_PORT_CTRLJOB_UNMATCH;
            }

            /*===== compare reserved controlJobID vs cassette's controlJobID =====*/
            if ( 0 != CIMFWStrCmp(saveControlJobID.identifier, eqpControlJobID.identifier) )
            {
                PPT_METHODTRACE_V1("","compare reserved controlJobID vs cassette's controlJobID");

                SET_MSG_RC( strCassette_CheckConditionForDelivery_out,
                            MSG_CAST_PORT_CTRLJOB_UNMATCH,
                            RC_CAST_PORT_CTRLJOB_UNMATCH );

                return RC_CAST_PORT_CTRLJOB_UNMATCH;
            }

            /*===== check reserved controlJobID's cassette count vs in-parm's cassette count =====*/
            if ( 0 < CIMFWStrLen(saveControlJobID.identifier) )
            {
                PPT_METHODTRACE_V1("","check reserved controlJobID's cassette count vs in-parm's cassette count");

                lenCassette = strStartCassette.length();
                if ( cjCastCnt != lenCassette )

                {
                    PPT_METHODTRACE_V1("","return RC_CAST_PORT_CTRLJOB_COUNT_UNMATCH");
                    SET_MSG_RC( strCassette_CheckConditionForDelivery_out,
                                MSG_CAST_PORT_CTRLJOB_COUNT_UNMATCH,
                                RC_CAST_PORT_CTRLJOB_COUNT_UNMATCH );

                    return RC_CAST_PORT_CTRLJOB_COUNT_UNMATCH;
                }
            }
        }
        else
        {
            PPT_METHODTRACE_V1("","operation != SP_Operation_OpeStart");
        }

        /*------------------------------------------------------------------------------*/
        /*                                                                              */
        /*   Check Condition for Eqp's MultiRecipeCapability VS RecipeParameterValue    */
        /*                                                                              */
        /*------------------------------------------------------------------------------*/
        if ( 0 == CIMFWStrCmp(operation, SP_Operation_OpeStart)
          || 0 == CIMFWStrCmp(operation, SP_Operation_StartReservation) )
        {
            PPT_METHODTRACE_V1("", "operation = SP_Operation_OpeStart or SP_Operation_StartReservation");

            if ( 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_SingleRecipe)
              || 0 == CIMFWStrCmp(multiRecipeCapability, SP_Eqp_MultiRecipeCapability_Batch) )
            {
                PPT_METHODTRACE_V1("", "multiRecipeCapability = SP_Eqp_MultiRecipeCapability_SingleRecipe or SP_Eqp_MultiRecipeCapability_Batch");
                /*-----------------------------------*/
                /*   Work Valiable for Check Logic   */
                /*-----------------------------------*/
                CORBA::Long baseSetFlag = FALSE;
                CORBA::Long baseI       = 0;
                CORBA::Long baseJ       = 0;
                CORBA::Long baseRPLen   = 0;

                /*-------------------------------*/
                /*   Loop for strStartCassette   */
                /*-------------------------------*/
                for ( i=0; i < lenCassette; i++ )
                {
                    /*------------------------*/
                    /*   Omit EmptyCassette   */
                    /*------------------------*/
                    if ( 0 == CIMFWStrCmp(strStartCassette[i].loadPurposeType, SP_LoadPurposeType_EmptyCassette) )
                    {
                        PPT_METHODTRACE_V1("","strStartCassette[i].loadPurposeType == SP_LoadPurposeType_EmptyCassette");
                        continue;
                    }

                    /*-------------------------------*/
                    /*   Loop for strLotInCassette   */
                    /*-------------------------------*/
                    CORBA::Long lenLotInCassette = strStartCassette[i].strLotInCassette.length();

                    for ( j=0; j < lenLotInCassette; j++ )
                    {
                        /*------------------------*/
                        /*   Omit Non-Start Lot   */
                        /*------------------------*/
                        if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )
                        {
                            PPT_METHODTRACE_V1("","strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE");
                            continue;
                        }

                        /*-------------------------------------*/
                        /*   Check RecipeParameterChangeType   */
                        /*-------------------------------------*/
                        if ( 0 != CIMFWStrCmp( strStartCassette[i].strLotInCassette[j].recipeParameterChangeType, SP_Rparm_ChangeType_ByLot ) )
                        {
                            PPT_METHODTRACE_V1("","return RC_INVALID_RPARM_CHANGETYPE!!");
                            PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForDelivery_out,
                                                 MSG_INVALID_RPARM_CHANGETYPE,
                                                 RC_INVALID_RPARM_CHANGETYPE,
                                                 strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                                 strStartCassette[i].cassetteID.identifier );
                            return RC_INVALID_RPARM_CHANGETYPE;
                        }

                        /*--------------------*/
                        /*   Save Base Info   */
                        /*--------------------*/
                        if ( baseSetFlag == FALSE )
                        {
                            PPT_METHODTRACE_V1("","baseSetFlag == FALSE");
                            baseSetFlag = TRUE;
                            baseI       = i;
                            baseJ       = j;

                            if ( strStartCassette[i].strLotInCassette[j].strLotWafer.length() > 0 )
                            {
                                PPT_METHODTRACE_V1("","strStartCassette[i].strLotInCassette[j].strLotWafer.length() > 0");
                                baseRPLen = strStartCassette[i].strLotInCassette[j].strLotWafer[0].strStartRecipeParameter.length();
                            }
                            else
                            {
                                PPT_METHODTRACE_V1("","return RC_INVALID_CAST_XFERSTAT!!");
                                PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForDelivery_out,
                                                     MSG_INVALID_WAFER_CNT,
                                                     RC_INVALID_WAFER_CNT,
                                                     strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                                     strStartCassette[i].cassetteID.identifier );

                                return RC_INVALID_WAFER_CNT;
                            }
                        }

                        /*--------------------------*/
                        /*   Loop for strLotWafer   */
                        /*--------------------------*/
                        CORBA::Long lwLen = strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                        for ( CORBA::Long k=0 ; k<lwLen ; k++ )
                        {
                            /*---------------------------------*/
                            /*   Check RecipeParameter Count   */
                            /*---------------------------------*/
                            CORBA::Long rpLen = strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length();

                            if ( rpLen != baseRPLen )
                            {
                                PPT_METHODTRACE_V1("","return RC_NOT_SAME_PRARM_INFO!!");
                                PPT_SET_MSG_RC_KEY4( strCassette_CheckConditionForDelivery_out,
                                                     MSG_NOT_SAME_RPARM_INFO,
                                                     RC_NOT_SAME_RPARM_INFO,
                                                     strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                                     strStartCassette[i].cassetteID.identifier,
                                                     strStartCassette[baseI].strLotInCassette[baseJ].lotID.identifier,
                                                     strStartCassette[baseI].cassetteID.identifier );

                                return RC_NOT_SAME_RPARM_INFO;
                            }

                            /*--------------------------------------*/
                            /*   Loop for strStartRecipeParameter   */
                            /*--------------------------------------*/
                            for ( CORBA::Long l=0 ; l<rpLen ; l++ )
                            {

                                /*-----------------------------------------------*/
                                /*   Check RecipeParameter Info is Same or Not   */
                                /*-----------------------------------------------*/
                                /*===== parameterName check (string) =====*/
                                if ( 0 != CIMFWStrCmp( strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterName, strStartCassette[baseI].strLotInCassette[baseJ].strLotWafer[0].strStartRecipeParameter[l].parameterName ) )
                                {
                                    PPT_METHODTRACE_V1("","return RC_NOT_SAME_RPARM_INFO!!");
                                    PPT_SET_MSG_RC_KEY4( strCassette_CheckConditionForDelivery_out,
                                                         MSG_NOT_SAME_RPARM_INFO,
                                                         RC_NOT_SAME_RPARM_INFO,
                                                         strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                                         strStartCassette[i].cassetteID.identifier,
                                                         strStartCassette[baseI].strLotInCassette[baseJ].lotID.identifier,
                                                         strStartCassette[baseI].cassetteID.identifier );

                                    return RC_NOT_SAME_RPARM_INFO;
                                }

                                /*===== parameterValue check (string) =====*/
                                if ( 0 != CIMFWStrCmp( strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterValue, strStartCassette[baseI].strLotInCassette[baseJ].strLotWafer[0].strStartRecipeParameter[l].parameterValue ) )
                                {
                                    PPT_METHODTRACE_V1("","return RC_NOT_SAME_RPARM_INFO!!");
                                    PPT_SET_MSG_RC_KEY4( strCassette_CheckConditionForDelivery_out,
                                                         MSG_NOT_SAME_RPARM_INFO,
                                                         RC_NOT_SAME_RPARM_INFO,
                                                         strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                                         strStartCassette[i].cassetteID.identifier,
                                                         strStartCassette[baseI].strLotInCassette[baseJ].lotID.identifier,
                                                         strStartCassette[baseI].cassetteID.identifier );

                                    return RC_NOT_SAME_RPARM_INFO;
                                }

                                /*===== useCurrentSettingValueFlag check (boolean) =====*/
                                if ( strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].useCurrentSettingValueFlag !=  strStartCassette[baseI].strLotInCassette[baseJ].strLotWafer[0].strStartRecipeParameter[l].useCurrentSettingValueFlag )
                                {
                                    PPT_METHODTRACE_V1("","return RC_NOT_SAME_RPARM_INFO!!");
                                    PPT_SET_MSG_RC_KEY4( strCassette_CheckConditionForDelivery_out,
                                                         MSG_NOT_SAME_RPARM_INFO,
                                                         RC_NOT_SAME_RPARM_INFO,
                                                         strStartCassette[i].strLotInCassette[j].lotID.identifier,
                                                         strStartCassette[i].cassetteID.identifier,
                                                         strStartCassette[baseI].strLotInCassette[baseJ].lotID.identifier,
                                                         strStartCassette[baseI].cassetteID.identifier );

                                    return RC_NOT_SAME_RPARM_INFO;
                                }
                            }
                        }
                    }
                }
            }
        }

        /*----------------------*/
        /*                      */
        /*   Return to Caller   */
        /*                      */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_CheckConditionForDelivery");

        return( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_CheckConditionForDelivery_out, cassette_CheckConditionForDelivery, methodName)
}
