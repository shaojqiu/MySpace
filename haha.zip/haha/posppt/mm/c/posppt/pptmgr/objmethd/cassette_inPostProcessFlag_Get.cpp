#ifndef lint
static char *sccsid =  "@(#) 1.2 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_inPostProcessFlag_Get.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 8/6/07 11:56:10 [ 8/6/07 11:56:11 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_inPostProcessFlag_Get.cpp
//

#include "pptmgr.hpp"

#include "pcas.hh"

//[Object Function Name]: long   cassette_inPostProcessFlag_Get
//
// Date        Level        Author         Note
// ----------  -----------  -------------  -------------------------------------------
// 2007/08/17  D9000056     H.Hotta        Initial release for PostProcess performance improvement.
//
//[Function Description]:
//  This function gets the specified Cassette's InPostProcessFlag and returns it.
//
//[Input Parameters]:
//  in  pptObjCommonIn                         strObjCommonIn;
//  in  objCassette_inPostProcessFlag_Get_in   strCassette_inPostProcessFlag_Get_in;
//
//  typedef struct objCassette_inPostProcessFlag_Get_in_struct {
//     objectIdentifier  casetteID;
//     any               siInfo;
//  } objCassette_inPostProcessFlag_Get_in;
//
//[Output Parameters]:
//
//  out objCassette_inPostProcessFlag_Get_out  strCassette_inPostProcessFlag_Get_out;
//
//  typedef struct objCassette_inPostProcessFlag_Get_out_struct {
//     pptRetCode        strResult;
//     boolean           inPostProcessFlagOfCassette;
//     any               siInfo;
//  } objCassette_inPostProcessFlag_Get_out;
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//  RC_INVALID_INPUT_PARM     MSG_INVALID_INPUT_PARM
//

CORBA::Long PPTManager_i:: cassette_inPostProcessFlag_Get (
    objCassette_inPostProcessFlag_Get_out&       strCassette_inPostProcessFlag_Get_out,
    const pptObjCommonIn&                        strObjCommonIn,
    const objCassette_inPostProcessFlag_Get_in&  strCassette_inPostProcessFlag_Get_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_inPostProcessFlag_Get");
        PPT_METHODTRACE_V2("", "in-para casetteID ", strCassette_inPostProcessFlag_Get_in.cassetteID.identifier);

        //----------------
        //  Initialize
        //----------------


        //---------------------------
        //  Check input parameter
        //---------------------------
        if( CIMFWStrLen( strCassette_inPostProcessFlag_Get_in.cassetteID.identifier ) <= 0 )
        {
            PPT_METHODTRACE_V1("", "CIMFWStrLen( strCassette_inPostProcessFlag_Get_in.cassetteID.identifier ) <= 0");
            SET_MSG_RC( strCassette_inPostProcessFlag_Get_out,
                        MSG_INVALID_INPUT_PARM,
                        RC_INVALID_INPUT_PARM );
            return( RC_INVALID_INPUT_PARM );
        }

        //-------------------------------------------
        //  Convert cassetteID to cassette object
        //-------------------------------------------
        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                               strCassette_inPostProcessFlag_Get_in.cassetteID,
                                               strCassette_inPostProcessFlag_Get_out,
                                               cassette_inPostProcessFlag_Get );

        //---------------------------------------
        //  Get InPostProcessFlag of cassette
        //---------------------------------------
        try
        {
            strCassette_inPostProcessFlag_Get_out.inPostProcessFlagOfCassette = aCassette->isPostProcessFlagOn();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isPostProcessFlagOn);

        //----------------------
        //  Return to Caller
        //----------------------
        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_inPostProcessFlag_Get");
        return( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_inPostProcessFlag_Get_out, cassette_inPostProcessFlag_Get, methodName);
}
