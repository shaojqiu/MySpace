#ifndef lint
static char *sccsid =  "@(#) 1.5 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_CheckConditionForWaferSort.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 8/9/07 18:55:36 [ 8/9/07 18:55:37 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_CheckConditionForWaferSort.cpp
//

#include "pptmgr.hpp"

#include "pcas.hh"
#include "pctrlj.hh"


//[Object Function Name]: long   cassette_CheckConditionForWaferSort()
//
// Date        Level       Author         Note
// ----------  ----------  -------------  -------------------------------------------
// 2000/09/14              H.Katoh        Initial Release
// 2000/10/23  P3000280    K.Matsuei      CORBA::Boolean does not initialized. sometime It causes error.
// 2007/08/03  D9000056    H.Hotta        Add check logic for InPostProcessFlag.
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/25 DSIV00000099 F.Chen        SLM(Small Lot Manufacturing) Support.
// 2008/10/30 DSIV00000214 S.Miyata       Multi Fab Transfer Support
//
//[Function Description]
//  * If 1 carrier is loaded on 1 equipment, all input carriers must be loaded on the same equipment.
//      (This method does not check carrier-equipment relation.)
//  * If 1 carrier is not loaded on any equipment, all input carriers must not be loaded on any equipment.
//      (This method does not check carrier-equipment relation.)
//  * If carrier is loaded on some equipment, this method maintains equipment's carrier-lot data
//    and inprocessing log data. and also maintain controlJob's carrier-lot information.
//
//
//[Input Parameters]:
//  in  pptObjCommonIn              strObjCommonIn;
//  in  objectIdentifier            equipmentID;
//  in  pptWaferTransferSequence    strWaferXferSeq;
//
//
//[Output Parameters]:
//
//  out objCassette_CheckConditionForWaferSort_out  strCassette_CheckConditionForWaferSort_out;
//
//  typedef struct objCassette_CheckConditionForWaferSort_out_struct {
//     pptRetCode         strResult;
//  } objCassette_CheckConditionForWaferSort_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  -------------------------   --------------------------------------------------
//
//[Pseudo Code]:
//

CORBA::Long PPTManager_i::cassette_CheckConditionForWaferSort(
                            objCassette_CheckConditionForWaferSort_out& strCassette_CheckConditionForWaferSort_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& equipmentID,
                            const pptWaferTransferSequence& strWaferXferSeq )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_CheckConditionForWaferSort");

        CORBA::Long rc = RC_OK;  //D9000056

        //--------------------------------------------------
        // Collect cassette ID of input parameter
        //--------------------------------------------------
        PPT_METHODTRACE_V1("", "Collect cassette ID of input parameter");

        objectIdentifierSequence cassetteIDSeq;
        booleanSequence bCassetteManagedBySiViewSeq;
        CORBA::Long i, j;
//P3000280        CORBA::Boolean bCassetteAdded;
        CORBA::Boolean bCassetteAdded = FALSE;  //P3000280
        CORBA::Long lenWaferXferSeq = strWaferXferSeq.length();
        CORBA::Long lenCasIDSeq=0;

        PPT_METHODTRACE_V2("", "lenWaferXferSeq-->", lenWaferXferSeq);

        for ( i=0; i < lenWaferXferSeq; i++ )
        {
            bCassetteAdded = FALSE;

            lenCasIDSeq = cassetteIDSeq.length();
            PPT_METHODTRACE_V2("", "lenCasIDSeq-->", lenCasIDSeq);
            for ( j=0; j < lenCasIDSeq; j++ )
            {
                if ( 0 == CIMFWStrCmp(strWaferXferSeq[i].destinationCassetteID.identifier, cassetteIDSeq[j].identifier) )
                {
                    PPT_METHODTRACE_V2("", "set bCassetteAdded = TRUE", j);
                    bCassetteAdded = TRUE;
                    break;
                }
            }
            if ( bCassetteAdded == FALSE )
            {
                PPT_METHODTRACE_V1("", "bCassetteAdded == FALSE");

                lenCasIDSeq++;
                cassetteIDSeq.length(lenCasIDSeq);
                cassetteIDSeq[lenCasIDSeq-1] = strWaferXferSeq[i].destinationCassetteID;

                CORBA::Long lenCasMangBySiViewSeq = bCassetteManagedBySiViewSeq.length();
                lenCasMangBySiViewSeq++;
                bCassetteManagedBySiViewSeq.length(lenCasMangBySiViewSeq);
                bCassetteManagedBySiViewSeq[lenCasMangBySiViewSeq-1] = strWaferXferSeq[i].bDestinationCassetteManagedBySiView;
            }

            bCassetteAdded = FALSE;

            lenCasIDSeq = cassetteIDSeq.length();
            PPT_METHODTRACE_V2("", "lenCasIDSeq-->", lenCasIDSeq);
            for ( j=0; j < lenCasIDSeq; j++ )
            {
                if ( 0 == CIMFWStrCmp(strWaferXferSeq[i].originalCassetteID.identifier, cassetteIDSeq[j].identifier) )
                {
                    PPT_METHODTRACE_V2("", "set bCassetteAdded = TRUE", j);
                    bCassetteAdded = TRUE;
                    break;
                }
            }
            if ( bCassetteAdded == FALSE )
            {
                PPT_METHODTRACE_V1("", "bCassetteAdded == FALSE");

                lenCasIDSeq++;
                cassetteIDSeq.length(lenCasIDSeq);
                //PTR3000270 cassetteIDSeq[lenCasIDSeq-1] = strWaferXferSeq[i].destinationCassetteID;
                cassetteIDSeq[lenCasIDSeq-1] = strWaferXferSeq[i].originalCassetteID;

                CORBA::Long lenCasMangBySiViewSeq = bCassetteManagedBySiViewSeq.length();
                lenCasMangBySiViewSeq++;
                bCassetteManagedBySiViewSeq.length(lenCasMangBySiViewSeq);
                bCassetteManagedBySiViewSeq[lenCasMangBySiViewSeq-1] = strWaferXferSeq[i].bOriginalCassetteManagedBySiView;
            }
        }

        //--------------------------------------------------
        // Collect cassette's equipment ID / Cassette ObjRef
        //--------------------------------------------------
        lenCasIDSeq = cassetteIDSeq.length();
        PPT_METHODTRACE_V2("", "Collect cassette's equipment ID / Cassette ObjRef", lenCasIDSeq);

        PosCassetteSequence aPosCassetteSeq;
        aPosCassetteSeq.length(lenCasIDSeq);

        stringSequence strLoadedEquipments;
        strLoadedEquipments.length(lenCasIDSeq);

        CORBA::Long LoadedEqpCnt = 0;

        for ( i=0; i < lenCasIDSeq; i++ )
        {
//P3000280            CORBA::Boolean cassetteFound;
            CORBA::Boolean cassetteFound = FALSE;  //P3000280
            PosCassette_var aPosCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_WITH_NO_RETURN( aPosCassette, cassetteIDSeq[i] );

            if ( FALSE == cassetteFound )
            {
                PPT_METHODTRACE_V1("", "continue!!");
                continue;
            }

            CORBA::String_var tmpCassetteTransportState;
            try
            {
                tmpCassetteTransportState = aPosCassette->getTransportState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::currentAssignedMachine);

            Machine_var tmpMachine;
            try
            {
                tmpMachine = aPosCassette->currentAssignedMachine();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::currentAssignedMachine);

            LoadedEqpCnt++;
            strLoadedEquipments.length(LoadedEqpCnt);
            aPosCassetteSeq[LoadedEqpCnt-1] = aPosCassette;

            if ( ! CORBA::is_nil(tmpMachine) &&
                 0 == CIMFWStrCmp(tmpCassetteTransportState, SP_TransState_EquipmentIn) )
            {
                PPT_METHODTRACE_V1("", "tmpMachine is not nil");

                CORBA::String_var strLoadedEquipment;
                try
                {
                    strLoadedEquipment = tmpMachine->getIdentifier();
                }
                CATCH_AND_RAISE_EXCEPTIONS(Machine::getIdentifier);

                strLoadedEquipments[LoadedEqpCnt-1] = strLoadedEquipment;
            }
        }

        strLoadedEquipments.length(LoadedEqpCnt);
        aPosCassetteSeq.length(LoadedEqpCnt);

//D9000056 add start
        //-----------------------------
        //  Check InPostProcessFlag
        //-----------------------------
        PPT_METHODTRACE_V1("", "Check InPostProcessFlag.");

        for( i = 0; i < lenCasIDSeq; i++ )
        {
            if( TRUE == bCassetteManagedBySiViewSeq[i] )
            {
                //---------------------------------------
                //  Get InPostProcessFlag of Cassette
                //---------------------------------------
                objCassette_inPostProcessFlag_Get_out strCassette_inPostProcessFlag_Get_out;
                objCassette_inPostProcessFlag_Get_in  strCassette_inPostProcessFlag_Get_in;
                strCassette_inPostProcessFlag_Get_in.cassetteID = cassetteIDSeq[i];

                rc = cassette_inPostProcessFlag_Get( strCassette_inPostProcessFlag_Get_out,
                                                     strObjCommonIn,
                                                     strCassette_inPostProcessFlag_Get_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "cassette_inPostProcessFlag_Get() != RC_OK");
                    strCassette_CheckConditionForWaferSort_out.strResult = strCassette_inPostProcessFlag_Get_out.strResult;
                    return( rc );
                }

//DSIV00000214 add start
                objCassette_interFabXferState_Get_out strCassette_interFabXferState_Get_out;
                objCassette_interFabXferState_Get_in strCassette_interFabXferState_Get_in;
                strCassette_interFabXferState_Get_in.cassetteID = cassetteIDSeq[i];

                rc = cassette_interFabXferState_Get( strCassette_interFabXferState_Get_out,
                                                     strObjCommonIn,
                                                     strCassette_interFabXferState_Get_in );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "cassette_interFabXferState_Get() != RC_OK");
                    strCassette_CheckConditionForWaferSort_out.strResult = strCassette_interFabXferState_Get_out.strResult;
                    return( rc );
                }

                if( CIMFWStrCmp( strCassette_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Transferring ) == 0 )
                {
                     PPT_METHODTRACE_V1("", "interFabXferState == Transferring");
                     PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForWaferSort_out,
                                          MSG_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                          RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ,
                                          cassetteIDSeq[i].identifier,
                                          strCassette_interFabXferState_Get_out.interFabXferState );
                     return( RC_INTERFAB_INVALID_CAST_XFERSTATE_FOR_REQ );
                }

                objCassette_lotList_GetDR_out strCassette_lotList_GetDR_out;
                rc = cassette_lotList_GetDR( strCassette_lotList_GetDR_out,
                                             strObjCommonIn,
                                             cassetteIDSeq[i] );
                if( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "cassette_lotList_GetDR() != RC_OK");
                    strCassette_CheckConditionForWaferSort_out.strResult = strCassette_lotList_GetDR_out.strResult;
                    return( rc );
                }

                CORBA::Long lotLen = strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID.length();
                for( CORBA::ULong j = 0; j < lotLen; j++ )
                {
                    objLot_interFabXferState_Get_out strLot_interFabXferState_Get_out;
                    objLot_interFabXferState_Get_in strLot_interFabXferState_Get_in;
                    strLot_interFabXferState_Get_in.lotID = strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID[j];

                    rc = lot_interFabXferState_Get( strLot_interFabXferState_Get_out,
                                                    strObjCommonIn,
                                                    strLot_interFabXferState_Get_in );
                    if( rc != RC_OK )
                    {
                        PPT_METHODTRACE_V1("", "lot_interFabXferState_Get() != RC_OK");
                        strCassette_CheckConditionForWaferSort_out.strResult = strLot_interFabXferState_Get_out.strResult;
                        return( rc );
                    }

                    if( CIMFWStrCmp( strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_OriginDeleting ) == 0 ||
                        CIMFWStrCmp( strLot_interFabXferState_Get_out.interFabXferState, SP_InterFab_XferState_Transferring ) == 0 )
                    {
                         PPT_METHODTRACE_V1("", "interFabXferState == OriginDeleting");
                         PPT_SET_MSG_RC_KEY2( strCassette_CheckConditionForWaferSort_out,
                                              MSG_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ,
                                              RC_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ,
                                              strCassette_lotList_GetDR_out.strLotListInCassetteInfo.lotID[i].identifier,
                                              strLot_interFabXferState_Get_out.interFabXferState );
                         return( RC_INTERFAB_INVALID_LOT_XFERSTATE_FOR_REQ );
                    }
                }
//DSIV00000214 add end

                //---------------------------------------------------
                //  If Cassette is in post process, returns error
                //---------------------------------------------------
                if( TRUE == strCassette_inPostProcessFlag_Get_out.inPostProcessFlagOfCassette )
                {
                    PPT_METHODTRACE_V1("", "Cassette is in post process.");
                    PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForWaferSort_out,
                                        MSG_CAST_INPOSTPROCESS, RC_CAST_INPOSTPROCESS,
                                        cassetteIDSeq[i].identifier );
                    return( RC_CAST_INPOSTPROCESS );
                }
//DSIV00000099 Add Start
                PosCassette_var aCassette;
                PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette, cassetteIDSeq[i],
                                                       strCassette_CheckConditionForWaferSort_out,
                                                       cassette_CheckConditionForWaferSort );

                PosMachine_var aSLMReservedMachine;
                try
                {
                    aSLMReservedMachine = aCassette->getSLMReservedMachine();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getSLMReservedMachine);
                
                if (!CORBA::is_nil(aSLMReservedMachine))
                {
                    PPT_METHODTRACE_V1("", "Cassette is in post process.");
                    PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForWaferSort_out,
                                        MSG_ALREADY_RESERVED_CAST_SLM, RC_ALREADY_RESERVED_CAST_SLM,
                                        cassetteIDSeq[i].identifier );
                    return( RC_ALREADY_RESERVED_CAST_SLM );
                }
//DSIV00000099 Add End
                
            }
        }
//D9000056 add end

        //--------------------------------------------------
        // Check all cassette is on the same equipment
        //--------------------------------------------------
        CORBA::String_var tmpLoadedEquipment;
        CORBA::Long lenLoadedEqp = strLoadedEquipments.length();
        PPT_METHODTRACE_V2("", "Check all cassette is on the same equipment", lenLoadedEqp);

        for (i=0; i < lenLoadedEqp; i++)
        {
            if ( 0 == i )
            {
                PPT_METHODTRACE_V2("", "i == 0", strLoadedEquipments[0]);
                tmpLoadedEquipment = strLoadedEquipments[0];
            }
            else
            {
                PPT_METHODTRACE_V3("", "i > 0", i, strLoadedEquipments[i]);

                if ( 0 != CIMFWStrCmp(tmpLoadedEquipment, strLoadedEquipments[i]) )
                {
                    SET_MSG_RC( strCassette_CheckConditionForWaferSort_out,
                                MSG_EQP_OF_CASSETTE_NOT_SAME,
                                RC_EQP_OF_CASSETTE_NOT_SAME );

                    return RC_EQP_OF_CASSETTE_NOT_SAME;
                }
            }
        }

        //--------------------------------------------------
        // Check equipment of cassette and input equipment is same or not
        //--------------------------------------------------
        PPT_METHODTRACE_V1("", "Check equipment of cassette and input equipment is same or not");

        if ( 0 != CIMFWStrCmp(equipmentID.identifier, tmpLoadedEquipment) )
        {
            SET_MSG_RC( strCassette_CheckConditionForWaferSort_out,
                        MSG_CASSETTE_EQP_DIFFERENT,
                        RC_CASSETTE_EQP_DIFFERENT );

            return RC_CASSETTE_EQP_DIFFERENT;
        }

        //--------------------------------------------------
        // If equipmetnID is not input, return OK
        //--------------------------------------------------
        PPT_METHODTRACE_V1("", "If equipmetnID is not input, return OK");

        if ( 0 == CIMFWStrLen(equipmentID.identifier) && 0 == CIMFWStrLen(tmpLoadedEquipment) )
        {
            PPT_METHODTRACE_EXIT("PPTManager_i::cassette_CheckConditionForWaferSort");
            return RC_OK;
        }

        //--------------------------------------------------
        // Get object reference of PosMachine
        //--------------------------------------------------
        PPT_METHODTRACE_V1("", "Get object reference of PosMachine");

        PosMachine_var aPosMachine;
        PPT_CONVERT_EQPID_TO_MACHINE_OR( aPosMachine,
                                         equipmentID,
                                         strCassette_CheckConditionForWaferSort_out,
                                         cassette_CheckConditionForWaferSort );
        // if aPosMachine is NIL, return error

        //--------------------------------------------------
        // Get Equipment attributes
        //--------------------------------------------------
        PPT_METHODTRACE_V1("", "Get Equipment attributes");

        CORBA::String_var strMachineCategory;
        try
        {
            strMachineCategory = aPosMachine->getCategory();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosMachine::getCategory);

        //--------------------------------------------------
        // Check Equipment Type
        //--------------------------------------------------
        PPT_METHODTRACE_V1("", "Check Equipment Type");

        if ( 0 != CIMFWStrCmp(strMachineCategory, SP_Mc_Category_WaferSorter) )
        {
            PPT_METHODTRACE_V1("", "Machine Type != Wafer Sorter");
            PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForWaferSort_out,
                                MSG_MACHINE_TYPE_NOT_SORTER,
                                RC_MACHINE_TYPE_NOT_SORTER,
                                strMachineCategory );

            return RC_MACHINE_TYPE_NOT_SORTER;
        }

        //--------------------------------------------------
        // Check Control Job Info
        //--------------------------------------------------
        PPT_METHODTRACE_V1("", "Check Control Job Info");

        CORBA::String_var strCassetteControlJob;
        CORBA::String_var tmpCassetteControlJob;
        CORBA::Long lenCasSeq = aPosCassetteSeq.length();
        PPT_METHODTRACE_V2("", "lenCasSeq-->", lenCasSeq);

        for ( i=0; i < lenCasSeq; i++ )
        {
            PosControlJob_var aPosCtrlJob;

            if ( i == 0 )
            {
                PPT_METHODTRACE_V1("", "i == 0");
                try
                {
                    aPosCtrlJob = aPosCassetteSeq[i]->getControlJob();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)

                if ( CORBA::is_nil(aPosCtrlJob) )
                {
                    PPT_METHODTRACE_V1("", "aPosCtrlJob is nil");

                    CORBA::String_var cassetteID;
                    try
                    {
                        cassetteID = aPosCassetteSeq[i]->getIdentifier();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getIdentifier)

                    PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForWaferSort_out,
                                        MSG_NOT_SAME_CTLJOBID,
                                        RC_NOT_SAME_CTLJOBID,
                                        cassetteID );
                }
                else
                {
                    PPT_METHODTRACE_V1("", "aPosCtrlJob is not nil");
                    try
                    {
                        strCassetteControlJob = aPosCtrlJob->getIdentifier();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosControlJob::getIdentifier)
                }
            }
            else
            {
                PPT_METHODTRACE_V2("", "i > 0", i);
                try
                {
                    aPosCtrlJob = aPosCassetteSeq[i]->getControlJob();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob)

                if ( CORBA::is_nil(aPosCtrlJob) )
                {
                    PPT_METHODTRACE_V1("", "aPosCtrlJob is nil");

                    CORBA::String_var cassetteID;
                    try
                    {
                        cassetteID = aPosCassetteSeq[i]->getIdentifier();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getIdentifier)

                    PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForWaferSort_out,
                                        MSG_NOT_SAME_CTLJOBID,
                                        RC_NOT_SAME_CTLJOBID,
                                        cassetteID );
                }
                else
                {
                    PPT_METHODTRACE_V1("", "aPosCtrlJob is not nil");
                    try
                    {
                        tmpCassetteControlJob = aPosCtrlJob->getIdentifier();
                    }
                    CATCH_AND_RAISE_EXCEPTIONS(PosControlJob::getIdentifier)

                    if ( 0 != CIMFWStrCmp(strCassetteControlJob, tmpCassetteControlJob) )
                    {
                        PPT_METHODTRACE_V1("", "strCassetteControlJob != tmpCassetteControlJob");

                        CORBA::String_var cassetteID;
                        try
                        {
                            cassetteID = aPosCassetteSeq[i]->getIdentifier();
                        }
                        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getIdentifier)

                        PPT_SET_MSG_RC_KEY( strCassette_CheckConditionForWaferSort_out,
                                            MSG_NOT_SAME_CTLJOBID,
                                            RC_NOT_SAME_CTLJOBID,
                                            cassetteID );
                    }
                }
            }
        }

        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_CheckConditionForWaferSort");

        return( RC_OK );
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_CheckConditionForWaferSort_out, cassette_CheckConditionForWaferSort, methodName)
}

