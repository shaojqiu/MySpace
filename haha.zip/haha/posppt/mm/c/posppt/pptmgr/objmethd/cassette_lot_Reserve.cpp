#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_lot_Reserve.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:35:03 [ 7/13/07 19:35:04 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_lot_Reserve.cpp
//

#include "pptmgr.hpp"
#include "timstamp.hpp"
#include "duration.hpp"

#include "pcas.hh"
#include "plot.hh"
#include "pperson.hh"
#include "pstmc.hh"
#include "pmc.hh"
#include "pbufrs.hh"
#include "pmaloc.hh"
//D5000016 #include "ppcgrp.hh"

// Class: PPTManager
//
// Service: cassette_lot_Reserve()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 2000/10/23 P3000280 K.Matsuei      CORBA::Boolean does not initialized. sometime It causes error.
// 2003/05/19 D5000016 K.Kido         Useless class deletion.
//
// Description:
//
// Return:
//     Long
//
// Parameter:
//    objCassette_lot_Reserve_out&   strCassette_lot_Reserve_out
//    const pptObjCommonIn& strObjCommonIn
//    const pptReserveLotSequence& strReserveLot
//    const char * claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long PPTManager_i::cassette_lot_Reserve(objCassette_lot_Reserve_out&   strCassette_lot_Reserve_out, const pptObjCommonIn& strObjCommonIn,  const pptReserveLotSequence& strReserveLot,  const char * claimMemo)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_lot_Reserve");

        PosPerson_var aPerson;
        PPT_GET_PERSON_FROM_USERID(aPerson, strObjCommonIn.strUser.userID, strCassette_lot_Reserve_out,cassette_lot_Reserve);

        CORBA::Long len, i;
//P3000280        CORBA::Boolean isEmpty, cassetteTransferReserved, lotTransferReserved;
        CORBA::Boolean isEmpty = FALSE;                     //P3000280
        CORBA::Boolean cassetteTransferReserved = FALSE;    //P3000280
        CORBA::Boolean lotTransferReserved = FALSE;         //P3000280

        len = strReserveLot.length();
        PPT_METHODTRACE_V2("PPTManager_i::cassette_lot_Reserve","strReserveLot.length()",len);

        PosCassette_var aCassette;
        for ( i = 0; i < len; i++)
        {
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR(aCassette, strReserveLot[i].cassetteID,strCassette_lot_Reserve_out, cassette_lot_Reserve);

            try
            {
                PPT_DISPLAY_RESPONSE_TIME();
                cassetteTransferReserved = aCassette->isReserved();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isReserved);

            if(cassetteTransferReserved)
            {
                SET_MSG_RC(strCassette_lot_Reserve_out, MSG_ALREADY_RESERVED_CST,RC_ALREADY_RESERVED_CST)
                return RC_ALREADY_RESERVED_CST;
            }

            try
            {
                CORBA::Boolean reserved;
                PPT_DISPLAY_RESPONSE_TIME();
                reserved = aCassette->reserveFor(aPerson);
                if ( reserved == FALSE )
                {
                    SET_MSG_RC(strCassette_lot_Reserve_out, MSG_ALREADY_RESERVED_CST,RC_ALREADY_RESERVED_CST)
                    return RC_ALREADY_RESERVED_CST;
                }
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::reserveFor);
        }

        strCassette_lot_Reserve_out.strReserveLot = strReserveLot;
        strCassette_lot_Reserve_out.claimMemo     = claimMemo;

        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_lot_Reserve");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_lot_Reserve_out, cassette_lot_Reserve, methodName)
}

