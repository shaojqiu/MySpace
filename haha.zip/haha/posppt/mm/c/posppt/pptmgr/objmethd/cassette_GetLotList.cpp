#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_GetLotList.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:33:06 [ 7/13/07 19:33:07 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_GetLotList.cpp
//

#include "pptmgr.hpp"

#include "pcas.hh"
#include "plot.hh"

//[Object Function Name]: long   cassette_GetLotList
//
// Date        Level  Author         Note
// ----------  -----  -------------  -------------------------------------------
// 2000-07-24  0.00   H.Ueda         Initial Release (R30)
// 2000/10/19 P3000276 S.Kawabe      Change Macro PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR
//                                            --> PPT_CONVERT_CASSETTEID_TO_CASSETTE_WITH_NO_RETURN
// 2002/10/07 P4200220 Y.Iwasaki     Return cassetteID absolutely even if it is Empty.
//
//
//[Function Description]:
//  Get lot information which is contained in cassetteID of In Parameter and return multiLotType.
//
//[Input Parameters]:
//  in  pptObjCommonIn    strObjCommonIn;
//  in  objectIdentifier  cassetteID;
//
//[Output Parameters]:
//
//  out objCassette_GetLotList_out   strCassette_GetLotList_out;
//
//  typedef struct objCassette_GetLotList_out_struct {
//     pptRetCode                strResult;
//     pptLotListInCassetteInfo  strLotListInCassetteInfo;
//  } objCassette_GetLotList_out;
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//  RC_SYSTEM_ERROR           MSG_SYSTEM_ERROR
//  RC_NOT_FOUND_LOT          MSG_NOT_FOUND_LOT
//

CORBA::Long  PPTManager_i::cassette_GetLotList(
                                  objCassette_GetLotList_out&  strCassette_GetLotList_out,
                                  const pptObjCommonIn&         strObjCommonIn,
                                  const objectIdentifier&       cassetteID)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_GetLotList");

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        /*-------------------------*/
        /*   Get Cassette Object   */
        /*-------------------------*/
        PosCassette_var aCassette;
//P3000276        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette, cassetteID,
//P3000276                                               strCassette_GetLotList_out,
//P3000276                                               cassette_GetLotList );
//P3000276 add start
        CORBA::Boolean cassetteFound = FALSE;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_WITH_NO_RETURN( aCassette, cassetteID );
        if( CORBA::is_nil( aCassette ) )
        {
            PPT_SET_MSG_RC_KEY(strCassette_GetLotList_out,
                               MSG_NOT_FOUND_CASSETTE,
                               RC_NOT_FOUND_CASSETTE,
                               cassetteID.identifier);
            return RC_NOT_FOUND_CASSETTE;
        }
//P3000276 add end

        //P4200220 add start
        //----------------------------------------//
        //   Set CassetteID to return structure   //
        //----------------------------------------//
        PPT_SET_OBJECT_IDENTIFIER(strCassette_GetLotList_out.strLotListInCassetteInfo.cassetteID,
                                  aCassette,
                                  strCassette_GetLotList_out,
                                  cassette_GetLotList,
                                  PosCassette);
        //P4200220 add end

        /*----------------------*/
        /*   Get multiLotType   */
        /*----------------------*/
        try
        {
            strCassette_GetLotList_out.strLotListInCassetteInfo.multiLotType = aCassette->getMultiLotType();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getMultiLotType);

        /*------------------------------------------------*/
        /*   Get LotIDs which are contained in cassette   */
        /*------------------------------------------------*/
        LotSequence* aLotSequence = NULL;
        try
        {
            PPT_DISPLAY_RESPONSE_TIME();
            aLotSequence = aCassette->allLots();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::allLots);

        LotSequence_var aTmpSeq = aLotSequence;

        CORBA::Long nLen;
        nLen = aLotSequence->length();
        PPT_METHODTRACE_V2("PPTManager_i::cassette_GetLotList", "aLotSequence->length()", nLen);

        if ( nLen == 0 )
        {
            PPT_METHODTRACE_V1("PPTManager_i::cassette_GetLotList", "nLen == 0");
            PPT_SET_MSG_RC_KEY(strCassette_GetLotList_out, MSG_NOT_FOUND_LOT, RC_NOT_FOUND_LOT, "*****");
            return RC_NOT_FOUND_LOT;
        }
        else
        {
            PPT_METHODTRACE_V1("PPTManager_i::cassette_GetLotList", "nLen != 0");

            strCassette_GetLotList_out.strLotListInCassetteInfo.lotID.length(nLen);
            for ( CORBA::Long i=0; i< nLen; i++ )
            {
                PPT_METHODTRACE_V2("PPTManager_i::cassette_GetLotList", "loop to aLotSequence->length()", i);
                PPT_SET_OBJECT_IDENTIFIER( strCassette_GetLotList_out.strLotListInCassetteInfo.lotID[i],
                                           (*aLotSequence)[i],
                                           strCassette_GetLotList_out,
                                           cassette_GetLotList,
                                           PosLot );
            }
        }

        strCassette_GetLotList_out.strLotListInCassetteInfo.cassetteID = cassetteID;

        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_GetLotList");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_GetLotList_out, cassette_GetLotList, methodName)
}
