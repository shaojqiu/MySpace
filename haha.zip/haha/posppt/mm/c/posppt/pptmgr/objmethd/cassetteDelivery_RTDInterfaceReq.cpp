#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassetteDelivery_RTDInterfaceReq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:30:35 [ 7/13/07 19:30:36 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassetteDelivery_RTDInterfaceReq.cpp
//

#include "pptmgr.hpp"


//[Object Function Name]: long   cassetteDelivery_RTDInterfaceReq
//
// Date        Level     Author         Note
// ----------  --------  -------------  -------------------------------------------
// 2001.09.11  0.00      K.Matsuei      Initial Release.
// 2004-11-04  P6000009  K.Matsuei      When RTD returns the column name which SiView does not know, CassetteDelivery goes wrong.
//
//[Function Description]:
//
//[Input Parameters]:
//  in  pptObjCommonIn              strObjCommonIn
//  in  const char*                 kind
//  in  const objectIdentifier&     keyID
//
//[Output Parameters]:
//  out objCassetteDelivery_RTDInterfaceReq_out   strCassetteDelivery_RTDInterfaceReq_out;
//
//  typedef struct objCassetteDelivery_RTDInterfaceReq_out_struct {
//      pptRetCode                     strResult;
//      pptWhereNextInterBayInqResult  strWhereNextInterBayInqResult;
//      pptWhatNextLotListInqResult    strWhatNextLotListInqResult;
//  } objCassetteDelivery_RTDInterfaceReq_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                       MSG_OK
//
//[Pseudo Code]:
//

CORBA::Long PPTManager_i::cassetteDelivery_RTDInterfaceReq(
        objCassetteDelivery_RTDInterfaceReq_out&  strCassetteDelivery_RTDInterfaceReq_out,
        const pptObjCommonIn&                       strObjCommonIn,
        const char*                                 kind,
        const objectIdentifier&                     keyID )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassetteDelivery_RTDInterfaceReq");

        PPT_METHODTRACE_V2("", "InParam [ kind]", kind);
        PPT_METHODTRACE_V2("", "InParam [keyID]", keyID.identifier);

        CORBA::Long rc = RC_OK;
        CORBA::Long i;

        /*-------------------------------------------*/
        /*   Read setting information from FSRTDIF   */
        /*-------------------------------------------*/
        PPT_METHODTRACE_V1("", "/*-------------------------------------------*/");
        PPT_METHODTRACE_V1("", "/*   Read setting information from FSRTDIF   */");
        PPT_METHODTRACE_V1("", "/*-------------------------------------------*/");

        objRTD_data_GetDR_out strRTD_data_GetDR_out;
        rc = RTD_data_GetDR( strRTD_data_GetDR_out,
                             strObjCommonIn,
                             kind,
                             keyID.identifier );

        if ( rc != RC_OK && rc == RC_NOT_FOUND_RTD )
        {
            PPT_METHODTRACE_V1("", "RTD_data_GetDR != RC_OK && RTD_data_GetDR == RC_NOT_FOUND_RTD");
            rc = RTD_data_GetDR( strRTD_data_GetDR_out,
                                 strObjCommonIn,
                                 kind,
                                 "*" );
        }

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "##### RC_OK != RTD_data_GetDR()");
            strCassetteDelivery_RTDInterfaceReq_out.strResult = strRTD_data_GetDR_out.strResult;
            return rc;
        }

        /*---------------------------------*/
        /*   Prepare AdditionalParameter   */
        /*---------------------------------*/
        PPT_METHODTRACE_V1("", "/*---------------------------------*/");
        PPT_METHODTRACE_V1("", "/*   Prepare AdditionalParameter   */");
        PPT_METHODTRACE_V1("", "/*---------------------------------*/");
        stringSequence additParams;
        additParams.length(0);
        char tmpBuf[1024];
        CIMFWStrCpy(&tmpBuf[0], strRTD_data_GetDR_out.RTDRecords[0].optionAttributes);

        char *startPos = &tmpBuf[0];
        char *endPos   = &tmpBuf[0];

        CORBA::Long nDataNum;
        for ( nDataNum=0; endPos != NULL; nDataNum++ )
        {
            endPos = strstr(startPos, ",");
            if ( endPos != NULL )
            {
                PPT_METHODTRACE_V1("","endPos != NULL");
                *endPos = '\0';
                additParams.length(nDataNum + 1);
                additParams[nDataNum] = CIMFWStrDup(startPos);
                startPos = endPos + 1;
            }
            else
            {
                PPT_METHODTRACE_V1("","endPos == NULL");
                additParams.length(nDataNum + 1);
                additParams[nDataNum] = CIMFWStrDup(startPos);
            }
        }

        CORBA::Long len = additParams.length();
        PPT_METHODTRACE_V2("", "additParams.length", len);
        for ( i=0; i < len; i++ )
        {
            PPT_METHODTRACE_V3("", "additParams", i, additParams[i]);
        }

        /*------------------------------*/
        /*   call RTD Service Manager   */
        /*------------------------------*/
        PPT_METHODTRACE_V1("", "/*------------------------------*/");
        PPT_METHODTRACE_V1("", "/*   call RTD Service Manager   */");
        PPT_METHODTRACE_V1("", "/*------------------------------*/");
        pptRTDDispatchListInqResult  strRTDDispatchListInqResult;
        rc = txRTDDispatchListInq( strRTDDispatchListInqResult,
                                   strObjCommonIn,
                                   kind,
                                   keyID.identifier,
                                   additParams );
        if( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "##### RC_OK != txRTDDispatchListInq()");
            strCassetteDelivery_RTDInterfaceReq_out.strResult = strRTDDispatchListInqResult.strResult;
            return rc;
        }

//P6000009 start
        //-------------------------------------
        //   Duplication columns are checked
        //-------------------------------------
        PPT_METHODTRACE_V1("", "Duplication columns are checked");
        CORBA::Long nLenCol = strRTDDispatchListInqResult.strDispatchResult.columnHeaders.length();
        PPT_METHODTRACE_V2("", "nLenCol", nLenCol);
        for ( i=0; i < nLenCol; i++ )
        {
            PPT_METHODTRACE_V3("", "column[i]", i, strRTDDispatchListInqResult.strDispatchResult.columnHeaders[i]);
            for ( CORBA::Long j=0; j < nLenCol; j++ )
            {
                if ( i == j )
                {
                    // Same column is not checked.
                    continue;
                }
                if ( 0 == CIMFWStrCmp(strRTDDispatchListInqResult.strDispatchResult.columnHeaders[i],
                                      strRTDDispatchListInqResult.strDispatchResult.columnHeaders[j]) )
                {
                    PPT_METHODTRACE_V1("", "##### Duplicate Column Name!!");
                    PPT_SET_MSG_RC_KEY( strCassetteDelivery_RTDInterfaceReq_out,
                                        MSG_DUPLICATE_RTD_COLUMN, RC_DUPLICATE_RTD_COLUMN,
                                        strRTDDispatchListInqResult.strDispatchResult.columnHeaders[i] );
                    return RC_DUPLICATE_RTD_COLUMN;
                }
            } // end of [j]
        } // end of [i]
//P6000009 end

        if ( 0 == CIMFWStrCmp(kind, SP_RTD_Function_Code_WhereNext) )
        {
            /*-----------------------------------------------*/
            /*   convert dispatchInfo to WhereNextInterBay   */
            /*-----------------------------------------------*/
            PPT_METHODTRACE_V1("", "/*-----------------------------------------------*/");
            PPT_METHODTRACE_V1("", "/*   convert dispatchInfo to WhereNextInterBay   */");
            PPT_METHODTRACE_V1("", "/*-----------------------------------------------*/");
            objRTD_dispatchDataToWhereNextInterBay_Convert_out  strRTD_dispatchDataToWhereNextInterBay_Convert_out;
            rc = RTD_dispatchDataToWhereNextInterBay_Convert( strRTD_dispatchDataToWhereNextInterBay_Convert_out,
                                                              strObjCommonIn,
                                                              strRTDDispatchListInqResult.strDispatchResult );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "##### RC_OK != RTD_dispatchDataToWhereNextInterBay_Convert()");
                strCassetteDelivery_RTDInterfaceReq_out.strResult = strRTD_dispatchDataToWhereNextInterBay_Convert_out.strResult;
                return rc;
            }

            strCassetteDelivery_RTDInterfaceReq_out.strWhereNextInterBayInqResult = strRTD_dispatchDataToWhereNextInterBay_Convert_out.strWhereNextInterBayInqResult;
        }
        else if ( 0 == CIMFWStrCmp(kind, SP_RTD_Function_Code_WhatNext) )
        {
            /*------------------------------------------*/
            /*   convert dispatchInfo to WhatNextInfo   */
            /*------------------------------------------*/
            PPT_METHODTRACE_V1("", "/*------------------------------------------*/");
            PPT_METHODTRACE_V1("", "/*   convert dispatchInfo to WhatNextInfo   */");
            PPT_METHODTRACE_V1("", "/*------------------------------------------*/");
            objRTD_dispatchDataToWhatNextLotList_Convert_out  strRTD_dispatchDataToWhatNextLotList_Convert_out;
            rc = RTD_dispatchDataToWhatNextLotList_Convert( strRTD_dispatchDataToWhatNextLotList_Convert_out,
                                                            strObjCommonIn,
                                                            strRTDDispatchListInqResult.strDispatchResult );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "##### RC_OK != RTD_dispatchDataToWhatNextLotList_Convert()");
                strCassetteDelivery_RTDInterfaceReq_out.strResult = strRTD_dispatchDataToWhatNextLotList_Convert_out.strResult;
                return rc;
            }

            strCassetteDelivery_RTDInterfaceReq_out.strWhatNextLotListInqResult = strRTD_dispatchDataToWhatNextLotList_Convert_out.strWhatNextLotListInqResult;
        }
        else
        {
            PPT_METHODTRACE_V1("", "##### Not Found RTD Kind !!!!!");
        }

        PPT_METHODTRACE_EXIT("PPTManager_i::cassetteDelivery_RTDInterfaceReq");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassetteDelivery_RTDInterfaceReq_out, cassetteDelivery_RTDInterfaceReq, methodName);
}
