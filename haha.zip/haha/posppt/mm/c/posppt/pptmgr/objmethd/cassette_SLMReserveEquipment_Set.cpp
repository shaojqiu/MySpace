//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_SLMReserveEquipment_Set.cpp
//

#include "pptmgr.hpp"
#include "pcas.hh"

// Class: PPTManager
//
// Service: cassette_SLMReserveEquipment_Set()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2008/07/11 DSIV00000099 M.Ogawa        Initial release (R10.0).
//
//[Function Description]:
//    Update cassette's SLMReservedEquipment.
//
// return
//    long
//[Input Parameters]:
//    const pptObjCommonIn&                                     strObjCommonIn,
//    const objCassette_SLMReserveEquipment_Set_in&             strCassette_SLMReserveEquipment_Set_in
//
// typedef struct objCassette_SLMReserveEquipment_Set_in_struct {
//     objectIdentifier  cassetteID;
//     objectIdentifier  SLMReserveEquipmentID;
//     any               siInfo;
// } objCassette_SLMReserveEquipment_Set_in;
//
//[Output Parameters]:
//    objCassette_SLMReserveEquipment_Set_out& strCassette_SLMReserveEquipment_Set_out
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long PPTManager_i:: cassette_SLMReserveEquipment_Set (
    objCassette_SLMReserveEquipment_Set_out&                  strCassette_SLMReserveEquipment_Set_out,
    const pptObjCommonIn&                                     strObjCommonIn,
    const objCassette_SLMReserveEquipment_Set_in&             strCassette_SLMReserveEquipment_Set_in )
{
    char*  methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_SLMReserveEquipment_Set");
        CORBA::Long  rc = RC_OK;

        /*--------------------------*/
        /*   Get Equipment Object   */
        /*--------------------------*/
        PPT_METHODTRACE_V1("", "Get Equipment object.");
        PosMachine_var aMachine = PosMachine::_nil();
        if( 0 != CIMFWStrLen(strCassette_SLMReserveEquipment_Set_in.SLMReserveEquipmentID.identifier) )
        {
            PPT_CONVERT_EQPID_TO_MACHINE_OR( aMachine,
                                             strCassette_SLMReserveEquipment_Set_in.SLMReserveEquipmentID,
                                             strCassette_SLMReserveEquipment_Set_out,
                                             cassette_SLMReserveEquipment_Set );
        }

        /*-------------------------*/
        /*   Get Cassette Object   */
        /*-------------------------*/
        PPT_METHODTRACE_V1("", "Get Cassette object.");
        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                               strCassette_SLMReserveEquipment_Set_in.cassetteID,
                                               strCassette_SLMReserveEquipment_Set_out,
                                               cassette_SLMReserveEquipment_Set );

        /*-----------------------------*/
        /*   Set SLMReserved Machine   */
        /*-----------------------------*/
        PPT_METHODTRACE_V1("", "Set reserved machine for retrieving.");
        try
        {
            aCassette->setSLMReservedMachine( aMachine );
        }
        CATCH_AND_RAISE_EXCEPTIONS( PosCassette::setSLMReservedMachine );


        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_SLMReserveEquipment_Set");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS( strCassette_SLMReserveEquipment_Set_out, cassette_SLMReserveEquipment_Set, methodName );
}
