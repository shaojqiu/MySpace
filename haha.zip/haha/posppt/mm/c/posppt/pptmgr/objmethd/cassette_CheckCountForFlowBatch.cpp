#ifndef lint
static char *sccsid =  "@(#) 1.4 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_CheckCountForFlowBatch.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 10/23/07 14:21:07 [ 10/23/07 14:21:08 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_CheckCountForFlowBatch.cpp
//

#include "pptmgr.hpp"

//[Object Function Name]: long   cassette_CheckCountForFlowBatch
//
// Date        Level        Author         Note
// ----------  -----------  -------------  -------------------------------------------
// 2000/07/07  0.00         O.Ohishi       Initial Release
// 2001/12/25  D4100036     K.Matsuei      FlowBatch Control.
// 2002/02/24  D4100036(2)  K.Matsuei      FlowBatch Control. add InputParam[operation]
// 2002/02/25  D4100036(3)  K.Matsuei      FlowBatch Control. add Check MinimumWaferSize
// 2002/02/27  D4100036(4)  K.Matsuei      FlowBatch Control. Add operation [SP_Operation_FlowBatchingAuto]
// 2002/09/05  P4200136     K.Matsuei      The check of MaxSize, MinSize, MinWaferCnt may leak by FlowBatch.
// 2002/09/12  P4200140     K.Matsuei      ErrorMessage is wrong in FlowBatch.
// 2002/11/06  P4200328     N.Maeda        Fixed Saved Max Batch Size and Saved Min Batch Size substitution
// 2007/10/23  D9000001     K.Matsuei      64bit support.
//
//[Function Description]:
//  Check Size for Flow Batch with target Operation
//
//[Input Parameters]:
//  in  pptObjCommonIn                          strObjCommonIn;
//D4100036//  in  pptUser                                 requestUserID;
//  in  objectIdentifier                        equipmentID;
//  in  sequence <pptFlowBatchingReqCassette>   strFlowBatchingReqCassette;
//  in  string                                  claimMemo;
//
//  typedef struct pptFlowBatchingReqCassette_struct {
//      objectIdentifier                        cassetteID;
//      sequence <objectIdentifier>             lotID;
//  } pptFlowBatchingReqCassette;
//
//[Output Parameters]:
//  out objCassette_CheckCountForFlowBatch_out   strCassette_CheckCountForFlowBatch_out;
//
//  typedef struct objCassette_CheckCountForFlowBatch_out_struct {
//      pptRetCode                  strResult;
//  } objCassette_CheckCountForFlowBatch_out;
//
//[Return Value]:
//
//  Return Code                               Messsage ID
//  ----------------------------------------- ------------------------------------------------
//  RC_OK                                     MSG_OK
//P4200140//  RC_INVALID_LOT_COUNT_FOR_BATCH            RC_INVALID_LOT_COUNT_FOR_BATCH;
//  RC_INVALID_CASSETTE_COUNT_FOR_BATCH       MSG_INVALID_CASSETTE_COUNT_FOR_BATCH;  //P4200140
//

CORBA::Long  PPTManager_i::cassette_CheckCountForFlowBatch(
                                  objCassette_CheckCountForFlowBatch_out&    strCassette_CheckCountForFlowBatch_out,
                                  const pptObjCommonIn&                      strObjCommonIn,
//D4100036                                  const pptUser&                             requestUserID,
                                  const objectIdentifier&                    equipmentID,
                                  const pptFlowBatchingReqCassetteSequence&  strFlowBatchingReqCassette,
                                  const char*                                operation,     //D4100036(2)
                                  const char*                                claimMemo )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_CheckCountForFlowBatch");

{
        PPT_METHODTRACE_V1("", "*****************************************************************");
        PPT_METHODTRACE_V1("", "  Input Parameter");
        PPT_METHODTRACE_V1("", "*****************************************************************");
        PPT_METHODTRACE_V2("", "equipmentID", equipmentID.identifier);
        PPT_METHODTRACE_V2("", "operation  ", operation);
        CORBA::Long len = strFlowBatchingReqCassette.length();
        PPT_METHODTRACE_V2("", "strFlowBatchingReqCassette.length", len);
        for ( CORBA::Long ii=0; ii < len; ii++ )
        {
        PPT_METHODTRACE_V2("", "cassetteID_________", strFlowBatchingReqCassette[ii].cassetteID.identifier);
        CORBA::Long len2 = strFlowBatchingReqCassette[ii].lotID.length();
        PPT_METHODTRACE_V2("", "strFlowBatchingReqCassette.lot.length", len2);
        for ( CORBA::Long jj=0; jj < len2; jj++ )
        {
        PPT_METHODTRACE_V2("", "lotID______________", strFlowBatchingReqCassette[ii].lotID[jj].identifier);
        }
        PPT_METHODTRACE_V1("", "");
        }
}

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long rc = RC_OK;

        /*----------------------------------------------*/
        /*   Check lot count to create new Flow Batch   */
        /*----------------------------------------------*/
        PPT_METHODTRACE_V1("", "/*----------------------------------------------*/");
        PPT_METHODTRACE_V1("", "/*   Check lot count to create new Flow Batch   */");
        PPT_METHODTRACE_V1("", "/*----------------------------------------------*/");
        CORBA::Long i, j, lotLen, cassetteLen;
        cassetteLen = strFlowBatchingReqCassette.length();
        PPT_METHODTRACE_V2("", "strFlowBatchingReqCassette.length()", cassetteLen);

        CORBA::Long savedMaxSize = 0;
        CORBA::Long savedMinSize = 0;
        CORBA::Long savedMinWaferSize = 0;  //D4100036(3)
        CORBA::Long totalWaferCount = 0;    //D4100036(3)
        CORBA::Long nAllLotCount = 0;

        for ( i=0; i < cassetteLen; i++ )
        {
            lotLen = strFlowBatchingReqCassette[i].lotID.length();
            PPT_METHODTRACE_V2("", "-----------------------------------------round strFlowBatchingReqCassette[i]", i);
            PPT_METHODTRACE_V2("", "cassetteID", strFlowBatchingReqCassette[i].cassetteID.identifier);

            nAllLotCount += lotLen;

            for ( j=0; j < lotLen; j++ )
            {
                PPT_METHODTRACE_V2("", "-----------------------------------------round strFlowBatchingReqCassette[i].lot[j]", j);
                PPT_METHODTRACE_V2("", "lotID", strFlowBatchingReqCassette[i].lotID[j].identifier);

//D4100036(3) start
                /*---------------------------*/
                /*   Get WaferCount of Lot   */
                /*---------------------------*/
                PPT_METHODTRACE_V1("", "call lot_materials_GetWafers()");
                objLot_materials_GetWafers_out  strLot_materials_GetWafers_out;
                rc = lot_materials_GetWafers( strLot_materials_GetWafers_out, strObjCommonIn, strFlowBatchingReqCassette[i].lotID[j] );

                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "##### lot_materials_GetWafers() != RC_OK", rc);
                    strCassette_CheckCountForFlowBatch_out.strResult = strLot_materials_GetWafers_out.strResult;
                    return rc;
                }
                totalWaferCount += strLot_materials_GetWafers_out.strLotWaferAttributes.length();
                PPT_METHODTRACE_V2("", "totalWaferCount", totalWaferCount);
//D4100036(3) end

                /*----------------------------------------------*/
                /*   Get lot's flow batch section information   */
                /*----------------------------------------------*/
                PPT_METHODTRACE_V1("", "call process_GetFlowBatchDefinition()");
                objProcess_GetFlowBatchDefinition_out strProcess_GetFlowBatchDefinition_out;
                rc = process_GetFlowBatchDefinition( strProcess_GetFlowBatchDefinition_out,
                                                     strObjCommonIn,
                                                     strFlowBatchingReqCassette[i].lotID[j] );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V2("", "##### process_GetFlowBatchDefinition() rc != RC_OK", rc);
                    strCassette_CheckCountForFlowBatch_out.strResult = strProcess_GetFlowBatchDefinition_out.strResult;
                    return rc;
                }
                PPT_METHODTRACE_V1("", "-------------------------------------------------------------------------");
                PPT_METHODTRACE_V2("", "FlowBatchArea.name-------------->", strProcess_GetFlowBatchDefinition_out.name);
                PPT_METHODTRACE_V2("", "FlowBatchArea.size-------------->", strProcess_GetFlowBatchDefinition_out.size);
                PPT_METHODTRACE_V2("", "FlowBatchArea.minimumSize------->", strProcess_GetFlowBatchDefinition_out.minimumSize);
                PPT_METHODTRACE_V2("", "FlowBatchArea.minWaferCount----->", strProcess_GetFlowBatchDefinition_out.minWaferCount);
//D9000001                PPT_METHODTRACE_V2("", "FlowBatchArea.targetOperation--->", (long)strProcess_GetFlowBatchDefinition_out.targetOperation);
                PPT_METHODTRACE_V2("", "FlowBatchArea.targetOperation--->", (int)strProcess_GetFlowBatchDefinition_out.targetOperation); //D9000001
                PPT_METHODTRACE_V1("", "-------------------------------------------------------------------------");

                /*--------------------------------------------*/
                /*   Save max / min batch size for each lot   */
                /*--------------------------------------------*/
//P4200328 delete                if ( j == 0 )
                if ( j == 0 && i == 0 )                                                         //P4200328 add
                {
                    PPT_METHODTRACE_V1("", "j == 0");
                    savedMaxSize = strProcess_GetFlowBatchDefinition_out.size;
                    savedMinSize = strProcess_GetFlowBatchDefinition_out.minimumSize;
                    savedMinWaferSize = strProcess_GetFlowBatchDefinition_out.minWaferCount;    //D4100036(3)
                    continue;
                }
                else
                {
                    if ( strProcess_GetFlowBatchDefinition_out.size < savedMaxSize )
                    {
                        savedMaxSize = strProcess_GetFlowBatchDefinition_out.size;
                        PPT_METHODTRACE_V2("", "Change savedMaxSize", savedMaxSize);
                    }
                    if ( strProcess_GetFlowBatchDefinition_out.minimumSize > savedMinSize )
                    {
                        savedMinSize = strProcess_GetFlowBatchDefinition_out.minimumSize;
                        PPT_METHODTRACE_V2("", "Change savedMinSize", savedMinSize);
                    }
//D4100036(3) start
                    if ( strProcess_GetFlowBatchDefinition_out.minWaferCount < savedMinWaferSize )
                    {
                        savedMinWaferSize = strProcess_GetFlowBatchDefinition_out.minWaferCount;
                        PPT_METHODTRACE_V2("", "Change savedMinWaferSize", savedMinWaferSize);
                    }
//D4100036(3) end
                }
            } //end of [j]
        } //end of [i]

        /*--------------------------------*/
        /*   Check max / min batch size   */
        /*--------------------------------*/
        PPT_METHODTRACE_V1("", "/*--------------------------------*/");
        PPT_METHODTRACE_V1("", "/*   Check max / min batch size   */");
        PPT_METHODTRACE_V1("", "/*--------------------------------*/");
        PPT_METHODTRACE_V4("", "cassetteLen , savedMaxSize , savedMinSize", cassetteLen, savedMaxSize, savedMinSize);
        if ( cassetteLen > savedMaxSize || cassetteLen < savedMinSize )
        {
            PPT_METHODTRACE_V1("", "cassetteLen > savedMaxSize || cassetteLen < savedMinSize");
//P4200140            PPT_METHODTRACE_V1("", "##### return RC_INVALID_LOT_COUNT_FOR_BATCH");
            PPT_METHODTRACE_V1("", "##### return RC_INVALID_CASSETTE_COUNT_FOR_BATCH"); //P4200140
            char  stringMaxSize[32];
            char  stringMinSize[32];
            sprintf( stringMaxSize, "%ld", savedMaxSize );
            sprintf( stringMinSize, "%ld", savedMinSize );

            PPT_SET_MSG_RC_KEY2( strCassette_CheckCountForFlowBatch_out,
//P4200140                                 MSG_INVALID_LOT_COUNT_FOR_BATCH, RC_INVALID_LOT_COUNT_FOR_BATCH,
                                 MSG_INVALID_CASSETTE_COUNT_FOR_BATCH, RC_INVALID_CASSETTE_COUNT_FOR_BATCH, //P4200140
                                 stringMinSize, stringMaxSize );
//P4200140            return RC_INVALID_LOT_COUNT_FOR_BATCH;
            return RC_INVALID_CASSETTE_COUNT_FOR_BATCH; //P4200140
        }

//D4100036(4) start
        /*----------------------------------------------*/
        /*   AutoFlowBatching must surely be MaxSize.   */
        /*----------------------------------------------*/
        if ( 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatchingAuto) )
        {
            PPT_METHODTRACE_V1("", "operation is [AutoBatching]");
            PPT_METHODTRACE_V1("", "/*----------------------------------------------*/");
            PPT_METHODTRACE_V1("", "/*   AutoFlowBatching must surely be MaxSize.   */");
            PPT_METHODTRACE_V1("", "/*----------------------------------------------*/");

//P4200136 start
            PPT_METHODTRACE_V1("", "call equipment_processBatchCondition_Get()");
            objEquipment_processBatchCondition_Get_out  strEquipment_processBatchCondition_Get_out;
            rc = equipment_processBatchCondition_Get( strEquipment_processBatchCondition_Get_out,
                                                      strObjCommonIn,
                                                      equipmentID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "##### equipment_processBatchCondition_Get() != RC_OK");
                strCassette_CheckCountForFlowBatch_out.strResult = strEquipment_processBatchCondition_Get_out.strResult;
                return( rc );
            }
            PPT_METHODTRACE_V2("", "  .minBatchSize", strEquipment_processBatchCondition_Get_out.minBatchSize);
            PPT_METHODTRACE_V2("", "  .maxBatchSize", strEquipment_processBatchCondition_Get_out.maxBatchSize);
            PPT_METHODTRACE_V2("", "  .minWaferSize", strEquipment_processBatchCondition_Get_out.minWaferSize);

            if ( savedMaxSize > strEquipment_processBatchCondition_Get_out.maxBatchSize )
            {
                PPT_METHODTRACE_V1("", "Change MaxSize ---> EQP's MaxBatchSize");
                savedMaxSize = strEquipment_processBatchCondition_Get_out.maxBatchSize;
            }
//P4200136 end

            if ( cassetteLen != savedMaxSize )
            {
//P4200140                PPT_METHODTRACE_V1("", "##### return RC_INVALID_LOT_COUNT_FOR_BATCH");
                PPT_METHODTRACE_V1("", "##### return RC_INVALID_CASSETTE_COUNT_FOR_BATCH"); //P4200140
                char  stringMaxSize[32];
                sprintf( stringMaxSize, "%ld", savedMaxSize );
                PPT_SET_MSG_RC_KEY2( strCassette_CheckCountForFlowBatch_out,
//P4200140                                     MSG_INVALID_LOT_COUNT_FOR_BATCH, RC_INVALID_LOT_COUNT_FOR_BATCH,
                                     MSG_INVALID_CASSETTE_COUNT_FOR_BATCH, RC_INVALID_CASSETTE_COUNT_FOR_BATCH, //P4200140
                                     stringMaxSize, stringMaxSize );
//P4200140                return RC_INVALID_LOT_COUNT_FOR_BATCH;
                return RC_INVALID_CASSETTE_COUNT_FOR_BATCH; //P4200140
            }
        }
//D4100036(4) end

//D4100036(3) start
        /*----------------------------*/
        /*   Check MinimumWaferSize   */
        /*----------------------------*/
        if ( 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatchingAuto)     //D4100036(4)
          || 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatching)
          || 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatch_LotRemove)  //P4200136
          || 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatch_EqpReserve) //P4200136
          || 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatch_ReBatch) )
        {
//P4200136            PPT_METHODTRACE_V1("", "operation is [AutoBatching] or [FlowBatching] or [ReBatching]");
            PPT_METHODTRACE_V1("", "operation is [AutoBatching] or [FlowBatching] or [ReBatching] or [LotRemove] or [EqpReserve]"); //P4200136
            PPT_METHODTRACE_V1("", "/*----------------------------*/");
            PPT_METHODTRACE_V1("", "/*   Check MinimumWaferSize   */");
            PPT_METHODTRACE_V1("", "/*----------------------------*/");
            if ( savedMinWaferSize > totalWaferCount )
            {
                PPT_METHODTRACE_V3("", "savedMinWaferSize > totalWaferCount", savedMinWaferSize, totalWaferCount);
                PPT_METHODTRACE_V1("", "##### return RC_INVALID_FLOW_BATCH_MINWAFER_CNT");
                char  strMinWaferSize[32];
                char  strTotalWaferSize[32];
                sprintf( strMinWaferSize, "%ld", savedMinWaferSize );
                sprintf( strTotalWaferSize, "%ld", totalWaferCount );
                PPT_SET_MSG_RC_KEY2( strCassette_CheckCountForFlowBatch_out,
                                     MSG_INVALID_FLOW_BATCH_MINWAFER_CNT, RC_INVALID_FLOW_BATCH_MINWAFER_CNT,
                                     strTotalWaferSize, strMinWaferSize );
                return RC_INVALID_FLOW_BATCH_MINWAFER_CNT;
            }
        }
//D4100036(3) end

        if ( 0 != CIMFWStrCmp(operation, SP_Operation_FlowBatch_LotRemove)          //P4200136
          && 0 != CIMFWStrCmp(operation, SP_Operation_FlowBatch_EqpReserve) )       //P4200136
        {                                                                           //P4200136
            PPT_METHODTRACE_V1("", "operation is not [LotRemove], [EqpReserve]");   //P4200136
            /*-----------------------------------------*/
            /*   Check operation flow for flow batch   */
            /*-----------------------------------------*/
            PPT_METHODTRACE_V1("", "/*-----------------------------------------*/");
            PPT_METHODTRACE_V1("", "/*   Check operation flow for flow batch   */");
            PPT_METHODTRACE_V1("", "/*-----------------------------------------*/");
            pptBatchingReqLotSequence strBatchingReqLot;
            strBatchingReqLot.length( nAllLotCount );

            CORBA::Long nSetIdx = 0;
            for ( i=0; i < cassetteLen; i++ )
            {
                lotLen = strFlowBatchingReqCassette[i].lotID.length();
                for ( j=0; j < lotLen; j++ )
                {
                    strBatchingReqLot[nSetIdx].cassetteID = strFlowBatchingReqCassette[i].cassetteID;
                    strBatchingReqLot[nSetIdx].lotID = strFlowBatchingReqCassette[i].lotID[j];

                    PPT_METHODTRACE_V3("", "cassetteID", nSetIdx, strBatchingReqLot[i].cassetteID.identifier);
                    PPT_METHODTRACE_V3("", "     lotID", nSetIdx, strBatchingReqLot[i].lotID.identifier);

                    nSetIdx++;
                } //end of [j]
            } //end of [i]

            PPT_METHODTRACE_V1("", "call lot_operation_CheckSameForFlowBatch()");
            objLot_operation_CheckSameForFlowBatch_out strLot_operation_CheckSameForFlowBatch_out;
            rc = lot_operation_CheckSameForFlowBatch( strLot_operation_CheckSameForFlowBatch_out,
                                                      strObjCommonIn,
                                                      equipmentID,
                                                      strBatchingReqLot );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V2("", "##### RC_OK != lot_operation_CheckSameForFlowBatch()", rc)
                strCassette_CheckCountForFlowBatch_out.strResult = strLot_operation_CheckSameForFlowBatch_out.strResult;
                return rc;
            }
        }  //P4200136

//P4200136 start
        /*---------------------------------------------------------*/
        /*   Check about MaxSize, MinSize of EQP-BatchCondition.   */
        /*---------------------------------------------------------*/
        if ( 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatching)
          || 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatch_LotRemove)
          || 0 == CIMFWStrCmp(operation, SP_Operation_FlowBatch_EqpReserve) )
        {
            PPT_METHODTRACE_V1("", "operation is [FlowBatching] or [LotRemove] or [EqpReserve]");
            if ( 0 < CIMFWStrLen(equipmentID.identifier) )
            {
                PPT_METHODTRACE_V1("", "call equipment_processBatchCondition_Get()");
                objEquipment_processBatchCondition_Get_out  strEquipment_processBatchCondition_Get_out;
                rc = equipment_processBatchCondition_Get( strEquipment_processBatchCondition_Get_out,
                                                          strObjCommonIn,
                                                          equipmentID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("", "##### equipment_processBatchCondition_Get() != RC_OK");
                    strCassette_CheckCountForFlowBatch_out.strResult = strEquipment_processBatchCondition_Get_out.strResult;
                    return( rc );
                }
                PPT_METHODTRACE_V2("", "  .minBatchSize", strEquipment_processBatchCondition_Get_out.minBatchSize);
                PPT_METHODTRACE_V2("", "  .maxBatchSize", strEquipment_processBatchCondition_Get_out.maxBatchSize);
                PPT_METHODTRACE_V2("", "  .minWaferSize", strEquipment_processBatchCondition_Get_out.minWaferSize);

                // cassetteLen is checked about MaxSize, MinSize of EQP-BatchCondition.
                if ( cassetteLen < strEquipment_processBatchCondition_Get_out.minBatchSize
                  || cassetteLen > strEquipment_processBatchCondition_Get_out.maxBatchSize )
                {
                    PPT_METHODTRACE_V1("", "##### return RC_INVALID_CASSETTE_COUNT_FOR_BATCH");
                    char procCnt[32];
                    char minSize[32];
                    char maxSize[32];
                    sprintf( procCnt, "%ld", cassetteLen );
                    sprintf( minSize, "%ld", strEquipment_processBatchCondition_Get_out.minBatchSize );
                    sprintf( maxSize, "%ld", strEquipment_processBatchCondition_Get_out.maxBatchSize );

                    PPT_SET_MSG_RC_KEY3( strCassette_CheckCountForFlowBatch_out,
                                         MSG_INVALID_PROCESS_BATCH_COUNT,
                                         RC_INVALID_PROCESS_BATCH_COUNT,
                                         procCnt, maxSize, minSize );
                    return RC_INVALID_PROCESS_BATCH_COUNT;
                }

                // cassetteLen is checked about MinWaferSize of EQP-BatchCondition.
                if ( strEquipment_processBatchCondition_Get_out.minWaferSize > totalWaferCount )
                {
                    PPT_METHODTRACE_V1("", "##### EQP.minWaferSize > totalWaferCount");
                    SET_MSG_RC(strCassette_CheckCountForFlowBatch_out, MSG_INVALID_INPUT_WAFER_COUNT, RC_INVALID_INPUT_WAFER_COUNT);
                    return RC_INVALID_INPUT_WAFER_COUNT;
                }
            }
        }
//P4200136 end

        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_CheckCountForFlowBatch");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_CheckCountForFlowBatch_out, cassette_CheckCountForFlowBatch, methodName)
}
