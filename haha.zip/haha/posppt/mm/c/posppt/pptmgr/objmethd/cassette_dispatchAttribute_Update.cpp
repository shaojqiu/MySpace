#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_dispatchAttribute_Update.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:34:08 [ 7/13/07 19:34:09 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_dispatchAttribute_Update.cpp
//

#include "pptmgr.hpp"

#include "pcas.hh"

// Class: PPTManager
//
// Service: cassette_dispatchAttribute_Update()
//
// Change history:
// Date       Defect#  Person         Comments
// ---------- -------- -------------- -------------------------------------------
// 02/08/07            C.Tsuchiya     Initial Release for R4.2           
//
// Description:
//   This object provides the function which update or delete dispatch attribute of a carrier.
//
// Return:
//
//  Return Code                    Messsage ID
//  ------------------------------ ---------------------------------------------
//  RC_OK                          MSG_OK
//  RC_NOT_FOUND_CASSETTE          MSG_NOT_FOUND_CASSETTE
//  RC_INVALID_CAST_DISP_ATTR      MSG_INVALID_CAST_DISP_ATTR

//
// Parameter:
//    in pptObjCommonIn                         strObjCommonIn,
//    in objectIdentifier                       cassetteID,
//    in boolean                                setFlag,
//    in string                                 actionCode,
//    in string                                 claimMemo
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

//
//  typedef struct objCassette_dispatchAttribute_Update_out_struct {
//      pptRetCode          strResult;
//      any                 siInfo;
//  }  objCassette_dispatchAttribute_Update_out;
//
//

CORBA::Long PPTManager_i::cassette_dispatchAttribute_Update(
                    objCassette_dispatchAttribute_Update_out& strCassette_dispatchAttribute_Update_out,
                    const pptObjCommonIn&          strObjCommonIn,
                    const objectIdentifier&        cassetteID,
                    CORBA::Boolean                 setFlag,
                    const char*                    actionCode)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i:::cassette_dispatchAttribute_Update")

        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR(aCassette, cassetteID,
                                              strCassette_dispatchAttribute_Update_out,
                                              cassette_dispatchAttribute_Update);

        /*------------------------------------------------------------------------*/
        /* Case1. If setFlag is on, update the Dispatch Attribute                      */
        /*------------------------------------------------------------------------*/
        if ( setFlag == TRUE ) {

            // Check String
            if( ( CIMFWStrCmp( actionCode , SP_Sorter_Read           ) != 0 ) &&
                ( CIMFWStrCmp( actionCode , SP_Sorter_MiniRead       ) != 0 ) &&
                ( CIMFWStrCmp( actionCode , SP_Sorter_PositionChange ) != 0 ) &&
                ( CIMFWStrCmp( actionCode , SP_Sorter_JustIn         ) != 0 ) &&
                ( CIMFWStrCmp( actionCode , SP_Sorter_JustOut        ) != 0 ) &&
                ( CIMFWStrCmp( actionCode , SP_Sorter_Scrap          ) != 0 ) &&
                ( CIMFWStrCmp( actionCode , SP_Sorter_VendLot_R_And_P) != 0 ) )
            {
                PPT_SET_MSG_RC_KEY( strCassette_dispatchAttribute_Update_out,
                                    MSG_INVALID_CAST_DISP_ATTR,
                                    RC_INVALID_CAST_DISP_ATTR,
                                    actionCode );
                return RC_INVALID_CAST_DISP_ATTR ;
            }

            // Set DispatchAttributeFlag
            try
            {
                aCassette->makeDispatchAttributeFlagOn();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::makeDispatchAttributeFlagOn);

            //set Action Code
            try
            {
                aCassette->setDispatchAttributeString( actionCode );
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setDispatchAttributeString);

        }

         /*------------------------------------------------------------------------*/
         /* Case2. If setFlag is off, delete the Dispatch Attribute                */
         /*------------------------------------------------------------------------*/
         else
         {

            // Reset DispatchAttributeFlag
            try
            {
                aCassette->makeDispatchAttributeFlagOff();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::makeDispatchAttributeFlagOff);

            // Reset Action Code
            try
            {
                aCassette->setDispatchAttributeString( "" );
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::setDispatchAttributeString);

        }

        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_dispatchAttribute_Update");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_dispatchAttribute_Update_out, cassette_dispatchAttribute_Update, methodName)
}
