//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2011. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2011. All rights reserved.
//
// SiView
// Name: autoDispatchControlEvent_Make.cpp
//

#include "pptmgr.hpp"
#include "pevbase.hh"
#include "pevmg.hh"
#include "pevmggl.hh"

// Class: PPTManager
//
// Service: autoDispatchControlEvent_Make()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2011/09/21 DSN000020767 T.Ishida       Auto Dispatch Control Support
//
//[Function Description]:
//    This function makes Auto Dispatch Control change event.
//
//[Input Parameters]:
//  const pptObjCommonIn&                      strObjCommonIn
//  const objAutoDispatchControlEvent_Make_in& strAutoDispatchControlEvent_Make_in
//
//    typedef struct objAutoDispatchControlEvent_Make_in_struct {
//        objectIdentifier                 lotID;
//        pptAutoDispatchControlUpdateInfo strAutoDispatchControlUpdateInfo;
//        any                              siInfo;
//    } objAutoDispatchControlEvent_Make_in;
//
//[Output Parameters]:
//  objAutoDispatchControlEvent_Make_out& strAutoDispatchControlEvent_Make_out
//
//    typedef objBase_out objAutoDispatchControlEvent_Make_out;
//
//[Return Value]:
//
//  Return Code                        Message ID
//  ---------------------------------- -----------------------------------------
//  RC_OK                              MSG_OK
//
CORBA::Long PPTManager_i::autoDispatchControlEvent_Make(
    objAutoDispatchControlEvent_Make_out&      strAutoDispatchControlEvent_Make_out,
    const pptObjCommonIn&                      strObjCommonIn,
    const objAutoDispatchControlEvent_Make_in& strAutoDispatchControlEvent_Make_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY( "PPTManager_i::autoDispatchControlEvent_Make" );

        //--------------//
        //  Initialize  //
        //--------------//
        CORBA::Long rc = RC_OK;

        objectIdentifier lotID;
        pptAutoDispatchControlUpdateInfo strAutoDispatchControlUpdateInfo;

        lotID                            = strAutoDispatchControlEvent_Make_in.lotID;
        strAutoDispatchControlUpdateInfo = strAutoDispatchControlEvent_Make_in.strAutoDispatchControlUpdateInfo;

        //---------------------------------------------
        // Prepare AutoDispatchControl event
        //---------------------------------------------
        posAutoDispatchControlEventRecord anEventRecord;

        anEventRecord.eventCommon.transactionID  = CIMFWStrDup( strObjCommonIn.transactionID );
        anEventRecord.eventCommon.eventTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
        anEventRecord.eventCommon.eventShopDate  = strObjCommonIn.strTimeStamp.reportShopdate;
        anEventRecord.eventCommon.userID         = strObjCommonIn.strUser.userID.identifier;
        anEventRecord.eventCommon.eventMemo      = CIMFWStrDup( strAutoDispatchControlEvent_Make_in.claimMemo );

        anEventRecord.lotID             = CIMFWStrDup( lotID.identifier );
        anEventRecord.action            = CIMFWStrDup( strAutoDispatchControlUpdateInfo.updateMode );
        anEventRecord.routeID           = CIMFWStrDup( strAutoDispatchControlUpdateInfo.routeID.identifier );
        anEventRecord.operationNumber   = CIMFWStrDup( strAutoDispatchControlUpdateInfo.operationNumber );
        anEventRecord.singleTriggerFlag = strAutoDispatchControlUpdateInfo.singleTriggerFlag;
        anEventRecord.description       = CIMFWStrDup( strAutoDispatchControlUpdateInfo.description );

        //---------------------------------------------
        // Create AutoDispatchControl event
        //---------------------------------------------
        PosEventBase_var  anEvent;
        CORBA::Any        eventRecord;
        eventRecord <<= anEventRecord;
        try
        {
            anEvent = theEventManager->createEvent( eventRecord );
        }
        catch(PosEventManager::InvalidEventRecordTypeSignal)
        {
            SET_MSG_RC( strAutoDispatchControlEvent_Make_out, MSG_INVALID_EVENTRECORD_TYPE, RC_INVALID_EVENTRECORD_TYPE );
            return RC_INVALID_EVENTRECORD_TYPE;
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosEventManager::createEvent)

        SET_MSG_RC( strAutoDispatchControlEvent_Make_out, MSG_OK, RC_OK );
        //--------------------//
        //  Return to Caller  //
        //--------------------//
        PPT_METHODTRACE_EXIT( "PPTManager_i::autoDispatchControlEvent_Make" );
        return RC_OK ;
    }
    CATCH_GLOBAL_EXCEPTIONS( strAutoDispatchControlEvent_Make_out, autoDispatchControlEvent_Make, methodName );
}
