#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_CheckConditionForArrivalCarrierCancel.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:31:05 [ 7/13/07 19:31:06 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_CheckConditionForArrivalCarrierCancel.cpp
//

#include "pptmgr.hpp"
#include "pcas.hh"
#include "pctrlj.hh"

//[Object Function Name]: long   cassette_CheckConditionForArrivalCarrierCancel
//
// Date        Level   Author         Note
// ----------  ------  -------------  -------------------------------------------
// 2001-07-19  D400028 M.Sunakawa     Initial Release (R40)
//
//[Function Description]:
//  Check cassette's condition for ArrivalCarrierCancel.
//
//  The following conditions are checked.
//
//  <<< dispatchState >>>
//  Cassette's dispatch state must be TRUE.
//
//  <<< controlJobID >>>
//  Cassette's controlJobID must be blank.
//
//
//[Input Parameters]:
//  in  pptObjCommonIn               strObjCommonIn;
//  in  pptNPWXferCassetteSequence   strNPWXferCassette;
//
//[Output Parameters]:
//  out objCassette_CheckConditionForArrivalCarrierCancel_out   strCassette_CheckConditionForArrivalCarrierCancel_out;
//
//  typedef struct objCassette_CheckConditionForArrivalCarrierCancel_out_struct {
//      pptRetCode                      strResult;
//  } objCassette_CheckConditionForArrivalCarrierCancel_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  --------------------------- ------------------------------------------------
//  RC_OK                        MSG_OK
//  RC_NOT_DISPATCH_RESVED_CST   MSG_NOT_DISPATCH_RESVED_CST
//  RC_CAST_CTRLJOBID_FILLED     MSG_CAST_CTRLJOBID_FILLED
//[Pseudo Code]:
//


CORBA::Long PPTManager_i::cassette_CheckConditionForArrivalCarrierCancel(objCassette_CheckConditionForArrivalCarrierCancel_out& strCassette_CheckConditionForArrivalCarrierCancel_out,
                                                                         const pptObjCommonIn& strObjCommonIn,
                                                                         const pptNPWXferCassetteSequence& strNPWXferCassette)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_CheckConditionForArrivalCarrierCancel");

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
        CORBA::Long i;
        CORBA::Long lenCassette;
        CORBA::Long rc = RC_OK;
        
        SET_MSG_RC( strCassette_CheckConditionForArrivalCarrierCancel_out, MSG_OK,RC_OK );
        
        /*--------------------------------------*/
        /*                                      */
        /*   Check Cassette's Transfer Status   */
        /*                                      */
        /*--------------------------------------*/
        lenCassette = strNPWXferCassette.length();
        PPT_METHODTRACE_V2("PPTManager_i::cassette_CheckConditionForArrivalCarrierCancel","Check Cassette's Transfer Status  lenCassette=", lenCassette);

        for ( i=0; i<lenCassette; i++)
        {
            PPT_METHODTRACE_V3("PPTManager_i::cassette_CheckConditionForArrivalCarrierCancel", "loop to strNPWXferCassette.length()",lenCassette,i);            
            /*---------------------------*/
            /*   Get cassetteID Object   */
            /*---------------------------*/
            PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckConditionForArrivalCarrierCancel","Get cassetteID Object");
            PosCassette_var aCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                                   strNPWXferCassette[i].cassetteID,
                                                   strCassette_CheckConditionForArrivalCarrierCancel_out,
                                                   cassette_CheckConditionForArrivalCarrierCancel );
            /*-----------------------*/
            /*   Get DispatchState   */
            /*-----------------------*/
            PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckConditionForArrivalCarrierCancel","Get DispatchState");
            CORBA::Boolean dispatchState;
            
            try
            {
                dispatchState = aCassette->isDispatchReserved();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isDispatchReserved)
            
            if ( dispatchState == TRUE)
            {
                PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckConditionForArrivalCarrierCancel", "dispatchState == TRUE");
                rc = RC_OK;
            
            }
            else
            {
                PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckConditionForArrivalCarrierCancel", "dispatchState != TRUE");
                SET_MSG_RC(strCassette_CheckConditionForArrivalCarrierCancel_out, MSG_NOT_DISPATCH_RESVED_CST, RC_NOT_DISPATCH_RESVED_CST);
                return(RC_NOT_DISPATCH_RESVED_CST);
                
            }
            
            /*----------------------------------*/
            /*   Get controlJobID of Cassette   */
            /*----------------------------------*/
            PosControlJob_var aControlJob;
            try
            {
                aControlJob = aCassette->getControlJob();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getControlJob);
            
            if ( CORBA::is_nil(aControlJob) != TRUE)
            {
                PPT_METHODTRACE_V1("PPTManager_i::cassette_CheckConditionForArrivalCarrierCancel", "CORBA::is_nil(aControlJob) != TRUE");
                SET_MSG_RC(strCassette_CheckConditionForArrivalCarrierCancel_out, MSG_CAST_CTRLJOBID_FILLED, RC_CAST_CTRLJOBID_FILLED);
                return(RC_CAST_CTRLJOBID_FILLED);
            }
        }
        
        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_CheckConditionForArrivalCarrierCancel");

        return( RC_OK );

    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_CheckConditionForArrivalCarrierCancel_out, cassette_CheckConditionForArrivalCarrierCancel, methodName)
}
