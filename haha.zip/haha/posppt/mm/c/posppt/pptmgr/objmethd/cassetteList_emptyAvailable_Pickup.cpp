#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassetteList_emptyAvailable_Pickup.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:30:55 [ 7/13/07 19:30:57 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassetteList_emptyAvailable_Pickup.cpp
//

#include "pptmgr.hpp"

#include "plcrc.hh"
#include "pmstat.hh"             //DCR 9900001
#include "prmsts.hh"             //DCR 9900001
#include "pe10st.hh"             //DCR 9900001
#include "plot.hh"
#include "pprsp.hh"
#include "pdp.hh"
#include "pdpgl.hh"
#include "pprmggl.hh"
#include "pmcrc.hh"
#include "pflwbch.hh"
#include "pperson.hh"
#include "pflwdp.hh"
#include "plot.hh"
#include "pcas.hh"
#include "pportrs.hh"
#include "pmcmggl.hh"
#include "pstmc.hh"
#include "ppcrs.hh"
#include "pbufrs.hh"
//D5000016 #include "ptrrs.hh"
#include "pmcnote.hh"
#include "pmc.hh"
//D5000016 #include "ppcjmg.hh"
//D5000016 #include "ppcgrp.hh"
#include "pdcdf.hh"
#include "ppcope.hh"
#include "ppcopsp.hh"
#include "ppcdf.hh"
//D6000044 #include "pdorv.hh"
//D5000016 #include "ppcj.hh"
#include "parea.hh"
#include "pbank.hh"
#include "ppcdrcp.hh"
#include "ppcflwx.hh"
#include "ppcflw.hh"
#include "prcssctv.hh"
#include "mtrllctn.hh"
#include "pevbase.hh"
#include "pevmggl.hh"

#include "pevmg.hh"
#include "pevbase.hh"
#include "pevalrm.hh"
#include "pevcmbs.hh"
#include "peveqps.hh"
#include "ppcdr.hh"

//#include "cimstate.hpp"
//[Object Function Name]: long   cassetteList_emptyAvailable_Pickup
//
//[Called by           ]: CassetteDeliveryReq()
//
// Date       Level    Author         Note
// ---------- -----    -------------  -------------------------------------------
// 1999-03-05 0.00     H.Ueda         Initial Release  (R20)
// 2000/09/12 P3000139 T.Yamano       SET_MSG_RC(MSG_OK,RC_OK) Comment Out
// 2000/11/24 D3000086 M.Mori         Transfer Reserve Check
// 2003/05/20 D5000016 K.Kido         Useless class deletion(R5.0).
// 2003/08/15 D5000194 K.Matsuei      ReRoute of Xfer is supported by CassetteDelivery.
// 2004/11/09 D6000044 F.Masada       Remove Document Component.
// 2006/05/10 P7000252 K.Matsuei      CassetteDelivery chooses EmptyCarrier with XferReserve, NPWReserve. And StartReserve fails.
// 2008/07/03 DSIV00000099 K.Matsuei  SLM(Small Lot Manufacturing) Support.
//
//[Function Description]:
//  Choose the data with the following conditions from the input pptCassetteListInqResult structure.
//  - emptyFlag is not False.
//  - cassetteStatus is Available or InUse.
//  - transferStatus is StationIn or BayIn or ManualIn.
//
//[Input Parameters]:
//  in  pptObjCommonIn   strObjCommonIn;                  // Tx, DateTime, User
//  in  sequence     <pptFoundCassette>  strFoundCassette;
//
//  *** NOTE ***
//  See SPCMNSTR.hpp for detail structure contents of pptFoundCassette.
//
//[Output Parameters]:
//
//  out objCassetteList_emptyAvailable_Pickup_out  strCassetteList_emptyAvailable_Pickup_out;
//
//  typedef struct objCassetteList_emptyAvailable_Pickup_out_struct {
//     pptRetCode    strResult;
//     pptFoundCassette  strFoundCassette;
//} objCassetteList_emptyAvailable_Pickup_out;
//
//*** NOTE ***
//See SPCMNSTR.hpp for detail structure contents of pptFoundCassette.
//
//[Return Value]:
//
//  Return Code               Message ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//  RC_NOT_FOUND_EMPTYCAST    MSG_NOT_FOUND_EMPTYCAST
//
//  Other return code will be set by the other function(s) called from this objectMethod.
//
//Pseudocode :
//
CORBA::Long PPTManager_i::cassetteList_emptyAvailable_Pickup(
                   objCassetteList_emptyAvailable_Pickup_out& strCassetteList_emptyAvailable_Pickup_out,
                   const pptObjCommonIn& strObjCommonIn,
                   const pptFoundCassetteSequence& strFoundCassette)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::cassetteList_emptyAvailable_Pickup");

        /*-----------------------------------------------------------------------*/
        /*   Initialize Flag.                                                    */
        /*-----------------------------------------------------------------------*/
        CORBA::Long rc = RC_OK;
//P3000139        SET_MSG_RC(strCassetteList_emptyAvailable_Pickup_out, MSG_OK, RC_OK) ;

        CORBA::Long i=0;
        CORBA::Long nOutputCasLen=0;
        CORBA::Long nFoundCasLen = strFoundCassette.length();
        CORBA::Boolean bEmptyCasFoundFlg = FALSE;

        for( i=0; i<nFoundCasLen; i++ )
        {
            PPT_METHODTRACE_V2("", "Select empty cassette from input cassette sequence.  Round", i ) ;

            /*--------------------------------------------------------------------*/
            /*   Data Condition Check                                             */
            /*--------------------------------------------------------------------*/
            if( !strFoundCassette[i].emptyFlag )
            {
                PPT_METHODTRACE_V1("", "Input cassette is not empty.") ;
                continue;
            }
            if( CIMFWStrCmp(strFoundCassette[i].cassetteStatus, CIMFW_Durable_Available) &&
                CIMFWStrCmp(strFoundCassette[i].cassetteStatus, CIMFW_Durable_InUse    ) )
            {
                PPT_METHODTRACE_V1("", "Input cassette is not 'Available' and not InUse.") ;
                continue;
            }

//D5000194 start
            CORBA::String_var reRouteXferFlag = CIMFWStrDup(getenv(SP_REROUTE_XFER_FLAG));
            PPT_METHODTRACE_V2("","SP_REROUTE_XFER_FLAG ---> ",reRouteXferFlag);

            if ( 0 == CIMFWStrCmp(reRouteXferFlag, "1") )
            {
                PPT_METHODTRACE_V1("","reRouteXferFlag is 1");

                if( CIMFWStrCmp(strFoundCassette[i].transferStatus, SP_TransState_StationIn) &&
                    CIMFWStrCmp(strFoundCassette[i].transferStatus, SP_TransState_BayIn)     &&
                    CIMFWStrCmp(strFoundCassette[i].transferStatus, SP_TransState_ManualIn)  &&
                    CIMFWStrCmp(strFoundCassette[i].transferStatus, SP_TransState_BayOut)  )
                {
                    PPT_METHODTRACE_V1("", "Input cassette is not [SI] [BI] [MI] [BO]") ;
                    continue;
                }
            }
            else
            {
//D5000194 end
                if( CIMFWStrCmp(strFoundCassette[i].transferStatus, SP_TransState_StationIn) &&
                    CIMFWStrCmp(strFoundCassette[i].transferStatus, SP_TransState_BayIn)     &&
                    CIMFWStrCmp(strFoundCassette[i].transferStatus, SP_TransState_ManualIn)  )
                {
                        PPT_METHODTRACE_V1("", "Input cassette is not [SI] [BI] [MI]") ;
                    continue;
                }
            }  //D5000194
// D3000086 add start
            objCassette_controlJobID_Get_out strCassette_controlJobID_Get_out;
            rc = cassette_controlJobID_Get( strCassette_controlJobID_Get_out,
                                            strObjCommonIn,
                                            strFoundCassette[i].cassetteID );

            PPT_METHODTRACE_V2("", "cassetteID", strFoundCassette[i].cassetteID.identifier ) ;

            if( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("", "<cassette_controlJobID_Get> failed.") ;
                strCassetteList_emptyAvailable_Pickup_out.strResult  = strCassette_controlJobID_Get_out.strResult ;
                return rc ;
            }

            if( CIMFWStrLen( strCassette_controlJobID_Get_out.controlJobID.identifier ) != 0 )
            {
                PPT_METHODTRACE_V1("", "Input cassette is not 'controlJobID is nil'") ;
                continue;
            }
// D3000086 add end

//P7000252 start
            PosCassette_var aCassette;
            PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette, strFoundCassette[i].cassetteID,
                                                   strCassetteList_emptyAvailable_Pickup_out,
                                                   cassetteList_emptyAvailable_Pickup );

            // Check XferReserve
            CORBA::Boolean transferReserved;
            try
            {
                transferReserved = aCassette->isReserved();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isReserved)

            if ( transferReserved != FALSE )
            {
                PPT_METHODTRACE_V1("", "Cassette has XferReservation");
                continue;
            }

            // Check NPWReserve
            CORBA::Boolean dispatchReserveFlag;
            try
            {
                dispatchReserveFlag = aCassette->isDispatchReserved();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isDispatchtReserved)

            if ( dispatchReserveFlag != FALSE )
            {
                PPT_METHODTRACE_V1("", "Cassette has DispatchReservation");
                continue;
            }
//P7000252 end

//DSIV00000099 start
            // Check SLM Reserve
            PosMachine_var aSLMReservedMachine;
            try
            {
                aSLMReservedMachine = aCassette->getSLMReservedMachine();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosCassette::getSLMReservedMachine);

            if ( !CORBA::is_nil(aSLMReservedMachine) )
            {
                PPT_METHODTRACE_V1("", "Cassette has SLM Reservation");
                continue;
            }
//DSIV00000099 end

            PPT_METHODTRACE_V1("", "Assign cassette as available empty cassette." ) ;

            strCassetteList_emptyAvailable_Pickup_out.strFoundCassette.length(nOutputCasLen+1);
            strCassetteList_emptyAvailable_Pickup_out.strFoundCassette[nOutputCasLen] = strFoundCassette[i];
            nOutputCasLen++;

            bEmptyCasFoundFlg = TRUE;
        }
        if( !bEmptyCasFoundFlg )
        {
            PPT_METHODTRACE_V1("", "Empty cassette was not found from input cassette sequence.") ;
            SET_MSG_RC(strCassetteList_emptyAvailable_Pickup_out, MSG_NOT_FOUND_EMPTYCAST, RC_NOT_FOUND_EMPTYCAST) ;
            return RC_NOT_FOUND_EMPTYCAST ;
        }
        PPT_METHODTRACE_EXIT("PPTManager_i::cassetteList_emptyAvailable_Pickup");
        return rc;
    }
    CATCH_GLOBAL_EXCEPTIONS(strCassetteList_emptyAvailable_Pickup_out, cassetteList_emptyAvailable_Pickup, methodName)
}
