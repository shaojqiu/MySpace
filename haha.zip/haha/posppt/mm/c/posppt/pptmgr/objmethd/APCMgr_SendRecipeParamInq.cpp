#ifndef lint
static char *sccsid =  "@(#) 1.4 superpos/src/spppt/source/posppt/pptmgr/objmethd/APCMgr_SendRecipeParamInq.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 2/5/08 20:34:59 [ 2/5/08 20:35:01 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: APCMgr_SendRecipeParamInq.cpp
//

#include "pptmgr.hpp"

#include "apcsm.hh"
#include "plot.hh"
#include "ppcdf.hh"
#include "ppcope.hh"
#include "pcas.hh"
//#include "apcif.hh"

//[Object Function Name]: long APCMgr_SendRecipeParamInq
//
// Date        Level       Author         Note
// ----------  ----------  -------------  ---------------------------------------------------------------------
// 2001/04/26  D4100014    K.Kido         Initial Release
// 2001/08/16  D4000093    M.Ameshita     Add logic to set route related information to pptStartCassette_struct.
// 2001/08/20  P4000099    K.Kido         Change filename
// 2001/09/03  D4000114    Y.Yamaguchi    Support marker for APC Server
// 2002/02/14  D4100134    C.Tsuchiya     Use getenv() instead of data member 'theSP_xxx'
// 2002/04/03  D4100133    K.Matsuei      Set _bind timeout logic.
// 2002/06/27  P4200022    K.Kimura       Fix Zero Fault Error (BFREE) 
// 2002/07/26  P4200074    K.Matsuei      Fix memory leak by externalServerList.
// 2002/12/25  D4200249    K.Matsuei      Detailed exception information is displayed in RTD.
// 2004/11/17  D6000025    K.Murakami     Change CORBA::string to CORBA::String
//                                        Add SP_STRING_TO_OBJECT for eBroker
// 2004/11/18  D6000025    K.Murakami     Change CORBA::IT_chooseDefaultEnv() to SP_CORBAENV_DEFENV
// 2004/11/24  D6000025    K.Murakami     Add SP_GET_OBJECT_WITH_ENV for eBroker
//                                        Add IMRegistry::orbPtr->object_to_string for eBroker
// 2008/01/17  D9000059    H.Hotta        External System Interface Security Control
//
// Date        Level         Author         Note
// ----------  ------------  -------------  -------------------------------------------
// 2011/10/13  DSN000022130  S.Kawabe       IOR Support
//
//[Function Description]:
//
//
//[Input Parameters]:
//  in  pptObjCommonIn&         strObjCommonIn
//  in  objectIdentifier        equipmentID
//  in  string                  portGroupID
//  in  objectIdentifier        controlJobID
//  in  pptStartCassetteSequence  strStartCassette
//[Output Parameters]:
//
//typedef struct objAPCMgr_SendRecipeParamInq_out_struct{
//      pptRetCode                  strResult;
//      pptStartCassetteSequence    strStartCassette;
//  } objAPCMgr_SendRecipeParamInq_Inq_out
//
//[Return Value]:
//
//  Return Code                  Messsage ID
//  ---------------------------- --------------------------------------------------
//  RC_OK                        MSG_OK
//
//
//[Pseudo Code]:
//
//P4000099CORBA::Long PPTManager_i::APC_AdjustedRecipeParameter_Inq(
//P4000099                                objAPC_AdjustedRecipeParameter_Inq_out& strAPC_AdjustedRecipeParameter_Inq_out,
//P4000099                                const pptObjCommonIn&                   strObjCommonIn,
//P4000099                                const objectIdentifier&                 equipmentID,
//P4000099                                const char *                            portGroupID,
//P4000099                                const objectIdentifier&                 controlJobID,
//P4000099//D4000093                      const pptStartCassetteSequence&         strStartCassette )
//P4000099                                const pptStartCassetteSequence&         strOrgStartCassette ) //D4000093
CORBA::Long PPTManager_i::APCMgr_SendRecipeParamInq(
                                objAPCMgr_SendRecipeParamInq_out& strAPCMgr_SendRecipeParamInq_out,
                                const pptObjCommonIn&                   strObjCommonIn,
                                const objectIdentifier&                 equipmentID,
                                const char *                            portGroupID,
                                const objectIdentifier&                 controlJobID,
                                const pptStartCassetteSequence&         strOrgStartCassette ) //P4000099
{
    char *methodName=NULL;
    try
    {
//P4000099        PPT_METHODTRACE_ENTRY("PPTManager_i::APC_AdjustedRecipeParameter_Inq");
        PPT_METHODTRACE_ENTRY("PPTManager_i::APCMgr_SendRecipeParamInq");                    //P4000099

        /*--------------------*/
        /*                    */
        /*     Initialize     */
        /*                    */
        /*--------------------*/
        CORBA::Long rc = RC_OK;

        //D4000093 Start -------------------
                                                                                                                                                   //D4000093
        /*-----------------------------------------------------------------------------------------*/                                              //D4000093
        /*     Set startOperationInfo                                                              */                                              //D4000093
        /*-----------------------------------------------------------------------------------------*/                                              //D4000093
        pptStartCassetteSequence strStartCassette;                                                                                                 //D4000093
        strStartCassette = strOrgStartCassette ;                                                                                                   //D4000093
                                                                                                                                                   //D4000093
        CORBA::Long scLen = strStartCassette.length();                                                                                             //D4000093
        PPT_METHODTRACE_V2("", "strStartCassette.length", scLen);                                                                                  //D4000093
                                                                                                                                                   //D4000093
        CORBA::Long i, j, k, l;                                                                                                                    //D4000093
                                                                                                                                                   //D4000093
        /*-------------------------------*/                                                                                                        //D4000093
        /*   Loop for strStartCassette   */                                                                                                        //D4000093
        /*-------------------------------*/                                                                                                        //D4000093
        for ( i=0; i < scLen; i++ )                                                                                                                //D4000093
        {                                                                                                                                          //D4000093
            PPT_METHODTRACE_V2("", "loop counter -----> [i]", i);                                                                                  //D4000093
                                                                                                                                                   //D4000093
            /*-------------------------------*/                                                                                                    //D4000093
            /*   Loop for strLotInCassette   */                                                                                                    //D4000093
            /*-------------------------------*/                                                                                                    //D4000093
            CORBA::Long lenLotInCassette = strStartCassette[i].strLotInCassette.length();                                                          //D4000093
            PPT_METHODTRACE_V3("", "strStartCassette[i].strLotInCassette.length", i, lenLotInCassette);                                            //D4000093
                                                                                                                                                   //D4000093
            for ( j=0; j < lenLotInCassette; j++ )                                                                                                 //D4000093
            {                                                                                                                                      //D4000093
                PPT_METHODTRACE_V2("", "loop counter -----> [j]", j);                                                                              //D4000093
                /*---------------------------*/                                                                                                    //D4000093
                /*   Omit Not-OpeStart Lot   */                                                                                                    //D4000093
                /*---------------------------*/                                                                                                    //D4000093
                if ( strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE )                                                         //D4000093
                {                                                                                                                                  //D4000093//D4000093
                    PPT_METHODTRACE_V1("", "strStartCassette[i].strLotInCassette[j].operationStartFlag == FALSE");                                 //D4000093
                    continue;                                                                                                                      //D4000093
                }                                                                                                                                  //D4000093
                                                                                                                                                   //D4000093
                /*--------------------*/                                                                                                           //D4000093
                /*   Get Lot ojbect   */                                                                                                           //D4000093
                /*--------------------*/                                                                                                           //D4000093
                PPT_METHODTRACE_V1("", "Get Lot ojbect");                                                                                          //D4000093
                PosLot_var aLot;                                                                                                                   //D4000093
                PPT_CONVERT_LOTID_TO_LOT_OR( aLot                                          ,                                                       //D4000093
                                             strStartCassette[i].strLotInCassette[j].lotID ,                                                       //D4000093
//P4000099                                   strAPC_AdjustedRecipeParameter_Inq_out         ,                                                      //D4000093
                                             strAPCMgr_SendRecipeParamInq_out               ,                                                      //P4000099
//P4000099                                   APC_AdjustedRecipeParameter_Inq                )                                                      //D4000093
                                             APCMgr_SendRecipeParamInq)                                                                            //P4000099
                                                                                                                                                   //D4000093
                /*----------------------------------------------------------------*/                                                               //D4000093
                /*   Set StartOperationInfo                                       */                                                               //D4000093
                /*                                                                */                                                               //D4000093
                /*   typedef struct pptStartOperationInfo_struct {                */                                                               //D4000093
                /*       objectIdentifier            routeID;                     */                                                               //D4000093
                /*       objectIdentifier            operationID;                 */                                                               //D4000093
                /*       string                      operationNumber;             */                                                               //D4000093
                /*       long                        passCount;                   */                                                               //D4000093
                /*       any siInfo;                                              */                                                               //D4000093
                /*   } pptStartOperationInfo;                                     */                                                               //D4000093
                /*                                                                */                                                               //D4000093
                /*----------------------------------------------------------------*/                                                               //D4000093
                ProcessOperation_var    aProcessOperation;                                                                                         //D4000093
                PosProcessOperation_var aPO;                                                                                                       //D4000093
                try                                                                                                                                //D4000093
                {                                                                                                                                  //D4000093
                    aProcessOperation = aLot->getProcessOperation();                                                                               //D4000093
                    aPO = PosProcessOperation::_narrow(aProcessOperation);                                                                         //D4000093//D4000093
                }                                                                                                                                  //D4000093
                CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProcessOperation)                                                                            //D4000093
                                                                                                                                                   //D4000093
                if ( ! CORBA::is_nil(aPO) )                                                                                                        //D4000093
                {                                                                                                                                  //D4000093
                    /*---------------------------------------------------------------*/                                                            //D4000093
                    /* Set     objectIdentifier            routeID;                  */                                                            //D4000093
                    /*---------------------------------------------------------------*/                                                            //D4000093
                    PPT_METHODTRACE_V1("", "aPO is not nil");                                                                                      //D4000093
                    PosProcessDefinition_var aMainPD;                                                                                              //D4000093
                    try                                                                                                                            //D4000093
                    {                                                                                                                              //D4000093
                        aMainPD = aLot->getMainProcessDefinition();                                                                                //D4000093
                    }                                                                                                                              //D4000093
                    CATCH_AND_RAISE_EXCEPTIONS(PosLot::getMainProcessDefinition)                                                                   //D4000093
                                                                                                                                                   //D4000093
                    if ( CORBA::is_nil(aMainPD) )                                                                                                  //D4000093
                    {                                                                                                                              //D4000093
                        PPT_METHODTRACE_V1("", "aMainPD is nil");                                                                                  //D4000093
//P4000099              PPT_SET_MSG_RC_KEY( strAPC_AdjustedRecipeParameter_Inq_out,                                                                //D4000093
                        PPT_SET_MSG_RC_KEY( strAPCMgr_SendRecipeParamInq_out,                                                                      //P4000099
                                            MSG_NOT_FOUND_ROUTE,                                                                                   //D4000093
                                            RC_NOT_FOUND_ROUTE,                                                                                    //D4000093
                                            "" );                                                                                                  //D4000093
                        return RC_NOT_FOUND_ROUTE;                                                                                                 //D4000093
                    }                                                                                                                              //D4000093
                                                                                                                                                   //D4000093
                    PPT_SET_OBJECT_IDENTIFIER( strStartCassette[i].strLotInCassette[j].strStartOperationInfo.routeID ,                             //D4000093
                                               aMainPD                                                               ,                             //D4000093
//P4000099                                     strAPC_AdjustedRecipeParameter_Inq_out                                ,                             //D4000093
                                               strAPCMgr_SendRecipeParamInq_out                                      ,                             //P4000099
                                               APCMgr_SendRecipeParamInq                                             ,                             //D4000093
                                               PosProcessDefinition )                                                                              //D4000093
                                                                                                                                                   //D4000093//D4000093
                    /*---------------------------------------------------------------*/                                                            //D4000093
                    /* Set     objectIdentifier            operationID;              */                                                            //D4000093
                    /*---------------------------------------------------------------*/                                                            //D4000093
                    PosProcessDefinition_var aPD;                                                                                                  //D4000093
                    try                                                                                                                            //D4000093
                    {                                                                                                                              //D4000093
                        aPD = aPO->getProcessDefinition();                                                                                         //D4000093
                    }                                                                                                                              //D4000093
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getProcessDefinition)                                                          //D4000093
                                                                                                                                                   //D4000093
                    if ( CORBA::is_nil(aPD) )                                                                                                      //D4000093
                    {                                                                                                                              //D4000093
                        PPT_METHODTRACE_V1("", "aPD is nil");                                                                                      //D4000093
//P4000099              PPT_SET_MSG_RC_KEY( strAPC_AdjustedRecipeParameter_Inq_out,                                                                //D4000093
                        PPT_SET_MSG_RC_KEY( strAPCMgr_SendRecipeParamInq_out,                                                                      //P4000099
                                            MSG_NOT_FOUND_PD,                                                                                      //D4000093
                                            RC_NOT_FOUND_PD,                                                                                       //D4000093
                                            "" );                                                                                                  //D4000093
                        return RC_NOT_FOUND_PD;                                                                                                    //D4000093
                    }                                                                                                                              //D4000093
                                                                                                                                                   //D4000093
                    PPT_SET_OBJECT_IDENTIFIER( strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationID ,                         //D4000093
                                               aPD                                                                       ,                         //D4000093
//P4000099                                     strAPC_AdjustedRecipeParameter_Inq_out                                    ,                         //D4000093
                                               strAPCMgr_SendRecipeParamInq_out                                          ,                         //P4000099
//P4000099                                     APC_AdjustedRecipeParameter_Inq                                           ,                         //D4000093
                                               APCMgr_SendRecipeParamInq                                                 ,                         //P4000099
                                               PosProcessDefinition                                                      )                         //D4000093
                                                                                                                                                   //D4000093
                    /*---------------------------------------------------------------*/                                                            //D4000093
                    /* Set     string                      operationNumber;          */                                                            //D4000093
                    /*---------------------------------------------------------------*/                                                            //D4000093
                    try                                                                                                                            //D4000093
                    {                                                                                                                              //D4000093
                        strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber = aLot->getOperationNumber();                //D4000093//D4000093//D4000093
                        PPT_METHODTRACE_V2("", "operationNumber", strStartCassette[i].strLotInCassette[j].strStartOperationInfo.operationNumber);  //D4000093
                    }                                                                                                                              //D4000093
                    CATCH_AND_RAISE_EXCEPTIONS(PosLot::getOperationNumber)                                                                         //D4000093
                                                                                                                                                   //D4000093
                    //----------------------------------------------------------------                                                             //D4000093
                    // Set     long                        passCount;                                                                              //D4000093
                    //----------------------------------------------------------------                                                             //D4000093
                    try                                                                                                                            //D4000093
                    {                                                                                                                              //D4000093
                        strStartCassette[i].strLotInCassette[j].strStartOperationInfo.passCount = aPO->getPassCount();                             //D4000093
                        PPT_METHODTRACE_V2("", "passCount", strStartCassette[i].strLotInCassette[j].strStartOperationInfo.passCount);              //D4000093
                    }                                                                                                                              //D4000093
                    CATCH_AND_RAISE_EXCEPTIONS(PosProcessOperation::getPassCount)                                                                  //D4000093
                }                                                                                                                                  //D4000093
            }                                                                                                                                      //D4000093
        }                                                                                                                                          //D4000093
        //D4000093 End ---------------------------------

#if 1

        APCServerManagerFactory_var anALF = APCServerManagerFactory::_nil();

        /*--------------------------------*/
        /*   Get APC Host & Server name   */
        /*--------------------------------*/
        PPT_METHODTRACE_V1("","/*--------------------------------*/");
        PPT_METHODTRACE_V1("","/*   Get APC Host & Server name   */");
        PPT_METHODTRACE_V1("","/*--------------------------------*/");

        APCServerManager_var APCSvrMgr = NULL;
        CORBA::String_var APCServerName;
        CORBA::String_var APCHostName;

        char scAPCServerName[512];

//D4100134        if ( strstr(theSP_APC_SERVER_NAME,":") == NULL )   //D4000114
        if ( strstr(getenv(SP_APC_SERVER_NAME),":") == NULL )        //D4100134
        {                                                            //D4000114
            CIMFWStrCpy(scAPCServerName,":");
//          CIMFWStrCat(scAPCServerName,getenv(SP_APC_SERVER_NAME));
//D4100134  CIMFWStrCat(scAPCServerName, theSP_APC_SERVER_NAME);
            CIMFWStrCat(scAPCServerName,getenv(SP_APC_SERVER_NAME)); //D4100134
        }                                                            //D4000114
        else                                                         //D4000114
        {                                                            //D4000114
//D4100134  CIMFWStrCpy(scAPCServerName, theSP_APC_SERVER_NAME);     //D4000114
            CIMFWStrCpy(scAPCServerName,getenv(SP_APC_SERVER_NAME)); //D4100134
        }                                                            //D4000114

        APCServerName = CIMFWStrDup(scAPCServerName);

        PPT_METHODTRACE_V2("", "APCServerName ---> ", APCServerName);

        char scAPCHostName[512];

//        CIMFWStrCpy(scAPCHostName,getenv(SP_APC_HOST_NAME));
//D4100134        CIMFWStrCpy(scAPCHostName, theSP_APC_HOST_NAME);
        CIMFWStrCpy(scAPCHostName,getenv(SP_APC_HOST_NAME));    //D4100134

        APCHostName = CIMFWStrDup(scAPCHostName);

        PPT_METHODTRACE_V2("", "APCHostName ---> ", APCHostName);

//        CORBA::String_var BindEverytimeFlg = getenv(SP_BindEverytime_APC);
//D4100134        CORBA::String_var BindEverytimeFlg = theSP_BindEverytime_APC;
//P4200022        CORBA::String_var BindEverytimeFlg = getenv(SP_BindEverytime_APC);    //D4100134
        CORBA::String_var BindEverytimeFlg = CIMFWStrDup(getenv(SP_BindEverytime_APC)); //P4200022
        PPT_METHODTRACE_V2("","BindEverytimeFlg ---> ",BindEverytimeFlg);

        CORBA::Boolean bExecBind = FALSE;

        if ( 0 == CIMFWStrCmp(BindEverytimeFlg, "1") )
        {
            /*--------------------*/
            /*   Everytime Bind   */
            /*--------------------*/
            PPT_METHODTRACE_V1("","/*--------------------*/");
            PPT_METHODTRACE_V1("","/*   Everytime Bind   */");
            PPT_METHODTRACE_V1("","/*--------------------*/");
        }

        if (FALSE == bExecBind)
        {
            /*----------------------------*/
            /*   Search Service Manager   */
            /*----------------------------*/
            PPT_METHODTRACE_V1("","/*----------------------------*/");
            PPT_METHODTRACE_V1("","/*   Search Service Manager   */");
            PPT_METHODTRACE_V1("","/*----------------------------*/");

            CORBA::Boolean existFlag = FALSE;
            //D6000025char* objRef = CORBA::string(NULL);
            char* objRef = CORBA::String(NULL); //D6000025

            try
            {
                existFlag = externalServerList.find((char*)APCServerName, objRef);
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "externalServerList.find() raises exception");
                SET_MSG_RC(strAPCMgr_SendRecipeParamInq_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
                return (RC_SYSTEM_ERROR);
            }
            if ( existFlag == TRUE )
            {
                PPT_METHODTRACE_V1("", "existFlag == TRUE...");
                CORBA::Object_var tmpAPC = CORBA::Object::_nil();
                try
                {
#ifdef EBROKER         //D6000025
                    tmpAPC = SP_STRING_TO_OBJECT(objRef);     //D6000025
#else                  //D6000025
                    tmpAPC = CORBA::Orbix.string_to_object(objRef);
#endif                 //D6000025
                }
                catch(...)
                {
                    PPT_METHODTRACE_V1("", "CORBA::Orbix.string_to_object() raises exception");
//P4000099          PPT_SET_MSG_RC_KEY(strAPC_AdjustedRecipeParameter_Inq_out, MSG_EXT_SERVER_BIND_FAIL_ETC, RC_EXT_SERVER_BIND_FAIL_ETC, "APC");
                    PPT_SET_MSG_RC_KEY(strAPCMgr_SendRecipeParamInq_out, MSG_EXT_SERVER_BIND_FAIL_ETC, RC_EXT_SERVER_BIND_FAIL_ETC, "APC");          //P4000099
                    try
                    {
                        externalServerList.remove((char *)APCServerName);
                    }
                    catch( ... )
                    {
                        PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                    }
                    return(RC_EXT_SERVER_BIND_FAIL_ETC);
                }
                if (CORBA::is_nil(tmpAPC) == TRUE)
                {
                    PPT_METHODTRACE_V1("", "CORBA::is_nil(tmpAPC) == TRUE");
//P4000099          SET_MSG_RC(strAPC_AdjustedRecipeParameter_Inq_out, MSG_EXT_SERVER_NIL_OBJ, RC_EXT_SERVER_NIL_OBJ);
                    SET_MSG_RC(strAPCMgr_SendRecipeParamInq_out, MSG_EXT_SERVER_NIL_OBJ, RC_EXT_SERVER_NIL_OBJ);                                     //P4000099
                    try
                    {
                        externalServerList.remove((char *)APCServerName);
                    }
                    catch( ... )
                    {
                        PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                    }
                    return(RC_EXT_SERVER_NIL_OBJ);
                }
//                 APCSvrMgr = ApcServerManager::_narrow(tmpAPC);
                anALF = APCServerManagerFactory::_narrow(tmpAPC);
            }
            else
            {
                bExecBind = TRUE;
            }
        }

//D4100133 start
        //D6000025CORBA::Environment envTimeOut = CORBA::IT_chooseDefaultEnv();
        CORBA::Environment envTimeOut = SP_CORBAENV_DEFENV;    //D6000025
        CORBA::String_var timeOutValue = CIMFWStrDup(getenv(SP_TX_Timeout_APC));
        PPT_METHODTRACE_V2("","timeOutValue ---> ",timeOutValue);

        if ( 0 < CIMFWStrLen(timeOutValue) )
        {
            PPT_METHODTRACE_V1("", "setting timeout!!");
            envTimeOut.timeout(atol(timeOutValue) * 1000);
        }
//D4100133 end

        if ( TRUE == bExecBind )
        {
            /*--------------------------*/
            /*   Bind Service Manager   */
            /*--------------------------*/
            PPT_METHODTRACE_V1("","/*--------------------------*/");
            PPT_METHODTRACE_V1("","/*   Bind Service Manager   */");
            PPT_METHODTRACE_V1("","/*--------------------------*/");

            CORBA::String_var newObjRef;

            try
            {
//                APCSvrMgr = ApcServerManager::_bind( APCServerName, APCHostName );
//D4100133                anALF = APCServerManagerFactory::_bind( APCServerName, APCHostName );
#ifdef EBROKER                                                                                                    //D6000025
                CORBA::String_var APCIOR = CIMFWStrDup(getenv("APC_IOR"));                              //DSN000022130
                if( CIMFWStrLen(APCIOR) == 0 )                                                          //DSN000022130
                {                                                                                       //DSN000022130
                    PPT_METHODTRACE_V1("", "APC_IOR is not setting.");                                  //DSN000022130
                    SP_GET_OBJECT_WITH_ENV(anALF, APCServerName, APCHostName, APCServerManagerFactory, envTimeOut);   //D6000025
                }                                                                                       //DSN000022130
                else                                                                                    //DSN000022130
                {                                                                                       //DSN000022130
                    PPT_METHODTRACE_V1("", "APC_IOR is setting.");                                      //DSN000022130
                    SP_GET_OBJECT_FOR_IOR_WITH_ENV(anALF, APCIOR, APCServerManagerFactory, envTimeOut); //DSN000022130
                }                                                                                       //DSN000022130
#else                                                                                                             //D6000025
                anALF = APCServerManagerFactory::_bind( APCServerName, APCHostName, envTimeOut );   //D4100133
#endif                                                                                                            //D6000025
            }
            catch(const CORBA::SystemException &SysEx)
            {
                PPT_METHODTRACE_V1("", "APCServerManager::_bind() raises system exception");
                APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
                PPT_SET_MSG_RC_KEY(strAPCMgr_SendRecipeParamInq_out, MSG_EXT_SERVER_BIND_FAIL_ETC, RC_EXT_SERVER_BIND_FAIL_ETC, "APC");
                return(RC_EXT_SERVER_BIND_FAIL_ETC);
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "APCServerManager::_bind() raises unknown exception");
                APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ();
//P4000099      PPT_SET_MSG_RC_KEY(strAPC_AdjustedRecipeParameter_Inq_out, MSG_EXT_SERVER_BIND_FAIL_ETC, RC_EXT_SERVER_BIND_FAIL_ETC, "APC");
                PPT_SET_MSG_RC_KEY(strAPCMgr_SendRecipeParamInq_out, MSG_EXT_SERVER_BIND_FAIL_ETC, RC_EXT_SERVER_BIND_FAIL_ETC, "APC");         //P4000099
                return(RC_EXT_SERVER_BIND_FAIL_ETC);
            }
            if (CORBA::is_nil(anALF) == TRUE)
            {
                PPT_METHODTRACE_V1("", "CORBA::is_nil(APCSvrMgr) == TRUE");
//P4000099      SET_MSG_RC(strAPC_AdjustedRecipeParameter_Inq_out, MSG_EXT_SERVER_NIL_OBJ, RC_EXT_SERVER_NIL_OBJ);
                SET_MSG_RC(strAPCMgr_SendRecipeParamInq_out, MSG_EXT_SERVER_NIL_OBJ, RC_EXT_SERVER_NIL_OBJ);                                    //P4000099
                return(RC_EXT_SERVER_NIL_OBJ);
            }
            try
            {
#ifdef EBROKER                                                            //D6000025
                newObjRef = IMRegistry::orbPtr->object_to_string(anALF);  //D6000025 
#else                                                                     //D6000025
                newObjRef = anALF->_object_to_string();
#endif                                                                    //D6000025 
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "anALF->_object_to_string() raises exception");
//P4000099      SET_MSG_RC(strAPC_AdjustedRecipeParameter_Inq_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
                SET_MSG_RC(strAPCMgr_SendRecipeParamInq_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);                                                //P4000099
                return(RC_SYSTEM_ERROR);
            }
            try
            {
                //P4200074 start
                PPT_METHODTRACE_V1("", "externalServerList.remove()");
                try
                {
                    externalServerList.remove((char *)APCServerName);
                }
                catch( ... )
                {
                    PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
                }
                //P4200074 end

//P4200074 The following comments are mistakes.
//P4200074 It does not MemoryLeak, if it remove same member after adding.
//P4200074
//P4200074                //About 2nd parameter, CIMFWStrDup(newObjRef) makes memory-leak, but it will be
//P4200074                //happened when stopping mmserver, so CIMFWStrDup(newObjRef) can be used.
//P4200074                //When 1st and 2nd parameters are same valiable case, CIMFWStrDup should not be
//P4200074                //used for 2nd parameter.
                externalServerList.add(CIMFWStrDup(APCServerName), CIMFWStrDup(newObjRef));
            }
            catch(...)
            {
                PPT_METHODTRACE_V1("", "externalServerList.add() raises exception");
//P4000099      SET_MSG_RC(strAPC_AdjustedRecipeParameter_Inq_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);
                SET_MSG_RC(strAPCMgr_SendRecipeParamInq_out, MSG_SYSTEM_ERROR, RC_SYSTEM_ERROR);                                                //P4000099
                return(RC_SYSTEM_ERROR);
            }
        }

        /*--------------------------------*/
        /*   get Service Manager Object   */
        /*--------------------------------*/
        PPT_METHODTRACE_V1("","/*--------------------------------*/");
        PPT_METHODTRACE_V1("","/*   get Service Manager Object   */");
        PPT_METHODTRACE_V1("","/*--------------------------------*/");

//D4100133        CORBA::Environment envTimeOut = CORBA::IT_chooseDefaultEnv();
//D4100133
//D4100133//D4100134        PPT_METHODTRACE_V2("","theSP_TX_Timeout_APC = ",theSP_TX_Timeout_APC);
//D4100133//D4100134        CORBA::String_var timeOutValue = theSP_TX_Timeout_APC;
//D4100133        CORBA::String_var timeOutValue = CIMFWStrDup(getenv(SP_TX_Timeout_APC));    //D4100134
//D4100133
//D4100133        PPT_METHODTRACE_V2("","timeOutValue ---> ",timeOutValue);
//D4100133
//D4100133        if ( 0 < CIMFWStrLen(timeOutValue) )
//D4100133        {
//D4100133            PPT_METHODTRACE_V1("", "setting timeout!!");
//D4100133            envTimeOut.timeout(atol(timeOutValue) * 1000);
//D4100133        }

        try
        {
            APCSvrMgr = anALF->createAPCServerManager( envTimeOut );

            PPT_METHODTRACE_V1("", "end anALF->createAPCServerManager");
        }
        catch(const CORBA::SystemException &SysEx)
        {
            PPT_METHODTRACE_V1("", "anALF->createAPCServerManager() raises system exception");
            APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
            SET_MSG_RC(strAPCMgr_SendRecipeParamInq_out, MSG_NO_RESPONSE_APC, RC_NO_RESPONSE_APC);
            try
            {
                PPT_METHODTRACE_V1("","externalServerList.remove");
                externalServerList.remove((char *)APCServerName);
            }
            catch( ... )
            {
                PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
            }
            return(RC_NO_RESPONSE_APC);
        }
        catch(...)
        {
            PPT_METHODTRACE_V1("", "anALF->createAPCServerManager() raises unknown exception");
            APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ();
            SET_MSG_RC(strAPCMgr_SendRecipeParamInq_out, MSG_NO_RESPONSE_APC, RC_NO_RESPONSE_APC);
            try
            {
                PPT_METHODTRACE_V1("","externalServerList.remove");
                externalServerList.remove((char *)APCServerName);
            }
            catch( ... )
            {
                PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
            }
            return(RC_NO_RESPONSE_APC);
        }
        if (CORBA::is_nil(APCSvrMgr) == TRUE)
        {
            PPT_METHODTRACE_V1("", "CORBA::is_nil(APCSvrMgr) == TRUE");
            SET_MSG_RC(strAPCMgr_SendRecipeParamInq_out, MSG_EXT_SERVER_NIL_OBJ, RC_EXT_SERVER_NIL_OBJ);
            try
            {
                PPT_METHODTRACE_V1("","externalServerList.remove");
                externalServerList.remove((char *)APCServerName);
            }
            catch( ... )
            {
                PPT_METHODTRACE_V1("", "externalServerList.remove() raises exception");
            }
            return(RC_EXT_SERVER_NIL_OBJ);
        }

        /*---------------------*/
        /*   Setting TimeOut   */
        /*---------------------*/
//        envTimeOut = CORBA::IT_chooseDefaultEnv();
//        envTimeOut.timeout( timeout * 1000 );

        /*--------------------------*/
        /*   befor adjust Log       */
        /*--------------------------*/
        PPT_METHODTRACE_V1("","/*--------------------------*/");
        PPT_METHODTRACE_V1("","/*      before adjust       */");
        PPT_METHODTRACE_V1("","/*--------------------------*/");
        PPT_METHODTRACE_V1("","###############ChangeRecipeParam before adjust...#################");
        CORBA::Long lenCassette = strStartCassette.length();
        for (i = 0 ; i < lenCassette ; i++)
        {
            CORBA::Long lenLot = strStartCassette[i].strLotInCassette.length();
            for (j = 0 ; j < lenLot ; j++)
            {
                CORBA::Long lenWafer = strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                for (k = 0 ; k < lenWafer ; k++)
                {
                    CORBA::Long lenRecipeParameter = strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length();
                    for (l = 0 ; l < lenRecipeParameter ; l++)
                    {
                        PPT_METHODTRACE_V1("","###########################################################");
                        PPT_METHODTRACE_V2("","before ParameterName              =",strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterName);
                        PPT_METHODTRACE_V2("","before RecipeParameter            =",strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterValue);
                        PPT_METHODTRACE_V2("","before targetValue                =",strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].targetValue);
                        PPT_METHODTRACE_V2("","before useCurrentSettingValueFlag =",strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].useCurrentSettingValueFlag);
                    }
                }
            }
        }
        PPT_METHODTRACE_V1("","###########################################################");

        /*----------------------------*/
        /*   Call TxRecipeParamInq    */
        /*----------------------------*/
        adjustedRecipeParamResult_var strAdjustedParam;

//D9000059 add start
        // External System Interface Security Control
        pptUser tmpRequestUser = strObjCommonIn.strUser;

        CORBA::String_var configFlag = CIMFWStrDup( getenv(SP_USER_ID_PASSWORD_CONFIGRATION) );
        PPT_METHODTRACE_V2("","SP_USER_ID_PASSWORD_CONFIGRATION ", configFlag);

        if( 0 == CIMFWStrCmp( configFlag, "1" ) )
        {
            PPT_METHODTRACE_V1("","SP_USER_ID_PASSWORD_CONFIGRATION=1");

            tmpRequestUser.userID.identifier = CIMFWStrDup( getenv(SP_APC_USER_ID) );
            tmpRequestUser.password          = CIMFWStrDup( getenv(SP_APC_USER_PASSWORD) );
        }

        PPT_METHODTRACE_V2("","userID   ", tmpRequestUser.userID.identifier);
        PPT_METHODTRACE_V2("","password ", tmpRequestUser.password);
//D9000059 add end

        try
        {
            PPT_METHODTRACE_V1("", "@@@@@@@@@@ call [start] APCSvrMgr->TxRecipeParamInq @@@@@@@@@@");
            strAdjustedParam = APCSvrMgr->TxRecipeParamInq(
//D9000059                                                strObjCommonIn.strUser,
                                                tmpRequestUser,           //D9000059
                                                equipmentID.identifier,
                                                portGroupID,
                                                controlJobID.identifier,
                                                strStartCassette,
                                                envTimeOut);
            PPT_METHODTRACE_V1("", "@@@@@@@@@@ call [ end ] APCSvrMgr->TxRecipeParamInq @@@@@@@@@@");
        }
//D4200249 start
        catch ( const CORBA::SystemException &SysEx )
        {
            PPT_METHODTRACE_V1("", "##### CORBA::SystemException caught");
            APPERRLOG_SYSTEMEXCEPTION_FOR_PUREOBJ(SysEx);
            SET_MSG_RC(strAPCMgr_SendRecipeParamInq_out, MSG_NO_RESPONSE_APC, RC_NO_RESPONSE_APC);
            try
            {
                externalServerList.remove((char *)APCServerName);
            }
            catch( ... )
            {
                PPT_METHODTRACE_V1("#######################################", "externalServerList.remove() raises exception");
            }
            return( RC_NO_RESPONSE_APC );
        }
//D4200249 end
        catch( ... )
        {
            PPT_METHODTRACE_V1("", "method call error by catch(...)" )
            APPERRLOG_UNKNOWNEXCEPTION_FOR_PUREOBJ();  //D4200249
//P4000099  SET_MSG_RC(strAPC_AdjustedRecipeParameter_Inq_out, MSG_NO_RESPONSE_APC, RC_NO_RESPONSE_APC);
            SET_MSG_RC(strAPCMgr_SendRecipeParamInq_out, MSG_NO_RESPONSE_APC, RC_NO_RESPONSE_APC);                    //P4000099
            try
            {
                externalServerList.remove((char *)APCServerName);
            }
            catch( ... )
            {
                PPT_METHODTRACE_V1("#######################################", "externalServerList.remove() raises exception");
            }
            return( RC_NO_RESPONSE_APC );
        }

//P4000099        strAPC_AdjustedRecipeParameter_Inq_out.strStartCassette = strAdjustedParam->strStartCassette;
        strAPCMgr_SendRecipeParamInq_out.strStartCassette = strAdjustedParam->strStartCassette;                        //P4000099

        /*--------------------------*/
        /*       Result Log         */
        /*--------------------------*/
        PPT_METHODTRACE_V1("","/*--------------------------*/");
        PPT_METHODTRACE_V1("","/*       Result Log         */");
        PPT_METHODTRACE_V1("","/*--------------------------*/");
        PPT_METHODTRACE_V1("","###############ChangeRecipeParam Result...#################");
        lenCassette = strAPCMgr_SendRecipeParamInq_out.strStartCassette.length();
        for (i = 0 ; i < lenCassette ; i++)
        {
            CORBA::Long lenLot = strAPCMgr_SendRecipeParamInq_out.strStartCassette[i].strLotInCassette.length();
            for (j = 0 ; j < lenLot ; j++)
            {
                CORBA::Long lenWafer = strAPCMgr_SendRecipeParamInq_out.strStartCassette[i].strLotInCassette[j].strLotWafer.length();
                for (k = 0 ; k < lenWafer ; k++)
                {
                    CORBA::Long lenRecipeParameter = strAPCMgr_SendRecipeParamInq_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter.length();
                    for (l = 0 ; l < lenRecipeParameter ; l++)
                    {
                        PPT_METHODTRACE_V1("","###########################################################");
                        PPT_METHODTRACE_V2("","After ParameterName              =",strAPCMgr_SendRecipeParamInq_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterName);
                        PPT_METHODTRACE_V2("","After RecipeParameter            =",strAPCMgr_SendRecipeParamInq_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].parameterValue);
                        PPT_METHODTRACE_V2("","After targetValue                =",strAPCMgr_SendRecipeParamInq_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].targetValue);
                        PPT_METHODTRACE_V2("","After useCurrentSettingValueFlag =",strAPCMgr_SendRecipeParamInq_out.strStartCassette[i].strLotInCassette[j].strLotWafer[k].strStartRecipeParameter[l].useCurrentSettingValueFlag);
                    }
                }
            }
        }
        PPT_METHODTRACE_V1("","###########################################################");

        /*----------------------------*/
        /*   Return to Caller         */
        /*----------------------------*/
#endif
    }
//P4000099    CATCH_GLOBAL_EXCEPTIONS(strAPC_AdjustedRecipeParameter_Inq_out, APC_AdjustedRecipeParameter_Inq, methodName)
    CATCH_GLOBAL_EXCEPTIONS(strAPCMgr_SendRecipeParamInq_out, APCMgr_SendRecipeParamInq, methodName)                           //P4000099

    PPT_METHODTRACE_EXIT("PPTManager_i::APCMgr_SendRecipeParamInq");

    return RC_OK;
}

