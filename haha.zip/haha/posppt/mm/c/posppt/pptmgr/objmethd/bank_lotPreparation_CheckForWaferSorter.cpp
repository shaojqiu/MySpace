#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/bank_lotPreparation_CheckForWaferSorter.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:30:05 [ 7/13/07 19:30:06 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: bank_lotPreparation_CheckForWaferSorter.cpp
//

#include "pptmgr.hpp"

#include "ppcope.hh"
#include "plot.hh"
#include "pbank.hh"
#include "ppcopsp.hh"
#include "pprsp.hh"
#include "pwafer.hh"
#include "pcas.hh"


//[Object Function Name]: long   bank_lotPreparation_CheckForWaferSorter
//
// Date        Level       Author         Note
// ----------  ----------  -------------  -------------------------------------------
// 2000/09/03  D4000056    M.Shimizu      The first coding (WaferSorter R40 CORE) 
// 2002/04/03  P4100313    K.Kimura       "cout" is changed into Method Trace
// 2004/01/15  P5100093    H.Adachi       Fix Source Production Check does not work.
//
//[Function Description]
//  * Check preparation lot type and Bank property combination
//  * Check source lot's hold state (might not be ONHOLD)
//  * Check source lot's inventory state (might be InBank)
//  * Check source lot's lot type (might be 'Vendor lot')
//  * Check source lot's bank ID (might be the same as input bank ID)
//  * Check source lot's product specification ID.
//    (all source lots' product ID must be the same)
//  * Check source wafer is allocated for STB or not
//  * Check carrier has control job or not
//  * Check carrier is on equipment or not
//  * For WaferSorter
//
//[Input Parameters]:
//  in  pptObjCommonIn          strObjCommonIn;
//  in  objectIdentifier        bankID;
//  in  string                  lotType;
//  in  string                  subLotType;
//  in  pptNewLotAttributes     strNewLotAttributes,
//
//[Output Parameters]:
//
//  out objBank_lotPreparation_CheckForWaferSorter_out  strBank_lotPreparation_CheckForWaferSorter_out;
//
//  typedef struct objBank_lotPreparation_CheckForWaferSorter_out_struct {
//     pptRetCode         strResult;
//  } objBank_lotPreparation_CheckForWaferSorter_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  -------------------------   --------------------------------------------------
//
//[Pseudo Code]:
//

CORBA::Long PPTManager_i::bank_lotPreparation_CheckForWaferSorter(
                            objBank_lotPreparation_CheckForWaferSorter_out& strBank_lotPreparation_CheckForWaferSorter_out,
                            const pptObjCommonIn& strObjCommonIn,
                            const objectIdentifier& bankID,
                            const char* lotType,
                            const char* subLotType,
                            const pptNewLotAttributes& strNewLotAttributes )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::bank_lotPreparation_CheckForWaferSorter");

        //------------------------------------------
        // Get Object reference of PosBank
        //------------------------------------------
        PPT_METHODTRACE_V1("","Get Object reference of PosBank");

        PosBank_var aBank;
        PPT_CONVERT_BANKID_TO_BANK_OR( aBank,
                                       bankID,
                                       strBank_lotPreparation_CheckForWaferSorter_out,
                                       bank_lotPreparation_CheckForWaferSorter );

        //------------------------------------------
        // Check Reqest type for generating lot
        //------------------------------------------
        PPT_METHODTRACE_V1("","Check Reqest type for generating lot");

        if ( 0 == CIMFWStrCmp(lotType, SP_Lot_Type_ProductionLot)
          || 0 == CIMFWStrCmp(lotType, SP_Lot_Type_EngineeringLot)
          || 0 == CIMFWStrCmp(lotType, SP_Lot_Type_VendorLot) )
        {
            PPT_METHODTRACE_V1("","lotType == SP_Lot_Type_ProductionLot or SP_Lot_Type_EngineeringLot or SP_Lot_Type_VendorLot");

            CORBA::Boolean bPrdBank;
            try
            {
                bPrdBank = aBank->isProductionBank();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosBank::isProductionBank)

            if ( bPrdBank == FALSE )
            {
                PPT_METHODTRACE_V1("","bPrdBank == FALSE");
                PPT_SET_MSG_RC_KEY2( strBank_lotPreparation_CheckForWaferSorter_out,
                                     MSG_INVALID_BANK_DATA,
                                     RC_INVALID_BANK_DATA,
                                     "",
                                     bankID.identifier );

                return RC_INVALID_BANK_DATA;
            }
        }
        else if ( 0 == CIMFWStrCmp(lotType, SP_Lot_Type_ProductionMonitorLot)
               || 0 == CIMFWStrCmp(lotType, SP_Lot_Type_EquipmentMonitorLot)
               || 0 == CIMFWStrCmp(lotType, SP_Lot_Type_DummyLot)
               || 0 == CIMFWStrCmp(lotType, SP_Lot_Type_RecycleLot) )
        {
            PPT_METHODTRACE_V1("","lotType = SP_Lot_Type_ProductionMonitorLot or SP_Lot_Type_EquipmentMonitorLot or SP_Lot_Type_DummyLot or SP_Lot_Type_RecycleLot");

            CORBA::Boolean bCtrlWaferBank;
            try
            {
                bCtrlWaferBank = aBank->isControlWaferBank();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosBank::isControlWaferBank)

            if ( bCtrlWaferBank == FALSE )
            {
                PPT_METHODTRACE_V1("","bCtrlWaferBank == FALSE");
                PPT_SET_MSG_RC_KEY2( strBank_lotPreparation_CheckForWaferSorter_out,
                                     MSG_INVALID_BANK_DATA,
                                     RC_INVALID_BANK_DATA,
                                     "",
                                     bankID.identifier );

                return RC_INVALID_BANK_DATA;
            }
        }
        else
        {
            PPT_METHODTRACE_V1("","Else!!");
            SET_MSG_RC( strBank_lotPreparation_CheckForWaferSorter_out,
                        MSG_INVALID_INPUT_PARM,
                        RC_INVALID_INPUT_PARM );

            return RC_INVALID_INPUT_PARM;
        }

        //------------------------------------------
        // Check source lot condition
        //------------------------------------------
        PPT_METHODTRACE_V1("","Check source lot condition");

        CORBA::Long nSourceWaferlen = 0;
//P5100093        CORBA::String strSourceLotProduct;
        CORBA::String_var    strSourceLotProduct;        //P5100093
        PosProductSpecification_var aPosProdSpec;
        CORBA::Long i;
        CORBA::Long lenLotAttr = strNewLotAttributes.strNewWaferAttributes.length();

//P5100093        strSourceLotProduct = NULL;

        for ( i=0; i < lenLotAttr; i++ )
        {
            if ( i > 0 )
            {
                PPT_METHODTRACE_V2("","Check source lot condition. Round", i);

                if ( 0 == CIMFWStrCmp(strNewLotAttributes.strNewWaferAttributes[i].sourceLotID.identifier,
                                      strNewLotAttributes.strNewWaferAttributes[i-1].sourceLotID.identifier) )
                {
                    continue;
                }
            }

            PosLot_var aPosLot;
            PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot,
                                         strNewLotAttributes.strNewWaferAttributes[i].sourceLotID,
                                         strBank_lotPreparation_CheckForWaferSorter_out,
                                         bank_lotPreparation_CheckForWaferSorter );

            CORBA::String_var strlotID;
            try
            {
                strlotID = aPosLot->getIdentifier();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getIdentifier)

            //------------------------------------------
            // Check source lot Hold Status
            //------------------------------------------
            PPT_METHODTRACE_V1("","Check source lot Hold Status");

            CORBA::String_var strLotHoldState;
            try
            {
                strLotHoldState = aPosLot->getLotHoldState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotHoldState)

            if ( 0 == CIMFWStrCmp(strLotHoldState, CIMFW_Lot_HoldState_OnHold) )
            {
                PPT_METHODTRACE_V1("","strLotHoldState == CIMFW_Lot_HoldState_OnHold");
                PPT_SET_MSG_RC_KEY2( strBank_lotPreparation_CheckForWaferSorter_out,
                                     MSG_INVALID_LOT_HOLDSTAT,
                                     RC_INVALID_LOT_HOLDSTAT,
                                     strlotID,
                                     strLotHoldState );

                return RC_INVALID_LOT_HOLDSTAT;
            }

            //------------------------------------------
            // Check source lot Inventory Status
            //------------------------------------------
            PPT_METHODTRACE_V1("","Check source lot Inventory Status");

            CORBA::String_var strLotInventoryState;
            try
            {
                strLotInventoryState = aPosLot->getLotInventoryState();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotInventoryState)

            if ( 0 != CIMFWStrCmp(strLotInventoryState, SP_Lot_InventoryState_InBank) )
            {
                PPT_METHODTRACE_V1("","strLotInventoryState == SP_Lot_InventoryState_InBank");
                PPT_SET_MSG_RC_KEY2( strBank_lotPreparation_CheckForWaferSorter_out,
                                     MSG_INVALID_LOT_INVENTORYSTAT,
                                     RC_INVALID_LOT_INVENTORYSTAT,
                                     strlotID,
                                     strLotInventoryState );

                return RC_INVALID_LOT_INVENTORYSTAT;
            }

            //------------------------------------------
            // Check source lot Type
            //------------------------------------------
            PPT_METHODTRACE_V1("","Check source lot Type");

            CORBA::String_var strLotType;
            try
            {
                strLotType = aPosLot->getLotType();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotType)

            if ( 0 != CIMFWStrCmp(strLotType, SP_Lot_Type_VendorLot) )
            {
                PPT_METHODTRACE_V1("","strLotType == SP_Lot_Type_VendorLot");
                PPT_SET_MSG_RC_KEY2( strBank_lotPreparation_CheckForWaferSorter_out,
                                     MSG_INVALID_LOT_TYPE,
                                     RC_INVALID_LOT_TYPE,
                                     strLotType,
                                     strlotID );

                return RC_INVALID_LOT_TYPE;
            }

            //------------------------------------------
            // Check source lot bank
            //------------------------------------------
            PPT_METHODTRACE_V1("","Check source lot bank");

            PosBank_var aPosBank;
            try
            {
                aPosBank = aPosLot->getBank();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getBank)

//Q3000124 start
            if(CORBA::is_nil(aPosBank))
            {
                PPT_SET_MSG_RC_KEY( strBank_lotPreparation_CheckForWaferSorter_out,
                                    MSG_NOT_FOUND_BANK,
                                    RC_NOT_FOUND_BANK, "" );
                return RC_NOT_FOUND_BANK ;
            }
//Q3000124 end

            CORBA::String_var strLotBankID;
            try
            {
                strLotBankID = aPosBank->getIdentifier();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosBank::getIdentifier)

            if ( 0 != CIMFWStrCmp(strLotBankID, bankID.identifier) )
            {
                PPT_METHODTRACE_V1("","strLotBankID = bankID.identifier");
                PPT_SET_MSG_RC_KEY2( strBank_lotPreparation_CheckForWaferSorter_out,
                                     MSG_LOT_BANK_DIFFERENT,
                                     RC_LOT_BANK_DIFFERENT,
                                     strLotBankID,
                                     bankID.identifier );

                return RC_INVALID_LOT_INVENTORYSTAT;                                 
            }

            //------------------------------------------
            // Check source lot Product Spec
            //------------------------------------------
            PPT_METHODTRACE_V1("","Check source lot Product Spec");

            ProductSpecification_var aProductSpec;
            PosProductSpecification_var aPosProdSpec;
            try
            {
                aProductSpec = aPosLot->getProductSpecification();
                aPosProdSpec = PosProductSpecification::_narrow(aProductSpec);
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosLot::getProductSpecification);

//Q3000124 start
            if ( CORBA::is_nil(aPosProdSpec) )
            {
                SET_MSG_RC( strBank_lotPreparation_CheckForWaferSorter_out,
                            MSG_NOT_FOUND_PRODUCTSPEC,
                            RC_NOT_FOUND_PRODUCTSPEC );

                return RC_NOT_FOUND_PRODUCTSPEC;
            }
//Q3000124 end

            CORBA::String_var tmpSourceLotProduct;
            try
            {
                tmpSourceLotProduct = aPosProdSpec->getIdentifier();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosProductSpecification::getIdentifier)

//P4100313            cout << "#### length of strSourceLotProduct [" << CIMFWStrLen(strSourceLotProduct) << "]" << endl;
            PPT_METHODTRACE_V2("","#### length of strSourceLotProduct ....",CIMFWStrLen(strSourceLotProduct) );    //P4100313

            if ( 0 == CIMFWStrLen(strSourceLotProduct) )
            {
                PPT_METHODTRACE_V1("","0 == CIMFWStrLen(strSourceLotProduct)");

                strSourceLotProduct = CIMFWStrDup( tmpSourceLotProduct );        //P5100093
//P5100093                strSourceLotProduct = tmpSourceLotProduct;
            }
            else
            {
                PPT_METHODTRACE_V1("","0 != CIMFWStrLen(strSourceLotProduct)");

//P4100313                cout << "#### strSourceLotProduct [" << strSourceLotProduct << "]" << endl;
//P4100313                cout << "#### tmpSourceLotProduct [" << tmpSourceLotProduct << "]" << endl;
                PPT_METHODTRACE_V2("","#### strSourceLotProduct ...",strSourceLotProduct);    //P4100313 
                PPT_METHODTRACE_V2("","#### tmpSourceLotProduct ...",tmpSourceLotProduct);    //P4100313
  
                if ( 0 != CIMFWStrCmp(strSourceLotProduct, tmpSourceLotProduct) )
                {
                    PPT_METHODTRACE_V1("","strSourceLotProduct != tmpSourceLotProduct");
                    SET_MSG_RC( strBank_lotPreparation_CheckForWaferSorter_out,
                                MSG_INVALID_SOURCELOT_COMBINATION,
                                RC_INVALID_SOURCELOT_COMBINATION );

                    return RC_INVALID_SOURCELOT_COMBINATION;
                }
            }
        }

        //------------------------------------------
        // Check source lot Wafer Contents
        //------------------------------------------
        lenLotAttr = strNewLotAttributes.strNewWaferAttributes.length();

        PPT_METHODTRACE_V2("","Check source lot Wafer Contents  lenLotAttr", lenLotAttr);

        for ( i=0; i < lenLotAttr; i++ )
        {
            // check requested wafer existance and
            // STB Allocated Flag of each wafer
            PosWafer_var aPosWafer;
            PPT_CONVERT_WAFERID_TO_WAFER_OR( aPosWafer,
                                             strNewLotAttributes.strNewWaferAttributes[i].sourceWaferID,
                                             strBank_lotPreparation_CheckForWaferSorter_out,
                                             bank_lotPreparation_CheckForWaferSorter );

            CORBA::Boolean bWaferFoundFlag;
            try
            {
                bWaferFoundFlag = aPosWafer->isSTBAllocated();
            }
            CATCH_AND_RAISE_EXCEPTIONS(PosWafer::isSTBAllocated)

            if ( bWaferFoundFlag == TRUE )
            {
                PPT_METHODTRACE_V1("","bWaferFoundFlag == TRUE");

                CORBA::String_var strWaferID;
                try
                {
                    strWaferID = aPosWafer->getIdentifier();
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosWafer::getIdentifier)

                PPT_SET_MSG_RC_KEY( strBank_lotPreparation_CheckForWaferSorter_out,
                                    MSG_WAFER_ALLOCATED,
                                    RC_WAFER_ALLOCATED,
                                    strWaferID );

                return RC_WAFER_ALLOCATED;
            }
        }

        PPT_METHODTRACE_EXIT("PPTManager_i::bank_lotPreparation_CheckForWaferSorter");

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strBank_lotPreparation_CheckForWaferSorter_out, bank_lotPreparation_CheckForWaferSorter, methodName)
}
