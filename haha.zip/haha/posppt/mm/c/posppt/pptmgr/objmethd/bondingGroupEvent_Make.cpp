//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2010. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2010. All rights reserved.
//
// SiView
// Name: bondingGroupEvent_Make.cpp
//

#include "pptmgr.hpp"
#include "pevbase.hh"

// Class: PPTManager
//
// Service: bondingGroupEvent_Make()
//
// Change history:
// Date       Defect#      Person         Comments
// ---------- ------------ -------------- -------------------------------------------
// 2010-03-31 DSIV00001830 R.Iriguchi     Wafer Stacking Support
//
//[Function Description]:
//    This function makes Bonding Group change event.
//
//[Input Parameters]:
//  const pptObjCommonIn&                       strObjCommonIn
//  const objBondingGroupEvent_Make_in&         strBondingGroupEvent_Make_in
//
//  //InParameter of bondingGroupEvent_Make
//  typedef struct objBondingGroupEvent_Make_in_struct {
//      string                              action;                                 //<i>Action
//                                                                                      //<c>SP_BondingGroup_Action_Create
//                                                                                      //<c>SP_BondingGroup_Action_Update
//                                                                                      //<c>SP_BondingGroup_Action_Delete
//                                                                                      //<c>SP_BondingGroup_Action_PartialRelease
//      pptBondingGroupInfo                 strBondingGroupInfo;                    //<i>Bonding Group Information
//      pptBondingMapInfoSequence           strPartialReleaseSourceMapSeq;          //<i>Bonding Map Information for TxBondingGroupPartialReleaseReq
//      any                                 siInfo;                                 //<i>Reserved for SI customization
//  } objBondingGroupEvent_Make_in;
//
//[Output Parameters]:
//  objBondingGroupEvent_Make_out&              strBondingGroupEvent_Make_out
//
//  typedef objBase_out objBondingGroupEvent_Make_out;
//
//[Return Value]:
//
//  Return Code                        Message ID
//  ---------------------------------- -----------------------------------------
//  RC_OK                              MSG_OK
//
CORBA::Long PPTManager_i::bondingGroupEvent_Make(
    objBondingGroupEvent_Make_out&              strBondingGroupEvent_Make_out,
    const pptObjCommonIn&                       strObjCommonIn,
    const objBondingGroupEvent_Make_in&         strBondingGroupEvent_Make_in )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY( "PPTManager_i::bondingGroupEvent_Make" );

        //--------------//
        //  Initialize  //
        //--------------//
        CORBA::Long rc = RC_OK;
        posBondingGroupEventRecord anEventRecord;

        //-----------------//
        //  Set Event Data //
        //-----------------//
        anEventRecord.eventCommon.transactionID  = strObjCommonIn.transactionID;
        anEventRecord.eventCommon.eventTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
        anEventRecord.eventCommon.eventShopDate  = strObjCommonIn.strTimeStamp.reportShopdate;
        anEventRecord.eventCommon.userID         = strObjCommonIn.strUser.userID.identifier;
        anEventRecord.eventCommon.eventMemo      = strBondingGroupEvent_Make_in.strBondingGroupInfo.claimMemo;
        anEventRecord.action                     = strBondingGroupEvent_Make_in.action;
        anEventRecord.bondingGroupID             = strBondingGroupEvent_Make_in.strBondingGroupInfo.bondingGroupID;
        anEventRecord.bondingGroupStatus         = strBondingGroupEvent_Make_in.strBondingGroupInfo.bondingGroupState;
        anEventRecord.equipmentID                = strBondingGroupEvent_Make_in.strBondingGroupInfo.targetEquipmentID.identifier;
        anEventRecord.controlJobID               = strBondingGroupEvent_Make_in.strBondingGroupInfo.controlJobID.identifier;

        const pptBondingMapInfoSequence& strBondingMapInfoSeq = strBondingGroupEvent_Make_in.strBondingGroupInfo.strBondingMapInfoSequence;
        CORBA::Long mapLen = strBondingMapInfoSeq.length();
        anEventRecord.bondingMapInfos.length( mapLen );
        for ( CORBA::Long mapCnt = 0; mapCnt < mapLen; mapCnt++ )
        {
            if ( CIMFWStrCmp( strBondingGroupEvent_Make_in.action, SP_BondingGroupAction_PartialRelease ) == 0 )
            {
                anEventRecord.bondingMapInfos[mapCnt].action = CIMFWStrDup( SP_BondingGroupAction_PartialReleaseDestination );

            }
            else
            {
                anEventRecord.bondingMapInfos[mapCnt].action = strBondingGroupEvent_Make_in.action;
            }

            anEventRecord.bondingMapInfos[mapCnt].bondingGroupID = strBondingGroupEvent_Make_in.strBondingGroupInfo.bondingGroupID;
            anEventRecord.bondingMapInfos[mapCnt].bondingSeqNo   = mapCnt;

            anEventRecord.bondingMapInfos[mapCnt].baseLotID       = strBondingMapInfoSeq[mapCnt].baseLotID.identifier;
            anEventRecord.bondingMapInfos[mapCnt].baseProductID   = strBondingMapInfoSeq[mapCnt].baseProductID.identifier;
            anEventRecord.bondingMapInfos[mapCnt].baseWaferID     = strBondingMapInfoSeq[mapCnt].baseWaferID.identifier;
            anEventRecord.bondingMapInfos[mapCnt].baseBondingSide = strBondingMapInfoSeq[mapCnt].baseBondingSide;

            if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].actualTopLotID.identifier ) > 0 )
            {
                anEventRecord.bondingMapInfos[mapCnt].topLotID       = strBondingMapInfoSeq[mapCnt].actualTopLotID.identifier;
            }
            else
            {
                anEventRecord.bondingMapInfos[mapCnt].topLotID       = strBondingMapInfoSeq[mapCnt].planTopLotID.identifier;
            }
            if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].actualTopProductID.identifier ) > 0 )
            {
                anEventRecord.bondingMapInfos[mapCnt].topProductID   = strBondingMapInfoSeq[mapCnt].actualTopProductID.identifier;
            }
            else
            {
                anEventRecord.bondingMapInfos[mapCnt].topProductID   = strBondingMapInfoSeq[mapCnt].planTopProductID.identifier;
            }
            if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier ) > 0 )
            {
                anEventRecord.bondingMapInfos[mapCnt].topWaferID     = strBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier;
            }
            else
            {
                anEventRecord.bondingMapInfos[mapCnt].topWaferID     = strBondingMapInfoSeq[mapCnt].planTopWaferID.identifier;
            }
            if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].actualTopBondingSide ) > 0 )
            {
                anEventRecord.bondingMapInfos[mapCnt].topBondingSide = strBondingMapInfoSeq[mapCnt].actualTopBondingSide;
            }
            else
            {
                anEventRecord.bondingMapInfos[mapCnt].topBondingSide = strBondingMapInfoSeq[mapCnt].planTopBondingSide;
            }
        }

        if ( CIMFWStrCmp( strBondingGroupEvent_Make_in.action, SP_BondingGroupAction_PartialRelease ) == 0 )
        {
            const pptBondingMapInfoSequence& strBondingMapInfoSeq = strBondingGroupEvent_Make_in.strPartialReleaseSourceMapSeq;
            CORBA::Long mapLen2 = strBondingMapInfoSeq.length();
            anEventRecord.bondingMapInfos.length( mapLen + mapLen2 );
            for ( CORBA::Long mapCnt = 0; mapCnt < mapLen2; mapCnt++ )
            {
                anEventRecord.bondingMapInfos[mapLen + mapCnt].action = CIMFWStrDup( SP_BondingGroupAction_PartialReleaseSource );

                anEventRecord.bondingMapInfos[mapLen + mapCnt].bondingGroupID = strBondingGroupEvent_Make_in.strBondingGroupInfo.bondingGroupID;
                anEventRecord.bondingMapInfos[mapLen + mapCnt].bondingSeqNo   = mapCnt;

                anEventRecord.bondingMapInfos[mapLen + mapCnt].baseLotID       = strBondingMapInfoSeq[mapCnt].baseLotID.identifier;
                anEventRecord.bondingMapInfos[mapLen + mapCnt].baseProductID   = strBondingMapInfoSeq[mapCnt].baseProductID.identifier;
                anEventRecord.bondingMapInfos[mapLen + mapCnt].baseWaferID     = strBondingMapInfoSeq[mapCnt].baseWaferID.identifier;
                anEventRecord.bondingMapInfos[mapLen + mapCnt].baseBondingSide = strBondingMapInfoSeq[mapCnt].baseBondingSide;

                if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].actualTopLotID.identifier ) > 0 )
                {
                    anEventRecord.bondingMapInfos[mapLen + mapCnt].topLotID       = strBondingMapInfoSeq[mapCnt].actualTopLotID.identifier;
                }
                else
                {
                    anEventRecord.bondingMapInfos[mapLen + mapCnt].topLotID       = strBondingMapInfoSeq[mapCnt].planTopLotID.identifier;
                }
                if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].actualTopProductID.identifier ) > 0 )
                {
                    anEventRecord.bondingMapInfos[mapLen + mapCnt].topProductID   = strBondingMapInfoSeq[mapCnt].actualTopProductID.identifier;
                }
                else
                {
                    anEventRecord.bondingMapInfos[mapLen + mapCnt].topProductID   = strBondingMapInfoSeq[mapCnt].planTopProductID.identifier;
                }
                if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier ) > 0 )
                {
                    anEventRecord.bondingMapInfos[mapLen + mapCnt].topWaferID     = strBondingMapInfoSeq[mapCnt].actualTopWaferID.identifier;
                }
                else
                {
                    anEventRecord.bondingMapInfos[mapLen + mapCnt].topWaferID     = strBondingMapInfoSeq[mapCnt].planTopWaferID.identifier;
                }
                if ( CIMFWStrLen( strBondingMapInfoSeq[mapCnt].actualTopBondingSide ) > 0 )
                {
                    anEventRecord.bondingMapInfos[mapLen + mapCnt].topBondingSide = strBondingMapInfoSeq[mapCnt].actualTopBondingSide;
                }
                else
                {
                    anEventRecord.bondingMapInfos[mapLen + mapCnt].topBondingSide = strBondingMapInfoSeq[mapCnt].planTopBondingSide;
                }
            }
        }

        //-----------------//
        //  Put Event Data //
        //-----------------//
        CORBA::Any       eventRecord;
        eventRecord <<= anEventRecord;

        PosEventBase_var anEvent;
        try
        {
            anEvent = theEventManager->createEvent( eventRecord );
        }
        catch( const PosEventManager::InvalidEventRecordTypeSignal& )
        {
            SET_FW_MSG_RC_NO_KEY( strBondingGroupEvent_Make_out,
                                  bondingGroupEvent_Make,
                                  MSG_INVALID_EVENTRECORD_TYPE,
                                  RC_INVALID_EVENTRECORD_TYPE,
                                  PosEventManager::createEvent,
                                  PosEventManager::InvalidEventRecordTypeSignal );
            return RC_INVALID_EVENTRECORD_TYPE;
        }
        CATCH_AND_RAISE_EXCEPTIONS( PosEventManager::createEvent )

        //--------------------//
        //  Return to Caller  //
        //--------------------//
        PPT_METHODTRACE_EXIT( "PPTManager_i::bondingGroupEvent_Make" );
        return RC_OK ;
    }
    CATCH_GLOBAL_EXCEPTIONS( strBondingGroupEvent_Make_out, bondingGroupEvent_Make, methodName );
}
