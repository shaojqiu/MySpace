#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/backupOperationEvent_Make.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:28:47 [ 7/13/07 19:28:48 ]";
#endif

//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: .cpp
//

#include "pptmgr.hpp"
#include "plot.hh"
#include "pevmggl.hh"
#include "pevbase.hh"

// Class: PPTManager
//
// Service:
//
// Change history:
// Date     Defect#  Person         Comments
// -------- -------- -------------- -------------------------------------------
// 09/08/02 D4200062 K.Kido         Initial release for backupOperation(Rel4.2).
//
//[Function Description]:
//    This transaction provide the function which make event record for backupOperation.
//
//[Input Parameters]:
//  in  pptObjCommonIn            strObjCommonIn;
//  in  string                    request;
//  in  objectIdentifier          lotID;
//  in  pptBackupAddress          strBackupAddress;
//  in  pptBackupProcess          strBackupProcess;
//
//[Output Parameters]:
//  out objBackupOperationEvent_Make_out   strBackupOperationEvent_Make_out;
//
//  typedef struct objBackupOperationEvent_Make_struct {
//      pptRetCode                strResult;
//      any siInfo;
//  } objBackupOperationEvent_Make_out;
//
//[Return Value]:
//
//  Return Code                   Messsage ID
//  ---------------------------   ------------------------------------------------
//  RC_OK
//  RC_INVALID_EVENTRECORD_TYPE
//

CORBA::Long PPTManager_i::backupOperationEvent_Make(
    objBackupOperationEvent_Make_out& strBackupOperationEvent_Make_out,
    const pptObjCommonIn&             strObjCommonIn,
    const char *                      request,
    const objectIdentifier&           lotID,
    const pptBackupAddress&           strBackupAddress,
    const pptBackupProcess&           strBackupProcess,
    const char*                       claimMemo )
{
    char* methodName = NULL ;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::backupOperationEvent_Make");
        //------------------
        // Initialize
        //------------------
        posBackupOperationEventRecord aBackupOperationEventRecord;
        PosLot_var aPosLot;
        PPT_CONVERT_LOTID_TO_LOT_OR( aPosLot,
                                     lotID,
                                     strBackupOperationEvent_Make_out,
                                     backupOperationEvent_Make );

        //------------------
        // Put Event Data
        //------------------
        posLotEventData_var lotEventData;
        try
        {
             lotEventData = aPosLot->getEventData();
        }
        CATCH_AND_RAISE_EXCEPTIONS( PosLot::getEventData )

        aBackupOperationEventRecord.lotData = (*lotEventData);

        aBackupOperationEventRecord.request              = request;
        aBackupOperationEventRecord.hostName             = strBackupAddress.hostName            ;
        aBackupOperationEventRecord.serverName           = strBackupAddress.serverName          ;
        aBackupOperationEventRecord.itDaemonPort         = strBackupAddress.itDaemonPort        ;
        aBackupOperationEventRecord.entryRouteID         = strBackupProcess.entryRouteID        ;
        aBackupOperationEventRecord.entryOperationNumber = strBackupProcess.entryOperationNumber;
        aBackupOperationEventRecord.exitRouteID          = strBackupProcess.exitRouteID         ;
        aBackupOperationEventRecord.exitOperationNumber  = strBackupProcess.exitOperationNumber ;

        aBackupOperationEventRecord.eventCommon.transactionID  = strObjCommonIn.transactionID;
        aBackupOperationEventRecord.eventCommon.userID         = strObjCommonIn.strUser.userID.identifier;
        aBackupOperationEventRecord.eventCommon.eventTimeStamp = strObjCommonIn.strTimeStamp.reportTimeStamp;
        aBackupOperationEventRecord.eventCommon.eventShopDate  = strObjCommonIn.strTimeStamp.reportShopdate;
        aBackupOperationEventRecord.eventCommon.eventMemo      = claimMemo;

        //-----------------------------------------
        // Send event data to Event Manager
        //-----------------------------------------
        PosEventBase_var anEvent ;
        CORBA::Any eventRecord;
        eventRecord <<= aBackupOperationEventRecord;

        try
        {
            anEvent = theEventManager->createEvent(eventRecord);
        }
        catch( PosEventManager::InvalidEventRecordTypeSignal )
        {
            SET_FW_MSG_RC_NO_KEY( strBackupOperationEvent_Make_out,
                                  backupOperationEvent_Make,
                                  MSG_INVALID_EVENTRECORD_TYPE,
                                  RC_INVALID_EVENTRECORD_TYPE,
                                  PosEventManager::createEvent,
                                  PosEventManager::InvalidEventRecordTypeSignal );
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosEventManager::createEvent)

        /*----------------------*/
        /*   Return to Caller   */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("PPTManager_i::backupOperationEvent_Make");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strBackupOperationEvent_Make_out, backupOperationEvent_Make, methodName)
}
