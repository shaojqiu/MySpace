#ifndef lint
static char *sccsid =  "@(#) 1.2 superpos/src/spppt/source/posppt/pptmgr/objmethd/bank_lotPreparationForWaferSorter.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 5/8/08 18:56:33 [ 5/8/08 18:56:34 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: bank_lotPreparationForWaferSorter.cpp
//

#include "pptmgr.hpp"

#include "plot.hh"
#include "pbank.hh"
#include "pprrq.hh"
#include "pperson.hh"
#include "pprsp.hh"
#include "plotfm.hh"    //D6000389


//[Object Function Name]: long   bank_lotPreparationForWaferSorter
//
// Date        Level  Author         Note
// ----------  ----------  -------------  -------------------------------------------
// 2001/09/03  D4000056    M.Shimizu      The first coding (WaferSorter R40 CORE)
// 2002/01/17  P4100071    H.Adachi       Recycle Count of Wafer is Invalid when VendorLotPrepare
// 2002/09/25  P4200192    H.Adachi       Add Nil Check
// 2005/09/02  D6000389    K.Kido         Split Number adjustment / Lot Family duplication check
// 2008/05/08  P9000282    M.Ogawa        Display appropriate error message
//
//
//[Function Description]
//  * Cancel relation between current carrier - current lot - current wafers
//  * Create lot and wafer information with input parameters
//  * Create new relation between lot and wafer
//  * if assignID is filled, re-assign wafer ID
//  * Set created lotID to createdLotID of out parameter.
//  * Relation between created lot and carrier is not created by this method.
//  * 1st source lot's vendor lot ID and vendor ID is taken over to new lot.
//  * for WaferSorter
//
//
//  Created Lot should have the following status
//  (1) ProductRequest
//       - Planning State     : Planned
//       - Production State   : Completed
//  (2) Lot
//       - Lot State          : Finished
//       - Production State   : InProduction
//       - Hold State         : NotOnHold
//       - Finished State     : Completed
//       - Process State      : Processed
//       - Inventory State    : InBank
//
//
//[Input Parameters]:
//  in  pptObjCommonIn          strObjCommonIn;
//  in  objectIdentifier        productRequestID;
//  in  objectIdentifier        bankID;
//  in  pptNewLotAttributes     strNewLotAttributes,
//
//
//[Output Parameters]:
//
//  out objBank_LotPreparationForWaferSorter_out  strBank_LotPreparationForWaferSorter_out;
//
//  typedef struct objBank_LotPreparationForWaferSorter_out_struct {
//     pptRetCode         strResult;
//     objectIdentifier   createdLotID;
//  } objBank_LotPreparationForWaferSorter_out;
//
//[Return Value]:
//
//  Return Code                 Messsage ID
//  -------------------------   --------------------------------------------------
//  RC_OK                       MSG_OK
//  RC_CAST_NOT_EMPTY           MSG_CAST_NOT_EMPTY
//  RC_NOT_FOUND_CASSETTE       MSG_NOT_FOUND_CASSETTE
//  RC_NOT_FOUND_LOT            MSG_NOT_FOUND_LOT
//  RC_INVALID_LOT_TYPE         MSG_INVALID_LOT_TYPE
//  RC_NOT_FOUND_WAFER          MSG_NOT_FOUND_WAFER
//  RC_NOT_FOUND_PRODUCTSPEC    MSG_NOT_FOUND_PRODUCTSPEC
//  RC_DUPLICATE_SLOTNO         MSG_DUPLICATE_SLOTNO
//  RC_LOCKED_BY_ANOTHER        MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR             MSG_SYSTEM_ERROR
//
//[Pseudo Code]:
//

CORBA::Long PPTManager_i::bank_lotPreparationForWaferSorter(
                                objBank_LotPreparationForWaferSorter_out& strBank_LotPreparationForWaferSorter_out,
                                const pptObjCommonIn& strObjCommonIn,
                                const objectIdentifier& productRequestID,
                                const objectIdentifier& bankID,
                                const pptNewLotAttributes& strNewLotAttributes )
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::bank_lotPreparation");
        CORBA::Long rc = RC_OK;

        PosLot_var aSourceLot;
        CORBA::Long NWALength;
        NWALength = strNewLotAttributes.strNewWaferAttributes.length();
        if (NWALength == 0)
        {
            PPT_METHODTRACE_V1("", "strNewLotAttributes.strNewWaferAttributes.length() == 0");
            SET_MSG_RC(strBank_LotPreparationForWaferSorter_out, MSG_INVALID_INPUT_PARM, RC_INVALID_INPUT_PARM);
            return(RC_INVALID_INPUT_PARM);
        }

        PPT_CONVERT_LOTID_TO_LOT_OR( aSourceLot,
                                     strNewLotAttributes.strNewWaferAttributes[0].sourceLotID,
                                     strBank_LotPreparationForWaferSorter_out,
                                     bank_lotPreparationForWaferSorter );

        //------------------------------------------
        // Get total count of Vendor Lot's Wafer
        //------------------------------------------
        CORBA::Long productCount = strNewLotAttributes.strNewWaferAttributes.length();

        PPT_METHODTRACE_V2("","Get total count of Vendor Lot's Wafer", productCount);

        PosBank_var aPosBank;
        PPT_CONVERT_BANKID_TO_BANK_OR( aPosBank,
                                   bankID,
                                   strBank_LotPreparationForWaferSorter_out,
                                   bank_lotPreparationForWaferSorter );

        //------------------------
        // Get Product Request object reference
        //------------------------
        PosProductRequest_var prdReq;
        PPT_CONVERT_PRODUCTREQUESTID_TO_PRODUCTREQUEST_OR( prdReq,
                                                           productRequestID,
                                                           strBank_LotPreparationForWaferSorter_out,
                                                           bank_lotPreparationForWaferSorter,
                                                           productRequestID.identifier ); 

        //------------------------
        // Create new lot
        //------------------------
        PPT_METHODTRACE_V1("","Create new lot");

        Lot_var aLot;
        PosLot_var newLot;
        try
        {
            aLot = theProductManager->createLotUsing(prdReq);
            newLot = PosLot::_narrow(aLot);
        }
//P9000282 add start
        catch ( FrameworkErrorSignal &fes )
        {
            if ( fes.errorCode == SPFW_ERROR_INVALID_STATE )
            {
                ProductSpecification_var aProductSpecification ;
                CORBA::String_var aProdID ;
                try
                {
                    aProductSpecification = prdReq->getProductSpecification();

                    if(CORBA::is_nil( aProductSpecification ))
                    {
                        SET_MSG_RC( strBank_LotPreparationForWaferSorter_out,
                                    MSG_NOT_FOUND_PRODUCTSPEC, RC_NOT_FOUND_PRODUCTSPEC );
                        return RC_NOT_FOUND_PRODUCTSPEC ;
                    }
                }
                CATCH_AND_RAISE_EXCEPTIONS(PosProductRequest::getProductSpecification)

                try
                {
                    aProdID = aProductSpecification->getIdentifier() ;
                }
                CATCH_AND_RAISE_EXCEPTIONS(ProductSpecification::getIdentifier)

                PPT_SET_MSG_RC_KEY( strBank_LotPreparationForWaferSorter_out,
                                    MSG_INVALID_PRODUCT_STAT,
                                    RC_INVALID_PRODUCT_STAT,
                                    aProdID );

                return RC_INVALID_PRODUCT_STAT ;
            }
            else if( fes.errorCode == SPFW_DUPLICATEIDENTIFIERSIGNAL )
            {
                PPT_SET_MSG_RC_KEY( strBank_LotPreparationForWaferSorter_out,
                                    MSG_DUPLICATE_LOTID,
                                    RC_DUPLICATE_LOTID,
                                    productRequestID.identifier );

                return RC_DUPLICATE_LOTID;
            }
            else
            {
                APPERRLOG_FRAMEWORKERRORSIGNAL_FOR_PUREOBJ( fes );
                throw;
            }
        }
//P9000282 add end
        CATCH_AND_RAISE_EXCEPTIONS(ProductManager::createLotUsing) ;

        //P4200192 Add Start
        if ( CORBA::is_nil(newLot) )
        {
            PPT_SET_MSG_RC_KEY( strBank_LotPreparationForWaferSorter_out,
                                MSG_NOT_FOUND_LOT,
                                RC_NOT_FOUND_LOT,
                                "" );

            return RC_NOT_FOUND_LOT;
        }
        //P4200192 Add End

//D6000389 add start
        //-----------------------------------
        //   Adjust split number if need.
        //-----------------------------------
        LotFamily_var aLotFM;
        PosLotFamily_var aLotFamily;
        try
        {
            aLotFM = newLot->getLotFamily();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotFamily)

        aLotFamily = PosLotFamily::_narrow(aLotFM);

        if( CORBA::is_nil(aLotFamily) )
        {
            SET_MSG_RC(strBank_LotPreparationForWaferSorter_out, MSG_NOT_FOUND_LOTFAMILY, RC_NOT_FOUND_LOTFAMILY);
            return RC_NOT_FOUND_LOTFAMILY ;
        }

        CORBA::Boolean notInheritedFlag = FALSE;
        try
        {
            notInheritedFlag = aLotFamily->isNewlyCreated();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLotFamily::isNewlyCreated)

        PPT_METHODTRACE_V2("","notInheritedFlag = ", notInheritedFlag);

        if( notInheritedFlag )
        {
            CORBA::Long rc = RC_OK ;
            objectIdentifier lotFamilyID ;
            PPT_SET_OBJECT_IDENTIFIER( lotFamilyID,
                                       aLotFamily,
                                       strBank_LotPreparationForWaferSorter_out,
                                       bank_lotPreparationForWaferSorter,
                                       PosLotFamily ) ;

            char* duplicationAllowableFlag = getenv(SP_LOTFAMILY_DUPLICATION_ALLOWABLE_FLAG);
            if( 0 == CIMFWStrCmp( duplicationAllowableFlag, "0" ) )
            {
                objLotFamily_DuplicationCheckDR_out strLotFamily_DuplicationCheckDR_out;
                rc = lotFamily_DuplicationCheckDR( strLotFamily_DuplicationCheckDR_out,
                                                   strObjCommonIn,
                                                   lotFamilyID );
                if ( rc != RC_OK )
                {
                    PPT_METHODTRACE_V1("","lotFamily_DuplicationCheckDR != RC_OK");
                    strBank_LotPreparationForWaferSorter_out.strResult = strLotFamily_DuplicationCheckDR_out.strResult;
                    return rc;
                }
            }

            objLotFamily_splitNo_Adjust_out strLotFamily_splitNo_Adjust_out;
            rc = lotFamily_splitNo_Adjust( strLotFamily_splitNo_Adjust_out,
                                           strObjCommonIn,
                                           lotFamilyID );
            if ( rc != RC_OK )
            {
                PPT_METHODTRACE_V1("","lotFamily_splitNo_Adjust != RC_OK");
                strBank_LotPreparationForWaferSorter_out.strResult = strLotFamily_splitNo_Adjust_out.strResult;
                return rc;
            }
        }
//D6000389 add end

        //------------------------
        // Prepare output structure
        //------------------------
        PPT_METHODTRACE_V1("","Prepare output structure");

        PPT_SET_OBJECT_IDENTIFIER(strBank_LotPreparationForWaferSorter_out.createdLotID,
                                  newLot,
                                  strBank_LotPreparationForWaferSorter_out,
                                  bank_lotPreparationForWaferSorter,
                                  PosLot );

//P4100071 delete start (Move to bottom)
//        //------------------------
//        // wafer assigned lot change
//        //------------------------
//        PPT_METHODTRACE_V1("","wafer assigned lot change");
//
//        pptNewLotAttributes tmpNewLotAttributes;
//        tmpNewLotAttributes = strNewLotAttributes;
//        CORBA::Long i;
//        for ( i=0; i < productCount; i++ )
//        {
//            tmpNewLotAttributes.strNewWaferAttributes[i].newLotID = strBank_LotPreparationForWaferSorter_out.createdLotID;
//        }
//
//        objWafer_assignedLot_ChangeForWaferSorter_out strWafer_assignedLot_ChangeForWaferSorter_out;
//        rc = wafer_assignedLot_ChangeForWaferSorter( strWafer_assignedLot_ChangeForWaferSorter_out,
//                                       strObjCommonIn,
//                                       tmpNewLotAttributes.strNewWaferAttributes );
//
//        if ( rc != RC_OK )
//        {
//            PPT_METHODTRACE_V1("", "wafer_assignLot_ChangeForWaferSorter != RC_OK") ;
//            strBank_LotPreparationForWaferSorter_out.strResult = strWafer_assignedLot_ChangeForWaferSorter_out.strResult;
//            return rc;
//        }
//P4100071 delete end (Move to bottom)

        //------------------------------------------
        // retrieve vendor lot information
        //------------------------------------------
        PPT_METHODTRACE_V1("","retrieve vendor lot information");

        CORBA::String_var vendLotID;
        try
        {
            vendLotID = aSourceLot->getVendorLot();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getVendorLot) ;

        CORBA::String_var vend;
        try
        {
            vend = aSourceLot->getVendor();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getVendor) ;

        //------------------------------------------
        // Set Lot info
        //------------------------------------------
        PPT_METHODTRACE_V1("","Set Lot info");

        try
        {
            newLot->setAllStatesForVendorLot();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setAllStatesForVendorLot) ;
        try
        {
            newLot->setBank(aPosBank); 
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setBank) ;
        try
        {
            newLot->refreshQuantity();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::refreshQuantity) ;
        try
        {
            newLot->setVendorLot(vendLotID);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setVendorLot) ;
        try
        {
            newLot->setVendor(vend);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setVendor) ;
        try
        {
            newLot->setLastClaimedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setLastClaimedTimeStamp) ;

        PosPerson_var aPerson;
        PPT_GET_PERSON_FROM_USERID( aPerson,
                                    strObjCommonIn.strUser.userID,
                                    strBank_LotPreparationForWaferSorter_out,
                                    bank_lotPreparationForWaferSorter );

        try
        {
            newLot->setLastClaimedPerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setLastClaimedPerson) ;
        try
        {
            newLot->setStateChangedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setStateChangedTimeStamp) ;
        try
        {
            newLot->setStateChangedPerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setStateChangedPerson) ;
        try
        {
            newLot->setInventoryStateChangedTimeStamp(strObjCommonIn.strTimeStamp.reportTimeStamp);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setInventoryStateChangedTimeStamp) ;
        try
        {
            newLot->setInventoryStateChangedPerson(aPerson);
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::setInventoryStateChangedPerson) ;

        CORBA::String_var lotType;
        try
        {
            lotType = newLot->getLotType();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::getLotType) ;

        PPT_METHODTRACE_V2("", "lotType==SP_Lot_Type_ProductionLot or SP_Lot_Type_EngineeringLot or SP_Lot_Type_VendorLot", __LINE__);
        try
        {
            newLot->makeWaitUse();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosLot::makeWaitUse) ;

        //P4100071 add start (Move from before) 
        //------------------------
        // wafer assigned lot change
        //------------------------
        PPT_METHODTRACE_V1("","wafer assigned lot change");

        pptNewLotAttributes tmpNewLotAttributes;
        tmpNewLotAttributes = strNewLotAttributes;
        CORBA::Long i;
        for ( i=0; i < productCount; i++ )
        {
            tmpNewLotAttributes.strNewWaferAttributes[i].newLotID = strBank_LotPreparationForWaferSorter_out.createdLotID;
        }

        objWafer_assignedLot_ChangeForWaferSorter_out strWafer_assignedLot_ChangeForWaferSorter_out;
        rc = wafer_assignedLot_ChangeForWaferSorter( strWafer_assignedLot_ChangeForWaferSorter_out,
                                       strObjCommonIn,
                                       tmpNewLotAttributes.strNewWaferAttributes );

        if ( rc != RC_OK )
        {
            PPT_METHODTRACE_V1("", "wafer_assignLot_ChangeForWaferSorter != RC_OK") ;
            strBank_LotPreparationForWaferSorter_out.strResult = strWafer_assignedLot_ChangeForWaferSorter_out.strResult;
            return rc;
        }
        //P4100071 add end (Move from before) 

        PPT_METHODTRACE_EXIT("PPTManager_i::bank_lotPreparationForWaferSorter");

        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strBank_LotPreparationForWaferSorter_out, bank_lotPreparationForWaferSorter, methodName) ;
}
