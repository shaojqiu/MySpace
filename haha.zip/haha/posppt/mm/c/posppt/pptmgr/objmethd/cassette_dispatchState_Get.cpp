#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/cassette_dispatchState_Get.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:34:25 [ 7/13/07 19:34:27 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: cassette_dispatchState_Get.cpp
//

#include "pptmgr.hpp"
#include "timstamp.hpp"
#include "duration.hpp"

#include "pcas.hh"
#include "plot.hh"
#include "pperson.hh"
#include "pstmc.hh"
#include "pmc.hh"
#include "pbufrs.hh"
#include "pmaloc.hh"
//D5000016 #include "ppcgrp.hh"

//[Object Function Name]: long   cassette_dispatchState_Get
//
// Date       Level    Author         Note
// ---------- -----    -------------  -------------------------------------------
// 1999-02-15 0.00     Y.Iwasaki      Initial Release                     (R20)
//                                    *Pseudo code is not implemented yet (R20)
// 1999-02-15 0.01     Y.Iwasaki      Pseudo code Release                 (R20)
// 2000/09/12 P3000139 T.Yamano       SET_MSG_RC(MSG_OK,RC_OK) Comment Out
// 2003/05/20 D5000016 K.Kido         Useless class deletion(R5.0).
//
//[Function Description]:
//  Get dispatch reserved status of cassette, and set to out parameter.
//
//[Input Parameters]:
//  in  pptObjCommonIn        strObjCommonIn;
//  in  objectIdentifier      cassetteID;
//
//[Output Parameters]:
//  out objCassette_dispatchState_Get_out   strCassette_dispatchState_Get_out;
//
//  typedef struct objCassette_reservedState_Get_out_struct {
//      pptRetCode            strResult;
//      boolean               dispatchReservedFlag;
//  } objCassette_dispatchState_Get_out;
//
//
//[Return Value]:
//
//  Return Code               Messsage ID
//  ------------------------- --------------------------------------------------
//  RC_OK                     MSG_OK
//  RC_NOT_FOUND_CASSETTE     MSG_NOT_FOUND_CASSETTE
//  RC_LOCKED_BY_ANOTHER      MSG_LOCKED_BY_ANOTHER
//  RC_SYSTEM_ERROR           MSG_SYSTEM_ERROR
//

CORBA::Long PPTManager_i::cassette_dispatchState_Get(
                                   objCassette_dispatchState_Get_out& strCassette_dispatchState_Get_out,
                                   const pptObjCommonIn&              strObjCommonIn,
                                   const objectIdentifier&            cassetteID)
{
    char * methodName = NULL;
    try {

        PPT_METHODTRACE_ENTRY("PPTManager_i::cassette_dispatchState_Get");

        /*----------------*/
        /*   Initialize   */
        /*----------------*/
//P3000139        SET_MSG_RC( strCassette_dispatchState_Get_out, MSG_OK, RC_OK )

        CORBA::Long    rc = RC_OK;

        /*-------------------------*/
        /*   Get Cassette Object   */
        /*-------------------------*/
        PosCassette_var aCassette;
        PPT_CONVERT_CASSETTEID_TO_CASSETTE_OR( aCassette,
                                               cassetteID,
                                               strCassette_dispatchState_Get_out,
                                               cassette_dispatchState_Get )

        /*--------------------------------*/
        /*   Get Current Dispatch State   */
        /*--------------------------------*/
        try {
           strCassette_dispatchState_Get_out.dispatchReservedFlag = aCassette->isDispatchReserved();
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosCassette::isDispatchReserved)

        /*----------------------*/
        /*   Return to Caller   */
        /*----------------------*/
        PPT_METHODTRACE_EXIT("PPTManager_i::cassette_dispatchState_Get");

        return( RC_OK );

    }
    CATCH_GLOBAL_EXCEPTIONS(strCassette_dispatchState_Get_out, cassette_dispatchState_Get, methodName)
}

