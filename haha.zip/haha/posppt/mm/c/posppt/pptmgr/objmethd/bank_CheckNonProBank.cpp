#ifndef lint
static char *sccsid =  "@(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/objmethd/bank_CheckNonProBank.cpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 19:29:18 [ 7/13/07 19:29:19 ]";
#endif
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView
// Name: bank_CheckNonProBank.cpp
//

#include "pptmgr.hpp"
#include "pbank.hh"

// Class: PPTManager
//
// Service: bank_CheckNonProBank()
//
// Change history:
// Date     Defect#  Person         Comments
// -------- -------- -------------- -------------------------------------------
//
// Description:
//
// Return:
//     Long
//
// Parameter:
//    const pptObjCommonIn& strObjCommonIn
//    objectIdentifier& bankID
//    objBank_CheckNonProBank_out& strBank_CheckNonProBank_out
//
// Require:
//
// Ensure:
//
// Exception:
//
// Pseudo code:
//

CORBA::Long PPTManager_i::bank_CheckNonProBank( objBank_CheckNonProBank_out& strBank_CheckNonProBank_out , const pptObjCommonIn& strObjCommonIn , const objectIdentifier& bankID)
{
    char * methodName = NULL;
    try
    {
        PPT_METHODTRACE_ENTRY("PPTManager_i::bank_CheckNonProBank");

        PosBank_var aBank ;
        PPT_CONVERT_BANKID_TO_BANK_OR( aBank , bankID , strBank_CheckNonProBank_out , bank_CheckNonProBank )

        try
        {
            if( aBank->isProductionBank() == TRUE )
            {
                SET_MSG_RC(strBank_CheckNonProBank_out,MSG_NOT_NONPROBANK,RC_NOT_NONPROBANK)
                PPT_METHODTRACE_EXIT("PPTManager_i::bank_CheckNonProBank");
                return RC_NOT_NONPROBANK ;
            }
        }
        CATCH_AND_RAISE_EXCEPTIONS(PosBank::isProductionBank)

        PPT_METHODTRACE_EXIT("PPTManager_i::bank_CheckNonProBank");
        return RC_OK;
    }
    CATCH_GLOBAL_EXCEPTIONS(strBank_CheckNonProBank_out, bank_CheckNonProBank, methodName)
}
