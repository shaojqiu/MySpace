// SCCS ID: @(#) 1.1 superpos/src/spppt/source/posppt/pptmgr/factory/bosfwpptmgr.hpp, mm_srv_90e_ppt, mm_srv_90e_ppt 7/13/07 21:07:41 [ 7/13/07 21:07:43 ]
//
// (c) Copyright: IBM Japan Services Company Ltd, 1997, 2008. All rights reserved.
// (c) Copyright: International Business Machines Corporation, 1997, 2008. All rights reserved.
//
// SiView - PPT Manager
// Name: bosfwpptmgr.hpp
//
// Change history:
//
// Date     Defect#  Person         Comments
// -------- -------- -------------- -------------------------------------------
//

#include "IMProt.h"

void global_func_BOSPPTMgr( GlobalComposedObjectTable *GCOT ) ;
